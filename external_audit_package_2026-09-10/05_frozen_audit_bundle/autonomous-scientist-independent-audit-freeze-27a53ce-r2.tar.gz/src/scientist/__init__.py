"""Reality-grounded autonomous discovery kernel."""

__version__ = "0.1.0"

