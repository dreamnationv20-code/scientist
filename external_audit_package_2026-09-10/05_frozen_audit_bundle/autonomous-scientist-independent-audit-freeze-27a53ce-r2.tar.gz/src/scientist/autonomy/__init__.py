"""Contracts and evaluators for autonomy-closure research."""

from scientist.autonomy.authority_contracts import (
    ACTION_AUTHORITY_CONTRACTS,
    ActionAuthorityContract,
    audit_component_pack,
    authority_contract,
    validate_component_execution,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    AuthoritativeResearchLedger,
    AuthoritativeStateRuntime,
    AutonomyEventKind,
    ResourceBudget,
    ResourceUsage,
    RunStatus,
    SubsystemSnapshot,
    UnifiedResearchState,
)
from scientist.autonomy.transitions import (
    FailureClass,
    RecoveryAction,
    TransitionAuthority,
    TransitionCase,
    TransitionDecision,
    TransitionScore,
    evaluate_transition_decision,
)

__all__ = [
    "ActorIdentity",
    "ActorKind",
    "AuthorityScope",
    "ACTION_AUTHORITY_CONTRACTS",
    "ActionAuthorityContract",
    "AuthoritativeResearchLedger",
    "AuthoritativeStateRuntime",
    "AutonomyEventKind",
    "FailureClass",
    "RecoveryAction",
    "ResourceBudget",
    "ResourceUsage",
    "RunStatus",
    "SubsystemSnapshot",
    "TransitionAuthority",
    "TransitionCase",
    "TransitionDecision",
    "TransitionScore",
    "UnifiedResearchState",
    "audit_component_pack",
    "authority_contract",
    "evaluate_transition_decision",
    "validate_component_execution",
]
