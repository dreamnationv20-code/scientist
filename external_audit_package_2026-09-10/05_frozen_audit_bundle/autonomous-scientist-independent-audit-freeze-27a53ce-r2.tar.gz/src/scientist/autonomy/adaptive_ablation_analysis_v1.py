from __future__ import annotations

from collections import Counter
from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_confirmatory_analysis_v1 import exact_mcnemar
from scientist.autonomy.adaptive_three_arm_v1 import ARM_SCIENTIST, AdaptiveAblation
from scientist.autonomy.adaptive_worlds_v1 import FaultClass, ScientificState
from scientist.core.artifacts import content_digest


ABLATION_ANALYSIS_VERSION = "adaptive-mechanistic-ablation-analysis-v1"


def analyze_adaptive_ablations(
    primary: Mapping[str, Any], ablations: Mapping[str, Any]
) -> Mapping[str, Any]:
    primary_body = dict(primary)
    primary_id = primary_body.pop("confirmatory_run_id", None)
    ablation_body = dict(ablations)
    ablation_id = ablation_body.pop("ablation_run_id", None)
    if not primary_id or content_digest(primary_body) != primary_id:
        raise ValueError("primary confirmatory run identity is invalid")
    if not ablation_id or content_digest(ablation_body) != ablation_id:
        raise ValueError("ablation run identity is invalid")
    if primary["freeze_id"] != ablations["freeze_id"]:
        raise ValueError("primary and ablation runs target different freezes")
    if ablations.get("status") != "complete" or ablations.get("task_count") != 90:
        raise ValueError("ablation run is incomplete")
    task_refs = sorted(ablations["task_strata"])
    if len(task_refs) != 90:
        raise ValueError("ablation task set is incomplete")
    primary_results = primary["results"]
    ablation_results = ablations["results"]
    expected_profiles = {
        profile.value
        for profile in AdaptiveAblation
        if profile != AdaptiveAblation.NONE
    }
    if set(ablations.get("profiles", ())) != expected_profiles:
        raise ValueError("ablation profiles are incomplete")
    observed_cells = Counter(
        (
            value["scientific_state"],
            int(value["variable_count"]),
            value["fault_class"],
        )
        for value in ablations["task_strata"].values()
    )
    expected_cells = {
        (state.value, width, fault.value): 1
        for state in ScientificState
        for width in (5, 6, 7)
        for fault in FaultClass
    }
    if observed_cells != expected_cells:
        raise ValueError("ablation subset is not one task per crossed cell")
    expected_slots = {
        f"{task}|{profile}"
        for task in task_refs
        for profile in expected_profiles
    }
    result_identities_valid = all(
        value.get("result_id")
        == content_digest(
            {key: item for key, item in value.items() if key != "result_id"}
        )
        for value in ablation_results.values()
    )
    token_accounts_exact = all(
        value.get("token_usage", {}).get("total_tokens")
        == value.get("token_usage", {}).get("input_tokens", -1)
        + value.get("token_usage", {}).get("output_tokens", -1)
        and bool(value.get("transcript_id"))
        for value in ablation_results.values()
    )
    profiles_match_records = all(
        value.get("scientist_ablation") == key.split("|", 1)[1]
        for key, value in ablation_results.items()
    )
    baseline_complete = all(
        f"{task}|{ARM_SCIENTIST}" in primary_results for task in task_refs
    )
    integrity_gates = {
        "all_450_ablation_results_present": set(ablation_results) == expected_slots
        and not ablations.get("failures"),
        "all_result_identities_valid": result_identities_valid,
        "all_token_accounts_exact": token_accounts_exact,
        "ablation_profiles_match_records": profiles_match_records,
        "all_primary_baselines_present": baseline_complete,
        "outcome_blind_subset_and_no_selective_reruns": ablations.get(
            "outcome_blind_subset"
        )
        is True
        and ablations.get("selective_reruns_performed") is False,
    }

    def primary_result(task: str) -> Mapping[str, Any]:
        return primary_results.get(f"{task}|{ARM_SCIENTIST}", {})

    def ablation_result(task: str, profile: str) -> Mapping[str, Any]:
        return ablation_results.get(f"{task}|{profile}", {})

    def valid(value: Mapping[str, Any]) -> int:
        return int(bool(value.get("score", {}).get("valid_root_advance")))

    def target_failure(value: Mapping[str, Any], profile: AdaptiveAblation) -> int:
        score = value.get("score", {})
        if not value:
            return 1
        if profile == AdaptiveAblation.CAUSAL_MEMORY:
            return int(not score.get("evidence_grounded") or not score.get("trace_complete"))
        if profile == AdaptiveAblation.PLAN_ADMISSIBILITY:
            return int(not score.get("evidence_grounded") or not score.get("within_budget"))
        if profile == AdaptiveAblation.CANDIDATE_VALIDATION:
            return int(not score.get("validator_certificate_valid"))
        if profile == AdaptiveAblation.TYPED_RECOVERY:
            return int(not score.get("typed_recovery_correct"))
        if profile == AdaptiveAblation.INDEPENDENT_PROMOTION:
            return int(bool(score.get("false_promotion")))
        raise ValueError("unknown ablation profile")

    profiles: Dict[str, Any] = {}
    all_supported = True
    for profile in AdaptiveAblation:
        if profile == AdaptiveAblation.NONE:
            continue
        relevant = task_refs
        if profile == AdaptiveAblation.TYPED_RECOVERY:
            relevant = [
                task
                for task in task_refs
                if ablations["task_strata"][task]["fault_class"] != "none"
            ]
        baseline = [valid(primary_result(task)) for task in relevant]
        removed = [valid(ablation_result(task, profile.value)) for task in relevant]
        baseline_target_failures = sum(
            target_failure(primary_result(task), profile) for task in relevant
        )
        removed_target_failures = sum(
            target_failure(ablation_result(task, profile.value), profile) for task in relevant
        )
        attenuation = sum(baseline) / len(relevant) - sum(removed) / len(relevant)
        mechanism_increase = removed_target_failures - baseline_target_failures
        supported = attenuation > 0 and mechanism_increase > 0
        all_supported = all_supported and supported
        profiles[profile.value] = {
            "task_count": len(relevant),
            "baseline_valid_rate": sum(baseline) / len(relevant),
            "removed_valid_rate": sum(removed) / len(relevant),
            "valid_rate_attenuation": attenuation,
            "baseline_target_failure_count": baseline_target_failures,
            "removed_target_failure_count": removed_target_failures,
            "target_failure_increase": mechanism_increase,
            "mcnemar": exact_mcnemar(baseline, removed),
            "component_supported": supported,
        }
    body: Dict[str, Any] = {
        "version": ABLATION_ANALYSIS_VERSION,
        "confirmatory_run_id": primary_id,
        "ablation_run_id": ablation_id,
        "task_count": 90,
        "profiles": profiles,
        "integrity_gates": integrity_gates,
        "ablation_execution_integrity_passed": all(integrity_gates.values()),
        "all_five_components_supported": all_supported
        and all(integrity_gates.values()),
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "ablation_analysis_id": content_digest(body)}
