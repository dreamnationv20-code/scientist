from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Tuple

from scientist.autonomy.adaptive_codex_runner_v1 import (
    DEFAULT_MODEL,
    DEFAULT_MODEL_TOKEN_CEILING,
    DEFAULT_REASONING_EFFORT,
    DEFAULT_WALL_TIME_CEILING_SECONDS,
    AdaptiveCodexAgentResponse,
    AdaptiveCodexWorker,
    assemble_adaptive_arm_result,
)
from scientist.autonomy.adaptive_confirmatory_provider_v1 import (
    validate_audit_release,
    validate_provider_package,
)
from scientist.autonomy.adaptive_three_arm_v1 import (
    ARM_SCIENTIST,
    AdaptiveAblation,
    AdaptiveThreeArmGateway,
)
from scientist.autonomy.autonomous_scientist_freeze_v1 import (
    validate_implementation_freeze,
)
from scientist.core.artifacts import ArtifactStore, content_digest


ABLATION_RUNNER_VERSION = "adaptive-mechanistic-ablation-runner-v1"
ABLATION_PROFILES = tuple(
    item for item in AdaptiveAblation if item != AdaptiveAblation.NONE
)


def _read_manifest(store: ArtifactStore, name: str) -> Mapping[str, Any] | None:
    path = store.manifests / f"{name}.json"
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} is not an object")
    return value


def _validate_identity(value: Mapping[str, Any], key: str) -> None:
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"ablation resume manifest has invalid {key}")


def run_adaptive_ablation_panel(
    *,
    project_root: Path,
    public_bundle: Mapping[str, Any],
    private_bundle: Mapping[str, Any],
    provider_commitment: Mapping[str, Any],
    freeze: Mapping[str, Any],
    audit_release: Mapping[str, Any],
    artifact_store: ArtifactStore,
    worker_factory: Callable[[AdaptiveAblation], AdaptiveCodexWorker],
) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    validate_implementation_freeze(freeze, root)
    validate_audit_release(audit_release, expected_freeze_id=freeze["freeze_id"])
    records = validate_provider_package(public_bundle, private_bundle, provider_commitment)
    eligible = [record for record in records if record[0]["ablation_eligible"]]
    if len(eligible) != 90:
        raise ValueError("mechanistic ablation subset must contain 90 outcome-blind tasks")
    all_results: Dict[str, Any] = {}
    all_failures: Dict[str, Any] = {}
    task_result_ids: Dict[str, str] = {}
    for item, public, authority in eligible:
        position = int(item["position"])
        task_ref = str(item["task_ref"])
        scored_name = f"ablation-scored-task-{position:03d}"
        prior = _read_manifest(artifact_store, scored_name)
        if prior is not None:
            _validate_identity(prior, "task_result_id")
            if not (
                prior.get("task_ref") == task_ref and prior.get("position") == position
            ):
                raise ValueError("scored ablation resume manifest targets another task")
            all_results.update(prior["results"])
            all_failures.update(prior["failures"])
            task_result_ids[task_ref] = prior["task_result_id"]
            continue
        opened_name = f"ablation-opened-task-{position:03d}"
        prior_opened = _read_manifest(artifact_store, opened_name)
        if prior_opened is not None:
            _validate_identity(prior_opened, "opened_id")
            if not (
                prior_opened.get("task_ref") == task_ref
                and prior_opened.get("position") == position
                and prior_opened.get("public_episode_id") == public.episode_id
                and prior_opened.get("provider_commitment_id")
                == provider_commitment["provider_commitment_id"]
            ):
                raise ValueError("opened ablation resume manifest targets another task")
            failures = {
                f"{task_ref}|{profile.value}": {
                    "type": "InterruptedAblationBlock",
                    "message": "ablation block interrupted after opening; selective rerun prohibited",
                }
                for profile in ABLATION_PROFILES
            }
            body = {
                "version": ABLATION_RUNNER_VERSION,
                "task_ref": task_ref,
                "position": position,
                "results": {},
                "failures": failures,
                "all_five_terminal_records_immutable_before_scoring": False,
                "selective_rerun_performed": False,
            }
            scored = {**body, "task_result_id": content_digest(body)}
            artifact_store.write_manifest(scored_name, scored)
            all_failures.update(failures)
            task_result_ids[task_ref] = scored["task_result_id"]
            continue
        opened_body = {
            "version": ABLATION_RUNNER_VERSION,
            "task_ref": task_ref,
            "position": position,
            "public_episode_id": public.episode_id,
            "ablation_order": item["ablation_order"],
            "provider_commitment_id": provider_commitment["provider_commitment_id"],
            "outcome_present": False,
            "authority_present": False,
        }
        artifact_store.write_manifest(
            opened_name, {**opened_body, "opened_id": content_digest(opened_body)}
        )
        collected: Dict[
            AdaptiveAblation, Tuple[AdaptiveCodexAgentResponse, AdaptiveThreeArmGateway]
        ] = {}
        failures: Dict[str, Any] = {}
        terminals: Dict[str, Any] = {}
        for raw_profile in item["ablation_order"]:
            profile = AdaptiveAblation(raw_profile)
            key = f"{task_ref}|{profile.value}"
            worker = worker_factory(profile)
            if not (
                worker.project_deny_root == root
                and worker.confirmatory_authorization_id
                == provider_commitment["provider_commitment_id"]
                and worker.scientist_ablation == profile
                and worker.model == DEFAULT_MODEL
                and worker.reasoning_effort == DEFAULT_REASONING_EFFORT
                and worker.model_token_ceiling == DEFAULT_MODEL_TOKEN_CEILING
                and worker.timeout_seconds == DEFAULT_WALL_TIME_CEILING_SECONDS
            ):
                raise ValueError("ablation worker factory violated the frozen contract")
            try:
                response, gateway = worker.run(public, authority, ARM_SCIENTIST)
            except Exception as error:
                failures[key] = {"type": type(error).__name__, "message": str(error)}
                terminals[profile.value] = {
                    "status": "runner_failure_terminal",
                    "failure_type": type(error).__name__,
                    "failure_message": str(error),
                    "score_present": False,
                    "authority_present": False,
                }
            else:
                collected[profile] = (response, gateway)
                terminals[profile.value] = {
                    "status": "terminal_response_collected",
                    "proposal": response.proposal.as_dict(),
                    "transcript_id": response.transcript_id,
                    "token_usage": response.token_usage.as_dict(),
                    "wall_seconds": response.wall_seconds,
                    "score_present": False,
                    "authority_present": False,
                }
        collection_body = {
            "version": ABLATION_RUNNER_VERSION,
            "task_ref": task_ref,
            "position": position,
            "terminal_records": terminals,
            "all_five_slots_terminal": set(terminals)
            == {profile.value for profile in ABLATION_PROFILES},
            "scores_present": False,
            "authority_present": False,
        }
        collection = {**collection_body, "collection_id": content_digest(collection_body)}
        artifact_store.write_manifest(f"ablation-prescore-task-{position:03d}", collection)
        results: Dict[str, Any] = {}
        for profile, (response, gateway) in collected.items():
            key = f"{task_ref}|{profile.value}"
            try:
                result = assemble_adaptive_arm_result(
                    public,
                    authority,
                    response,
                    gateway,
                    model_token_ceiling=worker.model_token_ceiling,
                    wall_time_ceiling_seconds=worker.timeout_seconds,
                )
            except Exception as error:
                failures[key] = {"type": type(error).__name__, "message": str(error)}
            else:
                results[key] = result.as_dict()
                artifact_store.put("adaptive_confirmatory_ablation_result", result.as_dict())
        body = {
            "version": ABLATION_RUNNER_VERSION,
            "task_ref": task_ref,
            "position": position,
            "scientific_state": authority.scientific_state.value,
            "variable_count": len(public.variable_names),
            "fault_class": authority.fault_class.value,
            "collection_id": collection["collection_id"],
            "results": results,
            "failures": failures,
            "all_five_terminal_records_immutable_before_scoring": True,
            "selective_rerun_performed": False,
        }
        scored = {**body, "task_result_id": content_digest(body)}
        artifact_store.write_manifest(scored_name, scored)
        all_results.update(results)
        all_failures.update(failures)
        task_result_ids[task_ref] = scored["task_result_id"]
    expected = {
        f"{item['task_ref']}|{profile.value}"
        for item, _public, _authority in eligible
        for profile in ABLATION_PROFILES
    }
    task_strata = {
        item["task_ref"]: {
            "scientific_state": authority.scientific_state.value,
            "variable_count": len(public.variable_names),
            "fault_class": authority.fault_class.value,
        }
        for item, public, authority in eligible
    }
    body = {
        "version": ABLATION_RUNNER_VERSION,
        "status": "complete" if set(all_results).union(all_failures) == expected else "incomplete",
        "freeze_id": freeze["freeze_id"],
        "audit_release_id": audit_release["audit_release_id"],
        "provider_commitment_id": provider_commitment["provider_commitment_id"],
        "task_count": 90,
        "ablation_episode_count": 450,
        "profiles": [item.value for item in ABLATION_PROFILES],
        "task_result_ids": task_result_ids,
        "task_strata": task_strata,
        "results": all_results,
        "failures": all_failures,
        "outcome_blind_subset": True,
        "selective_reruns_performed": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "ablation_run_id": content_digest(body)}
