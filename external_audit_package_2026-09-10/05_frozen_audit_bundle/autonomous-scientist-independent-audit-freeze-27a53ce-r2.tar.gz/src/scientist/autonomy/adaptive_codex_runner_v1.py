from __future__ import annotations

import json
import os
import re
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, Mapping, Tuple

from scientist.autonomy.adaptive_three_arm_v1 import (
    ADAPTIVE_THREE_ARM_VERSION,
    ARM_KINDS,
    ARM_SCIENTIST,
    AdaptiveAblation,
    AdaptiveLifecycleDecision,
    AdaptiveThreeArmGateway,
    adaptive_conclusion_schema,
    adaptive_model_public_packet,
    adaptive_probe_schema,
    adaptive_task_prompt,
    adaptive_three_arm_contract,
    adaptive_validate_schema,
    authorize_adaptive_scientist_conclusion,
    parse_adaptive_conclusion,
)
from scientist.autonomy.adaptive_worlds_v1 import (
    AdaptiveConclusion,
    AdaptiveValidationCertificate,
    AdaptiveWorldAuthority,
    AdaptiveWorldInstrument,
    AdaptiveWorldPublicPacket,
    AdaptiveWorldScore,
    score_adaptive_world,
)
from scientist.codex_exchange import CodexCliInvocationError
from scientist.core.artifacts import ArtifactStore, content_digest


ADAPTIVE_CODEX_RUNNER_VERSION = "adaptive-causal-codex-runner-v2"
DEFAULT_MODEL = "gpt-5.6-sol"
DEFAULT_REASONING_EFFORT = "low"
DEFAULT_MODEL_TOKEN_CEILING = 128_000
DEFAULT_WALL_TIME_CEILING_SECONDS = 900.0


_MINIMAL_MODEL_INSTRUCTIONS = """You are a sequestered research-task worker.
Follow the user task, use only the two research_instrument tools, and return only
the requested structured result. Do not inspect the filesystem, use the shell,
contact people, access the network directly, or invoke any other tool."""


_MCP_SERVER_SOURCE = r'''from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request


endpoint = sys.argv[1]
token = sys.argv[2]
schemas = json.loads(sys.argv[3])


def emit(request_id, result=None, error=None):
    message = {"jsonrpc": "2.0", "id": request_id}
    if error is not None:
        message["error"] = error
    else:
        message["result"] = result
    print(json.dumps(message, separators=(",", ":")), flush=True)


descriptions = {
    "probe_batch": (
        "Run a bounded batch of context/intervention probes. A typed fault may stop "
        "the batch. On the next call, identify the failure and declared recovery."
    ),
    "validate_candidate": (
        "Answer-blind public-evidence validation. Returns a certificate or bounded "
        "counterexamples and never reads hidden truth."
    ),
}


for raw in sys.stdin:
    request_id = None
    try:
        request = json.loads(raw)
        method = request.get("method")
        request_id = request.get("id")
        if method == "initialize":
            emit(
                request_id,
                {
                    "protocolVersion": request.get("params", {}).get(
                        "protocolVersion", "2025-06-18"
                    ),
                    "capabilities": {"tools": {}},
                    "serverInfo": {
                        "name": "adaptive-causal-research-instrument",
                        "version": "1.0.0",
                    },
                },
            )
        elif method == "notifications/initialized":
            continue
        elif method == "ping":
            emit(request_id, {})
        elif method == "tools/list":
            emit(
                request_id,
                {
                    "tools": [
                        {
                            "name": name,
                            "description": descriptions[name],
                            "inputSchema": schemas[name],
                        }
                        for name in ("probe_batch", "validate_candidate")
                    ]
                },
            )
        elif method == "tools/call":
            params = request.get("params", {})
            name = params.get("name")
            if name not in schemas:
                emit(request_id, error={"code": -32602, "message": "unknown tool"})
                continue
            payload = json.dumps(
                {"name": name, "arguments": params.get("arguments", {})}
            ).encode("utf-8")
            http_request = urllib.request.Request(
                endpoint,
                data=payload,
                method="POST",
                headers={
                    "Authorization": "Bearer " + token,
                    "Content-Type": "application/json",
                },
            )
            try:
                with urllib.request.urlopen(http_request, timeout=30) as response:
                    body = response.read().decode("utf-8")
                emit(request_id, {"content": [{"type": "text", "text": body}]})
            except urllib.error.HTTPError as http_error:
                body = http_error.read().decode("utf-8")
                emit(
                    request_id,
                    {"content": [{"type": "text", "text": body}], "isError": True},
                )
        elif request_id is not None:
            emit(request_id, error={"code": -32601, "message": "method not found"})
    except Exception as error:
        if request_id is not None:
            emit(request_id, error={"code": -32603, "message": str(error)})
'''


class _GatewayService:
    def __init__(self, gateway: AdaptiveThreeArmGateway, token: str) -> None:
        self.gateway = gateway
        self.token = token
        self.lock = threading.Lock()
        self.transport_rejections: list[Mapping[str, Any]] = []

    def handle(self, authorization: str, payload: Any) -> Tuple[int, Mapping[str, Any]]:
        with self.lock:
            if authorization != "Bearer " + self.token:
                rejection = {
                    "sequence": len(self.transport_rejections) + 1,
                    "failure": "invalid instrument capability",
                    "payload_digest": content_digest(payload),
                }
                self.transport_rejections.append(rejection)
                return 403, {"error": rejection["failure"]}
            if not isinstance(payload, Mapping):
                return 400, {"error": "tool envelope must be an object"}
            return self.gateway.handle(str(payload.get("name")), payload.get("arguments"))


def _handler(service: _GatewayService):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:  # noqa: N802
            if self.path != "/research-tool":
                self.send_error(404)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 262_144:
                    raise ValueError("invalid request size")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
            except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as error:
                status, body = 400, {"error": str(error)}
            else:
                status, body = service.handle(
                    self.headers.get("Authorization", ""), payload
                )
            encoded = json.dumps(body, sort_keys=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)

        def log_message(self, format: str, *args: Any) -> None:
            return

    return Handler


@dataclass(frozen=True)
class AdaptiveCodexTokenUsage:
    input_tokens: int
    cached_input_tokens: int
    cache_write_input_tokens: int
    output_tokens: int
    reasoning_output_tokens: int

    def __post_init__(self) -> None:
        if any(
            isinstance(value, bool) or not isinstance(value, int) or value < 0
            for value in (
                self.input_tokens,
                self.cached_input_tokens,
                self.cache_write_input_tokens,
                self.output_tokens,
                self.reasoning_output_tokens,
            )
        ):
            raise ValueError("Codex token usage requires non-negative integers")

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def as_dict(self) -> Dict[str, int]:
        return {
            "input_tokens": self.input_tokens,
            "cached_input_tokens": self.cached_input_tokens,
            "cache_write_input_tokens": self.cache_write_input_tokens,
            "output_tokens": self.output_tokens,
            "reasoning_output_tokens": self.reasoning_output_tokens,
            "total_tokens": self.total_tokens,
        }


def _parse_jsonl_usage(stdout: str) -> AdaptiveCodexTokenUsage:
    completions = []
    for line in stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") == "turn.completed" and isinstance(event.get("usage"), Mapping):
            completions.append(event["usage"])
    if len(completions) != 1:
        raise CodexCliInvocationError("JSONL must contain exactly one completed turn")
    usage = completions[0]
    return AdaptiveCodexTokenUsage(
        input_tokens=int(usage.get("input_tokens", 0)),
        cached_input_tokens=int(usage.get("cached_input_tokens", 0)),
        cache_write_input_tokens=int(usage.get("cache_write_input_tokens", 0)),
        output_tokens=int(usage.get("output_tokens", 0)),
        reasoning_output_tokens=int(usage.get("reasoning_output_tokens", 0)),
    )


def _forbidden_tool_events(stdout: str) -> Tuple[Mapping[str, Any], ...]:
    forbidden = []
    allowed_item_types = {"mcp_tool_call", "agent_message", "reasoning"}
    for line in stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") not in {"item.started", "item.completed"}:
            continue
        item = event.get("item")
        if not isinstance(item, Mapping):
            continue
        item_type = str(item.get("type"))
        invalid_mcp = item_type == "mcp_tool_call" and (
            item.get("server") != "research_instrument"
            or item.get("tool") not in {"probe_batch", "validate_candidate"}
        )
        if item_type not in allowed_item_types or invalid_mcp:
            forbidden.append(
                {"event_type": event.get("type"), "item_type": item_type, "item_id": item.get("id")}
            )
    return tuple(forbidden)


def _codex_version(binary: str) -> str:
    completed = subprocess.run(
        (binary, "--version"), capture_output=True, text=True, check=False
    )
    if completed.returncode != 0:
        raise CodexCliInvocationError("unable to identify Codex CLI version")
    return completed.stdout.strip()


@dataclass(frozen=True)
class AdaptiveCodexAgentResponse:
    raw_response: Mapping[str, Any]
    proposal: AdaptiveConclusion
    arm_kind: str
    model_ref: str
    reasoning_effort: str
    codex_version: str
    token_usage: AdaptiveCodexTokenUsage
    wall_seconds: float
    prompt_digest: str
    public_packet_digest: str
    tool_schema_digest: str
    response_digest: str
    transcript_id: str
    project_read_denial_preflight_passed: bool
    project_deny_root: str
    sandbox: str
    transport_rejection_count: int
    forbidden_tool_events: Tuple[Mapping[str, Any], ...]


@dataclass(frozen=True)
class AdaptiveArmResult:
    episode_id: str
    arm_kind: str
    proposal: AdaptiveConclusion
    conclusion: AdaptiveConclusion
    certificate: AdaptiveValidationCertificate | None
    score: AdaptiveWorldScore
    lifecycle_decision: AdaptiveLifecycleDecision | None
    model_ref: str
    reasoning_effort: str
    codex_version: str
    token_usage: AdaptiveCodexTokenUsage
    model_token_ceiling: int
    wall_seconds: float
    wall_time_ceiling_seconds: float
    measurement_attempts: int
    measurement_attempt_ceiling: int
    probe_batches: int
    validator_calls: int
    event_count: int
    transport_rejection_count: int
    forbidden_tool_event_count: int
    accounting_reconciled: bool
    execution_autonomous: bool
    project_read_denial_preflight_passed: bool
    transcript_id: str
    scientist_ablation: str

    @property
    def result_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": ADAPTIVE_CODEX_RUNNER_VERSION,
            "episode_id": self.episode_id,
            "arm_kind": self.arm_kind,
            "proposal": self.proposal.as_dict(),
            "conclusion": self.conclusion.as_dict(),
            "certificate": self.certificate.as_dict() if self.certificate else None,
            "score": self.score.as_dict(),
            "lifecycle_decision": (
                self.lifecycle_decision.as_dict() if self.lifecycle_decision else None
            ),
            "model_ref": self.model_ref,
            "reasoning_effort": self.reasoning_effort,
            "codex_version": self.codex_version,
            "token_usage": self.token_usage.as_dict(),
            "model_token_ceiling": self.model_token_ceiling,
            "wall_seconds": self.wall_seconds,
            "wall_time_ceiling_seconds": self.wall_time_ceiling_seconds,
            "measurement_attempts": self.measurement_attempts,
            "measurement_attempt_ceiling": self.measurement_attempt_ceiling,
            "probe_batches": self.probe_batches,
            "validator_calls": self.validator_calls,
            "event_count": self.event_count,
            "transport_rejection_count": self.transport_rejection_count,
            "forbidden_tool_event_count": self.forbidden_tool_event_count,
            "accounting_reconciled": self.accounting_reconciled,
            "execution_autonomous": self.execution_autonomous,
            "human_interventions": 0,
            "out_of_band_interventions": 0,
            "project_read_denial_preflight_passed": self.project_read_denial_preflight_passed,
            "transcript_id": self.transcript_id,
            "scientist_ablation": self.scientist_ablation,
        }
        if include_id:
            value["result_id"] = self.result_id
        return value


@dataclass(frozen=True)
class AdaptiveCodexWorker:
    artifact_store: ArtifactStore
    project_deny_root: Path
    model: str = DEFAULT_MODEL
    reasoning_effort: str = DEFAULT_REASONING_EFFORT
    model_token_ceiling: int = DEFAULT_MODEL_TOKEN_CEILING
    timeout_seconds: float = DEFAULT_WALL_TIME_CEILING_SECONDS
    codex_binary: str = "codex"
    sandbox_exec_binary: str = "/usr/bin/sandbox-exec"
    confirmatory_authorization_id: str | None = None
    scientist_ablation: AdaptiveAblation | str = AdaptiveAblation.NONE

    def __post_init__(self) -> None:
        if self.reasoning_effort not in {"low", "medium", "high", "xhigh"}:
            raise ValueError("unsupported reasoning effort")
        if self.model_token_ceiling <= 0 or self.timeout_seconds <= 0:
            raise ValueError("resource ceilings must be positive")
        if self.confirmatory_authorization_id is not None and re.fullmatch(
            r"[0-9a-f]{64}", self.confirmatory_authorization_id
        ) is None:
            raise ValueError("confirmatory authorization must be a 64-hex identifier")
        object.__setattr__(self, "scientist_ablation", AdaptiveAblation(self.scientist_ablation))
        object.__setattr__(self, "project_deny_root", Path(self.project_deny_root).resolve())

    def run(
        self,
        public: AdaptiveWorldPublicPacket,
        authority: AdaptiveWorldAuthority,
        arm_kind: str,
    ) -> Tuple[AdaptiveCodexAgentResponse, AdaptiveThreeArmGateway]:
        if arm_kind not in ARM_KINDS:
            raise ValueError("unknown adaptive arm")
        if not public.development_only and self.confirmatory_authorization_id is None:
            raise ValueError("worker cannot open a confirmatory task without authorization")
        if arm_kind != ARM_SCIENTIST and self.scientist_ablation != AdaptiveAblation.NONE:
            raise ValueError("Scientist ablation cannot be applied to a control arm")
        if public.episode_id != authority.episode_id:
            raise ValueError("adaptive worker inputs disagree")
        binary = shutil.which(self.codex_binary)
        if binary is None:
            raise CodexCliInvocationError("Codex CLI is unavailable")
        codex_version = _codex_version(binary)
        gateway = AdaptiveThreeArmGateway(
            public,
            AdaptiveWorldInstrument(public, authority),
            arm_kind,
            ablation=self.scientist_ablation,
        )
        token = secrets.token_hex(32)
        service = _GatewayService(gateway, token)
        server = HTTPServer(("127.0.0.1", 0), _handler(service))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory(
                prefix="adaptive-codex-agent-", dir="/private/tmp"
            ) as temporary:
                work = Path(temporary)
                mcp_path = work / "instrument_mcp.py"
                mcp_path.write_text(_MCP_SERVER_SOURCE, encoding="utf-8")
                instructions_path = work / "model-instructions.txt"
                instructions_path.write_text(_MINIMAL_MODEL_INSTRUCTIONS, encoding="utf-8")
                schema_path = work / "conclusion-schema.json"
                schema_path.write_text(
                    json.dumps(adaptive_conclusion_schema(public), sort_keys=True),
                    encoding="utf-8",
                )
                output_path = work / "final-response.json"
                profile = (
                    "(version 1)(allow default)(deny file-read* (subpath %s))"
                    % json.dumps(str(self.project_deny_root))
                )
                protected_source = (
                    self.project_deny_root
                    / "src/scientist/autonomy/adaptive_worlds_v1.py"
                )
                preflight = subprocess.run(
                    (
                        self.sandbox_exec_binary,
                        "-p",
                        profile,
                        "/bin/test",
                        "!",
                        "-r",
                        str(protected_source),
                    ),
                    cwd=work,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                preflight_passed = preflight.returncode == 0
                if not preflight_passed:
                    raise CodexCliInvocationError("project-read denial preflight failed")
                schemas = {
                    "probe_batch": adaptive_probe_schema(public),
                    "validate_candidate": adaptive_validate_schema(public),
                }
                schema_json = json.dumps(schemas, sort_keys=True, separators=(",", ":"))
                endpoint = f"http://127.0.0.1:{server.server_port}/research-tool"
                command = [
                    self.sandbox_exec_binary,
                    "-p",
                    profile,
                    binary,
                    "exec",
                    "--ephemeral",
                    "--skip-git-repo-check",
                    "--ignore-user-config",
                    "--ignore-rules",
                    "--json",
                    "--color",
                    "never",
                    "-c",
                    f'model_reasoning_effort="{self.reasoning_effort}"',
                    "-c",
                    f"model_context_window={self.model_token_ceiling}",
                    "-c",
                    f"model_auto_compact_token_limit={max(1024, self.model_token_ceiling - 2048)}",
                    "-c",
                    "include_permissions_instructions=false",
                    "-c",
                    "include_apps_instructions=false",
                    "-c",
                    "include_collaboration_mode_instructions=false",
                    "-c",
                    "include_environment_context=false",
                    "-c",
                    "sandbox_workspace_write.network_access=true",
                    "-c",
                    f"model_instructions_file={json.dumps(str(instructions_path))}",
                    "-c",
                    'mcp_servers.research_instrument.command="python3"',
                    "-c",
                    "mcp_servers.research_instrument.args="
                    + json.dumps([str(mcp_path), endpoint, token, schema_json]),
                    "-c",
                    "mcp_servers.research_instrument.startup_timeout_sec=10",
                    "-c",
                    "mcp_servers.research_instrument.required=true",
                    "-c",
                    'mcp_servers.research_instrument.enabled_tools=["probe_batch","validate_candidate"]',
                    "-c",
                    'mcp_servers.research_instrument.default_tools_approval_mode="approve"',
                    "-c",
                    'mcp_servers.research_instrument.tools.probe_batch.approval_mode="approve"',
                    "-c",
                    'mcp_servers.research_instrument.tools.validate_candidate.approval_mode="approve"',
                    "--sandbox",
                    "workspace-write",
                    "-C",
                    str(work),
                    "--output-schema",
                    str(schema_path),
                    "-o",
                    str(output_path),
                    "--model",
                    self.model,
                    "-",
                ]
                environment = dict(os.environ)
                environment.pop("OPENAI_API_KEY", None)
                environment.pop("OPENAI_KEY", None)
                prompt = adaptive_task_prompt(public, arm_kind)
                started = time.perf_counter()
                completed = subprocess.run(
                    command,
                    input=prompt,
                    text=True,
                    capture_output=True,
                    timeout=self.timeout_seconds,
                    check=False,
                    cwd=work,
                    env=environment,
                )
                wall_seconds = time.perf_counter() - started
                if completed.returncode != 0:
                    diagnostic = "\n".join(
                        ("STDOUT:\n" + (completed.stdout or ""), "STDERR:\n" + (completed.stderr or ""))
                    )[-8000:]
                    raise CodexCliInvocationError(
                        f"Codex arm exited {completed.returncode}: {diagnostic.strip()}"
                    )
                usage = _parse_jsonl_usage(completed.stdout or "")
                forbidden = _forbidden_tool_events(completed.stdout or "")
                transcript_value = {
                    "version": ADAPTIVE_CODEX_RUNNER_VERSION,
                    "arm_kind": arm_kind,
                    "stdout": completed.stdout or "",
                    "stderr": completed.stderr or "",
                    "gateway_events": [item.as_dict() for item in gateway.events],
                    "observations": [item.as_dict() for item in gateway.instrument.observations],
                    "recoveries": [item.as_dict() for item in gateway.instrument.recovery_records],
                    "certificates": {
                        key: value.as_dict() for key, value in gateway.certificates.items()
                    },
                    "transport_rejections": list(service.transport_rejections),
                    "forbidden_tool_events": list(forbidden),
                }
                try:
                    raw_response = json.loads(output_path.read_text(encoding="utf-8"))
                    proposal = parse_adaptive_conclusion(public, gateway, raw_response)
                except (OSError, json.JSONDecodeError, TypeError, ValueError) as error:
                    failure_transcript_id = self.artifact_store.put(
                        "adaptive_codex_failed_schema_transcript",
                        {
                            **transcript_value,
                            "raw_response_text": (
                                output_path.read_text(encoding="utf-8")
                                if output_path.is_file()
                                else None
                            ),
                            "parse_error_type": type(error).__name__,
                            "parse_error": str(error),
                        },
                    )
                    raise CodexCliInvocationError(
                        "Codex arm did not emit a semantically valid adaptive "
                        f"conclusion: {type(error).__name__}: {error}; "
                        f"failure_transcript={failure_transcript_id}"
                    ) from error
                transcript_id = self.artifact_store.put(
                    "adaptive_codex_jsonl_transcript", transcript_value
                )
                return (
                    AdaptiveCodexAgentResponse(
                        raw_response=raw_response,
                        proposal=proposal,
                        arm_kind=arm_kind,
                        model_ref=self.model,
                        reasoning_effort=self.reasoning_effort,
                        codex_version=codex_version,
                        token_usage=usage,
                        wall_seconds=wall_seconds,
                        prompt_digest=content_digest(prompt),
                        public_packet_digest=content_digest(adaptive_model_public_packet(public)),
                        tool_schema_digest=content_digest(schemas),
                        response_digest=content_digest(raw_response),
                        transcript_id=transcript_id,
                        project_read_denial_preflight_passed=preflight_passed,
                        project_deny_root=str(self.project_deny_root),
                        sandbox="macos_project_read_denial+codex_workspace_write",
                        transport_rejection_count=len(service.transport_rejections),
                        forbidden_tool_events=forbidden,
                    ),
                    gateway,
                )
        except subprocess.TimeoutExpired as error:
            raise CodexCliInvocationError(
                f"Codex arm exceeded its {self.timeout_seconds:.1f} second timeout"
            ) from error
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5.0)


def assemble_adaptive_arm_result(
    public: AdaptiveWorldPublicPacket,
    authority: AdaptiveWorldAuthority,
    response: AdaptiveCodexAgentResponse,
    gateway: AdaptiveThreeArmGateway,
    *,
    model_token_ceiling: int = DEFAULT_MODEL_TOKEN_CEILING,
    wall_time_ceiling_seconds: float = DEFAULT_WALL_TIME_CEILING_SECONDS,
) -> AdaptiveArmResult:
    if response.arm_kind != gateway.arm_kind:
        raise ValueError("adaptive response and gateway arms disagree")
    observation_refs = [item.evidence_ref for item in gateway.instrument.observations]
    trace_reconciled = (
        len(observation_refs) == len(set(observation_refs))
        and gateway.event_chain_valid
        and gateway.instrument.probe_batches <= public.maximum_probe_batches
        and gateway.validator.calls <= public.maximum_validator_calls
    )
    accounting_reconciled = all(
        (
            response.token_usage.total_tokens <= model_token_ceiling,
            response.wall_seconds <= wall_time_ceiling_seconds,
            gateway.instrument.measurement_attempts <= public.maximum_measurement_attempts,
            response.transport_rejection_count == 0,
            not response.forbidden_tool_events,
            response.project_read_denial_preflight_passed,
            trace_reconciled,
        )
    )
    lifecycle = None
    conclusion = response.proposal
    if (
        response.arm_kind == ARM_SCIENTIST
        and gateway.ablation != AdaptiveAblation.INDEPENDENT_PROMOTION
    ):
        lifecycle = authorize_adaptive_scientist_conclusion(
            public,
            gateway,
            response.proposal,
            accounting_reconciled=accounting_reconciled,
        )
        conclusion = lifecycle.authorized_conclusion
    certificate = gateway.certificate_by_id(conclusion.validator_certificate_id)
    score = score_adaptive_world(
        public,
        authority,
        gateway.instrument,
        conclusion,
        certificate,
        trace_complete=trace_reconciled,
        within_budget=accounting_reconciled,
        no_forbidden_operation=(
            response.transport_rejection_count == 0
            and not response.forbidden_tool_events
            and response.project_read_denial_preflight_passed
        ),
    )
    return AdaptiveArmResult(
        episode_id=public.episode_ref,
        arm_kind=response.arm_kind,
        proposal=response.proposal,
        conclusion=conclusion,
        certificate=certificate,
        score=score,
        lifecycle_decision=lifecycle,
        model_ref=response.model_ref,
        reasoning_effort=response.reasoning_effort,
        codex_version=response.codex_version,
        token_usage=response.token_usage,
        model_token_ceiling=model_token_ceiling,
        wall_seconds=response.wall_seconds,
        wall_time_ceiling_seconds=wall_time_ceiling_seconds,
        measurement_attempts=gateway.instrument.measurement_attempts,
        measurement_attempt_ceiling=public.maximum_measurement_attempts,
        probe_batches=gateway.instrument.probe_batches,
        validator_calls=gateway.validator.calls,
        event_count=len(gateway.events),
        transport_rejection_count=response.transport_rejection_count,
        forbidden_tool_event_count=len(response.forbidden_tool_events),
        accounting_reconciled=accounting_reconciled,
        execution_autonomous=True,
        project_read_denial_preflight_passed=response.project_read_denial_preflight_passed,
        transcript_id=response.transcript_id,
        scientist_ablation=gateway.ablation.value,
    )


def run_adaptive_codex_arm(
    public: AdaptiveWorldPublicPacket,
    authority: AdaptiveWorldAuthority,
    *,
    arm_kind: str,
    worker: AdaptiveCodexWorker,
) -> AdaptiveArmResult:
    if not public.development_only:
        raise ValueError("development runner cannot open a confirmatory task")
    response, gateway = worker.run(public, authority, arm_kind)
    return assemble_adaptive_arm_result(
        public,
        authority,
        response,
        gateway,
        model_token_ceiling=worker.model_token_ceiling,
        wall_time_ceiling_seconds=worker.timeout_seconds,
    )


def adaptive_runner_contract() -> Mapping[str, Any]:
    return {
        "version": ADAPTIVE_CODEX_RUNNER_VERSION,
        "three_arm_contract_version": ADAPTIVE_THREE_ARM_VERSION,
        "model": DEFAULT_MODEL,
        "reasoning_effort": DEFAULT_REASONING_EFFORT,
        "model_token_ceiling": DEFAULT_MODEL_TOKEN_CEILING,
        "wall_time_ceiling_seconds": DEFAULT_WALL_TIME_CEILING_SECONDS,
        "one_persistent_codex_turn_required": True,
        "codex_jsonl_usage_required": True,
        "cached_tokens_subtracted": False,
        "project_source_denied": True,
        "native_and_nonresearch_tools_forbidden": True,
        "credentials_removed_from_worker_environment": ["OPENAI_API_KEY", "OPENAI_KEY"],
        "shared_tool_contract": adaptive_three_arm_contract()["shared_tools"],
        "conclusion_schema": adaptive_conclusion_schema(),
        "outcome_over_any_ceiling": "fail_closed_zero",
        "confirmatory_tasks_accepted": False,
        "authorized_confirmatory_worker_available": True,
        "mechanistic_ablation_profiles": [
            item.value for item in AdaptiveAblation if item != AdaptiveAblation.NONE
        ],
    }
