from __future__ import annotations

import math
import random
from collections import Counter, defaultdict
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.adaptive_three_arm_v1 import (
    ARM_FREE,
    ARM_PROMPT_EQUATED,
    ARM_SCIENTIST,
)
from scientist.autonomy.adaptive_worlds_v1 import FaultClass, ScientificState
from scientist.core.artifacts import content_digest


CONFIRMATORY_ANALYSIS_VERSION = "adaptive-confirmatory-analysis-v1"
BOOTSTRAP_REPLICATES = 100_000
BOOTSTRAP_SEED = 2_026_090_901


def _quantile(values: Sequence[float], probability: float) -> float:
    if not values or not 0 <= probability <= 1:
        raise ValueError("invalid quantile request")
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def exact_mcnemar(scientist: Sequence[int], control: Sequence[int]) -> Mapping[str, Any]:
    if len(scientist) != len(control) or not scientist:
        raise ValueError("paired McNemar inputs are invalid")
    scientist_only = sum(a == 1 and b == 0 for a, b in zip(scientist, control))
    control_only = sum(a == 0 and b == 1 for a, b in zip(scientist, control))
    discordant = scientist_only + control_only
    if discordant == 0:
        p_value = 1.0
    else:
        tail = sum(
            math.comb(discordant, value) for value in range(min(scientist_only, control_only) + 1)
        ) / (2**discordant)
        p_value = min(1.0, 2 * tail)
    return {
        "scientist_only": scientist_only,
        "control_only": control_only,
        "discordant": discordant,
        "exact_two_sided_p": p_value,
    }


def _stratified_bootstrap(
    paired_rows: Sequence[Tuple[str, int, int]],
    *,
    replicates: int = BOOTSTRAP_REPLICATES,
    seed: int = BOOTSTRAP_SEED,
) -> Mapping[str, Any]:
    strata: Dict[str, list[Tuple[int, int]]] = defaultdict(list)
    for stratum, scientist, control in paired_rows:
        strata[stratum].append((scientist, control))
    if not strata or any(len(rows) != 2 for rows in strata.values()):
        raise ValueError("primary bootstrap requires exactly two replicates per crossed stratum")
    rng = random.Random(seed)
    draws = []
    ordered = [strata[key] for key in sorted(strata)]
    total = sum(len(rows) for rows in ordered)
    for _ in range(replicates):
        difference = 0
        for rows in ordered:
            for _replicate in range(len(rows)):
                scientist, control = rows[rng.randrange(len(rows))]
                difference += scientist - control
        draws.append(difference / total)
    return {
        "replicates": replicates,
        "seed": seed,
        "paired_stratification": "scientific_state_x_variable_count_x_fault_class",
        "two_sided_95_percent_interval": [
            _quantile(draws, 0.025),
            _quantile(draws, 0.975),
        ],
        "simultaneous_97_5_percent_interval": [
            _quantile(draws, 0.0125),
            _quantile(draws, 0.9875),
        ],
    }


def _holm_two(p_values: Mapping[str, float]) -> Mapping[str, float]:
    ordered = sorted(p_values, key=p_values.get)  # type: ignore[arg-type]
    adjusted: Dict[str, float] = {}
    running = 0.0
    count = len(ordered)
    for rank, key in enumerate(ordered):
        value = min(1.0, (count - rank) * p_values[key])
        running = max(running, value)
        adjusted[key] = running
    return adjusted


def analyze_adaptive_confirmatory_run(
    run: Mapping[str, Any], *, bootstrap_replicates: int = BOOTSTRAP_REPLICATES
) -> Mapping[str, Any]:
    body_for_id = dict(run)
    run_id = body_for_id.pop("confirmatory_run_id", None)
    if not run_id or content_digest(body_for_id) != run_id:
        raise ValueError("confirmatory run identity is invalid")
    if run.get("status") != "complete" or run.get("task_count") != 180:
        raise ValueError("confirmatory run is incomplete")
    task_strata = run["task_strata"]
    task_refs = sorted(task_strata)
    if len(task_refs) != 180:
        raise ValueError("confirmatory task strata are incomplete")
    observed_cells = Counter(
        (
            value["scientific_state"],
            int(value["variable_count"]),
            value["fault_class"],
        )
        for value in task_strata.values()
    )
    expected_cells = {
        (state.value, width, fault.value): 2
        for state in ScientificState
        for width in (5, 6, 7)
        for fault in FaultClass
    }
    if observed_cells != expected_cells:
        raise ValueError("confirmatory run is not the exact crossed design")
    results = run["results"]

    def outcome(task_ref: str, arm: str) -> int:
        value = results.get(f"{task_ref}|{arm}")
        return int(bool(value and value["score"]["valid_root_advance"]))

    outcomes = {
        arm: [outcome(task_ref, arm) for task_ref in task_refs]
        for arm in (ARM_SCIENTIST, ARM_PROMPT_EQUATED, ARM_FREE)
    }
    rates = {arm: sum(values) / 180 for arm, values in outcomes.items()}
    contrast_controls = {
        "prompt_equated": ARM_PROMPT_EQUATED,
        "free": ARM_FREE,
    }
    contrasts: Dict[str, Any] = {}
    raw_p = {}
    for name, arm in contrast_controls.items():
        rows = []
        for task_ref in task_refs:
            stratum = task_strata[task_ref]
            stratum_key = "|".join(
                (
                    stratum["scientific_state"],
                    str(stratum["variable_count"]),
                    stratum["fault_class"],
                )
            )
            rows.append((stratum_key, outcome(task_ref, ARM_SCIENTIST), outcome(task_ref, arm)))
        mcnemar = exact_mcnemar(outcomes[ARM_SCIENTIST], outcomes[arm])
        bootstrap = _stratified_bootstrap(
            rows,
            replicates=bootstrap_replicates,
            seed=BOOTSTRAP_SEED + (0 if arm == ARM_PROMPT_EQUATED else 1),
        )
        contrasts[name] = {
            "control_arm": arm,
            "paired_point_difference": rates[ARM_SCIENTIST] - rates[arm],
            "mcnemar": mcnemar,
            "bootstrap": bootstrap,
        }
        raw_p[name] = mcnemar["exact_two_sided_p"]
    adjusted = _holm_two(raw_p)
    for name in contrasts:
        contrasts[name]["holm_adjusted_p"] = adjusted[name]

    state_differences: Dict[str, Dict[str, float]] = {}
    tier_differences: Dict[str, Dict[str, float]] = {}
    for group_field, destination in (
        ("scientific_state", state_differences),
        ("variable_count", tier_differences),
    ):
        groups = sorted({str(task_strata[task][group_field]) for task in task_refs})
        for group in groups:
            members = [
                task for task in task_refs if str(task_strata[task][group_field]) == group
            ]
            destination[group] = {
                name: sum(
                    outcome(task, ARM_SCIENTIST) - outcome(task, arm) for task in members
                )
                / len(members)
                for name, arm in contrast_controls.items()
            }

    def false_promotion_rate(arm: str) -> float:
        count = sum(
            bool(results.get(f"{task}|{arm}", {}).get("score", {}).get("false_promotion"))
            for task in task_refs
        )
        return count / 180

    fp_rates = {
        arm: false_promotion_rate(arm)
        for arm in (ARM_SCIENTIST, ARM_PROMPT_EQUATED, ARM_FREE)
    }
    autonomous_completions = sum(
        bool(value.get("execution_autonomous"))
        and value.get("human_interventions") == 0
        and value.get("out_of_band_interventions") == 0
        for value in results.values()
    )
    expected_slots = {
        f"{task}|{arm}"
        for task in task_refs
        for arm in (ARM_SCIENTIST, ARM_PROMPT_EQUATED, ARM_FREE)
    }
    result_identities_valid = all(
        value.get("result_id")
        == content_digest({key: item for key, item in value.items() if key != "result_id"})
        for value in results.values()
    )
    token_accounts_exact = all(
        value.get("token_usage", {}).get("total_tokens")
        == value.get("token_usage", {}).get("input_tokens", -1)
        + value.get("token_usage", {}).get("output_tokens", -1)
        and bool(value.get("transcript_id"))
        for value in results.values()
    )
    failures_auditable = all(
        isinstance(value.get("type"), str) and isinstance(value.get("message"), str)
        for value in run["failures"].values()
    )
    accounting_complete = (
        set(results).union(run["failures"]) == expected_slots
        and result_identities_valid
        and token_accounts_exact
        and failures_auditable
    )
    fault_tasks = [
        task for task in task_refs if task_strata[task]["fault_class"] != "none"
    ]
    recovery_difference = sum(
        outcome(task, ARM_SCIENTIST) - outcome(task, ARM_PROMPT_EQUATED)
        for task in fault_tasks
    ) / len(fault_tasks)
    recovery_correct = all(
        f"{task}|{ARM_SCIENTIST}" in results
        and results[f"{task}|{ARM_SCIENTIST}"]
        .get("score", {})
        .get("typed_recovery_correct", False)
        for task in fault_tasks
    )

    primary = contrasts["prompt_equated"]
    secondary = contrasts["free"]
    gates = {
        "primary_holm_adjusted_p_below_0_05": primary["holm_adjusted_p"] < 0.05,
        "primary_simultaneous_interval_above_zero": (
            primary["bootstrap"]["simultaneous_97_5_percent_interval"][0] > 0
        ),
        "primary_point_difference_at_least_15pp": (
            primary["paired_point_difference"] >= 0.15
        ),
        "secondary_holm_adjusted_p_below_0_05": secondary["holm_adjusted_p"] < 0.05,
        "secondary_simultaneous_interval_above_zero": (
            secondary["bootstrap"]["simultaneous_97_5_percent_interval"][0] > 0
        ),
        "no_negative_scientific_state_stratum": all(
            value >= 0 for row in state_differences.values() for value in row.values()
        ),
        "no_negative_variable_tier_stratum": all(
            value >= 0 for row in tier_differences.values() for value in row.values()
        ),
        "scientist_false_promotion_below_2_percent": fp_rates[ARM_SCIENTIST] < 0.02,
        "scientist_false_promotion_noninferior_within_1pp": all(
            fp_rates[ARM_SCIENTIST] - fp_rates[arm] <= 0.01
            for arm in (ARM_PROMPT_EQUATED, ARM_FREE)
        ),
        "zero_human_completion_at_least_90_percent": autonomous_completions / 540 >= 0.90,
        "exact_provenance_and_accounting": accounting_complete,
        "positive_typed_recovery_evidence": recovery_difference > 0 and recovery_correct,
    }
    body: Dict[str, Any] = {
        "version": CONFIRMATORY_ANALYSIS_VERSION,
        "confirmatory_run_id": run_id,
        "task_count": 180,
        "arm_episode_count": 540,
        "missing_invalid_and_runner_failures_scored_zero": True,
        "rates": rates,
        "contrasts": contrasts,
        "holm_family": ["prompt_equated", "free"],
        "state_differences": state_differences,
        "tier_differences": tier_differences,
        "false_promotion_rates": fp_rates,
        "zero_human_completion_rate": autonomous_completions / 540,
        "accounting_complete": accounting_complete,
        "fault_task_scientist_minus_prompt_difference": recovery_difference,
        "gates": gates,
        "primary_controlled_gates_passed": all(gates.values()),
        "transport_gate_complete": False,
        "independent_replication_gate_complete": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "analysis_id": content_digest(body)}
