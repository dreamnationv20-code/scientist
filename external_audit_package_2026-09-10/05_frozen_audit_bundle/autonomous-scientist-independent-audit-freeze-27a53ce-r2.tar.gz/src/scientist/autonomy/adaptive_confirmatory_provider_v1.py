from __future__ import annotations

import hashlib
import hmac
import json
import random
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.adaptive_three_arm_v1 import ARM_KINDS
from scientist.autonomy.adaptive_three_arm_v1 import AdaptiveAblation
from scientist.autonomy.adaptive_worlds_v1 import (
    AdaptiveCandidate,
    AdaptiveWorldAuthority,
    AdaptiveWorldPublicPacket,
    FaultClass,
    RuleKind,
    ScientificState,
    generate_adaptive_world,
)
from scientist.core.artifacts import content_digest


ADAPTIVE_PROVIDER_VERSION = "adaptive-confirmatory-provider-v1"
AUDIT_RELEASE_VERSION = "adaptive-independent-audit-release-v1"
PUBLIC_BUNDLE_VERSION = "adaptive-confirmatory-public-bundle-v1"
PRIVATE_BUNDLE_VERSION = "adaptive-confirmatory-private-bundle-v1"
PROVIDER_COMMITMENT_VERSION = "adaptive-confirmatory-provider-commitment-v1"


def _identified(value: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"invalid {key}")
    return value


def read_identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return _identified(value, key)


def validate_audit_release(
    release: Mapping[str, Any], *, expected_freeze_id: str | None = None
) -> Mapping[str, Any]:
    _identified(release, "audit_release_id")
    checks = release.get("checks")
    if not (
        release.get("version") == AUDIT_RELEASE_VERSION
        and isinstance(release.get("auditor_ref"), str)
        and release["auditor_ref"].strip()
        and release.get("auditor_independent_of_authors_and_system") is True
        and release.get("provider_execution_authorized") is True
        and isinstance(release.get("signed_attestation"), str)
        and len(release["signed_attestation"].strip()) >= 32
        and isinstance(checks, Mapping)
        and checks
        and all(value is True for value in checks.values())
    ):
        raise ValueError("independent audit release is incomplete or negative")
    if expected_freeze_id is not None and release.get("freeze_id") != expected_freeze_id:
        raise ValueError("audit release targets a different freeze")
    return release


def confirmatory_cells() -> Tuple[Mapping[str, Any], ...]:
    cells = []
    index = 0
    for state in ScientificState:
        for width in (5, 6, 7):
            for fault in FaultClass:
                for replicate in range(2):
                    cells.append(
                        {
                            "cell_index": index,
                            "scientific_state": state.value,
                            "variable_count": width,
                            "fault_class": fault.value,
                            "replicate": replicate,
                        }
                    )
                    index += 1
    if len(cells) != 180:
        raise AssertionError("confirmatory panel must contain 180 crossed cells")
    return tuple(cells)


def _derive(entropy: bytes, label: str, length: int = 32) -> bytes:
    return hmac.new(entropy, label.encode("utf-8"), hashlib.sha256).digest()[:length]


def build_provider_package(
    *,
    freeze: Mapping[str, Any],
    audit_release: Mapping[str, Any],
    provider_ref: str,
    entropy: bytes,
) -> Tuple[Mapping[str, Any], Mapping[str, Any], Mapping[str, Any]]:
    if len(entropy) < 32:
        raise ValueError("provider entropy must contain at least 256 bits")
    if not provider_ref.strip():
        raise ValueError("provider_ref is required")
    _identified(freeze, "freeze_id")
    validate_audit_release(audit_release, expected_freeze_id=freeze["freeze_id"])
    if freeze.get("implementation_freeze_complete") is not True:
        raise ValueError("implementation is not frozen")

    private_records = []
    public_records = []
    development_seed_ranges = (
        range(71_000, 73_000),
        range(810_000, 811_000),
        range(920_000, 921_000),
        range(930_000, 931_000),
    )
    cells = list(confirmatory_cells())
    order_rng = random.Random(int.from_bytes(_derive(entropy, "task-order"), "big"))
    order_rng.shuffle(cells)
    for position, cell in enumerate(cells):
        seed_bytes = _derive(entropy, f"world-seed:{cell['cell_index']}")
        seed = int.from_bytes(seed_bytes[:16], "big") | (1 << 127)
        if any(seed in values for values in development_seed_ranges):
            raise ValueError("provider seed collides with a development range")
        episode_token = _derive(entropy, f"episode-ref:{cell['cell_index']}").hex()[:40]
        public, authority = generate_adaptive_world(
            seed,
            scientific_state=ScientificState(cell["scientific_state"]),
            variable_count=int(cell["variable_count"]),
            fault_class=FaultClass(cell["fault_class"]),
            development_only=False,
            episode_ref=f"episode-{episode_token}",
        )
        task_ref = "task-" + _derive(entropy, f"task-ref:{cell['cell_index']}").hex()[:24]
        arm_order = list(ARM_KINDS)
        random.Random(
            int.from_bytes(_derive(entropy, f"arm-order:{cell['cell_index']}"), "big")
        ).shuffle(arm_order)
        ablation_order = [
            value.value for value in AdaptiveAblation if value != AdaptiveAblation.NONE
        ]
        random.Random(
            int.from_bytes(_derive(entropy, f"ablation-order:{cell['cell_index']}"), "big")
        ).shuffle(ablation_order)
        public_records.append(
            {
                "position": position,
                "task_ref": task_ref,
                "arm_order": arm_order,
                "ablation_eligible": cell["replicate"] == 0,
                "ablation_order": ablation_order if cell["replicate"] == 0 else [],
                "public_packet": public.as_dict(),
            }
        )
        private_records.append(
            {
                "position": position,
                "task_ref": task_ref,
                "cell": cell,
                "authority": authority.as_dict(),
            }
        )

    public_body: Dict[str, Any] = {
        "version": PUBLIC_BUNDLE_VERSION,
        "freeze_id": freeze["freeze_id"],
        "audit_release_id": audit_release["audit_release_id"],
        "provider_ref": provider_ref,
        "task_count": 180,
        "arm_episode_count": 540,
        "ablation_task_count": 90,
        "ablation_episode_count": 450,
        "tasks": public_records,
        "authority_fields_included": False,
        "development_only": False,
    }
    public_bundle = {**public_body, "public_bundle_id": content_digest(public_body)}
    private_body: Dict[str, Any] = {
        "version": PRIVATE_BUNDLE_VERSION,
        "freeze_id": freeze["freeze_id"],
        "public_bundle_id": public_bundle["public_bundle_id"],
        "provider_ref": provider_ref,
        "entropy_hex": entropy.hex(),
        "tasks": private_records,
        "withhold_until_each_matched_triple_is_terminal": True,
    }
    private_bundle = {**private_body, "private_bundle_id": content_digest(private_body)}
    commitment_body: Dict[str, Any] = {
        "version": PROVIDER_COMMITMENT_VERSION,
        "status": "provider_committed_outcomes_absent",
        "freeze_id": freeze["freeze_id"],
        "audit_release_id": audit_release["audit_release_id"],
        "provider_ref": provider_ref,
        "provider_independent_of_authors_and_system": True,
        "entropy_bits_minimum": 256,
        "task_count": 180,
        "arm_episode_count": 540,
        "ablation_task_count": 90,
        "ablation_episode_count": 450,
        "crossed_cell_count": 90,
        "replicates_per_cell": 2,
        "public_bundle_id": public_bundle["public_bundle_id"],
        "private_bundle_id": private_bundle["private_bundle_id"],
        "private_bundle_withheld": True,
        "development_seed_ranges_excluded": True,
        "confirmatory_arm_trajectories_created": False,
        "confirmatory_outcomes_opened": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    commitment = {
        **commitment_body,
        "provider_commitment_id": content_digest(commitment_body),
    }
    return public_bundle, private_bundle, commitment


def candidate_from_dict(value: Mapping[str, Any]) -> AdaptiveCandidate:
    candidate = AdaptiveCandidate(
        hypothesis_ref=str(value["hypothesis_ref"]),
        rule_kind=RuleKind(value["rule_kind"]),
        variable_indices=tuple(int(item) for item in value["variable_indices"]),
        input_negations=tuple(bool(item) for item in value["input_negations"]),
        output_inverted=bool(value["output_inverted"]),
        threshold=int(value["threshold"]),
        intervention_when_zero=str(value["intervention_when_zero"]),
        intervention_when_one=str(value["intervention_when_one"]),
    )
    if value.get("hypothesis_id") != candidate.hypothesis_id:
        raise ValueError("candidate identity mismatch")
    return candidate


def public_packet_from_dict(value: Mapping[str, Any]) -> AdaptiveWorldPublicPacket:
    public = AdaptiveWorldPublicPacket(
        episode_ref=str(value["episode_ref"]),
        variable_names=tuple(str(item) for item in value["variable_names"]),
        intervention_names=tuple(str(item) for item in value["intervention_names"]),  # type: ignore[arg-type]
        hypotheses=tuple(candidate_from_dict(item) for item in value["hypotheses"]),
        instrument_contexts=tuple(
            tuple(int(bit) for bit in context) for context in value["instrument_contexts"]
        ),
        evaluation_contexts=tuple(
            tuple(int(bit) for bit in context) for context in value["evaluation_contexts"]
        ),
        maximum_probe_batches=int(value["maximum_probe_batches"]),
        maximum_measurement_attempts=int(value["maximum_measurement_attempts"]),
        maximum_validator_calls=int(value["maximum_validator_calls"]),
        minimum_decisive_contexts=int(value["minimum_decisive_contexts"]),
        development_only=bool(value["development_only"]),
        research_question=str(value["research_question"]),
    )
    if value.get("episode_id") != public.episode_id:
        raise ValueError("public packet identity mismatch")
    return public


def authority_from_dict(value: Mapping[str, Any]) -> AdaptiveWorldAuthority:
    authority = AdaptiveWorldAuthority(
        episode_id=str(value["episode_id"]),
        scientific_state=ScientificState(value["scientific_state"]),
        selected_hypothesis_id=str(value["selected_hypothesis_id"]),
        underdetermined_alias_ids=tuple(str(item) for item in value["underdetermined_alias_ids"]),
        fault_class=FaultClass(value["fault_class"]),
        fault_trigger_attempt=int(value["fault_trigger_attempt"]),
        generator_seed=int(value["generator_seed"]),
        scorer_ref=str(value["scorer_ref"]),
    )
    if value.get("authority_id") != authority.authority_id:
        raise ValueError("authority identity mismatch")
    return authority


def validate_provider_package(
    public_bundle: Mapping[str, Any],
    private_bundle: Mapping[str, Any],
    commitment: Mapping[str, Any],
) -> Tuple[Tuple[Mapping[str, Any], AdaptiveWorldPublicPacket, AdaptiveWorldAuthority], ...]:
    _identified(public_bundle, "public_bundle_id")
    _identified(private_bundle, "private_bundle_id")
    _identified(commitment, "provider_commitment_id")
    if not (
        public_bundle.get("version") == PUBLIC_BUNDLE_VERSION
        and private_bundle.get("version") == PRIVATE_BUNDLE_VERSION
        and commitment.get("version") == PROVIDER_COMMITMENT_VERSION
        and commitment["public_bundle_id"] == public_bundle["public_bundle_id"]
        and commitment["private_bundle_id"] == private_bundle["private_bundle_id"]
        and commitment["freeze_id"] == public_bundle["freeze_id"] == private_bundle["freeze_id"]
        and commitment["provider_ref"]
        == public_bundle["provider_ref"]
        == private_bundle["provider_ref"]
        and commitment.get("provider_independent_of_authors_and_system") is True
        and commitment.get("private_bundle_withheld") is True
        and commitment.get("confirmatory_outcomes_opened") is False
        and len(public_bundle["tasks"]) == len(private_bundle["tasks"]) == 180
    ):
        raise ValueError("provider package identities disagree")
    try:
        entropy = bytes.fromhex(str(private_bundle["entropy_hex"]))
    except ValueError as error:
        raise ValueError("provider entropy encoding is invalid") from error
    if len(entropy) < 32:
        raise ValueError("provider entropy is too short")
    expected_cells = list(confirmatory_cells())
    random.Random(int.from_bytes(_derive(entropy, "task-order"), "big")).shuffle(
        expected_cells
    )
    private_by_ref = {item["task_ref"]: item for item in private_bundle["tasks"]}
    if len(private_by_ref) != 180:
        raise ValueError("provider private task references are not unique")
    records = []
    for expected_position, item in enumerate(public_bundle["tasks"]):
        private = private_by_ref.get(item["task_ref"])
        if (
            private is None
            or private["position"] != item["position"]
            or item["position"] != expected_position
            or private["cell"] != expected_cells[expected_position]
        ):
            raise ValueError("public/private task alignment failed")
        cell = private["cell"]
        seed = int.from_bytes(
            _derive(entropy, f"world-seed:{cell['cell_index']}")[:16], "big"
        ) | (1 << 127)
        expected_episode = (
            "episode-" + _derive(entropy, f"episode-ref:{cell['cell_index']}").hex()[:40]
        )
        expected_task_ref = (
            "task-" + _derive(entropy, f"task-ref:{cell['cell_index']}").hex()[:24]
        )
        expected_arm_order = list(ARM_KINDS)
        random.Random(
            int.from_bytes(_derive(entropy, f"arm-order:{cell['cell_index']}"), "big")
        ).shuffle(expected_arm_order)
        expected_ablation_order = [
            value.value for value in AdaptiveAblation if value != AdaptiveAblation.NONE
        ]
        random.Random(
            int.from_bytes(
                _derive(entropy, f"ablation-order:{cell['cell_index']}"), "big"
            )
        ).shuffle(expected_ablation_order)
        public = public_packet_from_dict(item["public_packet"])
        authority = authority_from_dict(private["authority"])
        if public.development_only or public.episode_id != authority.episode_id:
            raise ValueError("confirmatory public/authority task mismatch")
        expected_public, expected_authority = generate_adaptive_world(
            seed,
            scientific_state=ScientificState(cell["scientific_state"]),
            variable_count=int(cell["variable_count"]),
            fault_class=FaultClass(cell["fault_class"]),
            development_only=False,
            episode_ref=expected_episode,
        )
        if not (
            item["task_ref"] == expected_task_ref
            and item["arm_order"] == expected_arm_order
            and public == expected_public
            and authority == expected_authority
        ):
            raise ValueError("confirmatory task does not reproduce from committed entropy")
        expected_ablations = sorted(
            value.value for value in AdaptiveAblation if value != AdaptiveAblation.NONE
        )
        if bool(item.get("ablation_eligible")) != (private["cell"]["replicate"] == 0):
            raise ValueError("ablation subset is not outcome blind")
        if sorted(item.get("ablation_order", [])) != (
            expected_ablations if item["ablation_eligible"] else []
        ):
            raise ValueError("ablation order is incomplete")
        if item.get("ablation_order", []) != (
            expected_ablation_order if item["ablation_eligible"] else []
        ):
            raise ValueError("ablation order does not reproduce from provider entropy")
        records.append((item, public, authority))
    cells = [private_by_ref[item["task_ref"]]["cell"] for item in public_bundle["tasks"]]
    if sorted(cells, key=lambda value: value["cell_index"]) != list(confirmatory_cells()):
        raise ValueError("provider panel is not the exact committed crossed design")
    return tuple(records)
