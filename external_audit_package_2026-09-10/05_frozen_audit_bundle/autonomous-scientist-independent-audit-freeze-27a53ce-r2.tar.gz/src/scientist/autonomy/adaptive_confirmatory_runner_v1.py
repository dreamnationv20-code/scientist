from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping, Tuple

from scientist.autonomy.adaptive_codex_runner_v1 import (
    DEFAULT_MODEL,
    DEFAULT_MODEL_TOKEN_CEILING,
    DEFAULT_REASONING_EFFORT,
    DEFAULT_WALL_TIME_CEILING_SECONDS,
    AdaptiveCodexAgentResponse,
    AdaptiveCodexWorker,
    AdaptiveThreeArmGateway,
    assemble_adaptive_arm_result,
)
from scientist.autonomy.adaptive_confirmatory_provider_v1 import (
    read_identified,
    validate_audit_release,
    validate_provider_package,
)
from scientist.autonomy.adaptive_three_arm_v1 import ARM_KINDS, AdaptiveAblation
from scientist.autonomy.autonomous_scientist_freeze_v1 import (
    validate_implementation_freeze,
)
from scientist.core.artifacts import ArtifactStore, content_digest


CONFIRMATORY_RUNNER_VERSION = "adaptive-confirmatory-runner-v1"


def _manifest(store: ArtifactStore, name: str) -> Mapping[str, Any] | None:
    path = store.manifests / f"{name}.json"
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} is not an object")
    return value


def _validate_identity(value: Mapping[str, Any], key: str) -> None:
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"resume manifest has invalid {key}")


def _terminal_record(
    response: AdaptiveCodexAgentResponse,
    gateway: AdaptiveThreeArmGateway,
) -> Mapping[str, Any]:
    return {
        "arm_kind": response.arm_kind,
        "status": "terminal_response_collected",
        "proposal": response.proposal.as_dict(),
        "model_ref": response.model_ref,
        "reasoning_effort": response.reasoning_effort,
        "codex_version": response.codex_version,
        "token_usage": response.token_usage.as_dict(),
        "wall_seconds": response.wall_seconds,
        "transcript_id": response.transcript_id,
        "gateway_terminal_event_id": gateway.events[-1].event_id if gateway.events else None,
        "measurement_attempts": gateway.instrument.measurement_attempts,
        "probe_batches": gateway.instrument.probe_batches,
        "validator_calls": gateway.validator.calls,
        "score_present": False,
        "authority_present": False,
    }


def run_confirmatory_panel(
    *,
    project_root: Path,
    public_bundle: Mapping[str, Any],
    private_bundle: Mapping[str, Any],
    provider_commitment: Mapping[str, Any],
    freeze: Mapping[str, Any],
    audit_release: Mapping[str, Any],
    artifact_store: ArtifactStore,
    worker: AdaptiveCodexWorker,
) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    validate_implementation_freeze(freeze, root)
    validate_audit_release(audit_release, expected_freeze_id=freeze["freeze_id"])
    records = validate_provider_package(public_bundle, private_bundle, provider_commitment)
    if not (
        freeze.get("implementation_freeze_complete") is True
        and provider_commitment["freeze_id"] == freeze["freeze_id"]
        and provider_commitment["audit_release_id"] == audit_release["audit_release_id"]
        and worker.confirmatory_authorization_id
        == provider_commitment["provider_commitment_id"]
        and worker.project_deny_root == root
        and worker.model == DEFAULT_MODEL
        and worker.reasoning_effort == DEFAULT_REASONING_EFFORT
        and worker.model_token_ceiling == DEFAULT_MODEL_TOKEN_CEILING
        and worker.timeout_seconds == DEFAULT_WALL_TIME_CEILING_SECONDS
        and worker.scientist_ablation == AdaptiveAblation.NONE
    ):
        raise ValueError("confirmatory runner authorization chain is invalid")

    all_results: Dict[str, Any] = {}
    all_failures: Dict[str, Any] = {}
    task_manifests: Dict[str, str] = {}
    for item, public, authority in records:
        position = int(item["position"])
        task_ref = str(item["task_ref"])
        scored_name = f"confirmatory-scored-task-{position:03d}"
        prior_scored = _manifest(artifact_store, scored_name)
        if prior_scored is not None:
            _validate_identity(prior_scored, "task_result_id")
            if not (
                prior_scored.get("task_ref") == task_ref
                and prior_scored.get("position") == position
                and prior_scored.get("public_episode_id") == public.episode_id
            ):
                raise ValueError("scored resume manifest targets a different task")
            for key, value in prior_scored["results"].items():
                all_results[key] = value
            for key, value in prior_scored["failures"].items():
                all_failures[key] = value
            task_manifests[task_ref] = prior_scored["task_result_id"]
            continue

        opened_name = f"confirmatory-opened-task-{position:03d}"
        prior_opened = _manifest(artifact_store, opened_name)
        if prior_opened is not None:
            _validate_identity(prior_opened, "opened_id")
            if not (
                prior_opened.get("task_ref") == task_ref
                and prior_opened.get("position") == position
                and prior_opened.get("public_episode_id") == public.episode_id
                and prior_opened.get("provider_commitment_id")
                == provider_commitment["provider_commitment_id"]
            ):
                raise ValueError("opened resume manifest targets a different task")
            failures = {
                f"{task_ref}|{arm}": {
                    "type": "InterruptedMatchedTriple",
                    "message": "task was interrupted after opening; selective rerun prohibited",
                }
                for arm in ARM_KINDS
            }
            body = {
                "version": CONFIRMATORY_RUNNER_VERSION,
                "task_ref": task_ref,
                "position": position,
                "public_episode_id": public.episode_id,
                "pre_score_collection_id": None,
                "results": {},
                "failures": failures,
                "all_three_terminal_records_immutable_before_scoring": False,
                "authorities_opened_for_scoring": False,
                "selective_rerun_performed": False,
            }
            scored = {**body, "task_result_id": content_digest(body)}
            artifact_store.write_manifest(scored_name, scored)
            all_failures.update(failures)
            task_manifests[task_ref] = scored["task_result_id"]
            continue

        opened_body = {
            "version": CONFIRMATORY_RUNNER_VERSION,
            "task_ref": task_ref,
            "position": position,
            "public_episode_id": public.episode_id,
            "arm_order": list(item["arm_order"]),
            "provider_commitment_id": provider_commitment["provider_commitment_id"],
            "authority_present": False,
            "outcome_present": False,
        }
        artifact_store.write_manifest(
            opened_name,
            {**opened_body, "opened_id": content_digest(opened_body)},
        )

        collected: Dict[str, Tuple[AdaptiveCodexAgentResponse, AdaptiveThreeArmGateway]] = {}
        failures: Dict[str, Any] = {}
        terminal_records: Dict[str, Any] = {}
        for arm in item["arm_order"]:
            key = f"{task_ref}|{arm}"
            try:
                response, gateway = worker.run(public, authority, arm)
            except Exception as error:
                failures[key] = {"type": type(error).__name__, "message": str(error)}
                terminal_records[arm] = {
                    "arm_kind": arm,
                    "status": "runner_failure_terminal",
                    "failure_type": type(error).__name__,
                    "failure_message": str(error),
                    "score_present": False,
                    "authority_present": False,
                }
            else:
                collected[arm] = (response, gateway)
                terminal_records[arm] = _terminal_record(response, gateway)

        collection_body = {
            "version": CONFIRMATORY_RUNNER_VERSION,
            "task_ref": task_ref,
            "position": position,
            "public_episode_id": public.episode_id,
            "terminal_records": terminal_records,
            "all_three_arm_slots_terminal": set(terminal_records) == set(ARM_KINDS),
            "scores_present": False,
            "authority_present": False,
        }
        collection = {
            **collection_body,
            "pre_score_collection_id": content_digest(collection_body),
        }
        artifact_store.write_manifest(
            f"confirmatory-prescore-task-{position:03d}", collection
        )

        results: Dict[str, Any] = {}
        for arm, (response, gateway) in collected.items():
            key = f"{task_ref}|{arm}"
            try:
                result = assemble_adaptive_arm_result(
                    public,
                    authority,
                    response,
                    gateway,
                    model_token_ceiling=worker.model_token_ceiling,
                    wall_time_ceiling_seconds=worker.timeout_seconds,
                )
            except Exception as error:
                failures[key] = {"type": type(error).__name__, "message": str(error)}
            else:
                results[key] = result.as_dict()
                artifact_store.put("adaptive_confirmatory_arm_result", result.as_dict())

        body = {
            "version": CONFIRMATORY_RUNNER_VERSION,
            "task_ref": task_ref,
            "position": position,
            "public_episode_id": public.episode_id,
            "scientific_state": authority.scientific_state.value,
            "variable_count": len(public.variable_names),
            "fault_class": authority.fault_class.value,
            "pre_score_collection_id": collection["pre_score_collection_id"],
            "results": results,
            "failures": failures,
            "all_three_terminal_records_immutable_before_scoring": True,
            "authorities_opened_for_scoring": True,
            "selective_rerun_performed": False,
        }
        scored = {**body, "task_result_id": content_digest(body)}
        artifact_store.write_manifest(scored_name, scored)
        all_results.update(results)
        all_failures.update(failures)
        task_manifests[task_ref] = scored["task_result_id"]

    expected_slots = {
        f"{item['task_ref']}|{arm}"
        for item in public_bundle["tasks"]
        for arm in ARM_KINDS
    }
    task_strata = {
        item["task_ref"]: {
            "scientific_state": authority.scientific_state.value,
            "variable_count": len(public.variable_names),
            "fault_class": authority.fault_class.value,
        }
        for item, public, authority in records
    }
    body = {
        "version": CONFIRMATORY_RUNNER_VERSION,
        "status": "complete" if set(all_results).union(all_failures) == expected_slots else "incomplete",
        "freeze_id": freeze["freeze_id"],
        "audit_release_id": audit_release["audit_release_id"],
        "provider_commitment_id": provider_commitment["provider_commitment_id"],
        "public_bundle_id": public_bundle["public_bundle_id"],
        "private_bundle_id": private_bundle["private_bundle_id"],
        "task_count": 180,
        "arm_episode_count": 540,
        "task_result_ids": task_manifests,
        "task_strata": task_strata,
        "results": all_results,
        "failures": all_failures,
        "missing_or_invalid_episodes_score_zero": True,
        "authority_withholding_enforced_per_matched_triple": True,
        "selective_reruns_performed": False,
        "human_interventions": 0,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "confirmatory_run_id": content_digest(body)}


def load_confirmatory_inputs(
    *,
    public_bundle_path: Path,
    private_bundle_path: Path,
    provider_commitment_path: Path,
    freeze_path: Path,
    audit_release_path: Path,
) -> Tuple[Mapping[str, Any], ...]:
    return (
        read_identified(public_bundle_path, "public_bundle_id"),
        read_identified(private_bundle_path, "private_bundle_id"),
        read_identified(provider_commitment_path, "provider_commitment_id"),
        read_identified(freeze_path, "freeze_id"),
        read_identified(audit_release_path, "audit_release_id"),
    )
