from __future__ import annotations

import inspect
import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_codex_runner_v1 import adaptive_runner_contract
from scientist.autonomy.adaptive_three_arm_v1 import adaptive_three_arm_contract
from scientist.autonomy.adaptive_worlds_v1 import (
    AdaptiveConclusion,
    AdaptivePublicValidator,
    AdaptiveWorldInstrument,
    ConclusionDisposition,
    FaultClass,
    RuleKind,
    ScientificState,
    canonical_design_contexts,
    generate_adaptive_world,
    run_answer_blind_reference_policy,
    score_adaptive_world,
)
from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


ADAPTIVE_QUALIFICATION_VERSION = "adaptive-causal-harness-qualification-v9"
EXPECTED_SCHEMA_COMPATIBILITY_ADJUDICATION_ID = (
    "e95429ea7126d2a8333fd0e0c49fec7b38a012cdb6857ea7e025ce160aecb16b"
)


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def _constant_conclusion(public: Any) -> AdaptiveConclusion:
    selected = next(
        (item for item in public.hypotheses if item.rule_kind != RuleKind.NULL),
        public.hypotheses[0],
    )
    return AdaptiveConclusion(
        episode_id=public.episode_id,
        selected_hypothesis_id=selected.hypothesis_id,
        disposition=ConclusionDisposition.PROMOTE,
        predicted_interventions={
            "".join(map(str, context)): selected.prediction(context)
            for context in public.evaluation_contexts
        },
        cited_evidence_refs=(),
        failure_dispositions={},
        validator_certificate_id="not-issued",
        limitations=("constant no-evidence qualification policy",),
    )


def build_adaptive_qualification(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    commitment_path = (
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v6/artifacts/manifests"
        / "protocol-commitment-v6.json"
    )
    commitment = _identified(commitment_path, "commitment_id")
    if commitment.get("model_token_ceiling_per_episode") != 128_000:
        raise ValueError("adaptive runtime amendment was not committed")
    confirmatory = root / commitment["confirmatory_namespace"]
    if confirmatory.exists():
        raise ValueError("confirmatory namespace exists before harness qualification")
    compatibility_path = (
        root
        / "runs/autonomy_closure_v1/schema_compatibility_adjudication_v1"
        / "artifacts/manifests/schema-compatibility-adjudication-v1.json"
    )
    compatibility = _identified(compatibility_path, "adjudication_id")
    if not (
        compatibility["adjudication_id"]
        == EXPECTED_SCHEMA_COMPATIBILITY_ADJUDICATION_ID
        and compatibility["failed_panel_permanently_excluded"] is True
        and compatibility["smoke_reached_model_inference"] is True
        and compatibility["confirmatory_execution_authorized"] is False
    ):
        raise ValueError("structured-output compatibility correction is not adjudicated")

    source_paths = (
        root / "src/scientist/autonomy/adaptive_worlds_v1.py",
        root / "src/scientist/autonomy/adaptive_three_arm_v1.py",
        root / "src/scientist/autonomy/adaptive_codex_runner_v1.py",
        root / "src/scientist/autonomy/adaptive_qualification_v1.py",
        root / "src/scientist/autonomy/schema_compatibility_adjudication_v1.py",
        root / "src/scientist/autonomy/adaptive_confirmatory_provider_v1.py",
        root / "src/scientist/autonomy/adaptive_confirmatory_runner_v1.py",
        root / "src/scientist/autonomy/adaptive_confirmatory_analysis_v1.py",
        root / "src/scientist/autonomy/adaptive_ablation_runner_v1.py",
        root / "src/scientist/autonomy/adaptive_ablation_analysis_v1.py",
        root / "src/scientist/autonomy/adaptive_replication_analysis_v1.py",
        root / "src/scientist/autonomy/nature_evidence_integration_v1.py",
        root / "src/scientist/autonomy/confirmatory_runtime_commitment_v1.py",
        root / "src/scientist/autonomy/causalab_transport_provider_v1.py",
        root / "src/scientist/autonomy/causalab_transport_runner_v1.py",
        root / "src/scientist/autonomy/causalab_transport_analysis_v1.py",
        root / "tests/test_autonomy_adaptive_worlds_v1.py",
        root / "tests/test_autonomy_adaptive_three_arm_v1.py",
        root / "tests/test_autonomy_adaptive_confirmatory_v1.py",
        root / "tests/test_autonomy_causalab_transport_v1.py",
        root / "docs/autonomous-scientist-prospective-evaluation-protocol-v6-amendment.md",
        root / "docs/autonomous-scientist-prefreeze-recovery-closure-adjudication-2026-09-09.md",
        root / "docs/autonomous-scientist-prefreeze-terminal-control-adjudication-2026-09-09.md",
        root / "docs/autonomous-scientist-prefreeze-schema-compatibility-adjudication-2026-09-09.md",
        root / "docs/autonomous-scientist-confirmatory-runtime-and-transport-supplement-2026-09-09.md",
    )
    for path in source_paths:
        if not path.is_file():
            raise FileNotFoundError(path)

    task_records = []
    reference_passes = 0
    constant_passes = 0
    maximum_design_contexts = 0
    maximum_reference_attempts = 0
    maximum_reference_batches = 0
    serial = 0
    for state in ScientificState:
        for width in (5, 6, 7):
            for fault in FaultClass:
                for replicate in range(2):
                    seed = 810_000 + serial
                    serial += 1
                    public, authority = generate_adaptive_world(
                        seed,
                        scientific_state=state,
                        variable_count=width,
                        fault_class=fault,
                        development_only=True,
                    )
                    regenerated = generate_adaptive_world(
                        seed,
                        scientific_state=state,
                        variable_count=width,
                        fault_class=fault,
                        development_only=True,
                    )
                    deterministic = regenerated == (public, authority)
                    public_text = json.dumps(public.as_dict(), sort_keys=True)
                    authority_sequestered = all(
                        key not in public_text
                        for key in (
                            "generator_seed",
                            "selected_hypothesis_id",
                            "scientific_state",
                            "fault_class",
                            "authority_id",
                        )
                    )
                    design = canonical_design_contexts(public)
                    maximum_design_contexts = max(maximum_design_contexts, len(design))

                    instrument = AdaptiveWorldInstrument(public, authority)
                    conclusion, certificate = run_answer_blind_reference_policy(
                        public, instrument
                    )
                    reference_score = score_adaptive_world(
                        public,
                        authority,
                        instrument,
                        conclusion,
                        certificate,
                        trace_complete=True,
                        within_budget=True,
                        no_forbidden_operation=True,
                    )
                    reference_passes += int(reference_score.valid_root_advance)
                    maximum_reference_attempts = max(
                        maximum_reference_attempts, instrument.measurement_attempts
                    )
                    maximum_reference_batches = max(
                        maximum_reference_batches, instrument.probe_batches
                    )

                    constant_instrument = AdaptiveWorldInstrument(public, authority)
                    constant = _constant_conclusion(public)
                    constant_score = score_adaptive_world(
                        public,
                        authority,
                        constant_instrument,
                        constant,
                        None,
                        trace_complete=True,
                        within_budget=True,
                        no_forbidden_operation=True,
                    )
                    constant_passes += int(constant_score.valid_root_advance)
                    task_records.append(
                        {
                            "episode_id": public.episode_id,
                            "authority_id": authority.authority_id,
                            "scientific_state": state.value,
                            "variable_count": width,
                            "fault_class": fault.value,
                            "replicate": replicate,
                            "candidate_count": len(public.hypotheses),
                            "instrument_context_count": len(public.instrument_contexts),
                            "evaluation_context_count": len(public.evaluation_contexts),
                            "canonical_design_context_count": len(design),
                            "deterministic": deterministic,
                            "authority_sequestered": authority_sequestered,
                            "reference_certificate_accepted": certificate.accepted,
                            "reference_valid_root_advance": reference_score.valid_root_advance,
                            "reference_recovery_correct": instrument.recovery_complete_and_correct,
                            "constant_valid_root_advance": constant_score.valid_root_advance,
                        }
                    )

    total = len(task_records)
    reference_rate = reference_passes / total
    constant_rate = constant_passes / total
    all_deterministic = all(item["deterministic"] for item in task_records)
    all_sequestered = all(item["authority_sequestered"] for item in task_records)
    all_cells_present = total == 5 * 3 * 6 * 2
    validator_signature = inspect.signature(AdaptivePublicValidator)
    validator_answer_blind = "authority" not in validator_signature.parameters
    checks = {
        "all_180_excluded_worlds_generated": all_cells_present,
        "all_worlds_deterministic": all_deterministic,
        "all_public_packets_sequester_authority": all_sequestered,
        "reference_policy_at_least_95_percent": reference_rate >= 0.95,
        "constant_policy_at_most_10_percent": constant_rate <= 0.10,
        "all_reference_fault_recoveries_correct": all(
            item["reference_recovery_correct"] for item in task_records
        ),
        "reference_within_probe_batch_budget": maximum_reference_batches <= 3,
        "reference_within_measurement_budget": maximum_reference_attempts <= 24,
        "validator_constructor_has_no_authority": validator_answer_blind,
        "runner_rejects_confirmatory_tasks": (
            adaptive_runner_contract()["confirmatory_tasks_accepted"] is False
        ),
        "confirmatory_namespace_absent": not confirmatory.exists(),
        "transport_namespace_absent": not (
            root / "runs/autonomy_closure_v1/causalab_transport_confirmatory_v1"
        ).exists(),
        "replication_namespace_absent": not (
            root / "runs/autonomy_closure_v1/adaptive_independent_replication_v1"
        ).exists(),
    }
    body: Dict[str, Any] = {
        "version": ADAPTIVE_QUALIFICATION_VERSION,
        "status": "no_model_harness_qualified_live_discrimination_pending",
        "development_only": True,
        "permanently_excluded": True,
        "protocol_commitment_id": commitment["commitment_id"],
        "schema_compatibility_adjudication_id": compatibility["adjudication_id"],
        "task_count": total,
        "state_count": len(tuple(ScientificState)),
        "variable_count_tiers": [5, 6, 7],
        "fault_count": len(tuple(FaultClass)),
        "replicates_per_crossed_cell": 2,
        "reference_policy_valid_root_advance_rate": reference_rate,
        "constant_policy_valid_root_advance_rate": constant_rate,
        "maximum_canonical_design_contexts": maximum_design_contexts,
        "maximum_reference_measurement_attempts": maximum_reference_attempts,
        "maximum_reference_probe_batches": maximum_reference_batches,
        "checks": checks,
        "all_checks_passed": all(checks.values()),
        "three_arm_contract": adaptive_three_arm_contract(),
        "runner_contract": adaptive_runner_contract(),
        "source_hashes": {
            str(path.relative_to(root)): bytes_sha256(path.read_bytes())
            for path in source_paths
        },
        "task_records": task_records,
        "live_control_discrimination_gate_complete": False,
        "implementation_freeze_complete": False,
        "confirmatory_execution_authorized": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "qualification_id": content_digest(body)}
