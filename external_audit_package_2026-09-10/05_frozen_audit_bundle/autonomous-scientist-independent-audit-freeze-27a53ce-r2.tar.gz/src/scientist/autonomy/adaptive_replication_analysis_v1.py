from __future__ import annotations

from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_confirmatory_analysis_v1 import (
    BOOTSTRAP_REPLICATES,
    analyze_adaptive_confirmatory_run,
)
from scientist.core.artifacts import content_digest


ADAPTIVE_REPLICATION_ANALYSIS_VERSION = "adaptive-independent-replication-analysis-v1"


def analyze_adaptive_replication_run(
    run: Mapping[str, Any], *, bootstrap_replicates: int = BOOTSTRAP_REPLICATES
) -> Mapping[str, Any]:
    base = analyze_adaptive_confirmatory_run(
        run, bootstrap_replicates=bootstrap_replicates
    )
    gates = base["gates"]
    replication_gates = {
        "prompt_equated_simultaneous_interval_above_zero": gates[
            "primary_simultaneous_interval_above_zero"
        ],
        "free_simultaneous_interval_above_zero": gates[
            "secondary_simultaneous_interval_above_zero"
        ],
        "no_negative_scientific_state_stratum": gates[
            "no_negative_scientific_state_stratum"
        ],
        "no_negative_variable_tier_stratum": gates[
            "no_negative_variable_tier_stratum"
        ],
        "scientist_false_promotion_below_2_percent": gates[
            "scientist_false_promotion_below_2_percent"
        ],
        "scientist_false_promotion_noninferior_within_1pp": gates[
            "scientist_false_promotion_noninferior_within_1pp"
        ],
        "zero_human_completion_at_least_90_percent": gates[
            "zero_human_completion_at_least_90_percent"
        ],
        "exact_provenance_and_accounting": gates[
            "exact_provenance_and_accounting"
        ],
        "positive_typed_recovery_evidence": gates[
            "positive_typed_recovery_evidence"
        ],
    }
    body: Dict[str, Any] = {
        "version": ADAPTIVE_REPLICATION_ANALYSIS_VERSION,
        "confirmatory_run_id": base["confirmatory_run_id"],
        "base_analysis_id": base["analysis_id"],
        "task_count": base["task_count"],
        "rates": base["rates"],
        "contrasts": base["contrasts"],
        "state_differences": base["state_differences"],
        "tier_differences": base["tier_differences"],
        "false_promotion_rates": base["false_promotion_rates"],
        "zero_human_completion_rate": base["zero_human_completion_rate"],
        "accounting_complete": base["accounting_complete"],
        "replication_gates": replication_gates,
        "independent_replication_result_passed": all(replication_gates.values()),
        "independent_execution_attestation_required": True,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "replication_analysis_id": content_digest(body)}
