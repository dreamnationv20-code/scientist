from __future__ import annotations

import json
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.adaptive_worlds_v1 import (
    ADAPTIVE_WORLD_VERSION,
    AdaptiveConclusion,
    AdaptivePublicValidator,
    AdaptiveValidationCertificate,
    AdaptiveWorldInstrument,
    AdaptiveWorldPublicPacket,
    ConclusionDisposition,
    FaultClass,
    ProbeQuery,
    ProbeStatus,
    RecoveryTransition,
    RuleKind,
    _predictions_for_alias_group,
    _predictions_for_candidate,
    _replacement_context,
    _decisive_labels,
    _live_candidates,
    _structurally_aliased,
    canonical_design_contexts,
)
from scientist.core.artifacts import content_digest


ADAPTIVE_THREE_ARM_VERSION = "adaptive-causal-three-arm-contract-v2"
ARM_FREE = "free_monolithic_codex"
ARM_PROMPT_EQUATED = "prompt_equated_monolithic_codex"
ARM_SCIENTIST = "authority_separated_scientist"
ARM_KINDS = (ARM_FREE, ARM_PROMPT_EQUATED, ARM_SCIENTIST)


class AdaptiveAblation(str, Enum):
    NONE = "none"
    CAUSAL_MEMORY = "remove_causal_memory"
    PLAN_ADMISSIBILITY = "remove_plan_admissibility"
    CANDIDATE_VALIDATION = "remove_candidate_validation"
    TYPED_RECOVERY = "remove_typed_recovery"
    INDEPENDENT_PROMOTION = "remove_independent_promotion"


METHOD_POLICY_APPENDIX = """ANSWER-BLIND METHOD POLICY
Maintain the live candidate set across every observation. Design paired probes
that separate all publicly distinguishable candidates and meet the decisive-
context floor. Preserve immutable evidence references. When a typed fault occurs,
apply its public recovery transition without erasing unaffected state. Before a
terminal decision, call validate_candidate; use its bounded counterexamples to
revise and revalidate. Promote only one isolated non-null policy, kill only an
isolated null, and abstain only for certified structural underdetermination."""


def adaptive_model_public_packet(public: AdaptiveWorldPublicPacket) -> Mapping[str, Any]:
    return {
        "episode_ref": public.episode_ref,
        "variables": list(public.variable_names),
        "interventions": list(public.intervention_names),
        "hypotheses": [
            {
                "ref": item.hypothesis_ref,
                "rule": item.rule_kind.value,
                "variable_names": [public.variable_names[index] for index in item.variable_indices],
                "input_negations": list(item.input_negations),
                "output_inverted": item.output_inverted,
                "threshold": item.threshold,
                "intervention_when_zero": item.intervention_when_zero,
                "intervention_when_one": item.intervention_when_one,
            }
            for item in public.hypotheses
        ],
        "instrument_contexts": [list(item) for item in public.instrument_contexts],
        "evaluation_contexts": [list(item) for item in public.evaluation_contexts],
        "budgets": {
            "probe_batches": public.maximum_probe_batches,
            "measurement_attempts": public.maximum_measurement_attempts,
            "validator_calls": public.maximum_validator_calls,
        },
        "minimum_decisive_contexts": public.minimum_decisive_contexts,
        "recovery_contract": public.as_dict()["recovery_contract"],
        "terminal_tokens": public.as_dict()["terminal_tokens"],
        "research_question": public.research_question,
    }


def adaptive_probe_schema(
    public: AdaptiveWorldPublicPacket | None = None,
) -> Mapping[str, Any]:
    context_schema: Dict[str, Any] = {
        "type": "array",
        "minItems": 5,
        "maxItems": 7,
        "items": {"type": "integer", "enum": [0, 1]},
    }
    intervention_schema: Dict[str, Any] = {"type": "string"}
    maximum = 36
    if public is not None:
        context_schema = {
            "type": "array",
            "minItems": len(public.variable_names),
            "maxItems": len(public.variable_names),
            "items": {"type": "integer", "enum": [0, 1]},
        }
        intervention_schema = {
            "type": "string",
            "enum": list(public.intervention_names),
        }
        maximum = public.maximum_measurement_attempts
    return {
        "type": "object",
        "properties": {
            "queries": {
                "type": "array",
                "minItems": 1,
                "maxItems": maximum,
                "items": {
                    "type": "object",
                    "properties": {
                        "context": context_schema,
                        "intervention": intervention_schema,
                        "replicate": {"type": "integer", "minimum": 0},
                    },
                    "required": ["context", "intervention", "replicate"],
                    "additionalProperties": False,
                },
            },
            "responding_to": {"type": ["string", "null"]},
            "recovery_transition": {
                "type": ["string", "null"],
                "enum": ["retry", "amend", "reframe", "park", "stop", None],
            },
        },
        "required": ["queries", "responding_to", "recovery_transition"],
        "additionalProperties": False,
    }


def adaptive_validate_schema(
    public: AdaptiveWorldPublicPacket | None = None,
) -> Mapping[str, Any]:
    hypothesis_schema: Dict[str, Any] = {"type": "string"}
    context_schema: Dict[str, Any] = {
        "type": "array",
        "minItems": 5,
        "maxItems": 7,
        "items": {"type": "integer", "enum": [0, 1]},
    }
    intervention_schema: Dict[str, Any] = {"type": "string"}
    prediction_count: Dict[str, int] = {"minItems": 1}
    if public is not None:
        hypothesis_schema = {
            "type": "string",
            "enum": [item.hypothesis_ref for item in public.hypotheses]
            + ["underdetermined"],
        }
        context_schema = {
            "type": "array",
            "minItems": len(public.variable_names),
            "maxItems": len(public.variable_names),
            "items": {"type": "integer", "enum": [0, 1]},
        }
        intervention_schema = {
            "type": "string",
            "enum": list(public.intervention_names)
            + ["equivalent", "underdetermined"],
        }
        prediction_count = {
            "minItems": len(public.evaluation_contexts),
            "maxItems": len(public.evaluation_contexts),
        }
    return {
        "type": "object",
        "properties": {
            "selected_hypothesis_ref": hypothesis_schema,
            "disposition": {"type": "string", "enum": ["promote", "kill", "abstain"]},
            "predictions": {
                "type": "array",
                **prediction_count,
                "items": {
                    "type": "object",
                    "properties": {
                        "context": context_schema,
                        "intervention": intervention_schema,
                    },
                    "required": ["context", "intervention"],
                    "additionalProperties": False,
                },
            },
            "cited_evidence_refs": {
                "type": "array",
                "items": {"type": "string", "pattern": "^e[0-9]{3}$"},
            },
        },
        "required": [
            "selected_hypothesis_ref",
            "disposition",
            "predictions",
            "cited_evidence_refs",
        ],
        "additionalProperties": False,
    }


def adaptive_conclusion_schema(
    public: AdaptiveWorldPublicPacket | None = None,
) -> Mapping[str, Any]:
    validate = adaptive_validate_schema(public)
    properties = dict(validate["properties"])
    properties.update(
        {
            "failure_dispositions": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "failure_ref": {"type": "string"},
                        "transition": {
                            "type": "string",
                            "enum": ["retry", "amend", "reframe", "park", "stop"],
                        },
                    },
                    "required": ["failure_ref", "transition"],
                    "additionalProperties": False,
                },
            },
            "validator_certificate_ref": {"type": "string"},
            "limitations": {
                "type": "array",
                "minItems": 1,
                "items": {"type": "string", "minLength": 1},
            },
        }
    )
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": properties,
        "required": list(validate["required"])
        + ["failure_dispositions", "validator_certificate_ref", "limitations"],
        "additionalProperties": False,
    }


def _context_key(context: Sequence[int]) -> str:
    return "".join(str(int(value)) for value in context)


def _parse_predictions(
    public: AdaptiveWorldPublicPacket, raw: Any
) -> Mapping[str, str]:
    if not isinstance(raw, list):
        raise ValueError("predictions must be an array")
    result: Dict[str, str] = {}
    permitted = set(public.intervention_names).union({"equivalent", "underdetermined"})
    evaluation = set(public.evaluation_contexts)
    for item in raw:
        if not isinstance(item, Mapping) or set(item) != {"context", "intervention"}:
            raise ValueError("prediction entry is malformed")
        context = tuple(int(value) for value in item["context"])
        if context not in evaluation:
            raise ValueError("prediction context is not an evaluation context")
        key = _context_key(context)
        if key in result:
            raise ValueError("prediction context is duplicated")
        intervention = str(item["intervention"])
        if intervention not in permitted:
            raise ValueError("prediction uses an unknown terminal token")
        result[key] = intervention
    if len(result) != len(evaluation):
        raise ValueError("predictions must cover every evaluation context")
    return result


def _hypothesis_id(public: AdaptiveWorldPublicPacket, reference: str) -> str:
    if reference == "underdetermined":
        return reference
    matches = [item for item in public.hypotheses if item.hypothesis_ref == reference]
    if len(matches) != 1:
        raise ValueError("unknown or ambiguous hypothesis reference")
    return matches[0].hypothesis_id


def _hypothesis_ref(public: AdaptiveWorldPublicPacket, identity: str) -> str:
    if identity == "underdetermined":
        return identity
    return next(item.hypothesis_ref for item in public.hypotheses if item.hypothesis_id == identity)


@dataclass(frozen=True)
class AdaptiveGatewayEvent:
    sequence: int
    event_kind: str
    actor_kind: str
    authority_scope: str
    payload_digest: str
    prior_event_id: str | None

    @property
    def event_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": ADAPTIVE_THREE_ARM_VERSION,
            "sequence": self.sequence,
            "event_kind": self.event_kind,
            "actor_kind": self.actor_kind,
            "authority_scope": self.authority_scope,
            "payload_digest": self.payload_digest,
            "prior_event_id": self.prior_event_id,
        }
        if include_id:
            value["event_id"] = self.event_id
        return value


@dataclass(frozen=True)
class AdaptiveLifecycleDecision:
    proposed_conclusion: AdaptiveConclusion
    authorized_conclusion: AdaptiveConclusion
    public_checks: Mapping[str, bool]
    proposal_modified: bool
    terminal_authorized: bool

    @property
    def decision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": ADAPTIVE_THREE_ARM_VERSION,
            "proposed_conclusion": self.proposed_conclusion.as_dict(),
            "authorized_conclusion": self.authorized_conclusion.as_dict(),
            "public_checks": dict(sorted(self.public_checks.items())),
            "proposal_modified": self.proposal_modified,
            "terminal_authorized": self.terminal_authorized,
        }
        if include_id:
            value["decision_id"] = self.decision_id
        return value


class AdaptiveThreeArmGateway:
    """Shared tools; only the Scientist arm receives answer-blind enforcement."""

    def __init__(
        self,
        public: AdaptiveWorldPublicPacket,
        instrument: AdaptiveWorldInstrument,
        arm_kind: str,
        ablation: AdaptiveAblation | str = AdaptiveAblation.NONE,
    ) -> None:
        if arm_kind not in ARM_KINDS:
            raise ValueError("unknown adaptive evaluation arm")
        if public.episode_id != instrument.public.episode_id:
            raise ValueError("adaptive gateway inputs disagree")
        ablation = AdaptiveAblation(ablation)
        if arm_kind != ARM_SCIENTIST and ablation != AdaptiveAblation.NONE:
            raise ValueError("component ablations are defined only for the Scientist arm")
        self.public = public
        self.instrument = instrument
        self.arm_kind = arm_kind
        self.ablation = ablation
        self.validator = AdaptivePublicValidator(public, instrument)
        self.events: list[AdaptiveGatewayEvent] = []
        self.certificates: Dict[str, AdaptiveValidationCertificate] = {}
        self._planned_by_id: Dict[str, ProbeQuery] = {}
        self._outstanding: list[ProbeQuery] = []
        self._last_failure = None
        self._terminal_public_state: Mapping[str, Any] | None = None
        self._latest_batch_evidence_refs: Tuple[str, ...] = ()
        self._record("task_bound", "state_host", "commit", public.as_dict())

    def _record(
        self, event_kind: str, actor_kind: str, authority_scope: str, payload: Any
    ) -> None:
        prior = self.events[-1].event_id if self.events else None
        self.events.append(
            AdaptiveGatewayEvent(
                sequence=len(self.events) + 1,
                event_kind=event_kind,
                actor_kind=actor_kind,
                authority_scope=authority_scope,
                payload_digest=content_digest(payload),
                prior_event_id=prior,
            )
        )

    @property
    def event_chain_valid(self) -> bool:
        prior = None
        for index, event in enumerate(self.events, start=1):
            if event.sequence != index or event.prior_event_id != prior:
                return False
            prior = event.event_id
        return True

    def _parse_queries(self, payload: Mapping[str, Any]) -> Tuple[ProbeQuery, ...]:
        if set(payload) != {"queries", "responding_to", "recovery_transition"}:
            raise ValueError("probe payload fields differ from the shared schema")
        raw = payload["queries"]
        if not isinstance(raw, list) or not raw:
            raise ValueError("probe queries must be a non-empty array")
        queries = []
        for item in raw:
            if not isinstance(item, Mapping) or set(item) != {
                "context",
                "intervention",
                "replicate",
            }:
                raise ValueError("probe query is malformed")
            queries.append(
                ProbeQuery(
                    tuple(int(value) for value in item["context"]),
                    str(item["intervention"]),
                    int(item["replicate"]),
                )
            )
        return tuple(queries)

    def _design_admissible(self, queries: Sequence[ProbeQuery]) -> bool:
        # A pre-fault plan that consumes the full budget is not admissible: the
        # hidden schedule may require reacquisition or a two-cell reframe.
        if len(queries) + 2 > self.public.maximum_measurement_attempts:
            return False
        by_context: Dict[Tuple[int, ...], set[str]] = {}
        for query in queries:
            if (
                len(query.context) != len(self.public.variable_names)
                or query.context not in self.public.instrument_contexts
                or query.intervention not in self.public.intervention_names
            ):
                return False
            by_context.setdefault(query.context, set()).add(query.intervention)
        paired = tuple(
            context
            for context, interventions in by_context.items()
            if set(self.public.intervention_names).issubset(interventions)
        )
        if len(paired) < self.public.minimum_decisive_contexts:
            return False

        def unresolved(contexts: Sequence[Sequence[int]]) -> set[Tuple[int, int]]:
            return {
                (left, right)
                for left in range(len(self.public.hypotheses))
                for right in range(left + 1, len(self.public.hypotheses))
                if all(
                    self.public.hypotheses[left].prediction(context)
                    == self.public.hypotheses[right].prediction(context)
                    for context in contexts
                )
            }

        return unresolved(paired) == unresolved(self.public.instrument_contexts)

    def _canonical_queries(self) -> Tuple[ProbeQuery, ...]:
        return tuple(
            ProbeQuery(context, intervention, 0)
            for context in canonical_design_contexts(self.public)
            for intervention in self.public.intervention_names
        )

    def _scientist_recovery_queries(self) -> Tuple[ProbeQuery, ...]:
        failure = self._last_failure
        if failure is None or failure.failure_ref is None:
            raise ValueError("Scientist recovery requested without a recorded failure")
        remaining = list(self._outstanding)
        if failure.status == ProbeStatus.PERMANENT_ACTION_UNAVAILABLE:
            used = tuple(
                dict.fromkeys(
                    item.query.context
                    for item in self.instrument.observations
                )
            )
            replacement = _replacement_context(
                self.public,
                used + (failure.query.context,),
                failure.query.context,
            )
            remaining = [item for item in remaining if item.context != failure.query.context]
            recovery = [
                ProbeQuery(replacement, intervention, 0)
                for intervention in self.public.intervention_names
            ]
        elif failure.status in {
            ProbeStatus.PROTOCOL_INVALID_REQUEST,
            ProbeStatus.MEASUREMENT_AMBIGUITY,
        }:
            recovery = [
                ProbeQuery(
                    failure.query.context,
                    failure.query.intervention,
                    failure.query.replicate + 1,
                )
            ]
        else:
            recovery = [failure.query]
        seen = {item.query_id for item in recovery}
        return tuple(recovery + [item for item in remaining if item.query_id not in seen])

    def _probe_response(self, result: Any, repaired: bool) -> Mapping[str, Any]:
        evidence_refs = [item.evidence_ref for item in self.instrument.observations]
        if self.ablation == AdaptiveAblation.CAUSAL_MEMORY:
            evidence_refs = list(self._latest_batch_evidence_refs)
        return {
            "batch": result.as_dict(),
            "repair_applied": repaired,
            "state": {
                "event_count": len(self.events),
                "evidence_refs": evidence_refs,
                "pending_failure_ref": self.instrument.pending_failure_ref,
                "measurement_attempts_used": self.instrument.measurement_attempts,
                "probe_batches_used": self.instrument.probe_batches,
            },
        }

    def handle_probe(self, payload: Any) -> Tuple[int, Mapping[str, Any]]:
        if not isinstance(payload, Mapping):
            return 400, {"error": "probe payload must be an object"}
        try:
            if (
                self.arm_kind == ARM_SCIENTIST
                and self._terminal_public_state is not None
                and self.ablation != AdaptiveAblation.CAUSAL_MEMORY
            ):
                self._record(
                    "redundant_probe_withheld",
                    "design_authority",
                    "authorize_tool",
                    self._terminal_public_state,
                )
                return 200, {
                    "probe_withheld": True,
                    "reason": "public evidence is terminal; revalidate the recommended conclusion",
                    "recommended_public_terminal": self._terminal_public_state,
                    "state": {
                        "event_count": len(self.events),
                        "evidence_refs": [
                            item.evidence_ref for item in self.instrument.observations
                        ],
                        "pending_failure_ref": self.instrument.pending_failure_ref,
                        "measurement_attempts_used": self.instrument.measurement_attempts,
                        "probe_batches_used": self.instrument.probe_batches,
                    },
                }
            submitted = self._parse_queries(payload)
            responding = payload["responding_to"]
            raw_transition = payload["recovery_transition"]
            transition = RecoveryTransition(raw_transition) if raw_transition else None
            repaired = False
            queries = submitted
            if self.arm_kind == ARM_SCIENTIST:
                if (
                    self.instrument.pending_failure_ref is not None
                    and self.ablation != AdaptiveAblation.TYPED_RECOVERY
                ):
                    queries = self._scientist_recovery_queries()
                    assert self._last_failure is not None
                    responding = self._last_failure.failure_ref
                    transition = RecoveryTransition(
                        self.public.as_dict()["recovery_contract"][self._last_failure.status.value]
                    )
                    repaired = (
                        queries != submitted
                        or responding != payload["responding_to"]
                        or (transition.value if transition else None) != raw_transition
                    )
                    self._record(
                        "typed_recovery_enforced",
                        "recovery_authority",
                        "recover",
                        {"queries": [item.as_dict() for item in queries], "transition": transition.value},
                    )
                elif (
                    self.instrument.probe_batches == 0
                    and self.ablation != AdaptiveAblation.PLAN_ADMISSIBILITY
                    and not self._design_admissible(submitted)
                ):
                    queries = self._canonical_queries()
                    repaired = True
                    self._record(
                        "design_admissibility_repaired",
                        "design_authority",
                        "authorize_tool",
                        [item.as_dict() for item in queries],
                    )
            self._record(
                "probe_batch_submitted",
                "proposal_model",
                "propose",
                [item.as_dict() for item in submitted],
            )
            self._planned_by_id = {item.query_id: item for item in queries}
            evidence_before = {item.evidence_ref for item in self.instrument.observations}
            result = self.instrument.probe_batch(
                queries,
                responding_to=str(responding) if responding is not None else None,
                recovery_transition=transition,
            )
            self._outstanding = [
                self._planned_by_id[item]
                for item in result.unattempted_query_ids
                if item in self._planned_by_id
            ]
            self._last_failure = next(
                (item for item in result.results if item.status != ProbeStatus.OK), None
            )
            self._latest_batch_evidence_refs = tuple(
                item.evidence_ref
                for item in self.instrument.observations
                if item.evidence_ref not in evidence_before
            )
            self._record(
                "probe_batch_committed",
                "instrument",
                "execute_tool",
                result.as_dict(),
            )
            if self._last_failure is not None:
                self._record(
                    "fault_classified",
                    "state_host",
                    "classify_failure",
                    self._last_failure.as_dict(),
                )
            return 200, self._probe_response(result, repaired)
        except (KeyError, TypeError, ValueError) as error:
            self._record("probe_request_rejected", "instrument", "execute_tool", str(error))
            return 400, {"error": str(error)}

    def handle_validate(self, payload: Any) -> Tuple[int, Mapping[str, Any]]:
        if not isinstance(payload, Mapping):
            return 400, {"error": "validation payload must be an object"}
        try:
            recovery_result = None
            if (
                self.arm_kind == ARM_SCIENTIST
                and self.instrument.pending_failure_ref is not None
                and self.ablation != AdaptiveAblation.TYPED_RECOVERY
            ):
                queries = self._scientist_recovery_queries()
                assert self._last_failure is not None
                evidence_before_recovery = {
                    item.evidence_ref for item in self.instrument.observations
                }
                transition = RecoveryTransition(
                    self.public.as_dict()["recovery_contract"][
                        self._last_failure.status.value
                    ]
                )
                self._record(
                    "typed_recovery_closed_before_validation",
                    "recovery_authority",
                    "recover",
                    {
                        "queries": [item.as_dict() for item in queries],
                        "transition": transition.value,
                    },
                )
                recovery_result = self.instrument.probe_batch(
                    queries,
                    responding_to=self._last_failure.failure_ref,
                    recovery_transition=transition,
                )
                self._latest_batch_evidence_refs = tuple(
                    item.evidence_ref
                    for item in self.instrument.observations
                    if item.evidence_ref not in evidence_before_recovery
                )
                self._record(
                    "recovery_probe_batch_committed",
                    "instrument",
                    "execute_tool",
                    recovery_result.as_dict(),
                )
                self._outstanding = []
                self._last_failure = None
            expected_fields = set(adaptive_validate_schema()["required"])
            if set(payload) != expected_fields:
                raise ValueError("validation fields differ from the shared schema")
            selected_id = _hypothesis_id(
                self.public, str(payload["selected_hypothesis_ref"])
            )
            predictions = _parse_predictions(self.public, payload["predictions"])
            disposition = ConclusionDisposition(str(payload["disposition"]))
            cited = tuple(str(item) for item in payload["cited_evidence_refs"])
            if (
                self.ablation == AdaptiveAblation.CAUSAL_MEMORY
                and not set(cited).issubset(self._latest_batch_evidence_refs)
            ):
                raise ValueError("causal-memory ablation cannot recover evidence from prior batches")
            self._record("validation_requested", "proposal_model", "propose", payload)
            certificate = self.validator.validate_candidate(
                selected_hypothesis_id=selected_id,
                disposition=disposition,
                predicted_interventions=predictions,
                cited_evidence_refs=cited,
            )
            certificate_ref = f"c{len(self.certificates) + 1}"
            validation_removed = self.ablation == AdaptiveAblation.CANDIDATE_VALIDATION
            if not validation_removed:
                self.certificates[certificate_ref] = certificate
            all_evidence_refs = (
                self._latest_batch_evidence_refs
                if self.ablation == AdaptiveAblation.CAUSAL_MEMORY
                else tuple(item.evidence_ref for item in self.instrument.observations)
            )
            trace_observations = tuple(
                item
                for item in self.instrument.observations
                if item.evidence_ref in all_evidence_refs
            )
            trace_labels = _decisive_labels(
                trace_observations,
                self.public.intervention_names,
                all_evidence_refs,
            )
            trace_live = _live_candidates(self.public, trace_labels)
            trace_ambiguity = _structurally_aliased(self.public, trace_live)
            recommendation = None
            if (
                len(trace_labels) >= self.public.minimum_decisive_contexts
                and (len(trace_live) == 1 or trace_ambiguity)
            ):
                if trace_ambiguity:
                    recommended_id = "underdetermined"
                    recommended_disposition = ConclusionDisposition.ABSTAIN
                    recommended_predictions = _predictions_for_alias_group(
                        self.public, trace_live
                    )
                else:
                    recommended_candidate = trace_live[0]
                    recommended_id = recommended_candidate.hypothesis_id
                    recommended_disposition = (
                        ConclusionDisposition.KILL
                        if recommended_candidate.rule_kind == RuleKind.NULL
                        else ConclusionDisposition.PROMOTE
                    )
                    recommended_predictions = _predictions_for_candidate(
                        self.public, recommended_candidate
                    )
                recommendation = {
                    "selected_hypothesis_ref": _hypothesis_ref(
                        self.public, recommended_id
                    ),
                    "disposition": recommended_disposition.value,
                    "predictions": [
                        {
                            "context": [int(bit) for bit in key],
                            "intervention": value,
                        }
                        for key, value in sorted(recommended_predictions.items())
                    ],
                    "cited_evidence_refs": list(all_evidence_refs),
                    "instruction": (
                        "Do not probe again. Submit exactly this public-state proposal "
                        "to validate_candidate, then return its accepted certificate."
                    ),
                }
                self._terminal_public_state = recommendation
            self._record(
                "validation_certificate_issued",
                "validation_authority",
                "validate",
                certificate.as_dict(),
            )
            response = {
                "certificate_ref": certificate_ref,
                "accepted": certificate.accepted and not validation_removed,
                "recovery_applied_before_validation": recovery_result is not None,
                "current_evidence": [
                    item.as_dict() for item in self.instrument.observations
                ],
                "recommended_public_terminal": recommendation,
                "counterexamples": (
                    ["candidate-validation component removed"]
                    if validation_removed
                    else list(certificate.counterexamples)
                ),
                "decisive_context_count": certificate.decisive_context_count,
                "live_hypothesis_refs": [
                    _hypothesis_ref(self.public, item)
                    for item in certificate.live_hypothesis_ids
                ],
                "structural_ambiguity": certificate.structural_ambiguity,
                "expected_predictions": [
                    {"context": [int(bit) for bit in key], "intervention": value}
                    for key, value in sorted(certificate.expected_predictions.items())
                ],
            }
            if self.ablation != AdaptiveAblation.NONE:
                response["component_ablation"] = self.ablation.value
            return 200, response
        except (KeyError, StopIteration, TypeError, ValueError) as error:
            self._record("validation_request_rejected", "validation_authority", "validate", str(error))
            return 400, {"error": str(error)}

    def handle(self, tool_name: str, payload: Any) -> Tuple[int, Mapping[str, Any]]:
        if tool_name == "probe_batch":
            return self.handle_probe(payload)
        if tool_name == "validate_candidate":
            return self.handle_validate(payload)
        return 400, {"error": "unknown research tool"}

    def resolve_certificate(self, reference: str) -> str:
        certificate = self.certificates.get(reference)
        return certificate.certificate_id if certificate else reference

    def certificate_by_id(self, identity: str) -> AdaptiveValidationCertificate | None:
        return next(
            (item for item in self.certificates.values() if item.certificate_id == identity),
            None,
        )


def parse_adaptive_conclusion(
    public: AdaptiveWorldPublicPacket,
    gateway: AdaptiveThreeArmGateway,
    value: Mapping[str, Any],
) -> AdaptiveConclusion:
    if not isinstance(value, Mapping):
        raise ValueError("adaptive conclusion must be a JSON object")
    expected = set(adaptive_conclusion_schema()["required"])
    if set(value) != expected:
        raise ValueError("adaptive conclusion fields differ from the frozen schema")
    raw_failures = value["failure_dispositions"]
    if not isinstance(raw_failures, list):
        raise ValueError("failure dispositions must be an array")
    failures: Dict[str, str] = {}
    for item in raw_failures:
        if not isinstance(item, Mapping) or set(item) != {"failure_ref", "transition"}:
            raise ValueError("failure disposition is malformed")
        reference = str(item["failure_ref"])
        if reference in failures:
            raise ValueError("failure disposition is duplicated")
        failures[reference] = RecoveryTransition(str(item["transition"])).value
    cited = value["cited_evidence_refs"]
    limitations = value["limitations"]
    if not isinstance(cited, list) or not isinstance(limitations, list):
        raise ValueError("conclusion evidence and limitations must be arrays")
    return AdaptiveConclusion(
        episode_id=public.episode_id,
        selected_hypothesis_id=_hypothesis_id(
            public, str(value["selected_hypothesis_ref"])
        ),
        disposition=ConclusionDisposition(str(value["disposition"])),
        predicted_interventions=_parse_predictions(public, value["predictions"]),
        cited_evidence_refs=tuple(str(item) for item in cited),
        failure_dispositions=failures,
        validator_certificate_id=gateway.resolve_certificate(
            str(value["validator_certificate_ref"])
        ),
        limitations=tuple(str(item) for item in limitations),
    )


def authorize_adaptive_scientist_conclusion(
    public: AdaptiveWorldPublicPacket,
    gateway: AdaptiveThreeArmGateway,
    proposal: AdaptiveConclusion,
    *,
    accounting_reconciled: bool,
) -> AdaptiveLifecycleDecision:
    """Bind public certificates/recovery and fail closed; never inspect authority."""

    if gateway.arm_kind != ARM_SCIENTIST:
        raise ValueError("Scientist authority cannot govern a control arm")
    certificate = gateway.certificate_by_id(proposal.validator_certificate_id)
    if certificate is None:
        certificate = next(
            (
                item
                for item in gateway.certificates.values()
                if item.proposal_digest == proposal.proposal_digest and item.accepted
            ),
            None,
        )
    evidence = {item.evidence_ref for item in gateway.instrument.observations}
    expected_failures = {
        item.failure_ref: item.expected_transition.value
        for item in gateway.instrument.recovery_records
    }
    checks = {
        "accounting_reconciled": bool(accounting_reconciled),
        "event_chain_valid": gateway.event_chain_valid,
        "evidence_trace_bound": (
            bool(proposal.cited_evidence_refs)
            and set(proposal.cited_evidence_refs).issubset(evidence)
        ),
        "public_validator_accepted": bool(certificate and certificate.accepted),
        "proposal_certificate_match": bool(
            certificate and certificate.proposal_digest == proposal.proposal_digest
        ),
        "typed_recovery_complete": gateway.instrument.recovery_complete_and_correct,
    }
    authorized = proposal
    terminal_authorized = all(checks.values())
    if terminal_authorized:
        assert certificate is not None
        authorized = replace(
            proposal,
            validator_certificate_id=certificate.certificate_id,
            failure_dispositions=expected_failures,
        )
    else:
        authorized = AdaptiveConclusion(
            episode_id=public.episode_id,
            selected_hypothesis_id="underdetermined",
            disposition=ConclusionDisposition.ABSTAIN,
            predicted_interventions={
                _context_key(context): "underdetermined"
                for context in public.evaluation_contexts
            },
            cited_evidence_refs=tuple(
                item for item in proposal.cited_evidence_refs if item in evidence
            ),
            failure_dispositions=expected_failures,
            validator_certificate_id=(
                certificate.certificate_id if certificate else proposal.validator_certificate_id
            ),
            limitations=(
                "independent promotion authority withheld terminal authorization: "
                + ", ".join(key for key, passed in checks.items() if not passed),
            ),
        )
    gateway._record(
        "terminal_authorized" if terminal_authorized else "terminal_withheld",
        "promotion_authority",
        "promote_or_veto",
        {"checks": checks, "conclusion_id": authorized.conclusion_id},
    )
    return AdaptiveLifecycleDecision(
        proposed_conclusion=proposal,
        authorized_conclusion=authorized,
        public_checks=checks,
        proposal_modified=proposal.conclusion_id != authorized.conclusion_id,
        terminal_authorized=terminal_authorized,
    )


def adaptive_task_prompt(public: AdaptiveWorldPublicPacket, arm_kind: str) -> str:
    if arm_kind not in ARM_KINDS:
        raise ValueError("unknown adaptive evaluation arm")
    packet = json.dumps(
        adaptive_model_public_packet(public), sort_keys=True, separators=(",", ":")
    )
    common = (
        "Resolve this finite causal research task in one persistent turn. Use only "
        "research_instrument.probe_batch and research_instrument.validate_candidate. "
        "The probe tool may stop a batch at a typed fault; unattempted entries do not "
        "produce evidence. Every attempted measurement counts, including failures. "
        "The validator is public and answer-blind. Its certificate_ref must match the "
        "same hypothesis, disposition, predictions, and evidence in your final JSON. "
        "Every evaluation context needs one prediction. Use 'equivalent' only for a "
        "supported null and 'underdetermined' only where certified live policies "
        "disagree. Cite e### evidence refs and record any f### recovery. Do not inspect "
        "files, seek hidden authority, or use other tools. Return only the supplied "
        "JSON schema.\n\nPUBLIC TASK (BYTE-IDENTICAL ACROSS ARMS):\n" + packet
    )
    if arm_kind == ARM_FREE:
        return common
    architecture = ""
    if arm_kind == ARM_SCIENTIST:
        architecture = (
            "\n\nARCHITECTURE: An event-sourced host owns scientific state. An "
            "answer-blind design authority may replace an inadmissible first probe "
            "plan; a recovery authority may replace an incorrect response to an "
            "observed typed fault. A separate public-evidence authority decides "
            "terminal authorization and can bind only certificate and recovery fields "
            "or withhold the conclusion; it cannot inspect hidden truth."
        )
    return common + "\n\n" + METHOD_POLICY_APPENDIX + architecture


def adaptive_three_arm_contract() -> Mapping[str, Any]:
    return {
        "version": ADAPTIVE_THREE_ARM_VERSION,
        "world_version": ADAPTIVE_WORLD_VERSION,
        "arms": list(ARM_KINDS),
        "shared_tools": {
            "probe_batch": adaptive_probe_schema(),
            "validate_candidate": adaptive_validate_schema(),
        },
        "conclusion_schema": adaptive_conclusion_schema(),
        "method_policy_sha256": content_digest(METHOD_POLICY_APPENDIX),
        "method_policy_byte_identical_for": [ARM_PROMPT_EQUATED, ARM_SCIENTIST],
        "scientist_answer_blind_design_admissibility": True,
        "scientist_event_sourced_state": True,
        "scientist_typed_recovery_enforced": True,
        "scientist_independent_promotion": True,
        "scientist_hidden_authority_input": False,
        "validator_hidden_authority_input": False,
        "mechanistic_ablation_profiles": [item.value for item in AdaptiveAblation if item != AdaptiveAblation.NONE],
    }
