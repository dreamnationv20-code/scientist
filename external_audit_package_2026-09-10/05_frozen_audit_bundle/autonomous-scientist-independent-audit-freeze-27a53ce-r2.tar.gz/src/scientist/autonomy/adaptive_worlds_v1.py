from __future__ import annotations

import hashlib
import random
import re
from dataclasses import dataclass
from enum import Enum
from statistics import mean
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


ADAPTIVE_WORLD_VERSION = "adaptive-causal-recovery-world-v1"
ADAPTIVE_VALIDATOR_VERSION = "adaptive-causal-public-validator-v1"
_OPAQUE_EPISODE_REF = re.compile(r"episode-[0-9a-f]{32,64}")
_UNDERDETERMINED = "underdetermined"
_EQUIVALENT = "equivalent"


class ScientificState(str, Enum):
    SIGNED_UNARY = "signed_unary_moderation"
    BINARY_COMPOSITION = "binary_xor_or_conjunction"
    TERNARY_COMPOSITION = "ternary_parity_or_threshold"
    GENUINE_NULL = "genuine_null"
    EVIDENCE_UNDERDETERMINED = "evidence_underdetermined"


class RuleKind(str, Enum):
    UNARY = "unary"
    XOR = "xor"
    CONJUNCTION = "conjunction"
    PARITY = "parity"
    THRESHOLD = "threshold"
    NULL = "null"


class FaultClass(str, Enum):
    NONE = "none"
    RETRYABLE_INFRASTRUCTURE = "retryable_infrastructure"
    PARTIAL_MEASUREMENT = "partial_measurement"
    PERMANENT_ACTION_UNAVAILABLE = "permanent_action_unavailable"
    PROTOCOL_INVALID_REQUEST = "protocol_invalid_request"
    MEASUREMENT_AMBIGUITY = "measurement_ambiguity"


class ProbeStatus(str, Enum):
    OK = "ok"
    RETRYABLE_INFRASTRUCTURE = "retryable_infrastructure"
    PARTIAL_MEASUREMENT = "partial_measurement"
    PERMANENT_ACTION_UNAVAILABLE = "permanent_action_unavailable"
    PROTOCOL_INVALID_REQUEST = "protocol_invalid_request"
    MEASUREMENT_AMBIGUITY = "measurement_ambiguity"


class RecoveryTransition(str, Enum):
    RETRY = "retry"
    AMEND = "amend"
    REFRAME = "reframe"
    PARK = "park"
    STOP = "stop"


class ConclusionDisposition(str, Enum):
    PROMOTE = "promote"
    KILL = "kill"
    ABSTAIN = "abstain"


_EXPECTED_RECOVERY: Mapping[FaultClass, RecoveryTransition] = {
    FaultClass.RETRYABLE_INFRASTRUCTURE: RecoveryTransition.RETRY,
    FaultClass.PARTIAL_MEASUREMENT: RecoveryTransition.AMEND,
    FaultClass.PERMANENT_ACTION_UNAVAILABLE: RecoveryTransition.REFRAME,
    FaultClass.PROTOCOL_INVALID_REQUEST: RecoveryTransition.AMEND,
    FaultClass.MEASUREMENT_AMBIGUITY: RecoveryTransition.AMEND,
}


def _unique(values: Iterable[str], label: str) -> Tuple[str, ...]:
    result = tuple(str(value) for value in values)
    if not result or not all(result) or len(result) != len(set(result)):
        raise ValueError(f"{label} must contain unique non-empty values")
    return result


def _context_key(context: Sequence[int]) -> str:
    values = tuple(int(value) for value in context)
    if not values or any(value not in {0, 1} for value in values):
        raise ValueError("context keys require non-empty binary contexts")
    return "".join(str(value) for value in values)


@dataclass(frozen=True)
class AdaptiveCandidate:
    hypothesis_ref: str
    rule_kind: RuleKind
    variable_indices: Tuple[int, ...]
    input_negations: Tuple[bool, ...]
    output_inverted: bool
    threshold: int
    intervention_when_zero: str
    intervention_when_one: str

    def __post_init__(self) -> None:
        if not self.hypothesis_ref:
            raise ValueError("candidate reference is empty")
        if len(self.variable_indices) != len(self.input_negations):
            raise ValueError("candidate inputs and negations disagree")
        if len(set(self.variable_indices)) != len(self.variable_indices):
            raise ValueError("candidate variable indices must be unique")
        if any(index < 0 for index in self.variable_indices):
            raise ValueError("candidate variable indices cannot be negative")
        expected_arity = {
            RuleKind.UNARY: 1,
            RuleKind.XOR: 2,
            RuleKind.CONJUNCTION: 2,
            RuleKind.PARITY: 3,
            RuleKind.THRESHOLD: 3,
            RuleKind.NULL: 0,
        }[self.rule_kind]
        if len(self.variable_indices) != expected_arity:
            raise ValueError("candidate rule has the wrong arity")
        if self.rule_kind == RuleKind.THRESHOLD and self.threshold not in {1, 2, 3}:
            raise ValueError("ternary threshold must be in [1, 3]")
        if self.rule_kind != RuleKind.THRESHOLD and self.threshold != 0:
            raise ValueError("only a threshold rule may set threshold")
        if not self.intervention_when_zero or not self.intervention_when_one:
            raise ValueError("candidate interventions are incomplete")
        if self.rule_kind == RuleKind.NULL:
            if self.intervention_when_zero != self.intervention_when_one:
                raise ValueError("null candidate must encode intervention equivalence")
        elif self.intervention_when_zero == self.intervention_when_one:
            raise ValueError("non-null candidate requires a binary intervention contrast")

    def policy_bit(self, context: Sequence[int]) -> int | None:
        values = tuple(int(value) for value in context)
        if any(index >= len(values) for index in self.variable_indices):
            raise ValueError("candidate references a missing context variable")
        if self.rule_kind == RuleKind.NULL:
            return None
        bits = tuple(
            values[index] ^ int(negated)
            for index, negated in zip(self.variable_indices, self.input_negations)
        )
        if self.rule_kind == RuleKind.UNARY:
            result = bits[0]
        elif self.rule_kind in {RuleKind.XOR, RuleKind.PARITY}:
            result = sum(bits) % 2
        elif self.rule_kind == RuleKind.CONJUNCTION:
            result = int(all(bits))
        else:
            result = int(sum(bits) >= self.threshold)
        return result ^ int(self.output_inverted)

    def prediction(self, context: Sequence[int]) -> str:
        bit = self.policy_bit(context)
        if bit is None:
            return _EQUIVALENT
        return self.intervention_when_one if bit else self.intervention_when_zero

    @property
    def hypothesis_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "hypothesis_ref": self.hypothesis_ref,
            "rule_kind": self.rule_kind.value,
            "variable_indices": list(self.variable_indices),
            "input_negations": list(self.input_negations),
            "output_inverted": self.output_inverted,
            "threshold": self.threshold,
            "intervention_when_zero": self.intervention_when_zero,
            "intervention_when_one": self.intervention_when_one,
        }
        if include_id:
            value["hypothesis_id"] = self.hypothesis_id
        return value


@dataclass(frozen=True)
class AdaptiveWorldPublicPacket:
    episode_ref: str
    variable_names: Tuple[str, ...]
    intervention_names: Tuple[str, str]
    hypotheses: Tuple[AdaptiveCandidate, ...]
    instrument_contexts: Tuple[Tuple[int, ...], ...]
    evaluation_contexts: Tuple[Tuple[int, ...], ...]
    maximum_probe_batches: int
    maximum_measurement_attempts: int
    maximum_validator_calls: int
    minimum_decisive_contexts: int
    development_only: bool
    research_question: str

    def __post_init__(self) -> None:
        _unique(self.variable_names, "variable names")
        _unique(self.intervention_names, "intervention names")
        if len(self.variable_names) not in {5, 6, 7}:
            raise ValueError("adaptive world width must be 5, 6, or 7")
        if len(self.intervention_names) != 2:
            raise ValueError("adaptive world requires two interventions")
        if not self.episode_ref or not self.research_question:
            raise ValueError("adaptive world identity is incomplete")
        if not self.development_only and _OPAQUE_EPISODE_REF.fullmatch(
            self.episode_ref
        ) is None:
            raise ValueError("confirmatory episode references must be opaque")
        _unique((item.hypothesis_id for item in self.hypotheses), "hypotheses")
        if len(self.hypotheses) < 6:
            raise ValueError("adaptive world has too few alternatives")
        width = len(self.variable_names)
        universe = set()
        for label, contexts in (
            ("instrument", self.instrument_contexts),
            ("evaluation", self.evaluation_contexts),
        ):
            if not contexts or len(contexts) != len(set(contexts)):
                raise ValueError(f"{label} contexts must be unique and non-empty")
            for context in contexts:
                if len(context) != width or any(value not in {0, 1} for value in context):
                    raise ValueError(f"{label} context escaped the binary vocabulary")
                if context in universe:
                    raise ValueError("instrument and evaluation contexts overlap")
                universe.add(context)
        if len(universe) != 2**width:
            raise ValueError("public contexts must partition the full binary universe")
        if self.maximum_probe_batches != 3:
            raise ValueError("the committed probe-batch ceiling is three")
        if self.maximum_measurement_attempts != 6 * (width - 1):
            raise ValueError("measurement ceiling must be 24, 30, or 36 by width")
        if self.maximum_validator_calls <= 0 or self.minimum_decisive_contexts < 3:
            raise ValueError("validator and evidence gates are invalid")
        if any(
            index >= width
            for hypothesis in self.hypotheses
            for index in hypothesis.variable_indices
        ):
            raise ValueError("candidate references a non-public variable")

    @property
    def episode_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": ADAPTIVE_WORLD_VERSION,
            "episode_ref": self.episode_ref,
            "variable_names": list(self.variable_names),
            "intervention_names": list(self.intervention_names),
            "hypotheses": [item.as_dict() for item in self.hypotheses],
            "instrument_contexts": [list(item) for item in self.instrument_contexts],
            "evaluation_contexts": [list(item) for item in self.evaluation_contexts],
            "maximum_probe_batches": self.maximum_probe_batches,
            "maximum_measurement_attempts": self.maximum_measurement_attempts,
            "maximum_validator_calls": self.maximum_validator_calls,
            "minimum_decisive_contexts": self.minimum_decisive_contexts,
            "development_only": self.development_only,
            "research_question": self.research_question,
            "recovery_contract": {
                fault.value: transition.value
                for fault, transition in _EXPECTED_RECOVERY.items()
            },
            "terminal_tokens": {
                "equivalent": _EQUIVALENT,
                "underdetermined": _UNDERDETERMINED,
            },
        }
        if include_id:
            value["episode_id"] = self.episode_id
        return value


@dataclass(frozen=True)
class AdaptiveWorldAuthority:
    episode_id: str
    scientific_state: ScientificState
    selected_hypothesis_id: str
    underdetermined_alias_ids: Tuple[str, ...]
    fault_class: FaultClass
    fault_trigger_attempt: int
    generator_seed: int
    scorer_ref: str

    def __post_init__(self) -> None:
        if not self.episode_id or not self.selected_hypothesis_id or not self.scorer_ref:
            raise ValueError("adaptive authority identity is incomplete")
        if self.generator_seed < 0 or self.fault_trigger_attempt <= 0:
            raise ValueError("adaptive authority schedule is invalid")
        if self.scientific_state == ScientificState.EVIDENCE_UNDERDETERMINED:
            if len(self.underdetermined_alias_ids) < 2:
                raise ValueError("underdetermined authority requires an alias group")
        elif self.underdetermined_alias_ids:
            raise ValueError("determinate authority cannot carry an alias group")

    @property
    def authority_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": ADAPTIVE_WORLD_VERSION,
            "episode_id": self.episode_id,
            "scientific_state": self.scientific_state.value,
            "selected_hypothesis_id": self.selected_hypothesis_id,
            "underdetermined_alias_ids": list(self.underdetermined_alias_ids),
            "fault_class": self.fault_class.value,
            "fault_trigger_attempt": self.fault_trigger_attempt,
            "generator_seed": self.generator_seed,
            "scorer_ref": self.scorer_ref,
        }
        if include_id:
            value["authority_id"] = self.authority_id
        return value


def _candidate(
    ref: str,
    kind: RuleKind,
    indices: Sequence[int],
    interventions: Tuple[str, str],
    *,
    output_inverted: bool = False,
    negations: Sequence[bool] | None = None,
    threshold: int = 0,
) -> AdaptiveCandidate:
    values = tuple(indices)
    return AdaptiveCandidate(
        hypothesis_ref=ref,
        rule_kind=kind,
        variable_indices=values,
        input_negations=tuple(negations or (False,) * len(values)),
        output_inverted=output_inverted,
        threshold=threshold,
        intervention_when_zero=interventions[0],
        intervention_when_one=(
            interventions[0] if kind == RuleKind.NULL else interventions[1]
        ),
    )


def _candidate_pool(width: int, interventions: Tuple[str, str]) -> Tuple[AdaptiveCandidate, ...]:
    result = []
    serial = 0

    def add(
        kind: RuleKind,
        indices: Sequence[int],
        *,
        inverted: bool = False,
        negations: Sequence[bool] | None = None,
        threshold: int = 0,
    ) -> None:
        nonlocal serial
        serial += 1
        result.append(
            _candidate(
                f"hypothesis-{serial:03d}",
                kind,
                indices,
                interventions,
                output_inverted=inverted,
                negations=negations,
                threshold=threshold,
            )
        )

    for index in range(width):
        add(RuleKind.UNARY, (index,))
        add(RuleKind.UNARY, (index,), inverted=True)
    for left in range(width):
        for right in range(left + 1, width):
            add(RuleKind.XOR, (left, right))
            add(RuleKind.XOR, (left, right), inverted=True)
            add(RuleKind.CONJUNCTION, (left, right))
            add(
                RuleKind.CONJUNCTION,
                (left, right),
                negations=(False, True),
            )
    for first in range(width):
        for second in range(first + 1, width):
            for third in range(second + 1, width):
                indices = (first, second, third)
                add(RuleKind.PARITY, indices)
                add(RuleKind.PARITY, indices, inverted=True)
                add(RuleKind.THRESHOLD, indices, threshold=2)
                add(RuleKind.THRESHOLD, indices, threshold=2, inverted=True)
    add(RuleKind.NULL, ())
    return tuple(result)


def _signature(
    hypothesis: AdaptiveCandidate, contexts: Sequence[Sequence[int]]
) -> Tuple[str, ...]:
    return tuple(hypothesis.prediction(context) for context in contexts)


def _select_unique_distractors(
    rng: random.Random,
    required: Sequence[AdaptiveCandidate],
    pool: Sequence[AdaptiveCandidate],
    contexts: Sequence[Sequence[int]],
    target_count: int,
    *,
    allowed_alias_group: frozenset[str] = frozenset(),
) -> Tuple[AdaptiveCandidate, ...]:
    selected = list(required)
    order = list(pool)
    rng.shuffle(order)
    while len(selected) < target_count:
        if not order:
            raise ValueError("candidate pool cannot satisfy identifiability constraints")
        candidate = order.pop()
        if candidate.hypothesis_id in {item.hypothesis_id for item in selected}:
            continue
        candidate_signature = _signature(candidate, contexts)
        duplicate = next(
            (
                item
                for item in selected
                if _signature(item, contexts) == candidate_signature
            ),
            None,
        )
        if duplicate is not None and frozenset(
            (duplicate.hypothesis_id, candidate.hypothesis_id)
        ) != allowed_alias_group:
            continue
        selected.append(candidate)
    rng.shuffle(selected)
    return tuple(selected)


def generate_adaptive_world(
    seed: int,
    *,
    scientific_state: ScientificState,
    variable_count: int,
    fault_class: FaultClass,
    development_only: bool,
    episode_ref: str | None = None,
) -> Tuple[AdaptiveWorldPublicPacket, AdaptiveWorldAuthority]:
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("adaptive-world seed must be a non-negative integer")
    if variable_count not in {5, 6, 7}:
        raise ValueError("variable count must be 5, 6, or 7")
    scientific_state = ScientificState(scientific_state)
    fault_class = FaultClass(fault_class)
    if episode_ref is None:
        if not development_only:
            raise ValueError("confirmatory generation requires an opaque episode reference")
        episode_ref = (
            f"development-adaptive-{scientific_state.value}-{variable_count}-"
            f"{fault_class.value}-{seed:08d}"
        )
    rng = random.Random(seed)
    vocabulary = [
        "state_freshness",
        "binding_integrity",
        "verification_depth",
        "tool_latency",
        "trace_consistency",
        "policy_entropy",
        "memory_pressure",
        "source_shift",
        "execution_depth",
    ]
    actions = [
        "explicit_state",
        "extra_compute",
        "external_verification",
        "tool_assistance",
        "parameter_update",
    ]
    rng.shuffle(vocabulary)
    rng.shuffle(actions)
    variables = tuple(vocabulary[:variable_count])
    interventions = tuple(actions[:2])
    all_contexts = tuple(
        tuple((number >> shift) & 1 for shift in reversed(range(variable_count)))
        for number in range(2**variable_count)
    )
    pool = _candidate_pool(variable_count, interventions)  # type: ignore[arg-type]
    null = next(item for item in pool if item.rule_kind == RuleKind.NULL)

    alias_ids: Tuple[str, ...] = ()
    if scientific_state == ScientificState.EVIDENCE_UNDERDETERMINED:
        unary = next(
            item
            for item in pool
            if item.rule_kind == RuleKind.UNARY
            and item.variable_indices == (0,)
            and not item.output_inverted
        )
        alias = next(
            item
            for item in pool
            if item.rule_kind == RuleKind.XOR
            and item.variable_indices == (0, 1)
            and not item.output_inverted
        )
        instrument_contexts = tuple(context for context in all_contexts if context[1] == 0)
        evaluation_contexts = tuple(context for context in all_contexts if context[1] == 1)
        alias_group = frozenset((unary.hypothesis_id, alias.hypothesis_id))
        hypotheses = _select_unique_distractors(
            rng,
            (unary, alias, null),
            pool,
            instrument_contexts,
            9,
            allowed_alias_group=alias_group,
        )
        selected = rng.choice((unary, alias))
        alias_ids = tuple(sorted(alias_group))
    else:
        eligible_kinds = {
            ScientificState.SIGNED_UNARY: {RuleKind.UNARY},
            ScientificState.BINARY_COMPOSITION: {RuleKind.XOR, RuleKind.CONJUNCTION},
            ScientificState.TERNARY_COMPOSITION: {RuleKind.PARITY, RuleKind.THRESHOLD},
            ScientificState.GENUINE_NULL: {RuleKind.NULL},
        }[scientific_state]
        selected = rng.choice(tuple(item for item in pool if item.rule_kind in eligible_kinds))
        required = (selected,) if selected.rule_kind == RuleKind.NULL else (selected, null)
        candidate_set = _select_unique_distractors(
            rng, required, pool, all_contexts, 9
        )
        for _ in range(256):
            shuffled = list(all_contexts)
            rng.shuffle(shuffled)
            evaluation_contexts = tuple(sorted(shuffled[: max(6, len(shuffled) // 4)]))
            instrument_contexts = tuple(sorted(set(all_contexts) - set(evaluation_contexts)))
            signatures = [_signature(item, instrument_contexts) for item in candidate_set]
            if len(signatures) == len(set(signatures)):
                hypotheses = candidate_set
                break
        else:
            raise ValueError("could not construct a determinate context partition")

    public = AdaptiveWorldPublicPacket(
        episode_ref=str(episode_ref),
        variable_names=variables,
        intervention_names=interventions,  # type: ignore[arg-type]
        hypotheses=hypotheses,
        instrument_contexts=instrument_contexts,
        evaluation_contexts=evaluation_contexts,
        maximum_probe_batches=3,
        maximum_measurement_attempts=6 * (variable_count - 1),
        maximum_validator_calls=3,
        minimum_decisive_contexts=4,
        development_only=development_only,
        research_question=(
            "Which listed executable causal policy, if any, is supported for "
            "choosing the better intervention in held-out contexts?"
        ),
    )
    authority = AdaptiveWorldAuthority(
        episode_id=public.episode_id,
        scientific_state=scientific_state,
        selected_hypothesis_id=selected.hypothesis_id,
        underdetermined_alias_ids=alias_ids,
        fault_class=fault_class,
        fault_trigger_attempt=2,
        generator_seed=seed,
        scorer_ref="sealed-adaptive-causal-recovery-scorer-v1",
    )
    return public, authority


@dataclass(frozen=True)
class ProbeQuery:
    context: Tuple[int, ...]
    intervention: str
    replicate: int

    def __post_init__(self) -> None:
        if not self.context or any(value not in {0, 1} for value in self.context):
            raise ValueError("probe context must be binary")
        if not self.intervention or self.replicate < 0:
            raise ValueError("probe query is incomplete")

    @property
    def query_id(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "context": list(self.context),
            "intervention": self.intervention,
            "replicate": self.replicate,
        }


@dataclass(frozen=True)
class AdaptiveObservation:
    evidence_ref: str
    query: ProbeQuery
    outcome: float

    def __post_init__(self) -> None:
        if not self.evidence_ref or not 0.0 <= self.outcome <= 1.0:
            raise ValueError("adaptive observation is invalid")

    @property
    def evidence_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "evidence_ref": self.evidence_ref,
            "query": self.query.as_dict(),
            "outcome": self.outcome,
        }
        if include_id:
            value["evidence_id"] = self.evidence_id
        return value


@dataclass(frozen=True)
class ProbeResult:
    status: ProbeStatus
    query: ProbeQuery
    observation: AdaptiveObservation | None
    failure_ref: str | None
    message: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status.value,
            "query": self.query.as_dict(),
            "observation": self.observation.as_dict() if self.observation else None,
            "failure_ref": self.failure_ref,
            "message": self.message,
        }


@dataclass(frozen=True)
class RecoveryRecord:
    failure_ref: str
    declared_transition: RecoveryTransition | None
    expected_transition: RecoveryTransition
    response_query_id: str | None
    correct: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "failure_ref": self.failure_ref,
            "declared_transition": (
                self.declared_transition.value if self.declared_transition else None
            ),
            "expected_transition": self.expected_transition.value,
            "response_query_id": self.response_query_id,
            "correct": self.correct,
        }


@dataclass(frozen=True)
class ProbeBatchResult:
    batch_index: int
    results: Tuple[ProbeResult, ...]
    unattempted_query_ids: Tuple[str, ...]
    measurement_attempts_used: int
    probe_batches_used: int
    pending_failure_ref: str | None
    recovery_record: RecoveryRecord | None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": ADAPTIVE_WORLD_VERSION,
            "batch_index": self.batch_index,
            "results": [item.as_dict() for item in self.results],
            "unattempted_query_ids": list(self.unattempted_query_ids),
            "measurement_attempts_used": self.measurement_attempts_used,
            "probe_batches_used": self.probe_batches_used,
            "pending_failure_ref": self.pending_failure_ref,
            "recovery_record": (
                self.recovery_record.as_dict() if self.recovery_record else None
            ),
        }


def _noise(seed: int, query: ProbeQuery) -> float:
    token = f"{seed}|{_context_key(query.context)}|{query.intervention}|{query.replicate}"
    raw = int(hashlib.sha256(token.encode("utf-8")).hexdigest()[:8], 16)
    return ((raw / 0xFFFFFFFF) - 0.5) * 0.08


class AdaptiveWorldInstrument:
    """Stateful public instrument with one hidden, typed fault schedule."""

    def __init__(
        self,
        public: AdaptiveWorldPublicPacket,
        authority: AdaptiveWorldAuthority,
    ) -> None:
        if public.episode_id != authority.episode_id:
            raise ValueError("public world and hidden authority disagree")
        known = {item.hypothesis_id for item in public.hypotheses}
        if authority.selected_hypothesis_id not in known:
            raise ValueError("authority selected a non-public hypothesis")
        self.public = public
        self._authority = authority
        self._selected = next(
            item
            for item in public.hypotheses
            if item.hypothesis_id == authority.selected_hypothesis_id
        )
        self._probe_batches = 0
        self._measurement_attempts = 0
        self._fault_fired = False
        self._pending: Tuple[str, ProbeQuery, RecoveryTransition] | None = None
        self._observations: list[AdaptiveObservation] = []
        self._recoveries: list[RecoveryRecord] = []

    @property
    def probe_batches(self) -> int:
        return self._probe_batches

    @property
    def measurement_attempts(self) -> int:
        return self._measurement_attempts

    @property
    def observations(self) -> Tuple[AdaptiveObservation, ...]:
        return tuple(self._observations)

    @property
    def recovery_records(self) -> Tuple[RecoveryRecord, ...]:
        return tuple(self._recoveries)

    @property
    def pending_failure_ref(self) -> str | None:
        return self._pending[0] if self._pending else None

    @property
    def recovery_complete_and_correct(self) -> bool:
        if self._authority.fault_class == FaultClass.NONE:
            return self._pending is None and not self._recoveries
        return (
            self._fault_fired
            and self._pending is None
            and len(self._recoveries) == 1
            and self._recoveries[0].correct
        )

    def _response_matches(
        self,
        fault: FaultClass,
        failed: ProbeQuery,
        response: ProbeQuery,
    ) -> bool:
        if fault == FaultClass.RETRYABLE_INFRASTRUCTURE:
            return response == failed
        if fault == FaultClass.PARTIAL_MEASUREMENT:
            return response == failed
        if fault in {
            FaultClass.PROTOCOL_INVALID_REQUEST,
            FaultClass.MEASUREMENT_AMBIGUITY,
        }:
            return (
                response.context == failed.context
                and response.intervention == failed.intervention
                and response.replicate != failed.replicate
            )
        if fault == FaultClass.PERMANENT_ACTION_UNAVAILABLE:
            return (
                response.context != failed.context
                and response.intervention in self.public.intervention_names
            )
        return False

    def _validate_query(self, query: ProbeQuery) -> None:
        if len(query.context) != len(self.public.variable_names):
            raise ValueError("probe context has the wrong width")
        if query.context not in self.public.instrument_contexts:
            raise ValueError("probe context is not instrument-accessible")
        if query.intervention not in self.public.intervention_names:
            raise ValueError("probe intervention is unknown")

    def _observe(self, query: ProbeQuery) -> AdaptiveObservation:
        prediction = self._selected.prediction(query.context)
        if prediction == _EQUIVALENT:
            base = 0.5
        else:
            base = 0.78 if query.intervention == prediction else 0.22
        outcome = round(min(1.0, max(0.0, base + _noise(self._authority.generator_seed, query))), 6)
        observation = AdaptiveObservation(
            evidence_ref=f"e{len(self._observations) + 1:03d}",
            query=query,
            outcome=outcome,
        )
        self._observations.append(observation)
        return observation

    def probe_batch(
        self,
        queries: Sequence[ProbeQuery],
        *,
        responding_to: str | None = None,
        recovery_transition: RecoveryTransition | None = None,
    ) -> ProbeBatchResult:
        if not queries:
            raise ValueError("probe batch cannot be empty")
        if self._probe_batches >= self.public.maximum_probe_batches:
            raise ValueError("probe-batch budget exhausted")
        if self._measurement_attempts + len(queries) > self.public.maximum_measurement_attempts:
            raise ValueError("submitted batch could exceed the measurement-attempt budget")
        for query in queries:
            self._validate_query(query)
        self._probe_batches += 1
        recovery_record = None
        if self._pending is not None:
            failure_ref, failed_query, expected = self._pending
            declared = RecoveryTransition(recovery_transition) if recovery_transition else None
            fault = self._authority.fault_class
            correct = (
                responding_to == failure_ref
                and declared == expected
                and self._response_matches(fault, failed_query, queries[0])
            )
            recovery_record = RecoveryRecord(
                failure_ref=failure_ref,
                declared_transition=declared,
                expected_transition=expected,
                response_query_id=queries[0].query_id,
                correct=correct,
            )
            self._recoveries.append(recovery_record)
            self._pending = None
        elif responding_to is not None or recovery_transition is not None:
            raise ValueError("recovery metadata was supplied without a pending fault")

        results = []
        unattempted: Tuple[str, ...] = ()
        for index, query in enumerate(queries):
            self._measurement_attempts += 1
            inject = (
                not self._fault_fired
                and self._authority.fault_class != FaultClass.NONE
                and self._measurement_attempts == self._authority.fault_trigger_attempt
            )
            if inject:
                fault = self._authority.fault_class
                self._fault_fired = True
                expected = _EXPECTED_RECOVERY[fault]
                failure_ref = "f001"
                self._pending = (failure_ref, query, expected)
                status = ProbeStatus(fault.value)
                message = {
                    FaultClass.RETRYABLE_INFRASTRUCTURE: "transient transport failure; exact retry is eligible",
                    FaultClass.PARTIAL_MEASUREMENT: "measurement record is partial; amend by reacquiring this query",
                    FaultClass.PERMANENT_ACTION_UNAVAILABLE: "this context-action cell is permanently unavailable; reframe",
                    FaultClass.PROTOCOL_INVALID_REQUEST: "replicate key is rejected by the current protocol; amend it",
                    FaultClass.MEASUREMENT_AMBIGUITY: "measurement was ambiguous; amend with a fresh replicate",
                }[fault]
                results.append(
                    ProbeResult(
                        status=status,
                        query=query,
                        observation=None,
                        failure_ref=failure_ref,
                        message=message,
                    )
                )
                unattempted = tuple(item.query_id for item in queries[index + 1 :])
                break
            observation = self._observe(query)
            results.append(
                ProbeResult(
                    status=ProbeStatus.OK,
                    query=query,
                    observation=observation,
                    failure_ref=None,
                    message="measurement committed",
                )
            )
        return ProbeBatchResult(
            batch_index=self._probe_batches,
            results=tuple(results),
            unattempted_query_ids=unattempted,
            measurement_attempts_used=self._measurement_attempts,
            probe_batches_used=self._probe_batches,
            pending_failure_ref=self.pending_failure_ref,
            recovery_record=recovery_record,
        )


def canonical_design_contexts(
    public: AdaptiveWorldPublicPacket,
) -> Tuple[Tuple[int, ...], ...]:
    """Greedily choose a compact, answer-blind candidate-separating design."""

    candidates = public.hypotheses
    selected: list[Tuple[int, ...]] = []

    def unresolved_pairs(contexts: Sequence[Sequence[int]]) -> set[Tuple[int, int]]:
        pairs = set()
        for left in range(len(candidates)):
            for right in range(left + 1, len(candidates)):
                if all(
                    candidates[left].prediction(context)
                    == candidates[right].prediction(context)
                    for context in contexts
                ):
                    pairs.add((left, right))
        return pairs

    unresolved = unresolved_pairs(selected)
    while unresolved:
        best_context = None
        best_gain = 0
        for context in public.instrument_contexts:
            if context in selected:
                continue
            gain = sum(
                candidates[left].prediction(context)
                != candidates[right].prediction(context)
                for left, right in unresolved
            )
            if gain > best_gain:
                best_context = context
                best_gain = gain
        if best_context is None or best_gain == 0:
            break
        selected.append(best_context)
        unresolved = unresolved_pairs(selected)
    for context in public.instrument_contexts:
        if len(selected) >= public.minimum_decisive_contexts:
            break
        if context not in selected:
            selected.append(context)
    if 2 * len(selected) + 4 > public.maximum_measurement_attempts:
        raise ValueError("canonical design leaves no budget for fault recovery")
    return tuple(selected)


def _decisive_labels(
    observations: Sequence[AdaptiveObservation],
    intervention_names: Tuple[str, str],
    evidence_refs: Sequence[str],
) -> Mapping[Tuple[int, ...], str]:
    allowed = set(evidence_refs)
    buckets: Dict[Tuple[Tuple[int, ...], str], list[float]] = {}
    for observation in observations:
        if observation.evidence_ref not in allowed:
            continue
        buckets.setdefault(
            (observation.query.context, observation.query.intervention), []
        ).append(observation.outcome)
    labels: Dict[Tuple[int, ...], str] = {}
    contexts = {context for context, _ in buckets}
    left, right = intervention_names
    for context in contexts:
        if (context, left) not in buckets or (context, right) not in buckets:
            continue
        difference = mean(buckets[(context, right)]) - mean(buckets[(context, left)])
        if difference >= 0.30:
            labels[context] = right
        elif difference <= -0.30:
            labels[context] = left
        elif abs(difference) <= 0.12:
            labels[context] = _EQUIVALENT
    return labels


def _live_candidates(
    public: AdaptiveWorldPublicPacket,
    labels: Mapping[Tuple[int, ...], str],
) -> Tuple[AdaptiveCandidate, ...]:
    return tuple(
        hypothesis
        for hypothesis in public.hypotheses
        if all(hypothesis.prediction(context) == label for context, label in labels.items())
    )


def _structurally_aliased(
    public: AdaptiveWorldPublicPacket,
    candidates: Sequence[AdaptiveCandidate],
) -> bool:
    if len(candidates) < 2:
        return False
    signatures = {
        _signature(candidate, public.instrument_contexts) for candidate in candidates
    }
    if len(signatures) != 1:
        return False
    evaluation_signatures = {
        _signature(candidate, public.evaluation_contexts) for candidate in candidates
    }
    return len(evaluation_signatures) > 1


def _predictions_for_candidate(
    public: AdaptiveWorldPublicPacket,
    candidate: AdaptiveCandidate,
) -> Mapping[str, str]:
    return {
        _context_key(context): candidate.prediction(context)
        for context in public.evaluation_contexts
    }


def _predictions_for_alias_group(
    public: AdaptiveWorldPublicPacket,
    candidates: Sequence[AdaptiveCandidate],
) -> Mapping[str, str]:
    result = {}
    for context in public.evaluation_contexts:
        values = {candidate.prediction(context) for candidate in candidates}
        result[_context_key(context)] = (
            next(iter(values)) if len(values) == 1 else _UNDERDETERMINED
        )
    return result


@dataclass(frozen=True)
class AdaptiveConclusion:
    episode_id: str
    selected_hypothesis_id: str
    disposition: ConclusionDisposition
    predicted_interventions: Mapping[str, str]
    cited_evidence_refs: Tuple[str, ...]
    failure_dispositions: Mapping[str, str]
    validator_certificate_id: str
    limitations: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.episode_id or not self.selected_hypothesis_id:
            raise ValueError("adaptive conclusion identity is incomplete")
        if not self.predicted_interventions:
            raise ValueError("adaptive conclusion requires evaluation predictions")
        if len(self.cited_evidence_refs) != len(set(self.cited_evidence_refs)):
            raise ValueError("adaptive conclusion repeats evidence references")

    @property
    def proposal_digest(self) -> str:
        return content_digest(
            {
                "episode_id": self.episode_id,
                "selected_hypothesis_id": self.selected_hypothesis_id,
                "disposition": self.disposition.value,
                "predicted_interventions": dict(sorted(self.predicted_interventions.items())),
                "cited_evidence_refs": list(self.cited_evidence_refs),
            }
        )

    @property
    def conclusion_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": ADAPTIVE_WORLD_VERSION,
            "episode_id": self.episode_id,
            "selected_hypothesis_id": self.selected_hypothesis_id,
            "disposition": self.disposition.value,
            "predicted_interventions": dict(sorted(self.predicted_interventions.items())),
            "cited_evidence_refs": list(self.cited_evidence_refs),
            "failure_dispositions": dict(sorted(self.failure_dispositions.items())),
            "validator_certificate_id": self.validator_certificate_id,
            "limitations": list(self.limitations),
            "proposal_digest": self.proposal_digest,
        }
        if include_id:
            value["conclusion_id"] = self.conclusion_id
        return value


@dataclass(frozen=True)
class AdaptiveValidationCertificate:
    episode_id: str
    proposal_digest: str
    selected_hypothesis_id: str
    disposition: ConclusionDisposition
    cited_evidence_refs: Tuple[str, ...]
    decisive_context_count: int
    live_hypothesis_ids: Tuple[str, ...]
    structural_ambiguity: bool
    expected_predictions: Mapping[str, str]
    evidence_integrity: bool
    accepted: bool
    counterexamples: Tuple[str, ...]
    validator_ref: str

    @property
    def certificate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": ADAPTIVE_VALIDATOR_VERSION,
            "episode_id": self.episode_id,
            "proposal_digest": self.proposal_digest,
            "selected_hypothesis_id": self.selected_hypothesis_id,
            "disposition": self.disposition.value,
            "cited_evidence_refs": list(self.cited_evidence_refs),
            "decisive_context_count": self.decisive_context_count,
            "live_hypothesis_ids": list(self.live_hypothesis_ids),
            "structural_ambiguity": self.structural_ambiguity,
            "expected_predictions": dict(sorted(self.expected_predictions.items())),
            "evidence_integrity": self.evidence_integrity,
            "accepted": self.accepted,
            "counterexamples": list(self.counterexamples),
            "validator_ref": self.validator_ref,
        }
        if include_id:
            value["certificate_id"] = self.certificate_id
        return value


class AdaptivePublicValidator:
    """Answer-blind validator: it receives no authority, seed, fault, or sealed outcomes."""

    def __init__(
        self,
        public: AdaptiveWorldPublicPacket,
        observation_source: AdaptiveWorldInstrument,
    ) -> None:
        if public.episode_id != observation_source.public.episode_id:
            raise ValueError("validator and observation source disagree")
        self.public = public
        self._source = observation_source
        self._calls = 0

    @property
    def calls(self) -> int:
        return self._calls

    def validate_candidate(
        self,
        *,
        selected_hypothesis_id: str,
        disposition: ConclusionDisposition,
        predicted_interventions: Mapping[str, str],
        cited_evidence_refs: Sequence[str],
    ) -> AdaptiveValidationCertificate:
        if self._calls >= self.public.maximum_validator_calls:
            raise ValueError("validator-call budget exhausted")
        self._calls += 1
        disposition = ConclusionDisposition(disposition)
        cited = tuple(str(item) for item in cited_evidence_refs)
        available = {item.evidence_ref for item in self._source.observations}
        evidence_integrity = (
            bool(cited)
            and len(cited) == len(set(cited))
            and set(cited).issubset(available)
        )
        labels = _decisive_labels(
            self._source.observations,
            self.public.intervention_names,
            cited,
        ) if evidence_integrity else {}
        live = _live_candidates(self.public, labels)
        ambiguity = _structurally_aliased(self.public, live)
        sufficient = len(labels) >= self.public.minimum_decisive_contexts
        known = {item.hypothesis_id: item for item in self.public.hypotheses}
        counterexamples = []
        expected: Mapping[str, str] = {}
        accepted = False
        if not evidence_integrity:
            counterexamples.append("cited evidence is empty, repeated, or not in the immutable trace")
        if not sufficient:
            counterexamples.append("too few paired decisive contexts")
        if selected_hypothesis_id == _UNDERDETERMINED:
            expected = _predictions_for_alias_group(self.public, live) if live else {}
            accepted = all(
                (
                    evidence_integrity,
                    sufficient,
                    disposition == ConclusionDisposition.ABSTAIN,
                    ambiguity,
                    dict(predicted_interventions) == dict(expected),
                )
            )
            if not ambiguity:
                counterexamples.append("live candidates are not structurally aliased on the full instrument surface")
        elif selected_hypothesis_id in known:
            candidate = known[selected_hypothesis_id]
            expected = _predictions_for_candidate(self.public, candidate)
            expected_disposition = (
                ConclusionDisposition.KILL
                if candidate.rule_kind == RuleKind.NULL
                else ConclusionDisposition.PROMOTE
            )
            accepted = all(
                (
                    evidence_integrity,
                    sufficient,
                    len(live) == 1,
                    live[0].hypothesis_id == selected_hypothesis_id if live else False,
                    disposition == expected_disposition,
                    dict(predicted_interventions) == dict(expected),
                )
            )
            if len(live) != 1:
                counterexamples.append("public evidence does not isolate exactly one hypothesis")
            elif live[0].hypothesis_id != selected_hypothesis_id:
                counterexamples.append("selected hypothesis contradicts the surviving public hypothesis")
        else:
            counterexamples.append("selected hypothesis is not public")
        if dict(predicted_interventions) != dict(expected):
            counterexamples.append("evaluation predictions do not match the public candidate state")
        proposal_digest = content_digest(
            {
                "episode_id": self.public.episode_id,
                "selected_hypothesis_id": selected_hypothesis_id,
                "disposition": disposition.value,
                "predicted_interventions": dict(sorted(predicted_interventions.items())),
                "cited_evidence_refs": list(cited),
            }
        )
        return AdaptiveValidationCertificate(
            episode_id=self.public.episode_id,
            proposal_digest=proposal_digest,
            selected_hypothesis_id=selected_hypothesis_id,
            disposition=disposition,
            cited_evidence_refs=cited,
            decisive_context_count=len(labels),
            live_hypothesis_ids=tuple(sorted(item.hypothesis_id for item in live)),
            structural_ambiguity=ambiguity,
            expected_predictions=expected,
            evidence_integrity=evidence_integrity,
            accepted=accepted,
            counterexamples=tuple(dict.fromkeys(counterexamples)),
            validator_ref="deterministic-public-evidence-validator-v1",
        )


def _replacement_context(
    public: AdaptiveWorldPublicPacket,
    used: Sequence[Tuple[int, ...]],
    failed: Tuple[int, ...],
) -> Tuple[int, ...]:
    selected = tuple(context for context in used if context != failed)
    current_pairs = {
        (left, right)
        for left in range(len(public.hypotheses))
        for right in range(left + 1, len(public.hypotheses))
        if all(
            public.hypotheses[left].prediction(context)
            == public.hypotheses[right].prediction(context)
            for context in selected
        )
    }
    choices = [
        context
        for context in public.instrument_contexts
        if context not in used and context != failed
    ]
    if not choices:
        raise ValueError("no replacement context is available")
    return max(
        choices,
        key=lambda context: sum(
            public.hypotheses[left].prediction(context)
            != public.hypotheses[right].prediction(context)
            for left, right in current_pairs
        ),
    )


def run_answer_blind_reference_policy(
    public: AdaptiveWorldPublicPacket,
    instrument: AdaptiveWorldInstrument,
) -> Tuple[AdaptiveConclusion, AdaptiveValidationCertificate]:
    """Solve only from public candidates and observations; never inspect authority."""

    design = list(canonical_design_contexts(public))
    left, right = public.intervention_names
    planned = [
        ProbeQuery(context=context, intervention=intervention, replicate=0)
        for context in design
        for intervention in (left, right)
    ]
    first = instrument.probe_batch(planned)
    failure = next(
        (item for item in first.results if item.status != ProbeStatus.OK), None
    )
    failure_dispositions: Dict[str, str] = {}
    if failure is not None:
        assert failure.failure_ref is not None
        expected = _EXPECTED_RECOVERY[FaultClass(failure.status.value)]
        failure_dispositions[failure.failure_ref] = expected.value
        attempted_ids = {item.query.query_id for item in first.results}
        remaining = [item for item in planned if item.query_id not in attempted_ids]
        if failure.status == ProbeStatus.PERMANENT_ACTION_UNAVAILABLE:
            replacement = _replacement_context(public, design, failure.query.context)
            design = [item for item in design if item != failure.query.context] + [replacement]
            remaining = [
                item for item in remaining if item.context != failure.query.context
            ]
            recovery_queries = [
                ProbeQuery(replacement, left, 0),
                ProbeQuery(replacement, right, 0),
            ] + remaining
        elif failure.status in {
            ProbeStatus.PROTOCOL_INVALID_REQUEST,
            ProbeStatus.MEASUREMENT_AMBIGUITY,
        }:
            recovery_queries = [
                ProbeQuery(
                    failure.query.context,
                    failure.query.intervention,
                    failure.query.replicate + 1,
                )
            ] + remaining
        else:
            recovery_queries = [failure.query] + remaining
        instrument.probe_batch(
            recovery_queries,
            responding_to=failure.failure_ref,
            recovery_transition=expected,
        )

    observations = instrument.observations
    evidence_refs = tuple(item.evidence_ref for item in observations)
    labels = _decisive_labels(observations, public.intervention_names, evidence_refs)
    live = _live_candidates(public, labels)
    if _structurally_aliased(public, live):
        selected_id = _UNDERDETERMINED
        disposition = ConclusionDisposition.ABSTAIN
        predictions = _predictions_for_alias_group(public, live)
    elif len(live) == 1:
        selected = live[0]
        selected_id = selected.hypothesis_id
        disposition = (
            ConclusionDisposition.KILL
            if selected.rule_kind == RuleKind.NULL
            else ConclusionDisposition.PROMOTE
        )
        predictions = _predictions_for_candidate(public, selected)
    else:
        selected_id = _UNDERDETERMINED
        disposition = ConclusionDisposition.ABSTAIN
        predictions = {
            _context_key(context): _UNDERDETERMINED
            for context in public.evaluation_contexts
        }
    validator = AdaptivePublicValidator(public, instrument)
    certificate = validator.validate_candidate(
        selected_hypothesis_id=selected_id,
        disposition=disposition,
        predicted_interventions=predictions,
        cited_evidence_refs=evidence_refs,
    )
    conclusion = AdaptiveConclusion(
        episode_id=public.episode_id,
        selected_hypothesis_id=selected_id,
        disposition=disposition,
        predicted_interventions=predictions,
        cited_evidence_refs=evidence_refs,
        failure_dispositions=failure_dispositions,
        validator_certificate_id=certificate.certificate_id,
        limitations=("finite public candidate class and instrument surface",),
    )
    return conclusion, certificate


@dataclass(frozen=True)
class AdaptiveWorldScore:
    episode_id: str
    conclusion_id: str
    scientific_state_correct: bool
    disposition_correct: bool
    evaluation_predictions_correct: bool
    evidence_grounded: bool
    validator_certificate_valid: bool
    typed_recovery_correct: bool
    trace_complete: bool
    within_budget: bool
    no_forbidden_operation: bool
    promoted: bool

    @property
    def valid_root_advance(self) -> bool:
        return all(
            (
                self.scientific_state_correct,
                self.disposition_correct,
                self.evaluation_predictions_correct,
                self.evidence_grounded,
                self.validator_certificate_valid,
                self.typed_recovery_correct,
                self.trace_complete,
                self.within_budget,
                self.no_forbidden_operation,
            )
        )

    @property
    def false_promotion(self) -> bool:
        return self.promoted and not all(
            (
                self.scientific_state_correct,
                self.evaluation_predictions_correct,
                self.validator_certificate_valid,
            )
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": ADAPTIVE_WORLD_VERSION,
            "episode_id": self.episode_id,
            "conclusion_id": self.conclusion_id,
            "scientific_state_correct": self.scientific_state_correct,
            "disposition_correct": self.disposition_correct,
            "evaluation_predictions_correct": self.evaluation_predictions_correct,
            "evidence_grounded": self.evidence_grounded,
            "validator_certificate_valid": self.validator_certificate_valid,
            "typed_recovery_correct": self.typed_recovery_correct,
            "trace_complete": self.trace_complete,
            "within_budget": self.within_budget,
            "no_forbidden_operation": self.no_forbidden_operation,
            "promoted": self.promoted,
            "valid_root_advance": self.valid_root_advance,
            "false_promotion": self.false_promotion,
        }


def score_adaptive_world(
    public: AdaptiveWorldPublicPacket,
    authority: AdaptiveWorldAuthority,
    instrument: AdaptiveWorldInstrument,
    conclusion: AdaptiveConclusion,
    certificate: AdaptiveValidationCertificate | None,
    *,
    trace_complete: bool,
    within_budget: bool,
    no_forbidden_operation: bool,
) -> AdaptiveWorldScore:
    if public.episode_id != authority.episode_id or conclusion.episode_id != public.episode_id:
        raise ValueError("adaptive score inputs belong to different episodes")
    known = {item.hypothesis_id: item for item in public.hypotheses}
    selected_truth = known[authority.selected_hypothesis_id]
    if authority.scientific_state == ScientificState.EVIDENCE_UNDERDETERMINED:
        correct_id = conclusion.selected_hypothesis_id == _UNDERDETERMINED
        correct_disposition = conclusion.disposition == ConclusionDisposition.ABSTAIN
        aliases = tuple(
            known[item] for item in authority.underdetermined_alias_ids
        )
        expected_predictions = _predictions_for_alias_group(public, aliases)
    else:
        correct_id = conclusion.selected_hypothesis_id == authority.selected_hypothesis_id
        correct_disposition = conclusion.disposition == (
            ConclusionDisposition.KILL
            if authority.scientific_state == ScientificState.GENUINE_NULL
            else ConclusionDisposition.PROMOTE
        )
        expected_predictions = _predictions_for_candidate(public, selected_truth)
    available = {item.evidence_ref for item in instrument.observations}
    evidence_grounded = (
        bool(conclusion.cited_evidence_refs)
        and set(conclusion.cited_evidence_refs).issubset(available)
    )
    certificate_valid = bool(
        certificate
        and certificate.episode_id == public.episode_id
        and certificate.certificate_id == conclusion.validator_certificate_id
        and certificate.proposal_digest == conclusion.proposal_digest
        and certificate.accepted
    )
    expected_failures = {
        item.failure_ref: item.expected_transition.value
        for item in instrument.recovery_records
    }
    typed_recovery = (
        instrument.recovery_complete_and_correct
        and dict(conclusion.failure_dispositions) == expected_failures
    )
    return AdaptiveWorldScore(
        episode_id=public.episode_id,
        conclusion_id=conclusion.conclusion_id,
        scientific_state_correct=correct_id,
        disposition_correct=correct_disposition,
        evaluation_predictions_correct=(
            dict(conclusion.predicted_interventions) == dict(expected_predictions)
        ),
        evidence_grounded=evidence_grounded,
        validator_certificate_valid=certificate_valid,
        typed_recovery_correct=typed_recovery,
        trace_complete=trace_complete,
        within_budget=(
            within_budget
            and instrument.probe_batches <= public.maximum_probe_batches
            and instrument.measurement_attempts <= public.maximum_measurement_attempts
        ),
        no_forbidden_operation=no_forbidden_operation,
        promoted=conclusion.disposition == ConclusionDisposition.PROMOTE,
    )
