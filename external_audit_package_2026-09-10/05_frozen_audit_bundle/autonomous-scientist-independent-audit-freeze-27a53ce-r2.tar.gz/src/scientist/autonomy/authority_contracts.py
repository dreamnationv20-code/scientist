from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.state import ActorIdentity, ActorKind, AuthorityScope
from scientist.autonomy.tracing import ComponentExecutionTrace, InvocationKind
from scientist.program.research_kernel import ResearchActionKind


AUTHORITY_CONTRACT_VERSION = "scientist-action-authority-contract-v1"


@dataclass(frozen=True)
class InvocationPermission:
    kind: InvocationKind
    authority_scope: AuthorityScope

    def as_dict(self) -> Dict[str, str]:
        return {
            "kind": self.kind.value,
            "authority_scope": self.authority_scope.value,
        }


@dataclass(frozen=True)
class ActionAuthorityContract:
    action_kind: ResearchActionKind
    commit_actor_kind: ActorKind
    commit_authority_scope: AuthorityScope
    allowed_invocations: Tuple[InvocationPermission, ...]
    required_invocation_kinds: Tuple[InvocationKind, ...]
    adaptive_proposal_allowed: bool
    scientific_role: str

    def __post_init__(self) -> None:
        actor = ActorIdentity("contract-check", self.commit_actor_kind)
        if not actor.permits(self.commit_authority_scope):
            raise ValueError("authority contract assigns an illegal commit scope")
        if not self.scientific_role:
            raise ValueError("authority contract requires a scientific role")
        permissions = tuple(
            (item.kind, item.authority_scope) for item in self.allowed_invocations
        )
        if len(permissions) != len(set(permissions)):
            raise ValueError("authority contract contains duplicate permissions")
        if len(self.required_invocation_kinds) != len(
            set(self.required_invocation_kinds)
        ):
            raise ValueError("authority contract contains duplicate requirements")
        allowed_kinds = {item.kind for item in self.allowed_invocations}
        if not set(self.required_invocation_kinds).issubset(allowed_kinds):
            raise ValueError("required invocation kind is not allowed")
        model_allowed = InvocationKind.MODEL in allowed_kinds
        if self.adaptive_proposal_allowed != model_allowed:
            raise ValueError("adaptive-proposal flag and model permission disagree")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": AUTHORITY_CONTRACT_VERSION,
            "action_kind": self.action_kind.value,
            "commit_actor_kind": self.commit_actor_kind.value,
            "commit_authority_scope": self.commit_authority_scope.value,
            "allowed_invocations": [
                item.as_dict() for item in self.allowed_invocations
            ],
            "required_invocation_kinds": [
                item.value for item in self.required_invocation_kinds
            ],
            "adaptive_proposal_allowed": self.adaptive_proposal_allowed,
            "scientific_role": self.scientific_role,
        }


MODEL_PROPOSAL = InvocationPermission(
    InvocationKind.MODEL,
    AuthorityScope.PROPOSE,
)
TOOL_EXECUTION = InvocationPermission(
    InvocationKind.TOOL,
    AuthorityScope.EXECUTE,
)
TOOL_MEASUREMENT = InvocationPermission(
    InvocationKind.TOOL,
    AuthorityScope.MEASURE,
)


def _contract(
    action: ResearchActionKind,
    actor: ActorKind,
    scope: AuthorityScope,
    *,
    allowed: Sequence[InvocationPermission] = (),
    required: Sequence[InvocationKind] = (),
    role: str,
) -> ActionAuthorityContract:
    permissions = tuple(allowed)
    return ActionAuthorityContract(
        action_kind=action,
        commit_actor_kind=actor,
        commit_authority_scope=scope,
        allowed_invocations=permissions,
        required_invocation_kinds=tuple(required),
        adaptive_proposal_allowed=any(
            item.kind == InvocationKind.MODEL for item in permissions
        ),
        scientific_role=role,
    )


# This is the frozen separation between adaptive intelligence and scientific
# authority. Model calls are proposal-only. Evidence-producing phases require
# a charged tool invocation and are committed by deterministic verification.
ACTION_AUTHORITY_CONTRACTS: Mapping[
    ResearchActionKind, ActionAuthorityContract
] = {
    ResearchActionKind.FREEZE_MISSION: _contract(
        ResearchActionKind.FREEZE_MISSION,
        ActorKind.SCIENTIST_POLICY,
        AuthorityScope.GOVERN,
        role="bind the user objective, claim boundary, and stop rules",
    ),
    ResearchActionKind.SURVEY_PRIOR_ART: _contract(
        ResearchActionKind.SURVEY_PRIOR_ART,
        ActorKind.DETERMINISTIC_VALIDATOR,
        AuthorityScope.VERIFY,
        allowed=(MODEL_PROPOSAL, TOOL_MEASUREMENT),
        required=(InvocationKind.TOOL,),
        role="verify literature-search coverage and closure from retrieved records",
    ),
    ResearchActionKind.REPRODUCE_INCUMBENT: _contract(
        ResearchActionKind.REPRODUCE_INCUMBENT,
        ActorKind.DETERMINISTIC_VALIDATOR,
        AuthorityScope.VERIFY,
        allowed=(TOOL_EXECUTION, TOOL_MEASUREMENT),
        required=(InvocationKind.TOOL,),
        role="verify an executable incumbent reproduction",
    ),
    ResearchActionKind.MAP_PHENOMENON: _contract(
        ResearchActionKind.MAP_PHENOMENON,
        ActorKind.DETERMINISTIC_VALIDATOR,
        AuthorityScope.VERIFY,
        allowed=(MODEL_PROPOSAL, TOOL_EXECUTION, TOOL_MEASUREMENT),
        required=(InvocationKind.TOOL,),
        role="verify counterfactual measurements across regimes and horizons",
    ),
    ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS: _contract(
        ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS,
        ActorKind.DETERMINISTIC_VALIDATOR,
        AuthorityScope.VERIFY,
        allowed=(MODEL_PROPOSAL,),
        role="verify that proposed causal models cover and cite measured failures",
    ),
    ResearchActionKind.INVENT_LATENT_CONCEPT: _contract(
        ResearchActionKind.INVENT_LATENT_CONCEPT,
        ActorKind.SCIENTIST_POLICY,
        AuthorityScope.PROPOSE,
        allowed=(MODEL_PROPOSAL,),
        required=(InvocationKind.MODEL,),
        role="propose a falsifiable representation from the causal diagnosis",
    ),
    ResearchActionKind.VALIDATE_LATENT_CONCEPT: _contract(
        ResearchActionKind.VALIDATE_LATENT_CONCEPT,
        ActorKind.DETERMINISTIC_VALIDATOR,
        AuthorityScope.VERIFY,
        allowed=(TOOL_EXECUTION, TOOL_MEASUREMENT),
        required=(InvocationKind.TOOL,),
        role="verify preregistered prospective concept predictions",
    ),
    ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT: _contract(
        ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT,
        ActorKind.SCIENTIST_POLICY,
        AuthorityScope.GOVERN,
        allowed=(MODEL_PROPOSAL,),
        required=(InvocationKind.MODEL,),
        role="freeze an answer-blind experiment and decision rules",
    ),
    ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM: _contract(
        ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM,
        ActorKind.DETERMINISTIC_VALIDATOR,
        AuthorityScope.VERIFY,
        allowed=(MODEL_PROPOSAL, TOOL_EXECUTION, TOOL_MEASUREMENT),
        required=(InvocationKind.TOOL,),
        role="verify executable behavior, novelty, and incumbent fallback parity",
    ),
    ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION: _contract(
        ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION,
        ActorKind.DETERMINISTIC_VALIDATOR,
        AuthorityScope.VERIFY,
        allowed=(TOOL_EXECUTION, TOOL_MEASUREMENT),
        required=(InvocationKind.TOOL,),
        role="verify sealed multi-horizon outcomes without adaptive reinterpretation",
    ),
    ResearchActionKind.MAKE_PROGRAM_DECISION: _contract(
        ResearchActionKind.MAKE_PROGRAM_DECISION,
        ActorKind.SCIENTIST_POLICY,
        AuthorityScope.GOVERN,
        role="apply frozen promotion, repair, reframe, or termination rules",
    ),
    ResearchActionKind.REPORT_TERMINAL: _contract(
        ResearchActionKind.REPORT_TERMINAL,
        ActorKind.SCIENTIST_POLICY,
        AuthorityScope.GOVERN,
        role="report the already-authorized terminal disposition",
    ),
}


def authority_contract(
    action_kind: ResearchActionKind,
) -> ActionAuthorityContract:
    return ACTION_AUTHORITY_CONTRACTS[action_kind]


def validate_component_execution(
    *,
    action_kind: ResearchActionKind,
    component_actor: ActorIdentity,
    component_scope: AuthorityScope,
    trace: ComponentExecutionTrace,
) -> None:
    contract = authority_contract(action_kind)
    if component_actor.kind != contract.commit_actor_kind:
        raise ValueError(
            "%s must commit as %s, not %s"
            % (
                action_kind.value,
                contract.commit_actor_kind.value,
                component_actor.kind.value,
            )
        )
    if component_scope != contract.commit_authority_scope:
        raise ValueError(
            "%s requires %s commit authority"
            % (action_kind.value, contract.commit_authority_scope.value)
        )
    allowed = {
        (item.kind, item.authority_scope) for item in contract.allowed_invocations
    }
    observed_kinds = set()
    for invocation in trace.invocations:
        observed = (invocation.kind, invocation.authority_scope)
        if observed not in allowed:
            raise ValueError(
                "%s used an invocation outside its frozen authority contract"
                % action_kind.value
            )
        observed_kinds.add(invocation.kind)
    missing = set(contract.required_invocation_kinds).difference(observed_kinds)
    if missing:
        raise ValueError(
            "%s omitted required invocation kinds: %s"
            % (action_kind.value, ", ".join(sorted(item.value for item in missing)))
        )


def component_authority(component: Any) -> Tuple[ActorIdentity, AuthorityScope]:
    try:
        kind = ActorKind(component.dispatch_actor_kind)
        scope = AuthorityScope(component.dispatch_authority_scope)
    except (AttributeError, ValueError) as error:
        raise ValueError(
            "research component lacks a valid dispatch-authority declaration"
        ) from error
    actor = ActorIdentity(
        actor_ref="%s@%s" % (component.name, component.component_version),
        kind=kind,
    )
    if not actor.permits(scope):
        raise ValueError("research component declares authority it cannot exercise")
    return actor, scope


@dataclass(frozen=True)
class ComponentPackAudit:
    installed_actions: Tuple[str, ...]
    conformant_actions: Tuple[str, ...]
    missing_actions: Tuple[str, ...]
    nonconformant_actions: Mapping[str, str]

    @property
    def passed(self) -> bool:
        return not self.missing_actions and not self.nonconformant_actions

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": AUTHORITY_CONTRACT_VERSION,
            "passed": self.passed,
            "installed_actions": list(self.installed_actions),
            "conformant_actions": list(self.conformant_actions),
            "missing_actions": list(self.missing_actions),
            "nonconformant_actions": dict(sorted(self.nonconformant_actions.items())),
        }


def audit_component_pack(components: Mapping[str, Any]) -> ComponentPackAudit:
    required = {item.value for item in ResearchActionKind}
    installed = set(components).intersection(required)
    conformant = []
    nonconformant: Dict[str, str] = {}
    for action_name in sorted(installed):
        component = components[action_name]
        try:
            actor, scope = component_authority(component)
            contract = authority_contract(ResearchActionKind(action_name))
            if actor.kind != contract.commit_actor_kind:
                raise ValueError(
                    "commit actor must be %s" % contract.commit_actor_kind.value
                )
            if scope != contract.commit_authority_scope:
                raise ValueError(
                    "commit scope must be %s"
                    % contract.commit_authority_scope.value
                )
        except ValueError as error:
            nonconformant[action_name] = str(error)
        else:
            conformant.append(action_name)
    return ComponentPackAudit(
        installed_actions=tuple(sorted(installed)),
        conformant_actions=tuple(conformant),
        missing_actions=tuple(sorted(required.difference(installed))),
        nonconformant_actions=nonconformant,
    )
