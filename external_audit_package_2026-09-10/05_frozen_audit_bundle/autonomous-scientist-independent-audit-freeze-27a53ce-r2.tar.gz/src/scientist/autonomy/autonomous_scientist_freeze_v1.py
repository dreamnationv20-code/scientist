from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


AUTONOMOUS_SCIENTIST_FREEZE_VERSION = "autonomous-scientist-implementation-freeze-v1"

FROZEN_SOURCE_PATHS: Sequence[str] = (
    "src/scientist/core/artifacts.py",
    "src/scientist/core/provenance.py",
    "src/scientist/codex_exchange.py",
    "src/scientist/program/research_kernel.py",
    "src/scientist/autonomy/authority_contracts.py",
    "src/scientist/autonomy/adaptive_worlds_v1.py",
    "src/scientist/autonomy/adaptive_three_arm_v1.py",
    "src/scientist/autonomy/adaptive_codex_runner_v1.py",
    "src/scientist/autonomy/adaptive_qualification_v1.py",
    "src/scientist/autonomy/adaptive_confirmatory_provider_v1.py",
    "src/scientist/autonomy/adaptive_confirmatory_runner_v1.py",
    "src/scientist/autonomy/adaptive_confirmatory_analysis_v1.py",
    "src/scientist/autonomy/adaptive_ablation_runner_v1.py",
    "src/scientist/autonomy/adaptive_ablation_analysis_v1.py",
    "src/scientist/autonomy/adaptive_replication_analysis_v1.py",
    "src/scientist/autonomy/causalab_external.py",
    "src/scientist/autonomy/causalab_generator.py",
    "src/scientist/autonomy/causalab_three_arm.py",
    "src/scientist/autonomy/causalab_codex_runner.py",
    "src/scientist/autonomy/causalab_validity.py",
    "src/scientist/autonomy/causalab_validity_v2.py",
    "src/scientist/autonomy/causalab_transport_provider_v1.py",
    "src/scientist/autonomy/causalab_transport_runner_v1.py",
    "src/scientist/autonomy/causalab_transport_analysis_v1.py",
    "src/scientist/autonomy/nature_evidence_integration_v1.py",
    "src/scientist/autonomy/autonomous_scientist_freeze_v1.py",
    "scripts/provision_adaptive_confirmatory_panel_v1.py",
    "scripts/run_adaptive_confirmatory_panel_v1.py",
    "scripts/analyze_adaptive_confirmatory_panel_v1.py",
    "scripts/run_adaptive_confirmatory_ablations_v1.py",
    "scripts/analyze_adaptive_confirmatory_ablations_v1.py",
    "scripts/analyze_adaptive_independent_replication_v1.py",
    "scripts/provision_causalab_transport_panel_v1.py",
    "scripts/run_causalab_transport_panel_v1.py",
    "scripts/analyze_causalab_transport_panel_v1.py",
    "scripts/integrate_autonomous_scientist_nature_evidence_v1.py",
    "scripts/qualify_adaptive_causal_harness_v1.py",
    "scripts/qualify_causalab_three_arm_harness_v1.py",
    "scripts/qualify_causalab_three_arm_harness_v10.py",
    "scripts/audit_autonomous_scientist_freeze_v1.py",
    "scripts/freeze_autonomous_scientist_implementation_v1.py",
    "tests/test_autonomy_adaptive_worlds_v1.py",
    "tests/test_autonomy_adaptive_three_arm_v1.py",
    "tests/test_autonomy_adaptive_confirmatory_v1.py",
    "tests/test_autonomy_causalab_transport_v1.py",
    "tests/test_causalab_external.py",
    "tests/test_causalab_generator.py",
    "tests/test_causalab_three_arm.py",
    "tests/test_causalab_codex_runner.py",
    "tests/test_causalab_validity_v2.py",
)

FROZEN_PROTOCOL_PATHS: Sequence[str] = (
    "docs/autonomous-scientist-adaptive-causal-recovery-protocol.md",
    "docs/autonomous-scientist-prospective-evaluation-protocol-v4-amendment.md",
    "docs/autonomous-scientist-prospective-evaluation-protocol-v6-amendment.md",
    "docs/autonomous-scientist-confirmatory-runtime-and-transport-supplement-2026-09-09.md",
    "docs/autonomous-scientist-linear-substrate-adjudication-2026-09-08.md",
    "docs/autonomous-scientist-prefreeze-recovery-closure-adjudication-2026-09-09.md",
    "docs/autonomous-scientist-prefreeze-terminal-control-adjudication-2026-09-09.md",
    "docs/autonomous-scientist-prefreeze-schema-compatibility-adjudication-2026-09-09.md",
    "docs/autonomous-scientist-fresh-development-discrimination-panel-commitment-2026-09-09.md",
    "docs/autonomous-scientist-fresh-development-panel-adjudication-2026-09-09.md",
    "docs/autonomous-scientist-postextension-live-regression-commitment-2026-09-09.md",
    "docs/autonomous-scientist-postextension-live-regression-adjudication-2026-09-09.md",
    "docs/autonomous-scientist-postextension-adjudicator-correction-2026-09-09.md",
    "docs/autonomous-scientist-independent-audit-guide-2026-09-09.md",
)

FROZEN_EVIDENCE_PATHS: Sequence[str] = (
    "runs/autonomy_closure_v1/prospective_protocol_v5/artifacts/manifests/protocol-commitment-v5.json",
    "runs/autonomy_closure_v1/prospective_protocol_v6/artifacts/manifests/protocol-commitment-v6.json",
    "runs/autonomy_closure_v1/schema_compatibility_adjudication_v1/artifacts/manifests/schema-compatibility-adjudication-v1.json",
    "runs/autonomy_closure_v1/adaptive_development_panel_commitment_v1/artifacts/manifests/adaptive-development-discrimination-commitment-v1.json",
    "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1/artifacts/manifests/adaptive-causal-development-fresh-prefreeze-v1.json",
    "runs/autonomy_closure_v1/adaptive_development_panel_adjudication_v1/artifacts/manifests/adaptive-development-panel-adjudication-v1.json",
    "runs/autonomy_closure_v1/confirmatory_runtime_commitment_v1/artifacts/manifests/confirmatory-runtime-commitment-v1.json",
    "runs/autonomy_closure_v1/postextension_regression_commitment_v1/artifacts/manifests/postextension-regression-commitment-v1.json",
    "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1/artifacts/manifests/adaptive-causal-postextension-regression-v1.json",
    "runs/autonomy_closure_v1/postextension_regression_adjudication_v1/artifacts/manifests/postextension-regression-adjudication-v1.json",
    "runs/autonomy_closure_v1/postextension_regression_adjudication_v2/artifacts/manifests/postextension-regression-adjudication-v2.json",
    "runs/autonomy_closure_v1/adaptive_causal_harness_qualification_v9/artifacts/manifests/adaptive-causal-harness-qualification-v9.json",
    "runs/autonomy_closure_v1/causalab_three_arm_harness_qualification_v10/artifacts/manifests/causalab-three-arm-harness-qualification-v10.json",
)


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has invalid {key}")
    return value


def _hashes(root: Path, paths: Sequence[str]) -> Mapping[str, str]:
    missing = [path for path in paths if not (root / path).is_file()]
    if missing:
        raise FileNotFoundError("freeze paths are missing: " + ", ".join(missing))
    return {path: bytes_sha256((root / path).read_bytes()) for path in paths}


def validate_implementation_freeze(
    freeze: Mapping[str, Any], project_root: Path
) -> Mapping[str, Any]:
    body = dict(freeze)
    identity = body.pop("freeze_id", None)
    if not identity or content_digest(body) != identity:
        raise ValueError("implementation freeze identity is invalid")
    if not (
        freeze.get("version") == AUTONOMOUS_SCIENTIST_FREEZE_VERSION
        and freeze.get("implementation_freeze_complete") is True
        and freeze.get("post_freeze_source_mutation_invalidates_execution") is True
    ):
        raise ValueError("implementation freeze is incomplete")
    root = Path(project_root).resolve()
    observed = _hashes(root, tuple(freeze["source_hashes"]))
    if observed != freeze["source_hashes"]:
        raise ValueError("current source tree does not match the implementation freeze")
    return freeze


def build_implementation_freeze(project_root: Path) -> Mapping[str, Any]:
    from scientist.autonomy.adaptive_codex_runner_v1 import adaptive_runner_contract
    from scientist.autonomy.adaptive_three_arm_v1 import adaptive_three_arm_contract
    from scientist.autonomy.causalab_codex_runner import causalab_runner_contract
    from scientist.autonomy.causalab_three_arm import three_arm_contract

    root = Path(project_root).resolve()
    protocol_v5 = _identified(root / FROZEN_EVIDENCE_PATHS[0], "commitment_id")
    protocol_v6 = _identified(root / FROZEN_EVIDENCE_PATHS[1], "commitment_id")
    compatibility = _identified(root / FROZEN_EVIDENCE_PATHS[2], "adjudication_id")
    development_commitment = _identified(root / FROZEN_EVIDENCE_PATHS[3], "commitment_id")
    development_panel = _identified(root / FROZEN_EVIDENCE_PATHS[4], "panel_id")
    development_adjudication = _identified(root / FROZEN_EVIDENCE_PATHS[5], "adjudication_id")
    runtime_commitment = _identified(root / FROZEN_EVIDENCE_PATHS[6], "runtime_commitment_id")
    regression_commitment = _identified(
        root / FROZEN_EVIDENCE_PATHS[7], "regression_commitment_id"
    )
    regression_panel = _identified(root / FROZEN_EVIDENCE_PATHS[8], "panel_id")
    failed_regression_adjudication = _identified(
        root / FROZEN_EVIDENCE_PATHS[9], "regression_adjudication_id"
    )
    regression_adjudication = _identified(
        root / FROZEN_EVIDENCE_PATHS[10], "regression_adjudication_id"
    )
    adaptive_qualification = _identified(
        root / FROZEN_EVIDENCE_PATHS[11], "qualification_id"
    )
    causalab_qualification = _identified(
        root / FROZEN_EVIDENCE_PATHS[12], "qualification_id"
    )
    confirmatory_namespaces = runtime_commitment["confirmatory_namespaces"]
    checks = {
        "protocol_chain_identified": protocol_v6["supersedes_commitment_id"]
        == protocol_v5["commitment_id"],
        "schema_compatibility_adjudicated": compatibility[
            "confirmatory_execution_authorized"
        ]
        is False,
        "development_commitment_matches_panel": development_adjudication[
            "commitment_id"
        ]
        == development_commitment["commitment_id"]
        and development_adjudication["panel_id"] == development_panel["panel_id"],
        "development_discrimination_passed": development_adjudication[
            "all_gates_passed"
        ]
        is True,
        "runtime_commitment_is_prospective": runtime_commitment[
            "confirmatory_outcomes_opened"
        ]
        is False,
        "postextension_commitment_matches_panel": regression_adjudication[
            "regression_commitment_id"
        ]
        == regression_commitment["regression_commitment_id"]
        and regression_adjudication["panel_id"] == regression_panel["panel_id"],
        "failed_adjudication_preserved_and_superseded": failed_regression_adjudication[
            "all_checks_passed"
        ]
        is False
        and regression_adjudication["supersedes_failed_adjudication_id"]
        == failed_regression_adjudication["regression_adjudication_id"],
        "postextension_regression_passed": regression_adjudication[
            "all_checks_passed"
        ]
        is True,
        "adaptive_no_model_qualification_passed": adaptive_qualification[
            "all_checks_passed"
        ]
        is True,
        "causalab_no_model_qualification_passed": causalab_qualification["passed"]
        is True,
        "postextension_live_panel_contract_matches_current": regression_panel[
            "three_arm_contract"
        ]
        == adaptive_three_arm_contract(),
        "preextension_public_interface_matches_current": all(
            development_panel["three_arm_contract"].get(key)
            == adaptive_three_arm_contract().get(key)
            for key in (
                "arms",
                "conclusion_schema",
                "method_policy_byte_identical_for",
                "method_policy_sha256",
                "shared_tools",
                "world_version",
            )
        )
        and all(
            development_panel["runner_contract"].get(key)
            == adaptive_runner_contract().get(key)
            for key in (
                "model",
                "reasoning_effort",
                "model_token_ceiling",
                "wall_time_ceiling_seconds",
                "conclusion_schema",
                "shared_tool_contract",
            )
        ),
        "postextension_live_runner_contract_matches_current": regression_panel[
            "runner_contract"
        ]
        == adaptive_runner_contract(),
        "confirmatory_namespaces_absent": not any(
            (root / path).exists() for path in confirmatory_namespaces.values()
        ),
    }
    if not all(checks.values()):
        failed = [key for key, value in checks.items() if not value]
        raise ValueError("implementation freeze prerequisites failed: " + ", ".join(failed))
    source_hashes = _hashes(root, FROZEN_SOURCE_PATHS)
    protocol_hashes = _hashes(root, FROZEN_PROTOCOL_PATHS)
    evidence_hashes = _hashes(root, FROZEN_EVIDENCE_PATHS)
    body: Dict[str, Any] = {
        "version": AUTONOMOUS_SCIENTIST_FREEZE_VERSION,
        "status": "implementation_frozen_independent_audit_pending",
        "objective": (
            "prospectively test whether authority-separated autonomy outperforms "
            "matched prompt-equated and free monolithic Codex without weakening validity"
        ),
        "prerequisite_checks": checks,
        "prerequisite_ids": {
            "primary_protocol": protocol_v5["commitment_id"],
            "runtime_amendment": protocol_v6["commitment_id"],
            "schema_adjudication": compatibility["adjudication_id"],
            "development_panel": development_panel["panel_id"],
            "development_adjudication": development_adjudication["adjudication_id"],
            "runtime_commitment": runtime_commitment["runtime_commitment_id"],
            "postextension_regression": regression_panel["panel_id"],
            "postextension_adjudication": regression_adjudication[
                "regression_adjudication_id"
            ],
            "adaptive_qualification": adaptive_qualification["qualification_id"],
            "causalab_qualification": causalab_qualification["qualification_id"],
        },
        "adaptive_contract": adaptive_three_arm_contract(),
        "adaptive_runner_contract": adaptive_runner_contract(),
        "causalab_contract": three_arm_contract(),
        "causalab_runner_contract": causalab_runner_contract(),
        "source_hashes": source_hashes,
        "protocol_hashes": protocol_hashes,
        "evidence_hashes": evidence_hashes,
        "confirmatory_namespaces": confirmatory_namespaces,
        "primary_tasks": 180,
        "primary_arm_episodes": 540,
        "ablation_tasks": 90,
        "ablation_episodes": 450,
        "transport_tasks": 30,
        "transport_arm_episodes": 90,
        "replication_tasks": 180,
        "replication_arm_episodes": 540,
        "implementation_freeze_complete": True,
        "post_freeze_source_mutation_invalidates_execution": True,
        "independent_audit_complete": False,
        "provider_execution_authorized": False,
        "confirmatory_seeds_created": False,
        "confirmatory_authorities_created": False,
        "confirmatory_outcomes_opened": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "freeze_id": content_digest(body)}
