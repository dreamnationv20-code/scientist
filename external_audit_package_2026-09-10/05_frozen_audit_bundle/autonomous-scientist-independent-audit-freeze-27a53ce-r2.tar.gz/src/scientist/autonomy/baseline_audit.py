from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.domains.registry import default_domain_registry
from scientist.program.research_kernel import ResearchActionKind


AUTONOMY_BASELINE_AUDIT_VERSION = "scientist-autonomy-baseline-audit-v1"


def _count_files(root: Path, pattern: str) -> int:
    if not root.exists():
        return 0
    return sum(path.is_file() for path in root.glob(pattern))


def _checkpoint_summary(path: Path) -> Mapping[str, Any]:
    if not path.exists():
        return {"present": False, "path": str(path)}
    value = json.loads(path.read_text(encoding="utf-8"))
    control = value["control_plane"]
    graph = control["graph"]
    statuses: Dict[str, int] = {}
    for node in graph["nodes"]:
        status = str(node["status"])
        statuses[status] = statuses.get(status, 0) + 1
    modified = datetime.fromtimestamp(
        path.stat().st_mtime,
        tz=timezone.utc,
    ).isoformat()
    serialized = path.read_text(encoding="utf-8")
    return {
        "present": True,
        "path": str(path),
        "checkpoint_id": value["checkpoint_id"],
        "modified_utc": modified,
        "node_count": len(graph["nodes"]),
        "status_counts": dict(sorted(statuses.items())),
        "ready_leaf_count": len(graph["ready_leaf_ids"]),
        "unresolved_critical_count": len(graph["unresolved_critical_node_ids"]),
        "memory_event_count": control["memory"]["event_count"],
        "compute_spent": control["compute_spent"],
        "compute_budget": control["goal"]["total_compute_budget"],
        "continuation_required": control["continuation_required"],
        "resolved": control["resolution"] is not None,
        "contains_trace_v68": "training_recipe_trace_v68" in serialized,
        "contains_curriculum_v69": "training_recipe_curriculum_v69" in serialized,
    }


def build_baseline_audit(project_root: Path) -> Mapping[str, Any]:
    project_root = Path(project_root).resolve()
    domain = default_domain_registry(discover_plugins=False).resolve(
        "cognitive_core_minilab"
    )
    installed = tuple(sorted(domain.research_components))
    required = tuple(action.value for action in ResearchActionKind)
    scripts_root = project_root / "scripts"
    cognitive_domain_root = (
        project_root / "src" / "scientist" / "domains" / "cognitive_core"
    )
    runs_root = project_root / "runs" / "cognitive_core"
    codex_markers = (
        "CodexCliPacketWorker",
        "CodexPacketCodeModel",
        "CodexAssisted",
        "Codex-owned",
        "Codex-assisted",
    )
    cognitive_scripts = tuple(
        path
        for path in scripts_root.glob("*cognitive*.py")
        if path.is_file()
    )
    codex_scripts = tuple(
        path
        for path in cognitive_scripts
        if any(
            marker in path.read_text(encoding="utf-8", errors="replace")
            for marker in codex_markers
        )
    )
    versioned_run_directories = tuple(
        path
        for path in runs_root.iterdir()
        if path.is_dir() and "_v" in path.name
    ) if runs_root.exists() else ()
    checkpoint = _checkpoint_summary(
        runs_root / "goal_program_v3" / "checkpoint.json"
    )
    manuscript = (
        project_root
        / "manuscript"
        / "autonomous_scientist_architecture_v1"
        / "manuscript.md"
    )
    manuscript_text = manuscript.read_text(encoding="utf-8")
    source_audit = (
        cognitive_domain_root / "invention_evidence_audit_v15.py"
    ).read_text(encoding="utf-8")
    body: Dict[str, Any] = {
        "version": AUTONOMY_BASELINE_AUDIT_VERSION,
        "project_root": str(project_root),
        "cognitive_core_component_coverage": {
            "required_action_count": len(required),
            "installed_action_count": len(installed),
            "installed_actions": list(installed),
            "missing_actions": sorted(set(required).difference(installed)),
            "complete": set(required).issubset(installed),
        },
        "state_unification": {
            "authoritative_checkpoint": checkpoint,
            "late_trace_results_present_outside_checkpoint": all(
                (
                    (
                        runs_root
                        / "training_recipe_trace_v68_r2"
                        / "DECISION_AUDIT.md"
                    ).exists(),
                    (
                        runs_root
                        / "training_recipe_curriculum_v69_r1"
                        / "DECISION_AUDIT.md"
                    ).exists(),
                )
            ),
        },
        "implementation_surface": {
            "cognitive_scripts": len(cognitive_scripts),
            "cognitive_domain_modules": _count_files(cognitive_domain_root, "*.py"),
            "versioned_cognitive_run_directories": len(versioned_run_directories),
            "cognitive_scripts_with_codex_markers": len(codex_scripts),
        },
        "existing_manuscript": {
            "path": str(manuscript),
            "word_count": len(manuscript_text.split()),
            "disclaims_validated_autonomous_discovery": (
                "not a claim that the system has already demonstrated autonomous scientific discovery"
                in manuscript_text
            ),
            "prospective_evaluation_not_yet_reported": (
                "Whether they improve real scientific discovery remains a prospective empirical question"
                in manuscript_text
            ),
        },
        "recorded_autonomy_boundary": {
            "semantic_missing_factor_autonomous": (
                '"semantic_missing_factor_is_invented_without_a_prewritten_domain_mapping": True'
                in source_audit
            ),
            "candidate_synthesized_by_runtime": (
                '"executable_candidate_is_synthesized_by_the_scientist_runtime": True'
                in source_audit
            ),
            "codex_authorship_explicitly_recorded": all(
                phrase in source_audit
                for phrase in (
                    "goal_graph\": \"engineered by Codex",
                    "latent_concept\": \"invented by Codex",
                    "candidate_program\": \"written by Codex",
                )
            ),
        },
        "nature_claim_readiness": {
            "autonomy_closed": False,
            "matched_standalone_codex_baseline_complete": False,
            "sealed_unseen_advantage_complete": False,
            "cross_domain_prospective_result_complete": False,
            "independent_replication_complete": False,
            "submission_ready": False,
        },
        "audit_conclusion": (
            "The deterministic authority layer is implemented, but the cognitive-core "
            "domain lacks a complete installed research worker, recent experiments are "
            "not unified in the authoritative checkpoint, and the current manuscript "
            "contains no prospective scientific-advantage result."
        ),
    }
    return {**body, "audit_id": content_digest(body)}
