from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Optional, Tuple

from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    AuthoritativeResearchLedger,
    AutonomyEventKind,
    ResourceBudget,
    SubsystemSnapshot,
)
from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.core.provenance import bytes_sha256


AUTONOMY_BOOTSTRAP_VERSION = "scientist-autonomy-bootstrap-v1"


def _verified_json_identity(path: Path, identity_field: str) -> str:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("state source must be a JSON object: %s" % path)
    supplied = value.get(identity_field)
    if not isinstance(supplied, str):
        raise ValueError("state source lacks %s: %s" % (identity_field, path))
    body = dict(value)
    body.pop(identity_field)
    if content_digest(body) != supplied:
        raise ValueError("state-source identity does not match content: %s" % path)
    return supplied


def _source_snapshots(project_root: Path) -> Tuple[SubsystemSnapshot, ...]:
    root = Path(project_root).resolve()
    sources = (
        (
            "baseline_audit",
            root / "runs" / "autonomy_closure_v1" / "baseline-audit.json",
            "audit_id",
            AUTONOMY_BOOTSTRAP_VERSION,
        ),
        (
            "goal_graph_control_plane",
            root / "runs" / "cognitive_core" / "goal_program_v3" / "checkpoint.json",
            "checkpoint_id",
            "goal-graph-program-runtime-v3",
        ),
        (
            "legacy_program_runtime",
            root / "runs" / "cognitive_core" / "program" / "checkpoint.json",
            "checkpoint_id",
            "autonomous-program-runtime-v1",
        ),
        (
            "research_kernel",
            root
            / "runs"
            / "cognitive_core"
            / "causal_structure_repairability_v1"
            / "research-kernel-checkpoint.json",
            "checkpoint_id",
            "autonomous-research-kernel-v3",
        ),
    )
    snapshots = [
        SubsystemSnapshot(
            subsystem=name,
            digest=_verified_json_identity(path, identity_field),
            schema_version=schema_version,
            source_ref=str(path.relative_to(root)),
        )
        for name, path, identity_field, schema_version in sources
    ]
    decisions = (
        (
            "trace_experiment_decision",
            root
            / "runs"
            / "cognitive_core"
            / "training_recipe_trace_v68_r2"
            / "DECISION_AUDIT.md",
        ),
        (
            "curriculum_experiment_decision",
            root
            / "runs"
            / "cognitive_core"
            / "training_recipe_curriculum_v69_r1"
            / "DECISION_AUDIT.md",
        ),
    )
    snapshots.extend(
        SubsystemSnapshot(
            subsystem=name,
            digest=bytes_sha256(path.read_bytes()),
            schema_version="frozen-decision-audit-v1",
            source_ref=str(path.relative_to(root)),
        )
        for name, path in decisions
    )
    return tuple(snapshots)


def build_bootstrap_ledger(
    project_root: Path,
    artifact_store: Optional[ArtifactStore] = None,
) -> AuthoritativeResearchLedger:
    root = Path(project_root).resolve()
    protocol_path = root / "docs" / "autonomy-closure-nature-program.md"
    objective_id = content_digest(
        {
            "version": AUTONOMY_BOOTSTRAP_VERSION,
            "protocol_digest": bytes_sha256(protocol_path.read_bytes()),
            "purpose": "migrate pre-closure scientific state without claiming autonomy",
        }
    )
    ledger = AuthoritativeResearchLedger(
        run_id="autonomy-closure-state-bootstrap-v1",
        objective_id=objective_id,
        budget=ResourceBudget(
            maximum_model_tokens=1,
            maximum_model_calls=1,
            maximum_tool_calls=1,
            maximum_wall_seconds=1.0,
            maximum_compute_units=1.0,
        ),
        controller=ActorIdentity(
            actor_ref="autonomy-bootstrap-controller-v1",
            kind=ActorKind.SCIENTIST_POLICY,
        ),
        artifact_store=artifact_store,
    )
    importer = ActorIdentity(
        actor_ref="audited-legacy-import-v1",
        kind=ActorKind.LEGACY_IMPORT,
    )
    for snapshot in _source_snapshots(root):
        ledger.append(
            AutonomyEventKind.LEGACY_STATE_IMPORTED,
            importer,
            AuthorityScope.IMPORT,
            payload={
                "migration_only": True,
                "autonomous_authorship_claimed": False,
                "source_ref": snapshot.source_ref,
            },
            output_artifact_ids=(snapshot.digest,),
            snapshot_updates=(snapshot,),
        )
    return ledger


def bootstrap_summary(ledger: AuthoritativeResearchLedger) -> Mapping[str, Any]:
    state = ledger.state
    body = {
        "version": AUTONOMY_BOOTSTRAP_VERSION,
        "run_id": state.run_id,
        "objective_id": state.objective_id,
        "authoritative_state_id": state.state_id,
        "ledger_head_event_id": ledger.events[-1].event_id,
        "event_count": len(ledger.events),
        "snapshot_count": len(state.subsystem_snapshots),
        "snapshots": [
            item.as_dict()
            for item in sorted(state.subsystem_snapshots, key=lambda item: item.subsystem)
        ],
        "legacy_autonomy_claimed": False,
        "prospective_evidence_claimed": False,
        "chain_valid": ledger.verify_chain(),
    }
    return {**body, "summary_id": content_digest(body)}
