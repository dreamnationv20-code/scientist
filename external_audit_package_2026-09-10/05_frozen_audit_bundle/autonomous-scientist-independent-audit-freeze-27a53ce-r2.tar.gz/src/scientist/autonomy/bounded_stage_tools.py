from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Tuple

from scientist.autonomy.lifecycle_components import LifecycleStageProduct
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import (
    ComponentExecutionTrace,
    ExternalInvocation,
    InvocationKind,
)
from scientist.program.research_kernel import (
    BehavioralMechanismCertificate,
    MultiHorizonEvaluationCertificate,
    ResearchActionKind,
)


BOUNDED_STAGE_TOOL_VERSION = "scientist-bounded-stage-tool-v1"


@dataclass(frozen=True)
class BoundedToolResult:
    """The complete, receipt-bearing result of one bounded scientific tool call."""

    artifact: Any
    receipt_ids: Tuple[str, ...]
    usage: ResourceUsage
    details: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.receipt_ids or any(not value for value in self.receipt_ids):
            raise ValueError("bounded stage tool requires durable receipt identities")
        if len(self.receipt_ids) != len(set(self.receipt_ids)):
            raise ValueError("bounded stage tool receipt identities must be unique")
        if self.usage.tool_calls != 1 or self.usage.model_calls != 0:
            raise ValueError("bounded stage tool must charge exactly one tool call")
        if self.usage.wall_seconds < 0.0 or self.usage.compute_units < 0.0:
            raise ValueError("bounded stage tool usage cannot be negative")
        if "_authority_trace" in self.details:
            raise ValueError("bounded stage tool cannot supply an authority trace")


class BoundedMechanismCompilerStageProvider:
    """Bind one frozen compiler/auditor tool to the mechanism lifecycle stage.

    The callable may internally use a model, search procedure, trainer, or compiler,
    but it must expose those activities through its own receipt bundle.  From the
    authority kernel's perspective it is one bounded tool transaction whose output
    is a typed mechanism certificate.
    """

    provider_version = "bounded-mechanism-compiler-stage-provider-v1"

    def __init__(
        self,
        tool: Callable[[Any, Any, Any], BoundedToolResult],
        *,
        tool_ref: str,
        operation: str = "compile_and_audit_behavioral_mechanism",
    ) -> None:
        if not callable(tool) or not tool_ref or not operation:
            raise ValueError("bounded mechanism compiler configuration is incomplete")
        self.tool = tool
        self.tool_ref = tool_ref
        self.operation = operation

    def __call__(self, action, kernel, domain, component_ref):
        if action.kind != ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM:
            raise ValueError("mechanism compiler received another action")
        if kernel.concept is None or kernel.experiment is None or kernel.incumbent is None:
            raise ValueError("mechanism compilation prerequisites are incomplete")
        result = self.tool(kernel, domain, action)
        if not isinstance(result, BoundedToolResult):
            raise ValueError("mechanism compiler returned an unreceipted result")
        certificate = result.artifact
        if not isinstance(certificate, BehavioralMechanismCertificate):
            raise ValueError("mechanism compiler returned the wrong artifact type")
        if certificate.concept_id != kernel.concept.concept_id:
            raise ValueError("mechanism certificate belongs to another concept")
        if certificate.plan_id != kernel.experiment.plan_id:
            raise ValueError("mechanism certificate belongs to another experiment")
        if certificate.primary_incumbent_id != kernel.incumbent.primary_incumbent_id:
            raise ValueError("mechanism certificate uses another incumbent")
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation=self.operation,
            actor=ActorIdentity(self.tool_ref, ActorKind.TOOL_RUNTIME),
            authority_scope=AuthorityScope.EXECUTE,
            input_artifact_ids=(
                kernel.concept.concept_id,
                kernel.experiment.plan_id,
                kernel.incumbent.portfolio_id,
            ),
            output_artifact_ids=(certificate.certificate_id, *result.receipt_ids),
            usage=result.usage,
        )
        return LifecycleStageProduct(
            artifact=certificate,
            trace=ComponentExecutionTrace(
                action_id=action.action_id,
                component_ref=component_ref,
                invocations=(invocation,),
                complete=True,
                undeclared_external_access=False,
                sealed_authority_accessed=False,
            ),
            outcome=(
                "behavioral_mechanism_compiled_and_audited"
                if certificate.passed
                else "compiled_mechanism_failed_behavioral_audit"
            ),
            details={
                "provider_version": self.provider_version,
                "tool_ref": self.tool_ref,
                "receipt_ids": list(result.receipt_ids),
                "certificate_passed": certificate.passed,
                **dict(result.details),
            },
        )


class BoundedMultiHorizonEvaluationStageProvider:
    """Bind an independent sealed evaluator to the final evidence stage."""

    provider_version = "bounded-multi-horizon-evaluation-stage-provider-v1"

    def __init__(
        self,
        tool: Callable[[Any, Any, Any], BoundedToolResult],
        *,
        tool_ref: str,
        operation: str = "run_independent_multi_horizon_evaluation",
    ) -> None:
        if not callable(tool) or not tool_ref or not operation:
            raise ValueError("bounded evaluation configuration is incomplete")
        self.tool = tool
        self.tool_ref = tool_ref
        self.operation = operation

    def __call__(self, action, kernel, domain, component_ref):
        if action.kind != ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION:
            raise ValueError("multi-horizon evaluator received another action")
        if kernel.mechanism is None or kernel.experiment is None or kernel.mission is None:
            raise ValueError("multi-horizon evaluation prerequisites are incomplete")
        if not kernel.mechanism.passed:
            raise ValueError("a collapsed mechanism cannot enter evaluation")
        result = self.tool(kernel, domain, action)
        if not isinstance(result, BoundedToolResult):
            raise ValueError("multi-horizon evaluator returned an unreceipted result")
        certificate = result.artifact
        if not isinstance(certificate, MultiHorizonEvaluationCertificate):
            raise ValueError("multi-horizon evaluator returned the wrong artifact type")
        if certificate.candidate_id != kernel.mechanism.candidate_id:
            raise ValueError("evaluation uses another candidate")
        if certificate.plan_id != kernel.experiment.plan_id:
            raise ValueError("evaluation uses another experiment")
        if not set(kernel.mission.required_horizons).issubset(
            certificate.horizon_metrics
        ):
            raise ValueError("evaluation omits a mission-required horizon")
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation=self.operation,
            actor=ActorIdentity(self.tool_ref, ActorKind.TOOL_RUNTIME),
            authority_scope=AuthorityScope.MEASURE,
            input_artifact_ids=(
                kernel.mechanism.certificate_id,
                kernel.experiment.plan_id,
            ),
            output_artifact_ids=(certificate.evaluation_id, *result.receipt_ids),
            usage=result.usage,
        )
        return LifecycleStageProduct(
            artifact=certificate,
            trace=ComponentExecutionTrace(
                action_id=action.action_id,
                component_ref=component_ref,
                invocations=(invocation,),
                complete=True,
                undeclared_external_access=False,
                sealed_authority_accessed=False,
            ),
            outcome=(
                "independent_multi_horizon_evaluation_passed"
                if certificate.claim_eligible
                else "independent_multi_horizon_evaluation_failed"
            ),
            details={
                "provider_version": self.provider_version,
                "tool_ref": self.tool_ref,
                "receipt_ids": list(result.receipt_ids),
                "claim_eligible": certificate.claim_eligible,
                **dict(result.details),
            },
        )


__all__ = [
    "BOUNDED_STAGE_TOOL_VERSION",
    "BoundedMechanismCompilerStageProvider",
    "BoundedMultiHorizonEvaluationStageProvider",
    "BoundedToolResult",
]
