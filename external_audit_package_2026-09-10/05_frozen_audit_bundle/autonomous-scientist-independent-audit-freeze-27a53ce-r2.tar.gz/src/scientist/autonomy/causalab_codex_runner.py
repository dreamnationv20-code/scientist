from __future__ import annotations

import json
import os
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.autonomy.causalab_external import (
    CausaLabInstrument,
    CausaLabPublicTask,
    CausaLabTaskAuthority,
)
from scientist.autonomy.causalab_three_arm import (
    ARM_KINDS,
    ARM_SCIENTIST,
    CAUSALAB_THREE_ARM_VERSION,
    CausaLabLifecycleDecision,
    MatchedCausaLabInstrumentGateway,
    authorize_scientist_conclusion,
    causalab_batch_tool_schema,
    causalab_conclusion_schema,
    causalab_model_public_packet,
    causalab_task_prompt,
    parse_causalab_conclusion,
    resolve_model_evidence_references,
)
from scientist.autonomy.causalab_validity import CausaLabConclusionV2
from scientist.autonomy.causalab_validity_v2 import (
    CausaLabValidityScoreV2,
    evaluate_causalab_validity_v2,
)
from scientist.codex_exchange import CodexCliInvocationError
from scientist.core.artifacts import ArtifactStore, content_digest


CAUSALAB_CODEX_RUNNER_VERSION = "causalab-codex-three-arm-runner-v5"
DEFAULT_MODEL_TOKEN_CEILING = 64_000
DEFAULT_WALL_TIME_CEILING_SECONDS = 900.0
DEFAULT_MODEL = "gpt-5.6-sol"
DEFAULT_REASONING_EFFORT = "low"


_MINIMAL_MODEL_INSTRUCTIONS = """You are a sequestered research-task worker.
Follow the user task, use only the explicitly provided research instrument, and
return only the requested structured result. Do not inspect the filesystem, use
the shell, seek hidden information, contact people, or access any other tool."""


_MCP_SERVER_SOURCE = r'''from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request


endpoint = sys.argv[1]
token = sys.argv[2]
schema = json.loads(sys.argv[3])


def emit(request_id, result=None, error=None):
    message = {"jsonrpc": "2.0", "id": request_id}
    if error is not None:
        message["error"] = error
    else:
        message["result"] = result
    print(json.dumps(message, separators=(",", ":")), flush=True)


for raw in sys.stdin:
    try:
        request = json.loads(raw)
        method = request.get("method")
        request_id = request.get("id")
        if method == "initialize":
            emit(
                request_id,
                {
                    "protocolVersion": request.get("params", {}).get(
                        "protocolVersion", "2025-06-18"
                    ),
                    "capabilities": {"tools": {}},
                    "serverInfo": {
                        "name": "matched-causal-research-instrument",
                        "version": "1.0.0",
                    },
                },
            )
        elif method == "notifications/initialized":
            continue
        elif method == "ping":
            emit(request_id, {})
        elif method == "tools/list":
            emit(
                request_id,
                {
                    "tools": [
                        {
                            "name": "intervene_batch",
                            "description": (
                                "Execute one prospectively planned batch of causal "
                                "interventions. Use exactly two values per variable. "
                                "Every attempt is charged to the public budget."
                            ),
                            "inputSchema": schema,
                        }
                    ]
                },
            )
        elif method == "tools/call":
            params = request.get("params", {})
            if params.get("name") != "intervene_batch":
                emit(
                    request_id,
                    error={"code": -32602, "message": "unknown instrument tool"},
                )
                continue
            payload = json.dumps(params.get("arguments", {})).encode("utf-8")
            http_request = urllib.request.Request(
                endpoint,
                data=payload,
                method="POST",
                headers={
                    "Authorization": "Bearer " + token,
                    "Content-Type": "application/json",
                },
            )
            try:
                with urllib.request.urlopen(http_request, timeout=30) as response:
                    body = response.read().decode("utf-8")
                emit(request_id, {"content": [{"type": "text", "text": body}]})
            except urllib.error.HTTPError as http_error:
                body = http_error.read().decode("utf-8")
                emit(
                    request_id,
                    {
                        "content": [{"type": "text", "text": body}],
                        "isError": True,
                    },
                )
        elif request_id is not None:
            emit(request_id, error={"code": -32601, "message": "method not found"})
    except Exception as error:
        if "request_id" in locals() and request_id is not None:
            emit(request_id, error={"code": -32603, "message": str(error)})
'''


class _GatewayService:
    def __init__(self, gateway: MatchedCausaLabInstrumentGateway, token: str) -> None:
        self.gateway = gateway
        self.token = token
        self.lock = threading.Lock()
        self.transport_rejections: list[Mapping[str, Any]] = []

    def handle(self, authorization: str, payload: Any) -> Tuple[int, Mapping[str, Any]]:
        with self.lock:
            if authorization != "Bearer " + self.token:
                rejection = {
                    "sequence": len(self.transport_rejections) + 1,
                    "failure": "invalid instrument capability",
                    "payload_digest": content_digest(payload),
                }
                self.transport_rejections.append(rejection)
                return 403, {"error": rejection["failure"]}
            return self.gateway.handle(payload)


def _handler(service: _GatewayService):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:  # noqa: N802
            if self.path != "/intervene-batch":
                self.send_error(404)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 65_536:
                    raise ValueError("invalid request size")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
            except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as error:
                status, body = 400, {"error": str(error)}
            else:
                status, body = service.handle(
                    self.headers.get("Authorization", ""), payload
                )
            encoded = json.dumps(body, sort_keys=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)

        def log_message(self, format: str, *args: Any) -> None:
            return

    return Handler


@dataclass(frozen=True)
class CodexTokenUsage:
    input_tokens: int
    cached_input_tokens: int
    cache_write_input_tokens: int
    output_tokens: int
    reasoning_output_tokens: int

    def __post_init__(self) -> None:
        if any(
            isinstance(value, bool) or int(value) != value or value < 0
            for value in (
                self.input_tokens,
                self.cached_input_tokens,
                self.cache_write_input_tokens,
                self.output_tokens,
                self.reasoning_output_tokens,
            )
        ):
            raise ValueError("Codex token usage must contain non-negative integers")

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def as_dict(self) -> Dict[str, int]:
        return {
            "input_tokens": self.input_tokens,
            "cached_input_tokens": self.cached_input_tokens,
            "cache_write_input_tokens": self.cache_write_input_tokens,
            "output_tokens": self.output_tokens,
            "reasoning_output_tokens": self.reasoning_output_tokens,
            "total_tokens": self.total_tokens,
        }


@dataclass(frozen=True)
class CausaLabCodexAgentResponse:
    raw_response: Mapping[str, Any]
    proposal: CausaLabConclusionV2
    arm_kind: str
    model_ref: str
    reasoning_effort: str
    codex_version: str
    token_usage: CodexTokenUsage
    wall_seconds: float
    prompt_digest: str
    public_packet_digest: str
    tool_schema_digest: str
    response_digest: str
    transcript_id: str
    project_read_denial_preflight_passed: bool
    project_deny_root: str
    sandbox: str
    transport_rejection_count: int


@dataclass(frozen=True)
class CausaLabArmResult:
    episode_id: str
    arm_kind: str
    proposal: CausaLabConclusionV2
    conclusion: CausaLabConclusionV2
    score: CausaLabValidityScoreV2
    lifecycle_decision: Optional[CausaLabLifecycleDecision]
    model_ref: str
    reasoning_effort: str
    codex_version: str
    token_usage: CodexTokenUsage
    model_token_ceiling: int
    wall_seconds: float
    wall_time_ceiling_seconds: float
    tool_attempts: int
    successful_tool_attempts: int
    intervention_budget: int
    batch_invocations: int
    transport_rejection_count: int
    accounting_reconciled: bool
    execution_autonomous: bool
    project_read_denial_preflight_passed: bool
    transcript_id: str

    @property
    def result_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_CODEX_RUNNER_VERSION,
            "episode_id": self.episode_id,
            "arm_kind": self.arm_kind,
            "proposal": self.proposal.as_dict(),
            "conclusion": self.conclusion.as_dict(),
            "score": self.score.as_dict(),
            "lifecycle_decision": (
                None
                if self.lifecycle_decision is None
                else self.lifecycle_decision.as_dict()
            ),
            "model_ref": self.model_ref,
            "reasoning_effort": self.reasoning_effort,
            "codex_version": self.codex_version,
            "token_usage": self.token_usage.as_dict(),
            "model_token_ceiling": self.model_token_ceiling,
            "wall_seconds": self.wall_seconds,
            "wall_time_ceiling_seconds": self.wall_time_ceiling_seconds,
            "tool_attempts": self.tool_attempts,
            "successful_tool_attempts": self.successful_tool_attempts,
            "intervention_budget": self.intervention_budget,
            "batch_invocations": self.batch_invocations,
            "transport_rejection_count": self.transport_rejection_count,
            "accounting_reconciled": self.accounting_reconciled,
            "execution_autonomous": self.execution_autonomous,
            "human_interventions": 0,
            "out_of_band_interventions": 0,
            "project_read_denial_preflight_passed": (
                self.project_read_denial_preflight_passed
            ),
            "transcript_id": self.transcript_id,
        }
        if include_id:
            value["result_id"] = self.result_id
        return value


def _codex_version(binary: str) -> str:
    completed = subprocess.run(
        (binary, "--version"), capture_output=True, text=True, check=False
    )
    if completed.returncode != 0:
        raise CodexCliInvocationError("unable to identify Codex CLI version")
    return completed.stdout.strip()


def _parse_jsonl_usage(stdout: str) -> CodexTokenUsage:
    completions = []
    for line in stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") == "turn.completed" and isinstance(
            event.get("usage"), Mapping
        ):
            completions.append(event["usage"])
    if len(completions) != 1:
        raise CodexCliInvocationError(
            "Codex JSONL transcript must contain exactly one completed turn"
        )
    usage = completions[0]
    return CodexTokenUsage(
        input_tokens=int(usage.get("input_tokens", 0)),
        cached_input_tokens=int(usage.get("cached_input_tokens", 0)),
        cache_write_input_tokens=int(usage.get("cache_write_input_tokens", 0)),
        output_tokens=int(usage.get("output_tokens", 0)),
        reasoning_output_tokens=int(usage.get("reasoning_output_tokens", 0)),
    )


@dataclass(frozen=True)
class CausaLabCodexWorker:
    artifact_store: ArtifactStore
    project_deny_root: Path
    model: str = DEFAULT_MODEL
    reasoning_effort: str = DEFAULT_REASONING_EFFORT
    model_token_ceiling: int = DEFAULT_MODEL_TOKEN_CEILING
    timeout_seconds: float = DEFAULT_WALL_TIME_CEILING_SECONDS
    codex_binary: str = "codex"
    sandbox_exec_binary: str = "/usr/bin/sandbox-exec"
    confirmatory_authorization_id: Optional[str] = None

    def __post_init__(self) -> None:
        if self.reasoning_effort not in {"low", "medium", "high", "xhigh"}:
            raise ValueError("unsupported Codex reasoning effort")
        if self.model_token_ceiling <= 0 or self.timeout_seconds <= 0:
            raise ValueError("Codex resource ceilings must be positive")
        if self.confirmatory_authorization_id is not None and (
            len(self.confirmatory_authorization_id) != 64
            or any(
                character not in "0123456789abcdef"
                for character in self.confirmatory_authorization_id
            )
        ):
            raise ValueError("invalid CausaLab confirmatory authorization")
        object.__setattr__(
            self, "project_deny_root", Path(self.project_deny_root).resolve()
        )

    def run(
        self,
        public: CausaLabPublicTask,
        authority: CausaLabTaskAuthority,
        arm_kind: str,
    ) -> Tuple[CausaLabCodexAgentResponse, MatchedCausaLabInstrumentGateway]:
        if arm_kind not in ARM_KINDS:
            raise ValueError("unknown CausaLab evaluation arm")
        if public.public_task_id != authority.public_task_id:
            raise ValueError("CausaLab worker task inputs do not match")
        if not public.development_only or not authority.development_only:
            if (
                public.development_only != authority.development_only
                or self.confirmatory_authorization_id is None
            ):
                raise ValueError("CausaLab confirmatory task is not authorized")
        binary = shutil.which(self.codex_binary)
        if binary is None:
            raise CodexCliInvocationError("Codex CLI is unavailable")
        codex_version = _codex_version(binary)
        gateway = MatchedCausaLabInstrumentGateway(
            public, CausaLabInstrument(public, authority), arm_kind
        )
        token = secrets.token_hex(32)
        service = _GatewayService(gateway, token)
        server = HTTPServer(("127.0.0.1", 0), _handler(service))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory(
                prefix="causalab-codex-agent-", dir="/private/tmp"
            ) as temporary:
                work = Path(temporary)
                mcp_path = work / "instrument_mcp.py"
                mcp_path.write_text(_MCP_SERVER_SOURCE, encoding="utf-8")
                instructions_path = work / "model-instructions.txt"
                instructions_path.write_text(
                    _MINIMAL_MODEL_INSTRUCTIONS, encoding="utf-8"
                )
                schema_path = work / "conclusion-schema.json"
                schema_path.write_text(
                    json.dumps(causalab_conclusion_schema(), sort_keys=True),
                    encoding="utf-8",
                )
                output_path = work / "final-response.json"
                profile = (
                    "(version 1)(allow default)(deny file-read* (subpath %s))"
                    % json.dumps(str(self.project_deny_root))
                )
                protected_source = (
                    self.project_deny_root
                    / "src/scientist/autonomy/causalab_generator.py"
                )
                preflight = subprocess.run(
                    (
                        self.sandbox_exec_binary,
                        "-p",
                        profile,
                        "/bin/test",
                        "!",
                        "-r",
                        str(protected_source),
                    ),
                    cwd=work,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                preflight_passed = preflight.returncode == 0
                if not preflight_passed:
                    raise CodexCliInvocationError(
                        "project-read denial preflight failed: %s"
                        % (preflight.stderr or preflight.stdout)[-1000:]
                    )
                endpoint = "http://127.0.0.1:%d/intervene-batch" % server.server_port
                tool_schema_json = json.dumps(
                    causalab_batch_tool_schema(), sort_keys=True, separators=(",", ":")
                )
                command = [
                    self.sandbox_exec_binary,
                    "-p",
                    profile,
                    binary,
                    "exec",
                    "--ephemeral",
                    "--skip-git-repo-check",
                    "--ignore-user-config",
                    "--ignore-rules",
                    "--json",
                    "--color",
                    "never",
                    "-c",
                    'model_reasoning_effort="%s"' % self.reasoning_effort,
                    "-c",
                    "model_context_window=%d" % self.model_token_ceiling,
                    "-c",
                    "model_auto_compact_token_limit=%d"
                    % max(1024, self.model_token_ceiling - 2048),
                    "-c",
                    "include_permissions_instructions=false",
                    "-c",
                    "include_apps_instructions=false",
                    "-c",
                    "include_collaboration_mode_instructions=false",
                    "-c",
                    "include_environment_context=false",
                    "-c",
                    "sandbox_workspace_write.network_access=true",
                    "-c",
                    "model_instructions_file=%s" % json.dumps(str(instructions_path)),
                    "-c",
                    'mcp_servers.research_instrument.command="python3"',
                    "-c",
                    "mcp_servers.research_instrument.args=%s"
                    % json.dumps([str(mcp_path), endpoint, token, tool_schema_json]),
                    "-c",
                    "mcp_servers.research_instrument.startup_timeout_sec=10",
                    "-c",
                    "mcp_servers.research_instrument.required=true",
                    "-c",
                    'mcp_servers.research_instrument.enabled_tools=["intervene_batch"]',
                    "-c",
                    'mcp_servers.research_instrument.default_tools_approval_mode="approve"',
                    "-c",
                    'mcp_servers.research_instrument.tools.intervene_batch.approval_mode="approve"',
                    "--sandbox",
                    "workspace-write",
                    "-C",
                    str(work),
                    "--output-schema",
                    str(schema_path),
                    "-o",
                    str(output_path),
                    "--model",
                    self.model,
                    "-",
                ]
                environment = dict(os.environ)
                environment.pop("OPENAI_API_KEY", None)
                environment.pop("OPENAI_KEY", None)
                prompt = causalab_task_prompt(public, arm_kind)
                started = time.perf_counter()
                completed = subprocess.run(
                    command,
                    input=prompt,
                    text=True,
                    capture_output=True,
                    timeout=self.timeout_seconds,
                    check=False,
                    cwd=work,
                    env=environment,
                )
                wall_seconds = time.perf_counter() - started
                if completed.returncode != 0:
                    diagnostic = "\n".join(
                        (
                            "STDOUT:\n" + (completed.stdout or ""),
                            "STDERR:\n" + (completed.stderr or ""),
                        )
                    )[-8000:]
                    raise CodexCliInvocationError(
                        "Codex arm exited %d: %s"
                        % (completed.returncode, diagnostic.strip())
                    )
                usage = _parse_jsonl_usage(completed.stdout or "")
                try:
                    raw_response = json.loads(
                        output_path.read_text(encoding="utf-8")
                    )
                    proposal = resolve_model_evidence_references(
                        public,
                        gateway,
                        parse_causalab_conclusion(raw_response),
                    )
                except (OSError, json.JSONDecodeError, TypeError, ValueError) as error:
                    raise CodexCliInvocationError(
                        "Codex arm did not emit the frozen conclusion schema"
                    ) from error
                transcript_id = self.artifact_store.put(
                    "causalab_codex_jsonl_transcript",
                    {
                        "version": CAUSALAB_CODEX_RUNNER_VERSION,
                        "arm_kind": arm_kind,
                        "stdout": completed.stdout or "",
                        "stderr": completed.stderr or "",
                        "batch_records": [item.as_dict() for item in gateway.batches],
                        "attempt_records": [item.as_dict() for item in gateway.attempts],
                        "transport_rejections": list(service.transport_rejections),
                    },
                )
                return (
                    CausaLabCodexAgentResponse(
                        raw_response=raw_response,
                        proposal=proposal,
                        arm_kind=arm_kind,
                        model_ref=self.model,
                        reasoning_effort=self.reasoning_effort,
                        codex_version=codex_version,
                        token_usage=usage,
                        wall_seconds=wall_seconds,
                        prompt_digest=content_digest(prompt),
                        public_packet_digest=content_digest(
                            causalab_model_public_packet(public)
                        ),
                        tool_schema_digest=content_digest(
                            causalab_batch_tool_schema()
                        ),
                        response_digest=content_digest(raw_response),
                        transcript_id=transcript_id,
                        project_read_denial_preflight_passed=preflight_passed,
                        project_deny_root=str(self.project_deny_root),
                        sandbox="macos_project_read_denial+codex_workspace_write",
                        transport_rejection_count=len(service.transport_rejections),
                    ),
                    gateway,
                )
        except subprocess.TimeoutExpired as error:
            raise CodexCliInvocationError(
                "Codex arm exceeded its %.1f second timeout" % self.timeout_seconds
            ) from error
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5.0)


def assemble_causalab_arm_result(
    public: CausaLabPublicTask,
    authority: CausaLabTaskAuthority,
    response: CausaLabCodexAgentResponse,
    gateway: MatchedCausaLabInstrumentGateway,
    *,
    model_token_ceiling: int = DEFAULT_MODEL_TOKEN_CEILING,
    wall_time_ceiling_seconds: float = DEFAULT_WALL_TIME_CEILING_SECONDS,
) -> CausaLabArmResult:
    if response.arm_kind != gateway.arm_kind:
        raise ValueError("CausaLab response and gateway arms do not match")
    trace_reconciled = all(
        item.sequence == index
        for index, item in enumerate(gateway.attempts, start=1)
    ) and gateway.instrument.calls_used == len(gateway.attempts)
    accounting_reconciled = bool(
        response.token_usage.total_tokens <= model_token_ceiling
        and response.wall_seconds <= wall_time_ceiling_seconds
        and gateway.instrument.calls_used <= public.intervention_budget
        and response.transport_rejection_count == 0
        and response.project_read_denial_preflight_passed
        and trace_reconciled
    )
    lifecycle = None
    conclusion = response.proposal
    if response.arm_kind == ARM_SCIENTIST:
        lifecycle = authorize_scientist_conclusion(
            public,
            gateway,
            response.proposal,
            accounting_reconciled=accounting_reconciled,
        )
        conclusion = lifecycle.authorized_conclusion
    score = evaluate_causalab_validity_v2(
        public,
        authority,
        gateway.instrument,
        conclusion,
        accounting_reconciled=accounting_reconciled,
    )
    return CausaLabArmResult(
        episode_id=public.episode_ref,
        arm_kind=response.arm_kind,
        proposal=response.proposal,
        conclusion=conclusion,
        score=score,
        lifecycle_decision=lifecycle,
        model_ref=response.model_ref,
        reasoning_effort=response.reasoning_effort,
        codex_version=response.codex_version,
        token_usage=response.token_usage,
        model_token_ceiling=model_token_ceiling,
        wall_seconds=response.wall_seconds,
        wall_time_ceiling_seconds=wall_time_ceiling_seconds,
        tool_attempts=gateway.instrument.calls_used,
        successful_tool_attempts=len(gateway.instrument.records),
        intervention_budget=public.intervention_budget,
        batch_invocations=len(gateway.batches),
        transport_rejection_count=response.transport_rejection_count,
        accounting_reconciled=accounting_reconciled,
        execution_autonomous=True,
        project_read_denial_preflight_passed=(
            response.project_read_denial_preflight_passed
        ),
        transcript_id=response.transcript_id,
    )


def run_causalab_codex_arm(
    public: CausaLabPublicTask,
    authority: CausaLabTaskAuthority,
    *,
    arm_kind: str,
    worker: CausaLabCodexWorker,
) -> CausaLabArmResult:
    if not public.development_only or not authority.development_only:
        raise ValueError("development runner cannot open a confirmatory task")
    response, gateway = worker.run(public, authority, arm_kind)
    return assemble_causalab_arm_result(
        public,
        authority,
        response,
        gateway,
        model_token_ceiling=worker.model_token_ceiling,
        wall_time_ceiling_seconds=worker.timeout_seconds,
    )


def causalab_runner_contract() -> Mapping[str, Any]:
    return {
        "version": CAUSALAB_CODEX_RUNNER_VERSION,
        "three_arm_contract_version": CAUSALAB_THREE_ARM_VERSION,
        "model": DEFAULT_MODEL,
        "reasoning_effort": DEFAULT_REASONING_EFFORT,
        "model_token_ceiling": DEFAULT_MODEL_TOKEN_CEILING,
        "wall_time_ceiling_seconds": DEFAULT_WALL_TIME_CEILING_SECONDS,
        "codex_jsonl_usage_required": True,
        "one_completed_codex_turn_required": True,
        "project_source_denied": True,
        "credentials_removed_from_worker_environment": [
            "OPENAI_API_KEY",
            "OPENAI_KEY",
        ],
        "scientific_instrument_schema": causalab_batch_tool_schema(),
        "conclusion_schema": causalab_conclusion_schema(),
        "strict_evaluator": "causalab-strict-valid-resolution-v2",
        "outcome_over_any_ceiling": "fail_closed_zero",
        "confirmatory_tasks_accepted": False,
        "authorized_transport_worker_available": True,
    }
