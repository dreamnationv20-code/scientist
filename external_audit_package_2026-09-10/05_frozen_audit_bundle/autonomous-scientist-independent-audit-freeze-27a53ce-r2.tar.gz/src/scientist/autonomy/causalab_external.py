from __future__ import annotations

import ast
import hashlib
import json
import math
import operator
import random
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest


CAUSALAB_EXTERNAL_ADAPTER_VERSION = "scientist-causalab-external-adapter-v1"
FREQUENCY_PROPERTY = "resonanceFreq"

_BINARY_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
}
_UNARY_OPERATORS = {ast.UAdd: operator.pos, ast.USub: operator.neg}


def _plain(value: Mapping[str, Any]) -> Dict[str, Any]:
    # Preserve node insertion order because the upstream episode constructor
    # assigns deterministic RNG draws in that order.
    return json.loads(json.dumps(dict(value)))


def _finite_number(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be numeric")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{label} must be finite")
    return result


def _evaluate_node(node: ast.AST, values: Mapping[str, float]) -> float:
    if isinstance(node, ast.Expression):
        return _evaluate_node(node.body, values)
    if isinstance(node, ast.Constant):
        return _finite_number(node.value, "expression constant")
    if isinstance(node, ast.Name):
        if node.id not in values:
            raise ValueError(f"unknown expression name: {node.id}")
        return _finite_number(values[node.id], f"expression value {node.id}")
    if isinstance(node, ast.BinOp) and type(node.op) in _BINARY_OPERATORS:
        left = _evaluate_node(node.left, values)
        right = _evaluate_node(node.right, values)
        result = _BINARY_OPERATORS[type(node.op)](left, right)
        return _finite_number(result, "expression result")
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPERATORS:
        result = _UNARY_OPERATORS[type(node.op)](_evaluate_node(node.operand, values))
        return _finite_number(result, "expression result")
    raise ValueError(f"unsupported expression syntax: {type(node).__name__}")


def evaluate_causalab_expression(expression: str, values: Mapping[str, Any]) -> float:
    """Evaluate the arithmetic subset used by the released CausaLab SCMs.

    Upstream uses ``eval``.  The adapter deliberately accepts only named finite
    numeric values and arithmetic AST nodes so a sealed authority cannot become
    a code-execution channel.
    """

    if not isinstance(expression, str) or not expression.strip():
        raise ValueError("causal expression must be non-empty")
    try:
        tree = ast.parse(expression.replace("^", "**"), mode="eval")
    except SyntaxError as error:
        raise ValueError("invalid causal expression") from error
    return _evaluate_node(tree, {str(k): v for k, v in values.items()})


def _node_property(node_name: str, node_config: Mapping[str, Any]) -> str:
    return str(node_config.get("property_name", node_name))


def validate_causalab_graph_config(config: Mapping[str, Any]) -> Tuple[str, ...]:
    nodes = config.get("nodes")
    edges = config.get("edges")
    params = config.get("params")
    if not isinstance(nodes, Mapping) or len(nodes) < 2:
        raise ValueError("CausaLab graph requires at least two nodes")
    if not isinstance(edges, list) or not isinstance(params, Mapping):
        raise ValueError("CausaLab graph edges or parameters are invalid")
    names = tuple(str(name) for name in nodes)
    if len(names) != len(set(names)) or not all(names):
        raise ValueError("CausaLab node names must be unique and non-empty")
    properties = tuple(_node_property(name, nodes[name]) for name in names)
    if len(properties) != len(set(properties)):
        raise ValueError("CausaLab property names must be unique")
    frequency_nodes = [
        name for name in names if _node_property(name, nodes[name]) == FREQUENCY_PROPERTY
    ]
    if len(frequency_nodes) != 1:
        raise ValueError("CausaLab graph requires exactly one frequency node")
    if bool(nodes[frequency_nodes[0]].get("is_controllable", False)):
        raise ValueError("CausaLab frequency node cannot be controllable")

    parent_map: Dict[str, list[str]] = {name: [] for name in names}
    edge_pairs = []
    for edge in edges:
        if not isinstance(edge, Mapping):
            raise ValueError("CausaLab edge must be an object")
        source, target = str(edge.get("from", "")), str(edge.get("to", ""))
        if source not in nodes or target not in nodes or source == target:
            raise ValueError("CausaLab edge references an invalid node")
        pair = (source, target)
        if pair in edge_pairs:
            raise ValueError("CausaLab graph contains a duplicate edge")
        edge_pairs.append(pair)
        parent_map[target].append(source)

    visiting: set[str] = set()
    visited: set[str] = set()
    order: list[str] = []

    def visit(name: str) -> None:
        if name in visiting:
            raise ValueError("CausaLab graph contains a directed cycle")
        if name in visited:
            return
        visiting.add(name)
        for parent in parent_map[name]:
            visit(parent)
        visiting.remove(name)
        visited.add(name)
        order.append(name)

    for name in names:
        visit(name)

    for name in names:
        node = nodes[name]
        if not isinstance(node, Mapping):
            raise ValueError("CausaLab node configuration must be an object")
        controllable = bool(node.get("is_controllable", False))
        expression = node.get("computation")
        if not controllable and not expression:
            raise ValueError("derived CausaLab node lacks a computation")
        if controllable and "base_value" not in node:
            raise ValueError("controllable CausaLab node lacks a base generator")
        if expression:
            sample_values = {key: 1.25 for key in names}
            sample_values.update({str(key): value for key, value in params.items()})
            sample_values["base"] = 1.25
            sample_values[f"{name}_base"] = 1.25
            evaluate_causalab_expression(str(expression), sample_values)
    return tuple(order)


def compute_causalab_values(
    config: Mapping[str, Any],
    base_values: Mapping[str, Any],
    *,
    precision: int = 2,
) -> Dict[str, float]:
    order = validate_causalab_graph_config(config)
    nodes = config["nodes"]
    params = {str(k): _finite_number(v, f"parameter {k}") for k, v in config["params"].items()}
    parents: Dict[str, list[str]] = {name: [] for name in nodes}
    for edge in config["edges"]:
        parents[str(edge["to"])].append(str(edge["from"]))
    result: Dict[str, float] = {}
    for name in order:
        node = nodes[name]
        controllable = bool(node.get("is_controllable", False))
        base: Optional[float] = None
        if controllable:
            if name not in base_values:
                raise ValueError(f"missing controllable base value: {name}")
            base = _finite_number(base_values[name], f"base value {name}")
        expression = node.get("computation")
        if not expression:
            assert base is not None
            value = base
        else:
            environment: Dict[str, float] = dict(params)
            environment.update({parent: result[parent] for parent in parents[name]})
            if base is not None:
                environment["base"] = base
                # This is the compatibility alias used by CausaLab's own
                # CausalGraph.compute_values implementation.
                environment[f"base_{name}"] = base
            value = evaluate_causalab_expression(str(expression), environment)
        result[name] = round(_finite_number(value, f"computed value {name}"), precision)
    return result


def _stable_node_seed(seed: int, node_name: str, role: str) -> int:
    payload = f"{CAUSALAB_EXTERNAL_ADAPTER_VERSION}:{seed}:{role}:{node_name}".encode()
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")


def deterministic_base_values(
    config: Mapping[str, Any], seed: int, role: str
) -> Dict[str, float]:
    validate_causalab_graph_config(config)
    hard_metadata = config.get("quadratic_metadata") or {}
    if config.get("quadratic_mode") == "hard" and role in {
        "manipulator",
        "reactor",
    }:
        preset = hard_metadata.get(
            "property_manipulator" if role == "manipulator" else "reactor"
        )
        if isinstance(preset, Mapping):
            return {
                str(name): _finite_number(value, f"hard preset {name}")
                for name, value in preset.items()
            }
    values: Dict[str, float] = {}
    for name, node in config["nodes"].items():
        if not bool(node.get("is_controllable", False)):
            continue
        # CausaLab's episode constructor overrides every controllable base with
        # an integer in [0, 100].  Its use of hash(node_name) is process
        # dependent; SHA-256 supplies the same intended per-node separation
        # without that instability.
        rng = random.Random(_stable_node_seed(int(seed), str(name), role))
        values[str(name)] = float(rng.randint(0, 100))
    return values


def _property_values(config: Mapping[str, Any], values: Mapping[str, float]) -> Dict[str, float]:
    return {
        _node_property(str(name), config["nodes"][name]): float(values[name])
        for name in config["nodes"]
        if bool(config["nodes"][name].get("observable", True))
    }


@dataclass(frozen=True)
class CausaLabObservation:
    sequence: int
    intervention_property: Optional[str]
    intervention_value: Optional[float]
    values: Mapping[str, float]

    @property
    def observation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "sequence": self.sequence,
            "intervention_property": self.intervention_property,
            "intervention_value": self.intervention_value,
            "values": {str(k): float(v) for k, v in sorted(self.values.items())},
        }
        if include_id:
            value["observation_id"] = self.observation_id
        return value


@dataclass(frozen=True)
class CausaLabPublicTask:
    episode_ref: str
    variable_names: Tuple[str, ...]
    controllable_properties: Tuple[str, ...]
    observable_properties: Tuple[str, ...]
    equation_family: str
    starting_observations: Tuple[CausaLabObservation, ...]
    target_properties: Mapping[str, float]
    intervention_budget: int
    frequency_tolerance: float
    source_family: str
    development_only: bool

    def __post_init__(self) -> None:
        if not self.episode_ref or not self.source_family:
            raise ValueError("CausaLab public task identity is incomplete")
        for label, values in (
            ("variables", self.variable_names),
            ("controllable properties", self.controllable_properties),
            ("observable properties", self.observable_properties),
        ):
            if not values or len(values) != len(set(values)) or not all(values):
                raise ValueError(f"CausaLab {label} must be unique and non-empty")
        if FREQUENCY_PROPERTY not in self.variable_names:
            raise ValueError("CausaLab public task lacks frequency")
        if FREQUENCY_PROPERTY in self.controllable_properties:
            raise ValueError("frequency cannot be an intervention target")
        if FREQUENCY_PROPERTY in self.target_properties:
            raise ValueError("target frequency leaked into the public task")
        if self.intervention_budget <= 0 or self.frequency_tolerance <= 0:
            raise ValueError("CausaLab resource or scoring bound is invalid")

    @property
    def public_task_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_EXTERNAL_ADAPTER_VERSION,
            "episode_ref": self.episode_ref,
            "variable_names": list(self.variable_names),
            "controllable_properties": list(self.controllable_properties),
            "observable_properties": list(self.observable_properties),
            "equation_family": self.equation_family,
            "starting_observations": [item.as_dict() for item in self.starting_observations],
            "target_properties": {
                str(k): float(v) for k, v in sorted(self.target_properties.items())
            },
            "intervention_budget": self.intervention_budget,
            "frequency_tolerance": self.frequency_tolerance,
            "source_family": self.source_family,
            "development_only": self.development_only,
        }
        if include_id:
            value["public_task_id"] = self.public_task_id
        return value


@dataclass(frozen=True)
class CausaLabTaskAuthority:
    public_task_id: str
    graph_config: Mapping[str, Any]
    manipulator_base_values: Mapping[str, float]
    reactor_base_values: Mapping[str, float]
    environment_seed: int
    source_ref: str
    development_only: bool

    def __post_init__(self) -> None:
        if len(self.public_task_id) != 64 or not self.source_ref:
            raise ValueError("CausaLab authority identity is incomplete")
        validate_causalab_graph_config(self.graph_config)
        compute_causalab_values(self.graph_config, self.manipulator_base_values)
        compute_causalab_values(self.graph_config, self.reactor_base_values)

    @property
    def authority_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def target_frequency(self) -> float:
        values = compute_causalab_values(self.graph_config, self.reactor_base_values)
        for name, node in self.graph_config["nodes"].items():
            if _node_property(str(name), node) == FREQUENCY_PROPERTY:
                return values[str(name)]
        raise ValueError("frequency node disappeared")

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_EXTERNAL_ADAPTER_VERSION,
            "public_task_id": self.public_task_id,
            "graph_config": _plain(self.graph_config),
            "manipulator_base_values": dict(sorted(self.manipulator_base_values.items())),
            "reactor_base_values": dict(sorted(self.reactor_base_values.items())),
            "environment_seed": self.environment_seed,
            "source_ref": self.source_ref,
            "development_only": self.development_only,
        }
        if include_id:
            value["authority_id"] = self.authority_id
        return value


def load_released_causalab_task(
    config: Mapping[str, Any],
    *,
    environment_seed: int,
    source_ref: str,
    initial_observation_count: int = 2,
) -> Tuple[CausaLabPublicTask, CausaLabTaskAuthority]:
    """Create a development-only sealed task from one released graph config."""

    if initial_observation_count < 0:
        raise ValueError("initial observation count cannot be negative")
    canonical = _plain(config)
    validate_causalab_graph_config(canonical)
    nodes = canonical["nodes"]
    variables = tuple(_node_property(str(name), node) for name, node in nodes.items())
    controllable = tuple(
        _node_property(str(name), node)
        for name, node in nodes.items()
        if bool(node.get("is_controllable", False))
    )
    observable = tuple(
        _node_property(str(name), node)
        for name, node in nodes.items()
        if bool(node.get("observable", True))
    )
    starting = []
    prior_rng = random.Random(42)
    hard_metadata = canonical.get("quadratic_metadata") or {}
    hard_presets = hard_metadata.get("observation_presets") or []
    for index in range(initial_observation_count):
        if index < len(hard_presets) and isinstance(hard_presets[index], Mapping):
            bases = {
                str(name): _finite_number(value, f"observation preset {name}")
                for name, value in hard_presets[index].items()
            }
        else:
            bases = {
                str(name): float(prior_rng.randint(0, 100))
                for name, node in nodes.items()
                if bool(node.get("is_controllable", False))
            }
        values = _property_values(canonical, compute_causalab_values(canonical, bases))
        starting.append(CausaLabObservation(index, None, None, values))
    for entry in canonical.get("bootstrap_past_data", []):
        if isinstance(entry, Mapping):
            props = dict(entry.get("props") or {})
            if entry.get("freq") is not None:
                props[FREQUENCY_PROPERTY] = entry["freq"]
            starting.append(
                CausaLabObservation(len(starting), None, None, props)
            )
    manipulator_bases = deterministic_base_values(canonical, environment_seed, "manipulator")
    reactor_bases = deterministic_base_values(canonical, environment_seed, "reactor")
    target_all = _property_values(
        canonical, compute_causalab_values(canonical, reactor_bases)
    )
    target_public = {
        key: value for key, value in target_all.items() if key != FREQUENCY_PROPERTY
    }
    family = str(canonical.get("equation_family") or "linear")
    public = CausaLabPublicTask(
        episode_ref="development-" + content_digest(
            {"source_ref": source_ref, "seed": int(environment_seed)}
        )[:24],
        variable_names=variables,
        controllable_properties=controllable,
        observable_properties=observable,
        equation_family=family,
        starting_observations=tuple(starting),
        target_properties=target_public,
        intervention_budget=int(canonical.get("budget", 12)),
        frequency_tolerance=5.0,
        source_family="CausaLab-v0.0.2-released-grammar",
        development_only=True,
    )
    authority = CausaLabTaskAuthority(
        public_task_id=public.public_task_id,
        graph_config=canonical,
        manipulator_base_values=manipulator_bases,
        reactor_base_values=reactor_bases,
        environment_seed=int(environment_seed),
        source_ref=source_ref,
        development_only=True,
    )
    return public, authority


class CausaLabInstrument:
    """Bounded intervention capability that never returns hidden authority data."""

    def __init__(self, public: CausaLabPublicTask, authority: CausaLabTaskAuthority):
        if public.public_task_id != authority.public_task_id:
            raise ValueError("CausaLab public task and authority do not match")
        self.public = public
        self._authority = authority
        self._base_values = dict(authority.manipulator_base_values)
        self.records: list[CausaLabObservation] = []
        self.failed_attempts = 0

    @property
    def calls_used(self) -> int:
        return len(self.records) + self.failed_attempts

    def intervene(self, property_name: str, target_value: Any) -> CausaLabObservation:
        if self.calls_used >= self.public.intervention_budget:
            self.failed_attempts += 1
            raise RuntimeError("CausaLab intervention budget exhausted")
        try:
            value = _finite_number(target_value, "intervention value")
            if property_name not in self.public.controllable_properties:
                raise ValueError("intervention target is not publicly controllable")
            config = self._authority.graph_config
            node_name = next(
                str(name)
                for name, node in config["nodes"].items()
                if _node_property(str(name), node) == property_name
            )
            current = compute_causalab_values(config, self._base_values)
            node = config["nodes"][node_name]
            if node.get("computation"):
                contribution = current[node_name] - self._base_values[node_name]
                self._base_values[node_name] = round(value - contribution, 6)
            else:
                self._base_values[node_name] = round(value, 6)
            observed = _property_values(
                config, compute_causalab_values(config, self._base_values)
            )
            record = CausaLabObservation(
                sequence=len(self.records) + 1,
                intervention_property=property_name,
                intervention_value=value,
                values=observed,
            )
            self.records.append(record)
            return record
        except Exception:
            self.failed_attempts += 1
            raise


def normalize_edges(edges: Iterable[Any]) -> frozenset[Tuple[str, str]]:
    result = set()
    for edge in edges:
        if isinstance(edge, Mapping):
            source, target = edge.get("from"), edge.get("to")
        elif isinstance(edge, Sequence) and not isinstance(edge, (str, bytes)) and len(edge) == 2:
            source, target = edge
        else:
            raise ValueError("predicted edge is invalid")
        source, target = str(source or ""), str(target or "")
        if not source or not target or source == target:
            raise ValueError("predicted edge is invalid")
        result.add((source, target))
    return frozenset(result)


@dataclass(frozen=True)
class CausaLabConclusion:
    predicted_frequency: float
    edges: Tuple[Tuple[str, str], ...]

    def __post_init__(self) -> None:
        _finite_number(self.predicted_frequency, "predicted frequency")
        normalize_edges(self.edges)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "predicted_frequency": float(self.predicted_frequency),
            "edges": [
                {"from": source, "to": target}
                for source, target in sorted(normalize_edges(self.edges))
            ],
        }


@dataclass(frozen=True)
class CausaLabScore:
    prediction_correct: bool
    absolute_error: float
    edge_precision: float
    edge_recall: float
    edge_f1: float
    exact_graph: bool
    intervention_coverage: float
    invalid_attempts: int
    valid_resolution: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "prediction_correct": self.prediction_correct,
            "absolute_error": self.absolute_error,
            "edge_precision": self.edge_precision,
            "edge_recall": self.edge_recall,
            "edge_f1": self.edge_f1,
            "exact_graph": self.exact_graph,
            "intervention_coverage": self.intervention_coverage,
            "invalid_attempts": self.invalid_attempts,
            "valid_resolution": self.valid_resolution,
        }


def score_causalab_conclusion(
    public: CausaLabPublicTask,
    authority: CausaLabTaskAuthority,
    instrument: CausaLabInstrument,
    conclusion: CausaLabConclusion,
) -> CausaLabScore:
    if public.public_task_id != authority.public_task_id:
        raise ValueError("CausaLab score inputs do not match")
    predicted = normalize_edges(conclusion.edges)
    node_to_property = {
        str(name): _node_property(str(name), node)
        for name, node in authority.graph_config["nodes"].items()
    }
    truth = frozenset(
        (node_to_property[str(edge["from"])], node_to_property[str(edge["to"])])
        for edge in authority.graph_config["edges"]
    )
    correct = len(predicted & truth)
    precision = correct / len(predicted) if predicted else (1.0 if not truth else 0.0)
    recall = correct / len(truth) if truth else (1.0 if not predicted else 0.0)
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    exact = predicted == truth
    targets = {record.intervention_property for record in instrument.records}
    coverage = len(targets) / len(public.controllable_properties)
    error = abs(float(conclusion.predicted_frequency) - authority.target_frequency)
    prediction_correct = error <= public.frequency_tolerance
    valid = all(
        (
            prediction_correct,
            exact,
            coverage == 1.0,
            instrument.failed_attempts == 0,
            instrument.calls_used <= public.intervention_budget,
        )
    )
    return CausaLabScore(
        prediction_correct=prediction_correct,
        absolute_error=error,
        edge_precision=precision,
        edge_recall=recall,
        edge_f1=f1,
        exact_graph=exact,
        intervention_coverage=coverage,
        invalid_attempts=instrument.failed_attempts,
        valid_resolution=valid,
    )
