from __future__ import annotations

import random
import secrets
from dataclasses import dataclass, replace
from typing import Any, Dict, Mapping, Tuple

from scientist.autonomy.causalab_external import (
    CausaLabPublicTask,
    CausaLabTaskAuthority,
    compute_causalab_values,
    deterministic_base_values,
    load_released_causalab_task,
    validate_causalab_graph_config,
)
from scientist.core.artifacts import content_digest


CAUSALAB_GENERATOR_VERSION = "prospective-causalab-task-generator-v1"
_PROPERTIES = (
    "temperatureC",
    "moisture",
    "density",
    "quantumSize",
    "radiation",
    "pressure",
    "ph",
    "conductivity",
)
_DISPLAY = {
    "temperatureC": "Temperature (C)",
    "moisture": "Moisture",
    "density": "Density",
    "quantumSize": "Quantum Size",
    "radiation": "Radiation",
    "pressure": "Pressure",
    "ph": "pH",
    "conductivity": "Conductivity",
    "resonanceFreq": "Resonance Frequency (Hz)",
}


@dataclass(frozen=True)
class CausaLabGenerationSpec:
    tier: str
    node_count: int
    intervention_budget: int
    extra_edge_probability: float
    allow_frequency_parent: bool

    def __post_init__(self) -> None:
        if self.tier not in {"L1", "L2", "L3"}:
            raise ValueError("prospective CausaLab tier must be L1, L2, or L3")
        if not 3 <= self.node_count <= 7:
            raise ValueError("prospective CausaLab node count must be 3 through 7")
        if self.intervention_budget < 2 * (self.node_count - 1):
            raise ValueError("prospective CausaLab intervention budget is too small")
        if not 0.0 <= self.extra_edge_probability <= 1.0:
            raise ValueError("prospective CausaLab edge probability is invalid")

    @property
    def spec_id(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": CAUSALAB_GENERATOR_VERSION,
            "tier": self.tier,
            "node_count": self.node_count,
            "intervention_budget": self.intervention_budget,
            "extra_edge_probability": self.extra_edge_probability,
            "allow_frequency_parent": self.allow_frequency_parent,
        }


def default_generation_spec(tier: str, node_count: int) -> CausaLabGenerationSpec:
    settings = {
        "L1": (0.10, False),
        "L2": (0.25, False),
        # Frequency-as-parent is retained for labeled transport stress tests,
        # not the primary panel: frequency cannot be intervened on, so arbitrary
        # outgoing frequency edges are not guaranteed identifiable.
        "L3": (0.35, False),
    }
    if tier not in settings:
        raise ValueError("unknown prospective CausaLab tier")
    probability, allow_frequency_parent = settings[tier]
    return CausaLabGenerationSpec(
        tier=tier,
        node_count=node_count,
        intervention_budget=4 * (node_count - 1),
        extra_edge_probability=probability,
        allow_frequency_parent=allow_frequency_parent,
    )


def _random_dag(rng: random.Random, spec: CausaLabGenerationSpec) -> Tuple[Tuple[str, ...], Tuple[Tuple[str, str], ...]]:
    selected = list(rng.sample(_PROPERTIES, spec.node_count - 1))
    rng.shuffle(selected)
    if spec.allow_frequency_parent:
        insertion = rng.randint(1, len(selected) - 1)
        order = selected[:insertion] + ["resonanceFreq"] + selected[insertion:]
    else:
        order = selected + ["resonanceFreq"]
    edges = set()
    for index in range(1, len(order)):
        child = order[index]
        edges.add((rng.choice(order[:index]), child))
        for parent in order[:index]:
            if (parent, child) not in edges and rng.random() < spec.extra_edge_probability:
                edges.add((parent, child))
    if not any(target == "resonanceFreq" for _, target in edges):
        position = order.index("resonanceFreq")
        edges.add((rng.choice(order[:position]), "resonanceFreq"))
    if spec.allow_frequency_parent and not any(
        source == "resonanceFreq" for source, _ in edges
    ):
        position = order.index("resonanceFreq")
        edges.add(("resonanceFreq", rng.choice(order[position + 1 :])))
    return tuple(order), tuple(sorted(edges))


def _graph_config(seed: int, spec: CausaLabGenerationSpec) -> Mapping[str, Any]:
    rng = random.Random(int(seed))
    for attempt in range(100):
        order, edges = _random_dag(rng, spec)
        parents = {name: [] for name in order}
        for source, target in edges:
            parents[target].append(source)
        insertion_order = list(order)
        rng.shuffle(insertion_order)
        nodes: Dict[str, Dict[str, Any]] = {}
        params: Dict[str, float] = {}
        for name in insertion_order:
            controllable = name != "resonanceFreq"
            node: Dict[str, Any] = {
                "is_controllable": controllable,
                "observable": True,
                "property_name": name,
                "display_name": _DISPLAY[name],
            }
            if controllable:
                node["base_value"] = {"type": "uniform", "min": 15.0, "max": 45.0}
            incoming = sorted(parents[name])
            if incoming or not controllable:
                base_name = f"base_{name}"
                params[base_name] = float(rng.randint(15, 25))
                terms = [base_name]
                for source in incoming:
                    coefficient = f"coeff_{source}_{name}"
                    params[coefficient] = float(rng.choice((1, 1, 2)))
                    terms.append(f"{coefficient} * {source}")
                node["computation"] = " + ".join(terms)
            nodes[name] = node
        config = {
            "graph_id": "sealed-" + content_digest(
                {
                    "generator": CAUSALAB_GENERATOR_VERSION,
                    "seed": int(seed),
                    "attempt": attempt,
                }
            )[:24],
            "description": "Prospectively generated CausaLab-compatible causal graph",
            "nodes": nodes,
            "edges": [{"from": source, "to": target} for source, target in edges],
            "params": params,
            "budget": spec.intervention_budget,
            "equation_family": "linear",
            "frequency_can_be_parent": spec.allow_frequency_parent,
            "generator": {
                "version": CAUSALAB_GENERATOR_VERSION,
                "spec_id": spec.spec_id,
                "attempt": attempt,
            },
        }
        validate_causalab_graph_config(config)
        safe = True
        for role in ("manipulator", "reactor", "qualification-low", "qualification-high"):
            bases = deterministic_base_values(config, seed + attempt, role)
            values = compute_causalab_values(config, bases)
            frequency = values["resonanceFreq"]
            if not 0.0 <= frequency <= 9500.0 or any(abs(value) > 9500 for value in values.values()):
                safe = False
                break
        if safe:
            return config
    raise RuntimeError("unable to sample a numerically bounded prospective CausaLab graph")


@dataclass(frozen=True)
class DevelopmentGeneratedCausaLabTask:
    public: CausaLabPublicTask
    authority: CausaLabTaskAuthority
    generation_spec: CausaLabGenerationSpec
    generation_receipt: Mapping[str, Any]

    @property
    def task_generation_id(self) -> str:
        return content_digest(self.as_dict(include_authority=True))

    def as_dict(self, include_authority: bool = False) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_GENERATOR_VERSION,
            "public": self.public.as_dict(),
            "generation_spec": self.generation_spec.as_dict(),
            "generation_receipt": dict(self.generation_receipt),
        }
        if include_authority:
            value["development_authority"] = self.authority.as_dict()
        return value


def generate_development_causalab_task(
    *, seed: int, tier: str, node_count: int
) -> DevelopmentGeneratedCausaLabTask:
    """Generate a reproducible development task; never a confirmatory authority."""

    if isinstance(seed, bool) or int(seed) != seed:
        raise ValueError("prospective CausaLab seed must be an integer")
    spec = default_generation_spec(tier, node_count)
    config = _graph_config(int(seed), spec)
    source_ref = (
        f"{CAUSALAB_GENERATOR_VERSION}:{spec.spec_id}:"
        f"development-seed-{content_digest({'seed': int(seed)})[:16]}"
    )
    prototype, _ = load_released_causalab_task(
        config,
        environment_seed=int(seed),
        source_ref=source_ref,
        initial_observation_count=2,
    )
    public = replace(
        prototype,
        episode_ref="development-" + content_digest(
            {"spec_id": spec.spec_id, "seed": int(seed), "nonce": "fixed"}
        )[:32],
        source_family="CausaLab-v0.0.2-prospective-compatible-grammar",
        development_only=True,
    )
    authority = CausaLabTaskAuthority(
        public_task_id=public.public_task_id,
        graph_config=config,
        manipulator_base_values=deterministic_base_values(config, int(seed), "manipulator"),
        reactor_base_values=deterministic_base_values(config, int(seed), "reactor"),
        environment_seed=int(seed),
        source_ref=source_ref,
        development_only=True,
    )
    receipt = {
        "generator_version": CAUSALAB_GENERATOR_VERSION,
        "spec_id": spec.spec_id,
        "seed_commitment": content_digest({"seed": int(seed)}),
        "graph_commitment": content_digest(config),
        "development_only": True,
        "confirmatory_generation_permitted": False,
    }
    return DevelopmentGeneratedCausaLabTask(public, authority, spec, receipt)


@dataclass(frozen=True)
class SequesteredGeneratedCausaLabTask:
    """A provider-created task whose authority must remain outside the worker."""

    public: CausaLabPublicTask
    authority: CausaLabTaskAuthority
    generation_spec: CausaLabGenerationSpec
    generation_receipt: Mapping[str, Any]

    @property
    def task_generation_id(self) -> str:
        return content_digest(self.as_dict(include_authority=True))

    def as_dict(self, include_authority: bool = False) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_GENERATOR_VERSION,
            "public": self.public.as_dict(),
            "generation_spec": self.generation_spec.as_dict(),
            "generation_receipt": dict(self.generation_receipt),
        }
        if include_authority:
            value["sequestered_authority"] = self.authority.as_dict()
        return value


def generate_sequestered_causalab_task(
    *,
    seed: int,
    tier: str,
    node_count: int,
    episode_ref: str,
    confirmatory_authorization_id: str,
) -> SequesteredGeneratedCausaLabTask:
    """Generate one post-audit task for an independently provisioned panel.

    The authorization token is a provenance guard rather than a secret.  The
    provider module validates the signed audit release and passes the identified
    provider commitment while retaining the returned authority in its private
    bundle.
    """

    if (
        not isinstance(confirmatory_authorization_id, str)
        or len(confirmatory_authorization_id) != 64
        or any(character not in "0123456789abcdef" for character in confirmatory_authorization_id)
    ):
        raise ValueError("sequestered CausaLab generation requires an identified authorization")
    if isinstance(seed, bool) or int(seed) != seed:
        raise ValueError("prospective CausaLab seed must be an integer")
    if not isinstance(episode_ref, str) or not episode_ref.startswith("transport-"):
        raise ValueError("sequestered CausaLab episode_ref must be opaque transport identity")

    spec = default_generation_spec(tier, node_count)
    config = _graph_config(int(seed), spec)
    source_ref = (
        f"{CAUSALAB_GENERATOR_VERSION}:{spec.spec_id}:"
        f"sequestered-{content_digest({'seed': int(seed), 'authorization': confirmatory_authorization_id})[:20]}"
    )
    prototype, _ = load_released_causalab_task(
        config,
        environment_seed=int(seed),
        source_ref=source_ref,
        initial_observation_count=2,
    )
    public = replace(
        prototype,
        episode_ref=episode_ref,
        source_family="CausaLab-v0.0.2-prospective-compatible-grammar",
        development_only=False,
    )
    authority = CausaLabTaskAuthority(
        public_task_id=public.public_task_id,
        graph_config=config,
        manipulator_base_values=deterministic_base_values(config, int(seed), "manipulator"),
        reactor_base_values=deterministic_base_values(config, int(seed), "reactor"),
        environment_seed=int(seed),
        source_ref=source_ref,
        development_only=False,
    )
    receipt = {
        "generator_version": CAUSALAB_GENERATOR_VERSION,
        "spec_id": spec.spec_id,
        "seed_commitment": content_digest({"seed": int(seed)}),
        "graph_commitment": content_digest(config),
        "development_only": False,
        "confirmatory_generation_permitted": True,
        "authorization_id": confirmatory_authorization_id,
    }
    return SequesteredGeneratedCausaLabTask(public, authority, spec, receipt)


def fresh_secret_seed() -> int:
    """Return a cryptographic seed for a future sequestered provider.

    Calling this helper creates no task or authority.  Confirmatory code must
    live in a separately audited process and is intentionally absent here.
    """

    return secrets.randbits(128)
