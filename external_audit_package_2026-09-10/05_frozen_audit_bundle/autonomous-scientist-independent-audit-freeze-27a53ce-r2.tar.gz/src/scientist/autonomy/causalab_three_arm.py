from __future__ import annotations

import math
from dataclasses import dataclass, replace
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.autonomy.authority_contracts import authority_contract
from scientist.autonomy.causalab_external import (
    CausaLabInstrument,
    CausaLabObservation,
    CausaLabPublicTask,
    FREQUENCY_PROPERTY,
    normalize_edges,
)
from scientist.autonomy.causalab_validity import CausaLabConclusionV2
from scientist.core.artifacts import content_digest
from scientist.program.research_kernel import ResearchActionKind


CAUSALAB_THREE_ARM_VERSION = "causalab-three-arm-contract-v4"
ARM_FREE = "free_monolithic_codex"
ARM_PROMPT_EQUATED = "prompt_equated_monolithic_codex"
ARM_SCIENTIST = "authority_separated_scientist"
ARM_KINDS = (ARM_FREE, ARM_PROMPT_EQUATED, ARM_SCIENTIST)


# This exact string is inserted byte-for-byte into the prompt-equated and
# authority-separated prompts.  It states the public method; it contains no
# task answer, generator information, or scoring authority.
METHOD_POLICY_APPENDIX = """ANSWER-BLIND METHOD POLICY
Call the instrument once with exactly two distinct values per controllable
variable. Infer a public-variable DAG and the direct linear resonanceFreq
equation, distinguishing direct from total effects. Apply that equation to the
target. Cite evidence refs and promote only if graph, equation, prediction,
paired coverage, and accounting agree; otherwise abstain."""


def causalab_model_public_packet(public: CausaLabPublicTask) -> Mapping[str, Any]:
    """Compact, byte-stable model view with no loss of scientific information."""

    return {
        "variables": list(public.variable_names),
        "controllable": list(public.controllable_properties),
        "observable": list(public.observable_properties),
        "equation_family": public.equation_family,
        "starting": [
            {"ref": f"s{index}", "values": dict(sorted(item.values.items()))}
            for index, item in enumerate(public.starting_observations, start=1)
        ],
        "target": dict(sorted(public.target_properties.items())),
        "intervention_budget": public.intervention_budget,
        "frequency_tolerance": public.frequency_tolerance,
    }


def causalab_conclusion_schema() -> Mapping[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "disposition": {"type": "string", "enum": ["promote", "abstain"]},
            "predicted_frequency": {"type": ["number", "null"]},
            "edges": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "from": {"type": "string"},
                        "to": {"type": "string"},
                    },
                    "required": ["from", "to"],
                    "additionalProperties": False,
                },
            },
            "frequency_intercept": {"type": ["number", "null"]},
            "frequency_coefficients": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "property_name": {"type": "string"},
                        "coefficient": {"type": "number"},
                    },
                    "required": ["property_name", "coefficient"],
                    "additionalProperties": False,
                },
            },
            "support_observation_ids": {
                "type": "array",
                "items": {
                    "type": "string",
                    "pattern": "^(s|i)[1-9][0-9]*$",
                },
            },
            "rationale": {"type": "string", "minLength": 1},
        },
        "required": [
            "disposition",
            "predicted_frequency",
            "edges",
            "frequency_intercept",
            "frequency_coefficients",
            "support_observation_ids",
            "rationale",
        ],
        "additionalProperties": False,
    }


def parse_causalab_conclusion(value: Mapping[str, Any]) -> CausaLabConclusionV2:
    if not isinstance(value, Mapping):
        raise ValueError("CausaLab conclusion must be a JSON object")
    expected = set(causalab_conclusion_schema()["required"])
    if set(value) != expected:
        raise ValueError("CausaLab conclusion fields differ from the frozen schema")
    raw_edges = value["edges"]
    if not isinstance(raw_edges, list):
        raise ValueError("CausaLab conclusion edges must be an array")
    edges = []
    for edge in raw_edges:
        if not isinstance(edge, Mapping) or set(edge) != {"from", "to"}:
            raise ValueError("CausaLab conclusion edge is malformed")
        edges.append((str(edge["from"]), str(edge["to"])))
    raw_coefficients = value["frequency_coefficients"]
    if not isinstance(raw_coefficients, list):
        raise ValueError("CausaLab frequency coefficients must be an array")
    coefficients: Dict[str, float] = {}
    for item in raw_coefficients:
        if not isinstance(item, Mapping) or set(item) != {
            "property_name",
            "coefficient",
        }:
            raise ValueError("CausaLab frequency coefficient is malformed")
        property_name = str(item["property_name"])
        if property_name in coefficients:
            raise ValueError("CausaLab frequency coefficient is duplicated")
        coefficients[property_name] = float(item["coefficient"])
    raw_support = value["support_observation_ids"]
    if not isinstance(raw_support, list):
        raise ValueError("CausaLab support identifiers must be an array")
    return CausaLabConclusionV2(
        disposition=str(value["disposition"]),
        predicted_frequency=value["predicted_frequency"],
        edges=tuple(edges),
        frequency_intercept=value["frequency_intercept"],
        frequency_coefficients=coefficients,
        support_observation_ids=tuple(str(item) for item in raw_support),
        rationale=str(value["rationale"]),
    )


def causalab_batch_tool_schema() -> Mapping[str, Any]:
    """The byte-identical scientific instrument schema used by all arms."""

    return {
        "type": "object",
        "properties": {
            "i": {
                "type": "array",
                "minItems": 1,
                "maxItems": 24,
                "items": {
                    "type": "object",
                    "properties": {
                        "p": {"type": "string"},
                        "x": {"type": "number"},
                    },
                    "required": ["p", "x"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["i"],
        "additionalProperties": False,
    }


@dataclass(frozen=True)
class CausaLabInstrumentAttempt:
    sequence: int
    request_id: str
    requested_property: Optional[str]
    requested_value: Optional[float]
    source: str
    succeeded: bool
    observation: Optional[CausaLabObservation]
    failure: Optional[str]

    @property
    def attempt_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_THREE_ARM_VERSION,
            "sequence": self.sequence,
            "request_id": self.request_id,
            "requested_property": self.requested_property,
            "requested_value": self.requested_value,
            "source": self.source,
            "succeeded": self.succeeded,
            "observation": (
                None if self.observation is None else self.observation.as_dict()
            ),
            "failure": self.failure,
        }
        if include_id:
            value["attempt_id"] = self.attempt_id
        return value


@dataclass(frozen=True)
class CausaLabBatchRecord:
    sequence: int
    request_id: str
    arm_kind: str
    repaired_by_policy: bool
    submitted_count: int
    executed_count: int
    attempt_ids: Tuple[str, ...]
    failure: Optional[str]

    @property
    def batch_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_THREE_ARM_VERSION,
            "sequence": self.sequence,
            "request_id": self.request_id,
            "arm_kind": self.arm_kind,
            "repaired_by_policy": self.repaired_by_policy,
            "submitted_count": self.submitted_count,
            "executed_count": self.executed_count,
            "attempt_ids": list(self.attempt_ids),
            "failure": self.failure,
        }
        if include_id:
            value["batch_id"] = self.batch_id
        return value


def _finite(value: Any) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("intervention value must be numeric")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("intervention value must be finite")
    return number


def _parse_schedule(payload: Any) -> Tuple[Tuple[str, float], ...]:
    if not isinstance(payload, Mapping) or set(payload) != {"i"}:
        raise ValueError("batch request must contain only i")
    interventions = payload["i"]
    if not isinstance(interventions, list) or not interventions:
        raise ValueError("interventions must be a non-empty array")
    result = []
    for item in interventions:
        if not isinstance(item, Mapping) or set(item) != {"p", "x"}:
            raise ValueError("intervention entry is malformed")
        result.append((str(item["p"]), _finite(item["x"])))
    return tuple(result)


def _coverage_complete(
    schedule: Sequence[Tuple[str, float]], public: CausaLabPublicTask
) -> bool:
    return all(
        len({value for name, value in schedule if name == property_name}) >= 2
        for property_name in public.controllable_properties
    )


def canonical_paired_schedule(
    public: CausaLabPublicTask,
) -> Tuple[Tuple[str, float], ...]:
    return tuple(
        (property_name, value)
        for property_name in public.controllable_properties
        for value in (0.0, 100.0)
    )


def causalab_batch_payload(
    schedule: Sequence[Tuple[str, float]],
) -> Mapping[str, Any]:
    return {"i": [{"p": name, "x": value} for name, value in schedule]}


def resolve_model_evidence_references(
    public: CausaLabPublicTask,
    gateway: "MatchedCausaLabInstrumentGateway",
    conclusion: CausaLabConclusionV2,
) -> CausaLabConclusionV2:
    aliases = {
        f"s{index}": item.observation_id
        for index, item in enumerate(public.starting_observations, start=1)
    }
    aliases.update(
        {
            f"i{index}": item.observation.observation_id
            for index, item in enumerate(gateway.attempts, start=1)
            if item.succeeded and item.observation is not None
        }
    )
    return replace(
        conclusion,
        support_observation_ids=tuple(
            aliases.get(identifier, identifier)
            for identifier in conclusion.support_observation_ids
        ),
    )


class MatchedCausaLabInstrumentGateway:
    """One-batch public instrument, with treatment only at the policy boundary.

    The underlying CausaLab instrument and returned measurements are identical
    across arms.  The Scientist arm adds an answer-blind admissibility/recovery
    gate: malformed, illegal, under-covered, or over-budget schedules are replaced
    before execution by the frozen paired schedule.  The controls execute their
    submitted legal entries directly.  This is the predeclared architectural
    treatment, not additional scientific information.
    """

    def __init__(
        self,
        public: CausaLabPublicTask,
        instrument: CausaLabInstrument,
        arm_kind: str,
    ) -> None:
        if arm_kind not in ARM_KINDS:
            raise ValueError("unknown CausaLab evaluation arm")
        if public.public_task_id != instrument.public.public_task_id:
            raise ValueError("instrument gateway inputs do not match")
        self.public = public
        self.instrument = instrument
        self.arm_kind = arm_kind
        self.attempts: list[CausaLabInstrumentAttempt] = []
        self.batches: list[CausaLabBatchRecord] = []

    def _failed_attempt(
        self,
        request_id: str,
        failure: str,
        *,
        property_name: Optional[str] = None,
        target_value: Optional[float] = None,
    ) -> CausaLabInstrumentAttempt:
        self.instrument.failed_attempts += 1
        attempt = CausaLabInstrumentAttempt(
            sequence=len(self.attempts) + 1,
            request_id=request_id,
            requested_property=property_name,
            requested_value=target_value,
            source="model_submitted",
            succeeded=False,
            observation=None,
            failure=failure,
        )
        self.attempts.append(attempt)
        return attempt

    def handle(self, payload: Any) -> Tuple[int, Mapping[str, Any]]:
        request_id = content_digest(
            {"sequence": len(self.batches) + 1, "payload": payload}
        )
        if self.batches:
            attempt = self._failed_attempt(
                request_id, "only one batch invocation is permitted"
            )
            batch = CausaLabBatchRecord(
                sequence=len(self.batches) + 1,
                request_id=request_id,
                arm_kind=self.arm_kind,
                repaired_by_policy=False,
                submitted_count=0,
                executed_count=0,
                attempt_ids=(attempt.attempt_id,),
                failure=attempt.failure,
            )
            self.batches.append(batch)
            return 429, {"error": attempt.failure, "request_id": request_id}

        parse_failure = None
        try:
            submitted = _parse_schedule(payload)
        except (TypeError, ValueError) as error:
            submitted = ()
            parse_failure = str(error)

        repaired = False
        if self.arm_kind == ARM_SCIENTIST:
            legal = bool(
                submitted
                and len(submitted) == 2 * len(self.public.controllable_properties)
                and all(
                    name in self.public.controllable_properties
                    for name, _ in submitted
                )
                and _coverage_complete(submitted, self.public)
            )
            if not legal:
                submitted = canonical_paired_schedule(self.public)
                repaired = True
                parse_failure = None
        elif parse_failure is not None:
            attempt = self._failed_attempt(request_id, parse_failure)
            batch = CausaLabBatchRecord(
                sequence=1,
                request_id=request_id,
                arm_kind=self.arm_kind,
                repaired_by_policy=False,
                submitted_count=0,
                executed_count=0,
                attempt_ids=(attempt.attempt_id,),
                failure=parse_failure,
            )
            self.batches.append(batch)
            return 400, {"error": parse_failure, "request_id": request_id}

        original_count = (
            len(payload.get("i", []))
            if isinstance(payload, Mapping)
            and isinstance(payload.get("i"), list)
            else 0
        )
        request_attempts = []
        responses = []
        for property_name, target_value in submitted:
            source = "policy_repair" if repaired else "model_submitted"
            try:
                observation = self.instrument.intervene(property_name, target_value)
            except Exception as error:  # instrument owns failure accounting
                attempt = CausaLabInstrumentAttempt(
                    sequence=len(self.attempts) + 1,
                    request_id=request_id,
                    requested_property=property_name,
                    requested_value=target_value,
                    source=source,
                    succeeded=False,
                    observation=None,
                    failure=str(error),
                )
                responses.append(
                    {
                        "property_name": property_name,
                        "target_value": target_value,
                        "error": str(error),
                    }
                )
            else:
                attempt = CausaLabInstrumentAttempt(
                    sequence=len(self.attempts) + 1,
                    request_id=request_id,
                    requested_property=property_name,
                    requested_value=target_value,
                    source=source,
                    succeeded=True,
                    observation=observation,
                    failure=None,
                )
                responses.append(observation.as_dict())
            self.attempts.append(attempt)
            request_attempts.append(attempt)
        failure = next(
            (item.failure for item in request_attempts if not item.succeeded), None
        )
        batch = CausaLabBatchRecord(
            sequence=1,
            request_id=request_id,
            arm_kind=self.arm_kind,
            repaired_by_policy=repaired,
            submitted_count=original_count,
            executed_count=sum(item.succeeded for item in request_attempts),
            attempt_ids=tuple(item.attempt_id for item in request_attempts),
            failure=failure,
        )
        self.batches.append(batch)
        status = 200 if failure is None else 400
        columns = (
            "ref",
            "p",
            "x",
        ) + tuple(self.public.observable_properties)
        rows = []
        for response in responses:
            if "error" in response:
                rows.append(
                    [
                        None,
                        response.get("property_name"),
                        response.get("target_value"),
                    ]
                    + [None] * len(self.public.observable_properties)
                )
            else:
                rows.append(
                    [
                        f"i{len(rows) + 1}",
                        response["intervention_property"],
                        response["intervention_value"],
                    ]
                    + [
                        response["values"][name]
                        for name in self.public.observable_properties
                    ]
                )
        return status, {
            "k": list(columns),
            "z": rows,
            "n": self.instrument.calls_used,
            "B": self.public.intervention_budget,
            "repair": repaired,
        }


_LIFECYCLE_ORDER = (
    ResearchActionKind.FREEZE_MISSION,
    ResearchActionKind.SURVEY_PRIOR_ART,
    ResearchActionKind.REPRODUCE_INCUMBENT,
    ResearchActionKind.MAP_PHENOMENON,
    ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS,
    ResearchActionKind.INVENT_LATENT_CONCEPT,
    ResearchActionKind.VALIDATE_LATENT_CONCEPT,
    ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT,
    ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM,
    ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION,
    ResearchActionKind.MAKE_PROGRAM_DECISION,
    ResearchActionKind.REPORT_TERMINAL,
)


@dataclass(frozen=True)
class CausaLabLifecycleStageRecord:
    ordinal: int
    action_kind: str
    commit_actor_kind: str
    commit_authority_scope: str
    source_artifact_ids: Tuple[str, ...]
    outcome: str
    details: Mapping[str, Any]

    @property
    def stage_record_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_THREE_ARM_VERSION,
            "ordinal": self.ordinal,
            "action_kind": self.action_kind,
            "commit_actor_kind": self.commit_actor_kind,
            "commit_authority_scope": self.commit_authority_scope,
            "source_artifact_ids": list(self.source_artifact_ids),
            "outcome": self.outcome,
            "details": dict(self.details),
        }
        if include_id:
            value["stage_record_id"] = self.stage_record_id
        return value


@dataclass(frozen=True)
class CausaLabLifecycleDecision:
    proposed_conclusion: CausaLabConclusionV2
    authorized_conclusion: CausaLabConclusionV2
    stage_records: Tuple[CausaLabLifecycleStageRecord, ...]
    public_checks: Mapping[str, bool]
    proposal_modified: bool
    promotion_authorized: bool

    @property
    def decision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_THREE_ARM_VERSION,
            "proposed_conclusion": self.proposed_conclusion.as_dict(),
            "authorized_conclusion": self.authorized_conclusion.as_dict(),
            "stage_records": [item.as_dict() for item in self.stage_records],
            "public_checks": dict(sorted(self.public_checks.items())),
            "proposal_modified": self.proposal_modified,
            "promotion_authorized": self.promotion_authorized,
        }
        if include_id:
            value["decision_id"] = self.decision_id
        return value


def _acyclic(edges: Iterable[Tuple[str, str]], nodes: Sequence[str]) -> bool:
    parents: Dict[str, set[str]] = {name: set() for name in nodes}
    for source, target in edges:
        if source not in parents or target not in parents or source == target:
            return False
        parents[target].add(source)
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(node: str) -> bool:
        if node in visiting:
            return False
        if node in visited:
            return True
        visiting.add(node)
        for parent in parents[node]:
            if not visit(parent):
                return False
        visiting.remove(node)
        visited.add(node)
        return True

    return all(visit(node) for node in nodes)


def _record(
    ordinal: int,
    action: ResearchActionKind,
    sources: Sequence[str],
    outcome: str,
    details: Mapping[str, Any],
) -> CausaLabLifecycleStageRecord:
    contract = authority_contract(action)
    return CausaLabLifecycleStageRecord(
        ordinal=ordinal,
        action_kind=action.value,
        commit_actor_kind=contract.commit_actor_kind.value,
        commit_authority_scope=contract.commit_authority_scope.value,
        source_artifact_ids=tuple(sources),
        outcome=outcome,
        details=dict(details),
    )


def authorize_scientist_conclusion(
    public: CausaLabPublicTask,
    gateway: MatchedCausaLabInstrumentGateway,
    proposal: CausaLabConclusionV2,
    *,
    accounting_reconciled: bool,
) -> CausaLabLifecycleDecision:
    """Run the twelve-stage answer-blind authority pipeline.

    This function never receives a CausaLabTaskAuthority and therefore cannot
    compare a proposal with hidden truth.  It can bind evidence, correct a
    purely mechanical equation-to-target calculation, and veto promotion.
    """

    if gateway.arm_kind != ARM_SCIENTIST:
        raise ValueError("lifecycle authority can govern only the Scientist arm")
    if gateway.public.public_task_id != public.public_task_id:
        raise ValueError("lifecycle public task and instrument trace do not match")

    try:
        edges = normalize_edges(proposal.edges)
        graph_well_formed = _acyclic(edges, public.variable_names)
    except ValueError:
        edges = frozenset()
        graph_well_formed = False
    frequency_parents = {
        source for source, target in edges if target == FREQUENCY_PROPERTY
    }
    coefficient_keys = set(proposal.frequency_coefficients)
    equation_variables_valid = bool(
        coefficient_keys
        and coefficient_keys.issubset(set(public.target_properties))
        and FREQUENCY_PROPERTY not in coefficient_keys
    )
    equation_graph_consistent = bool(
        graph_well_formed
        and equation_variables_valid
        and coefficient_keys == frequency_parents
    )
    equation_complete = bool(
        proposal.frequency_intercept is not None
        and all(math.isfinite(float(value)) for value in proposal.frequency_coefficients.values())
    )
    recomputed: Optional[float] = None
    if equation_complete and equation_variables_valid:
        recomputed = float(proposal.frequency_intercept) + sum(
            float(coefficient) * float(public.target_properties[property_name])
            for property_name, coefficient in proposal.frequency_coefficients.items()
        )
    # The frozen strict evaluator treats intervention records as the citable
    # experimental trace. Starting observations remain incumbent evidence in
    # their own lifecycle stage and are not silently promoted to intervention
    # support.
    trace_ids = tuple(
        item.observation.observation_id
        for item in gateway.attempts
        if item.succeeded and item.observation is not None
    )
    trace_set = set(trace_ids)
    citable_set = trace_set.union(
        item.observation_id for item in public.starting_observations
    )
    submitted_citations_valid = all(
        item in citable_set for item in proposal.support_observation_ids
    )
    observed_schedule = tuple(
        (str(item.requested_property), float(item.requested_value))
        for item in gateway.attempts
        if item.succeeded
        and item.requested_property is not None
        and item.requested_value is not None
    )
    coverage_complete = _coverage_complete(observed_schedule, public)
    resource_integrity = bool(
        gateway.batches
        and len(gateway.batches) == 1
        and gateway.instrument.failed_attempts == 0
        and gateway.instrument.calls_used <= public.intervention_budget
    )
    target_binding_possible = recomputed is not None and math.isfinite(recomputed)
    checks = {
        "accounting_reconciled": bool(accounting_reconciled),
        "direct_equation_matches_graph": equation_graph_consistent,
        "evidence_trace_bound": bool(trace_ids) and submitted_citations_valid,
        "graph_is_public_dag": graph_well_formed,
        "paired_intervention_coverage": coverage_complete,
        "resource_integrity": resource_integrity,
        "target_binding_possible": target_binding_possible,
    }
    authorized_promotion = bool(
        proposal.disposition == "promote" and all(checks.values())
    )
    if authorized_promotion:
        authorized = replace(
            proposal,
            predicted_frequency=recomputed,
            edges=tuple(sorted(edges)),
            support_observation_ids=trace_ids,
            rationale=(
                proposal.rationale
                + " [Authority: public DAG, equation binding, paired evidence, "
                "resource, and accounting checks passed.]"
            ),
        )
    else:
        failed = ", ".join(key for key, passed in checks.items() if not passed)
        if proposal.disposition == "abstain" and not failed:
            failed = "model elected to abstain"
        authorized = CausaLabConclusionV2(
            disposition="abstain",
            predicted_frequency=None,
            edges=tuple(sorted(edges)),
            frequency_intercept=proposal.frequency_intercept,
            frequency_coefficients=dict(proposal.frequency_coefficients),
            support_observation_ids=tuple(
                item for item in proposal.support_observation_ids if item in trace_set
            ),
            rationale="Promotion not authorized: " + (failed or "model abstention"),
        )

    public_id = public.public_task_id
    batch_ids = tuple(item.batch_id for item in gateway.batches)
    attempt_ids = tuple(item.attempt_id for item in gateway.attempts)
    proposal_id = proposal.conclusion_id
    authorized_id = authorized.conclusion_id
    stage_sources = {
        ResearchActionKind.FREEZE_MISSION: (public_id,),
        ResearchActionKind.SURVEY_PRIOR_ART: (content_digest(METHOD_POLICY_APPENDIX),),
        ResearchActionKind.REPRODUCE_INCUMBENT: tuple(
            item.observation_id for item in public.starting_observations
        ),
        ResearchActionKind.MAP_PHENOMENON: attempt_ids,
        ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS: (proposal_id,),
        ResearchActionKind.INVENT_LATENT_CONCEPT: (proposal_id,),
        ResearchActionKind.VALIDATE_LATENT_CONCEPT: attempt_ids,
        ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT: batch_ids,
        ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM: (proposal_id,),
        ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION: (proposal_id, public_id),
        ResearchActionKind.MAKE_PROGRAM_DECISION: (authorized_id,),
        ResearchActionKind.REPORT_TERMINAL: (authorized_id,),
    }
    outcomes = {
        ResearchActionKind.FREEZE_MISSION: "mission_bound",
        ResearchActionKind.SURVEY_PRIOR_ART: "method_contract_bound",
        ResearchActionKind.REPRODUCE_INCUMBENT: "starting_evidence_reproduced",
        ResearchActionKind.MAP_PHENOMENON: "intervention_trace_mapped",
        ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS: "candidate_graph_registered",
        ResearchActionKind.INVENT_LATENT_CONCEPT: "candidate_equation_registered",
        ResearchActionKind.VALIDATE_LATENT_CONCEPT: "paired_evidence_checked",
        ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT: "preoutcome_batch_plan_audited",
        ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM: "proposal_consistency_audited",
        ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION: "target_binding_audited",
        ResearchActionKind.MAKE_PROGRAM_DECISION: (
            "promotion_authorized" if authorized_promotion else "promotion_withheld"
        ),
        ResearchActionKind.REPORT_TERMINAL: "terminal_record_emitted",
    }
    records = tuple(
        _record(
            ordinal,
            action,
            stage_sources[action],
            outcomes[action],
            {
                "answer_blind": True,
                "sealed_authority_accessed": False,
                "check_digest": content_digest(checks),
            },
        )
        for ordinal, action in enumerate(_LIFECYCLE_ORDER, start=1)
    )
    return CausaLabLifecycleDecision(
        proposed_conclusion=proposal,
        authorized_conclusion=authorized,
        stage_records=records,
        public_checks=checks,
        proposal_modified=authorized.conclusion_id != proposal.conclusion_id,
        promotion_authorized=authorized_promotion,
    )


def causalab_task_prompt(public: CausaLabPublicTask, arm_kind: str) -> str:
    if arm_kind not in ARM_KINDS:
        raise ValueError("unknown CausaLab evaluation arm")
    public_json = __import__("json").dumps(
        causalab_model_public_packet(public),
        sort_keys=True,
        separators=(",", ":"),
    )
    common = (
        "Resolve the following causal research task. The only scientific instrument "
        "is research_instrument.intervene_batch. It accepts one batch, and every "
        "individual attempted intervention consumes the public intervention budget. "
        "Do not inspect files, seek hidden authority, or use other tools. Tool input "
        "is i=[{p:variable,x:value}]; output gives columns k and rows z. Cite s#/i# "
        "refs. Keep rationale under 40 words. Return one JSON object "
        "matching the supplied schema.\n\n"
        "PUBLIC TASK (IDENTICAL ACROSS ARMS):\n" + public_json
    )
    if arm_kind == ARM_FREE:
        return common
    architecture = ""
    if arm_kind == ARM_SCIENTIST:
        architecture = (
            "\n\nARCHITECTURE: Your batch plan passes through an answer-blind protocol "
            "gate. If it is inadmissible, the gate substitutes the frozen paired "
            "schedule before execution. Your final JSON is a proposal; independent "
            "public-evidence and promotion authorities may only bind mechanical "
            "evidence fields, recompute your equation at the target, or abstain."
        )
    return common + "\n\n" + METHOD_POLICY_APPENDIX + architecture


def three_arm_contract() -> Mapping[str, Any]:
    return {
        "version": CAUSALAB_THREE_ARM_VERSION,
        "arms": list(ARM_KINDS),
        "public_task_serializer": causalab_model_public_packet.__qualname__,
        "instrument_tool_name": "intervene_batch",
        "instrument_schema": causalab_batch_tool_schema(),
        "conclusion_schema": causalab_conclusion_schema(),
        "method_policy_sha256": content_digest(METHOD_POLICY_APPENDIX),
        "method_policy_byte_identical_for": [ARM_PROMPT_EQUATED, ARM_SCIENTIST],
        "scientist_lifecycle_actions": [item.value for item in _LIFECYCLE_ORDER],
        "scientist_hidden_authority_input": False,
        "scientist_answer_blind_schedule_recovery": "canonical pairs 0 and 100",
    }
