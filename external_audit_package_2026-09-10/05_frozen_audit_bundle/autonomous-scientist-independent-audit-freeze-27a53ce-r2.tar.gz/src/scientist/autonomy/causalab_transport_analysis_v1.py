from __future__ import annotations

from collections import Counter
from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_confirmatory_analysis_v1 import exact_mcnemar
from scientist.autonomy.causalab_three_arm import (
    ARM_FREE,
    ARM_PROMPT_EQUATED,
    ARM_SCIENTIST,
)
from scientist.core.artifacts import content_digest


CAUSALAB_TRANSPORT_ANALYSIS_VERSION = "causalab-transport-analysis-v1"


def analyze_causalab_transport_run(run: Mapping[str, Any]) -> Mapping[str, Any]:
    body_for_id = dict(run)
    run_id = body_for_id.pop("transport_run_id", None)
    if not run_id or content_digest(body_for_id) != run_id:
        raise ValueError("CausaLab transport run identity is invalid")
    if run.get("status") != "complete" or run.get("task_count") != 30:
        raise ValueError("CausaLab transport run is incomplete")
    task_strata = run["task_strata"]
    task_refs = sorted(task_strata)
    if len(task_refs) != 30:
        raise ValueError("CausaLab transport strata are incomplete")
    observed_cells = Counter(
        (value["tier"], int(value["node_count"]))
        for value in task_strata.values()
    )
    expected_cells = {
        (tier, node_count): 2
        for tier in ("L1", "L2", "L3")
        for node_count in (3, 4, 5, 6, 7)
    }
    if observed_cells != expected_cells:
        raise ValueError("CausaLab transport run is not the exact balanced design")
    results = run["results"]

    def outcome(task_ref: str, arm: str) -> int:
        result = results.get(f"{task_ref}|{arm}")
        return int(bool(result and result.get("score", {}).get("valid_resolution")))

    arms = (ARM_SCIENTIST, ARM_PROMPT_EQUATED, ARM_FREE)
    outcomes = {arm: [outcome(task, arm) for task in task_refs] for arm in arms}
    rates = {arm: sum(values) / 30 for arm, values in outcomes.items()}
    controls = {"prompt_equated": ARM_PROMPT_EQUATED, "free": ARM_FREE}
    contrasts: Dict[str, Any] = {}
    for name, arm in controls.items():
        contrasts[name] = {
            "control_arm": arm,
            "paired_point_difference": rates[ARM_SCIENTIST] - rates[arm],
            "mcnemar": exact_mcnemar(outcomes[ARM_SCIENTIST], outcomes[arm]),
            "inferential_role": "descriptive_positive_control_not_primary_efficacy",
        }

    tier_differences: Dict[str, Dict[str, float]] = {}
    for tier in ("L1", "L2", "L3"):
        members = [task for task in task_refs if task_strata[task]["tier"] == tier]
        if len(members) != 10:
            raise ValueError("CausaLab transport tier is not balanced")
        tier_differences[tier] = {
            name: sum(outcome(task, ARM_SCIENTIST) - outcome(task, arm) for task in members)
            / len(members)
            for name, arm in controls.items()
        }

    expected_slots = {f"{task}|{arm}" for task in task_refs for arm in arms}
    result_identities_valid = all(
        value.get("result_id")
        == content_digest({key: item for key, item in value.items() if key != "result_id"})
        for value in results.values()
    )
    token_accounts_exact = all(
        value.get("token_usage", {}).get("total_tokens")
        == value.get("token_usage", {}).get("input_tokens", -1)
        + value.get("token_usage", {}).get("output_tokens", -1)
        and bool(value.get("transcript_id"))
        for value in results.values()
    )
    failures_auditable = all(
        isinstance(value.get("type"), str) and isinstance(value.get("message"), str)
        for value in run["failures"].values()
    )
    accounting_complete = (
        set(results).union(run["failures"]) == expected_slots
        and result_identities_valid
        and token_accounts_exact
        and failures_auditable
    )
    unsupported_promotion_rates = {
        arm: sum(
            bool(
                results.get(f"{task}|{arm}", {})
                .get("score", {})
                .get("unsupported_promotion")
            )
            for task in task_refs
        )
        / 30
        for arm in arms
    }
    gates = {
        "scientist_positive_control_rate_at_least_80_percent": rates[ARM_SCIENTIST]
        >= 0.80,
        "scientist_nonnegative_vs_prompt_equated": contrasts["prompt_equated"][
            "paired_point_difference"
        ]
        >= 0,
        "scientist_nonnegative_vs_free": contrasts["free"]["paired_point_difference"]
        >= 0,
        "no_negative_tier_stratum": all(
            difference >= 0
            for row in tier_differences.values()
            for difference in row.values()
        ),
        "exact_provenance_and_accounting": accounting_complete,
        "all_90_model_results_present_without_runner_failure": set(results)
        == expected_slots
        and not run["failures"],
        "zero_human_and_no_selective_reruns": run.get("human_interventions") == 0
        and run.get("selective_reruns_performed") is False,
    }
    body: Dict[str, Any] = {
        "version": CAUSALAB_TRANSPORT_ANALYSIS_VERSION,
        "transport_run_id": run_id,
        "domain": run["domain"],
        "role": "positive_control_cross_domain_transport",
        "task_count": 30,
        "arm_episode_count": 90,
        "rates": rates,
        "contrasts": contrasts,
        "tier_differences": tier_differences,
        "unsupported_promotion_rates": unsupported_promotion_rates,
        "accounting_complete": accounting_complete,
        "gates": gates,
        "transport_gate_passed": all(gates.values()),
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "transport_analysis_id": content_digest(body)}
