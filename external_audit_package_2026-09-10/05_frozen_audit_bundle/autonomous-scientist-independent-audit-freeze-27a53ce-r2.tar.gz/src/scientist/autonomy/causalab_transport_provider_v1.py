from __future__ import annotations

import hashlib
import hmac
import random
from typing import Any, Dict, Mapping, Tuple

from scientist.autonomy.adaptive_confirmatory_provider_v1 import validate_audit_release
from scientist.autonomy.causalab_external import (
    CausaLabObservation,
    CausaLabPublicTask,
    CausaLabTaskAuthority,
)
from scientist.autonomy.causalab_generator import (
    CausaLabGenerationSpec,
    generate_sequestered_causalab_task,
)
from scientist.autonomy.causalab_three_arm import ARM_KINDS
from scientist.core.artifacts import content_digest


CAUSALAB_TRANSPORT_PROVIDER_VERSION = "causalab-transport-provider-v1"
CAUSALAB_TRANSPORT_PUBLIC_VERSION = "causalab-transport-public-bundle-v1"
CAUSALAB_TRANSPORT_PRIVATE_VERSION = "causalab-transport-private-bundle-v1"
CAUSALAB_TRANSPORT_COMMITMENT_VERSION = "causalab-transport-provider-commitment-v1"


def transport_cells() -> Tuple[Mapping[str, Any], ...]:
    cells = []
    index = 0
    for tier in ("L1", "L2", "L3"):
        for node_count in (3, 4, 5, 6, 7):
            for replicate in range(2):
                cells.append(
                    {
                        "cell_index": index,
                        "tier": tier,
                        "node_count": node_count,
                        "replicate": replicate,
                    }
                )
                index += 1
    if len(cells) != 30:
        raise AssertionError("CausaLab transport panel must contain 30 tasks")
    return tuple(cells)


def _identified(value: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"invalid {key}")
    return value


def _derive(entropy: bytes, label: str) -> bytes:
    return hmac.new(entropy, label.encode("utf-8"), hashlib.sha256).digest()


def build_causalab_transport_package(
    *,
    freeze: Mapping[str, Any],
    audit_release: Mapping[str, Any],
    provider_ref: str,
    entropy: bytes,
) -> Tuple[Mapping[str, Any], Mapping[str, Any], Mapping[str, Any]]:
    if len(entropy) < 32:
        raise ValueError("transport-provider entropy must contain at least 256 bits")
    if not provider_ref.strip():
        raise ValueError("transport provider_ref is required")
    _identified(freeze, "freeze_id")
    validate_audit_release(audit_release, expected_freeze_id=freeze["freeze_id"])
    if freeze.get("implementation_freeze_complete") is not True:
        raise ValueError("implementation is not frozen")

    authorization = content_digest(
        {
            "freeze_id": freeze["freeze_id"],
            "audit_release_id": audit_release["audit_release_id"],
            "provider_ref": provider_ref,
            "entropy_commitment": hashlib.sha256(entropy).hexdigest(),
            "domain": "CausaLab-linear-transport",
        }
    )
    cells = list(transport_cells())
    random.Random(int.from_bytes(_derive(entropy, "task-order"), "big")).shuffle(cells)
    public_records = []
    private_records = []
    for position, cell in enumerate(cells):
        seed = int.from_bytes(_derive(entropy, f"seed:{cell['cell_index']}")[:16], "big") | (1 << 127)
        episode_ref = "transport-" + _derive(
            entropy, f"episode:{cell['cell_index']}"
        ).hex()[:40]
        task_ref = "transport-task-" + _derive(
            entropy, f"task:{cell['cell_index']}"
        ).hex()[:24]
        task = generate_sequestered_causalab_task(
            seed=seed,
            tier=str(cell["tier"]),
            node_count=int(cell["node_count"]),
            episode_ref=episode_ref,
            confirmatory_authorization_id=authorization,
        )
        arm_order = list(ARM_KINDS)
        random.Random(
            int.from_bytes(_derive(entropy, f"arm-order:{cell['cell_index']}"), "big")
        ).shuffle(arm_order)
        public_records.append(
            {
                "position": position,
                "task_ref": task_ref,
                "arm_order": arm_order,
                "public_task": task.public.as_dict(),
            }
        )
        private_records.append(
            {
                "position": position,
                "task_ref": task_ref,
                "cell": cell,
                "authority": task.authority.as_dict(),
                "generation_spec": task.generation_spec.as_dict(),
                "generation_receipt": dict(task.generation_receipt),
            }
        )

    public_body: Dict[str, Any] = {
        "version": CAUSALAB_TRANSPORT_PUBLIC_VERSION,
        "freeze_id": freeze["freeze_id"],
        "audit_release_id": audit_release["audit_release_id"],
        "provider_ref": provider_ref,
        "domain": "CausaLab-v0.0.2-compatible-linear-SCM",
        "role": "positive_control_cross_domain_transport",
        "task_count": 30,
        "arm_episode_count": 90,
        "tasks": public_records,
        "authority_fields_included": False,
        "development_only": False,
    }
    public_bundle = {**public_body, "public_bundle_id": content_digest(public_body)}
    private_body: Dict[str, Any] = {
        "version": CAUSALAB_TRANSPORT_PRIVATE_VERSION,
        "freeze_id": freeze["freeze_id"],
        "public_bundle_id": public_bundle["public_bundle_id"],
        "provider_ref": provider_ref,
        "entropy_hex": entropy.hex(),
        "tasks": private_records,
        "withhold_until_each_matched_triple_is_terminal": True,
    }
    private_bundle = {**private_body, "private_bundle_id": content_digest(private_body)}
    commitment_body: Dict[str, Any] = {
        "version": CAUSALAB_TRANSPORT_COMMITMENT_VERSION,
        "status": "transport_provider_committed_outcomes_absent",
        "freeze_id": freeze["freeze_id"],
        "audit_release_id": audit_release["audit_release_id"],
        "provider_ref": provider_ref,
        "provider_independent_of_authors_and_system": True,
        "generation_authorization_id": authorization,
        "entropy_bits_minimum": 256,
        "task_count": 30,
        "arm_episode_count": 90,
        "tiers": ["L1", "L2", "L3"],
        "node_counts": [3, 4, 5, 6, 7],
        "replicates_per_cell": 2,
        "public_bundle_id": public_bundle["public_bundle_id"],
        "private_bundle_id": private_bundle["private_bundle_id"],
        "private_bundle_withheld": True,
        "confirmatory_outcomes_opened": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    commitment = {
        **commitment_body,
        "provider_commitment_id": content_digest(commitment_body),
    }
    return public_bundle, private_bundle, commitment


def _observation_from_dict(value: Mapping[str, Any]) -> CausaLabObservation:
    observation = CausaLabObservation(
        sequence=int(value["sequence"]),
        intervention_property=(
            None
            if value.get("intervention_property") is None
            else str(value["intervention_property"])
        ),
        intervention_value=(
            None
            if value.get("intervention_value") is None
            else float(value["intervention_value"])
        ),
        values={str(key): float(item) for key, item in value["values"].items()},
    )
    if value.get("observation_id") != observation.observation_id:
        raise ValueError("CausaLab observation identity mismatch")
    return observation


def public_task_from_dict(value: Mapping[str, Any]) -> CausaLabPublicTask:
    public = CausaLabPublicTask(
        episode_ref=str(value["episode_ref"]),
        variable_names=tuple(str(item) for item in value["variable_names"]),
        controllable_properties=tuple(str(item) for item in value["controllable_properties"]),
        observable_properties=tuple(str(item) for item in value["observable_properties"]),
        equation_family=str(value["equation_family"]),
        starting_observations=tuple(
            _observation_from_dict(item) for item in value["starting_observations"]
        ),
        target_properties={
            str(key): float(item) for key, item in value["target_properties"].items()
        },
        intervention_budget=int(value["intervention_budget"]),
        frequency_tolerance=float(value["frequency_tolerance"]),
        source_family=str(value["source_family"]),
        development_only=bool(value["development_only"]),
    )
    if value.get("public_task_id") != public.public_task_id:
        raise ValueError("CausaLab public task identity mismatch")
    return public


def authority_from_dict(value: Mapping[str, Any]) -> CausaLabTaskAuthority:
    authority = CausaLabTaskAuthority(
        public_task_id=str(value["public_task_id"]),
        graph_config=value["graph_config"],
        manipulator_base_values={
            str(key): float(item) for key, item in value["manipulator_base_values"].items()
        },
        reactor_base_values={
            str(key): float(item) for key, item in value["reactor_base_values"].items()
        },
        environment_seed=int(value["environment_seed"]),
        source_ref=str(value["source_ref"]),
        development_only=bool(value["development_only"]),
    )
    if value.get("authority_id") != authority.authority_id:
        raise ValueError("CausaLab authority identity mismatch")
    return authority


def validate_causalab_transport_package(
    public_bundle: Mapping[str, Any],
    private_bundle: Mapping[str, Any],
    commitment: Mapping[str, Any],
) -> Tuple[Tuple[Mapping[str, Any], CausaLabPublicTask, CausaLabTaskAuthority], ...]:
    _identified(public_bundle, "public_bundle_id")
    _identified(private_bundle, "private_bundle_id")
    _identified(commitment, "provider_commitment_id")
    if not (
        public_bundle.get("version") == CAUSALAB_TRANSPORT_PUBLIC_VERSION
        and private_bundle.get("version") == CAUSALAB_TRANSPORT_PRIVATE_VERSION
        and commitment.get("version") == CAUSALAB_TRANSPORT_COMMITMENT_VERSION
        and commitment["public_bundle_id"] == public_bundle["public_bundle_id"]
        and commitment["private_bundle_id"] == private_bundle["private_bundle_id"]
        and commitment["freeze_id"] == public_bundle["freeze_id"] == private_bundle["freeze_id"]
        and commitment["provider_ref"]
        == public_bundle["provider_ref"]
        == private_bundle["provider_ref"]
        and commitment.get("provider_independent_of_authors_and_system") is True
        and commitment.get("private_bundle_withheld") is True
        and commitment.get("confirmatory_outcomes_opened") is False
        and len(public_bundle["tasks"]) == len(private_bundle["tasks"]) == 30
    ):
        raise ValueError("CausaLab transport package identities disagree")
    try:
        entropy = bytes.fromhex(str(private_bundle["entropy_hex"]))
    except ValueError as error:
        raise ValueError("CausaLab provider entropy encoding is invalid") from error
    if len(entropy) < 32:
        raise ValueError("CausaLab provider entropy is too short")
    expected_cells = list(transport_cells())
    random.Random(int.from_bytes(_derive(entropy, "task-order"), "big")).shuffle(
        expected_cells
    )
    private_by_ref = {item["task_ref"]: item for item in private_bundle["tasks"]}
    if len(private_by_ref) != 30:
        raise ValueError("CausaLab private task references are not unique")
    records = []
    cells = []
    for expected_position, item in enumerate(public_bundle["tasks"]):
        private = private_by_ref.get(item["task_ref"])
        if (
            private is None
            or private["position"] != item["position"]
            or item["position"] != expected_position
            or private["cell"] != expected_cells[expected_position]
        ):
            raise ValueError("CausaLab public/private task alignment failed")
        cell = private["cell"]
        seed = int.from_bytes(
            _derive(entropy, f"seed:{cell['cell_index']}")[:16], "big"
        ) | (1 << 127)
        expected_episode = (
            "transport-" + _derive(entropy, f"episode:{cell['cell_index']}").hex()[:40]
        )
        expected_task_ref = (
            "transport-task-" + _derive(entropy, f"task:{cell['cell_index']}").hex()[:24]
        )
        expected_arm_order = list(ARM_KINDS)
        random.Random(
            int.from_bytes(_derive(entropy, f"arm-order:{cell['cell_index']}"), "big")
        ).shuffle(expected_arm_order)
        public = public_task_from_dict(item["public_task"])
        authority = authority_from_dict(private["authority"])
        if public.development_only or authority.development_only:
            raise ValueError("CausaLab transport task is marked development-only")
        if public.public_task_id != authority.public_task_id:
            raise ValueError("CausaLab public and authority records disagree")
        expected_task = generate_sequestered_causalab_task(
            seed=seed,
            tier=str(cell["tier"]),
            node_count=int(cell["node_count"]),
            episode_ref=expected_episode,
            confirmatory_authorization_id=commitment["generation_authorization_id"],
        )
        if not (
            item["task_ref"] == expected_task_ref
            and item["arm_order"] == expected_arm_order
            and public == expected_task.public
            and authority == expected_task.authority
        ):
            raise ValueError("CausaLab task does not reproduce from committed entropy")
        spec = CausaLabGenerationSpec(
            tier=str(private["generation_spec"]["tier"]),
            node_count=int(private["generation_spec"]["node_count"]),
            intervention_budget=int(private["generation_spec"]["intervention_budget"]),
            extra_edge_probability=float(private["generation_spec"]["extra_edge_probability"]),
            allow_frequency_parent=bool(private["generation_spec"]["allow_frequency_parent"]),
        )
        if spec.spec_id != private["generation_receipt"].get("spec_id"):
            raise ValueError("CausaLab generation-spec identity mismatch")
        if not (
            private["generation_receipt"].get("authorization_id")
            == commitment["generation_authorization_id"]
            and private["generation_receipt"].get("seed_commitment")
            == content_digest({"seed": seed})
            and private["generation_receipt"].get("graph_commitment")
            == content_digest(authority.graph_config)
        ):
            raise ValueError("CausaLab generation receipt does not reconcile")
        cells.append(private["cell"])
        records.append((item, public, authority))
    if sorted(cells, key=lambda item: item["cell_index"]) != list(transport_cells()):
        raise ValueError("CausaLab transport panel is not the committed balanced design")
    return tuple(records)
