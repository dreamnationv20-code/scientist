from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.autonomy.causalab_external import (
    CausaLabInstrument,
    CausaLabPublicTask,
    CausaLabTaskAuthority,
    FREQUENCY_PROPERTY,
    evaluate_causalab_expression,
    normalize_edges,
)
from scientist.core.artifacts import content_digest


CAUSALAB_VALIDITY_VERSION = "causalab-strict-valid-resolution-v1"


def _finite_optional(value: Optional[float], label: str) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be numeric")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{label} must be finite")
    return result


@dataclass(frozen=True)
class CausaLabConclusionV2:
    disposition: str
    predicted_frequency: Optional[float]
    edges: Tuple[Tuple[str, str], ...]
    frequency_intercept: Optional[float]
    frequency_coefficients: Mapping[str, float]
    support_observation_ids: Tuple[str, ...]
    rationale: str

    def __post_init__(self) -> None:
        if self.disposition not in {"promote", "abstain"}:
            raise ValueError("CausaLab disposition must be promote or abstain")
        _finite_optional(self.predicted_frequency, "predicted frequency")
        _finite_optional(self.frequency_intercept, "frequency intercept")
        normalize_edges(self.edges)
        for key, value in self.frequency_coefficients.items():
            if not str(key):
                raise ValueError("frequency coefficient property is empty")
            _finite_optional(value, f"frequency coefficient {key}")
        if len(self.support_observation_ids) != len(set(self.support_observation_ids)):
            raise ValueError("support observation identifiers must be unique")
        if not self.rationale.strip():
            raise ValueError("CausaLab conclusion requires a rationale")
        if self.disposition == "promote" and (
            self.predicted_frequency is None or self.frequency_intercept is None
        ):
            raise ValueError("promoted CausaLab conclusion is incomplete")

    @property
    def conclusion_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSALAB_VALIDITY_VERSION,
            "disposition": self.disposition,
            "predicted_frequency": self.predicted_frequency,
            "edges": [
                {"from": source, "to": target}
                for source, target in sorted(normalize_edges(self.edges))
            ],
            "frequency_intercept": self.frequency_intercept,
            "frequency_coefficients": {
                str(k): float(v)
                for k, v in sorted(self.frequency_coefficients.items())
            },
            "support_observation_ids": list(self.support_observation_ids),
            "rationale": self.rationale,
        }
        if include_id:
            value["conclusion_id"] = self.conclusion_id
        return value


@dataclass(frozen=True)
class CausaLabValidityScore:
    promoted: bool
    prediction_correct: bool
    absolute_error: Optional[float]
    exact_graph: bool
    edge_precision: float
    edge_recall: float
    edge_f1: float
    exact_frequency_equation: bool
    equation_target_consistent: bool
    cited_evidence_exists: bool
    paired_intervention_coverage: float
    resource_integrity: bool
    accounting_reconciled: bool
    valid_resolution: bool
    unsupported_promotion: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": CAUSALAB_VALIDITY_VERSION,
            "promoted": self.promoted,
            "prediction_correct": self.prediction_correct,
            "absolute_error": self.absolute_error,
            "exact_graph": self.exact_graph,
            "edge_precision": self.edge_precision,
            "edge_recall": self.edge_recall,
            "edge_f1": self.edge_f1,
            "exact_frequency_equation": self.exact_frequency_equation,
            "equation_target_consistent": self.equation_target_consistent,
            "cited_evidence_exists": self.cited_evidence_exists,
            "paired_intervention_coverage": self.paired_intervention_coverage,
            "resource_integrity": self.resource_integrity,
            "accounting_reconciled": self.accounting_reconciled,
            "valid_resolution": self.valid_resolution,
            "unsupported_promotion": self.unsupported_promotion,
        }


def true_frequency_equation(
    authority: CausaLabTaskAuthority,
) -> Tuple[float, Dict[str, float]]:
    config = authority.graph_config
    nodes = config["nodes"]
    frequency_name = next(
        str(name)
        for name, node in nodes.items()
        if str(node.get("property_name", name)) == FREQUENCY_PROPERTY
    )
    expression = str(nodes[frequency_name].get("computation") or "")
    if not expression:
        raise ValueError("frequency node lacks an equation")
    node_to_property = {
        str(name): str(node.get("property_name", name))
        for name, node in nodes.items()
    }
    parent_names = [
        str(edge["from"])
        for edge in config["edges"]
        if str(edge["to"]) == frequency_name
    ]
    zero = {name: 0.0 for name in parent_names}
    environment = dict(config.get("params") or {})
    environment.update(zero)
    intercept = evaluate_causalab_expression(expression, environment)
    coefficients = {}
    for parent in parent_names:
        one = dict(environment)
        one[parent] = 1.0
        coefficient = evaluate_causalab_expression(expression, one) - intercept
        two = dict(environment)
        two[parent] = 2.0
        if not math.isclose(
            evaluate_causalab_expression(expression, two) - intercept,
            2.0 * coefficient,
            abs_tol=1e-9,
            rel_tol=0.0,
        ):
            raise ValueError("strict primary evaluator requires a linear frequency equation")
        coefficients[node_to_property[parent]] = coefficient
    return intercept, coefficients


def evaluate_causalab_validity(
    public: CausaLabPublicTask,
    authority: CausaLabTaskAuthority,
    instrument: CausaLabInstrument,
    conclusion: CausaLabConclusionV2,
    *,
    accounting_reconciled: bool,
    coefficient_tolerance: float = 1e-6,
) -> CausaLabValidityScore:
    if public.public_task_id != authority.public_task_id:
        raise ValueError("CausaLab validity inputs do not match")
    if coefficient_tolerance <= 0:
        raise ValueError("coefficient tolerance must be positive")
    promoted = conclusion.disposition == "promote"
    node_to_property = {
        str(name): str(node.get("property_name", name))
        for name, node in authority.graph_config["nodes"].items()
    }
    truth = frozenset(
        (node_to_property[str(edge["from"])], node_to_property[str(edge["to"])])
        for edge in authority.graph_config["edges"]
    )
    predicted = normalize_edges(conclusion.edges)
    correct = len(predicted & truth)
    precision = correct / len(predicted) if predicted else (1.0 if not truth else 0.0)
    recall = correct / len(truth) if truth else (1.0 if not predicted else 0.0)
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    exact_graph = predicted == truth

    true_intercept, true_coefficients = true_frequency_equation(authority)
    coefficient_keys_exact = set(conclusion.frequency_coefficients) == set(
        true_coefficients
    )
    coefficients_exact = coefficient_keys_exact and all(
        math.isclose(
            float(conclusion.frequency_coefficients[key]),
            true_coefficients[key],
            abs_tol=coefficient_tolerance,
            rel_tol=0.0,
        )
        for key in true_coefficients
    )
    intercept_exact = conclusion.frequency_intercept is not None and math.isclose(
        float(conclusion.frequency_intercept),
        true_intercept,
        abs_tol=coefficient_tolerance,
        rel_tol=0.0,
    )
    exact_equation = bool(coefficients_exact and intercept_exact)

    equation_target_consistent = False
    if conclusion.predicted_frequency is not None and conclusion.frequency_intercept is not None:
        if set(conclusion.frequency_coefficients).issubset(public.target_properties):
            recomputed = float(conclusion.frequency_intercept) + sum(
                float(coefficient) * public.target_properties[property_name]
                for property_name, coefficient in conclusion.frequency_coefficients.items()
            )
            equation_target_consistent = math.isclose(
                recomputed,
                float(conclusion.predicted_frequency),
                abs_tol=coefficient_tolerance,
                rel_tol=0.0,
            )

    if conclusion.predicted_frequency is None:
        absolute_error = None
        prediction_correct = False
    else:
        absolute_error = abs(float(conclusion.predicted_frequency) - authority.target_frequency)
        prediction_correct = absolute_error <= public.frequency_tolerance

    records = {record.observation_id: record for record in instrument.records}
    cited_evidence_exists = all(
        identifier in records for identifier in conclusion.support_observation_ids
    )
    cited = [
        records[identifier]
        for identifier in conclusion.support_observation_ids
        if identifier in records
    ]
    covered = 0
    for property_name in public.controllable_properties:
        values = {
            float(record.intervention_value)
            for record in cited
            if record.intervention_property == property_name
            and record.intervention_value is not None
        }
        if len(values) >= 2:
            covered += 1
    paired_coverage = covered / len(public.controllable_properties)
    resource_integrity = bool(
        instrument.failed_attempts == 0
        and instrument.calls_used <= public.intervention_budget
    )
    scientific_checks = all(
        (
            prediction_correct,
            exact_graph,
            exact_equation,
            equation_target_consistent,
            cited_evidence_exists,
            paired_coverage == 1.0,
            resource_integrity,
            accounting_reconciled,
        )
    )
    valid_resolution = bool(promoted and scientific_checks)
    unsupported_promotion = bool(promoted and not scientific_checks)
    return CausaLabValidityScore(
        promoted=promoted,
        prediction_correct=prediction_correct,
        absolute_error=absolute_error,
        exact_graph=exact_graph,
        edge_precision=precision,
        edge_recall=recall,
        edge_f1=f1,
        exact_frequency_equation=exact_equation,
        equation_target_consistent=equation_target_consistent,
        cited_evidence_exists=cited_evidence_exists,
        paired_intervention_coverage=paired_coverage,
        resource_integrity=resource_integrity,
        accounting_reconciled=bool(accounting_reconciled),
        valid_resolution=valid_resolution,
        unsupported_promotion=unsupported_promotion,
    )
