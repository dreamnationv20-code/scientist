from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Optional

from scientist.autonomy.causalab_external import (
    CausaLabInstrument,
    CausaLabPublicTask,
    CausaLabTaskAuthority,
    normalize_edges,
)
from scientist.autonomy.causalab_validity import (
    CausaLabConclusionV2,
    true_frequency_equation,
)


CAUSALAB_VALIDITY_V2_VERSION = "causalab-strict-valid-resolution-v2"


@dataclass(frozen=True)
class CausaLabValidityScoreV2:
    promoted: bool
    prediction_correct: bool
    absolute_error: Optional[float]
    exact_graph: bool
    edge_precision: float
    edge_recall: float
    edge_f1: float
    exact_frequency_equation: bool
    equation_target_consistent: bool
    cited_evidence_exists: bool
    cited_starting_observation_count: int
    cited_intervention_observation_count: int
    paired_intervention_coverage: float
    resource_integrity: bool
    accounting_reconciled: bool
    valid_resolution: bool
    unsupported_promotion: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": CAUSALAB_VALIDITY_V2_VERSION,
            "promoted": self.promoted,
            "prediction_correct": self.prediction_correct,
            "absolute_error": self.absolute_error,
            "exact_graph": self.exact_graph,
            "edge_precision": self.edge_precision,
            "edge_recall": self.edge_recall,
            "edge_f1": self.edge_f1,
            "exact_frequency_equation": self.exact_frequency_equation,
            "equation_target_consistent": self.equation_target_consistent,
            "cited_evidence_exists": self.cited_evidence_exists,
            "cited_starting_observation_count": (
                self.cited_starting_observation_count
            ),
            "cited_intervention_observation_count": (
                self.cited_intervention_observation_count
            ),
            "paired_intervention_coverage": self.paired_intervention_coverage,
            "resource_integrity": self.resource_integrity,
            "accounting_reconciled": self.accounting_reconciled,
            "valid_resolution": self.valid_resolution,
            "unsupported_promotion": self.unsupported_promotion,
        }


def evaluate_causalab_validity_v2(
    public: CausaLabPublicTask,
    authority: CausaLabTaskAuthority,
    instrument: CausaLabInstrument,
    conclusion: CausaLabConclusionV2,
    *,
    accounting_reconciled: bool,
    coefficient_tolerance: float = 1e-6,
) -> CausaLabValidityScoreV2:
    """Strict hidden scorer with protocol-correct evidence provenance.

    V1 registered only intervention observations when validating citations.
    Public starting observations are also immutable arm evidence under the
    prospective protocol. V2 admits both registries for citation existence but
    still computes paired-intervention coverage solely from interventions.
    """

    if public.public_task_id != authority.public_task_id:
        raise ValueError("CausaLab validity inputs do not match")
    if coefficient_tolerance <= 0:
        raise ValueError("coefficient tolerance must be positive")
    promoted = conclusion.disposition == "promote"
    node_to_property = {
        str(name): str(node.get("property_name", name))
        for name, node in authority.graph_config["nodes"].items()
    }
    truth = frozenset(
        (node_to_property[str(edge["from"])], node_to_property[str(edge["to"])])
        for edge in authority.graph_config["edges"]
    )
    predicted = normalize_edges(conclusion.edges)
    correct = len(predicted & truth)
    precision = correct / len(predicted) if predicted else (1.0 if not truth else 0.0)
    recall = correct / len(truth) if truth else (1.0 if not predicted else 0.0)
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    exact_graph = predicted == truth

    true_intercept, true_coefficients = true_frequency_equation(authority)
    coefficient_keys_exact = set(conclusion.frequency_coefficients) == set(
        true_coefficients
    )
    coefficients_exact = coefficient_keys_exact and all(
        math.isclose(
            float(conclusion.frequency_coefficients[key]),
            true_coefficients[key],
            abs_tol=coefficient_tolerance,
            rel_tol=0.0,
        )
        for key in true_coefficients
    )
    intercept_exact = conclusion.frequency_intercept is not None and math.isclose(
        float(conclusion.frequency_intercept),
        true_intercept,
        abs_tol=coefficient_tolerance,
        rel_tol=0.0,
    )
    exact_equation = bool(coefficients_exact and intercept_exact)

    equation_target_consistent = False
    if conclusion.predicted_frequency is not None and conclusion.frequency_intercept is not None:
        if set(conclusion.frequency_coefficients).issubset(public.target_properties):
            recomputed = float(conclusion.frequency_intercept) + sum(
                float(coefficient) * public.target_properties[property_name]
                for property_name, coefficient in conclusion.frequency_coefficients.items()
            )
            equation_target_consistent = math.isclose(
                recomputed,
                float(conclusion.predicted_frequency),
                abs_tol=coefficient_tolerance,
                rel_tol=0.0,
            )

    if conclusion.predicted_frequency is None:
        absolute_error = None
        prediction_correct = False
    else:
        absolute_error = abs(
            float(conclusion.predicted_frequency) - authority.target_frequency
        )
        prediction_correct = absolute_error <= public.frequency_tolerance

    starting = {
        record.observation_id: record for record in public.starting_observations
    }
    interventions = {
        record.observation_id: record for record in instrument.records
    }
    all_records = {**starting, **interventions}
    cited_evidence_exists = all(
        identifier in all_records for identifier in conclusion.support_observation_ids
    )
    cited_starting = sum(
        identifier in starting for identifier in conclusion.support_observation_ids
    )
    cited_interventions = [
        interventions[identifier]
        for identifier in conclusion.support_observation_ids
        if identifier in interventions
    ]
    covered = 0
    for property_name in public.controllable_properties:
        values = {
            float(record.intervention_value)
            for record in cited_interventions
            if record.intervention_property == property_name
            and record.intervention_value is not None
        }
        if len(values) >= 2:
            covered += 1
    paired_coverage = covered / len(public.controllable_properties)
    resource_integrity = bool(
        instrument.failed_attempts == 0
        and instrument.calls_used <= public.intervention_budget
    )
    scientific_checks = all(
        (
            prediction_correct,
            exact_graph,
            exact_equation,
            equation_target_consistent,
            cited_evidence_exists,
            paired_coverage == 1.0,
            resource_integrity,
            accounting_reconciled,
        )
    )
    valid_resolution = bool(promoted and scientific_checks)
    unsupported_promotion = bool(promoted and not scientific_checks)
    return CausaLabValidityScoreV2(
        promoted=promoted,
        prediction_correct=prediction_correct,
        absolute_error=absolute_error,
        exact_graph=exact_graph,
        edge_precision=precision,
        edge_recall=recall,
        edge_f1=f1,
        exact_frequency_equation=exact_equation,
        equation_target_consistent=equation_target_consistent,
        cited_evidence_exists=cited_evidence_exists,
        cited_starting_observation_count=cited_starting,
        cited_intervention_observation_count=len(cited_interventions),
        paired_intervention_coverage=paired_coverage,
        resource_integrity=resource_integrity,
        accounting_reconciled=bool(accounting_reconciled),
        valid_resolution=valid_resolution,
        unsupported_promotion=unsupported_promotion,
    )
