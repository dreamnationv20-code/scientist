from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.autonomy.state import (
    AuthoritativeResearchLedger,
    AutonomyEventKind,
)
from scientist.core.artifacts import content_digest
from scientist.program.research_kernel import (
    AutonomousResearchKernel,
    KnowledgeKind,
    ProgramDisposition,
    ScientificKnowledgeRecord,
)


CLAIM_LEDGER_VERSION = "scientist-evidence-bound-claim-ledger-v1"


class ClaimEvidenceGrade(str, Enum):
    CONTEXT = "context"
    INTERNAL = "internal"
    PROSPECTIVE = "prospective"
    REPLICATED = "replicated"


@dataclass(frozen=True)
class HarvestedClaim:
    statement: str
    evidence_grade: ClaimEvidenceGrade
    evidence_ids: Tuple[str, ...]
    source_record_ids: Tuple[str, ...]
    manuscript_eligible: bool
    nature_central_claim_eligible: bool
    limitations: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.statement or not self.evidence_ids or not self.source_record_ids:
            raise ValueError("harvested claim is incomplete")
        if self.nature_central_claim_eligible and not self.manuscript_eligible:
            raise ValueError("a central claim must first be manuscript eligible")
        if self.nature_central_claim_eligible and self.evidence_grade != (
            ClaimEvidenceGrade.REPLICATED
        ):
            raise ValueError("a Nature central claim requires replicated evidence")

    @property
    def claim_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CLAIM_LEDGER_VERSION,
            "statement": self.statement,
            "evidence_grade": self.evidence_grade.value,
            "evidence_ids": list(self.evidence_ids),
            "source_record_ids": list(self.source_record_ids),
            "manuscript_eligible": self.manuscript_eligible,
            "nature_central_claim_eligible": self.nature_central_claim_eligible,
            "limitations": list(self.limitations),
        }
        if include_id:
            value["claim_id"] = self.claim_id
        return value


@dataclass(frozen=True)
class ClaimLedger:
    run_id: str
    research_state_id: str
    authority_state_id: str
    contains_legacy_inputs: bool
    claims: Tuple[HarvestedClaim, ...]
    exclusions: Mapping[str, Tuple[str, ...]]

    @property
    def central_claim_count(self) -> int:
        return sum(item.nature_central_claim_eligible for item in self.claims)

    @property
    def ledger_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CLAIM_LEDGER_VERSION,
            "run_id": self.run_id,
            "research_state_id": self.research_state_id,
            "authority_state_id": self.authority_state_id,
            "contains_legacy_inputs": self.contains_legacy_inputs,
            "claims": [item.as_dict() for item in self.claims],
            "exclusions": {
                key: list(values) for key, values in sorted(self.exclusions.items())
            },
            "central_claim_count": self.central_claim_count,
        }
        if include_id:
            value["ledger_id"] = self.ledger_id
        return value


def _classify_record(
    record: ScientificKnowledgeRecord,
    *,
    contains_legacy_inputs: bool,
) -> Tuple[Optional[HarvestedClaim], Tuple[str, ...]]:
    limitations = []
    manuscript_eligible = True
    central = False
    grade = ClaimEvidenceGrade.INTERNAL

    if record.kind == KnowledgeKind.LITERATURE:
        grade = ClaimEvidenceGrade.CONTEXT
    elif record.status in {"unvalidated", "open", "unreproduced"}:
        manuscript_eligible = False
        limitations.append("the source record is not evidence-closed")
    elif "prospective" in record.tags:
        grade = ClaimEvidenceGrade.PROSPECTIVE
    elif record.status == "claim_eligible":
        grade = ClaimEvidenceGrade.REPLICATED
        central = True

    if contains_legacy_inputs:
        limitations.append("the run imported legacy state")
        central = False
        if grade in {ClaimEvidenceGrade.PROSPECTIVE, ClaimEvidenceGrade.REPLICATED}:
            grade = ClaimEvidenceGrade.INTERNAL

    # Proposed concepts are retained in memory, but cannot become results
    # until a separate validation record exists.
    if record.kind == KnowledgeKind.CONCEPT and record.status == "unvalidated":
        manuscript_eligible = False

    if not manuscript_eligible:
        return None, tuple(limitations)
    return (
        HarvestedClaim(
            statement=record.statement,
            evidence_grade=grade,
            evidence_ids=tuple(dict.fromkeys((record.artifact_id, *record.evidence_ids))),
            source_record_ids=(record.record_id,),
            manuscript_eligible=True,
            nature_central_claim_eligible=central,
            limitations=tuple(limitations),
        ),
        (),
    )


def harvest_claims(
    kernel: AutonomousResearchKernel,
    authority: AuthoritativeResearchLedger,
) -> ClaimLedger:
    if not authority.verify_chain():
        raise ValueError("claims cannot be harvested from an invalid authority chain")
    snapshots = tuple(
        item
        for item in authority.state.subsystem_snapshots
        if item.subsystem == "research_kernel"
    )
    if len(snapshots) != 1:
        raise ValueError("claim harvesting requires one authoritative research snapshot")
    contains_legacy = any(
        event.kind == AutonomyEventKind.LEGACY_STATE_IMPORTED
        for event in authority.events
    )
    claims = []
    exclusions: Dict[str, Tuple[str, ...]] = {}
    for record_id, record in sorted(kernel.knowledge.records.items()):
        claim, reasons = _classify_record(
            record,
            contains_legacy_inputs=contains_legacy,
        )
        if claim is None:
            exclusions[record_id] = reasons or (
                "the record is not an assertion eligible for manuscript text",
            )
        else:
            claims.append(claim)

    # A promoted central result must be represented by both the replicated
    # evaluation record and the evidence-bound program decision.
    if kernel.terminal_disposition == ProgramDisposition.PROMOTE:
        central = tuple(item for item in claims if item.nature_central_claim_eligible)
        if not central:
            raise ValueError("promotion has no replicated claim-eligible evidence")
        if not kernel.decisions or kernel.decisions[-1].disposition != (
            ProgramDisposition.PROMOTE
        ):
            raise ValueError("terminal promotion lacks its program decision")

    return ClaimLedger(
        run_id=authority.state.run_id,
        research_state_id=kernel.state_digest,
        authority_state_id=authority.state.state_id,
        contains_legacy_inputs=contains_legacy,
        claims=tuple(claims),
        exclusions=exclusions,
    )
