from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


CONFIRMATORY_RUNTIME_COMMITMENT_VERSION = "autonomous-scientist-confirmatory-runtime-commitment-v1"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has invalid {key}")
    return value


def build_confirmatory_runtime_commitment(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    primary_protocol = _identified(
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v5/artifacts/manifests/protocol-commitment-v5.json",
        "commitment_id",
    )
    runtime_amendment = _identified(
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v6/artifacts/manifests/protocol-commitment-v6.json",
        "commitment_id",
    )
    supplement_path = root / (
        "docs/autonomous-scientist-confirmatory-runtime-and-transport-supplement-2026-09-09.md"
    )
    namespaces = {
        "primary": root / "runs/autonomy_closure_v1/prospective_v6_confirmatory",
        "transport": root / "runs/autonomy_closure_v1/causalab_transport_confirmatory_v1",
        "replication": root / "runs/autonomy_closure_v1/adaptive_independent_replication_v1",
    }
    if any(path.exists() for path in namespaces.values()):
        raise ValueError("a prospective namespace exists before runtime commitment")
    body: Dict[str, Any] = {
        "version": CONFIRMATORY_RUNTIME_COMMITMENT_VERSION,
        "status": "prospective_runtime_complete_implementation_unfrozen",
        "primary_protocol_commitment_id": primary_protocol["commitment_id"],
        "runtime_amendment_commitment_id": runtime_amendment["commitment_id"],
        "supplement_path": str(supplement_path.relative_to(root)),
        "supplement_sha256": bytes_sha256(supplement_path.read_bytes()),
        "primary_task_count": 180,
        "primary_arm_episode_count": 540,
        "ablation_task_count": 90,
        "ablation_episode_count": 450,
        "transport_task_count": 30,
        "transport_arm_episode_count": 90,
        "replication_task_count": 180,
        "replication_arm_episode_count": 540,
        "primary_model_token_ceiling": 128_000,
        "transport_model_token_ceiling": 64_000,
        "wall_time_ceiling_seconds": 900,
        "primary_outcome_and_contrasts_unchanged": True,
        "development_outcomes_not_used_as_confirmatory_evidence": True,
        "all_confirmatory_namespaces_absent": True,
        "confirmatory_namespaces": {
            key: str(path.relative_to(root)) for key, path in namespaces.items()
        },
        "implementation_freeze_complete": False,
        "independent_audit_complete": False,
        "provider_execution_authorized": False,
        "confirmatory_outcomes_opened": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "runtime_commitment_id": content_digest(body)}
