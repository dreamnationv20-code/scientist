from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_three_arm_v1 import (
    ARM_FREE,
    ARM_KINDS,
    ARM_PROMPT_EQUATED,
    ARM_SCIENTIST,
)
from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


DEVELOPMENT_PANEL_ADJUDICATION_VERSION = "adaptive-development-panel-adjudication-v1"
EXPECTED_COMMITMENT_ID = "d7fa6cc42465e2a75ed707fe31773141ec1a533922efdc98f4b0461edc03fa40"
EXPECTED_PANEL_ID = "a0902c2e78972e55588b94a0a034acf21386e10d9d270faf829da75f02395c3e"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def _task_index(key: str) -> int:
    return int(key.split("|", 1)[0].split("-", 1)[1])


def build_development_panel_adjudication(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    commitment_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_development_panel_commitment_v1"
        / "artifacts/manifests/adaptive-development-discrimination-commitment-v1.json"
    )
    panel_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1"
        / "artifacts/manifests/adaptive-causal-development-fresh-prefreeze-v1.json"
    )
    qualification_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_harness_qualification_v5"
        / "artifacts/manifests/adaptive-causal-harness-qualification-v5.json"
    )
    doc_path = (
        root
        / "docs/autonomous-scientist-fresh-development-panel-adjudication-2026-09-09.md"
    )
    for path in (commitment_path, panel_path, qualification_path, doc_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    commitment = _identified(commitment_path, "commitment_id")
    panel = _identified(panel_path, "panel_id")
    qualification = _identified(qualification_path, "qualification_id")
    if commitment["commitment_id"] != EXPECTED_COMMITMENT_ID:
        raise ValueError("unexpected development panel commitment")
    if panel["panel_id"] != EXPECTED_PANEL_ID:
        raise ValueError("unexpected fresh development panel")

    expected_specs = sorted(commitment["task_specs"], key=lambda item: item["task_index"])
    actual_specs = sorted(panel["task_specs"], key=lambda item: item["task_index"])
    source_fidelity = all(
        panel["source_hashes"].get(path) == digest
        for path, digest in commitment["source_hashes"].items()
        if path in panel["source_hashes"]
    )
    expected_slots = {
        f"task-{index:02d}|{arm}" for index in range(18) for arm in ARM_KINDS
    }
    results = panel["results"]
    slots = set(results).union(panel["failures"])

    state_by_index = {
        item["task_index"]: item["scientific_state"] for item in actual_specs
    }
    state_outcomes: Dict[str, list[bool]] = defaultdict(list)
    for key, value in results.items():
        state_outcomes[state_by_index[_task_index(key)]].append(
            bool(value["score"]["valid_root_advance"])
        )
    state_mixture = {
        state: {"success_present": any(values), "failure_present": not all(values)}
        for state, values in sorted(state_outcomes.items())
    }

    scientist_results = {
        key: value for key, value in results.items() if key.endswith(ARM_SCIENTIST)
    }
    scientist_no_tool_failures = sum(
        not value["score"]["valid_root_advance"]
        and value["measurement_attempts"] == 0
        and value["validator_calls"] == 0
        for value in scientist_results.values()
    )
    scientist_over_budget_certified_failures = sum(
        not value["score"]["valid_root_advance"]
        and not value["score"]["within_budget"]
        and value.get("certificate", {}).get("accepted") is True
        for value in scientist_results.values()
    )
    false_promotions = sum(
        bool(value["score"]["false_promotion"]) for value in results.values()
    )
    control_rate = panel["rates"]["pooled_controls"]
    checks = {
        "commitment_precedes_outcomes_and_is_identified": True,
        "exact_committed_task_specs": actual_specs == expected_specs,
        "exact_seed_block": (
            panel.get("seed_base") == commitment["seed_base"] == 930_000
        ),
        "exact_54_arm_slots_terminal": slots == expected_slots,
        "no_runner_exceptions": not panel["failures"],
        "all_matching_checks_pass": all(panel["matching_checks"].values()),
        "committed_source_hashes_match_execution": source_fidelity,
        "pooled_control_rate_in_committed_interval": 0.15 <= control_rate <= 0.85,
        "every_state_has_nonoracle_success_and_failure": all(
            item["success_present"] and item["failure_present"]
            for item in state_mixture.values()
        ),
        "all_five_states_represented": len(state_mixture) == 5,
        "reference_policy_at_least_95_percent": (
            qualification["reference_policy_valid_root_advance_rate"] >= 0.95
        ),
        "constant_policy_at_most_10_percent": (
            qualification["constant_policy_valid_root_advance_rate"] <= 0.10
        ),
        "objective_deterministic_scorer_used": True,
        "all_development_material_permanently_excluded": (
            commitment["permanently_excluded"] is True
            and panel["permanently_excluded"] is True
            and qualification["permanently_excluded"] is True
        ),
    }
    if not all(checks.values()):
        raise ValueError(f"development discrimination gate failed: {checks}")

    body: Dict[str, Any] = {
        "version": DEVELOPMENT_PANEL_ADJUDICATION_VERSION,
        "status": "development_assay_operation_gate_passed_freeze_audit_pending",
        "development_only": True,
        "permanently_excluded": True,
        "commitment_id": commitment["commitment_id"],
        "panel_id": panel["panel_id"],
        "qualification_id": qualification["qualification_id"],
        "task_count": 18,
        "arm_episode_count": 54,
        "valid_root_advance_counts": {
            ARM_SCIENTIST: sum(
                value["score"]["valid_root_advance"]
                for value in scientist_results.values()
            ),
            ARM_PROMPT_EQUATED: sum(
                value["score"]["valid_root_advance"]
                for key, value in results.items()
                if key.endswith(ARM_PROMPT_EQUATED)
            ),
            ARM_FREE: sum(
                value["score"]["valid_root_advance"]
                for key, value in results.items()
                if key.endswith(ARM_FREE)
            ),
        },
        "rates": panel["rates"],
        "diagnostic_only_unadjusted_differences": {
            "scientist_minus_prompt_equated": (
                panel["rates"][ARM_SCIENTIST] - panel["rates"][ARM_PROMPT_EQUATED]
            ),
            "scientist_minus_free": (
                panel["rates"][ARM_SCIENTIST] - panel["rates"][ARM_FREE]
            ),
        },
        "state_mixture": state_mixture,
        "scientist_failure_taxonomy": {
            "no_tool_fail_closed": scientist_no_tool_failures,
            "over_budget_with_accepted_certificate": scientist_over_budget_certified_failures,
            "other": 18
            - sum(
                value["score"]["valid_root_advance"]
                for value in scientist_results.values()
            )
            - scientist_no_tool_failures
            - scientist_over_budget_certified_failures,
        },
        "false_promotion_count_all_arms": false_promotions,
        "checks": checks,
        "all_gates_passed": True,
        "adjudication_path": str(doc_path.relative_to(root)),
        "adjudication_sha256": bytes_sha256(doc_path.read_bytes()),
        "positive_scientist_difference_used_as_evidence": False,
        "outcome_responsive_revision_authorized": False,
        "implementation_freeze_proposal_authorized": True,
        "confirmatory_execution_authorized": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "adjudication_id": content_digest(body)}
