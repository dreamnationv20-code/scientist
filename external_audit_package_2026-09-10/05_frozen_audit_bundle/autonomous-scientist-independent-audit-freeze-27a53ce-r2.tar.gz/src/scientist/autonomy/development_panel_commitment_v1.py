from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_worlds_v1 import FaultClass, ScientificState
from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


DEVELOPMENT_PANEL_COMMITMENT_VERSION = "adaptive-development-discrimination-commitment-v1"
EXPECTED_QUALIFICATION_ID = "93397de7b6b7cb3cb812e15dc549485a0fc98dbfe307492c7edadb3367f09b3c"
EXPECTED_PROTOCOL_V6_ID = "fdbf5b094ba2015b963aa02d29dd4b7f04955cd8e8101c242e1e410e65a4f377"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def committed_task_specs(seed_base: int = 930_000) -> list[Mapping[str, Any]]:
    states = tuple(ScientificState)
    faults = tuple(FaultClass)
    specs = []
    for replicate in range(3):
        for fault_index, fault in enumerate(faults):
            index = len(specs)
            specs.append(
                {
                    "task_index": index,
                    "seed": seed_base + index,
                    "scientific_state": states[(fault_index + 2 * replicate) % len(states)].value,
                    "variable_count": (5, 6, 7)[(fault_index + replicate) % 3],
                    "fault_class": fault.value,
                }
            )
    return specs


def build_development_panel_commitment(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    qualification_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_harness_qualification_v5"
        / "artifacts/manifests/adaptive-causal-harness-qualification-v5.json"
    )
    protocol_path = (
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v6/artifacts/manifests"
        / "protocol-commitment-v6.json"
    )
    doc_path = (
        root
        / "docs/autonomous-scientist-fresh-development-discrimination-panel-commitment-2026-09-09.md"
    )
    source_paths = (
        root / "src/scientist/autonomy/adaptive_worlds_v1.py",
        root / "src/scientist/autonomy/adaptive_three_arm_v1.py",
        root / "src/scientist/autonomy/adaptive_codex_runner_v1.py",
        root / "scripts/run_adaptive_causal_development_panel_v1.py",
        root / "src/scientist/autonomy/development_panel_commitment_v1.py",
    )
    for path in (qualification_path, protocol_path, doc_path, *source_paths):
        if not path.is_file():
            raise FileNotFoundError(path)
    qualification = _identified(qualification_path, "qualification_id")
    protocol = _identified(protocol_path, "commitment_id")
    if qualification["qualification_id"] != EXPECTED_QUALIFICATION_ID:
        raise ValueError("unexpected adaptive harness qualification")
    if protocol["commitment_id"] != EXPECTED_PROTOCOL_V6_ID:
        raise ValueError("unexpected adaptive runtime commitment")
    if not qualification["all_checks_passed"]:
        raise ValueError("adaptive harness is not qualified")

    target = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1"
        / "artifacts/manifests/adaptive-causal-development-fresh-prefreeze-v1.json"
    )
    if target.exists():
        raise ValueError("fresh development panel outcome already exists")
    for namespace in (
        "prospective_v3_confirmatory",
        "prospective_v4_confirmatory",
        "prospective_v5_confirmatory",
        "prospective_v6_confirmatory",
    ):
        if (root / "runs/autonomy_closure_v1" / namespace).exists():
            raise ValueError("confirmatory state exists before development commitment")

    specs = committed_task_specs()
    body: Dict[str, Any] = {
        "version": DEVELOPMENT_PANEL_COMMITMENT_VERSION,
        "status": "committed_outcomes_absent",
        "development_only": True,
        "permanently_excluded": True,
        "protocol_commitment_id": protocol["commitment_id"],
        "qualification_id": qualification["qualification_id"],
        "run_id": "adaptive-causal-development-fresh-prefreeze-v1",
        "task_count": 18,
        "arm_episode_count": 54,
        "seed_base": 930_000,
        "seed_end_inclusive": 930_017,
        "order_seed": 240_911,
        "task_specs": specs,
        "model": "gpt-5.6-sol",
        "reasoning_effort": "low",
        "token_ceiling_per_episode": 128_000,
        "wall_time_ceiling_seconds_per_episode": 900,
        "pass_gates": {
            "all_54_arm_slots_terminal": True,
            "runner_exception_count": 0,
            "pooled_control_rate_inclusive": [0.15, 0.85],
            "each_represented_state_has_nonoracle_success_and_failure": True,
            "all_matching_checks": True,
            "reference_policy_minimum": 0.95,
            "constant_policy_maximum": 0.10,
        },
        "positive_scientist_difference_required": False,
        "positive_scientist_difference_reportable_as_evidence": False,
        "selective_reruns_allowed": False,
        "adjudication_path": str(doc_path.relative_to(root)),
        "adjudication_sha256": bytes_sha256(doc_path.read_bytes()),
        "source_hashes": {
            str(path.relative_to(root)): bytes_sha256(path.read_bytes())
            for path in source_paths
        },
        "implementation_freeze_complete": False,
        "confirmatory_execution_authorized": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "commitment_id": content_digest(body)}
