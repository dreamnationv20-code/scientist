from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Optional

from scientist.autonomy.authority_contracts import (
    component_authority,
    validate_component_execution,
)
from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    adjudicate_failure,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    AuthoritativeStateRuntime,
    AutonomyEventKind,
    ResourceUsage,
    RunStatus,
    SubsystemSnapshot,
)
from scientist.autonomy.tracing import (
    ComponentExecutionTrace,
    InvocationKind,
    total_invocation_usage,
)
from scientist.autonomy.transitions import RecoveryAction
from scientist.program.research_kernel import (
    AutonomousResearchKernel,
    ResearchExecutiveOutcome,
    ResearchExecutiveStep,
    ResearchKernelRuntime,
)


class GovernedResearchExecutive:
    """Run V3 actions only through components with declared authority.

    The research-kernel checkpoint is committed first. The authoritative ledger
    then points to that exact checkpoint. A crash between those operations is
    detectable as an orphan checkpoint and must enter typed recovery rather
    than being silently accepted on resume.
    """

    def __init__(
        self,
        kernel: AutonomousResearchKernel,
        domain,
        *,
        research_checkpoint_path: Path,
        authority_runtime: AuthoritativeStateRuntime,
        component_pack=None,
        maximum_exact_retries_per_action: int = 1,
    ) -> None:
        if maximum_exact_retries_per_action < 0:
            raise ValueError("exact-retry limit cannot be negative")
        self.kernel = kernel
        self.domain = domain
        self.research_runtime = ResearchKernelRuntime(
            kernel,
            domain,
            research_checkpoint_path,
        )
        self.authority_runtime = authority_runtime
        self.component_pack = component_pack
        if component_pack is not None:
            if component_pack.domain_id != domain.domain_id:
                raise ValueError("component pack belongs to another domain")
            if (
                kernel.mission is not None
                and component_pack.mission_id != kernel.mission.mission_id
            ):
                raise ValueError("component pack belongs to another mission")
        self.maximum_exact_retries_per_action = maximum_exact_retries_per_action
        self._assert_synchronized()

    def _research_component(self, action_kind: str):
        if self.component_pack is not None:
            return self.component_pack.research_component(action_kind)
        return self.domain.research_component(action_kind)

    def _research_checkpoint_id(self) -> str:
        value = json.loads(
            self.research_runtime.checkpoint_path.read_text(encoding="utf-8")
        )
        return str(value["checkpoint_id"])

    def _assert_synchronized(self) -> None:
        matches = tuple(
            item
            for item in self.authority_runtime.ledger.state.subsystem_snapshots
            if item.subsystem == "research_kernel"
        )
        if matches and matches[0].digest != self._research_checkpoint_id():
            raise ValueError(
                "research checkpoint diverges from authoritative state; "
                "typed recovery is required"
            )

    def _save_authority(self) -> None:
        self.authority_runtime.save_checkpoint()

    def _record_failure(self, action, failure: AdjudicableResearchFailure):
        decision = adjudicate_failure(failure.case, failure.profile)
        for invocation in failure.attempt_invocations:
            event_kind = (
                AutonomyEventKind.MODEL_EXCHANGE_RECORDED
                if invocation.kind == InvocationKind.MODEL
                else AutonomyEventKind.TOOL_RESULT_RECORDED
            )
            self.authority_runtime.ledger.append(
                event_kind,
                invocation.actor,
                invocation.authority_scope,
                action_id=action.action_id,
                payload={
                    "operation": invocation.operation,
                    "invocation_id": invocation.invocation_id,
                    "failed_attempt": True,
                    "failure_case_id": failure.case.case_id,
                },
                input_artifact_ids=invocation.input_artifact_ids,
                output_artifact_ids=invocation.output_artifact_ids,
                resource_delta=invocation.usage,
            )
            self._save_authority()
        self.authority_runtime.ledger.append(
            AutonomyEventKind.FAILURE_ADJUDICATED,
            ActorIdentity(
                actor_ref="typed-failure-adjudicator-v1",
                kind=ActorKind.DETERMINISTIC_VALIDATOR,
            ),
            AuthorityScope.VERIFY,
            action_id=action.action_id,
            payload={
                "message": str(failure),
                "case": failure.case.as_dict(),
                "profile": failure.profile.as_dict(),
                "decision": decision.as_dict(),
                "attempt_invocation_ids": [
                    item.invocation_id for item in failure.attempt_invocations
                ],
            },
            input_artifact_ids=failure.case.evidence_refs,
            output_artifact_ids=(decision.decision_id,),
            resource_delta=(
                ResourceUsage()
                if failure.attempt_invocations
                else failure.attempt_usage
            ),
        )
        self._save_authority()
        return decision

    def run(self, max_steps: int = 16) -> ResearchExecutiveOutcome:
        if max_steps <= 0:
            raise ValueError("governed research max_steps must be positive")
        ledger = self.authority_runtime.ledger
        if ledger.state.status != RunStatus.ACTIVE:
            raise ValueError("governed research run is not active")
        steps = []
        exact_retry_counts = {}
        for step_index in range(max_steps):
            action = self.kernel.next_action()
            component = self._research_component(action.kind.value)
            component_actor, component_scope = component_authority(component)
            if ledger.state.active_action_id is None:
                ledger.append(
                    AutonomyEventKind.ACTION_SELECTED,
                    ActorIdentity(
                        actor_ref="v3-action-policy-v1",
                        kind=ActorKind.SCIENTIST_POLICY,
                    ),
                    AuthorityScope.GOVERN,
                    action_id=action.action_id,
                    payload=action.as_dict(),
                )
                self._save_authority()
            elif ledger.state.active_action_id != action.action_id:
                raise ValueError(
                    "active authoritative action and research kernel disagree"
                )

            before = self.kernel.state_digest
            # Execute against a disposable copy. Scientific state is accepted
            # only after trace identity and action-level authority checks pass.
            working_kernel = AutonomousResearchKernel.from_dict(
                self.kernel.as_dict()
            )
            started = time.perf_counter()
            try:
                dispatch = component.dispatch(action, working_kernel, self.domain)
            except AdjudicableResearchFailure as failure:
                decision = self._record_failure(action, failure)
                retries = exact_retry_counts.get(action.action_id, 0)
                if (
                    decision.action == RecoveryAction.EXACT_RETRY
                    and retries < self.maximum_exact_retries_per_action
                ):
                    exact_retry_counts[action.action_id] = retries + 1
                    # The action remains active and the authoritative kernel is
                    # unchanged. Retry the exact same action inside this turn.
                    continue
                return ResearchExecutiveOutcome(
                    boundary="recovery_%s_required" % decision.action.value,
                    steps=tuple(steps),
                    state=self.kernel.as_dict(),
                )
            elapsed = time.perf_counter() - started
            after = working_kernel.state_digest
            if (
                self.component_pack is not None
                and working_kernel.mission is not None
                and working_kernel.mission.mission_id
                != self.component_pack.mission_id
            ):
                raise ValueError("component pack advanced another research mission")
            trace_value = dispatch.details.get("_authority_trace")
            if not isinstance(trace_value, dict):
                raise ValueError(
                    "research component omitted its complete authority trace"
                )
            trace = ComponentExecutionTrace.from_dict(trace_value)
            expected_component_ref = "%s@%s" % (
                component.name,
                component.component_version,
            )
            if trace.action_id != action.action_id:
                raise ValueError("component trace belongs to another action")
            if trace.component_ref != expected_component_ref:
                raise ValueError("component trace belongs to another component")
            validate_component_execution(
                action_kind=action.kind,
                component_actor=component_actor,
                component_scope=component_scope,
                trace=trace,
            )
            if dispatch.progressed and after == before:
                raise ValueError(
                    "research component claimed progress without changing durable state"
                )
            if not dispatch.progressed and after != before:
                raise ValueError(
                    "research component changed durable state without claiming progress"
                )
            prior_successful_invocations = {
                str(event.payload.get("invocation_id")): event
                for event in ledger.events
                if event.action_id == action.action_id
                and event.kind
                in {
                    AutonomyEventKind.MODEL_EXCHANGE_RECORDED,
                    AutonomyEventKind.TOOL_RESULT_RECORDED,
                }
                and event.payload.get("failed_attempt") is not True
            }
            # A resumable instrument may expose an immutable unit receipt in a
            # failed attempt and then include that same completed unit in the
            # successful trace.  It was already charged when the failure was
            # recorded, so accepting the identical receipt must not charge it
            # a second time.  Failed operations whose identities change on
            # retry remain distinct and are still charged normally.
            prior_failed_invocations = {
                str(event.payload.get("invocation_id")): event
                for event in ledger.events
                if event.action_id == action.action_id
                and event.kind
                in {
                    AutonomyEventKind.MODEL_EXCHANGE_RECORDED,
                    AutonomyEventKind.TOOL_RESULT_RECORDED,
                }
                and event.payload.get("failed_attempt") is True
            }
            observed_invocation_ids = {
                invocation.invocation_id for invocation in trace.invocations
            }
            unexpected_prior = set(prior_successful_invocations).difference(
                observed_invocation_ids
            )
            if unexpected_prior:
                raise ValueError(
                    "resumed action produced a different external-invocation trace"
                )
            for invocation in trace.invocations:
                if invocation.invocation_id in prior_successful_invocations:
                    continue
                if invocation.invocation_id in prior_failed_invocations:
                    continue
                event_kind = (
                    AutonomyEventKind.MODEL_EXCHANGE_RECORDED
                    if invocation.kind == InvocationKind.MODEL
                    else AutonomyEventKind.TOOL_RESULT_RECORDED
                )
                ledger.append(
                    event_kind,
                    invocation.actor,
                    invocation.authority_scope,
                    action_id=action.action_id,
                    payload={
                        "operation": invocation.operation,
                        "invocation_id": invocation.invocation_id,
                        "component_trace_id": trace.trace_id,
                    },
                    input_artifact_ids=invocation.input_artifact_ids,
                    output_artifact_ids=invocation.output_artifact_ids,
                    resource_delta=invocation.usage,
                )
                self._save_authority()
            # Preserve the caller-visible object identity while accepting the
            # validated state only after its external invocations are durably
            # linked to the active action.
            self.kernel.__dict__.clear()
            self.kernel.__dict__.update(working_kernel.__dict__)
            self.research_runtime.save_checkpoint()
            checkpoint_id = self._research_checkpoint_id()
            prior = tuple(
                item.digest
                for item in ledger.state.subsystem_snapshots
                if item.subsystem == "research_kernel"
            )
            ledger.append(
                AutonomyEventKind.STATE_COMMITTED,
                component_actor,
                component_scope,
                action_id=action.action_id,
                payload={
                    "component_ref": "%s@%s"
                    % (component.name, component.component_version),
                    "kernel_before_digest": before,
                    "kernel_after_digest": after,
                    "dispatch": dispatch.as_dict(),
                },
                input_artifact_ids=prior,
                output_artifact_ids=(checkpoint_id,),
                resource_delta=ResourceUsage(
                    wall_seconds=max(
                        0.0,
                        elapsed - total_invocation_usage(trace.invocations).wall_seconds,
                    )
                ),
                snapshot_updates=(
                    SubsystemSnapshot(
                        subsystem="research_kernel",
                        digest=checkpoint_id,
                        schema_version="autonomous-research-kernel-v3",
                        source_ref=str(
                            self.research_runtime.checkpoint_path.resolve()
                        ),
                    ),
                ),
            )
            self._save_authority()
            ledger.append(
                AutonomyEventKind.ACTION_COMPLETED,
                ActorIdentity(
                    actor_ref="v3-action-policy-v1",
                    kind=ActorKind.SCIENTIST_POLICY,
                ),
                AuthorityScope.GOVERN,
                action_id=action.action_id,
                payload={
                    "outcome": dispatch.outcome,
                    "progressed": dispatch.progressed,
                    "stop": dispatch.stop,
                },
            )
            self._save_authority()
            steps.append(
                ResearchExecutiveStep(
                    step_index=step_index,
                    action=action,
                    component_ref="%s@%s"
                    % (component.name, component.component_version),
                    before_digest=before,
                    after_digest=after,
                    dispatch=dispatch,
                )
            )
            if dispatch.stop:
                ledger.append(
                    AutonomyEventKind.RUN_TERMINATED,
                    ActorIdentity(
                        actor_ref="v3-action-policy-v1",
                        kind=ActorKind.SCIENTIST_POLICY,
                    ),
                    AuthorityScope.GOVERN,
                    payload={"boundary": dispatch.outcome},
                )
                self._save_authority()
                return ResearchExecutiveOutcome(
                    boundary=dispatch.outcome,
                    steps=tuple(steps),
                    state=self.kernel.as_dict(),
                )
        return ResearchExecutiveOutcome(
            boundary="step_budget_exhausted",
            steps=tuple(steps),
            state=self.kernel.as_dict(),
        )
