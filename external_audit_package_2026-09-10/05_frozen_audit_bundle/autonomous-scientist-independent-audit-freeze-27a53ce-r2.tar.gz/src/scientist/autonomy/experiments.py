from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from pathlib import PurePosixPath
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


EXPERIMENT_SPEC_VERSION = "scientist-declarative-experiment-v1"


def _unique(values: Sequence[str], label: str, minimum: int = 1) -> Tuple[str, ...]:
    result = tuple(str(value) for value in values)
    if len(result) < minimum or not all(result):
        raise ValueError("%s must contain at least %d non-empty values" % (label, minimum))
    if len(result) != len(set(result)):
        raise ValueError("%s must be unique" % label)
    return result


def _relative_path(value: str, label: str) -> str:
    path = PurePosixPath(str(value))
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError("%s must be a safe relative path" % label)
    return path.as_posix()


class ExperimentPartition(str, Enum):
    DEVELOPMENT = "development"
    VALIDATION = "validation"
    SEALED = "sealed"
    REPLICATION = "replication"


class MetricDirection(str, Enum):
    MAXIMIZE = "maximize"
    MINIMIZE = "minimize"


class Comparator(str, Enum):
    GREATER_EQUAL = "greater_equal"
    LESS_EQUAL = "less_equal"
    GREATER = "greater"
    LESS = "less"


@dataclass(frozen=True)
class CommandSpec:
    name: str
    argv: Tuple[str, ...]
    working_subdirectory: str
    expected_output_paths: Tuple[str, ...]
    timeout_seconds: float
    network_allowed: bool
    sealed_authority_allowed: bool

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("experiment command name must not be empty")
        if not self.argv or not all(str(token) for token in self.argv):
            raise ValueError("command arguments must be non-empty")
        if self.argv[0] in {"sh", "bash", "zsh", "fish", "cmd", "powershell"}:
            raise ValueError("experiment commands cannot invoke a shell")
        if any(
            token in {"|", "||", "&&", ";", ">", ">>", "<"}
            or "\x00" in token
            or "\n" in token
            for token in self.argv
        ):
            raise ValueError("experiment command contains a shell control token")
        _relative_path(self.working_subdirectory, "command working directory")
        outputs = _unique(self.expected_output_paths, "expected command outputs")
        for output in outputs:
            _relative_path(output, "expected command output")
        if not math.isfinite(self.timeout_seconds) or self.timeout_seconds <= 0.0:
            raise ValueError("command timeout must be finite and positive")
        if self.network_allowed:
            raise ValueError("confirmatory experiment commands must be network isolated")
        if self.sealed_authority_allowed:
            raise ValueError("experiment commands cannot read sealed authority")

    @property
    def command_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": EXPERIMENT_SPEC_VERSION,
            "name": self.name,
            "argv": list(self.argv),
            "working_subdirectory": self.working_subdirectory,
            "expected_output_paths": list(self.expected_output_paths),
            "timeout_seconds": self.timeout_seconds,
            "network_allowed": self.network_allowed,
            "sealed_authority_allowed": self.sealed_authority_allowed,
        }
        if include_id:
            value["command_id"] = self.command_id
        return value


@dataclass(frozen=True)
class ConditionSpec:
    name: str
    role: str
    intervention_family: str
    representation_signature: Tuple[str, ...]
    parameters: Mapping[str, Any]
    matched_control_name: str

    def __post_init__(self) -> None:
        if not all((self.name, self.role, self.intervention_family)):
            raise ValueError("experiment condition identity is incomplete")
        if self.role not in {"control", "treatment", "sham", "anchor"}:
            raise ValueError("unknown experiment-condition role")
        _unique(self.representation_signature, "condition representation signature")
        if self.role != "control" and not self.matched_control_name:
            raise ValueError("non-control condition requires a matched control")
        if self.role == "control" and self.matched_control_name:
            raise ValueError("control condition cannot point to another control")

    @property
    def condition_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": EXPERIMENT_SPEC_VERSION,
            "name": self.name,
            "role": self.role,
            "intervention_family": self.intervention_family,
            "representation_signature": list(self.representation_signature),
            "parameters": dict(self.parameters),
            "matched_control_name": self.matched_control_name,
        }
        if include_id:
            value["condition_id"] = self.condition_id
        return value


@dataclass(frozen=True)
class MetricContract:
    name: str
    direction: MetricDirection
    unit: str
    aggregation: str
    primary: bool
    evaluator_ref: str

    def __post_init__(self) -> None:
        if not all((self.name, self.unit, self.aggregation, self.evaluator_ref)):
            raise ValueError("metric contract is incomplete")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "direction": self.direction.value,
            "unit": self.unit,
            "aggregation": self.aggregation,
            "primary": self.primary,
            "evaluator_ref": self.evaluator_ref,
        }


@dataclass(frozen=True)
class ThresholdRule:
    rule_ref: str
    metric_name: str
    condition_name: str
    baseline_condition_name: str
    comparator: Comparator
    threshold: float
    all_seeds_required: bool
    disposition_if_passed: str
    disposition_if_failed: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.rule_ref,
                self.metric_name,
                self.condition_name,
                self.disposition_if_passed,
                self.disposition_if_failed,
            )
        ):
            raise ValueError("experiment decision rule is incomplete")
        if not math.isfinite(self.threshold):
            raise ValueError("experiment decision threshold must be finite")

    @property
    def rule_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": EXPERIMENT_SPEC_VERSION,
            "rule_ref": self.rule_ref,
            "metric_name": self.metric_name,
            "condition_name": self.condition_name,
            "baseline_condition_name": self.baseline_condition_name,
            "comparator": self.comparator.value,
            "threshold": self.threshold,
            "all_seeds_required": self.all_seeds_required,
            "disposition_if_passed": self.disposition_if_passed,
            "disposition_if_failed": self.disposition_if_failed,
        }
        if include_id:
            value["rule_id"] = self.rule_id
        return value


@dataclass(frozen=True)
class ExperimentResourceLimit:
    maximum_total_wall_seconds: float
    maximum_total_compute_units: float
    maximum_tool_calls: int
    maximum_model_tokens: int

    def __post_init__(self) -> None:
        if any(
            not math.isfinite(value) or value <= 0.0
            for value in (
                self.maximum_total_wall_seconds,
                self.maximum_total_compute_units,
            )
        ):
            raise ValueError("experiment resource quantities must be positive")
        if self.maximum_tool_calls <= 0 or self.maximum_model_tokens < 0:
            raise ValueError("experiment resource counters are invalid")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "maximum_total_wall_seconds": self.maximum_total_wall_seconds,
            "maximum_total_compute_units": self.maximum_total_compute_units,
            "maximum_tool_calls": self.maximum_tool_calls,
            "maximum_model_tokens": self.maximum_model_tokens,
        }


@dataclass(frozen=True)
class DeclarativeExperimentSpec:
    mission_id: str
    concept_id: str
    research_question: str
    competing_hypothesis_ids: Tuple[str, ...]
    conditions: Tuple[ConditionSpec, ...]
    seeds: Tuple[int, ...]
    partitions: Tuple[ExperimentPartition, ...]
    commands: Tuple[CommandSpec, ...]
    metrics: Tuple[MetricContract, ...]
    decision_rules: Tuple[ThresholdRule, ...]
    resource_limit: ExperimentResourceLimit
    public_input_artifact_ids: Tuple[str, ...]
    sealed_authority_artifact_id: str
    final_target_withheld: bool
    answer_blind: bool
    frozen: bool
    designer_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.mission_id,
                self.concept_id,
                self.research_question,
                self.designer_ref,
            )
        ):
            raise ValueError("declarative experiment identity is incomplete")
        _unique(self.competing_hypothesis_ids, "competing hypotheses", minimum=2)
        condition_names = _unique(
            tuple(item.name for item in self.conditions),
            "experiment conditions",
            minimum=2,
        )
        controls = {item.name for item in self.conditions if item.role == "control"}
        if not controls:
            raise ValueError("experiment requires at least one control")
        if any(
            item.role != "control" and item.matched_control_name not in controls
            for item in self.conditions
        ):
            raise ValueError("experiment condition names an unknown matched control")
        if len(set(self.seeds)) != len(self.seeds) or len(self.seeds) < 2:
            raise ValueError("experiment requires at least two unique seeds")
        if any(isinstance(seed, bool) or not isinstance(seed, int) for seed in self.seeds):
            raise ValueError("experiment seeds must be integers")
        partition_set = set(self.partitions)
        if not {
            ExperimentPartition.DEVELOPMENT,
            ExperimentPartition.SEALED,
            ExperimentPartition.REPLICATION,
        }.issubset(partition_set):
            raise ValueError("experiment omits development, sealed, or replication partition")
        _unique(tuple(item.command_id for item in self.commands), "experiment commands")
        metric_names = _unique(tuple(item.name for item in self.metrics), "experiment metrics")
        if sum(item.primary for item in self.metrics) != 1:
            raise ValueError("experiment must declare exactly one primary metric")
        _unique(tuple(item.rule_id for item in self.decision_rules), "decision rules")
        if any(rule.metric_name not in metric_names for rule in self.decision_rules):
            raise ValueError("decision rule names an unknown metric")
        if any(
            rule.condition_name not in condition_names
            or (
                rule.baseline_condition_name
                and rule.baseline_condition_name not in condition_names
            )
            for rule in self.decision_rules
        ):
            raise ValueError("decision rule names an unknown condition")
        _unique(self.public_input_artifact_ids, "public experiment inputs")
        if len(self.sealed_authority_artifact_id) != 64:
            raise ValueError("sealed authority must use a content identity")
        if self.sealed_authority_artifact_id in self.public_input_artifact_ids:
            raise ValueError("sealed authority cannot be a public experiment input")
        if not (self.final_target_withheld and self.answer_blind and self.frozen):
            raise ValueError("experiment must be frozen, answer blind, and target withheld")

    @property
    def specification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": EXPERIMENT_SPEC_VERSION,
            "mission_id": self.mission_id,
            "concept_id": self.concept_id,
            "research_question": self.research_question,
            "competing_hypothesis_ids": list(self.competing_hypothesis_ids),
            "conditions": [item.as_dict() for item in self.conditions],
            "seeds": list(self.seeds),
            "partitions": [item.value for item in self.partitions],
            "commands": [item.as_dict() for item in self.commands],
            "metrics": [item.as_dict() for item in self.metrics],
            "decision_rules": [item.as_dict() for item in self.decision_rules],
            "resource_limit": self.resource_limit.as_dict(),
            "public_input_artifact_ids": list(self.public_input_artifact_ids),
            "sealed_authority_artifact_id": self.sealed_authority_artifact_id,
            "final_target_withheld": self.final_target_withheld,
            "answer_blind": self.answer_blind,
            "frozen": self.frozen,
            "designer_ref": self.designer_ref,
        }
        if include_id:
            value["specification_id"] = self.specification_id
        return value


@dataclass(frozen=True)
class ExperimentJob:
    specification_id: str
    condition_id: str
    condition_name: str
    seed: int
    partition: ExperimentPartition
    command_ids: Tuple[str, ...]
    output_subdirectory: str

    @property
    def job_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": EXPERIMENT_SPEC_VERSION,
            "specification_id": self.specification_id,
            "condition_id": self.condition_id,
            "condition_name": self.condition_name,
            "seed": self.seed,
            "partition": self.partition.value,
            "command_ids": list(self.command_ids),
            "output_subdirectory": self.output_subdirectory,
        }
        if include_id:
            value["job_id"] = self.job_id
        return value


@dataclass(frozen=True)
class ExperimentExecutionPlan:
    specification_id: str
    jobs: Tuple[ExperimentJob, ...]
    resource_limit: ExperimentResourceLimit
    executor_read_artifact_ids: Tuple[str, ...]
    executor_denied_artifact_ids: Tuple[str, ...]
    evaluator_ref: str
    compiler_ref: str

    @property
    def plan_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": EXPERIMENT_SPEC_VERSION,
            "specification_id": self.specification_id,
            "jobs": [item.as_dict() for item in self.jobs],
            "resource_limit": self.resource_limit.as_dict(),
            "executor_read_artifact_ids": list(self.executor_read_artifact_ids),
            "executor_denied_artifact_ids": list(self.executor_denied_artifact_ids),
            "evaluator_ref": self.evaluator_ref,
            "compiler_ref": self.compiler_ref,
        }
        if include_id:
            value["plan_id"] = self.plan_id
        return value


def compile_experiment(
    specification: DeclarativeExperimentSpec,
    *,
    compiler_ref: str = "deterministic-experiment-compiler-v1",
) -> ExperimentExecutionPlan:
    command_ids = tuple(item.command_id for item in specification.commands)
    jobs = tuple(
        ExperimentJob(
            specification_id=specification.specification_id,
            condition_id=condition.condition_id,
            condition_name=condition.name,
            seed=seed,
            partition=partition,
            command_ids=command_ids,
            output_subdirectory="jobs/%s/%s/%d"
            % (partition.value, condition.name, seed),
        )
        for partition in specification.partitions
        for seed in specification.seeds
        for condition in specification.conditions
    )
    evaluator_refs = {item.evaluator_ref for item in specification.metrics}
    if len(evaluator_refs) != 1:
        raise ValueError("all metrics must use one frozen evaluator authority")
    plan = ExperimentExecutionPlan(
        specification_id=specification.specification_id,
        jobs=jobs,
        resource_limit=specification.resource_limit,
        executor_read_artifact_ids=specification.public_input_artifact_ids,
        executor_denied_artifact_ids=(specification.sealed_authority_artifact_id,),
        evaluator_ref=next(iter(evaluator_refs)),
        compiler_ref=compiler_ref,
    )
    if len({job.job_id for job in plan.jobs}) != len(plan.jobs):
        raise ValueError("compiled experiment contains duplicate jobs")
    if len({job.output_subdirectory for job in plan.jobs}) != len(plan.jobs):
        raise ValueError("compiled experiment jobs collide on output paths")
    return plan
