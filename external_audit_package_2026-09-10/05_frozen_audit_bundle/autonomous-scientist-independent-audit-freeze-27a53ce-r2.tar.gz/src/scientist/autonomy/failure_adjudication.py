from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.autonomy.state import ResourceUsage
from scientist.autonomy.tracing import ExternalInvocation, total_invocation_usage
from scientist.autonomy.transitions import (
    FailureClass,
    RecoveryAction,
    TransitionCase,
    TransitionDecision,
)
from scientist.core.artifacts import content_digest


FAILURE_ADJUDICATION_VERSION = "scientist-typed-failure-adjudication-v1"


class AdjudicableResearchFailure(RuntimeError):
    """A component failure accompanied by candidate-visible causal evidence."""

    def __init__(
        self,
        message: str,
        *,
        case: TransitionCase,
        profile: "FailureEvidenceProfile",
        attempt_usage: ResourceUsage = ResourceUsage(),
        attempt_invocations: Tuple[ExternalInvocation, ...] = (),
    ) -> None:
        super().__init__(message)
        if case.retrospective:
            raise ValueError("a live component failure cannot use a retrospective case")
        if profile.case_id != case.case_id:
            raise ValueError("live failure profile belongs to another case")
        traced_usage = total_invocation_usage(attempt_invocations)
        if attempt_invocations and attempt_usage != ResourceUsage() and (
            attempt_usage != traced_usage
        ):
            raise ValueError("failure attempt usage disagrees with its invocations")
        self.case = case
        self.profile = profile
        self.attempt_invocations = tuple(attempt_invocations)
        self.attempt_usage = traced_usage if attempt_invocations else attempt_usage


@dataclass(frozen=True)
class FailureEvidenceProfile:
    case_id: str
    runtime_available: bool
    external_dependency_missing: bool
    implementation_integrity_passed: Optional[bool]
    interface_qualified: Optional[bool]
    protocol_feasible: Optional[bool]
    measurement_qualified: Optional[bool]
    scientific_outcome_observed: bool
    scientific_gate_passed: Optional[bool]
    representation_limit_demonstrated: bool

    def __post_init__(self) -> None:
        if not self.case_id:
            raise ValueError("failure-evidence profile requires a case")
        if self.scientific_gate_passed is not None and not self.scientific_outcome_observed:
            raise ValueError("a scientific gate cannot be scored before an outcome")
        if self.representation_limit_demonstrated and (
            not self.scientific_outcome_observed or self.scientific_gate_passed is not False
        ):
            raise ValueError(
                "representation exhaustion requires an observed failed scientific gate"
            )

    @property
    def profile_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": FAILURE_ADJUDICATION_VERSION,
            "case_id": self.case_id,
            "runtime_available": self.runtime_available,
            "external_dependency_missing": self.external_dependency_missing,
            "implementation_integrity_passed": self.implementation_integrity_passed,
            "interface_qualified": self.interface_qualified,
            "protocol_feasible": self.protocol_feasible,
            "measurement_qualified": self.measurement_qualified,
            "scientific_outcome_observed": self.scientific_outcome_observed,
            "scientific_gate_passed": self.scientific_gate_passed,
            "representation_limit_demonstrated": self.representation_limit_demonstrated,
        }
        if include_id:
            value["profile_id"] = self.profile_id
        return value


_RECOVERY = {
    FailureClass.NONE: RecoveryAction.CONTINUE,
    FailureClass.INFRASTRUCTURE: RecoveryAction.EXACT_RETRY,
    FailureClass.IMPLEMENTATION: RecoveryAction.REPAIR_IMPLEMENTATION,
    FailureClass.INTERFACE: RecoveryAction.REPAIR_INTERFACE,
    FailureClass.PROTOCOL: RecoveryAction.AMEND_PROTOCOL,
    FailureClass.MEASUREMENT: RecoveryAction.RECALIBRATE_MEASUREMENT,
    FailureClass.SCIENTIFIC_NULL: RecoveryAction.UPDATE_CAUSAL_THEORY,
    FailureClass.REPRESENTATION_EXHAUSTION: RecoveryAction.CHANGE_REPRESENTATION,
    FailureClass.EXTERNAL_DEPENDENCY: RecoveryAction.REQUEST_EXTERNAL_AUTHORITY,
}


def classify_failure(profile: FailureEvidenceProfile) -> FailureClass:
    """Apply a frozen precedence order from delivery to scientific meaning."""

    if profile.external_dependency_missing:
        return FailureClass.EXTERNAL_DEPENDENCY
    if not profile.runtime_available:
        return FailureClass.INFRASTRUCTURE
    if profile.implementation_integrity_passed is False:
        return FailureClass.IMPLEMENTATION
    if profile.interface_qualified is False:
        return FailureClass.INTERFACE
    if profile.protocol_feasible is False:
        return FailureClass.PROTOCOL
    if profile.measurement_qualified is False:
        return FailureClass.MEASUREMENT
    if profile.scientific_outcome_observed and profile.scientific_gate_passed is False:
        if profile.representation_limit_demonstrated:
            return FailureClass.REPRESENTATION_EXHAUSTION
        return FailureClass.SCIENTIFIC_NULL
    return FailureClass.NONE


def adjudicate_failure(
    case: TransitionCase,
    profile: FailureEvidenceProfile,
    *,
    actor_ref: str = "typed-failure-adjudicator-v1",
) -> TransitionDecision:
    if profile.case_id != case.case_id:
        raise ValueError("failure profile belongs to another transition case")
    failure_class = classify_failure(profile)
    action = _RECOVERY[failure_class]
    if action not in case.available_actions:
        raise ValueError("frozen recovery action is unavailable in this case")
    changed_assumptions = ()
    if failure_class == FailureClass.PROTOCOL:
        changed_assumptions = ("protocol feasibility",)
    elif failure_class == FailureClass.SCIENTIFIC_NULL:
        changed_assumptions = ("central causal hypothesis",)
    elif failure_class == FailureClass.REPRESENTATION_EXHAUSTION:
        changed_assumptions = ("fixed representation sufficiency",)
    rationale = {
        FailureClass.NONE: "All prerequisite validity gates passed; continue the frozen program.",
        FailureClass.INFRASTRUCTURE: "The runtime failed before scientific execution; retry only the identical operation.",
        FailureClass.IMPLEMENTATION: "The implementation failed before a valid outcome; repair code without changing the scientific contract.",
        FailureClass.INTERFACE: "The declared semantic interface was not qualified; repair delivery before interpreting efficacy.",
        FailureClass.PROTOCOL: "The frozen protocol contains an infeasible requirement; amend and reaudit it before execution.",
        FailureClass.MEASUREMENT: "The measurement channel was not qualified; recalibrate without updating the causal hypothesis.",
        FailureClass.SCIENTIFIC_NULL: "A valid prospective test failed; update the causal theory rather than retrying implementation.",
        FailureClass.REPRESENTATION_EXHAUSTION: "Valid controlled outcomes exhausted the fixed representation; change the learned representation or parameters.",
        FailureClass.EXTERNAL_DEPENDENCY: "A required external capability is absent; request that authority without fabricating progress.",
    }[failure_class]
    return TransitionDecision(
        case_id=case.case_id,
        primary_failure_class=failure_class,
        secondary_failure_classes=(),
        action=action,
        rationale=rationale,
        cited_evidence_refs=case.evidence_refs,
        preserved_invariants=case.protected_invariants,
        changed_assumptions=changed_assumptions,
        actor_ref=actor_ref,
    )
