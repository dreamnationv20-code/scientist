from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.generated_worlds import (
    EpisodeDisposition,
    GeneratedResearchConclusion,
    GeneratedWorldAuthority,
    GeneratedWorldInstrument,
    GeneratedWorldPublicPacket,
    GeneratedWorldScore,
    PublicObservation,
    score_generated_world,
)
from scientist.autonomy.generated_validation import (
    generated_contrast_interventions,
    validate_generated_hypotheses,
    validate_generated_query_identifiability,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    AuthoritativeResearchLedger,
    AuthoritativeStateRuntime,
    AutonomyEventKind,
    ResourceBudget,
    ResourceUsage,
)
from scientist.codex_exchange import AuditedCodexResponse, CodexStructuredExchange
from scientist.core.artifacts import ArtifactStore, content_digest


GENERATED_ARM_VERSION = "scientist-generated-world-closed-arm-v4"
GENERATED_QUERY_OPERATION = "design_generated_world_interventions"
GENERATED_CONCLUSION_OPERATION = "propose_generated_world_conclusion"
GENERATED_PROMPT_PROTOCOL_VERSION = "generated-world-matched-prompt-protocol-v1"
_QUERY_PROMPT_PREFIX = (
    "You are the proposal module of an authority-separated scientist. "
    "Design a compact set of paired interventions that discriminates the "
    "listed hypotheses. Select contexts only from instrument_contexts. Never "
    "query evaluation_contexts; they are prediction targets only. Use only "
    "the public packet; do not guess hidden authority. The query design must "
    "satisfy every coverage requirement in evidence_gate for every candidate "
    "binary moderator so either an effect or the null can be certified. Return query "
    "contexts, interventions, and non-negative replicate indices."
)
_CONCLUSION_PROMPT_PREFIX = (
    "Infer exactly one listed hypothesis from the public packet and measured "
    "observations. Choose promote only for a supported moderator; choose kill "
    "for the supported null. Predict the best intervention for every public "
    "evaluation context. Cite only observation_id values present below. The "
    "model proposes; a hidden deterministic scorer decides validity."
)
GENERATED_PROMPT_PROTOCOL_ID = content_digest(
    {
        "version": GENERATED_PROMPT_PROTOCOL_VERSION,
        "query_operation": GENERATED_QUERY_OPERATION,
        "query_prompt_prefix": _QUERY_PROMPT_PREFIX,
        "conclusion_operation": GENERATED_CONCLUSION_OPERATION,
        "conclusion_prompt_prefix": _CONCLUSION_PROMPT_PREFIX,
    }
)


def _context_key(context: Sequence[int]) -> str:
    values = tuple(int(value) for value in context)
    if not values or any(value not in {0, 1} for value in values):
        raise ValueError("research query context must be binary")
    return "".join(str(value) for value in values)


@dataclass(frozen=True)
class ResearchQuery:
    context: Tuple[int, ...]
    intervention: str
    replicate: int

    @property
    def query_id(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "context": list(self.context),
            "intervention": self.intervention,
            "replicate": self.replicate,
        }


@dataclass(frozen=True)
class GeneratedClosedArmResult:
    episode_id: str
    conclusion: GeneratedResearchConclusion
    score: GeneratedWorldScore
    authority_state_id: str
    event_count: int
    model_calls: int
    model_tokens: int
    tool_calls: int
    human_interventions: int
    out_of_band_interventions: int
    host_authorization_audited: bool
    model_sequester_audited: bool
    model_ref: str
    prompt_protocol_id: str
    budget: ResourceBudget
    design_proposal_accepted: bool
    design_validation_certificate_id: str

    @property
    def autonomy_closed(self) -> bool:
        return all(
            (
                self.host_authorization_audited,
                self.model_sequester_audited,
                self.human_interventions == 0,
                self.out_of_band_interventions == 0,
            )
        )

    @property
    def result_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": GENERATED_ARM_VERSION,
            "episode_id": self.episode_id,
            "conclusion": self.conclusion.as_dict(),
            "score": self.score.as_dict(),
            "authority_state_id": self.authority_state_id,
            "event_count": self.event_count,
            "model_calls": self.model_calls,
            "model_tokens": self.model_tokens,
            "tool_calls": self.tool_calls,
            "human_interventions": self.human_interventions,
            "out_of_band_interventions": self.out_of_band_interventions,
            "host_authorization_audited": self.host_authorization_audited,
            "model_sequester_audited": self.model_sequester_audited,
            "autonomy_closed": self.autonomy_closed,
            "model_ref": self.model_ref,
            "prompt_protocol_id": self.prompt_protocol_id,
            "budget": self.budget.as_dict(),
            "design_proposal_accepted": self.design_proposal_accepted,
            "design_validation_certificate_id": (
                self.design_validation_certificate_id
            ),
        }
        if include_id:
            value["result_id"] = self.result_id
        return value


def _query_schema(width: int, maximum: int) -> Mapping[str, Any]:
    return {
        "type": "object",
        "properties": {
            "queries": {
                "type": "array",
                "minItems": 2,
                "maxItems": maximum,
                "items": {
                    "type": "object",
                    "properties": {
                        "context": {
                            "type": "array",
                            "minItems": width,
                            "maxItems": width,
                            "items": {"type": "integer", "enum": [0, 1]},
                        },
                        "intervention": {"type": "string"},
                        "replicate": {"type": "integer"},
                    },
                    "required": ["context", "intervention", "replicate"],
                    "additionalProperties": False,
                },
            },
            "rationale": {"type": "string"},
        },
        "required": ["queries", "rationale"],
        "additionalProperties": False,
    }


def _conclusion_schema() -> Mapping[str, Any]:
    return {
        "type": "object",
        "properties": {
            "selected_hypothesis_id": {"type": "string"},
            "disposition": {"type": "string", "enum": ["promote", "kill"]},
            "predictions": {
                "type": "array",
                "minItems": 1,
                "items": {
                    "type": "object",
                    "properties": {
                        "context": {
                            "type": "array",
                            "minItems": 1,
                            "items": {"type": "integer", "enum": [0, 1]},
                        },
                        "intervention": {"type": "string"},
                    },
                    "required": ["context", "intervention"],
                    "additionalProperties": False,
                },
            },
            "cited_evidence_ids": {
                "type": "array",
                "minItems": 1,
                "items": {"type": "string"},
            },
            "limitations": {
                "type": "array",
                "minItems": 1,
                "items": {"type": "string"},
            },
        },
        "required": [
            "selected_hypothesis_id",
            "disposition",
            "predictions",
            "cited_evidence_ids",
            "limitations",
        ],
        "additionalProperties": False,
    }


def build_generated_query_prompt(public: GeneratedWorldPublicPacket) -> str:
    """Return the frozen model-visible query-design prompt for every arm."""

    public_json = json.dumps(public.as_dict(), indent=2, sort_keys=True)
    return "%s\n\n%s" % (_QUERY_PROMPT_PREFIX, public_json)


def build_generated_conclusion_prompt(
    public: GeneratedWorldPublicPacket,
    observations: Sequence[PublicObservation],
) -> str:
    """Return the frozen model-visible conclusion prompt for every arm."""

    public_json = json.dumps(public.as_dict(), indent=2, sort_keys=True)
    observation_json = json.dumps(
        [item.as_dict() for item in observations], indent=2, sort_keys=True
    )
    return "%s\n\nPUBLIC PACKET:\n%s\n\nOBSERVATIONS:\n%s" % (
        _CONCLUSION_PROMPT_PREFIX,
        public_json,
        observation_json,
    )


def _model_usage(audited: AuditedCodexResponse) -> ResourceUsage:
    return ResourceUsage(
        model_output_tokens=audited.reported_tokens_used,
        model_calls=1,
        wall_seconds=audited.wall_seconds,
    )


def _record_model(
    runtime: AuthoritativeStateRuntime,
    action_id: str,
    operation: str,
    audited: AuditedCodexResponse,
) -> None:
    runtime.ledger.append(
        AutonomyEventKind.MODEL_EXCHANGE_RECORDED,
        ActorIdentity(
            "codex-proposal-model:%s" % audited.model_ref,
            ActorKind.PROPOSAL_MODEL,
        ),
        AuthorityScope.PROPOSE,
        action_id=action_id,
        payload={"operation": operation, "packet_id": audited.packet_id},
        input_artifact_ids=(audited.request_digest,),
        output_artifact_ids=(audited.response_digest,),
        resource_delta=_model_usage(audited),
    )
    runtime.save_checkpoint()


def _select_action(
    runtime: AuthoritativeStateRuntime,
    episode_id: str,
    name: str,
) -> str:
    action_id = content_digest(
        {"version": GENERATED_ARM_VERSION, "episode_id": episode_id, "action": name}
    )
    runtime.ledger.append(
        AutonomyEventKind.ACTION_SELECTED,
        ActorIdentity("generated-world-policy-v1", ActorKind.SCIENTIST_POLICY),
        AuthorityScope.GOVERN,
        action_id=action_id,
        payload={"action": name, "episode_id": episode_id},
    )
    runtime.save_checkpoint()
    return action_id


def _complete_action(runtime: AuthoritativeStateRuntime, action_id: str) -> None:
    runtime.ledger.append(
        AutonomyEventKind.ACTION_COMPLETED,
        ActorIdentity("generated-world-policy-v1", ActorKind.SCIENTIST_POLICY),
        AuthorityScope.GOVERN,
        action_id=action_id,
        payload={"completed": True},
    )
    runtime.save_checkpoint()


def _parse_queries(
    value: Mapping[str, Any],
    public: GeneratedWorldPublicPacket,
) -> Tuple[ResearchQuery, ...]:
    queries = tuple(
        ResearchQuery(
            context=tuple(int(item) for item in row["context"]),
            intervention=str(row["intervention"]),
            replicate=int(row["replicate"]),
        )
        for row in value["queries"]
    )
    if len({item.query_id for item in queries}) != len(queries):
        raise ValueError("proposal contains duplicate instrument queries")
    if any(
        len(item.context) != len(public.variable_names)
        or item.context not in public.instrument_contexts
        or item.intervention not in public.intervention_names
        or item.replicate < 0
        for item in queries
    ):
        raise ValueError("proposal contains an unavailable instrument query")
    return queries


def _parse_conclusion(
    value: Mapping[str, Any],
    public: GeneratedWorldPublicPacket,
) -> GeneratedResearchConclusion:
    known_hypotheses = {item.hypothesis_id for item in public.hypotheses}
    selected = str(value["selected_hypothesis_id"])
    if selected not in known_hypotheses:
        raise ValueError("conclusion selected an unknown hypothesis")
    predictions = {
        _context_key(row["context"]): str(row["intervention"])
        for row in value["predictions"]
    }
    expected_keys = {_context_key(item) for item in public.evaluation_contexts}
    if set(predictions) != expected_keys:
        raise ValueError("conclusion predictions do not cover evaluation contexts")
    if any(item not in public.intervention_names for item in predictions.values()):
        raise ValueError("conclusion predicts an unknown intervention")
    return GeneratedResearchConclusion(
        episode_id=public.episode_id,
        selected_hypothesis_id=selected,
        disposition=EpisodeDisposition(str(value["disposition"])),
        predicted_interventions=predictions,
        cited_evidence_ids=tuple(str(item) for item in value["cited_evidence_ids"]),
        limitations=tuple(str(item) for item in value["limitations"]),
    )


def run_closed_scientist_development_episode(
    public: GeneratedWorldPublicPacket,
    authority: GeneratedWorldAuthority,
    *,
    output_dir: Path,
    exchange: CodexStructuredExchange,
    budget: ResourceBudget = ResourceBudget(50_000, 4, 18, 900.0, 1.0),
    host_authorization_audited: bool = False,
) -> GeneratedClosedArmResult:
    if not public.development_only:
        raise ValueError("development runner cannot open a confirmatory episode")
    instrument = GeneratedWorldInstrument(public, authority)
    store = ArtifactStore(Path(output_dir) / "artifacts")
    ledger = AuthoritativeResearchLedger(
        run_id="closed-scientist:%s" % public.episode_id,
        objective_id=content_digest(public.research_question),
        budget=budget,
        controller=ActorIdentity(
            "generated-world-policy-v1", ActorKind.SCIENTIST_POLICY
        ),
        artifact_store=store,
    )
    runtime = AuthoritativeStateRuntime(
        ledger, Path(output_dir) / "authority-checkpoint.json"
    )
    runtime.save_checkpoint()

    design_action = _select_action(runtime, public.episode_id, "design_queries")
    design_operation = GENERATED_QUERY_OPERATION
    design_prompt = build_generated_query_prompt(public)
    design = exchange.request_audited(
        operation=design_operation,
        prompt=design_prompt,
        response_schema=_query_schema(
            len(public.variable_names), public.maximum_instrument_calls
        ),
    )
    _record_model(runtime, design_action, design_operation, design)
    proposed_queries = _parse_queries(design.response, public)
    proposed_query_plan_id = content_digest(
        {"queries": [item.as_dict() for item in proposed_queries]}
    )
    ledger.append(
        AutonomyEventKind.PROPOSAL_RECORDED,
        ActorIdentity(
            "codex-proposal-model:%s" % design.model_ref,
            ActorKind.PROPOSAL_MODEL,
        ),
        AuthorityScope.PROPOSE,
        action_id=design_action,
        payload={"proposed_queries": [item.as_dict() for item in proposed_queries]},
        input_artifact_ids=(design.response_digest,),
        output_artifact_ids=(proposed_query_plan_id,),
    )
    runtime.save_checkpoint()
    proposal_design_validation = validate_generated_query_identifiability(
        public,
        tuple((item.context, item.intervention) for item in proposed_queries),
    )
    if proposal_design_validation.accepted:
        queries = proposed_queries
        design_validation = proposal_design_validation
    else:
        contrast = generated_contrast_interventions(public)
        queries = tuple(
            ResearchQuery(context=context, intervention=intervention, replicate=0)
            for context in public.instrument_contexts
            for intervention in contrast
        )
        design_validation = validate_generated_query_identifiability(
            public,
            tuple((item.context, item.intervention) for item in queries),
        )
        if not design_validation.accepted:
            raise ValueError(
                "canonical generated-world design is not identifiable"
            )
    validation_outputs = (proposal_design_validation.certificate_id,)
    if design_validation.certificate_id != proposal_design_validation.certificate_id:
        validation_outputs = (
            proposal_design_validation.certificate_id,
            design_validation.certificate_id,
        )
    ledger.append(
        AutonomyEventKind.VERIFICATION_RECORDED,
        ActorIdentity(
            design_validation.validator_ref, ActorKind.DETERMINISTIC_VALIDATOR
        ),
        AuthorityScope.VERIFY,
        action_id=design_action,
        payload={
            "proposal_validation": proposal_design_validation.as_dict(),
            "authorized_validation": design_validation.as_dict(),
            "proposal_accepted": proposal_design_validation.accepted,
            "authorized_queries": [item.as_dict() for item in queries],
        },
        input_artifact_ids=(proposed_query_plan_id,),
        output_artifact_ids=validation_outputs,
    )
    runtime.save_checkpoint()
    _complete_action(runtime, design_action)

    instrument_action = _select_action(
        runtime, public.episode_id, "execute_queries"
    )
    observations = []
    for query in queries:
        started = time.perf_counter()
        observation = instrument.intervene(
            query.context,
            query.intervention,
            replicate=query.replicate,
        )
        elapsed = time.perf_counter() - started
        observations.append(observation)
        ledger.append(
            AutonomyEventKind.TOOL_RESULT_RECORDED,
            ActorIdentity(
                "generated-world-instrument-v1", ActorKind.TOOL_RUNTIME
            ),
            AuthorityScope.MEASURE,
            action_id=instrument_action,
            payload={"operation": "intervene", "query": query.as_dict()},
            input_artifact_ids=(query.query_id,),
            output_artifact_ids=(observation.observation_id,),
            resource_delta=ResourceUsage(tool_calls=1, wall_seconds=elapsed),
        )
        runtime.save_checkpoint()
    _complete_action(runtime, instrument_action)

    all_observations = (*public.starting_observations, *observations)
    evidence_ids = tuple(item.observation_id for item in all_observations)
    conclusion_action = _select_action(
        runtime, public.episode_id, "propose_conclusion"
    )
    conclusion_operation = GENERATED_CONCLUSION_OPERATION
    conclusion_prompt = build_generated_conclusion_prompt(public, all_observations)
    proposed = exchange.request_audited(
        operation=conclusion_operation,
        prompt=conclusion_prompt,
        response_schema=_conclusion_schema(),
    )
    if proposed.model_ref != design.model_ref:
        raise ValueError("generated-world arm changed model within an episode")
    _record_model(runtime, conclusion_action, conclusion_operation, proposed)
    model_sequester_audited = all(
        bool(item.worker.get("project_read_denial_preflight_passed"))
        for item in (design, proposed)
    )
    model_conclusion = _parse_conclusion(proposed.response, public)
    validation = validate_generated_hypotheses(
        public,
        all_observations,
        proposed_hypothesis_id=model_conclusion.selected_hypothesis_id,
    )
    conclusion = GeneratedResearchConclusion(
        episode_id=public.episode_id,
        selected_hypothesis_id=validation.selected_hypothesis_id,
        disposition=validation.disposition,
        predicted_interventions=validation.predicted_interventions,
        cited_evidence_ids=model_conclusion.cited_evidence_ids,
        limitations=model_conclusion.limitations,
    )
    ledger.append(
        AutonomyEventKind.PROPOSAL_RECORDED,
        ActorIdentity(
            "codex-proposal-model:%s" % proposed.model_ref,
            ActorKind.PROPOSAL_MODEL,
        ),
        AuthorityScope.PROPOSE,
        action_id=conclusion_action,
        payload={"model_proposal": model_conclusion.as_dict()},
        input_artifact_ids=evidence_ids,
        output_artifact_ids=(model_conclusion.conclusion_id,),
    )
    runtime.save_checkpoint()
    ledger.append(
        AutonomyEventKind.VERIFICATION_RECORDED,
        ActorIdentity(
            validation.validator_ref, ActorKind.DETERMINISTIC_VALIDATOR
        ),
        AuthorityScope.VERIFY,
        action_id=conclusion_action,
        payload={
            "validation": validation.as_dict(),
            "model_disposition_accepted": (
                model_conclusion.disposition == conclusion.disposition
            ),
            "model_hypothesis_accepted": (
                model_conclusion.selected_hypothesis_id
                == conclusion.selected_hypothesis_id
            ),
        },
        input_artifact_ids=(model_conclusion.conclusion_id, *evidence_ids),
        output_artifact_ids=(validation.certificate_id,),
    )
    runtime.save_checkpoint()
    ledger.append(
        AutonomyEventKind.STATE_COMMITTED,
        ActorIdentity("generated-world-policy-v1", ActorKind.SCIENTIST_POLICY),
        AuthorityScope.GOVERN,
        action_id=conclusion_action,
        payload={
            "authorized_conclusion": conclusion.as_dict(),
            "validation_certificate_id": validation.certificate_id,
        },
        input_artifact_ids=(validation.certificate_id,),
        output_artifact_ids=(conclusion.conclusion_id,),
    )
    runtime.save_checkpoint()
    _complete_action(runtime, conclusion_action)

    score_action = _select_action(runtime, public.episode_id, "verify_conclusion")
    score = score_generated_world(
        public,
        authority,
        conclusion,
        accessible_evidence_ids=evidence_ids,
        trace_complete=(
            ledger.verify_chain()
            and host_authorization_audited
            and model_sequester_audited
            and validation.conclusive
        ),
        within_budget=budget.admits(ledger.state.usage),
    )
    score_id = content_digest(score.as_dict())
    ledger.append(
        AutonomyEventKind.VERIFICATION_RECORDED,
        ActorIdentity(
            authority.scorer_ref, ActorKind.DETERMINISTIC_VALIDATOR
        ),
        AuthorityScope.VERIFY,
        action_id=score_action,
        payload={"score": score.as_dict(), "authority_id": authority.authority_id},
        input_artifact_ids=(conclusion.conclusion_id, authority.authority_id),
        output_artifact_ids=(score_id,),
    )
    runtime.save_checkpoint()
    _complete_action(runtime, score_action)
    ledger.append(
        AutonomyEventKind.RUN_TERMINATED,
        ActorIdentity("generated-world-policy-v1", ActorKind.SCIENTIST_POLICY),
        AuthorityScope.GOVERN,
        payload={"root_advance": score.root_advance},
    )
    runtime.save_checkpoint()
    if not ledger.verify_chain():
        raise ValueError("generated-world arm produced an invalid authority chain")
    state = ledger.state
    result = GeneratedClosedArmResult(
        episode_id=public.episode_id,
        conclusion=conclusion,
        score=score,
        authority_state_id=state.state_id,
        event_count=len(ledger.events),
        model_calls=state.usage.model_calls,
        model_tokens=state.usage.total_model_tokens,
        tool_calls=state.usage.tool_calls,
        human_interventions=state.human_intervention_count,
        out_of_band_interventions=state.out_of_band_intervention_count,
        host_authorization_audited=host_authorization_audited,
        model_sequester_audited=model_sequester_audited,
        model_ref=design.model_ref,
        prompt_protocol_id=GENERATED_PROMPT_PROTOCOL_ID,
        budget=budget,
        design_proposal_accepted=proposal_design_validation.accepted,
        design_validation_certificate_id=design_validation.certificate_id,
    )
    store.write_manifest("generated-world-closed-arm-result-v4", result.as_dict())
    return result
