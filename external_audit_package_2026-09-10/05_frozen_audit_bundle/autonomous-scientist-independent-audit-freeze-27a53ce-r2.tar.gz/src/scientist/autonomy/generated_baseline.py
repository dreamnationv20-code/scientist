from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

from scientist.autonomy.generated_arm import (
    GENERATED_CONCLUSION_OPERATION,
    GENERATED_PROMPT_PROTOCOL_ID,
    GENERATED_QUERY_OPERATION,
    _conclusion_schema,
    _model_usage,
    _parse_conclusion,
    _parse_queries,
    _query_schema,
    build_generated_conclusion_prompt,
    build_generated_query_prompt,
)
from scientist.autonomy.generated_worlds import (
    GeneratedResearchConclusion,
    GeneratedWorldAuthority,
    GeneratedWorldInstrument,
    GeneratedWorldPublicPacket,
    GeneratedWorldScore,
    score_generated_world,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    AuthoritativeResearchLedger,
    AuthoritativeStateRuntime,
    AutonomyEventKind,
    ResourceBudget,
    ResourceUsage,
)
from scientist.codex_exchange import CodexStructuredExchange
from scientist.core.artifacts import ArtifactStore, content_digest


GENERATED_STANDALONE_VERSION = "scientist-generated-world-standalone-codex-v1"
_ACCOUNTING_ACTOR = ActorIdentity(
    "standalone-codex-accounting-runtime-v1", ActorKind.SCIENTIST_POLICY
)


@dataclass(frozen=True)
class GeneratedStandaloneCodexResult:
    episode_id: str
    conclusion: GeneratedResearchConclusion
    score: GeneratedWorldScore
    authority_state_id: str
    event_count: int
    model_calls: int
    model_tokens: int
    tool_calls: int
    human_interventions: int
    out_of_band_interventions: int
    host_authorization_audited: bool
    model_ref: str
    prompt_protocol_id: str
    budget: ResourceBudget

    @property
    def execution_autonomous(self) -> bool:
        return all(
            (
                self.host_authorization_audited,
                self.human_interventions == 0,
                self.out_of_band_interventions == 0,
            )
        )

    @property
    def result_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": GENERATED_STANDALONE_VERSION,
            "arm_kind": "structured_standalone_codex",
            "scientific_decision_source": "codex_model_output",
            "independent_authority_before_hidden_score": False,
            "episode_id": self.episode_id,
            "conclusion": self.conclusion.as_dict(),
            "score": self.score.as_dict(),
            "authority_state_id": self.authority_state_id,
            "event_count": self.event_count,
            "model_calls": self.model_calls,
            "model_tokens": self.model_tokens,
            "tool_calls": self.tool_calls,
            "human_interventions": self.human_interventions,
            "out_of_band_interventions": self.out_of_band_interventions,
            "host_authorization_audited": self.host_authorization_audited,
            "execution_autonomous": self.execution_autonomous,
            "model_ref": self.model_ref,
            "prompt_protocol_id": self.prompt_protocol_id,
            "budget": self.budget.as_dict(),
        }
        if include_id:
            value["result_id"] = self.result_id
        return value


def _select_action(
    runtime: AuthoritativeStateRuntime,
    episode_id: str,
    name: str,
) -> str:
    action_id = content_digest(
        {
            "version": GENERATED_STANDALONE_VERSION,
            "episode_id": episode_id,
            "action": name,
        }
    )
    runtime.ledger.append(
        AutonomyEventKind.ACTION_SELECTED,
        _ACCOUNTING_ACTOR,
        AuthorityScope.GOVERN,
        action_id=action_id,
        payload={
            "action": name,
            "episode_id": episode_id,
            "role": "resource_and_provenance_accounting_only",
        },
    )
    runtime.save_checkpoint()
    return action_id


def _complete_action(runtime: AuthoritativeStateRuntime, action_id: str) -> None:
    runtime.ledger.append(
        AutonomyEventKind.ACTION_COMPLETED,
        _ACCOUNTING_ACTOR,
        AuthorityScope.GOVERN,
        action_id=action_id,
        payload={"completed": True},
    )
    runtime.save_checkpoint()


def _record_model(
    runtime: AuthoritativeStateRuntime,
    action_id: str,
    operation: str,
    audited: Any,
) -> None:
    runtime.ledger.append(
        AutonomyEventKind.MODEL_EXCHANGE_RECORDED,
        ActorIdentity(
            "standalone-codex:%s" % audited.model_ref,
            ActorKind.PROPOSAL_MODEL,
        ),
        AuthorityScope.PROPOSE,
        action_id=action_id,
        payload={"operation": operation, "packet_id": audited.packet_id},
        input_artifact_ids=(audited.request_digest,),
        output_artifact_ids=(audited.response_digest,),
        resource_delta=_model_usage(audited),
    )
    runtime.save_checkpoint()


def run_standalone_codex_development_episode(
    public: GeneratedWorldPublicPacket,
    authority: GeneratedWorldAuthority,
    *,
    output_dir: Path,
    exchange: CodexStructuredExchange,
    budget: ResourceBudget = ResourceBudget(50_000, 4, 18, 900.0, 1.0),
    host_authorization_audited: bool = False,
) -> GeneratedStandaloneCodexResult:
    """Run the matched structured Codex-only development comparison.

    The accounting runtime records provenance and enforces the common resource
    ceiling, but it never changes Codex's scientific conclusion. Hidden scoring
    occurs only after that conclusion is terminal.
    """

    if not public.development_only:
        raise ValueError("development runner cannot open a confirmatory episode")
    instrument = GeneratedWorldInstrument(public, authority)
    store = ArtifactStore(Path(output_dir) / "artifacts")
    ledger = AuthoritativeResearchLedger(
        run_id="standalone-codex:%s" % public.episode_id,
        objective_id=content_digest(public.research_question),
        budget=budget,
        controller=_ACCOUNTING_ACTOR,
        artifact_store=store,
    )
    runtime = AuthoritativeStateRuntime(
        ledger, Path(output_dir) / "authority-checkpoint.json"
    )
    runtime.save_checkpoint()

    design_action = _select_action(runtime, public.episode_id, "design_queries")
    design = exchange.request_audited(
        operation=GENERATED_QUERY_OPERATION,
        prompt=build_generated_query_prompt(public),
        response_schema=_query_schema(
            len(public.variable_names), public.maximum_instrument_calls
        ),
    )
    _record_model(runtime, design_action, GENERATED_QUERY_OPERATION, design)
    queries = _parse_queries(design.response, public)
    _complete_action(runtime, design_action)

    instrument_action = _select_action(runtime, public.episode_id, "execute_queries")
    observations = []
    for query in queries:
        started = time.perf_counter()
        observation = instrument.intervene(
            query.context,
            query.intervention,
            replicate=query.replicate,
        )
        elapsed = time.perf_counter() - started
        observations.append(observation)
        ledger.append(
            AutonomyEventKind.TOOL_RESULT_RECORDED,
            ActorIdentity(
                "generated-world-instrument-v1", ActorKind.TOOL_RUNTIME
            ),
            AuthorityScope.MEASURE,
            action_id=instrument_action,
            payload={"operation": "intervene", "query": query.as_dict()},
            input_artifact_ids=(query.query_id,),
            output_artifact_ids=(observation.observation_id,),
            resource_delta=ResourceUsage(tool_calls=1, wall_seconds=elapsed),
        )
        runtime.save_checkpoint()
    _complete_action(runtime, instrument_action)

    all_observations = (*public.starting_observations, *observations)
    evidence_ids = tuple(item.observation_id for item in all_observations)
    conclusion_action = _select_action(
        runtime, public.episode_id, "make_terminal_conclusion"
    )
    proposed = exchange.request_audited(
        operation=GENERATED_CONCLUSION_OPERATION,
        prompt=build_generated_conclusion_prompt(public, all_observations),
        response_schema=_conclusion_schema(),
    )
    if proposed.model_ref != design.model_ref:
        raise ValueError("standalone Codex changed model within an episode")
    _record_model(
        runtime, conclusion_action, GENERATED_CONCLUSION_OPERATION, proposed
    )
    conclusion = _parse_conclusion(proposed.response, public)
    ledger.append(
        AutonomyEventKind.PROPOSAL_RECORDED,
        ActorIdentity(
            "standalone-codex:%s" % proposed.model_ref,
            ActorKind.PROPOSAL_MODEL,
        ),
        AuthorityScope.PROPOSE,
        action_id=conclusion_action,
        payload={
            "terminal_model_conclusion": conclusion.as_dict(),
            "independent_authority_applied": False,
        },
        input_artifact_ids=evidence_ids,
        output_artifact_ids=(conclusion.conclusion_id,),
    )
    runtime.save_checkpoint()
    _complete_action(runtime, conclusion_action)

    score_action = _select_action(runtime, public.episode_id, "score_terminal_output")
    score = score_generated_world(
        public,
        authority,
        conclusion,
        accessible_evidence_ids=evidence_ids,
        trace_complete=(ledger.verify_chain() and host_authorization_audited),
        within_budget=budget.admits(ledger.state.usage),
    )
    score_id = content_digest(score.as_dict())
    ledger.append(
        AutonomyEventKind.VERIFICATION_RECORDED,
        ActorIdentity(authority.scorer_ref, ActorKind.DETERMINISTIC_VALIDATOR),
        AuthorityScope.VERIFY,
        action_id=score_action,
        payload={
            "score": score.as_dict(),
            "authority_id": authority.authority_id,
            "post_terminal_scoring_only": True,
        },
        input_artifact_ids=(conclusion.conclusion_id, authority.authority_id),
        output_artifact_ids=(score_id,),
    )
    runtime.save_checkpoint()
    _complete_action(runtime, score_action)
    ledger.append(
        AutonomyEventKind.RUN_TERMINATED,
        _ACCOUNTING_ACTOR,
        AuthorityScope.GOVERN,
        payload={"root_advance": score.root_advance},
    )
    runtime.save_checkpoint()
    if not ledger.verify_chain():
        raise ValueError("standalone Codex arm produced an invalid provenance chain")

    state = ledger.state
    result = GeneratedStandaloneCodexResult(
        episode_id=public.episode_id,
        conclusion=conclusion,
        score=score,
        authority_state_id=state.state_id,
        event_count=len(ledger.events),
        model_calls=state.usage.model_calls,
        model_tokens=state.usage.total_model_tokens,
        tool_calls=state.usage.tool_calls,
        human_interventions=state.human_intervention_count,
        out_of_band_interventions=state.out_of_band_intervention_count,
        host_authorization_audited=host_authorization_audited,
        model_ref=design.model_ref,
        prompt_protocol_id=GENERATED_PROMPT_PROTOCOL_ID,
        budget=budget,
    )
    store.write_manifest("generated-world-standalone-codex-result-v1", result.as_dict())
    return result
