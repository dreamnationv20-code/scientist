from __future__ import annotations

from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.generated_worlds import (
    CandidateHypothesis,
    EpisodeDisposition,
    GeneratedWorldPublicPacket,
    HiddenRuleKind,
    PublicObservation,
)
from scientist.core.artifacts import content_digest


GENERATED_VALIDATION_VERSION = "generated-world-hypothesis-validation-v1"
GENERATED_DESIGN_VALIDATION_VERSION = "generated-world-design-identifiability-v1"


def _context_key(context: Sequence[int]) -> str:
    return "".join(str(int(value)) for value in context)


@dataclass(frozen=True)
class HypothesisEvidenceScore:
    hypothesis_id: str
    rule_kind: HiddenRuleKind
    covered_context_count: int
    covered_zero_context_count: int
    covered_one_context_count: int
    mean_predicted_advantage: float
    minimum_predicted_advantage: float
    maximum_observed_range: float
    support_passed: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": GENERATED_VALIDATION_VERSION,
            "hypothesis_id": self.hypothesis_id,
            "rule_kind": self.rule_kind.value,
            "covered_context_count": self.covered_context_count,
            "covered_zero_context_count": self.covered_zero_context_count,
            "covered_one_context_count": self.covered_one_context_count,
            "mean_predicted_advantage": self.mean_predicted_advantage,
            "minimum_predicted_advantage": self.minimum_predicted_advantage,
            "maximum_observed_range": self.maximum_observed_range,
            "support_passed": self.support_passed,
        }


@dataclass(frozen=True)
class GeneratedHypothesisValidation:
    episode_id: str
    selected_hypothesis_id: str
    disposition: EpisodeDisposition
    predicted_interventions: Mapping[str, str]
    scores: Tuple[HypothesisEvidenceScore, ...]
    conclusive: bool
    decision_reason: str
    validator_ref: str

    @property
    def certificate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": GENERATED_VALIDATION_VERSION,
            "episode_id": self.episode_id,
            "selected_hypothesis_id": self.selected_hypothesis_id,
            "disposition": self.disposition.value,
            "predicted_interventions": dict(
                sorted(self.predicted_interventions.items())
            ),
            "scores": [item.as_dict() for item in self.scores],
            "conclusive": self.conclusive,
            "decision_reason": self.decision_reason,
            "validator_ref": self.validator_ref,
        }
        if include_id:
            value["certificate_id"] = self.certificate_id
        return value


@dataclass(frozen=True)
class GeneratedDesignIdentifiability:
    episode_id: str
    paired_contexts: Tuple[Tuple[int, ...], ...]
    coverage_passed: bool
    signatures_unique: bool
    aliased_hypothesis_groups: Tuple[Tuple[str, ...], ...]
    accepted: bool
    decision_reason: str
    validator_ref: str

    @property
    def certificate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": GENERATED_DESIGN_VALIDATION_VERSION,
            "episode_id": self.episode_id,
            "paired_contexts": [list(item) for item in self.paired_contexts],
            "coverage_passed": self.coverage_passed,
            "signatures_unique": self.signatures_unique,
            "aliased_hypothesis_groups": [
                list(item) for item in self.aliased_hypothesis_groups
            ],
            "accepted": self.accepted,
            "decision_reason": self.decision_reason,
            "validator_ref": self.validator_ref,
        }
        if include_id:
            value["certificate_id"] = self.certificate_id
        return value


def generated_contrast_interventions(
    public: GeneratedWorldPublicPacket,
) -> Tuple[str, str]:
    effects = tuple(
        item
        for item in public.hypotheses
        if item.rule_kind == HiddenRuleKind.BINARY_MODERATOR
    )
    if not effects:
        raise ValueError("generated world has no effect hypotheses")
    first = effects[0]
    contrast = (first.intervention_when_zero, first.intervention_when_one)
    expected = frozenset(contrast)
    if len(expected) != 2 or any(
        frozenset(
            (item.intervention_when_zero, item.intervention_when_one)
        )
        != expected
        for item in effects
    ):
        raise ValueError("candidate hypotheses do not share one binary contrast")
    return contrast


def validate_generated_query_identifiability(
    public: GeneratedWorldPublicPacket,
    query_pairs: Sequence[Tuple[Sequence[int], str]],
) -> GeneratedDesignIdentifiability:
    """Certify that a proposed instrument design separates all effect rules."""

    intervention_zero, intervention_one = generated_contrast_interventions(public)
    required = {intervention_zero, intervention_one}
    by_context: Dict[Tuple[int, ...], set] = {}
    for context, intervention in query_pairs:
        values = tuple(int(item) for item in context)
        by_context.setdefault(values, set()).add(str(intervention))
    paired = tuple(
        sorted(
            context
            for context, interventions in by_context.items()
            if required.issubset(interventions)
        )
    )
    gate = public.evidence_gate
    effect_hypotheses = tuple(
        item
        for item in public.hypotheses
        if item.rule_kind == HiddenRuleKind.BINARY_MODERATOR
    )
    coverage = len(paired) >= gate.minimum_paired_contexts
    for hypothesis in effect_hypotheses:
        moderator_index = public.variable_names.index(hypothesis.moderator_name)
        coverage = coverage and (
            sum(context[moderator_index] == 0 for context in paired)
            >= gate.minimum_contexts_per_binary_value
            and sum(context[moderator_index] == 1 for context in paired)
            >= gate.minimum_contexts_per_binary_value
        )
    signatures: Dict[Tuple[str, ...], list] = {}
    for hypothesis in effect_hypotheses:
        moderator_index = public.variable_names.index(hypothesis.moderator_name)
        signature = tuple(
            hypothesis.intervention_when_one
            if context[moderator_index]
            else hypothesis.intervention_when_zero
            for context in paired
        )
        signatures.setdefault(signature, []).append(hypothesis.hypothesis_id)
    aliases = tuple(
        sorted(
            tuple(sorted(group))
            for group in signatures.values()
            if len(group) > 1
        )
    )
    unique = bool(paired) and not aliases
    accepted = coverage and unique
    if not coverage:
        reason = "paired intervention coverage is insufficient"
    elif not unique:
        reason = "candidate causal rules remain observationally aliased"
    else:
        reason = "paired design uniquely identifies every candidate causal rule"
    return GeneratedDesignIdentifiability(
        episode_id=public.episode_id,
        paired_contexts=paired,
        coverage_passed=coverage,
        signatures_unique=unique,
        aliased_hypothesis_groups=aliases,
        accepted=accepted,
        decision_reason=reason,
        validator_ref="deterministic-generated-design-validator-v1",
    )


def _means_by_context(
    observations: Sequence[PublicObservation],
) -> Mapping[Tuple[int, ...], Mapping[str, float]]:
    buckets: Dict[Tuple[Tuple[int, ...], str], list] = {}
    for observation in observations:
        buckets.setdefault(
            (observation.context, observation.intervention), []
        ).append(observation.outcome)
    result: Dict[Tuple[int, ...], Dict[str, float]] = {}
    for (context, intervention), values in buckets.items():
        result.setdefault(context, {})[intervention] = float(mean(values))
    return result


def _score_hypothesis(
    public: GeneratedWorldPublicPacket,
    hypothesis: CandidateHypothesis,
    observations: Sequence[PublicObservation],
) -> HypothesisEvidenceScore:
    gate = public.evidence_gate
    by_context = _means_by_context(observations)
    ranges = tuple(
        max(values.values()) - min(values.values())
        for values in by_context.values()
        if len(values) >= 2
    )
    maximum_range = max(ranges, default=1.0)
    if hypothesis.rule_kind == HiddenRuleKind.NULL_EFFECT:
        covered = len(ranges)
        passed = (
            covered >= gate.minimum_paired_contexts
            and maximum_range <= gate.null_maximum_range
        )
        return HypothesisEvidenceScore(
            hypothesis_id=hypothesis.hypothesis_id,
            rule_kind=hypothesis.rule_kind,
            covered_context_count=covered,
            covered_zero_context_count=covered,
            covered_one_context_count=covered,
            mean_predicted_advantage=0.0,
            minimum_predicted_advantage=0.0,
            maximum_observed_range=maximum_range,
            support_passed=passed,
        )

    try:
        moderator_index = public.variable_names.index(hypothesis.moderator_name)
    except ValueError:
        return HypothesisEvidenceScore(
            hypothesis_id=hypothesis.hypothesis_id,
            rule_kind=hypothesis.rule_kind,
            covered_context_count=0,
            covered_zero_context_count=0,
            covered_one_context_count=0,
            mean_predicted_advantage=-1.0,
            minimum_predicted_advantage=-1.0,
            maximum_observed_range=maximum_range,
            support_passed=False,
        )
    advantages = []
    zero_count = 0
    one_count = 0
    for context, values in by_context.items():
        bit = context[moderator_index]
        predicted = (
            hypothesis.intervention_when_one
            if bit
            else hypothesis.intervention_when_zero
        )
        alternate = (
            hypothesis.intervention_when_zero
            if bit
            else hypothesis.intervention_when_one
        )
        if predicted not in values or alternate not in values:
            continue
        advantages.append(values[predicted] - values[alternate])
        zero_count += int(bit == 0)
        one_count += int(bit == 1)
    average = float(mean(advantages)) if advantages else -1.0
    minimum = min(advantages, default=-1.0)
    passed = all(
        (
            len(advantages) >= gate.minimum_paired_contexts,
            zero_count >= gate.minimum_contexts_per_binary_value,
            one_count >= gate.minimum_contexts_per_binary_value,
            average >= gate.minimum_mean_advantage,
            minimum >= gate.minimum_context_advantage,
        )
    )
    return HypothesisEvidenceScore(
        hypothesis_id=hypothesis.hypothesis_id,
        rule_kind=hypothesis.rule_kind,
        covered_context_count=len(advantages),
        covered_zero_context_count=zero_count,
        covered_one_context_count=one_count,
        mean_predicted_advantage=average,
        minimum_predicted_advantage=minimum,
        maximum_observed_range=maximum_range,
        support_passed=passed,
    )


def validate_generated_hypotheses(
    public: GeneratedWorldPublicPacket,
    observations: Sequence[PublicObservation],
    *,
    proposed_hypothesis_id: str,
) -> GeneratedHypothesisValidation:
    known = {item.hypothesis_id: item for item in public.hypotheses}
    if proposed_hypothesis_id not in known:
        raise ValueError("validator received an unknown proposed hypothesis")
    scores = tuple(
        _score_hypothesis(
            public,
            hypothesis,
            observations,
        )
        for hypothesis in public.hypotheses
    )
    supported_effects = tuple(
        score
        for score in scores
        if score.rule_kind == HiddenRuleKind.BINARY_MODERATOR
        and score.support_passed
    )
    null_score = next(
        score for score in scores if score.rule_kind == HiddenRuleKind.NULL_EFFECT
    )
    if len(supported_effects) == 1:
        selected_score = supported_effects[0]
        disposition = EpisodeDisposition.PROMOTE
        conclusive = True
        reason = "one moderator passed coverage, effect, and consistency gates"
    elif len(supported_effects) > 1:
        selected_score = next(
            score for score in scores if score.hypothesis_id == proposed_hypothesis_id
        )
        disposition = EpisodeDisposition.KILL
        conclusive = False
        reason = "multiple incompatible moderators passed; promotion is forbidden"
    elif null_score.support_passed:
        selected_score = null_score
        disposition = EpisodeDisposition.KILL
        conclusive = True
        reason = "the null passed paired-coverage and maximum-range gates"
    else:
        selected_score = next(
            score for score in scores if score.hypothesis_id == proposed_hypothesis_id
        )
        disposition = EpisodeDisposition.KILL
        conclusive = False
        reason = "no hypothesis passed its preregistered evidence gate"
    selected = known[selected_score.hypothesis_id]
    predictions = {}
    for context in public.evaluation_contexts:
        if selected.rule_kind == HiddenRuleKind.NULL_EFFECT:
            intervention = selected.intervention_when_zero
        else:
            moderator_index = public.variable_names.index(selected.moderator_name)
            intervention = (
                selected.intervention_when_one
                if context[moderator_index]
                else selected.intervention_when_zero
            )
        predictions[_context_key(context)] = intervention
    return GeneratedHypothesisValidation(
        episode_id=public.episode_id,
        selected_hypothesis_id=selected.hypothesis_id,
        disposition=disposition,
        predicted_interventions=predictions,
        scores=scores,
        conclusive=conclusive,
        decision_reason=reason,
        validator_ref="deterministic-generated-hypothesis-validator-v1",
    )
