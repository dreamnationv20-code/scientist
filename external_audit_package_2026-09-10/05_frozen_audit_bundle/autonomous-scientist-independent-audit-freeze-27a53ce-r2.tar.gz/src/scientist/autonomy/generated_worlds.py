from __future__ import annotations

import hashlib
import random
import re
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


GENERATED_WORLD_VERSION = "scientist-generated-research-world-v3"
_OPAQUE_EPISODE_REF = re.compile(r"episode-[0-9a-f]{32,64}")


def _unique(values: Sequence[str], label: str) -> Tuple[str, ...]:
    result = tuple(str(value) for value in values)
    if not result or not all(result) or len(result) != len(set(result)):
        raise ValueError("%s must contain unique non-empty values" % label)
    return result


class GeneratedResearchGrammar(str, Enum):
    CAUSAL_STATE_MACHINE = "causal_state_machine"


class HiddenRuleKind(str, Enum):
    BINARY_MODERATOR = "binary_moderator"
    NULL_EFFECT = "null_effect"


class EpisodeDisposition(str, Enum):
    PROMOTE = "promote"
    KILL = "kill"


@dataclass(frozen=True)
class GeneratedEvidenceGate:
    minimum_paired_contexts: int
    minimum_contexts_per_binary_value: int
    minimum_mean_advantage: float
    minimum_context_advantage: float
    null_maximum_range: float

    def __post_init__(self) -> None:
        if self.minimum_paired_contexts <= 0:
            raise ValueError("evidence gate requires paired contexts")
        if self.minimum_contexts_per_binary_value <= 0:
            raise ValueError("evidence gate requires binary-value coverage")
        if self.minimum_paired_contexts < 2 * self.minimum_contexts_per_binary_value:
            raise ValueError("paired-context floor cannot satisfy binary coverage")
        if not 0.0 < self.minimum_context_advantage <= self.minimum_mean_advantage:
            raise ValueError("effect-size gates are inconsistent")
        if not 0.0 < self.null_maximum_range < self.minimum_context_advantage:
            raise ValueError("null and positive gates overlap")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "minimum_paired_contexts": self.minimum_paired_contexts,
            "minimum_contexts_per_binary_value": (
                self.minimum_contexts_per_binary_value
            ),
            "minimum_mean_advantage": self.minimum_mean_advantage,
            "minimum_context_advantage": self.minimum_context_advantage,
            "null_maximum_range": self.null_maximum_range,
        }


@dataclass(frozen=True)
class PublicObservation:
    observation_ref: str
    context: Tuple[int, ...]
    intervention: str
    outcome: float

    def __post_init__(self) -> None:
        if not self.observation_ref or not self.intervention:
            raise ValueError("public observation identity is incomplete")
        if not self.context or any(value not in {0, 1} for value in self.context):
            raise ValueError("observation context must be binary")
        if not 0.0 <= self.outcome <= 1.0:
            raise ValueError("observation outcome must be in [0, 1]")

    @property
    def observation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "observation_ref": self.observation_ref,
            "context": list(self.context),
            "intervention": self.intervention,
            "outcome": self.outcome,
        }
        if include_id:
            value["observation_id"] = self.observation_id
        return value


@dataclass(frozen=True)
class CandidateHypothesis:
    hypothesis_ref: str
    rule_kind: HiddenRuleKind
    moderator_name: str
    intervention_when_zero: str
    intervention_when_one: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.hypothesis_ref,
                self.moderator_name,
                self.intervention_when_zero,
                self.intervention_when_one,
            )
        ):
            raise ValueError("candidate hypothesis is incomplete")

    @property
    def hypothesis_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "hypothesis_ref": self.hypothesis_ref,
            "rule_kind": self.rule_kind.value,
            "moderator_name": self.moderator_name,
            "intervention_when_zero": self.intervention_when_zero,
            "intervention_when_one": self.intervention_when_one,
        }
        if include_id:
            value["hypothesis_id"] = self.hypothesis_id
        return value


@dataclass(frozen=True)
class GeneratedWorldPublicPacket:
    episode_ref: str
    grammar: GeneratedResearchGrammar
    variable_names: Tuple[str, ...]
    intervention_names: Tuple[str, ...]
    hypotheses: Tuple[CandidateHypothesis, ...]
    starting_observations: Tuple[PublicObservation, ...]
    instrument_contexts: Tuple[Tuple[int, ...], ...]
    evaluation_contexts: Tuple[Tuple[int, ...], ...]
    evidence_gate: GeneratedEvidenceGate
    maximum_instrument_calls: int
    research_question: str
    development_only: bool

    def __post_init__(self) -> None:
        if not self.episode_ref or not self.research_question:
            raise ValueError("generated-world public identity is incomplete")
        if not self.development_only and _OPAQUE_EPISODE_REF.fullmatch(
            self.episode_ref
        ) is None:
            raise ValueError(
                "confirmatory episode references must be opaque high-entropy identifiers"
            )
        _unique(self.variable_names, "world variables")
        _unique(self.intervention_names, "world interventions")
        if len(self.variable_names) < 3 or len(self.intervention_names) < 2:
            raise ValueError("generated world is too small to discriminate")
        _unique(
            tuple(item.hypothesis_id for item in self.hypotheses),
            "world hypotheses",
        )
        if any(
            len(item.context) != len(self.variable_names)
            or item.intervention not in self.intervention_names
            for item in self.starting_observations
        ):
            raise ValueError("starting observation escaped the public vocabulary")
        if not self.instrument_contexts or any(
            len(context) != len(self.variable_names)
            or any(value not in {0, 1} for value in context)
            for context in self.instrument_contexts
        ):
            raise ValueError("instrument contexts must use the public binary vocabulary")
        if len(self.instrument_contexts) != len(set(self.instrument_contexts)):
            raise ValueError("instrument contexts must be unique")
        if not self.evaluation_contexts or any(
            len(context) != len(self.variable_names)
            or any(value not in {0, 1} for value in context)
            for context in self.evaluation_contexts
        ):
            raise ValueError("evaluation contexts must use the public binary vocabulary")
        if len(self.evaluation_contexts) != len(set(self.evaluation_contexts)):
            raise ValueError("evaluation contexts must be unique")
        if set(self.instrument_contexts).intersection(self.evaluation_contexts):
            raise ValueError("instrument and evaluation contexts must be disjoint")
        if self.maximum_instrument_calls <= 0:
            raise ValueError("world instrument budget must be positive")

    @property
    def episode_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": GENERATED_WORLD_VERSION,
            "episode_ref": self.episode_ref,
            "grammar": self.grammar.value,
            "variable_names": list(self.variable_names),
            "intervention_names": list(self.intervention_names),
            "hypotheses": [item.as_dict() for item in self.hypotheses],
            "starting_observations": [
                item.as_dict() for item in self.starting_observations
            ],
            "instrument_contexts": [
                list(item) for item in self.instrument_contexts
            ],
            "evaluation_contexts": [
                list(item) for item in self.evaluation_contexts
            ],
            "evidence_gate": self.evidence_gate.as_dict(),
            "maximum_instrument_calls": self.maximum_instrument_calls,
            "research_question": self.research_question,
            "development_only": self.development_only,
        }
        if include_id:
            value["episode_id"] = self.episode_id
        return value


@dataclass(frozen=True)
class GeneratedWorldAuthority:
    episode_id: str
    rule_kind: HiddenRuleKind
    moderator_index: int
    intervention_when_zero: str
    intervention_when_one: str
    sealed_contexts: Tuple[Tuple[int, ...], ...]
    generator_seed: int
    scorer_ref: str

    def __post_init__(self) -> None:
        if not self.episode_id or not self.scorer_ref:
            raise ValueError("generated-world authority identity is incomplete")
        if self.moderator_index < 0:
            raise ValueError("moderator index cannot be negative")
        if not self.sealed_contexts or len(self.sealed_contexts) != len(
            set(self.sealed_contexts)
        ):
            raise ValueError("sealed contexts must be unique and non-empty")
        if self.generator_seed < 0:
            raise ValueError("generator seed cannot be negative")

    @property
    def authority_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": GENERATED_WORLD_VERSION,
            "episode_id": self.episode_id,
            "rule_kind": self.rule_kind.value,
            "moderator_index": self.moderator_index,
            "intervention_when_zero": self.intervention_when_zero,
            "intervention_when_one": self.intervention_when_one,
            "sealed_contexts": [list(item) for item in self.sealed_contexts],
            "generator_seed": self.generator_seed,
            "scorer_ref": self.scorer_ref,
        }
        if include_id:
            value["authority_id"] = self.authority_id
        return value


@dataclass(frozen=True)
class GeneratedResearchConclusion:
    episode_id: str
    selected_hypothesis_id: str
    disposition: EpisodeDisposition
    predicted_interventions: Mapping[str, str]
    cited_evidence_ids: Tuple[str, ...]
    limitations: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.episode_id or not self.selected_hypothesis_id:
            raise ValueError("generated-world conclusion is incomplete")
        if not self.predicted_interventions:
            raise ValueError("conclusion requires sealed-context predictions")
        _unique(self.cited_evidence_ids, "conclusion evidence")

    @property
    def conclusion_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": GENERATED_WORLD_VERSION,
            "episode_id": self.episode_id,
            "selected_hypothesis_id": self.selected_hypothesis_id,
            "disposition": self.disposition.value,
            "predicted_interventions": dict(
                sorted(self.predicted_interventions.items())
            ),
            "cited_evidence_ids": list(self.cited_evidence_ids),
            "limitations": list(self.limitations),
        }
        if include_id:
            value["conclusion_id"] = self.conclusion_id
        return value


@dataclass(frozen=True)
class GeneratedWorldScore:
    episode_id: str
    conclusion_id: str
    hypothesis_correct: bool
    disposition_correct: bool
    sealed_predictions_correct: bool
    evidence_grounded: bool
    trace_complete: bool
    within_budget: bool
    promoted: bool

    @property
    def root_advance(self) -> bool:
        return all(
            (
                self.hypothesis_correct,
                self.disposition_correct,
                self.sealed_predictions_correct,
                self.evidence_grounded,
                self.trace_complete,
                self.within_budget,
            )
        )

    @property
    def false_promotion(self) -> bool:
        return self.promoted and (
            not self.hypothesis_correct or not self.sealed_predictions_correct
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": GENERATED_WORLD_VERSION,
            "episode_id": self.episode_id,
            "conclusion_id": self.conclusion_id,
            "hypothesis_correct": self.hypothesis_correct,
            "disposition_correct": self.disposition_correct,
            "sealed_predictions_correct": self.sealed_predictions_correct,
            "evidence_grounded": self.evidence_grounded,
            "trace_complete": self.trace_complete,
            "within_budget": self.within_budget,
            "promoted": self.promoted,
            "root_advance": self.root_advance,
            "false_promotion": self.false_promotion,
        }


def _context_key(context: Sequence[int]) -> str:
    if not context or any(value not in {0, 1} for value in context):
        raise ValueError("context key requires binary values")
    return "".join(str(value) for value in context)


def _noise(seed: int, context: Sequence[int], intervention: str, replicate: int) -> float:
    token = "%d|%s|%s|%d" % (
        seed,
        _context_key(context),
        intervention,
        replicate,
    )
    raw = int(hashlib.sha256(token.encode("utf-8")).hexdigest()[:8], 16)
    return ((raw / 0xFFFFFFFF) - 0.5) * 0.08


def _optimal_intervention(
    authority: GeneratedWorldAuthority,
    context: Sequence[int],
) -> str:
    if authority.rule_kind == HiddenRuleKind.NULL_EFFECT:
        return authority.intervention_when_zero
    return (
        authority.intervention_when_one
        if context[authority.moderator_index]
        else authority.intervention_when_zero
    )


class GeneratedWorldInstrument:
    """Candidate-visible development instrument; sealed contexts stay hidden."""

    def __init__(
        self,
        public: GeneratedWorldPublicPacket,
        authority: GeneratedWorldAuthority,
    ) -> None:
        if public.episode_id != authority.episode_id:
            raise ValueError("public world and hidden authority disagree")
        if tuple(public.evaluation_contexts) != tuple(authority.sealed_contexts):
            raise ValueError("public evaluation contexts and authority disagree")
        self.public = public
        self._authority = authority
        self._calls = 0
        self._observations = []

    @property
    def call_count(self) -> int:
        return self._calls

    @property
    def observation_ids(self) -> Tuple[str, ...]:
        return tuple(item.observation_id for item in self._observations)

    def intervene(
        self,
        context: Sequence[int],
        intervention: str,
        *,
        replicate: int = 0,
    ) -> PublicObservation:
        values = tuple(int(value) for value in context)
        if len(values) != len(self.public.variable_names):
            raise ValueError("instrument context has the wrong width")
        if values in self._authority.sealed_contexts:
            raise ValueError("sealed evaluation contexts are not instrument-accessible")
        if values not in self.public.instrument_contexts:
            raise ValueError("context is outside the public instrument surface")
        if intervention not in self.public.intervention_names:
            raise ValueError("unknown intervention")
        if replicate < 0:
            raise ValueError("replicate must be non-negative")
        if self._calls >= self.public.maximum_instrument_calls:
            raise ValueError("generated-world instrument budget exhausted")
        self._calls += 1
        optimum = _optimal_intervention(self._authority, values)
        base = 0.82 if intervention == optimum else 0.28
        if self._authority.rule_kind == HiddenRuleKind.NULL_EFFECT:
            base = 0.55
        outcome = min(
            1.0,
            max(
                0.0,
                base
                + _noise(
                    self._authority.generator_seed,
                    values,
                    intervention,
                    replicate,
                ),
            ),
        )
        observation = PublicObservation(
            observation_ref="instrument-%03d" % self._calls,
            context=values,
            intervention=intervention,
            outcome=outcome,
        )
        self._observations.append(observation)
        return observation


def generate_causal_state_machine_world(
    seed: int,
    *,
    development_only: bool,
    episode_ref: str | None = None,
) -> Tuple[GeneratedWorldPublicPacket, GeneratedWorldAuthority]:
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("generated-world seed must be a non-negative integer")
    if episode_ref is None:
        if not development_only:
            raise ValueError(
                "confirmatory generation requires a sequestered opaque episode reference"
            )
        resolved_episode_ref = "development-causal-state-machine-%08d" % seed
    else:
        resolved_episode_ref = str(episode_ref)
        if not resolved_episode_ref:
            raise ValueError("episode reference must not be empty")
    rng = random.Random(seed)
    vocabulary = [
        "phase_lock",
        "source_binding",
        "buffer_freshness",
        "commit_order",
        "trace_depth",
        "state_aliasing",
    ]
    interventions = [
        "extra_compute",
        "explicit_state",
        "verification",
        "tool_query",
    ]
    rng.shuffle(vocabulary)
    rng.shuffle(interventions)
    variable_names = tuple(vocabulary[:3])
    intervention_names = tuple(interventions[:3])
    rule_kind = (
        HiddenRuleKind.NULL_EFFECT
        if seed % 5 == 0
        else HiddenRuleKind.BINARY_MODERATOR
    )
    moderator_index = rng.randrange(len(variable_names))
    intervention_zero, intervention_one = rng.sample(intervention_names, 2)
    hypotheses = []
    for index, variable in enumerate(variable_names):
        hypotheses.append(
            CandidateHypothesis(
                hypothesis_ref="moderator-%s" % variable,
                rule_kind=HiddenRuleKind.BINARY_MODERATOR,
                moderator_name=variable,
                intervention_when_zero=intervention_zero,
                intervention_when_one=intervention_one,
            )
        )
        hypotheses.append(
            CandidateHypothesis(
                hypothesis_ref="reversed-%s" % variable,
                rule_kind=HiddenRuleKind.BINARY_MODERATOR,
                moderator_name=variable,
                intervention_when_zero=intervention_one,
                intervention_when_one=intervention_zero,
            )
        )
    hypotheses.append(
        CandidateHypothesis(
            hypothesis_ref="null-effect",
            rule_kind=HiddenRuleKind.NULL_EFFECT,
            moderator_name="none",
            intervention_when_zero=intervention_zero,
            intervention_when_one=intervention_zero,
        )
    )
    all_contexts = tuple(
        (a, b, c)
        for a in (0, 1)
        for b in (0, 1)
        for c in (0, 1)
    )
    shuffled_contexts = list(all_contexts)
    rng.shuffle(shuffled_contexts)
    sealed_contexts = tuple(sorted(shuffled_contexts[:2]))
    instrument_contexts = tuple(sorted(shuffled_contexts[2:]))
    evidence_gate = GeneratedEvidenceGate(
        minimum_paired_contexts=4,
        minimum_contexts_per_binary_value=2,
        minimum_mean_advantage=0.20,
        minimum_context_advantage=0.10,
        null_maximum_range=0.08,
    )

    # Build a provisional public packet to obtain its identity, then construct
    # authority and observations without ever serializing authority into it.
    provisional = GeneratedWorldPublicPacket(
        episode_ref=resolved_episode_ref,
        grammar=GeneratedResearchGrammar.CAUSAL_STATE_MACHINE,
        variable_names=variable_names,
        intervention_names=intervention_names,
        hypotheses=tuple(hypotheses),
        starting_observations=(),
        instrument_contexts=instrument_contexts,
        evaluation_contexts=sealed_contexts,
        evidence_gate=evidence_gate,
        maximum_instrument_calls=18,
        research_question=(
            "Which answer-blind state variable, if any, determines which "
            "intervention improves the delayed outcome?"
        ),
        development_only=development_only,
    )
    provisional_authority = GeneratedWorldAuthority(
        episode_id=provisional.episode_id,
        rule_kind=rule_kind,
        moderator_index=moderator_index,
        intervention_when_zero=intervention_zero,
        intervention_when_one=intervention_one,
        sealed_contexts=sealed_contexts,
        generator_seed=seed,
        scorer_ref="sealed-generated-world-scorer-v1",
    )
    # Starting data are deliberately balanced but sparse. They cannot include
    # the two sealed contexts and use only one replicate.
    observations = []
    for index, context in enumerate(
        item for item in shuffled_contexts[2:6] if item not in sealed_contexts
    ):
        intervention = intervention_names[index % len(intervention_names)]
        optimum = _optimal_intervention(provisional_authority, context)
        base = 0.82 if intervention == optimum else 0.28
        if rule_kind == HiddenRuleKind.NULL_EFFECT:
            base = 0.55
        observations.append(
            PublicObservation(
                observation_ref="starting-%02d" % index,
                context=context,
                intervention=intervention,
                outcome=min(
                    1.0,
                    max(0.0, base + _noise(seed, context, intervention, 0)),
                ),
            )
        )
    public = GeneratedWorldPublicPacket(
        episode_ref=provisional.episode_ref,
        grammar=provisional.grammar,
        variable_names=provisional.variable_names,
        intervention_names=provisional.intervention_names,
        hypotheses=provisional.hypotheses,
        starting_observations=tuple(observations),
        instrument_contexts=provisional.instrument_contexts,
        evaluation_contexts=provisional.evaluation_contexts,
        evidence_gate=provisional.evidence_gate,
        maximum_instrument_calls=provisional.maximum_instrument_calls,
        research_question=provisional.research_question,
        development_only=development_only,
    )
    # The public identity legitimately changes when starting evidence is added.
    authority = GeneratedWorldAuthority(
        episode_id=public.episode_id,
        rule_kind=rule_kind,
        moderator_index=moderator_index,
        intervention_when_zero=intervention_zero,
        intervention_when_one=intervention_one,
        sealed_contexts=sealed_contexts,
        generator_seed=seed,
        scorer_ref="sealed-generated-world-scorer-v1",
    )
    return public, authority


def oracle_conclusion(
    public: GeneratedWorldPublicPacket,
    authority: GeneratedWorldAuthority,
    evidence_ids: Sequence[str],
) -> GeneratedResearchConclusion:
    expected_hypothesis = next(
        item
        for item in public.hypotheses
        if (
            item.rule_kind == authority.rule_kind
            and (
                authority.rule_kind == HiddenRuleKind.NULL_EFFECT
                or (
                    item.moderator_name
                    == public.variable_names[authority.moderator_index]
                    and item.intervention_when_zero
                    == authority.intervention_when_zero
                    and item.intervention_when_one
                    == authority.intervention_when_one
                )
            )
        )
    )
    predictions = {
        _context_key(context): _optimal_intervention(authority, context)
        for context in authority.sealed_contexts
    }
    return GeneratedResearchConclusion(
        episode_id=public.episode_id,
        selected_hypothesis_id=expected_hypothesis.hypothesis_id,
        disposition=(
            EpisodeDisposition.KILL
            if authority.rule_kind == HiddenRuleKind.NULL_EFFECT
            else EpisodeDisposition.PROMOTE
        ),
        predicted_interventions=predictions,
        cited_evidence_ids=tuple(evidence_ids),
        limitations=("valid only for the generated episode vocabulary",),
    )


def score_generated_world(
    public: GeneratedWorldPublicPacket,
    authority: GeneratedWorldAuthority,
    conclusion: GeneratedResearchConclusion,
    *,
    accessible_evidence_ids: Sequence[str],
    trace_complete: bool,
    within_budget: bool,
) -> GeneratedWorldScore:
    if public.episode_id != authority.episode_id:
        raise ValueError("public episode and scorer authority disagree")
    if conclusion.episode_id != public.episode_id:
        raise ValueError("conclusion belongs to another episode")
    oracle = oracle_conclusion(public, authority, conclusion.cited_evidence_ids)
    expected_disposition = oracle.disposition
    expected_predictions = oracle.predicted_interventions
    evidence = set(accessible_evidence_ids)
    return GeneratedWorldScore(
        episode_id=public.episode_id,
        conclusion_id=conclusion.conclusion_id,
        hypothesis_correct=(
            conclusion.selected_hypothesis_id == oracle.selected_hypothesis_id
        ),
        disposition_correct=conclusion.disposition == expected_disposition,
        sealed_predictions_correct=(
            dict(conclusion.predicted_interventions) == dict(expected_predictions)
        ),
        evidence_grounded=(
            bool(conclusion.cited_evidence_ids)
            and set(conclusion.cited_evidence_ids).issubset(evidence)
        ),
        trace_complete=trace_complete,
        within_budget=within_budget,
        promoted=conclusion.disposition == EpisodeDisposition.PROMOTE,
    )
