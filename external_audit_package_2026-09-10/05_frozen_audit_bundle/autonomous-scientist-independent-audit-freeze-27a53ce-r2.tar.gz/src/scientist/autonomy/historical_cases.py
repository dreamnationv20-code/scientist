from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Tuple

from scientist.autonomy.failure_adjudication import FailureEvidenceProfile
from scientist.autonomy.transitions import (
    FailureClass,
    RecoveryAction,
    TransitionAuthority,
    TransitionCase,
)
from scientist.core.provenance import bytes_sha256


@dataclass(frozen=True)
class HistoricalTransitionFixture:
    case: TransitionCase
    profile: FailureEvidenceProfile
    authority: TransitionAuthority


def _source_identity(path: Path) -> str:
    if path.suffix == ".json":
        value = json.loads(path.read_text(encoding="utf-8"))
        for field in (
            "checkpoint_id",
            "assessment_id",
            "audit_id",
            "summary_id",
        ):
            candidate = value.get(field) if isinstance(value, dict) else None
            if isinstance(candidate, str) and len(candidate) == 64:
                return candidate
    return bytes_sha256(path.read_bytes())


def _fixture(
    *,
    case_ref: str,
    phase: str,
    question: str,
    observations: Tuple[str, ...],
    available_actions: Tuple[RecoveryAction, ...],
    invariants: Tuple[str, ...],
    source_paths: Tuple[Path, ...],
    failure_class: FailureClass,
    action: RecoveryAction,
    profile_values,
) -> HistoricalTransitionFixture:
    evidence = tuple(_source_identity(path) for path in source_paths)
    case = TransitionCase(
        case_ref=case_ref,
        phase=phase,
        question=question,
        observations=observations,
        available_actions=available_actions,
        protected_invariants=invariants,
        evidence_refs=evidence,
        retrospective=True,
        domain="cognitive_core",
    )
    profile = FailureEvidenceProfile(case_id=case.case_id, **profile_values)
    authority = TransitionAuthority(
        case_id=case.case_id,
        primary_failure_class=failure_class,
        acceptable_secondary_classes=(),
        acceptable_actions=(action,),
        forbidden_actions=tuple(
            item for item in available_actions if item != action
        ),
        required_invariants=invariants,
        required_evidence_refs=evidence,
        adjudication_ref="sequestered-historical-audit-v1:%s" % case_ref,
    )
    return HistoricalTransitionFixture(case, profile, authority)


def historical_transition_fixtures(
    project_root: Path,
) -> Tuple[HistoricalTransitionFixture, ...]:
    root = Path(project_root).resolve()
    runs = root / "runs" / "cognitive_core"
    actions = tuple(RecoveryAction)
    common = {
        "runtime_available": True,
        "external_dependency_missing": False,
        "implementation_integrity_passed": True,
        "interface_qualified": True,
        "protocol_feasible": True,
        "measurement_qualified": True,
        "scientific_outcome_observed": False,
        "scientific_gate_passed": None,
        "representation_limit_demonstrated": False,
    }
    fixtures = (
        _fixture(
            case_ref="metal-device-unavailable",
            phase="execution",
            question="What should happen when the required local accelerator is absent?",
            observations=(
                "the sealed execution could not acquire an Apple Metal device",
                "no scientific outcome was produced",
            ),
            available_actions=actions,
            invariants=("model identity", "protocol", "unopened outcome"),
            source_paths=(
                runs
                / "repairability_semantic_observability_codex_v1_20260905"
                / "ENVIRONMENT_FAILURE.md",
            ),
            failure_class=FailureClass.EXTERNAL_DEPENDENCY,
            action=RecoveryAction.REQUEST_EXTERNAL_AUTHORITY,
            profile_values={
                **common,
                "runtime_available": False,
                "external_dependency_missing": True,
                "implementation_integrity_passed": None,
                "interface_qualified": None,
                "protocol_feasible": None,
                "measurement_qualified": None,
            },
        ),
        _fixture(
            case_ref="v62-noncanonical-adjudicator-key",
            phase="post_execution_adjudication",
            question="Do four completion events license a scientific interpretation after the adjudicator crashes?",
            observations=(
                "four model completions were emitted",
                "the post-run adjudicator referenced a noncanonical family key",
                "no metric vector or model record was sealed",
            ),
            available_actions=actions,
            invariants=("data", "seed", "schedule", "model", "gates"),
            source_paths=(
                runs / "training_recipe_state_bridge_v62_r1" / "DECISION_AUDIT.md",
            ),
            failure_class=FailureClass.IMPLEMENTATION,
            action=RecoveryAction.REPAIR_IMPLEMENTATION,
            profile_values={
                **common,
                "implementation_integrity_passed": False,
                "measurement_qualified": None,
            },
        ),
        _fixture(
            case_ref="v68t-infeasible-universal-checks",
            phase="protocol_preflight",
            question="Should training begin when universal feasibility checks are false for structural reasons?",
            observations=(
                "the generator never uses one declared operator class",
                "one-token answer-changing counterfactuals do not exist for every valid transition",
                "no model was trained",
            ),
            available_actions=actions,
            invariants=("unopened training", "future outcome gates", "source artifact"),
            source_paths=(
                runs
                / "training_recipe_trace_feasibility_v68t_r1"
                / "DECISION_AUDIT.md",
            ),
            failure_class=FailureClass.PROTOCOL,
            action=RecoveryAction.AMEND_PROTOCOL,
            profile_values={
                **common,
                "protocol_feasible": False,
                "measurement_qualified": None,
            },
        ),
        _fixture(
            case_ref="m44-free-form-proposal-interface",
            phase="proposal_delivery",
            question="Does a failed strict typed parse identify a scientific-policy failure?",
            observations=(
                "execution and integrity passed",
                "correct-dossier causal parse coverage was 40 percent",
                "a relaxed parser recovered most causal assignment performance",
            ),
            available_actions=actions,
            invariants=("frozen outcome", "benchmark", "model", "compute budget"),
            source_paths=(
                runs / "propose_execute_rerank_v44" / "LOCAL_RESULTS.md",
            ),
            failure_class=FailureClass.INTERFACE,
            action=RecoveryAction.REPAIR_INTERFACE,
            profile_values={
                **common,
                "interface_qualified": False,
            },
        ),
        _fixture(
            case_ref="m46-sequential-policy-state-failure",
            phase="sequential_policy_calibration",
            question="What changes when syntax passes but the policy cannot track legal state or use feedback?",
            observations=(
                "every action parsed",
                "only 12.8 percent of actions were valid",
                "correct feedback had zero advantage over withheld and swapped feedback",
                "the checkpoint was trained only for one-shot experiment emission",
            ),
            available_actions=actions,
            invariants=("tool contract", "benchmark", "feedback controls", "inference authority"),
            source_paths=(
                runs / "model_controlled_tool_loop_v46" / "LOCAL_RESULTS.md",
            ),
            failure_class=FailureClass.REPRESENTATION_EXHAUSTION,
            action=RecoveryAction.CHANGE_REPRESENTATION,
            profile_values={
                **common,
                "scientific_outcome_observed": True,
                "scientific_gate_passed": False,
                "representation_limit_demonstrated": True,
            },
        ),
        _fixture(
            case_ref="failed-prospective-repair-channel-concept",
            phase="concept_validation",
            question="What follows when a well-formed prospective concept loses to its baseline?",
            observations=(
                "prospective evaluation completed under an independent evaluator",
                "augmented predictive score was 0.640625",
                "baseline predictive score was 0.7375",
                "the preregistered concept-validation gate failed",
            ),
            available_actions=actions,
            invariants=("prospective cases", "evaluator", "concept definition", "thresholds"),
            source_paths=(
                runs
                / "causal_structure_repairability_v1"
                / "research-kernel-checkpoint.json",
            ),
            failure_class=FailureClass.SCIENTIFIC_NULL,
            action=RecoveryAction.UPDATE_CAUSAL_THEORY,
            profile_values={
                **common,
                "scientific_outcome_observed": True,
                "scientific_gate_passed": False,
            },
        ),
        _fixture(
            case_ref="v68-v69-plasticity-verification-frontier",
            phase="cross_experiment_synthesis",
            question="What changes after both shared and frozen representations fail complementary gates?",
            observations=(
                "shared-encoder trace learning caused semantic following but damaged verification",
                "frozen-encoder training preserved verification but failed semantic acquisition",
                "both experiments passed their integrity and delivery checks",
            ),
            available_actions=actions,
            invariants=("fresh tasks", "matched controls", "verification gates", "trace semantics"),
            source_paths=(
                runs / "training_recipe_trace_v68_r2" / "DECISION_AUDIT.md",
                runs / "training_recipe_curriculum_v69_r1" / "DECISION_AUDIT.md",
            ),
            failure_class=FailureClass.REPRESENTATION_EXHAUSTION,
            action=RecoveryAction.CHANGE_REPRESENTATION,
            profile_values={
                **common,
                "scientific_outcome_observed": True,
                "scientific_gate_passed": False,
                "representation_limit_demonstrated": True,
            },
        ),
    )
    return fixtures
