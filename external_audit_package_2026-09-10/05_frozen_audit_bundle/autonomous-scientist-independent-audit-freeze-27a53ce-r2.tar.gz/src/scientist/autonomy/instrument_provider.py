from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.lifecycle_components import LifecycleStageProduct
from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.state import ActorKind
from scientist.autonomy.tracing import ComponentExecutionTrace, ExternalInvocation, InvocationKind
from scientist.core.artifacts import content_digest
from scientist.program.research_kernel import ResearchActionKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase


INSTRUMENT_PROVIDER_VERSION = "scientist-instrument-validator-provider-v1"


@dataclass(frozen=True)
class InstrumentOutput:
    artifact: Any
    artifact_id: str
    invocations: Tuple[ExternalInvocation, ...]
    measurement_ref: str
    details: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.artifact_id or not self.measurement_ref:
            raise ValueError("instrument output identity is incomplete")
        if not self.invocations:
            raise ValueError("instrument output requires external tool evidence")
        if any(
            invocation.kind != InvocationKind.TOOL
            or invocation.actor.kind != ActorKind.TOOL_RUNTIME
            for invocation in self.invocations
        ):
            raise ValueError("instrument output may contain only tool invocations")
        produced = {
            artifact_id
            for invocation in self.invocations
            for artifact_id in invocation.output_artifact_ids
        }
        if self.artifact_id not in produced:
            raise ValueError("instrument artifact is absent from tool outputs")


@dataclass(frozen=True)
class DeterministicValidationReceipt:
    artifact_id: str
    verifier_ref: str
    checks: Mapping[str, bool]
    evidence_ids: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.artifact_id or not self.verifier_ref or not self.checks:
            raise ValueError("validation receipt is incomplete")
        if not all(self.checks):
            raise ValueError("validation checks must have non-empty names")
        if not self.evidence_ids:
            raise ValueError("validation receipt requires evidence")

    @property
    def passed(self) -> bool:
        return all(bool(value) for value in self.checks.values())

    @property
    def receipt_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": INSTRUMENT_PROVIDER_VERSION,
            "artifact_id": self.artifact_id,
            "verifier_ref": self.verifier_ref,
            "checks": dict(sorted(self.checks.items())),
            "evidence_ids": list(self.evidence_ids),
            "passed": self.passed,
        }
        if include_id:
            value["receipt_id"] = self.receipt_id
        return value


class InstrumentValidatorStageProvider:
    """Run external instruments, then accept output via a separate validator."""

    _ALLOWED_ACTIONS = {
        ResearchActionKind.SURVEY_PRIOR_ART,
        ResearchActionKind.REPRODUCE_INCUMBENT,
        ResearchActionKind.MAP_PHENOMENON,
        ResearchActionKind.VALIDATE_LATENT_CONCEPT,
        ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM,
        ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION,
    }

    def __init__(
        self,
        *,
        action_kind: ResearchActionKind,
        runner: Callable[[Any, Any], InstrumentOutput],
        validator: Callable[
            [InstrumentOutput, Any, Any], DeterministicValidationReceipt
        ],
        outcome: str,
        adjudicable_failures: bool = False,
    ) -> None:
        if action_kind not in self._ALLOWED_ACTIONS:
            raise ValueError("instrument provider is not authorized for this action")
        if not callable(runner) or not callable(validator) or not outcome:
            raise ValueError("instrument provider configuration is incomplete")
        self.action_kind = action_kind
        self.runner = runner
        self.validator = validator
        self.outcome = outcome
        self.adjudicable_failures = bool(adjudicable_failures)

    def __call__(self, action, kernel, domain, component_ref):
        if action.kind != self.action_kind:
            raise ValueError("instrument provider received another research action")
        output = self.runner(kernel, domain)
        if not isinstance(output, InstrumentOutput):
            raise ValueError("instrument runner returned an invalid output")
        receipt = self.validator(output, kernel, domain)
        if not isinstance(receipt, DeterministicValidationReceipt):
            raise ValueError("instrument validator returned an invalid receipt")
        if receipt.artifact_id != output.artifact_id:
            raise ValueError("validator certified another instrument artifact")
        if receipt.verifier_ref == output.measurement_ref:
            raise ValueError("measurement and validation actors must be independent")
        if not receipt.passed:
            if self.adjudicable_failures:
                case = TransitionCase(
                    case_ref="instrument-validation:%s" % output.artifact_id,
                    phase=self.action_kind.value,
                    question="Did the measured artifact pass its frozen validity checks?",
                    observations=tuple(
                        "%s=%s" % (name, bool(value))
                        for name, value in sorted(receipt.checks.items())
                    ),
                    available_actions=(
                        RecoveryAction.RECALIBRATE_MEASUREMENT,
                        RecoveryAction.REPAIR_INTERFACE,
                        RecoveryAction.REPAIR_IMPLEMENTATION,
                    ),
                    protected_invariants=(
                        "preserve the frozen scientific claim and outcome boundary",
                        "retain every completed external invocation receipt",
                        "do not promote an invalid measurement",
                    ),
                    evidence_refs=receipt.evidence_ids,
                    retrospective=False,
                    domain=str(getattr(domain, "domain_id", "unknown-domain")),
                )
                raise AdjudicableResearchFailure(
                    "instrument artifact failed deterministic validation",
                    case=case,
                    profile=FailureEvidenceProfile(
                        case_id=case.case_id,
                        runtime_available=True,
                        external_dependency_missing=False,
                        implementation_integrity_passed=True,
                        interface_qualified=True,
                        protocol_feasible=True,
                        measurement_qualified=False,
                        scientific_outcome_observed=False,
                        scientific_gate_passed=None,
                        representation_limit_demonstrated=False,
                    ),
                    attempt_invocations=output.invocations,
                )
            raise ValueError("instrument artifact failed deterministic validation")
        trace = ComponentExecutionTrace(
            action_id=action.action_id,
            component_ref=component_ref,
            invocations=output.invocations,
            complete=True,
            undeclared_external_access=False,
            sealed_authority_accessed=False,
        )
        return LifecycleStageProduct(
            artifact=output.artifact,
            trace=trace,
            outcome=self.outcome,
            details={
                **dict(output.details),
                "instrument_provider_version": INSTRUMENT_PROVIDER_VERSION,
                "measurement_ref": output.measurement_ref,
                "validation_receipt": receipt.as_dict(),
                "model_exercised_scientific_authority": False,
            },
        )
