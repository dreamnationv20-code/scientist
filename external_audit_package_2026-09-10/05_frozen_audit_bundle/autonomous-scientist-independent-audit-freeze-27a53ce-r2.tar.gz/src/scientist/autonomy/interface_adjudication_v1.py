from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


INTERFACE_ADJUDICATION_VERSION = "causalab-prefreeze-interface-adjudication-v1"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    identity = value.get(key)
    body = dict(value)
    body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def build_interface_adjudication(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    protocol_path = (
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v4/artifacts/manifests"
        / "protocol-commitment-v4.json"
    )
    calibration_path = (
        root
        / "runs/autonomy_closure_v1/causalab_three_arm_development_calibration_v1"
        / "artifacts/manifests/causalab-three-arm-development-calibration-v9.json"
    )
    decision_path = (
        root
        / "docs/autonomous-scientist-prefreeze-interface-adjudication-2026-09-08.md"
    )
    confirmatory = root / "runs/autonomy_closure_v1/prospective_v4_confirmatory"
    if confirmatory.exists():
        raise ValueError("confirmatory namespace exists; pre-freeze adjudication is too late")
    protocol = _identified(protocol_path, "commitment_id")
    calibration = _identified(calibration_path, "calibration_id")
    if protocol.get("implementation_freeze_complete") is not False:
        raise ValueError("protocol does not authorize pre-freeze implementation repair")
    if calibration.get("status") != "complete" or not calibration.get(
        "development_only"
    ):
        raise ValueError("interface diagnostic is not a completed development run")
    if calibration.get("scientific_result_claimed") or calibration.get(
        "nature_claim_authorized"
    ):
        raise ValueError("interface diagnostic makes an impermissible claim")
    if calibration.get("confirmatory_authorities_created") or calibration.get(
        "confirmatory_outcomes_opened"
    ):
        raise ValueError("interface diagnostic accessed confirmatory state")
    results = calibration.get("results") or {}
    if len(results) != 3 or calibration.get("failures"):
        raise ValueError("interface diagnostic is not a complete three-arm run")
    for arm, result in results.items():
        if not result.get("accounting_reconciled"):
            raise ValueError(f"{arm} did not establish budget feasibility")
        if result.get("transport_rejection_count") != 0:
            raise ValueError(f"{arm} had a transport rejection")
        if result.get("batch_invocations") != 1:
            raise ValueError(f"{arm} did not use one batch")
    scientist = results["authority_separated_scientist"]
    scientist_coefficients = (
        scientist.get("proposal", {}).get("frequency_coefficients") or {}
    )
    controls = (
        results["free_monolithic_codex"],
        results["prompt_equated_monolithic_codex"],
    )
    if "intercept" not in scientist_coefficients:
        raise ValueError("diagnostic does not contain the coefficient-label ambiguity")
    if not all(not item.get("score", {}).get("exact_graph") for item in controls):
        raise ValueError("diagnostic does not contain the edge-label ambiguity")

    implementation_files = (
        root / "src/scientist/autonomy/causalab_three_arm.py",
        root / "src/scientist/autonomy/causalab_codex_runner.py",
    )
    body: Dict[str, Any] = {
        "version": INTERFACE_ADJUDICATION_VERSION,
        "status": "adjudicated_prefreeze_repair_required",
        "protocol_commitment_id": protocol["commitment_id"],
        "diagnostic_calibration_id": calibration["calibration_id"],
        "diagnostic_permanently_excluded": True,
        "primary_failure_class": "interface_specification",
        "action": "restore_descriptive_conclusion_fields_and_requalify",
        "scientific_contract_changed": False,
        "task_information_changed": False,
        "arm_treatment_changed": False,
        "resource_budget_changed": False,
        "scorer_changed": False,
        "change_applies_identically_to_all_arms": True,
        "evidence_alias_pattern_retained": "^(s|i)[1-9][0-9]*$",
        "decision_path": str(decision_path.relative_to(root)),
        "decision_sha256": bytes_sha256(decision_path.read_bytes()),
        "candidate_implementation_hashes": {
            str(path.relative_to(root)): bytes_sha256(path.read_bytes())
            for path in implementation_files
        },
        "confirmatory_namespace_absent": True,
        "confirmatory_authorities_created": False,
        "confirmatory_outcomes_opened": False,
        "scientific_result_claimed": False,
        "nature_claim_authorized": False,
    }
    return {**body, "adjudication_id": content_digest(body)}
