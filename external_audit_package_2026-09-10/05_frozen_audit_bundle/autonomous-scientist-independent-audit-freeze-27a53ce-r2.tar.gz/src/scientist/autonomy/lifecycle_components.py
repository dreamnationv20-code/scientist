from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Protocol, Tuple, Type

from scientist.autonomy.authority_contracts import (
    audit_component_pack,
    authority_contract,
)
from scientist.core.artifacts import content_digest
from scientist.autonomy.tracing import ComponentExecutionTrace
from scientist.program.campaigns import IncumbentPortfolio
from scientist.program.causal_failure import CausalFailureModelSet
from scientist.program.literature import PriorArtAssessment
from scientist.program.research_kernel import (
    AutonomousResearchKernel,
    BehavioralMechanismCertificate,
    ConceptValidationCertificate,
    DiagnosticConceptHypothesis,
    DiscriminatingExperimentPlan,
    MultiHorizonEvaluationCertificate,
    PhenomenonAtlas,
    ResearchActionKind,
    ResearchDispatchResult,
    ResearchMissionContract,
)


LIFECYCLE_COMPONENT_VERSION = "scientist-verified-lifecycle-component-v1"


@dataclass(frozen=True)
class LifecycleStageProduct:
    artifact: Any
    trace: ComponentExecutionTrace
    outcome: str
    details: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.outcome:
            raise ValueError("lifecycle-stage outcome must not be empty")
        if "_authority_trace" in self.details:
            raise ValueError("stage provider cannot replace the authority trace")


class LifecycleStageProvider(Protocol):
    def __call__(
        self,
        action: Any,
        kernel: AutonomousResearchKernel,
        domain: Any,
        component_ref: str,
    ) -> LifecycleStageProduct:
        ...


@dataclass(frozen=True)
class BoundResearchComponentPack:
    """A complete V3 component set bound to one mission and domain.

    Domain bundles describe stable instruments. Research component packs are
    deliberately run-scoped because goals, evidence partitions, and external
    services differ between missions in the same domain.
    """

    mission_id: str
    domain_id: str
    components: Mapping[str, Any]
    pack_ref: str

    def __post_init__(self) -> None:
        if not all((self.mission_id, self.domain_id, self.pack_ref)):
            raise ValueError("bound research component pack identity is incomplete")
        copied = dict(self.components)
        audit = audit_component_pack(copied)
        if not audit.passed:
            raise ValueError(
                "bound research component pack is incomplete or nonconformant: %s"
                % audit.as_dict()
            )
        object.__setattr__(self, "components", copied)

    @property
    def pack_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": "scientist-bound-research-component-pack-v1",
            "mission_id": self.mission_id,
            "domain_id": self.domain_id,
            "pack_ref": self.pack_ref,
            "component_refs": {
                action: "%s@%s"
                % (component.name, component.component_version)
                for action, component in sorted(self.components.items())
            },
        }
        if include_id:
            value["pack_id"] = self.pack_id
        return value

    def research_component(self, action_kind: str) -> Any:
        try:
            return self.components[action_kind]
        except KeyError as error:
            raise ValueError(
                "bound pack has no autonomous research component for %r"
                % action_kind
            ) from error


class FrozenMissionStageProvider:
    """Bind a user-frozen mission without hidden model or tool authorship."""

    def __init__(self, mission: ResearchMissionContract, *, source_ref: str) -> None:
        if not isinstance(mission, ResearchMissionContract) or not source_ref:
            raise ValueError("frozen mission provider configuration is incomplete")
        self.mission = mission
        self.source_ref = source_ref

    def __call__(self, action, kernel, domain, component_ref):
        if action.kind != ResearchActionKind.FREEZE_MISSION:
            raise ValueError("frozen mission provider received another action")
        if self.mission.domain_id != domain.domain_id:
            raise ValueError("frozen mission belongs to another domain")
        return LifecycleStageProduct(
            artifact=self.mission,
            trace=ComponentExecutionTrace.deterministic(
                action.action_id, component_ref
            ),
            outcome="research_mission_frozen",
            details={
                "mission_source_ref": self.source_ref,
                "adaptive_model_used": False,
                "mission_id": self.mission.mission_id,
            },
        )


_STAGE_TYPES: Mapping[ResearchActionKind, Type[Any]] = {
    ResearchActionKind.FREEZE_MISSION: ResearchMissionContract,
    ResearchActionKind.SURVEY_PRIOR_ART: PriorArtAssessment,
    ResearchActionKind.REPRODUCE_INCUMBENT: IncumbentPortfolio,
    ResearchActionKind.MAP_PHENOMENON: PhenomenonAtlas,
    ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS: CausalFailureModelSet,
    ResearchActionKind.INVENT_LATENT_CONCEPT: DiagnosticConceptHypothesis,
    ResearchActionKind.VALIDATE_LATENT_CONCEPT: ConceptValidationCertificate,
    ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT: (
        DiscriminatingExperimentPlan
    ),
    ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM: (
        BehavioralMechanismCertificate
    ),
    ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION: (
        MultiHorizonEvaluationCertificate
    ),
}


def _register(
    action_kind: ResearchActionKind,
    artifact: Any,
    kernel: AutonomousResearchKernel,
    domain: Any,
) -> str:
    if action_kind == ResearchActionKind.FREEZE_MISSION:
        return kernel.freeze_mission(artifact, domain)
    method_names = {
        ResearchActionKind.SURVEY_PRIOR_ART: "register_prior_art",
        ResearchActionKind.REPRODUCE_INCUMBENT: "register_incumbent",
        ResearchActionKind.MAP_PHENOMENON: "register_atlas",
        ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS: "register_diagnosis",
        ResearchActionKind.INVENT_LATENT_CONCEPT: "register_concept",
        ResearchActionKind.VALIDATE_LATENT_CONCEPT: "validate_concept",
        ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT: (
            "register_experiment"
        ),
        ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM: "register_mechanism",
        ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION: "record_evaluation",
    }
    return getattr(kernel, method_names[action_kind])(artifact)


class VerifiedLifecycleComponent:
    """Typed boundary between a stage provider and the V3 authority kernel.

    Providers may use adaptive models and tools, but must return a complete
    trace. The governed executive enforces the action-specific authority
    contract before this product becomes authoritative state.
    """

    def __init__(
        self,
        action_kind: ResearchActionKind,
        provider: LifecycleStageProvider,
        *,
        name: str,
        component_version: str = "v1",
    ) -> None:
        if action_kind not in _STAGE_TYPES:
            raise ValueError("verified lifecycle component cannot govern this action")
        if not name or not component_version:
            raise ValueError("lifecycle component identity is incomplete")
        if not callable(provider):
            raise ValueError("lifecycle stage provider must be callable")
        contract = authority_contract(action_kind)
        self.action_kind = action_kind
        self.provider = provider
        self.name = name
        self.component_version = component_version
        self.dispatch_actor_kind = contract.commit_actor_kind.value
        self.dispatch_authority_scope = contract.commit_authority_scope.value

    @property
    def component_ref(self) -> str:
        return "%s@%s" % (self.name, self.component_version)

    def dispatch(
        self,
        action: Any,
        kernel: AutonomousResearchKernel,
        domain: Any,
    ) -> ResearchDispatchResult:
        if action.kind != self.action_kind:
            raise ValueError("lifecycle component received another action")
        product = self.provider(action, kernel, domain, self.component_ref)
        if not isinstance(product, LifecycleStageProduct):
            raise ValueError("lifecycle provider returned an invalid stage product")
        expected_type = _STAGE_TYPES[self.action_kind]
        if not isinstance(product.artifact, expected_type):
            raise ValueError(
                "%s provider returned %s instead of %s"
                % (
                    self.action_kind.value,
                    type(product.artifact).__name__,
                    expected_type.__name__,
                )
            )
        if product.trace.action_id != action.action_id:
            raise ValueError("lifecycle provider traced another action")
        if product.trace.component_ref != self.component_ref:
            raise ValueError("lifecycle provider traced another component")
        artifact_id = _register(
            self.action_kind,
            product.artifact,
            kernel,
            domain,
        )
        return ResearchDispatchResult(
            progressed=True,
            stop=False,
            outcome=product.outcome,
            details={
                **dict(product.details),
                "artifact_id": artifact_id,
                "authority_contract_version": LIFECYCLE_COMPONENT_VERSION,
                "_authority_trace": product.trace.as_dict(),
            },
        )


def build_verified_lifecycle_components(
    providers: Mapping[ResearchActionKind, LifecycleStageProvider],
) -> Dict[str, VerifiedLifecycleComponent]:
    expected = set(_STAGE_TYPES)
    supplied = set(providers)
    if supplied != expected:
        missing = sorted(item.value for item in expected.difference(supplied))
        extra = sorted(item.value for item in supplied.difference(expected))
        raise ValueError(
            "lifecycle provider pack mismatch; missing=%s extra=%s"
            % (missing, extra)
        )
    return {
        action.value: VerifiedLifecycleComponent(
            action,
            providers[action],
            name="verified-%s-component" % action.value.replace("_", "-"),
        )
        for action in sorted(expected, key=lambda item: item.value)
    }


def required_stage_actions() -> Tuple[ResearchActionKind, ...]:
    return tuple(sorted(_STAGE_TYPES, key=lambda item: item.value))
