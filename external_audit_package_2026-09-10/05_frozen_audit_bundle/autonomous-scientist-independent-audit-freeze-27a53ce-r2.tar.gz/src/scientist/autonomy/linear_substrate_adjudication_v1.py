from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


LINEAR_SUBSTRATE_ADJUDICATION_VERSION = (
    "causalab-linear-substrate-saturation-adjudication-v1"
)
ARMS = {
    "free_monolithic_codex",
    "prompt_equated_monolithic_codex",
    "authority_separated_scientist",
}


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    identity = value.get(key)
    body = dict(value)
    body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def _validate_saturated(calibration: Mapping[str, Any]) -> None:
    if calibration.get("status") != "complete" or not calibration.get(
        "development_only"
    ):
        raise ValueError("saturation evidence is not a completed development run")
    if calibration.get("failures"):
        raise ValueError("saturation evidence contains arm failures")
    if calibration.get("scientific_result_claimed") or calibration.get(
        "nature_claim_authorized"
    ):
        raise ValueError("saturation evidence makes an impermissible claim")
    if calibration.get("confirmatory_authorities_created") or calibration.get(
        "confirmatory_outcomes_opened"
    ):
        raise ValueError("saturation evidence accessed confirmatory state")
    matching = calibration.get("matching_checks") or {}
    if not all(matching.values()) or not matching.get("full_matched_triple"):
        raise ValueError("saturation evidence is not a fully matched triple")
    results = calibration.get("results") or {}
    if set(results) != ARMS:
        raise ValueError("saturation evidence has the wrong arms")
    for arm, result in results.items():
        if not result.get("score", {}).get("valid_resolution"):
            raise ValueError(f"{arm} did not reach the observed performance ceiling")
        if result.get("score", {}).get("unsupported_promotion"):
            raise ValueError(f"{arm} made an unsupported promotion")
        if not result.get("accounting_reconciled"):
            raise ValueError(f"{arm} accounting did not reconcile")
        if result.get("batch_invocations") != 1:
            raise ValueError(f"{arm} did not use the frozen one-batch transport")
        if result.get("transport_rejection_count") != 0:
            raise ValueError(f"{arm} had a transport rejection")


def build_linear_substrate_adjudication(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    protocol_path = (
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v4/artifacts/manifests"
        / "protocol-commitment-v4.json"
    )
    calibration_paths = (
        root
        / "runs/autonomy_closure_v1/causalab_three_arm_development_calibration_v1"
        / "artifacts/manifests/causalab-three-arm-development-calibration-v10.json",
        root
        / "runs/autonomy_closure_v1/causalab_three_arm_development_calibration_v1"
        / "artifacts/manifests/causalab-three-arm-development-calibration-v11.json",
    )
    decision_path = (
        root
        / "docs/autonomous-scientist-linear-substrate-adjudication-2026-09-08.md"
    )
    confirmatory = root / "runs/autonomy_closure_v1/prospective_v4_confirmatory"
    if confirmatory.exists():
        raise ValueError("confirmatory namespace exists; saturation adjudication is too late")
    protocol = _identified(protocol_path, "commitment_id")
    calibrations = tuple(_identified(path, "calibration_id") for path in calibration_paths)
    if protocol.get("implementation_freeze_complete") is not False:
        raise ValueError("protocol is no longer implementation-unfrozen")
    for calibration in calibrations:
        _validate_saturated(calibration)
    specs = {(item["generation_spec"]["tier"], item["generation_spec"]["node_count"]) for item in calibrations}
    if specs != {("L1", 3), ("L3", 7)}:
        raise ValueError("saturation evidence does not span the low/high boundary")
    if len({item["public_task_artifact_id"] for item in calibrations}) != 2:
        raise ValueError("saturation calibrations reused one public task")

    body: Dict[str, Any] = {
        "version": LINEAR_SUBSTRATE_ADJUDICATION_VERSION,
        "status": "primary_substrate_rejected_for_saturation",
        "protocol_commitment_id": protocol["commitment_id"],
        "calibration_ids": [item["calibration_id"] for item in calibrations],
        "calibration_task_boundaries": [
            {
                "tier": item["generation_spec"]["tier"],
                "node_count": item["generation_spec"]["node_count"],
                "valid_resolution_by_arm": {
                    arm: result["score"]["valid_resolution"]
                    for arm, result in sorted(item["results"].items())
                },
                "tokens_by_arm": {
                    arm: result["token_usage"]["total_tokens"]
                    for arm, result in sorted(item["results"].items())
                },
            }
            for item in calibrations
        ],
        "failure_class": "benchmark_discrimination_ceiling",
        "decision": "retain_as_positive_control_do_not_confirm_as_primary",
        "predeclared_effect_gate_percentage_points": protocol[
            "primary_effect_gate_percentage_points"
        ],
        "next_substrate": "adaptive_causal_recovery_challenge",
        "required_new_mechanisms": [
            "multi_round_experiment_selection",
            "competing_hypothesis_memory",
            "public_answer_blind_candidate_validation",
            "bounded_reproposal",
            "typed_failure_recovery",
            "valid_negative_conclusions",
        ],
        "decision_path": str(decision_path.relative_to(root)),
        "decision_sha256": bytes_sha256(decision_path.read_bytes()),
        "calibrations_permanently_excluded": True,
        "confirmatory_namespace_absent": True,
        "confirmatory_authorities_created": False,
        "confirmatory_outcomes_opened": False,
        "scientific_result_claimed": False,
        "nature_claim_authorized": False,
    }
    return {**body, "adjudication_id": content_digest(body)}
