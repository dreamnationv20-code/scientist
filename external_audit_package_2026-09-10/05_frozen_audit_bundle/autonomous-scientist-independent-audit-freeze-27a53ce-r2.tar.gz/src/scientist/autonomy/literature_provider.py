from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Callable, Optional

from scientist.autonomy.instrument_provider import (
    DeterministicValidationReceipt,
    InstrumentOutput,
    InstrumentValidatorStageProvider,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.program.literature import PriorArtAssessment
from scientist.program.research_kernel import ResearchActionKind
from scientist.program.web_literature import default_live_web_reviewer


LIVE_LITERATURE_PROVIDER_VERSION = "scientist-live-literature-provider-v1"


class LiveLiteratureStageRunner:
    """Execute and fully account a live, multi-provider literature survey."""

    def __init__(
        self,
        *,
        store: ArtifactStore,
        plan_builder: Callable[[Any, Any], PriorArtAssessment],
        reviewer_factory: Optional[Callable[[ArtifactStore], Any]] = None,
        timeout_seconds: float = 20.0,
        results_per_query: int = 6,
    ) -> None:
        if not callable(plan_builder):
            raise ValueError("live literature runner requires a plan builder")
        self.store = store
        self.plan_builder = plan_builder
        self.reviewer_factory = reviewer_factory
        self.timeout_seconds = timeout_seconds
        self.results_per_query = results_per_query

    def __call__(self, kernel, domain) -> InstrumentOutput:
        plan = self.plan_builder(kernel, domain)
        if not isinstance(plan, PriorArtAssessment):
            raise ValueError("literature plan builder returned another artifact")
        if kernel.mission is None:
            raise ValueError("live literature survey requires a frozen mission")
        if plan.signature.signature_id != kernel.mission.claim_signature.signature_id:
            raise ValueError("literature plan belongs to another mission")
        plan_artifact_id = self.store.put("prior_art_query_plan", plan.as_dict())
        reviewer = (
            default_live_web_reviewer(
                self.store,
                timeout_seconds=self.timeout_seconds,
                results_per_query=self.results_per_query,
            )
            if self.reviewer_factory is None
            else self.reviewer_factory(self.store)
        )
        started = time.perf_counter()
        assessment = reviewer.review(plan)
        elapsed = time.perf_counter() - started
        manifest_id = reviewer.last_manifest_digest
        if not manifest_id:
            raise ValueError("live literature reviewer omitted its survey manifest")
        receipts = tuple(
            receipt
            for provider in reviewer.providers
            for receipt in provider.receipts
        )
        if not receipts:
            raise ValueError("live literature survey emitted no provider receipts")
        assessment_store_id = self.store.put(
            "closed_prior_art_assessment", assessment.as_dict()
        )
        invocations = []
        for index, receipt in enumerate(receipts):
            outputs = [receipt.raw_response_artifact]
            if index == len(receipts) - 1:
                outputs.extend(
                    (
                        manifest_id,
                        assessment_store_id,
                        assessment.assessment_id,
                    )
                )
            invocations.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="literature_%s" % receipt.operation,
                    actor=ActorIdentity(
                        "literature-provider:%s@%s"
                        % (receipt.provider, receipt.provider_version),
                        ActorKind.TOOL_RUNTIME,
                    ),
                    authority_scope=AuthorityScope.MEASURE,
                    input_artifact_ids=(
                        plan_artifact_id,
                        content_digest(
                            {
                                "request_url": receipt.request_url,
                                "query": receipt.query,
                                "facet": receipt.facet.value,
                            }
                        ),
                    ),
                    output_artifact_ids=tuple(outputs),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=elapsed if index == len(receipts) - 1 else 0.0,
                    ),
                )
            )
        evidence_ids = tuple(
            dict.fromkeys(
                (
                    manifest_id,
                    assessment_store_id,
                    *(receipt.raw_response_artifact for receipt in receipts),
                )
            )
        )
        return InstrumentOutput(
            artifact=assessment,
            artifact_id=assessment.assessment_id,
            invocations=tuple(invocations),
            measurement_ref="live-web-prior-art-reviewer:v3:%s" % manifest_id,
            details={
                "live_literature_provider_version": LIVE_LITERATURE_PROVIDER_VERSION,
                "plan_artifact_id": plan_artifact_id,
                "survey_manifest_id": manifest_id,
                "assessment_store_id": assessment_store_id,
                "provider_receipt_count": len(receipts),
                "provider_names": sorted(
                    {receipt.provider for receipt in receipts}
                ),
                "failed_receipt_count": sum(
                    not receipt.success for receipt in receipts
                ),
                "evidence_ids": list(evidence_ids),
            },
        )


def validate_live_literature_output(
    output: InstrumentOutput,
    kernel,
    domain,
) -> DeterministicValidationReceipt:
    del domain
    assessment = output.artifact
    if not isinstance(assessment, PriorArtAssessment):
        raise ValueError("literature instrument returned another artifact type")
    if kernel.mission is None:
        raise ValueError("literature validation requires a frozen mission")
    evidence_ids = tuple(str(item) for item in output.details["evidence_ids"])
    query_providers = {query.provider for query in assessment.queries}
    checks = {
        "artifact_identity": output.artifact_id == assessment.assessment_id,
        "mission_signature": assessment.signature.signature_id
        == kernel.mission.claim_signature.signature_id,
        "literature_closure": assessment.closure_passed,
        "provider_diversity": len(query_providers) >= 2,
        "citation_neighborhood_closed": assessment.citation_snowball_complete,
        "executable_incumbent_present": assessment.executable_incumbent_id
        is not None,
        "receipt_count_matches_trace": int(
            output.details["provider_receipt_count"]
        )
        == len(output.invocations),
        "manifest_retained": str(output.details["survey_manifest_id"])
        in evidence_ids,
    }
    return DeterministicValidationReceipt(
        artifact_id=output.artifact_id,
        verifier_ref="deterministic-literature-closure-validator-v1",
        checks=checks,
        evidence_ids=evidence_ids,
    )


def build_live_literature_stage_provider(
    *,
    store_root: Path,
    plan_builder: Callable[[Any, Any], PriorArtAssessment],
    reviewer_factory: Optional[Callable[[ArtifactStore], Any]] = None,
    timeout_seconds: float = 20.0,
    results_per_query: int = 6,
) -> InstrumentValidatorStageProvider:
    runner = LiveLiteratureStageRunner(
        store=ArtifactStore(Path(store_root)),
        plan_builder=plan_builder,
        reviewer_factory=reviewer_factory,
        timeout_seconds=timeout_seconds,
        results_per_query=results_per_query,
    )
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.SURVEY_PRIOR_ART,
        runner=runner,
        validator=validate_live_literature_output,
        outcome="live_prior_art_closed",
        adjudicable_failures=True,
    )


__all__ = [
    "LIVE_LITERATURE_PROVIDER_VERSION",
    "LiveLiteratureStageRunner",
    "build_live_literature_stage_provider",
    "validate_live_literature_output",
]
