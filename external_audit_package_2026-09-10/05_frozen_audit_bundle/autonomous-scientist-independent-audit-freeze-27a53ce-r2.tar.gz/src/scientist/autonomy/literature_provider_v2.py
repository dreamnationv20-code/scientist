from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any, Callable, Optional

from scientist.autonomy.instrument_provider import InstrumentValidatorStageProvider
from scientist.autonomy.literature_provider import (
    LiveLiteratureStageRunner,
    validate_live_literature_output,
)
from scientist.core.artifacts import ArtifactStore
from scientist.program.literature import PriorArtAssessment
from scientist.program.research_kernel import ResearchActionKind


LIVE_LITERATURE_PROVIDER_V2_VERSION = "scientist-live-literature-provider-v2"


class LiveLiteratureStageRunnerV2(LiveLiteratureStageRunner):
    """Bind measurement identity to the reviewer that produced the assessment."""

    def __call__(self, kernel, domain):
        output = super().__call__(kernel, domain)
        assessment = output.artifact
        if not isinstance(assessment, PriorArtAssessment):
            raise ValueError("v2 literature runner received another artifact")
        if not assessment.reviewer_ref:
            raise ValueError("v2 literature assessment omitted reviewer identity")
        return replace(
            output,
            measurement_ref=assessment.reviewer_ref,
            details={
                **dict(output.details),
                "live_literature_provider_version": (
                    LIVE_LITERATURE_PROVIDER_V2_VERSION
                ),
            },
        )


def build_live_literature_stage_provider_v2(
    *,
    store_root: Path,
    plan_builder: Callable[[Any, Any], PriorArtAssessment],
    reviewer_factory: Optional[Callable[[ArtifactStore], Any]] = None,
    timeout_seconds: float = 20.0,
    results_per_query: int = 6,
) -> InstrumentValidatorStageProvider:
    runner = LiveLiteratureStageRunnerV2(
        store=ArtifactStore(Path(store_root)),
        plan_builder=plan_builder,
        reviewer_factory=reviewer_factory,
        timeout_seconds=timeout_seconds,
        results_per_query=results_per_query,
    )
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.SURVEY_PRIOR_ART,
        runner=runner,
        validator=validate_live_literature_output,
        outcome="live_prior_art_closed",
        adjudicable_failures=True,
    )


__all__ = [
    "LIVE_LITERATURE_PROVIDER_V2_VERSION",
    "LiveLiteratureStageRunnerV2",
    "build_live_literature_stage_provider_v2",
]
