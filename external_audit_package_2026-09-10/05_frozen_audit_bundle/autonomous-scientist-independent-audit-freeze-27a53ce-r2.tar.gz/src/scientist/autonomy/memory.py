from __future__ import annotations

import json
import os
import re
import tempfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import canonical_json, content_digest


CAUSAL_MEMORY_VERSION = "scientist-semantic-causal-memory-v1"
_DIGEST = re.compile(r"[0-9a-f]{64}")


def _unique(values: Sequence[str], label: str, *, required: bool = False) -> Tuple[str, ...]:
    result = tuple(str(value) for value in values)
    if required and not result:
        raise ValueError("%s must not be empty" % label)
    if not all(result) or len(result) != len(set(result)):
        raise ValueError("%s must contain unique non-empty values" % label)
    return result


def _evidence(values: Sequence[str]) -> Tuple[str, ...]:
    result = _unique(values, "causal-memory evidence")
    if any(_DIGEST.fullmatch(value) is None for value in result):
        raise ValueError("causal-memory evidence must use content digests")
    return result


class CausalMemoryKind(str, Enum):
    HYPOTHESIS = "hypothesis"
    PREDICTION = "prediction"
    ASSUMPTION = "assumption"
    CONTRADICTION = "contradiction"
    INTERVENTION = "intervention"
    CLAIM = "claim"


class CausalMemoryStatus(str, Enum):
    ACTIVE = "active"
    SUPPORTED = "supported"
    REFUTED = "refuted"
    EXHAUSTED = "exhausted"
    SUPERSEDED = "superseded"


@dataclass(frozen=True)
class CausalMemoryRecord:
    domain_id: str
    subject_id: str
    kind: CausalMemoryKind
    statement: str
    status: CausalMemoryStatus
    causal_variables: Tuple[str, ...]
    predicted_outcomes: Tuple[str, ...]
    boundary_conditions: Tuple[str, ...]
    intervention_family: Optional[str]
    representation_signature: Tuple[str, ...]
    experiment_fingerprint: Optional[str]
    evidence_ids: Tuple[str, ...]
    parent_record_ids: Tuple[str, ...]
    source_ref: str

    def __post_init__(self) -> None:
        if not all((self.domain_id, self.subject_id, self.statement, self.source_ref)):
            raise ValueError("causal-memory record identity is incomplete")
        _unique(self.causal_variables, "causal variables")
        _unique(self.predicted_outcomes, "predicted outcomes")
        _unique(self.boundary_conditions, "boundary conditions")
        _unique(self.representation_signature, "representation signature")
        _evidence(self.evidence_ids)
        _unique(self.parent_record_ids, "parent record IDs")
        if self.experiment_fingerprint is not None and _DIGEST.fullmatch(
            self.experiment_fingerprint
        ) is None:
            raise ValueError("experiment fingerprint must be a content digest")
        if self.status in {
            CausalMemoryStatus.SUPPORTED,
            CausalMemoryStatus.REFUTED,
            CausalMemoryStatus.EXHAUSTED,
        } and not self.evidence_ids:
            raise ValueError("tested causal-memory status requires evidence")
        if self.status == CausalMemoryStatus.EXHAUSTED and (
            self.kind != CausalMemoryKind.INTERVENTION
            or not self.intervention_family
            or not self.representation_signature
        ):
            raise ValueError(
                "exhaustion requires an intervention family and representation"
            )
        if self.kind == CausalMemoryKind.CONTRADICTION and not self.parent_record_ids:
            raise ValueError("a contradiction must identify contradicted records")

    @property
    def record_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSAL_MEMORY_VERSION,
            "domain_id": self.domain_id,
            "subject_id": self.subject_id,
            "kind": self.kind.value,
            "statement": self.statement,
            "status": self.status.value,
            "causal_variables": list(self.causal_variables),
            "predicted_outcomes": list(self.predicted_outcomes),
            "boundary_conditions": list(self.boundary_conditions),
            "intervention_family": self.intervention_family,
            "representation_signature": list(self.representation_signature),
            "experiment_fingerprint": self.experiment_fingerprint,
            "evidence_ids": list(self.evidence_ids),
            "parent_record_ids": list(self.parent_record_ids),
            "source_ref": self.source_ref,
        }
        if include_id:
            value["record_id"] = self.record_id
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "CausalMemoryRecord":
        if value.get("version") != CAUSAL_MEMORY_VERSION:
            raise ValueError("unsupported causal-memory record version")
        result = cls(
            domain_id=str(value["domain_id"]),
            subject_id=str(value["subject_id"]),
            kind=CausalMemoryKind(value["kind"]),
            statement=str(value["statement"]),
            status=CausalMemoryStatus(value["status"]),
            causal_variables=tuple(str(item) for item in value["causal_variables"]),
            predicted_outcomes=tuple(str(item) for item in value["predicted_outcomes"]),
            boundary_conditions=tuple(str(item) for item in value["boundary_conditions"]),
            intervention_family=value.get("intervention_family"),
            representation_signature=tuple(
                str(item) for item in value["representation_signature"]
            ),
            experiment_fingerprint=value.get("experiment_fingerprint"),
            evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
            parent_record_ids=tuple(str(item) for item in value["parent_record_ids"]),
            source_ref=str(value["source_ref"]),
        )
        if value.get("record_id") != result.record_id:
            raise ValueError("causal-memory record identity mismatch")
        return result


@dataclass(frozen=True)
class ExperimentAuthorization:
    authorized: bool
    reason: str
    blocking_record_ids: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "authorized": self.authorized,
            "reason": self.reason,
            "blocking_record_ids": list(self.blocking_record_ids),
        }


class SemanticCausalMemory:
    """Structured memory for hypotheses, contradictions, and exhausted paths."""

    def __init__(self) -> None:
        self._records: Dict[str, CausalMemoryRecord] = {}

    @property
    def records(self) -> Mapping[str, CausalMemoryRecord]:
        return dict(self._records)

    def add(self, record: CausalMemoryRecord) -> str:
        unknown_parents = set(record.parent_record_ids).difference(self._records)
        if unknown_parents:
            raise ValueError("causal-memory record cites unknown parents")
        existing = self._records.get(record.record_id)
        if existing is not None and existing != record:
            raise ValueError("causal-memory identity conflict")
        self._records[record.record_id] = record
        return record.record_id

    def query(
        self,
        *,
        domain_id: Optional[str] = None,
        subject_id: Optional[str] = None,
        kind: Optional[CausalMemoryKind] = None,
        status: Optional[CausalMemoryStatus] = None,
        causal_variables: Sequence[str] = (),
    ) -> Tuple[CausalMemoryRecord, ...]:
        variables = set(causal_variables)
        return tuple(
            record
            for _, record in sorted(self._records.items())
            if (domain_id is None or record.domain_id == domain_id)
            and (subject_id is None or record.subject_id == subject_id)
            and (kind is None or record.kind == kind)
            and (status is None or record.status == status)
            and (not variables or variables.intersection(record.causal_variables))
        )

    def authorize_experiment(
        self,
        *,
        domain_id: str,
        intervention_family: str,
        representation_signature: Sequence[str],
        experiment_fingerprint: str,
    ) -> ExperimentAuthorization:
        signature = tuple(sorted(_unique(
            representation_signature,
            "experiment representation signature",
            required=True,
        )))
        if _DIGEST.fullmatch(experiment_fingerprint) is None:
            raise ValueError("experiment fingerprint must be a content digest")
        repeated = tuple(
            record.record_id
            for record in self._records.values()
            if record.domain_id == domain_id
            and record.experiment_fingerprint == experiment_fingerprint
        )
        if repeated:
            return ExperimentAuthorization(
                False,
                "an equivalent experiment already exists in causal memory",
                tuple(sorted(repeated)),
            )
        exhausted = tuple(
            record.record_id
            for record in self._records.values()
            if record.domain_id == domain_id
            and record.kind == CausalMemoryKind.INTERVENTION
            and record.status == CausalMemoryStatus.EXHAUSTED
            and record.intervention_family == intervention_family
            and tuple(sorted(record.representation_signature)) == signature
        )
        if exhausted:
            return ExperimentAuthorization(
                False,
                "the intervention family is exhausted under this representation",
                tuple(sorted(exhausted)),
            )
        return ExperimentAuthorization(
            True,
            "no equivalent experiment or representation-matched exhaustion was found",
            (),
        )

    @property
    def memory_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": CAUSAL_MEMORY_VERSION,
            "records": [
                record.as_dict()
                for _, record in sorted(self._records.items())
            ],
        }
        if include_id:
            value["memory_id"] = self.memory_id
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SemanticCausalMemory":
        if value.get("version") != CAUSAL_MEMORY_VERSION:
            raise ValueError("unsupported semantic causal-memory version")
        memory = cls()
        pending = [CausalMemoryRecord.from_dict(item) for item in value["records"]]
        while pending:
            progressed = False
            for record in tuple(pending):
                if set(record.parent_record_ids).issubset(memory._records):
                    memory.add(record)
                    pending.remove(record)
                    progressed = True
            if not progressed:
                raise ValueError("causal-memory parent graph is cyclic or incomplete")
        if value.get("memory_id") != memory.memory_id:
            raise ValueError("semantic causal-memory identity mismatch")
        return memory


class CausalMemoryRuntime:
    def __init__(
        self,
        memory: SemanticCausalMemory,
        checkpoint_path: Path,
        *,
        save_on_init: bool = True,
    ) -> None:
        self.memory = memory
        self.checkpoint_path = Path(checkpoint_path)
        if save_on_init:
            self.save_checkpoint()

    def _checkpoint_value(self) -> Dict[str, Any]:
        value = {
            "version": CAUSAL_MEMORY_VERSION,
            "memory": self.memory.as_dict(),
        }
        value["checkpoint_id"] = content_digest(value)
        return value

    def save_checkpoint(self) -> Path:
        destination = self.checkpoint_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        payload = canonical_json(self._checkpoint_value()) + b"\n"
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=destination.name + ".",
            suffix=".tmp",
            dir=str(destination.parent),
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, destination)
        finally:
            temporary = Path(temporary_name)
            if temporary.exists():
                temporary.unlink()
        return destination

    @classmethod
    def from_checkpoint(cls, path: Path) -> "CausalMemoryRuntime":
        checkpoint_path = Path(path)
        value = json.loads(checkpoint_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("causal-memory checkpoint must be a JSON object")
        body = dict(value)
        supplied = body.pop("checkpoint_id", None)
        if supplied != content_digest(body):
            raise ValueError("causal-memory checkpoint identity mismatch")
        memory = SemanticCausalMemory.from_dict(body["memory"])
        return cls(memory, checkpoint_path, save_on_init=False)
