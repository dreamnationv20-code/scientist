from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Protocol, Sequence, Tuple

from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    AuthoritativeStateRuntime,
    AutonomyEventKind,
    ResourceUsage,
    SubsystemSnapshot,
)
from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.program.contracts import HighLevelGoal
from scientist.program.literature import ClaimSignature
from scientist.program.research_kernel import (
    AutonomousResearchKernel,
    ProgramDisposition,
    ResearchKernelRuntime,
    ResearchMissionContract,
)


MISSION_SUCCESSION_VERSION = "autonomous-mission-succession-v1"
PROPOSAL_OPERATION = "propose_evidence_responsive_successor_missions"
NOVELTY_REVIEW_OPERATION = "audit_successor_mission_novelty"
METHOD_REVIEW_OPERATION = "audit_successor_mission_validity"
REQUIRED_HORIZONS = (
    "discovery_calibration",
    "sealed_prospective",
    "independent_replication",
)


def allowed_model_descriptor(value: str) -> bool:
    """Accept named 1.7B/3B models while rejecting any larger size marker."""

    sizes = tuple(
        float(item)
        for item in re.findall(r"(?<![0-9.])([0-9]+(?:\.[0-9]+)?)\s*[bB]\b", value)
    )
    if not sizes or any(size > 3.0 for size in sizes):
        return False
    return all(abs(size - 1.7) < 1e-9 or abs(size - 3.0) < 1e-9 for size in sizes)


class AuditedStructuredExchange(Protocol):
    def request_audited(
        self,
        *,
        operation: str,
        prompt: str,
        response_schema: Mapping[str, Any],
    ) -> Any: ...


def _unique_strings(
    values: Sequence[Any], label: str, *, minimum: int = 1
) -> Tuple[str, ...]:
    result = tuple(str(value).strip() for value in values)
    if len(result) < minimum or not all(result):
        raise ValueError("%s requires at least %d non-empty values" % (label, minimum))
    if len(result) != len(set(result)):
        raise ValueError("%s must contain unique values" % label)
    return result


def _array(item: Mapping[str, Any], minimum: int, maximum: int) -> Dict[str, Any]:
    return {
        "type": "array",
        "minItems": minimum,
        "maxItems": maximum,
        "items": dict(item),
    }


def proposal_schema() -> Dict[str, Any]:
    string = {"type": "string"}
    strings = lambda low, high: _array(string, low, high)
    experiment = {
        "type": "object",
        "properties": {
            "manipulation": string,
            "comparator": string,
            "positive_controls": strings(2, 6),
            "negative_controls": strings(1, 5),
            "answer_blind_measurements": strings(2, 6),
            "development_partition_ref": string,
            "sealed_partition_ref": string,
            "sample_size": {"type": "integer"},
            "maximum_laptop_hours": {"type": "number"},
            "model_classes": strings(1, 3),
            "outcome_withheld": {"type": "boolean"},
        },
        "required": [
            "manipulation",
            "comparator",
            "positive_controls",
            "negative_controls",
            "answer_blind_measurements",
            "development_partition_ref",
            "sealed_partition_ref",
            "sample_size",
            "maximum_laptop_hours",
            "model_classes",
            "outcome_withheld",
        ],
        "additionalProperties": False,
    }
    candidate = {
        "type": "object",
        "properties": {
            "candidate_ref": string,
            "title": string,
            "research_question": string,
            "central_hypothesis": string,
            "causal_representation": string,
            "changed_representation_dimensions": strings(2, 7),
            "explains_failed_result": string,
            "alternative_explanations": strings(2, 5),
            "answer_blind_features": strings(4, 12),
            "forbidden_predictor_inputs": strings(4, 10),
            "distinguishing_predictions": strings(3, 7),
            "falsification_conditions": strings(3, 7),
            "claim_statement": string,
            "claim_phenomenon": string,
            "claim_intervention": string,
            "claim_mechanism": string,
            "claim_evaluation": string,
            "initial_experiment": experiment,
            "program_stop_rules": strings(3, 7),
            "forbidden_shortcuts": strings(3, 8),
            "source_evidence_ids": strings(2, 6),
        },
        "required": [
            "candidate_ref",
            "title",
            "research_question",
            "central_hypothesis",
            "causal_representation",
            "changed_representation_dimensions",
            "explains_failed_result",
            "alternative_explanations",
            "answer_blind_features",
            "forbidden_predictor_inputs",
            "distinguishing_predictions",
            "falsification_conditions",
            "claim_statement",
            "claim_phenomenon",
            "claim_intervention",
            "claim_mechanism",
            "claim_evaluation",
            "initial_experiment",
            "program_stop_rules",
            "forbidden_shortcuts",
            "source_evidence_ids",
        ],
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {
            "candidates": _array(candidate, 3, 3),
            "generation_rationale": string,
        },
        "required": ["candidates", "generation_rationale"],
        "additionalProperties": False,
    }


def review_schema() -> Dict[str, Any]:
    string = {"type": "string"}
    boolean = {"type": "boolean"}
    number = {"type": "number"}
    review = {
        "type": "object",
        "properties": {
            "candidate_ref": string,
            "root_goal_aligned": boolean,
            "material_representation_change": boolean,
            "not_relabeling_failed_concept": boolean,
            "answer_blind": boolean,
            "causally_falsifiable": boolean,
            "executable_within_budget": boolean,
            "evidence_responsive": boolean,
            "positive_controls_adequate": boolean,
            "novelty_score": number,
            "expected_information_gain": number,
            "feasibility_score": number,
            "root_goal_relevance": number,
            "evidence_citations": _array(string, 2, 6),
            "disqualifying_defects": _array(string, 0, 8),
            "strongest_risk": string,
        },
        "required": [
            "candidate_ref",
            "root_goal_aligned",
            "material_representation_change",
            "not_relabeling_failed_concept",
            "answer_blind",
            "causally_falsifiable",
            "executable_within_budget",
            "evidence_responsive",
            "positive_controls_adequate",
            "novelty_score",
            "expected_information_gain",
            "feasibility_score",
            "root_goal_relevance",
            "evidence_citations",
            "disqualifying_defects",
            "strongest_risk",
        ],
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {
            "reviews": _array(review, 3, 3),
            "recommended_candidate_ref": string,
            "review_rationale": string,
        },
        "required": ["reviews", "recommended_candidate_ref", "review_rationale"],
        "additionalProperties": False,
    }


@dataclass(frozen=True)
class SuccessorExperimentContract:
    manipulation: str
    comparator: str
    positive_controls: Tuple[str, ...]
    negative_controls: Tuple[str, ...]
    answer_blind_measurements: Tuple[str, ...]
    development_partition_ref: str
    sealed_partition_ref: str
    sample_size: int
    maximum_laptop_hours: float
    model_classes: Tuple[str, ...]
    outcome_withheld: bool

    def __post_init__(self) -> None:
        if not all(
            (
                self.manipulation,
                self.comparator,
                self.development_partition_ref,
                self.sealed_partition_ref,
            )
        ):
            raise ValueError("successor experiment is incomplete")
        _unique_strings(self.positive_controls, "positive controls", minimum=2)
        _unique_strings(self.negative_controls, "negative controls")
        _unique_strings(self.answer_blind_measurements, "measurements", minimum=2)
        _unique_strings(self.model_classes, "model classes")
        if self.sample_size <= 0:
            raise ValueError("successor experiment sample size must be positive")
        if self.maximum_laptop_hours <= 0.0:
            raise ValueError("successor experiment budget must be positive")

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SuccessorExperimentContract":
        return cls(
            manipulation=str(value["manipulation"]),
            comparator=str(value["comparator"]),
            positive_controls=_unique_strings(value["positive_controls"], "positive controls", minimum=2),
            negative_controls=_unique_strings(value["negative_controls"], "negative controls"),
            answer_blind_measurements=_unique_strings(value["answer_blind_measurements"], "measurements", minimum=2),
            development_partition_ref=str(value["development_partition_ref"]),
            sealed_partition_ref=str(value["sealed_partition_ref"]),
            sample_size=int(value["sample_size"]),
            maximum_laptop_hours=float(value["maximum_laptop_hours"]),
            model_classes=_unique_strings(value["model_classes"], "model classes"),
            outcome_withheld=bool(value["outcome_withheld"]),
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "manipulation": self.manipulation,
            "comparator": self.comparator,
            "positive_controls": list(self.positive_controls),
            "negative_controls": list(self.negative_controls),
            "answer_blind_measurements": list(self.answer_blind_measurements),
            "development_partition_ref": self.development_partition_ref,
            "sealed_partition_ref": self.sealed_partition_ref,
            "sample_size": self.sample_size,
            "maximum_laptop_hours": self.maximum_laptop_hours,
            "model_classes": list(self.model_classes),
            "outcome_withheld": self.outcome_withheld,
        }


@dataclass(frozen=True)
class SuccessorMissionCandidate:
    candidate_ref: str
    title: str
    research_question: str
    central_hypothesis: str
    causal_representation: str
    changed_representation_dimensions: Tuple[str, ...]
    explains_failed_result: str
    alternative_explanations: Tuple[str, ...]
    answer_blind_features: Tuple[str, ...]
    forbidden_predictor_inputs: Tuple[str, ...]
    distinguishing_predictions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    claim_statement: str
    claim_phenomenon: str
    claim_intervention: str
    claim_mechanism: str
    claim_evaluation: str
    initial_experiment: SuccessorExperimentContract
    program_stop_rules: Tuple[str, ...]
    forbidden_shortcuts: Tuple[str, ...]
    source_evidence_ids: Tuple[str, ...]

    def __post_init__(self) -> None:
        required = (
            self.candidate_ref,
            self.title,
            self.research_question,
            self.central_hypothesis,
            self.causal_representation,
            self.explains_failed_result,
            self.claim_statement,
            self.claim_phenomenon,
            self.claim_intervention,
            self.claim_mechanism,
            self.claim_evaluation,
        )
        if not all(required):
            raise ValueError("successor candidate is incomplete")
        _unique_strings(self.changed_representation_dimensions, "changed dimensions", minimum=2)
        _unique_strings(self.alternative_explanations, "alternative explanations", minimum=2)
        _unique_strings(self.answer_blind_features, "answer-blind features", minimum=4)
        _unique_strings(self.forbidden_predictor_inputs, "forbidden inputs", minimum=4)
        _unique_strings(self.distinguishing_predictions, "predictions", minimum=3)
        _unique_strings(self.falsification_conditions, "falsification conditions", minimum=3)
        _unique_strings(self.program_stop_rules, "program stop rules", minimum=3)
        _unique_strings(self.forbidden_shortcuts, "forbidden shortcuts", minimum=3)
        _unique_strings(self.source_evidence_ids, "source evidence", minimum=2)

    @property
    def candidate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SuccessorMissionCandidate":
        return cls(
            candidate_ref=str(value["candidate_ref"]),
            title=str(value["title"]),
            research_question=str(value["research_question"]),
            central_hypothesis=str(value["central_hypothesis"]),
            causal_representation=str(value["causal_representation"]),
            changed_representation_dimensions=_unique_strings(value["changed_representation_dimensions"], "changed dimensions", minimum=2),
            explains_failed_result=str(value["explains_failed_result"]),
            alternative_explanations=_unique_strings(value["alternative_explanations"], "alternative explanations", minimum=2),
            answer_blind_features=_unique_strings(value["answer_blind_features"], "answer-blind features", minimum=4),
            forbidden_predictor_inputs=_unique_strings(value["forbidden_predictor_inputs"], "forbidden inputs", minimum=4),
            distinguishing_predictions=_unique_strings(value["distinguishing_predictions"], "predictions", minimum=3),
            falsification_conditions=_unique_strings(value["falsification_conditions"], "falsification conditions", minimum=3),
            claim_statement=str(value["claim_statement"]),
            claim_phenomenon=str(value["claim_phenomenon"]),
            claim_intervention=str(value["claim_intervention"]),
            claim_mechanism=str(value["claim_mechanism"]),
            claim_evaluation=str(value["claim_evaluation"]),
            initial_experiment=SuccessorExperimentContract.from_dict(value["initial_experiment"]),
            program_stop_rules=_unique_strings(value["program_stop_rules"], "program stop rules", minimum=3),
            forbidden_shortcuts=_unique_strings(value["forbidden_shortcuts"], "forbidden shortcuts", minimum=3),
            source_evidence_ids=_unique_strings(value["source_evidence_ids"], "source evidence", minimum=2),
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": MISSION_SUCCESSION_VERSION,
            "candidate_ref": self.candidate_ref,
            "title": self.title,
            "research_question": self.research_question,
            "central_hypothesis": self.central_hypothesis,
            "causal_representation": self.causal_representation,
            "changed_representation_dimensions": list(self.changed_representation_dimensions),
            "explains_failed_result": self.explains_failed_result,
            "alternative_explanations": list(self.alternative_explanations),
            "answer_blind_features": list(self.answer_blind_features),
            "forbidden_predictor_inputs": list(self.forbidden_predictor_inputs),
            "distinguishing_predictions": list(self.distinguishing_predictions),
            "falsification_conditions": list(self.falsification_conditions),
            "claim_statement": self.claim_statement,
            "claim_phenomenon": self.claim_phenomenon,
            "claim_intervention": self.claim_intervention,
            "claim_mechanism": self.claim_mechanism,
            "claim_evaluation": self.claim_evaluation,
            "initial_experiment": self.initial_experiment.as_dict(),
            "program_stop_rules": list(self.program_stop_rules),
            "forbidden_shortcuts": list(self.forbidden_shortcuts),
            "source_evidence_ids": list(self.source_evidence_ids),
        }
        if include_id:
            value["candidate_id"] = self.candidate_id
        return value


@dataclass(frozen=True)
class SuccessorCandidateReview:
    candidate_ref: str
    root_goal_aligned: bool
    material_representation_change: bool
    not_relabeling_failed_concept: bool
    answer_blind: bool
    causally_falsifiable: bool
    executable_within_budget: bool
    evidence_responsive: bool
    positive_controls_adequate: bool
    novelty_score: float
    expected_information_gain: float
    feasibility_score: float
    root_goal_relevance: float
    evidence_citations: Tuple[str, ...]
    disqualifying_defects: Tuple[str, ...]
    strongest_risk: str

    def __post_init__(self) -> None:
        if not self.candidate_ref or not self.strongest_risk:
            raise ValueError("successor review is incomplete")
        for value in (
            self.novelty_score,
            self.expected_information_gain,
            self.feasibility_score,
            self.root_goal_relevance,
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError("successor review scores must be in [0,1]")
        _unique_strings(self.evidence_citations, "review evidence", minimum=2)
        if not all(str(value).strip() for value in self.disqualifying_defects):
            raise ValueError("review defects must be non-empty strings")

    @property
    def hard_gate_passed(self) -> bool:
        return all(
            (
                self.root_goal_aligned,
                self.material_representation_change,
                self.not_relabeling_failed_concept,
                self.answer_blind,
                self.causally_falsifiable,
                self.executable_within_budget,
                self.evidence_responsive,
                self.positive_controls_adequate,
                not self.disqualifying_defects,
            )
        )

    @property
    def selection_score(self) -> float:
        return (
            0.30 * self.expected_information_gain
            + 0.25 * self.novelty_score
            + 0.20 * self.feasibility_score
            + 0.25 * self.root_goal_relevance
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SuccessorCandidateReview":
        return cls(
            candidate_ref=str(value["candidate_ref"]),
            root_goal_aligned=bool(value["root_goal_aligned"]),
            material_representation_change=bool(value["material_representation_change"]),
            not_relabeling_failed_concept=bool(value["not_relabeling_failed_concept"]),
            answer_blind=bool(value["answer_blind"]),
            causally_falsifiable=bool(value["causally_falsifiable"]),
            executable_within_budget=bool(value["executable_within_budget"]),
            evidence_responsive=bool(value["evidence_responsive"]),
            positive_controls_adequate=bool(value["positive_controls_adequate"]),
            novelty_score=float(value["novelty_score"]),
            expected_information_gain=float(value["expected_information_gain"]),
            feasibility_score=float(value["feasibility_score"]),
            root_goal_relevance=float(value["root_goal_relevance"]),
            evidence_citations=_unique_strings(value["evidence_citations"], "review evidence", minimum=2),
            disqualifying_defects=tuple(str(item).strip() for item in value["disqualifying_defects"]),
            strongest_risk=str(value["strongest_risk"]),
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_ref": self.candidate_ref,
            "hard_gate_passed": self.hard_gate_passed,
            "selection_score": self.selection_score,
            "root_goal_aligned": self.root_goal_aligned,
            "material_representation_change": self.material_representation_change,
            "not_relabeling_failed_concept": self.not_relabeling_failed_concept,
            "answer_blind": self.answer_blind,
            "causally_falsifiable": self.causally_falsifiable,
            "executable_within_budget": self.executable_within_budget,
            "evidence_responsive": self.evidence_responsive,
            "positive_controls_adequate": self.positive_controls_adequate,
            "novelty_score": self.novelty_score,
            "expected_information_gain": self.expected_information_gain,
            "feasibility_score": self.feasibility_score,
            "root_goal_relevance": self.root_goal_relevance,
            "evidence_citations": list(self.evidence_citations),
            "disqualifying_defects": list(self.disqualifying_defects),
            "strongest_risk": self.strongest_risk,
        }


@dataclass(frozen=True)
class MissionSuccessionAuthorization:
    root_goal_id: str
    parent_mission_id: str
    parent_decision_id: str
    failed_validation_id: str
    selected_candidate_id: str
    selected_candidate_ref: str
    proposal_set_id: str
    novelty_review_set_id: str
    method_review_set_id: str
    successor_mission: ResearchMissionContract
    rejected_candidate_ids: Tuple[str, ...]
    deterministic_gate_checks: Mapping[str, bool]
    next_action: str

    @property
    def authorization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": MISSION_SUCCESSION_VERSION,
            "root_goal_id": self.root_goal_id,
            "parent_mission_id": self.parent_mission_id,
            "parent_decision_id": self.parent_decision_id,
            "failed_validation_id": self.failed_validation_id,
            "selected_candidate_id": self.selected_candidate_id,
            "selected_candidate_ref": self.selected_candidate_ref,
            "proposal_set_id": self.proposal_set_id,
            "novelty_review_set_id": self.novelty_review_set_id,
            "method_review_set_id": self.method_review_set_id,
            "successor_mission": self.successor_mission.as_dict(),
            "rejected_candidate_ids": list(self.rejected_candidate_ids),
            "deterministic_gate_checks": dict(sorted(self.deterministic_gate_checks.items())),
            "next_action": self.next_action,
        }
        if include_id:
            value["authorization_id"] = self.authorization_id
        return value


def _public_evidence_packet(
    root_goal: HighLevelGoal,
    parent: AutonomousResearchKernel,
    causal_memory_records: Sequence[Mapping[str, Any]],
) -> Dict[str, Any]:
    if parent.mission is None or parent.concept is None or parent.concept_validation is None:
        raise ValueError("successor genesis requires a complete failed concept branch")
    if parent.terminal_disposition != ProgramDisposition.KILL or not parent.decisions:
        raise ValueError("successor genesis requires a terminal kill decision")
    decision = parent.decisions[-1]
    if decision.disposition != ProgramDisposition.KILL:
        raise ValueError("parent decision is not a kill")
    if parent.concept_validation.passed:
        raise ValueError("successor genesis cannot replace a passing concept")
    return {
        "root_goal": root_goal.as_dict(),
        "parent_mission": {
            "mission_id": parent.mission.mission_id,
            "research_question": parent.mission.research_question,
            "claim_signature": parent.mission.claim_signature.as_dict(),
        },
        "rejected_concept": {
            "concept_id": parent.concept.concept_id,
            "name": parent.concept.name,
            "definition": parent.concept.definition,
            "causal_explanation": parent.concept.causal_explanation,
            "input_primitives": list(parent.concept.input_primitives),
        },
        "failed_validation": {
            "validation_id": parent.concept_validation.validation_id,
            "passed": parent.concept_validation.passed,
            "augmented_predictive_score": parent.concept_validation.augmented_predictive_score,
            "baseline_predictive_score": parent.concept_validation.baseline_predictive_score,
            "predictive_improvement": parent.concept_validation.predictive_improvement,
            "intervention_effect": parent.concept_validation.intervention_effect,
        },
        "terminal_decision": decision.as_dict(),
        "causal_memory": [dict(item) for item in causal_memory_records],
        "outcome_boundary": (
            "Only the listed development evidence is available. No confirmatory, "
            "prospective Nature, or replication outcome may be inferred or accessed."
        ),
    }


def _proposal_prompt(packet: Mapping[str, Any]) -> str:
    return (
        "You are the abductive mission-genesis component inside an autonomous AI "
        "scientist. A preregistered latent concept failed prospectively and its "
        "mission was correctly terminated. Generate exactly three genuinely distinct "
        "successor missions under the unchanged root objective. Do not repair, rename, "
        "or decompose the rejected concept. Each candidate must introduce a materially "
        "different causal representation, explain why the failed result is informative, "
        "and begin with an answer-blind discriminating experiment that fits four laptop "
        "hours and uses only 1.7B/3B models. Predictions and stopping rules must be "
        "falsifiable before outcomes. Treat active causal-memory entries as hypotheses, "
        "not conclusions; never revive exhausted paths. Return only the typed proposal.\n\n"
        + json.dumps(packet, indent=2, sort_keys=True)
    )


def _review_prompt(
    packet: Mapping[str, Any],
    proposals: Mapping[str, Any],
    *,
    role: str,
) -> str:
    emphasis = (
        "Focus on semantic novelty, causal distinctness, and disguised relabeling."
        if role == "novelty"
        else "Focus on answer blindness, falsifiability, controls, feasibility, and claim validity."
    )
    return (
        "You are an independent adversarial %s reviewer. You did not generate these "
        "missions. Audit all three against the unchanged root goal and the actual "
        "negative evidence. %s Scores are probabilities in [0,1]. A defect is "
        "disqualifying when it permits leakage, post-hoc flexibility, failed-concept "
        "relabeling, unqualified intervention inference, or infeasible local execution. "
        "Cite both the failed validation ID and terminal decision ID for every review. "
        "Return only the typed review.\n\nEVIDENCE\n%s\n\nCANDIDATES\n%s"
        % (
            role,
            emphasis,
            json.dumps(packet, indent=2, sort_keys=True),
            json.dumps(proposals, indent=2, sort_keys=True),
        )
    )


def _model_usage(audited: Any) -> ResourceUsage:
    return ResourceUsage(
        model_output_tokens=audited.reported_tokens_used,
        model_calls=1,
        wall_seconds=audited.wall_seconds,
    )


class AutonomousMissionSuccessionController:
    """Authorize a new mission without letting proposal models govern state."""

    controller_version = MISSION_SUCCESSION_VERSION

    def __init__(
        self,
        *,
        root_goal: HighLevelGoal,
        parent_kernel: AutonomousResearchKernel,
        domain: Any,
        causal_memory_records: Sequence[Mapping[str, Any]],
        generator_exchange: AuditedStructuredExchange,
        novelty_exchange: AuditedStructuredExchange,
        method_exchange: AuditedStructuredExchange,
        authority_runtime: AuthoritativeStateRuntime,
        artifact_store: ArtifactStore,
        successor_checkpoint_path: Path,
    ) -> None:
        self.root_goal = root_goal
        self.parent_kernel = parent_kernel
        self.domain = domain
        self.causal_memory_records = tuple(dict(item) for item in causal_memory_records)
        self.generator_exchange = generator_exchange
        self.novelty_exchange = novelty_exchange
        self.method_exchange = method_exchange
        self.authority_runtime = authority_runtime
        self.artifact_store = artifact_store
        self.successor_checkpoint_path = Path(successor_checkpoint_path)

    def _save(self) -> None:
        self.authority_runtime.save_checkpoint()

    def _record_exchange(self, action_id: str, audited: Any, operation: str) -> None:
        usage = _model_usage(audited)
        prospective = self.authority_runtime.ledger.state.usage.plus(usage)
        if not self.authority_runtime.ledger.state.budget.admits(prospective):
            raise ValueError("successor-genesis model usage exceeds the frozen budget")
        self.authority_runtime.ledger.append(
            AutonomyEventKind.MODEL_EXCHANGE_RECORDED,
            ActorIdentity("proposal-model:%s" % audited.model_ref, ActorKind.PROPOSAL_MODEL),
            AuthorityScope.PROPOSE,
            action_id=action_id,
            payload={
                "operation": operation,
                "packet_id": audited.packet_id,
                "model_exercised_scientific_authority": False,
            },
            input_artifact_ids=(audited.request_digest,),
            output_artifact_ids=(audited.response_digest,),
            resource_delta=usage,
        )
        self._save()

    @staticmethod
    def _review_map(value: Mapping[str, Any]) -> Dict[str, SuccessorCandidateReview]:
        result = {
            review.candidate_ref: review
            for review in (
                SuccessorCandidateReview.from_dict(item) for item in value["reviews"]
            )
        }
        if len(result) != 3:
            raise ValueError("review must cover three unique candidates")
        if value["recommended_candidate_ref"] not in result:
            raise ValueError("review recommendation references an unknown candidate")
        return result

    def _authorize(
        self,
        proposals: Mapping[str, Any],
        novelty_value: Mapping[str, Any],
        method_value: Mapping[str, Any],
    ) -> Tuple[MissionSuccessionAuthorization, SuccessorMissionCandidate]:
        candidates = tuple(
            SuccessorMissionCandidate.from_dict(item) for item in proposals["candidates"]
        )
        by_ref = {item.candidate_ref: item for item in candidates}
        if len(by_ref) != 3:
            raise ValueError("proposal must contain three uniquely referenced candidates")
        novelty = self._review_map(novelty_value)
        method = self._review_map(method_value)
        if set(by_ref) != set(novelty) or set(by_ref) != set(method):
            raise ValueError("independent reviewers did not audit the same proposal set")

        decision = self.parent_kernel.decisions[-1]
        failed_validation_id = self.parent_kernel.concept_validation.validation_id
        required_review_authorities = {
            decision.decision_id,
            failed_validation_id,
        }

        def review_cites_authorities(review: SuccessorCandidateReview) -> bool:
            return all(
                any(authority_id in citation for citation in review.evidence_citations)
                for authority_id in required_review_authorities
            )

        eligible = []
        for ref, candidate in by_ref.items():
            experiment = candidate.initial_experiment
            deterministic_candidate_gate = all(
                (
                    experiment.sample_size >= 24,
                    experiment.maximum_laptop_hours <= 4.0,
                    experiment.outcome_withheld,
                    experiment.development_partition_ref
                    != experiment.sealed_partition_ref,
                    all(
                        allowed_model_descriptor(item)
                        for item in experiment.model_classes
                    ),
                )
            )
            if not deterministic_candidate_gate:
                continue
            if failed_validation_id not in candidate.source_evidence_ids:
                continue
            candidate_reviews = (novelty[ref], method[ref])
            if not all(review_cites_authorities(item) for item in candidate_reviews):
                continue
            if not all(item.hard_gate_passed for item in candidate_reviews):
                continue
            if min(item.novelty_score for item in candidate_reviews) < 0.60:
                continue
            if min(item.expected_information_gain for item in candidate_reviews) < 0.55:
                continue
            if min(item.feasibility_score for item in candidate_reviews) < 0.55:
                continue
            score = sum(item.selection_score for item in candidate_reviews) / 2.0
            eligible.append((score, ref, candidate))
        if not eligible:
            raise ValueError("no successor mission passed both independent hard gates")
        _, selected_ref, selected = sorted(
            eligible, key=lambda item: (-item[0], item[1])
        )[0]

        proposal_set_id = content_digest(proposals)
        novelty_review_set_id = content_digest(novelty_value)
        method_review_set_id = content_digest(method_value)
        root_node_id = content_digest(
            {
                "version": MISSION_SUCCESSION_VERSION,
                "candidate_id": selected.candidate_id,
                "role": "successor_mission_root",
            }
        )
        mission = ResearchMissionContract(
            goal=self.root_goal,
            goal_graph_ref=content_digest(
                {
                    "proposal_set_id": proposal_set_id,
                    "novelty_review_set_id": novelty_review_set_id,
                    "method_review_set_id": method_review_set_id,
                    "selected_candidate_id": selected.candidate_id,
                }
            ),
            root_node_id=root_node_id,
            domain_id=self.domain.domain_id,
            domain_bundle_ref=self.domain.bundle_ref,
            research_question=selected.research_question,
            claim_signature=ClaimSignature(
                subject_id=root_node_id,
                statement=selected.claim_statement,
                problem=self.root_goal.outcome,
                phenomenon=selected.claim_phenomenon,
                intervention=selected.claim_intervention,
                mechanism=selected.claim_mechanism,
                evaluation=selected.claim_evaluation,
            ),
            primary_metric=next(
                item.name for item in self.root_goal.terminal_metrics if item.primary
            ),
            terminal_gate_ref="successor-terminal-gate:%s" % selected.candidate_id,
            required_horizons=REQUIRED_HORIZONS,
            program_stop_rules=selected.program_stop_rules,
            forbidden_shortcuts=selected.forbidden_shortcuts,
            owner_ref="autonomous-mission-succession-controller-v1",
        )
        checks = {
            "parent_terminal_kill_verified": True,
            "failed_validation_verified": True,
            "root_goal_unchanged": mission.goal.goal_id == self.root_goal.goal_id,
            "three_distinct_candidates": len(by_ref) == 3,
            "two_independent_reviews_complete": set(novelty) == set(method) == set(by_ref),
            "selected_passed_both_hard_gates": novelty[selected_ref].hard_gate_passed and method[selected_ref].hard_gate_passed,
            "selected_cites_negative_evidence": failed_validation_id
            in selected.source_evidence_ids,
            "independent_reviews_cite_terminal_authority": all(
                review_cites_authorities(item)
                for item in (novelty[selected_ref], method[selected_ref])
            ),
            "development_and_sealed_partitions_disjoint": selected.initial_experiment.development_partition_ref != selected.initial_experiment.sealed_partition_ref,
            "confirmatory_outcomes_unopened": selected.initial_experiment.outcome_withheld,
            "local_model_boundary_preserved": all(
                allowed_model_descriptor(item)
                for item in selected.initial_experiment.model_classes
            ),
        }
        if not all(checks.values()):
            raise ValueError("deterministic successor authorization gate failed")
        authorization = MissionSuccessionAuthorization(
            root_goal_id=self.root_goal.goal_id,
            parent_mission_id=self.parent_kernel.mission.mission_id,
            parent_decision_id=decision.decision_id,
            failed_validation_id=self.parent_kernel.concept_validation.validation_id,
            selected_candidate_id=selected.candidate_id,
            selected_candidate_ref=selected_ref,
            proposal_set_id=proposal_set_id,
            novelty_review_set_id=novelty_review_set_id,
            method_review_set_id=method_review_set_id,
            successor_mission=mission,
            rejected_candidate_ids=tuple(
                item.candidate_id for item in candidates if item.candidate_ref != selected_ref
            ),
            deterministic_gate_checks=checks,
            next_action="survey_prior_art",
        )
        return authorization, selected

    def run(self) -> Tuple[MissionSuccessionAuthorization, AutonomousResearchKernel]:
        packet = _public_evidence_packet(
            self.root_goal, self.parent_kernel, self.causal_memory_records
        )
        decision = self.parent_kernel.decisions[-1]
        action_id = content_digest(
            {
                "version": MISSION_SUCCESSION_VERSION,
                "kind": "authorize_successor_mission",
                "root_goal_id": self.root_goal.goal_id,
                "parent_mission_id": self.parent_kernel.mission.mission_id,
                "parent_decision_id": decision.decision_id,
            }
        )
        ledger = self.authority_runtime.ledger
        if ledger.state.objective_id != self.root_goal.goal_id:
            raise ValueError("successor controller and authority objective disagree")
        ledger.append(
            AutonomyEventKind.ACTION_SELECTED,
            ActorIdentity("successor-goal-policy-v1", ActorKind.SCIENTIST_POLICY),
            AuthorityScope.GOVERN,
            action_id=action_id,
            payload={
                "kind": "authorize_successor_mission",
                "parent_decision_id": decision.decision_id,
                "confirmatory_outcomes_available": False,
            },
        )
        self._save()

        proposal = self.generator_exchange.request_audited(
            operation=PROPOSAL_OPERATION,
            prompt=_proposal_prompt(packet),
            response_schema=proposal_schema(),
        )
        self._record_exchange(action_id, proposal, PROPOSAL_OPERATION)
        novelty = self.novelty_exchange.request_audited(
            operation=NOVELTY_REVIEW_OPERATION,
            prompt=_review_prompt(packet, proposal.response, role="novelty"),
            response_schema=review_schema(),
        )
        self._record_exchange(action_id, novelty, NOVELTY_REVIEW_OPERATION)
        method = self.method_exchange.request_audited(
            operation=METHOD_REVIEW_OPERATION,
            prompt=_review_prompt(packet, proposal.response, role="methods"),
            response_schema=review_schema(),
        )
        self._record_exchange(action_id, method, METHOD_REVIEW_OPERATION)

        authorization, selected = self._authorize(
            proposal.response, novelty.response, method.response
        )
        proposal_artifact = self.artifact_store.put(
            "successor_mission_proposal_set", proposal.response
        )
        novelty_artifact = self.artifact_store.put(
            "successor_mission_novelty_review", novelty.response
        )
        method_artifact = self.artifact_store.put(
            "successor_mission_method_review", method.response
        )
        authorization_artifact = self.artifact_store.put(
            "successor_mission_authorization", authorization.as_dict()
        )
        ledger.append(
            AutonomyEventKind.VERIFICATION_RECORDED,
            ActorIdentity("successor-mission-validator-v1", ActorKind.DETERMINISTIC_VALIDATOR),
            AuthorityScope.VERIFY,
            action_id=action_id,
            payload={
                "authorization_id": authorization.authorization_id,
                "selected_candidate_ref": selected.candidate_ref,
                "gate_checks": dict(authorization.deterministic_gate_checks),
                "proposal_models_exercised_scientific_authority": False,
            },
            input_artifact_ids=(proposal_artifact, novelty_artifact, method_artifact),
            output_artifact_ids=(authorization_artifact,),
        )
        self._save()

        successor = AutonomousResearchKernel(policy=self.parent_kernel.policy)
        successor.freeze_mission(authorization.successor_mission, self.domain)
        ResearchKernelRuntime(
            successor, self.domain, self.successor_checkpoint_path
        )
        successor_checkpoint = json.loads(
            self.successor_checkpoint_path.read_text(encoding="utf-8")
        )
        successor_checkpoint_id = str(successor_checkpoint["checkpoint_id"])
        lineage = {
            "version": MISSION_SUCCESSION_VERSION,
            "root_goal_id": self.root_goal.goal_id,
            "parent": {
                "mission_id": self.parent_kernel.mission.mission_id,
                "decision_id": decision.decision_id,
                "disposition": decision.disposition.value,
                "immutable": True,
            },
            "edge": {
                "kind": "evidence_responsive_successor",
                "authorization_id": authorization.authorization_id,
                "failed_validation_id": self.parent_kernel.concept_validation.validation_id,
            },
            "successor": {
                "mission_id": authorization.successor_mission.mission_id,
                "status": "authorized",
                "next_action": successor.next_action().kind.value,
            },
        }
        lineage["lineage_id"] = content_digest(lineage)
        lineage_artifact = self.artifact_store.put("mission_lineage", lineage)
        ledger.append(
            AutonomyEventKind.STATE_COMMITTED,
            ActorIdentity("successor-goal-policy-v1", ActorKind.SCIENTIST_POLICY),
            AuthorityScope.GOVERN,
            action_id=action_id,
            payload={
                "authorization_id": authorization.authorization_id,
                "parent_preserved": True,
                "successor_mission_id": authorization.successor_mission.mission_id,
                "successor_next_action": successor.next_action().kind.value,
                "nature_claim_authorized": False,
            },
            input_artifact_ids=(authorization_artifact,),
            output_artifact_ids=(lineage_artifact, successor_checkpoint_id),
            snapshot_updates=(
                SubsystemSnapshot(
                    "mission_lineage",
                    lineage_artifact,
                    MISSION_SUCCESSION_VERSION,
                    str(self.successor_checkpoint_path.parent / "artifacts"),
                ),
                SubsystemSnapshot(
                    "research_kernel",
                    successor_checkpoint_id,
                    "autonomous-research-kernel-v3",
                    str(self.successor_checkpoint_path),
                ),
            ),
        )
        self._save()
        ledger.append(
            AutonomyEventKind.ACTION_COMPLETED,
            ActorIdentity("successor-goal-policy-v1", ActorKind.SCIENTIST_POLICY),
            AuthorityScope.GOVERN,
            action_id=action_id,
            payload={
                "outcome": "successor_mission_authorized",
                "authorization_id": authorization.authorization_id,
            },
        )
        self._save()
        ledger.append(
            AutonomyEventKind.RUN_TERMINATED,
            ActorIdentity("successor-goal-policy-v1", ActorKind.SCIENTIST_POLICY),
            AuthorityScope.GOVERN,
            payload={
                "outcome": "handoff_to_authorized_successor_mission",
                "successor_mission_id": authorization.successor_mission.mission_id,
            },
        )
        self._save()
        return authorization, successor


__all__ = [
    "AutonomousMissionSuccessionController",
    "MISSION_SUCCESSION_VERSION",
    "METHOD_REVIEW_OPERATION",
    "NOVELTY_REVIEW_OPERATION",
    "PROPOSAL_OPERATION",
    "MissionSuccessionAuthorization",
    "SuccessorCandidateReview",
    "SuccessorExperimentContract",
    "SuccessorMissionCandidate",
    "allowed_model_descriptor",
    "proposal_schema",
    "review_schema",
]
