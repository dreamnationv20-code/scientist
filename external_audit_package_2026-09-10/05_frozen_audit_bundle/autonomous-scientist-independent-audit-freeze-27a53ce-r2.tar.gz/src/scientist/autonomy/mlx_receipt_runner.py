from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence, Tuple

from scientist.autonomy.receipt_journal import ResumableReceiptJournal
from scientist.autonomy.state import ResourceUsage
from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.repairability_runtime_guard_v2 import (
    ensure_qwen_streaming_detokenizer_compatibility,
)


MLX_RECEIPT_RUNNER_VERSION = "scientist-resumable-mlx-receipt-runner-v1"


def _file_sha256(path: Path) -> str:
    result = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


@dataclass(frozen=True)
class GenerationUnit:
    unit_ref: str
    prompt: str
    maximum_new_tokens: int
    seed: int
    public_metadata: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.unit_ref or not self.prompt:
            raise ValueError("generation unit identity is incomplete")
        if self.maximum_new_tokens <= 0 or self.seed < 0:
            raise ValueError("generation unit budget or seed is invalid")


class MlxGenerationBackend:
    """Lazy, deterministic MLX backend for an already frozen model identity."""

    def __init__(self, model_identity: Mapping[str, Any]) -> None:
        self.model_identity = dict(model_identity)
        self._model = None
        self._tokenizer = None
        self.compatibility: Mapping[str, Any] | None = None

    def _load(self) -> None:
        path = Path(str(self.model_identity["path"]))
        if _file_sha256(path / "config.json") != self.model_identity["config_sha256"]:
            raise ValueError("MLX model config changed after freeze")
        for weight in self.model_identity["weights"]:
            candidate = path / str(weight["name"])
            if (
                candidate.stat().st_size != int(weight["bytes"])
                or _file_sha256(candidate) != weight["sha256"]
            ):
                raise ValueError("MLX model weights changed after freeze")
        from mlx_lm import load

        self._model, self._tokenizer = load(
            str(path), tokenizer_config={"trust_remote_code": False}
        )
        self.compatibility = ensure_qwen_streaming_detokenizer_compatibility(
            self._tokenizer
        )

    def __call__(self, unit: GenerationUnit) -> Mapping[str, Any]:
        if self._model is None or self._tokenizer is None:
            self._load()
        import mlx.core as mx
        from mlx_lm import stream_generate
        from mlx_lm.sample_utils import make_sampler

        mx.random.seed(unit.seed)
        pieces = []
        last = None
        sampler = make_sampler(temp=0.0, top_p=1.0)
        for response in stream_generate(
            self._model,
            self._tokenizer,
            prompt=unit.prompt,
            max_tokens=unit.maximum_new_tokens,
            sampler=sampler,
        ):
            pieces.append(response.text)
            last = response
        text = "".join(pieces)
        generation = (
            {
                "finish_reason": "empty",
                "generation_tps": 0.0,
                "peak_memory_gb": 0.0,
            }
            if last is None
            else {
                "finish_reason": str(last.finish_reason),
                "generation_tps": float(last.generation_tps),
                "peak_memory_gb": float(last.peak_memory),
            }
        )
        return {
            "response": text,
            "prompt_tokens": len(self._tokenizer.encode(unit.prompt)),
            "output_tokens": len(
                self._tokenizer.encode(text, add_special_tokens=False)
            ),
            "generation": generation,
        }

    def chat_prompt(self, *, system: str, content: str) -> str:
        if self._model is None or self._tokenizer is None:
            self._load()
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": content},
        ]
        try:
            return self._tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            return self._tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )

    def close(self) -> None:
        if self._model is None:
            return
        import gc
        import mlx.core as mx

        self._model = None
        self._tokenizer = None
        gc.collect()
        mx.clear_cache()


class ResumableGenerationCell:
    """Execute and checkpoint each generation before starting the next one."""

    def __init__(
        self,
        *,
        journal_root: Path,
        run_id: str,
        action_id: str,
        contract_id: str,
        units: Sequence[GenerationUnit],
        generator: Callable[[GenerationUnit], Mapping[str, Any]],
    ) -> None:
        copied = tuple(units)
        if not copied or len({unit.unit_ref for unit in copied}) != len(copied):
            raise ValueError("generation cell units must be unique")
        self.units = copied
        self.generator = generator
        self.journal = ResumableReceiptJournal(
            journal_root,
            run_id=run_id,
            action_id=action_id,
            contract_id=contract_id,
            expected_units=tuple(unit.unit_ref for unit in copied),
        )

    def run(self) -> Tuple[Mapping[str, Any], ...]:
        by_ref = {unit.unit_ref: unit for unit in self.units}
        for unit_ref in self.journal.pending_units:
            unit = by_ref[unit_ref]
            started = time.perf_counter()
            generated = dict(self.generator(unit))
            elapsed = time.perf_counter() - started
            required = {"response", "prompt_tokens", "output_tokens", "generation"}
            if not required.issubset(generated):
                raise ValueError("generation backend returned an incomplete result")
            body = {
                "runner_version": MLX_RECEIPT_RUNNER_VERSION,
                "unit_ref": unit.unit_ref,
                **dict(unit.public_metadata),
                "prompt_sha256": content_digest(unit.prompt),
                "maximum_new_tokens": unit.maximum_new_tokens,
                "seed": unit.seed,
                "response": str(generated["response"]),
                "prompt_tokens": int(generated["prompt_tokens"]),
                "output_tokens": int(generated["output_tokens"]),
                "generation": dict(generated["generation"]),
                "elapsed_seconds": elapsed,
            }
            receipt = {**body, "receipt_id": content_digest(body)}
            self.journal.record(
                unit.unit_ref,
                {"receipt": receipt},
                usage=ResourceUsage(
                    wall_seconds=elapsed,
                    compute_units=elapsed,
                ),
            )
        self.journal.finalize()
        return tuple(
            dict(item.payload["receipt"]) for item in self.journal.receipts()
        )


__all__ = [
    "MLX_RECEIPT_RUNNER_VERSION",
    "GenerationUnit",
    "MlxGenerationBackend",
    "ResumableGenerationCell",
]
