from __future__ import annotations

from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest


NATURE_EVIDENCE_INTEGRATION_VERSION = "autonomous-scientist-nature-evidence-v1"
REPLICATION_ATTESTATION_VERSION = "adaptive-independent-replication-attestation-v1"


def _identified(value: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"invalid {key}")
    return value


def validate_replication_attestation(
    value: Mapping[str, Any], *, expected_run_id: str
) -> Mapping[str, Any]:
    _identified(value, "replication_attestation_id")
    checks = value.get("checks")
    if not (
        value.get("version") == REPLICATION_ATTESTATION_VERSION
        and value.get("confirmatory_run_id") == expected_run_id
        and isinstance(value.get("replicating_laboratory_ref"), str)
        and value["replicating_laboratory_ref"].strip()
        and value.get("laboratory_independent_of_authors") is True
        and value.get("laboratory_independent_of_primary_provider") is True
        and value.get("authors_absent_from_execution_and_scoring") is True
        and isinstance(value.get("signed_attestation"), str)
        and len(value["signed_attestation"].strip()) >= 32
        and isinstance(checks, Mapping)
        and checks
        and all(item is True for item in checks.values())
    ):
        raise ValueError("independent replication attestation is incomplete")
    return value


def integrate_nature_evidence(
    *,
    primary_run: Mapping[str, Any],
    primary_analysis: Mapping[str, Any],
    primary_provider_commitment: Mapping[str, Any],
    ablation_run: Mapping[str, Any],
    ablation_analysis: Mapping[str, Any],
    transport_run: Mapping[str, Any],
    transport_analysis: Mapping[str, Any],
    transport_provider_commitment: Mapping[str, Any],
    replication_run: Mapping[str, Any],
    replication_analysis: Mapping[str, Any],
    replication_provider_commitment: Mapping[str, Any],
    replication_attestation: Mapping[str, Any],
) -> Mapping[str, Any]:
    _identified(primary_run, "confirmatory_run_id")
    _identified(primary_analysis, "analysis_id")
    _identified(primary_provider_commitment, "provider_commitment_id")
    _identified(ablation_run, "ablation_run_id")
    _identified(ablation_analysis, "ablation_analysis_id")
    _identified(transport_run, "transport_run_id")
    _identified(transport_analysis, "transport_analysis_id")
    _identified(transport_provider_commitment, "provider_commitment_id")
    _identified(replication_run, "confirmatory_run_id")
    _identified(replication_analysis, "replication_analysis_id")
    _identified(replication_provider_commitment, "provider_commitment_id")
    validate_replication_attestation(
        replication_attestation,
        expected_run_id=replication_run["confirmatory_run_id"],
    )

    freeze_ids = {
        primary_run["freeze_id"],
        ablation_run["freeze_id"],
        transport_run["freeze_id"],
        replication_run["freeze_id"],
        primary_provider_commitment["freeze_id"],
        transport_provider_commitment["freeze_id"],
        replication_provider_commitment["freeze_id"],
    }
    links = {
        "one_frozen_implementation": len(freeze_ids) == 1,
        "primary_analysis_targets_primary_run": primary_analysis[
            "confirmatory_run_id"
        ]
        == primary_run["confirmatory_run_id"],
        "ablation_analysis_targets_primary_and_ablation": ablation_analysis[
            "confirmatory_run_id"
        ]
        == primary_run["confirmatory_run_id"]
        and ablation_analysis["ablation_run_id"] == ablation_run["ablation_run_id"],
        "transport_analysis_targets_transport_run": transport_analysis[
            "transport_run_id"
        ]
        == transport_run["transport_run_id"],
        "replication_analysis_targets_replication_run": replication_analysis[
            "confirmatory_run_id"
        ]
        == replication_run["confirmatory_run_id"],
        "provider_commitments_target_runs": primary_run["provider_commitment_id"]
        == primary_provider_commitment["provider_commitment_id"]
        and transport_run["provider_commitment_id"]
        == transport_provider_commitment["provider_commitment_id"]
        and replication_run["provider_commitment_id"]
        == replication_provider_commitment["provider_commitment_id"],
        "bundle_identities_target_runs": primary_run["public_bundle_id"]
        == primary_provider_commitment["public_bundle_id"]
        and primary_run["private_bundle_id"]
        == primary_provider_commitment["private_bundle_id"]
        and transport_run["public_bundle_id"]
        == transport_provider_commitment["public_bundle_id"]
        and transport_run["private_bundle_id"]
        == transport_provider_commitment["private_bundle_id"]
        and replication_run["public_bundle_id"]
        == replication_provider_commitment["public_bundle_id"]
        and replication_run["private_bundle_id"]
        == replication_provider_commitment["private_bundle_id"],
        "ablation_uses_primary_provider_panel": ablation_run[
            "provider_commitment_id"
        ]
        == primary_provider_commitment["provider_commitment_id"],
        "primary_and_replication_providers_distinct": primary_provider_commitment[
            "provider_ref"
        ]
        != replication_provider_commitment["provider_ref"],
        "primary_and_replication_panels_distinct": primary_provider_commitment[
            "public_bundle_id"
        ]
        != replication_provider_commitment["public_bundle_id"]
        and primary_provider_commitment["private_bundle_id"]
        != replication_provider_commitment["private_bundle_id"],
        "primary_and_replication_runs_distinct": primary_run[
            "confirmatory_run_id"
        ]
        != replication_run["confirmatory_run_id"],
        "replication_laboratory_matches_provider": replication_attestation[
            "replicating_laboratory_ref"
        ]
        == replication_provider_commitment["provider_ref"],
        "all_providers_attest_independence": all(
            value.get("provider_independent_of_authors_and_system") is True
            for value in (
                primary_provider_commitment,
                transport_provider_commitment,
                replication_provider_commitment,
            )
        ),
    }
    evidence_gates = {
        "identity_and_independence_chain_complete": all(links.values()),
        "primary_controlled_superiority_passed": primary_analysis.get(
            "primary_controlled_gates_passed"
        )
        is True,
        "all_five_mechanistic_components_supported": ablation_analysis.get(
            "all_five_components_supported"
        )
        is True,
        "cross_domain_transport_passed": transport_analysis.get(
            "transport_gate_passed"
        )
        is True,
        "independent_replication_result_passed": replication_analysis.get(
            "independent_replication_result_passed"
        )
        is True,
        "independent_replication_execution_attested": True,
    }
    authorized = all(evidence_gates.values())
    body: Dict[str, Any] = {
        "version": NATURE_EVIDENCE_INTEGRATION_VERSION,
        "freeze_id": next(iter(freeze_ids)) if len(freeze_ids) == 1 else None,
        "primary_run_id": primary_run["confirmatory_run_id"],
        "primary_analysis_id": primary_analysis["analysis_id"],
        "ablation_run_id": ablation_run["ablation_run_id"],
        "ablation_analysis_id": ablation_analysis["ablation_analysis_id"],
        "transport_run_id": transport_run["transport_run_id"],
        "transport_analysis_id": transport_analysis["transport_analysis_id"],
        "replication_run_id": replication_run["confirmatory_run_id"],
        "replication_analysis_id": replication_analysis["replication_analysis_id"],
        "replication_attestation_id": replication_attestation[
            "replication_attestation_id"
        ],
        "link_checks": links,
        "evidence_gates": evidence_gates,
        "claim_boundary": (
            "matched-model authority-separated autonomy improves valid root scientific "
            "advances over prompt-equated and free monolithic execution on the frozen "
            "adaptive causal-recovery assay, with component support, cross-domain "
            "non-degradation, and independent replication"
        ),
        "scientific_result_claimed": authorized,
        "nature_central_claim_authorized": authorized,
    }
    return {**body, "nature_evidence_id": content_digest(body)}
