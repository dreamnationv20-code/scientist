from __future__ import annotations

import json
import os
import re
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.autonomy.generated_arm import _conclusion_schema, _parse_conclusion
from scientist.autonomy.generated_worlds import (
    GeneratedResearchConclusion,
    GeneratedWorldAuthority,
    GeneratedWorldInstrument,
    GeneratedWorldPublicPacket,
    GeneratedWorldScore,
    PublicObservation,
    score_generated_world,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    AuthoritativeResearchLedger,
    AuthoritativeStateRuntime,
    AutonomyEventKind,
    ResourceBudget,
    ResourceUsage,
)
from scientist.codex_exchange import (
    CodexCliInvocationError,
    CodexExchangeProtocolError,
    _schema_failure,
)
from scientist.core.artifacts import ArtifactStore, content_digest


PERSISTENT_CODEX_BASELINE_VERSION = "persistent-standalone-codex-baseline-v3"
PERSISTENT_TASK_PROTOCOL_VERSION = "persistent-generated-world-task-v2"
_ACCOUNTING_ACTOR = ActorIdentity(
    "persistent-codex-accounting-runtime-v1", ActorKind.SCIENTIST_POLICY
)


_CLIENT_SOURCE = r'''from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request


parser = argparse.ArgumentParser(description="Query the bounded research instrument.")
parser.add_argument("--context", required=True, help="Comma-separated binary context")
parser.add_argument("--intervention", required=True)
parser.add_argument("--replicate", type=int, default=0)
args = parser.parse_args()
payload = json.dumps(
    {
        "context": [int(item) for item in args.context.split(",")],
        "intervention": args.intervention,
        "replicate": args.replicate,
    }
).encode("utf-8")
request = urllib.request.Request(
    os.environ["SCIENTIST_INSTRUMENT_ENDPOINT"],
    data=payload,
    method="POST",
    headers={
        "Authorization": "Bearer " + os.environ["SCIENTIST_INSTRUMENT_TOKEN"],
        "Content-Type": "application/json",
    },
)
try:
    with urllib.request.urlopen(request, timeout=30) as response:
        print(response.read().decode("utf-8"))
except urllib.error.HTTPError as error:
    print(error.read().decode("utf-8"), file=sys.stderr)
    raise SystemExit(2)
'''


_MCP_SERVER_SOURCE = r'''from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request


endpoint = sys.argv[1]
token = sys.argv[2]


def emit(request_id, result=None, error=None):
    message = {"jsonrpc": "2.0", "id": request_id}
    if error is not None:
        message["error"] = error
    else:
        message["result"] = result
    print(json.dumps(message, separators=(",", ":")), flush=True)


for raw in sys.stdin:
    try:
        request = json.loads(raw)
        method = request.get("method")
        request_id = request.get("id")
        if method == "initialize":
            emit(
                request_id,
                {
                    "protocolVersion": request.get("params", {}).get(
                        "protocolVersion", "2025-06-18"
                    ),
                    "capabilities": {"tools": {}},
                    "serverInfo": {
                        "name": "bounded-research-instrument",
                        "version": "1.0.0",
                    },
                },
            )
        elif method == "notifications/initialized":
            continue
        elif method == "ping":
            emit(request_id, {})
        elif method == "tools/list":
            emit(
                request_id,
                {
                    "tools": [
                        {
                            "name": "intervene",
                            "description": (
                                "Measure one legal generated-world intervention. "
                                "Evaluation contexts are forbidden and attempts are bounded."
                            ),
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "context": {
                                        "type": "array",
                                        "items": {
                                            "type": "integer",
                                            "enum": [0, 1],
                                        },
                                    },
                                    "intervention": {"type": "string"},
                                    "replicate": {
                                        "type": "integer",
                                        "minimum": 0,
                                    },
                                },
                                "required": ["context", "intervention"],
                                "additionalProperties": False,
                            },
                        }
                    ]
                },
            )
        elif method == "tools/call":
            params = request.get("params", {})
            if params.get("name") != "intervene":
                emit(
                    request_id,
                    error={"code": -32602, "message": "unknown instrument tool"},
                )
                continue
            payload = json.dumps(params.get("arguments", {})).encode("utf-8")
            http_request = urllib.request.Request(
                endpoint,
                data=payload,
                method="POST",
                headers={
                    "Authorization": "Bearer " + token,
                    "Content-Type": "application/json",
                },
            )
            try:
                with urllib.request.urlopen(http_request, timeout=30) as response:
                    body = response.read().decode("utf-8")
                emit(
                    request_id,
                    {"content": [{"type": "text", "text": body}]},
                )
            except urllib.error.HTTPError as http_error:
                body = http_error.read().decode("utf-8")
                emit(
                    request_id,
                    {
                        "content": [{"type": "text", "text": body}],
                        "isError": True,
                    },
                )
        elif request_id is not None:
            emit(
                request_id,
                error={"code": -32601, "message": "method not found"},
            )
    except Exception as error:
        if "request_id" in locals() and request_id is not None:
            emit(
                request_id,
                error={"code": -32603, "message": str(error)},
            )
'''


@dataclass(frozen=True)
class PersistentToolRecord:
    sequence: int
    query: Mapping[str, Any]
    query_id: str
    succeeded: bool
    observation: Optional[PublicObservation]
    failure: Optional[str]

    @property
    def output_id(self) -> str:
        if self.observation is not None:
            return self.observation.observation_id
        return content_digest(
            {"query_id": self.query_id, "failure": self.failure, "sequence": self.sequence}
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "sequence": self.sequence,
            "query": dict(self.query),
            "query_id": self.query_id,
            "succeeded": self.succeeded,
            "observation": (
                None if self.observation is None else self.observation.as_dict()
            ),
            "failure": self.failure,
            "output_id": self.output_id,
        }


@dataclass(frozen=True)
class PersistentCodexAgentResponse:
    response: Mapping[str, Any]
    model_ref: str
    reported_tokens_used: int
    wall_seconds: float
    prompt_digest: str
    response_digest: str
    transcript_id: str
    tool_records: Tuple[PersistentToolRecord, ...]
    project_read_denial_preflight_passed: bool
    project_deny_root: str
    sandbox: str


@dataclass(frozen=True)
class PersistentCodexBaselineResult:
    episode_id: str
    conclusion: GeneratedResearchConclusion
    score: GeneratedWorldScore
    authority_state_id: str
    event_count: int
    model_calls: int
    model_tokens: int
    tool_calls: int
    successful_tool_calls: int
    human_interventions: int
    out_of_band_interventions: int
    host_authorization_audited: bool
    model_ref: str
    task_protocol_id: str
    budget: ResourceBudget
    project_read_denial_preflight_passed: bool
    project_deny_root: str
    transcript_id: str

    @property
    def execution_autonomous(self) -> bool:
        return all(
            (
                self.host_authorization_audited,
                self.human_interventions == 0,
                self.out_of_band_interventions == 0,
            )
        )

    @property
    def sequester_audited(self) -> bool:
        return bool(self.project_read_denial_preflight_passed)

    @property
    def result_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": PERSISTENT_CODEX_BASELINE_VERSION,
            "arm_kind": "persistent_standalone_codex",
            "scientific_decision_source": "codex_model_output",
            "independent_authority_before_hidden_score": False,
            "episode_id": self.episode_id,
            "conclusion": self.conclusion.as_dict(),
            "score": self.score.as_dict(),
            "authority_state_id": self.authority_state_id,
            "event_count": self.event_count,
            "model_calls": self.model_calls,
            "model_tokens": self.model_tokens,
            "tool_calls": self.tool_calls,
            "successful_tool_calls": self.successful_tool_calls,
            "human_interventions": self.human_interventions,
            "out_of_band_interventions": self.out_of_band_interventions,
            "host_authorization_audited": self.host_authorization_audited,
            "execution_autonomous": self.execution_autonomous,
            "model_ref": self.model_ref,
            "task_protocol_id": self.task_protocol_id,
            "budget": self.budget.as_dict(),
            "project_read_denial_preflight_passed": (
                self.project_read_denial_preflight_passed
            ),
            "project_deny_root": self.project_deny_root,
            "sequester_audited": self.sequester_audited,
            "transcript_id": self.transcript_id,
        }
        if include_id:
            value["result_id"] = self.result_id
        return value


class _InstrumentService:
    def __init__(
        self,
        instrument: GeneratedWorldInstrument,
        token: str,
        maximum_attempts: int,
    ) -> None:
        self.instrument = instrument
        self.token = token
        self.maximum_attempts = maximum_attempts
        self.records = []
        self.lock = threading.Lock()

    def handle(self, authorization: str, payload: Any) -> Tuple[int, Mapping[str, Any]]:
        with self.lock:
            if authorization != "Bearer " + self.token:
                return 403, {"error": "invalid instrument capability"}
            if len(self.records) >= self.maximum_attempts:
                return 429, {"error": "instrument attempt budget exhausted"}
            sequence = len(self.records) + 1
            query = dict(payload) if isinstance(payload, dict) else {"payload": payload}
            query_id = content_digest({"sequence": sequence, "query": query})
            try:
                if not isinstance(payload, dict):
                    raise ValueError("instrument query must be a JSON object")
                observation = self.instrument.intervene(
                    payload["context"],
                    str(payload["intervention"]),
                    replicate=int(payload.get("replicate", 0)),
                )
                record = PersistentToolRecord(
                    sequence=sequence,
                    query=query,
                    query_id=query_id,
                    succeeded=True,
                    observation=observation,
                    failure=None,
                )
                self.records.append(record)
                return 200, observation.as_dict()
            except (KeyError, TypeError, ValueError) as error:
                record = PersistentToolRecord(
                    sequence=sequence,
                    query=query,
                    query_id=query_id,
                    succeeded=False,
                    observation=None,
                    failure=str(error),
                )
                self.records.append(record)
                return 400, {"error": str(error), "query_id": query_id}


def _handler(service: _InstrumentService):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:  # noqa: N802
            if self.path != "/intervene":
                self.send_error(404)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 16_384:
                    raise ValueError("invalid request size")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
            except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as error:
                status, body = 400, {"error": str(error)}
            else:
                status, body = service.handle(
                    self.headers.get("Authorization", ""), payload
                )
            encoded = json.dumps(body, sort_keys=True).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)

        def log_message(self, format: str, *args: Any) -> None:
            return

    return Handler


def _task_prompt(public: GeneratedWorldPublicPacket) -> str:
    public_json = json.dumps(public.as_dict(), indent=2, sort_keys=True)
    return (
        "You are the standalone persistent Codex research agent. Resolve the public "
        "research question within the stated instrument budget. You control which "
        "legal interventions to run, in what order, and when to stop. The only research "
        "instrument is the research_instrument.intervene tool. Call it with a binary "
        "context array, an intervention name, and an optional non-negative replicate. "
        "Use contexts only from instrument_contexts and never query evaluation_contexts. "
        "The tool returns an observation_id that you may cite. Starting observation "
        "IDs may also be cited. Do not inspect the filesystem or attempt to discover "
        "hidden generator or scoring authority. Return exactly "
        "one final JSON object matching the supplied schema. Select one listed hypothesis, "
        "choose promote only for a supported effect or kill for the supported null, and "
        "predict the best intervention for every evaluation context.\n\nPUBLIC PACKET:\n%s"
        % public_json
    )


PERSISTENT_TASK_PROTOCOL_ID = content_digest(
    {
        "version": PERSISTENT_TASK_PROTOCOL_VERSION,
        "tool_interface": "research_instrument.intervene(context, intervention, replicate)",
        "response_schema": _conclusion_schema(),
    }
)


@dataclass(frozen=True)
class PersistentCodexAgentWorker:
    artifact_store: ArtifactStore
    project_deny_root: Path
    model: str = "gpt-5.6-sol"
    reasoning_effort: str = "medium"
    timeout_seconds: float = 900.0
    codex_binary: str = "codex"
    sandbox_exec_binary: str = "/usr/bin/sandbox-exec"

    def __post_init__(self) -> None:
        if self.reasoning_effort not in {"low", "medium", "high", "xhigh"}:
            raise ValueError("unsupported Codex reasoning effort")
        if self.timeout_seconds <= 0:
            raise ValueError("Codex timeout must be positive")
        object.__setattr__(
            self, "project_deny_root", Path(self.project_deny_root).resolve()
        )

    def run(
        self,
        public: GeneratedWorldPublicPacket,
        instrument: GeneratedWorldInstrument,
        *,
        maximum_tool_attempts: int,
    ) -> PersistentCodexAgentResponse:
        binary = shutil.which(self.codex_binary)
        if binary is None:
            raise CodexCliInvocationError("Codex CLI is unavailable")
        token = secrets.token_hex(32)
        service = _InstrumentService(instrument, token, maximum_tool_attempts)
        server = HTTPServer(("127.0.0.1", 0), _handler(service))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory(
                prefix="persistent-codex-agent-", dir="/private/tmp"
            ) as temporary:
                work = Path(temporary)
                mcp_path = work / "instrument_mcp.py"
                mcp_path.write_text(_MCP_SERVER_SOURCE, encoding="utf-8")
                schema_path = work / "conclusion-schema.json"
                schema_path.write_text(
                    json.dumps(_conclusion_schema(), sort_keys=True),
                    encoding="utf-8",
                )
                output_path = work / "final-response.json"
                profile = "(version 1)(allow default)(deny file-read* (subpath %s))" % json.dumps(
                    str(self.project_deny_root)
                )
                preflight = subprocess.run(
                    (
                        self.sandbox_exec_binary,
                        "-p",
                        profile,
                        "/bin/test",
                        "!",
                        "-r",
                        str(self.project_deny_root / "src" / "scientist" / "autonomy" / "generated_worlds.py"),
                    ),
                    cwd=work,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                preflight_passed = preflight.returncode == 0
                if not preflight_passed:
                    raise CodexCliInvocationError(
                        "project-read denial preflight failed: %s"
                        % (preflight.stderr or preflight.stdout)[-1000:]
                    )
                command = [
                    self.sandbox_exec_binary,
                    "-p",
                    profile,
                    binary,
                    "exec",
                    "--ephemeral",
                    "--skip-git-repo-check",
                    "--ignore-user-config",
                    "--ignore-rules",
                    "-c",
                    'model_reasoning_effort="%s"' % self.reasoning_effort,
                    "-c",
                    "sandbox_workspace_write.network_access=true",
                    "-c",
                    'mcp_servers.research_instrument.command="python3"',
                    "-c",
                    "mcp_servers.research_instrument.args=%s"
                    % json.dumps(
                        [
                            str(mcp_path),
                            "http://127.0.0.1:%d/intervene" % server.server_port,
                            token,
                        ]
                    ),
                    "-c",
                    "mcp_servers.research_instrument.startup_timeout_sec=10",
                    "-c",
                    "mcp_servers.research_instrument.required=true",
                    "-c",
                    'mcp_servers.research_instrument.enabled_tools=["intervene"]',
                    "-c",
                    'mcp_servers.research_instrument.default_tools_approval_mode="approve"',
                    "-c",
                    'mcp_servers.research_instrument.tools.intervene.approval_mode="approve"',
                    "--sandbox",
                    "workspace-write",
                    "-C",
                    str(work),
                    "--output-schema",
                    str(schema_path),
                    "-o",
                    str(output_path),
                    "--model",
                    self.model,
                    "-",
                ]
                environment = dict(os.environ)
                environment.pop("OPENAI_API_KEY", None)
                environment.pop("OPENAI_KEY", None)
                environment["SCIENTIST_INSTRUMENT_ENDPOINT"] = (
                    "http://127.0.0.1:%d/intervene" % server.server_port
                )
                environment["SCIENTIST_INSTRUMENT_TOKEN"] = token
                prompt = _task_prompt(public)
                started = time.perf_counter()
                completed = subprocess.run(
                    command,
                    input=prompt,
                    text=True,
                    capture_output=True,
                    timeout=self.timeout_seconds,
                    check=False,
                    cwd=work,
                    env=environment,
                )
                wall_seconds = time.perf_counter() - started
                if completed.returncode != 0:
                    diagnostic = (completed.stderr or completed.stdout)[-4000:]
                    raise CodexCliInvocationError(
                        "persistent Codex exited %d: %s"
                        % (completed.returncode, diagnostic.strip())
                    )
                try:
                    response = json.loads(output_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError) as error:
                    raise CodexCliInvocationError(
                        "persistent Codex did not emit structured JSON"
                    ) from error
                failure = _schema_failure(response, _conclusion_schema(), "response")
                if failure is not None:
                    raise CodexExchangeProtocolError(failure)
                transcript = "\n".join(
                    (completed.stdout or "", completed.stderr or "")
                )
                tokens_match = re.search(
                    r"tokens used\s*[\r\n]+([0-9,]+)",
                    transcript,
                    flags=re.IGNORECASE,
                )
                if tokens_match is None:
                    raise CodexExchangeProtocolError(
                        "persistent baseline requires exact reported token use"
                    )
                reported_tokens = int(tokens_match.group(1).replace(",", ""))
                transcript_id = self.artifact_store.put(
                    "persistent_codex_transcript",
                    {
                        "stdout": completed.stdout or "",
                        "stderr": completed.stderr or "",
                    },
                )
                return PersistentCodexAgentResponse(
                    response=response,
                    model_ref=self.model,
                    reported_tokens_used=reported_tokens,
                    wall_seconds=wall_seconds,
                    prompt_digest=content_digest(prompt),
                    response_digest=content_digest(response),
                    transcript_id=transcript_id,
                    tool_records=tuple(service.records),
                    project_read_denial_preflight_passed=preflight_passed,
                    project_deny_root=str(self.project_deny_root),
                    sandbox="macos_project_read_denial+codex_workspace_write",
                )
        except subprocess.TimeoutExpired as error:
            raise CodexCliInvocationError(
                "persistent Codex exceeded its %.1f second timeout"
                % self.timeout_seconds
            ) from error
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5.0)


def run_persistent_codex_development_episode(
    public: GeneratedWorldPublicPacket,
    authority: GeneratedWorldAuthority,
    *,
    output_dir: Path,
    worker: PersistentCodexAgentWorker,
    budget: ResourceBudget = ResourceBudget(50_000, 4, 18, 900.0, 1.0),
    host_authorization_audited: bool = False,
) -> PersistentCodexBaselineResult:
    if not public.development_only:
        raise ValueError("development runner cannot open a confirmatory episode")
    output = Path(output_dir)
    store = ArtifactStore(output / "artifacts")
    ledger = AuthoritativeResearchLedger(
        run_id="persistent-standalone-codex:%s" % public.episode_id,
        objective_id=content_digest(public.research_question),
        budget=budget,
        controller=_ACCOUNTING_ACTOR,
        artifact_store=store,
    )
    runtime = AuthoritativeStateRuntime(
        ledger, output / "authority-checkpoint.json"
    )
    runtime.save_checkpoint()
    action_id = content_digest(
        {
            "version": PERSISTENT_CODEX_BASELINE_VERSION,
            "episode_id": public.episode_id,
            "action": "persistent_research_episode",
        }
    )
    ledger.append(
        AutonomyEventKind.ACTION_SELECTED,
        _ACCOUNTING_ACTOR,
        AuthorityScope.GOVERN,
        action_id=action_id,
        payload={"action": "persistent_research_episode", "accounting_only": True},
    )
    runtime.save_checkpoint()
    instrument = GeneratedWorldInstrument(public, authority)
    agent = worker.run(
        public,
        instrument,
        maximum_tool_attempts=min(
            public.maximum_instrument_calls, budget.maximum_tool_calls
        ),
    )
    for record in agent.tool_records:
        ledger.append(
            AutonomyEventKind.TOOL_RESULT_RECORDED,
            ActorIdentity("persistent-instrument-service-v1", ActorKind.TOOL_RUNTIME),
            AuthorityScope.MEASURE,
            action_id=action_id,
            payload=record.as_dict(),
            input_artifact_ids=(record.query_id,),
            output_artifact_ids=(record.output_id,),
            resource_delta=ResourceUsage(tool_calls=1),
        )
        runtime.save_checkpoint()
    ledger.append(
        AutonomyEventKind.MODEL_EXCHANGE_RECORDED,
        ActorIdentity(
            "persistent-standalone-codex:%s" % agent.model_ref,
            ActorKind.PROPOSAL_MODEL,
        ),
        AuthorityScope.PROPOSE,
        action_id=action_id,
        payload={
            "operation": "persistent_generated_world_research",
            "task_protocol_id": PERSISTENT_TASK_PROTOCOL_ID,
            "transcript_id": agent.transcript_id,
            "sandbox": agent.sandbox,
        },
        input_artifact_ids=(agent.prompt_digest,),
        output_artifact_ids=(agent.response_digest,),
        resource_delta=ResourceUsage(
            model_output_tokens=agent.reported_tokens_used,
            model_calls=1,
            wall_seconds=agent.wall_seconds,
        ),
    )
    runtime.save_checkpoint()
    conclusion = _parse_conclusion(agent.response, public)
    evidence_ids = tuple(
        item.observation_id for item in public.starting_observations
    ) + tuple(
        record.observation.observation_id
        for record in agent.tool_records
        if record.observation is not None
    )
    ledger.append(
        AutonomyEventKind.PROPOSAL_RECORDED,
        ActorIdentity(
            "persistent-standalone-codex:%s" % agent.model_ref,
            ActorKind.PROPOSAL_MODEL,
        ),
        AuthorityScope.PROPOSE,
        action_id=action_id,
        payload={
            "terminal_model_conclusion": conclusion.as_dict(),
            "independent_authority_applied": False,
        },
        input_artifact_ids=evidence_ids,
        output_artifact_ids=(conclusion.conclusion_id,),
    )
    runtime.save_checkpoint()
    ledger.append(
        AutonomyEventKind.ACTION_COMPLETED,
        _ACCOUNTING_ACTOR,
        AuthorityScope.GOVERN,
        action_id=action_id,
        payload={"completed": True},
    )
    runtime.save_checkpoint()
    score_action = content_digest(
        {
            "version": PERSISTENT_CODEX_BASELINE_VERSION,
            "episode_id": public.episode_id,
            "action": "post_terminal_hidden_score",
        }
    )
    ledger.append(
        AutonomyEventKind.ACTION_SELECTED,
        _ACCOUNTING_ACTOR,
        AuthorityScope.GOVERN,
        action_id=score_action,
        payload={"action": "post_terminal_hidden_score", "accounting_only": True},
    )
    runtime.save_checkpoint()
    score = score_generated_world(
        public,
        authority,
        conclusion,
        accessible_evidence_ids=evidence_ids,
        trace_complete=(
            ledger.verify_chain()
            and host_authorization_audited
            and agent.project_read_denial_preflight_passed
        ),
        within_budget=budget.admits(ledger.state.usage),
    )
    score_id = content_digest(score.as_dict())
    ledger.append(
        AutonomyEventKind.VERIFICATION_RECORDED,
        ActorIdentity(authority.scorer_ref, ActorKind.DETERMINISTIC_VALIDATOR),
        AuthorityScope.VERIFY,
        action_id=score_action,
        payload={
            "score": score.as_dict(),
            "authority_id": authority.authority_id,
            "post_terminal_scoring_only": True,
        },
        input_artifact_ids=(conclusion.conclusion_id, authority.authority_id),
        output_artifact_ids=(score_id,),
    )
    runtime.save_checkpoint()
    ledger.append(
        AutonomyEventKind.ACTION_COMPLETED,
        _ACCOUNTING_ACTOR,
        AuthorityScope.GOVERN,
        action_id=score_action,
        payload={"completed": True},
    )
    runtime.save_checkpoint()
    ledger.append(
        AutonomyEventKind.RUN_TERMINATED,
        _ACCOUNTING_ACTOR,
        AuthorityScope.GOVERN,
        payload={"root_advance": score.root_advance},
    )
    runtime.save_checkpoint()
    if not ledger.verify_chain():
        raise ValueError("persistent Codex produced an invalid provenance chain")
    state = ledger.state
    result = PersistentCodexBaselineResult(
        episode_id=public.episode_id,
        conclusion=conclusion,
        score=score,
        authority_state_id=state.state_id,
        event_count=len(ledger.events),
        model_calls=state.usage.model_calls,
        model_tokens=state.usage.total_model_tokens,
        tool_calls=state.usage.tool_calls,
        successful_tool_calls=sum(record.succeeded for record in agent.tool_records),
        human_interventions=state.human_intervention_count,
        out_of_band_interventions=state.out_of_band_intervention_count,
        host_authorization_audited=host_authorization_audited,
        model_ref=agent.model_ref,
        task_protocol_id=PERSISTENT_TASK_PROTOCOL_ID,
        budget=budget,
        project_read_denial_preflight_passed=(
            agent.project_read_denial_preflight_passed
        ),
        project_deny_root=agent.project_deny_root,
        transcript_id=agent.transcript_id,
    )
    store.write_manifest("persistent-codex-baseline-result-v3", result.as_dict())
    store.write_manifest(
        "persistent-codex-tool-trace-v3",
        {
            "version": PERSISTENT_CODEX_BASELINE_VERSION,
            "episode_id": public.episode_id,
            "records": [item.as_dict() for item in agent.tool_records],
            "trace_id": content_digest(
                [item.as_dict() for item in agent.tool_records]
            ),
        },
    )
    return result
