from __future__ import annotations

import json
import queue
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Protocol, Sequence, Tuple

from scientist.core.artifacts import content_digest


PETRI_EXTERNAL_ADAPTER_VERSION = "scientist-petri-external-adapter-v1"
PETRI_MCP_PROTOCOL_VERSION = "2025-06-18"
_MODELS = {"origin", "swarm", "morph", "market", "social"}
_TIERS = {"L1", "L2", "L3"}


def _plain_mapping(value: Mapping[str, Any]) -> Dict[str, Any]:
    return {str(key): item for key, item in value.items()}


@dataclass(frozen=True)
class PetriPublicTask:
    task_id: str
    model: str
    control: Mapping[str, Any]
    metric: str
    replicates: int
    tool_budget: int
    tier: str
    candidate_params: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.task_id or self.model not in _MODELS or not self.metric:
            raise ValueError("Petri public task identity is invalid")
        if self.tier not in _TIERS:
            raise ValueError("Petri task tier must be L1, L2, or L3")
        if self.replicates <= 0 or self.tool_budget <= 0:
            raise ValueError("Petri task resource limits must be positive")
        if len(self.candidate_params) < (4 if self.tier == "L3" else 3):
            raise ValueError("Petri task has too few candidate parameters")
        if len(self.candidate_params) != len(set(self.candidate_params)):
            raise ValueError("Petri candidate parameters must be unique")
        if any(not value for value in self.candidate_params):
            raise ValueError("Petri candidate parameter cannot be empty")

    @property
    def public_task_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": PETRI_EXTERNAL_ADAPTER_VERSION,
            "task_id": self.task_id,
            "model": self.model,
            "control": _plain_mapping(self.control),
            "metric": self.metric,
            "replicates": self.replicates,
            "tool_budget": self.tool_budget,
            "tier": self.tier,
            "candidate_params": list(self.candidate_params),
        }
        if include_id:
            value["public_task_id"] = self.public_task_id
        return value


@dataclass(frozen=True)
class PetriTaskAuthority:
    public_task_id: str
    seed_base: int
    parameter: str
    value: Any
    direction: str
    magnitude: Optional[str] = None
    parameter_2: Optional[str] = None
    value_2: Any = None
    interaction: Optional[str] = None
    source_ref: str = ""
    development_only: bool = True

    def __post_init__(self) -> None:
        if len(self.public_task_id) != 64 or not self.parameter:
            raise ValueError("Petri authority identity is invalid")
        if isinstance(self.seed_base, bool) or int(self.seed_base) != self.seed_base:
            raise ValueError("Petri authority seed must be an integer")
        if self.direction not in {"up", "down"}:
            raise ValueError("Petri direction must be up or down")
        if self.magnitude is not None and self.magnitude not in {
            "small",
            "medium",
            "large",
        }:
            raise ValueError("Petri magnitude is invalid")
        pair_values = (self.parameter_2, self.interaction)
        if (pair_values[0] is None) != (pair_values[1] is None):
            raise ValueError("Petri interaction authority must be complete")
        if self.parameter_2 is not None:
            if self.parameter_2 == self.parameter:
                raise ValueError("Petri interaction parameters must differ")
            if self.interaction not in {"positive", "negative"}:
                raise ValueError("Petri interaction sign is invalid")
        if not self.source_ref:
            raise ValueError("Petri authority source reference is required")

    @property
    def authority_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def hidden_config(self, public: PetriPublicTask) -> Dict[str, Any]:
        if public.public_task_id != self.public_task_id:
            raise ValueError("Petri public task and authority do not match")
        result = _plain_mapping(public.control)
        result[self.parameter] = self.value
        if self.parameter_2 is not None:
            result[self.parameter_2] = self.value_2
        return result

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": PETRI_EXTERNAL_ADAPTER_VERSION,
            "public_task_id": self.public_task_id,
            "seed_base": self.seed_base,
            "parameter": self.parameter,
            "value": self.value,
            "direction": self.direction,
            "magnitude": self.magnitude,
            "parameter_2": self.parameter_2,
            "value_2": self.value_2,
            "interaction": self.interaction,
            "source_ref": self.source_ref,
            "development_only": self.development_only,
        }
        if include_id:
            value["authority_id"] = self.authority_id
        return value


def load_released_petri_episode(
    episode: Mapping[str, Any], *, source_ref: str
) -> Tuple[PetriPublicTask, PetriTaskAuthority]:
    """Split a released Petri episode into public and sealed development data."""

    task = episode.get("task")
    if not isinstance(task, Mapping):
        raise ValueError("released Petri episode lacks a task")
    truth = task.get("truth")
    if not isinstance(truth, Mapping):
        raise ValueError("released Petri task lacks truth")
    tier = str(task.get("tier", "L1"))
    public = PetriPublicTask(
        task_id=str(task["id"]),
        model=str(task["model"]),
        control=_plain_mapping(task.get("control", {})),
        metric=str(task["metric"]),
        replicates=int(task["replicates"]),
        tool_budget=int(task["budget"]),
        tier=tier,
        candidate_params=tuple(str(value) for value in task["candidateParams"]),
    )
    authority = PetriTaskAuthority(
        public_task_id=public.public_task_id,
        seed_base=int(task["seed"]),
        parameter=str(truth["param"]),
        value=truth["value"],
        direction=str(truth["effectOnMetric"]),
        magnitude=(None if truth.get("magnitude") is None else str(truth["magnitude"])),
        parameter_2=(None if truth.get("param2") is None else str(truth["param2"])),
        value_2=truth.get("value2"),
        interaction=(
            None if truth.get("interaction") is None else str(truth["interaction"])
        ),
        source_ref=source_ref,
        development_only=True,
    )
    truth_parameters = {authority.parameter}
    if authority.parameter_2 is not None:
        truth_parameters.add(authority.parameter_2)
    if not truth_parameters.issubset(set(public.candidate_params)):
        raise ValueError("Petri truth is outside the public candidate set")
    if (tier == "L3") != (authority.parameter_2 is not None):
        raise ValueError("Petri tier and interaction authority disagree")
    return public, authority


class PetriToolCaller(Protocol):
    def call_tool(self, name: str, arguments: Mapping[str, Any]) -> Mapping[str, Any]:
        ...


class JsonLineMcpError(RuntimeError):
    pass


class JsonLineMcpClient:
    """Minimal sequential JSON-lines MCP client with bounded response waits."""

    def __init__(
        self,
        command: Sequence[str],
        *,
        cwd: Optional[Path] = None,
        timeout_seconds: float = 120.0,
    ) -> None:
        if not command:
            raise ValueError("MCP command cannot be empty")
        if timeout_seconds <= 0:
            raise ValueError("MCP timeout must be positive")
        self.command = tuple(str(value) for value in command)
        self.cwd = None if cwd is None else Path(cwd)
        self.timeout_seconds = float(timeout_seconds)
        self._process: Optional[subprocess.Popen[str]] = None
        self._responses: "queue.Queue[object]" = queue.Queue()
        self._stderr: list[str] = []
        self._request_id = 0
        self.server_info: Mapping[str, Any] = {}

    def __enter__(self) -> "JsonLineMcpClient":
        self.start()
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()

    @property
    def stderr_text(self) -> str:
        return "".join(self._stderr)

    def start(self) -> None:
        if self._process is not None:
            raise RuntimeError("MCP client is already started")
        self._process = subprocess.Popen(
            self.command,
            cwd=None if self.cwd is None else str(self.cwd),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        assert self._process.stdout is not None
        assert self._process.stderr is not None
        threading.Thread(
            target=self._read_stdout,
            args=(self._process.stdout,),
            daemon=True,
        ).start()
        threading.Thread(
            target=self._read_stderr,
            args=(self._process.stderr,),
            daemon=True,
        ).start()
        initialized = self._request(
            "initialize",
            {
                "protocolVersion": PETRI_MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {
                    "name": "scientist-petri-external-adapter",
                    "version": PETRI_EXTERNAL_ADAPTER_VERSION,
                },
            },
        )
        self.server_info = _plain_mapping(initialized.get("serverInfo", {}))
        self._notify("notifications/initialized", {})

    def _read_stdout(self, stream: Any) -> None:
        try:
            for line in stream:
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    self._responses.put(json.loads(stripped))
                except json.JSONDecodeError as error:
                    self._responses.put(
                        JsonLineMcpError(f"MCP returned invalid JSON: {error}")
                    )
        finally:
            self._responses.put(JsonLineMcpError("MCP stdout closed"))

    def _read_stderr(self, stream: Any) -> None:
        for line in stream:
            self._stderr.append(line)

    def _write(self, payload: Mapping[str, Any]) -> None:
        if self._process is None or self._process.stdin is None:
            raise JsonLineMcpError("MCP client is not running")
        if self._process.poll() is not None:
            raise JsonLineMcpError(
                f"MCP process exited with {self._process.returncode}: {self.stderr_text}"
            )
        self._process.stdin.write(json.dumps(payload, separators=(",", ":")) + "\n")
        self._process.stdin.flush()

    def _notify(self, method: str, params: Mapping[str, Any]) -> None:
        self._write({"jsonrpc": "2.0", "method": method, "params": dict(params)})

    def _request(self, method: str, params: Mapping[str, Any]) -> Mapping[str, Any]:
        self._request_id += 1
        request_id = self._request_id
        self._write(
            {
                "jsonrpc": "2.0",
                "id": request_id,
                "method": method,
                "params": dict(params),
            }
        )
        deadline = time.monotonic() + self.timeout_seconds
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise JsonLineMcpError(f"MCP request {method} timed out")
            try:
                response = self._responses.get(timeout=remaining)
            except queue.Empty as error:
                raise JsonLineMcpError(f"MCP request {method} timed out") from error
            if isinstance(response, Exception):
                raise response
            if not isinstance(response, Mapping):
                raise JsonLineMcpError("MCP response is not an object")
            if response.get("id") != request_id:
                continue
            if response.get("error") is not None:
                raise JsonLineMcpError(
                    f"MCP request {method} failed: {response['error']}"
                )
            result = response.get("result")
            if not isinstance(result, Mapping):
                raise JsonLineMcpError("MCP response result is not an object")
            return result

    def list_tools(self) -> Tuple[Mapping[str, Any], ...]:
        result = self._request("tools/list", {})
        tools = result.get("tools")
        if not isinstance(tools, list) or not all(
            isinstance(value, Mapping) for value in tools
        ):
            raise JsonLineMcpError("MCP tool list is invalid")
        return tuple(tools)

    def call_tool(self, name: str, arguments: Mapping[str, Any]) -> Mapping[str, Any]:
        result = self._request(
            "tools/call", {"name": str(name), "arguments": dict(arguments)}
        )
        if result.get("isError"):
            raise JsonLineMcpError(f"MCP tool {name} returned an error: {result}")
        structured = result.get("structuredContent")
        if isinstance(structured, Mapping):
            return structured
        content = result.get("content")
        if not isinstance(content, list) or not content:
            raise JsonLineMcpError(f"MCP tool {name} returned no content")
        text = content[0].get("text") if isinstance(content[0], Mapping) else None
        if not isinstance(text, str):
            raise JsonLineMcpError(f"MCP tool {name} returned no text content")
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as error:
            # petri-labs-mcp prepends a one-line human summary to its JSON
            # report. Preserve strict JSON parsing while accepting that
            # documented wire shape.
            json_start = text.find("{")
            if json_start < 0:
                raise JsonLineMcpError(
                    f"MCP tool {name} returned non-JSON text"
                ) from error
            try:
                parsed = json.loads(text[json_start:])
            except json.JSONDecodeError as nested_error:
                raise JsonLineMcpError(
                    f"MCP tool {name} returned non-JSON text"
                ) from nested_error
        if not isinstance(parsed, Mapping):
            raise JsonLineMcpError(f"MCP tool {name} returned a non-object")
        return parsed

    def close(self) -> None:
        process = self._process
        self._process = None
        if process is None:
            return
        if process.stdin is not None:
            process.stdin.close()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)


@dataclass(frozen=True)
class PetriObservation:
    sequence: int
    kind: str
    metric: str
    report: Mapping[str, Any]
    elapsed_seconds: float

    @property
    def observation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": PETRI_EXTERNAL_ADAPTER_VERSION,
            "sequence": self.sequence,
            "kind": self.kind,
            "metric": self.metric,
            "report": dict(self.report),
            "elapsed_seconds": self.elapsed_seconds,
        }
        if include_id:
            value["observation_id"] = self.observation_id
        return value


class PetriMcpInstrument:
    """Budgeted blind wrapper around the public Petri simulation MCP server."""

    def __init__(
        self,
        public: PetriPublicTask,
        authority: PetriTaskAuthority,
        caller: PetriToolCaller,
    ) -> None:
        if public.public_task_id != authority.public_task_id:
            raise ValueError("Petri task and authority do not match")
        self.public = public
        self._authority = authority
        self._caller = caller
        self._attempts = 0
        self._observations: list[PetriObservation] = []

    @property
    def calls_used(self) -> int:
        return self._attempts

    @property
    def observations(self) -> Tuple[PetriObservation, ...]:
        return tuple(self._observations)

    def _config(self, overrides: Mapping[str, Any]) -> Dict[str, Any]:
        result = _plain_mapping(self.public.control)
        for key, value in overrides.items():
            key = str(key)
            if key not in self.public.candidate_params:
                raise ValueError(f"parameter {key} is outside the public candidate set")
            result[key] = value
        return result

    def _run(
        self,
        *,
        kind: str,
        control: Mapping[str, Any],
        treatment: Mapping[str, Any],
    ) -> PetriObservation:
        if self._attempts >= self.public.tool_budget:
            raise RuntimeError("Petri task tool budget exhausted")
        self._attempts += 1
        started = time.monotonic()
        report = self._caller.call_tool(
            "run_experiment",
            {
                "model": self.public.model,
                "control": dict(control),
                "treatment": dict(treatment),
                "primaryMetric": self.public.metric,
                "replicates": self.public.replicates,
                "seedBase": self._authority.seed_base,
            },
        )
        elapsed = time.monotonic() - started
        observation = PetriObservation(
            sequence=self._attempts,
            kind=kind,
            metric=self.public.metric,
            report=report,
            elapsed_seconds=elapsed,
        )
        self._observations.append(observation)
        return observation

    def experiment(
        self, config_a: Mapping[str, Any], config_b: Mapping[str, Any]
    ) -> PetriObservation:
        return self._run(
            kind="experiment",
            control=self._config(config_a),
            treatment=self._config(config_b),
        )

    def probe(self, guess: Mapping[str, Any]) -> PetriObservation:
        return self._run(
            kind="probe",
            control=self._config(guess),
            treatment=self._authority.hidden_config(self.public),
        )
