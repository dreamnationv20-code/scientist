from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_three_arm_v1 import ARM_KINDS, ARM_SCIENTIST
from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


POSTEXTENSION_REGRESSION_ADJUDICATION_VERSION = "adaptive-postextension-regression-adjudication-v2"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has invalid {key}")
    return value


def adjudicate_postextension_regression(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    commitment = _identified(
        root
        / "runs/autonomy_closure_v1/postextension_regression_commitment_v1/artifacts/manifests/postextension-regression-commitment-v1.json",
        "regression_commitment_id",
    )
    panel = _identified(
        root
        / "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1/artifacts/manifests/adaptive-causal-postextension-regression-v1.json",
        "panel_id",
    )
    failed_adjudication = _identified(
        root
        / "runs/autonomy_closure_v1/postextension_regression_adjudication_v1/artifacts/manifests/postextension-regression-adjudication-v1.json",
        "regression_adjudication_id",
    )
    if not (
        failed_adjudication.get("all_checks_passed") is False
        and failed_adjudication.get("panel_id") == panel["panel_id"]
        and failed_adjudication.get("regression_commitment_id")
        == commitment["regression_commitment_id"]
    ):
        raise ValueError("failed first adjudication is not the expected immutable record")
    doc = root / (
        "docs/autonomous-scientist-postextension-adjudicator-correction-2026-09-09.md"
    )
    results = panel["results"]
    failures = panel["failures"]
    result_identities = all(
        value.get("result_id")
        == content_digest(
            {key: item for key, item in value.items() if key != "result_id"}
        )
        for value in results.values()
    )
    token_accounts = all(
        value.get("token_usage", {}).get("total_tokens")
        == value.get("token_usage", {}).get("input_tokens", -1)
        + value.get("token_usage", {}).get("output_tokens", -1)
        for value in results.values()
    )
    successes = {
        arm: sum(
            int(value["score"]["valid_root_advance"])
            for key, value in results.items()
            if key.split("|", 1)[1] == arm
        )
        for arm in ARM_KINDS
    }
    false_promotions = sum(
        int(value["score"]["false_promotion"]) for value in results.values()
    )
    checks = {
        "commitment_precedes_and_identifies_outcomes": commitment["run_id"]
        == "adaptive-causal-postextension-regression-v1",
        "exact_committed_task_specifications": sorted(
            panel["task_specs"], key=lambda item: item["task_index"]
        )
        == sorted(commitment["task_specs"], key=lambda item: item["task_index"]),
        "committed_execution_source_hashes_match": all(
            panel["source_hashes"].get(path) == digest
            for path, digest in commitment["source_hashes"].items()
        ),
        "all_18_arm_slots_terminal": len(results) + len(failures) == 18
        and panel["matching_checks"]["all_arm_slots_terminal"],
        "zero_runner_exceptions": not failures
        and panel["matching_checks"]["all_arms_completed_without_runner_exception"],
        "all_matching_checks": all(panel["matching_checks"].values()),
        "result_identities_and_token_accounts_exact": result_identities
        and token_accounts,
        "zero_false_promotions": false_promotions == 0,
        "each_arm_has_at_least_one_valid_advance": all(
            count >= 1 for count in successes.values()
        ),
        "scientist_has_at_least_four_valid_advances": successes[ARM_SCIENTIST]
        >= 4,
        "development_material_permanently_excluded": panel["development_only"]
        is True
        and panel["permanently_excluded"] is True,
        "confirmatory_namespaces_absent": not any(
            path.exists()
            for path in (
                root / "runs/autonomy_closure_v1/prospective_v6_confirmatory",
                root / "runs/autonomy_closure_v1/causalab_transport_confirmatory_v1",
                root / "runs/autonomy_closure_v1/adaptive_independent_replication_v1",
            )
        ),
    }
    body: Dict[str, Any] = {
        "version": POSTEXTENSION_REGRESSION_ADJUDICATION_VERSION,
        "status": "passed_freeze_proposal_authorized" if all(checks.values()) else "failed",
        "regression_commitment_id": commitment["regression_commitment_id"],
        "panel_id": panel["panel_id"],
        "supersedes_failed_adjudication_id": failed_adjudication[
            "regression_adjudication_id"
        ],
        "task_count": 6,
        "arm_episode_count": 18,
        "valid_root_advance_counts": successes,
        "rates": panel["rates"],
        "false_promotion_count": false_promotions,
        "checks": checks,
        "all_checks_passed": all(checks.values()),
        "adjudication_path": str(doc.relative_to(root)),
        "adjudication_sha256": bytes_sha256(doc.read_bytes()),
        "development_only": True,
        "permanently_excluded": True,
        "arm_differences_reportable_as_scientific_evidence": False,
        "implementation_freeze_proposal_authorized": all(checks.values()),
        "confirmatory_execution_authorized": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "regression_adjudication_id": content_digest(body)}
