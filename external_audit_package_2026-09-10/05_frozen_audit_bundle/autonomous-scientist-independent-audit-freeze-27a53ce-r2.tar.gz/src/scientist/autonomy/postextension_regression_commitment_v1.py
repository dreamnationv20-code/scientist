from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_worlds_v1 import FaultClass, ScientificState
from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


POSTEXTENSION_REGRESSION_COMMITMENT_VERSION = "adaptive-postextension-regression-commitment-v1"
EXPECTED_ADAPTIVE_QUALIFICATION_ID = "b2f9901aa0f002d9ff202850c95960f81edd8419900e29a9779e5bd002989657"
EXPECTED_CAUSALAB_QUALIFICATION_ID = "111796519ede9460004e4ee8a2e5f9a5092d016302af17c3cba02539212cb21d"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has invalid {key}")
    return value


def regression_task_specs(seed_base: int = 950_000) -> list[Mapping[str, Any]]:
    states = tuple(ScientificState)
    faults = tuple(FaultClass)
    return [
        {
            "task_index": index,
            "seed": seed_base + index,
            "scientific_state": states[index % len(states)].value,
            "variable_count": (5, 6, 7)[index % 3],
            "fault_class": fault.value,
        }
        for index, fault in enumerate(faults)
    ]


def build_postextension_regression_commitment(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    adaptive = _identified(
        root
        / "runs/autonomy_closure_v1/adaptive_causal_harness_qualification_v8/artifacts/manifests/adaptive-causal-harness-qualification-v8.json",
        "qualification_id",
    )
    causalab = _identified(
        root
        / "runs/autonomy_closure_v1/causalab_three_arm_harness_qualification_v9/artifacts/manifests/causalab-three-arm-harness-qualification-v9.json",
        "qualification_id",
    )
    if not (
        adaptive["qualification_id"] == EXPECTED_ADAPTIVE_QUALIFICATION_ID
        and adaptive["all_checks_passed"] is True
        and causalab["qualification_id"] == EXPECTED_CAUSALAB_QUALIFICATION_ID
        and causalab["passed"] is True
    ):
        raise ValueError("post-extension harness qualifications do not match")
    run_id = "adaptive-causal-postextension-regression-v1"
    outcome_path = root / (
        "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1/"
        f"artifacts/manifests/{run_id}.json"
    )
    if outcome_path.exists():
        raise ValueError("post-extension regression outcome already exists")
    confirmatory_namespaces = (
        root / "runs/autonomy_closure_v1/prospective_v6_confirmatory",
        root / "runs/autonomy_closure_v1/causalab_transport_confirmatory_v1",
        root / "runs/autonomy_closure_v1/adaptive_independent_replication_v1",
    )
    if any(path.exists() for path in confirmatory_namespaces):
        raise ValueError("confirmatory state exists before regression commitment")
    doc = root / (
        "docs/autonomous-scientist-postextension-live-regression-commitment-2026-09-09.md"
    )
    source_paths = (
        root / "src/scientist/autonomy/adaptive_worlds_v1.py",
        root / "src/scientist/autonomy/adaptive_three_arm_v1.py",
        root / "src/scientist/autonomy/adaptive_codex_runner_v1.py",
        root / "scripts/run_adaptive_causal_development_panel_v1.py",
    )
    body: Dict[str, Any] = {
        "version": POSTEXTENSION_REGRESSION_COMMITMENT_VERSION,
        "status": "committed_outcomes_absent",
        "run_id": run_id,
        "development_only": True,
        "permanently_excluded": True,
        "adaptive_qualification_id": adaptive["qualification_id"],
        "causalab_qualification_id": causalab["qualification_id"],
        "task_count": 6,
        "arm_episode_count": 18,
        "seed_base": 950_000,
        "seed_end_inclusive": 950_005,
        "order_seed": 250_909,
        "task_specs": regression_task_specs(),
        "model": "gpt-5.6-sol",
        "reasoning_effort": "low",
        "model_token_ceiling": 128_000,
        "wall_time_ceiling_seconds": 900,
        "pass_gates": {
            "all_18_arm_slots_terminal": True,
            "runner_exception_count": 0,
            "all_matching_checks": True,
            "result_identities_and_token_accounts_exact": True,
            "false_promotion_count": 0,
            "each_arm_valid_root_advance_minimum": 1,
            "scientist_valid_root_advance_minimum": 4,
        },
        "positive_arm_difference_is_evidence": False,
        "selective_reruns_allowed": False,
        "commitment_path": str(doc.relative_to(root)),
        "commitment_sha256": bytes_sha256(doc.read_bytes()),
        "source_hashes": {
            str(path.relative_to(root)): bytes_sha256(path.read_bytes())
            for path in source_paths
        },
        "confirmatory_namespaces_absent": True,
        "implementation_freeze_complete": False,
        "confirmatory_execution_authorized": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "regression_commitment_id": content_digest(body)}
