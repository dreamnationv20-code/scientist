from __future__ import annotations

from typing import Any, Callable, Mapping

from scientist.autonomy.lifecycle_components import LifecycleStageProduct
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import (
    ComponentExecutionTrace,
    ExternalInvocation,
    InvocationKind,
)
from scientist.codex_exchange import CodexStructuredExchange
from scientist.program.research_kernel import ResearchActionKind


PROPOSAL_PROVIDER_VERSION = "scientist-codex-proposal-provider-v1"


class CodexTypedProposalProvider:
    """Use Codex only to propose a typed artifact, never to validate it."""

    _ALLOWED_ACTIONS = {
        ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS,
        ResearchActionKind.INVENT_LATENT_CONCEPT,
        ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT,
    }

    def __init__(
        self,
        *,
        action_kind: ResearchActionKind,
        operation: str,
        exchange: CodexStructuredExchange,
        prompt_builder: Callable[[Any, Any], str],
        response_schema: Mapping[str, Any],
        parser: Callable[[Mapping[str, Any]], Any],
        outcome: str,
    ) -> None:
        if action_kind not in self._ALLOWED_ACTIONS:
            raise ValueError("Codex typed proposals are not authorized for this action")
        if not operation or not outcome:
            raise ValueError("proposal-provider identity is incomplete")
        if not callable(prompt_builder) or not callable(parser):
            raise ValueError("proposal provider requires prompt and parser callables")
        self.action_kind = action_kind
        self.operation = operation
        self.exchange = exchange
        self.prompt_builder = prompt_builder
        self.response_schema = dict(response_schema)
        self.parser = parser
        self.outcome = outcome

    def __call__(self, action, kernel, domain, component_ref):
        if action.kind != self.action_kind:
            raise ValueError("proposal provider received another research action")
        prompt = self.prompt_builder(kernel, domain)
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("proposal prompt must not be empty")
        audited = self.exchange.request_audited(
            operation=self.operation,
            prompt=prompt,
            response_schema=self.response_schema,
        )
        artifact = self.parser(audited.response)
        invocation = ExternalInvocation(
            kind=InvocationKind.MODEL,
            operation=self.operation,
            actor=ActorIdentity(
                actor_ref="codex-proposal-model:%s" % audited.model_ref,
                kind=ActorKind.PROPOSAL_MODEL,
            ),
            authority_scope=AuthorityScope.PROPOSE,
            input_artifact_ids=(audited.request_digest,),
            output_artifact_ids=(audited.response_digest,),
            # Codex CLI currently exposes a total token count rather than a
            # prompt/completion split. Store it in one bucket while preserving
            # the exact total used by the budget gate.
            usage=ResourceUsage(
                model_output_tokens=audited.reported_tokens_used,
                model_calls=1,
                wall_seconds=audited.wall_seconds,
            ),
        )
        trace = ComponentExecutionTrace(
            action_id=action.action_id,
            component_ref=component_ref,
            invocations=(invocation,),
            complete=True,
            undeclared_external_access=False,
            sealed_authority_accessed=False,
        )
        return LifecycleStageProduct(
            artifact=artifact,
            trace=trace,
            outcome=self.outcome,
            details={
                "proposal_provider_version": PROPOSAL_PROVIDER_VERSION,
                "packet_id": audited.packet_id,
                "proposal_response_digest": audited.response_digest,
                "model_ref": audited.model_ref,
                "reported_total_tokens": audited.reported_tokens_used,
                "model_wall_seconds": audited.wall_seconds,
                "model_exercised_scientific_authority": False,
            },
        )
