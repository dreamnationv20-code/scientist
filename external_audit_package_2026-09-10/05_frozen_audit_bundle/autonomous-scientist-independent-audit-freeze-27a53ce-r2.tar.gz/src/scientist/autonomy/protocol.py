from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


PROTOCOL_COMMITMENT_VERSION = "autonomous-scientist-protocol-commitment-v1"


def build_protocol_commitment(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    protocol = root / "docs" / "autonomous-scientist-prospective-evaluation-protocol.md"
    programme = root / "docs" / "autonomy-closure-nature-program.md"
    baseline_path = root / "runs" / "autonomy_closure_v1" / "baseline-audit.json"
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    baseline_body = dict(baseline)
    baseline_id = baseline_body.pop("audit_id")
    if content_digest(baseline_body) != baseline_id:
        raise ValueError("autonomy baseline audit identity mismatch")
    body: Dict[str, Any] = {
        "version": PROTOCOL_COMMITMENT_VERSION,
        "status": "protocol_committed_implementation_not_ready",
        "protocol_path": str(protocol.relative_to(root)),
        "protocol_sha256": bytes_sha256(protocol.read_bytes()),
        "programme_path": str(programme.relative_to(root)),
        "programme_sha256": bytes_sha256(programme.read_bytes()),
        "baseline_audit_id": baseline_id,
        "confirmatory_generated_episode_count": 180,
        "real_domain_episode_count": 30,
        "primary_effect_gate_percentage_points": 15.0,
        "outcomes_opened": False,
        "arm_trajectories_created": False,
        "implementation_freeze_complete": False,
        "generator_freeze_complete": False,
        "independent_audit_complete": False,
        "claim_eligible": False,
    }
    return {**body, "commitment_id": content_digest(body)}
