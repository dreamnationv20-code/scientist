from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


PROTOCOL_V2_COMMITMENT_VERSION = "autonomous-scientist-protocol-commitment-v2"


def _identified_json(path: Path, identity_key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    identity = str(value.get(identity_key, ""))
    body = dict(value)
    body.pop(identity_key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {identity_key}")
    return value


def build_protocol_v2_commitment(project_root: Path) -> Mapping[str, Any]:
    """Bind the external three-arm protocol before confirmatory authorities exist."""

    root = Path(project_root).resolve()
    protocol = (
        root
        / "docs"
        / "autonomous-scientist-prospective-evaluation-protocol-v2.md"
    )
    positioning = (
        root
        / "docs"
        / "autonomy-closure-literature-positioning-2026-09-08.md"
    )
    programme = root / "docs" / "autonomy-closure-nature-program.md"
    prior_commitment_path = (
        root
        / "runs"
        / "autonomy_closure_v1"
        / "prospective_protocol"
        / "artifacts"
        / "manifests"
        / "protocol-commitment-v1.json"
    )
    qualification_path = (
        root
        / "runs"
        / "autonomy_closure_v1"
        / "cognitive_universal_component_pack_qualification_v2"
        / "artifacts"
        / "manifests"
        / "cognitive-universal-component-pack-qualification-v2.json"
    )
    pack_audit_path = (
        root
        / "runs"
        / "autonomy_closure_v1"
        / "cognitive_universal_component_pack_qualification_audit_v1"
        / "artifacts"
        / "manifests"
        / "cognitive-universal-component-pack-independent-audit-v1.json"
    )
    confirmatory_namespace = (
        root
        / "runs"
        / "autonomy_closure_v1"
        / "prospective_v2_confirmatory"
    )

    for required in (protocol, positioning, programme):
        if not required.is_file():
            raise FileNotFoundError(required)
    if confirmatory_namespace.exists():
        raise ValueError(
            "v2 confirmatory namespace already exists; protocol cannot be committed"
        )

    prior = _identified_json(prior_commitment_path, "commitment_id")
    qualification = _identified_json(qualification_path, "qualification_id")
    pack_audit = _identified_json(pack_audit_path, "audit_id")
    if prior.get("outcomes_opened") or prior.get("arm_trajectories_created"):
        raise ValueError("prior commitment is not eligible for pre-outcome supersession")
    if not qualification.get("passed") or not qualification.get(
        "structural_qualification_only"
    ):
        raise ValueError("complete-pack structural qualification is invalid")
    if qualification.get("prospective_scientific_evidence_claimed"):
        raise ValueError("structural qualification improperly claims scientific evidence")
    if not pack_audit.get("passed") or not pack_audit.get(
        "structural_qualification_only"
    ):
        raise ValueError("complete-pack independent audit is invalid")
    if pack_audit.get("qualification_id") != qualification.get("qualification_id"):
        raise ValueError("complete-pack qualification and audit disagree")

    body: Dict[str, Any] = {
        "version": PROTOCOL_V2_COMMITMENT_VERSION,
        "status": "committed_fresh_external_authority_unresolved",
        "protocol_path": str(protocol.relative_to(root)),
        "protocol_sha256": bytes_sha256(protocol.read_bytes()),
        "positioning_path": str(positioning.relative_to(root)),
        "positioning_sha256": bytes_sha256(positioning.read_bytes()),
        "programme_path": str(programme.relative_to(root)),
        "programme_sha256": bytes_sha256(programme.read_bytes()),
        "supersedes_commitment_id": prior["commitment_id"],
        "supersession_pre_outcome": True,
        "supersession_reason": (
            "pre-outcome prior-art refresh identified a broader external "
            "procedural causal-discovery benchmark and the need for a "
            "prompt-equated monolithic control"
        ),
        "complete_pack_qualification_id": qualification["qualification_id"],
        "complete_pack_audit_id": pack_audit["audit_id"],
        "complete_pack_structurally_qualified": True,
        "arms": [
            "free_persistent_codex",
            "prompt_equated_monolithic_codex",
            "closed_scientist",
        ],
        "scientific_method_episode_count": 150,
        "typed_recovery_episode_count": 112,
        "cross_grammar_episode_count_minimum": 36,
        "primary_effect_gate_percentage_points": 15.0,
        "primary_contrast": (
            "closed_scientist_minus_prompt_equated_monolithic_codex"
        ),
        "key_secondary_contrast": (
            "closed_scientist_minus_free_persistent_codex"
        ),
        "released_petri_episodes_development_only": True,
        "fresh_external_task_authority_resolved": False,
        "confirmatory_namespace": str(confirmatory_namespace.relative_to(root)),
        "confirmatory_namespace_absent": True,
        "confirmatory_authorities_created": False,
        "confirmatory_outcomes_opened": False,
        "confirmatory_arm_trajectories_created": False,
        "implementation_freeze_complete": False,
        "three_arm_adapter_qualified": False,
        "independent_preexecution_audit_complete": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "commitment_id": content_digest(body)}

