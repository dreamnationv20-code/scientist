from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


PROTOCOL_V3_COMMITMENT_VERSION = "autonomous-scientist-protocol-commitment-v3"


def _identified_json(path: Path, identity_key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    identity = str(value.get(identity_key, ""))
    body = dict(value)
    body.pop(identity_key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {identity_key}")
    return value


def build_protocol_v3_commitment(project_root: Path) -> Mapping[str, Any]:
    """Bind the CausaLab-compatible three-arm protocol before model outcomes."""

    root = Path(project_root).resolve()
    protocol = root / "docs" / "autonomous-scientist-prospective-evaluation-protocol-v3.md"
    positioning = root / "docs" / "autonomy-closure-literature-positioning-2026-09-08.md"
    programme = root / "docs" / "autonomy-closure-nature-program.md"
    prior_path = (
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v2/artifacts/manifests"
        / "protocol-commitment-v2.json"
    )
    petri_path = (
        root
        / "runs/autonomy_closure_v1/petri_external_adapter_adjudication_v1/artifacts/manifests"
        / "petri-external-adapter-adjudication-v1.json"
    )
    adapter_path = (
        root
        / "runs/autonomy_closure_v1/causalab_external_adapter_qualification_v1/artifacts/manifests"
        / "causalab-external-adapter-qualification-v1.json"
    )
    generator_path = (
        root
        / "runs/autonomy_closure_v1/prospective_causalab_generator_qualification_v1/artifacts/manifests"
        / "prospective-causalab-generator-qualification-v1.json"
    )
    confirmatory_namespace = root / "runs/autonomy_closure_v1/prospective_v3_confirmatory"
    for required in (protocol, positioning, programme):
        if not required.is_file():
            raise FileNotFoundError(required)
    if confirmatory_namespace.exists():
        raise ValueError("v3 confirmatory namespace already exists; protocol cannot be committed")

    prior = _identified_json(prior_path, "commitment_id")
    petri = _identified_json(petri_path, "adjudication_id")
    adapter = _identified_json(adapter_path, "qualification_id")
    generator = _identified_json(generator_path, "qualification_id")
    if any(
        (
            prior.get("confirmatory_authorities_created"),
            prior.get("confirmatory_outcomes_opened"),
            prior.get("confirmatory_arm_trajectories_created"),
        )
    ):
        raise ValueError("v2 commitment is not eligible for pre-outcome supersession")
    petri_decision = petri.get("decision") or petri
    if (
        petri_decision.get("primary_failure_class")
        != "external_dependency"
        or petri_decision.get("action") != "request_external_authority"
    ):
        raise ValueError("Petri failure was not conservatively adjudicated")
    for label, qualification in (("adapter", adapter), ("generator", generator)):
        if not qualification.get("passed"):
            raise ValueError(f"CausaLab {label} qualification failed")
        if qualification.get("scientific_result_claimed"):
            raise ValueError(f"CausaLab {label} qualification claims a scientific result")
        if qualification.get("nature_claim_authorized"):
            raise ValueError(f"CausaLab {label} qualification improperly authorizes Nature")
        checks = qualification.get("checks") or {}
        if not checks.get("no_confirmatory_authority_created") or not checks.get(
            "no_confirmatory_outcome_opened"
        ):
            raise ValueError(f"CausaLab {label} qualification is not pre-outcome")

    body: Dict[str, Any] = {
        "version": PROTOCOL_V3_COMMITMENT_VERSION,
        "status": "committed_primary_generator_qualified_implementation_unfrozen",
        "protocol_path": str(protocol.relative_to(root)),
        "protocol_sha256": bytes_sha256(protocol.read_bytes()),
        "positioning_path": str(positioning.relative_to(root)),
        "positioning_sha256": bytes_sha256(positioning.read_bytes()),
        "programme_path": str(programme.relative_to(root)),
        "programme_sha256": bytes_sha256(programme.read_bytes()),
        "supersedes_commitment_id": prior["commitment_id"],
        "supersession_pre_outcome": True,
        "supersession_reason": (
            "the public Petri runtime failed released-result reproduction; "
            "a pinned CausaLab-compatible adapter and prospectively seeded "
            "identifiable generator passed pre-outcome qualification"
        ),
        "petri_adjudication_id": petri["adjudication_id"],
        "petri_primary_use_parked": True,
        "causalab_adapter_qualification_id": adapter["qualification_id"],
        "causalab_generator_qualification_id": generator["qualification_id"],
        "causalab_release_task_count": 950,
        "released_causalab_tasks_development_or_labeled_transport_only": True,
        "development_generator_tasks_qualified": generator["panel"]["tasks"],
        "arms": [
            "free_monolithic_codex",
            "prompt_equated_monolithic_codex",
            "authority_separated_scientist",
        ],
        "primary_task_count": 150,
        "primary_arm_episode_count": 450,
        "typed_recovery_task_count": 112,
        "cross_grammar_task_count_minimum": 36,
        "primary_outcome": "valid_scientific_resolution_within_budget",
        "primary_effect_gate_percentage_points": 15.0,
        "primary_contrast": "authority_separated_scientist_minus_prompt_equated_monolithic_codex",
        "key_secondary_contrast": "authority_separated_scientist_minus_free_monolithic_codex",
        "model_token_ceiling_per_episode": 32000,
        "wall_time_ceiling_seconds_per_episode": 900,
        "instrument_budget_rule": "4*(node_count-1)",
        "minimum_distinct_interventions_per_controllable_variable": 2,
        "exact_directed_graph_required": True,
        "frequency_equation_and_target_binding_required": True,
        "fresh_task_provider_resolved": False,
        "confirmatory_namespace": str(confirmatory_namespace.relative_to(root)),
        "confirmatory_namespace_absent": True,
        "confirmatory_authorities_created": False,
        "confirmatory_outcomes_opened": False,
        "confirmatory_arm_trajectories_created": False,
        "implementation_freeze_complete": False,
        "three_arm_adapter_qualified": False,
        "strict_outcome_evaluator_qualified": False,
        "independent_preexecution_audit_complete": False,
        "independent_replication_complete": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "commitment_id": content_digest(body)}
