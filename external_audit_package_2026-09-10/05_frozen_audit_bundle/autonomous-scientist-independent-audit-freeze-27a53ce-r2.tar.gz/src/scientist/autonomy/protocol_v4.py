from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


PROTOCOL_V4_COMMITMENT_VERSION = "autonomous-scientist-protocol-commitment-v4"
PRIOR_TOKEN_CEILING = 32_000
AMENDED_TOKEN_CEILING = 64_000


def _identified_json(path: Path, identity_key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    identity = str(value.get(identity_key, ""))
    body = dict(value)
    body.pop(identity_key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {identity_key}")
    return value


def _validate_calibration(calibration: Mapping[str, Any]) -> None:
    if calibration.get("status") != "complete" or not calibration.get(
        "development_only"
    ):
        raise ValueError("runtime-floor calibration is not a completed development run")
    if calibration.get("scientific_result_claimed") or calibration.get(
        "nature_claim_authorized"
    ):
        raise ValueError("runtime-floor calibration makes an impermissible claim")
    if calibration.get("confirmatory_authorities_created") or calibration.get(
        "confirmatory_outcomes_opened"
    ):
        raise ValueError("runtime-floor calibration accessed confirmatory state")
    if calibration.get("failures"):
        raise ValueError("runtime-floor calibration did not complete all requested arms")
    matching = calibration.get("matching_checks") or {}
    required_matching = (
        "all_requested_arms_completed",
        "full_matched_triple",
        "model_identical",
        "reasoning_effort_identical",
        "codex_version_identical",
        "public_task_identical",
        "tool_and_output_schemas_identical",
        "token_ceiling_identical",
        "wall_ceiling_identical",
    )
    if not all(matching.get(key) is True for key in required_matching):
        raise ValueError("runtime-floor calibration is not a matched three-arm episode")
    results = calibration.get("results") or {}
    expected_arms = {
        "free_monolithic_codex",
        "prompt_equated_monolithic_codex",
        "authority_separated_scientist",
    }
    if set(results) != expected_arms:
        raise ValueError("runtime-floor calibration does not contain exactly three arms")
    for arm, result in results.items():
        if result.get("model_token_ceiling") != PRIOR_TOKEN_CEILING:
            raise ValueError(f"{arm} did not use the committed v3 token ceiling")
        usage = result.get("token_usage") or {}
        if usage.get("total_tokens", 0) <= PRIOR_TOKEN_CEILING:
            raise ValueError(f"{arm} does not establish the 32k runtime-floor failure")
        if usage.get("total_tokens") != usage.get("input_tokens") + usage.get(
            "output_tokens"
        ):
            raise ValueError(f"{arm} token accounting is not input plus output")


def build_protocol_v4_commitment(project_root: Path) -> Mapping[str, Any]:
    """Commit a transparent runtime-only amendment before confirmation."""

    root = Path(project_root).resolve()
    prior_path = (
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v3/artifacts/manifests"
        / "protocol-commitment-v3.json"
    )
    calibration_path = (
        root
        / "runs/autonomy_closure_v1/causalab_three_arm_development_calibration_v1"
        / "artifacts/manifests/causalab-three-arm-development-calibration-v8.json"
    )
    amendment = (
        root
        / "docs/autonomous-scientist-prospective-evaluation-protocol-v4-amendment.md"
    )
    protocol_v3 = (
        root / "docs/autonomous-scientist-prospective-evaluation-protocol-v3.md"
    )
    confirmatory_v3 = root / "runs/autonomy_closure_v1/prospective_v3_confirmatory"
    confirmatory_v4 = root / "runs/autonomy_closure_v1/prospective_v4_confirmatory"
    for required in (prior_path, calibration_path, amendment, protocol_v3):
        if not required.is_file():
            raise FileNotFoundError(required)
    if confirmatory_v3.exists() or confirmatory_v4.exists():
        raise ValueError("confirmatory namespace already exists; amendment is too late")

    prior = _identified_json(prior_path, "commitment_id")
    calibration = _identified_json(calibration_path, "calibration_id")
    if prior.get("model_token_ceiling_per_episode") != PRIOR_TOKEN_CEILING:
        raise ValueError("v3 commitment does not contain the superseded 32k ceiling")
    if any(
        (
            prior.get("confirmatory_authorities_created"),
            prior.get("confirmatory_outcomes_opened"),
            prior.get("confirmatory_arm_trajectories_created"),
        )
    ):
        raise ValueError("v3 commitment is not eligible for pre-outcome amendment")
    _validate_calibration(calibration)

    body: Dict[str, Any] = {
        "version": PROTOCOL_V4_COMMITMENT_VERSION,
        "status": "committed_preoutcome_runtime_amendment_implementation_unfrozen",
        "amendment_path": str(amendment.relative_to(root)),
        "amendment_sha256": bytes_sha256(amendment.read_bytes()),
        "incorporated_protocol_path": str(protocol_v3.relative_to(root)),
        "incorporated_protocol_sha256": bytes_sha256(protocol_v3.read_bytes()),
        "supersedes_commitment_id": prior["commitment_id"],
        "supersession_pre_outcome": True,
        "amendment_scope": ["model_token_ceiling", "model_reasoning_effort"],
        "amendment_reason": "32k was below the measured matched Codex tool-runtime floor",
        "runtime_floor_calibration_id": calibration["calibration_id"],
        "runtime_floor_tokens_by_arm": {
            arm: result["token_usage"]["total_tokens"]
            for arm, result in sorted(calibration["results"].items())
        },
        "runtime_floor_calibration_permanently_excluded": True,
        "all_development_tasks_and_seeds_permanently_excluded": True,
        "token_accounting_definition": "turn.completed.input_tokens + turn.completed.output_tokens",
        "cached_input_tokens_subtracted": False,
        "prior_model_token_ceiling_per_episode": PRIOR_TOKEN_CEILING,
        "model_token_ceiling_per_episode": AMENDED_TOKEN_CEILING,
        "model_context_limit": AMENDED_TOKEN_CEILING,
        "model_auto_compact_token_limit": AMENDED_TOKEN_CEILING - 2_048,
        "model_reasoning_effort": "low",
        "wall_time_ceiling_seconds_per_episode": 900,
        "instrument_budget_rule": "4*(node_count-1)",
        "primary_task_count": prior["primary_task_count"],
        "primary_arm_episode_count": prior["primary_arm_episode_count"],
        "primary_outcome": prior["primary_outcome"],
        "primary_contrast": prior["primary_contrast"],
        "primary_effect_gate_percentage_points": prior[
            "primary_effect_gate_percentage_points"
        ],
        "all_other_v3_scientific_and_analysis_clauses_unchanged": True,
        "confirmatory_namespace": str(confirmatory_v4.relative_to(root)),
        "confirmatory_namespace_absent": True,
        "confirmatory_authorities_created": False,
        "confirmatory_outcomes_opened": False,
        "confirmatory_arm_trajectories_created": False,
        "implementation_freeze_complete": False,
        "three_arm_adapter_qualified": False,
        "strict_outcome_evaluator_qualified": False,
        "independent_preexecution_audit_complete": False,
        "independent_replication_complete": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "commitment_id": content_digest(body)}
