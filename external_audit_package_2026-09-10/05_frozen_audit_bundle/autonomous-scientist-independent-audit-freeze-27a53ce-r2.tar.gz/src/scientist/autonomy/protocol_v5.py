from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


PROTOCOL_V5_COMMITMENT_VERSION = "autonomous-scientist-protocol-commitment-v5"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    identity = value.get(key)
    body = dict(value)
    body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def build_protocol_v5_commitment(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    prior_path = (
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v4/artifacts/manifests"
        / "protocol-commitment-v4.json"
    )
    saturation_path = (
        root
        / "runs/autonomy_closure_v1/causalab_linear_substrate_adjudication_v1"
        / "artifacts/manifests/causalab-linear-substrate-adjudication-v1.json"
    )
    prior_baseline_path = (
        root
        / "runs/autonomy_closure_v1/generated_world_persistent_baseline_audit_v1"
        / "artifacts/manifests/generated-world-persistent-baseline-audit-v1.json"
    )
    protocol_path = (
        root / "docs/autonomous-scientist-adaptive-causal-recovery-protocol.md"
    )
    positioning_path = (
        root / "docs/autonomy-closure-literature-positioning-2026-09-08.md"
    )
    confirmatory_namespaces = (
        root / "runs/autonomy_closure_v1/prospective_v3_confirmatory",
        root / "runs/autonomy_closure_v1/prospective_v4_confirmatory",
        root / "runs/autonomy_closure_v1/prospective_v5_confirmatory",
    )
    for required in (
        prior_path,
        saturation_path,
        prior_baseline_path,
        protocol_path,
        positioning_path,
    ):
        if not required.is_file():
            raise FileNotFoundError(required)
    if any(path.exists() for path in confirmatory_namespaces):
        raise ValueError("a confirmatory namespace exists; primary-substrate revision is too late")

    prior = _identified(prior_path, "commitment_id")
    saturation = _identified(saturation_path, "adjudication_id")
    prior_baseline = _identified(prior_baseline_path, "audit_id")
    if any(
        (
            prior.get("confirmatory_authorities_created"),
            prior.get("confirmatory_outcomes_opened"),
            prior.get("confirmatory_arm_trajectories_created"),
        )
    ):
        raise ValueError("prior protocol is not eligible for pre-outcome supersession")
    if saturation.get("status") != "primary_substrate_rejected_for_saturation":
        raise ValueError("linear substrate was not conservatively adjudicated")
    summary = prior_baseline.get("summary") or {}
    if (
        prior_baseline.get("status") != "development_qualification_only"
        or summary.get("paired_root_advance_difference") != 0
        or prior_baseline.get("nature_primary_claim_authorized") is not False
    ):
        raise ValueError("prior persistent-baseline ceiling was not retained")

    body: Dict[str, Any] = {
        "version": PROTOCOL_V5_COMMITMENT_VERSION,
        "status": "committed_adaptive_primary_implementation_unfrozen",
        "protocol_path": str(protocol_path.relative_to(root)),
        "protocol_sha256": bytes_sha256(protocol_path.read_bytes()),
        "positioning_path": str(positioning_path.relative_to(root)),
        "positioning_sha256": bytes_sha256(positioning_path.read_bytes()),
        "supersedes_commitment_id": prior["commitment_id"],
        "supersession_pre_outcome": True,
        "supersession_reason": "noiseless linear tasks saturated both Codex controls",
        "linear_substrate_adjudication_id": saturation["adjudication_id"],
        "prior_persistent_baseline_audit_id": prior_baseline["audit_id"],
        "linear_causalab_role": "positive_control_only",
        "primary_substrate": "adaptive_causal_recovery_worlds",
        "arms": [
            "free_monolithic_codex",
            "prompt_equated_monolithic_codex",
            "authority_separated_scientist",
        ],
        "primary_task_count": 180,
        "primary_arm_episode_count": 540,
        "scientific_state_strata": [
            "signed_unary_moderation",
            "binary_xor_or_conjunction",
            "ternary_parity_or_threshold",
            "genuine_null",
            "evidence_underdetermined",
        ],
        "variable_count_tiers": [5, 6, 7],
        "fault_strata": [
            "none",
            "retryable_infrastructure",
            "partial_measurement",
            "permanent_action_unavailable",
            "protocol_invalid_request",
            "measurement_ambiguity",
        ],
        "primary_outcome": "valid_root_advance_within_budget",
        "primary_contrast": (
            "authority_separated_scientist_minus_prompt_equated_monolithic_codex"
        ),
        "key_secondary_contrast": (
            "authority_separated_scientist_minus_free_monolithic_codex"
        ),
        "primary_effect_gate_percentage_points": 15.0,
        "model": "gpt-5.6-sol",
        "reasoning_effort": "low",
        "model_token_ceiling_per_episode": 64_000,
        "wall_time_ceiling_seconds_per_episode": 900,
        "maximum_probe_batches": 3,
        "measurement_attempt_ceiling_by_variable_count": {
            "5": 24,
            "6": 30,
            "7": 36,
        },
        "shared_tools": ["probe_batch", "validate_candidate"],
        "validator_hidden_authority_access": False,
        "valid_null_and_underdetermined_conclusions_count_as_root_advance": True,
        "development_discrimination_task_count_minimum": 18,
        "development_reference_policy_minimum": 0.95,
        "development_random_policy_maximum": 0.10,
        "development_control_rate_interval": [0.15, 0.85],
        "all_development_tasks_and_outcomes_permanently_excluded": True,
        "confirmatory_namespace": (
            "runs/autonomy_closure_v1/prospective_v5_confirmatory"
        ),
        "confirmatory_namespace_absent": True,
        "confirmatory_seeds_created": False,
        "confirmatory_authorities_created": False,
        "confirmatory_arm_trajectories_created": False,
        "confirmatory_outcomes_opened": False,
        "implementation_freeze_complete": False,
        "independent_preexecution_audit_complete": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "commitment_id": content_digest(body)}
