from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


PROTOCOL_V6_COMMITMENT_VERSION = "autonomous-scientist-protocol-commitment-v6"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def build_protocol_v6_commitment(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    prior_path = (
        root
        / "runs/autonomy_closure_v1/prospective_protocol_v5/artifacts/manifests"
        / "protocol-commitment-v5.json"
    )
    triple_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_three_arm_development_v1/artifacts/manifests"
        / "adaptive-causal-three-arm-development-v2.json"
    )
    scientist_path = triple_path.parent / "adaptive-causal-scientist-schema-diagnostic-v3.json"
    prompt_path = triple_path.parent / "adaptive-causal-prompt-budget-diagnostic-v4.json"
    amendment_path = (
        root / "docs/autonomous-scientist-prospective-evaluation-protocol-v6-amendment.md"
    )
    for path in (prior_path, triple_path, scientist_path, prompt_path, amendment_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    for namespace in (
        "prospective_v3_confirmatory",
        "prospective_v4_confirmatory",
        "prospective_v5_confirmatory",
        "prospective_v6_confirmatory",
    ):
        if (root / "runs/autonomy_closure_v1" / namespace).exists():
            raise ValueError("a confirmatory namespace exists; budget amendment is too late")

    prior = _identified(prior_path, "commitment_id")
    triple = _identified(triple_path, "calibration_id")
    scientist = _identified(scientist_path, "calibration_id")
    prompt = _identified(prompt_path, "calibration_id")
    if any(
        (
            prior.get("confirmatory_authorities_created"),
            prior.get("confirmatory_outcomes_opened"),
            prior.get("confirmatory_arm_trajectories_created"),
        )
    ):
        raise ValueError("prior protocol is not eligible for pre-outcome amendment")
    free_result = triple.get("results", {}).get("free_monolithic_codex", {})
    scientist_result = scientist.get("results", {}).get(
        "authority_separated_scientist", {}
    )
    prompt_result = prompt.get("results", {}).get(
        "prompt_equated_monolithic_codex", {}
    )
    observed = {
        "free_monolithic_codex": free_result.get("token_usage", {}).get("total_tokens"),
        "authority_separated_scientist": scientist_result.get("token_usage", {}).get("total_tokens"),
        "prompt_equated_monolithic_codex_no_tool_diagnostic": prompt_result.get("token_usage", {}).get("total_tokens"),
    }
    if not (
        observed["free_monolithic_codex"] == 91_102
        and observed["authority_separated_scientist"] == 72_817
        and observed["prompt_equated_monolithic_codex_no_tool_diagnostic"] == 11_762
        and free_result.get("accounting_reconciled") is False
        and scientist_result.get("accounting_reconciled") is False
        and scientist_result.get("certificate", {}).get("accepted") is True
        and scientist_result.get("forbidden_tool_event_count") == 0
    ):
        raise ValueError("excluded diagnostics do not establish the adaptive runtime floor")

    body: Dict[str, Any] = {
        "version": PROTOCOL_V6_COMMITMENT_VERSION,
        "status": "committed_runtime_amendment_implementation_unfrozen",
        "supersedes_commitment_id": prior["commitment_id"],
        "supersession_pre_confirmatory": True,
        "adaptive_protocol_path": prior["protocol_path"],
        "adaptive_protocol_sha256": prior["protocol_sha256"],
        "amendment_path": str(amendment_path.relative_to(root)),
        "amendment_sha256": bytes_sha256(amendment_path.read_bytes()),
        "prior_model_token_ceiling_per_episode": prior["model_token_ceiling_per_episode"],
        "model_token_ceiling_per_episode": 128_000,
        "cached_input_tokens_subtracted": False,
        "observed_excluded_diagnostic_tokens": observed,
        "excluded_diagnostic_ids": [
            triple["calibration_id"],
            scientist["calibration_id"],
            prompt["calibration_id"],
        ],
        "all_diagnostic_tasks_and_outcomes_permanently_excluded": True,
        "model": prior["model"],
        "reasoning_effort": prior["reasoning_effort"],
        "wall_time_ceiling_seconds_per_episode": prior[
            "wall_time_ceiling_seconds_per_episode"
        ],
        "maximum_probe_batches": prior["maximum_probe_batches"],
        "measurement_attempt_ceiling_by_variable_count": prior[
            "measurement_attempt_ceiling_by_variable_count"
        ],
        "all_other_v5_scientific_and_analysis_clauses_unchanged": True,
        "confirmatory_namespace": "runs/autonomy_closure_v1/prospective_v6_confirmatory",
        "confirmatory_namespace_absent": True,
        "confirmatory_seeds_created": False,
        "confirmatory_authorities_created": False,
        "confirmatory_arm_trajectories_created": False,
        "confirmatory_outcomes_opened": False,
        "implementation_freeze_complete": False,
        "live_control_discrimination_gate_complete": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "commitment_id": content_digest(body)}
