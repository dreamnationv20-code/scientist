from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.autonomy.authority_contracts import (
    ACTION_AUTHORITY_CONTRACTS,
    audit_component_pack,
)
from scientist.autonomy.state import AuthoritativeStateRuntime, AutonomyEventKind
from scientist.autonomy.tracing import ComponentExecutionTrace
from scientist.autonomy.tracing import InvocationKind
from scientist.autonomy.memory import CausalMemoryRuntime, CausalMemoryStatus
from scientist.core.artifacts import content_digest
from scientist.domains.registry import default_domain_registry
from scientist.program.research_kernel import ResearchActionKind


AUTONOMY_READINESS_VERSION = "scientist-autonomy-readiness-v1"


def _verified_report(path: Path, identity_field: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("readiness source must be a JSON object: %s" % path)
    body = dict(value)
    supplied = body.pop(identity_field, None)
    if supplied != content_digest(body):
        raise ValueError("readiness-source identity mismatch: %s" % path)
    return value


def build_readiness_report(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    run_root = root / "runs" / "autonomy_closure_v1"
    bootstrap = AuthoritativeStateRuntime.from_checkpoint(
        run_root / "authoritative_state" / "checkpoint.json"
    )
    regression = AuthoritativeStateRuntime.from_checkpoint(
        run_root
        / "historical_regression"
        / "causal_structure_decision_trace_v1"
        / "authority-checkpoint.json"
    )
    regression_report = _verified_report(
        run_root
        / "historical_regression"
        / "causal_structure_decision_trace_v1"
        / "artifacts"
        / "manifests"
        / "historical-regression-report-v1.json",
        "report_id",
    )
    failure_report = _verified_report(
        run_root
        / "historical_failure_adjudication"
        / "artifacts"
        / "manifests"
        / "historical-failure-audit-v1.json",
        "report_id",
    )
    protocol = _verified_report(
        run_root
        / "prospective_protocol"
        / "artifacts"
        / "manifests"
        / "protocol-commitment-v1.json",
        "commitment_id",
    )
    semantic_memory = CausalMemoryRuntime.from_checkpoint(
        run_root / "semantic_memory" / "checkpoint.json"
    )
    claim_boundary = _verified_report(
        run_root
        / "claim_boundary_v1"
        / "artifacts"
        / "manifests"
        / "claim-boundary-audit-v1.json",
        "report_id",
    )
    generated_calibration = _verified_report(
        run_root
        / "generated_world_final_calibration_v3"
        / "artifacts"
        / "manifests"
        / "generated-world-final-calibration-v3.json",
        "audit_id",
    )
    matched_development = _verified_report(
        run_root
        / "generated_world_matched_development_audit_v1"
        / "artifacts"
        / "manifests"
        / "generated-world-matched-development-audit-v1.json",
        "audit_id",
    )
    persistent_baseline = _verified_report(
        run_root
        / "generated_world_persistent_baseline_audit_v1"
        / "artifacts"
        / "manifests"
        / "generated-world-persistent-baseline-audit-v1.json",
        "audit_id",
    )
    closed_sequester = _verified_report(
        run_root
        / "generated_world_closed_sequester_audit_v1"
        / "artifacts"
        / "manifests"
        / "generated-world-closed-sequester-audit-v1.json",
        "audit_id",
    )
    cognitive_stage_capabilities = _verified_report(
        run_root
        / "cognitive_v3_stage_capability_audit_v7"
        / "artifacts"
        / "manifests"
        / "cognitive-v3-stage-capability-audit-v1.json",
        "audit_id",
    )
    cognitive_self_ask = _verified_report(
        run_root
        / "cognitive_self_ask_v3_qualification_audit_v1"
        / "artifacts"
        / "manifests"
        / "cognitive-self-ask-v3-qualification-audit-v1.json",
        "audit_id",
    )
    receipt_journal = _verified_report(
        run_root
        / "resumable_receipt_journal_audit_v1"
        / "artifacts"
        / "manifests"
        / "resumable-receipt-journal-audit-v1.json",
        "audit_id",
    )
    cognitive_atlas = _verified_report(
        run_root
        / "cognitive_atlas_v3_qualification_audit_v1"
        / "artifacts"
        / "manifests"
        / "cognitive-causal-atlas-v3-qualification-audit-v1.json",
        "audit_id",
    )
    cognitive_negative_branch = _verified_report(
        run_root
        / "cognitive_negative_branch_v3_audit_v1"
        / "artifacts"
        / "manifests"
        / "cognitive-negative-branch-v3-independent-audit-v1.json",
        "audit_id",
    )
    cognitive_successor = _verified_report(
        run_root
        / "cognitive_successor_mission_v3_qualification_audit_v1"
        / "artifacts"
        / "manifests"
        / "cognitive-successor-mission-v3-independent-audit-v1.json",
        "audit_id",
    )
    trace_count = 0
    for event in regression.ledger.events:
        if event.kind != AutonomyEventKind.STATE_COMMITTED:
            continue
        trace = ComponentExecutionTrace.from_dict(
            event.payload["dispatch"]["details"]["_authority_trace"]
        )
        if trace.complete:
            trace_count += 1

    domain = default_domain_registry(discover_plugins=False).resolve(
        "cognitive_core_minilab"
    )
    required = {item.value for item in ResearchActionKind}
    component_audit = audit_component_pack(domain.research_components)
    installed = set(component_audit.installed_actions)
    component_coverage = len(component_audit.conformant_actions) / len(required)
    body: Dict[str, Any] = {
        "version": AUTONOMY_READINESS_VERSION,
        "authoritative_state": {
            "passed": bootstrap.ledger.verify_chain(),
            "state_id": bootstrap.ledger.state.state_id,
            "snapshot_count": len(bootstrap.ledger.state.subsystem_snapshots),
        },
        "governed_historical_decision": {
            "passed": all(
                (
                    regression.ledger.verify_chain(),
                    regression_report["boundary"] == "terminal_kill",
                    regression_report["human_interventions"] == 0,
                    regression_report["out_of_band_interventions"] == 0,
                    trace_count == 2,
                )
            ),
            "report_id": regression_report["report_id"],
            "complete_component_trace_count": trace_count,
        },
        "historical_failure_adjudication": {
            "passed": failure_report["passed_count"] == failure_report["case_count"],
            "passed_count": failure_report["passed_count"],
            "case_count": failure_report["case_count"],
            "retrospective": True,
            "prospective_evidence_claimed": False,
        },
        "semantic_causal_memory": {
            "passed": len(semantic_memory.memory.records) >= 4,
            "memory_id": semantic_memory.memory.memory_id,
            "record_count": len(semantic_memory.memory.records),
            "exhausted_intervention_count": len(
                semantic_memory.memory.query(status=CausalMemoryStatus.EXHAUSTED)
            ),
        },
        "evidence_bound_claim_harvesting": {
            "passed": all(
                (
                    claim_boundary["claim_ledger"]["contains_legacy_inputs"],
                    claim_boundary["claim_ledger"]["central_claim_count"] == 0,
                    not claim_boundary["prospective_result_claimed"],
                    not claim_boundary["nature_central_claim_authorized"],
                )
            ),
            "claim_ledger_id": claim_boundary["claim_ledger"]["ledger_id"],
            "legacy_result_blocked_from_central_claim": True,
        },
        "frozen_action_authority": {
            "passed": all(
                (
                    len(ACTION_AUTHORITY_CONTRACTS) == len(required),
                    all(
                        invocation.authority_scope.value == "propose"
                        for contract in ACTION_AUTHORITY_CONTRACTS.values()
                        for invocation in contract.allowed_invocations
                        if invocation.kind == InvocationKind.MODEL
                    ),
                    all(
                        InvocationKind.TOOL
                        in ACTION_AUTHORITY_CONTRACTS[action].required_invocation_kinds
                        for action in (
                            ResearchActionKind.SURVEY_PRIOR_ART,
                            ResearchActionKind.REPRODUCE_INCUMBENT,
                            ResearchActionKind.MAP_PHENOMENON,
                            ResearchActionKind.VALIDATE_LATENT_CONCEPT,
                            ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM,
                            ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION,
                        )
                    ),
                )
            ),
            "contract_count": len(ACTION_AUTHORITY_CONTRACTS),
            "model_authority": "proposal_only",
            "evidence_stages_require_tool_trace": True,
            "transactional_component_commit": True,
            "typed_live_failure_recovery_integrated": True,
        },
        "generated_world_development_calibration": {
            "passed": generated_calibration["passed"],
            "audit_id": generated_calibration["audit_id"],
            "episode_count": generated_calibration["episode_count"],
            "root_advance_count": generated_calibration[
                "root_advance_count"
            ],
            "false_promotion_count": generated_calibration[
                "false_promotion_count"
            ],
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        },
        "structured_matched_codex_development": {
            "passed": all(
                (
                    matched_development["summary"][
                        "all_required_invariants_passed"
                    ],
                    matched_development["same_output_component_ablation"][
                        "false_promotion_prevented"
                    ],
                    matched_development["same_output_component_ablation"][
                        "root_advance_recovered"
                    ],
                    not matched_development["nature_primary_claim_authorized"],
                )
            ),
            "audit_id": matched_development["audit_id"],
            "episode_count": matched_development["summary"]["episode_count"],
            "closed_root_advance_rate": matched_development["summary"][
                "closed_root_advance_rate"
            ],
            "standalone_codex_root_advance_rate": matched_development["summary"][
                "standalone_codex_root_advance_rate"
            ],
            "closed_false_promotion_rate": matched_development["summary"][
                "closed_false_promotion_rate"
            ],
            "standalone_codex_false_promotion_rate": matched_development[
                "summary"
            ]["standalone_codex_false_promotion_rate"],
            "development_only": True,
            "persistent_free_agent_baseline_complete": False,
            "prospective_nature_evidence_claimed": False,
        },
        "persistent_codex_causal_grammar_development": {
            "passed": all(
                (
                    persistent_baseline[
                        "causal_grammar_persistent_baseline_qualified"
                    ],
                    not persistent_baseline[
                        "global_persistent_baseline_qualified"
                    ],
                    not persistent_baseline["nature_primary_claim_authorized"],
                )
            ),
            "audit_id": persistent_baseline["audit_id"],
            "episode_count": persistent_baseline["summary"]["episode_count"],
            "closed_root_advance_rate": persistent_baseline["summary"][
                "closed_root_advance_rate"
            ],
            "persistent_codex_root_advance_rate": persistent_baseline["summary"][
                "persistent_codex_root_advance_rate"
            ],
            "paired_root_advance_difference": persistent_baseline["summary"][
                "paired_root_advance_difference"
            ],
            "persistent_codex_mean_model_tokens": persistent_baseline["summary"][
                "persistent_codex_mean_model_tokens"
            ],
            "global_persistent_baseline_complete": False,
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        },
        "closed_model_sequester_development": {
            "passed": all(
                (
                    closed_sequester["closed_model_sequester_qualified"],
                    closed_sequester["all_failed_attempts_pre_inference"],
                    not closed_sequester["confirmatory_performance_evidence_claimed"],
                    not closed_sequester["nature_primary_claim_authorized"],
                )
            ),
            "audit_id": closed_sequester["audit_id"],
            "successful_result_id": closed_sequester["successful_attempt"][
                "result_id"
            ],
            "failed_pre_inference_attempt_count": len(
                closed_sequester["failed_attempts"]
            ),
            "project_read_denial_enforced": closed_sequester[
                "successful_attempt"
            ]["checks"]["project_read_denial_preflight_passed"],
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        },
        "tested_closed_arm_fidelity": {
            "passed": False,
            "uses_universal_v3_lifecycle": False,
            "uses_bespoke_generated_world_loop": True,
            "required_remedy": (
                "Run generated-world evaluation through the same complete V3 "
                "lifecycle, authority contracts, memory, and recovery policy "
                "that constitute the claimed Scientist."
            ),
        },
        "cognitive_v3_component_pack": {
            "passed": component_audit.passed,
            "installed_action_count": len(installed.intersection(required)),
            "authority_conformant_action_count": len(
                component_audit.conformant_actions
            ),
            "required_action_count": len(required),
            "coverage": component_coverage,
            "missing_actions": list(component_audit.missing_actions),
            "nonconformant_actions": dict(
                component_audit.nonconformant_actions
            ),
        },
        "cognitive_v3_stage_capabilities": {
            "passed": all(
                (
                    cognitive_stage_capabilities[
                        "all_declared_sources_present"
                    ],
                    not cognitive_stage_capabilities[
                        "historical_artifacts_count_as_prospective_closure"
                    ],
                    not cognitive_stage_capabilities[
                        "complete_cognitive_pack_claimed"
                    ],
                )
            ),
            "audit_id": cognitive_stage_capabilities["audit_id"],
            "status_counts": cognitive_stage_capabilities["status_counts"],
            "run_binding_ready_action_count": cognitive_stage_capabilities[
                "status_counts"
            ]["run_binding_ready"],
            "implemented_provider_action_count": cognitive_stage_capabilities[
                "status_counts"
            ]["provider_implemented"],
            "fresh_execution_qualified_action_count": cognitive_stage_capabilities[
                "status_counts"
            ]["fresh_execution_qualified"],
            "complete_pack_claimed": False,
        },
        "cognitive_negative_branch_composition": {
            "passed": all(cognitive_negative_branch["checks"].values()),
            "audit_id": cognitive_negative_branch["audit_id"],
            "mission_id": cognitive_negative_branch["mission_id"],
            "validation_id": cognitive_negative_branch["validation_id"],
            "disposition": cognitive_negative_branch["disposition"],
            "negative_result_not_promoted": cognitive_negative_branch["checks"]
            ["negative_result_not_promoted"],
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        },
        "autonomous_successor_mission_genesis": {
            "passed": all(cognitive_successor["checks"].values()),
            "audit_id": cognitive_successor["audit_id"],
            "authorization_id": cognitive_successor["authorization_id"],
            "parent_mission_id": cognitive_successor["parent_mission_id"],
            "successor_mission_id": cognitive_successor["successor_mission_id"],
            "selected_candidate_ref": cognitive_successor[
                "selected_candidate_ref"
            ],
            "eligible_candidate_count": len(
                cognitive_successor["eligible_candidate_refs"]
            ),
            "model_calls": cognitive_successor["resource_usage"]["model_calls"],
            "codex_repair_count_during_development": 3,
            "parent_terminal_state_preserved": cognitive_successor["checks"]
            ["parent_terminal_kill_preserved"],
            "confirmatory_outcomes_unopened": True,
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        },
        "cognitive_self_ask_v3_qualification": {
            "passed": cognitive_self_ask["fresh_component_qualified"],
            "audit_id": cognitive_self_ask["audit_id"],
            "successful_qualification_id": cognitive_self_ask[
                "successful_qualification_id"
            ],
            "failure_accounting_regression_fixed": cognitive_self_ask[
                "failure_accounting_regression_fixed"
            ],
            "pre_fix_failure_accounting_defect_observed": cognitive_self_ask[
                "pre_fix_failure_accounting_defect_observed"
            ],
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        },
        "resumable_instrument_receipt_journal": {
            "passed": receipt_journal["passed"],
            "audit_id": receipt_journal["audit_id"],
            "completed_unit_mutation_blocked": receipt_journal["checks"][
                "completed_unit_mutation_blocked"
            ],
            "restart_preserved_completed_unit": receipt_journal["checks"][
                "restart_preserved_completed_unit"
            ],
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        },
        "cognitive_causal_atlas_v3_qualification": {
            "passed": all(cognitive_atlas["checks"].values()),
            "audit_id": cognitive_atlas["audit_id"],
            "qualification_id": cognitive_atlas["qualification_id"],
            "atlas_id": cognitive_atlas["atlas_id"],
            "failed_scoring_attempt_retained": cognitive_atlas[
                "checks"
            ]["failed_attempt_retained_trigger"],
            "source_repair_invalidated_failed_attempt": cognitive_atlas[
                "checks"
            ]["failed_attempt_invalidated_by_source_repair"],
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        },
        "prospective_protocol": {
            "committed": True,
            "commitment_id": protocol["commitment_id"],
            "outcomes_opened": protocol["outcomes_opened"],
            "implementation_freeze_complete": protocol[
                "implementation_freeze_complete"
            ],
        },
        "nature_gates": {
            "autonomy_closed": False,
            "matched_codex_baseline_complete": False,
            "prospective_advantage_complete": False,
            "cross_domain_confirmation_complete": False,
            "independent_replication_complete": False,
            "submission_ready": False,
        },
        "next_blocking_milestone": (
            "Qualify prior-art and experiment-design on the authorized successor, "
            "add mechanism-compilation and multi-horizon evaluators, bind all twelve "
            "actions into one universal V3 pack, then run the same pack across all "
            "blinded matched-budget grammars before any confirmatory seeds are created."
        ),
    }
    return {**body, "readiness_id": content_digest(body)}
