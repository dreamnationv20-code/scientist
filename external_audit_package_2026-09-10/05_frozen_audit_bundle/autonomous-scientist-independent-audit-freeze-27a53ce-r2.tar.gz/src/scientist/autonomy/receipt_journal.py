from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.state import ResourceUsage
from scientist.core.artifacts import content_digest


RECEIPT_JOURNAL_VERSION = "scientist-resumable-receipt-journal-v1"


def _write_immutable(path: Path, value: Mapping[str, Any]) -> None:
    payload = (
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        + "\n"
    ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.read_bytes() != payload:
            raise ValueError("refusing to overwrite immutable receipt: %s" % path)
        return
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _read_object(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("receipt journal file is not an object: %s" % path)
    return value


@dataclass(frozen=True)
class JournalReceipt:
    run_id: str
    action_id: str
    contract_id: str
    unit_ref: str
    payload: Mapping[str, Any]
    usage: ResourceUsage

    def __post_init__(self) -> None:
        if not all((self.run_id, self.action_id, self.contract_id, self.unit_ref)):
            raise ValueError("journal receipt identity is incomplete")

    @property
    def receipt_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": RECEIPT_JOURNAL_VERSION,
            "run_id": self.run_id,
            "action_id": self.action_id,
            "contract_id": self.contract_id,
            "unit_ref": self.unit_ref,
            "payload": dict(self.payload),
            "usage": self.usage.as_dict(),
        }
        if include_id:
            value["receipt_id"] = self.receipt_id
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "JournalReceipt":
        if value.get("version") != RECEIPT_JOURNAL_VERSION:
            raise ValueError("unsupported journal receipt version")
        result = cls(
            run_id=str(value["run_id"]),
            action_id=str(value["action_id"]),
            contract_id=str(value["contract_id"]),
            unit_ref=str(value["unit_ref"]),
            payload=dict(value["payload"]),
            usage=ResourceUsage.from_dict(value["usage"]),
        )
        if value.get("receipt_id") != result.receipt_id:
            raise ValueError("journal receipt identity mismatch")
        return result


class ResumableReceiptJournal:
    """An append-only, per-unit checkpoint for expensive instrument cells."""

    def __init__(
        self,
        root: Path,
        *,
        run_id: str,
        action_id: str,
        contract_id: str,
        expected_units: Sequence[str],
    ) -> None:
        units = tuple(str(item) for item in expected_units)
        if not all((run_id, action_id, contract_id)):
            raise ValueError("receipt journal identity is incomplete")
        if not units or not all(units) or len(units) != len(set(units)):
            raise ValueError("receipt journal units must be unique and non-empty")
        self.root = Path(root)
        self.receipt_root = self.root / "receipts"
        self.run_id = str(run_id)
        self.action_id = str(action_id)
        self.contract_id = str(contract_id)
        self.expected_units = units
        claim_body = {
            "version": RECEIPT_JOURNAL_VERSION,
            "run_id": self.run_id,
            "action_id": self.action_id,
            "contract_id": self.contract_id,
            "expected_units": list(self.expected_units),
        }
        self.claim = {**claim_body, "claim_id": content_digest(claim_body)}
        _write_immutable(self.root / "claim.json", self.claim)
        self._validate_existing_receipts()

    def _receipt_path(self, unit_ref: str) -> Path:
        return self.receipt_root / (content_digest(unit_ref) + ".json")

    def _load_unit(self, unit_ref: str) -> JournalReceipt | None:
        path = self._receipt_path(unit_ref)
        if not path.exists():
            return None
        receipt = JournalReceipt.from_dict(_read_object(path))
        if (
            receipt.run_id != self.run_id
            or receipt.action_id != self.action_id
            or receipt.contract_id != self.contract_id
            or receipt.unit_ref != unit_ref
        ):
            raise ValueError("journal receipt belongs to another execution")
        return receipt

    def _validate_existing_receipts(self) -> None:
        expected_paths = {
            self._receipt_path(unit).name for unit in self.expected_units
        }
        if self.receipt_root.exists():
            unexpected = {
                path.name for path in self.receipt_root.glob("*.json")
            }.difference(expected_paths)
            if unexpected:
                raise ValueError("receipt journal contains undeclared units")
        for unit in self.expected_units:
            self._load_unit(unit)

    @property
    def completed_units(self) -> Tuple[str, ...]:
        return tuple(
            unit for unit in self.expected_units if self._load_unit(unit) is not None
        )

    @property
    def pending_units(self) -> Tuple[str, ...]:
        completed = set(self.completed_units)
        return tuple(unit for unit in self.expected_units if unit not in completed)

    def record(
        self,
        unit_ref: str,
        payload: Mapping[str, Any],
        *,
        usage: ResourceUsage,
    ) -> JournalReceipt:
        unit = str(unit_ref)
        if unit not in self.expected_units:
            raise ValueError("cannot record an undeclared receipt unit")
        candidate = JournalReceipt(
            run_id=self.run_id,
            action_id=self.action_id,
            contract_id=self.contract_id,
            unit_ref=unit,
            payload=dict(payload),
            usage=usage,
        )
        existing = self._load_unit(unit)
        if existing is not None:
            if existing != candidate:
                raise ValueError("completed receipt unit cannot be changed")
            return existing
        _write_immutable(self._receipt_path(unit), candidate.as_dict())
        return self._load_unit(unit)  # type: ignore[return-value]

    def receipts(self) -> Tuple[JournalReceipt, ...]:
        values = tuple(self._load_unit(unit) for unit in self.expected_units)
        if any(value is None for value in values):
            raise ValueError("receipt journal is incomplete")
        return tuple(value for value in values if value is not None)

    def finalize(self) -> Mapping[str, Any]:
        receipts = self.receipts()
        total = ResourceUsage()
        for receipt in receipts:
            total = total.plus(receipt.usage)
        body = {
            "version": RECEIPT_JOURNAL_VERSION,
            "run_id": self.run_id,
            "action_id": self.action_id,
            "contract_id": self.contract_id,
            "claim_id": self.claim["claim_id"],
            "unit_count": len(receipts),
            "receipt_ids": [receipt.receipt_id for receipt in receipts],
            "total_usage": total.as_dict(),
            "complete": True,
        }
        completion = {**body, "completion_id": content_digest(body)}
        _write_immutable(self.root / "completion.json", completion)
        return _read_object(self.root / "completion.json")


__all__ = [
    "RECEIPT_JOURNAL_VERSION",
    "JournalReceipt",
    "ResumableReceiptJournal",
]
