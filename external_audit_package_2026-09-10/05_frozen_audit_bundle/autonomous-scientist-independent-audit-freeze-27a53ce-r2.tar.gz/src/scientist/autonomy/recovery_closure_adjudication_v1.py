from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


RECOVERY_CLOSURE_ADJUDICATION_VERSION = "recovery-closure-adjudication-v1"
EXPECTED_PANEL_ID = "e98b14945c732c0d904dfa857cae2321dace3366fbd3e2c5354aab5f33d4993a"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def build_recovery_closure_adjudication(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    panel_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1"
        / "artifacts/manifests/adaptive-causal-development-pilot-v2.json"
    )
    doc_path = (
        root
        / "docs/autonomous-scientist-prefreeze-recovery-closure-adjudication-2026-09-09.md"
    )
    implementation_path = root / "src/scientist/autonomy/adaptive_three_arm_v1.py"
    test_path = root / "tests/test_autonomy_adaptive_three_arm_v1.py"
    for path in (panel_path, doc_path, implementation_path, test_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    panel = _identified(panel_path, "panel_id")
    if panel["panel_id"] != EXPECTED_PANEL_ID:
        raise ValueError("recovery correction is not bound to the adjudicated pilot")
    failed = panel["results"]["task-04|authority_separated_scientist"]
    if not (
        panel["development_only"] is True
        and panel["permanently_excluded"] is True
        and panel["rates"]["pooled_controls"] == 0.5
        and panel["rates"]["authority_separated_scientist"] == 5 / 6
        and failed["measurement_attempts"] == 2
        and failed["probe_batches"] == 1
        and failed["validator_calls"] == 2
        and failed["score"]["typed_recovery_correct"] is False
        and failed["score"]["validator_certificate_valid"] is False
        and failed["lifecycle_decision"]["terminal_authorized"] is False
    ):
        raise ValueError("pilot does not establish the recovery-closure defect")
    for namespace in (
        "prospective_v3_confirmatory",
        "prospective_v4_confirmatory",
        "prospective_v5_confirmatory",
        "prospective_v6_confirmatory",
    ):
        if (root / "runs/autonomy_closure_v1" / namespace).exists():
            raise ValueError("confirmatory state exists; implementation correction is too late")
    body: Dict[str, Any] = {
        "version": RECOVERY_CLOSURE_ADJUDICATION_VERSION,
        "status": "prefreeze_recovery_closure_correction_installed",
        "source_panel_id": panel["panel_id"],
        "failure_classification": "host_recovery_dependency_autonomy_gap",
        "correction": {
            "reserve_measurement_capacity_for_fault_recovery": True,
            "close_pending_recovery_before_scientist_validation": True,
            "return_recovered_public_evidence_to_proposal_model": True,
            "controls_changed": False,
            "shared_tool_schemas_changed": False,
            "hidden_authority_access_added": False,
        },
        "adjudication_path": str(doc_path.relative_to(root)),
        "adjudication_sha256": bytes_sha256(doc_path.read_bytes()),
        "implementation_path": str(implementation_path.relative_to(root)),
        "implementation_sha256": bytes_sha256(implementation_path.read_bytes()),
        "test_path": str(test_path.relative_to(root)),
        "test_sha256": bytes_sha256(test_path.read_bytes()),
        "fresh_excluded_replay_required": True,
        "implementation_freeze_complete": False,
        "confirmatory_execution_authorized": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "adjudication_id": content_digest(body)}
