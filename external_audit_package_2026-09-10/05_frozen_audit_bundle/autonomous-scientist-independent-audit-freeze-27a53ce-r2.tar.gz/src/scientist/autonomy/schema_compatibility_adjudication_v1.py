from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.autonomy.adaptive_three_arm_v1 import (
    adaptive_conclusion_schema,
    adaptive_probe_schema,
    adaptive_validate_schema,
)
from scientist.autonomy.adaptive_worlds_v1 import (
    FaultClass,
    ScientificState,
    generate_adaptive_world,
)
from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


SCHEMA_COMPATIBILITY_ADJUDICATION_VERSION = "schema-compatibility-adjudication-v1"
EXPECTED_SMOKE_ID = "716774dae39cde4f6f2d6db175f078a5dbca132d31d365f767cf1fa6c6b1e6d2"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def _contains_array_enum(value: Any) -> bool:
    if isinstance(value, Mapping):
        enum = value.get("enum")
        if isinstance(enum, list) and any(isinstance(item, list) for item in enum):
            return True
        return any(_contains_array_enum(item) for item in value.values())
    if isinstance(value, list):
        return any(_contains_array_enum(item) for item in value)
    return False


def build_schema_compatibility_adjudication(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    failed_checkpoint_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1"
        / "artifacts/manifests/adaptive-causal-development-pilot-v4-checkpoint-05.json"
    )
    smoke_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_three_arm_development_v1"
        / "artifacts/manifests/adaptive-causal-schema-compatibility-smoke-v6.json"
    )
    doc_path = (
        root
        / "docs/autonomous-scientist-prefreeze-schema-compatibility-adjudication-2026-09-09.md"
    )
    implementation_path = root / "src/scientist/autonomy/adaptive_three_arm_v1.py"
    runner_path = root / "src/scientist/autonomy/adaptive_codex_runner_v1.py"
    test_path = root / "tests/test_autonomy_adaptive_three_arm_v1.py"
    for path in (
        failed_checkpoint_path,
        smoke_path,
        doc_path,
        implementation_path,
        runner_path,
        test_path,
    ):
        if not path.is_file():
            raise FileNotFoundError(path)

    checkpoint = json.loads(failed_checkpoint_path.read_text(encoding="utf-8"))
    failures = checkpoint.get("failures", {})
    if not (
        checkpoint.get("development_only") is True
        and checkpoint.get("completed_task_count") == 5
        and len(failures) == 15
        and not checkpoint.get("results")
        and all("invalid_json_schema" in item.get("message", "") for item in failures.values())
    ):
        raise ValueError("checkpoint does not establish a pre-inference schema failure")

    smoke = _identified(smoke_path, "calibration_id")
    if smoke["calibration_id"] != EXPECTED_SMOKE_ID:
        raise ValueError("compatibility correction is not bound to the expected smoke")
    scientist = smoke.get("results", {}).get("authority_separated_scientist")
    if not (
        smoke.get("development_only") is True
        and smoke.get("permanently_excluded") is True
        and not smoke.get("failures")
        and scientist
        and scientist["token_usage"]["total_tokens"] > 0
        and scientist["score"]["valid_root_advance"] is False
    ):
        raise ValueError("smoke does not establish schema transport without a result claim")

    public, _ = generate_adaptive_world(
        920_005,
        scientific_state=ScientificState.SIGNED_UNARY,
        variable_count=7,
        fault_class=FaultClass.MEASUREMENT_AMBIGUITY,
        development_only=True,
    )
    schemas = (
        adaptive_probe_schema(public),
        adaptive_validate_schema(public),
        adaptive_conclusion_schema(public),
    )
    if any(_contains_array_enum(schema) for schema in schemas):
        raise ValueError("corrected schemas still contain an enum of arrays")
    validate = adaptive_validate_schema(public)
    selected = validate["properties"]["selected_hypothesis_ref"]
    intervention = validate["properties"]["predictions"]["items"]["properties"]["intervention"]
    context = validate["properties"]["predictions"]["items"]["properties"]["context"]
    if not (
        selected.get("enum")
        and intervention.get("enum")
        and context.get("minItems") == 7
        and context.get("maxItems") == 7
        and context.get("items", {}).get("enum") == [0, 1]
    ):
        raise ValueError("corrected schemas lack the committed primitive constraints")

    for namespace in (
        "prospective_v3_confirmatory",
        "prospective_v4_confirmatory",
        "prospective_v5_confirmatory",
        "prospective_v6_confirmatory",
    ):
        if (root / "runs/autonomy_closure_v1" / namespace).exists():
            raise ValueError("confirmatory state exists; compatibility correction is too late")

    body: Dict[str, Any] = {
        "version": SCHEMA_COMPATIBILITY_ADJUDICATION_VERSION,
        "status": "prefreeze_structured_output_compatibility_correction_installed",
        "failed_checkpoint_sha256": bytes_sha256(failed_checkpoint_path.read_bytes()),
        "failed_arm_count": len(failures),
        "failure_stage": "before_model_inference",
        "failed_panel_permanently_excluded": True,
        "compatibility_smoke_id": smoke["calibration_id"],
        "smoke_reached_model_inference": True,
        "smoke_scientific_success_claimed": False,
        "correction": {
            "primitive_string_enums_retained": True,
            "array_valued_enums_removed": True,
            "fixed_width_binary_context_schema": True,
            "semantic_context_membership_enforced_by_answer_blind_parser": True,
            "schema_identical_across_matched_arms": True,
            "hidden_authority_access_added": False,
        },
        "adjudication_path": str(doc_path.relative_to(root)),
        "adjudication_sha256": bytes_sha256(doc_path.read_bytes()),
        "source_hashes": {
            str(path.relative_to(root)): bytes_sha256(path.read_bytes())
            for path in (implementation_path, runner_path, test_path)
        },
        "fresh_excluded_replay_required": True,
        "implementation_freeze_complete": False,
        "confirmatory_execution_authorized": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "adjudication_id": content_digest(body)}
