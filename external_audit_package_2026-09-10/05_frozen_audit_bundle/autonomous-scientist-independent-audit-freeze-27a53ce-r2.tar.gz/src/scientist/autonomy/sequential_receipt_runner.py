from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from scientist.autonomy.mlx_receipt_runner import GenerationUnit
from scientist.autonomy.receipt_journal import ResumableReceiptJournal
from scientist.autonomy.state import ResourceUsage
from scientist.core.artifacts import content_digest


SEQUENTIAL_RECEIPT_RUNNER_VERSION = (
    "scientist-sequential-resumable-generation-runner-v1"
)


class SequentialResumableGenerationCell:
    """Checkpoint dependent generations whose prompts are built sequentially."""

    def __init__(
        self,
        *,
        journal_root: Path,
        run_id: str,
        action_id: str,
        contract_id: str,
        expected_unit_refs: Sequence[str],
        generator: Callable[[GenerationUnit], Mapping[str, Any]],
    ) -> None:
        self.generator = generator
        self.journal = ResumableReceiptJournal(
            journal_root,
            run_id=run_id,
            action_id=action_id,
            contract_id=contract_id,
            expected_units=tuple(expected_unit_refs),
        )

    def receipt(self, unit_ref: str) -> Mapping[str, Any] | None:
        existing = self.journal._load_unit(unit_ref)
        if existing is None:
            return None
        value = existing.payload.get("receipt")
        if not isinstance(value, Mapping):
            raise ValueError("sequential journal omitted its generation receipt")
        return dict(value)

    def run_unit(self, unit: GenerationUnit) -> Mapping[str, Any]:
        if unit.unit_ref not in self.journal.expected_units:
            raise ValueError("sequential generation unit was not preregistered")
        existing = self.receipt(unit.unit_ref)
        if existing is not None:
            return existing
        started = time.perf_counter()
        generated = dict(self.generator(unit))
        elapsed = time.perf_counter() - started
        required = {"response", "prompt_tokens", "output_tokens", "generation"}
        if not required.issubset(generated):
            raise ValueError("generation backend returned an incomplete result")
        body = {
            "runner_version": SEQUENTIAL_RECEIPT_RUNNER_VERSION,
            "unit_ref": unit.unit_ref,
            **dict(unit.public_metadata),
            "prompt_sha256": content_digest(unit.prompt),
            "maximum_new_tokens": unit.maximum_new_tokens,
            "seed": unit.seed,
            "response": str(generated["response"]),
            "prompt_tokens": int(generated["prompt_tokens"]),
            "output_tokens": int(generated["output_tokens"]),
            "generation": dict(generated["generation"]),
            "elapsed_seconds": elapsed,
        }
        receipt = {**body, "receipt_id": content_digest(body)}
        self.journal.record(
            unit.unit_ref,
            {"receipt": receipt},
            usage=ResourceUsage(wall_seconds=elapsed, compute_units=elapsed),
        )
        return self.receipt(unit.unit_ref)  # type: ignore[return-value]

    def finalize(self) -> tuple[Mapping[str, Any], ...]:
        self.journal.finalize()
        return tuple(
            dict(item.payload["receipt"]) for item in self.journal.receipts()
        )


__all__ = [
    "SEQUENTIAL_RECEIPT_RUNNER_VERSION",
    "SequentialResumableGenerationCell",
]
