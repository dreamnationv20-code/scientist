from __future__ import annotations

import json
import math
import os
import re
import tempfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, canonical_json, content_digest


AUTONOMY_STATE_VERSION = "scientist-authoritative-state-v1"
_DIGEST = re.compile(r"[0-9a-f]{64}")


def _digest(value: str, label: str) -> str:
    result = str(value)
    if _DIGEST.fullmatch(result) is None:
        raise ValueError("%s must be a SHA-256 digest" % label)
    return result


def _unique_digests(values: Sequence[str], label: str) -> Tuple[str, ...]:
    result = tuple(_digest(value, label) for value in values)
    if len(result) != len(set(result)):
        raise ValueError("%s must be unique" % label)
    return result


class ActorKind(str, Enum):
    SCIENTIST_POLICY = "scientist_policy"
    PROPOSAL_MODEL = "proposal_model"
    DETERMINISTIC_VALIDATOR = "deterministic_validator"
    TOOL_RUNTIME = "tool_runtime"
    HUMAN = "human"
    EXTERNAL_REPLICATOR = "external_replicator"
    LEGACY_IMPORT = "legacy_import"


class AuthorityScope(str, Enum):
    PROPOSE = "propose"
    EXECUTE = "execute"
    MEASURE = "measure"
    VERIFY = "verify"
    GOVERN = "govern"
    IMPORT = "import"


_ACTOR_SCOPES = {
    ActorKind.SCIENTIST_POLICY: {
        AuthorityScope.PROPOSE,
        AuthorityScope.GOVERN,
    },
    ActorKind.PROPOSAL_MODEL: {AuthorityScope.PROPOSE},
    ActorKind.DETERMINISTIC_VALIDATOR: {
        AuthorityScope.MEASURE,
        AuthorityScope.VERIFY,
    },
    ActorKind.TOOL_RUNTIME: {
        AuthorityScope.EXECUTE,
        AuthorityScope.MEASURE,
    },
    ActorKind.HUMAN: {AuthorityScope.GOVERN},
    ActorKind.EXTERNAL_REPLICATOR: {AuthorityScope.VERIFY},
    ActorKind.LEGACY_IMPORT: {AuthorityScope.IMPORT},
}


@dataclass(frozen=True)
class ActorIdentity:
    actor_ref: str
    kind: ActorKind

    def __post_init__(self) -> None:
        if not self.actor_ref:
            raise ValueError("actor reference must not be empty")

    @property
    def inside_autonomy_boundary(self) -> bool:
        return self.kind in {
            ActorKind.SCIENTIST_POLICY,
            ActorKind.PROPOSAL_MODEL,
            ActorKind.DETERMINISTIC_VALIDATOR,
            ActorKind.TOOL_RUNTIME,
        }

    def permits(self, scope: AuthorityScope) -> bool:
        return scope in _ACTOR_SCOPES[self.kind]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "actor_ref": self.actor_ref,
            "kind": self.kind.value,
            "inside_autonomy_boundary": self.inside_autonomy_boundary,
        }


class AutonomyEventKind(str, Enum):
    RUN_REGISTERED = "run_registered"
    LEGACY_STATE_IMPORTED = "legacy_state_imported"
    ACTION_SELECTED = "action_selected"
    PROPOSAL_RECORDED = "proposal_recorded"
    MODEL_EXCHANGE_RECORDED = "model_exchange_recorded"
    TOOL_RESULT_RECORDED = "tool_result_recorded"
    MEASUREMENT_RECORDED = "measurement_recorded"
    VERIFICATION_RECORDED = "verification_recorded"
    FAILURE_ADJUDICATED = "failure_adjudicated"
    STATE_COMMITTED = "state_committed"
    INTERVENTION_RECORDED = "intervention_recorded"
    ACTION_COMPLETED = "action_completed"
    RUN_TERMINATED = "run_terminated"


class RunStatus(str, Enum):
    ACTIVE = "active"
    TERMINATED = "terminated"


@dataclass(frozen=True)
class ResourceUsage:
    model_input_tokens: int = 0
    model_output_tokens: int = 0
    model_calls: int = 0
    tool_calls: int = 0
    wall_seconds: float = 0.0
    compute_units: float = 0.0

    def __post_init__(self) -> None:
        integer_values = (
            self.model_input_tokens,
            self.model_output_tokens,
            self.model_calls,
            self.tool_calls,
        )
        if any(isinstance(value, bool) or int(value) != value or value < 0 for value in integer_values):
            raise ValueError("resource counters must be non-negative integers")
        if any(
            not math.isfinite(float(value)) or float(value) < 0.0
            for value in (self.wall_seconds, self.compute_units)
        ):
            raise ValueError("resource quantities must be finite and non-negative")

    @property
    def total_model_tokens(self) -> int:
        return self.model_input_tokens + self.model_output_tokens

    def plus(self, other: "ResourceUsage") -> "ResourceUsage":
        return ResourceUsage(
            model_input_tokens=self.model_input_tokens + other.model_input_tokens,
            model_output_tokens=self.model_output_tokens + other.model_output_tokens,
            model_calls=self.model_calls + other.model_calls,
            tool_calls=self.tool_calls + other.tool_calls,
            wall_seconds=self.wall_seconds + other.wall_seconds,
            compute_units=self.compute_units + other.compute_units,
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "model_input_tokens": self.model_input_tokens,
            "model_output_tokens": self.model_output_tokens,
            "model_calls": self.model_calls,
            "tool_calls": self.tool_calls,
            "wall_seconds": self.wall_seconds,
            "compute_units": self.compute_units,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ResourceUsage":
        return cls(
            model_input_tokens=int(value.get("model_input_tokens", 0)),
            model_output_tokens=int(value.get("model_output_tokens", 0)),
            model_calls=int(value.get("model_calls", 0)),
            tool_calls=int(value.get("tool_calls", 0)),
            wall_seconds=float(value.get("wall_seconds", 0.0)),
            compute_units=float(value.get("compute_units", 0.0)),
        )


@dataclass(frozen=True)
class ResourceBudget:
    maximum_model_tokens: int
    maximum_model_calls: int
    maximum_tool_calls: int
    maximum_wall_seconds: float
    maximum_compute_units: float

    def __post_init__(self) -> None:
        integers = (
            self.maximum_model_tokens,
            self.maximum_model_calls,
            self.maximum_tool_calls,
        )
        if any(isinstance(value, bool) or int(value) != value or value <= 0 for value in integers):
            raise ValueError("resource-budget counters must be positive integers")
        if any(
            not math.isfinite(float(value)) or float(value) <= 0.0
            for value in (self.maximum_wall_seconds, self.maximum_compute_units)
        ):
            raise ValueError("resource-budget quantities must be finite and positive")

    def admits(self, usage: ResourceUsage) -> bool:
        return all(
            (
                usage.total_model_tokens <= self.maximum_model_tokens,
                usage.model_calls <= self.maximum_model_calls,
                usage.tool_calls <= self.maximum_tool_calls,
                usage.wall_seconds <= self.maximum_wall_seconds,
                usage.compute_units <= self.maximum_compute_units,
            )
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "maximum_model_tokens": self.maximum_model_tokens,
            "maximum_model_calls": self.maximum_model_calls,
            "maximum_tool_calls": self.maximum_tool_calls,
            "maximum_wall_seconds": self.maximum_wall_seconds,
            "maximum_compute_units": self.maximum_compute_units,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ResourceBudget":
        return cls(
            maximum_model_tokens=int(value["maximum_model_tokens"]),
            maximum_model_calls=int(value["maximum_model_calls"]),
            maximum_tool_calls=int(value["maximum_tool_calls"]),
            maximum_wall_seconds=float(value["maximum_wall_seconds"]),
            maximum_compute_units=float(value["maximum_compute_units"]),
        )


@dataclass(frozen=True)
class SubsystemSnapshot:
    subsystem: str
    digest: str
    schema_version: str
    source_ref: str

    def __post_init__(self) -> None:
        if not all((self.subsystem, self.schema_version, self.source_ref)):
            raise ValueError("subsystem snapshot identity is incomplete")
        _digest(self.digest, "subsystem snapshot digest")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "subsystem": self.subsystem,
            "digest": self.digest,
            "schema_version": self.schema_version,
            "source_ref": self.source_ref,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SubsystemSnapshot":
        return cls(
            subsystem=str(value["subsystem"]),
            digest=str(value["digest"]),
            schema_version=str(value["schema_version"]),
            source_ref=str(value["source_ref"]),
        )


@dataclass(frozen=True)
class UnifiedResearchState:
    run_id: str
    objective_id: str
    budget: ResourceBudget
    usage: ResourceUsage
    subsystem_snapshots: Tuple[SubsystemSnapshot, ...]
    active_action_id: Optional[str]
    completed_action_count: int
    human_intervention_count: int
    out_of_band_intervention_count: int
    status: RunStatus

    def __post_init__(self) -> None:
        if not self.run_id or not self.objective_id:
            raise ValueError("research-state identity is incomplete")
        names = tuple(item.subsystem for item in self.subsystem_snapshots)
        if len(names) != len(set(names)):
            raise ValueError("only one authoritative snapshot is allowed per subsystem")
        if any(
            isinstance(value, bool) or int(value) != value or value < 0
            for value in (
                self.completed_action_count,
                self.human_intervention_count,
                self.out_of_band_intervention_count,
            )
        ):
            raise ValueError("research-state counters must be non-negative integers")
        if self.out_of_band_intervention_count > self.human_intervention_count:
            raise ValueError("out-of-band interventions cannot exceed all interventions")
        if not self.budget.admits(self.usage):
            raise ValueError("research state exceeds its frozen resource budget")
        if self.status == RunStatus.TERMINATED and self.active_action_id is not None:
            raise ValueError("a terminated run cannot retain an active action")

    @property
    def state_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": AUTONOMY_STATE_VERSION,
            "run_id": self.run_id,
            "objective_id": self.objective_id,
            "budget": self.budget.as_dict(),
            "usage": self.usage.as_dict(),
            "subsystem_snapshots": [
                item.as_dict()
                for item in sorted(self.subsystem_snapshots, key=lambda item: item.subsystem)
            ],
            "active_action_id": self.active_action_id,
            "completed_action_count": self.completed_action_count,
            "human_intervention_count": self.human_intervention_count,
            "out_of_band_intervention_count": self.out_of_band_intervention_count,
            "status": self.status.value,
        }
        if include_id:
            value["state_id"] = self.state_id
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "UnifiedResearchState":
        if value.get("version") != AUTONOMY_STATE_VERSION:
            raise ValueError("unsupported authoritative research-state version")
        result = cls(
            run_id=str(value["run_id"]),
            objective_id=str(value["objective_id"]),
            budget=ResourceBudget.from_dict(value["budget"]),
            usage=ResourceUsage.from_dict(value["usage"]),
            subsystem_snapshots=tuple(
                SubsystemSnapshot.from_dict(item)
                for item in value.get("subsystem_snapshots", ())
            ),
            active_action_id=value.get("active_action_id"),
            completed_action_count=int(value.get("completed_action_count", 0)),
            human_intervention_count=int(value.get("human_intervention_count", 0)),
            out_of_band_intervention_count=int(
                value.get("out_of_band_intervention_count", 0)
            ),
            status=RunStatus(value["status"]),
        )
        supplied_id = value.get("state_id")
        if supplied_id is not None and supplied_id != result.state_id:
            raise ValueError("authoritative research-state digest mismatch")
        return result


@dataclass(frozen=True)
class AutonomyStateEvent:
    sequence: int
    run_id: str
    kind: AutonomyEventKind
    actor: ActorIdentity
    authority_scope: AuthorityScope
    action_id: Optional[str]
    payload: Mapping[str, Any]
    input_artifact_ids: Tuple[str, ...]
    output_artifact_ids: Tuple[str, ...]
    resource_delta: ResourceUsage
    snapshot_updates: Tuple[SubsystemSnapshot, ...]
    state_before_id: Optional[str]
    state_after: UnifiedResearchState
    previous_event_id: Optional[str]

    @property
    def event_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": AUTONOMY_STATE_VERSION,
            "sequence": self.sequence,
            "run_id": self.run_id,
            "kind": self.kind.value,
            "actor": self.actor.as_dict(),
            "authority_scope": self.authority_scope.value,
            "action_id": self.action_id,
            "payload": dict(self.payload),
            "input_artifact_ids": list(self.input_artifact_ids),
            "output_artifact_ids": list(self.output_artifact_ids),
            "resource_delta": self.resource_delta.as_dict(),
            "snapshot_updates": [item.as_dict() for item in self.snapshot_updates],
            "state_before_id": self.state_before_id,
            "state_after": self.state_after.as_dict(),
            "previous_event_id": self.previous_event_id,
        }
        if include_id:
            value["event_id"] = self.event_id
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "AutonomyStateEvent":
        if value.get("version") != AUTONOMY_STATE_VERSION:
            raise ValueError("unsupported autonomy-state event version")
        actor_value = value["actor"]
        actor = ActorIdentity(
            actor_ref=str(actor_value["actor_ref"]),
            kind=ActorKind(actor_value["kind"]),
        )
        if actor_value.get("inside_autonomy_boundary") != actor.inside_autonomy_boundary:
            raise ValueError("actor autonomy-boundary declaration is inconsistent")
        result = cls(
            sequence=int(value["sequence"]),
            run_id=str(value["run_id"]),
            kind=AutonomyEventKind(value["kind"]),
            actor=actor,
            authority_scope=AuthorityScope(value["authority_scope"]),
            action_id=value.get("action_id"),
            payload=dict(value.get("payload", {})),
            input_artifact_ids=_unique_digests(
                value.get("input_artifact_ids", ()), "input artifact IDs"
            ),
            output_artifact_ids=_unique_digests(
                value.get("output_artifact_ids", ()), "output artifact IDs"
            ),
            resource_delta=ResourceUsage.from_dict(value.get("resource_delta", {})),
            snapshot_updates=tuple(
                SubsystemSnapshot.from_dict(item)
                for item in value.get("snapshot_updates", ())
            ),
            state_before_id=value.get("state_before_id"),
            state_after=UnifiedResearchState.from_dict(value["state_after"]),
            previous_event_id=value.get("previous_event_id"),
        )
        supplied_id = value.get("event_id")
        if supplied_id is not None and supplied_id != result.event_id:
            raise ValueError("autonomy-state event digest mismatch")
        return result


def _validate_event_contract(
    *,
    kind: AutonomyEventKind,
    actor: ActorIdentity,
    authority_scope: AuthorityScope,
    output_artifact_ids: Sequence[str],
    resource_delta: ResourceUsage,
    snapshot_updates: Sequence[SubsystemSnapshot],
) -> None:
    if not actor.permits(authority_scope):
        raise ValueError(
            "%s actor cannot exercise %s authority"
            % (actor.kind.value, authority_scope.value)
        )
    if actor.kind == ActorKind.HUMAN and kind != AutonomyEventKind.INTERVENTION_RECORDED:
        raise ValueError("human actions must be recorded explicitly as interventions")
    if kind == AutonomyEventKind.INTERVENTION_RECORDED and actor.kind != ActorKind.HUMAN:
        raise ValueError("an intervention must identify its human actor")
    if kind == AutonomyEventKind.LEGACY_STATE_IMPORTED and actor.kind != ActorKind.LEGACY_IMPORT:
        raise ValueError("legacy import requires a legacy-import actor")
    if kind == AutonomyEventKind.MODEL_EXCHANGE_RECORDED:
        if actor.kind != ActorKind.PROPOSAL_MODEL or resource_delta.model_calls < 1:
            raise ValueError("model exchanges require a proposal model and a charged call")
    if kind == AutonomyEventKind.TOOL_RESULT_RECORDED:
        if actor.kind != ActorKind.TOOL_RUNTIME or resource_delta.tool_calls < 1:
            raise ValueError("tool results require a tool-runtime actor and a charged call")
    update_names = tuple(item.subsystem for item in snapshot_updates)
    if len(update_names) != len(set(update_names)):
        raise ValueError("snapshot updates must name unique subsystems")
    missing_outputs = set(item.digest for item in snapshot_updates).difference(
        output_artifact_ids
    )
    if missing_outputs:
        raise ValueError("every authoritative snapshot update must be an output artifact")


def _advance_state(
    state: UnifiedResearchState,
    *,
    kind: AutonomyEventKind,
    action_id: Optional[str],
    payload: Mapping[str, Any],
    resource_delta: ResourceUsage,
    snapshot_updates: Sequence[SubsystemSnapshot],
) -> UnifiedResearchState:
    if state.status == RunStatus.TERMINATED:
        raise ValueError("a terminated authoritative state is immutable")
    active = state.active_action_id
    completed = state.completed_action_count
    interventions = state.human_intervention_count
    out_of_band = state.out_of_band_intervention_count

    if kind == AutonomyEventKind.ACTION_SELECTED:
        if active is not None or not action_id:
            raise ValueError("action selection requires no other active action")
        active = action_id
    elif kind == AutonomyEventKind.LEGACY_STATE_IMPORTED:
        if active is not None or completed:
            raise ValueError("legacy state may only be imported before autonomous actions")
        if action_id is not None:
            raise ValueError("legacy-state import cannot claim an autonomous action")
    elif kind == AutonomyEventKind.RUN_TERMINATED:
        if active is not None or action_id is not None:
            raise ValueError("run termination requires no active action")
    else:
        if active is None or action_id != active:
            raise ValueError("event must be linked to the active action")
        if kind == AutonomyEventKind.ACTION_COMPLETED:
            active = None
            completed += 1
        if kind == AutonomyEventKind.INTERVENTION_RECORDED:
            interventions += 1
            if bool(payload.get("out_of_band", False)):
                out_of_band += 1

    updates = {item.subsystem: item for item in state.subsystem_snapshots}
    for item in snapshot_updates:
        updates[item.subsystem] = item
    usage = state.usage.plus(resource_delta)
    return UnifiedResearchState(
        run_id=state.run_id,
        objective_id=state.objective_id,
        budget=state.budget,
        usage=usage,
        subsystem_snapshots=tuple(
            updates[name] for name in sorted(updates)
        ),
        active_action_id=active,
        completed_action_count=completed,
        human_intervention_count=interventions,
        out_of_band_intervention_count=out_of_band,
        status=(
            RunStatus.TERMINATED
            if kind == AutonomyEventKind.RUN_TERMINATED
            else state.status
        ),
    )


class AuthoritativeResearchLedger:
    """The single replayable provenance and resource-accounting spine."""

    def __init__(
        self,
        run_id: str,
        objective_id: str,
        budget: ResourceBudget,
        controller: ActorIdentity,
        artifact_store: Optional[ArtifactStore] = None,
    ) -> None:
        if controller.kind != ActorKind.SCIENTIST_POLICY:
            raise ValueError("an autonomous run must be registered by scientist policy")
        initial = UnifiedResearchState(
            run_id=run_id,
            objective_id=objective_id,
            budget=budget,
            usage=ResourceUsage(),
            subsystem_snapshots=(),
            active_action_id=None,
            completed_action_count=0,
            human_intervention_count=0,
            out_of_band_intervention_count=0,
            status=RunStatus.ACTIVE,
        )
        event = AutonomyStateEvent(
            sequence=0,
            run_id=run_id,
            kind=AutonomyEventKind.RUN_REGISTERED,
            actor=controller,
            authority_scope=AuthorityScope.GOVERN,
            action_id=None,
            payload={"objective_id": objective_id, "budget": budget.as_dict()},
            input_artifact_ids=(),
            output_artifact_ids=(),
            resource_delta=ResourceUsage(),
            snapshot_updates=(),
            state_before_id=None,
            state_after=initial,
            previous_event_id=None,
        )
        self._events: Tuple[AutonomyStateEvent, ...] = (event,)
        self._state = initial
        self._artifact_store = artifact_store
        self._artifact_digests: Tuple[str, ...] = ()
        self._store_event(event)

    @property
    def events(self) -> Tuple[AutonomyStateEvent, ...]:
        return self._events

    @property
    def state(self) -> UnifiedResearchState:
        return self._state

    @property
    def artifact_digests(self) -> Tuple[str, ...]:
        return self._artifact_digests

    def _store_event(self, event: AutonomyStateEvent) -> None:
        if self._artifact_store is not None:
            artifact_id = self._artifact_store.put(
                "authoritative_research_state_event", event.as_dict()
            )
            self._artifact_digests = (*self._artifact_digests, artifact_id)

    def append(
        self,
        kind: AutonomyEventKind,
        actor: ActorIdentity,
        authority_scope: AuthorityScope,
        *,
        action_id: Optional[str] = None,
        payload: Optional[Mapping[str, Any]] = None,
        input_artifact_ids: Sequence[str] = (),
        output_artifact_ids: Sequence[str] = (),
        resource_delta: ResourceUsage = ResourceUsage(),
        snapshot_updates: Sequence[SubsystemSnapshot] = (),
    ) -> AutonomyStateEvent:
        if kind == AutonomyEventKind.RUN_REGISTERED:
            raise ValueError("run registration may occur only once")

        inputs = _unique_digests(input_artifact_ids, "input artifact IDs")
        outputs = _unique_digests(output_artifact_ids, "output artifact IDs")
        updates = tuple(snapshot_updates)
        _validate_event_contract(
            kind=kind,
            actor=actor,
            authority_scope=authority_scope,
            output_artifact_ids=outputs,
            resource_delta=resource_delta,
            snapshot_updates=updates,
        )

        after = _advance_state(
            self._state,
            kind=kind,
            action_id=action_id,
            payload={} if payload is None else payload,
            resource_delta=resource_delta,
            snapshot_updates=updates,
        )
        event = AutonomyStateEvent(
            sequence=len(self._events),
            run_id=self._state.run_id,
            kind=kind,
            actor=actor,
            authority_scope=authority_scope,
            action_id=action_id,
            payload={} if payload is None else dict(payload),
            input_artifact_ids=inputs,
            output_artifact_ids=outputs,
            resource_delta=resource_delta,
            snapshot_updates=updates,
            state_before_id=self._state.state_id,
            state_after=after,
            previous_event_id=self._events[-1].event_id,
        )
        self._events = (*self._events, event)
        self._state = after
        self._store_event(event)
        return event

    def verify_chain(self) -> bool:
        try:
            self._verify_and_replay(self._events)
        except ValueError:
            return False
        return True

    @staticmethod
    def _verify_and_replay(
        events: Sequence[AutonomyStateEvent],
    ) -> UnifiedResearchState:
        if not events or events[0].kind != AutonomyEventKind.RUN_REGISTERED:
            raise ValueError("the first authoritative event must register the run")
        first = events[0]
        if first.sequence != 0 or first.previous_event_id is not None:
            raise ValueError("invalid run-registration position")
        if first.state_before_id is not None or first.action_id is not None:
            raise ValueError("run registration must begin from an empty state")
        if first.actor.kind != ActorKind.SCIENTIST_POLICY:
            raise ValueError("run registration requires scientist policy")
        if first.authority_scope != AuthorityScope.GOVERN:
            raise ValueError("run registration requires governance authority")
        state = first.state_after
        if first.run_id != state.run_id:
            raise ValueError("run registration and initial state disagree")
        if first.payload.get("objective_id") != state.objective_id:
            raise ValueError("run registration and objective disagree")
        if first.payload.get("budget") != state.budget.as_dict():
            raise ValueError("run registration and resource budget disagree")
        if state.usage != ResourceUsage() or state.subsystem_snapshots:
            raise ValueError("run registration cannot smuggle prior state or usage")
        if state.active_action_id is not None or state.status != RunStatus.ACTIVE:
            raise ValueError("run registration created an invalid initial state")
        previous = first.event_id

        for sequence, event in enumerate(events[1:], start=1):
            if event.sequence != sequence or event.previous_event_id != previous:
                raise ValueError("authoritative event chain is broken")
            if event.run_id != state.run_id or event.state_before_id != state.state_id:
                raise ValueError("authoritative event is linked to the wrong state")
            _validate_event_contract(
                kind=event.kind,
                actor=event.actor,
                authority_scope=event.authority_scope,
                output_artifact_ids=event.output_artifact_ids,
                resource_delta=event.resource_delta,
                snapshot_updates=event.snapshot_updates,
            )
            expected = _advance_state(
                state,
                kind=event.kind,
                action_id=event.action_id,
                payload=event.payload,
                resource_delta=event.resource_delta,
                snapshot_updates=event.snapshot_updates,
            )
            if expected != event.state_after:
                raise ValueError("event state transition does not replay")
            state = expected
            previous = event.event_id
        return state

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": AUTONOMY_STATE_VERSION,
            "run_id": self._state.run_id,
            "event_count": len(self._events),
            "chain_valid": self.verify_chain(),
            "head_event_id": self._events[-1].event_id,
            "state": self._state.as_dict(),
            "events": [event.as_dict() for event in self._events],
            "artifact_digests": list(self._artifact_digests),
        }

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
        artifact_store: Optional[ArtifactStore] = None,
    ) -> "AuthoritativeResearchLedger":
        if value.get("version") != AUTONOMY_STATE_VERSION:
            raise ValueError("unsupported authoritative ledger version")
        events = tuple(
            AutonomyStateEvent.from_dict(item) for item in value.get("events", ())
        )
        state = cls._verify_and_replay(events)
        if int(value.get("event_count", -1)) != len(events):
            raise ValueError("authoritative event count mismatch")
        if value.get("run_id") != state.run_id:
            raise ValueError("authoritative ledger run identity mismatch")
        if value.get("head_event_id") != events[-1].event_id:
            raise ValueError("authoritative ledger head mismatch")
        supplied_state = UnifiedResearchState.from_dict(value["state"])
        if supplied_state != state:
            raise ValueError("authoritative ledger final state mismatch")
        ledger = cls.__new__(cls)
        ledger._events = events
        ledger._state = state
        ledger._artifact_store = artifact_store
        ledger._artifact_digests = tuple(value.get("artifact_digests", ()))
        return ledger


class AuthoritativeStateRuntime:
    """Atomic checkpoint boundary for the cross-kernel authority ledger."""

    def __init__(
        self,
        ledger: AuthoritativeResearchLedger,
        checkpoint_path: Path,
        *,
        save_on_init: bool = True,
    ) -> None:
        self.ledger = ledger
        self.checkpoint_path = Path(checkpoint_path)
        if save_on_init:
            self.save_checkpoint()

    def _checkpoint_value(self) -> Dict[str, Any]:
        value = {
            "version": AUTONOMY_STATE_VERSION,
            "ledger": self.ledger.as_dict(),
        }
        value["checkpoint_id"] = content_digest(value)
        return value

    def save_checkpoint(self) -> Path:
        destination = self.checkpoint_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        payload = canonical_json(self._checkpoint_value()) + b"\n"
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=destination.name + ".",
            suffix=".tmp",
            dir=str(destination.parent),
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, destination)
        finally:
            temporary_path = Path(temporary_name)
            if temporary_path.exists():
                temporary_path.unlink()
        return destination

    @classmethod
    def from_checkpoint(
        cls,
        checkpoint_path: Path,
        artifact_store: Optional[ArtifactStore] = None,
    ) -> "AuthoritativeStateRuntime":
        path = Path(checkpoint_path)
        with path.open("r", encoding="utf-8") as handle:
            supplied = json.load(handle)
        if not isinstance(supplied, dict):
            raise ValueError("authoritative checkpoint must be a JSON object")
        value = dict(supplied)
        checkpoint_id = value.pop("checkpoint_id", None)
        if checkpoint_id != content_digest(value):
            raise ValueError("authoritative checkpoint digest mismatch")
        ledger = AuthoritativeResearchLedger.from_dict(
            value["ledger"], artifact_store=artifact_store
        )
        return cls(ledger, path, save_on_init=False)
