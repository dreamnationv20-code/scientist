from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.state import ResourceUsage
from scientist.core.artifacts import content_digest


VERSION = "scientist-fail-fast-substage-gates-v1"


def _unique(values: Sequence[str], label: str, *, allow_empty: bool = False):
    result = tuple(str(value) for value in values)
    if (not allow_empty and not result) or any(not value for value in result):
        raise ValueError("%s requires non-empty values" % label)
    if len(result) != len(set(result)):
        raise ValueError("%s must be unique" % label)
    return result


class GateDirection(str, Enum):
    AT_LEAST = "at_least"
    AT_MOST = "at_most"


class GateFailureDisposition(str, Enum):
    INVALIDATE = "invalidate"
    REPAIR_IMPLEMENTATION = "repair_implementation"
    AMEND_PROTOCOL = "amend_protocol"
    UPDATE_CAUSAL_THEORY = "update_causal_theory"


class ScheduleStatus(str, Enum):
    ACTIVE = "active"
    INVALID = "invalid"
    REPAIR_REQUIRED = "repair_required"
    PROTOCOL_AMENDMENT_REQUIRED = "protocol_amendment_required"
    SCIENTIFIC_STOP = "scientific_stop"
    COMPLETE = "complete"


@dataclass(frozen=True)
class SubstageSpec:
    substage_id: str
    dependencies: Tuple[str, ...]
    purpose: str
    may_access_authority: bool
    produces_outcome: bool

    def __post_init__(self) -> None:
        if not self.substage_id or not self.purpose:
            raise ValueError("substage specification is incomplete")
        _unique(self.dependencies, "substage dependencies", allow_empty=True)
        if self.substage_id in self.dependencies:
            raise ValueError("substage cannot depend on itself")

    @property
    def spec_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": VERSION,
            "substage_id": self.substage_id,
            "dependencies": list(self.dependencies),
            "purpose": self.purpose,
            "may_access_authority": self.may_access_authority,
            "produces_outcome": self.produces_outcome,
        }
        if include_id:
            value["spec_id"] = self.spec_id
        return value


@dataclass(frozen=True)
class FrozenGate:
    gate_id: str
    substage_id: str
    metric_name: str
    threshold: float
    direction: GateDirection
    prerequisites: Tuple[str, ...]
    failure_disposition: GateFailureDisposition
    reason: str

    def __post_init__(self) -> None:
        if not all((self.gate_id, self.substage_id, self.metric_name, self.reason)):
            raise ValueError("frozen substage gate is incomplete")
        if not math.isfinite(self.threshold):
            raise ValueError("substage gate threshold must be finite")
        _unique(self.prerequisites, "gate prerequisites")

    def evaluate(
        self,
        *,
        metric_value: float,
        prerequisite_checks: Mapping[str, bool],
        evidence_ids: Sequence[str],
    ) -> "GateResult":
        if not math.isfinite(metric_value):
            raise ValueError("substage gate metric must be finite")
        if set(prerequisite_checks) != set(self.prerequisites):
            raise ValueError("substage gate prerequisite contract changed")
        evidence = _unique(evidence_ids, "gate evidence")
        prerequisites_passed = all(
            bool(prerequisite_checks[key]) for key in self.prerequisites
        )
        if self.direction == GateDirection.AT_LEAST:
            metric_passed = metric_value >= self.threshold
        else:
            metric_passed = metric_value <= self.threshold
        passed = prerequisites_passed and metric_passed
        disposition = (
            None
            if passed
            else GateFailureDisposition.INVALIDATE
            if not prerequisites_passed
            else self.failure_disposition
        )
        return GateResult(
            gate_id=self.gate_id,
            substage_id=self.substage_id,
            metric_name=self.metric_name,
            metric_value=float(metric_value),
            threshold=self.threshold,
            direction=self.direction,
            prerequisite_checks=dict(sorted(prerequisite_checks.items())),
            passed=passed,
            failure_disposition=disposition,
            evidence_ids=evidence,
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": VERSION,
            "gate_id": self.gate_id,
            "substage_id": self.substage_id,
            "metric_name": self.metric_name,
            "threshold": self.threshold,
            "direction": self.direction.value,
            "prerequisites": list(self.prerequisites),
            "failure_disposition": self.failure_disposition.value,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class GateResult:
    gate_id: str
    substage_id: str
    metric_name: str
    metric_value: float
    threshold: float
    direction: GateDirection
    prerequisite_checks: Mapping[str, bool]
    passed: bool
    failure_disposition: GateFailureDisposition | None
    evidence_ids: Tuple[str, ...]

    @property
    def result_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": VERSION,
            "gate_id": self.gate_id,
            "substage_id": self.substage_id,
            "metric_name": self.metric_name,
            "metric_value": self.metric_value,
            "threshold": self.threshold,
            "direction": self.direction.value,
            "prerequisite_checks": dict(sorted(self.prerequisite_checks.items())),
            "passed": self.passed,
            "failure_disposition": (
                None
                if self.failure_disposition is None
                else self.failure_disposition.value
            ),
            "evidence_ids": list(self.evidence_ids),
        }
        if include_id:
            value["result_id"] = self.result_id
        return value


@dataclass(frozen=True)
class SubstageCompletion:
    substage_id: str
    spec_id: str
    output_artifact_ids: Tuple[str, ...]
    usage: ResourceUsage
    gate_result: GateResult | None = None

    def __post_init__(self) -> None:
        if not self.substage_id or not self.spec_id:
            raise ValueError("substage completion identity is incomplete")
        _unique(self.output_artifact_ids, "substage outputs")
        if self.gate_result is not None and self.gate_result.substage_id != self.substage_id:
            raise ValueError("substage completion carries another gate result")

    @property
    def completion_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": VERSION,
            "substage_id": self.substage_id,
            "spec_id": self.spec_id,
            "output_artifact_ids": list(self.output_artifact_ids),
            "usage": self.usage.as_dict(),
            "gate_result": (
                None if self.gate_result is None else self.gate_result.as_dict()
            ),
        }
        if include_id:
            value["completion_id"] = self.completion_id
        return value


class FailFastSubstageSchedule:
    """A deterministic DAG that evaluates sufficient gates before scheduling dependents."""

    def __init__(
        self,
        specs: Sequence[SubstageSpec],
        gates: Sequence[FrozenGate],
    ) -> None:
        self.specs = tuple(specs)
        self.gates = tuple(gates)
        if not self.specs:
            raise ValueError("substage schedule requires specifications")
        spec_ids = _unique(
            [spec.substage_id for spec in self.specs], "substage identifiers"
        )
        known = set(spec_ids)
        if any(
            dependency not in known
            for spec in self.specs
            for dependency in spec.dependencies
        ):
            raise ValueError("substage schedule has an unknown dependency")
        gate_substages = _unique(
            [gate.substage_id for gate in self.gates],
            "gate substages",
            allow_empty=True,
        )
        if not set(gate_substages).issubset(known):
            raise ValueError("substage gate references an unknown substage")
        self._by_id = {spec.substage_id: spec for spec in self.specs}
        self._gate_by_substage = {gate.substage_id: gate for gate in self.gates}
        self._completions: Dict[str, SubstageCompletion] = {}
        self._status = ScheduleStatus.ACTIVE
        self._terminal_gate_result: GateResult | None = None
        self._assert_acyclic()

    def _assert_acyclic(self) -> None:
        visited = set()
        active = set()

        def visit(substage_id: str) -> None:
            if substage_id in active:
                raise ValueError("substage schedule contains a dependency cycle")
            if substage_id in visited:
                return
            active.add(substage_id)
            for dependency in self._by_id[substage_id].dependencies:
                visit(dependency)
            active.remove(substage_id)
            visited.add(substage_id)

        for substage_id in self._by_id:
            visit(substage_id)

    @property
    def status(self) -> ScheduleStatus:
        return self._status

    @property
    def terminal_gate_result(self) -> GateResult | None:
        return self._terminal_gate_result

    @property
    def completions(self) -> Tuple[SubstageCompletion, ...]:
        return tuple(
            self._completions[spec.substage_id]
            for spec in self.specs
            if spec.substage_id in self._completions
        )

    @property
    def total_usage(self) -> ResourceUsage:
        result = ResourceUsage()
        for completion in self.completions:
            result = result.plus(completion.usage)
        return result

    def next_runnable(self) -> SubstageSpec | None:
        if self._status != ScheduleStatus.ACTIVE:
            return None
        completed = set(self._completions)
        for spec in self.specs:
            if spec.substage_id in completed:
                continue
            if set(spec.dependencies).issubset(completed):
                return spec
        if len(completed) == len(self.specs):
            self._status = ScheduleStatus.COMPLETE
            return None
        raise ValueError("active substage schedule is dependency-blocked")

    def record_completion(
        self,
        substage_id: str,
        *,
        output_artifact_ids: Sequence[str],
        usage: ResourceUsage,
        metric_value: float | None = None,
        prerequisite_checks: Mapping[str, bool] | None = None,
        gate_evidence_ids: Sequence[str] = (),
    ) -> SubstageCompletion:
        if self._status != ScheduleStatus.ACTIVE:
            raise ValueError("cannot complete a terminal substage schedule")
        expected = self.next_runnable()
        if expected is None or expected.substage_id != substage_id:
            raise ValueError("substage completion violates frozen dependency order")
        gate = self._gate_by_substage.get(substage_id)
        if gate is None:
            if metric_value is not None or prerequisite_checks is not None or gate_evidence_ids:
                raise ValueError("ungated substage supplied gate material")
            result = None
        else:
            if metric_value is None or prerequisite_checks is None:
                raise ValueError("gated substage omitted immediate gate evaluation")
            result = gate.evaluate(
                metric_value=metric_value,
                prerequisite_checks=prerequisite_checks,
                evidence_ids=gate_evidence_ids,
            )
        completion = SubstageCompletion(
            substage_id=substage_id,
            spec_id=expected.spec_id,
            output_artifact_ids=tuple(str(value) for value in output_artifact_ids),
            usage=usage,
            gate_result=result,
        )
        self._completions[substage_id] = completion
        if result is not None and not result.passed:
            self._terminal_gate_result = result
            dispositions = {
                GateFailureDisposition.INVALIDATE: ScheduleStatus.INVALID,
                GateFailureDisposition.REPAIR_IMPLEMENTATION: ScheduleStatus.REPAIR_REQUIRED,
                GateFailureDisposition.AMEND_PROTOCOL: (
                    ScheduleStatus.PROTOCOL_AMENDMENT_REQUIRED
                ),
                GateFailureDisposition.UPDATE_CAUSAL_THEORY: (
                    ScheduleStatus.SCIENTIFIC_STOP
                ),
            }
            self._status = dispositions[result.failure_disposition]
        elif len(self._completions) == len(self.specs):
            self._status = ScheduleStatus.COMPLETE
        return completion

    @property
    def schedule_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": VERSION,
            "specs": [spec.as_dict() for spec in self.specs],
            "gates": [gate.as_dict() for gate in self.gates],
            "completions": [item.as_dict() for item in self.completions],
            "status": self.status.value,
            "terminal_gate_result": (
                None
                if self.terminal_gate_result is None
                else self.terminal_gate_result.as_dict()
            ),
            "total_usage": self.total_usage.as_dict(),
        }
        if include_id:
            value["schedule_id"] = self.schedule_id
        return value


__all__ = [
    "VERSION",
    "FailFastSubstageSchedule",
    "FrozenGate",
    "GateDirection",
    "GateFailureDisposition",
    "GateResult",
    "ScheduleStatus",
    "SubstageCompletion",
    "SubstageSpec",
]
