from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.core.provenance import bytes_sha256


TERMINAL_CONTROL_ADJUDICATION_VERSION = "terminal-control-adjudication-v1"
EXPECTED_PANEL_ID = "a6f6057c4a0c32eebc848e07f7cfda642310c834e33efdd510a76a7c948eaf4b"


def _identified(path: Path, key: str) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = dict(value)
    identity = body.pop(key, None)
    if not identity or content_digest(body) != identity:
        raise ValueError(f"{path} has an invalid {key}")
    return value


def build_terminal_control_adjudication(project_root: Path) -> Mapping[str, Any]:
    root = Path(project_root).resolve()
    panel_path = (
        root
        / "runs/autonomy_closure_v1/adaptive_causal_development_panel_v1"
        / "artifacts/manifests/adaptive-causal-development-pilot-v3.json"
    )
    doc_path = (
        root
        / "docs/autonomous-scientist-prefreeze-terminal-control-adjudication-2026-09-09.md"
    )
    implementation_path = root / "src/scientist/autonomy/adaptive_three_arm_v1.py"
    runner_path = root / "src/scientist/autonomy/adaptive_codex_runner_v1.py"
    test_path = root / "tests/test_autonomy_adaptive_three_arm_v1.py"
    for path in (panel_path, doc_path, implementation_path, runner_path, test_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    panel = _identified(panel_path, "panel_id")
    if panel["panel_id"] != EXPECTED_PANEL_ID:
        raise ValueError("terminal correction is not bound to the adjudicated replay")
    null_result = panel["results"]["task-03|authority_separated_scientist"]
    ambiguous_result = panel["results"]["task-04|authority_separated_scientist"]
    scientist_reference_failure = panel["failures"].get(
        "task-05|authority_separated_scientist", {}
    )
    if not (
        panel["development_only"] is True
        and panel["permanently_excluded"] is True
        and panel["rates"]["pooled_controls"] == 0.5
        and panel["rates"]["authority_separated_scientist"] == 0.5
        and null_result["certificate"]["accepted"] is True
        and null_result["validator_calls"] == 3
        and null_result["token_usage"]["total_tokens"] > 128_000
        and ambiguous_result["certificate"]["accepted"] is True
        and ambiguous_result["validator_calls"] == 3
        and ambiguous_result["token_usage"]["total_tokens"] > 128_000
        and "unknown or ambiguous hypothesis reference"
        in scientist_reference_failure.get("message", "")
    ):
        raise ValueError("replay does not establish the terminal-control defects")
    for namespace in (
        "prospective_v3_confirmatory",
        "prospective_v4_confirmatory",
        "prospective_v5_confirmatory",
        "prospective_v6_confirmatory",
    ):
        if (root / "runs/autonomy_closure_v1" / namespace).exists():
            raise ValueError("confirmatory state exists; implementation correction is too late")
    body: Dict[str, Any] = {
        "version": TERMINAL_CONTROL_ADJUDICATION_VERSION,
        "status": "prefreeze_terminal_control_correction_installed",
        "source_panel_id": panel["panel_id"],
        "failure_classifications": [
            "generic_schema_identifier_transcription",
            "terminal_public_state_not_controlling_measurement_policy",
        ],
        "correction": {
            "task_specific_shared_schema_enums": True,
            "public_trace_terminal_recommendation_shared_by_all_arms": True,
            "scientist_redundant_measurement_withheld_after_terminal_state": True,
            "model_revalidation_still_required": True,
            "scientific_hypothesis_silently_substituted": False,
            "hidden_authority_access_added": False,
        },
        "adjudication_path": str(doc_path.relative_to(root)),
        "adjudication_sha256": bytes_sha256(doc_path.read_bytes()),
        "source_hashes": {
            str(path.relative_to(root)): bytes_sha256(path.read_bytes())
            for path in (implementation_path, runner_path, test_path)
        },
        "fresh_excluded_replay_required": True,
        "implementation_freeze_complete": False,
        "confirmatory_execution_authorized": False,
        "scientific_result_claimed": False,
        "nature_central_claim_authorized": False,
    }
    return {**body, "adjudication_id": content_digest(body)}
