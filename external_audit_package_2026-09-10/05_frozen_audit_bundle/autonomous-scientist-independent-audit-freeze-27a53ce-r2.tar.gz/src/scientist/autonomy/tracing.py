from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.core.artifacts import content_digest


COMPONENT_TRACE_VERSION = "scientist-component-execution-trace-v1"


class InvocationKind(str, Enum):
    MODEL = "model"
    TOOL = "tool"


@dataclass(frozen=True)
class ExternalInvocation:
    kind: InvocationKind
    operation: str
    actor: ActorIdentity
    authority_scope: AuthorityScope
    input_artifact_ids: Tuple[str, ...]
    output_artifact_ids: Tuple[str, ...]
    usage: ResourceUsage

    def __post_init__(self) -> None:
        if not self.operation:
            raise ValueError("external invocation operation must not be empty")
        if not self.actor.permits(self.authority_scope):
            raise ValueError("external invocation actor exceeded its authority")
        if self.kind == InvocationKind.MODEL:
            if self.actor.kind != ActorKind.PROPOSAL_MODEL:
                raise ValueError("model invocation requires a proposal-model actor")
            if self.usage.model_calls != 1 or self.usage.tool_calls != 0:
                raise ValueError("model invocation must charge exactly one model call")
        if self.kind == InvocationKind.TOOL:
            if self.actor.kind != ActorKind.TOOL_RUNTIME:
                raise ValueError("tool invocation requires a tool-runtime actor")
            if self.usage.tool_calls != 1 or self.usage.model_calls != 0:
                raise ValueError("tool invocation must charge exactly one tool call")

    @property
    def invocation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": COMPONENT_TRACE_VERSION,
            "kind": self.kind.value,
            "operation": self.operation,
            "actor": self.actor.as_dict(),
            "authority_scope": self.authority_scope.value,
            "input_artifact_ids": list(self.input_artifact_ids),
            "output_artifact_ids": list(self.output_artifact_ids),
            "usage": self.usage.as_dict(),
        }
        if include_id:
            value["invocation_id"] = self.invocation_id
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ExternalInvocation":
        if value.get("version") != COMPONENT_TRACE_VERSION:
            raise ValueError("unsupported external-invocation trace version")
        actor_value = value["actor"]
        actor = ActorIdentity(
            actor_ref=str(actor_value["actor_ref"]),
            kind=ActorKind(actor_value["kind"]),
        )
        if actor_value.get("inside_autonomy_boundary") != actor.inside_autonomy_boundary:
            raise ValueError("external invocation boundary declaration changed")
        result = cls(
            kind=InvocationKind(value["kind"]),
            operation=str(value["operation"]),
            actor=actor,
            authority_scope=AuthorityScope(value["authority_scope"]),
            input_artifact_ids=tuple(str(item) for item in value["input_artifact_ids"]),
            output_artifact_ids=tuple(str(item) for item in value["output_artifact_ids"]),
            usage=ResourceUsage.from_dict(value["usage"]),
        )
        if value.get("invocation_id") != result.invocation_id:
            raise ValueError("external invocation identity mismatch")
        return result


@dataclass(frozen=True)
class ComponentExecutionTrace:
    action_id: str
    component_ref: str
    invocations: Tuple[ExternalInvocation, ...]
    complete: bool
    undeclared_external_access: bool
    sealed_authority_accessed: bool

    def __post_init__(self) -> None:
        if not self.action_id or not self.component_ref:
            raise ValueError("component trace identity is incomplete")
        identities = tuple(item.invocation_id for item in self.invocations)
        if len(identities) != len(set(identities)):
            raise ValueError("component trace contains duplicate invocations")
        if not self.complete:
            raise ValueError("an incomplete component trace cannot advance state")
        if self.undeclared_external_access:
            raise ValueError("undeclared external access prevents autonomy closure")
        if self.sealed_authority_accessed:
            raise ValueError("component accessed sealed scientific authority")

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": COMPONENT_TRACE_VERSION,
            "action_id": self.action_id,
            "component_ref": self.component_ref,
            "invocations": [item.as_dict() for item in self.invocations],
            "complete": self.complete,
            "undeclared_external_access": self.undeclared_external_access,
            "sealed_authority_accessed": self.sealed_authority_accessed,
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value

    @classmethod
    def deterministic(
        cls,
        action_id: str,
        component_ref: str,
    ) -> "ComponentExecutionTrace":
        return cls(
            action_id=action_id,
            component_ref=component_ref,
            invocations=(),
            complete=True,
            undeclared_external_access=False,
            sealed_authority_accessed=False,
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ComponentExecutionTrace":
        if value.get("version") != COMPONENT_TRACE_VERSION:
            raise ValueError("unsupported component execution-trace version")
        result = cls(
            action_id=str(value["action_id"]),
            component_ref=str(value["component_ref"]),
            invocations=tuple(
                ExternalInvocation.from_dict(item)
                for item in value.get("invocations", ())
            ),
            complete=bool(value["complete"]),
            undeclared_external_access=bool(value["undeclared_external_access"]),
            sealed_authority_accessed=bool(value["sealed_authority_accessed"]),
        )
        if value.get("trace_id") != result.trace_id:
            raise ValueError("component execution-trace identity mismatch")
        return result


def total_invocation_usage(
    invocations: Sequence[ExternalInvocation],
) -> ResourceUsage:
    total = ResourceUsage()
    for invocation in invocations:
        total = total.plus(invocation.usage)
    return total
