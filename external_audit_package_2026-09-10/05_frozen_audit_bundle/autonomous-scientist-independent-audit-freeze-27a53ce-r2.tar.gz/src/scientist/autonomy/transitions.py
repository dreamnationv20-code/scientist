from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


AUTONOMY_TRANSITION_VERSION = "scientist-autonomy-transition-v1"


def _unique(values: Sequence[str], label: str) -> Tuple[str, ...]:
    normalized = tuple(str(value) for value in values)
    if not normalized or not all(normalized):
        raise ValueError("%s must contain non-empty values" % label)
    if len(set(normalized)) != len(normalized):
        raise ValueError("%s must be unique" % label)
    return normalized


class FailureClass(str, Enum):
    NONE = "none"
    INFRASTRUCTURE = "infrastructure"
    IMPLEMENTATION = "implementation"
    INTERFACE = "interface"
    PROTOCOL = "protocol"
    MEASUREMENT = "measurement"
    SCIENTIFIC_NULL = "scientific_null"
    REPRESENTATION_EXHAUSTION = "representation_exhaustion"
    EXTERNAL_DEPENDENCY = "external_dependency"


class RecoveryAction(str, Enum):
    CONTINUE = "continue"
    EXACT_RETRY = "exact_retry"
    REPAIR_IMPLEMENTATION = "repair_implementation"
    REPAIR_INTERFACE = "repair_interface"
    AMEND_PROTOCOL = "amend_protocol"
    RECALIBRATE_MEASUREMENT = "recalibrate_measurement"
    UPDATE_CAUSAL_THEORY = "update_causal_theory"
    CHANGE_REPRESENTATION = "change_representation"
    PARK_BRANCH = "park_branch"
    REQUEST_EXTERNAL_AUTHORITY = "request_external_authority"


@dataclass(frozen=True)
class TransitionCase:
    """Candidate-visible evidence at one scientific decision boundary."""

    case_ref: str
    phase: str
    question: str
    observations: Tuple[str, ...]
    available_actions: Tuple[RecoveryAction, ...]
    protected_invariants: Tuple[str, ...]
    evidence_refs: Tuple[str, ...]
    retrospective: bool
    domain: str

    def __post_init__(self) -> None:
        required = (self.case_ref, self.phase, self.question, self.domain)
        if not all(required):
            raise ValueError("transition case identity is incomplete")
        _unique(self.observations, "transition observations")
        _unique(tuple(item.value for item in self.available_actions), "available actions")
        _unique(self.protected_invariants, "protected invariants")
        _unique(self.evidence_refs, "transition evidence")

    @property
    def case_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": AUTONOMY_TRANSITION_VERSION,
            "case_ref": self.case_ref,
            "phase": self.phase,
            "question": self.question,
            "observations": list(self.observations),
            "available_actions": [item.value for item in self.available_actions],
            "protected_invariants": list(self.protected_invariants),
            "evidence_refs": list(self.evidence_refs),
            "retrospective": self.retrospective,
            "domain": self.domain,
        }
        if include_id:
            value["case_id"] = self.case_id
        return value


@dataclass(frozen=True)
class TransitionAuthority:
    """Sequestered adjudication contract, never supplied to the candidate."""

    case_id: str
    primary_failure_class: FailureClass
    acceptable_secondary_classes: Tuple[FailureClass, ...]
    acceptable_actions: Tuple[RecoveryAction, ...]
    forbidden_actions: Tuple[RecoveryAction, ...]
    required_invariants: Tuple[str, ...]
    required_evidence_refs: Tuple[str, ...]
    adjudication_ref: str

    def __post_init__(self) -> None:
        if not self.case_id or not self.adjudication_ref:
            raise ValueError("transition authority identity is incomplete")
        _unique(
            tuple(item.value for item in self.acceptable_actions),
            "acceptable actions",
        )
        if set(self.acceptable_actions).intersection(self.forbidden_actions):
            raise ValueError("an action cannot be both acceptable and forbidden")
        _unique(self.required_invariants, "required invariants")
        _unique(self.required_evidence_refs, "required evidence")

    @property
    def authority_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": AUTONOMY_TRANSITION_VERSION,
            "case_id": self.case_id,
            "primary_failure_class": self.primary_failure_class.value,
            "acceptable_secondary_classes": [
                item.value for item in self.acceptable_secondary_classes
            ],
            "acceptable_actions": [item.value for item in self.acceptable_actions],
            "forbidden_actions": [item.value for item in self.forbidden_actions],
            "required_invariants": list(self.required_invariants),
            "required_evidence_refs": list(self.required_evidence_refs),
            "adjudication_ref": self.adjudication_ref,
        }
        if include_id:
            value["authority_id"] = self.authority_id
        return value


@dataclass(frozen=True)
class TransitionDecision:
    case_id: str
    primary_failure_class: FailureClass
    secondary_failure_classes: Tuple[FailureClass, ...]
    action: RecoveryAction
    rationale: str
    cited_evidence_refs: Tuple[str, ...]
    preserved_invariants: Tuple[str, ...]
    changed_assumptions: Tuple[str, ...]
    actor_ref: str

    def __post_init__(self) -> None:
        if not all((self.case_id, self.rationale, self.actor_ref)):
            raise ValueError("transition decision is incomplete")
        if self.primary_failure_class in self.secondary_failure_classes:
            raise ValueError("primary failure class cannot be repeated as secondary")
        if len(set(self.secondary_failure_classes)) != len(
            self.secondary_failure_classes
        ):
            raise ValueError("secondary failure classes must be unique")
        _unique(self.cited_evidence_refs, "decision evidence")
        _unique(self.preserved_invariants, "decision invariants")
        if self.changed_assumptions:
            _unique(self.changed_assumptions, "changed assumptions")

    @property
    def decision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": AUTONOMY_TRANSITION_VERSION,
            "case_id": self.case_id,
            "primary_failure_class": self.primary_failure_class.value,
            "secondary_failure_classes": [
                item.value for item in self.secondary_failure_classes
            ],
            "action": self.action.value,
            "rationale": self.rationale,
            "cited_evidence_refs": list(self.cited_evidence_refs),
            "preserved_invariants": list(self.preserved_invariants),
            "changed_assumptions": list(self.changed_assumptions),
            "actor_ref": self.actor_ref,
        }
        if include_id:
            value["decision_id"] = self.decision_id
        return value


@dataclass(frozen=True)
class TransitionScore:
    case_id: str
    classification_correct: bool
    action_acceptable: bool
    forbidden_action_avoided: bool
    invariant_recall: float
    evidence_recall: float

    @property
    def passed(self) -> bool:
        return all(
            (
                self.classification_correct,
                self.action_acceptable,
                self.forbidden_action_avoided,
                self.invariant_recall == 1.0,
                self.evidence_recall == 1.0,
            )
        )

    @property
    def score(self) -> float:
        binary = (
            float(self.classification_correct)
            + float(self.action_acceptable)
            + float(self.forbidden_action_avoided)
        )
        return (binary + self.invariant_recall + self.evidence_recall) / 5.0

    def as_dict(self) -> Mapping[str, Any]:
        return {
            "version": AUTONOMY_TRANSITION_VERSION,
            "case_id": self.case_id,
            "classification_correct": self.classification_correct,
            "action_acceptable": self.action_acceptable,
            "forbidden_action_avoided": self.forbidden_action_avoided,
            "invariant_recall": self.invariant_recall,
            "evidence_recall": self.evidence_recall,
            "passed": self.passed,
            "score": self.score,
        }


def _recall(required: Sequence[str], observed: Sequence[str]) -> float:
    required_set = set(required)
    if not required_set:
        return 1.0
    return len(required_set.intersection(observed)) / len(required_set)


def evaluate_transition_decision(
    case: TransitionCase,
    authority: TransitionAuthority,
    decision: TransitionDecision,
) -> TransitionScore:
    if authority.case_id != case.case_id or decision.case_id != case.case_id:
        raise ValueError("transition case, authority, and decision disagree")
    if decision.action not in case.available_actions:
        raise ValueError("decision selected an action unavailable to the candidate")
    classification_correct = (
        decision.primary_failure_class == authority.primary_failure_class
    )
    action_acceptable = decision.action in authority.acceptable_actions
    forbidden_action_avoided = decision.action not in authority.forbidden_actions
    return TransitionScore(
        case_id=case.case_id,
        classification_correct=classification_correct,
        action_acceptable=action_acceptable,
        forbidden_action_avoided=forbidden_action_avoided,
        invariant_recall=_recall(
            authority.required_invariants,
            decision.preserved_invariants,
        ),
        evidence_recall=_recall(
            authority.required_evidence_refs,
            decision.cited_evidence_refs,
        ),
    )
