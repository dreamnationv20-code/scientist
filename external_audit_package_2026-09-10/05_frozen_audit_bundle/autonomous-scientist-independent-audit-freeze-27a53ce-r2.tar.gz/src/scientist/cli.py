from __future__ import annotations

import argparse
import datetime as dt
import json
import platform
from pathlib import Path
from typing import Sequence

from scientist import __version__
from scientist.confirmation.binpacking import confirm_frozen_candidates
from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.core.provenance import python_source_tree_digest
from scientist.domains.binpacking.equivalence import behaviour_fingerprint
from scientist.domains.binpacking.benchmark_conformance import (
    verify_funsearch_benchmark_conformance,
)
from scientist.domains.binpacking.evaluator import (
    evaluate_heuristic,
    prepare_optima,
)
from scientist.domains.binpacking.goal_program import (
    BinPackingGoalRunConfig,
    continue_goal_program,
    run_clean_goal_program,
)
from scientist.domains.binpacking.discovery_reset import (
    DiscoveryResetConfig,
    run_discovery_reset,
)
from scientist.domains.binpacking.code_policy import (
    CodexPacketCodeModel,
    OpenAIResponsesCodeModel,
)
from scientist.domains.binpacking.stochastic_value import StochasticValueConfig
from scientist.domains.binpacking.generators import GENERATORS, generate_suite
from scientist.domains.binpacking.heuristics import baseline_heuristics
from scientist.domains.binpacking.orlib import (
    load_orlib_corpus,
    load_source_manifest,
    verify_orlib_files,
)
from scientist.domains.binpacking.programs import program_from_dict
from scientist.search.evolution import SearchConfig, run_evolutionary_search
from scientist.studies.active_policy import (
    ActiveStudyConfig,
    run_active_policy_study,
)
from scientist.studies.adversarial_search import (
    AdversarialSearchConfig,
    run_adversarial_search,
)
from scientist.studies.incumbent_repair import (
    IncumbentRepairConfig,
    run_incumbent_repair_study,
)
from scientist.studies.regime_search import (
    MatchedRegimeSearchConfig,
    run_matched_regime_search,
)
from scientist.studies.repair_replication import (
    RepairReplicationConfig,
    run_repair_replication,
)
from scientist.studies.three_island_campaign import (
    ThreeIslandCampaignConfig,
    run_three_island_campaign,
)
from scientist.studies.campaign_replication import (
    CampaignReplicationConfig,
    run_campaign_replication,
)
from scientist.program.goal_graph_runtime import GoalGraphRuntime
from scientist.scientific_runtime import (
    ScientificCommandOutcome,
    ScientificCommandRuntime,
)
from scientist.domains.registry import default_domain_registry
from scientist.domains.cognitive_core.goal_program import (
    build_control_plane as build_cognitive_goal_control_plane,
    fresh_goal_graph_spec,
)


def _new_run_id(identity: object) -> tuple[str, str]:
    created_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    run_id = created_at.replace(":", "").replace("+00:00", "Z")
    run_id += "-" + content_digest(
        {"created_at": created_at, "identity": identity}
    )[:10]
    return run_id, created_at


def _benchmark(args: argparse.Namespace) -> int:
    families = tuple(args.families or sorted(GENERATORS))
    seeds = tuple(range(args.seed_start, args.seed_start + args.seed_count))
    instances = generate_suite(
        families=families,
        seeds=seeds,
        length=args.length,
        capacity=args.capacity,
    )
    store = ArtifactStore(Path(args.output))

    spec = {
        "schema": 1,
        "domain": "online_1d_bin_packing",
        "suite": {
            "generator_version": 1,
            "families": list(families),
            "seeds": list(seeds),
            "length": args.length,
            "capacity": args.capacity,
        },
        "heuristics": sorted(baseline_heuristics()),
    }
    spec_digest = store.put("experiment_spec", spec)
    instance_digest = store.put(
        "instance_suite",
        [instance.as_dict() for instance in instances],
    )

    reports = []
    for heuristic in baseline_heuristics().values():
        report = evaluate_heuristic(heuristic, instances)
        report_value = report.as_dict()
        report_digest = store.put("evaluation_report", report_value)
        reports.append(
            {
                "heuristic": heuristic.name,
                "report_digest": report_digest,
                "mean_regret": report.mean_regret,
                "p95_regret": report.p95_regret,
                "worst_regret": report.worst_regret,
            }
        )

    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "instance_digest": instance_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "spec_digest": spec_digest,
        "instance_digest": instance_digest,
        "reports": sorted(reports, key=lambda report: report["heuristic"]),
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print()
    print("%-14s %12s %12s %12s" % ("heuristic", "mean regret", "p95 regret", "worst"))
    for report in sorted(reports, key=lambda value: value["mean_regret"]):
        print(
            "%-14s %12.3f %12.3f %12d"
            % (
                report["heuristic"],
                report["mean_regret"],
                report["p95_regret"],
                report["worst_regret"],
            )
        )
    return 0


def _binpacking_conformance(args: argparse.Namespace) -> int:
    report = verify_funsearch_benchmark_conformance(
        Path(args.orlib_dir)
    )
    print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
    return 0


def _search(args: argparse.Namespace) -> int:
    families = tuple(args.families or sorted(GENERATORS))
    development_seeds = tuple(
        range(
            args.development_seed_start,
            args.development_seed_start + args.development_seed_count,
        )
    )
    validation_seeds = tuple(
        range(
            args.validation_seed_start,
            args.validation_seed_start + args.validation_seed_count,
        )
    )
    development_instances = generate_suite(
        families=families,
        seeds=development_seeds,
        length=args.length,
        capacity=args.capacity,
    )
    validation_instances = generate_suite(
        families=families,
        seeds=validation_seeds,
        length=args.length,
        capacity=args.capacity,
    )
    equivalence_seeds = tuple(
        range(
            args.equivalence_seed_start,
            args.equivalence_seed_start + args.equivalence_seed_count,
        )
    )
    equivalence_instances = generate_suite(
        families=families,
        seeds=equivalence_seeds,
        length=max(args.length, args.equivalence_length),
        capacity=args.capacity,
    )
    store = ArtifactStore(Path(args.output))
    config = SearchConfig(
        seed=args.search_seed,
        evaluation_budget=args.budget,
        initial_random=args.initial_random,
        crossover_probability=args.crossover_probability,
        max_expression_depth=args.max_depth,
        max_expression_nodes=args.max_nodes,
        complexity_penalty=args.complexity_penalty,
    )
    spec = {
        "schema": 1,
        "kind": "fixed_budget_evolutionary_baseline",
        "domain": "online_1d_bin_packing",
        "search": config.as_dict(),
        "development_suite": {
            "generator_version": 1,
            "families": list(families),
            "seeds": list(development_seeds),
            "length": args.length,
            "capacity": args.capacity,
        },
        "validation_suite": {
            "generator_version": 1,
            "families": list(families),
            "seeds": list(validation_seeds),
            "length": args.length,
            "capacity": args.capacity,
        },
        "equivalence_probe_suite": {
            "generator_version": 1,
            "families": list(families),
            "seeds": list(equivalence_seeds),
            "length": max(args.length, args.equivalence_length),
            "capacity": args.capacity,
        },
    }
    spec_digest = store.put("search_spec", spec)
    development_digest = store.put(
        "development_instance_suite",
        [instance.as_dict() for instance in development_instances],
    )
    validation_digest = store.put(
        "validation_instance_suite",
        [instance.as_dict() for instance in validation_instances],
    )
    equivalence_digest = store.put(
        "equivalence_probe_instance_suite",
        [instance.as_dict() for instance in equivalence_instances],
    )

    outcome = run_evolutionary_search(
        config,
        development_instances,
        artifact_store=store,
    )
    validation_optima = prepare_optima(validation_instances)
    validation_reports = []
    for heuristic in baseline_heuristics().values():
        report = evaluate_heuristic(
            heuristic,
            validation_instances,
            optima=validation_optima,
        )
        digest = store.put("validation_evaluation_report", report.as_dict())
        validation_reports.append(
            {
                "heuristic": heuristic.name,
                "report_digest": digest,
                "mean_regret": report.mean_regret,
                "p95_regret": report.p95_regret,
                "worst_regret": report.worst_regret,
            }
        )

    best_validation = evaluate_heuristic(
        outcome.best.program,
        validation_instances,
        optima=validation_optima,
    )
    best_validation_digest = store.put(
        "validation_evaluation_report",
        best_validation.as_dict(),
    )
    validation_reports.append(
        {
            "heuristic": outcome.best.program.name,
            "candidate_id": outcome.best.program.candidate_id,
            "report_digest": best_validation_digest,
            "mean_regret": best_validation.mean_regret,
            "p95_regret": best_validation.p95_regret,
            "worst_regret": best_validation.worst_regret,
        }
    )

    best_fingerprint = behaviour_fingerprint(
        outcome.best.program,
        equivalence_instances,
    )
    baseline_fingerprints = {
        name: behaviour_fingerprint(heuristic, equivalence_instances)
        for name, heuristic in baseline_heuristics().items()
    }
    equivalent_baselines = sorted(
        name
        for name, fingerprint in baseline_fingerprints.items()
        if fingerprint == best_fingerprint
    )
    equivalence_report = {
        "schema": 1,
        "probe_suite_digest": equivalence_digest,
        "candidate_id": outcome.best.program.candidate_id,
        "candidate_fingerprint": best_fingerprint,
        "baseline_fingerprints": baseline_fingerprints,
        "equivalent_baselines": equivalent_baselines,
        "scope": "exact placement decisions on the recorded probe suite",
    }
    equivalence_report_digest = store.put(
        "behavioural_equivalence_report",
        equivalence_report,
    )

    search_summary = outcome.as_dict()
    search_summary["best_validation_report_digest"] = best_validation_digest
    search_summary["equivalence_report_digest"] = equivalence_report_digest
    search_summary["equivalent_baselines"] = equivalent_baselines
    search_summary_digest = store.put("evolutionary_search_summary", search_summary)
    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "search_summary_digest": search_summary_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "spec_digest": spec_digest,
        "development_suite_digest": development_digest,
        "validation_suite_digest": validation_digest,
        "equivalence_probe_suite_digest": equivalence_digest,
        "search_summary_digest": search_summary_digest,
        "equivalence_report_digest": equivalence_report_digest,
        "best_candidate_id": outcome.best.program.candidate_id,
        "best_candidate_artifact": outcome.best.candidate_artifact,
        "validation_reports": sorted(
            validation_reports,
            key=lambda report: report["heuristic"],
        ),
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("Evaluated:", len(outcome.evaluated))
    print("Archive cells:", len(outcome.archive))
    print("Duplicate attempts:", outcome.duplicate_attempts)
    print()
    print("Best candidate:", outcome.best.program.candidate_id)
    print("Expression:", outcome.best.program.expression.render())
    print("Complexity:", outcome.best.program.complexity)
    print(
        "Equivalent baselines on probe suite:",
        ", ".join(equivalent_baselines) if equivalent_baselines else "none",
    )
    print(
        "Development regret: mean %.3f, p95 %.3f, worst %d"
        % (
            outcome.best.report.mean_regret,
            outcome.best.report.p95_regret,
            outcome.best.report.worst_regret,
        )
    )
    print()
    print("Validation")
    print("%-24s %12s %12s %12s" % ("heuristic", "mean regret", "p95 regret", "worst"))
    for report in sorted(
        validation_reports,
        key=lambda value: (value["mean_regret"], value["heuristic"]),
    ):
        print(
            "%-24s %12.3f %12.3f %12d"
            % (
                report["heuristic"],
                report["mean_regret"],
                report["p95_regret"],
                report["worst_regret"],
            )
        )
    return 0


def _study(args: argparse.Namespace) -> int:
    families = tuple(args.families or sorted(GENERATORS))
    config = ActiveStudyConfig(
        families=families,
        selection_mode=args.selection_mode,
        pool_seed_start=args.pool_seed_start,
        pool_seed_count=args.pool_seed_count,
        length=args.length,
        capacity=args.capacity,
        evaluation_budget=args.budget,
        temperature=args.temperature,
        maximum_counterexamples=args.maximum_counterexamples,
    )
    store = ArtifactStore(Path(args.output))
    spec_digest = store.put(
        "active_policy_study_spec",
        {
            "schema": 1,
            "kind": "active_policy_discrimination",
            "config": config.as_dict(),
            "policies": sorted(baseline_heuristics()),
            "update_rule": (
                "normalized prior * exp(-temperature * cumulative_loss)"
            ),
        },
    )
    outcome = run_active_policy_study(
        config,
        baseline_heuristics(),
        artifact_store=store,
    )
    summary = outcome.as_dict()
    summary_digest = store.put("active_policy_study_summary", summary)
    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "summary_digest": summary_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "spec_digest": spec_digest,
        "study_summary_digest": summary_digest,
        "winner_hypothesis_id": outcome.winner.hypothesis_id,
        "exact_evaluations": outcome.exact_evaluations,
        "artifact_digests": dict(sorted(outcome.artifact_digests.items())),
    }
    manifest_path = store.write_manifest(run_id, manifest)
    names = {
        hypothesis.hypothesis_id: hypothesis.name
        for hypothesis in outcome.hypotheses
    }

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("Pool size:", len(outcome.rounds) + outcome.remaining_pool_size)
    print("Selection mode:", config.selection_mode)
    print("Selected probes:", len(outcome.rounds))
    print("Exact evaluations:", outcome.exact_evaluations)
    print("Discriminating probes:", outcome.discriminating_rounds)
    print("Final weight entropy: %.6f" % outcome.final_entropy)
    print()
    print("%-14s %16s %16s" % ("hypothesis", "cumulative loss", "final weight"))
    for bundle in sorted(
        outcome.bundles,
        key=lambda value: (-value.normalized_weight, value.hypothesis_id),
    ):
        print(
            "%-14s %16.3f %16.6f"
            % (
                names[bundle.hypothesis_id],
                bundle.cumulative_loss,
                bundle.normalized_weight,
            )
        )
    print()
    print("Winner:", names[outcome.winner.hypothesis_id])
    print("Minimized counterexamples:", len(outcome.counterexamples))
    for counterexample in outcome.counterexamples:
        print(
            "  %s < %s: items=%s, bins=%d<%d, optimum=%s"
            % (
                counterexample.better_name,
                counterexample.worse_name,
                list(counterexample.minimized_instance.items),
                counterexample.better_bin_count,
                counterexample.worse_bin_count,
                counterexample.optimum,
            )
        )
    return 0


def _regime_search(args: argparse.Namespace) -> int:
    families = tuple(args.families or sorted(GENERATORS))
    config = MatchedRegimeSearchConfig(
        families=families,
        length=args.length,
        validation_length=args.validation_length,
        sealed_length=args.sealed_length,
        capacity=args.capacity,
        reference_mode=args.reference_mode,
        development_seed_start=args.development_seed_start,
        development_seed_count=args.development_seed_count,
        validation_seed_start=args.validation_seed_start,
        validation_seed_count=args.validation_seed_count,
        sealed_seed_start=args.sealed_seed_start,
        sealed_seed_count=args.sealed_seed_count,
        equivalence_seed_start=args.equivalence_seed_start,
        evaluation_budget=args.budget,
        search_seed=args.search_seed,
        regime_emphasis=args.regime_emphasis,
        maximum_targeted_seeds=args.maximum_targeted_seeds,
    )
    store = ArtifactStore(Path(args.output))
    spec_digest = store.put(
        "matched_regime_search_spec",
        {
            "schema": 1,
            "kind": "m1_vs_m2_matched_regime_search",
            "config": config.as_dict(),
            "candidate_evaluations_per_method": args.budget,
            "novelty_policy": (
                "behavioural equivalence plus literature provenance"
            ),
        },
    )
    outcome = run_matched_regime_search(config, artifact_store=store)
    summary_digest = store.put(
        "matched_regime_search_summary",
        outcome.as_dict(),
    )
    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "summary_digest": summary_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "spec_digest": spec_digest,
        "summary_digest": summary_digest,
        "suite_digests": dict(sorted(outcome.suite_digests.items())),
        "artifact_digests": dict(sorted(outcome.artifact_digests.items())),
        "candidate_evaluations_per_method": args.budget,
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("Best Fit failing development instances:", len(
        outcome.failure_report.failing_instance_ids
    ))
    print("Discovered regimes:", len(outcome.failure_report.regimes))
    print("Targeted seed programs:", len(outcome.targeted_seeds))
    print()
    print("Top failure regimes")
    for regime in outcome.failure_report.regimes[:5]:
        print(
            "  %s failures=%d/%d regret=%d mean_min=%.3f"
            % (
                " | ".join(regime.key),
                regime.failure_count,
                regime.instance_count,
                regime.total_regret,
                regime.mean_min_item,
            )
        )
    print()
    print("%-20s %12s %12s %12s %20s" % (
        "method",
        "dev mean",
        "val mean",
        "sealed mean",
        "equivalent",
    ))
    rows = (
        (
            "best_fit",
            outcome.failure_report.evaluator_report.mean_regret,
            outcome.best_fit_validation.mean_regret,
            outcome.best_fit_sealed.mean_regret,
            "best_fit",
        ),
        *tuple(
            (
                name,
                float("nan"),
                outcome.known_reference_validation[name].mean_regret,
                outcome.known_reference_sealed[name].mean_regret,
                "literature",
            )
            for name in sorted(outcome.known_reference_validation)
        ),
        (
            outcome.baseline.method,
            outcome.baseline.search.best.report.mean_regret,
            outcome.baseline.validation.mean_regret,
            outcome.baseline.sealed.mean_regret,
            ",".join(outcome.baseline.equivalent_baselines) or "none",
        ),
        (
            outcome.targeted.method,
            outcome.targeted.search.best.report.mean_regret,
            outcome.targeted.validation.mean_regret,
            outcome.targeted.sealed.mean_regret,
            ",".join(outcome.targeted.equivalent_baselines) or "none",
        ),
    )
    for row in rows:
        print(
            "%-20s %12.3f %12.3f %12.3f %20s" % row
        )
    print()
    print("M1 expression:", outcome.baseline.search.best.program.expression.render())
    print(
        "M2 expression:",
        outcome.targeted.search.best.program.expression.render(),
    )
    return 0


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _adversarial_search(args: argparse.Namespace) -> int:
    config = AdversarialSearchConfig(
        length=args.length,
        development_seed_start=args.development_seed_start,
        development_seed_count=args.development_seed_count,
        validation_seed_start=args.validation_seed_start,
        validation_seed_count=args.validation_seed_count,
        equivalence_seed_start=args.equivalence_seed_start,
        equivalence_seed_count=args.equivalence_seed_count,
        scout_candidate_budget=args.scout_budget,
        arm_candidate_budget=args.arm_budget,
        adversary_evaluation_budget=args.adversary_budget,
        adversary_initial_population=args.adversary_initial_population,
        augmentation_count=args.augmentation_count,
        search_seed=args.search_seed,
        adversary_seed=args.adversary_seed,
    )
    store = ArtifactStore(Path(args.output))
    source_provenance = python_source_tree_digest(_project_root())
    external_source_contract = load_source_manifest(
        _project_root() / "data" / "orlib" / "SOURCES.json"
    )
    spec = {
        "schema": 1,
        "kind": "m3_adversarial_sequence_discovery",
        "config": config.as_dict(),
        "source_provenance": source_provenance,
        "benchmark_firewall": {
            "external_corpus": "OR-Library binpack1 through binpack4",
            "opened_by_this_command": False,
            "confirmation_command": "scientist confirm",
            "source_metadata": external_source_contract,
        },
        "budget_accounting": {
            "scout_candidate_evaluations": config.scout_candidate_budget,
            "candidate_evaluations_per_arm": config.arm_candidate_budget,
            "sequences_per_arm": (
                config.development_seed_count + config.augmentation_count
            ),
            "adversary_sequence_evaluations": (
                config.adversary_evaluation_budget
            ),
            "adversary_policy_runs_per_sequence": 2,
            "claim": (
                "candidate-search arms are matched; adversary overhead is "
                "reported separately and is not claimed to be matched"
            ),
        },
    }
    spec_digest = store.put("m3_adversarial_search_spec", spec)
    outcome = run_adversarial_search(
        config,
        artifact_store=store,
        source_provenance=source_provenance,
        external_source_contract=external_source_contract,
    )
    summary_digest = store.put(
        "m3_adversarial_search_summary",
        outcome.as_dict(),
    )
    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "summary_digest": summary_digest,
            "frozen_bundle_digest": outcome.frozen_bundle_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "kind": "m3_discovery",
        "spec_digest": spec_digest,
        "summary_digest": summary_digest,
        "source_provenance": source_provenance,
        "suite_digests": dict(sorted(outcome.suite_digests.items())),
        "artifact_digests": dict(sorted(outcome.artifact_digests.items())),
        "frozen_bundle_digest": outcome.frozen_bundle_digest,
        "frozen_bundle_artifact": outcome.artifact_digests[
            "frozen_candidate_bundle"
        ],
        "external_benchmark_opened": False,
        "confirmation_status": "pending",
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("External OR-Library benchmark opened: no")
    print("Frozen bundle:", outcome.frozen_bundle_digest)
    print("Adversarial sequences evaluated:", len(outcome.adversary.evaluated))
    print("Best scout gap vs FunSearch:", outcome.adversary.best.target_gap)
    if outcome.minimized_scout_counterexample is not None:
        print(
            "Minimized scout counterexample length:",
            len(
                outcome.minimized_scout_counterexample
                .minimized_instance.items
            ),
        )
    print()
    print("%-34s %14s %14s %18s" % (
        "policy",
        "validation",
        "worst",
        "known equivalent",
    ))
    rows = (
        (
            outcome.control.name,
            outcome.control.validation.mean_regret,
            outcome.control.validation.worst_regret,
            ",".join(outcome.control.equivalent_known_policies) or "none",
        ),
        (
            outcome.treatment.name,
            outcome.treatment.validation.mean_regret,
            outcome.treatment.validation.worst_regret,
            ",".join(outcome.treatment.equivalent_known_policies) or "none",
        ),
        *tuple(
            (
                name,
                report.mean_regret,
                report.worst_regret,
                "literature" if "funsearch" in name else "baseline",
            )
            for name, report in sorted(outcome.reference_validation.items())
        ),
    )
    for row in rows:
        print("%-34s %14.3f %14d %18s" % row)
    print()
    print(
        "Next: scientist confirm --discovery-manifest %s"
        % manifest_path
    )
    return 0


def _confirm(args: argparse.Namespace) -> int:
    discovery_manifest_path = Path(args.discovery_manifest).resolve()
    with discovery_manifest_path.open("r", encoding="utf-8") as handle:
        discovery_manifest = json.load(handle)
    if discovery_manifest.get("kind") != "m3_discovery":
        raise ValueError("manifest is not an M3 discovery run")
    if discovery_manifest.get("external_benchmark_opened") is not False:
        raise ValueError("discovery manifest is not sealed")

    store_root = (
        Path(args.output)
        if args.output is not None
        else discovery_manifest_path.parent.parent
    )
    store = ArtifactStore(store_root)
    frozen_artifact = str(discovery_manifest["frozen_bundle_artifact"])
    frozen_envelope = store.get(frozen_artifact)
    if frozen_envelope.get("kind") != "m3_frozen_candidate_bundle":
        raise ValueError("manifest points to the wrong artifact kind")
    frozen_bundle = frozen_envelope["value"]
    if (
        content_digest(frozen_bundle)
        != discovery_manifest["frozen_bundle_digest"]
    ):
        raise ValueError("frozen bundle digest does not match discovery manifest")

    orlib_root = Path(args.orlib_dir)
    source_manifest = load_source_manifest(orlib_root / "SOURCES.json")
    source_checksums = verify_orlib_files(orlib_root, source_manifest)
    records = load_orlib_corpus(orlib_root)
    outcome = confirm_frozen_candidates(
        frozen_bundle,
        records,
        source_checksums,
    )
    confirmation_digest = store.put(
        "m3_external_confirmation",
        outcome.as_dict(),
    )
    source_provenance = python_source_tree_digest(_project_root())
    run_id, created_at = _new_run_id(
        {
            "parent_run_id": discovery_manifest["run_id"],
            "frozen_bundle_digest": outcome.frozen_bundle_digest,
            "corpus_digest": outcome.corpus_digest,
            "confirmation_digest": confirmation_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "kind": "m3_external_confirmation",
        "parent_discovery_run_id": discovery_manifest["run_id"],
        "parent_discovery_manifest": str(discovery_manifest_path),
        "frozen_bundle_digest": outcome.frozen_bundle_digest,
        "corpus_digest": outcome.corpus_digest,
        "source_checksums": dict(sorted(source_checksums.items())),
        "confirmation_digest": confirmation_digest,
        "source_provenance": source_provenance,
        "external_benchmark_opened": True,
        "candidate_search_performed": False,
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("Parent discovery:", discovery_manifest["run_id"])
    print("External instances:", len(records))
    print("Candidate search performed after opening: no")
    print()
    print("%-34s %12s %12s %12s" % (
        "policy",
        "mean bins",
        "mean excess",
        "worst excess",
    ))
    for name, report in sorted(
        outcome.reports.items(),
        key=lambda item: (item[1].mean_excess, item[0]),
    ):
        print(
            "%-34s %12.3f %12.3f %12d"
            % (
                name,
                report.mean_bins,
                report.mean_excess,
                report.worst_excess,
            )
        )
    print()
    for prediction, passed in sorted(outcome.prediction_results.items()):
        print("%s: %s" % (prediction, "PASS" if passed else "FAIL"))
    return 0


def _incumbent_repair(args: argparse.Namespace) -> int:
    config = IncumbentRepairConfig(
        length=args.length,
        guard_seed_start=args.guard_seed_start,
        guard_seed_count_per_length=args.guard_seed_count_per_length,
        audit_seed_start=args.audit_seed_start,
        audit_seed_count_per_length=args.audit_seed_count_per_length,
        minimum_audit_wins=args.minimum_audit_wins,
        nomination_minimum_audit_wins=(
            args.nomination_minimum_audit_wins
        ),
        nomination_maximum_regression=(
            args.nomination_maximum_regression
        ),
        validation_seed_start=args.validation_seed_start,
        validation_seed_count=args.validation_seed_count,
        validation_lengths=tuple(args.validation_lengths),
        adversary_evaluation_budget=args.adversary_budget,
        adversary_initial_population=args.adversary_initial_population,
        repair_instance_count=args.repair_instance_count,
        candidate_evaluation_budget=args.candidate_budget,
        adversary_seed=args.adversary_seed,
        search_seed=args.search_seed,
        residual_scale=args.residual_scale,
        guard_regression_fraction_ceiling=(
            args.guard_regression_fraction_ceiling
        ),
    )
    store = ArtifactStore(Path(args.output))
    source_provenance = python_source_tree_digest(_project_root())
    spec_digest = store.put(
        "m31_incumbent_repair_spec",
        {
            "schema": 1,
            "kind": "m31_funsearch_incumbent_repair",
            "config": config.as_dict(),
            "source_provenance": source_provenance,
            "baseline_ladder": {
                "sanity_control": "best_fit",
                "optimization_incumbent": "funsearch_or_reference",
                "treatment": "adversarial residual repair",
            },
            "budget_accounting": {
                "candidate_evaluations_per_arm": (
                    config.candidate_evaluation_budget
                ),
                "repair_instances_per_arm": config.repair_instance_count,
                "adversary_sequence_evaluations": (
                    config.adversary_evaluation_budget
                ),
                "end_to_end_compute_matched": False,
            },
            "external_benchmark_opened": False,
        },
    )
    outcome = run_incumbent_repair_study(
        config,
        artifact_store=store,
        source_provenance=source_provenance,
    )
    summary_digest = store.put(
        "m31_incumbent_repair_summary",
        outcome.as_dict(),
    )
    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "summary_digest": summary_digest,
            "frozen_bundle_digest": outcome.frozen_bundle_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "kind": "m31_incumbent_repair",
        "spec_digest": spec_digest,
        "summary_digest": summary_digest,
        "frozen_bundle_digest": outcome.frozen_bundle_digest,
        "suite_digests": dict(sorted(outcome.suite_digests.items())),
        "artifact_digests": dict(sorted(outcome.artifact_digests.items())),
        "source_provenance": source_provenance,
        "external_benchmark_opened": False,
        "external_confirmation_performed": False,
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("Optimization incumbent: funsearch_or_reference")
    print("External OR-Library benchmark opened: no")
    print("Adversarial sequences evaluated:", len(outcome.adversary.evaluated))
    print("Largest FunSearch-minus-Best-Fit gap:", outcome.adversary.best.target_gap)
    if outcome.minimized_incumbent_counterexample is not None:
        print(
            "Minimized incumbent counterexample:",
            list(
                outcome.minimized_incumbent_counterexample
                .minimized_instance.items
            ),
        )
    print()
    for arm in (outcome.control, outcome.treatment):
        print("%s proposed candidate:" % arm.name)
        print(" ", arm.search.best.program.as_dict()["rendered"])
        print(
            "  repair delta %.3f; guard delta %.3f; eligible %s"
            % (
                arm.search.best.repair_report.mean_delta,
                arm.search.best.guard_report.mean_delta,
                arm.search.best.eligible,
            )
        )
        audit_wins = sum(
            report.wins for report in arm.audit_by_length.values()
        )
        audit_losses = sum(
            report.losses for report in arm.audit_by_length.values()
        )
        print(
            "  promotion audit wins %d; losses %d; passed %s"
            % (audit_wins, audit_losses, arm.promotion_passed)
        )
        print("  deployed:", arm.promoted_program.as_dict()["rendered"])
    print()
    print("%-8s %14s %14s %14s %14s" % (
        "length",
        "control Δ",
        "treatment Δ",
        "treat-control",
        "bestfit Δ",
    ))
    for length in config.validation_lengths:
        print(
            "%-8d %14.3f %14.3f %14.3f %14.3f"
            % (
                length,
                outcome.control.validation_by_length[length].mean_delta,
                outcome.treatment.validation_by_length[length].mean_delta,
                outcome.treatment_vs_control_by_length[length].mean_delta,
                outcome.best_fit_vs_incumbent_by_length[length].mean_delta,
            )
        )
    print()
    for prediction, passed in sorted(outcome.prediction_results.items()):
        print("%s: %s" % (prediction, "PASS" if passed else "FAIL"))
    return 0


def _repair_replication(args: argparse.Namespace) -> int:
    config = RepairReplicationConfig(
        replicate_count=args.replicates,
        guard_seed_start=args.guard_seed_start,
        audit_seed_start=args.audit_seed_start,
        validation_seed_start=args.validation_seed_start,
        seed_stride=args.seed_stride,
        adversary_seed_start=args.adversary_seed_start,
        search_seed_start=args.search_seed_start,
        guard_seed_count_per_length=args.guard_seed_count_per_length,
        audit_seed_count_per_length=args.audit_seed_count_per_length,
        validation_seed_count=args.validation_seed_count,
        candidate_evaluation_budget=args.candidate_budget,
        adversary_evaluation_budget=args.adversary_budget,
        repair_instance_count=args.repair_instance_count,
    )
    store = ArtifactStore(Path(args.output))
    source_provenance = python_source_tree_digest(_project_root())
    spec_digest = store.put(
        "m31_repair_replication_spec",
        {
            "schema": 1,
            "kind": "m31_independent_generated_replication",
            "config": config.as_dict(),
            "source_provenance": source_provenance,
            "aggregate_predictions": [
                "every replicate has pooled treatment delta <= 0",
                "a majority of replicates has pooled treatment delta < 0",
                "aggregate treatment delta is < 0",
                "aggregate treatment-minus-control delta is < 0",
            ],
            "external_benchmark_opened": False,
        },
    )
    outcome = run_repair_replication(
        config,
        artifact_store=store,
        source_provenance=source_provenance,
    )
    summary_digest = store.put(
        "m31_repair_replication_summary",
        outcome.as_dict(),
    )
    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "summary_digest": summary_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "kind": "m31_repair_replication",
        "spec_digest": spec_digest,
        "summary_digest": summary_digest,
        "source_provenance": source_provenance,
        "external_benchmark_opened": False,
        "replicate_count": config.replicate_count,
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("External OR-Library benchmark opened: no")
    print()
    print("%-10s %14s %14s %18s" % (
        "replicate",
        "treatment Δ",
        "control Δ",
        "candidate",
    ))
    for index, replicate in enumerate(outcome.replicates):
        print(
            "%-10d %14d %14d %18s"
            % (
                index,
                outcome.pooled_treatment_deltas[index],
                outcome.pooled_control_deltas[index],
                replicate.treatment.promoted_program.candidate_id[:12],
            )
        )
        print(
            "  %s"
            % replicate.treatment.promoted_program.as_dict()["rendered"]
        )
        if not replicate.treatment.promotion_passed:
            print("  proposed residual rejected by untouched audit")
    print()
    print("Aggregate treatment delta:", sum(outcome.pooled_treatment_deltas))
    print("Aggregate control delta:", sum(outcome.pooled_control_deltas))
    for prediction, passed in sorted(
        outcome.aggregate_prediction_results.items()
    ):
        print("%s: %s" % (prediction, "PASS" if passed else "FAIL"))
    return 0


def _three_island_campaign(args: argparse.Namespace) -> int:
    incumbent_program = None
    incumbent_replication_manifest = None
    if args.incumbent_replication_manifest is not None:
        incumbent_path = Path(
            args.incumbent_replication_manifest
        ).resolve()
        with incumbent_path.open("r", encoding="utf-8") as handle:
            incumbent_replication_manifest = json.load(handle)
        if (
            incumbent_replication_manifest.get("kind")
            != "three_island_finalist_replication"
        ):
            raise ValueError(
                "incumbent manifest is not a finalist replication"
            )
        if (
            incumbent_replication_manifest.get(
                "confirmed_generated_improvement"
            )
            is not True
        ):
            raise ValueError(
                "replication did not confirm the proposed incumbent"
            )
        incumbent_store = ArtifactStore(
            incumbent_path.parent.parent
        )
        incumbent_summary_envelope = incumbent_store.get(
            str(incumbent_replication_manifest["summary_digest"])
        )
        if (
            incumbent_summary_envelope.get("kind")
            != "three_island_finalist_replication_summary"
        ):
            raise ValueError(
                "incumbent manifest points to the wrong summary"
            )
        incumbent_program = program_from_dict(
            incumbent_summary_envelope["value"]["candidate"]
        )
        if (
            incumbent_program.candidate_id
            != incumbent_replication_manifest["candidate_id"]
        ):
            raise ValueError("confirmed incumbent identity mismatch")
    config = ThreeIslandCampaignConfig(
        rounds=args.rounds,
        length=args.length,
        candidate_budget_per_island=args.candidate_budget,
        initial_random_candidates=args.initial_random,
        adversary_budget_per_round=args.adversary_budget,
        adversary_initial_population=args.adversary_initial_population,
        repair_instance_count=args.repair_instance_count,
        motif_variant_count=args.motif_variants,
        carry_elites_per_island=args.carry_elites,
        guard_seed_count_per_length=args.guard_count,
        audit_seed_count_per_length=args.audit_count,
        validation_seed_count_per_length=args.validation_count,
        validation_lengths=tuple(args.validation_lengths),
        minimum_audit_wins=args.minimum_audit_wins,
        base_seed=args.base_seed,
        residual_scale=args.residual_scale,
    )
    store = ArtifactStore(Path(args.output))
    source_provenance = python_source_tree_digest(_project_root())
    spec_digest = store.put(
        "m32_three_island_campaign_spec",
        {
            "schema": 1,
            "kind": "m32_three_island_autonomous_campaign",
            "config": config.as_dict(),
            "source_provenance": source_provenance,
            "islands": [
                "funsearch_ancestry",
                "de_novo",
                "hybrid",
            ],
            "matched_contract": {
                "candidate_evaluations_per_island_per_round": (
                    config.candidate_budget_per_island
                ),
                "shared_repair_suite_within_round": True,
                "shared_guard_suite_within_round": True,
                "shared_untouched_audit_within_round": True,
            },
            "proposer": (
                "structured typed-DSL mutation/crossover; pluggable "
                "model proposer not yet enabled"
            ),
            "external_benchmark_opened": False,
            "optimization_incumbent": (
                "funsearch_or_reference"
                if incumbent_program is None
                else incumbent_program.as_dict()
            ),
            "incumbent_replication_manifest": (
                None
                if incumbent_replication_manifest is None
                else str(
                    Path(args.incumbent_replication_manifest).resolve()
                )
            ),
        },
    )
    outcome = run_three_island_campaign(
        config,
        artifact_store=store,
        progress=lambda message: print(message, flush=True),
        incumbent_program=incumbent_program,
    )
    summary_digest = store.put(
        "m32_three_island_campaign_summary",
        outcome.as_dict(),
    )
    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "summary_digest": summary_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "kind": "m32_three_island_campaign",
        "spec_digest": spec_digest,
        "summary_digest": summary_digest,
        "source_provenance": source_provenance,
        "round_count": config.rounds,
        "candidate_evaluations_per_island_per_round": (
            config.candidate_budget_per_island
        ),
        "finalist_island": outcome.finalist_island,
        "finalist_candidate_id": outcome.finalist_program.candidate_id,
        "optimization_incumbent_candidate_id": (
            outcome.incumbent_program.candidate_id
        ),
        "provisional_breakthrough": outcome.provisional_breakthrough,
        "replication_recommended": outcome.replication_recommended,
        "external_benchmark_opened": False,
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print()
    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("External OR-Library benchmark opened: no")
    print("Proposal engine:", outcome.proposer_name)
    print(
        "Optimization incumbent:",
        outcome.incumbent_program.as_dict()["rendered"],
    )
    print("Finalist island:", outcome.finalist_island)
    print("Finalist:", outcome.finalist_program.as_dict()["rendered"])
    print()
    print("%-8s %14s %14s %14s %14s" % (
        "length",
        "ancestry Δ",
        "de novo Δ",
        "hybrid Δ",
        "best fit Δ",
    ))
    for length in config.validation_lengths:
        print(
            "%-8d %14.3f %14.3f %14.3f %14.3f"
            % (
                length,
                outcome.island_validation_by_length[
                    "funsearch_ancestry"
                ][length].mean_delta,
                outcome.island_validation_by_length[
                    "de_novo"
                ][length].mean_delta,
                outcome.island_validation_by_length[
                    "hybrid"
                ][length].mean_delta,
                outcome.best_fit_validation_by_length[length].mean_delta,
            )
        )
    print()
    print(
        "Provisional breakthrough:",
        "YES" if outcome.provisional_breakthrough else "NO",
    )
    print(
        "Frozen replication recommended:",
        "YES" if outcome.replication_recommended else "NO",
    )
    for reason in outcome.breakthrough_reasons:
        print(" ", reason)
    return 0


def _replicate_campaign_finalist(args: argparse.Namespace) -> int:
    campaign_manifest_path = Path(args.campaign_manifest).resolve()
    with campaign_manifest_path.open("r", encoding="utf-8") as handle:
        campaign_manifest = json.load(handle)
    if campaign_manifest.get("kind") not in (
        "m4_three_island_campaign",
        "m32_three_island_campaign",
    ):
        raise ValueError("manifest is not a three-island campaign")
    store_root = (
        Path(args.output)
        if args.output is not None
        else campaign_manifest_path.parent.parent
    )
    store = ArtifactStore(store_root)
    summary_digest = str(campaign_manifest["summary_digest"])
    summary_envelope = store.get(summary_digest)
    if summary_envelope.get("kind") not in (
        "m4_three_island_campaign_summary",
        "m32_three_island_campaign_summary",
    ):
        raise ValueError("campaign manifest points to the wrong summary kind")
    campaign_summary = summary_envelope["value"]
    candidate = program_from_dict(campaign_summary["finalist"])
    incumbent_program = (
        program_from_dict(campaign_summary["optimization_incumbent"])
        if campaign_summary.get("optimization_incumbent") is not None
        else None
    )
    if candidate.candidate_id != campaign_manifest["finalist_candidate_id"]:
        raise ValueError("frozen finalist does not match campaign manifest")
    source_campaign_digest = content_digest(campaign_manifest)
    config = CampaignReplicationConfig(
        replicate_count=args.replicates,
        instances_per_length=args.instances_per_length,
        lengths=tuple(args.lengths),
        seed_start=args.seed_start,
        replicate_seed_stride=args.seed_stride,
        sign_test_alpha=args.sign_test_alpha,
        required_nonregressing_replicates=(
            args.required_nonregressing_replicates
        ),
        required_strictly_improving_replicates=(
            args.required_improving_replicates
        ),
    )
    source_provenance = python_source_tree_digest(_project_root())
    spec_digest = store.put(
        "three_island_finalist_replication_spec",
        {
            "schema": 1,
            "kind": "three_island_finalist_no_search_replication",
            "config": config.as_dict(),
            "candidate": candidate.as_dict(),
            "optimization_incumbent": (
                "funsearch_or_reference"
                if incumbent_program is None
                else incumbent_program.as_dict()
            ),
            "source_campaign_manifest": str(campaign_manifest_path),
            "source_campaign_digest": source_campaign_digest,
            "source_provenance": source_provenance,
            "candidate_search_performed": False,
            "external_benchmark_opened": False,
        },
    )
    outcome = run_campaign_replication(
        config,
        candidate,
        source_campaign_digest,
        artifact_store=store,
        incumbent_program=incumbent_program,
    )
    replication_summary_digest = store.put(
        "three_island_finalist_replication_summary",
        outcome.as_dict(),
    )
    run_id, created_at = _new_run_id(
        {
            "spec_digest": spec_digest,
            "summary_digest": replication_summary_digest,
            "source_campaign_digest": source_campaign_digest,
        }
    )
    manifest = {
        "schema": 1,
        "run_id": run_id,
        "created_at": created_at,
        "scientist_version": __version__,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "kind": "three_island_finalist_replication",
        "spec_digest": spec_digest,
        "summary_digest": replication_summary_digest,
        "source_campaign_manifest": str(campaign_manifest_path),
        "source_campaign_digest": source_campaign_digest,
        "candidate_id": candidate.candidate_id,
        "confirmed_generated_improvement": (
            outcome.confirmed_generated_improvement
        ),
        "candidate_search_performed": False,
        "external_benchmark_opened": False,
        "source_provenance": source_provenance,
    }
    manifest_path = store.write_manifest(run_id, manifest)

    print("Run:", run_id)
    print("Manifest:", manifest_path)
    print("Frozen candidate:", candidate.as_dict()["rendered"])
    print(
        "Optimization incumbent:",
        outcome.incumbent.as_dict()["rendered"],
    )
    print("Candidate search performed: no")
    print("External OR-Library benchmark opened: no")
    print()
    print("%-10s %14s %10s %10s" % (
        "replicate",
        "pooled delta",
        "wins",
        "losses",
    ))
    for batch in outcome.batches:
        print(
            "%-10d %14d %10d %10d"
            % (
                batch.replicate_index,
                batch.pooled_delta,
                batch.wins,
                batch.losses,
            )
        )
    print()
    print("%-8s %14s %10s %10s" % (
        "length",
        "mean delta",
        "wins",
        "losses",
    ))
    for length in config.lengths:
        report = outcome.aggregate_by_length[length]
        print(
            "%-8d %14.4f %10d %10d"
            % (
                length,
                report.mean_delta,
                report.wins,
                report.losses,
            )
        )
    print()
    print("Aggregate pooled delta:", outcome.pooled_delta)
    print("One-sided paired sign-test p:", outcome.sign_test_p_value)
    for prediction, passed in sorted(outcome.prediction_results.items()):
        print("%s: %s" % (prediction, "PASS" if passed else "FAIL"))
    print(
        "Confirmed generated improvement:",
        "YES" if outcome.confirmed_generated_improvement else "NO",
    )
    return 0


def _goal_program_status(args: argparse.Namespace) -> int:
    store = (
        None
        if args.artifact_root is None
        else ArtifactStore(Path(args.artifact_root))
    )
    runtime = GoalGraphRuntime.from_checkpoint(
        Path(args.checkpoint),
        artifact_store=store,
    )
    print(json.dumps(runtime.status(), indent=2, sort_keys=True))
    return 0


def _cognitive_goal_init(args: argparse.Namespace) -> ScientificCommandOutcome:
    checkpoint = Path(args.checkpoint)
    if checkpoint.exists():
        raise ValueError("checkpoint already exists; refusing to overwrite it")
    store = ArtifactStore(Path(args.artifact_root))
    control = build_cognitive_goal_control_plane(artifact_store=store)
    runtime = GoalGraphRuntime(
        control,
        checkpoint,
        artifact_store=store,
    )
    spec = fresh_goal_graph_spec()
    status = {
        **runtime.status(),
        "fresh_program": True,
        "historical_driver_active": False,
        "planned_node_ids": {
            name: node.node_id for name, node in sorted(spec.nodes.items())
        },
        "planned_decomposition_count": len(spec.decompositions),
        "next_required_gate": "close root literature before graph registration",
    }
    print(json.dumps(status, indent=2, sort_keys=True))
    return ScientificCommandOutcome(
        details={
            "checkpoint": str(checkpoint.resolve()),
            "goal_graph_status": status,
        }
    )


def _binpacking_goal_run(args: argparse.Namespace) -> ScientificCommandOutcome:
    value_config = StochasticValueConfig(
        capacity=args.capacity,
        training_lengths=tuple(args.validation_lengths),
        base_seed=args.base_seed,
    )
    config = DiscoveryResetConfig(
        search_rounds=max(2, args.rounds),
        code_candidates_per_island_per_round=args.candidate_budget,
        initial_code_candidates=args.initial_random,
        value=value_config,
    )
    result = run_discovery_reset(
        checkpoint_path=Path(args.checkpoint),
        artifact_root=Path(args.artifact_root),
        orlib_root=Path(args.orlib_dir),
        config=config,
        code_backend=OpenAIResponsesCodeModel(model_ref=args.code_model),
        resume=args.resume,
        on_conformance_passed=(
            None
            if getattr(args, "_scientific_runtime", None) is None
            else args._scientific_runtime.start
        ),
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return ScientificCommandOutcome(
        manifest_paths=(str(result["manifest"]),),
        artifact_ids=(
            str(result["summary_digest"]),
            str(result["benchmark_conformance_digest"]),
        ),
        details={
            "outcome": result["outcome"],
            "goal_graph_checkpoint": result["goal_graph_checkpoint"],
        },
    )


def _binpacking_goal_codex_run(
    args: argparse.Namespace,
) -> ScientificCommandOutcome:
    value_config = StochasticValueConfig(
        capacity=args.capacity,
        training_lengths=tuple(args.validation_lengths),
        base_seed=args.base_seed,
    )
    config = DiscoveryResetConfig(
        search_rounds=max(2, args.rounds),
        code_candidates_per_island_per_round=args.candidate_budget,
        initial_code_candidates=args.initial_random,
        value=value_config,
    )
    exchange_root = (
        Path(args.codex_exchange_root)
        if args.codex_exchange_root
        else Path(args.artifact_root) / "codex_exchange"
    )
    result = run_discovery_reset(
        checkpoint_path=Path(args.checkpoint),
        artifact_root=Path(args.artifact_root),
        orlib_root=Path(args.orlib_dir),
        config=config,
        code_backend=CodexPacketCodeModel(
            exchange_root=exchange_root,
            model_ref=args.codex_producer_ref,
            auto_fulfill=args.auto_codex,
            codex_model=args.codex_model,
            codex_binary=args.codex_binary,
            codex_reasoning_effort=args.codex_reasoning_effort,
            codex_compiler_reasoning_effort=(
                args.codex_compiler_reasoning_effort
            ),
            codex_timeout_seconds=args.codex_timeout,
        ),
        resume=args.resume,
        on_conformance_passed=(
            None
            if getattr(args, "_scientific_runtime", None) is None
            else args._scientific_runtime.start
        ),
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return ScientificCommandOutcome(
        manifest_paths=(str(result["manifest"]),),
        artifact_ids=(
            str(result["summary_digest"]),
            str(result["benchmark_conformance_digest"]),
        ),
        details={
            "outcome": result["outcome"],
            "goal_graph_checkpoint": result["goal_graph_checkpoint"],
            "codex_exchange_root": str(exchange_root.resolve()),
        },
    )


def _binpacking_discovery_reset_run(
    args: argparse.Namespace,
) -> ScientificCommandOutcome:
    result = run_discovery_reset(
        checkpoint_path=Path(args.checkpoint),
        artifact_root=Path(args.artifact_root),
        orlib_root=Path(args.orlib_dir),
        config=DiscoveryResetConfig(),
        code_backend=OpenAIResponsesCodeModel(model_ref=args.code_model),
        on_conformance_passed=(
            None
            if getattr(args, "_scientific_runtime", None) is None
            else args._scientific_runtime.start
        ),
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return ScientificCommandOutcome(
        manifest_paths=(str(result["manifest"]),),
        artifact_ids=(
            str(result["summary_digest"]),
            str(result["benchmark_conformance_digest"]),
        ),
        details={
            "outcome": result["outcome"],
            "goal_graph_checkpoint": result["goal_graph_checkpoint"],
        },
    )


def _binpacking_goal_continue(
    args: argparse.Namespace,
) -> ScientificCommandOutcome:
    result = continue_goal_program(
        checkpoint_path=Path(args.checkpoint),
        artifact_root=Path(args.artifact_root),
        prior_manifest_path=Path(args.prior_manifest),
        orlib_root=Path(args.orlib_dir),
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return ScientificCommandOutcome(
        manifest_paths=(str(result["manifest"]),),
        artifact_ids=tuple(
            str(result[name])
            for name in ("summary_digest",)
            if name in result
        ),
        details={"outcome": result.get("outcome")},
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="scientist")
    subparsers = parser.add_subparsers(dest="command", required=True)

    benchmark = subparsers.add_parser(
        "benchmark",
        help="Run the deterministic baseline bin-packing laboratory.",
    )
    benchmark.add_argument("--output", default="runs")
    benchmark.add_argument("--capacity", type=int, default=100)
    benchmark.add_argument("--length", type=int, default=14)
    benchmark.add_argument("--seed-start", type=int, default=0)
    benchmark.add_argument("--seed-count", type=int, default=4)
    benchmark.add_argument(
        "--families",
        nargs="*",
        choices=sorted(GENERATORS),
    )
    benchmark.set_defaults(handler=_benchmark)

    conformance = subparsers.add_parser(
        "binpacking-conformance",
        help=(
            "Reproduce the pinned official FunSearch notebook evaluator, "
            "OR3 results, and golden action traces."
        ),
    )
    conformance.add_argument("--orlib-dir", default="data/orlib")
    conformance.set_defaults(handler=_binpacking_conformance)

    search = subparsers.add_parser(
        "search",
        help="Run the fixed-budget evolutionary priority-program baseline.",
    )
    search.add_argument("--output", default="runs")
    search.add_argument("--capacity", type=int, default=100)
    search.add_argument("--length", type=int, default=14)
    search.add_argument("--development-seed-start", type=int, default=0)
    search.add_argument("--development-seed-count", type=int, default=4)
    search.add_argument("--validation-seed-start", type=int, default=10_000)
    search.add_argument("--validation-seed-count", type=int, default=4)
    search.add_argument("--equivalence-seed-start", type=int, default=20_000)
    search.add_argument("--equivalence-seed-count", type=int, default=8)
    search.add_argument("--equivalence-length", type=int, default=40)
    search.add_argument("--search-seed", type=int, default=0)
    search.add_argument("--budget", type=int, default=200)
    search.add_argument("--initial-random", type=int, default=16)
    search.add_argument("--crossover-probability", type=float, default=0.25)
    search.add_argument("--max-depth", type=int, default=5)
    search.add_argument("--max-nodes", type=int, default=31)
    search.add_argument("--complexity-penalty", type=float, default=0.002)
    search.add_argument(
        "--families",
        nargs="*",
        choices=sorted(GENERATORS),
    )
    search.set_defaults(handler=_search)

    study = subparsers.add_parser(
        "study",
        help=(
            "Run active hypothesis discrimination and minimize "
            "counterexamples."
        ),
    )
    study.add_argument("--output", default="runs")
    study.add_argument("--capacity", type=int, default=100)
    study.add_argument("--length", type=int, default=14)
    study.add_argument(
        "--selection-mode",
        choices=("active", "passive"),
        default="active",
    )
    study.add_argument("--pool-seed-start", type=int, default=30_000)
    study.add_argument("--pool-seed-count", type=int, default=20)
    study.add_argument("--budget", type=int, default=12)
    study.add_argument("--temperature", type=float, default=0.7)
    study.add_argument("--maximum-counterexamples", type=int, default=3)
    study.add_argument(
        "--families",
        nargs="*",
        choices=sorted(GENERATORS),
    )
    study.set_defaults(handler=_study)

    regime_search = subparsers.add_parser(
        "regime-search",
        help=(
            "Compare ordinary evolution with failure-regime-targeted "
            "evolution under matched budgets."
        ),
    )
    regime_search.add_argument("--output", default="runs")
    regime_search.add_argument("--capacity", type=int, default=100)
    regime_search.add_argument("--length", type=int, default=14)
    regime_search.add_argument("--validation-length", type=int)
    regime_search.add_argument("--sealed-length", type=int)
    regime_search.add_argument(
        "--reference-mode",
        choices=("exact", "volume_lower_bound"),
        default="exact",
    )
    regime_search.add_argument("--development-seed-start", type=int, default=0)
    regime_search.add_argument("--development-seed-count", type=int, default=6)
    regime_search.add_argument("--validation-seed-start", type=int, default=70_000)
    regime_search.add_argument("--validation-seed-count", type=int, default=6)
    regime_search.add_argument("--sealed-seed-start", type=int, default=80_000)
    regime_search.add_argument("--sealed-seed-count", type=int, default=12)
    regime_search.add_argument("--equivalence-seed-start", type=int, default=90_000)
    regime_search.add_argument("--budget", type=int, default=200)
    regime_search.add_argument("--search-seed", type=int, default=0)
    regime_search.add_argument("--regime-emphasis", type=float, default=3.0)
    regime_search.add_argument("--maximum-targeted-seeds", type=int, default=24)
    regime_search.add_argument(
        "--families",
        nargs="*",
        choices=sorted(GENERATORS),
    )
    regime_search.set_defaults(handler=_regime_search)

    adversarial_search = subparsers.add_parser(
        "adversarial-search",
        help=(
            "Run M3 matched random-vs-adversarial discovery and freeze "
            "candidates without opening the external benchmark."
        ),
    )
    adversarial_search.add_argument("--output", default="runs")
    adversarial_search.add_argument("--length", type=int, default=120)
    adversarial_search.add_argument(
        "--development-seed-start",
        type=int,
        default=0,
    )
    adversarial_search.add_argument(
        "--development-seed-count",
        type=int,
        default=10,
    )
    adversarial_search.add_argument(
        "--validation-seed-start",
        type=int,
        default=160_000,
    )
    adversarial_search.add_argument(
        "--validation-seed-count",
        type=int,
        default=10,
    )
    adversarial_search.add_argument(
        "--equivalence-seed-start",
        type=int,
        default=170_000,
    )
    adversarial_search.add_argument(
        "--equivalence-seed-count",
        type=int,
        default=8,
    )
    adversarial_search.add_argument("--scout-budget", type=int, default=60)
    adversarial_search.add_argument("--arm-budget", type=int, default=100)
    adversarial_search.add_argument(
        "--adversary-budget",
        type=int,
        default=200,
    )
    adversarial_search.add_argument(
        "--adversary-initial-population",
        type=int,
        default=20,
    )
    adversarial_search.add_argument(
        "--augmentation-count",
        type=int,
        default=12,
    )
    adversarial_search.add_argument("--search-seed", type=int, default=0)
    adversarial_search.add_argument("--adversary-seed", type=int, default=31)
    adversarial_search.set_defaults(handler=_adversarial_search)

    confirm = subparsers.add_parser(
        "confirm",
        help=(
            "Independently evaluate an already-frozen M3 bundle on "
            "checksummed OR-Library instances."
        ),
    )
    confirm.add_argument("--discovery-manifest", required=True)
    confirm.add_argument("--output")
    confirm.add_argument("--orlib-dir", default="data/orlib")
    confirm.set_defaults(handler=_confirm)

    incumbent_repair = subparsers.add_parser(
        "incumbent-repair",
        help=(
            "Run M3.1 matched residual repair around the executable "
            "FunSearch incumbent using generated data only."
        ),
    )
    incumbent_repair.add_argument("--output", default="runs")
    incumbent_repair.add_argument("--length", type=int, default=120)
    incumbent_repair.add_argument("--guard-seed-start", type=int, default=180_000)
    incumbent_repair.add_argument(
        "--guard-seed-count-per-length",
        type=int,
        default=6,
    )
    incumbent_repair.add_argument(
        "--audit-seed-start",
        type=int,
        default=600_000,
    )
    incumbent_repair.add_argument(
        "--audit-seed-count-per-length",
        type=int,
        default=20,
    )
    incumbent_repair.add_argument(
        "--minimum-audit-wins",
        type=int,
        default=1,
    )
    incumbent_repair.add_argument(
        "--validation-seed-start",
        type=int,
        default=700_000,
    )
    incumbent_repair.add_argument(
        "--validation-seed-count",
        type=int,
        default=10,
    )
    incumbent_repair.add_argument(
        "--validation-lengths",
        nargs="+",
        type=int,
        default=(120, 250, 500),
    )
    incumbent_repair.add_argument(
        "--adversary-budget",
        type=int,
        default=200,
    )
    incumbent_repair.add_argument(
        "--adversary-initial-population",
        type=int,
        default=20,
    )
    incumbent_repair.add_argument(
        "--repair-instance-count",
        type=int,
        default=12,
    )
    incumbent_repair.add_argument(
        "--candidate-budget",
        type=int,
        default=120,
    )
    incumbent_repair.add_argument("--adversary-seed", type=int, default=47)
    incumbent_repair.add_argument("--search-seed", type=int, default=53)
    incumbent_repair.add_argument(
        "--residual-scale",
        type=float,
        default=0.10,
    )
    incumbent_repair.add_argument(
        "--guard-regression-fraction-ceiling",
        type=float,
        default=0.0,
    )
    incumbent_repair.set_defaults(handler=_incumbent_repair)

    repair_replication = subparsers.add_parser(
        "repair-replication",
        help=(
            "Replicate M3.1 incumbent repair across independent generated "
            "adversary, guard, search, and validation seeds."
        ),
    )
    repair_replication.add_argument("--output", default="runs")
    repair_replication.add_argument("--replicates", type=int, default=3)
    repair_replication.add_argument(
        "--guard-seed-start",
        type=int,
        default=300_000,
    )
    repair_replication.add_argument(
        "--audit-seed-start",
        type=int,
        default=600_000,
    )
    repair_replication.add_argument(
        "--validation-seed-start",
        type=int,
        default=700_000,
    )
    repair_replication.add_argument("--seed-stride", type=int, default=50_000)
    repair_replication.add_argument(
        "--adversary-seed-start",
        type=int,
        default=101,
    )
    repair_replication.add_argument(
        "--search-seed-start",
        type=int,
        default=211,
    )
    repair_replication.add_argument(
        "--guard-seed-count-per-length",
        type=int,
        default=6,
    )
    repair_replication.add_argument(
        "--audit-seed-count-per-length",
        type=int,
        default=20,
    )
    repair_replication.add_argument(
        "--validation-seed-count",
        type=int,
        default=10,
    )
    repair_replication.add_argument(
        "--candidate-budget",
        type=int,
        default=120,
    )
    repair_replication.add_argument(
        "--adversary-budget",
        type=int,
        default=200,
    )
    repair_replication.add_argument(
        "--repair-instance-count",
        type=int,
        default=12,
    )
    repair_replication.set_defaults(handler=_repair_replication)

    three_island = subparsers.add_parser(
        "three-island-campaign",
        help=(
            "Run the matched FunSearch-ancestry, de novo, and hybrid "
            "autonomous discovery campaign."
        ),
    )
    three_island.add_argument("--output", default="runs")
    three_island.add_argument(
        "--incumbent-replication-manifest",
        help=(
            "Use a candidate from a successful no-search replication as "
            "the next optimization incumbent."
        ),
    )
    three_island.add_argument("--rounds", type=int, default=6)
    three_island.add_argument("--length", type=int, default=120)
    three_island.add_argument(
        "--candidate-budget",
        type=int,
        default=40,
    )
    three_island.add_argument("--initial-random", type=int, default=6)
    three_island.add_argument(
        "--adversary-budget",
        type=int,
        default=80,
    )
    three_island.add_argument(
        "--adversary-initial-population",
        type=int,
        default=12,
    )
    three_island.add_argument(
        "--repair-instance-count",
        type=int,
        default=12,
    )
    three_island.add_argument("--motif-variants", type=int, default=12)
    three_island.add_argument("--carry-elites", type=int, default=6)
    three_island.add_argument("--guard-count", type=int, default=4)
    three_island.add_argument("--audit-count", type=int, default=8)
    three_island.add_argument("--validation-count", type=int, default=20)
    three_island.add_argument(
        "--validation-lengths",
        nargs="+",
        type=int,
        default=(120, 250, 500),
    )
    three_island.add_argument(
        "--minimum-audit-wins",
        type=int,
        default=1,
    )
    three_island.add_argument(
        "--nomination-minimum-audit-wins",
        type=int,
        default=2,
    )
    three_island.add_argument(
        "--nomination-maximum-regression",
        type=int,
        default=1,
    )
    three_island.add_argument("--base-seed", type=int, default=1_000)
    three_island.add_argument(
        "--residual-scale",
        type=float,
        default=0.10,
    )
    three_island.set_defaults(handler=_three_island_campaign)

    campaign_replication = subparsers.add_parser(
        "replicate-campaign-finalist",
        help=(
            "Replicate a frozen three-island finalist on fresh generated "
            "suites without candidate search."
        ),
    )
    campaign_replication.add_argument("--campaign-manifest", required=True)
    campaign_replication.add_argument("--output")
    campaign_replication.add_argument("--replicates", type=int, default=5)
    campaign_replication.add_argument(
        "--instances-per-length",
        type=int,
        default=40,
    )
    campaign_replication.add_argument(
        "--lengths",
        nargs="+",
        type=int,
        default=(120, 250, 500),
    )
    campaign_replication.add_argument(
        "--seed-start",
        type=int,
        default=120_000_000,
    )
    campaign_replication.add_argument(
        "--seed-stride",
        type=int,
        default=1_000_000,
    )
    campaign_replication.add_argument(
        "--sign-test-alpha",
        type=float,
        default=0.01,
    )
    campaign_replication.add_argument(
        "--required-nonregressing-replicates",
        type=int,
        default=4,
    )
    campaign_replication.add_argument(
        "--required-improving-replicates",
        type=int,
        default=3,
    )
    campaign_replication.set_defaults(
        handler=_replicate_campaign_finalist
    )
    goal_status = subparsers.add_parser(
        "goal-program-status",
        help=(
            "Load and verify a durable v2 goal-graph checkpoint, then show "
            "its next scientific actions."
        ),
    )
    goal_status.add_argument("--checkpoint", required=True)
    goal_status.add_argument("--artifact-root")
    goal_status.set_defaults(handler=_goal_program_status)
    cognitive_goal = subparsers.add_parser(
        "cognitive-goal-init",
        help=(
            "Initialize the fresh diagnostic-first cognitive-core objective "
            "on the durable goal-graph runtime."
        ),
    )
    cognitive_goal.add_argument(
        "--checkpoint",
        default="runs/cognitive_core/goal_program_v3/checkpoint.json",
    )
    cognitive_goal.add_argument(
        "--artifact-root",
        default="runs/cognitive_core/goal_program_v3/artifacts",
    )
    cognitive_goal.set_defaults(handler=_cognitive_goal_init)
    binpacking_goal = subparsers.add_parser(
        "binpacking-goal-run",
        help=(
            "Run the current clean discovery reset: benchmark conformance, "
            "live literature, executable code generation, i.i.d. suffix "
            "value learning, episode audit, and sealed replication."
        ),
    )
    binpacking_goal.add_argument(
        "--checkpoint",
        default="runs/binpacking_goal_program/checkpoint.json",
    )
    binpacking_goal.add_argument(
        "--artifact-root",
        default="runs/binpacking_goal_program/artifacts",
    )
    binpacking_goal.add_argument("--orlib-dir", default="data/orlib")
    binpacking_goal.add_argument("--rounds", type=int, default=4)
    binpacking_goal.add_argument(
        "--candidate-budget",
        type=int,
        default=24,
    )
    binpacking_goal.add_argument("--initial-random", type=int, default=6)
    binpacking_goal.add_argument("--capacity", type=int, default=150)
    binpacking_goal.add_argument(
        "--validation-lengths",
        nargs="+",
        type=int,
        default=(120, 250, 500),
    )
    binpacking_goal.add_argument(
        "--base-seed",
        type=int,
        default=30_072_026,
    )
    binpacking_goal.add_argument("--code-model", default="gpt-5.6-sol")
    binpacking_goal.add_argument(
        "--resume",
        action="store_true",
        help=(
            "Resume only the same isolated artifact root from its durable "
            "literature, value, island, and round checkpoints."
        ),
    )
    binpacking_goal.set_defaults(handler=_binpacking_goal_run)
    binpacking_codex = subparsers.add_parser(
        "binpacking-goal-codex-run",
        help=(
            "Run the clean discovery reset through immutable Codex request and "
            "response packets without an API key."
        ),
    )
    binpacking_codex.add_argument(
        "--checkpoint",
        default="runs/binpacking_goal_codex/checkpoint.json",
    )
    binpacking_codex.add_argument(
        "--artifact-root",
        default="runs/binpacking_goal_codex/artifacts",
    )
    binpacking_codex.add_argument("--orlib-dir", default="data/orlib")
    binpacking_codex.add_argument("--rounds", type=int, default=4)
    binpacking_codex.add_argument(
        "--candidate-budget",
        type=int,
        default=24,
    )
    binpacking_codex.add_argument("--initial-random", type=int, default=6)
    binpacking_codex.add_argument("--capacity", type=int, default=150)
    binpacking_codex.add_argument(
        "--validation-lengths",
        nargs="+",
        type=int,
        default=(120, 250, 500),
    )
    binpacking_codex.add_argument(
        "--base-seed",
        type=int,
        default=30_072_026,
    )
    binpacking_codex.add_argument(
        "--codex-exchange-root",
        help=(
            "Request/response exchange directory; defaults to "
            "<artifact-root>/codex_exchange."
        ),
    )
    binpacking_codex.add_argument(
        "--codex-producer-ref",
        default="codex-task-agent",
    )
    binpacking_codex.add_argument(
        "--auto-codex",
        action="store_true",
        help=(
            "Automatically fulfil packets with the locally authenticated "
            "Codex CLI; API-key variables are removed from every child."
        ),
    )
    binpacking_codex.add_argument(
        "--codex-model",
        help="Optional Codex model override; defaults to the local Codex choice.",
    )
    binpacking_codex.add_argument(
        "--codex-binary",
        default="codex",
    )
    binpacking_codex.add_argument(
        "--codex-reasoning-effort",
        choices=("low", "medium", "high", "xhigh"),
        default="medium",
    )
    binpacking_codex.add_argument(
        "--codex-compiler-reasoning-effort",
        choices=("low", "medium", "high", "xhigh"),
        default="low",
    )
    binpacking_codex.add_argument(
        "--codex-timeout",
        type=float,
        default=900.0,
    )
    binpacking_codex.add_argument(
        "--resume",
        action="store_true",
        help=(
            "Resume the same durable campaign and consume any validated Codex "
            "response packets."
        ),
    )
    binpacking_codex.set_defaults(handler=_binpacking_goal_codex_run)
    discovery_reset = subparsers.add_parser(
        "binpacking-discovery-reset-run",
        help=(
            "Run the conformance-gated, code-generating, literature-grounded "
            "i.i.d.-OR discovery architecture with episode-level evidence."
        ),
    )
    discovery_reset.add_argument(
        "--checkpoint",
        default="runs/binpacking_discovery_reset/checkpoint.json",
    )
    discovery_reset.add_argument(
        "--artifact-root",
        default="runs/binpacking_discovery_reset/artifacts",
    )
    discovery_reset.add_argument("--orlib-dir", default="data/orlib")
    discovery_reset.add_argument("--code-model", default="gpt-5.6-sol")
    discovery_reset.set_defaults(handler=_binpacking_discovery_reset_run)
    binpacking_continue = subparsers.add_parser(
        "binpacking-goal-continue",
        help=(
            "Restore a v2 bin-packing goal checkpoint, consume its next "
            "control action, revise a plateaued graph from recorded evidence, "
            "and continue autonomously."
        ),
    )
    binpacking_continue.add_argument("--checkpoint", required=True)
    binpacking_continue.add_argument("--artifact-root", required=True)
    binpacking_continue.add_argument("--prior-manifest", required=True)
    binpacking_continue.add_argument("--orlib-dir", default="data/orlib")
    binpacking_continue.set_defaults(
        handler=_binpacking_goal_continue
    )
    cognitive_goal.set_defaults(
        scientific_domain_id="cognitive_core_minilab"
    )
    for active_reset_parser in (
        binpacking_goal,
        binpacking_codex,
        discovery_reset,
    ):
        active_reset_parser.set_defaults(
            scientific_domain_id="online_1d_bin_packing",
            scientific_runtime_lazy=True,
        )
    binpacking_continue.set_defaults(
        scientific_domain_id="online_1d_bin_packing"
    )
    for domain_parser in (
        benchmark,
        conformance,
        search,
        study,
        regime_search,
        adversarial_search,
        confirm,
        incumbent_repair,
        repair_replication,
        three_island,
        campaign_replication,
    ):
        domain_parser.set_defaults(
            scientific_domain_id="online_1d_bin_packing"
        )
    return parser


def main(argv: Sequence[str] = ()) -> int:
    parser = build_parser()
    arguments = parser.parse_args(list(argv) if argv else None)
    if arguments.command in (
        "goal-program-status",
        "binpacking-conformance",
    ):
        return int(arguments.handler(arguments))
    domain_id = getattr(arguments, "scientific_domain_id", None)
    if not domain_id:
        raise ValueError(
            "scientific command did not declare a domain bundle"
        )
    domain = default_domain_registry().resolve(str(domain_id))
    runtime = ScientificCommandRuntime(
        arguments,
        domain=domain,
        lazy_start=bool(
            getattr(arguments, "scientific_runtime_lazy", False)
        ),
    )
    arguments._scientific_runtime = runtime
    return runtime.execute(arguments.handler)
