"""Independent confirmation paths that do not import discovery search code."""
