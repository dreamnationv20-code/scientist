from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import (
    OnlineHeuristic,
    baseline_heuristics,
    literature_heuristics,
)
from scientist.domains.binpacking.orlib import (
    ORLibraryRecord,
    corpus_digest,
)
from scientist.domains.binpacking.programs import (
    DSL_VERSION,
    Expression,
    PriorityProgram,
)


CONFIRMATION_VERSION = "orlib-independent-confirmation-v2"


def _quantile(values: Sequence[float], probability: float) -> float:
    ordered = sorted(values)
    position = probability * (len(ordered) - 1)
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return float(ordered[lower])
    fraction = position - lower
    return float(
        ordered[lower] * (1.0 - fraction)
        + ordered[upper] * fraction
    )


def _audited_trace(
    record: ORLibraryRecord,
    heuristic: OnlineHeuristic,
) -> Tuple[int, str]:
    """Independent replay: does not call the discovery evaluator or pack()."""

    instance = record.instance
    loads = []
    history = []
    decisions = []
    for item_index, item in enumerate(instance.items):
        choice = heuristic.choose_bin(
            item,
            tuple(loads),
            instance.capacity,
            item_index,
            tuple(history),
        )
        if choice is None:
            loads.append(item)
            chosen_index = len(loads) - 1
        else:
            if choice < 0 or choice >= len(loads):
                raise ValueError(
                    "%s selected nonexistent bin %d"
                    % (heuristic.name, choice)
                )
            if loads[choice] + item > instance.capacity:
                raise ValueError(
                    "%s selected an infeasible bin" % heuristic.name
                )
            loads[choice] += item
            chosen_index = choice
        if any(load > instance.capacity for load in loads):
            raise AssertionError("independent capacity audit failed")
        if sum(loads) != sum(history) + item:
            raise AssertionError(
                "independent prefix-conservation audit failed"
            )
        decisions.append(chosen_index)
        history.append(item)
    if sum(loads) != sum(instance.items):
        raise AssertionError("independent conservation audit failed")
    return (
        len(loads),
        content_digest(
            {
                "instance_id": instance.instance_id,
                "chosen_bin_indices": decisions,
            }
        ),
    )


@dataclass(frozen=True)
class ExternalBenchmarkReport:
    policy_name: str
    instance_count: int
    mean_bins: float
    mean_excess: float
    p95_excess: float
    worst_excess: int
    source_file_mean_excess: Mapping[str, float]
    observations: Tuple[Mapping[str, Any], ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "confirmation_version": CONFIRMATION_VERSION,
            "reference_kind": "or_library_recorded_best_known",
            "policy_name": self.policy_name,
            "instance_count": self.instance_count,
            "mean_bins": self.mean_bins,
            "mean_excess": self.mean_excess,
            "p95_excess": self.p95_excess,
            "worst_excess": self.worst_excess,
            "source_file_mean_excess": dict(
                self.source_file_mean_excess
            ),
            "observations": list(self.observations),
        }


def evaluate_external_policy(
    policy: OnlineHeuristic,
    records: Sequence[ORLibraryRecord],
) -> ExternalBenchmarkReport:
    if not records:
        raise ValueError("external confirmation requires at least one instance")
    observations = []
    by_source: Dict[str, list] = {}
    for record in records:
        bin_count, decision_digest = _audited_trace(record, policy)
        excess = bin_count - record.best_known_bin_count
        observation = {
            "instance_id": record.instance.instance_id,
            "source_file": record.source_file,
            "source_identifier": record.source_identifier,
            "bin_count": bin_count,
            "recorded_best_known": record.best_known_bin_count,
            "excess": excess,
            "decision_digest": decision_digest,
        }
        observations.append(observation)
        by_source.setdefault(record.source_file, []).append(float(excess))
    excesses = [float(value["excess"]) for value in observations]
    bins = [float(value["bin_count"]) for value in observations]
    return ExternalBenchmarkReport(
        policy_name=policy.name,
        instance_count=len(observations),
        mean_bins=mean(bins),
        mean_excess=mean(excesses),
        p95_excess=_quantile(excesses, 0.95),
        worst_excess=int(max(excesses)),
        source_file_mean_excess={
            source: mean(values)
            for source, values in sorted(by_source.items())
        },
        observations=tuple(observations),
    )


def _program_from_frozen(value: Mapping[str, Any]) -> PriorityProgram:
    if value.get("dsl_version") != DSL_VERSION:
        raise ValueError("frozen candidate uses an unsupported DSL version")
    program = PriorityProgram(
        Expression.from_dict(value["expression"])
    )
    if program.candidate_id != value.get("candidate_id"):
        raise ValueError("frozen candidate identity does not match expression")
    return program


def _behaviour_fingerprint(
    report: ExternalBenchmarkReport,
) -> Tuple[Tuple[str, str], ...]:
    return tuple(
        (
            str(observation["instance_id"]),
            str(observation["decision_digest"]),
        )
        for observation in report.observations
    )


def _paired_summary(
    left: ExternalBenchmarkReport,
    right: ExternalBenchmarkReport,
) -> Mapping[str, Any]:
    left_by_id = {
        str(observation["instance_id"]): int(observation["bin_count"])
        for observation in left.observations
    }
    right_by_id = {
        str(observation["instance_id"]): int(observation["bin_count"])
        for observation in right.observations
    }
    if set(left_by_id) != set(right_by_id):
        raise ValueError("paired reports do not cover the same instances")
    differences = [
        left_by_id[instance_id] - right_by_id[instance_id]
        for instance_id in sorted(left_by_id)
    ]
    return {
        "left": left.policy_name,
        "right": right.policy_name,
        "mean_bin_difference_left_minus_right": mean(differences),
        "left_wins": sum(value < 0 for value in differences),
        "ties": sum(value == 0 for value in differences),
        "left_losses": sum(value > 0 for value in differences),
    }


@dataclass(frozen=True)
class ConfirmationOutcome:
    frozen_bundle_digest: str
    corpus_digest: str
    source_checksums: Mapping[str, str]
    reports: Mapping[str, ExternalBenchmarkReport]
    paired_comparisons: Mapping[str, Mapping[str, Any]]
    known_policy_equivalence: Mapping[str, Tuple[str, ...]]
    prediction_results: Mapping[str, bool]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "confirmation_version": CONFIRMATION_VERSION,
            "frozen_bundle_digest": self.frozen_bundle_digest,
            "corpus_digest": self.corpus_digest,
            "source_checksums": dict(sorted(self.source_checksums.items())),
            "reports": {
                name: report.as_dict()
                for name, report in sorted(self.reports.items())
            },
            "paired_comparisons": {
                name: dict(value)
                for name, value in sorted(
                    self.paired_comparisons.items()
                )
            },
            "known_policy_equivalence": {
                name: list(value)
                for name, value in sorted(
                    self.known_policy_equivalence.items()
                )
            },
            "prediction_results": dict(
                sorted(self.prediction_results.items())
            ),
        }


def confirm_frozen_candidates(
    frozen_bundle: Mapping[str, Any],
    records: Sequence[ORLibraryRecord],
    source_checksums: Mapping[str, str],
) -> ConfirmationOutcome:
    contract = frozen_bundle.get("training_contract", {})
    if contract.get("external_benchmark_opened") is not False:
        raise ValueError("bundle lacks a clean sealed-benchmark declaration")
    source_contract = frozen_bundle.get("external_source_contract", {})
    source_files = source_contract.get("files", ())
    expected_checksums = {
        str(entry["name"]): str(entry["sha256"])
        for entry in source_files
    }
    if not expected_checksums:
        raise ValueError("bundle does not pin external source checksums")
    if dict(source_checksums) != expected_checksums:
        raise ValueError(
            "observed external checksums differ from the frozen contract"
        )
    roles = frozen_bundle.get("candidate_roles", {})
    expected_roles = {
        "random_augmentation_control",
        "adversarial_augmentation_treatment",
    }
    if set(roles) != expected_roles:
        raise ValueError("frozen bundle does not contain the two M3 arms")
    programs = {
        role: _program_from_frozen(value)
        for role, value in roles.items()
    }
    policies: Dict[str, OnlineHeuristic] = {
        **programs,
        "best_fit": baseline_heuristics()["best_fit"],
        "funsearch_or_reference": literature_heuristics()[
            "funsearch_or_reference"
        ],
    }
    reports = {
        name: evaluate_external_policy(policy, records)
        for name, policy in policies.items()
    }
    treatment = reports["adversarial_augmentation_treatment"]
    control = reports["random_augmentation_control"]
    published = reports["funsearch_or_reference"]
    known_fingerprints = {
        name: _behaviour_fingerprint(reports[name])
        for name in ("best_fit", "funsearch_or_reference")
    }
    known_policy_equivalence = {
        role: tuple(
            sorted(
                known_name
                for known_name, fingerprint in known_fingerprints.items()
                if _behaviour_fingerprint(reports[role]) == fingerprint
            )
        )
        for role in sorted(expected_roles)
    }
    return ConfirmationOutcome(
        frozen_bundle_digest=content_digest(frozen_bundle),
        corpus_digest=corpus_digest(records),
        source_checksums=source_checksums,
        reports=reports,
        paired_comparisons={
            "treatment_vs_control": _paired_summary(
                treatment,
                control,
            ),
            "treatment_vs_funsearch": _paired_summary(
                treatment,
                published,
            ),
        },
        known_policy_equivalence=known_policy_equivalence,
        prediction_results={
            "adversarial_beats_random": (
                treatment.mean_excess < control.mean_excess
            ),
            "candidate_beats_published_reference": (
                treatment.mean_excess < published.mean_excess
            ),
        },
    )
