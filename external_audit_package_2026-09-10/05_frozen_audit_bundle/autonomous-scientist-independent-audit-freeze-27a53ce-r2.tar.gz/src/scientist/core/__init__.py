"""Scientific artifact and experiment contracts."""

