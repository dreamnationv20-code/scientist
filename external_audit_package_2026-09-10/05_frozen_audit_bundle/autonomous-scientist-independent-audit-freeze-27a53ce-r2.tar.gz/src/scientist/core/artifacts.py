from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Dict, Iterator, Tuple


class ArtifactConflictError(RuntimeError):
    """Raised when an immutable artifact would be overwritten."""


class ArtifactIntegrityError(RuntimeError):
    """Raised when stored content does not match its content identity."""


_DIGEST_PATTERN = re.compile(r"[0-9a-f]{64}")
_MANIFEST_ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._+:-]{0,254}")


def _validated_digest(digest: str) -> str:
    value = str(digest)
    if _DIGEST_PATTERN.fullmatch(value) is None:
        raise ValueError("artifact digest must be 64 lowercase hexadecimal characters")
    return value


def _validated_manifest_id(run_id: str) -> str:
    value = str(run_id)
    if _MANIFEST_ID_PATTERN.fullmatch(value) is None:
        raise ValueError("manifest id contains unsafe or unsupported characters")
    return value


def canonical_json(value: Any) -> bytes:
    if is_dataclass(value):
        value = asdict(value)
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def content_digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


class ArtifactStore:
    """Small content-addressed store with atomic, immutable writes."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.objects = self.root / "objects"
        self.manifests = self.root / "manifests"
        self.objects.mkdir(parents=True, exist_ok=True)
        self.manifests.mkdir(parents=True, exist_ok=True)

    def put(self, kind: str, value: Any) -> str:
        if not kind:
            raise ValueError("artifact kind must not be empty")
        envelope = {"schema": 1, "kind": kind, "value": value}
        digest = content_digest(envelope)
        destination = self.objects / digest[:2] / (digest[2:] + ".json")
        self._write_immutable(destination, canonical_json(envelope) + b"\n")
        return digest

    def get(self, digest: str) -> Dict[str, Any]:
        digest = _validated_digest(digest)
        path = self.objects / digest[:2] / (digest[2:] + ".json")
        with path.open("r", encoding="utf-8") as handle:
            envelope = json.load(handle)
        if not isinstance(envelope, dict):
            raise ArtifactIntegrityError("artifact envelope must be a JSON object")
        observed = content_digest(envelope)
        if observed != digest:
            raise ArtifactIntegrityError(
                "artifact content does not match requested digest: %s" % digest
            )
        return envelope

    def iter_kind(self, kind: str) -> Iterator[Tuple[str, Any]]:
        """Yield integrity-checked artifacts of one kind in digest order."""

        if not kind:
            raise ValueError("artifact kind must not be empty")
        if not self.objects.exists():
            return
        for path in sorted(self.objects.glob("[0-9a-f][0-9a-f]/*.json")):
            digest = path.parent.name + path.stem
            envelope = self.get(digest)
            if envelope.get("kind") == kind:
                yield digest, envelope["value"]

    def write_manifest(self, run_id: str, value: Any) -> Path:
        run_id = _validated_manifest_id(run_id)
        destination = self.manifests / (run_id + ".json")
        self._write_immutable(destination, canonical_json(value) + b"\n")
        return destination

    @staticmethod
    def _write_immutable(destination: Path, payload: bytes) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=destination.name + ".",
            suffix=".tmp",
            dir=str(destination.parent),
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.link(temporary_name, destination)
            except FileExistsError:
                if destination.read_bytes() != payload:
                    raise ArtifactConflictError(
                        "Refusing to mutate immutable artifact: %s"
                        % destination
                    )
        finally:
            temporary_path = Path(temporary_name)
            if temporary_path.exists():
                temporary_path.unlink()
