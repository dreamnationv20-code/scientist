from __future__ import annotations

from typing import Any, Mapping, Optional


class ScientificCommandPaused(RuntimeError):
    """A durable, non-failing pause awaiting an external bounded input."""

    exit_code = 75

    def __init__(
        self,
        message: str,
        *,
        details: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.details = {} if details is None else dict(details)
