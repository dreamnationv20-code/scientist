from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping

from scientist.core.artifacts import content_digest


SOURCE_TREE_DIGEST_VERSION = "source-tree-digest-v1"


def bytes_sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def source_tree_digest(
    root: Path,
    relative_paths: Iterable[Path],
) -> Mapping[str, Any]:
    root = Path(root)
    files: Dict[str, str] = {}
    for relative_path in sorted(
        (Path(path) for path in relative_paths),
        key=lambda path: path.as_posix(),
    ):
        path = root / relative_path
        if not path.is_file():
            raise FileNotFoundError("source file does not exist: %s" % path)
        files[relative_path.as_posix()] = bytes_sha256(path.read_bytes())
    return {
        "version": SOURCE_TREE_DIGEST_VERSION,
        "digest": content_digest(
            {
                "version": SOURCE_TREE_DIGEST_VERSION,
                "files": files,
            }
        ),
        "files": files,
    }


def python_source_tree_digest(project_root: Path) -> Mapping[str, Any]:
    project_root = Path(project_root)
    paths = list((project_root / "src").rglob("*.py"))
    relative_paths = [path.relative_to(project_root) for path in paths]
    for name in ("pyproject.toml", "uv.lock"):
        path = project_root / name
        if path.is_file():
            relative_paths.append(Path(name))
    return source_tree_digest(project_root, relative_paths)
