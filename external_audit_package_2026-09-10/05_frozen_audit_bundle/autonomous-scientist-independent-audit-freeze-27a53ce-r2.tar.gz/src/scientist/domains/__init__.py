"""Scientific domain adapters."""

