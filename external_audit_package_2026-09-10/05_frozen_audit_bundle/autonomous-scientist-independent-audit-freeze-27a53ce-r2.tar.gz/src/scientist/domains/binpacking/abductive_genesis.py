from __future__ import annotations

from dataclasses import dataclass
import math
import random
from statistics import mean
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.generators import generate_instance
from scientist.domains.binpacking.heuristics import (
    OnlineHeuristic,
    baseline_heuristics,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.representation_capacity import (
    AdvantageTrainingExample,
    LinearAdvantageModel,
    fit_linear_advantage_model,
)
from scientist.program.discovery_evidence import paired_episode_evidence


ABDUCTIVE_GENESIS_VERSION = "codex-mediated-abductive-genesis-v1"


@dataclass(frozen=True)
class GenesisPartition:
    name: str
    seed_offset: int
    episodes_per_length: int


@dataclass(frozen=True)
class GenesisConfig:
    capacity: int = 150
    item_low: int = 20
    item_high: int = 100
    lengths: Tuple[int, ...] = (120, 250, 500)
    base_seed: int = 248_104_026
    probes_per_episode: int = 6
    minimum_history_items: int = 12
    maximum_action_representatives: int = 16

    def __post_init__(self) -> None:
        if self.capacity != 150 or (self.item_low, self.item_high) != (20, 100):
            raise ValueError("genesis v1 is committed to the OR distribution")
        if not self.lengths or min(self.lengths) < 24:
            raise ValueError("invalid genesis lengths")
        if self.probes_per_episode < 2 or self.minimum_history_items < 0:
            raise ValueError("invalid genesis probe schedule")
        if self.maximum_action_representatives < 4:
            raise ValueError("too few action representatives")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "capacity": self.capacity,
            "item_low": self.item_low,
            "item_high": self.item_high,
            "lengths": list(self.lengths),
            "base_seed": self.base_seed,
            "probes_per_episode": self.probes_per_episode,
            "minimum_history_items": self.minimum_history_items,
            "maximum_action_representatives": self.maximum_action_representatives,
        }


def genesis_suite(
    config: GenesisConfig,
    partition: GenesisPartition,
) -> Tuple[BinPackingInstance, ...]:
    if not partition.name or partition.seed_offset < 0:
        raise ValueError("invalid genesis partition")
    if partition.episodes_per_length <= 0:
        raise ValueError("genesis partition must contain episodes")
    return tuple(
        generate_instance(
            "or_uniform",
            seed=(
                config.base_seed
                + partition.seed_offset
                + length_index * 10_000_000
                + episode_index
            ),
            length=length,
            capacity=config.capacity,
        )
        for length_index, length in enumerate(config.lengths)
        for episode_index in range(partition.episodes_per_length)
    )


def _action_ref(action: Optional[int]) -> str:
    return "new" if action is None else "bin:%d" % action


def _parse_action(action_ref: str) -> Optional[int]:
    if action_ref == "new":
        return None
    if not action_ref.startswith("bin:"):
        raise ValueError("invalid genesis action reference")
    return int(action_ref.split(":", 1)[1])


def _apply_action(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    if action is None:
        return (*loads, item)
    if action < 0 or action >= len(loads) or loads[action] + item > capacity:
        raise ValueError("genesis policy selected an illegal action")
    updated = list(loads)
    updated[action] += item
    return tuple(updated)


def _successor_signature(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    return tuple(sorted(_apply_action(action, item, loads, capacity)))


def _legal_actions(
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[Optional[int], ...]:
    return (
        *(index for index, load in enumerate(loads) if load + item <= capacity),
        None,
    )


def _quantile_indices(count: int, wanted: int) -> Tuple[int, ...]:
    if count <= wanted:
        return tuple(range(count))
    return tuple(
        sorted(
            {
                int(round(rank * (count - 1) / float(wanted - 1)))
                for rank in range(wanted)
            }
        )
    )


def representative_actions(
    item: int,
    loads: Sequence[int],
    capacity: int,
    baseline_action: Optional[int],
    maximum: int,
) -> Tuple[Optional[int], ...]:
    """Cover successor-distinct residual choices without overweighting duplicate bins."""

    by_load: Dict[int, int] = {}
    for action, load in enumerate(loads):
        if load + item > capacity:
            continue
        incumbent = by_load.get(load)
        if incumbent is None or action == baseline_action:
            by_load[load] = action
    actions = tuple(
        sorted(
            (*by_load.values(), None),
            key=lambda action: (
                capacity - item
                if action is None
                else capacity - loads[action] - item,
                len(loads) if action is None else action,
            ),
        )
    )
    if len(actions) <= maximum:
        return actions
    keep = {actions[index] for index in _quantile_indices(len(actions), maximum)}
    keep.add(baseline_action)
    keep.add(None)
    if len(keep) > maximum:
        removable = [
            action
            for action in actions
            if action in keep and action not in (baseline_action, None)
        ]
        while len(keep) > maximum:
            keep.remove(removable.pop(len(removable) // 2))
    return tuple(action for action in actions if action in keep)


def _fast_policy_action_features(
    name: str,
    *,
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
    action: Optional[int],
) -> Mapping[str, float]:
    """Compute exactly the frozen representation's inputs and no unused fields."""

    if name not in ("residual_ecology", "demand_portfolio_dual"):
        return observable_action_features(
            item=item,
            loads=loads,
            capacity=capacity,
            item_index=item_index,
            history=history,
            action=action,
        )
    successor = _apply_action(action, item, loads, capacity)
    residuals = tuple(capacity - load for load in successor)
    post_residual = (
        capacity - item if action is None else capacity - loads[action] - item
    )
    dead_count = float(sum(residual < 20 for residual in residuals))
    support_count = float(sum(20 <= residual <= 100 for residual in residuals))
    oversized_count = float(sum(residual > 100 for residual in residuals))
    if name == "residual_ecology":
        normalized = tuple(residual / float(capacity) for residual in residuals)
        return {
            "action_is_new": float(action is None),
            "portfolio_dead_count": dead_count,
            "portfolio_support_count": support_count,
            "portfolio_oversized_count": oversized_count,
            "portfolio_mean_residual": mean(normalized) if normalized else 1.0,
            "portfolio_q10": _percentile(normalized, 0.10),
            "portfolio_q25": _percentile(normalized, 0.25),
            "portfolio_q50": _percentile(normalized, 0.50),
            "portfolio_q75": _percentile(normalized, 0.75),
            "portfolio_q90": _percentile(normalized, 0.90),
            "portfolio_residual_entropy": _entropy(residuals),
        }
    recent = tuple(history[-128:])
    empirical_tightness = []
    empirical_options = []
    for possible_item in recent[-48:]:
        feasible_after = tuple(
            residual - possible_item
            for residual in residuals
            if residual >= possible_item
        )
        if feasible_after:
            empirical_tightness.append(min(feasible_after) / float(capacity))
            empirical_options.append(len(feasible_after))
        else:
            empirical_tightness.append((capacity - possible_item) / float(capacity))
            empirical_options.append(0)
    uniform_tightness = []
    uniform_options = []
    for possible_item in range(20, 101):
        feasible_after = tuple(
            residual - possible_item
            for residual in residuals
            if residual >= possible_item
        )
        if feasible_after:
            uniform_tightness.append(min(feasible_after) / float(capacity))
            uniform_options.append(len(feasible_after))
        else:
            uniform_tightness.append((capacity - possible_item) / float(capacity))
            uniform_options.append(0)
    return {
        "action_is_new": float(action is None),
        "post_residual_dead": float(post_residual < 20),
        "post_residual_in_demand_support": float(20 <= post_residual <= 100),
        "portfolio_dead_count": dead_count,
        "portfolio_support_count": support_count,
        "portfolio_oversized_count": oversized_count,
        "uniform_next_open_probability": sum(
            count == 0 for count in uniform_options
        ) / float(len(uniform_options)),
        "uniform_next_single_option_probability": sum(
            count == 1 for count in uniform_options
        ) / float(len(uniform_options)),
        "uniform_next_tightness": mean(uniform_tightness),
        "uniform_next_log_option_count": mean(
            math.log1p(count) for count in uniform_options
        ),
        "empirical_next_tightness": (
            mean(empirical_tightness) if empirical_tightness else 0.0
        ),
        "empirical_next_option_count": (
            mean(empirical_options) if empirical_options else 0.0
        ),
    }


def _probe_indices(config: GenesisConfig, length: int) -> Tuple[int, ...]:
    first = config.minimum_history_items
    last = length - 2
    if last <= first:
        raise ValueError("episode is too short for genesis probes")
    return tuple(
        sorted(
            {
                int(
                    round(
                        first
                        + rank
                        * (last - first)
                        / float(config.probes_per_episode - 1)
                    )
                )
                for rank in range(config.probes_per_episode)
            }
        )
    )


def _percentile(values: Sequence[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(float(value) for value in values)
    position = fraction * (len(ordered) - 1)
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def _entropy(values: Sequence[int]) -> float:
    if not values:
        return 0.0
    counts: Dict[int, int] = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    total = float(len(values))
    return -sum(
        (count / total) * math.log(count / total)
        for count in counts.values()
    )


def observable_action_features(
    *,
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
    action: Optional[int],
) -> Mapping[str, float]:
    """Rich online-only descriptors for abductive analysis and predictions."""

    successor = _apply_action(action, item, loads, capacity)
    residuals = tuple(capacity - load for load in successor)
    post_residual = capacity - item if action is None else capacity - loads[action] - item
    recent = tuple(history[-128:])
    support_residuals = tuple(
        residual for residual in residuals if 20 <= residual <= 100
    )
    dead_residuals = sum(residual < 20 for residual in residuals)
    oversized_residuals = sum(residual > 100 for residual in residuals)
    empirical_exact = (
        sum(abs(value - post_residual) <= 2 for value in recent)
        / float(max(1, len(recent)))
    )
    empirical_near = (
        sum(abs(value - post_residual) <= 6 for value in recent)
        / float(max(1, len(recent)))
    )
    sample = recent[-48:]
    next_tightness = []
    next_option_counts = []
    for next_item in sample:
        feasible_after = tuple(
            residual - next_item for residual in residuals if residual >= next_item
        )
        if feasible_after:
            next_tightness.append(min(feasible_after) / float(capacity))
            next_option_counts.append(len(feasible_after))
        else:
            next_tightness.append((capacity - next_item) / float(capacity))
            next_option_counts.append(0)
    uniform_tightness = []
    uniform_options = []
    for possible_item in range(20, 101):
        feasible_after = tuple(
            residual - possible_item
            for residual in residuals
            if residual >= possible_item
        )
        if feasible_after:
            uniform_tightness.append(min(feasible_after) / float(capacity))
            uniform_options.append(len(feasible_after))
        else:
            uniform_tightness.append((capacity - possible_item) / float(capacity))
            uniform_options.append(0)
    normalized = tuple(residual / float(capacity) for residual in residuals)
    return {
        "item_ratio": item / float(capacity),
        "progress_log": math.log1p(item_index),
        "open_bin_count": float(len(loads)),
        "action_is_new": float(action is None),
        "post_residual": float(post_residual),
        "post_residual_ratio": post_residual / float(capacity),
        "post_residual_dead": float(post_residual < 20),
        "post_residual_in_demand_support": float(20 <= post_residual <= 100),
        "post_residual_oversized": float(post_residual > 100),
        "portfolio_dead_count": float(dead_residuals),
        "portfolio_support_count": float(len(support_residuals)),
        "portfolio_oversized_count": float(oversized_residuals),
        "portfolio_mean_residual": mean(normalized) if normalized else 1.0,
        "portfolio_q10": _percentile(normalized, 0.10),
        "portfolio_q25": _percentile(normalized, 0.25),
        "portfolio_q50": _percentile(normalized, 0.50),
        "portfolio_q75": _percentile(normalized, 0.75),
        "portfolio_q90": _percentile(normalized, 0.90),
        "portfolio_residual_entropy": _entropy(residuals),
        "empirical_exact_complement_density": empirical_exact,
        "empirical_near_complement_density": empirical_near,
        "empirical_next_tightness": mean(next_tightness) if next_tightness else 0.0,
        "empirical_next_option_count": mean(next_option_counts) if next_option_counts else 0.0,
        "uniform_next_open_probability": sum(
            count == 0 for count in uniform_options
        ) / float(len(uniform_options)),
        "uniform_next_single_option_probability": sum(
            count == 1 for count in uniform_options
        ) / float(len(uniform_options)),
        "uniform_next_tightness": mean(uniform_tightness),
        "uniform_next_option_count": mean(uniform_options),
        "uniform_next_log_option_count": mean(
            math.log1p(count) for count in uniform_options
        ),
        "history_mean_ratio": mean(recent) / capacity if recent else 0.0,
        "history_q25_ratio": _percentile(recent, 0.25) / capacity if recent else 0.0,
        "history_q50_ratio": _percentile(recent, 0.50) / capacity if recent else 0.0,
        "history_q75_ratio": _percentile(recent, 0.75) / capacity if recent else 0.0,
    }


def _terminal_after_intervention(
    instance: BinPackingInstance,
    *,
    item_index: int,
    loads: Sequence[int],
    history: Sequence[int],
    action: Optional[int],
    continuation: OnlineHeuristic,
) -> int:
    item = instance.items[item_index]
    current_loads = _apply_action(action, item, loads, instance.capacity)
    current_history = (*history, item)
    for next_index in range(item_index + 1, len(instance.items)):
        next_item = instance.items[next_index]
        next_action = continuation.choose_bin(
            next_item,
            current_loads,
            instance.capacity,
            next_index,
            current_history,
        )
        current_loads = _apply_action(
            next_action, next_item, current_loads, instance.capacity
        )
        current_history = (*current_history, next_item)[-128:]
    return len(current_loads)


def build_causal_atlas(
    config: GenesisConfig,
    partition: GenesisPartition,
) -> Mapping[str, Any]:
    baseline = baseline_heuristics()["best_fit"]
    probes = []
    instances = genesis_suite(config, partition)
    for instance in instances:
        selected_indices = set(_probe_indices(config, len(instance.items)))
        loads: Tuple[int, ...] = ()
        history: Tuple[int, ...] = ()
        for item_index, item in enumerate(instance.items):
            baseline_action = baseline.choose_bin(
                item, loads, instance.capacity, item_index, history
            )
            if item_index in selected_indices:
                actions = representative_actions(
                    item,
                    loads,
                    instance.capacity,
                    baseline_action,
                    config.maximum_action_representatives,
                )
                terminal_bins = {
                    action: _terminal_after_intervention(
                        instance,
                        item_index=item_index,
                        loads=loads,
                        history=history,
                        action=action,
                        continuation=baseline,
                    )
                    for action in actions
                }
                baseline_bins = terminal_bins[baseline_action]
                probe_body = {
                    "partition": partition.name,
                    "instance_id": instance.instance_id,
                    "length": len(instance.items),
                    "seed": instance.seed,
                    "item_index": item_index,
                    "item": item,
                    "loads": list(loads),
                    "history": list(history[-128:]),
                    "baseline_action_ref": _action_ref(baseline_action),
                    "baseline_terminal_bins": baseline_bins,
                    "actions": [
                        {
                            "action_ref": _action_ref(action),
                            "terminal_bins": terminal_bins[action],
                            "terminal_advantage": baseline_bins - terminal_bins[action],
                            "features": dict(
                                observable_action_features(
                                    item=item,
                                    loads=loads,
                                    capacity=instance.capacity,
                                    item_index=item_index,
                                    history=history,
                                    action=action,
                                )
                            ),
                        }
                        for action in actions
                    ],
                }
                probe_body["probe_id"] = content_digest(probe_body)
                probes.append(probe_body)
            loads = _apply_action(
                baseline_action, item, loads, instance.capacity
            )
            history = (*history, item)[-128:]

    rows = tuple(action for probe in probes for action in probe["actions"])
    helpful = tuple(row for row in rows if row["terminal_advantage"] > 0)
    harmful = tuple(row for row in rows if row["terminal_advantage"] < 0)
    report: Dict[str, Any] = {
        "schema": 1,
        "version": ABDUCTIVE_GENESIS_VERSION,
        "partition": partition.name,
        "config": config.as_dict(),
        "partition_config": {
            "seed_offset": partition.seed_offset,
            "episodes_per_length": partition.episodes_per_length,
        },
        "trajectory_policy": "best_fit",
        "continuation_policy": "best_fit",
        "comparator_exposed": False,
        "future_items_available_to_features": False,
        "instance_count": len(instances),
        "probe_count": len(probes),
        "action_row_count": len(rows),
        "helpful_action_row_count": len(helpful),
        "harmful_action_row_count": len(harmful),
        "terminal_opportunity_probe_count": sum(
            any(action["terminal_advantage"] > 0 for action in probe["actions"])
            for probe in probes
        ),
        "aggregate_oracle_intervention_advantage": sum(
            max(action["terminal_advantage"] for action in probe["actions"])
            for probe in probes
        ),
        "episode_seed_commitment": content_digest(
            [(len(instance.items), instance.seed) for instance in instances]
        ),
        "probes": probes,
    }
    report["atlas_id"] = content_digest(report)
    return report


def _terminal_after_synthetic_suffix(
    *,
    item: int,
    item_index: int,
    loads: Sequence[int],
    history: Sequence[int],
    capacity: int,
    action: Optional[int],
    suffix: Sequence[int],
    continuation: OnlineHeuristic,
) -> int:
    current_loads = _apply_action(action, item, loads, capacity)
    current_history = (*history, item)[-128:]
    for offset, next_item in enumerate(suffix, start=1):
        next_action = continuation.choose_bin(
            next_item,
            current_loads,
            capacity,
            item_index + offset,
            current_history,
        )
        current_loads = _apply_action(
            next_action, next_item, current_loads, capacity
        )
        current_history = (*current_history, next_item)[-128:]
    return len(current_loads)


def build_distributional_causal_atlas(
    config: GenesisConfig,
    partition: GenesisPartition,
    *,
    suffix_samples_per_action: int = 32,
    suffix_horizon: int = 96,
    baseline_policy: Optional[OnlineHeuristic] = None,
) -> Mapping[str, Any]:
    """Estimate intervention value over common synthetic futures, not one suffix."""

    if suffix_samples_per_action < 4 or suffix_horizon < 8:
        raise ValueError("distributional causal credit is underpowered")
    baseline = baseline_policy or baseline_heuristics()["best_fit"]
    baseline_name = baseline.name
    probes = []
    instances = genesis_suite(config, partition)
    for instance in instances:
        selected_indices = set(_probe_indices(config, len(instance.items)))
        loads: Tuple[int, ...] = ()
        history: Tuple[int, ...] = ()
        for item_index, item in enumerate(instance.items):
            baseline_action = baseline.choose_bin(
                item, loads, instance.capacity, item_index, history
            )
            if item_index in selected_indices:
                actions = representative_actions(
                    item,
                    loads,
                    instance.capacity,
                    baseline_action,
                    config.maximum_action_representatives,
                )
                rollout_material = {
                    "version": ABDUCTIVE_GENESIS_VERSION,
                    "credit": "distributional_common_random_numbers",
                    "instance_seed": instance.seed,
                    "item_index": item_index,
                    "suffix_samples": suffix_samples_per_action,
                    "suffix_horizon": suffix_horizon,
                }
                rollout_seed = int(content_digest(rollout_material)[:16], 16)
                rng = random.Random(rollout_seed)
                suffixes = tuple(
                    tuple(rng.randint(20, 100) for _ in range(suffix_horizon))
                    for _ in range(suffix_samples_per_action)
                )
                samples_by_action = {
                    action: tuple(
                        _terminal_after_synthetic_suffix(
                            item=item,
                            item_index=item_index,
                            loads=loads,
                            history=history,
                            capacity=instance.capacity,
                            action=action,
                            suffix=suffix,
                            continuation=baseline,
                        )
                        for suffix in suffixes
                    )
                    for action in actions
                }
                means = {
                    action: mean(values)
                    for action, values in samples_by_action.items()
                }
                baseline_mean = means[baseline_action]
                probe_body = {
                    "partition": partition.name,
                    "instance_id": instance.instance_id,
                    "length": len(instance.items),
                    "seed": instance.seed,
                    "item_index": item_index,
                    "item": item,
                    "loads": list(loads),
                    "history": list(history[-128:]),
                    "baseline_action_ref": _action_ref(baseline_action),
                    "baseline_terminal_bins": baseline_mean,
                    "rollout_seed": rollout_seed,
                    "actions": [
                        {
                            "action_ref": _action_ref(action),
                            "terminal_bins": means[action],
                            "terminal_advantage": baseline_mean - means[action],
                            "rollout_bin_counts": list(samples_by_action[action]),
                            "features": dict(
                                observable_action_features(
                                    item=item,
                                    loads=loads,
                                    capacity=instance.capacity,
                                    item_index=item_index,
                                    history=history,
                                    action=action,
                                )
                            ),
                        }
                        for action in actions
                    ],
                }
                probe_body["probe_id"] = content_digest(probe_body)
                probes.append(probe_body)
            loads = _apply_action(
                baseline_action, item, loads, instance.capacity
            )
            history = (*history, item)[-128:]
    rows = tuple(action for probe in probes for action in probe["actions"])
    epsilon = 1e-12
    report: Dict[str, Any] = {
        "schema": 1,
        "version": "%s-distributional-credit" % ABDUCTIVE_GENESIS_VERSION,
        "partition": partition.name,
        "config": config.as_dict(),
        "partition_config": {
            "seed_offset": partition.seed_offset,
            "episodes_per_length": partition.episodes_per_length,
        },
        "trajectory_policy": baseline_name,
        "continuation_policy": baseline_name,
        "credit": "mean_over_common_random_number_iid_suffixes",
        "suffix_samples_per_action": suffix_samples_per_action,
        "suffix_horizon": suffix_horizon,
        "common_random_numbers_across_actions": True,
        "rollout_samples_counted_as_independent_evidence": False,
        "comparator_exposed": False,
        "future_items_available_to_features": False,
        "instance_count": len(instances),
        "probe_count": len(probes),
        "action_row_count": len(rows),
        "helpful_action_row_count": sum(
            row["terminal_advantage"] > epsilon for row in rows
        ),
        "harmful_action_row_count": sum(
            row["terminal_advantage"] < -epsilon for row in rows
        ),
        "terminal_opportunity_probe_count": sum(
            any(action["terminal_advantage"] > epsilon for action in probe["actions"])
            for probe in probes
        ),
        "aggregate_oracle_intervention_advantage": sum(
            max(action["terminal_advantage"] for action in probe["actions"])
            for probe in probes
        ),
        "episode_seed_commitment": content_digest(
            [(len(instance.items), instance.seed) for instance in instances]
        ),
        "probes": probes,
    }
    report["atlas_id"] = content_digest(report)
    return report


def atlas_feature_summary(atlas: Mapping[str, Any]) -> Mapping[str, Any]:
    rows = [
        {**action, "probe_id": probe["probe_id"]}
        for probe in atlas["probes"]
        for action in probe["actions"]
        if action["action_ref"] != probe["baseline_action_ref"]
    ]
    feature_names = sorted(rows[0]["features"]) if rows else []
    summaries = []
    for feature in feature_names:
        ordered = sorted(rows, key=lambda row: row["features"][feature])
        if not ordered:
            continue
        boundaries = [
            int(round(index * len(ordered) / 5.0)) for index in range(6)
        ]
        groups = [ordered[boundaries[index] : boundaries[index + 1]] for index in range(5)]
        summaries.append(
            {
                "feature": feature,
                "quintiles": [
                    {
                        "count": len(group),
                        "feature_mean": mean(
                            row["features"][feature] for row in group
                        ) if group else 0.0,
                        "terminal_advantage_mean": mean(
                            row["terminal_advantage"] for row in group
                        ) if group else 0.0,
                        "helpful_rate": sum(
                            row["terminal_advantage"] > 0 for row in group
                        ) / float(max(1, len(group))),
                        "harmful_rate": sum(
                            row["terminal_advantage"] < 0 for row in group
                        ) / float(max(1, len(group))),
                    }
                    for group in groups
                ],
            }
        )
    return {
        "atlas_id": atlas["atlas_id"],
        "baseline_actions_excluded": True,
        "row_count": len(rows),
        "feature_summaries": summaries,
    }


_REPRESENTATIONS: Mapping[str, Mapping[str, Any]] = {
    "arrival_hazard": {
        "representation": (
            "A successor is represented by the probability that the next "
            "unknown arrival cannot use its residual portfolio, together with "
            "the expected tightness of the best available placement."
        ),
        "mechanism": (
            "Avoid actions that make the residual portfolio unable to absorb "
            "a broad range of plausible next items, even when they close the "
            "current bin more tightly."
        ),
        "features": (
            "action_is_new",
            "post_residual_dead",
            "portfolio_dead_count",
            "portfolio_support_count",
            "uniform_next_open_probability",
            "uniform_next_tightness",
        ),
        "prediction": (
            "Held-out actions predicted to reduce arrival hazard will have "
            "positive terminal advantage after conservative abstention."
        ),
        "falsifier": (
            "The held-out top-action terminal-advantage confidence interval "
            "includes zero or the score/advantage association is non-positive."
        ),
    },
    "option_scarcity": {
        "representation": (
            "Each residual portfolio is a supply curve: for every possible "
            "arrival size, count how many distinct bins could absorb it."
        ),
        "mechanism": (
            "A tight placement can consume the sole option for a range of "
            "future items; preserve scarce options while allowing redundant "
            "options to be consolidated."
        ),
        "features": (
            "action_is_new",
            "portfolio_dead_count",
            "uniform_next_open_probability",
            "uniform_next_single_option_probability",
            "uniform_next_option_count",
            "uniform_next_log_option_count",
        ),
        "prediction": (
            "Interventions that preserve the option-supply curve will show "
            "positive terminal credit on untouched episodes."
        ),
        "falsifier": (
            "Conservative option-scarcity predictions fail either held-out "
            "association or positive selected-action credit."
        ),
    },
    "residual_ecology": {
        "representation": (
            "The open bins form a residual ecology summarized by dead, usable, "
            "and oversized niches plus portfolio quantiles and diversity."
        ),
        "mechanism": (
            "Terminal waste arises from a population imbalance of residual "
            "niches, not from one bin's residual in isolation."
        ),
        "features": (
            "action_is_new",
            "portfolio_dead_count",
            "portfolio_support_count",
            "portfolio_oversized_count",
            "portfolio_mean_residual",
            "portfolio_q10",
            "portfolio_q25",
            "portfolio_q50",
            "portfolio_q75",
            "portfolio_q90",
            "portfolio_residual_entropy",
        ),
        "prediction": (
            "Actions that restore a balanced residual ecology will transfer to "
            "held-out terminal counterfactuals."
        ),
        "falsifier": (
            "Ecology scores do not associate positively with held-out terminal "
            "credit or selected actions have non-positive mean credit."
        ),
    },
    "empirical_complement_field": {
        "representation": (
            "Recent arrivals induce an empirical complement field over the "
            "entire successor residual portfolio."
        ),
        "mechanism": (
            "Residuals repeatedly matched by observed demand should be retained "
            "or created, while unmatched residuals can be consumed."
        ),
        "features": (
            "action_is_new",
            "portfolio_dead_count",
            "portfolio_support_count",
            "empirical_exact_complement_density",
            "empirical_near_complement_density",
            "empirical_next_tightness",
            "empirical_next_option_count",
            "portfolio_residual_entropy",
        ),
        "prediction": (
            "The learned complement field will identify transferable helpful "
            "departures without access to future items."
        ),
        "falsifier": (
            "Prediction association or conservative selected-action credit is "
            "not positive on the untouched mechanism partition."
        ),
    },
    "demand_portfolio_dual": {
        "representation": (
            "A successor is represented jointly by a distributional demand "
            "model and a portfolio supply curve, approximating an online dual "
            "price for residual capacity."
        ),
        "mechanism": (
            "The useful shadow price of capacity depends on which arrival sizes "
            "the whole portfolio can still serve, rather than remaining space."
        ),
        "features": (
            "action_is_new",
            "post_residual_dead",
            "post_residual_in_demand_support",
            "portfolio_dead_count",
            "portfolio_support_count",
            "portfolio_oversized_count",
            "uniform_next_open_probability",
            "uniform_next_single_option_probability",
            "uniform_next_tightness",
            "uniform_next_log_option_count",
            "empirical_next_tightness",
            "empirical_next_option_count",
        ),
        "prediction": (
            "Positive dual-margin interventions will retain terminal advantage "
            "on new seeds and lengths."
        ),
        "falsifier": (
            "The frozen dual margin has non-positive held-out association or "
            "non-positive conservative intervention return."
        ),
    },
    "phase_conditioned_ecology": {
        "representation": (
            "Residual ecology is conditioned on online maturity: item count and "
            "portfolio scale determine whether diversity or consolidation is "
            "currently scarce."
        ),
        "mechanism": (
            "Early exploratory residual creation and late consolidation have "
            "different causal value; a stationary placement rule confounds them."
        ),
        "features": (
            "progress_log",
            "open_bin_count",
            "action_is_new",
            "portfolio_dead_count",
            "portfolio_support_count",
            "portfolio_oversized_count",
            "portfolio_q10",
            "portfolio_q50",
            "portfolio_q90",
            "uniform_next_open_probability",
            "uniform_next_single_option_probability",
            "uniform_next_log_option_count",
            "empirical_next_tightness",
            "empirical_next_option_count",
        ),
        "interactions": (
            ("progress_log", "uniform_next_open_probability"),
            ("progress_log", "portfolio_dead_count"),
            ("open_bin_count", "uniform_next_single_option_probability"),
            ("portfolio_dead_count", "uniform_next_log_option_count"),
        ),
        "prediction": (
            "Phase-conditioned margins will transfer better than an unconditioned "
            "scalar residual rule on the untouched mechanism partition."
        ),
        "falsifier": (
            "The phase-conditioned score fails positive held-out association or "
            "its selected actions fail positive terminal return."
        ),
    },
}


def _representation_features(
    name: str,
    features: Mapping[str, float],
) -> Mapping[str, float]:
    spec = _REPRESENTATIONS[name]
    selected = {
        feature: float(features[feature]) for feature in spec["features"]
    }
    for left, right in spec.get("interactions", ()):
        selected["interaction:%s*%s" % (left, right)] = (
            float(features[left]) * float(features[right])
        )
    return selected


def _fresh_action_features(
    probe: Mapping[str, Any], action_ref: str
) -> Mapping[str, float]:
    return observable_action_features(
        item=int(probe["item"]),
        loads=tuple(int(value) for value in probe["loads"]),
        capacity=150,
        item_index=int(probe["item_index"]),
        history=tuple(int(value) for value in probe["history"]),
        action=_parse_action(action_ref),
    )


@dataclass(frozen=True)
class GenesisHypothesis:
    hypothesis_id: str
    name: str
    representation: str
    mechanism: str
    prediction: str
    falsifier: str
    model: LinearAdvantageModel
    adoption_threshold: float
    discovery_calibration: Mapping[str, Any]

    def as_dict(self) -> Mapping[str, Any]:
        body = {
            "name": self.name,
            "representation": self.representation,
            "mechanism": self.mechanism,
            "prediction": self.prediction,
            "falsifier": self.falsifier,
            "model": self.model.as_dict(),
            "adoption_threshold": self.adoption_threshold,
            "discovery_calibration": dict(self.discovery_calibration),
            "policy_form": (
                "score every successor-distinct legal action in the declared "
                "representation; depart from best_fit only when the best "
                "alternative exceeds the frozen conservative margin"
            ),
            "comparator_exposed": False,
        }
        return {**body, "hypothesis_id": content_digest(body)}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "GenesisHypothesis":
        result = cls(
            hypothesis_id=str(value["hypothesis_id"]),
            name=str(value["name"]),
            representation=str(value["representation"]),
            mechanism=str(value["mechanism"]),
            prediction=str(value["prediction"]),
            falsifier=str(value["falsifier"]),
            model=LinearAdvantageModel.from_dict(value["model"]),
            adoption_threshold=float(value["adoption_threshold"]),
            discovery_calibration=dict(value["discovery_calibration"]),
        )
        if result.as_dict()["hypothesis_id"] != result.hypothesis_id:
            raise ValueError("genesis hypothesis identity mismatch")
        return result


def _hypothesis_rows(
    atlas: Mapping[str, Any], representation_name: str
) -> Tuple[AdvantageTrainingExample, ...]:
    rows = []
    for probe in atlas["probes"]:
        informative = len(
            {action["terminal_bins"] for action in probe["actions"]}
        ) > 1
        for action in probe["actions"]:
            fresh = _fresh_action_features(probe, action["action_ref"])
            rows.append(
                AdvantageTrainingExample(
                    state_id=str(probe["probe_id"]),
                    instance_id=str(probe["instance_id"]),
                    action_ref=str(action["action_ref"]),
                    features=_representation_features(
                        representation_name, fresh
                    ),
                    advantage=float(action["terminal_advantage"]),
                    informative=informative,
                )
            )
    return tuple(rows)


def _calibrate_threshold(
    atlas: Mapping[str, Any],
    representation_name: str,
    model: LinearAdvantageModel,
) -> Tuple[float, Mapping[str, Any]]:
    margins = []
    for probe in atlas["probes"]:
        scored = []
        for action in probe["actions"]:
            features = _representation_features(
                representation_name,
                _fresh_action_features(probe, action["action_ref"]),
            )
            scored.append((model.predict(features), action))
        baseline_score = next(
            score
            for score, action in scored
            if action["action_ref"] == probe["baseline_action_ref"]
        )
        alternatives = tuple(
            pair for pair in scored if pair[1]["action_ref"] != probe["baseline_action_ref"]
        )
        if not alternatives:
            continue
        best_score, best_action = max(alternatives, key=lambda pair: pair[0])
        margins.append(
            {
                "probe_id": probe["probe_id"],
                "margin": float(best_score - baseline_score),
                "terminal_advantage": float(best_action["terminal_advantage"]),
            }
        )
    positive_margins = sorted({row["margin"] for row in margins if row["margin"] > 0.0})
    if not positive_margins:
        return math.inf, {
            "activation_count": 0,
            "net_terminal_advantage": 0,
            "helpful_count": 0,
            "harmful_count": 0,
        }
    candidate_indices = _quantile_indices(len(positive_margins), min(80, len(positive_margins)))
    thresholds = tuple(
        max(0.0, positive_margins[index] - 1e-12) for index in candidate_indices
    )
    evaluated = []
    for threshold in thresholds:
        selected = tuple(row for row in margins if row["margin"] > threshold)
        if len(selected) < 8:
            continue
        net = sum(row["terminal_advantage"] for row in selected)
        helpful = sum(row["terminal_advantage"] > 0 for row in selected)
        harmful = sum(row["terminal_advantage"] < 0 for row in selected)
        evaluated.append(
            (
                net,
                helpful - harmful,
                -len(selected),
                threshold,
                selected,
            )
        )
    if not evaluated:
        threshold = positive_margins[-1]
        return threshold, {
            "activation_count": 0,
            "net_terminal_advantage": 0,
            "helpful_count": 0,
            "harmful_count": 0,
        }
    net, _, _, threshold, selected = max(evaluated, key=lambda row: row[:4])
    return float(threshold), {
        "activation_count": len(selected),
        "net_terminal_advantage": net,
        "helpful_count": sum(
            row["terminal_advantage"] > 0 for row in selected
        ),
        "harmful_count": sum(
            row["terminal_advantage"] < 0 for row in selected
        ),
        "neutral_count": sum(
            row["terminal_advantage"] == 0 for row in selected
        ),
        "minimum_activation_count": 8,
        "threshold_selection_inputs": "discovery counterfactual labels only",
    }


def fit_genesis_hypotheses(atlas: Mapping[str, Any]) -> Tuple[GenesisHypothesis, ...]:
    hypotheses = []
    for index, (name, spec) in enumerate(_REPRESENTATIONS.items()):
        rows = _hypothesis_rows(atlas, name)
        model = fit_linear_advantage_model(
            rows,
            seed=248_104_026 + index,
            epochs=50,
            learning_rate=0.003,
            ridge=0.002,
            informative_weight=4.0,
        )
        threshold, calibration = _calibrate_threshold(atlas, name, model)
        provisional = GenesisHypothesis(
            hypothesis_id="",
            name=name,
            representation=str(spec["representation"]),
            mechanism=str(spec["mechanism"]),
            prediction=str(spec["prediction"]),
            falsifier=str(spec["falsifier"]),
            model=model,
            adoption_threshold=threshold,
            discovery_calibration=calibration,
        )
        hypotheses.append(
            GenesisHypothesis.from_dict(provisional.as_dict())
        )
    return tuple(hypotheses)


@dataclass(frozen=True)
class GenesisHypothesisPolicy:
    hypothesis: GenesisHypothesis

    @property
    def name(self) -> str:
        return "genesis_%s" % self.hypothesis.name

    def _features(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
        action: Optional[int],
    ) -> Mapping[str, float]:
        return _representation_features(
            self.hypothesis.name,
            observable_action_features(
                item=item,
                loads=loads,
                capacity=capacity,
                item_index=item_index,
                history=history,
                action=action,
            ),
        )

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        baseline = baseline_heuristics()["best_fit"].choose_bin(
            item, loads, capacity, item_index, history
        )
        actions = representative_actions(
            item, loads, capacity, baseline, maximum=32
        )
        baseline_score = self.hypothesis.model.predict(
            self._features(
                item, loads, capacity, item_index, history, baseline
            )
        )
        alternatives = tuple(action for action in actions if action != baseline)
        if not alternatives:
            return baseline
        scored = tuple(
            (
                self.hypothesis.model.predict(
                    self._features(
                        item, loads, capacity, item_index, history, action
                    )
                ),
                -order,
                action,
            )
            for order, action in enumerate(alternatives)
        )
        score, _, selected = max(scored, key=lambda row: (row[0], row[1]))
        if score - baseline_score > self.hypothesis.adoption_threshold:
            return selected
        return baseline


def _correlation(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right) or len(left) < 2:
        return 0.0
    left_mean = mean(left)
    right_mean = mean(right)
    numerator = sum(
        (x - left_mean) * (y - right_mean) for x, y in zip(left, right)
    )
    left_scale = math.sqrt(sum((x - left_mean) ** 2 for x in left))
    right_scale = math.sqrt(sum((y - right_mean) ** 2 for y in right))
    if left_scale == 0.0 or right_scale == 0.0:
        return 0.0
    return numerator / (left_scale * right_scale)


def evaluate_mechanism_prediction(
    hypothesis: GenesisHypothesis,
    atlas: Mapping[str, Any],
    *,
    bootstrap_samples: int = 2_000,
) -> Mapping[str, Any]:
    if bootstrap_samples < 200:
        raise ValueError("mechanism prediction needs a stable cluster bootstrap")
    rows = []
    selected_by_episode: Dict[str, float] = {}
    activation_by_episode: Dict[str, int] = {}
    selected_rows = []
    for probe in atlas["probes"]:
        scored = []
        for action in probe["actions"]:
            features = _representation_features(
                hypothesis.name,
                _fresh_action_features(probe, action["action_ref"]),
            )
            scored.append((hypothesis.model.predict(features), action))
        baseline_score = next(
            score
            for score, action in scored
            if action["action_ref"] == probe["baseline_action_ref"]
        )
        alternatives = tuple(
            pair
            for pair in scored
            if pair[1]["action_ref"] != probe["baseline_action_ref"]
        )
        for score, action in alternatives:
            rows.append(
                {
                    "instance_id": probe["instance_id"],
                    "probe_id": probe["probe_id"],
                    "predicted_margin": float(score - baseline_score),
                    "terminal_advantage": float(action["terminal_advantage"]),
                }
            )
        episode_id = str(probe["instance_id"])
        selected_by_episode.setdefault(episode_id, 0.0)
        activation_by_episode.setdefault(episode_id, 0)
        if alternatives:
            score, action = max(alternatives, key=lambda pair: pair[0])
            margin = float(score - baseline_score)
            if margin > hypothesis.adoption_threshold:
                advantage = float(action["terminal_advantage"])
                selected_by_episode[episode_id] += advantage
                activation_by_episode[episode_id] += 1
                selected_rows.append(
                    {
                        "instance_id": episode_id,
                        "probe_id": probe["probe_id"],
                        "predicted_margin": margin,
                        "terminal_advantage": advantage,
                    }
                )
    predicted = tuple(row["predicted_margin"] for row in rows)
    observed = tuple(row["terminal_advantage"] for row in rows)
    association = _correlation(predicted, observed)
    by_episode: Dict[str, list[Mapping[str, Any]]] = {}
    for row in rows:
        by_episode.setdefault(str(row["instance_id"]), []).append(row)
    episode_ids = sorted(by_episode)
    rng = random.Random(248_104_026 + int(hypothesis.hypothesis_id[:8], 16))
    bootstrapped = []
    for _ in range(bootstrap_samples):
        sample = [episode_ids[rng.randrange(len(episode_ids))] for _ in episode_ids]
        sampled_rows = [row for episode_id in sample for row in by_episode[episode_id]]
        bootstrapped.append(
            _correlation(
                tuple(row["predicted_margin"] for row in sampled_rows),
                tuple(row["terminal_advantage"] for row in sampled_rows),
            )
        )
    ordered = sorted(bootstrapped)
    association_lower = _percentile(ordered, 0.025)
    association_upper = _percentile(ordered, 0.975)
    episode_values = tuple(selected_by_episode[episode_id] for episode_id in episode_ids)
    selected_evidence = paired_episode_evidence(episode_values, episode_ids)
    activated_episode_ids = tuple(
        episode_id for episode_id in episode_ids if activation_by_episode[episode_id]
    )
    activated_evidence = (
        paired_episode_evidence(
            tuple(selected_by_episode[episode_id] for episode_id in activated_episode_ids),
            activated_episode_ids,
        ).as_dict()
        if len(activated_episode_ids) >= 2
        else None
    )
    passed = bool(
        association_lower > 0.0
        and selected_evidence.mean_ci_lower > 0.0
    )
    return {
        "hypothesis_id": hypothesis.hypothesis_id,
        "name": hypothesis.name,
        "atlas_id": atlas["atlas_id"],
        "prediction_frozen_before_atlas": True,
        "counterfactual_row_count": len(rows),
        "prediction_association": association,
        "episode_cluster_bootstrap_association_ci_lower": association_lower,
        "episode_cluster_bootstrap_association_ci_upper": association_upper,
        "bootstrap_samples": bootstrap_samples,
        "activation_count": len(selected_rows),
        "activated_episode_count": len(activated_episode_ids),
        "selected_action_helpful_count": sum(
            row["terminal_advantage"] > 0 for row in selected_rows
        ),
        "selected_action_harmful_count": sum(
            row["terminal_advantage"] < 0 for row in selected_rows
        ),
        "selected_action_neutral_count": sum(
            row["terminal_advantage"] == 0 for row in selected_rows
        ),
        "selected_action_episode_evidence_all_committed_episodes": (
            selected_evidence.as_dict()
        ),
        "selected_action_episode_evidence_activated_episodes": activated_evidence,
        "mechanism_replication_passed": passed,
        "gate": {
            "association_ci_lower_strictly_positive": association_lower > 0.0,
            "all_episode_selected_return_ci_lower_strictly_positive": (
                selected_evidence.mean_ci_lower > 0.0
            ),
        },
    }


def _expanded_representation_features(
    name: str,
    features: Mapping[str, float],
) -> Mapping[str, float]:
    base = dict(_representation_features(name, features))
    expanded = dict(base)
    for feature, value in base.items():
        expanded["square:%s" % feature] = float(value) ** 2
        for threshold in (0.10, 0.25, 0.50, 0.75):
            expanded["hinge:%s:%.2f" % (feature, threshold)] = max(
                0.0, float(value) - threshold
            )
    return expanded


def _menu_features(
    name: str,
    action_features: Sequence[Mapping[str, float]],
    baseline_index: int,
) -> Mapping[str, float]:
    represented = tuple(
        _expanded_representation_features(name, features)
        for features in action_features
    )
    baseline = represented[baseline_index]
    alternatives = tuple(
        features
        for index, features in enumerate(represented)
        if index != baseline_index
    )
    result: Dict[str, float] = {
        "menu_action_count": float(len(represented)),
        "menu_has_alternative": float(bool(alternatives)),
    }
    for feature, baseline_value in baseline.items():
        result["baseline:%s" % feature] = float(baseline_value)
        deltas = tuple(
            float(value[feature] - baseline_value) for value in alternatives
        )
        result["menu_min_delta:%s" % feature] = min(deltas) if deltas else 0.0
        result["menu_max_delta:%s" % feature] = max(deltas) if deltas else 0.0
        result["menu_range_delta:%s" % feature] = (
            max(deltas) - min(deltas) if deltas else 0.0
        )
    return result


@dataclass(frozen=True)
class GenesisTwoStageHypothesis:
    hypothesis_id: str
    name: str
    representation: str
    mechanism: str
    prediction: str
    falsifier: str
    opportunity_model: LinearAdvantageModel
    action_model: LinearAdvantageModel
    opportunity_threshold: float
    action_threshold: float
    discovery_calibration: Mapping[str, Any]

    def as_dict(self) -> Mapping[str, Any]:
        body = {
            "name": self.name,
            "representation": self.representation,
            "mechanism": self.mechanism,
            "prediction": self.prediction,
            "falsifier": self.falsifier,
            "opportunity_model": self.opportunity_model.as_dict(),
            "action_model": self.action_model.as_dict(),
            "opportunity_threshold": self.opportunity_threshold,
            "action_threshold": self.action_threshold,
            "discovery_calibration": dict(self.discovery_calibration),
            "policy_form": (
                "model repairable-state opportunity separately from causal "
                "action credit; depart from best_fit only when both frozen "
                "margins pass"
            ),
            "credit_target": "expected terminal return over common random futures",
            "comparator_exposed": False,
        }
        return {**body, "hypothesis_id": content_digest(body)}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "GenesisTwoStageHypothesis":
        result = cls(
            hypothesis_id=str(value["hypothesis_id"]),
            name=str(value["name"]),
            representation=str(value["representation"]),
            mechanism=str(value["mechanism"]),
            prediction=str(value["prediction"]),
            falsifier=str(value["falsifier"]),
            opportunity_model=LinearAdvantageModel.from_dict(
                value["opportunity_model"]
            ),
            action_model=LinearAdvantageModel.from_dict(value["action_model"]),
            opportunity_threshold=float(value["opportunity_threshold"]),
            action_threshold=float(value["action_threshold"]),
            discovery_calibration=dict(value["discovery_calibration"]),
        )
        if result.as_dict()["hypothesis_id"] != result.hypothesis_id:
            raise ValueError("two-stage genesis hypothesis identity mismatch")
        return result


def _two_stage_probe_scores(
    hypothesis: GenesisTwoStageHypothesis,
    probe: Mapping[str, Any],
) -> Tuple[float, float, Mapping[str, Any]]:
    actions = tuple(probe["actions"])
    raw = tuple(
        _fresh_action_features(probe, action["action_ref"])
        for action in actions
    )
    baseline_index = next(
        index
        for index, action in enumerate(actions)
        if action["action_ref"] == probe["baseline_action_ref"]
    )
    opportunity_score = hypothesis.opportunity_model.predict(
        _menu_features(hypothesis.name, raw, baseline_index)
    )
    scored = tuple(
        (
            hypothesis.action_model.predict(
                _expanded_representation_features(hypothesis.name, features)
            ),
            action,
        )
        for features, action in zip(raw, actions)
    )
    baseline_score = scored[baseline_index][0]
    alternatives = tuple(
        pair for index, pair in enumerate(scored) if index != baseline_index
    )
    if not alternatives:
        return opportunity_score, -math.inf, actions[baseline_index]
    best_score, best_action = max(alternatives, key=lambda pair: pair[0])
    return opportunity_score, float(best_score - baseline_score), best_action


def _fit_two_stage_models(
    atlas: Mapping[str, Any],
    name: str,
    seed: int,
) -> Tuple[LinearAdvantageModel, LinearAdvantageModel]:
    action_rows = []
    opportunity_rows = []
    for probe in atlas["probes"]:
        raw = tuple(
            _fresh_action_features(probe, action["action_ref"])
            for action in probe["actions"]
        )
        baseline_index = next(
            index
            for index, action in enumerate(probe["actions"])
            if action["action_ref"] == probe["baseline_action_ref"]
        )
        best_advantage = max(
            float(action["terminal_advantage"])
            for action in probe["actions"]
        )
        informative = any(
            abs(float(action["terminal_advantage"])) > 1e-12
            for action in probe["actions"]
        )
        opportunity_rows.append(
            AdvantageTrainingExample(
                state_id=str(probe["probe_id"]),
                instance_id=str(probe["instance_id"]),
                action_ref="state",
                features=_menu_features(name, raw, baseline_index),
                advantage=best_advantage,
                informative=informative,
            )
        )
        for features, action in zip(raw, probe["actions"]):
            action_rows.append(
                AdvantageTrainingExample(
                    state_id=str(probe["probe_id"]),
                    instance_id=str(probe["instance_id"]),
                    action_ref=str(action["action_ref"]),
                    features=_expanded_representation_features(name, features),
                    advantage=float(action["terminal_advantage"]),
                    informative=informative,
                )
            )
    opportunity_model = fit_linear_advantage_model(
        tuple(opportunity_rows),
        seed=seed,
        epochs=70,
        learning_rate=0.002,
        ridge=0.003,
        informative_weight=2.0,
    )
    action_model = fit_linear_advantage_model(
        tuple(action_rows),
        seed=seed + 10_000,
        epochs=70,
        learning_rate=0.002,
        ridge=0.003,
        informative_weight=3.0,
    )
    return opportunity_model, action_model


def _calibrate_two_stage_thresholds(
    atlas: Mapping[str, Any],
    hypothesis: GenesisTwoStageHypothesis,
) -> Tuple[float, float, Mapping[str, Any]]:
    rows = []
    for probe in atlas["probes"]:
        opportunity, action_margin, action = _two_stage_probe_scores(
            hypothesis, probe
        )
        rows.append(
            {
                "opportunity": opportunity,
                "action_margin": action_margin,
                "advantage": float(action["terminal_advantage"]),
            }
        )
    opportunity_values = sorted({row["opportunity"] for row in rows})
    action_values = sorted(
        {row["action_margin"] for row in rows if math.isfinite(row["action_margin"])}
    )
    opportunity_indices = _quantile_indices(
        len(opportunity_values), min(24, len(opportunity_values))
    )
    action_indices = _quantile_indices(
        len(action_values), min(24, len(action_values))
    )
    evaluated = []
    for opportunity_index in opportunity_indices:
        opportunity_threshold = opportunity_values[opportunity_index] - 1e-12
        for action_index in action_indices:
            action_threshold = action_values[action_index] - 1e-12
            selected = tuple(
                row
                for row in rows
                if row["opportunity"] > opportunity_threshold
                and row["action_margin"] > action_threshold
            )
            if len(selected) < 20:
                continue
            net = sum(row["advantage"] for row in selected)
            harmful_magnitude = -sum(
                min(0.0, row["advantage"]) for row in selected
            )
            evaluated.append(
                (
                    net - 0.25 * harmful_magnitude,
                    net,
                    -harmful_magnitude,
                    -len(selected),
                    opportunity_threshold,
                    action_threshold,
                    selected,
                )
            )
    if not evaluated:
        return math.inf, math.inf, {
            "activation_count": 0,
            "net_expected_terminal_advantage": 0.0,
        }
    selected_row = max(evaluated, key=lambda row: row[:6])
    _, net, _, _, opportunity_threshold, action_threshold, selected = selected_row
    return float(opportunity_threshold), float(action_threshold), {
        "activation_count": len(selected),
        "net_expected_terminal_advantage": net,
        "mean_expected_terminal_advantage": net / len(selected),
        "helpful_count": sum(row["advantage"] > 1e-12 for row in selected),
        "harmful_count": sum(row["advantage"] < -1e-12 for row in selected),
        "neutral_count": sum(abs(row["advantage"]) <= 1e-12 for row in selected),
        "minimum_activation_count": 20,
        "threshold_selection_inputs": "v2 discovery distributional labels only",
    }


def fit_two_stage_genesis_hypotheses(
    atlas: Mapping[str, Any],
) -> Tuple[GenesisTwoStageHypothesis, ...]:
    hypotheses = []
    for index, (name, spec) in enumerate(_REPRESENTATIONS.items()):
        opportunity_model, action_model = _fit_two_stage_models(
            atlas, name, 348_104_026 + index
        )
        provisional = GenesisTwoStageHypothesis(
            hypothesis_id="",
            name=name,
            representation=str(spec["representation"]),
            mechanism=(
                str(spec["mechanism"])
                + " Opportunity existence and responsible action are modeled separately."
            ),
            prediction=str(spec["prediction"]),
            falsifier=str(spec["falsifier"]),
            opportunity_model=opportunity_model,
            action_model=action_model,
            opportunity_threshold=0.0,
            action_threshold=0.0,
            discovery_calibration={},
        )
        opportunity_threshold, action_threshold, calibration = (
            _calibrate_two_stage_thresholds(atlas, provisional)
        )
        frozen = GenesisTwoStageHypothesis(
            hypothesis_id="",
            name=provisional.name,
            representation=provisional.representation,
            mechanism=provisional.mechanism,
            prediction=provisional.prediction,
            falsifier=provisional.falsifier,
            opportunity_model=opportunity_model,
            action_model=action_model,
            opportunity_threshold=opportunity_threshold,
            action_threshold=action_threshold,
            discovery_calibration=calibration,
        )
        hypotheses.append(
            GenesisTwoStageHypothesis.from_dict(frozen.as_dict())
        )
    return tuple(hypotheses)


@dataclass(frozen=True)
class GenesisTwoStagePolicy:
    hypothesis: GenesisTwoStageHypothesis

    @property
    def name(self) -> str:
        return "genesis_v2_%s" % self.hypothesis.name

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        baseline = baseline_heuristics()["best_fit"].choose_bin(
            item, loads, capacity, item_index, history
        )
        actions = representative_actions(
            item, loads, capacity, baseline, maximum=32
        )
        raw = tuple(
            _fast_policy_action_features(
                self.hypothesis.name,
                item=item,
                loads=loads,
                capacity=capacity,
                item_index=item_index,
                history=history,
                action=action,
            )
            for action in actions
        )
        baseline_index = actions.index(baseline)
        opportunity = self.hypothesis.opportunity_model.predict(
            _menu_features(self.hypothesis.name, raw, baseline_index)
        )
        if opportunity <= self.hypothesis.opportunity_threshold:
            return baseline
        scores = tuple(
            self.hypothesis.action_model.predict(
                _expanded_representation_features(self.hypothesis.name, features)
            )
            for features in raw
        )
        alternatives = tuple(
            (score, -index, action)
            for index, (score, action) in enumerate(zip(scores, actions))
            if index != baseline_index
        )
        if not alternatives:
            return baseline
        score, _, selected = max(alternatives, key=lambda row: (row[0], row[1]))
        if score - scores[baseline_index] > self.hypothesis.action_threshold:
            return selected
        return baseline


def evaluate_two_stage_mechanism_prediction(
    hypothesis: GenesisTwoStageHypothesis,
    atlas: Mapping[str, Any],
    *,
    bootstrap_samples: int = 2_000,
) -> Mapping[str, Any]:
    rows = []
    selected_by_episode: Dict[str, float] = {}
    activation_by_episode: Dict[str, int] = {}
    for probe in atlas["probes"]:
        opportunity, action_margin, action = _two_stage_probe_scores(
            hypothesis, probe
        )
        advantage = float(action["terminal_advantage"])
        if math.isfinite(action_margin):
            rows.append(
                {
                    "instance_id": str(probe["instance_id"]),
                    "predicted_margin": action_margin,
                    "terminal_advantage": advantage,
                }
            )
        episode_id = str(probe["instance_id"])
        selected_by_episode.setdefault(episode_id, 0.0)
        activation_by_episode.setdefault(episode_id, 0)
        if (
            opportunity > hypothesis.opportunity_threshold
            and action_margin > hypothesis.action_threshold
        ):
            selected_by_episode[episode_id] += advantage
            activation_by_episode[episode_id] += 1
    association = _correlation(
        tuple(row["predicted_margin"] for row in rows),
        tuple(row["terminal_advantage"] for row in rows),
    )
    by_episode: Dict[str, list[Mapping[str, Any]]] = {}
    for row in rows:
        by_episode.setdefault(row["instance_id"], []).append(row)
    association_episode_ids = sorted(by_episode)
    rng = random.Random(348_104_026 + int(hypothesis.hypothesis_id[:8], 16))
    bootstrapped = []
    for _ in range(bootstrap_samples):
        sample = [
            association_episode_ids[rng.randrange(len(association_episode_ids))]
            for _ in association_episode_ids
        ]
        sampled = [row for episode_id in sample for row in by_episode[episode_id]]
        bootstrapped.append(
            _correlation(
                tuple(row["predicted_margin"] for row in sampled),
                tuple(row["terminal_advantage"] for row in sampled),
            )
        )
    association_lower = _percentile(sorted(bootstrapped), 0.025)
    episode_ids = sorted(selected_by_episode)
    evidence = paired_episode_evidence(
        tuple(selected_by_episode[episode_id] for episode_id in episode_ids),
        episode_ids,
    )
    passed = association_lower > 0.0 and evidence.mean_ci_lower > 0.0
    return {
        "hypothesis_id": hypothesis.hypothesis_id,
        "name": hypothesis.name,
        "atlas_id": atlas["atlas_id"],
        "prediction_frozen_before_atlas": True,
        "opportunity_and_action_models_separate": True,
        "prediction_association": association,
        "episode_cluster_bootstrap_association_ci_lower": association_lower,
        "episode_cluster_bootstrap_association_ci_upper": _percentile(
            sorted(bootstrapped), 0.975
        ),
        "activation_count": sum(activation_by_episode.values()),
        "activated_episode_count": sum(
            count > 0 for count in activation_by_episode.values()
        ),
        "selected_expected_return_episode_evidence": evidence.as_dict(),
        "mechanism_replication_passed": passed,
        "gate": {
            "association_ci_lower_strictly_positive": association_lower > 0.0,
            "all_episode_selected_expected_return_ci_lower_strictly_positive": (
                evidence.mean_ci_lower > 0.0
            ),
        },
    }


def action_change_rate(
    policy: OnlineHeuristic,
    instances: Iterable[BinPackingInstance],
) -> float:
    baseline = baseline_heuristics()["best_fit"]
    changed = 0
    total = 0
    for instance in instances:
        loads: Tuple[int, ...] = ()
        history: Tuple[int, ...] = ()
        for item_index, item in enumerate(instance.items):
            selected = policy.choose_bin(
                item, loads, instance.capacity, item_index, history
            )
            reference = baseline.choose_bin(
                item, loads, instance.capacity, item_index, history
            )
            changed += _successor_signature(
                selected, item, loads, instance.capacity
            ) != _successor_signature(reference, item, loads, instance.capacity)
            total += 1
            loads = _apply_action(selected, item, loads, instance.capacity)
            history = (*history, item)[-128:]
    return changed / float(max(1, total))
