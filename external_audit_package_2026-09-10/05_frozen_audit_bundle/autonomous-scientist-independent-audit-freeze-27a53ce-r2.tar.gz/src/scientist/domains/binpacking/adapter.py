from __future__ import annotations

from typing import Any, Dict, Iterable, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.counterexamples import (
    Counterexample,
    minimize_policy_gap,
)
from scientist.domains.binpacking.equivalence import behaviour_fingerprint
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import (
    BinPackingInstance,
    PackingResult,
)
from scientist.kernel.contracts import ExecutionMode, SearchFamily
from scientist.kernel.capabilities import (
    ComparisonMode,
    DomainCapability,
    DomainCapabilityManifest,
    ResearchMode,
)
from scientist.kernel.interfaces import PairedComparison, VerificationResult


class BinPackingAdapter:
    """Domain authority connecting online bin packing to the generic kernel."""

    domain_id = "online_1d_bin_packing"
    adapter_version = "binpacking-adapter-v1"
    evaluator_ref = "binpacking-sequential-packer-v1"
    verifier_ref = "binpacking-conservation-auditor-v1"
    execution_mode = ExecutionMode.SEEDED
    capabilities = DomainCapabilityManifest(
        domain_id=domain_id,
        research_modes=(ResearchMode.OPTIMIZATION,),
        capabilities=(
            DomainCapability.PAIRED_COMPARISON,
            DomainCapability.BEHAVIOR_FINGERPRINT,
            DomainCapability.FAILURE_MINIMIZATION,
            DomainCapability.EXPERIMENT_GENERATION,
            DomainCapability.CODE_EXECUTION,
        ),
        comparison_mode=ComparisonMode.PAIRED_INCUMBENT,
        primary_metric="improvement",
        independent_evidence_unit="complete item-sequence episode",
        manifest_ref="binpacking-capabilities-v1",
    )

    @staticmethod
    def _candidate_core(candidate: OnlineHeuristic) -> Dict[str, Any]:
        serializer = getattr(candidate, "as_dict", None)
        if callable(serializer):
            payload = dict(serializer())
            payload.pop("candidate_id", None)
            return payload
        return {
            "candidate_type": (
                type(candidate).__module__ + "." + type(candidate).__qualname__
            ),
            "name": candidate.name,
        }

    def candidate_id(self, candidate: OnlineHeuristic) -> str:
        declared = getattr(candidate, "candidate_id", None)
        if declared is not None:
            return str(declared)
        return content_digest(self._candidate_core(candidate))

    def candidate_as_dict(
        self,
        candidate: OnlineHeuristic,
    ) -> Mapping[str, Any]:
        payload = self._candidate_core(candidate)
        payload["candidate_id"] = self.candidate_id(candidate)
        return payload

    def experiment_id(self, experiment: BinPackingInstance) -> str:
        return experiment.instance_id

    def experiment_as_dict(
        self,
        experiment: BinPackingInstance,
    ) -> Mapping[str, Any]:
        return experiment.as_dict()

    def observation_as_dict(
        self,
        observation: PackingResult,
    ) -> Mapping[str, Any]:
        return observation.as_dict()

    def observation_id(self, observation: PackingResult) -> str:
        return content_digest(self.observation_as_dict(observation))

    def evaluate(
        self,
        candidate: OnlineHeuristic,
        experiment: BinPackingInstance,
    ) -> PackingResult:
        return pack(experiment, candidate)

    def verify(
        self,
        experiment: BinPackingInstance,
        observation: PackingResult,
    ) -> VerificationResult:
        identity_ok = observation.instance_id == experiment.instance_id
        length_ok = len(observation.placements) == len(experiment.items)
        index_ok = True
        item_ok = True
        transition_ok = True
        capacity_ok = True
        loads = []

        if length_ok:
            for expected_index, (item, placement) in enumerate(
                zip(experiment.items, observation.placements)
            ):
                index_ok = (
                    index_ok and placement.item_index == expected_index
                )
                item_ok = item_ok and placement.item == item
                selected = placement.bin_index
                if selected == len(loads):
                    loads.append(item)
                elif 0 <= selected < len(loads):
                    loads[selected] += item
                else:
                    transition_ok = False
                if transition_ok:
                    capacity_ok = capacity_ok and all(
                        0 < load <= experiment.capacity for load in loads
                    )
                    transition_ok = (
                        transition_ok
                        and tuple(loads) == placement.loads_after
                    )

        conservation_ok = sum(loads) == sum(experiment.items)
        bin_count_ok = (
            observation.bin_count == len(loads)
            and (
                not observation.placements
                or observation.bin_count
                == len(observation.placements[-1].loads_after)
            )
        )
        checks = {
            "instance_identity": identity_ok,
            "placement_count": length_ok,
            "item_indices": index_ok,
            "item_values": item_ok,
            "state_transitions": transition_ok,
            "capacity": capacity_ok,
            "conservation": conservation_ok,
            "bin_count": bin_count_ok,
        }
        return VerificationResult(
            passed=all(checks.values()),
            checks=checks,
            details={
                "reported_bin_count": observation.bin_count,
                "reconstructed_bin_count": len(loads),
                "reported_item_sum": sum(experiment.items),
                "reconstructed_item_sum": sum(loads),
            },
            verifier_ref=self.verifier_ref,
        )

    def compare(
        self,
        candidate: OnlineHeuristic,
        incumbent: OnlineHeuristic,
        experiment: BinPackingInstance,
    ) -> PairedComparison:
        candidate_result = self.evaluate(candidate, experiment)
        incumbent_result = self.evaluate(incumbent, experiment)
        return PairedComparison(
            candidate_id=self.candidate_id(candidate),
            incumbent_id=self.candidate_id(incumbent),
            experiment_id=self.experiment_id(experiment),
            metrics={
                "candidate_bins": float(candidate_result.bin_count),
                "incumbent_bins": float(incumbent_result.bin_count),
                "primary_delta": float(
                    candidate_result.bin_count - incumbent_result.bin_count
                ),
                "improvement": float(
                    incumbent_result.bin_count - candidate_result.bin_count
                ),
            },
        )

    def behavior_fingerprint(
        self,
        candidate: OnlineHeuristic,
        experiments: Iterable[BinPackingInstance],
    ) -> str:
        return behaviour_fingerprint(candidate, experiments)

    def minimize_failure(
        self,
        experiment: BinPackingInstance,
        better: OnlineHeuristic,
        worse: OnlineHeuristic,
    ) -> Counterexample:
        return minimize_policy_gap(experiment, better, worse)

    def search_families(self) -> Tuple[SearchFamily, ...]:
        return (
            SearchFamily.ANCESTRY,
            SearchFamily.DE_NOVO,
            SearchFamily.HYBRID,
        )
