from __future__ import annotations

import random
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.monte_carlo_policy_improvement import (
    _cluster_bootstrap_harmful_rate_upper,
    _outcomes,
    _paired_stats,
    summarize_double_sampled_evaluation,
)
from scientist.domains.binpacking.typed_macro_policy_improvement import (
    _macro_outcomes,
    _pure_funsearch_outcomes,
)
from scientist.program.discovery_evidence import paired_episode_evidence


ADAPTIVE_THREE_ARM_RACE_VERSION = "adaptive-three-arm-policy-race-v1"


def _race_suffix_bank(
    probe: Mapping[str, Any],
    *,
    bank: str,
    sample_count: int,
    suffix_horizon: int,
) -> Tuple[int, Tuple[Tuple[int, ...], ...]]:
    material = {
        "version": ADAPTIVE_THREE_ARM_RACE_VERSION,
        "probe_id": str(probe["probe_id"]),
        "bank": bank,
        "sample_count": int(sample_count),
        "suffix_horizon": int(suffix_horizon),
    }
    seed = int(content_digest(material)[:16], 16)
    rng = random.Random(seed)
    return seed, tuple(
        tuple(rng.randint(20, 100) for _ in range(suffix_horizon))
        for _ in range(sample_count)
    )


def action_only_arm(action_ref: str) -> Mapping[str, Any]:
    body = {
        "family": "initial_action_then_funsearch",
        "initial_action_ref": str(action_ref),
    }
    return {**body, "arm_id": content_digest(body)}


def typed_macro_arm(
    action_ref: str,
    *,
    commitment_span: int = 8,
    closure_slack_threshold: int = 5,
) -> Mapping[str, Any]:
    body = {
        "family": "protect_then_close_distinguished_residual",
        "initial_action_ref": str(action_ref),
        "commitment_span": int(commitment_span),
        "closure_slack_threshold": int(closure_slack_threshold),
    }
    return {**body, "macro_id": content_digest(body), "arm_id": content_digest(body)}


def three_arm_pairs(
    probe: Mapping[str, Any],
    *,
    commitment_span: int = 8,
    closure_slack_threshold: int = 5,
) -> Tuple[Mapping[str, Any], ...]:
    baseline_ref = str(probe["baseline_action_ref"])
    pairs = []
    for order, action_ref in enumerate(str(value) for value in probe["action_refs"]):
        if action_ref == baseline_ref:
            continue
        action_arm = action_only_arm(action_ref)
        macro_arm = typed_macro_arm(
            action_ref,
            commitment_span=commitment_span,
            closure_slack_threshold=closure_slack_threshold,
        )
        body = {
            "pair_order": order,
            "initial_action_ref": action_ref,
            "action_only_arm": action_arm,
            "typed_macro_arm": macro_arm,
        }
        pairs.append({**body, "pair_id": content_digest(body)})
    return tuple(pairs)


def _advantage(
    reference_outcomes: Sequence[int], candidate_outcomes: Sequence[int]
) -> Tuple[float, ...]:
    return tuple(
        float(reference - candidate)
        for reference, candidate in zip(reference_outcomes, candidate_outcomes)
    )


def plan_probe_with_adaptive_race(
    probe: Mapping[str, Any],
    *,
    stages: Sequence[int] = (64, 128, 256, 512, 1_024, 2_048),
    suffix_horizon: int = 96,
    planning_bank: str = "adaptive_race_planning_v1",
    mean_critical_value: float = 3.6,
    harm_z: float = 3.6,
    maximum_harm_rate_upper: float = 0.40,
    commitment_span: int = 8,
    closure_slack_threshold: int = 5,
) -> Mapping[str, Any]:
    stages = tuple(int(value) for value in stages)
    if not stages or stages[0] < 2 or any(
        left >= right for left, right in zip(stages, stages[1:])
    ):
        raise ValueError("adaptive stages must be strictly increasing")
    pairs = three_arm_pairs(
        probe,
        commitment_span=commitment_span,
        closure_slack_threshold=closure_slack_threshold,
    )
    planning_seed, suffixes = _race_suffix_bank(
        probe,
        bank=planning_bank,
        sample_count=stages[-1],
        suffix_horizon=suffix_horizon,
    )
    states: Dict[str, Dict[str, Any]] = {
        str(pair["pair_id"]): {
            "pair": pair,
            "action_viable": True,
            "macro_viable": True,
            "baseline_outcomes": [],
            "action_outcomes": [],
            "macro_outcomes": [],
        }
        for pair in pairs
    }
    stage_records = []
    selected: Optional[Mapping[str, Any]] = None
    previous_count = 0
    for stage in stages:
        active_states = tuple(
            state
            for state in states.values()
            if state["action_viable"] or state["macro_viable"]
        )
        if not active_states:
            break
        suffix_segment = suffixes[previous_count:stage]
        baseline_segment = _pure_funsearch_outcomes(probe, suffix_segment)
        eligible = []
        stage_pairs = []
        for state in active_states:
            pair = state["pair"]
            action_segment = _outcomes(
                probe,
                str(pair["initial_action_ref"]),
                suffix_segment,
            )
            macro_segment = _macro_outcomes(
                probe, pair["typed_macro_arm"], suffix_segment
            )
            state["baseline_outcomes"].extend(baseline_segment)
            state["action_outcomes"].extend(action_segment)
            state["macro_outcomes"].extend(macro_segment)
            action_advantage = _advantage(
                state["baseline_outcomes"], state["action_outcomes"]
            )
            macro_advantage = _advantage(
                state["baseline_outcomes"], state["macro_outcomes"]
            )
            macro_increment = _advantage(
                state["action_outcomes"], state["macro_outcomes"]
            )
            action_stats = _paired_stats(
                action_advantage,
                mean_critical_value=mean_critical_value,
                harm_z=harm_z,
            )
            macro_stats = _paired_stats(
                macro_advantage,
                mean_critical_value=mean_critical_value,
                harm_z=harm_z,
            )
            increment_stats = _paired_stats(
                macro_increment,
                mean_critical_value=mean_critical_value,
                harm_z=harm_z,
            )
            action_passes = (
                state["action_viable"]
                and float(action_stats["mean_ci_lower"]) > 0.0
                and float(action_stats["harmful_suffix_rate_wilson_upper"])
                <= maximum_harm_rate_upper
            )
            macro_passes = (
                state["macro_viable"]
                and float(macro_stats["mean_ci_lower"]) > 0.0
                and float(macro_stats["harmful_suffix_rate_wilson_upper"])
                <= maximum_harm_rate_upper
                and float(increment_stats["mean_ci_lower"]) > 0.0
                and float(
                    increment_stats["harmful_suffix_rate_wilson_upper"]
                )
                <= maximum_harm_rate_upper
            )
            if action_passes:
                eligible.append(
                    {
                        "arm_type": "initial_action_then_funsearch",
                        "arm": pair["action_only_arm"],
                        "pair_id": pair["pair_id"],
                        "pair_order": pair["pair_order"],
                        "stage": stage,
                        "baseline_advantage": action_stats,
                        "typed_macro_incremental_advantage": None,
                    }
                )
            if macro_passes:
                eligible.append(
                    {
                        "arm_type": "protect_then_close_distinguished_residual",
                        "arm": pair["typed_macro_arm"],
                        "pair_id": pair["pair_id"],
                        "pair_order": pair["pair_order"],
                        "stage": stage,
                        "baseline_advantage": macro_stats,
                        "typed_macro_incremental_advantage": increment_stats,
                    }
                )
            next_action_viable = (
                state["action_viable"]
                and float(action_stats["mean_ci_upper"]) > 0.0
            )
            next_macro_viable = (
                state["macro_viable"]
                and float(macro_stats["mean_ci_upper"]) > 0.0
                and float(increment_stats["mean_ci_upper"]) > 0.0
            )
            stage_pairs.append(
                {
                    "pair_id": pair["pair_id"],
                    "pair_order": pair["pair_order"],
                    "initial_action_ref": pair["initial_action_ref"],
                    "action_only_was_viable": bool(state["action_viable"]),
                    "typed_macro_was_viable": bool(state["macro_viable"]),
                    "action_only_passed": action_passes,
                    "typed_macro_passed": macro_passes,
                    "action_only_baseline_advantage": action_stats,
                    "typed_macro_baseline_advantage": macro_stats,
                    "typed_macro_incremental_advantage": increment_stats,
                    "action_only_remains_viable": next_action_viable,
                    "typed_macro_remains_viable": next_macro_viable,
                }
            )
            state["action_viable"] = next_action_viable
            state["macro_viable"] = next_macro_viable
        stage_records.append(
            {
                "stage_sample_count": stage,
                "active_pair_count": len(active_states),
                "eligible_arm_count": len(eligible),
                "pairs": stage_pairs,
            }
        )
        if eligible:
            selected = max(
                eligible,
                key=lambda row: (
                    float(row["baseline_advantage"]["mean_ci_lower"]),
                    float(row["baseline_advantage"]["mean_terminal_advantage"]),
                    row["arm_type"] == "initial_action_then_funsearch",
                    -int(row["pair_order"]),
                ),
            )
            break
        previous_count = stage

    return {
        "probe_id": str(probe["probe_id"]),
        "instance_id": str(probe["instance_id"]),
        "length": int(probe["length"]),
        "item_index": int(probe["item_index"]),
        "baseline_action_ref": str(probe["baseline_action_ref"]),
        "planning_bank": planning_bank,
        "planning_bank_seed": planning_seed,
        "maximum_planning_sample_count": stages[-1],
        "planning_suffix_horizon": suffix_horizon,
        "adaptive_stages": list(stages),
        "candidate_pair_count": len(pairs),
        "stage_records": stage_records,
        "eligible_for_episode_arbitration": selected is not None,
        "selected_planning_arm": selected,
        "planner_activated": False,
        "eligible_but_not_episode_selected": False,
        "audit": None,
        "learned_selector_used": False,
        "latent_concept_used": False,
    }


def plan_probe_with_adaptive_action_race(
    probe: Mapping[str, Any],
    *,
    stages: Sequence[int] = (64, 128, 256, 512, 1_024, 2_048),
    suffix_horizon: int = 96,
    planning_bank: str = "adaptive_action_race_full_trajectory_v1",
    mean_critical_value: float = 3.6,
    harm_z: float = 3.6,
    maximum_harm_rate_upper: float = 0.40,
) -> Mapping[str, Any]:
    """Race only causal initial-action deviations; persistent macros are absent."""

    stages = tuple(int(value) for value in stages)
    if not stages or stages[0] < 2 or any(
        left >= right for left, right in zip(stages, stages[1:])
    ):
        raise ValueError("adaptive stages must be strictly increasing")
    pairs = three_arm_pairs(probe)
    planning_seed, suffixes = _race_suffix_bank(
        probe,
        bank=planning_bank,
        sample_count=stages[-1],
        suffix_horizon=suffix_horizon,
    )
    states: Dict[str, Dict[str, Any]] = {
        str(pair["pair_id"]): {
            "pair": pair,
            "viable": True,
            "baseline_outcomes": [],
            "action_outcomes": [],
        }
        for pair in pairs
    }
    stage_records = []
    selected: Optional[Mapping[str, Any]] = None
    previous_count = 0
    for stage in stages:
        active_states = tuple(state for state in states.values() if state["viable"])
        if not active_states:
            break
        suffix_segment = suffixes[previous_count:stage]
        baseline_segment = _pure_funsearch_outcomes(probe, suffix_segment)
        eligible = []
        stage_pairs = []
        for state in active_states:
            pair = state["pair"]
            action_segment = _outcomes(
                probe,
                str(pair["initial_action_ref"]),
                suffix_segment,
            )
            state["baseline_outcomes"].extend(baseline_segment)
            state["action_outcomes"].extend(action_segment)
            stats = _paired_stats(
                _advantage(state["baseline_outcomes"], state["action_outcomes"]),
                mean_critical_value=mean_critical_value,
                harm_z=harm_z,
            )
            passes = (
                float(stats["mean_ci_lower"]) > 0.0
                and float(stats["harmful_suffix_rate_wilson_upper"])
                <= maximum_harm_rate_upper
            )
            remains_viable = float(stats["mean_ci_upper"]) > 0.0
            if passes:
                eligible.append(
                    {
                        "arm_type": "initial_action_then_funsearch",
                        "arm": pair["action_only_arm"],
                        "pair_id": pair["pair_id"],
                        "pair_order": pair["pair_order"],
                        "stage": stage,
                        "baseline_advantage": stats,
                    }
                )
            stage_pairs.append(
                {
                    "pair_id": pair["pair_id"],
                    "pair_order": pair["pair_order"],
                    "initial_action_ref": pair["initial_action_ref"],
                    "passed": passes,
                    "baseline_advantage": stats,
                    "remains_viable": remains_viable,
                }
            )
            state["viable"] = remains_viable
        stage_records.append(
            {
                "stage_sample_count": stage,
                "active_action_count": len(active_states),
                "eligible_action_count": len(eligible),
                "actions": stage_pairs,
            }
        )
        if eligible:
            selected = max(
                eligible,
                key=lambda row: (
                    float(row["baseline_advantage"]["mean_ci_lower"]),
                    float(row["baseline_advantage"]["mean_terminal_advantage"]),
                    -int(row["pair_order"]),
                ),
            )
            break
        previous_count = stage
    return {
        "probe_id": str(probe["probe_id"]),
        "instance_id": str(probe["instance_id"]),
        "length": int(probe["length"]),
        "item_index": int(probe["item_index"]),
        "planning_bank": planning_bank,
        "planning_bank_seed": planning_seed,
        "adaptive_stages": list(stages),
        "planning_suffix_horizon": suffix_horizon,
        "candidate_action_count": len(pairs),
        "stage_records": stage_records,
        "planner_activated": selected is not None,
        "selected_action": selected,
        "persistent_macro_available": False,
        "learned_selector_used": False,
        "latent_concept_used": False,
        "actual_future_items_used": False,
    }


def arbitrate_one_probe_per_episode(
    planning_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    by_episode: Dict[str, list[int]] = {}
    for index, row in enumerate(planning_rows):
        if bool(row["eligible_for_episode_arbitration"]):
            by_episode.setdefault(str(row["instance_id"]), []).append(index)
    winners = set()
    for indices in by_episode.values():
        winner = max(
            indices,
            key=lambda index: (
                float(
                    planning_rows[index]["selected_planning_arm"][
                        "baseline_advantage"
                    ]["mean_ci_lower"]
                ),
                float(
                    planning_rows[index]["selected_planning_arm"][
                        "baseline_advantage"
                    ]["mean_terminal_advantage"]
                ),
                -int(planning_rows[index]["item_index"]),
                str(planning_rows[index]["probe_id"]),
            ),
        )
        winners.add(winner)
    return tuple(
        {
            **row,
            "planner_activated": index in winners,
            "eligible_but_not_episode_selected": (
                bool(row["eligible_for_episode_arbitration"])
                and index not in winners
            ),
        }
        for index, row in enumerate(planning_rows)
    )


def audit_selected_arm(
    probe: Mapping[str, Any],
    planning_row: Mapping[str, Any],
    *,
    audit_sample_count: int = 1_024,
    suffix_horizon: int = 96,
    audit_bank: str = "adaptive_race_independent_audit_v1",
) -> Mapping[str, Any]:
    if not bool(planning_row["planner_activated"]):
        raise ValueError("cannot audit a planning row that lost episode arbitration")
    selected = planning_row["selected_planning_arm"]
    audit_seed, suffixes = _race_suffix_bank(
        probe,
        bank=audit_bank,
        sample_count=audit_sample_count,
        suffix_horizon=suffix_horizon,
    )
    if audit_seed == int(planning_row["planning_bank_seed"]):
        raise RuntimeError("adaptive planning and audit banks are not independent")
    baseline_outcomes = _pure_funsearch_outcomes(probe, suffixes)
    action_ref = str(selected["arm"]["initial_action_ref"])
    action_outcomes = _outcomes(probe, action_ref, suffixes)
    if selected["arm_type"] == "initial_action_then_funsearch":
        selected_outcomes = action_outcomes
        macro_increment = None
    elif selected["arm_type"] == "protect_then_close_distinguished_residual":
        selected_outcomes = _macro_outcomes(probe, selected["arm"], suffixes)
        macro_increment = _advantage(action_outcomes, selected_outcomes)
    else:
        raise ValueError("unknown selected adaptive-race arm")
    selected_advantage = _advantage(baseline_outcomes, selected_outcomes)
    return {
        "audit_bank": audit_bank,
        "audit_bank_seed": audit_seed,
        "audit_bank_independent_of_planning": True,
        "planning_bank_reused_for_evaluation": False,
        "actual_instance_future_items_used": False,
        "common_random_numbers_across_all_audited_arms": True,
        "rollout_suffixes_counted_as_independent_evidence": False,
        **_paired_stats(
            selected_advantage, mean_critical_value=1.96, harm_z=1.96
        ),
        "paired_rollout_advantages": list(selected_advantage),
        "typed_macro_incremental_audit": (
            None
            if macro_increment is None
            else {
                **_paired_stats(
                    macro_increment, mean_critical_value=1.96, harm_z=1.96
                ),
                "paired_rollout_advantages": list(macro_increment),
            }
        ),
    }


def summarize_adaptive_race(
    atlas: Mapping[str, Any],
    rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    base = dict(summarize_double_sampled_evaluation(atlas, rows))
    base.pop("assessment_id", None)
    base.pop("isolated_policy_improvement_passed", None)
    base["version"] = ADAPTIVE_THREE_ARM_RACE_VERSION
    activated = tuple(row for row in rows if bool(row["planner_activated"]))
    if len({str(row["instance_id"]) for row in activated}) != len(activated):
        raise ValueError("adaptive race selected more than one probe per episode")
    action_only = tuple(
        row
        for row in activated
        if row["selected_planning_arm"]["arm_type"]
        == "initial_action_then_funsearch"
    )
    typed_macro = tuple(
        row
        for row in activated
        if row["selected_planning_arm"]["arm_type"]
        == "protect_then_close_distinguished_residual"
    )
    macro_credit_evidence = None
    macro_credit_gate = True
    if typed_macro:
        if len(typed_macro) < 2:
            macro_credit_gate = False
        else:
            evidence = paired_episode_evidence(
                tuple(
                    float(
                        row["audit"]["typed_macro_incremental_audit"][
                            "mean_terminal_advantage"
                        ]
                    )
                    for row in typed_macro
                ),
                tuple(str(row["instance_id"]) for row in typed_macro),
            )
            macro_credit_evidence = evidence.as_dict()
            macro_credit_gate = evidence.mean_ci_lower > 0.0
    base["planning_eligible_probe_count"] = sum(
        bool(row["eligible_for_episode_arbitration"]) for row in rows
    )
    base["one_probe_selected_per_activated_episode"] = True
    base["selected_arm_counts"] = {
        "initial_action_then_funsearch": len(action_only),
        "protect_then_close_distinguished_residual": len(typed_macro),
    }
    base["selected_stage_counts"] = {}
    for row in activated:
        stage = str(row["selected_planning_arm"]["stage"])
        base["selected_stage_counts"][stage] = (
            base["selected_stage_counts"].get(stage, 0) + 1
        )
    base["typed_macro_incremental_credit"] = {
        "selected_macro_episode_count": len(typed_macro),
        "independent_audit_evidence": macro_credit_evidence,
        "gate_passed": macro_credit_gate,
        "interpretation": (
            "No typed macro was selected; no macro credit is claimed."
            if not typed_macro
            else "Macro credit requires a positive episode-level 95% lower bound against the same initial action followed immediately by FunSearch."
        ),
    }
    base["gates"] = {
        **base["gates"],
        "at_most_one_activation_per_source_episode": True,
        "typed_macro_incremental_credit_if_selected": macro_credit_gate,
    }
    base["isolated_adaptive_race_passed"] = all(base["gates"].values())
    base["assessment_id"] = content_digest(base)
    return base
