from __future__ import annotations

import math
import random
from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.binpacking.generators import generate_instance
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance


ADVERSARY_VERSION = "or-sequence-adversary-v1"
AdversaryCell = Tuple[int, int, int, int]


@dataclass(frozen=True)
class AdversaryConfig:
    seed: int = 0
    evaluation_budget: int = 200
    initial_population: int = 20
    length: int = 120
    capacity: int = 150
    minimum_item: int = 20
    maximum_item: int = 100
    mean_tolerance_fraction: float = 0.12

    def __post_init__(self) -> None:
        if self.evaluation_budget <= 0:
            raise ValueError("evaluation_budget must be positive")
        if self.initial_population <= 0:
            raise ValueError("initial_population must be positive")
        if self.initial_population > self.evaluation_budget:
            raise ValueError("initial_population cannot exceed evaluation_budget")
        if self.length <= 1 or self.capacity <= 0:
            raise ValueError("length must exceed one and capacity must be positive")
        if not 0 < self.minimum_item <= self.maximum_item <= self.capacity:
            raise ValueError("invalid item bounds")
        if not 0.0 <= self.mean_tolerance_fraction <= 0.5:
            raise ValueError("invalid mean tolerance")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "seed": self.seed,
            "evaluation_budget": self.evaluation_budget,
            "initial_population": self.initial_population,
            "length": self.length,
            "capacity": self.capacity,
            "minimum_item": self.minimum_item,
            "maximum_item": self.maximum_item,
            "mean_tolerance_fraction": self.mean_tolerance_fraction,
        }


@dataclass(frozen=True)
class AdversarialSequenceRecord:
    instance: BinPackingInstance
    parent_ids: Tuple[str, ...]
    operator: str
    evaluation_index: int
    target_bin_count: int
    comparator_bin_count: int
    volume_lower_bound: int
    target_gap: int
    target_excess: int
    distribution_penalty: float
    fitness: float
    archive_cell: AdversaryCell
    artifact_digest: Optional[str] = None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "instance": self.instance.as_dict(),
            "parent_ids": list(self.parent_ids),
            "operator": self.operator,
            "evaluation_index": self.evaluation_index,
            "target_bin_count": self.target_bin_count,
            "comparator_bin_count": self.comparator_bin_count,
            "volume_lower_bound": self.volume_lower_bound,
            "target_gap": self.target_gap,
            "target_excess": self.target_excess,
            "distribution_penalty": self.distribution_penalty,
            "fitness": self.fitness,
            "archive_cell": list(self.archive_cell),
            "artifact_digest": self.artifact_digest,
        }


@dataclass(frozen=True)
class AdversaryOutcome:
    config: AdversaryConfig
    target_name: str
    comparator_name: str
    evaluated: Tuple[AdversarialSequenceRecord, ...]
    archive: Tuple[AdversarialSequenceRecord, ...]
    duplicate_attempts: int

    @property
    def best(self) -> AdversarialSequenceRecord:
        return max(self.evaluated, key=_record_sort_key)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "adversary_version": ADVERSARY_VERSION,
            "config": self.config.as_dict(),
            "target_name": self.target_name,
            "comparator_name": self.comparator_name,
            "evaluated_count": len(self.evaluated),
            "archive_size": len(self.archive),
            "duplicate_attempts": self.duplicate_attempts,
            "best_instance_id": self.best.instance.instance_id,
            "best_target_gap": self.best.target_gap,
            "evaluated": [record.as_dict() for record in self.evaluated],
            "archive": [record.as_dict() for record in self.archive],
        }


def _record_sort_key(
    record: AdversarialSequenceRecord,
) -> Tuple[float, int, int, str]:
    return (
        record.fitness,
        record.target_gap,
        record.target_excess,
        record.instance.instance_id,
    )


def _instance(
    items: Sequence[int],
    config: AdversaryConfig,
    evaluation_index: int,
) -> BinPackingInstance:
    item_tuple = tuple(int(item) for item in items)
    return BinPackingInstance(
        instance_id=content_digest(
            {
                "adversary_version": ADVERSARY_VERSION,
                "capacity": config.capacity,
                "items": list(item_tuple),
            }
        )[:20],
        family="adversarial_or_uniform",
        seed=evaluation_index,
        capacity=config.capacity,
        items=item_tuple,
    )


def _distribution_penalty(
    items: Sequence[int],
    config: AdversaryConfig,
) -> float:
    midpoint = (config.minimum_item + config.maximum_item) / 2.0
    span = float(config.maximum_item - config.minimum_item)
    if span <= 0:
        return 0.0
    return abs(mean(items) - midpoint) / span


def _within_distribution(
    items: Sequence[int],
    config: AdversaryConfig,
) -> bool:
    if len(items) != config.length:
        return False
    if any(
        item < config.minimum_item or item > config.maximum_item
        for item in items
    ):
        return False
    midpoint = (config.minimum_item + config.maximum_item) / 2.0
    tolerance = (
        (config.maximum_item - config.minimum_item)
        * config.mean_tolerance_fraction
    )
    return abs(mean(items) - midpoint) <= tolerance


def _cell(
    instance: BinPackingInstance,
    target_gap: int,
    config: AdversaryConfig,
) -> AdversaryCell:
    items = instance.items
    span = max(1.0, config.maximum_item - config.minimum_item)
    normalized_mean = (
        mean(items) - config.minimum_item
    ) / span
    large_fraction = sum(
        item > config.capacity / 2.0 for item in items
    ) / float(len(items))
    tight_adjacent_fraction = sum(
        abs(config.capacity - left - right) <= 3
        for left, right in zip(items, items[1:])
    ) / float(max(1, len(items) - 1))
    return (
        min(4, max(0, int(normalized_mean * 5))),
        min(4, max(0, int(large_fraction * 5))),
        min(4, max(0, int(tight_adjacent_fraction * 10))),
        0 if target_gap < 0 else 1 if target_gap == 0 else min(4, target_gap + 1),
    )


def _mutate(
    source: Sequence[int],
    rng: random.Random,
    config: AdversaryConfig,
) -> Tuple[Tuple[int, ...], str]:
    items = list(source)
    operator = rng.choice(
        ("point_replace", "swap", "reverse", "block_move", "window_shuffle")
    )
    if operator == "point_replace":
        index = rng.randrange(len(items))
        items[index] = rng.randint(config.minimum_item, config.maximum_item)
    elif operator == "swap":
        first, second = rng.sample(range(len(items)), 2)
        items[first], items[second] = items[second], items[first]
    elif operator == "reverse":
        first, second = sorted(rng.sample(range(len(items) + 1), 2))
        if second - first < 2:
            second = min(len(items), first + 2)
            first = max(0, second - 2)
        items[first:second] = reversed(items[first:second])
    elif operator == "block_move":
        start = rng.randrange(len(items) - 1)
        width = rng.randint(1, min(8, len(items) - start))
        block = items[start : start + width]
        remainder = items[:start] + items[start + width :]
        destination = rng.randrange(len(remainder) + 1)
        items = (
            remainder[:destination]
            + block
            + remainder[destination:]
        )
    else:
        start = rng.randrange(len(items) - 1)
        width = rng.randint(2, min(12, len(items) - start))
        window = items[start : start + width]
        rng.shuffle(window)
        items[start : start + width] = window
    return tuple(items), operator


def evolve_adversarial_sequences(
    config: AdversaryConfig,
    target: OnlineHeuristic,
    comparator: OnlineHeuristic,
    artifact_store: Optional[ArtifactStore] = None,
) -> AdversaryOutcome:
    """Evolve in-distribution sequences that expose a target/comparator gap."""

    rng = random.Random(config.seed)
    evaluated: List[AdversarialSequenceRecord] = []
    archive: Dict[AdversaryCell, AdversarialSequenceRecord] = {}
    seen = set()
    duplicate_attempts = 0

    def evaluate(
        instance: BinPackingInstance,
        parent_ids: Tuple[str, ...],
        operator: str,
    ) -> bool:
        if instance.instance_id in seen:
            return False
        seen.add(instance.instance_id)
        target_bins = pack(instance, target).bin_count
        comparator_bins = pack(instance, comparator).bin_count
        lower_bound = int(
            math.ceil(sum(instance.items) / float(instance.capacity))
        )
        gap = target_bins - comparator_bins
        excess = target_bins - lower_bound
        penalty = _distribution_penalty(instance.items, config)
        fitness = 100.0 * gap + excess - penalty
        cell = _cell(instance, gap, config)
        artifact_digest = None
        record_value = {
            "instance": instance.as_dict(),
            "parent_ids": list(parent_ids),
            "operator": operator,
            "evaluation_index": len(evaluated),
            "target_bin_count": target_bins,
            "comparator_bin_count": comparator_bins,
            "volume_lower_bound": lower_bound,
            "target_gap": gap,
            "target_excess": excess,
            "distribution_penalty": penalty,
            "fitness": fitness,
            "archive_cell": list(cell),
        }
        if artifact_store is not None:
            artifact_digest = artifact_store.put(
                "adversarial_sequence_evaluation",
                record_value,
            )
        record = AdversarialSequenceRecord(
            instance=instance,
            parent_ids=parent_ids,
            operator=operator,
            evaluation_index=len(evaluated),
            target_bin_count=target_bins,
            comparator_bin_count=comparator_bins,
            volume_lower_bound=lower_bound,
            target_gap=gap,
            target_excess=excess,
            distribution_penalty=penalty,
            fitness=fitness,
            archive_cell=cell,
            artifact_digest=artifact_digest,
        )
        evaluated.append(record)
        incumbent = archive.get(cell)
        if incumbent is None or _record_sort_key(record) > _record_sort_key(incumbent):
            archive[cell] = record
        return True

    seed_base = config.seed * 1_000_003 + 17
    seed_offset = 0
    while len(evaluated) < config.initial_population:
        generated = generate_instance(
            "or_uniform",
            seed_base + seed_offset,
            config.length,
            config.capacity,
        )
        seed_offset += 1
        if not _within_distribution(generated.items, config):
            if seed_offset > config.initial_population * 1_000:
                raise RuntimeError(
                    "could not sample enough in-contract adversary seeds"
                )
            continue
        evaluate(
            _instance(generated.items, config, len(evaluated)),
            (),
            "random_seed",
        )

    attempts = 0
    maximum_attempts = config.evaluation_budget * 200
    while len(evaluated) < config.evaluation_budget and attempts < maximum_attempts:
        attempts += 1
        parent_pool = tuple(archive.values())
        first = rng.choice(parent_pool)
        candidate_items, operator = _mutate(first.instance.items, rng, config)
        if not _within_distribution(candidate_items, config):
            continue
        candidate = _instance(candidate_items, config, len(evaluated))
        if not evaluate(
            candidate,
            (first.instance.instance_id,),
            operator,
        ):
            duplicate_attempts += 1

    if len(evaluated) != config.evaluation_budget:
        raise RuntimeError(
            "adversary exhausted unique sequences at %d/%d evaluations"
            % (len(evaluated), config.evaluation_budget)
        )
    return AdversaryOutcome(
        config=config,
        target_name=target.name,
        comparator_name=comparator.name,
        evaluated=tuple(evaluated),
        archive=tuple(
            archive[cell] for cell in sorted(archive)
        ),
        duplicate_attempts=duplicate_attempts,
    )


def select_diverse_adversaries(
    outcome: AdversaryOutcome,
    count: int,
    minimum_target_gap: Optional[int] = None,
) -> Tuple[AdversarialSequenceRecord, ...]:
    if count <= 0:
        return ()
    selected: List[AdversarialSequenceRecord] = []
    seen = set()
    for record in sorted(outcome.archive, key=_record_sort_key, reverse=True):
        if (
            minimum_target_gap is not None
            and record.target_gap < minimum_target_gap
        ):
            continue
        selected.append(record)
        seen.add(record.instance.instance_id)
        if len(selected) == count:
            return tuple(selected)
    for record in sorted(outcome.evaluated, key=_record_sort_key, reverse=True):
        if record.instance.instance_id in seen:
            continue
        if (
            minimum_target_gap is not None
            and record.target_gap < minimum_target_gap
        ):
            continue
        selected.append(record)
        seen.add(record.instance.instance_id)
        if len(selected) == count:
            return tuple(selected)
    raise ValueError(
        "not enough adversarial sequences satisfy the selection contract"
    )
