from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import (
    FunSearchORReference,
    funsearch_or_score,
    pack,
)
from scientist.domains.binpacking.orlib import (
    ORLibraryRecord,
    load_orlib_corpus,
    load_source_manifest,
    verify_orlib_files,
)


BENCHMARK_CONFORMANCE_VERSION = "funsearch-notebook-conformance-v1"
OFFICIAL_FUNSEARCH_REPOSITORY = (
    "https://github.com/google-deepmind/funsearch"
)
OFFICIAL_FUNSEARCH_NOTEBOOK_COMMIT = (
    "2a2c8641f8590ae17ad98e82435cb1781a917957"
)
OFFICIAL_FUNSEARCH_NOTEBOOK = (
    OFFICIAL_FUNSEARCH_REPOSITORY
    + "/blob/"
    + OFFICIAL_FUNSEARCH_NOTEBOOK_COMMIT
    + "/bin_packing/bin_packing.ipynb"
)
OFFICIAL_OR3_SOURCE_FILE = "binpack3.txt"
OFFICIAL_OR3_IDENTIFIERS = tuple(
    "u500_%02d" % index for index in range(20)
)
OFFICIAL_OR3_BEST_FIT_MEAN = 212.0
OFFICIAL_OR3_FUNSEARCH_MEAN = 207.45
OFFICIAL_OR3_L1_LOWER_BOUND_MEAN = 201.2
OFFICIAL_OR3_FUNSEARCH_COUNTS = (
    204,
    208,
    206,
    212,
    213,
    213,
    217,
    212,
    202,
    207,
    204,
    207,
    205,
    201,
    210,
    208,
    207,
    203,
    208,
    202,
)

# First 64 actions of the notebook's OR3 u500_00 evaluator. These values were
# frozen from the independently transcribed all-empty-bin/first-argmax
# semantics, not from the production packer.
OFFICIAL_U500_00_PREFIX_ITEMS = (
    42, 69, 67, 57, 93, 90, 38, 36, 45, 42, 33, 79, 27, 57, 44, 84,
    86, 92, 46, 38, 85, 33, 82, 73, 49, 70, 59, 23, 57, 72, 74, 69,
    33, 42, 28, 46, 30, 64, 29, 74, 41, 49, 55, 98, 80, 32, 25, 38,
    82, 30, 35, 39, 57, 84, 62, 50, 55, 27, 30, 36, 20, 78, 47, 26,
)
OFFICIAL_U500_00_PREFIX_ACTIONS = (
    0, 0, 1, 1, 2, 3, 0, 3, 4, 4, 2, 5, 4, 6, 5, 7,
    6, 8, 9, 7, 10, 4, 9, 11, 11, 12, 10, 2, 8, 13, 13, 14,
    12, 12, 7, 14, 14, 15, 15, 16, 16, 17, 15, 17, 18, 16, 1, 18,
    19, 18, 19, 20, 20, 21, 21, 20, 22, 5, 19, 22, 9, 23, 23, 11,
)


class BenchmarkConformanceError(RuntimeError):
    """Raised before discovery when the official evaluator is not reproduced."""


def _official_funsearch_priority(item: int, residual: int) -> float:
    remaining_after = residual - item
    if remaining_after <= 2:
        return 4.0
    if remaining_after <= 3:
        return 3.0
    if remaining_after <= 5:
        return 2.0
    if remaining_after <= 7:
        return 1.0
    if remaining_after <= 9:
        return 0.9
    if remaining_after <= 12:
        return 0.95
    if remaining_after <= 15:
        return 0.97
    if remaining_after <= 18:
        return 0.98
    if remaining_after <= 20:
        return 0.98
    if remaining_after <= 21:
        return 0.98
    return 0.99


def _official_best_fit_priority(item: int, residual: int) -> float:
    return float(-(residual - item))


def _official_notebook_trace(
    items: Sequence[int],
    capacity: int,
    *,
    priority: str,
) -> Tuple[Tuple[int, ...], int]:
    """Execute the official all-empty-bin and first-numpy-argmax semantics."""

    residuals = [capacity for _ in items]
    actions = []
    scorer = (
        _official_funsearch_priority
        if priority == "funsearch"
        else _official_best_fit_priority
        if priority == "best_fit"
        else None
    )
    if scorer is None:
        raise ValueError("unknown official notebook priority: %s" % priority)
    for item in items:
        valid = tuple(
            index
            for index, residual in enumerate(residuals)
            if residual - item >= 0
        )
        scores = tuple(scorer(item, residuals[index]) for index in valid)
        best_offset = max(
            range(len(scores)),
            key=lambda index: (scores[index], -index),
        )
        best_index = valid[best_offset]
        residuals[best_index] -= item
        actions.append(best_index)
    return tuple(actions), sum(residual != capacity for residual in residuals)


def _or3_records(records: Iterable[ORLibraryRecord]) -> Tuple[ORLibraryRecord, ...]:
    selected = tuple(
        record
        for record in records
        if record.source_file == OFFICIAL_OR3_SOURCE_FILE
    )
    return tuple(
        sorted(
            selected,
            key=lambda record: OFFICIAL_OR3_IDENTIFIERS.index(
                record.source_identifier
            ),
        )
    )


@dataclass(frozen=True)
class FunSearchBenchmarkConformanceReport:
    conformance_version: str
    source_repository: str
    notebook_commit: str
    notebook_locator: str
    or3_source_sha256: str
    checks: Dict[str, bool]
    official_best_fit_counts: Tuple[int, ...]
    official_funsearch_counts: Tuple[int, ...]
    production_funsearch_counts: Tuple[int, ...]
    golden_action_trace: Tuple[int, ...]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def report_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "conformance_version": self.conformance_version,
            "source_repository": self.source_repository,
            "notebook_commit": self.notebook_commit,
            "notebook_locator": self.notebook_locator,
            "or3_source_file": OFFICIAL_OR3_SOURCE_FILE,
            "or3_source_sha256": self.or3_source_sha256,
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
            "official_outputs": {
                "best_fit_mean_bins": mean(self.official_best_fit_counts),
                "funsearch_mean_bins": mean(self.official_funsearch_counts),
                "l1_lower_bound_mean_bins": (
                    OFFICIAL_OR3_L1_LOWER_BOUND_MEAN
                ),
            },
            "official_best_fit_counts": list(self.official_best_fit_counts),
            "official_funsearch_counts": list(self.official_funsearch_counts),
            "production_funsearch_counts": list(
                self.production_funsearch_counts
            ),
            "golden_trace": {
                "instance": "u500_00",
                "prefix_items": list(OFFICIAL_U500_00_PREFIX_ITEMS),
                "actions": list(self.golden_action_trace),
            },
        }
        if include_id:
            value["report_id"] = self.report_id
        return value

    def require_passed(self) -> None:
        if not self.passed:
            failed = tuple(
                name for name, passed in self.checks.items() if not passed
            )
            raise BenchmarkConformanceError(
                "official FunSearch benchmark conformance failed: %s"
                % ", ".join(failed)
            )


def verify_funsearch_benchmark_conformance(
    orlib_root: Path,
) -> FunSearchBenchmarkConformanceReport:
    root = Path(orlib_root)
    source_manifest = load_source_manifest(root / "SOURCES.json")
    observed = verify_orlib_files(root, source_manifest)
    records = _or3_records(load_orlib_corpus(root))
    identifiers = tuple(record.source_identifier for record in records)

    official_best_fit = tuple(
        _official_notebook_trace(
            record.instance.items,
            record.instance.capacity,
            priority="best_fit",
        )[1]
        for record in records
    )
    official_funsearch_results = tuple(
        _official_notebook_trace(
            record.instance.items,
            record.instance.capacity,
            priority="funsearch",
        )
        for record in records
    )
    official_funsearch = tuple(
        result[1] for result in official_funsearch_results
    )
    production_results = tuple(
        pack(record.instance, FunSearchORReference())
        for record in records
    )
    production_funsearch = tuple(
        result.bin_count for result in production_results
    )
    reference_prefix_trace, _ = _official_notebook_trace(
        OFFICIAL_U500_00_PREFIX_ITEMS,
        150,
        priority="funsearch",
    )
    production_prefix_trace = tuple(
        placement.bin_index
        for placement in production_results[0].placements[
            : len(OFFICIAL_U500_00_PREFIX_ACTIONS)
        ]
    ) if production_results else ()
    l1_bounds = tuple(
        math.ceil(sum(record.instance.items) / record.instance.capacity)
        for record in records
    )
    score_table_matches = all(
        funsearch_or_score(remaining_after)
        == _official_funsearch_priority(0, remaining_after)
        for remaining_after in range(151)
    )
    checks = {
        "official_or3_file_checksum_verified": (
            OFFICIAL_OR3_SOURCE_FILE in observed
        ),
        "official_or3_identifiers_exact": (
            identifiers == OFFICIAL_OR3_IDENTIFIERS
        ),
        "official_notebook_priority_table_exact": score_table_matches,
        "official_best_fit_result_exact": (
            mean(official_best_fit) == OFFICIAL_OR3_BEST_FIT_MEAN
        ),
        "official_funsearch_result_exact": (
            mean(official_funsearch) == OFFICIAL_OR3_FUNSEARCH_MEAN
            and official_funsearch == OFFICIAL_OR3_FUNSEARCH_COUNTS
        ),
        "official_l1_lower_bound_exact": (
            mean(l1_bounds) == OFFICIAL_OR3_L1_LOWER_BOUND_MEAN
        ),
        "golden_reference_action_trace_exact": (
            reference_prefix_trace == OFFICIAL_U500_00_PREFIX_ACTIONS
        ),
        "production_action_trace_matches_golden": (
            production_prefix_trace == OFFICIAL_U500_00_PREFIX_ACTIONS
        ),
        "production_episode_counts_match_official": (
            production_funsearch == official_funsearch
        ),
    }
    report = FunSearchBenchmarkConformanceReport(
        conformance_version=BENCHMARK_CONFORMANCE_VERSION,
        source_repository=OFFICIAL_FUNSEARCH_REPOSITORY,
        notebook_commit=OFFICIAL_FUNSEARCH_NOTEBOOK_COMMIT,
        notebook_locator=OFFICIAL_FUNSEARCH_NOTEBOOK,
        or3_source_sha256=observed.get(OFFICIAL_OR3_SOURCE_FILE, ""),
        checks=checks,
        official_best_fit_counts=official_best_fit,
        official_funsearch_counts=official_funsearch,
        production_funsearch_counts=production_funsearch,
        golden_action_trace=reference_prefix_trace,
    )
    report.require_passed()
    return report
