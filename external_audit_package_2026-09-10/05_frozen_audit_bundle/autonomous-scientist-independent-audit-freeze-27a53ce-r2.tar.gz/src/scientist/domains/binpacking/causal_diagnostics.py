from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.program.executable_hypothesis import InformationRegime


DECISION_TRACE_VERSION = "binpacking-decision-counterfactual-v1"


class CounterfactualStatus(str, Enum):
    SUPPORTED = "supported"
    NO_IMPROVING_ONE_STEP_DEVIATION = "no_improving_one_step_deviation"


@dataclass(frozen=True)
class DecisionCounterfactualTrace:
    target_node_id: str
    instance: BinPackingInstance
    decision_index: int
    item: int
    loads_before: Tuple[int, ...]
    chosen_action: int
    alternative_action: int
    baseline_bin_count: int
    counterfactual_bin_count: int
    outcome_delta: int
    chosen_remaining_after: int
    alternative_remaining_after: int
    future_chosen_complements: int
    future_alternative_complements: int
    recent_chosen_proxy: float
    recent_alternative_proxy: float
    proxy_reliability: float
    information_regime: InformationRegime
    mediator: str
    causal_signature: Tuple[str, ...]
    status: CounterfactualStatus
    tracer_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_node_id,
                self.instance,
                self.causal_signature,
                self.mediator,
                self.tracer_ref,
            )
        ):
            raise ValueError("decision counterfactual trace is incomplete")
        if not 0 <= self.decision_index < len(self.instance.items):
            raise ValueError("counterfactual decision index is invalid")
        if self.item != self.instance.items[self.decision_index]:
            raise ValueError("counterfactual item does not match the instance")
        if self.chosen_action == self.alternative_action:
            raise ValueError("counterfactual action must change the decision")
        if not 0 <= self.proxy_reliability <= 1:
            raise ValueError("counterfactual proxy reliability is invalid")
        if self.status == CounterfactualStatus.SUPPORTED:
            if self.outcome_delta <= 0:
                raise ValueError(
                    "supported counterfactual must improve suffix outcome"
                )
        elif self.outcome_delta > 0:
            raise ValueError(
                "unsupported counterfactual cannot improve suffix outcome"
            )

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": DECISION_TRACE_VERSION,
            "target_node_id": self.target_node_id,
            "instance": self.instance.as_dict(),
            "decision_index": self.decision_index,
            "item": self.item,
            "loads_before": list(self.loads_before),
            # -1 is the explicit "open a new bin" action.
            "chosen_action": self.chosen_action,
            "alternative_action": self.alternative_action,
            "baseline_bin_count": self.baseline_bin_count,
            "counterfactual_bin_count": self.counterfactual_bin_count,
            "outcome_delta": self.outcome_delta,
            "chosen_remaining_after": self.chosen_remaining_after,
            "alternative_remaining_after": self.alternative_remaining_after,
            "future_chosen_complements": self.future_chosen_complements,
            "future_alternative_complements": (
                self.future_alternative_complements
            ),
            "recent_chosen_proxy": self.recent_chosen_proxy,
            "recent_alternative_proxy": self.recent_alternative_proxy,
            "proxy_reliability": self.proxy_reliability,
            "information_regime": self.information_regime.value,
            "mediator": self.mediator,
            "causal_signature": list(self.causal_signature),
            "status": self.status.value,
            "tracer_ref": self.tracer_ref,
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


def _loads_before(
    placements: Sequence[Any],
    decision_index: int,
) -> Tuple[int, ...]:
    if decision_index == 0:
        return ()
    return tuple(placements[decision_index - 1].loads_after)


def _action_remaining(
    action: int,
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> int:
    load = 0 if action == -1 else loads[action]
    return capacity - load - item


def _replay_suffix(
    instance: BinPackingInstance,
    heuristic: OnlineHeuristic,
    decision_index: int,
    loads_before: Sequence[int],
    alternative_action: int,
) -> int:
    loads = list(loads_before)
    item = instance.items[decision_index]
    if alternative_action == -1:
        loads.append(item)
    else:
        if (
            alternative_action < 0
            or alternative_action >= len(loads)
            or loads[alternative_action] + item > instance.capacity
        ):
            raise ValueError("forced counterfactual action is infeasible")
        loads[alternative_action] += item
    history = list(instance.items[: decision_index + 1])
    for suffix_index in range(decision_index + 1, len(instance.items)):
        suffix_item = instance.items[suffix_index]
        action = heuristic.choose_bin(
            suffix_item,
            tuple(loads),
            instance.capacity,
            suffix_index,
            tuple(history),
        )
        if action is None:
            loads.append(suffix_item)
        else:
            if (
                action < 0
                or action >= len(loads)
                or loads[action] + suffix_item > instance.capacity
            ):
                raise ValueError(
                    "heuristic selected an invalid action during replay"
                )
            loads[action] += suffix_item
        history.append(suffix_item)
    return len(loads)


def _density(values: Sequence[int], target: int, tolerance: int = 2) -> float:
    if not values:
        return 0.0
    return sum(abs(value - target) <= tolerance for value in values) / float(
        len(values)
    )


def _shortlist_actions(
    feasible: Sequence[int],
    loads: Sequence[int],
    item: int,
    capacity: int,
) -> Tuple[int, ...]:
    actions = tuple(feasible) + (-1,)
    if len(actions) <= 9:
        return actions
    ranked = sorted(
        actions,
        key=lambda action: (
            _action_remaining(action, item, loads, capacity),
            action,
        ),
    )
    positions = (0, 1, len(ranked) // 4, len(ranked) // 2, 3 * len(ranked) // 4, -2, -1)
    return tuple(dict.fromkeys(ranked[position] for position in positions))


def trace_first_effective_decision(
    target_node_id: str,
    instance: BinPackingInstance,
    heuristic: OnlineHeuristic,
) -> DecisionCounterfactualTrace:
    """Find the first one-step action change that improves the replayed suffix."""

    baseline = pack(instance, heuristic)
    best_unsupported: Optional[Tuple[Any, ...]] = None
    for decision_index, placement in enumerate(baseline.placements):
        loads_before = _loads_before(baseline.placements, decision_index)
        item = placement.item
        chosen_action = (
            placement.bin_index
            if placement.bin_index < len(loads_before)
            else -1
        )
        feasible = tuple(
            index
            for index, load in enumerate(loads_before)
            if load + item <= instance.capacity
        )
        actions = tuple(
            action
            for action in _shortlist_actions(
                feasible,
                loads_before,
                item,
                instance.capacity,
            )
            if action != chosen_action
        )
        if not actions:
            continue
        replayed = tuple(
            (
                baseline.bin_count
                - _replay_suffix(
                    instance,
                    heuristic,
                    decision_index,
                    loads_before,
                    action,
                ),
                action,
            )
            for action in actions
        )
        outcome_delta, alternative_action = max(
            replayed,
            key=lambda value: (value[0], -value[1]),
        )
        candidate = (
            decision_index,
            item,
            loads_before,
            chosen_action,
            alternative_action,
            outcome_delta,
        )
        if best_unsupported is None or outcome_delta > best_unsupported[-1]:
            best_unsupported = candidate
        if outcome_delta > 0:
            return _build_trace(
                target_node_id,
                instance,
                baseline.bin_count,
                *candidate,
                status=CounterfactualStatus.SUPPORTED,
            )
    if best_unsupported is None:
        # The first placement always has a distinct "new bin" encoding but no
        # distinct feasible action. Use the first later decision with a forced
        # new-bin alternative if possible; this remains explicit unsupported
        # evidence and therefore cannot authorize retrieval.
        for decision_index, placement in enumerate(baseline.placements[1:], 1):
            loads_before = _loads_before(baseline.placements, decision_index)
            chosen_action = (
                placement.bin_index
                if placement.bin_index < len(loads_before)
                else -1
            )
            alternative_action = -1 if chosen_action != -1 else 0
            if (
                alternative_action == 0
                and (
                    not loads_before
                    or loads_before[0] + placement.item > instance.capacity
                )
            ):
                continue
            counterfactual_count = _replay_suffix(
                instance,
                heuristic,
                decision_index,
                loads_before,
                alternative_action,
            )
            best_unsupported = (
                decision_index,
                placement.item,
                loads_before,
                chosen_action,
                alternative_action,
                baseline.bin_count - counterfactual_count,
            )
            break
    if best_unsupported is None:
        raise ValueError("instance exposes no distinct feasible intervention")
    return _build_trace(
        target_node_id,
        instance,
        baseline.bin_count,
        *best_unsupported,
        status=CounterfactualStatus.NO_IMPROVING_ONE_STEP_DEVIATION,
    )


def _build_trace(
    target_node_id: str,
    instance: BinPackingInstance,
    baseline_bin_count: int,
    decision_index: int,
    item: int,
    loads_before: Tuple[int, ...],
    chosen_action: int,
    alternative_action: int,
    outcome_delta: int,
    *,
    status: CounterfactualStatus,
) -> DecisionCounterfactualTrace:
    capacity = instance.capacity
    chosen_remaining = _action_remaining(
        chosen_action,
        item,
        loads_before,
        capacity,
    )
    alternative_remaining = _action_remaining(
        alternative_action,
        item,
        loads_before,
        capacity,
    )
    future = instance.items[decision_index + 1 :]
    recent = instance.items[max(0, decision_index - 32) : decision_index]
    future_chosen = sum(
        abs(value - chosen_remaining) <= 2 for value in future
    )
    future_alternative = sum(
        abs(value - alternative_remaining) <= 2 for value in future
    )
    recent_chosen = _density(recent, chosen_remaining)
    recent_alternative = _density(recent, alternative_remaining)
    proxy_difference = recent_alternative - recent_chosen
    future_difference = future_alternative - future_chosen
    if proxy_difference == 0 or future_difference == 0:
        proxy_reliability = 0.5
    else:
        proxy_reliability = float(
            (proxy_difference > 0) == (future_difference > 0)
        )
    information_regime = (
        InformationRegime.PREDICTIVE_PROXY
        if len(recent) >= 8 and proxy_reliability >= 0.75
        else InformationRegime.ROBUST_OPTIONALITY
    )
    if future_alternative > future_chosen:
        mediator = "preserved_future_complement_residual"
    elif alternative_remaining > chosen_remaining:
        mediator = "preserved_large_item_option"
    else:
        mediator = "reduced_stranded_residual"
    action_contrast = "%s_to_%s" % (
        "new" if chosen_action == -1 else "existing",
        "new" if alternative_action == -1 else "existing",
    )
    causal_signature = (
        information_regime.value,
        mediator,
        action_contrast,
        status.value,
    )
    return DecisionCounterfactualTrace(
        target_node_id=target_node_id,
        instance=instance,
        decision_index=decision_index,
        item=item,
        loads_before=loads_before,
        chosen_action=chosen_action,
        alternative_action=alternative_action,
        baseline_bin_count=baseline_bin_count,
        counterfactual_bin_count=baseline_bin_count - outcome_delta,
        outcome_delta=outcome_delta,
        chosen_remaining_after=chosen_remaining,
        alternative_remaining_after=alternative_remaining,
        future_chosen_complements=future_chosen,
        future_alternative_complements=future_alternative,
        recent_chosen_proxy=recent_chosen,
        recent_alternative_proxy=recent_alternative,
        proxy_reliability=proxy_reliability,
        information_regime=information_regime,
        mediator=mediator,
        causal_signature=causal_signature,
        status=status,
        tracer_ref="binpacking-first-effective-decision-tracer-v1",
    )
