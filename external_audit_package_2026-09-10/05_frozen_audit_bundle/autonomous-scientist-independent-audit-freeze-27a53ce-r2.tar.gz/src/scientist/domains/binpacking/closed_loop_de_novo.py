from __future__ import annotations

import math
import random
from dataclasses import dataclass
from statistics import mean
from typing import Any, Callable, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import FunSearchORReference, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.program.discovery_evidence import paired_episode_evidence


CLOSED_LOOP_DE_NOVO_VERSION = "binpacking-closed-loop-de-novo-v1"
CLOSED_LOOP_MECHANISMS = (
    "scenario_tree_controller",
    "completion_graph_controller",
    "residual_market_controller",
)


def _stable_quantiles(values: Sequence[int], count: int) -> Tuple[int, ...]:
    ordered = tuple(sorted(int(value) for value in values))
    if not ordered:
        raise ValueError("quantiles require at least one observation")
    if count <= 1:
        return (ordered[len(ordered) // 2],)
    return tuple(
        dict.fromkeys(
            ordered[round(index * (len(ordered) - 1) / float(count - 1))]
            for index in range(count)
        )
    )


def _abstract_actions(
    item: int,
    loads: Sequence[int],
    capacity: int,
    *,
    limit: int,
) -> Tuple[Optional[int], ...]:
    """Return one representative per symmetric load, stratified if necessary."""

    by_load: Dict[int, int] = {}
    for index, load in enumerate(loads):
        if load + item <= capacity and load not in by_load:
            by_load[int(load)] = index
    actions = tuple(
        by_load[load]
        for load in sorted(by_load, reverse=True)
    )
    if len(actions) > limit:
        positions = tuple(
            dict.fromkeys(
                round(index * (len(actions) - 1) / float(limit - 1))
                for index in range(limit)
            )
        )
        actions = tuple(actions[position] for position in positions)
    return (*actions, None)


def _post_loads(
    item: int,
    loads: Sequence[int],
    action: Optional[int],
) -> Tuple[int, ...]:
    if action is None:
        return (*loads, item)
    changed = list(loads)
    changed[action] += item
    return tuple(changed)


def _history_sample(
    item: int,
    history: Sequence[int],
    capacity: int,
    window: int,
) -> Tuple[int, ...]:
    observed = tuple(int(value) for value in history[-window:])
    if observed:
        return observed
    # A cold-start prior derived only from the current problem state.  It does
    # not encode the benchmark's item distribution or another policy.
    return tuple(
        dict.fromkeys(
            (
                int(item),
                max(1, capacity // 4),
                max(1, capacity // 2),
                max(1, (3 * capacity) // 4),
            )
        )
    )


@dataclass(frozen=True)
class ClosedLoopPolicy:
    """A complete incumbent-free policy, rather than an action override."""

    mechanism: str
    profile: str
    parameters: Tuple[float, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "parameters",
            tuple(float(value) for value in self.parameters),
        )
        if self.mechanism not in CLOSED_LOOP_MECHANISMS:
            raise ValueError("unsupported closed-loop mechanism")
        if not self.profile:
            raise ValueError("closed-loop profile must not be empty")
        if len(self.parameters) != 6:
            raise ValueError("closed-loop policies require six parameters")
        if not all(math.isfinite(value) for value in self.parameters):
            raise ValueError("closed-loop parameters must be finite")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "version": CLOSED_LOOP_DE_NOVO_VERSION,
                "mechanism": self.mechanism,
                "profile": self.profile,
                "parameters": list(self.parameters),
            }
        )

    @property
    def name(self) -> str:
        return "closed_loop_%s_%s" % (
            self.mechanism,
            self.candidate_id[:12],
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "closed_loop_de_novo_policy",
            "version": CLOSED_LOOP_DE_NOVO_VERSION,
            "candidate_id": self.candidate_id,
            "name": self.name,
            "mechanism": self.mechanism,
            "profile": self.profile,
            "parameters": list(self.parameters),
            "complete_policy": True,
            "incumbent": None,
            "incumbent_blind": True,
            "fallback_policy": None,
            "future_arrivals_available": False,
            "deployment_information": [
                "current item",
                "current open-bin loads",
                "capacity",
                "bounded observed arrival history",
            ],
            "objective": "closed-loop terminal bin count over complete episodes",
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ClosedLoopPolicy":
        if value.get("version") != CLOSED_LOOP_DE_NOVO_VERSION:
            raise ValueError("unsupported closed-loop policy version")
        policy = cls(
            mechanism=str(value["mechanism"]),
            profile=str(value["profile"]),
            parameters=tuple(float(item) for item in value["parameters"]),
        )
        if value.get("candidate_id") != policy.candidate_id:
            raise ValueError("closed-loop policy identity mismatch")
        return policy

    def _scenario_suffixes(
        self,
        item: int,
        history: Sequence[int],
        capacity: int,
        horizon: int,
        scenario_count: int,
        window: int,
    ) -> Tuple[Tuple[int, ...], ...]:
        observed = _history_sample(item, history, capacity, window)
        quantiles = _stable_quantiles(observed, min(7, scenario_count))
        suffixes = []
        starts = _stable_quantiles(tuple(range(len(observed))), scenario_count)
        for start in starts:
            suffixes.append(
                tuple(
                    observed[(start + offset) % len(observed)]
                    for offset in range(horizon)
                )
            )
        for shift in range(len(quantiles)):
            suffixes.append(
                tuple(
                    quantiles[(shift + offset) % len(quantiles)]
                    for offset in range(horizon)
                )
            )
        return tuple(dict.fromkeys(suffixes))[:scenario_count]

    @staticmethod
    def _terminal_state_cost(
        loads: Sequence[int],
        capacity: int,
        observed: Sequence[int],
        dead_weight: float,
        coverage_weight: float,
    ) -> float:
        residuals = tuple(capacity - load for load in loads)
        minimum = min(observed)
        dead_mass = sum(
            residual
            for residual in residuals
            if 0 < residual < minimum
        ) / float(capacity)
        demands = _stable_quantiles(observed, 5)
        uncovered = sum(
            not any(residual >= demand for residual in residuals)
            for demand in demands
        ) / float(len(demands))
        return (
            len(loads)
            + dead_weight * dead_mass
            + coverage_weight * uncovered
        )

    def _beam_terminal_cost(
        self,
        loads: Sequence[int],
        suffix: Sequence[int],
        capacity: int,
        observed: Sequence[int],
        beam_width: int,
        action_limit: int,
        dead_weight: float,
        coverage_weight: float,
    ) -> float:
        frontier = (tuple(sorted(loads)),)
        for future_item in suffix:
            expanded: Dict[Tuple[int, ...], float] = {}
            for state in frontier:
                for action in _abstract_actions(
                    future_item,
                    state,
                    capacity,
                    limit=action_limit,
                ):
                    post = tuple(
                        sorted(_post_loads(future_item, state, action))
                    )
                    expanded[post] = self._terminal_state_cost(
                        post,
                        capacity,
                        observed,
                        dead_weight,
                        coverage_weight,
                    )
            frontier = tuple(
                state
                for state, _ in sorted(
                    expanded.items(),
                    key=lambda pair: (pair[1], pair[0]),
                )[:beam_width]
            )
        return min(
            self._terminal_state_cost(
                state,
                capacity,
                observed,
                dead_weight,
                coverage_weight,
            )
            for state in frontier
        )

    def _scenario_tree_action(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> Optional[int]:
        horizon = max(1, min(4, round(self.parameters[0])))
        scenario_count = max(2, min(8, round(self.parameters[1])))
        beam_width = max(2, min(12, round(self.parameters[2])))
        risk_weight = max(0.0, min(1.0, self.parameters[3]))
        dead_weight = max(0.0, self.parameters[4])
        coverage_weight = max(0.0, self.parameters[5])
        observed = _history_sample(item, history, capacity, 64)
        suffixes = self._scenario_suffixes(
            item,
            history,
            capacity,
            horizon,
            scenario_count,
            64,
        )
        ranked = []
        for action in _abstract_actions(item, loads, capacity, limit=8):
            post = _post_loads(item, loads, action)
            costs = tuple(
                self._beam_terminal_cost(
                    post,
                    suffix,
                    capacity,
                    observed,
                    beam_width,
                    6,
                    dead_weight,
                    coverage_weight,
                )
                for suffix in suffixes
            )
            expected = mean(costs)
            robust = max(costs)
            score = (1.0 - risk_weight) * expected + risk_weight * robust
            numeric = len(loads) if action is None else action
            ranked.append((score, numeric, action))
        return min(ranked, key=lambda row: (row[0], row[1]))[2]

    @staticmethod
    def _completion_probability(
        residual: int,
        observed: Sequence[int],
        tolerance: int,
    ) -> Tuple[float, float]:
        if residual <= 0:
            return (1.0, 0.0)
        single = sum(
            abs(value - residual) <= tolerance for value in observed
        ) / float(len(observed))
        support = _stable_quantiles(observed, min(11, len(observed)))
        pair_hits = sum(
            abs(left + right - residual) <= tolerance
            for left in support
            for right in support
        )
        pair = pair_hits / float(len(support) ** 2)
        return single, pair

    def _completion_graph_action(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> Optional[int]:
        tolerance = max(0, min(8, round(self.parameters[0])))
        window = max(8, min(128, round(self.parameters[1])))
        single_weight = max(0.0, self.parameters[2])
        pair_weight = max(0.0, self.parameters[3])
        dead_weight = max(0.0, self.parameters[4])
        open_cost = max(0.25, self.parameters[5])
        observed = _history_sample(item, history, capacity, window)
        minimum = min(observed)
        ranked = []
        for action in _abstract_actions(item, loads, capacity, limit=16):
            post = _post_loads(item, loads, action)
            score = open_cost * float(action is None)
            for load in post:
                residual = capacity - load
                single, pair = self._completion_probability(
                    residual,
                    observed,
                    tolerance,
                )
                score += (
                    dead_weight
                    * (residual / float(capacity))
                    * float(0 < residual < minimum)
                    - single_weight * single
                    - pair_weight * pair
                )
            numeric = len(loads) if action is None else action
            ranked.append((score, numeric, action))
        return min(ranked, key=lambda row: (row[0], row[1]))[2]

    def _residual_market_action(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> Optional[int]:
        band_count = max(4, min(15, round(self.parameters[0])))
        window = max(8, min(128, round(self.parameters[1])))
        imbalance_weight = max(0.0, self.parameters[2])
        scarcity_weight = max(0.0, self.parameters[3])
        dead_weight = max(0.0, self.parameters[4])
        open_cost = max(0.25, self.parameters[5])
        observed = _history_sample(item, history, capacity, window)
        target = [0.0] * band_count
        for value in observed:
            complement = max(0, capacity - value)
            band = min(
                band_count - 1,
                int(band_count * complement / float(capacity + 1)),
            )
            target[band] += 1.0 / len(observed)
        minimum = min(observed)
        ranked = []
        for action in _abstract_actions(item, loads, capacity, limit=16):
            post = _post_loads(item, loads, action)
            residuals = tuple(capacity - load for load in post)
            supply = [0.0] * band_count
            for residual in residuals:
                band = min(
                    band_count - 1,
                    int(band_count * residual / float(capacity + 1)),
                )
                supply[band] += 1.0 / len(residuals)
            imbalance = sum(
                abs(observed_supply - desired)
                for observed_supply, desired in zip(supply, target)
            )
            demands = _stable_quantiles(observed, 5)
            scarcity = sum(
                1.0 / (1.0 + sum(residual >= demand for residual in residuals))
                for demand in demands
            ) / len(demands)
            dead_mass = sum(
                residual
                for residual in residuals
                if 0 < residual < minimum
            ) / float(capacity)
            score = (
                open_cost * float(action is None)
                + imbalance_weight * imbalance
                + scarcity_weight * scarcity
                + dead_weight * dead_mass
            )
            numeric = len(loads) if action is None else action
            ranked.append((score, numeric, action))
        return min(ranked, key=lambda row: (row[0], row[1]))[2]

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        del item_index
        if self.mechanism == "scenario_tree_controller":
            return self._scenario_tree_action(
                item, loads, capacity, history
            )
        if self.mechanism == "completion_graph_controller":
            return self._completion_graph_action(
                item, loads, capacity, history
            )
        return self._residual_market_action(item, loads, capacity, history)


def preregistered_policy_family() -> Tuple[ClosedLoopPolicy, ...]:
    """A small semantic family frozen before any benchmark episode is opened."""

    specifications = (
        ("scenario_tree_controller", "short_expected", (2, 4, 4, 0.0, 0.35, 0.35)),
        ("scenario_tree_controller", "balanced", (2, 6, 6, 0.20, 0.60, 0.50)),
        ("scenario_tree_controller", "robust", (3, 6, 6, 0.45, 0.80, 0.65)),
        ("completion_graph_controller", "single_forward", (2, 64, 1.40, 0.40, 1.25, 1.00)),
        ("completion_graph_controller", "balanced", (3, 64, 1.00, 0.85, 1.50, 1.05)),
        ("completion_graph_controller", "pair_forward", (3, 96, 0.65, 1.40, 1.25, 1.10)),
        ("residual_market_controller", "coarse", (6, 48, 1.00, 0.50, 1.25, 1.00)),
        ("residual_market_controller", "balanced", (9, 64, 1.30, 0.80, 1.50, 1.05)),
        ("residual_market_controller", "fine", (12, 96, 1.60, 1.00, 1.75, 1.10)),
    )
    return tuple(
        ClosedLoopPolicy(mechanism, profile, parameters)
        for mechanism, profile, parameters in specifications
    )


@dataclass(frozen=True)
class ClosedLoopDeNovoConfig:
    lengths: Tuple[int, ...] = (120, 250, 500)
    stage_one_episodes_per_length: int = 6
    stage_two_episodes_per_length: int = 16
    validation_episodes_per_length: int = 40
    capacity: int = 150
    item_low: int = 20
    item_high: int = 100
    base_seed: int = 83_082_026

    def __post_init__(self) -> None:
        if not self.lengths or min(self.lengths) <= 1:
            raise ValueError("closed-loop episode lengths must exceed one")
        if min(
            self.stage_one_episodes_per_length,
            self.stage_two_episodes_per_length,
            self.validation_episodes_per_length,
        ) < 2:
            raise ValueError("each closed-loop stage needs two episodes per length")
        if self.capacity <= 0 or not 0 < self.item_low <= self.item_high <= self.capacity:
            raise ValueError("invalid closed-loop IID distribution")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": CLOSED_LOOP_DE_NOVO_VERSION,
            "lengths": list(self.lengths),
            "stage_one_episodes_per_length": self.stage_one_episodes_per_length,
            "stage_two_episodes_per_length": self.stage_two_episodes_per_length,
            "validation_episodes_per_length": self.validation_episodes_per_length,
            "capacity": self.capacity,
            "item_low_inclusive": self.item_low,
            "item_high_inclusive": self.item_high,
            "base_seed": self.base_seed,
        }


_PARTITION_OFFSETS = {
    "elimination_stage_one": 100_000_000,
    "elimination_stage_two": 300_000_000,
    "untouched_validation": 700_000_000,
}


def _episode_suite(
    config: ClosedLoopDeNovoConfig,
    partition: str,
    episodes_per_length: int,
) -> Tuple[BinPackingInstance, ...]:
    offset = _PARTITION_OFFSETS[partition]
    instances = []
    for length_index, length in enumerate(config.lengths):
        for episode_index in range(episodes_per_length):
            seed = (
                config.base_seed
                + offset
                + length_index * 10_000_000
                + episode_index
            )
            rng = random.Random(seed)
            instances.append(
                BinPackingInstance(
                    instance_id="%s:length=%d:seed=%d"
                    % (partition, length, seed),
                    family="iid_or_uniform_%d_%d"
                    % (config.item_low, config.item_high),
                    seed=seed,
                    capacity=config.capacity,
                    items=tuple(
                        rng.randint(config.item_low, config.item_high)
                        for _ in range(length)
                    ),
                )
            )
    return tuple(instances)


def closed_loop_commitment(
    config: ClosedLoopDeNovoConfig,
) -> Dict[str, Any]:
    family = preregistered_policy_family()
    partitions = (
        ("elimination_stage_one", config.stage_one_episodes_per_length),
        ("elimination_stage_two", config.stage_two_episodes_per_length),
        ("untouched_validation", config.validation_episodes_per_length),
    )
    seed_commitments = {}
    all_seeds = []
    for partition, count in partitions:
        suite = _episode_suite(config, partition, count)
        seeds = tuple(instance.seed for instance in suite)
        all_seeds.extend(seeds)
        seed_commitments[partition] = {
            "episode_count": len(suite),
            "seed_digest": content_digest(seeds),
            "instance_id_digest": content_digest(
                tuple(instance.instance_id for instance in suite)
            ),
        }
    if len(set(all_seeds)) != len(all_seeds):
        raise AssertionError("closed-loop partitions must have disjoint seeds")
    commitment: Dict[str, Any] = {
        "schema": 1,
        "version": CLOSED_LOOP_DE_NOVO_VERSION,
        "config": config.as_dict(),
        "candidate_family": [candidate.as_dict() for candidate in family],
        "candidate_family_digest": content_digest(
            tuple(candidate.candidate_id for candidate in family)
        ),
        "seed_commitments": seed_commitments,
        "selection_objective": (
            "minimum mean full-episode excess bins per 100 arrivals; "
            "no incumbent-relative signal"
        ),
        "successive_elimination": (
            "stage one keeps the best profile within each semantic mechanism; "
            "fresh stage two selects one finalist"
        ),
        "comparator_policy": "funsearch_or_reference",
        "comparator_access": "only after finalist selection is frozen",
        "candidate_fallback_policy": None,
    }
    commitment["commitment_id"] = content_digest(commitment)
    return commitment


def _length_from_instance(instance: BinPackingInstance) -> int:
    return len(instance.items)


def _evaluate_candidate(
    candidate: ClosedLoopPolicy,
    instances: Sequence[BinPackingInstance],
) -> Dict[str, Any]:
    rows = []
    for instance in instances:
        result = pack(instance, candidate)
        lower_bound = math.ceil(sum(instance.items) / float(instance.capacity))
        excess = result.bin_count - lower_bound
        rows.append(
            {
                "instance_id": instance.instance_id,
                "length": _length_from_instance(instance),
                "bin_count": result.bin_count,
                "volume_lower_bound": lower_bound,
                "excess_bins": excess,
                "excess_bins_per_100_arrivals": (
                    100.0 * excess / len(instance.items)
                ),
            }
        )
    by_length = {}
    for length in sorted({_length_from_instance(item) for item in instances}):
        selected = tuple(row for row in rows if row["length"] == length)
        by_length[str(length)] = {
            "episode_count": len(selected),
            "mean_bin_count": mean(row["bin_count"] for row in selected),
            "mean_excess_bins": mean(row["excess_bins"] for row in selected),
            "mean_excess_bins_per_100_arrivals": mean(
                row["excess_bins_per_100_arrivals"] for row in selected
            ),
        }
    objective = mean(row["excess_bins_per_100_arrivals"] for row in rows)
    return {
        "candidate": candidate.as_dict(),
        "episode_count": len(rows),
        "objective_mean_excess_bins_per_100_arrivals": objective,
        "expected_return": -objective,
        "mean_bin_count": mean(row["bin_count"] for row in rows),
        "mean_excess_bins": mean(row["excess_bins"] for row in rows),
        "by_length": by_length,
        "episodes": rows,
    }


def _rank_key(report: Mapping[str, Any]) -> Tuple[float, float, str]:
    worst_length = max(
        row["mean_excess_bins_per_100_arrivals"]
        for row in report["by_length"].values()
    )
    return (
        float(report["objective_mean_excess_bins_per_100_arrivals"]),
        float(worst_length),
        str(report["candidate"]["candidate_id"]),
    )


def _validation_comparison(
    candidate: ClosedLoopPolicy,
    instances: Sequence[BinPackingInstance],
) -> Dict[str, Any]:
    incumbent = FunSearchORReference()
    rows = []
    candidate_results = []
    incumbent_results = []
    for instance in instances:
        candidate_result = pack(instance, candidate)
        incumbent_result = pack(instance, incumbent)
        improvement = incumbent_result.bin_count - candidate_result.bin_count
        candidate_results.append(candidate_result.bin_count)
        incumbent_results.append(incumbent_result.bin_count)
        rows.append(
            {
                "instance_id": instance.instance_id,
                "length": len(instance.items),
                "candidate_bins": candidate_result.bin_count,
                "funsearch_bins": incumbent_result.bin_count,
                "improvement": improvement,
            }
        )
    evidence = paired_episode_evidence(
        (row["improvement"] for row in rows),
        tuple(row["instance_id"] for row in rows),
    )
    by_length = {}
    for length in sorted({row["length"] for row in rows}):
        selected = tuple(row for row in rows if row["length"] == length)
        length_evidence = paired_episode_evidence(
            (row["improvement"] for row in selected),
            tuple(row["instance_id"] for row in selected),
        )
        by_length[str(length)] = length_evidence.as_dict()
    screen_passed = (
        evidence.mean_ci_lower > 0.0
        and all(
            report["mean_improvement"] >= 0.0
            for report in by_length.values()
        )
    )
    return {
        "candidate_id": candidate.candidate_id,
        "comparator": incumbent.name,
        "episode_count": len(rows),
        "candidate_mean_bins": mean(candidate_results),
        "funsearch_mean_bins": mean(incumbent_results),
        "evidence": evidence.as_dict(),
        "by_length": by_length,
        "screen_passed": screen_passed,
        "episodes": rows,
    }


def run_closed_loop_de_novo(
    config: ClosedLoopDeNovoConfig,
    *,
    commitment: Optional[Mapping[str, Any]] = None,
    progress: Optional[Callable[[str, Mapping[str, Any]], None]] = None,
) -> Dict[str, Any]:
    frozen_commitment = closed_loop_commitment(config)
    if commitment is not None and dict(commitment) != frozen_commitment:
        raise ValueError("closed-loop commitment does not match the run config")
    family = preregistered_policy_family()
    stage_one_instances = _episode_suite(
        config,
        "elimination_stage_one",
        config.stage_one_episodes_per_length,
    )
    stage_one = tuple(
        _evaluate_candidate(candidate, stage_one_instances)
        for candidate in family
    )
    survivors = []
    for mechanism in CLOSED_LOOP_MECHANISMS:
        mechanism_reports = tuple(
            report
            for report in stage_one
            if report["candidate"]["mechanism"] == mechanism
        )
        winner = min(mechanism_reports, key=_rank_key)
        survivors.append(
            next(
                candidate
                for candidate in family
                if candidate.candidate_id == winner["candidate"]["candidate_id"]
            )
        )
    if progress is not None:
        progress(
            "stage_one_complete",
            {
                "candidate_count": len(family),
                "survivor_ids": [item.candidate_id for item in survivors],
            },
        )
    stage_two_instances = _episode_suite(
        config,
        "elimination_stage_two",
        config.stage_two_episodes_per_length,
    )
    stage_two = tuple(
        _evaluate_candidate(candidate, stage_two_instances)
        for candidate in survivors
    )
    winning_report = min(stage_two, key=_rank_key)
    finalist = next(
        candidate
        for candidate in survivors
        if candidate.candidate_id == winning_report["candidate"]["candidate_id"]
    )
    selection: Dict[str, Any] = {
        "status": "frozen_before_comparator_access",
        "candidate_id": finalist.candidate_id,
        "candidate": finalist.as_dict(),
        "selection_stage": "elimination_stage_two",
        "selection_objective": frozen_commitment["selection_objective"],
        "selection_report_digest": content_digest(winning_report),
        "funsearch_evaluated_during_selection": False,
    }
    selection["selection_id"] = content_digest(selection)
    if progress is not None:
        progress(
            "finalist_frozen",
            {
                "candidate_id": finalist.candidate_id,
                "mechanism": finalist.mechanism,
                "profile": finalist.profile,
                "selection_id": selection["selection_id"],
            },
        )
    validation_instances = _episode_suite(
        config,
        "untouched_validation",
        config.validation_episodes_per_length,
    )
    validation = _validation_comparison(finalist, validation_instances)
    if progress is not None:
        progress(
            "validation_complete",
            {
                "screen_passed": validation["screen_passed"],
                "mean_improvement": validation["evidence"]["mean_improvement"],
                "mean_ci_lower": validation["evidence"]["mean_improvement_ci_lower"],
                "mean_ci_upper": validation["evidence"]["mean_improvement_ci_upper"],
            },
        )
    report: Dict[str, Any] = {
        "schema": 1,
        "version": CLOSED_LOOP_DE_NOVO_VERSION,
        "status": "completed",
        "commitment": frozen_commitment,
        "architecture_audit": {
            "candidate_is_complete_policy": True,
            "candidate_fallback_policy": None,
            "incumbent_in_candidate_generation": False,
            "incumbent_in_candidate_trajectory": False,
            "selection_uses_incumbent_relative_signal": False,
            "full_episode_return_used": True,
            "common_episode_seeds_within_stage": True,
            "fresh_seeds_between_stages": True,
            "comparator_opened_only_after_selection": True,
        },
        "stage_one": {
            "partition": "elimination_stage_one",
            "candidate_count": len(stage_one),
            "reports": list(stage_one),
            "survivor_ids": [candidate.candidate_id for candidate in survivors],
        },
        "stage_two": {
            "partition": "elimination_stage_two",
            "candidate_count": len(stage_two),
            "reports": list(stage_two),
        },
        "selection": selection,
        "validation": validation,
        "confirmation_executed": False,
    }
    report["report_id"] = content_digest(report)
    return report
