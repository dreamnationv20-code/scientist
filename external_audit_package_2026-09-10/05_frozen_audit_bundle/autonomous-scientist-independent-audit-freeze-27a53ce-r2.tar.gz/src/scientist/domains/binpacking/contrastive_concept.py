from __future__ import annotations

import math
from statistics import mean, stdev
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import (
    _apply_action,
    _parse_action,
    _percentile,
)
from scientist.domains.binpacking.generated_concepts.admissible_residual_mass import (
    concept_value,
)
from scientist.domains.binpacking.representation_capacity import (
    AdvantageTrainingExample,
    LinearAdvantageModel,
    fit_linear_advantage_model,
)


CONTRASTIVE_CONCEPT_VERSION = "contrast-driven-latent-concept-v1"


def _spread(values: Sequence[float]) -> float:
    if not values:
        return 0.0
    center = mean(values)
    return math.sqrt(mean((float(value) - center) ** 2 for value in values))


def _action_values(
    probe: Mapping[str, Any], action_ref: str
) -> Mapping[str, float]:
    action = _parse_action(action_ref)
    item = int(probe["item"])
    capacity = 150
    loads = tuple(int(value) for value in probe["loads"])
    history = tuple(int(value) for value in probe["history"])
    successor = _apply_action(action, item, loads, capacity)
    residuals = tuple(capacity - load for load in successor)
    normalized = tuple(residual / float(capacity) for residual in residuals)
    post_residual = (
        capacity - item if action is None else capacity - loads[action] - item
    )
    recent = history[-64:]
    complement_density = sum(
        abs(value - post_residual) <= 5 for value in recent
    ) / float(max(1, len(recent)))
    return {
        "action_is_new": float(action is None),
        "post_residual_ratio": post_residual / float(capacity),
        "post_residual_dead": float(post_residual < 20),
        "exact_fill": float(post_residual == 0),
        "successor_mean_residual": mean(normalized) if normalized else 1.0,
        "successor_residual_spread": _spread(normalized),
        "local_complement_density": complement_density,
    }


def old_intervention_features(
    probe: Mapping[str, Any], action_ref: str
) -> Mapping[str, float]:
    """The frozen generic scalar-greedy language for an A-to-B intervention."""

    item = int(probe["item"])
    loads = tuple(int(value) for value in probe["loads"])
    history = tuple(int(value) for value in probe["history"])
    baseline = _action_values(probe, str(probe["baseline_action_ref"]))
    candidate = _action_values(probe, action_ref)
    feasible_count = sum(load + item <= 150 for load in loads)
    recent = history[-64:]
    result: Dict[str, float] = {
        "state_item_ratio": item / 150.0,
        "state_log_item_index": math.log1p(int(probe["item_index"])),
        "state_bins_per_item": len(loads)
        / float(max(1, int(probe["item_index"]))),
        "state_feasible_count_log": math.log1p(feasible_count),
        "state_history_mean_ratio": mean(recent) / 150.0 if recent else 0.0,
        "state_history_spread_ratio": _spread(recent) / 150.0,
    }
    for name in sorted(candidate):
        result["intervention_delta_%s" % name] = (
            candidate[name] - baseline[name]
        )
    return result


def _paired_interval(values: Sequence[float]) -> Tuple[float, float, float]:
    if len(values) < 2:
        raise ValueError("contrast reliability needs paired rollout samples")
    center = mean(values)
    standard_error = stdev(values) / math.sqrt(len(values))
    radius = 2.040 * standard_error
    return center, center - radius, center + radius


def reliable_interventions(atlas: Mapping[str, Any]) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for probe in atlas["probes"]:
        baseline = next(
            action
            for action in probe["actions"]
            if action["action_ref"] == probe["baseline_action_ref"]
        )
        baseline_samples = tuple(
            int(value) for value in baseline["rollout_bin_counts"]
        )
        for action in probe["actions"]:
            if action["action_ref"] == probe["baseline_action_ref"]:
                continue
            action_samples = tuple(
                int(value) for value in action["rollout_bin_counts"]
            )
            paired = tuple(
                baseline_value - action_value
                for baseline_value, action_value in zip(
                    baseline_samples, action_samples
                )
            )
            effect, lower, upper = _paired_interval(paired)
            if lower > 0.0:
                sign = "positive"
            elif upper < 0.0:
                sign = "negative"
            else:
                continue
            action_ref = str(action["action_ref"])
            action_index: Optional[int] = _parse_action(action_ref)
            baseline_index: Optional[int] = _parse_action(
                str(probe["baseline_action_ref"])
            )
            loads = tuple(int(value) for value in probe["loads"])
            item = int(probe["item"])
            candidate_successor = _apply_action(action_index, item, loads, 150)
            baseline_successor = _apply_action(baseline_index, item, loads, 150)
            body = {
                "probe_id": probe["probe_id"],
                "instance_id": probe["instance_id"],
                "length": probe["length"],
                "item_index": probe["item_index"],
                "item": item,
                "loads": list(loads),
                "history": list(probe["history"]),
                "baseline_action_ref": probe["baseline_action_ref"],
                "action_ref": action_ref,
                "action_is_new": action_ref == "new",
                "baseline_successor_residuals": sorted(
                    (150 - load for load in baseline_successor), reverse=True
                ),
                "candidate_successor_residuals": sorted(
                    (150 - load for load in candidate_successor), reverse=True
                ),
                "paired_rollout_advantages": list(paired),
                "mean_terminal_advantage": effect,
                "advantage_ci_lower": lower,
                "advantage_ci_upper": upper,
                "sign": sign,
                "old_features": dict(old_intervention_features(probe, action_ref)),
            }
            body["intervention_id"] = content_digest(body)
            rows.append(body)
    return tuple(rows)


def _standardization(
    rows: Sequence[Mapping[str, Any]],
) -> Tuple[Tuple[str, ...], Mapping[str, float], Mapping[str, float]]:
    names = tuple(sorted(rows[0]["old_features"]))
    centers = {
        name: mean(float(row["old_features"][name]) for row in rows)
        for name in names
    }
    scales = {
        name: max(
            1e-9,
            _spread(tuple(float(row["old_features"][name]) for row in rows)),
        )
        for name in names
    }
    return names, centers, scales


def _distance(
    left: Mapping[str, Any],
    right: Mapping[str, Any],
    names: Sequence[str],
    scales: Mapping[str, float],
) -> float:
    return math.sqrt(
        mean(
            (
                (float(left["old_features"][name]) - float(right["old_features"][name]))
                / scales[name]
            )
            ** 2
            for name in names
        )
    )


def build_collision_dossier(
    atlas: Mapping[str, Any], *, maximum_pairs: int = 30
) -> Mapping[str, Any]:
    rows = reliable_interventions(atlas)
    if not rows:
        raise ValueError("no reliable interventions exist")
    names, centers, scales = _standardization(rows)
    positives = tuple(row for row in rows if row["sign"] == "positive")
    negatives = tuple(row for row in rows if row["sign"] == "negative")
    candidates = []
    for positive in positives:
        compatible = tuple(
            negative
            for negative in negatives
            if negative["action_is_new"] == positive["action_is_new"]
        )
        if not compatible:
            continue
        negative = min(
            compatible,
            key=lambda row: _distance(positive, row, names, scales),
        )
        candidates.append(
            {
                "existing_representation_distance": _distance(
                    positive, negative, names, scales
                ),
                "positive": positive,
                "negative": negative,
            }
        )
    candidates.sort(
        key=lambda pair: (
            pair["existing_representation_distance"],
            -pair["positive"]["mean_terminal_advantage"],
            pair["negative"]["mean_terminal_advantage"],
        )
    )
    selected = tuple(candidates[:maximum_pairs])
    report: Dict[str, Any] = {
        "schema": 1,
        "version": CONTRASTIVE_CONCEPT_VERSION,
        "source_atlas_id": atlas["atlas_id"],
        "future_items_exposed_to_generator": False,
        "reliable_intervention_count": len(rows),
        "reliable_positive_count": len(positives),
        "reliable_negative_count": len(negatives),
        "collision_pair_count": len(selected),
        "existing_representation_feature_names": list(names),
        "existing_representation_centers": centers,
        "existing_representation_scales": scales,
        "collision_distance_summary": {
            "minimum": min(
                pair["existing_representation_distance"] for pair in selected
            ) if selected else None,
            "median": _percentile(
                tuple(pair["existing_representation_distance"] for pair in selected),
                0.5,
            ) if selected else None,
            "maximum": max(
                pair["existing_representation_distance"] for pair in selected
            ) if selected else None,
        },
        "pairs": selected,
    }
    report["dossier_id"] = content_digest(report)
    return report


def concept_value_for_intervention(
    probe: Mapping[str, Any], action_ref: str
) -> float:
    return concept_value(
        item=int(probe["item"]),
        loads=tuple(int(value) for value in probe["loads"]),
        capacity=150,
        item_index=int(probe["item_index"]),
        history=tuple(int(value) for value in probe["history"]),
        baseline_action=_parse_action(str(probe["baseline_action_ref"])),
        candidate_action=_parse_action(action_ref),
    )


def prediction_rows(
    atlas: Mapping[str, Any], *, include_concept: bool
) -> Tuple[AdvantageTrainingExample, ...]:
    rows = []
    for probe in atlas["probes"]:
        informative = len(
            {float(action["terminal_advantage"]) for action in probe["actions"]}
        ) > 1
        for action in probe["actions"]:
            action_ref = str(action["action_ref"])
            if action_ref == probe["baseline_action_ref"]:
                continue
            features = dict(old_intervention_features(probe, action_ref))
            if include_concept:
                features["invented_admissible_residual_mass_exchange"] = (
                    concept_value_for_intervention(probe, action_ref)
                )
            rows.append(
                AdvantageTrainingExample(
                    state_id=str(probe["probe_id"]),
                    instance_id=str(probe["instance_id"]),
                    action_ref=action_ref,
                    features=features,
                    advantage=float(action["terminal_advantage"]),
                    informative=informative,
                )
            )
    return tuple(rows)


def fit_frozen_prediction_models(
    atlas: Mapping[str, Any],
) -> Tuple[LinearAdvantageModel, LinearAdvantageModel]:
    config = {
        "seed": 448_104_026,
        "epochs": 80,
        "learning_rate": 0.002,
        "ridge": 0.003,
        "informative_weight": 2.0,
    }
    old_model = fit_linear_advantage_model(
        prediction_rows(atlas, include_concept=False), **config
    )
    augmented_model = fit_linear_advantage_model(
        prediction_rows(atlas, include_concept=True), **config
    )
    return old_model, augmented_model


def discovery_concept_summary(dossier: Mapping[str, Any]) -> Mapping[str, Any]:
    ordered = 0
    positive_values = []
    negative_values = []
    for pair in dossier["pairs"]:
        positive = pair["positive"]
        negative = pair["negative"]

        def from_row(row: Mapping[str, Any]) -> float:
            baseline = tuple(int(value) for value in row["baseline_successor_residuals"])
            candidate = tuple(int(value) for value in row["candidate_successor_residuals"])
            support_width = 81.0
            usable = lambda residuals: sum(
                max(0, min(100, residual) - 20 + 1) for residual in residuals
            ) / support_width
            return usable(candidate) - usable(baseline)

        positive_value = from_row(positive)
        negative_value = from_row(negative)
        positive_values.append(positive_value)
        negative_values.append(negative_value)
        ordered += positive_value > negative_value
    return {
        "pair_count": len(positive_values),
        "positive_concept_mean": mean(positive_values),
        "negative_concept_mean": mean(negative_values),
        "positive_above_matched_negative_count": ordered,
        "matched_pair_order_accuracy": ordered / float(len(positive_values)),
    }
