from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance


def _derived_instance(
    source: BinPackingInstance,
    items: Sequence[int],
) -> BinPackingInstance:
    item_tuple = tuple(items)
    return BinPackingInstance(
        instance_id=content_digest(
            {
                "schema": 1,
                "kind": "deletion_counterexample",
                "source_instance_id": source.instance_id,
                "capacity": source.capacity,
                "items": item_tuple,
            }
        )[:20],
        family="minimized_counterexample",
        seed=source.seed,
        capacity=source.capacity,
        items=item_tuple,
    )


@dataclass(frozen=True)
class Counterexample:
    better_name: str
    worse_name: str
    source_instance_id: str
    minimized_instance: BinPackingInstance
    better_bin_count: int
    worse_bin_count: int
    original_length: int
    deletion_minimal: bool
    optimum: Optional[int] = None

    @property
    def gap(self) -> int:
        return self.worse_bin_count - self.better_bin_count

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "better": self.better_name,
            "worse": self.worse_name,
            "source_instance_id": self.source_instance_id,
            "minimized_instance": self.minimized_instance.as_dict(),
            "better_bin_count": self.better_bin_count,
            "worse_bin_count": self.worse_bin_count,
            "gap": self.gap,
            "original_length": self.original_length,
            "minimized_length": len(self.minimized_instance.items),
            "deletion_minimal": self.deletion_minimal,
            "optimum": self.optimum,
        }


def minimize_policy_gap(
    source: BinPackingInstance,
    better: OnlineHeuristic,
    worse: OnlineHeuristic,
) -> Counterexample:
    """Find a deterministic 1-minimal subsequence preserving a strict gap."""

    def gap(items: Sequence[int]) -> Tuple[int, int, int]:
        candidate = _derived_instance(source, items)
        better_count = pack(candidate, better).bin_count
        worse_count = pack(candidate, worse).bin_count
        return worse_count - better_count, better_count, worse_count

    initial_gap, _, _ = gap(source.items)
    if initial_gap <= 0:
        raise ValueError("source does not show a strict policy gap")

    items = list(source.items)
    changed = True
    while changed and len(items) > 1:
        changed = False
        for index in range(len(items)):
            proposal = items[:index] + items[index + 1 :]
            if not proposal:
                continue
            proposal_gap, _, _ = gap(proposal)
            if proposal_gap > 0:
                items = proposal
                changed = True
                break

    minimized = _derived_instance(source, items)
    final_gap, better_count, worse_count = gap(items)
    deletion_minimal = all(
        gap(items[:index] + items[index + 1 :])[0] <= 0
        for index in range(len(items))
        if len(items) > 1
    )
    if final_gap <= 0:
        raise AssertionError("counterexample minimization lost the policy gap")
    return Counterexample(
        better_name=better.name,
        worse_name=worse.name,
        source_instance_id=source.instance_id,
        minimized_instance=minimized,
        better_bin_count=better_count,
        worse_bin_count=worse_count,
        original_length=len(source.items),
        deletion_minimal=deletion_minimal,
    )
