from __future__ import annotations

from dataclasses import dataclass
import random
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import (
    GeneratedPolicyModuleProgram,
)
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.rollout_teacher import (
    RolloutTeacherProbe,
    score_policy_on_rollout_teacher,
)
from scientist.domains.binpacking.stochastic_value import (
    StochasticValueConfig,
    iid_or_episode_suite,
)
from scientist.program.discovery_evidence import paired_episode_evidence


DE_NOVO_CALIBRATION_VERSION = "de-novo-objective-calibration-v1"


@dataclass(frozen=True)
class DeNovoCalibrationConfig:
    capacity: int = 150
    lengths: Tuple[int, ...] = (120, 250, 500)
    variant_budget: int = 24
    calibration_episodes_per_length: int = 6
    admission_episodes_per_length: int = 8
    base_seed: int = 92_830_026
    rollout_regret_weight: float = 0.25

    def __post_init__(self) -> None:
        if self.capacity <= 0 or not self.lengths:
            raise ValueError("invalid de-novo calibration domain")
        if min(self.lengths) <= 1:
            raise ValueError("de-novo calibration episodes are too short")
        if not 1 <= self.variant_budget <= 128:
            raise ValueError("de-novo calibration variant budget is invalid")
        if min(
            self.calibration_episodes_per_length,
            self.admission_episodes_per_length,
        ) < 2:
            raise ValueError("de-novo calibration partitions are too small")
        if self.rollout_regret_weight < 0.0:
            raise ValueError("rollout regret weight must be non-negative")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "capacity": self.capacity,
            "lengths": list(self.lengths),
            "variant_budget": self.variant_budget,
            "calibration_episodes_per_length": (
                self.calibration_episodes_per_length
            ),
            "admission_episodes_per_length": (
                self.admission_episodes_per_length
            ),
            "base_seed": self.base_seed,
            "rollout_regret_weight": self.rollout_regret_weight,
        }


@dataclass(frozen=True)
class DeNovoCalibrationResult:
    original_program: GeneratedPolicyModuleProgram
    selected_program: GeneratedPolicyModuleProgram
    report: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return dict(self.report)


def _parameter_vectors(
    program: GeneratedPolicyModuleProgram,
    config: DeNovoCalibrationConfig,
) -> Tuple[Mapping[str, float], ...]:
    parameters = program.calibration_parameters
    if not parameters:
        return ({},)
    vectors = [
        {parameter.name: parameter.value for parameter in parameters}
    ]
    for parameter in parameters:
        for value in (parameter.minimum, parameter.maximum):
            vector = dict(vectors[0])
            vector[parameter.name] = value
            vectors.append(vector)
    rng = random.Random(
        int(
            content_digest(
                {
                    "version": DE_NOVO_CALIBRATION_VERSION,
                    "hypothesis_id": program.hypothesis_id,
                    "seed": config.base_seed,
                }
            )[:16],
            16,
        )
    )
    while len(vectors) < config.variant_budget:
        vector = {}
        stratum = len(vectors)
        for parameter_index, parameter in enumerate(parameters):
            width = parameter.maximum - parameter.minimum
            fraction = (
                (stratum + rng.random() + parameter_index * 0.61803398875)
                % config.variant_budget
            ) / float(config.variant_budget)
            vector[parameter.name] = parameter.minimum + fraction * width
        vectors.append(vector)
    unique = {}
    for vector in vectors[: config.variant_budget]:
        key = tuple(sorted((name, round(value, 12)) for name, value in vector.items()))
        unique.setdefault(key, vector)
    return tuple(unique.values())


def _episode_evidence(
    candidate: OnlineHeuristic,
    incumbent: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
    incumbent_bins: Mapping[str, int],
) -> Mapping[str, Any]:
    improvements = tuple(
        float(
            incumbent_bins[instance.instance_id]
            - pack(instance, candidate).bin_count
        )
        for instance in instances
    )
    evidence = paired_episode_evidence(
        improvements,
        tuple(instance.instance_id for instance in instances),
    )
    return evidence.as_dict()


def calibrate_de_novo_program(
    program: GeneratedPolicyModuleProgram,
    incumbent: OnlineHeuristic,
    rollout_probes: Sequence[RolloutTeacherProbe],
    *,
    config: DeNovoCalibrationConfig = DeNovoCalibrationConfig(),
) -> DeNovoCalibrationResult:
    """Fit numerical choices on calibration data, then freeze before admission."""

    if program.island_family != "de_novo":
        raise ValueError("objective calibration is reserved for de-novo policies")
    stochastic = StochasticValueConfig(
        capacity=config.capacity,
        training_lengths=config.lengths,
        training_episodes_per_length=2,
        states_per_episode=1,
        actions_per_state=1,
        suffix_samples_per_action=1,
        grouped_cv_folds=1,
        validation_episodes_per_length=2,
        replication_episodes_per_length=2,
        base_seed=config.base_seed,
        fit_epochs=1,
    )
    calibration = iid_or_episode_suite(
        stochastic,
        partition="de-novo-objective-calibration",
        episodes_per_length=config.calibration_episodes_per_length,
        seed_offset=410_000_000,
    )
    admission = iid_or_episode_suite(
        stochastic,
        partition="de-novo-objective-admission",
        episodes_per_length=config.admission_episodes_per_length,
        seed_offset=510_000_000,
    )
    calibration_incumbent_bins = {
        instance.instance_id: pack(instance, incumbent).bin_count
        for instance in calibration
    }
    admission_incumbent_bins = {
        instance.instance_id: pack(instance, incumbent).bin_count
        for instance in admission
    }

    rows = []
    variants = []
    for vector in _parameter_vectors(program, config):
        variant = program.with_calibration_values(vector)
        episode = _episode_evidence(
            variant,
            incumbent,
            calibration,
            calibration_incumbent_bins,
        )
        teacher = score_policy_on_rollout_teacher(variant, rollout_probes)
        selection_score = (
            float(episode["mean_improvement"])
            - config.rollout_regret_weight
            * float(teacher["mean_rollout_regret_bins"])
        )
        rows.append(
            {
                "candidate_id": variant.candidate_id,
                "parameters": {
                    parameter.name: parameter.value
                    for parameter in variant.calibration_parameters
                },
                "calibration_mean_improvement_bins": episode[
                    "mean_improvement"
                ],
                "calibration_mean_ci_lower": episode[
                    "mean_improvement_ci_lower"
                ],
                "calibration_maximum_regression_bins": episode[
                    "maximum_regression"
                ],
                "teacher_mean_rollout_regret_bins": teacher[
                    "mean_rollout_regret_bins"
                ],
                "teacher_best_action_rate": teacher[
                    "teacher_best_action_rate"
                ],
                "selection_score": selection_score,
            }
        )
        variants.append(variant)

    selected_index = max(
        range(len(rows)),
        key=lambda index: (
            rows[index]["selection_score"],
            rows[index]["calibration_mean_improvement_bins"],
            -rows[index]["calibration_maximum_regression_bins"],
            variants[index].candidate_id,
        ),
    )
    selected = variants[selected_index]
    admission_evidence = _episode_evidence(
        selected,
        incumbent,
        admission,
        admission_incumbent_bins,
    )
    default_teacher = score_policy_on_rollout_teacher(program, rollout_probes)
    selected_teacher = score_policy_on_rollout_teacher(selected, rollout_probes)
    failures = []
    if len(program.calibration_parameters) < 2:
        failures.append("insufficient_executable_calibration_parameters")
    if float(admission_evidence["mean_improvement"]) <= 0.0:
        failures.append("failed_independent_incumbent_competency_floor")
    if (
        selected_teacher["mean_rollout_regret_bins"]
        > default_teacher["mean_rollout_regret_bins"] + 1e-12
    ):
        failures.append("calibration_increased_rollout_teacher_regret")

    report: Dict[str, Any] = {
        "schema": 1,
        "calibration_version": DE_NOVO_CALIBRATION_VERSION,
        "hypothesis_id": program.hypothesis_id,
        "original_candidate_id": program.candidate_id,
        "selected_candidate_id": selected.candidate_id,
        "parameter_count": len(program.calibration_parameters),
        "variant_count": len(variants),
        "selected_parameters": {
            parameter.name: parameter.value
            for parameter in selected.calibration_parameters
        },
        "selection_partition": {
            "episode_count": len(calibration),
            "used_for_final_admission": False,
        },
        "admission_partition": {
            "episode_count": len(admission),
            "used_for_parameter_selection": False,
        },
        "default_teacher_score": dict(default_teacher),
        "selected_teacher_score": dict(selected_teacher),
        "selected_calibration_row": rows[selected_index],
        "independent_admission_evidence": admission_evidence,
        "variant_results": rows,
        "passed": not failures,
        "failure_reasons": failures,
    }
    report["calibration_id"] = content_digest(report)
    return DeNovoCalibrationResult(program, selected, report)
