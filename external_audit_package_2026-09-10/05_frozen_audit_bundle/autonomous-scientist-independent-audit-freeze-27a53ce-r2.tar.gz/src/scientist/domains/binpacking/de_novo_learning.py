from __future__ import annotations

from dataclasses import dataclass
import math
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import (
    GeneratedPolicyModuleProgram,
)
from scientist.domains.binpacking.first_principles_oracle import (
    exact_action_values,
    first_principles_oracle_suite,
)
from scientist.domains.binpacking.heuristics import literature_heuristics


DE_NOVO_LEARNING_VERSION = "de-novo-counterexample-learning-v1"


def _action_ref(action: Optional[int]) -> str:
    return "new" if action is None else "bin:%d" % int(action)


def _apply_action(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    if action is None:
        return (*loads, item)
    if action < 0 or action >= len(loads):
        raise ValueError("policy selected a nonexistent bin")
    if loads[action] + item > capacity:
        raise ValueError("policy selected an infeasible bin")
    updated = list(loads)
    updated[action] += item
    return tuple(updated)


def _successor_signature(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
) -> Tuple[int, ...]:
    return tuple(sorted(_apply_action(action, item, loads, 10**9), reverse=True))


@dataclass(frozen=True)
class CounterexampleAtlasConfig:
    capacity: int = 150
    exact_suffix_horizon: int = 5
    minimum_history_items: int = 8
    probe_stride: int = 4
    development_families: Tuple[str, ...] = (
        "first_principles_oracle_complementary",
        "first_principles_oracle_paired_mixture",
    )
    holdout_families: Tuple[str, ...] = (
        "first_principles_oracle_uniform",
        "first_principles_oracle_regime_switch",
    )
    minimum_development_helpful_actions: int = 2
    minimum_holdout_helpful_actions: int = 1
    minimum_holdout_selective_advantage: int = 1
    minimum_parameter_action_change_rate: float = 0.01

    def __post_init__(self) -> None:
        if self.capacity <= 0:
            raise ValueError("counterexample-atlas capacity must be positive")
        if not 2 <= self.exact_suffix_horizon <= 10:
            raise ValueError("counterexample-atlas suffix horizon is invalid")
        if self.minimum_history_items < 0 or self.probe_stride <= 0:
            raise ValueError("counterexample-atlas sampling is invalid")
        if not self.development_families or not self.holdout_families:
            raise ValueError("counterexample atlas needs two partitions")
        if set(self.development_families).intersection(self.holdout_families):
            raise ValueError("counterexample-atlas families must be disjoint")
        if min(
            self.minimum_development_helpful_actions,
            self.minimum_holdout_helpful_actions,
            self.minimum_holdout_selective_advantage,
        ) < 1:
            raise ValueError("counterexample-atlas evidence floors must be positive")
        if not 0.0 <= self.minimum_parameter_action_change_rate <= 1.0:
            raise ValueError("parameter sensitivity floor must be in [0, 1]")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "capacity": self.capacity,
            "exact_suffix_horizon": self.exact_suffix_horizon,
            "minimum_history_items": self.minimum_history_items,
            "probe_stride": self.probe_stride,
            "development_families": list(self.development_families),
            "holdout_families": list(self.holdout_families),
            "minimum_development_helpful_actions": (
                self.minimum_development_helpful_actions
            ),
            "minimum_holdout_helpful_actions": (
                self.minimum_holdout_helpful_actions
            ),
            "minimum_holdout_selective_advantage": (
                self.minimum_holdout_selective_advantage
            ),
            "minimum_parameter_action_change_rate": (
                self.minimum_parameter_action_change_rate
            ),
        }


@dataclass(frozen=True)
class CounterexampleProbe:
    probe_id: str
    partition: str
    instance_id: str
    family: str
    item: int
    loads: Tuple[int, ...]
    capacity: int
    item_index: int
    history: Tuple[int, ...]
    action_values: Tuple[Tuple[str, int], ...]
    incumbent_action_ref: str

    @property
    def values(self) -> Mapping[str, int]:
        return dict(self.action_values)

    @property
    def incumbent_regret(self) -> int:
        values = self.values
        return values[self.incumbent_action_ref] - min(values.values())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe_id": self.probe_id,
            "partition": self.partition,
            "instance_id": self.instance_id,
            "family": self.family,
            "item": self.item,
            "loads": list(self.loads),
            "capacity": self.capacity,
            "item_index": self.item_index,
            "history": list(self.history),
            "action_values": [
                {"action_ref": action_ref, "exact_terminal_bins": value}
                for action_ref, value in self.action_values
            ],
            "incumbent_action_ref": self.incumbent_action_ref,
            "incumbent_exact_action_regret": self.incumbent_regret,
        }


@dataclass(frozen=True)
class CounterexampleAtlas:
    config: CounterexampleAtlasConfig
    probes: Tuple[CounterexampleProbe, ...]
    report: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            **dict(self.report),
            "config": self.config.as_dict(),
            "probes": [probe.as_dict() for probe in self.probes],
        }


def build_counterexample_atlas(
    config: CounterexampleAtlasConfig = CounterexampleAtlasConfig(),
) -> CounterexampleAtlas:
    """Build a fixed exact-action atlas on trajectories of the target incumbent."""

    incumbent = literature_heuristics()["funsearch_or_reference"]
    allowed = set(config.development_families).union(config.holdout_families)
    probes = []
    family_counts: Dict[str, int] = {}
    opportunity_counts: Dict[str, int] = {}
    for instance in first_principles_oracle_suite(config.capacity):
        if instance.family not in allowed:
            continue
        partition = (
            "development"
            if instance.family in config.development_families
            else "holdout"
        )
        loads: Tuple[int, ...] = ()
        history: Tuple[int, ...] = ()
        for item_index, item in enumerate(instance.items):
            incumbent_action = incumbent.choose_bin(
                item, loads, instance.capacity, item_index, history
            )
            is_probe = (
                item_index >= config.minimum_history_items
                and (item_index - config.minimum_history_items)
                % config.probe_stride
                == 0
            )
            if is_probe:
                raw_values = exact_action_values(
                    item=item,
                    loads=loads,
                    remaining_items=instance.items[
                        item_index + 1 :
                        item_index + config.exact_suffix_horizon
                    ],
                    capacity=instance.capacity,
                )
                values = tuple(
                    sorted(
                        (
                            (_action_ref(action), int(value))
                            for action, value in raw_values.items()
                        ),
                        key=lambda pair: pair[0],
                    )
                )
                material = {
                    "version": DE_NOVO_LEARNING_VERSION,
                    "instance_id": instance.instance_id,
                    "item_index": item_index,
                    "loads": list(loads),
                    "item": item,
                }
                probe = CounterexampleProbe(
                    probe_id=content_digest(material),
                    partition=partition,
                    instance_id=instance.instance_id,
                    family=instance.family,
                    item=item,
                    loads=loads,
                    capacity=instance.capacity,
                    item_index=item_index,
                    history=history,
                    action_values=values,
                    incumbent_action_ref=_action_ref(incumbent_action),
                )
                probes.append(probe)
                family_counts[instance.family] = (
                    family_counts.get(instance.family, 0) + 1
                )
                if probe.incumbent_regret > 0:
                    opportunity_counts[instance.family] = (
                        opportunity_counts.get(instance.family, 0) + 1
                    )
            loads = _apply_action(
                incumbent_action, item, loads, instance.capacity
            )
            history = (*history, item)

    partition_counts = {
        partition: sum(probe.partition == partition for probe in probes)
        for partition in ("development", "holdout")
    }
    opportunity_by_partition = {
        partition: sum(
            probe.partition == partition and probe.incumbent_regret > 0
            for probe in probes
        )
        for partition in ("development", "holdout")
    }
    report: Dict[str, Any] = {
        "schema": 1,
        "learning_version": DE_NOVO_LEARNING_VERSION,
        "incumbent_policy_id": "funsearch_or_reference",
        "candidate_future_access": False,
        "state_trajectory_policy": "funsearch_or_reference",
        "probe_count": len(probes),
        "partition_probe_counts": partition_counts,
        "incumbent_opportunity_count": sum(
            probe.incumbent_regret > 0 for probe in probes
        ),
        "partition_opportunity_counts": opportunity_by_partition,
        "family_probe_counts": dict(sorted(family_counts.items())),
        "family_opportunity_counts": dict(
            sorted(opportunity_counts.items())
        ),
        "partitions_disjoint_by_family": True,
    }
    report["atlas_id"] = content_digest(
        {
            **report,
            "config": config.as_dict(),
            "probe_ids": [probe.probe_id for probe in probes],
        }
    )
    return CounterexampleAtlas(config, tuple(probes), report)


def _candidate_action_ref(
    program: GeneratedPolicyModuleProgram,
    probe: CounterexampleProbe,
) -> str:
    return _action_ref(
        program.choose_bin(
            probe.item,
            probe.loads,
            probe.capacity,
            probe.item_index,
            probe.history,
        )
    )


def _action_residual(
    action_ref: str,
    probe: CounterexampleProbe,
) -> float:
    if action_ref == "new":
        return (probe.capacity - probe.item) / float(probe.capacity)
    index = int(action_ref.split(":", 1)[1])
    return (
        probe.capacity - probe.loads[index] - probe.item
    ) / float(probe.capacity)


def _representation_features(
    program: GeneratedPolicyModuleProgram,
    probe: CounterexampleProbe,
    candidate_action_ref: str,
) -> Mapping[str, float]:
    state = program.observable_state_features(
        probe.item,
        probe.loads,
        probe.capacity,
        probe.item_index,
        probe.history,
    )
    feasible = sum(
        load + probe.item <= probe.capacity for load in probe.loads
    )
    residuals = tuple(
        (probe.capacity - load) / float(probe.capacity)
        for load in probe.loads
    )
    features = {
        "observable_item_ratio": probe.item / float(probe.capacity),
        "observable_bin_count": float(len(probe.loads)),
        "observable_feasible_count": float(feasible),
        "observable_history_count": float(len(probe.history)),
        "observable_mean_residual": mean(residuals) if residuals else 1.0,
        "observable_min_residual": min(residuals) if residuals else 1.0,
        "observable_max_residual": max(residuals) if residuals else 1.0,
        "candidate_post_action_residual": _action_residual(
            candidate_action_ref, probe
        ),
    }
    for name, value in state.items():
        features["candidate_state_%s" % name] = float(value)
    return features


def _partition_summary(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    overrides = [row for row in rows if row["override"]]
    advantages = [int(row["advantage"]) for row in overrides]
    return {
        "probe_count": len(rows),
        "override_count": len(overrides),
        "helpful_override_count": sum(value > 0 for value in advantages),
        "harmful_override_count": sum(value < 0 for value in advantages),
        "tied_override_count": sum(value == 0 for value in advantages),
        "unconditional_net_advantage_bins": sum(advantages),
        "oracle_selective_upper_bound_bins": sum(
            max(0, value) for value in advantages
        ),
    }


def _candidate_thresholds(values: Sequence[float]) -> Tuple[float, ...]:
    unique = sorted(set(float(value) for value in values if math.isfinite(value)))
    if len(unique) < 2:
        return ()
    indices = range(len(unique) - 1)
    if len(unique) > 33:
        indices = tuple(
            sorted(
                set(
                    int(round(index * (len(unique) - 2) / 31.0))
                    for index in range(32)
                )
            )
        )
    return tuple((unique[index] + unique[index + 1]) / 2.0 for index in indices)


def _fit_authority_rule(
    rows: Sequence[Mapping[str, Any]],
) -> Optional[Mapping[str, Any]]:
    overrides = [row for row in rows if row["override"]]
    if not overrides:
        return None
    feature_names = sorted(
        set.intersection(*(set(row["features"]) for row in overrides))
    )
    best = None
    for name in feature_names:
        thresholds = _candidate_thresholds(
            [float(row["features"][name]) for row in overrides]
        )
        for threshold in thresholds:
            for direction in ("le", "gt"):
                selected = [
                    row
                    for row in overrides
                    if (
                        float(row["features"][name]) <= threshold
                        if direction == "le"
                        else float(row["features"][name]) > threshold
                    )
                ]
                if not selected:
                    continue
                advantages = [int(row["advantage"]) for row in selected]
                candidate = {
                    "feature": name,
                    "threshold": threshold,
                    "direction": direction,
                    "selected_count": len(selected),
                    "helpful_count": sum(value > 0 for value in advantages),
                    "harmful_count": sum(value < 0 for value in advantages),
                    "net_advantage_bins": sum(advantages),
                }
                rank = (
                    candidate["net_advantage_bins"],
                    candidate["helpful_count"],
                    -candidate["harmful_count"],
                    -candidate["selected_count"],
                    name,
                    direction,
                    -threshold,
                )
                if best is None or rank > best[0]:
                    best = (rank, candidate)
    return None if best is None else best[1]


def _score_authority_rule(
    rule: Optional[Mapping[str, Any]],
    rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    if rule is None:
        return {
            "selected_count": 0,
            "helpful_count": 0,
            "harmful_count": 0,
            "tied_count": 0,
            "net_advantage_bins": 0,
        }
    selected = []
    for row in rows:
        if not row["override"] or rule["feature"] not in row["features"]:
            continue
        value = float(row["features"][rule["feature"]])
        match = (
            value <= float(rule["threshold"])
            if rule["direction"] == "le"
            else value > float(rule["threshold"])
        )
        if match:
            selected.append(int(row["advantage"]))
    return {
        "selected_count": len(selected),
        "helpful_count": sum(value > 0 for value in selected),
        "harmful_count": sum(value < 0 for value in selected),
        "tied_count": sum(value == 0 for value in selected),
        "net_advantage_bins": sum(selected),
    }


def _parameter_sensitivity(
    program: GeneratedPolicyModuleProgram,
    probes: Sequence[CounterexampleProbe],
) -> Mapping[str, Any]:
    if not program.calibration_parameters:
        return {
            "parameter_count": 0,
            "changed_probe_count": 0,
            "probe_count": len(probes),
            "action_change_rate": 0.0,
            "per_parameter": {},
        }
    default_actions = tuple(_candidate_action_ref(program, probe) for probe in probes)
    any_changed = [False] * len(probes)
    per_parameter = {}
    for parameter in program.calibration_parameters:
        changed = [False] * len(probes)
        for value in (parameter.minimum, parameter.maximum):
            variant = program.with_calibration_values({parameter.name: value})
            actions = tuple(
                _candidate_action_ref(variant, probe) for probe in probes
            )
            for index, (default, action) in enumerate(
                zip(default_actions, actions)
            ):
                if default != action:
                    changed[index] = True
                    any_changed[index] = True
        per_parameter[parameter.name] = {
            "changed_probe_count": sum(changed),
            "action_change_rate": sum(changed) / float(max(1, len(probes))),
        }
    return {
        "parameter_count": len(program.calibration_parameters),
        "changed_probe_count": sum(any_changed),
        "probe_count": len(probes),
        "action_change_rate": sum(any_changed) / float(max(1, len(probes))),
        "per_parameter": per_parameter,
    }


def assess_representation_headroom(
    program: GeneratedPolicyModuleProgram,
    atlas: CounterexampleAtlas,
) -> Mapping[str, Any]:
    """Test opportunity, separability, and executable sensitivity independently."""

    rows = []
    for probe in atlas.probes:
        candidate_action_ref = _candidate_action_ref(program, probe)
        values = probe.values
        if candidate_action_ref not in values:
            raise ValueError("candidate action is absent from atlas action values")
        candidate_signature = _successor_signature(
            None
            if candidate_action_ref == "new"
            else int(candidate_action_ref.split(":", 1)[1]),
            probe.item,
            probe.loads,
        )
        incumbent_signature = _successor_signature(
            None
            if probe.incumbent_action_ref == "new"
            else int(probe.incumbent_action_ref.split(":", 1)[1]),
            probe.item,
            probe.loads,
        )
        advantage = (
            values[probe.incumbent_action_ref] - values[candidate_action_ref]
        )
        rows.append(
            {
                "probe_id": probe.probe_id,
                "partition": probe.partition,
                "family": probe.family,
                "candidate_action_ref": candidate_action_ref,
                "incumbent_action_ref": probe.incumbent_action_ref,
                "advantage": advantage,
                "override": candidate_signature != incumbent_signature,
                "features": _representation_features(
                    program, probe, candidate_action_ref
                ),
            }
        )

    development = [row for row in rows if row["partition"] == "development"]
    holdout = [row for row in rows if row["partition"] == "holdout"]
    development_summary = _partition_summary(development)
    holdout_summary = _partition_summary(holdout)
    rule = _fit_authority_rule(development)
    development_rule = _score_authority_rule(rule, development)
    holdout_rule = _score_authority_rule(rule, holdout)
    sensitivity = _parameter_sensitivity(program, atlas.probes)
    failures = []
    config = atlas.config
    if (
        development_summary["helpful_override_count"]
        < config.minimum_development_helpful_actions
    ):
        failures.append("insufficient_development_target_headroom")
    if (
        holdout_summary["helpful_override_count"]
        < config.minimum_holdout_helpful_actions
    ):
        failures.append("no_heldout_target_headroom")
    if rule is None or development_rule["net_advantage_bins"] <= 0:
        failures.append("representation_not_separable_on_development")
    if (
        holdout_rule["net_advantage_bins"]
        < config.minimum_holdout_selective_advantage
    ):
        failures.append("representation_does_not_transport_to_heldout_families")
    if (
        program.calibration_parameters
        and sensitivity["action_change_rate"]
        < config.minimum_parameter_action_change_rate
    ):
        failures.append("declared_parameters_are_behaviorally_insensitive")

    examples = sorted(
        (
            {
                key: row[key]
                for key in (
                    "probe_id",
                    "partition",
                    "family",
                    "candidate_action_ref",
                    "incumbent_action_ref",
                    "advantage",
                )
            }
            for row in rows
            if row["override"] and row["advantage"] != 0
        ),
        key=lambda row: (
            -abs(int(row["advantage"])),
            row["partition"],
            row["probe_id"],
        ),
    )[:12]
    report: Dict[str, Any] = {
        "schema": 1,
        "learning_version": DE_NOVO_LEARNING_VERSION,
        "candidate_id": program.candidate_id,
        "hypothesis_id": program.hypothesis_id,
        "atlas_id": atlas.report["atlas_id"],
        "target_policy_id": "funsearch_or_reference",
        "candidate_future_access": False,
        "feature_source": "candidate_state_plus_candidate_action_geometry",
        "development": development_summary,
        "holdout": holdout_summary,
        "authority_rule": rule,
        "development_rule_evidence": development_rule,
        "holdout_rule_evidence": holdout_rule,
        "parameter_sensitivity": sensitivity,
        "counterexample_examples": examples,
        "passed": not failures,
        "failure_reasons": failures,
    }
    report["assessment_id"] = content_digest(report)
    return report


def classify_de_novo_evidence(
    representation_headroom: Mapping[str, Any],
    *,
    calibration: Optional[Mapping[str, Any]] = None,
    objective_oracle: Optional[Mapping[str, Any]] = None,
) -> Mapping[str, Any]:
    """Turn rejection evidence into a concrete next theory operation."""

    development = representation_headroom["development"]
    holdout = representation_headroom["holdout"]
    sensitivity = representation_headroom["parameter_sensitivity"]
    if (
        development["oracle_selective_upper_bound_bins"] <= 0
        and holdout["oracle_selective_upper_bound_bins"] <= 0
    ):
        failure_kind = "theory_has_no_target_headroom"
        disposition = "replace_causal_mechanism"
        required_changes = (
            "mediator",
            "protected_resource",
            "surrogate_objective",
        )
    elif "declared_parameters_are_behaviorally_insensitive" in (
        representation_headroom["failure_reasons"]
    ):
        failure_kind = "executable_control_is_insensitive"
        disposition = "compile_structurally_distinct_approximation"
        required_changes = (
            "controller_structure",
            "executable_degrees_of_freedom",
        )
    elif not representation_headroom["passed"]:
        failure_kind = "target_headroom_not_observably_separable"
        disposition = "revise_state_representation"
        required_changes = (
            "observable_state",
            "authority_boundary",
            "counterexample_partition",
        )
    elif objective_oracle is not None and not objective_oracle.get(
        "passed", False
    ):
        failure_kind = "approximation_fails_causal_oracle"
        disposition = "compile_structurally_distinct_approximation"
        required_changes = (
            "tractable_approximation",
            "credit_horizon",
            "action_realization",
        )
    elif calibration is not None and not calibration.get("passed", False):
        failure_kind = "locally_valid_but_globally_uncompetitive"
        disposition = "revise_credit_and_complete_controller"
        required_changes = (
            "complete_controller",
            "credit_assignment",
            "surrogate_objective",
        )
    else:
        failure_kind = "passed_cheap_learning_gates"
        disposition = "run_independent_episode_evaluation"
        required_changes = ()
    result: Dict[str, Any] = {
        "schema": 1,
        "learning_version": DE_NOVO_LEARNING_VERSION,
        "failure_kind": failure_kind,
        "disposition": disposition,
        "required_changes": list(required_changes),
        "preserve_theory": disposition not in {"replace_causal_mechanism"},
    }
    result["classification_id"] = content_digest(result)
    return result


def build_de_novo_research_memory(
    program: GeneratedPolicyModuleProgram,
    representation_headroom: Mapping[str, Any],
    classification: Mapping[str, Any],
    *,
    calibration: Optional[Mapping[str, Any]] = None,
    objective_oracle: Optional[Mapping[str, Any]] = None,
    campaign_stage_id: Optional[str] = None,
) -> Mapping[str, Any]:
    value: Dict[str, Any] = {
        "schema": 1,
        "learning_version": DE_NOVO_LEARNING_VERSION,
        "campaign_stage_id": campaign_stage_id,
        "hypothesis_id": program.hypothesis_id,
        "candidate_id": program.candidate_id,
        "known_family": program.mechanism_fingerprint.known_family,
        "decision_topology": program.mechanism_fingerprint.decision_topology,
        "representation_headroom": dict(representation_headroom),
        "classification": dict(classification),
        "objective_calibration": (
            None if calibration is None else dict(calibration)
        ),
        "objective_oracle_gate": (
            None if objective_oracle is None else dict(objective_oracle)
        ),
        "episode_screen_executed": False,
    }
    value["memory_id"] = content_digest(value)
    return value
