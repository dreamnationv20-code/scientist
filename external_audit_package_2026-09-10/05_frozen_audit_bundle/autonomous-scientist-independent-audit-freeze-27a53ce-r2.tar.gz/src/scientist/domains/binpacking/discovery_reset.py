from __future__ import annotations

from dataclasses import dataclass, field, replace
from collections import Counter
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Protocol, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.binpacking.benchmark_conformance import (
    verify_funsearch_benchmark_conformance,
)
from scientist.domains.binpacking.adapter import BinPackingAdapter
from scientist.domains.binpacking.causal_diagnostics import (
    trace_first_effective_decision,
)
from scientist.domains.binpacking.code_policy import (
    CodeModelBackend,
    LEGACY_REPRESENTATION_CONTRACT_ID,
    OpenAIResponsesCodeModel,
)
from scientist.domains.binpacking.goal_program import (
    BinPackingGoalProgram,
    BinPackingGoalRunConfig,
    RESEARCH_GOAL,
    build_control_plane,
    goal_nodes,
    high_level_goal,
    literature_assessment,
)
from scientist.domains.binpacking.heuristics import (
    OnlineHeuristic,
    literature_heuristics,
    pack,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.literature_ontology import (
    BINPACKING_LITERATURE_VOCABULARY,
)
from scientist.domains.binpacking.stochastic_value import (
    DistilledStochasticValuePolicy,
    LinearValueModel,
    StochasticValueConfig,
    iid_or_episode_suite,
    train_stochastic_suffix_value,
)
from scientist.domains.binpacking.programs import program_from_dict
from scientist.domains.binpacking.research_strategy import (
    BinPackingRepresentationStrategist,
    initial_binpacking_research_program,
)
from scientist.program.discovery_evidence import (
    paired_episode_evidence,
    qualify_deployment,
    qualify_discovery,
)
from scientist.program.goal_graph_runtime import GoalGraphRuntime
from scientist.kernel.contracts import EvidencePartition, SearchFamily
from scientist.program.campaigns import (
    CampaignRoundSummary,
    InformationChannel,
    IslandCandidateProposal,
    default_information_views,
)
from scientist.program.literature import (
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    SearchFacet,
)
from scientist.program.literature_grounding import (
    LiteratureHypothesisContext,
    build_literature_hypothesis_context,
)
from scientist.program.research_strategy import (
    ResearchProgramContract,
    ResearchProgramDiagnosis,
    ResearchProgramEvidence,
    ResearchStrategyPolicy,
    StrategyDisposition,
    diagnose_research_program,
)
from scientist.program.web_literature import default_live_web_reviewer
from scientist.search.islands import (
    ISLAND_SEARCH_VERSION,
    IslandSearchConfig,
    MechanismCodeProposer,
    Proposal,
    run_island_search,
)


DISCOVERY_RESET_VERSION = (
    "binpacking-discovery-reset-v4-first-principles-de-novo"
)
_ISLAND_FAMILIES = {
    "funsearch_ancestry": "ancestry",
    "de_novo": "de_novo",
    "hybrid": "hybrid",
}
_SEARCH_FAMILY_BY_ISLAND = {
    "funsearch_ancestry": SearchFamily.ANCESTRY,
    "de_novo": SearchFamily.DE_NOVO,
    "hybrid": SearchFamily.HYBRID,
}
AuthorityCandidateIndex = Dict[Tuple[str, int, SearchFamily], str]


def _artifact_root_contains_material(root: Path) -> bool:
    """Ignore empty backend-created directories, but reject durable content."""

    return root.exists() and any(
        not item.is_dir() for item in root.rglob("*")
    )


class LiteratureReviewer(Protocol):
    def review(self, planned: PriorArtAssessment) -> PriorArtAssessment:
        ...


@dataclass(frozen=True)
class DiscoveryResetConfig:
    search_rounds: int = 2
    code_candidates_per_island_per_round: int = 12
    initial_code_candidates: int = 4
    screen_episodes_per_length: int = 40
    discovery_audit_episodes_per_length: int = 200
    replication_episodes_per_length: int = 400
    code_batch_size: int = 4
    max_representation_revisions: int = 2
    literature_timeout_seconds: float = 20.0
    literature_results_per_query: int = 8
    value: StochasticValueConfig = field(default_factory=StochasticValueConfig)

    def __post_init__(self) -> None:
        counts = (
            self.search_rounds,
            self.code_candidates_per_island_per_round,
            self.initial_code_candidates,
            self.screen_episodes_per_length,
            self.discovery_audit_episodes_per_length,
            self.replication_episodes_per_length,
            self.code_batch_size,
            self.max_representation_revisions,
            self.literature_results_per_query,
        )
        if min(counts) <= 0:
            raise ValueError("discovery-reset counts must be positive")
        if self.initial_code_candidates > self.code_candidates_per_island_per_round:
            raise ValueError("initial code batch exceeds island budget")
        if (
            self.search_rounds > 1
            and self.code_candidates_per_island_per_round < 2
        ):
            raise ValueError(
                "multi-round search requires room for a carried control and a new candidate"
            )
        if self.literature_timeout_seconds <= 0.0:
            raise ValueError("literature timeout must be positive")

    @property
    def discovery_episode_count(self) -> int:
        return (
            len(self.value.training_lengths)
            * self.discovery_audit_episodes_per_length
        )

    @property
    def replication_episode_count(self) -> int:
        return (
            len(self.value.training_lengths)
            * self.replication_episodes_per_length
        )

    @property
    def production_evidence_contract_passed(self) -> bool:
        return (
            self.value.production_evidence_contract_passed
            and self.discovery_episode_count >= 500
            and self.replication_episode_count >= 1_000
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": DISCOVERY_RESET_VERSION,
            "search_rounds": self.search_rounds,
            "code_candidates_per_island_per_round": (
                self.code_candidates_per_island_per_round
            ),
            "initial_code_candidates": self.initial_code_candidates,
            "screen_episodes_per_length": self.screen_episodes_per_length,
            "discovery_audit_episodes_per_length": (
                self.discovery_audit_episodes_per_length
            ),
            "discovery_episode_count": self.discovery_episode_count,
            "replication_episodes_per_length": (
                self.replication_episodes_per_length
            ),
            "replication_episode_count": self.replication_episode_count,
            "code_batch_size": self.code_batch_size,
            "max_representation_revisions": (
                self.max_representation_revisions
            ),
            "literature_timeout_seconds": self.literature_timeout_seconds,
            "literature_results_per_query": self.literature_results_per_query,
            "value": self.value.as_dict(),
            "production_evidence_contract_passed": (
                self.production_evidence_contract_passed
            ),
        }


def _family_queries(family: str, findings: str) -> Tuple[LiteratureQuery, ...]:
    base = {
        "ancestry": (
            "evolutionary heuristic generation online bin packing",
            "FunSearch bin packing follow-up program synthesis heuristic",
        ),
        "de_novo": (
            "offline policy improvement counterfactual action value selective prediction calibration",
            "reinforcement learning online bin packing future demand distribution",
        ),
        "hybrid": (
            "safe policy improvement baseline bootstrapping abstention counterfactual",
            "safe policy improvement baseline override sequential allocation",
        ),
        "cross_domain": (
            "model predictive control irreversible decisions uncertainty scenario rollout",
            "approximate dynamic programming reservation uncertain demand",
        ),
    }[family]
    finding_query = " ".join(findings.split())[:240]
    queries = (*base, finding_query) if finding_query else base
    facets = (SearchFacet.MECHANISM, SearchFacet.INTERVENTION, SearchFacet.EVALUATION)
    return tuple(
        LiteratureQuery(
            query=query,
            facet=facets[min(index, len(facets) - 1)],
            provider="live-multi-provider-web-survey",
        )
        for index, query in enumerate(queries)
    )


def _planned_literature(
    node: Any,
    family: str,
    findings: str,
    round_index: int,
) -> PriorArtAssessment:
    base = literature_assessment(
        node,
        trigger=(
            LiteratureTrigger.INITIAL_SCOPE
            if round_index == 0
            else LiteratureTrigger.PERIODIC_DELTA
        ),
        candidate_delta=(findings or None),
    )
    return replace(
        base,
        queries=(*base.queries, *_family_queries(family, findings)),
        rationale=(
            base.rationale
            + " The %s discovery channel receives full source content before "
            "the next executable-code proposal round." % family
        ),
        reviewer_ref="discovery-reset-live-literature-plan-v1",
    )


def _review_contexts(
    reviewer: LiteratureReviewer,
    node: Any,
    findings_by_family: Mapping[str, str],
    round_index: int,
    store: ArtifactStore,
    runtime: GoalGraphRuntime,
) -> Tuple[
    Mapping[str, PriorArtAssessment],
    Mapping[str, LiteratureHypothesisContext],
]:
    assessments = {}
    contexts = {}
    for family in (*_ISLAND_FAMILIES.values(), "cross_domain"):
        assessment = reviewer.review(
            _planned_literature(
                node,
                family,
                findings_by_family.get(family, ""),
                round_index,
            )
        )
        if not assessment.closure_passed:
            raise ValueError(
                "%s literature survey did not reach fail-closed closure" % family
            )
        runtime.transact("register_literature_assessment", assessment)
        context = build_literature_hypothesis_context(
            assessment,
            family,
            vocabulary=BINPACKING_LITERATURE_VOCABULARY,
        )
        assessments[family] = assessment
        contexts[family] = context
        store.put(
            "discovery_reset_literature_source_context",
            context.as_dict(),
        )
    return assessments, contexts


def _candidate_performance(
    candidate: OnlineHeuristic,
    ancestry: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
    *,
    minimum_episodes: int,
) -> Mapping[str, Any]:
    improvements = tuple(
        float(
            pack(instance, ancestry).bin_count
            - pack(instance, candidate).bin_count
        )
        for instance in instances
    )
    evidence = paired_episode_evidence(
        improvements,
        tuple(instance.instance_id for instance in instances),
    )
    discovery = qualify_discovery(
        evidence,
        minimum_independent_episodes=minimum_episodes,
    )
    deployment = qualify_deployment(
        evidence,
        maximum_allowed_regression=1.0,
        maximum_allowed_loss_rate=0.05,
    )
    return {
        "candidate_id": getattr(candidate, "candidate_id", candidate.name),
        "candidate": dict(candidate.as_dict()),
        "discovery": discovery.as_dict(),
        "deployment": deployment.as_dict(),
        "discovery_passed": discovery.passed,
        "deployment_passed": deployment.passed,
        "rank": (
            discovery.passed,
            evidence.mean_ci_lower,
            evidence.mean_improvement,
            evidence.aggregate_improvement,
        ),
    }


def _findings(outcome: Any) -> str:
    best = outcome.best
    evidence = best.discovery_evidence
    rationale = str(getattr(best.program, "rationale", ""))
    return (
        "Candidate source rationale: %s. Mean episode improvement %.6f; "
        "95%% lower bound %.6f; wins %d, losses %d. Search for equations, "
        "limitations, and mechanisms that explain or overcome this result."
        % (
            rationale,
            evidence.mean_improvement,
            evidence.mean_ci_lower,
            evidence.wins,
            evidence.losses,
        )
    )


def _post_effect_causal_analysis(
    candidate: OnlineHeuristic,
    ancestry: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
) -> Mapping[str, Any]:
    ranked = sorted(
        instances,
        key=lambda instance: (
            pack(instance, candidate).bin_count
            - pack(instance, ancestry).bin_count,
            instance.instance_id,
        ),
        reverse=True,
    )[:8]
    models = []
    for instance in ranked:
        try:
            trace = trace_first_effective_decision(
                "post-effect-candidate-refinement",
                instance,
                candidate,
            )
        except ValueError as error:
            models.append(
                {
                    "instance_id": instance.instance_id,
                    "status": "no_trace",
                    "error": str(error),
                }
            )
            continue
        models.append(
            {
                "instance_id": instance.instance_id,
                "status": trace.status.value,
                "what_information_was_unavailable": (
                    "future demand for residual capacities %d and %d"
                    % (
                        trace.chosen_remaining_after,
                        trace.alternative_remaining_after,
                    )
                ),
                "irreversible_decision": {
                    "decision_index": trace.decision_index,
                    "item": trace.item,
                    "chosen_action": trace.chosen_action,
                },
                "alternative_action": trace.alternative_action,
                "changed_result_bins": trace.outcome_delta,
                "mediator": trace.mediator,
                "distinguishing_prediction": (
                    "forcing the alternative once and resuming the unchanged "
                    "policy changes final bin count by the measured amount"
                ),
                "trace": trace.as_dict(),
            }
        )
    return {
        "status": "performed_after_replicated_episode_effect",
        "used_for_initial_hypothesis_generation": False,
        "purpose": "understand and refine an already promising policy",
        "models": models,
    }


def _context_checkpoint_value(
    round_index: int,
    contexts: Mapping[str, LiteratureHypothesisContext],
) -> Mapping[str, Any]:
    return {
        "program_version": DISCOVERY_RESET_VERSION,
        "round_index": round_index,
        "assessment_ids": {
            family: context.assessment_id
            for family, context in contexts.items()
        },
        "contexts": {
            family: context.as_dict()
            for family, context in contexts.items()
        },
    }


def _load_context_checkpoint(
    store: ArtifactStore,
    round_index: int,
) -> Optional[Tuple[Mapping[str, str], Mapping[str, LiteratureHypothesisContext]]]:
    matches = [
        value
        for _, value in store.iter_kind("discovery_reset_literature_round")
        if int(value["round_index"]) == round_index
    ]
    if len(matches) > 1:
        raise ValueError("multiple literature checkpoints exist for one round")
    if not matches:
        return None
    value = matches[0]
    contexts = {
        family: LiteratureHypothesisContext.from_dict(context)
        for family, context in value["contexts"].items()
    }
    return (
        {
            family: str(assessment_id)
            for family, assessment_id in value["assessment_ids"].items()
        },
        contexts,
    )


def _load_legacy_initial_contexts(
    store: ArtifactStore,
) -> Mapping[str, LiteratureHypothesisContext]:
    contexts: Dict[str, LiteratureHypothesisContext] = {}
    for _, value in store.iter_kind(
        "discovery_reset_literature_source_context"
    ):
        context = LiteratureHypothesisContext.from_dict(value)
        if context.island_family in contexts:
            raise ValueError(
                "initial literature contexts are ambiguous; no round checkpoint exists"
            )
        contexts[context.island_family] = context
    expected = {*_ISLAND_FAMILIES.values(), "cross_domain"}
    if set(contexts) != expected:
        raise ValueError("resume requires one closed initial context per family")
    return contexts


def _stage_id(
    config: DiscoveryResetConfig,
    round_index: int,
    island: str,
    context: LiteratureHypothesisContext,
    representation_id: Optional[str] = None,
) -> str:
    value = {
        "program_version": DISCOVERY_RESET_VERSION,
        "round_index": round_index,
        "island": island,
        "literature_context_id": context.context_id,
        "seed": config.value.base_seed + round_index * 101,
        "evaluation_budget": config.code_candidates_per_island_per_round,
    }
    # Keep legacy round-zero stage identities resumable.  Every actual
    # representation revision receives a new stage namespace.
    if representation_id is not None:
        value["representation_id"] = representation_id
    return content_digest(value)


def _load_completed_island(
    store: ArtifactStore,
    stage_id: str,
) -> Optional[Mapping[str, Any]]:
    matches = [
        value
        for _, value in store.iter_kind("discovery_reset_island_completed")
        if value["campaign_stage_id"] == stage_id
    ]
    if len(matches) > 1:
        raise ValueError("multiple completion artifacts exist for one island stage")
    return None if not matches else matches[0]["outcome"]


def _load_resumed_proposals(
    store: ArtifactStore,
    *,
    stage_id: str,
    island: str,
    context: LiteratureHypothesisContext,
    round_index: int,
) -> Tuple[Proposal, ...]:
    selected: Dict[str, Tuple[int, int, Mapping[str, Any]]] = {}
    expected_families = {
        "funsearch_ancestry": {"ancestry"},
        "de_novo": {"de_novo", "cross_domain"},
        "hybrid": {"hybrid"},
    }[island]
    terminal_rejections = {
        str(value.get("candidate", {}).get("candidate_id", ""))
        for _, value in store.iter_kind("three_island_pre_screen_rejection")
        if value.get("campaign_stage_id") == stage_id
        and value.get("island") == island
        and value.get("mechanism_gate_decision", {}).get("search_version")
        == ISLAND_SEARCH_VERSION
    }
    terminal_rejections.discard("")
    compiled_order = 0
    for _, value in store.iter_kind("compiled_mechanism_candidate"):
        if value.get("campaign_stage_id") != stage_id:
            continue
        candidate = value.get("candidate")
        if not isinstance(candidate, Mapping):
            continue
        if str(candidate.get("island_family", "")) not in expected_families:
            continue
        candidate_id = str(candidate.get("candidate_id", ""))
        if not candidate_id or candidate_id in terminal_rejections:
            continue
        selected[candidate_id] = (
            0,
            compiled_order,
            {
                "candidate": candidate,
                "parent_ids": value.get("parent_ids", ()),
                "operator": value.get("operator", "resumed_mechanism_compilation"),
            },
        )
        compiled_order += 1
    for _, value in store.iter_kind("three_island_candidate_evaluation"):
        if value["island"] != island:
            continue
        recorded_stage = value.get("campaign_stage_id")
        is_current = recorded_stage == stage_id
        is_legacy_round_zero = (
            recorded_stage is None
            and round_index == 0
            and value["candidate"].get("literature_context_id")
            == context.context_id
        )
        if not (is_current or is_legacy_round_zero):
            continue
        candidate_id = str(value["candidate"]["candidate_id"])
        priority = 2 if is_current else 1
        entry = (priority, int(value["evaluation_index"]), value)
        if candidate_id not in selected or entry[:2] > selected[candidate_id][:2]:
            selected[candidate_id] = entry
    ordered = tuple(
        entry[2]
        for entry in sorted(
            selected.values(),
            key=lambda entry: (-entry[0], entry[1]),
        )
    )
    return tuple(
        Proposal(
            program=program_from_dict(value["candidate"]),
            parent_ids=tuple(str(item) for item in value["parent_ids"]),
            operator=str(value["operator"]),
        )
        for value in ordered
    )


def _findings_from_outcome(value: Mapping[str, Any]) -> str:
    best = value["best"]
    evidence = best["discovery_performance"]
    rationale = str(best["candidate"].get("rationale", ""))
    return (
        "Candidate source rationale: %s. Mean episode improvement %.6f; "
        "95%% lower bound %.6f; wins %d, losses %d. Search for equations, "
        "limitations, and mechanisms that explain or overcome this result."
        % (
            rationale,
            float(evidence["mean_improvement"]),
            float(evidence["mean_improvement_ci_lower"]),
            int(evidence["wins"]),
            int(evidence["losses"]),
        )
    )


def _load_completed_round(
    store: ArtifactStore,
    round_index: int,
) -> Optional[Mapping[str, Any]]:
    matches = [
        value
        for _, value in store.iter_kind("discovery_reset_round_completed")
        if int(value["round_index"]) == round_index
        and value.get("program_version") == DISCOVERY_RESET_VERSION
    ]
    if len(matches) > 1:
        raise ValueError("multiple completion artifacts exist for one round")
    return None if not matches else matches[0]


def _active_research_program(
    runtime: GoalGraphRuntime,
    node_id: str,
) -> ResearchProgramContract:
    program_id = runtime.control_plane.active_research_program_ids.get(node_id)
    if program_id is None:
        raise ValueError("goal node has no active research program")
    return runtime.control_plane.research_programs[program_id]


def _ensure_research_program(
    runtime: GoalGraphRuntime,
    store: ArtifactStore,
    node_id: str,
    config: DiscoveryResetConfig,
) -> ResearchProgramContract:
    active_id = runtime.control_plane.active_research_program_ids.get(node_id)
    if active_id is not None:
        return runtime.control_plane.research_programs[active_id]
    existing = tuple(
        program
        for program in runtime.control_plane.research_programs.values()
        if program.node_id == node_id
    )
    if existing:
        raise ValueError(
            "research program is parked; explicit reopening evidence is required"
        )
    program = initial_binpacking_research_program(
        node_id,
        candidate_budget=(
            len(_ISLAND_FAMILIES)
            * config.code_candidates_per_island_per_round
        ),
    )
    runtime.transact("register_research_program", program)
    store.put("research_program_contract", program.as_dict())
    return program


def _mechanism_class(record: Mapping[str, Any]) -> str:
    candidate = record["candidate"]
    fingerprint = candidate.get("mechanism_fingerprint", {})
    text = " ".join(
        str(fingerprint.get(field, ""))
        for field in (
            "decision_topology",
            "intervention_structure",
            "action_coupling",
            "memory",
        )
    ).casefold()
    categories = (
        ("causal_or_option_graph", ("graph", "edge", "node")),
        ("role_or_portfolio_controller", ("role", "portfolio", "coverage")),
        ("expert_or_regime_router", ("router", "expert", "regime")),
        ("reservation_controller", ("reserv", "protected", "option value")),
        ("finite_state_controller", ("finite", "state machine", "counter")),
    )
    for name, markers in categories:
        if any(marker in text for marker in markers):
            return name
    return "other_non_scalar_controller"


def _program_evidence_from_round(
    program: ResearchProgramContract,
    round_report: Mapping[str, Any],
) -> ResearchProgramEvidence:
    outcomes = round_report["outcomes"]

    def belongs_to_program(record: Mapping[str, Any]) -> bool:
        representation_id = record["candidate"].get(
            "representation_contract_id",
            LEGACY_REPRESENTATION_CONTRACT_ID,
        )
        if representation_id == program.representation.representation_id:
            return True
        return (
            program.representation.parent_representation_id is None
            and representation_id == LEGACY_REPRESENTATION_CONTRACT_ID
        )

    records_by_channel = {
        str(island): tuple(
            record
            for record in outcome["evaluated"]
            if record.get("operator") != "carried_elite"
            and belongs_to_program(record)
        )
        for island, outcome in outcomes.items()
    }
    records = tuple(
        record
        for channel_records in records_by_channel.values()
        for record in channel_records
    )
    channel_evaluations = {
        island: len(channel_records)
        for island, channel_records in records_by_channel.items()
    }
    behaviorally_distinct = 0
    semantically_novel = 0
    supported_improvements = 0
    eligible = 0
    mechanism_classes: Counter[str] = Counter()
    failures: Counter[str] = Counter()
    effects = []
    lower_bounds = []
    evidence_ids = []
    for record in records:
        semantic = record.get("semantic_novelty", {})
        comparisons = semantic.get("control_comparisons", {})
        if any(
            not bool(comparison.get("semantically_equivalent", False))
            for comparison in comparisons.values()
        ):
            behaviorally_distinct += 1
        if bool(semantic.get("passed", False)):
            semantically_novel += 1
        for reason in semantic.get("failure_reasons", ()):
            failures[str(reason)] += 1
        diagnostic = record.get("distinguishing_diagnostic", {})
        for reason in diagnostic.get("failure_reasons", ()):
            failures[str(reason)] += 1
        performance = record["discovery_performance"]
        effect = float(performance["mean_improvement"])
        lower = float(performance["mean_improvement_ci_lower"])
        effects.append(effect)
        lower_bounds.append(lower)
        if lower > 0.0:
            supported_improvements += 1
        if bool(record.get("research_eligible", False)):
            eligible += 1
        mechanism_classes[_mechanism_class(record)] += 1
        evidence_ids.append(str(record["candidate"]["candidate_id"]))
    evaluated = len(records)
    return ResearchProgramEvidence(
        program_id=program.program_id,
        representation_id=program.representation.representation_id,
        cycle_index=int(round_report["round_index"]),
        channel_evaluations=channel_evaluations,
        # These are admitted executable research objects. Transport-level
        # rejected drafts are recorded separately and cannot masquerade as
        # evidence against the scientific program.
        proposed_count=evaluated,
        compiled_count=evaluated,
        evaluated_count=evaluated,
        behaviorally_distinct_count=behaviorally_distinct,
        semantically_novel_count=semantically_novel,
        confidence_supported_improvement_count=supported_improvements,
        research_eligible_count=eligible,
        mechanism_class_counts=dict(mechanism_classes),
        failure_counts=dict(failures),
        best_effect=max(effects) if effects else 0.0,
        best_lower_confidence_bound=max(lower_bounds) if lower_bounds else 0.0,
        evidence_ids=tuple(dict.fromkeys(evidence_ids)),
    )


def _diagnosis_for_cycle(
    runtime: GoalGraphRuntime,
    cycle_index: int,
) -> Optional[ResearchProgramDiagnosis]:
    matches = tuple(
        diagnosis
        for diagnoses in runtime.control_plane.research_program_diagnoses.values()
        for diagnosis in diagnoses
        if diagnosis.cycle_index == cycle_index
    )
    if len(matches) > 1:
        raise ValueError("multiple research-program diagnoses exist for one cycle")
    return None if not matches else matches[0]


def _advance_research_strategy(
    *,
    runtime: GoalGraphRuntime,
    store: ArtifactStore,
    program: ResearchProgramContract,
    round_report: Mapping[str, Any],
    config: DiscoveryResetConfig,
) -> ResearchProgramDiagnosis:
    cycle_index = int(round_report["round_index"])
    existing = _diagnosis_for_cycle(runtime, cycle_index)
    if existing is not None:
        if (
            existing.disposition == StrategyDisposition.CHANGE_REPRESENTATION
            and cycle_index < config.search_rounds - 1
            and runtime.control_plane.active_research_program_ids.get(
                program.node_id
            )
            == existing.program_id
        ):
            prior = runtime.control_plane.research_programs[
                existing.program_id
            ]
            proposal = BinPackingRepresentationStrategist().propose_change(
                prior,
                existing,
            )
            runtime.transact("adopt_representation_change", proposal)
            store.put("representation_change_proposal", proposal.as_dict())
            store.put(
                "research_program_contract",
                proposal.revised_program.as_dict(),
            )
        return existing
    evidence = _program_evidence_from_round(program, round_report)
    store.put("research_program_evidence", evidence.as_dict())
    revision_count = sum(
        change.revised_program.node_id == program.node_id
        for change in runtime.control_plane.representation_changes.values()
    )
    diagnosis = diagnose_research_program(
        program,
        evidence,
        ResearchStrategyPolicy(
            minimum_evaluated_candidates=(
                len(_ISLAND_FAMILIES)
                * (
                    config.code_candidates_per_island_per_round
                    if cycle_index == 0
                    else max(
                        1,
                        config.code_candidates_per_island_per_round - 1,
                    )
                )
            ),
            minimum_evaluations_per_channel=(
                config.code_candidates_per_island_per_round
                if cycle_index == 0
                else max(
                    1,
                    config.code_candidates_per_island_per_round - 1,
                )
            ),
            maximum_representation_revisions=(
                config.max_representation_revisions
            ),
        ),
        representation_revision_count=revision_count,
    )
    runtime.transact("record_research_program_diagnosis", diagnosis)
    store.put("research_program_diagnosis", diagnosis.as_dict())
    if (
        diagnosis.disposition == StrategyDisposition.CHANGE_REPRESENTATION
        and cycle_index < config.search_rounds - 1
    ):
        proposal = BinPackingRepresentationStrategist().propose_change(
            program,
            diagnosis,
        )
        runtime.transact("adopt_representation_change", proposal)
        store.put("representation_change_proposal", proposal.as_dict())
        store.put(
            "research_program_contract",
            proposal.revised_program.as_dict(),
        )
    return diagnosis


def _hybrid_parent_material(
    outcomes: Mapping[str, Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    """Bind hybrid compilation to distinct executable source-lane survivors."""

    required = {"funsearch_ancestry", "de_novo"}
    if not required.issubset(outcomes):
        raise ValueError(
            "hybrid compilation started before both source islands completed"
        )
    ancestry = outcomes["funsearch_ancestry"]["best"]
    ancestry_fingerprint = str(ancestry["behavior_fingerprint"])
    de_novo_records = sorted(
        outcomes["de_novo"]["evaluated"],
        key=lambda record: tuple(record["rank"]),
        reverse=True,
    )
    de_novo = next(
        (
            record
            for record in de_novo_records
            if bool(record.get("discovery_admitted", False))
            if str(record["behavior_fingerprint"]) != ancestry_fingerprint
        ),
        None,
    )
    if de_novo is None:
        raise ValueError(
            "hybrid compilation requires an objective-improving, behaviorally "
            "distinct de-novo parent; stop and revise the first-principles "
            "derivation instead of hybridizing a failed idea"
        )
    parents = []
    for family, best in (
        ("ancestry", ancestry),
        ("de_novo", de_novo),
    ):
        parents.append(
            {
                "family": family,
                "candidate": dict(best["candidate"]),
                "discovery_performance": dict(
                    best["discovery_performance"]
                ),
                "mechanism_distance": dict(
                    best["discovery_assessment"]["mechanism_distance"]
                ),
                "deployment_safe": bool(best["deployment_safe"]),
            }
        )
    return tuple(parents)


def _active_campaign(runtime: GoalGraphRuntime, leaf_id: str):
    campaign_id = runtime.control_plane.active_campaign_ids.get(leaf_id)
    if campaign_id is None:
        raise ValueError("discovery reset requires an active goal-graph campaign")
    return runtime.control_plane.campaigns[campaign_id]


def _authority_candidate_index(
    runtime: GoalGraphRuntime,
    store: ArtifactStore,
    leaf_id: str,
) -> AuthorityCandidateIndex:
    index: AuthorityCandidateIndex = {}
    for proposal_id, proposal in _active_campaign(
        runtime, leaf_id
    ).proposals.items():
        envelope = store.get(proposal.executable_digest)
        value = envelope.get("value", {})
        domain_id = value.get("candidate_id") if isinstance(value, dict) else None
        if domain_id:
            index[(
                str(domain_id),
                proposal.round_index,
                proposal.family,
            )] = proposal_id
    return index


def _latest_authority_proposal(
    candidate_index: AuthorityCandidateIndex,
    domain_candidate_id: str,
    *,
    family: Optional[SearchFamily] = None,
) -> Optional[str]:
    matches = (
        (round_index, indexed_family.value, proposal_id)
        for (
            indexed_domain_id,
            round_index,
            indexed_family,
        ), proposal_id in candidate_index.items()
        if indexed_domain_id == domain_candidate_id
        and (family is None or indexed_family == family)
    )
    try:
        return max(matches)[2]
    except ValueError:
        return None


def _register_authoritative_outcome(
    *,
    runtime: GoalGraphRuntime,
    store: ArtifactStore,
    adapter: BinPackingAdapter,
    leaf_id: str,
    outcome: Mapping[str, Any],
    round_index: int,
    candidate_index: AuthorityCandidateIndex,
    current_family_best: Mapping[SearchFamily, str],
) -> str:
    island = str(outcome["config"]["island"])
    family = _SEARCH_FAMILY_BY_ISLAND[island]
    incumbent_id = _active_campaign(
        runtime, leaf_id
    ).portfolio.primary_incumbent_id
    best_domain_id = str(outcome["best_candidate_id"])
    best_proposal_id = candidate_index.get(
        (best_domain_id, round_index, family),
        "",
    )
    for item in outcome["evaluated"]:
        program = program_from_dict(item["candidate"])
        domain_id = program.candidate_id
        existing = candidate_index.get((domain_id, round_index, family))
        if existing is not None:
            if domain_id == best_domain_id:
                best_proposal_id = existing
            continue
        parent_ids = tuple(
            proposal_id
            for parent_id in item.get("parent_ids", ())
            for proposal_id in (
                _latest_authority_proposal(
                    candidate_index,
                    str(parent_id),
                    family=(
                        None
                        if family == SearchFamily.HYBRID
                        else family
                    ),
                ),
            )
            if proposal_id is not None
        )
        if family == SearchFamily.ANCESTRY and not parent_ids:
            parent_ids = (incumbent_id,)
        if family == SearchFamily.HYBRID:
            cross_parents = tuple(
                current_family_best[parent_family]
                for parent_family in (
                    SearchFamily.ANCESTRY,
                    SearchFamily.DE_NOVO,
                )
                if parent_family in current_family_best
            )
            parent_ids = tuple(dict.fromkeys((*parent_ids, *cross_parents)))
        executable_digest = store.put(
            "domain_candidate",
            dict(adapter.candidate_as_dict(program)),
        )
        rendered = str(item["candidate"].get("rendered", program.name))
        proposal = IslandCandidateProposal(
            node_id=leaf_id,
            family=family,
            executable_digest=executable_digest,
            mechanism_summary="%s: %s"
            % (str(item.get("operator", "code_model_generation")), rendered),
            ancestry_ids=parent_ids,
            proposer_ref=str(outcome["proposer"]),
            round_index=round_index,
            exposed_information=default_information_views()[family],
            literature_context_id=(
                None
                if outcome.get("literature_context_id") is None
                else str(outcome["literature_context_id"])
            ),
            literature_evidence_ids=tuple(
                str(value)
                for value in outcome.get("literature_evidence_ids", ())
            ),
        )
        runtime.transact("submit_candidate", proposal)
        candidate_index[(domain_id, round_index, family)] = (
            proposal.candidate_id
        )
        if domain_id == best_domain_id:
            best_proposal_id = proposal.candidate_id
    if not best_proposal_id:
        raise ValueError("discovery outcome did not register its best candidate")
    return best_proposal_id


def _proposal_ids_for_domain_candidate(
    runtime: GoalGraphRuntime,
    store: ArtifactStore,
    leaf_id: str,
    domain_candidate_id: str,
) -> Tuple[str, ...]:
    matches = []
    for proposal_id, proposal in _active_campaign(
        runtime, leaf_id
    ).proposals.items():
        value = store.get(proposal.executable_digest).get("value", {})
        if (
            isinstance(value, dict)
            and str(value.get("candidate_id", "")) == domain_candidate_id
        ):
            matches.append(proposal_id)
    return tuple(matches)


def _candidate_for_authority_proposal(
    *,
    runtime: GoalGraphRuntime,
    store: ArtifactStore,
    leaf_id: str,
    proposal_id: str,
) -> OnlineHeuristic:
    proposal = _active_campaign(runtime, leaf_id).proposals[proposal_id]
    value = store.get(proposal.executable_digest).get("value", {})
    if not isinstance(value, dict):
        raise ValueError("goal-graph candidate artifact is malformed")
    if value.get("program_kind") == "distilled_stochastic_value_policy":
        candidate: OnlineHeuristic = DistilledStochasticValuePolicy(
            LinearValueModel.from_dict(value["value_model"]),
            name=str(value["name"]),
        )
    else:
        candidate = program_from_dict(value)
    if str(value.get("candidate_id", "")) != getattr(
        candidate, "candidate_id", candidate.name
    ):
        raise ValueError("goal-graph candidate artifact identity mismatch")
    return candidate


def _register_value_candidate(
    *,
    runtime: GoalGraphRuntime,
    store: ArtifactStore,
    adapter: BinPackingAdapter,
    leaf_id: str,
    candidate: DistilledStochasticValuePolicy,
    round_index: int,
    candidate_index: AuthorityCandidateIndex,
) -> str:
    key = (candidate.candidate_id, round_index, SearchFamily.ANCESTRY)
    existing = candidate_index.get(key)
    if existing is not None:
        return existing
    campaign = _active_campaign(runtime, leaf_id)
    proposal = IslandCandidateProposal(
        node_id=leaf_id,
        family=SearchFamily.ANCESTRY,
        executable_digest=store.put(
            "domain_candidate", dict(adapter.candidate_as_dict(candidate))
        ),
        mechanism_summary=(
            "independently sampled suffix state-action value policy"
        ),
        ancestry_ids=(campaign.portfolio.primary_incumbent_id,),
        proposer_ref="iid-or-suffix-value-learner-v1",
        round_index=round_index,
        exposed_information=(
            InformationChannel.PROBLEM_CONTRACT,
            InformationChannel.INCUMBENT_CODE,
        ),
    )
    runtime.transact("submit_candidate", proposal)
    candidate_index[key] = proposal.candidate_id
    return proposal.candidate_id


def _record_authoritative_batch(
    *,
    runtime: GoalGraphRuntime,
    adapter: BinPackingAdapter,
    leaf_id: str,
    proposal_id: str,
    candidate: OnlineHeuristic,
    incumbent: OnlineHeuristic,
    experiments: Sequence[BinPackingInstance],
    partition: EvidencePartition,
):
    campaign = _active_campaign(runtime, leaf_id)
    existing = tuple(
        record
        for record in campaign.verifications.get(proposal_id, ())
        if record.partition == partition
    )
    if existing:
        record = existing[-1]
        return record, campaign.gate_decisions[record.verification_id]
    gate = next(
        item
        for item in campaign.contract.gates
        if item.evidence_partition == partition
    )
    return runtime.evaluate_and_record_batch(
        adapter=adapter,
        node_id=leaf_id,
        candidate_id=proposal_id,
        candidate=candidate,
        incumbent=incumbent,
        experiments=experiments,
        partition=partition,
        gate_contract_id=gate.contract_id,
    )


def _complete_authoritative_rounds(
    *,
    runtime: GoalGraphRuntime,
    leaf_id: str,
    completed_round_count: int,
) -> None:
    campaign = _active_campaign(runtime, leaf_id)
    if not 0 <= completed_round_count <= campaign.contract.max_rounds:
        raise ValueError("authoritative completed-round count is out of bounds")
    while len(campaign.rounds) < completed_round_count:
        round_index = len(campaign.rounds)
        proposals = tuple(
            proposal
            for proposal in campaign.proposals.values()
            if proposal.round_index == round_index
        )
        attempts = {
            family: sum(proposal.family == family for proposal in proposals)
            for family in campaign.contract.search_families
        }
        ancestries = {
            family: len(
                {
                    proposal.ancestry_ids or (proposal.candidate_id,)
                    for proposal in proposals
                    if proposal.family == family
                }
            )
            for family in campaign.contract.search_families
        }
        effects = tuple(
            verification.effect_size
            for proposal in proposals
            for verification in campaign.verifications.get(
                proposal.candidate_id, ()
            )
        )
        if proposals and not effects:
            raise ValueError(
                "goal-graph round has candidates but no authoritative evidence"
            )
        runtime.transact(
            "complete_campaign_round",
            CampaignRoundSummary(
                node_id=leaf_id,
                round_index=round_index,
                attempts_by_family=attempts,
                distinct_ancestries_by_family=ancestries,
                best_verified_effect=max(effects) if effects else 0.0,
                confidence_sufficient=any(effect > 0.0 for effect in effects),
                failure_signature=(
                    "confidence_supported_episode_effect"
                    if any(effect > 0.0 for effect in effects)
                    else "no_confidence_supported_episode_effect"
                ),
                compute_spent=float(sum(attempts.values())),
                budget_complete=bool(proposals),
            ),
        )
        campaign = runtime.control_plane.campaigns[campaign.contract.campaign_id]


def run_discovery_reset(
    *,
    checkpoint_path: Path,
    artifact_root: Path,
    orlib_root: Path,
    config: Optional[DiscoveryResetConfig] = None,
    code_backend: Optional[CodeModelBackend] = None,
    literature_reviewer: Optional[LiteratureReviewer] = None,
    resume: bool = False,
    on_conformance_passed: Optional[Callable[[], None]] = None,
) -> Mapping[str, Any]:
    """Run or resume one isolated reset campaign after exact conformance."""

    config = config or DiscoveryResetConfig()
    if not config.production_evidence_contract_passed:
        raise ValueError(
            "scientific discovery requires the production episode-evidence contract"
        )
    checkpoint_path = Path(checkpoint_path)
    artifact_root = Path(artifact_root)
    if resume:
        if not checkpoint_path.exists():
            raise ValueError("resume requires an existing checkpoint")
        if not artifact_root.exists():
            raise ValueError("resume requires an existing artifact root")
    else:
        if checkpoint_path.exists():
            raise ValueError("checkpoint already exists; refusing to overwrite")
        if _artifact_root_contains_material(artifact_root):
            raise ValueError("artifact root is not empty; clean discovery is required")

    # Nothing adaptive—not even literature retrieval or graph campaign setup—may
    # execute before exact evaluator and trace conformance succeeds.
    conformance = verify_funsearch_benchmark_conformance(orlib_root)
    conformance.require_passed()
    if on_conformance_passed is not None:
        on_conformance_passed()

    store = ArtifactStore(artifact_root)
    conformance_digest = store.put(
        "binpacking_funsearch_benchmark_conformance",
        conformance.as_dict(),
    )
    graph_config = BinPackingGoalRunConfig(
        rounds=config.search_rounds,
        candidate_budget_per_island=config.code_candidates_per_island_per_round,
        initial_random_candidates=config.initial_code_candidates,
        audit_cases_per_length=config.discovery_audit_episodes_per_length,
        replication_cases_per_length=config.replication_episodes_per_length,
        validation_lengths=config.value.training_lengths,
        capacity=config.value.capacity,
        # The reset runner performs four explicit live surveys below. The
        # legacy graph bootstrap receives static charter literature only so it
        # cannot issue duplicate, pre-island web queries.
        require_web_literature=False,
        isolation_rounds=0,
    )
    adapter = BinPackingAdapter()
    if resume:
        runtime = GoalGraphRuntime.from_checkpoint(
            checkpoint_path,
            artifact_store=store,
        )
        _, _, leaf = goal_nodes(runtime.control_plane.goal, graph_config)
    else:
        control = build_control_plane(graph_config, artifact_store=store)
        runtime = GoalGraphRuntime(
            control,
            checkpoint_path,
            artifact_store=store,
        )
        graph_program = BinPackingGoalProgram(
            runtime,
            store,
            graph_config,
            orlib_root=orlib_root,
        )
        _, _, leaf, _ = graph_program._bootstrap()
    authority_candidate_ids = _authority_candidate_index(
        runtime, store, leaf.node_id
    )
    authority_family_best: Dict[SearchFamily, str] = {}
    _ensure_research_program(runtime, store, leaf.node_id, config)

    reviewer = literature_reviewer or default_live_web_reviewer(
        store,
        timeout_seconds=config.literature_timeout_seconds,
        results_per_query=config.literature_results_per_query,
    )
    backend = code_backend or OpenAIResponsesCodeModel()
    ancestry = literature_heuristics()["funsearch_or_reference"]
    repair_suite = iid_or_episode_suite(
        config.value,
        partition="adaptive-repair",
        episodes_per_length=config.screen_episodes_per_length,
        seed_offset=100_000_000,
    )
    guard_suite = iid_or_episode_suite(
        config.value,
        partition="adaptive-guard",
        episodes_per_length=config.screen_episodes_per_length,
        seed_offset=200_000_000,
    )
    discovery_suite = iid_or_episode_suite(
        config.value,
        partition="untouched-discovery-audit",
        episodes_per_length=config.discovery_audit_episodes_per_length,
        seed_offset=300_000_000,
    )

    # Complete all four initial live surveys before either discovery branch
    # starts. A resume consumes only durable artifacts from this same root.
    initial_checkpoint = _load_context_checkpoint(store, 0) if resume else None
    if initial_checkpoint is not None:
        assessment_ids, contexts = initial_checkpoint
    elif resume:
        contexts = _load_legacy_initial_contexts(store)
        assessment_ids = {
            family: context.assessment_id
            for family, context in contexts.items()
        }
        store.put(
            "discovery_reset_literature_round",
            _context_checkpoint_value(0, contexts),
        )
    else:
        assessments, contexts = _review_contexts(
            reviewer,
            leaf,
            {},
            0,
            store,
            runtime,
        )
        assessment_ids = {
            family: assessment.assessment_id
            for family, assessment in assessments.items()
        }
        store.put(
            "discovery_reset_literature_round",
            _context_checkpoint_value(0, contexts),
        )

    value_policy = None
    if resume:
        value_artifacts = list(store.iter_kind("iid_or_suffix_value_training"))
        if len(value_artifacts) != 1:
            raise ValueError("resume requires exactly one completed value stage")
        value_digest, value_dict = value_artifacts[0]
        distilled = value_dict.get("distilled_policy")
        if distilled is not None:
            value_policy = DistilledStochasticValuePolicy(
                LinearValueModel.from_dict(distilled["value_model"]),
                name=str(distilled["name"]),
            )
            if value_policy.candidate_id != distilled["candidate_id"]:
                raise ValueError("distilled value-policy identity mismatch")
    else:
        value_result = train_stochastic_suffix_value(config.value, ancestry)
        value_dict = value_result.as_dict()
        value_policy = value_result.distilled_policy
        value_digest = store.put(
            "iid_or_suffix_value_training",
            value_dict,
        )
    findings_by_family: Dict[str, str] = {}
    carried: Dict[str, Tuple[Any, ...]] = {
        island: () for island in _ISLAND_FAMILIES
    }
    round_reports = []
    strategy_diagnoses = []
    park_diagnosis: Optional[ResearchProgramDiagnosis] = None
    all_finalists = []
    for round_index in range(config.search_rounds):
        research_program = _active_research_program(runtime, leaf.node_id)
        completed_round = _load_completed_round(store, round_index)
        if completed_round is not None:
            round_report = completed_round["round_report"]
            round_reports.append(round_report)
            findings_by_family = {
                family: str(finding)
                for family, finding in completed_round[
                    "findings_by_family_after_round"
                ].items()
            }
            for island in _ISLAND_FAMILIES:
                completed_outcome = round_report["outcomes"][island]
                best_program = program_from_dict(
                    completed_outcome["best"]["candidate"]
                )
                carried[island] = (best_program,)
                all_finalists.append(best_program)
                search_family = _SEARCH_FAMILY_BY_ISLAND[island]
                authority_family_best[search_family] = (
                    _register_authoritative_outcome(
                        runtime=runtime,
                        store=store,
                        adapter=adapter,
                        leaf_id=leaf.node_id,
                        outcome=completed_outcome,
                        round_index=round_index,
                        candidate_index=authority_candidate_ids,
                        current_family_best=authority_family_best,
                    )
                )
            diagnosis = _advance_research_strategy(
                runtime=runtime,
                store=store,
                program=research_program,
                round_report=round_report,
                config=config,
            )
            strategy_diagnoses.append(diagnosis.as_dict())
            if diagnosis.disposition == StrategyDisposition.PARK:
                park_diagnosis = diagnosis
                break
            continue
        if round_index > 0:
            context_checkpoint = _load_context_checkpoint(store, round_index)
            if context_checkpoint is not None:
                assessment_ids, contexts = context_checkpoint
            else:
                assessments, contexts = _review_contexts(
                    reviewer,
                    leaf,
                    findings_by_family,
                    round_index,
                    store,
                    runtime,
                )
                assessment_ids = {
                    family: assessment.assessment_id
                    for family, assessment in assessments.items()
                }
                store.put(
                    "discovery_reset_literature_round",
                    _context_checkpoint_value(round_index, contexts),
                )
        outcome_dicts = {}
        next_findings = {}
        for island, family in _ISLAND_FAMILIES.items():
            stage_id = _stage_id(
                config,
                round_index,
                island,
                contexts[family],
                representation_id=(
                    None
                    if research_program.representation.parent_representation_id
                    is None
                    else research_program.representation.representation_id
                ),
            )
            outcome_dict = _load_completed_island(store, stage_id)
            if outcome_dict is not None:
                outcome_dicts[island] = outcome_dict
                best_program = program_from_dict(
                    outcome_dict["best"]["candidate"]
                )
                carried[island] = (best_program,)
                all_finalists.append(best_program)
                next_findings[family] = _findings_from_outcome(outcome_dict)
            else:
                resumed_proposals = _load_resumed_proposals(
                    store,
                    stage_id=stage_id,
                    island=island,
                    context=contexts[family],
                    round_index=round_index,
                )
                proposer = MechanismCodeProposer(
                    backend,
                    contexts[family],
                    island_family=family,
                    target_node_id=leaf.node_id,
                    cross_domain_context=contexts["cross_domain"],
                    hybrid_parent_material=(
                        _hybrid_parent_material(outcome_dicts)
                        if island == "hybrid"
                        else ()
                    ),
                    experimental_findings=str(
                        findings_by_family.get(family, "")
                    ),
                    batch_size=config.code_batch_size,
                    artifact_store=store,
                    campaign_stage_id=stage_id,
                    existing_proposals=resumed_proposals,
                    research_program=research_program,
                    baseline_policy_ref=(
                        ancestry.name if family == "ancestry" else None
                    ),
                )
                minimum_distance = (
                    2 if family in {"hybrid", "cross_domain"} else 0
                )
                outcome = run_island_search(
                    IslandSearchConfig(
                        island=island,
                        seed=(
                            config.value.base_seed
                            + round_index * 101
                            + len(outcome_dicts)
                        ),
                        evaluation_budget=(
                            config.code_candidates_per_island_per_round
                        ),
                        initial_random=config.initial_code_candidates,
                        episode_confidence_discovery=True,
                        exploration_lane=True,
                        minimum_mechanism_distance=minimum_distance,
                        require_incumbent_blind=False,
                        require_new_decision_primitive=(
                            family == "hybrid"
                        ),
                        require_mechanism_gate=True,
                        minimum_known_control_action_distance=(
                            0.001
                        ),
                        max_candidates_per_mechanism_cluster=(
                            0
                        ),
                        max_consecutive_candidate_rejections=(
                            max(8, config.initial_code_candidates * 2)
                        ),
                    ),
                    repair_suite,
                    guard_suite,
                    ancestry,
                    carried_programs=carried[island],
                    proposer=proposer,
                    literature_context=contexts[family],
                    artifact_store=store,
                    resumed_proposals=resumed_proposals,
                    campaign_stage_id=stage_id,
                )
                outcome_dict = outcome.as_dict()
                store.put(
                    "discovery_reset_island_completed",
                    {
                        "program_version": DISCOVERY_RESET_VERSION,
                        "campaign_stage_id": stage_id,
                        "round_index": round_index,
                        "island": island,
                        "family": family,
                        "literature_context_id": contexts[family].context_id,
                        "research_program_id": research_program.program_id,
                        "representation_id": (
                            research_program.representation.representation_id
                        ),
                        "outcome": outcome_dict,
                    },
                )
                outcome_dicts[island] = outcome_dict
                carried[island] = (outcome.best.program,)
                all_finalists.append(outcome.best.program)
                next_findings[family] = _findings(outcome)
            search_family = _SEARCH_FAMILY_BY_ISLAND[island]
            authority_family_best[search_family] = (
                _register_authoritative_outcome(
                    runtime=runtime,
                    store=store,
                    adapter=adapter,
                    leaf_id=leaf.node_id,
                    outcome=outcome_dict,
                    round_index=round_index,
                    candidate_index=authority_candidate_ids,
                    current_family_best=authority_family_best,
                )
            )
        findings_by_family = {
            **next_findings,
            "cross_domain": " ".join(next_findings.values()),
        }
        round_report = {
            "round_index": round_index,
            "research_program_id": research_program.program_id,
            "representation_id": (
                research_program.representation.representation_id
            ),
            "literature_assessment_ids": dict(assessment_ids),
            "literature_context_ids": {
                family: context.context_id
                for family, context in contexts.items()
            },
            "outcomes": outcome_dicts,
            "experiment_findings_fed_to_next_literature_round": (
                round_index < config.search_rounds - 1
            ),
        }
        round_reports.append(round_report)
        store.put(
            "discovery_reset_round_completed",
            {
                "program_version": DISCOVERY_RESET_VERSION,
                "round_index": round_index,
                "round_report": round_report,
                "findings_by_family_after_round": findings_by_family,
            },
        )
        diagnosis = _advance_research_strategy(
            runtime=runtime,
            store=store,
            program=research_program,
            round_report=round_report,
            config=config,
        )
        strategy_diagnoses.append(diagnosis.as_dict())
        if diagnosis.disposition == StrategyDisposition.PARK:
            park_diagnosis = diagnosis
            break

    candidates = list(all_finalists)
    if value_policy is not None:
        candidates.append(value_policy)
    unique_candidates = {
        getattr(candidate, "candidate_id", candidate.name): candidate
        for candidate in candidates
    }
    if value_policy is not None:
        _register_value_candidate(
            runtime=runtime,
            store=store,
            adapter=adapter,
            leaf_id=leaf.node_id,
            candidate=value_policy,
            round_index=max(0, len(round_reports) - 1),
            candidate_index=authority_candidate_ids,
        )
    audits = tuple(
        _candidate_performance(
            candidate,
            ancestry,
            discovery_suite,
            minimum_episodes=config.discovery_episode_count,
        )
        for candidate in unique_candidates.values()
    )
    for audit in audits:
        store.put("discovery_reset_candidate_audit", audit)
        domain_candidate_id = str(audit["candidate_id"])
        candidate = unique_candidates[domain_candidate_id]
        proposal_ids = _proposal_ids_for_domain_candidate(
            runtime,
            store,
            leaf.node_id,
            domain_candidate_id,
        )
        if not proposal_ids:
            raise ValueError("audited candidate is absent from the goal graph")
        for proposal_id in proposal_ids:
            authority_candidate = _candidate_for_authority_proposal(
                runtime=runtime,
                store=store,
                leaf_id=leaf.node_id,
                proposal_id=proposal_id,
            )
            _, authority_decision = _record_authoritative_batch(
                runtime=runtime,
                adapter=adapter,
                leaf_id=leaf.node_id,
                proposal_id=proposal_id,
                candidate=authority_candidate,
                incumbent=ancestry,
                experiments=discovery_suite,
                partition=EvidencePartition.AUDIT,
            )
            if authority_decision.passed != bool(audit["discovery_passed"]):
                raise ValueError(
                    "goal-graph audit decision disagrees with reset qualification"
                )
    qualified = tuple(audit for audit in audits if audit["discovery_passed"])
    selected_audit = max(qualified, key=lambda item: item["rank"]) if qualified else None
    selected = (
        None
        if selected_audit is None
        else unique_candidates[str(selected_audit["candidate_id"])]
    )

    replication_manifest = {
        "status": "sealed_unopened" if selected is None else "opened_once",
        "episode_count": config.replication_episode_count,
        "seed_commitment": content_digest(
            {
                "base_seed": config.value.base_seed,
                "offset": 700_000_000,
                "lengths": list(config.value.training_lengths),
                "episodes_per_length": config.replication_episodes_per_length,
            }
        ),
    }
    replication = None
    causal_analysis: Mapping[str, Any] = {
        "status": "deferred_until_statistically_supported_episode_effect",
        "used_for_initial_hypothesis_generation": False,
    }
    if selected is not None:
        replication_suite = iid_or_episode_suite(
            config.value,
            partition="untouched-replication",
            episodes_per_length=config.replication_episodes_per_length,
            seed_offset=700_000_000,
        )
        replication = _candidate_performance(
            selected,
            ancestry,
            replication_suite,
            minimum_episodes=config.replication_episode_count,
        )
        store.put("discovery_reset_untouched_replication", replication)
        selected_proposal_id = _latest_authority_proposal(
            authority_candidate_ids,
            str(replication["candidate_id"]),
        )
        if selected_proposal_id is None:
            raise ValueError(
                "replication candidate is absent from the goal graph"
            )
        authority_selected = _candidate_for_authority_proposal(
            runtime=runtime,
            store=store,
            leaf_id=leaf.node_id,
            proposal_id=selected_proposal_id,
        )
        _, replication_decision = _record_authoritative_batch(
            runtime=runtime,
            adapter=adapter,
            leaf_id=leaf.node_id,
            proposal_id=selected_proposal_id,
            candidate=authority_selected,
            incumbent=ancestry,
            experiments=replication_suite,
            partition=EvidencePartition.REPLICATION,
        )
        if replication_decision.passed != bool(
            replication["discovery_passed"]
        ):
            raise ValueError(
                "goal-graph replication decision disagrees with reset qualification"
            )
        if replication_decision.passed:
            runtime.transact(
                "nominate_local_candidate",
                leaf.node_id,
                selected_proposal_id,
            )
        if replication["discovery_passed"]:
            causal_analysis = _post_effect_causal_analysis(
                selected,
                ancestry,
                replication_suite,
            )
            store.put("discovery_reset_post_effect_causal_analysis", causal_analysis)

    _complete_authoritative_rounds(
        runtime=runtime,
        leaf_id=leaf.node_id,
        completed_round_count=len(round_reports),
    )
    if (
        park_diagnosis is not None
        and not (
            replication is not None
            and replication["discovery_passed"]
        )
        and leaf.node_id
        in runtime.control_plane.active_research_program_ids
    ):
        runtime.transact(
            "park_research_program",
            leaf.node_id,
            park_diagnosis.diagnosis_id,
        )

    program_parked = (
        park_diagnosis is not None
        and not (
            replication is not None
            and replication["discovery_passed"]
        )
        and leaf.node_id
        not in runtime.control_plane.active_research_program_ids
    )
    result = {
        "program_version": DISCOVERY_RESET_VERSION,
        "research_goal": RESEARCH_GOAL,
        "config": config.as_dict(),
        "benchmark_conformance": conformance.as_dict(),
        "benchmark_conformance_digest": conformance_digest,
        "goal_graph_checkpoint": str(checkpoint_path.resolve()),
        "goal_graph_status": runtime.status(),
        "discovery_order": (
            "benchmark_conformance",
            "live_literature_source_packets",
            "iid_suffix_state_action_value",
            "causal_mechanism_hypotheses",
            "candidate_specific_prior_art_binding",
            "typed_mechanism_compilation",
            "episode_level_discovery_audit",
            "untouched_replication",
            "post_effect_causal_analysis",
        ),
        "value_training_digest": value_digest,
        "value_training": value_dict,
        "search_rounds": round_reports,
        "research_strategy": {
            "diagnoses": strategy_diagnoses,
            "representation_changes": [
                proposal.as_dict()
                for proposal in (
                    runtime.control_plane.representation_changes.values()
                )
                if proposal.revised_program.node_id == leaf.node_id
            ],
            "parked": program_parked,
            "park_diagnosis_id": (
                None
                if not program_parked
                else park_diagnosis.diagnosis_id
            ),
        },
        "all_hypotheses_tried": [
            record
            for round_report in round_reports
            for outcome in round_report["outcomes"].values()
            for record in outcome["evaluated"]
        ],
        "candidate_audits": list(audits),
        "selected_candidate": (
            None if selected is None else dict(selected.as_dict())
        ),
        "replication_manifest": replication_manifest,
        "replication": replication,
        "causal_analysis": causal_analysis,
        "performance_and_safety_are_separate": True,
        "outcome": (
            "replicated_episode_effect"
            if replication is not None and replication["discovery_passed"]
            else (
                "research_program_parked"
                if program_parked
                else "no_replicated_episode_effect"
            )
        ),
    }
    summary_digest = store.put("binpacking_discovery_reset_summary", result)
    manifest_id = "binpacking-discovery-reset-" + summary_digest[:24]
    manifest = store.write_manifest(
        manifest_id,
        {
            "schema": 1,
            "kind": "binpacking_discovery_reset_run",
            "program_version": DISCOVERY_RESET_VERSION,
            "research_goal": RESEARCH_GOAL,
            "summary_digest": summary_digest,
            "benchmark_conformance_digest": conformance_digest,
            "outcome": result["outcome"],
        },
    )
    return {
        **result,
        "summary_digest": summary_digest,
        "manifest": str(manifest.resolve()),
    }
