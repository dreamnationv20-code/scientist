from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance


BEHAVIOUR_FINGERPRINT_SCHEMA = 1


@dataclass(frozen=True)
class DirectActionComparison:
    """Compare policies on the same states while the left policy drives."""

    left_id: str
    right_id: str
    decision_count: int
    disagreements: int
    affected_cases: int

    @property
    def disagreement_rate(self) -> float:
        return (
            self.disagreements / float(self.decision_count)
            if self.decision_count
            else 0.0
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "left_id": self.left_id,
            "right_id": self.right_id,
            "decision_count": self.decision_count,
            "disagreements": self.disagreements,
            "disagreement_rate": self.disagreement_rate,
            "affected_cases": self.affected_cases,
        }


def _heuristic_id(heuristic: OnlineHeuristic) -> str:
    candidate_id = getattr(heuristic, "candidate_id", None)
    return str(candidate_id or heuristic.name)


def direct_action_comparison(
    left: OnlineHeuristic,
    right: OnlineHeuristic,
    instances: Iterable[BinPackingInstance],
) -> DirectActionComparison:
    """Measure intervention without counting downstream trajectory cascades."""

    decision_count = 0
    disagreements = 0
    affected_cases = 0
    for instance in instances:
        loads = []
        history = []
        case_disagreed = False
        for item_index, item in enumerate(instance.items):
            state_loads: Sequence[int] = tuple(loads)
            state_history: Sequence[int] = tuple(history)
            left_action = left.choose_bin(
                item,
                state_loads,
                instance.capacity,
                item_index,
                state_history,
            )
            right_action = right.choose_bin(
                item,
                state_loads,
                instance.capacity,
                item_index,
                state_history,
            )
            decision_count += 1
            if left_action != right_action:
                disagreements += 1
                case_disagreed = True
            if left_action is None:
                loads.append(item)
            else:
                if (
                    left_action < 0
                    or left_action >= len(loads)
                    or loads[left_action] + item > instance.capacity
                ):
                    raise ValueError(
                        "%s selected an invalid action during comparison"
                        % left.name
                    )
                loads[left_action] += item
            history.append(item)
        if case_disagreed:
            affected_cases += 1
    return DirectActionComparison(
        left_id=_heuristic_id(left),
        right_id=_heuristic_id(right),
        decision_count=decision_count,
        disagreements=disagreements,
        affected_cases=affected_cases,
    )


def behaviour_trace(
    heuristic: OnlineHeuristic,
    instances: Iterable[BinPackingInstance],
) -> Tuple[Dict[str, Any], ...]:
    """Return the policy's observable decisions on a fixed probe suite."""
    traces = []
    for instance in instances:
        result = pack(instance, heuristic)
        traces.append(
            {
                "instance_id": instance.instance_id,
                "placements": [
                    placement.bin_index for placement in result.placements
                ],
                "bin_count": result.bin_count,
            }
        )
    return tuple(traces)


def behaviour_fingerprint(
    heuristic: OnlineHeuristic,
    instances: Iterable[BinPackingInstance],
) -> str:
    """Hash observable decisions, not program syntax or heuristic name."""
    return content_digest(
        {
            "schema": BEHAVIOUR_FINGERPRINT_SCHEMA,
            "traces": behaviour_trace(heuristic, instances),
        }
    )


def equivalent_on_suite(
    left: OnlineHeuristic,
    right: OnlineHeuristic,
    instances: Iterable[BinPackingInstance],
) -> bool:
    instance_tuple = tuple(instances)
    return (
        behaviour_fingerprint(left, instance_tuple)
        == behaviour_fingerprint(right, instance_tuple)
    )
