from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from scientist.domains.binpacking.exact import optimal_bin_count
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance


EVALUATOR_VERSION = "binpacking-evaluator-v2"
REFERENCE_MODES = ("exact", "volume_lower_bound")


def _quantile(values: Sequence[float], probability: float) -> float:
    if not values:
        raise ValueError("cannot calculate a quantile of no values")
    ordered = sorted(values)
    position = probability * (len(ordered) - 1)
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return float(ordered[lower])
    fraction = position - lower
    return float(ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction)


@dataclass(frozen=True)
class EvaluationReport:
    evaluator_version: str
    reference_kind: str
    heuristic: str
    instance_count: int
    mean_bins: float
    mean_regret: float
    p95_regret: float
    worst_regret: int
    family_mean_regret: Mapping[str, float]
    observations: Sequence[Mapping[str, Any]]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "evaluator_version": self.evaluator_version,
            "reference_kind": self.reference_kind,
            "heuristic": self.heuristic,
            "instance_count": self.instance_count,
            "mean_bins": self.mean_bins,
            "mean_regret": self.mean_regret,
            "p95_regret": self.p95_regret,
            "worst_regret": self.worst_regret,
            "family_mean_regret": dict(self.family_mean_regret),
            "observations": list(self.observations),
        }


def evaluate_heuristic(
    heuristic: OnlineHeuristic,
    instances: Iterable[BinPackingInstance],
    optima: Optional[Mapping[str, int]] = None,
    reference_mode: str = "exact",
    include_placements: bool = True,
) -> EvaluationReport:
    if reference_mode not in REFERENCE_MODES:
        raise ValueError("unknown reference mode: %s" % reference_mode)
    observations: List[Mapping[str, Any]] = []
    by_family: Dict[str, List[float]] = {}

    for instance in instances:
        result = pack(instance, heuristic)
        reference = (
            optima[instance.instance_id]
            if optima is not None
            else (
                optimal_bin_count(instance.items, instance.capacity)
                if reference_mode == "exact"
                else int(math.ceil(
                    sum(instance.items) / float(instance.capacity)
                ))
            )
        )
        regret = result.bin_count - reference
        if regret < 0:
            raise AssertionError("online result cannot beat its lower reference")
        observation = {
            "instance_id": instance.instance_id,
            "family": instance.family,
            "seed": instance.seed,
            "bin_count": result.bin_count,
            "reference": reference,
            "reference_kind": reference_mode,
            "optimum": reference if reference_mode == "exact" else None,
            "regret": regret,
            "placements": (
                [
                    placement.as_dict()
                    for placement in result.placements
                ]
                if include_placements
                else None
            ),
        }
        observations.append(observation)
        by_family.setdefault(instance.family, []).append(float(regret))

    if not observations:
        raise ValueError("at least one instance is required")

    regrets = [float(observation["regret"]) for observation in observations]
    bin_counts = [float(observation["bin_count"]) for observation in observations]
    return EvaluationReport(
        evaluator_version=EVALUATOR_VERSION,
        reference_kind=reference_mode,
        heuristic=heuristic.name,
        instance_count=len(observations),
        mean_bins=mean(bin_counts),
        mean_regret=mean(regrets),
        p95_regret=_quantile(regrets, 0.95),
        worst_regret=int(max(regrets)),
        family_mean_regret={
            family: mean(values) for family, values in sorted(by_family.items())
        },
        observations=observations,
    )


def prepare_optima(
    instances: Iterable[BinPackingInstance],
) -> Dict[str, int]:
    return {
        instance.instance_id: optimal_bin_count(
            instance.items,
            instance.capacity,
        )
        for instance in instances
    }


def prepare_references(
    instances: Iterable[BinPackingInstance],
    reference_mode: str,
) -> Dict[str, int]:
    instance_tuple = tuple(instances)
    if reference_mode == "exact":
        return prepare_optima(instance_tuple)
    if reference_mode == "volume_lower_bound":
        return {
            instance.instance_id: int(
                math.ceil(sum(instance.items) / float(instance.capacity))
            )
            for instance in instance_tuple
        }
    raise ValueError("unknown reference mode: %s" % reference_mode)
