from __future__ import annotations

import math
from typing import List, Sequence


def first_fit_decreasing(items: Sequence[int], capacity: int) -> int:
    loads: List[int] = []
    for item in sorted(items, reverse=True):
        for index, load in enumerate(loads):
            if load + item <= capacity:
                loads[index] += item
                break
        else:
            loads.append(item)
    return len(loads)


def optimal_bin_count(items: Sequence[int], capacity: int) -> int:
    """Return the exact optimum using symmetry-pruned branch and bound.

    This solver is intentionally small and independently testable. It is for
    short confirmation instances, not frontier-scale optimization.
    """

    if capacity <= 0:
        raise ValueError("capacity must be positive")
    if not items:
        return 0
    if any(item <= 0 or item > capacity for item in items):
        raise ValueError("every item must be in [1, capacity]")

    ordered = tuple(sorted(items, reverse=True))
    lower_bound = int(math.ceil(sum(ordered) / float(capacity)))
    best = first_fit_decreasing(ordered, capacity)
    if best == lower_bound:
        return best

    suffix_sum = [0] * (len(ordered) + 1)
    for index in range(len(ordered) - 1, -1, -1):
        suffix_sum[index] = suffix_sum[index + 1] + ordered[index]

    loads: List[int] = []

    def search(index: int) -> None:
        nonlocal best
        if len(loads) >= best:
            return
        if index == len(ordered):
            best = len(loads)
            return

        remaining_capacity = sum(capacity - load for load in loads)
        unavoidable_new_space = max(0, suffix_sum[index] - remaining_capacity)
        minimum_additional_bins = int(
            math.ceil(unavoidable_new_space / float(capacity))
        )
        if len(loads) + minimum_additional_bins >= best:
            return

        item = ordered[index]
        seen_loads = set()
        for bin_index, load in enumerate(loads):
            if load in seen_loads or load + item > capacity:
                continue
            seen_loads.add(load)
            loads[bin_index] += item
            search(index + 1)
            loads[bin_index] -= item

        if len(loads) + 1 < best:
            loads.append(item)
            search(index + 1)
            loads.pop()

    search(0)
    return best

