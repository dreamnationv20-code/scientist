from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple

from scientist.domains.binpacking.evaluator import (
    EvaluationReport,
    evaluate_heuristic,
    prepare_references,
)
from scientist.domains.binpacking.heuristics import OnlineHeuristic
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.programs import Expression, PriorityProgram


RegimeKey = Tuple[str, str]


def _level(value: float, low: float, high: float) -> str:
    if value < low:
        return "low"
    if value < high:
        return "mid"
    return "high"


@dataclass(frozen=True)
class InstanceFeatures:
    instance_id: str
    min_item: float
    mean_item: float
    item_std: float
    large_fraction: float
    near_half_fraction: float
    complementarity: float

    @property
    def regime_key(self) -> RegimeKey:
        return (
            "min_item:" + _level(self.min_item, 0.10, 0.25),
            "pairable:" + _level(self.complementarity, 0.30, 0.70),
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "instance_id": self.instance_id,
            "min_item": self.min_item,
            "mean_item": self.mean_item,
            "item_std": self.item_std,
            "large_fraction": self.large_fraction,
            "near_half_fraction": self.near_half_fraction,
            "complementarity": self.complementarity,
            "regime_key": list(self.regime_key),
        }


def instance_features(instance: BinPackingInstance) -> InstanceFeatures:
    values = [item / float(instance.capacity) for item in instance.items]
    average = mean(values)
    variance = mean((value - average) ** 2 for value in values)
    tolerance = 0.05
    pairable = 0
    for index, value in enumerate(values):
        if any(
            abs((value + other) - 1.0) <= tolerance
            for other_index, other in enumerate(values)
            if other_index != index
        ):
            pairable += 1
    return InstanceFeatures(
        instance_id=instance.instance_id,
        min_item=min(values),
        mean_item=average,
        item_std=math.sqrt(variance),
        large_fraction=sum(value > 0.5 for value in values) / len(values),
        near_half_fraction=sum(
            abs(value - 0.5) <= 0.08 for value in values
        )
        / len(values),
        complementarity=pairable / float(len(values)),
    )


@dataclass(frozen=True)
class RegimeSummary:
    key: RegimeKey
    instance_count: int
    failure_count: int
    total_regret: int
    mean_regret: float
    failure_rate: float
    mean_min_item: float
    mean_item_std: float
    mean_large_fraction: float
    mean_complementarity: float

    @property
    def priority(self) -> float:
        return self.total_regret + self.failure_rate

    def as_dict(self) -> Dict[str, Any]:
        return {
            "key": list(self.key),
            "instance_count": self.instance_count,
            "failure_count": self.failure_count,
            "total_regret": self.total_regret,
            "mean_regret": self.mean_regret,
            "failure_rate": self.failure_rate,
            "mean_min_item": self.mean_min_item,
            "mean_item_std": self.mean_item_std,
            "mean_large_fraction": self.mean_large_fraction,
            "mean_complementarity": self.mean_complementarity,
            "priority": self.priority,
        }


@dataclass(frozen=True)
class FailureRegimeReport:
    heuristic: str
    evaluator_report: EvaluationReport
    features: Mapping[str, InstanceFeatures]
    regimes: Tuple[RegimeSummary, ...]

    @property
    def failing_instance_ids(self) -> Tuple[str, ...]:
        return tuple(
            str(observation["instance_id"])
            for observation in self.evaluator_report.observations
            if int(observation["regret"]) > 0
        )

    def target_weights(self, emphasis: float = 3.0) -> Dict[str, float]:
        if emphasis < 0.0:
            raise ValueError("emphasis must be non-negative")
        regime_by_key = {regime.key: regime for regime in self.regimes}
        regrets = {
            str(observation["instance_id"]): int(observation["regret"])
            for observation in self.evaluator_report.observations
        }
        raw = {}
        for instance_id, features in self.features.items():
            regime = regime_by_key[features.regime_key]
            raw[instance_id] = 1.0 + emphasis * (
                regrets[instance_id] + regime.failure_rate
            )
        normalizer = mean(raw.values())
        return {
            instance_id: value / normalizer
            for instance_id, value in sorted(raw.items())
        }

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "heuristic": self.heuristic,
            "failing_instance_ids": list(self.failing_instance_ids),
            "features": {
                instance_id: features.as_dict()
                for instance_id, features in sorted(self.features.items())
            },
            "regimes": [regime.as_dict() for regime in self.regimes],
            "evaluator_report": self.evaluator_report.as_dict(),
        }


def discover_failure_regimes(
    heuristic: OnlineHeuristic,
    instances: Iterable[BinPackingInstance],
    optima: Optional[Mapping[str, int]] = None,
    reference_mode: str = "exact",
) -> FailureRegimeReport:
    instance_tuple = tuple(instances)
    if not instance_tuple:
        raise ValueError("at least one instance is required")
    resolved_optima = (
        dict(optima)
        if optima is not None
        else prepare_references(instance_tuple, reference_mode)
    )
    evaluator_report = evaluate_heuristic(
        heuristic,
        instance_tuple,
        optima=resolved_optima,
        reference_mode=reference_mode,
    )
    features = {
        instance.instance_id: instance_features(instance)
        for instance in instance_tuple
    }
    observations = {
        str(observation["instance_id"]): observation
        for observation in evaluator_report.observations
    }
    grouped: Dict[RegimeKey, List[str]] = {}
    for instance_id, feature_row in features.items():
        grouped.setdefault(feature_row.regime_key, []).append(instance_id)

    regimes = []
    for key, instance_ids in grouped.items():
        group_features = [features[instance_id] for instance_id in instance_ids]
        regrets = [
            int(observations[instance_id]["regret"])
            for instance_id in instance_ids
        ]
        failures = sum(regret > 0 for regret in regrets)
        regimes.append(
            RegimeSummary(
                key=key,
                instance_count=len(instance_ids),
                failure_count=failures,
                total_regret=sum(regrets),
                mean_regret=mean(regrets),
                failure_rate=failures / float(len(instance_ids)),
                mean_min_item=mean(
                    row.min_item for row in group_features
                ),
                mean_item_std=mean(
                    row.item_std for row in group_features
                ),
                mean_large_fraction=mean(
                    row.large_fraction for row in group_features
                ),
                mean_complementarity=mean(
                    row.complementarity for row in group_features
                ),
            )
        )
    regimes.sort(
        key=lambda regime: (
            -regime.priority,
            regime.key,
        )
    )
    return FailureRegimeReport(
        heuristic=heuristic.name,
        evaluator_report=evaluator_report,
        features=features,
        regimes=tuple(regimes),
    )


@dataclass(frozen=True)
class TargetedSeed:
    program: PriorityProgram
    mechanism: str
    source_regime: RegimeKey
    threshold: float
    penalty: float

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program": self.program.as_dict(),
            "mechanism": self.mechanism,
            "source_regime": list(self.source_regime),
            "threshold": self.threshold,
            "penalty": self.penalty,
        }


def _dead_gap_program(
    min_item_threshold: Expression,
    tight_threshold: float,
    penalty: float,
) -> PriorityProgram:
    is_existing = Expression.binary(
        "sub",
        Expression.const(1.0),
        Expression.feature("is_new_bin"),
    )
    below_minimum = Expression.unary(
        "step",
        Expression.binary(
            "sub",
            min_item_threshold,
            Expression.feature("remaining_after"),
        ),
    )
    not_tight = Expression.unary(
        "step",
        Expression.binary(
            "sub",
            Expression.feature("remaining_after"),
            Expression.const(tight_threshold),
        ),
    )
    dead_gap = Expression.binary(
        "mul",
        is_existing,
        Expression.binary("mul", below_minimum, not_tight),
    )
    return PriorityProgram(
        Expression.binary(
            "sub",
            Expression.feature("fill_after"),
            Expression.binary(
                "mul",
                Expression.const(penalty),
                dead_gap,
            ),
        )
    )


def _hard_dead_gap_program(
    min_item_threshold: Expression,
    tight_threshold: float,
) -> PriorityProgram:
    """Prefer Best Fit among safe bins; open rather than create a dead gap."""
    is_new = Expression.feature("is_new_bin")
    is_existing = Expression.binary(
        "sub",
        Expression.const(1.0),
        is_new,
    )
    dead_gap = Expression.binary(
        "mul",
        is_existing,
        Expression.binary(
            "mul",
            Expression.unary(
                "step",
                Expression.binary(
                    "sub",
                    min_item_threshold,
                    Expression.feature("remaining_after"),
                ),
            ),
            Expression.unary(
                "step",
                Expression.binary(
                    "sub",
                    Expression.feature("remaining_after"),
                    Expression.const(tight_threshold),
                ),
            ),
        ),
    )
    safe_existing = Expression.binary("sub", is_existing, dead_gap)
    return PriorityProgram(
        Expression.binary(
            "add",
            Expression.binary(
                "add",
                Expression.binary(
                    "mul",
                    Expression.const(2.0),
                    safe_existing,
                ),
                is_new,
            ),
            Expression.binary(
                "mul",
                Expression.const(0.01),
                Expression.feature("fill_after"),
            ),
        )
    )


def generate_targeted_seeds(
    report: FailureRegimeReport,
    maximum: int = 24,
) -> Tuple[TargetedSeed, ...]:
    """Generate mechanism-labeled seeds from the strongest failure regimes."""
    if maximum <= 0:
        return ()
    failing_regimes = [
        regime for regime in report.regimes if regime.failure_count > 0
    ]
    seeds: List[TargetedSeed] = []
    seen = set()
    for regime in failing_regimes:
        fixed_threshold = max(0.02, min(0.45, regime.mean_min_item))
        threshold_forms = (
            ("fixed_minimum", Expression.const(fixed_threshold)),
            ("observed_minimum", Expression.feature("seen_min")),
        )
        for mechanism, threshold_expression in threshold_forms:
            for tight_threshold in (0.02, 0.05):
                hard_program = _hard_dead_gap_program(
                    threshold_expression,
                    tight_threshold,
                )
                if hard_program.candidate_id not in seen:
                    seen.add(hard_program.candidate_id)
                    seeds.append(
                        TargetedSeed(
                            program=hard_program,
                            mechanism="hard_" + mechanism,
                            source_regime=regime.key,
                            threshold=fixed_threshold,
                            penalty=0.0,
                        )
                    )
                    if len(seeds) >= maximum:
                        return tuple(seeds)
                for penalty in (0.5, 1.0, 2.0):
                    program = _dead_gap_program(
                        threshold_expression,
                        tight_threshold,
                        penalty,
                    )
                    if program.candidate_id in seen:
                        continue
                    seen.add(program.candidate_id)
                    seeds.append(
                        TargetedSeed(
                            program=program,
                            mechanism=mechanism,
                            source_regime=regime.key,
                            threshold=fixed_threshold,
                            penalty=penalty,
                        )
                    )
                    if len(seeds) >= maximum:
                        return tuple(seeds)
    return tuple(seeds)
