from __future__ import annotations

from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import GeneratedPolicyModuleProgram
from scientist.domains.binpacking.mechanism_hypothesis import (
    ExecutableMechanismFingerprint,
)


FIRST_PRINCIPLES_CANDIDATE_VERSION = (
    "binpacking-first-principles-builtin-candidate-v1"
)


_EMPIRICAL_OPTION_VALUE_SOURCE = """
def build_state(item, loads, capacity, item_index, history):
    observed_count = 0
    observed_sum = 0.0
    observed_square_sum = 0.0
    observed_low = capacity
    observed_high = 0.0
    for past in history[-64:]:
        observed_count += 1
        observed_sum += past
        observed_square_sum += past * past
        if past < observed_low:
            observed_low = past
        if past > observed_high:
            observed_high = past
    if observed_count == 0:
        observed_count = 1
        observed_sum = item
        observed_square_sum = item * item
        observed_low = item
        observed_high = item
    observed_mean = observed_sum / observed_count
    observed_second = observed_square_sum / observed_count
    observed_variance = observed_second - observed_mean * observed_mean
    bin_scale = max(1, len(loads))
    dead_residual_mass = 0.0
    low_slots = 0
    mean_slots = 0
    high_slots = 0
    residual_sum = 0.0
    residual_square_sum = 0.0
    for load in loads:
        residual = capacity - load
        residual_sum += residual
        residual_square_sum += residual * residual
        if residual < observed_low:
            dead_residual_mass += residual / capacity
        if residual >= observed_low:
            low_slots += 1
        if residual >= observed_mean:
            mean_slots += 1
        if residual >= observed_high:
            high_slots += 1
    low_price = (observed_low / capacity) / (low_slots + 1)
    mean_price = (observed_mean / capacity) / (mean_slots + 1)
    high_price = (observed_high / capacity) / (high_slots + 1)
    return {"observed_low_ratio": observed_low / capacity, "observed_mean_ratio": observed_mean / capacity, "observed_high_ratio": observed_high / capacity, "observed_variance_ratio2": observed_variance / (capacity * capacity), "dead_residual_mass_per_bin": dead_residual_mass / bin_scale, "residual_mean_ratio": residual_sum / (bin_scale * capacity), "residual_second_moment_ratio2": residual_square_sum / (bin_scale * capacity * capacity), "low_slot_fraction": low_slots / bin_scale, "mean_slot_fraction": mean_slots / bin_scale, "high_slot_fraction": high_slots / bin_scale, "low_shadow_price": low_price, "mean_shadow_price": mean_price, "high_shadow_price": high_price, "total_shadow_pressure": low_price + mean_price + high_price}

def choose_action(item, loads, capacity, item_index, history, state):
    observed_low = state["observed_low_ratio"] * capacity
    observed_mean = state["observed_mean_ratio"] * capacity
    observed_high = state["observed_high_ratio"] * capacity
    new_residual = capacity - item
    best = -1
    best_score = 1.0 + abs(new_residual - observed_mean) / capacity
    for index, load in enumerate(loads):
        if load + item <= capacity:
            old_residual = capacity - load
            residual = old_residual - item
            option_loss = 0.0
            if old_residual >= observed_high and residual < observed_high:
                option_loss += state["high_shadow_price"]
            if old_residual >= observed_mean and residual < observed_mean:
                option_loss += state["mean_shadow_price"]
            if old_residual >= observed_low and residual < observed_low:
                option_loss += state["low_shadow_price"]
            score = option_loss + abs(residual - observed_mean) / capacity
            if score < best_score:
                best = index
                best_score = score
    return best
"""


def _empirical_option_value_program() -> Tuple[
    GeneratedPolicyModuleProgram, Mapping[str, Any]
]:
    statement = (
        "A placement is costly when it destroys one of the few residual-capacity "
        "slots able to serve the empirical item demand, even when its immediate "
        "post-placement residual looks attractive."
    )
    mechanism = (
        "Treat every open-bin residual as a reusable service slot. Estimate demand "
        "from bounded observed history and assign a larger shadow price when only "
        "zero, one, or two slots can serve an observed item size. Represent each "
        "action by its marginal effect on this capacity-coverage pressure, dead "
        "space, and empirical closure gap."
    )
    fingerprint = ExecutableMechanismFingerprint(
        information_used=(
            "current item size",
            "current open-bin residual capacities",
            "bounded empirical distribution of the last 64 item sizes",
            "joint feasible-slot multiplicity for observed item sizes",
        ),
        memory=(
            "bounded empirical demand memory over the last 64 arrivals; order is "
            "discarded after constructing service-pressure statistics"
        ),
        horizon=(
            "stationary empirical continuation represented as future demand for "
            "currently scarce residual-capacity slots"
        ),
        action_coupling=(
            "all legal actions are coupled through their marginal destruction of "
            "the same global residual-capacity service inventory"
        ),
        optimization_object=(
            "minimize empirical capacity shadow-price loss, dead residual mass, "
            "and closure gap after the irreversible placement"
        ),
        intervention_structure=(
            "joint state-dependent comparison of all legal placements; the "
            "external scientific controller may authorize at most one override"
        ),
        fallback=(
            "the standalone mechanism opens a new bin only when every feasible "
            "existing placement has larger estimated option loss; stable index "
            "order resolves ties"
        ),
        known_family=(
            "empirical bid-price control and resource-option valuation derived "
            "from residual-capacity service multiplicity"
        ),
        decision_topology=(
            "joint marginal shadow-price comparison over the global residual "
            "capacity inventory"
        ),
        fallback_policy_id="first_fit",
    )
    derivation = {
        "version": FIRST_PRINCIPLES_CANDIDATE_VERSION,
        "statement": statement,
        "mechanism": mechanism,
        "irreversible_decision": "placing the current item consumes capacity",
        "protected_resource": (
            "rare residual-capacity slots capable of serving observed demand"
        ),
        "prediction": (
            "helpful deviations from FunSearch will disproportionately preserve "
            "singleton and tight service slots while reducing future terminal bins"
        ),
    }
    hypothesis_id = content_digest(derivation)
    representation_contract = {
        "version": FIRST_PRINCIPLES_CANDIDATE_VERSION,
        "hypothesis_id": hypothesis_id,
        "feature_semantics": (
            "bounded-history empirical demand versus global residual service supply"
        ),
        "candidate_future_access": False,
    }
    program = GeneratedPolicyModuleProgram(
        source=_EMPIRICAL_OPTION_VALUE_SOURCE,
        model_ref="codex-first-principles-empirical-option-value-v1",
        prompt_digest=content_digest(derivation),
        hypothesis_id=hypothesis_id,
        mechanism_fingerprint=fingerprint,
        candidate_literature_assessment_id=content_digest(
            {
                "candidate_specific_search": "not_used_for_derivation",
                "known_family_assigned_after_derivation": fingerprint.known_family,
            }
        ),
        distinguishing_prediction=derivation["prediction"],
        information_ablation=(
            "erase the empirical demand history while retaining generic item, bin, "
            "and residual features"
        ),
        mechanism_ablation=(
            "replace service-slot multiplicity and shadow-price pressure with total "
            "residual capacity alone"
        ),
        rationale=mechanism,
        inspiration_refs=("first-principles-capacity-option-value",),
        island_family="de_novo",
        first_principles_derivation_id=content_digest(derivation),
        first_principles_audit_id=content_digest(
            {
                "derivation": derivation,
                "incumbent_hidden_during_derivation": True,
                "future_arrivals_available_to_candidate": False,
            }
        ),
        representation_contract_id=content_digest(representation_contract),
    )
    report: Dict[str, Any] = {
        "schema": 1,
        "version": FIRST_PRINCIPLES_CANDIDATE_VERSION,
        "builtin_name": "empirical_option_value",
        "hypothesis_id": program.hypothesis_id,
        "candidate_id": program.candidate_id,
        "statement": statement,
        "causal_mechanism": mechanism,
        "distinguishing_prediction": derivation["prediction"],
        "information_ablation": program.information_ablation,
        "mechanism_ablation": program.mechanism_ablation,
        "mechanism_fingerprint": fingerprint.as_dict(),
        "representation_contract": representation_contract,
        "source": program.as_dict(),
    }
    report["proposal_id"] = content_digest(report)
    return program, report


def builtin_first_principles_candidates() -> Mapping[
    str, Tuple[GeneratedPolicyModuleProgram, Mapping[str, Any]]
]:
    """Return deterministic first-principles candidates with full provenance."""

    program, report = _empirical_option_value_program()
    return {"empirical_option_value": (program, report)}
