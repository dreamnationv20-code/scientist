from __future__ import annotations

from dataclasses import dataclass
import math
import random
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import (
    OnlineHeuristic,
    baseline_heuristics,
    literature_heuristics,
    pack,
)
from scientist.domains.binpacking.models import BinPackingInstance


FIRST_PRINCIPLES_ORACLE_VERSION = (
    "binpacking-first-principles-objective-oracle-v1"
)
REGISTERED_FALLBACK_POLICY_IDS = (
    "first_fit",
    "best_fit",
    "worst_fit",
    "next_fit",
    "funsearch_or_reference",
)


@dataclass(frozen=True)
class FirstPrinciplesOracleConfig:
    """Admission thresholds for a cheap, objective-level executable test."""

    minimum_override_decisions: int = 4
    minimum_helpful_overrides: int = 2
    minimum_net_conditional_advantage: int = 1
    maximum_harmful_override_fraction: float = 0.50
    require_noninferior_tiny_outcome: bool = True
    exact_suffix_horizon: int = 5
    minimum_history_items: int = 8
    probe_stride: int = 16

    def __post_init__(self) -> None:
        if self.minimum_override_decisions < 1:
            raise ValueError("minimum override decisions must be positive")
        if self.minimum_helpful_overrides < 1:
            raise ValueError("minimum helpful overrides must be positive")
        if self.minimum_net_conditional_advantage < 1:
            raise ValueError("minimum conditional advantage must be positive")
        if not 0.0 <= self.maximum_harmful_override_fraction <= 1.0:
            raise ValueError("maximum harmful override fraction must be in [0, 1]")
        if not 2 <= self.exact_suffix_horizon <= 10:
            raise ValueError("exact suffix horizon must be in [2, 10]")
        if self.minimum_history_items < 0:
            raise ValueError("minimum history items must be non-negative")
        if self.probe_stride < 1:
            raise ValueError("probe stride must be positive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "minimum_override_decisions": self.minimum_override_decisions,
            "minimum_helpful_overrides": self.minimum_helpful_overrides,
            "minimum_net_conditional_advantage": (
                self.minimum_net_conditional_advantage
            ),
            "maximum_harmful_override_fraction": (
                self.maximum_harmful_override_fraction
            ),
            "require_noninferior_tiny_outcome": (
                self.require_noninferior_tiny_outcome
            ),
            "exact_suffix_horizon": self.exact_suffix_horizon,
            "minimum_history_items": self.minimum_history_items,
            "probe_stride": self.probe_stride,
        }


def registered_fallback_policies() -> Mapping[str, OnlineHeuristic]:
    policies = {**baseline_heuristics(), **literature_heuristics()}
    return {
        policy_id: policies[policy_id]
        for policy_id in REGISTERED_FALLBACK_POLICY_IDS
    }


def resolve_declared_fallback_policy_id(candidate: OnlineHeuristic) -> str:
    """Return the candidate's machine-readable causal reference policy."""

    fingerprint = getattr(candidate, "mechanism_fingerprint", None)
    policy_id = str(getattr(fingerprint, "fallback_policy_id", ""))
    if policy_id not in REGISTERED_FALLBACK_POLICY_IDS:
        raise ValueError("candidate lacks a registered fallback_policy_id")
    return policy_id


def _canonical_loads(loads: Sequence[int]) -> Tuple[int, ...]:
    return tuple(sorted((int(load) for load in loads), reverse=True))


def exact_terminal_bin_count(
    loads: Sequence[int],
    remaining_items: Sequence[int],
    capacity: int,
) -> int:
    """Exact terminal bin count from a partially packed state.

    Existing bins are fixed, while the remaining tiny suffix is placed optimally.
    The routine is deliberately separate from the deployed online controller: it
    is an offline diagnostic and never exposes a future item to the candidate.
    """

    if capacity <= 0:
        raise ValueError("capacity must be positive")
    canonical_loads = _canonical_loads(loads)
    remaining = tuple(sorted((int(item) for item in remaining_items), reverse=True))
    if any(load <= 0 or load > capacity for load in canonical_loads):
        raise ValueError("existing loads must be in [1, capacity]")
    if any(item <= 0 or item > capacity for item in remaining):
        raise ValueError("remaining items must be in [1, capacity]")

    base_bin_count = len(canonical_loads)
    greedy_loads = list(canonical_loads)
    greedy_new_bins = 0
    for item in remaining:
        feasible = [
            index
            for index, load in enumerate(greedy_loads)
            if load + item <= capacity
        ]
        if feasible:
            index = max(feasible, key=lambda value: greedy_loads[value])
            greedy_loads[index] += item
        else:
            greedy_loads.append(item)
            greedy_new_bins += 1
    if greedy_new_bins == 0:
        return base_bin_count

    suffix_sum = [0] * (len(remaining) + 1)
    for index in range(len(remaining) - 1, -1, -1):
        suffix_sum[index] = suffix_sum[index + 1] + remaining[index]
    loads_working = list(canonical_loads)
    best_new_bins = greedy_new_bins

    def search(item_index: int, opened: int) -> None:
        nonlocal best_new_bins
        if opened >= best_new_bins:
            return
        if item_index == len(remaining):
            best_new_bins = opened
            return
        free_space = sum(capacity - load for load in loads_working)
        unavoidable_volume = max(0, suffix_sum[item_index] - free_space)
        lower_new = int(math.ceil(unavoidable_volume / float(capacity)))
        if opened + lower_new >= best_new_bins:
            return

        item = remaining[item_index]
        seen_loads = set()
        feasible = [
            (load, index)
            for index, load in enumerate(loads_working)
            if load + item <= capacity
        ]
        for load, index in sorted(feasible, reverse=True):
            if load in seen_loads:
                continue
            seen_loads.add(load)
            loads_working[index] += item
            search(item_index + 1, opened)
            loads_working[index] -= item
            if best_new_bins == 0:
                return
        if opened + 1 < best_new_bins:
            loads_working.append(item)
            search(item_index + 1, opened + 1)
            loads_working.pop()

    search(0, 0)
    return base_bin_count + best_new_bins


def exact_action_values(
    *,
    item: int,
    loads: Sequence[int],
    remaining_items: Sequence[int],
    capacity: int,
) -> Mapping[Optional[int], int]:
    """Map every legal current action to exact final bins for the tiny suffix."""

    values: Dict[Optional[int], int] = {}
    for index, load in enumerate(loads):
        if load + item > capacity:
            continue
        successor = list(loads)
        successor[index] += item
        values[index] = exact_terminal_bin_count(
            successor,
            remaining_items,
            capacity,
        )
    values[None] = exact_terminal_bin_count(
        (*loads, item),
        remaining_items,
        capacity,
    )
    return values


def _scaled_items(capacity: int, ratios: Sequence[int]) -> Tuple[int, ...]:
    return tuple(
        max(1, min(capacity, int(round(capacity * ratio / 150.0))))
        for ratio in ratios
    )


def first_principles_oracle_suite(
    capacity: int = 150,
) -> Tuple[BinPackingInstance, ...]:
    """A preregistered broad tiny suite, independent of any candidate story."""

    if capacity < 10:
        raise ValueError("first-principles oracle capacity must be at least 10")
    families = []
    handcrafted_seeds = (
        (90, 60, 80, 70, 55, 95, 45, 50, 100),
        (80, 80, 70, 40, 30, 70, 60, 90, 20),
        (95, 55, 85, 65, 35, 30, 85, 50, 70),
        (75, 45, 30, 75, 60, 90, 45, 30, 60),
        (100, 50, 90, 30, 60, 40, 80, 70, 20),
        (85, 65, 80, 25, 45, 70, 55, 95, 30),
        (60, 45, 45, 90, 60, 30, 75, 75, 30),
        (70, 50, 30, 80, 40, 60, 90, 20, 55),
    )
    families.extend(
        ("complementary", tuple(values) * 14)
        for values in handcrafted_seeds
    )

    rng = random.Random(20_260_803)
    for _ in range(8):
        families.append(
            ("uniform", tuple(rng.randint(20, 100) for _ in range(120)))
        )
    pairs = ((50, 100), (55, 95), (60, 90), (65, 85), (70, 80))
    for index in range(8):
        values = []
        for offset in range(5):
            pair = pairs[(index + offset) % len(pairs)]
            values.extend(pair)
        del values[(index * 3) % len(values)]
        rng.shuffle(values)
        families.append(("paired_mixture", tuple(values) * 14))
    for index in range(8):
        early = tuple(rng.randint(72, 100) for _ in range(60))
        late = tuple(rng.randint(20, 58) for _ in range(60))
        values = early + late if index % 2 == 0 else late + early
        families.append(("regime_switch", values))

    return tuple(
        BinPackingInstance(
            instance_id="fp-oracle-%s-%02d" % (family, index),
            family="first_principles_oracle_%s" % family,
            seed=20_260_803 + index,
            capacity=capacity,
            items=_scaled_items(capacity, values),
        )
        for index, (family, values) in enumerate(families)
    )


def _successor_signature(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
) -> Tuple[int, ...]:
    if action is None:
        return _canonical_loads((*loads, item))
    successor = list(loads)
    successor[action] += item
    return _canonical_loads(successor)


def _apply_action(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    if action is None:
        return (*loads, item)
    if action < 0 or action >= len(loads):
        raise ValueError("policy selected a nonexistent bin")
    if loads[action] + item > capacity:
        raise ValueError("policy selected an infeasible bin")
    successor = list(loads)
    successor[action] += item
    return tuple(successor)


def assess_first_principles_objective_gate(
    candidate: OnlineHeuristic,
    *,
    fallback_policy_id: Optional[str] = None,
    instances: Optional[Sequence[BinPackingInstance]] = None,
    capacity: int = 150,
    config: FirstPrinciplesOracleConfig = FirstPrinciplesOracleConfig(),
) -> Mapping[str, Any]:
    """Test whether real candidate deviations improve exact tiny objectives."""

    fallback_id = fallback_policy_id
    failures = []
    if fallback_id is None:
        try:
            fallback_id = resolve_declared_fallback_policy_id(candidate)
        except ValueError:
            fallback_id = "unregistered"
    policies = registered_fallback_policies()
    fallback = policies.get(fallback_id)
    if fallback is None:
        failures.append("unregistered_declared_fallback")

    suite = tuple(instances or first_principles_oracle_suite(capacity))
    if not suite:
        raise ValueError("first-principles oracle suite must not be empty")
    if len({instance.capacity for instance in suite}) != 1:
        raise ValueError("first-principles oracle suite must use one capacity")

    decision_count = 0
    informative_decisions = 0
    override_count = 0
    helpful = 0
    harmful = 0
    tied = 0
    candidate_regret = 0
    fallback_regret = 0
    net_advantage = 0
    trace_rows = []
    candidate_terminal_bins = 0
    fallback_terminal_bins = 0
    aggregate_oracle_action_value = 0

    if fallback is not None:
        for instance in suite:
            loads: Tuple[int, ...] = ()
            history: Tuple[int, ...] = ()
            instance_candidate_regret = 0
            instance_fallback_regret = 0
            instance_overrides = 0
            for item_index, item in enumerate(instance.items):
                candidate_action = candidate.choose_bin(
                    item,
                    loads,
                    instance.capacity,
                    item_index,
                    history,
                )
                is_probe = (
                    item_index >= config.minimum_history_items
                    and (
                        item_index - config.minimum_history_items
                    ) % config.probe_stride == 0
                )
                if not is_probe:
                    loads = _apply_action(
                        candidate_action,
                        item,
                        loads,
                        instance.capacity,
                    )
                    history = (*history, item)
                    continue
                action_values = exact_action_values(
                    item=item,
                    loads=loads,
                    remaining_items=instance.items[
                        item_index + 1 :
                        item_index + config.exact_suffix_horizon
                    ],
                    capacity=instance.capacity,
                )
                fallback_action = fallback.choose_bin(
                    item,
                    loads,
                    instance.capacity,
                    item_index,
                    history,
                )
                if candidate_action not in action_values:
                    raise ValueError("candidate produced an illegal oracle action")
                if fallback_action not in action_values:
                    raise ValueError("fallback produced an illegal oracle action")
                best_value = min(action_values.values())
                aggregate_oracle_action_value += best_value
                candidate_value = action_values[candidate_action]
                fallback_value = action_values[fallback_action]
                current_candidate_regret = candidate_value - best_value
                current_fallback_regret = fallback_value - best_value
                decision_count += 1
                if len(set(action_values.values())) > 1:
                    informative_decisions += 1
                candidate_regret += current_candidate_regret
                fallback_regret += current_fallback_regret
                instance_candidate_regret += current_candidate_regret
                instance_fallback_regret += current_fallback_regret
                override = _successor_signature(
                    candidate_action, item, loads
                ) != _successor_signature(fallback_action, item, loads)
                if override:
                    advantage = fallback_value - candidate_value
                    override_count += 1
                    instance_overrides += 1
                    net_advantage += advantage
                    if advantage > 0:
                        helpful += 1
                    elif advantage < 0:
                        harmful += 1
                    else:
                        tied += 1
                loads = _apply_action(
                    candidate_action,
                    item,
                    loads,
                    instance.capacity,
                )
                history = (*history, item)
            candidate_bins = len(loads)
            fallback_bins = pack(instance, fallback).bin_count
            candidate_terminal_bins += candidate_bins
            fallback_terminal_bins += fallback_bins
            trace_rows.append(
                {
                    "instance_id": instance.instance_id,
                    "family": instance.family,
                    "candidate_bins": candidate_bins,
                    "fallback_bins": fallback_bins,
                    "candidate_action_regret": instance_candidate_regret,
                    "fallback_action_regret_on_candidate_states": (
                        instance_fallback_regret
                    ),
                    "override_decisions": instance_overrides,
                }
            )

        harmful_fraction = harmful / float(max(1, override_count))
        if override_count < config.minimum_override_decisions:
            failures.append("insufficient_distinct_fallback_overrides")
        if helpful < config.minimum_helpful_overrides:
            failures.append("insufficient_exactly_helpful_overrides")
        if net_advantage < config.minimum_net_conditional_advantage:
            failures.append("nonpositive_conditional_advantage")
        if candidate_regret >= fallback_regret:
            failures.append("candidate_exact_regret_not_better_than_fallback")
        if harmful_fraction > config.maximum_harmful_override_fraction:
            failures.append("too_many_exactly_harmful_overrides")
        if (
            config.require_noninferior_tiny_outcome
            and candidate_terminal_bins > fallback_terminal_bins
        ):
            failures.append("tiny_episode_outcome_worse_than_fallback")
    else:
        harmful_fraction = 0.0

    report: Dict[str, Any] = {
        "schema": 1,
        "oracle_version": FIRST_PRINCIPLES_ORACLE_VERSION,
        "candidate_id": getattr(candidate, "candidate_id", candidate.name),
        "fallback_policy_id": fallback_id,
        "suite_digest": content_digest(
            [instance.as_dict() for instance in suite]
        ),
        "suite_instances": len(suite),
        "decision_count": decision_count,
        "informative_decision_count": informative_decisions,
        "override_decisions": override_count,
        "helpful_overrides": helpful,
        "harmful_overrides": harmful,
        "oracle_tied_overrides": tied,
        "harmful_override_fraction": harmful_fraction,
        "net_conditional_advantage_bins": net_advantage,
        "mean_conditional_advantage_bins": (
            net_advantage / float(override_count) if override_count else 0.0
        ),
        "candidate_exact_action_regret": candidate_regret,
        "fallback_exact_action_regret_on_candidate_states": fallback_regret,
        "candidate_tiny_terminal_bins": candidate_terminal_bins,
        "fallback_tiny_terminal_bins": fallback_terminal_bins,
        "aggregate_exact_best_action_value": aggregate_oracle_action_value,
        "config": config.as_dict(),
        "passed": not failures,
        "failure_reasons": failures,
        "episode_screen_executed": False,
        "instance_results": trace_rows,
    }
    report["assessment_id"] = content_digest(report)
    return report
