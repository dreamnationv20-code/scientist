from __future__ import annotations

from statistics import mean
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import (
    GenesisConfig,
    _action_ref,
    _apply_action,
    _parse_action,
    _probe_indices,
    representative_actions,
)
from scientist.domains.binpacking.adaptive_three_arm_race import (
    ADAPTIVE_THREE_ARM_RACE_VERSION,
    plan_probe_with_adaptive_action_race,
)
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.domains.binpacking.monte_carlo_policy_improvement import _wilson_upper
from scientist.program.discovery_evidence import paired_episode_evidence


FULL_TRAJECTORY_ACTION_PLANNER_VERSION = "full-trajectory-adaptive-action-planner-v1"


def _baseline_terminal(items: Sequence[int], capacity: int = 150) -> int:
    baseline = literature_heuristics()["funsearch_or_reference"]
    loads: Tuple[int, ...] = ()
    history: Tuple[int, ...] = ()
    for item_index, item in enumerate(items):
        action = baseline.choose_bin(
            int(item), loads, capacity, item_index, history
        )
        loads = _apply_action(action, int(item), loads, capacity)
        history = (*history, int(item))[-128:]
    return len(loads)


def evaluate_causal_action_planner_episode(
    episode: Mapping[str, Any],
    *,
    probes_per_episode: int = 4,
    minimum_history_items: int = 12,
    maximum_action_representatives: int = 16,
    stages: Sequence[int] = (64, 128, 256, 512, 1_024, 2_048),
    synthetic_suffix_horizon: int = 96,
    planning_bank: str = "adaptive_action_race_full_trajectory_v1",
    mean_critical_value: float = 3.6,
    harm_z: float = 3.6,
    maximum_harm_rate_upper: float = 0.40,
) -> Mapping[str, Any]:
    items = tuple(int(value) for value in episode["items"])
    capacity = int(episode["capacity"])
    if capacity != 150:
        raise ValueError("full-trajectory planner is frozen to capacity 150")
    config = GenesisConfig(
        capacity=capacity,
        item_low=20,
        item_high=100,
        lengths=(len(items),),
        base_seed=0,
        probes_per_episode=probes_per_episode,
        minimum_history_items=minimum_history_items,
        maximum_action_representatives=maximum_action_representatives,
    )
    decision_indices = tuple(
        index
        for index in _probe_indices(config, len(items))
        if len(items) - index - 1 >= synthetic_suffix_horizon
    )
    baseline_terminal = _baseline_terminal(items, capacity)
    baseline = literature_heuristics()["funsearch_or_reference"]
    loads: Tuple[int, ...] = ()
    history: Tuple[int, ...] = ()
    intervention = None
    planning_records = []
    for item_index, item in enumerate(items):
        baseline_action = baseline.choose_bin(
            item, loads, capacity, item_index, history
        )
        action = baseline_action
        if intervention is None and item_index in decision_indices:
            actions = representative_actions(
                item,
                loads,
                capacity,
                baseline_action,
                maximum_action_representatives,
            )
            probe_body: Dict[str, Any] = {
                "partition": str(episode["partition"]),
                "instance_id": str(episode["instance_id"]),
                "length": len(items),
                "seed": int(episode["seed"]),
                "item_index": item_index,
                "item": item,
                "loads": list(loads),
                "history": list(history[-128:]),
                "baseline_action_ref": _action_ref(baseline_action),
                "action_refs": [_action_ref(value) for value in actions],
                "actual_future_items_stored": False,
                "outcome_labels_stored": False,
            }
            probe_body["probe_id"] = content_digest(probe_body)
            plan = plan_probe_with_adaptive_action_race(
                probe_body,
                stages=stages,
                suffix_horizon=synthetic_suffix_horizon,
                planning_bank=planning_bank,
                mean_critical_value=mean_critical_value,
                harm_z=harm_z,
                maximum_harm_rate_upper=maximum_harm_rate_upper,
            )
            planning_records.append(plan)
            if bool(plan["planner_activated"]):
                selected_ref = str(plan["selected_action"]["arm"]["initial_action_ref"])
                action = _parse_action(selected_ref)
                intervention = {
                    "probe_id": probe_body["probe_id"],
                    "item_index": item_index,
                    "baseline_action_ref": _action_ref(baseline_action),
                    "selected_action_ref": selected_ref,
                    "planning_stage": int(plan["selected_action"]["stage"]),
                    "planning_baseline_advantage": plan["selected_action"][
                        "baseline_advantage"
                    ],
                }
        loads = _apply_action(action, item, loads, capacity)
        history = (*history, item)[-128:]
    candidate_terminal = len(loads)
    return {
        "instance_id": str(episode["instance_id"]),
        "seed": int(episode["seed"]),
        "length": len(items),
        "decision_indices": list(decision_indices),
        "actual_future_items_available_to_planner": False,
        "synthetic_suffix_horizon_fits_before_episode_end": True,
        "maximum_interventions": 1,
        "intervention": intervention,
        "planning_records": planning_records,
        "baseline_terminal_bins": baseline_terminal,
        "candidate_terminal_bins": candidate_terminal,
        "terminal_bins_saved": baseline_terminal - candidate_terminal,
        "persistent_macro_used": False,
        "learned_selector_used": False,
        "latent_concept_used": False,
    }


def summarize_full_trajectory_action_planner(
    rows: Sequence[Mapping[str, Any]],
    *,
    minimum_intervention_count: int = 50,
    maximum_loss_rate_upper: float = 0.40,
    loss_wilson_z: float = 2.576,
) -> Mapping[str, Any]:
    episode_ids = tuple(str(row["instance_id"]) for row in rows)
    if len(set(episode_ids)) != len(rows):
        raise ValueError("full-trajectory rows reuse an episode")
    improvements = tuple(float(row["terminal_bins_saved"]) for row in rows)
    evidence = paired_episode_evidence(improvements, episode_ids)
    intervention_rows = tuple(row for row in rows if row["intervention"] is not None)
    losses = sum(value < 0.0 for value in improvements)
    loss_upper = _wilson_upper(losses, len(rows), z=loss_wilson_z)
    by_length = {}
    for length in sorted({int(row["length"]) for row in rows}):
        length_rows = tuple(row for row in rows if int(row["length"]) == length)
        by_length[str(length)] = {
            "episode_count": len(length_rows),
            "intervention_count": sum(
                row["intervention"] is not None for row in length_rows
            ),
            "aggregate_bins_saved": sum(
                int(row["terminal_bins_saved"]) for row in length_rows
            ),
            "mean_bins_saved_per_episode": mean(
                float(row["terminal_bins_saved"]) for row in length_rows
            ),
        }
    gates = {
        "intervention_count_minimum": len(intervention_rows) >= minimum_intervention_count,
        "full_trajectory_mean_95_percent_ci_lower_positive": (
            evidence.mean_ci_lower > 0.0
        ),
        "full_trajectory_loss_rate_99_percent_upper_at_most_0_40": (
            loss_upper <= maximum_loss_rate_upper
        ),
        "mean_bins_saved_each_length_nonnegative": all(
            row["mean_bins_saved_per_episode"] >= 0.0
            for row in by_length.values()
        ),
        "at_most_one_intervention_per_episode": all(
            int(row["maximum_interventions"]) == 1 for row in rows
        ),
    }
    body = {
        "schema": 1,
        "version": FULL_TRAJECTORY_ACTION_PLANNER_VERSION,
        "source_isolated_planner_version": ADAPTIVE_THREE_ARM_RACE_VERSION,
        "episode_count": len(rows),
        "intervention_count": len(intervention_rows),
        "intervention_fraction": len(intervention_rows) / float(len(rows)),
        "wins": sum(value > 0.0 for value in improvements),
        "ties": sum(value == 0.0 for value in improvements),
        "losses": losses,
        "loss_rate": losses / float(len(rows)),
        "loss_rate_wilson_99_percent_upper": loss_upper,
        "paired_full_trajectory_evidence": evidence.as_dict(),
        "by_length": by_length,
        "gates": gates,
        "full_trajectory_confirmation_passed": all(gates.values()),
        "actual_future_items_available_to_planner": False,
        "persistent_macro_used": False,
        "learned_selector_used": False,
        "latent_concept_used": False,
    }
    body["assessment_id"] = content_digest(body)
    return body
