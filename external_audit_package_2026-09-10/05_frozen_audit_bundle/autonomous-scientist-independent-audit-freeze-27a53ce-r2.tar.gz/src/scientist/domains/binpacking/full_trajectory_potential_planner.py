from __future__ import annotations

from statistics import mean
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import (
    GenesisConfig,
    _action_ref,
    _apply_action,
    _parse_action,
    _probe_indices,
    representative_actions,
)
from scientist.domains.binpacking.full_trajectory_action_planner import (
    _baseline_terminal,
)
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.domains.binpacking.horizon_transport_potential import (
    plan_probe_with_frozen_potential,
)
from scientist.domains.binpacking.monte_carlo_policy_improvement import _wilson_upper
from scientist.program.discovery_evidence import paired_episode_evidence


FULL_TRAJECTORY_POTENTIAL_PLANNER_VERSION = (
    "full-trajectory-horizon-weighted-absorptive-diversity-v1"
)


def evaluate_frozen_potential_episode(
    episode: Mapping[str, Any],
    hypothesis: Mapping[str, Any],
    *,
    probes_per_episode: int = 4,
    minimum_history_items: int = 12,
    maximum_action_representatives: int = 16,
    minimum_terminal_horizon: int = 128,
    short_horizon: int = 96,
    suffix_samples: int = 128,
    planning_bank: str = "frozen_absorptive_diversity_full_trajectory_v1",
) -> Mapping[str, Any]:
    items = tuple(int(value) for value in episode["items"])
    capacity = int(episode["capacity"])
    config = GenesisConfig(
        capacity=capacity,
        item_low=20,
        item_high=100,
        lengths=(len(items),),
        base_seed=0,
        probes_per_episode=probes_per_episode,
        minimum_history_items=minimum_history_items,
        maximum_action_representatives=maximum_action_representatives,
    )
    decision_indices = tuple(
        index
        for index in _probe_indices(config, len(items))
        if len(items) - index - 1 >= minimum_terminal_horizon
    )
    baseline_terminal = _baseline_terminal(items, capacity)
    baseline = literature_heuristics()["funsearch_or_reference"]
    loads: Tuple[int, ...] = ()
    history: Tuple[int, ...] = ()
    intervention = None
    planning_records = []
    for item_index, item in enumerate(items):
        baseline_action = baseline.choose_bin(
            item, loads, capacity, item_index, history
        )
        action = baseline_action
        if intervention is None and item_index in decision_indices:
            actions = representative_actions(
                item,
                loads,
                capacity,
                baseline_action,
                maximum_action_representatives,
            )
            probe: Dict[str, Any] = {
                "partition": str(episode["partition"]),
                "instance_id": str(episode["instance_id"]),
                "seed": int(episode["seed"]),
                "length": len(items),
                "item_index": item_index,
                "item": item,
                "loads": list(loads),
                "history": list(history[-128:]),
                "baseline_action_ref": _action_ref(baseline_action),
                "action_refs": [_action_ref(value) for value in actions],
                "actual_future_items_stored": False,
            }
            probe["probe_id"] = content_digest(probe)
            plan = plan_probe_with_frozen_potential(
                probe,
                hypothesis,
                terminal_horizon=len(items) - item_index - 1,
                short_horizon=short_horizon,
                sample_count=suffix_samples,
                bank=planning_bank,
            )
            planning_records.append(plan)
            if bool(plan["planner_activated"]):
                selected_ref = str(plan["selected_action"]["action_ref"])
                action = _parse_action(selected_ref)
                intervention = {
                    "probe_id": probe["probe_id"],
                    "item_index": item_index,
                    "baseline_action_ref": _action_ref(baseline_action),
                    "selected_action_ref": selected_ref,
                    "predicted_terminal_advantage": float(
                        plan["selected_action"]["predicted_terminal_advantage"]
                    ),
                    "short_advantage": plan["selected_action"]["short_advantage"],
                    "mean_potential_feature_deltas": plan["selected_action"][
                        "mean_potential_feature_deltas"
                    ],
                }
        loads = _apply_action(action, item, loads, capacity)
        history = (*history, item)[-128:]
    candidate_terminal = len(loads)
    return {
        "instance_id": str(episode["instance_id"]),
        "seed": int(episode["seed"]),
        "length": len(items),
        "decision_indices": list(decision_indices),
        "hypothesis_id": str(hypothesis["hypothesis_id"]),
        "actual_future_items_available_to_planner": False,
        "maximum_interventions": 1,
        "intervention": intervention,
        "planning_records": planning_records,
        "baseline_terminal_bins": baseline_terminal,
        "candidate_terminal_bins": candidate_terminal,
        "terminal_bins_saved": baseline_terminal - candidate_terminal,
        "latent_concept_used": True,
        "persistent_macro_used": False,
        "learned_selector_used": False,
    }


def summarize_frozen_potential_trajectories(
    rows: Sequence[Mapping[str, Any]],
    *,
    minimum_interventions: int = 100,
    maximum_loss_rate_upper: float = 0.40,
) -> Mapping[str, Any]:
    episode_ids = tuple(str(row["instance_id"]) for row in rows)
    improvements = tuple(float(row["terminal_bins_saved"]) for row in rows)
    evidence = paired_episode_evidence(improvements, episode_ids)
    intervention_rows = tuple(row for row in rows if row["intervention"] is not None)
    losses = sum(value < 0.0 for value in improvements)
    loss_upper = _wilson_upper(losses, len(rows), z=2.576)
    by_length = {}
    for length in sorted({int(row["length"]) for row in rows}):
        subset = tuple(row for row in rows if int(row["length"]) == length)
        by_length[str(length)] = {
            "episode_count": len(subset),
            "intervention_count": sum(row["intervention"] is not None for row in subset),
            "aggregate_bins_saved": sum(int(row["terminal_bins_saved"]) for row in subset),
            "mean_bins_saved_per_episode": mean(
                float(row["terminal_bins_saved"]) for row in subset
            ),
        }
    gates = {
        "intervention_count_minimum": len(intervention_rows) >= minimum_interventions,
        "mean_terminal_bins_saved_95_percent_ci_lower_positive": (
            evidence.mean_ci_lower > 0.0
        ),
        "loss_rate_99_percent_upper_at_most_0_40": loss_upper
        <= maximum_loss_rate_upper,
        "mean_bins_saved_each_length_nonnegative": all(
            value["mean_bins_saved_per_episode"] >= 0.0
            for value in by_length.values()
        ),
        "at_most_one_intervention_per_episode": all(
            int(row["maximum_interventions"]) == 1 for row in rows
        ),
    }
    body = {
        "schema": 1,
        "version": FULL_TRAJECTORY_POTENTIAL_PLANNER_VERSION,
        "hypothesis_id": str(rows[0]["hypothesis_id"]),
        "episode_count": len(rows),
        "intervention_count": len(intervention_rows),
        "wins": sum(value > 0.0 for value in improvements),
        "ties": sum(value == 0.0 for value in improvements),
        "losses": losses,
        "loss_rate": losses / float(len(rows)),
        "loss_rate_wilson_99_percent_upper": loss_upper,
        "paired_full_trajectory_evidence": evidence.as_dict(),
        "by_length": by_length,
        "gates": gates,
        "full_trajectory_potential_confirmation_passed": all(gates.values()),
        "actual_future_items_available_to_planner": False,
        "latent_concept_used": True,
        "persistent_macro_used": False,
        "learned_selector_used": False,
    }
    body["assessment_id"] = content_digest(body)
    return body
