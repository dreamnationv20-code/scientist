from __future__ import annotations

from dataclasses import dataclass
import math
import random
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import (
    _action_ref,
    _parse_action,
    _percentile,
    representative_actions,
)
from scientist.domains.binpacking.contrastive_concept import (
    concept_value_for_intervention,
    fit_frozen_prediction_models,
    old_intervention_features,
    prediction_rows,
)
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.domains.binpacking.representation_capacity import (
    LinearAdvantageModel,
)
from scientist.program.discovery_evidence import paired_episode_evidence


FUNSEARCH_CONCEPT_TRANSFER_VERSION = "funsearch-concept-transfer-v1"


def selector_features(
    probe: Mapping[str, Any], action_ref: str, *, include_concept: bool
) -> Mapping[str, float]:
    features = dict(old_intervention_features(probe, action_ref))
    if include_concept:
        features["invented_admissible_residual_mass_exchange"] = (
            concept_value_for_intervention(probe, action_ref)
        )
    return features


def _quantile_indices(count: int, wanted: int) -> Tuple[int, ...]:
    if count <= wanted:
        return tuple(range(count))
    return tuple(
        sorted(
            {
                int(round(rank * (count - 1) / float(wanted - 1)))
                for rank in range(wanted)
            }
        )
    )


def _calibrate_threshold(
    atlas: Mapping[str, Any], model: LinearAdvantageModel
) -> Tuple[float, Mapping[str, Any]]:
    rows = []
    for probe in atlas["probes"]:
        alternatives = tuple(
            action
            for action in probe["actions"]
            if action["action_ref"] != probe["baseline_action_ref"]
        )
        if not alternatives:
            continue
        scored = tuple(
            (
                model.predict(
                    selector_features(
                        probe, str(action["action_ref"]), include_concept=True
                    )
                ),
                action,
            )
            for action in alternatives
        )
        score, action = max(scored, key=lambda pair: pair[0])
        rows.append(
            {
                "instance_id": probe["instance_id"],
                "predicted_advantage": float(score),
                "terminal_advantage": float(action["terminal_advantage"]),
            }
        )
    values = sorted({row["predicted_advantage"] for row in rows})
    thresholds = tuple(
        values[index] - 1e-12
        for index in _quantile_indices(len(values), min(80, len(values)))
    )
    evaluated = []
    for threshold in thresholds:
        selected = tuple(
            row for row in rows if row["predicted_advantage"] > threshold
        )
        if len(selected) < 20:
            continue
        net = sum(row["terminal_advantage"] for row in selected)
        harmful_magnitude = -sum(
            min(0.0, row["terminal_advantage"]) for row in selected
        )
        evaluated.append(
            (
                net - 0.25 * harmful_magnitude,
                net,
                -harmful_magnitude,
                -len(selected),
                threshold,
                selected,
            )
        )
    if not evaluated:
        return math.inf, {
            "activation_count": 0,
            "net_expected_terminal_advantage": 0.0,
        }
    _, net, _, _, threshold, selected = max(
        evaluated, key=lambda row: row[:5]
    )
    return float(threshold), {
        "activation_count": len(selected),
        "net_expected_terminal_advantage": net,
        "mean_expected_terminal_advantage": net / len(selected),
        "helpful_count": sum(
            row["terminal_advantage"] > 1e-12 for row in selected
        ),
        "harmful_count": sum(
            row["terminal_advantage"] < -1e-12 for row in selected
        ),
        "neutral_count": sum(
            abs(row["terminal_advantage"]) <= 1e-12 for row in selected
        ),
        "minimum_activation_count": 20,
        "inputs": "FunSearch counterfactual discovery only",
    }


@dataclass(frozen=True)
class FrozenFunSearchConceptSelector:
    selector_id: str
    old_model: LinearAdvantageModel
    augmented_model: LinearAdvantageModel
    adoption_threshold: float
    maximum_interventions_per_episode: int
    minimum_decision_cooldown: int
    discovery_calibration: Mapping[str, Any]
    concept_source_digest: str

    def as_dict(self) -> Mapping[str, Any]:
        body = {
            "version": FUNSEARCH_CONCEPT_TRANSFER_VERSION,
            "old_model": self.old_model.as_dict(),
            "augmented_model": self.augmented_model.as_dict(),
            "adoption_threshold": self.adoption_threshold,
            "maximum_interventions_per_episode": (
                self.maximum_interventions_per_episode
            ),
            "minimum_decision_cooldown": self.minimum_decision_cooldown,
            "discovery_calibration": dict(self.discovery_calibration),
            "concept_source_digest": self.concept_source_digest,
            "fallback": "funsearch_or_reference",
        }
        return {**body, "selector_id": content_digest(body)}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FrozenFunSearchConceptSelector":
        result = cls(
            selector_id=str(value["selector_id"]),
            old_model=LinearAdvantageModel.from_dict(value["old_model"]),
            augmented_model=LinearAdvantageModel.from_dict(
                value["augmented_model"]
            ),
            adoption_threshold=float(value["adoption_threshold"]),
            maximum_interventions_per_episode=int(
                value["maximum_interventions_per_episode"]
            ),
            minimum_decision_cooldown=int(value["minimum_decision_cooldown"]),
            discovery_calibration=dict(value["discovery_calibration"]),
            concept_source_digest=str(value["concept_source_digest"]),
        )
        if result.as_dict()["selector_id"] != result.selector_id:
            raise ValueError("FunSearch concept selector identity mismatch")
        return result


def fit_funsearch_concept_selector(
    atlas: Mapping[str, Any], *, concept_source_digest: str
) -> FrozenFunSearchConceptSelector:
    if atlas["trajectory_policy"] != "funsearch_or_reference":
        raise ValueError("selector discovery must use FunSearch trajectories")
    old_model, augmented_model = fit_frozen_prediction_models(atlas)
    threshold, calibration = _calibrate_threshold(atlas, augmented_model)
    provisional = FrozenFunSearchConceptSelector(
        selector_id="",
        old_model=old_model,
        augmented_model=augmented_model,
        adoption_threshold=threshold,
        maximum_interventions_per_episode=4,
        minimum_decision_cooldown=32,
        discovery_calibration=calibration,
        concept_source_digest=concept_source_digest,
    )
    return FrozenFunSearchConceptSelector.from_dict(provisional.as_dict())


def _correlation(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right) or len(left) < 2:
        return 0.0
    left_mean = mean(left)
    right_mean = mean(right)
    numerator = sum(
        (x - left_mean) * (y - right_mean) for x, y in zip(left, right)
    )
    left_scale = math.sqrt(sum((x - left_mean) ** 2 for x in left))
    right_scale = math.sqrt(sum((y - right_mean) ** 2 for y in right))
    if left_scale == 0.0 or right_scale == 0.0:
        return 0.0
    return numerator / (left_scale * right_scale)


def evaluate_funsearch_concept_transfer(
    selector: FrozenFunSearchConceptSelector,
    atlas: Mapping[str, Any],
) -> Mapping[str, Any]:
    if atlas["trajectory_policy"] != "funsearch_or_reference":
        raise ValueError("transfer validation must use FunSearch trajectories")
    old_rows = prediction_rows(atlas, include_concept=False)
    augmented_rows = prediction_rows(atlas, include_concept=True)
    if tuple((row.state_id, row.action_ref) for row in old_rows) != tuple(
        (row.state_id, row.action_ref) for row in augmented_rows
    ):
        raise ValueError("transfer prediction rows do not align")
    association_rows = []
    error_by_episode: Dict[str, list[float]] = {}
    old_errors = []
    augmented_errors = []
    for old_row, augmented_row in zip(old_rows, augmented_rows):
        concept = float(
            augmented_row.features[
                "invented_admissible_residual_mass_exchange"
            ]
        )
        association_rows.append(
            (old_row.instance_id, concept, old_row.advantage)
        )
        old_error = (
            selector.old_model.predict(old_row.features) - old_row.advantage
        ) ** 2
        augmented_error = (
            selector.augmented_model.predict(augmented_row.features)
            - augmented_row.advantage
        ) ** 2
        old_errors.append(old_error)
        augmented_errors.append(augmented_error)
        error_by_episode.setdefault(old_row.instance_id, []).append(
            old_error - augmented_error
        )
    association_by_episode: Dict[str, list[Tuple[float, float]]] = {}
    for episode_id, concept, advantage in association_rows:
        association_by_episode.setdefault(episode_id, []).append(
            (concept, advantage)
        )
    association_episode_ids = sorted(association_by_episode)
    error_episode_ids = sorted(error_by_episode)
    rng = random.Random(548_104_026)
    association_bootstrap = []
    error_bootstrap = []
    for _ in range(5_000):
        association_sample = [
            association_episode_ids[rng.randrange(len(association_episode_ids))]
            for _ in association_episode_ids
        ]
        sampled_rows = [
            row
            for episode_id in association_sample
            for row in association_by_episode[episode_id]
        ]
        association_bootstrap.append(
            _correlation(
                tuple(row[0] for row in sampled_rows),
                tuple(row[1] for row in sampled_rows),
            )
        )
        error_sample = [
            error_episode_ids[rng.randrange(len(error_episode_ids))]
            for _ in error_episode_ids
        ]
        error_bootstrap.append(
            mean(
                mean(error_by_episode[episode_id])
                for episode_id in error_sample
            )
        )
    selected_by_episode: Dict[str, float] = {}
    activations = 0
    for probe in atlas["probes"]:
        episode_id = str(probe["instance_id"])
        selected_by_episode.setdefault(episode_id, 0.0)
        alternatives = tuple(
            action
            for action in probe["actions"]
            if action["action_ref"] != probe["baseline_action_ref"]
        )
        if not alternatives:
            continue
        scored = tuple(
            (
                selector.augmented_model.predict(
                    selector_features(
                        probe, str(action["action_ref"]), include_concept=True
                    )
                ),
                -order,
                action,
            )
            for order, action in enumerate(alternatives)
        )
        score, _, action = max(scored, key=lambda row: (row[0], row[1]))
        if score > selector.adoption_threshold:
            selected_by_episode[episode_id] += float(
                action["terminal_advantage"]
            )
            activations += 1
    episode_ids = sorted(selected_by_episode)
    selected_evidence = paired_episode_evidence(
        tuple(selected_by_episode[episode_id] for episode_id in episode_ids),
        episode_ids,
    )
    old_mse = mean(old_errors)
    augmented_mse = mean(augmented_errors)
    association = _correlation(
        tuple(row[1] for row in association_rows),
        tuple(row[2] for row in association_rows),
    )
    gates = {
        "concept_association_cluster_bootstrap_lower_positive": (
            _percentile(sorted(association_bootstrap), 0.025) > 0.0
        ),
        "old_plus_concept_relative_mse_reduction_positive": (
            augmented_mse < old_mse
        ),
        "error_reduction_cluster_bootstrap_lower_positive": (
            _percentile(sorted(error_bootstrap), 0.025) > 0.0
        ),
        "selected_expected_counterfactual_return_ci_lower_positive": (
            selected_evidence.mean_ci_lower > 0.0
        ),
    }
    return {
        "version": FUNSEARCH_CONCEPT_TRANSFER_VERSION,
        "selector_id": selector.selector_id,
        "validation_atlas_id": atlas["atlas_id"],
        "concept_action_value_association": association,
        "concept_association_cluster_bootstrap_ci_lower": _percentile(
            sorted(association_bootstrap), 0.025
        ),
        "concept_association_cluster_bootstrap_ci_upper": _percentile(
            sorted(association_bootstrap), 0.975
        ),
        "old_only_mse": old_mse,
        "old_plus_concept_mse": augmented_mse,
        "relative_mse_reduction": (old_mse - augmented_mse) / old_mse,
        "error_reduction_cluster_bootstrap_ci_lower": _percentile(
            sorted(error_bootstrap), 0.025
        ),
        "error_reduction_cluster_bootstrap_ci_upper": _percentile(
            sorted(error_bootstrap), 0.975
        ),
        "selector_activation_count": activations,
        "selected_expected_counterfactual_return": selected_evidence.as_dict(),
        "gates": gates,
        "transfer_passed": all(gates.values()),
    }


class TrustRegionConceptFunSearchPolicy:
    name = "trust_region_concept_funsearch"

    def __init__(self, selector: FrozenFunSearchConceptSelector) -> None:
        self.selector = selector
        self._interventions = 0
        self._last_intervention = -10**9
        self._baseline = literature_heuristics()["funsearch_or_reference"]

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        if item_index == 0:
            self._interventions = 0
            self._last_intervention = -10**9
        baseline_action = self._baseline.choose_bin(
            item, loads, capacity, item_index, history
        )
        if (
            self._interventions
            >= self.selector.maximum_interventions_per_episode
            or item_index - self._last_intervention
            < self.selector.minimum_decision_cooldown
        ):
            return baseline_action
        actions = representative_actions(
            item, loads, capacity, baseline_action, maximum=16
        )
        alternatives = tuple(action for action in actions if action != baseline_action)
        if not alternatives:
            return baseline_action
        probe = {
            "item": item,
            "item_index": item_index,
            "loads": list(loads),
            "history": list(history[-128:]),
            "baseline_action_ref": _action_ref(baseline_action),
        }
        scored = tuple(
            (
                self.selector.augmented_model.predict(
                    selector_features(
                        probe, _action_ref(action), include_concept=True
                    )
                ),
                -order,
                action,
            )
            for order, action in enumerate(alternatives)
        )
        score, _, selected = max(scored, key=lambda row: (row[0], row[1]))
        if score > self.selector.adoption_threshold:
            self._interventions += 1
            self._last_intervention = item_index
            return selected
        return baseline_action
