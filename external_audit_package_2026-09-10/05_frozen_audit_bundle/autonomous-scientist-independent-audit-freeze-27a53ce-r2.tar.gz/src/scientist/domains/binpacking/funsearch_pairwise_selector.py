from __future__ import annotations

from dataclasses import dataclass
import math
import random
from statistics import mean, stdev
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import (
    _action_ref,
    _parse_action,
    _percentile,
    _terminal_after_synthetic_suffix,
)
from scientist.domains.binpacking.funsearch_concept_transfer import (
    FrozenFunSearchConceptSelector,
    selector_features,
)
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.program.discovery_evidence import paired_episode_evidence


PAIRWISE_SELECTOR_VERSION = "funsearch-pairwise-risk-selector-v1"
CONCEPT_FEATURE = "invented_admissible_residual_mass_exchange"


def _sigmoid(value: float) -> float:
    if value >= 0.0:
        decay = math.exp(-min(40.0, value))
        return 1.0 / (1.0 + decay)
    growth = math.exp(max(-40.0, value))
    return growth / (1.0 + growth)


def _spread(values: Sequence[float]) -> float:
    if not values:
        return 0.0
    center = mean(values)
    return math.sqrt(mean((value - center) ** 2 for value in values))


def _paired_interval(
    samples: Sequence[float], *, critical_value: float = 2.040
) -> Tuple[float, float, float]:
    if len(samples) < 2:
        raise ValueError("paired interval requires at least two samples")
    center = mean(samples)
    standard_error = stdev(samples) / math.sqrt(len(samples))
    radius = critical_value * standard_error
    return center, center - radius, center + radius


def paired_rollout_advantages(
    probe: Mapping[str, Any], action_ref: str
) -> Tuple[float, ...]:
    baseline = next(
        action
        for action in probe["actions"]
        if action["action_ref"] == probe["baseline_action_ref"]
    )
    candidate = next(
        action for action in probe["actions"] if action["action_ref"] == action_ref
    )
    return tuple(
        float(baseline_bins) - float(candidate_bins)
        for baseline_bins, candidate_bins in zip(
            baseline["rollout_bin_counts"], candidate["rollout_bin_counts"]
        )
    )


def expanded_pairwise_features(
    probe: Mapping[str, Any],
    action_ref: str,
    *,
    include_concept: bool,
) -> Mapping[str, float]:
    """Fixed selector representation; this does not change the latent concept."""

    base = dict(
        selector_features(probe, action_ref, include_concept=include_concept)
    )
    expanded: Dict[str, float] = {}
    for name in sorted(base):
        value = float(base[name])
        expanded["base:%s" % name] = value
        expanded["square:%s" % name] = value * value
    if include_concept:
        concept = float(base[CONCEPT_FEATURE])
        for name in sorted(base):
            if name == CONCEPT_FEATURE:
                continue
            expanded["concept_interaction:%s" % name] = concept * float(
                base[name]
            )
    return expanded


@dataclass(frozen=True)
class PairwiseTrainingRow:
    state_id: str
    instance_id: str
    action_ref: str
    features: Mapping[str, float]
    target_helpful: float
    confidence_weight: float
    terminal_advantage: float


def pairwise_training_rows(
    atlas: Mapping[str, Any], *, include_concept: bool
) -> Tuple[PairwiseTrainingRow, ...]:
    rows = []
    for probe in atlas["probes"]:
        for action in probe["actions"]:
            action_ref = str(action["action_ref"])
            if action_ref == probe["baseline_action_ref"]:
                continue
            paired = paired_rollout_advantages(probe, action_ref)
            effect = mean(paired)
            if abs(effect) <= 1e-12:
                continue
            standard_error = stdev(paired) / math.sqrt(len(paired))
            signal_to_noise = abs(effect) / max(
                1.0 / len(paired), standard_error
            )
            rows.append(
                PairwiseTrainingRow(
                    state_id=str(probe["probe_id"]),
                    instance_id=str(probe["instance_id"]),
                    action_ref=action_ref,
                    features=expanded_pairwise_features(
                        probe, action_ref, include_concept=include_concept
                    ),
                    target_helpful=float(effect > 0.0),
                    confidence_weight=max(0.25, min(4.0, signal_to_noise)),
                    terminal_advantage=effect,
                )
            )
    if not rows:
        raise ValueError("pairwise selector has no non-neutral training rows")
    return tuple(rows)


@dataclass(frozen=True)
class LogisticPairwiseModel:
    feature_names: Tuple[str, ...]
    centers: Tuple[float, ...]
    scales: Tuple[float, ...]
    weights: Tuple[float, ...]
    bias: float
    training_config: Mapping[str, Any]

    def predict_probability(self, features: Mapping[str, float]) -> float:
        logit = self.bias + sum(
            weight
            * max(
                -8.0,
                min(8.0, (float(features.get(name, 0.0)) - center) / scale),
            )
            for name, center, scale, weight in zip(
                self.feature_names,
                self.centers,
                self.scales,
                self.weights,
            )
        )
        return _sigmoid(logit)

    def as_dict(self) -> Mapping[str, Any]:
        body = {
            "feature_names": list(self.feature_names),
            "centers": list(self.centers),
            "scales": list(self.scales),
            "weights": list(self.weights),
            "bias": self.bias,
            "training_config": dict(self.training_config),
        }
        return {**body, "model_id": content_digest(body)}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "LogisticPairwiseModel":
        result = cls(
            feature_names=tuple(str(item) for item in value["feature_names"]),
            centers=tuple(float(item) for item in value["centers"]),
            scales=tuple(float(item) for item in value["scales"]),
            weights=tuple(float(item) for item in value["weights"]),
            bias=float(value["bias"]),
            training_config=dict(value["training_config"]),
        )
        dimensions = {
            len(result.feature_names),
            len(result.centers),
            len(result.scales),
            len(result.weights),
        }
        if len(dimensions) != 1 or not result.feature_names:
            raise ValueError("pairwise model dimensions do not match")
        if any(scale <= 0.0 for scale in result.scales):
            raise ValueError("pairwise model scales must be positive")
        supplied_id = value.get("model_id")
        if supplied_id is not None and supplied_id != result.as_dict()["model_id"]:
            raise ValueError("pairwise model identity mismatch")
        return result


def _fit_logistic_model(
    rows: Sequence[PairwiseTrainingRow],
    *,
    seed: int,
    held_out_fold: int,
    fold_count: int,
    epochs: int = 70,
    learning_rate: float = 0.012,
    ridge: float = 0.002,
) -> LogisticPairwiseModel:
    if not rows:
        raise ValueError("cannot fit an empty pairwise model")
    names = tuple(sorted(set().union(*(set(row.features) for row in rows))))
    columns = tuple(
        tuple(float(row.features.get(name, 0.0)) for row in rows)
        for name in names
    )
    centers = tuple(mean(column) for column in columns)
    scales = tuple(max(1e-6, _spread(column)) for column in columns)
    positives = sum(row.target_helpful for row in rows)
    negatives = len(rows) - positives
    if positives <= 0.0 or negatives <= 0.0:
        raise ValueError("pairwise model requires both helpful and harmful rows")
    positive_weight = len(rows) / (2.0 * positives)
    negative_weight = len(rows) / (2.0 * negatives)
    prevalence = positives / len(rows)
    bias = math.log(prevalence / (1.0 - prevalence))
    weights = [0.0] * len(names)
    standardized = tuple(
        tuple(
            max(
                -8.0,
                min(
                    8.0,
                    (float(row.features.get(name, 0.0)) - center) / scale,
                ),
            )
            for name, center, scale in zip(names, centers, scales)
        )
        for row in rows
    )
    order = list(range(len(rows)))
    rng = random.Random(seed)
    for epoch in range(epochs):
        rng.shuffle(order)
        rate = learning_rate / math.sqrt(epoch + 1.0)
        for row_index in order:
            row = rows[row_index]
            values = standardized[row_index]
            probability = _sigmoid(
                bias + sum(weight * value for weight, value in zip(weights, values))
            )
            balance = (
                positive_weight if row.target_helpful > 0.5 else negative_weight
            )
            importance = row.confidence_weight * balance
            error = importance * (probability - row.target_helpful)
            bias = max(-12.0, min(12.0, bias - rate * error))
            for index, value in enumerate(values):
                gradient = error * value + ridge * weights[index]
                weights[index] = max(
                    -12.0, min(12.0, weights[index] - rate * gradient)
                )
    return LogisticPairwiseModel(
        feature_names=names,
        centers=centers,
        scales=scales,
        weights=tuple(weights),
        bias=bias,
        training_config={
            "seed": seed,
            "held_out_episode_fold": held_out_fold,
            "episode_fold_count": fold_count,
            "epochs": epochs,
            "learning_rate": learning_rate,
            "ridge": ridge,
            "objective": "balanced_confidence_weighted_pairwise_logistic",
        },
    )


def _episode_fold(instance_id: str, fold_count: int) -> int:
    return int(content_digest(instance_id)[:12], 16) % fold_count


def _auc(labels_and_scores: Sequence[Tuple[float, float]]) -> float:
    positives = tuple(score for label, score in labels_and_scores if label > 0.5)
    negatives = tuple(score for label, score in labels_and_scores if label < 0.5)
    if not positives or not negatives:
        return 0.5
    wins = 0.0
    for positive in positives:
        for negative in negatives:
            wins += float(positive > negative) + 0.5 * float(positive == negative)
    return wins / (len(positives) * len(negatives))


def fit_episode_grouped_ensemble(
    atlas: Mapping[str, Any],
    *,
    include_concept: bool,
    fold_count: int = 5,
) -> Tuple[Tuple[LogisticPairwiseModel, ...], Mapping[str, Any]]:
    rows = pairwise_training_rows(atlas, include_concept=include_concept)
    models = []
    held_out_predictions = []
    fold_rows = []
    for fold in range(fold_count):
        training = tuple(
            row
            for row in rows
            if _episode_fold(row.instance_id, fold_count) != fold
        )
        held_out = tuple(
            row
            for row in rows
            if _episode_fold(row.instance_id, fold_count) == fold
        )
        model = _fit_logistic_model(
            training,
            seed=648_104_026 + fold + (0 if include_concept else 100),
            held_out_fold=fold,
            fold_count=fold_count,
        )
        models.append(model)
        fold_rows.append(
            {
                "fold": fold,
                "training_row_count": len(training),
                "held_out_row_count": len(held_out),
                "held_out_episode_count": len(
                    {row.instance_id for row in held_out}
                ),
            }
        )
        held_out_predictions.extend(
            (
                row.target_helpful,
                model.predict_probability(row.features),
            )
            for row in held_out
        )
    accuracy = mean(
        float((score >= 0.5) == (label > 0.5))
        for label, score in held_out_predictions
    )
    brier = mean(
        (score - label) ** 2 for label, score in held_out_predictions
    )
    return tuple(models), {
        "include_concept": include_concept,
        "training_atlas_id": atlas["atlas_id"],
        "training_row_count": len(rows),
        "training_episode_count": len({row.instance_id for row in rows}),
        "episode_fold_count": fold_count,
        "folds": fold_rows,
        "held_out_accuracy": accuracy,
        "held_out_brier": brier,
        "held_out_auc": _auc(held_out_predictions),
    }


def ensemble_conservative_score(
    models: Sequence[LogisticPairwiseModel],
    features: Mapping[str, float],
) -> Tuple[float, float, float]:
    probabilities = tuple(model.predict_probability(features) for model in models)
    center = mean(probabilities)
    uncertainty = stdev(probabilities) if len(probabilities) > 1 else 0.0
    return center - 1.645 * uncertainty, center, uncertainty


def best_pairwise_alternative(
    models: Sequence[LogisticPairwiseModel],
    probe: Mapping[str, Any],
    *,
    include_concept: bool,
) -> Optional[Mapping[str, Any]]:
    scored = []
    for order, action in enumerate(probe["actions"]):
        action_ref = str(action["action_ref"])
        if action_ref == probe["baseline_action_ref"]:
            continue
        conservative, probability, uncertainty = ensemble_conservative_score(
            models,
            expanded_pairwise_features(
                probe, action_ref, include_concept=include_concept
            ),
        )
        scored.append(
            (
                conservative,
                probability,
                -uncertainty,
                -order,
                action_ref,
            )
        )
    if not scored:
        return None
    conservative, probability, negative_uncertainty, _, action_ref = max(
        scored, key=lambda row: row[:4]
    )
    return {
        "action_ref": action_ref,
        "conservative_score": conservative,
        "mean_helpful_probability": probability,
        "between_model_standard_deviation": -negative_uncertainty,
    }


def refined_counterfactual_credit(
    probe: Mapping[str, Any],
    action_ref: str,
    *,
    sample_count: int,
    suffix_horizon: int,
    namespace: str,
) -> Mapping[str, Any]:
    if action_ref == probe["baseline_action_ref"]:
        raise ValueError("refinement requires a non-baseline action")
    material = {
        "version": PAIRWISE_SELECTOR_VERSION,
        "namespace": namespace,
        "probe_id": probe["probe_id"],
        "action_ref": action_ref,
        "sample_count": sample_count,
        "suffix_horizon": suffix_horizon,
    }
    seed = int(content_digest(material)[:16], 16)
    rng = random.Random(seed)
    suffixes = tuple(
        tuple(rng.randint(20, 100) for _ in range(suffix_horizon))
        for _ in range(sample_count)
    )
    continuation = literature_heuristics()["funsearch_or_reference"]
    common = {
        "item": int(probe["item"]),
        "item_index": int(probe["item_index"]),
        "loads": tuple(int(value) for value in probe["loads"]),
        "history": tuple(int(value) for value in probe["history"]),
        "capacity": 150,
        "suffixes": suffixes,
        "continuation": continuation,
    }

    def outcomes(action_ref_value: str) -> Tuple[int, ...]:
        return tuple(
            _terminal_after_synthetic_suffix(
                item=common["item"],
                item_index=common["item_index"],
                loads=common["loads"],
                history=common["history"],
                capacity=common["capacity"],
                action=_parse_action(action_ref_value),
                suffix=suffix,
                continuation=common["continuation"],
            )
            for suffix in common["suffixes"]
        )

    baseline = outcomes(str(probe["baseline_action_ref"]))
    candidate = outcomes(action_ref)
    paired = tuple(float(left - right) for left, right in zip(baseline, candidate))
    effect, lower, upper = _paired_interval(paired, critical_value=1.979)
    return {
        "probe_id": probe["probe_id"],
        "instance_id": probe["instance_id"],
        "action_ref": action_ref,
        "sample_count": sample_count,
        "suffix_horizon": suffix_horizon,
        "common_random_numbers": True,
        "rollout_samples_counted_as_independent_evidence": False,
        "rollout_seed": seed,
        "terminal_advantage": effect,
        "advantage_ci_lower": lower,
        "advantage_ci_upper": upper,
        "paired_rollout_advantages": list(paired),
    }


def score_atlas(
    atlas: Mapping[str, Any],
    models: Sequence[LogisticPairwiseModel],
    *,
    include_concept: bool,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for probe in atlas["probes"]:
        best = best_pairwise_alternative(
            models, probe, include_concept=include_concept
        )
        if best is not None:
            rows.append({"probe": probe, **best})
    return tuple(rows)


def refine_scored_rows(
    scored_groups: Iterable[Sequence[Mapping[str, Any]]],
    *,
    sample_count: int = 128,
    suffix_horizon: int = 96,
    namespace: str,
) -> Mapping[Tuple[str, str], Mapping[str, Any]]:
    wanted: Dict[Tuple[str, str], Mapping[str, Any]] = {}
    for scored_rows in scored_groups:
        for row in scored_rows:
            key = (str(row["probe"]["probe_id"]), str(row["action_ref"]))
            wanted[key] = row
    refined = {}
    for key in sorted(wanted):
        row = wanted[key]
        refined[key] = refined_counterfactual_credit(
            row["probe"],
            str(row["action_ref"]),
            sample_count=sample_count,
            suffix_horizon=suffix_horizon,
            namespace=namespace,
        )
    return refined


def _cluster_bootstrap_selection(
    selected: Sequence[Mapping[str, Any]],
    *,
    episode_ids: Sequence[str],
    seed: int,
    draws: int = 5_000,
) -> Mapping[str, float]:
    by_episode: Dict[str, list[Mapping[str, Any]]] = {
        str(episode_id): [] for episode_id in episode_ids
    }
    for row in selected:
        by_episode.setdefault(str(row["instance_id"]), []).append(row)
    independent_episode_ids = sorted(by_episode)
    if len(independent_episode_ids) < 2:
        return {
            "mean_return_ci_lower": -math.inf,
            "mean_return_ci_upper": math.inf,
            "harmful_rate_ci_lower": 0.0,
            "harmful_rate_ci_upper": 1.0,
        }
    rng = random.Random(seed)
    return_samples = []
    harmful_samples = []
    for _ in range(draws):
        sampled = tuple(
            independent_episode_ids[rng.randrange(len(independent_episode_ids))]
            for _ in independent_episode_ids
        )
        rows = tuple(row for episode_id in sampled for row in by_episode[episode_id])
        return_samples.append(
            sum(float(row["terminal_advantage"]) for row in rows)
            / len(independent_episode_ids)
        )
        harmful_samples.append(
            sum(float(row["terminal_advantage"]) < 0.0 for row in rows)
            / float(len(rows))
            if rows
            else 0.0
        )
    return {
        "mean_return_ci_lower": _percentile(tuple(sorted(return_samples)), 0.01),
        "mean_return_ci_upper": _percentile(tuple(sorted(return_samples)), 0.99),
        "harmful_rate_ci_lower": _percentile(tuple(sorted(harmful_samples)), 0.01),
        "harmful_rate_ci_upper": _percentile(tuple(sorted(harmful_samples)), 0.99),
    }


def calibrate_risk_controlled_threshold(
    scored: Sequence[Mapping[str, Any]],
    refined: Mapping[Tuple[str, str], Mapping[str, Any]],
    *,
    include_concept: bool,
    coverage_candidates: Sequence[float] = (0.05, 0.10, 0.20, 0.30, 0.40),
    minimum_activations: int = 60,
) -> Tuple[float, Mapping[str, Any]]:
    if not scored:
        raise ValueError("risk calibration requires scored probes")
    scores = sorted(
        (float(row["conservative_score"]) for row in scored), reverse=True
    )
    candidates = []
    for order, coverage in enumerate(coverage_candidates):
        selected_count = max(1, int(math.ceil(coverage * len(scores))))
        threshold = scores[selected_count - 1] - 1e-12
        selected = []
        for row in scored:
            if float(row["conservative_score"]) <= threshold:
                continue
            credit = refined[(str(row["probe"]["probe_id"]), str(row["action_ref"]))]
            selected.append(
                {
                    **credit,
                    "conservative_score": float(row["conservative_score"]),
                }
            )
        episode_ids = sorted({str(row["probe"]["instance_id"]) for row in scored})
        by_episode = {episode_id: 0.0 for episode_id in episode_ids}
        for row in selected:
            by_episode[str(row["instance_id"])] += float(row["terminal_advantage"])
        evidence = paired_episode_evidence(
            tuple(by_episode[episode_id] for episode_id in episode_ids),
            episode_ids,
        )
        bootstrap = _cluster_bootstrap_selection(
            selected,
            episode_ids=episode_ids,
            seed=748_104_026 + order + (0 if include_concept else 100),
        )
        passed = (
            len(selected) >= minimum_activations
            and bootstrap["mean_return_ci_lower"] > 0.0
            and bootstrap["harmful_rate_ci_upper"] <= 0.40
        )
        candidates.append(
            {
                "coverage_target": coverage,
                "threshold": threshold,
                "activation_count": len(selected),
                "mean_expected_bins_saved_per_episode": evidence.mean_improvement,
                "ordinary_95_percent_ci_lower": evidence.mean_ci_lower,
                "ordinary_95_percent_ci_upper": evidence.mean_ci_upper,
                "harmful_action_count": sum(
                    float(row["terminal_advantage"]) < 0.0 for row in selected
                ),
                "neutral_action_count": sum(
                    abs(float(row["terminal_advantage"])) <= 1e-12
                    for row in selected
                ),
                "helpful_action_count": sum(
                    float(row["terminal_advantage"]) > 0.0 for row in selected
                ),
                **bootstrap,
                "risk_control_passed": passed,
            }
        )
    passing = tuple(row for row in candidates if row["risk_control_passed"])
    if not passing:
        return math.inf, {
            "include_concept": include_concept,
            "safe_threshold_found": False,
            "minimum_activation_count": minimum_activations,
            "candidate_results": candidates,
        }
    chosen = max(
        passing,
        key=lambda row: (
            row["mean_return_ci_lower"],
            row["mean_expected_bins_saved_per_episode"],
            row["activation_count"],
        ),
    )
    return float(chosen["threshold"]), {
        "include_concept": include_concept,
        "safe_threshold_found": True,
        "minimum_activation_count": minimum_activations,
        "chosen": chosen,
        "candidate_results": candidates,
    }


@dataclass(frozen=True)
class FrozenRiskControlledPairwiseSelector:
    selector_id: str
    include_concept: bool
    models: Tuple[LogisticPairwiseModel, ...]
    adoption_threshold: float
    model_diagnostics: Mapping[str, Any]
    risk_calibration: Mapping[str, Any]
    concept_source_digest: str

    def as_dict(self) -> Mapping[str, Any]:
        body = {
            "version": PAIRWISE_SELECTOR_VERSION,
            "include_concept": self.include_concept,
            "models": [model.as_dict() for model in self.models],
            "adoption_threshold": self.adoption_threshold,
            "model_diagnostics": dict(self.model_diagnostics),
            "risk_calibration": dict(self.risk_calibration),
            "concept_source_digest": self.concept_source_digest,
            "fallback": "funsearch_or_reference",
        }
        return {**body, "selector_id": content_digest(body)}

    @classmethod
    def from_dict(
        cls, value: Mapping[str, Any]
    ) -> "FrozenRiskControlledPairwiseSelector":
        result = cls(
            selector_id=str(value["selector_id"]),
            include_concept=bool(value["include_concept"]),
            models=tuple(
                LogisticPairwiseModel.from_dict(model) for model in value["models"]
            ),
            adoption_threshold=float(value["adoption_threshold"]),
            model_diagnostics=dict(value["model_diagnostics"]),
            risk_calibration=dict(value["risk_calibration"]),
            concept_source_digest=str(value["concept_source_digest"]),
        )
        if result.as_dict()["selector_id"] != result.selector_id:
            raise ValueError("risk-controlled selector identity mismatch")
        return result


def freeze_pairwise_selector(
    training_atlas: Mapping[str, Any],
    calibration_atlas: Mapping[str, Any],
    refined_calibration: Mapping[Tuple[str, str], Mapping[str, Any]],
    *,
    include_concept: bool,
    concept_source_digest: str,
) -> FrozenRiskControlledPairwiseSelector:
    models, diagnostics = fit_episode_grouped_ensemble(
        training_atlas, include_concept=include_concept
    )
    scored = score_atlas(
        calibration_atlas, models, include_concept=include_concept
    )
    threshold, calibration = calibrate_risk_controlled_threshold(
        scored,
        refined_calibration,
        include_concept=include_concept,
    )
    provisional = FrozenRiskControlledPairwiseSelector(
        selector_id="",
        include_concept=include_concept,
        models=models,
        adoption_threshold=threshold,
        model_diagnostics=diagnostics,
        risk_calibration=calibration,
        concept_source_digest=concept_source_digest,
    )
    return FrozenRiskControlledPairwiseSelector.from_dict(provisional.as_dict())


def evaluate_frozen_pairwise_selectors(
    augmented: FrozenRiskControlledPairwiseSelector,
    ablation: FrozenRiskControlledPairwiseSelector,
    atlas: Mapping[str, Any],
    refined: Mapping[Tuple[str, str], Mapping[str, Any]],
) -> Mapping[str, Any]:
    summaries = {}
    for name, selector in (("augmented", augmented), ("ablation", ablation)):
        scored = score_atlas(
            atlas, selector.models, include_concept=selector.include_concept
        )
        episode_ids = sorted({str(probe["instance_id"]) for probe in atlas["probes"]})
        by_episode = {episode_id: 0.0 for episode_id in episode_ids}
        selected = []
        for row in scored:
            if float(row["conservative_score"]) <= selector.adoption_threshold:
                continue
            credit = refined[(str(row["probe"]["probe_id"]), str(row["action_ref"]))]
            selected.append(credit)
            by_episode[str(credit["instance_id"])] += float(
                credit["terminal_advantage"]
            )
        evidence = paired_episode_evidence(
            tuple(by_episode[episode_id] for episode_id in episode_ids), episode_ids
        )
        bootstrap = _cluster_bootstrap_selection(
            selected,
            episode_ids=episode_ids,
            seed=848_104_026 + (0 if selector.include_concept else 100),
        )
        summaries[name] = {
            "selector_id": selector.selector_id,
            "activation_count": len(selected),
            "helpful_action_count": sum(
                float(row["terminal_advantage"]) > 0.0 for row in selected
            ),
            "neutral_action_count": sum(
                abs(float(row["terminal_advantage"])) <= 1e-12 for row in selected
            ),
            "harmful_action_count": sum(
                float(row["terminal_advantage"]) < 0.0 for row in selected
            ),
            "episode_evidence": evidence.as_dict(),
            **bootstrap,
        }
    augmented_summary = summaries["augmented"]
    ablation_summary = summaries["ablation"]
    gates = {
        "activation_count_minimum_100": augmented_summary["activation_count"] >= 100,
        "selected_expected_return_ci_lower_positive": augmented_summary[
            "episode_evidence"
        ]["mean_improvement_ci_lower"]
        > 0.0,
        "cluster_bootstrap_harmful_rate_upper_at_most_0_40": augmented_summary[
            "harmful_rate_ci_upper"
        ]
        <= 0.40,
        "augmented_mean_strictly_above_ablation": augmented_summary[
            "episode_evidence"
        ]["mean_improvement"]
        > ablation_summary["episode_evidence"]["mean_improvement"],
    }
    return {
        "version": PAIRWISE_SELECTOR_VERSION,
        "validation_atlas_id": atlas["atlas_id"],
        **summaries,
        "gates": gates,
        "isolated_selector_passed": all(gates.values()),
    }


def decompose_prior_selector_errors(
    selector: FrozenFunSearchConceptSelector,
    atlas: Mapping[str, Any],
) -> Mapping[str, Any]:
    selected_rows = []
    reliable_rows = []
    for probe in atlas["probes"]:
        alternatives = tuple(
            action
            for action in probe["actions"]
            if action["action_ref"] != probe["baseline_action_ref"]
        )
        if not alternatives:
            continue
        scored = tuple(
            (
                selector.augmented_model.predict(
                    selector_features(
                        probe, str(action["action_ref"]), include_concept=True
                    )
                ),
                -order,
                action,
            )
            for order, action in enumerate(alternatives)
        )
        score, _, selected = max(scored, key=lambda row: (row[0], row[1]))
        for action in alternatives:
            action_ref = str(action["action_ref"])
            effect, lower, upper = _paired_interval(
                paired_rollout_advantages(probe, action_ref)
            )
            if lower > 0.0 or upper < 0.0:
                reliable_rows.append(
                    {
                        "probe_id": probe["probe_id"],
                        "instance_id": probe["instance_id"],
                        "action_ref": action_ref,
                        "sign": "positive" if lower > 0.0 else "negative",
                        "effect": effect,
                        "features": expanded_pairwise_features(
                            probe, action_ref, include_concept=True
                        ),
                    }
                )
        if score <= selector.adoption_threshold:
            continue
        selected_ref = str(selected["action_ref"])
        paired = paired_rollout_advantages(probe, selected_ref)
        effect, lower, upper = _paired_interval(paired)
        better_alternative_exists = False
        for alternative in alternatives:
            alternative_ref = str(alternative["action_ref"])
            if alternative_ref == selected_ref:
                continue
            candidate_counts = tuple(selected["rollout_bin_counts"])
            alternative_counts = tuple(alternative["rollout_bin_counts"])
            pairwise_improvement = tuple(
                float(left) - float(right)
                for left, right in zip(candidate_counts, alternative_counts)
            )
            _, alternative_lower, _ = _paired_interval(pairwise_improvement)
            if alternative_lower > 0.0:
                better_alternative_exists = True
                break
        selected_rows.append(
            {
                "probe_id": probe["probe_id"],
                "instance_id": probe["instance_id"],
                "action_ref": selected_ref,
                "effect": effect,
                "ci_lower": lower,
                "ci_upper": upper,
                "rollout_outcome_uncertainty": lower <= 0.0 <= upper,
                "within_state_ranking_error": better_alternative_exists,
                "confident_harmful_selection": upper < 0.0,
                "reliable_helpful_selection": lower > 0.0,
            }
        )
    collisions = _confident_representation_collisions(reliable_rows)
    return {
        "version": PAIRWISE_SELECTOR_VERSION,
        "prior_selector_id": selector.selector_id,
        "source_atlas_id": atlas["atlas_id"],
        "activation_count": len(selected_rows),
        "rollout_outcome_uncertainty_count": sum(
            row["rollout_outcome_uncertainty"] for row in selected_rows
        ),
        "within_state_ranking_error_count": sum(
            row["within_state_ranking_error"] for row in selected_rows
        ),
        "confident_harmful_selection_count": sum(
            row["confident_harmful_selection"] for row in selected_rows
        ),
        "reliable_helpful_selection_count": sum(
            row["reliable_helpful_selection"] for row in selected_rows
        ),
        "distribution_shift": "not_assessed_before_isolated_selector_gate",
        "reliable_augmented_representation_row_count": len(reliable_rows),
        "representation_collision_diagnostic": collisions,
        "selected_rows": selected_rows,
    }


def _confident_representation_collisions(
    rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    if len(rows) < 3:
        return {
            "pair_count": 0,
            "high_precision_refinement_triggered": False,
            "concept_invention_triggered": False,
            "pairs": [],
        }
    names = tuple(sorted(rows[0]["features"]))
    scales = {
        name: max(
            1e-9,
            _spread(tuple(float(row["features"][name]) for row in rows)),
        )
        for name in names
    }

    def distance(left: Mapping[str, Any], right: Mapping[str, Any]) -> float:
        return math.sqrt(
            mean(
                (
                    (float(left["features"][name]) - float(right["features"][name]))
                    / scales[name]
                )
                ** 2
                for name in names
            )
        )

    nearest_opposite: Dict[Tuple[str, str], Tuple[Tuple[str, str], float]] = {}
    keyed = {
        (str(row["probe_id"]), str(row["action_ref"])): row for row in rows
    }
    for key, row in keyed.items():
        opposite = tuple(other for other in rows if other["sign"] != row["sign"])
        if not opposite:
            continue
        neighbor = min(opposite, key=lambda other: distance(row, other))
        neighbor_key = (str(neighbor["probe_id"]), str(neighbor["action_ref"]))
        nearest_opposite[key] = (neighbor_key, distance(row, neighbor))
    pairs = []
    seen = set()
    for left_key, (right_key, observed_distance) in nearest_opposite.items():
        reverse = nearest_opposite.get(right_key)
        pair_key = tuple(sorted((left_key, right_key)))
        if (
            reverse is None
            or reverse[0] != left_key
            or observed_distance > 0.35
            or pair_key in seen
        ):
            continue
        seen.add(pair_key)
        pairs.append(
            {
                "standardized_rms_distance": observed_distance,
                "left": {
                    key: keyed[left_key][key]
                    for key in ("probe_id", "instance_id", "action_ref", "sign", "effect")
                },
                "right": {
                    key: keyed[right_key][key]
                    for key in ("probe_id", "instance_id", "action_ref", "sign", "effect")
                },
            }
        )
    pairs.sort(key=lambda row: row["standardized_rms_distance"])
    return {
        "definition": "candidate mutual-nearest opposite-sign neighbors from low-precision credit within standardized RMS distance 0.35",
        "pair_count": len(pairs),
        "minimum_pairs_for_high_precision_refinement": 10,
        "high_precision_refinement_triggered": len(pairs) >= 10,
        "concept_invention_triggered": False,
        "concept_invention_requires_persistent_opposite_sign_pairs_after_independent_high_precision_credit": True,
        "pairs": pairs[:30],
    }
