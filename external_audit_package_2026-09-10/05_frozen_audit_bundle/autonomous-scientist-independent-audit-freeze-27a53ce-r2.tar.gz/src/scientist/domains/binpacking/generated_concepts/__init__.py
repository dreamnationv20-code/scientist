"""Executable concepts produced by contrast-driven invention experiments."""
