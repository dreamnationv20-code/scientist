from __future__ import annotations

from typing import Optional, Sequence, Tuple


CONCEPT_NAME = "admissible_residual_mass_exchange"
CONCEPT_VERSION = "contrast-invented-concept-v1"


def _successor_residuals(
    item: int,
    loads: Sequence[int],
    capacity: int,
    action: Optional[int],
) -> Tuple[int, ...]:
    if action is None:
        successor = (*loads, item)
    else:
        if action < 0 or action >= len(loads) or loads[action] + item > capacity:
            raise ValueError("latent concept received an illegal action")
        updated = list(loads)
        updated[action] += item
        successor = tuple(updated)
    return tuple(capacity - load for load in successor)


def _admissible_mass(
    residuals: Sequence[int],
    *,
    minimum_arrival: int,
    maximum_arrival: int,
) -> float:
    """Integral of the residual option-count curve over admissible demand."""

    support_width = maximum_arrival - minimum_arrival + 1
    if support_width <= 0:
        raise ValueError("invalid arrival support")
    return sum(
        max(0, min(maximum_arrival, residual) - minimum_arrival + 1)
        for residual in residuals
    ) / float(support_width)


def concept_value(
    *,
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
    baseline_action: Optional[int],
    candidate_action: Optional[int],
) -> float:
    """Usable residual-option mass gained by B relative to Best-Fit action A.

    The benchmark's admissible online arrival support is part of the problem
    statement. No future item or terminal label is read. ``item_index`` and
    ``history`` are accepted to make the online interface explicit, but this
    first concept predicts that the mechanism is distributional rather than
    trajectory-phase dependent.
    """

    del item_index, history
    scale = capacity / 150.0
    minimum_arrival = max(1, int(round(20 * scale)))
    maximum_arrival = max(minimum_arrival, int(round(100 * scale)))
    baseline_residuals = _successor_residuals(
        item, loads, capacity, baseline_action
    )
    candidate_residuals = _successor_residuals(
        item, loads, capacity, candidate_action
    )
    return _admissible_mass(
        candidate_residuals,
        minimum_arrival=minimum_arrival,
        maximum_arrival=maximum_arrival,
    ) - _admissible_mass(
        baseline_residuals,
        minimum_arrival=minimum_arrival,
        maximum_arrival=maximum_arrival,
    )
