from __future__ import annotations

import hashlib
import json
import math
import random
from typing import Callable, Dict, Iterable, List, Sequence, Tuple

from scientist.domains.binpacking.models import BinPackingInstance


Generator = Callable[[random.Random, int, int], Sequence[int]]


def _uniform(rng: random.Random, length: int, capacity: int) -> Sequence[int]:
    return [rng.randint(1, capacity) for _ in range(length)]


def _small_heavy(rng: random.Random, length: int, capacity: int) -> Sequence[int]:
    upper = max(2, capacity // 3)
    return [
        rng.randint(1, upper)
        if rng.random() < 0.8
        else rng.randint(upper + 1, capacity)
        for _ in range(length)
    ]


def _bimodal(rng: random.Random, length: int, capacity: int) -> Sequence[int]:
    low = (max(1, capacity // 10), max(2, capacity // 3))
    high = (max(low[1] + 1, 2 * capacity // 3), capacity)
    return [
        rng.randint(*(low if rng.random() < 0.5 else high))
        for _ in range(length)
    ]


def _near_half(rng: random.Random, length: int, capacity: int) -> Sequence[int]:
    radius = max(2, capacity // 12)
    midpoint = capacity // 2
    return [
        max(1, min(capacity, midpoint + rng.randint(-radius, radius)))
        for _ in range(length)
    ]


def _complementary_pairs(
    rng: random.Random, length: int, capacity: int
) -> Sequence[int]:
    items: List[int] = []
    while len(items) < length:
        first = rng.randint(max(1, capacity // 5), max(1, capacity // 2))
        jitter = rng.choice((-2, -1, 0, 0, 0, 1, 2))
        second = max(1, min(capacity, capacity - first + jitter))
        pair = [first, second]
        rng.shuffle(pair)
        items.extend(pair)
    rng.shuffle(items)
    return items[:length]


def _near_triplets(
    rng: random.Random, length: int, capacity: int
) -> Sequence[int]:
    items: List[int] = []
    while len(items) < length:
        first = rng.randint(max(1, capacity // 8), max(1, capacity // 2))
        second_max = max(1, capacity - first - 1)
        second = rng.randint(1, second_max)
        jitter = rng.choice((-2, -1, 0, 0, 0, 1, 2))
        third = max(1, min(capacity, capacity - first - second + jitter))
        triple = [first, second, third]
        rng.shuffle(triple)
        items.extend(triple)
    rng.shuffle(items)
    return items[:length]


def _or_uniform(
    rng: random.Random,
    length: int,
    capacity: int,
) -> Sequence[int]:
    """OR-Library-style distribution used in the FunSearch study.

    The original benchmark samples integer sizes from [20, 100] with capacity
    150. Fractions preserve that contract when another capacity is requested.
    """
    lower = max(1, int(math.ceil(capacity * (20.0 / 150.0))))
    upper = max(lower, int(math.floor(capacity * (100.0 / 150.0))))
    return [rng.randint(lower, upper) for _ in range(length)]


GENERATORS: Dict[str, Generator] = {
    "uniform": _uniform,
    "small_heavy": _small_heavy,
    "bimodal": _bimodal,
    "near_half": _near_half,
    "complementary_pairs": _complementary_pairs,
    "near_triplets": _near_triplets,
    "or_uniform": _or_uniform,
}


def generate_instance(
    family: str,
    seed: int,
    length: int,
    capacity: int = 100,
) -> BinPackingInstance:
    if family not in GENERATORS:
        raise KeyError("unknown instance family: %s" % family)
    if length <= 0:
        raise ValueError("length must be positive")

    rng = random.Random(seed)
    items = tuple(int(item) for item in GENERATORS[family](rng, length, capacity))
    identity_payload = json.dumps(
        {
            "generator_version": 1,
            "family": family,
            "seed": seed,
            "length": length,
            "capacity": capacity,
            "items": items,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    instance_id = hashlib.sha256(identity_payload).hexdigest()[:20]
    return BinPackingInstance(
        instance_id=instance_id,
        family=family,
        seed=seed,
        capacity=capacity,
        items=items,
    )


def generate_suite(
    families: Iterable[str],
    seeds: Iterable[int],
    length: int,
    capacity: int = 100,
) -> Tuple[BinPackingInstance, ...]:
    return tuple(
        generate_instance(family, seed, length, capacity)
        for family in families
        for seed in seeds
    )
