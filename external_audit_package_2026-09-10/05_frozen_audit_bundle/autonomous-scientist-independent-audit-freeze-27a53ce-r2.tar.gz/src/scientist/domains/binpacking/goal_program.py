from __future__ import annotations

import json
import random
from dataclasses import dataclass, replace
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.binpacking.adapter import BinPackingAdapter
from scientist.domains.binpacking.benchmark_conformance import (
    verify_funsearch_benchmark_conformance,
)
from scientist.domains.binpacking.causal_diagnostics import (
    CounterfactualStatus,
    DecisionCounterfactualTrace,
    trace_first_effective_decision,
)
from scientist.domains.binpacking.adversary import (
    AdversaryConfig,
    AdversaryOutcome,
    evolve_adversarial_sequences,
)
from scientist.domains.binpacking.equivalence import behaviour_fingerprint
from scientist.domains.binpacking.generators import (
    GENERATORS,
    generate_instance,
)
from scientist.domains.binpacking.heuristics import (
    FunctionalHeuristic,
    OnlineHeuristic,
    baseline_heuristics,
    literature_heuristics,
    pack,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.orlib import (
    corpus_digest,
    load_orlib_corpus,
    load_source_manifest,
    verify_orlib_files,
)
from scientist.domains.binpacking.programs import (
    ActionHybridProgram,
    CalibratedOverrideHybridProgram,
    CONTEXTUAL_FEATURES,
    DEMAND_MEMORY_FEATURES,
    REGIME_ROUTER_FEATURES,
    REGIME_ROUTER_POLICIES,
    ContextualLinearProgram,
    DemandMemoryProgram,
    Expression,
    FunSearchResidualProgram,
    MOONSHOT_PARAMETER_COUNT,
    MOONSHOT_TOPOLOGIES,
    MoonshotHybridProgram,
    MoonshotProgram,
    PriorityProgram,
    RegimeRouterProgram,
    StructuralHybridProgram,
    demand_memory_action_features,
    mutate_expression,
    program_from_dict,
    random_expression,
)
from scientist.domains.binpacking.override_value import (
    CausalStatePrototype,
    CalibratedOverrideValueModel,
    fit_calibrated_override_value_model,
)
from scientist.domains.binpacking.literature_ontology import (
    BINPACKING_LITERATURE_VOCABULARY,
)
from scientist.domains.binpacking.scientific_validation import (
    assess_composite_contribution,
    assess_semantic_novelty,
    reduced_mechanism_labels,
)
from scientist.kernel.contracts import (
    EvidencePartition,
    GateContract,
    GateCriterion,
    GateKind,
    MetricDirection,
    MetricSpec,
    SearchFamily,
)
from scientist.kernel.gates import GateDecision, evaluate_gate
from scientist.program.campaigns import (
    CampaignPlateauPolicy,
    CampaignRoundSummary,
    IncumbentEntry,
    IncumbentPortfolio,
    IncumbentRole,
    IslandCampaignContract,
    IslandCandidateProposal,
    ParentIntegrationRecord,
    default_information_views,
)
from scientist.program.causal_failure import (
    CausalDiscriminationAssessment,
    CausalFailureModel,
    CausalFailureModelSet,
    CausalRelationKind,
    CausalRole,
    assess_causal_discrimination,
)
from scientist.program.contracts import HighLevelGoal
from scientist.program.control_plane import (
    AutonomousScientistControlPlane,
    ControlAction,
    ControlActionKind,
    NodeSchedulingAssessment,
    RootUnresolvedReason,
)
from scientist.program.autonomous import (
    ActionDispatchResult,
    AutonomousGoalExecutive,
)
from scientist.program.goal_graph import (
    CompositionOperator,
    ExecutableLeafContract,
    GoalNodeKind,
    GoalNodeSpec,
    GoalNodeStatus,
    ParentCompositionRule,
)
from scientist.program.goal_graph_runtime import GoalGraphRuntime
from scientist.program.goal_graph_serialization import (
    tournament_hypothesis_from_dict,
)
from scientist.program.discovery_evidence import paired_episode_evidence
from scientist.program.inspiration import (
    CrossDomainInspiration,
    CrossDomainInspirationPortfolio,
    MechanismMapping,
    TransferEvaluation,
)
from scientist.program.hypothesis_tournament import (
    HypothesisOrigin,
    HypothesisReview,
    HypothesisTournament,
    TournamentHypothesis,
    run_hypothesis_tournament,
)
from scientist.program.executable_hypothesis import (
    CausalEvolutionOperator,
    ExecutableHypothesisContract,
    GeneratorPatch,
    HypothesisDiagnosticResult,
    InformationRegime,
)
from scientist.program.hypothesis_learning import (
    HypothesisEvolutionBasis,
    HypothesisFailureAssessment,
    HypothesisFailureKind,
    HypothesisPredictionProfile,
    MechanismSignature,
    classify_hypothesis_diagnostic,
)
from scientist.program.mechanism_discovery import (
    CatalogMechanismScout,
    MechanismCatalogEntry,
    MechanismDiscoveryQuery,
    MechanismDiscoveryTrace,
    SourceCausalMechanism,
)
from scientist.program.literature import (
    ClaimClassification,
    ClaimLevel,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
    evaluate_claim_authorization,
)
from scientist.program.literature_grounding import (
    LiteratureHypothesisContext,
    build_literature_hypothesis_context,
)
from scientist.program.web_literature import (
    LiveWebPriorArtReviewer,
    default_live_web_reviewer,
)
from scientist.search.islands import (
    IslandCandidateRecord,
    IslandSearchConfig,
    IslandSearchOutcome,
    Proposal,
    StructuredEvolutionProposer,
    run_island_search,
)


BINPACKING_GOAL_PROGRAM_VERSION = "binpacking-goal-program-v21"
RESEARCH_GOAL = (
    "Autonomous Discovery of Superior Heuristics for bin packing via "
    "Iterative Code Evolution."
)
FUNSEARCH_WORK_ID = "doi:10.1038/s41586-023-06924-6"
SCIENTIFIC_METHOD_PRIORS = (
    {
        "lesson_id": "hybrid-parent-credit-v1",
        "claim_constraint": (
            "A composed policy receives mechanism credit only when the full "
            "composition beats its strongest parent ablation and the added "
            "module changes preregistered same-state actions."
        ),
        "reentry_condition": (
            "new component-level evidence satisfies the contribution gate"
        ),
    },
    {
        "lesson_id": "semantic-exact-fill-family-v1",
        "claim_constraint": (
            "Integer-domain threshold variants that act only at zero residual "
            "belong to the established exact-fill mechanism family."
        ),
        "reentry_condition": (
            "a non-exact-fill reduced mechanism makes a distinguishing "
            "prediction and survives semantic controls"
        ),
    },
    {
        "lesson_id": "history-demand-mediator-v1",
        "claim_constraint": (
            "A history-derived demand or reservation story is unsupported "
            "unless the compiled action engages its proposed mediator and "
            "beats matched target and control replays."
        ),
        "reentry_condition": (
            "the causal assumption, executable intervention, and "
            "distinguishing prediction all change"
        ),
    },
    {
        "lesson_id": "trajectory-interaction-credit-v5",
        "claim_constraint": (
            "A learned override may use suffix outcomes only as labels. "
            "Every alternative must be compared with the ancestry action "
            "in the same state; outcome-equivalent pairs produce no "
            "gradient, strict improvements earn positive margins, and "
            "strict regressions earn negative margins. "
            "Intervention authorization must be selected from complete "
            "episode returns on a dedicated policy-fit partition, be "
            "conditioned on preregistered causal-state prototypes, and be "
            "tested once as a frozen policy on an independent gate. "
            "A bounded intervention sequence must be rerun over its complete "
            "subset lattice; leave-one-intervention-out marginal credit and "
            "pairwise interaction credit must train only observable sequence "
            "features on action-fit instances. "
            "Its labels and calibration must evaluate the deployed "
            "closed-loop intervention policy; action fitting, action-model "
            "selection, instance-clustered gate calibration, and outer "
            "outcome evaluation must use disjoint instance sets."
        ),
        "reentry_condition": (
            "a budgeted sequence-aware model passes policy-fit and frozen-"
            "gate episode returns with intervention- and instance-level "
            "leave-one-out stability, "
            "leakage checks, and parent-relative audit attribution"
        ),
    },
)


@dataclass(frozen=True)
class BinPackingGoalRunConfig:
    rounds: int = 4
    candidate_budget_per_island: int = 24
    initial_random_candidates: int = 6
    adversary_budget_per_round: int = 48
    adversary_initial_population: int = 12
    repair_case_count: int = 12
    override_training_case_count: int = 30
    override_trace_decisions_per_instance: int = 32
    guard_cases_per_length: int = 4
    audit_cases_per_length: int = 8
    replication_cases_per_length: int = 80
    integration_cases_per_family: int = 20
    audit_nominees_per_island: int = 3
    capacity: int = 150
    development_length: int = 120
    validation_lengths: Tuple[int, ...] = (120, 250, 500)
    base_seed: int = 30_072_026
    residual_scale: float = 0.10
    minimum_module_action_disagreement_rate: float = 0.001
    minimum_module_action_disagreements: int = 2
    require_web_literature: bool = True
    literature_timeout_seconds: float = 20.0
    literature_results_per_query: int = 6
    isolation_rounds: int = 1

    def __post_init__(self) -> None:
        counts = (
            self.rounds,
            self.candidate_budget_per_island,
            self.initial_random_candidates,
            self.adversary_budget_per_round,
            self.adversary_initial_population,
            self.repair_case_count,
            self.override_trace_decisions_per_instance,
            self.guard_cases_per_length,
            self.audit_cases_per_length,
            self.replication_cases_per_length,
            self.integration_cases_per_family,
            self.audit_nominees_per_island,
            self.capacity,
            self.development_length,
        )
        if min(counts) <= 0:
            raise ValueError("bin-packing goal-run counts must be positive")
        if self.override_training_case_count < 0:
            raise ValueError(
                "override training case count cannot be negative"
            )
        if 0 < self.override_training_case_count < 12:
            raise ValueError(
                "episode transport requires at least twelve override cases"
            )
        if (
            self.adversary_initial_population
            > self.adversary_budget_per_round
        ):
            raise ValueError(
                "adversary initial population exceeds its budget"
            )
        if self.isolation_rounds < 0:
            raise ValueError("isolation rounds must be non-negative")
        if self.isolation_rounds > 0 and self.rounds < 2:
            raise ValueError(
                "v2 isolation requires at least two campaign rounds"
            )
        if not self.validation_lengths:
            raise ValueError("validation lengths must not be empty")
        if self.residual_scale <= 0.0:
            raise ValueError("residual scale must be positive")
        if not 0.0 <= self.minimum_module_action_disagreement_rate <= 1.0:
            raise ValueError(
                "module action-disagreement rate must be in [0, 1]"
            )
        if self.minimum_module_action_disagreements <= 0:
            raise ValueError(
                "minimum module action disagreements must be positive"
            )
        if self.literature_timeout_seconds <= 0.0:
            raise ValueError("literature timeout must be positive")
        if self.literature_results_per_query <= 0:
            raise ValueError(
                "literature result count must be positive"
            )

    @property
    def audit_evidence_count(self) -> int:
        return self.audit_cases_per_length * len(self.validation_lengths)

    @property
    def replication_evidence_count(self) -> int:
        return (
            self.replication_cases_per_length
            * len(self.validation_lengths)
        )

    @property
    def maximum_search_compute(self) -> float:
        isolated_rounds = min(self.rounds, self.isolation_rounds)
        return float(
            (
                isolated_rounds * 2
                + (self.rounds - isolated_rounds) * 3
            )
            * self.candidate_budget_per_island
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "rounds": self.rounds,
            "candidate_budget_per_island": (
                self.candidate_budget_per_island
            ),
            "initial_random_candidates": self.initial_random_candidates,
            "adversary_budget_per_round": (
                self.adversary_budget_per_round
            ),
            "adversary_initial_population": (
                self.adversary_initial_population
            ),
            "repair_case_count": self.repair_case_count,
            "override_training_case_count": (
                self.override_training_case_count
            ),
            "override_trace_decisions_per_instance": (
                self.override_trace_decisions_per_instance
            ),
            "guard_cases_per_length": self.guard_cases_per_length,
            "audit_cases_per_length": self.audit_cases_per_length,
            "replication_cases_per_length": (
                self.replication_cases_per_length
            ),
            "integration_cases_per_family": (
                self.integration_cases_per_family
            ),
            "audit_nominees_per_island": (
                self.audit_nominees_per_island
            ),
            "capacity": self.capacity,
            "development_length": self.development_length,
            "validation_lengths": list(self.validation_lengths),
            "base_seed": self.base_seed,
            "residual_scale": self.residual_scale,
            "minimum_module_action_disagreement_rate": (
                self.minimum_module_action_disagreement_rate
            ),
            "minimum_module_action_disagreements": (
                self.minimum_module_action_disagreements
            ),
            "require_web_literature": self.require_web_literature,
            "literature_timeout_seconds": (
                self.literature_timeout_seconds
            ),
            "literature_results_per_query": (
                self.literature_results_per_query
            ),
            "isolation_rounds": self.isolation_rounds,
            "maximum_search_compute": self.maximum_search_compute,
        }


def _primary_metric() -> MetricSpec:
    return MetricSpec(
        name="primary_delta",
        direction=MetricDirection.MINIMIZE,
        unit="bins",
        aggregation="paired sum candidate minus published incumbent",
        primary=True,
    )


def high_level_goal(config: BinPackingGoalRunConfig) -> HighLevelGoal:
    return HighLevelGoal(
        name=RESEARCH_GOAL,
        outcome=(
            "Discover a deterministic online one-dimensional bin-packing "
            "program that is behaviorally distinct from preregistered prior "
            "mechanisms and uses fewer bins than the strongest executable "
            "published incumbent on generated replication and the official "
            "OR-Library corpus."
        ),
        scope=(
            "online irrevocable one-dimensional integer bin packing",
            "capacity 150 with OR-style and declared distribution shifts",
            "typed executable priority programs",
            "paired evaluation against a reproduced published incumbent",
        ),
        anti_scope=(
            "offline item reordering or look-ahead",
            "multi-dimensional or variable-sized bins",
            "reuse of any previous Scientist execution artifact",
            "rediscovery of best-fit, exact-fill, or published tight-fit behavior",
            "claims beyond measured distributions and scales",
        ),
        terminal_metrics=(
            _primary_metric(),
            MetricSpec(
                name="maximum_regression",
                direction=MetricDirection.MINIMIZE,
                unit="bins",
                aggregation="maximum paired instance regression",
            ),
        ),
        success_definition=(
            "A frozen candidate passes component-level causal ablation, "
            "semantic mechanism reduction, candidate-specific literature "
            "closure, independent generated replication, immediate "
            "distribution-shift integration, and a preregistered public-claim "
            "gate on checksummed OR-Library instances."
        ),
        failure_conditions=(
            "no candidate passes the frozen replication gate",
            "a composed candidate does not beat its strongest parent ablation",
            "the candidate reduces to a preregistered prior mechanism family",
            "the generated improvement fails under distribution shift",
            "the external paired bin delta is non-negative",
        ),
        integration_requirements=(
            "candidate has a measured causal contribution beyond its strongest parent",
            "candidate is semantically distinct from preregistered published mechanisms",
            "candidate-specific relational prior-art review supports scientific novelty",
            "independent generated replication beats the executable published incumbent",
            "external OR-Library confirmation passes the frozen root gate",
        ),
        total_compute_budget=max(
            1_200.0,
            config.maximum_search_compute + 600.0,
        ),
        max_parallel_campaigns=1,
        risk_tier="research_only",
    )


def goal_nodes(
    goal: HighLevelGoal,
    config: BinPackingGoalRunConfig,
) -> Tuple[GoalNodeSpec, GoalNodeSpec, GoalNodeSpec]:
    root = GoalNodeSpec(
        goal_id=goal.goal_id,
        title=RESEARCH_GOAL,
        question=(
            "Can iterative code evolution produce a prior-art-distinct online "
            "bin-packing heuristic that beats the published executable "
            "incumbent end to end?"
        ),
        kind=GoalNodeKind.ROOT,
        rationale=(
            "This is the user-specified outcome; only external end-to-end "
            "evidence can resolve it."
        ),
        success_conditions=(
            "the frozen causal, semantic, literature, and external public-claim gates pass",
            "every causal integration edge passes",
        ),
        falsification_conditions=goal.failure_conditions,
        expected_artifact="root resolution certificate",
        critical=True,
        tags=("bin-packing", "iterative-code-evolution", "root"),
    )
    capability = GoalNodeSpec(
        goal_id=goal.goal_id,
        title="Generalizable novel online placement policy",
        question=(
            "Does a newly evolved placement mechanism improve beyond the "
            "published incumbent across distribution shifts?"
        ),
        kind=GoalNodeKind.CAPABILITY,
        rationale=(
            "Local search performance is only useful if the frozen policy "
            "transfers across generated families before external confirmation."
        ),
        success_conditions=(
            "a locally replicated candidate improves the preregistered shift suite",
            "the full candidate beats its strongest parent ablation",
            "no disallowed prior-art semantic duplicate is promoted",
        ),
        falsification_conditions=(
            "the candidate regresses on the shift suite",
            "the candidate duplicates or reduces to a preregistered mechanism",
            "the added module does not change or improve decisions",
        ),
        expected_artifact="independently verified distribution-shift integration",
        critical=True,
        tags=("generalization", "novelty-firewall"),
    )
    leaf_contract = ExecutableLeafContract(
        hypothesis=(
            "Matched isolated ancestry and genuinely de-novo code evolution, "
            "followed by delayed cross-island recombination, can produce a "
            "non-duplicate policy with negative paired bin delta."
        ),
        parent_decision=(
            "freeze the candidate for multi-distribution integration"
        ),
        root_metric_link=(
            "candidate-minus-incumbent paired bin count feeds the root metric"
        ),
        metric=_primary_metric(),
        success_conditions=(
            "the frozen replication aggregate primary_delta is negative",
            "maximum per-instance regression is at most one bin",
            "the preregistered semantic novelty probe finds no known-family equivalent",
            "every hybrid beats its strongest parent and intervenes on actions",
        ),
        falsification_conditions=(
            "replication aggregate primary_delta is non-negative",
            "independent packing verification fails",
            "the candidate matches a prior-art behavior fingerprint",
        ),
        testbed_ref="binpacking-adapter-v1",
        parent_integration_test=(
            "frozen multi-family generated shift suite v1"
        ),
        experiment_budget=max(
            900.0,
            config.maximum_search_compute + 300.0,
        ),
        preregistration_ref=(
            "binpacking-v2-clean-preregistration-2026-07-30"
        ),
    )
    leaf = GoalNodeSpec(
        goal_id=goal.goal_id,
        title="Isolated iterative code-evolution campaign",
        question=(
            "Which executable priority program survives matched development, "
            "guard, audit, novelty, and replication gates?"
        ),
        kind=GoalNodeKind.EXECUTABLE_LEAF,
        rationale=(
            "This is the first falsifiable executable boundary. Search cannot "
            "observe prior run artifacts or sequestered evidence."
        ),
        success_conditions=leaf_contract.success_conditions,
        falsification_conditions=leaf_contract.falsification_conditions,
        expected_artifact="frozen executable candidate and verified evidence",
        critical=True,
        leaf_contract=leaf_contract,
        tags=("three-island", "clean-run", "executable"),
    )
    return root, capability, leaf


def _literature_queries(
    mechanism_terms: Sequence[str] = (),
) -> Tuple[LiteratureQuery, ...]:
    base = (
        LiteratureQuery(
            query="online one dimensional bin packing algorithms",
            facet=SearchFacet.PROBLEM,
            provider="arXiv",
        ),
        LiteratureQuery(
            query="program search online bin packing FunSearch",
            facet=SearchFacet.INTERVENTION,
            provider="Nature",
        ),
        LiteratureQuery(
            query="evolutionary heuristic generation online bin packing",
            facet=SearchFacet.MECHANISM,
            provider="ACM Digital Library",
        ),
        LiteratureQuery(
            query="LLM automatic heuristic design online bin packing",
            facet=SearchFacet.INTERVENTION,
            provider="OpenReview",
        ),
        LiteratureQuery(
            query="online bin packing OR-Library evaluation FunSearch",
            facet=SearchFacet.EVALUATION,
            provider="Nature",
        ),
        LiteratureQuery(
            query="citations FunSearch EoH policy matrix online bin packing",
            facet=SearchFacet.CITATION_NEIGHBORHOOD,
            provider="Crossref",
        ),
        LiteratureQuery(
            query=(
                "online bin packing learning augmented algorithms "
                "predictions robustness"
            ),
            facet=SearchFacet.MECHANISM,
            provider="Google Scholar",
        ),
        LiteratureQuery(
            query=(
                "model predictive control irreversible decisions "
                "uncertainty scenario rollout"
            ),
            facet=SearchFacet.MECHANISM,
            provider="Semantic Scholar",
        ),
        LiteratureQuery(
            query=(
                "complete episode return policy selection nested validation "
                "safe policy improvement causal state abstraction"
            ),
            facet=SearchFacet.MECHANISM,
            provider="Semantic Scholar",
        ),
        LiteratureQuery(
            query=(
                "multi-agent credit assignment difference rewards "
                "reinforcement learning"
            ),
            facet=SearchFacet.MECHANISM,
            provider="Semantic Scholar",
        ),
        LiteratureQuery(
            query=(
                "safe policy improvement baseline bootstrapping "
                "abstention counterfactual"
            ),
            facet=SearchFacet.MECHANISM,
            provider="Google Scholar",
        ),
        LiteratureQuery(
            query=(
                "offline policy improvement counterfactual action value "
                "selective prediction calibration"
            ),
            facet=SearchFacet.MECHANISM,
            provider="Semantic Scholar",
        ),
        LiteratureQuery(
            query=(
                "learning to defer confidence calibration distribution "
                "shift safe intervention"
            ),
            facet=SearchFacet.MECHANISM,
            provider="Google Scholar",
        ),
        LiteratureQuery(
            query=(
                "pairwise advantage learning baseline policy safe "
                "improvement counterfactual"
            ),
            facet=SearchFacet.MECHANISM,
            provider="Semantic Scholar",
        ),
    )
    candidate_queries = tuple(
        LiteratureQuery(
            query="online bin packing %s" % term.replace("_", " "),
            facet=SearchFacet.MECHANISM,
            provider=provider,
        )
        for term in mechanism_terms
        for provider in ("Google Scholar", "Semantic Scholar")
    )
    return (*base, *candidate_queries)


def _closest_works() -> Tuple[PriorWork, ...]:
    return (
        PriorWork(
            work_id=FUNSEARCH_WORK_ID,
            title=(
                "Mathematical discoveries from program search with large "
                "language models"
            ),
            year=2023,
            locator="https://doi.org/10.1038/s41586-023-06924-6",
            relation=PriorArtRelation.EXECUTABLE_BASELINE,
            matched_components=(
                "online bin packing",
                "program evolution",
                "priority function",
                "OR-Library evaluation",
                "tight-fit mechanism",
            ),
            executable=True,
        ),
        PriorWork(
            work_id="doi:10.1145/2001576.2001846",
            title="Policy Matrix Evolution for Generation of Heuristics",
            year=2011,
            locator="https://doi.org/10.1145/2001576.2001846",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "online bin packing",
                "genetic evolution",
                "placement score policy",
            ),
        ),
        PriorWork(
            work_id="doi:10.1016/j.eswa.2016.07.005",
            title=(
                "CHAMP: Creating Heuristics via Many Parameters for Online "
                "Bin Packing"
            ),
            year=2016,
            locator="https://doi.org/10.1016/j.eswa.2016.07.005",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "online bin packing",
                "automatic heuristic generation",
                "parameterized score matrix",
            ),
        ),
        PriorWork(
            work_id="arxiv:1707.01728",
            title="A new and improved algorithm for online bin packing",
            year=2018,
            locator="https://arxiv.org/abs/1707.01728",
            relation=PriorArtRelation.ADJACENT,
            matched_components=(
                "online bin packing",
                "exact item sizes",
                "worst-case competitive ratio",
            ),
        ),
        PriorWork(
            work_id="openreview:negdAvLDvE",
            title=(
                "An Example of Evolutionary Computation + Large Language "
                "Model Beating Human"
            ),
            year=2024,
            locator="https://openreview.net/forum?id=negdAvLDvE",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "online bin packing",
                "evolution of heuristics",
                "executable code",
            ),
        ),
        PriorWork(
            work_id="openreview:teUg2pMrF0",
            title=(
                "Large Language Model-driven Large Neighborhood Search for "
                "Large-Scale MILP Problems"
            ),
            year=2026,
            locator="https://openreview.net/pdf?id=teUg2pMrF0",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "automatic heuristic design",
                "online bin packing comparison",
                "Weibull distribution evaluation",
            ),
        ),
        PriorWork(
            work_id="ijcai:2022/635",
            title="Online Bin Packing with Predictions",
            year=2022,
            locator=(
                "https://www.ijcai.org/proceedings/2022/0635.pdf"
            ),
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "predicted item-frequency profile",
                "packing-pattern reservation",
                "robust fallback policy",
                "source profile maps to residual opportunity targets",
                "distinguishing prediction: endogenous history should lag "
                "after abrupt distribution shifts",
            ),
        ),
        PriorWork(
            work_id="doi:10.3390/sym14071301",
            title=(
                "Identify Patterns in Online Bin Packing Problem: An "
                "Adaptive Pattern-Based Algorithm"
            ),
            year=2022,
            locator="https://doi.org/10.3390/sym14071301",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "historical item-distribution estimation",
                "packing-pattern quotas",
                "Best-Fit fallback",
                "history maps to candidate demand memory",
                "broken assumption: explicit patterns versus local score",
            ),
        ),
        PriorWork(
            work_id="url:eswa24-fuzzy-pattern-bin-selector",
            title=(
                "A Pattern-Based Algorithm with Fuzzy Logic Bin Selector "
                "for Online Bin Packing Problem"
            ),
            year=2024,
            locator=(
                "https://people.cs.nott.ac.uk/pszrq/files/ESWA24.pdf"
            ),
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "history-derived packing patterns",
                "state-dependent selector",
                "robust fallback bin population",
                "selector maps to failure-syndrome gate",
                "broken assumption: explicit pattern state versus local "
                "activation",
            ),
        ),
    )


def _work_relevant_to_mechanism(
    work: PriorWork,
    labels: Sequence[str],
) -> bool:
    text = " ".join(
        (
            work.title,
            *work.matched_components,
        )
    ).lower()
    for label in labels:
        normalized = label.replace("_", " ").lower()
        if "exact fill" in normalized or "funsearch residual" in normalized:
            if any(
                term in text
                for term in ("tight-fit", "funsearch", "priority function")
            ):
                return True
        elif any(
            term in normalized
            for term in ("demand", "history", "portfolio", "complement")
        ):
            if any(
                term in text
                for term in ("profile", "pattern", "history", "frequency")
            ):
                return True
        elif any(
            term in normalized
            for term in ("contextual", "policy", "router", "bin role")
        ):
            if any(
                term in text
                for term in (
                    "policy",
                    "parameterized score",
                    "state-dependent selector",
                )
            ):
                return True
        elif any(
            term in normalized
            for term in (
                "counterfactual",
                "rollout",
                "regret",
                "abstain",
            )
        ):
            if any(
                term in text
                for term in (
                    "prediction",
                    "robust fallback",
                    "alternative action",
                    "lookahead",
                    "rollout",
                    "counterfactual",
                )
            ):
                return True
    return False


def _candidate_closest_works(
    labels: Sequence[str],
) -> Tuple[PriorWork, ...]:
    works = _closest_works()
    if not labels:
        return works
    incumbent = next(
        work for work in works if work.work_id == FUNSEARCH_WORK_ID
    )
    relevant = tuple(
        work
        for work in works
        if work.work_id != FUNSEARCH_WORK_ID
        and _work_relevant_to_mechanism(work, labels)
    )
    return (incumbent, *relevant)


def _mechanism_literature_coverage_complete(
    labels: Sequence[str],
    works: Sequence[PriorWork],
) -> bool:
    return bool(labels) and all(
        any(
            _work_relevant_to_mechanism(work, (label,))
            for work in works
        )
        for label in labels
    )


def literature_assessment(
    node: GoalNodeSpec,
    *,
    trigger: LiteratureTrigger = LiteratureTrigger.INITIAL_SCOPE,
    candidate_delta: Optional[str] = None,
    mechanism_review: Optional[Mapping[str, Any]] = None,
) -> PriorArtAssessment:
    mechanism_review = dict(mechanism_review or {})
    labels = tuple(
        str(value)
        for value in mechanism_review.get(
            "reduced_mechanism_labels",
            (),
        )
    )
    known_matches = tuple(
        str(value)
        for value in mechanism_review.get("known_family_matches", ())
    )
    contribution_passed = bool(
        mechanism_review.get("causal_contribution_passed", False)
    )
    contribution_applicable = bool(
        mechanism_review.get("causal_contribution_applicable", False)
    )
    semantic_novelty_passed = bool(
        mechanism_review.get("semantic_novelty_passed", False)
    )
    known_reduction = bool(known_matches) or (
        any("exact_fill" in label for label in labels)
        and (
            not semantic_novelty_passed
            or not contribution_applicable
            or not contribution_passed
        )
    )
    if candidate_delta is None:
        classification = ClaimClassification.NOVEL_CANDIDATE
        delta = (
            "search uses delayed isolated cross-island recombination",
            "promotion excludes behavioral duplicates of published mechanisms",
            "claims require generated and external end-to-end gates",
        )
    elif known_reduction:
        classification = ClaimClassification.REDISCOVERY
        delta = ()
    elif not contribution_passed:
        classification = ClaimClassification.REPRODUCTION
        delta = ()
    else:
        classification = ClaimClassification.NOVEL_CANDIDATE
        delta = (
            candidate_delta,
            "full composition beats its strongest parent ablation",
            "same-state action interventions exceed the preregistered minimum",
            "reduced mechanism is distinct from registered semantic controls",
        )
    closest_works = _candidate_closest_works(labels)
    literature_coverage_complete = (
        True
        if candidate_delta is None
        else _mechanism_literature_coverage_complete(
            labels,
            closest_works,
        )
    )
    return PriorArtAssessment(
        signature=ClaimSignature(
            subject_id=node.node_id,
            statement=node.question,
            problem="online one-dimensional bin packing",
            phenomenon=(
                "distribution-specific waste caused by irrevocable placement"
            ),
            intervention=(
                "iterative typed code evolution with isolated search families"
            ),
            mechanism=(
                "; ".join(labels)
                if labels
                else (
                    "history-aware placement scoring outside exact-fill and "
                    "published tight-fit behavior"
                )
            ),
            evaluation=(
                "paired generated replication and checksummed OR-Library "
                "external confirmation"
            ),
        ),
        trigger=trigger,
        queries=_literature_queries(labels),
        closest_works=closest_works,
        classification=classification,
        rationale=(
            (
                "The executable reduces to a registered exact-fill or known "
                "policy family and is classified as rediscovery regardless "
                "of its surface topology."
                if known_reduction
                else (
                    "The proposed component did not add a parent-relative "
                    "causal contribution, so its conceptual mechanism cannot "
                    "be advanced."
                    if candidate_delta is not None
                    and not contribution_passed
                    else (
                        "FunSearch remains the strongest matching executable "
                        "baseline in this repository. Candidate-specific "
                        "mechanism queries and relationally mapped prediction, "
                        "pattern, fallback, and automatic-design work were "
                        "included in the novelty closure."
                    )
                )
            )
        ),
        novel_delta=delta,
        citation_snowball_complete=literature_coverage_complete,
        searched_at="2026-07-31",
        reviewer_ref=(
            "candidate-reduced-mechanism-relational-prior-art-review-v3"
        ),
        executable_incumbent_id=FUNSEARCH_WORK_ID,
    )


def contextual_literature_assessment(
    node: GoalNodeSpec,
) -> PriorArtAssessment:
    return PriorArtAssessment(
        signature=ClaimSignature(
            subject_id=node.node_id,
            statement=node.question,
            problem="online one-dimensional bin packing",
            phenomenon=(
                "audit-local sequence-regime gains that reverse under "
                "multiscale replication"
            ),
            intervention=(
                "contextual linear policy evolution over recent-window and "
                "load-distribution features"
            ),
            mechanism=(
                "smooth state-conditioned action scoring rather than a "
                "single symbolic expression tree"
            ),
            evaluation=(
                "matched isolated search, frozen multiscale replication, "
                "generated shifts, and checksummed OR-Library confirmation"
            ),
        ),
        trigger=LiteratureTrigger.NEW_INTERVENTION,
        queries=(
            *_literature_queries(),
            LiteratureQuery(
                query=(
                    "contextual linear hyper-heuristic online bin packing "
                    "recent sequence load distribution"
                ),
                facet=SearchFacet.MECHANISM,
                provider="Google Scholar",
            ),
        ),
        closest_works=_closest_works(),
        classification=ClaimClassification.NOVEL_CANDIDATE,
        rationale=(
            "The plateau evidence rejects the audit-local symbolic finalist. "
            "Policy-matrix and automatic heuristic-generation work overlap "
            "with linear action scoring, so they remain explicit prior-art "
            "constraints. The revised delta is the use of rolling sequence "
            "and global load-distribution state under the existing frozen "
            "end-to-end gates; behavioral distinction alone will not be "
            "reported as conceptual novelty."
        ),
        novel_delta=(
            "rolling recent-window state is directly represented",
            "global load-distribution moments condition each action",
            "the symbolic expression-tree representation is removed",
            "the failed finalist and exact-fill behaviors remain exclusions",
        ),
        citation_snowball_complete=True,
        searched_at="2026-07-30",
        reviewer_ref="plateau-triggered-prior-art-review-v1",
        executable_incumbent_id=FUNSEARCH_WORK_ID,
    )


def regime_router_literature_assessment(
    node: GoalNodeSpec,
) -> PriorArtAssessment:
    return PriorArtAssessment(
        signature=ClaimSignature(
            subject_id=node.node_id,
            statement=node.question,
            problem="online one-dimensional bin packing",
            phenomenon=(
                "contextual action scores collapsing to exact-fill or a "
                "single published placement policy"
            ),
            intervention=(
                "online state-conditioned routing among complete, "
                "independently executable placement policies"
            ),
            mechanism=(
                "a policy-level regime decision before placement, rather "
                "than another per-bin action score"
            ),
            evaluation=(
                "isolated portfolio-router evolution, behavioral prior-art "
                "exclusion, frozen multiscale replication, generated shifts, "
                "and checksummed OR-Library confirmation"
            ),
        ),
        trigger=LiteratureTrigger.NEW_INTERVENTION,
        queries=(
            *_literature_queries(),
            LiteratureQuery(
                query=(
                    "selection hyper-heuristic policy portfolio online bin "
                    "packing state conditioned routing"
                ),
                facet=SearchFacet.MECHANISM,
                provider="Google Scholar",
            ),
        ),
        closest_works=_closest_works(),
        classification=ClaimClassification.NOVEL_CANDIDATE,
        rationale=(
            "The contextual-linear revision repeatedly rediscovered "
            "exact-fill behavior, which is already excluded. Selection "
            "hyper-heuristics and policy-matrix methods overlap with policy "
            "choice, so the campaign makes no conceptual-novelty claim from "
            "routing alone. Its testable delta is online routing among frozen "
            "complete policies using sequence and load-regime state, subject "
            "to the same behavioral novelty and replication gates."
        ),
        novel_delta=(
            "the unit of evolution is a state-conditioned policy router",
            "each routed policy remains a complete executable heuristic",
            "pure FunSearch, Best Fit, First Fit, Worst Fit, Next Fit, and "
            "exact-fill behavior remain preregistered exclusions",
            "the failed contextual action-score representation is removed",
        ),
        citation_snowball_complete=True,
        searched_at="2026-07-30",
        reviewer_ref="plateau-triggered-policy-router-review-v1",
        executable_incumbent_id=FUNSEARCH_WORK_ID,
    )


def demand_memory_literature_assessment(
    node: GoalNodeSpec,
) -> PriorArtAssessment:
    return PriorArtAssessment(
        signature=ClaimSignature(
            subject_id=node.node_id,
            statement=node.question,
            problem="online one-dimensional bin packing",
            phenomenon=(
                "policy routers collapsing to the incumbent while novel "
                "pure-policy routes incur large regressions"
            ),
            intervention=(
                "empirical recent-demand memory embedded in placement scoring"
            ),
            mechanism=(
                "preserve or create residual capacities according to a "
                "causal estimate of near-future complement demand"
            ),
            evaluation=(
                "isolated fixed-budget evolution, behavioral prior-art "
                "exclusion, frozen multiscale replication, generated shifts, "
                "and checksummed OR-Library confirmation"
            ),
        ),
        trigger=LiteratureTrigger.NEW_INTERVENTION,
        queries=(
            *_literature_queries(),
            LiteratureQuery(
                query=(
                    "online bin packing empirical demand distribution "
                    "complement frequency residual capacity heuristic"
                ),
                facet=SearchFacet.MECHANISM,
                provider="Google Scholar",
            ),
        ),
        closest_works=_closest_works(),
        classification=ClaimClassification.NOVEL_CANDIDATE,
        rationale=(
            "The policy-router campaign showed that switching among complete "
            "policies either reproduced FunSearch or introduced large audit "
            "regressions. The final bounded revision therefore targets the "
            "missing action-level signal directly: empirical demand for each "
            "post-placement residual capacity. Related hyper-heuristic and "
            "policy-matrix work remains an explicit novelty constraint."
        ),
        novel_delta=(
            "recent arrivals define a kernel estimate over demanded residuals",
            "candidate actions expose complement frequency and slot-preservation",
            "the representation is neither a symbolic tree nor a policy router",
            "known pure policies and exact-fill behavior remain exclusions",
        ),
        citation_snowball_complete=True,
        searched_at="2026-07-30",
        reviewer_ref="plateau-triggered-demand-memory-review-v1",
        executable_incumbent_id=FUNSEARCH_WORK_ID,
    )


def build_control_plane(
    config: BinPackingGoalRunConfig,
    *,
    artifact_store: Optional[ArtifactStore] = None,
) -> AutonomousScientistControlPlane:
    goal = high_level_goal(config)
    root, _, _ = goal_nodes(goal, config)
    return AutonomousScientistControlPlane(
        goal,
        root,
        artifact_store=artifact_store,
        controller_ref=BINPACKING_GOAL_PROGRAM_VERSION,
    )


_MOONSHOT_PARAMETER_STEPS = (
    -1.0,
    -0.5,
    -0.25,
    0.25,
    0.5,
    1.0,
)


def _random_moonshot_parameters(
    rng: random.Random,
) -> Tuple[float, ...]:
    return tuple(
        round(rng.uniform(-2.0, 2.0), 4)
        for _ in range(MOONSHOT_PARAMETER_COUNT)
    )


def _mutate_moonshot(
    program: MoonshotProgram,
    rng: random.Random,
    *,
    permit_topology_change: bool = True,
) -> MoonshotProgram:
    parameters = list(program.parameters)
    for _ in range(1 if rng.random() < 0.75 else 2):
        index = rng.randrange(len(parameters))
        parameters[index] = round(
            max(
                -4.0,
                min(
                    4.0,
                    parameters[index]
                    + rng.choice(_MOONSHOT_PARAMETER_STEPS),
                ),
            ),
            4,
        )
    topology = program.topology
    if permit_topology_change and rng.random() < 0.12:
        topology = rng.choice(
            tuple(
                item
                for item in MOONSHOT_TOPOLOGIES
                if item != topology
            )
        )
    return MoonshotProgram(topology, tuple(parameters))


def _crossover_moonshots(
    first: MoonshotProgram,
    second: MoonshotProgram,
    rng: random.Random,
) -> MoonshotProgram:
    topology = rng.choice((first.topology, second.topology))
    parameters = tuple(
        left if rng.random() < 0.5 else right
        for left, right in zip(first.parameters, second.parameters)
    )
    return _mutate_moonshot(
        MoonshotProgram(topology, parameters),
        rng,
        permit_topology_change=False,
    )


_LITERATURE_TO_MOONSHOT_TOPOLOGY = {
    "counterfactual_lookahead": "robust_counterfactual_rollout",
    "option_preservation": "robust_counterfactual_rollout",
    "predictive_profile_reservation": (
        "residual_portfolio_controller"
    ),
    "adaptive_pattern_memory": "residual_portfolio_controller",
    "state_conditioned_policy_selection": "bin_role_automaton",
    "change_detection": "bin_role_automaton",
    "failure_syndrome_intervention": "sparse_syndrome_repair",
    "uncertainty_robustness": "sparse_syndrome_repair",
}

_LITERATURE_MOONSHOT_PARAMETERS = {
    "robust_counterfactual_rollout": (
        0.75,
        -0.50,
        0.25,
        0.50,
        -0.25,
        0.25,
    ),
    "residual_portfolio_controller": (
        0.50,
        0.75,
        -0.25,
        0.25,
        0.50,
        -0.50,
    ),
    "bin_role_automaton": (
        -0.25,
        0.50,
        0.75,
        -0.50,
        0.25,
        0.50,
    ),
    "sparse_syndrome_repair": (
        0.25,
        -0.25,
        0.50,
        0.75,
        -0.50,
        0.50,
    ),
}


def _literature_seed_operator(
    context: LiteratureHypothesisContext,
    mechanism: str,
) -> str:
    evidence = context.primary_evidence(mechanism)
    source_id = (
        evidence.work_id
        if evidence is not None
        else context.source_work_ids[0]
    )
    return "literature_contrast_seed:%s:%s" % (
        mechanism,
        source_id,
    )


def _moonshot_literature_priors(
    context: Optional[LiteratureHypothesisContext],
) -> Mapping[str, Tuple[str, Tuple[float, ...]]]:
    if context is None:
        return {}
    priors = {}
    for mechanism in context.hypothesis_mechanisms:
        topology = _LITERATURE_TO_MOONSHOT_TOPOLOGY.get(
            mechanism
        )
        if topology is None or topology in priors:
            continue
        priors[topology] = (
            mechanism,
            _LITERATURE_MOONSHOT_PARAMETERS[topology],
        )
    return priors


class RiskTakingMoonshotProposer:
    name = "incumbent_blind_risk_budgeted_moonshot_evolution"

    def __init__(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        if (
            literature_context is not None
            and literature_context.island_family != "de_novo"
        ):
            raise ValueError(
                "moonshot proposer requires a de-novo literature view"
            )
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        priors = _moonshot_literature_priors(
            self.literature_context
        )
        for topology in MOONSHOT_TOPOLOGIES:
            prior = priors.get(topology)
            yield Proposal(
                MoonshotProgram(
                    topology,
                    (
                        (0.0,) * MOONSHOT_PARAMETER_COUNT
                        if prior is None
                        else prior[1]
                    ),
                ),
                (),
                (
                    "topology_control_seed"
                    if prior is None
                    else _literature_seed_operator(
                        self.literature_context,
                        prior[0],
                    )
                ),
            )
        for _ in range(config.initial_random):
            yield Proposal(
                MoonshotProgram(
                    rng.choice(MOONSHOT_TOPOLOGIES),
                    _random_moonshot_parameters(rng),
                ),
                (),
                "bounded_risk_seed",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        first = rng.choice(tuple(archive))
        if not isinstance(first.program, MoonshotProgram):
            raise ValueError("moonshot archive contains another program type")
        if len(archive) > 1 and rng.random() < config.crossover_probability:
            second = rng.choice(tuple(archive))
            if not isinstance(second.program, MoonshotProgram):
                raise ValueError(
                    "moonshot archive contains another program type"
                )
            return Proposal(
                _crossover_moonshots(
                    first.program,
                    second.program,
                    rng,
                ),
                (
                    first.program.candidate_id,
                    second.program.candidate_id,
                ),
                "topology_parameter_crossover",
            )
        return Proposal(
            _mutate_moonshot(first.program, rng),
            (first.program.candidate_id,),
            "bounded_risk_mutation",
        )


def _moonshot_hybrid_threshold_specs(
    source: MoonshotProgram,
    mechanisms: Sequence[str],
) -> Tuple[Tuple[float, Optional[str]], ...]:
    threshold_priors = {
        "state_conditioned_policy_selection": 0.35,
        "change_detection": 0.45,
        "uncertainty_robustness": 0.55,
        "option_preservation": 0.65,
        "failure_syndrome_intervention": 0.80,
    }
    if source.topology == "robust_counterfactual_rollout":
        threshold_priors.update(
            {
                "counterfactual_lookahead": 0.01,
                "uncertainty_robustness": 0.02,
                "option_preservation": 0.05,
            }
        )
    grounded = tuple(
        dict.fromkeys(
            (
                threshold_priors[mechanism],
                mechanism,
            )
            for mechanism in mechanisms
            if mechanism in threshold_priors
        )
    )
    if grounded:
        return grounded
    return tuple(
        (threshold, None)
        for threshold in (
            (0.005, 0.02, 0.05, 0.10)
            if source.topology == "robust_counterfactual_rollout"
            else (0.35, 0.50, 0.65, 0.80)
        )
    )


class CrossIslandMoonshotHybridProposer:
    name = "delayed_sparse_moonshot_recombination"

    def __init__(
        self,
        ancestry: FunSearchResidualProgram,
        de_novo: Any,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        if (
            literature_context is not None
            and literature_context.island_family != "hybrid"
        ):
            raise ValueError(
                "cross-island proposer requires a hybrid literature view"
        )
        self.ancestry = ancestry
        sources = (
            tuple(de_novo)
            if isinstance(de_novo, (tuple, list))
            else (de_novo,)
        )
        if (
            not sources
            or not all(
                isinstance(source, MoonshotProgram)
                for source in sources
            )
        ):
            raise ValueError(
                "hybrid recombination requires moonshot sources"
            )
        by_topology = {}
        for source in sources:
            by_topology.setdefault(source.topology, source)
        self.de_novo_sources = tuple(
            by_topology[topology]
            for topology in MOONSHOT_TOPOLOGIES
            if topology in by_topology
        )
        self.de_novo = self.de_novo_sources[0]
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        literature_mechanisms = (
            ()
            if self.literature_context is None
            else self.literature_context.hypothesis_mechanisms
        )
        source_specs = tuple(
            (
                source,
                _moonshot_hybrid_threshold_specs(
                    source,
                    literature_mechanisms,
                ),
            )
            for source in self.de_novo_sources
        )
        emitted = 0
        for threshold_index in range(
            max(len(specs) for _, specs in source_specs)
        ):
            for de_novo_source, threshold_specs in source_specs:
                if threshold_index >= len(threshold_specs):
                    continue
                threshold, mechanism = threshold_specs[threshold_index]
                emitted += 1
                yield Proposal(
                    MoonshotHybridProgram(
                        self.ancestry.expression,
                        de_novo_source,
                        threshold,
                        config.residual_scale,
                    ),
                    (
                        self.ancestry.candidate_id,
                        de_novo_source.candidate_id,
                    ),
                    (
                        "topology_stratified_cross_island_gate_control"
                        if mechanism is None
                        else _literature_seed_operator(
                            self.literature_context,
                            mechanism,
                        )
                    ),
                )
        for _ in range(
            max(0, config.initial_random - emitted)
        ):
            de_novo_source = rng.choice(self.de_novo_sources)
            yield Proposal(
                MoonshotHybridProgram(
                    mutate_expression(
                        self.ancestry.expression,
                        rng,
                        config.max_expression_depth,
                        config.max_expression_nodes,
                    ),
                    _mutate_moonshot(de_novo_source, rng),
                    round(
                        rng.uniform(
                            0.001
                            if de_novo_source.topology
                            == "robust_counterfactual_rollout"
                            else 0.25,
                            0.15
                            if de_novo_source.topology
                            == "robust_counterfactual_rollout"
                            else 0.90,
                        ),
                        4,
                    ),
                    config.residual_scale,
                ),
                (
                    self.ancestry.candidate_id,
                    de_novo_source.candidate_id,
                ),
                "topology_stratified_cross_island_mutation",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        first = rng.choice(tuple(archive))
        if not isinstance(first.program, MoonshotHybridProgram):
            raise ValueError("hybrid archive contains another program type")
        program = first.program
        if rng.random() < 0.55:
            moonshot = _mutate_moonshot(program.moonshot, rng)
            ancestry_expression = program.ancestry_expression
            operator = "moonshot_module_mutation"
        else:
            moonshot = program.moonshot
            ancestry_expression = mutate_expression(
                program.ancestry_expression,
                rng,
                config.max_expression_depth,
                config.max_expression_nodes,
            )
            operator = "ancestry_module_mutation"
        minimum_gate = (
            0.001
            if program.moonshot.topology
            == "robust_counterfactual_rollout"
            else 0.10
        )
        gate_threshold = round(
            max(
                minimum_gate,
                min(
                    0.95,
                    program.gate_threshold
                    + rng.choice((-0.15, -0.05, 0.05, 0.15)),
                ),
            ),
            4,
        )
        return Proposal(
            MoonshotHybridProgram(
                ancestry_expression,
                moonshot,
                gate_threshold,
                config.residual_scale,
            ),
            (program.candidate_id,),
            operator,
        )


class CrossRepresentationMoonshotHybridProposer:
    """Preserve a structural de-novo primitive across graph revisions."""

    name = "delayed_cross_representation_structural_recombination"

    def __init__(
        self,
        ancestry: OnlineHeuristic,
        de_novo: Any,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        if (
            literature_context is not None
            and literature_context.island_family != "hybrid"
        ):
            raise ValueError(
                "structural recombination requires a hybrid literature view"
            )
        if not callable(getattr(ancestry, "as_dict", None)):
            raise ValueError(
                "structural recombination ancestry is not serializable"
        )
        self.ancestry = ancestry
        sources = (
            tuple(de_novo)
            if isinstance(de_novo, (tuple, list))
            else (de_novo,)
        )
        if (
            not sources
            or not all(
                isinstance(source, MoonshotProgram)
                for source in sources
            )
        ):
            raise ValueError(
                "structural recombination requires moonshot sources"
            )
        by_topology = {}
        for source in sources:
            by_topology.setdefault(source.topology, source)
        self.de_novo_sources = tuple(
            by_topology[topology]
            for topology in MOONSHOT_TOPOLOGIES
            if topology in by_topology
        )
        self.de_novo = self.de_novo_sources[0]
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        del rng
        mechanisms = (
            ()
            if self.literature_context is None
            else self.literature_context.hypothesis_mechanisms
        )
        source_specs = tuple(
            (
                source,
                _moonshot_hybrid_threshold_specs(
                    source,
                    mechanisms,
                ),
            )
            for source in self.de_novo_sources
        )
        for threshold_index in range(
            max(len(specs) for _, specs in source_specs)
        ):
            for de_novo_source, threshold_specs in source_specs:
                if threshold_index >= len(threshold_specs):
                    continue
                threshold, mechanism = threshold_specs[threshold_index]
                yield Proposal(
                    StructuralHybridProgram(
                        self.ancestry,
                        de_novo_source,
                        threshold,
                    ),
                    (
                        self.ancestry.candidate_id,
                        de_novo_source.candidate_id,
                    ),
                    (
                        "topology_stratified_structural_override_control"
                        if mechanism is None
                        else _literature_seed_operator(
                            self.literature_context,
                            mechanism,
                        )
                    ),
                )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        first = rng.choice(tuple(archive))
        if not isinstance(first.program, StructuralHybridProgram):
            raise ValueError(
                "structural hybrid archive contains another program type"
            )
        moonshot = first.program.moonshot
        parents = [first.program.candidate_id]
        if (
            len(archive) > 1
            and rng.random() < config.crossover_probability
        ):
            second = rng.choice(tuple(archive))
            if not isinstance(second.program, StructuralHybridProgram):
                raise ValueError(
                    "structural hybrid archive contains another program type"
                )
            moonshot = _crossover_moonshots(
                moonshot,
                second.program.moonshot,
                rng,
            )
            parents.append(second.program.candidate_id)
            operator = "typed_structural_override_crossover"
        else:
            moonshot = _mutate_moonshot(moonshot, rng)
            operator = "typed_structural_override_mutation"
        minimum_gate = (
            0.001
            if moonshot.topology
            == "robust_counterfactual_rollout"
            else 0.05
        )
        threshold = max(
            minimum_gate,
            min(
                0.95,
                round(
                    first.program.gate_threshold
                    + rng.uniform(-0.15, 0.15),
                    4,
                ),
            ),
        )
        return Proposal(
            StructuralHybridProgram(
                first.program.ancestry,
                moonshot,
                threshold,
            ),
            tuple(parents),
            operator,
        )


class CalibratedOverrideHybridProposer:
    """Add one frozen closed-loop model to a normal hybrid search."""

    name = "trajectory_credit_transport_plus_structural_search"

    def __init__(
        self,
        base_proposer: Any,
        ancestry: OnlineHeuristic,
        override_model: CalibratedOverrideValueModel,
    ) -> None:
        if not override_model.deployment_enabled:
            raise ValueError(
                "an unqualified override model cannot enter hybrid search"
            )
        self.base_proposer = base_proposer
        self.ancestry = ancestry
        self.override_model = override_model
        self.literature_context_id = getattr(
            base_proposer,
            "literature_context_id",
            None,
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        yield Proposal(
            CalibratedOverrideHybridProgram(
                self.ancestry,
                self.override_model,
                0.5,
            ),
            (
                self.ancestry.candidate_id,
                self.override_model.model_id,
            ),
            "trajectory_credit_episode_transport_override_seed",
        )
        yield from self.base_proposer.seeds(config, rng)

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        structural_archive = tuple(
            record
            for record in archive
            if not isinstance(
                record.program,
                CalibratedOverrideHybridProgram,
            )
        )
        if structural_archive:
            return self.base_proposer.propose(
                config,
                structural_archive,
                rng,
            )
        return next(iter(self.base_proposer.seeds(config, rng)))


_CONTEXTUAL_WEIGHT_STEPS = (
    -2.0,
    -1.0,
    -0.5,
    -0.25,
    0.25,
    0.5,
    1.0,
    2.0,
)


def _contextual_weights(
    values: Optional[Mapping[str, float]] = None,
) -> Tuple[float, ...]:
    supplied = dict(values or {})
    return tuple(
        float(supplied.get(feature, 0.0))
        for feature in CONTEXTUAL_FEATURES
    )


def _random_contextual_weights(
    rng: random.Random,
) -> Tuple[float, ...]:
    weights = [0.0] * len(CONTEXTUAL_FEATURES)
    for index in rng.sample(
        range(len(weights)),
        rng.randint(2, min(7, len(weights))),
    ):
        weights[index] = rng.choice(_CONTEXTUAL_WEIGHT_STEPS)
    return tuple(weights)


def _mutate_contextual_weights(
    weights: Sequence[float],
    rng: random.Random,
) -> Tuple[float, ...]:
    mutated = list(weights)
    for index in rng.sample(
        range(len(mutated)),
        1 if rng.random() < 0.75 else 2,
    ):
        if rng.random() < 0.15:
            mutated[index] = 0.0
        else:
            mutated[index] = round(
                max(
                    -4.0,
                    min(
                        4.0,
                        mutated[index]
                        + rng.choice(_CONTEXTUAL_WEIGHT_STEPS),
                    ),
                ),
                4,
            )
    return tuple(mutated)


def _mutate_residual_scale(
    value: float,
    rng: random.Random,
) -> float:
    """Evolve intervention strength instead of freezing every candidate."""
    if rng.random() >= 0.35:
        return value
    options = (0.025, 0.05, 0.10, 0.20, 0.40)
    return rng.choice(tuple(item for item in options if item != value))


def _expected_literature_family(mode: str) -> str:
    return {
        "ancestry": "ancestry",
        "de_novo": "de_novo",
        "hybrid": "hybrid",
    }[mode]


def _contextual_literature_seeds(
    context: Optional[LiteratureHypothesisContext],
) -> Tuple[Tuple[str, Mapping[str, float]], ...]:
    if context is None:
        return ()
    mapping = {
        "option_preservation": {
            "remaining_x_recent_large_fraction": 1.0,
            "recent_large_fraction": 0.5,
            "negative_remaining_after": -0.25,
        },
        "change_detection": {
            "recent_trend": 1.0,
            "recent_std": 0.5,
            "load_std": -0.5,
        },
        "uncertainty_robustness": {
            "recent_std": -0.5,
            "load_std": -0.5,
            "is_new_bin": -0.25,
        },
        "state_conditioned_policy_selection": {
            "item_x_load": 0.5,
            "recent_large_fraction": -0.5,
            "load_std": 0.5,
        },
        "adaptive_pattern_memory": {
            "remaining_x_recent_mean": 1.0,
            "item_x_recent_mean": -0.5,
        },
    }
    return tuple(
        (mechanism, mapping[mechanism])
        for mechanism in context.hypothesis_mechanisms
        if mechanism in mapping
    )


class ContextualEvolutionProposer:
    name = "contextual_linear_mutation_crossover"

    def __init__(
        self,
        mode: str,
        hypothesis_seed: Optional[GeneratorPatch] = None,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        if mode not in ("ancestry", "de_novo", "hybrid"):
            raise ValueError("unsupported contextual proposer mode")
        if (
            hypothesis_seed is not None
            and hypothesis_seed.generator_ref
            != "binpacking-contextual-linear-generator-v1"
        ):
            raise ValueError("contextual proposer received another generator")
        self.mode = mode
        self.hypothesis_seed = hypothesis_seed
        if (
            literature_context is not None
            and literature_context.island_family
            != _expected_literature_family(mode)
        ):
            raise ValueError(
                "contextual proposer received another island's literature"
            )
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        if self.hypothesis_seed is not None:
            yield Proposal(
                ContextualLinearProgram(
                    self.mode,
                    _contextual_weights(
                        dict(self.hypothesis_seed.feature_weights)
                    ),
                    config.residual_scale,
                ),
                (),
                "causal_hypothesis_compiled_seed:"
                + self.hypothesis_seed.patch_id,
            )
        for mechanism, values in _contextual_literature_seeds(
            self.literature_context
        ):
            yield Proposal(
                ContextualLinearProgram(
                    self.mode,
                    _contextual_weights(values),
                    config.residual_scale,
                ),
                (),
                _literature_seed_operator(
                    self.literature_context,
                    mechanism,
                ),
            )
        templates = (
            (
                {}
                if self.mode == "ancestry"
                else {"negative_remaining_after": 1.0}
            ),
            {"exact_fill": 1.0},
            {"near_fill": 1.0},
            {
                "negative_remaining_after": 1.0,
                "is_new_bin": -1.0,
            },
            {
                "item_x_load": 1.0,
                "recent_large_fraction": -0.5,
                "remaining_x_recent_large_fraction": -1.0,
            },
            {
                "negative_remaining_after": 1.0,
                "recent_trend": 0.5,
                "load_std": -0.5,
            },
        )
        for weights in templates:
            yield Proposal(
                ContextualLinearProgram(
                    self.mode,
                    _contextual_weights(weights),
                    config.residual_scale,
                ),
                (),
                "contextual_mechanism_seed",
            )
        for _ in range(config.initial_random):
            yield Proposal(
                ContextualLinearProgram(
                    self.mode,
                    _random_contextual_weights(rng),
                    config.residual_scale,
                ),
                (),
                "contextual_random_seed",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        first = rng.choice(tuple(archive))
        if not isinstance(first.program, ContextualLinearProgram):
            raise ValueError("contextual archive contains another program type")
        if (
            len(archive) > 1
            and rng.random() < config.crossover_probability
        ):
            second = rng.choice(tuple(archive))
            if not isinstance(second.program, ContextualLinearProgram):
                raise ValueError(
                    "contextual archive contains another program type"
                )
            cut = rng.randint(1, len(CONTEXTUAL_FEATURES) - 1)
            weights = (
                first.program.weights[:cut]
                + second.program.weights[cut:]
            )
            return Proposal(
                ContextualLinearProgram(
                    self.mode,
                    weights,
                    round(
                        (
                            first.program.residual_scale
                            + second.program.residual_scale
                        ) / 2.0,
                        4,
                    ),
                ),
                (
                    first.program.candidate_id,
                    second.program.candidate_id,
                ),
                "contextual_crossover",
            )
        return Proposal(
            ContextualLinearProgram(
                self.mode,
                _mutate_contextual_weights(first.program.weights, rng),
                _mutate_residual_scale(
                    first.program.residual_scale,
                    rng,
                ),
            ),
            (first.program.candidate_id,),
            "contextual_mutation",
        )


class CrossContextualHybridProposer:
    name = "delayed_contextual_cross_island_recombination"

    def __init__(
        self,
        ancestry: ContextualLinearProgram,
        de_novo: ContextualLinearProgram,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        self.ancestry = ancestry
        self.de_novo = de_novo
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )
        self._delegate = ContextualEvolutionProposer(
            "hybrid",
            literature_context=literature_context,
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        source_ids = (
            self.ancestry.candidate_id,
            self.de_novo.candidate_id,
        )
        combinations = (
            tuple(
                left if index % 2 == 0 else right
                for index, (left, right) in enumerate(
                    zip(
                        self.ancestry.weights,
                        self.de_novo.weights,
                    )
                )
            ),
            tuple(
                round((left + right) / 2.0, 4)
                for left, right in zip(
                    self.ancestry.weights,
                    self.de_novo.weights,
                )
            ),
            self.ancestry.weights,
            self.de_novo.weights,
        )
        scales = (
            self.ancestry.residual_scale,
            round(
                (
                    self.ancestry.residual_scale
                    + self.de_novo.residual_scale
                ) / 2.0,
                4,
            ),
            self.ancestry.residual_scale,
            self.de_novo.residual_scale,
        )
        for mechanism, values in _contextual_literature_seeds(
            self.literature_context
        ):
            grounded = list(combinations[1])
            for feature, weight in values.items():
                grounded[CONTEXTUAL_FEATURES.index(feature)] = weight
            yield Proposal(
                ContextualLinearProgram(
                    "hybrid",
                    tuple(grounded),
                    scales[1],
                ),
                source_ids,
                _literature_seed_operator(
                    self.literature_context,
                    mechanism,
                ),
            )
        for weights, scale in zip(combinations, scales):
            yield Proposal(
                ContextualLinearProgram(
                    "hybrid",
                    weights,
                    scale,
                ),
                source_ids,
                "contextual_cross_island_seed",
            )
        for _ in range(max(1, config.initial_random - len(combinations))):
            yield Proposal(
                ContextualLinearProgram(
                    "hybrid",
                    _mutate_contextual_weights(
                        rng.choice(combinations),
                        rng,
                    ),
                    _mutate_residual_scale(
                        rng.choice(scales),
                        rng,
                    ),
                ),
                source_ids,
                "contextual_cross_island_mutation",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        return self._delegate.propose(config, archive, rng)


_REGIME_WEIGHT_STEPS = (
    -2.0,
    -1.0,
    -0.5,
    -0.25,
    0.25,
    0.5,
    1.0,
    2.0,
)


def _regime_matrix(
    values: Optional[Mapping[str, Mapping[str, float]]] = None,
) -> Tuple[Tuple[float, ...], ...]:
    supplied = dict(values or {})
    return tuple(
        tuple(
            float(supplied.get(policy, {}).get(feature, 0.0))
            for feature in REGIME_ROUTER_FEATURES
        )
        for policy in REGIME_ROUTER_POLICIES
    )


def _random_regime_matrix(
    rng: random.Random,
    *,
    mode: str,
) -> Tuple[Tuple[float, ...], ...]:
    matrix = [
        [0.0] * len(REGIME_ROUTER_FEATURES)
        for _ in REGIME_ROUTER_POLICIES
    ]
    allowed_policies = (
        range(1, len(REGIME_ROUTER_POLICIES))
        if mode == "de_novo"
        else range(len(REGIME_ROUTER_POLICIES))
    )
    cell_count = rng.randint(3, 10)
    cells = [
        (policy_index, feature_index)
        for policy_index in allowed_policies
        for feature_index in range(len(REGIME_ROUTER_FEATURES))
    ]
    for policy_index, feature_index in rng.sample(
        cells,
        min(cell_count, len(cells)),
    ):
        matrix[policy_index][feature_index] = rng.choice(
            _REGIME_WEIGHT_STEPS
        )
    return tuple(tuple(row) for row in matrix)


def _mutate_regime_matrix(
    matrix: Sequence[Sequence[float]],
    rng: random.Random,
    *,
    mode: str,
) -> Tuple[Tuple[float, ...], ...]:
    mutated = [list(row) for row in matrix]
    allowed_policies = (
        tuple(range(1, len(REGIME_ROUTER_POLICIES)))
        if mode == "de_novo"
        else tuple(range(len(REGIME_ROUTER_POLICIES)))
    )
    for _ in range(1 if rng.random() < 0.7 else 2):
        policy_index = rng.choice(allowed_policies)
        feature_index = rng.randrange(len(REGIME_ROUTER_FEATURES))
        if rng.random() < 0.15:
            mutated[policy_index][feature_index] = 0.0
        else:
            mutated[policy_index][feature_index] = round(
                max(
                    -4.0,
                    min(
                        4.0,
                        mutated[policy_index][feature_index]
                        + rng.choice(_REGIME_WEIGHT_STEPS),
                    ),
                ),
                4,
            )
    return tuple(tuple(row) for row in mutated)


def _regime_literature_seeds(
    context: Optional[LiteratureHypothesisContext],
) -> Tuple[
    Tuple[str, Mapping[str, Mapping[str, float]]],
    ...,
]:
    if context is None:
        return ()
    mapping = {
        "state_conditioned_policy_selection": {
            "best_fit": {"recent_std": 0.75},
            "worst_fit": {"recent_large_fraction": -0.75},
        },
        "change_detection": {
            "first_fit": {"recent_trend": 1.0},
            "best_fit": {"recent_std": 0.5},
        },
        "uncertainty_robustness": {
            "best_fit": {"load_std": 0.5},
            "first_fit": {"recent_std": -0.5},
        },
        "option_preservation": {
            "worst_fit": {"fullest_remaining": -0.75},
            "best_fit": {"recent_large_fraction": 0.75},
        },
    }
    return tuple(
        (mechanism, mapping[mechanism])
        for mechanism in context.hypothesis_mechanisms
        if mechanism in mapping
    )


class RegimeRouterEvolutionProposer:
    name = "state_conditioned_policy_router_evolution"

    def __init__(
        self,
        mode: str,
        hypothesis_seed: Optional[GeneratorPatch] = None,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        if mode not in ("ancestry", "de_novo", "hybrid"):
            raise ValueError("unsupported regime-router proposer mode")
        if (
            hypothesis_seed is not None
            and hypothesis_seed.generator_ref
            != "binpacking-regime-router-generator-v1"
        ):
            raise ValueError("router proposer received another generator")
        self.mode = mode
        self.hypothesis_seed = hypothesis_seed
        if (
            literature_context is not None
            and literature_context.island_family
            != _expected_literature_family(mode)
        ):
            raise ValueError(
                "router proposer received another island's literature"
            )
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        if self.hypothesis_seed is not None:
            values: Dict[str, Dict[str, float]] = {}
            for name, weight in self.hypothesis_seed.feature_weights:
                policy, separator, feature = name.partition(":")
                if (
                    not separator
                    or policy not in REGIME_ROUTER_POLICIES
                    or feature not in REGIME_ROUTER_FEATURES
                ):
                    raise ValueError(
                        "compiled router patch has an invalid feature"
                    )
                values.setdefault(policy, {})[feature] = weight
            yield Proposal(
                RegimeRouterProgram(
                    self.mode,
                    _regime_matrix(values),
                ),
                (),
                "causal_hypothesis_compiled_seed:"
                + self.hypothesis_seed.patch_id,
            )
        for mechanism, values in _regime_literature_seeds(
            self.literature_context
        ):
            yield Proposal(
                RegimeRouterProgram(
                    self.mode,
                    _regime_matrix(values),
                ),
                (),
                _literature_seed_operator(
                    self.literature_context,
                    mechanism,
                ),
            )
        templates = (
            {},
            {
                "funsearch": {"bias": 0.5},
                "best_fit": {
                    "recent_large_fraction": 1.0,
                    "load_std": 0.5,
                },
            },
            {
                "best_fit": {"item": 1.0, "fullest_remaining": -0.5},
                "first_fit": {"recent_std": 1.0},
            },
            {
                "funsearch": {"recent_mean": 0.5},
                "worst_fit": {
                    "recent_large_fraction": -1.0,
                    "recent_trend": -0.5,
                },
            },
            {
                "first_fit": {"open_bins": -0.5},
                "next_fit": {
                    "recent_trend": 1.0,
                    "load_mean": -0.5,
                },
            },
            {
                "funsearch": {"load_std": -0.5},
                "best_fit": {"load_std": 0.5},
                "worst_fit": {"fullest_remaining": 1.0},
            },
        )
        for values in templates:
            yield Proposal(
                RegimeRouterProgram(
                    self.mode,
                    _regime_matrix(values),
                ),
                (),
                "regime_router_mechanism_seed",
            )
        for _ in range(config.initial_random):
            yield Proposal(
                RegimeRouterProgram(
                    self.mode,
                    _random_regime_matrix(rng, mode=self.mode),
                ),
                (),
                "regime_router_random_seed",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        first = rng.choice(tuple(archive))
        if not isinstance(first.program, RegimeRouterProgram):
            raise ValueError(
                "regime-router archive contains another program type"
            )
        if (
            len(archive) > 1
            and rng.random() < config.crossover_probability
        ):
            second = rng.choice(tuple(archive))
            if not isinstance(second.program, RegimeRouterProgram):
                raise ValueError(
                    "regime-router archive contains another program type"
                )
            cut = rng.randint(1, len(REGIME_ROUTER_POLICIES) - 1)
            matrix = (
                first.program.policy_weights[:cut]
                + second.program.policy_weights[cut:]
            )
            return Proposal(
                RegimeRouterProgram(self.mode, matrix),
                (
                    first.program.candidate_id,
                    second.program.candidate_id,
                ),
                "regime_router_crossover",
            )
        return Proposal(
            RegimeRouterProgram(
                self.mode,
                _mutate_regime_matrix(
                    first.program.policy_weights,
                    rng,
                    mode=self.mode,
                ),
            ),
            (first.program.candidate_id,),
            "regime_router_mutation",
        )


class CrossRegimeRouterProposer:
    name = "delayed_policy_router_cross_island_recombination"

    def __init__(
        self,
        ancestry: RegimeRouterProgram,
        de_novo: RegimeRouterProgram,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        self.ancestry = ancestry
        self.de_novo = de_novo
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )
        self._delegate = RegimeRouterEvolutionProposer(
            "hybrid",
            literature_context=literature_context,
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        source_ids = (
            self.ancestry.candidate_id,
            self.de_novo.candidate_id,
        )
        alternating = tuple(
            ancestry_row if index % 2 == 0 else de_novo_row
            for index, (ancestry_row, de_novo_row) in enumerate(
                zip(
                    self.ancestry.policy_weights,
                    self.de_novo.policy_weights,
                )
            )
        )
        averaged = tuple(
            tuple(
                round((left + right) / 2.0, 4)
                for left, right in zip(ancestry_row, de_novo_row)
            )
            for ancestry_row, de_novo_row in zip(
                self.ancestry.policy_weights,
                self.de_novo.policy_weights,
            )
        )
        combinations = (
            alternating,
            averaged,
            self.ancestry.policy_weights,
            self.de_novo.policy_weights,
        )
        for mechanism, values in _regime_literature_seeds(
            self.literature_context
        ):
            grounded = [
                list(row) for row in combinations[1]
            ]
            for policy, feature_values in values.items():
                policy_index = REGIME_ROUTER_POLICIES.index(policy)
                for feature, weight in feature_values.items():
                    grounded[policy_index][
                        REGIME_ROUTER_FEATURES.index(feature)
                    ] = weight
            yield Proposal(
                RegimeRouterProgram(
                    "hybrid",
                    tuple(tuple(row) for row in grounded),
                ),
                source_ids,
                _literature_seed_operator(
                    self.literature_context,
                    mechanism,
                ),
            )
        for matrix in combinations:
            yield Proposal(
                RegimeRouterProgram("hybrid", matrix),
                source_ids,
                "regime_router_cross_island_seed",
            )
        for _ in range(max(1, config.initial_random - len(combinations))):
            yield Proposal(
                RegimeRouterProgram(
                    "hybrid",
                    _mutate_regime_matrix(
                        rng.choice(combinations),
                        rng,
                        mode="hybrid",
                    ),
                ),
                source_ids,
                "regime_router_cross_island_mutation",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        return self._delegate.propose(config, archive, rng)


def _demand_memory_weights(
    values: Optional[Mapping[str, float]] = None,
) -> Tuple[float, ...]:
    supplied = dict(values or {})
    return tuple(
        float(supplied.get(feature, 0.0))
        for feature in DEMAND_MEMORY_FEATURES
    )


def _random_demand_memory_weights(
    rng: random.Random,
) -> Tuple[float, ...]:
    weights = [0.0] * len(DEMAND_MEMORY_FEATURES)
    for index in rng.sample(
        range(len(weights)),
        rng.randint(2, min(7, len(weights))),
    ):
        weights[index] = rng.choice(_CONTEXTUAL_WEIGHT_STEPS)
    return tuple(weights)


def _mutate_demand_memory_weights(
    weights: Sequence[float],
    rng: random.Random,
) -> Tuple[float, ...]:
    mutated = list(weights)
    for index in rng.sample(
        range(len(mutated)),
        1 if rng.random() < 0.75 else 2,
    ):
        if rng.random() < 0.15:
            mutated[index] = 0.0
        else:
            mutated[index] = round(
                max(
                    -4.0,
                    min(
                        4.0,
                        mutated[index]
                        + rng.choice(_CONTEXTUAL_WEIGHT_STEPS),
                    ),
                ),
                4,
            )
    return tuple(mutated)


def _demand_literature_seeds(
    context: Optional[LiteratureHypothesisContext],
) -> Tuple[Tuple[str, Mapping[str, float]], ...]:
    if context is None:
        return ()
    mapping = {
        "predictive_profile_reservation": {
            "demand_density_after": 1.0,
            "demand_density_preserved": 0.5,
        },
        "adaptive_pattern_memory": {
            "exact_complement_rate": 0.75,
            "demand_density_after": 0.75,
        },
        "option_preservation": {
            "demand_density_preserved": 1.0,
            "large_item_slot": 0.75,
            "small_item_fragment": -0.5,
        },
        "change_detection": {
            "demand_density_after": 0.5,
            "demand_density_preserved": -0.5,
            "is_new_bin": -0.25,
        },
        "uncertainty_robustness": {
            "large_item_slot": 0.5,
            "small_item_fragment": -0.5,
            "near_fill": 0.25,
        },
    }
    return tuple(
        (mechanism, mapping[mechanism])
        for mechanism in context.hypothesis_mechanisms
        if mechanism in mapping
    )


class DemandMemoryEvolutionProposer:
    name = "empirical_demand_memory_evolution"

    def __init__(
        self,
        mode: str,
        hypothesis_seed: Optional[GeneratorPatch] = None,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        if mode not in ("ancestry", "de_novo", "hybrid"):
            raise ValueError("unsupported demand-memory proposer mode")
        if (
            hypothesis_seed is not None
            and hypothesis_seed.generator_ref
            != "binpacking-demand-memory-generator-v1"
        ):
            raise ValueError(
                "demand-memory proposer received another generator"
            )
        self.mode = mode
        self.hypothesis_seed = hypothesis_seed
        if (
            literature_context is not None
            and literature_context.island_family
            != _expected_literature_family(mode)
        ):
            raise ValueError(
                "demand proposer received another island's literature"
            )
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        if self.hypothesis_seed is not None:
            yield Proposal(
                DemandMemoryProgram(
                    self.mode,
                    _demand_memory_weights(
                        dict(self.hypothesis_seed.feature_weights)
                    ),
                    config.residual_scale,
                ),
                (),
                "causal_hypothesis_compiled_seed:"
                + self.hypothesis_seed.patch_id,
            )
        for mechanism, values in _demand_literature_seeds(
            self.literature_context
        ):
            yield Proposal(
                DemandMemoryProgram(
                    self.mode,
                    _demand_memory_weights(values),
                    config.residual_scale,
                ),
                (),
                _literature_seed_operator(
                    self.literature_context,
                    mechanism,
                ),
            )
        templates = (
            (
                {}
                if self.mode == "ancestry"
                else {"negative_remaining_after": 1.0}
            ),
            {
                "demand_density_after": 1.0,
                "demand_density_preserved": 0.5,
            },
            {
                "negative_remaining_after": 1.0,
                "demand_density_after": 0.5,
            },
            {
                "exact_complement_rate": 1.0,
                "small_item_fragment": -0.5,
            },
            {
                "demand_density_preserved": 1.0,
                "large_item_slot": 0.5,
                "is_new_bin": -0.5,
            },
            {
                "near_fill": 0.5,
                "demand_density_after": 1.0,
                "large_item_slot": -0.5,
            },
        )
        for values in templates:
            yield Proposal(
                DemandMemoryProgram(
                    self.mode,
                    _demand_memory_weights(values),
                    config.residual_scale,
                ),
                (),
                "demand_memory_mechanism_seed",
            )
        for _ in range(config.initial_random):
            yield Proposal(
                DemandMemoryProgram(
                    self.mode,
                    _random_demand_memory_weights(rng),
                    config.residual_scale,
                ),
                (),
                "demand_memory_random_seed",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        first = rng.choice(tuple(archive))
        if not isinstance(first.program, DemandMemoryProgram):
            raise ValueError(
                "demand-memory archive contains another program type"
            )
        if (
            len(archive) > 1
            and rng.random() < config.crossover_probability
        ):
            second = rng.choice(tuple(archive))
            if not isinstance(second.program, DemandMemoryProgram):
                raise ValueError(
                    "demand-memory archive contains another program type"
                )
            cut = rng.randint(1, len(DEMAND_MEMORY_FEATURES) - 1)
            weights = (
                first.program.weights[:cut]
                + second.program.weights[cut:]
            )
            return Proposal(
                DemandMemoryProgram(
                    self.mode,
                    weights,
                    round(
                        (
                            first.program.residual_scale
                            + second.program.residual_scale
                        ) / 2.0,
                        4,
                    ),
                ),
                (
                    first.program.candidate_id,
                    second.program.candidate_id,
                ),
                "demand_memory_crossover",
            )
        return Proposal(
            DemandMemoryProgram(
                self.mode,
                _mutate_demand_memory_weights(
                    first.program.weights,
                    rng,
                ),
                _mutate_residual_scale(
                    first.program.residual_scale,
                    rng,
                ),
            ),
            (first.program.candidate_id,),
            "demand_memory_mutation",
        )


class CrossDemandMemoryProposer:
    name = "delayed_demand_memory_cross_island_recombination"

    def __init__(
        self,
        ancestry: DemandMemoryProgram,
        de_novo: DemandMemoryProgram,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        self.ancestry = ancestry
        self.de_novo = de_novo
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )
        self._delegate = DemandMemoryEvolutionProposer(
            "hybrid",
            literature_context=literature_context,
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        source_ids = (
            self.ancestry.candidate_id,
            self.de_novo.candidate_id,
        )
        combinations = (
            tuple(
                left if index % 2 == 0 else right
                for index, (left, right) in enumerate(
                    zip(
                        self.ancestry.weights,
                        self.de_novo.weights,
                    )
                )
            ),
            tuple(
                round((left + right) / 2.0, 4)
                for left, right in zip(
                    self.ancestry.weights,
                    self.de_novo.weights,
                )
            ),
            self.ancestry.weights,
            self.de_novo.weights,
        )
        scales = (
            self.ancestry.residual_scale,
            round(
                (
                    self.ancestry.residual_scale
                    + self.de_novo.residual_scale
                ) / 2.0,
                4,
            ),
            self.ancestry.residual_scale,
            self.de_novo.residual_scale,
        )
        for mechanism, values in _demand_literature_seeds(
            self.literature_context
        ):
            grounded = list(combinations[1])
            for feature, weight in values.items():
                grounded[
                    DEMAND_MEMORY_FEATURES.index(feature)
                ] = weight
            yield Proposal(
                DemandMemoryProgram(
                    "hybrid",
                    tuple(grounded),
                    scales[1],
                ),
                source_ids,
                _literature_seed_operator(
                    self.literature_context,
                    mechanism,
                ),
            )
        for weights, scale in zip(combinations, scales):
            yield Proposal(
                DemandMemoryProgram(
                    "hybrid",
                    weights,
                    scale,
                ),
                source_ids,
                "demand_memory_cross_island_seed",
            )
        for _ in range(max(1, config.initial_random - len(combinations))):
            yield Proposal(
                DemandMemoryProgram(
                    "hybrid",
                    _mutate_demand_memory_weights(
                        rng.choice(combinations),
                        rng,
                    ),
                    _mutate_residual_scale(
                        rng.choice(scales),
                        rng,
                    ),
                ),
                source_ids,
                "demand_memory_cross_island_mutation",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence[IslandCandidateRecord],
        rng: random.Random,
    ) -> Proposal:
        return self._delegate.propose(config, archive, rng)


def _suite(
    *,
    families: Sequence[str],
    seed_start: int,
    cases_per_family: int,
    length: int,
    capacity: int,
) -> Tuple[BinPackingInstance, ...]:
    return tuple(
        generate_instance(
            family,
            seed_start + family_index * 1_000_000 + offset,
            length,
            capacity,
        )
        for family_index, family in enumerate(families)
        for offset in range(cases_per_family)
    )


def _multiscale_or_suite(
    config: BinPackingGoalRunConfig,
    *,
    seed_start: int,
    cases_per_length: int,
) -> Tuple[BinPackingInstance, ...]:
    return tuple(
        generate_instance(
            "or_uniform",
            seed_start + length_index * 1_000_000 + offset,
            length,
            config.capacity,
        )
        for length_index, length in enumerate(config.validation_lengths)
        for offset in range(cases_per_length)
    )


def _reproduction_entry(
    store: ArtifactStore,
    adapter: BinPackingAdapter,
    candidate: OnlineHeuristic,
    experiments: Sequence[BinPackingInstance],
    *,
    name: str,
    role: IncumbentRole,
    source_locator: str,
    source_work_id: Optional[str] = None,
) -> IncumbentEntry:
    evidence_ids = []
    bin_counts = []
    for experiment in experiments:
        observation = adapter.evaluate(candidate, experiment)
        verification = adapter.verify(experiment, observation)
        if not verification.passed:
            raise ValueError("baseline reproduction failed independent checks")
        bin_counts.append(observation.bin_count)
        evidence_ids.append(
            store.put(
                "binpacking_incumbent_reproduction_evidence",
                {
                    "candidate_id": adapter.candidate_id(candidate),
                    "experiment": adapter.experiment_as_dict(experiment),
                    "observation": adapter.observation_as_dict(observation),
                    "verification": verification.as_dict(),
                },
            )
        )
    executable_digest = store.put(
        "domain_candidate",
        dict(adapter.candidate_as_dict(candidate)),
    )
    return IncumbentEntry(
        candidate_id=adapter.candidate_id(candidate),
        name=name,
        role=role,
        executable_digest=executable_digest,
        source_locator=source_locator,
        source_work_id=source_work_id,
        reproduction_evidence_ids=tuple(evidence_ids),
        metric_summary={
            "mean_bins": mean(bin_counts),
            "case_count": float(len(bin_counts)),
        },
        limitations=(
            "reproduced only on the clean preregistered generated suite",
        ),
    )


def _campaign_gates(
    config: BinPackingGoalRunConfig,
) -> Tuple[GateContract, GateContract]:
    audit = GateContract(
        kind=GateKind.REPLICATION_NOMINATION,
        evidence_partition=EvidencePartition.AUDIT,
        criteria=(
            GateCriterion(
                metric="aggregate_improvement_ci_lower",
                operator=">",
                threshold=0.0,
                description=(
                    "untouched audit aggregate improvement has a positive "
                    "episode-level 95% confidence bound"
                ),
            ),
            GateCriterion(
                metric="mean_improvement_ci_lower",
                operator=">",
                threshold=0.0,
                description=(
                    "untouched audit mean episode improvement excludes zero"
                ),
            ),
        ),
        minimum_evidence_count=config.audit_evidence_count,
    )
    replication = GateContract(
        kind=GateKind.INCUMBENT_ADVANCE,
        evidence_partition=EvidencePartition.REPLICATION,
        criteria=(
            GateCriterion(
                metric="aggregate_improvement_ci_lower",
                operator=">",
                threshold=0.0,
                description=(
                    "frozen replication aggregate improvement has a positive "
                    "episode-level 95% confidence bound"
                ),
            ),
            GateCriterion(
                metric="mean_improvement_ci_lower",
                operator=">",
                threshold=0.0,
                description=(
                    "frozen replication mean episode improvement excludes zero"
                ),
            ),
        ),
        minimum_evidence_count=config.replication_evidence_count,
    )
    return audit, replication


def _verified_batch(
    store: ArtifactStore,
    adapter: BinPackingAdapter,
    candidate: OnlineHeuristic,
    incumbent: OnlineHeuristic,
    experiments: Sequence[BinPackingInstance],
    *,
    kind: str,
) -> Tuple[Mapping[str, float], Tuple[str, ...], str]:
    experiment_digest = store.put(
        kind + "_experiment_suite",
        [adapter.experiment_as_dict(item) for item in experiments],
    )
    evidence_ids = []
    deltas = []
    for experiment in experiments:
        candidate_observation = adapter.evaluate(candidate, experiment)
        incumbent_observation = adapter.evaluate(incumbent, experiment)
        candidate_verification = adapter.verify(
            experiment,
            candidate_observation,
        )
        incumbent_verification = adapter.verify(
            experiment,
            incumbent_observation,
        )
        if (
            not candidate_verification.passed
            or not incumbent_verification.passed
        ):
            raise ValueError("integration evidence failed independent checks")
        comparison = adapter.compare(candidate, incumbent, experiment)
        delta = float(comparison.metrics["primary_delta"])
        deltas.append(delta)
        evidence_ids.append(
            store.put(
                kind + "_verified_comparison",
                {
                    "experiment_id": adapter.experiment_id(experiment),
                    "candidate_observation": adapter.observation_as_dict(
                        candidate_observation
                    ),
                    "incumbent_observation": adapter.observation_as_dict(
                        incumbent_observation
                    ),
                    "candidate_verification": (
                        candidate_verification.as_dict()
                    ),
                    "incumbent_verification": (
                        incumbent_verification.as_dict()
                    ),
                    "comparison": comparison.as_dict(),
                },
            )
        )
    episode_evidence = paired_episode_evidence(
        (-delta for delta in deltas),
        tuple(adapter.experiment_id(item) for item in experiments),
    )
    metrics = {
        "primary_delta": sum(deltas),
        "mean_primary_delta": mean(deltas),
        **episode_evidence.metrics(),
    }
    return metrics, tuple(evidence_ids), experiment_digest


class BinPackingGoalProgram:
    """End-to-end v2 orchestration for a clean bin-packing research run."""

    run_phase = "initial_risk_budgeted_moonshot_search"
    representation = "mixed_symbolic_and_moonshot_decision_topologies"
    moonshot_exploration_lane = True

    _FAMILY_BY_ISLAND = {
        "funsearch_ancestry": SearchFamily.ANCESTRY,
        "de_novo": SearchFamily.DE_NOVO,
        "hybrid": SearchFamily.HYBRID,
    }

    def __init__(
        self,
        runtime: GoalGraphRuntime,
        store: ArtifactStore,
        config: BinPackingGoalRunConfig,
        *,
        orlib_root: Path,
        selected_hypothesis: Optional[TournamentHypothesis] = None,
        literature_reviewer: Optional[
            LiveWebPriorArtReviewer
        ] = None,
    ) -> None:
        self.runtime = runtime
        self.control = runtime.control_plane
        self.store = store
        self.config = config
        self.orlib_root = Path(orlib_root)
        self.selected_hypothesis = selected_hypothesis
        self.selected_hypothesis_contract = (
            None
            if selected_hypothesis is None
            else selected_hypothesis.executable_contract
        )
        self.literature_reviewer = literature_reviewer
        if (
            self.literature_reviewer is None
            and self.config.require_web_literature
        ):
            self.literature_reviewer = default_live_web_reviewer(
                self.store,
                timeout_seconds=self.config.literature_timeout_seconds,
                results_per_query=(
                    self.config.literature_results_per_query
                ),
            )
        if (
            selected_hypothesis is not None
            and (
                not selected_hypothesis.revision_eligible
                or selected_hypothesis.executable_contract is None
                or selected_hypothesis.diagnostic_result is None
                or not selected_hypothesis.diagnostic_result.passed
            )
        ):
            raise ValueError(
                "revision program requires a diagnostic-qualified "
                "executable hypothesis"
            )
        self.adapter = BinPackingAdapter()
        self.incumbent = literature_heuristics()["funsearch_or_reference"]
        self.best_fit = baseline_heuristics()["best_fit"]
        self._domain_lineage: Dict[
            SearchFamily, Dict[str, str]
        ] = {
            family: {}
            for family in (
                SearchFamily.ANCESTRY,
                SearchFamily.DE_NOVO,
                SearchFamily.HYBRID,
            )
        }
        self._programs: Dict[str, OnlineHeuristic] = {}
        self._audit_results: Dict[
            str, Tuple[Any, GateDecision]
        ] = {}
        self._contribution_results: Dict[str, Mapping[str, Any]] = {}
        self._semantic_novelty_results: Dict[
            str, Mapping[str, Any]
        ] = {}
        self._known_novelty_fingerprints: Dict[str, str] = {}
        self._failure_target: Optional[OnlineHeuristic] = None
        self._failure_target_candidate_id: Optional[str] = None
        self._method_prior_digest: Optional[str] = None
        self._round_literature_contexts: Dict[
            int, Mapping[str, LiteratureHypothesisContext]
        ] = {}
        self._override_value_training_artifacts: Dict[int, str] = {}

    def _review_literature(
        self,
        node: GoalNodeSpec,
        *,
        trigger: LiteratureTrigger = LiteratureTrigger.INITIAL_SCOPE,
        candidate_delta: Optional[str] = None,
        mechanism_review: Optional[Mapping[str, Any]] = None,
        planned: Optional[PriorArtAssessment] = None,
    ) -> PriorArtAssessment:
        assessment = planned or literature_assessment(
            node,
            trigger=trigger,
            candidate_delta=candidate_delta,
            mechanism_review=mechanism_review,
        )
        if self.literature_reviewer is None:
            return assessment
        return self.literature_reviewer.review(assessment)

    def _ancestry_proposer(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        return StructuredEvolutionProposer(literature_context)

    def _de_novo_proposer(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        return RiskTakingMoonshotProposer(literature_context)

    def _hybrid_proposer(
        self,
        ancestry_source: OnlineHeuristic,
        de_novo_source: Any,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        de_novo_sources = (
            tuple(de_novo_source)
            if isinstance(de_novo_source, (tuple, list))
            else (de_novo_source,)
        )
        if not isinstance(
            ancestry_source,
            FunSearchResidualProgram,
        ) or not de_novo_sources or not all(
            isinstance(source, MoonshotProgram)
            for source in de_novo_sources
        ):
            raise ValueError(
                "cross-island survivors have incompatible types"
            )
        return CrossIslandMoonshotHybridProposer(
            ancestry_source,
            de_novo_sources,
            literature_context,
        )

    @staticmethod
    def _causal_literature_questions(
        causal_models: CausalFailureModelSet,
    ) -> Tuple[str, ...]:
        return tuple(
            dict.fromkeys(
                value
                for model in causal_models.models
                for value in (
                    model.unavailable_information,
                    model.irreversible_decision,
                    model.alternative_action,
                    model.mediator,
                    *model.observable_proxies,
                    *model.distinguishing_predictions,
                    *model.falsification_conditions,
                )
                if value
            )
        )

    def _round_literature_assessment(
        self,
        node: GoalNodeSpec,
        causal_models: CausalFailureModelSet,
        round_index: int,
    ) -> PriorArtAssessment:
        causal_questions = self._causal_literature_questions(
            causal_models
        )
        model_terms = tuple(
            dict.fromkeys(
                (
                    model.mediator,
                    *(
                        relation.value
                        for relation in model.causal_relations
                    ),
                    *model.observable_proxies,
                )
                for model in causal_models.models
            )
        )
        flattened_terms = tuple(
            dict.fromkeys(
                term
                for values in model_terms
                for term in (
                    values if isinstance(values, tuple) else (values,)
                )
            )
        )
        mechanism = "; ".join(flattened_terms)
        base = literature_assessment(
            node,
            trigger=LiteratureTrigger.PERIODIC_DELTA,
        )
        literature_native_queries = {
            "preserved_future_complement_residual": (
                "online bin packing residual capacity future item distribution"
            ),
            "preserved_large_item_option": (
                "online bin packing reserve capacity future large items"
            ),
            "information_revealed_after_commitment": (
                "online bin packing unknown future arrivals"
            ),
            "commitment_destroys_option": (
                "online bin packing irrevocable placement decisions"
            ),
            "alternative_preserves_option": (
                "online bin packing lookahead placement decision"
            ),
            "preserved_option_changes_outcome": (
                "online bin packing capacity reservation future items"
            ),
            "feedback_corrects_future_action": (
                "adaptive online bin packing arrival distribution learning"
            ),
        }
        targeted_queries = tuple(
            LiteratureQuery(
                query=literature_native_queries.get(
                    term,
                    "online bin packing %s"
                    % term.replace("_", " "),
                ),
                facet=SearchFacet.MECHANISM,
                provider=provider,
            )
            for term in flattened_terms[:4]
            for provider in ("Google Scholar", "Semantic Scholar")
        )
        return PriorArtAssessment(
            signature=ClaimSignature(
                subject_id=node.node_id,
                statement=node.question,
                problem=base.signature.problem,
                phenomenon=(
                    "round %d observed causal failures under hidden future "
                    "demand and irreversible placement" % round_index
                ),
                intervention=(
                    "literature-grounded contrastive hypothesis generation "
                    "for ancestry, de-novo, and hybrid search"
                ),
                mechanism=mechanism or base.signature.mechanism,
                evaluation=base.signature.evaluation,
            ),
            trigger=LiteratureTrigger.PERIODIC_DELTA,
            queries=(*base.queries, *targeted_queries),
            closest_works=base.closest_works,
            classification=ClaimClassification.NOVEL_CANDIDATE,
            rationale=(
                "The round-specific survey is an upstream experiment-design "
                "input. Published mechanisms become exclusions; broken "
                "assumptions, adjacent mechanisms, and causal questions "
                "become contrastive executable seeds."
            ),
            novel_delta=(
                "each island receives an isolation-safe literature context",
                "candidate provenance records source works and survey digest",
                "failure-specific queries are refreshed before search",
            ),
            citation_snowball_complete=(
                base.citation_snowball_complete
            ),
            searched_at=base.searched_at,
            reviewer_ref=(
                "round-causal-literature-planner-v1"
            ),
            executable_incumbent_id=base.executable_incumbent_id,
        )

    def _literature_contexts_for_round(
        self,
        node: GoalNodeSpec,
        causal_models: CausalFailureModelSet,
        round_index: int,
    ) -> Tuple[
        PriorArtAssessment,
        Mapping[str, LiteratureHypothesisContext],
        Mapping[str, str],
    ]:
        assessment = self._review_literature(
            node,
            trigger=LiteratureTrigger.PERIODIC_DELTA,
            planned=self._round_literature_assessment(
                node,
                causal_models,
                round_index,
            ),
        )
        self.runtime.transact(
            "register_literature_assessment",
            assessment,
        )
        causal_questions = self._causal_literature_questions(
            causal_models
        )
        contexts = {
            island: build_literature_hypothesis_context(
                assessment,
                family,
                vocabulary=BINPACKING_LITERATURE_VOCABULARY,
                causal_questions=causal_questions,
            )
            for island, family in (
                ("funsearch_ancestry", "ancestry"),
                ("de_novo", "de_novo"),
                ("hybrid", "hybrid"),
            )
        }
        context_artifacts = {
            island: self.store.put(
                "island_literature_hypothesis_context",
                context.as_dict(),
            )
            for island, context in contexts.items()
        }
        self._round_literature_contexts[round_index] = contexts
        return assessment, contexts, context_artifacts

    def _bootstrap(
        self,
    ) -> Tuple[GoalNodeSpec, GoalNodeSpec, GoalNodeSpec, IslandCampaignContract]:
        goal = self.control.goal
        root, capability, leaf = goal_nodes(goal, self.config)
        if root.node_id != self.control.graph.root_id:
            raise ValueError("clean-run root does not match its checkpoint")
        self._method_prior_digest = self.store.put(
            "scientific_method_prior",
            {
                "schema": 1,
                "scope": (
                    "architecture-level causal and semantic constraints; "
                    "contains no previous run candidate, metric, seed, or "
                    "execution artifact"
                ),
                "lessons": list(SCIENTIFIC_METHOD_PRIORS),
            },
        )
        self.runtime.transact(
            "register_literature_assessment",
            self._review_literature(root),
        )
        self.runtime.transact(
            "add_decomposition",
            (capability,),
            ParentCompositionRule(
                parent_id=root.node_id,
                child_ids=(capability.node_id,),
                operator=CompositionOperator.ALL,
                integration_test=(
                    "checksummed OR-Library external paired comparison"
                ),
                rationale=(
                    "the root requires an end-to-end generalizable policy"
                ),
                decomposer_ref="binpacking-causal-decomposer-v1",
            ),
            assumptions=(
                "generated OR-style performance predicts external utility",
                "paired bin count is the relevant terminal quantity",
            ),
            distinguishing_predictions=(
                "a real mechanism transfers beyond the search distribution",
                "a surrogate exploit fails parent integration",
            ),
            reasoning=(
                "separate local code search from end-to-end generalization"
            ),
        )
        self.runtime.transact(
            "register_literature_assessment",
            self._review_literature(capability),
        )
        self.runtime.transact(
            "add_decomposition",
            (leaf,),
            ParentCompositionRule(
                parent_id=capability.node_id,
                child_ids=(leaf.node_id,),
                operator=CompositionOperator.ALL,
                integration_test=(
                    "frozen multi-family generated shift suite v1"
                ),
                rationale=(
                    "only a replicated executable candidate can be tested "
                    "for generalization"
                ),
                decomposer_ref="binpacking-causal-decomposer-v1",
            ),
            assumptions=(
                "typed priority programs are executable in the domain adapter",
                "island isolation supplies a meaningful mechanism control",
            ),
            distinguishing_predictions=(
                "ancestry wins depend on incumbent mechanisms",
                "de-novo wins survive without incumbent exposure",
                "hybrid wins require survivors from both isolated islands",
            ),
            reasoning=(
                "stop decomposition at the first falsifiable executable "
                "search-and-replication boundary"
            ),
        )
        leaf_literature = self._review_literature(leaf)
        self.runtime.transact(
            "register_literature_assessment",
            leaf_literature,
        )
        reproduction = _suite(
            families=("or_uniform",),
            seed_start=self.config.base_seed + 90_000_000,
            cases_per_family=30,
            length=self.config.development_length,
            capacity=self.config.capacity,
        )
        baselines = baseline_heuristics()
        portfolio = IncumbentPortfolio(
            node_id=leaf.node_id,
            literature_assessment_id=leaf_literature.assessment_id,
            entries=(
                _reproduction_entry(
                    self.store,
                    self.adapter,
                    baselines["next_fit"],
                    reproduction,
                    name="Next Fit null control",
                    role=IncumbentRole.NULL,
                    source_locator="internal:next-fit-control",
                ),
                _reproduction_entry(
                    self.store,
                    self.adapter,
                    self.best_fit,
                    reproduction,
                    name="Best Fit",
                    role=IncumbentRole.CHEAPEST_CREDIBLE,
                    source_locator="published:best-fit",
                ),
                _reproduction_entry(
                    self.store,
                    self.adapter,
                    self.incumbent,
                    reproduction,
                    name="Published FunSearch OR heuristic",
                    role=IncumbentRole.BEST_PUBLISHED_COMPONENT,
                    source_locator=(
                        "https://doi.org/10.1038/s41586-023-06924-6"
                    ),
                    source_work_id=FUNSEARCH_WORK_ID,
                ),
            ),
            primary_incumbent_id=self.adapter.candidate_id(self.incumbent),
            selection_rationale=(
                "Fresh literature closure identified FunSearch as the "
                "strongest matching executable published OR-style baseline; "
                "all entries were re-evaluated without prior run artifacts."
            ),
        )
        self.runtime.transact(
            "register_incumbent_portfolio",
            portfolio,
        )
        self.runtime.transact(
            "assess_nodes",
            (
                NodeSchedulingAssessment(
                    node_id=leaf.node_id,
                    root_relevance=1.0,
                    value_of_information=0.9,
                    success_probability=0.25,
                    integration_leverage=1.0,
                    uncertainty=0.9,
                    estimated_cost=self.config.maximum_search_compute,
                    basis=(
                        "only executable frontier node",
                        "directly controls the terminal paired-bin metric",
                    ),
                    assessor_ref="binpacking-v2-scheduler-v1",
                ),
            ),
        )
        schedule = self.runtime.transact(
            "schedule_frontier",
            1,
            self.config.maximum_search_compute,
        )
        if schedule.node_ids != (leaf.node_id,):
            raise ValueError("scheduler did not authorize the search leaf")
        audit_gate, replication_gate = _campaign_gates(self.config)
        contract = IslandCampaignContract(
            node_id=leaf.node_id,
            leaf_contract_id=leaf.leaf_contract.contract_id,
            incumbent_portfolio_id=portfolio.portfolio_id,
            evaluator_ref=self.adapter.evaluator_ref,
            verifier_ref=self.adapter.verifier_ref,
            quarantined_test_ref=(
                "clean-run-sequestered-audit-and-replication-v1"
            ),
            total_compute_budget=max(
                900.0,
                self.config.maximum_search_compute + 300.0,
            ),
            max_rounds=self.config.rounds,
            isolation_rounds=self.config.isolation_rounds,
            information_views=default_information_views(),
            gates=(audit_gate, replication_gate),
            selected_hypothesis_id=(
                None
                if self.selected_hypothesis is None
                else self.selected_hypothesis.hypothesis_id
            ),
            selected_executable_digest=(
                None
                if self.selected_hypothesis_contract is None
                else self.selected_hypothesis_contract.executable_digest
            ),
            selected_diagnostic_id=(
                None
                if self.selected_hypothesis is None
                or self.selected_hypothesis.diagnostic_result is None
                else self.selected_hypothesis.diagnostic_result.diagnostic_id
            ),
        )
        self.runtime.transact(
            "start_campaign",
            contract,
            CampaignPlateauPolicy(
                minimum_complete_rounds=self.config.rounds,
                no_improvement_window=min(2, self.config.rounds),
                minimum_attempts_per_island=(
                    self.config.candidate_budget_per_island
                ),
                minimum_distinct_ancestries_per_island=2,
                minimum_meaningful_effect=0.001,
                stable_failure_window=min(2, self.config.rounds),
            ),
        )
        return root, capability, leaf, contract

    def _causal_failure_models(
        self,
        *,
        node_id: str,
        round_index: int,
        adversary: AdversaryOutcome,
        failure_mining_digest: str,
        target: OnlineHeuristic,
        target_ref: str,
    ) -> Tuple[CausalFailureModelSet, Tuple[CausalStatePrototype, ...]]:
        failures = tuple(
            record
            for record in adversary.archive
            if record.target_gap > 0
        )
        if not failures:
            failures = (adversary.best,)
        traced = []
        trace_artifact_ids = []
        for record in sorted(
            failures,
            key=lambda item: (item.archive_cell, item.instance.instance_id),
        ):
            trace = trace_first_effective_decision(
                node_id,
                record.instance,
                target,
            )
            trace_digest = self.store.put(
                "binpacking_decision_counterfactual_trace",
                {
                    **trace.as_dict(),
                    "adversary_archive_cell": list(record.archive_cell),
                    "adversary_artifact_digest": record.artifact_digest,
                    "target_gap": record.target_gap,
                    "target_excess": record.target_excess,
                    "causal_target_ref": target_ref,
                },
            )
            traced.append((record, trace, trace_digest))
            trace_artifact_ids.append(trace_digest)

        grouped: Dict[
            Tuple[str, ...],
            list[Tuple[Any, DecisionCounterfactualTrace, str]],
        ] = {}
        for record, trace, trace_digest in traced:
            grouped.setdefault(trace.causal_signature, []).append(
                (record, trace, trace_digest)
            )
        models = []
        causal_prototypes = []
        for signature, group in sorted(grouped.items()):
            traces = tuple(item[1] for item in group)
            supported = tuple(
                trace
                for trace in traces
                if trace.status == CounterfactualStatus.SUPPORTED
            )
            representative = max(
                traces,
                key=lambda trace: (
                    trace.outcome_delta,
                    trace.proxy_reliability,
                    trace.trace_id,
                ),
            )
            empirical_support = bool(supported)
            regime = representative.information_regime
            if regime == InformationRegime.PREDICTIVE_PROXY:
                relations = (
                    CausalRelationKind
                    .INFORMATION_REVEALED_AFTER_COMMITMENT,
                    CausalRelationKind.COMMITMENT_DESTROYS_OPTION,
                    CausalRelationKind.ALTERNATIVE_PRESERVES_OPTION,
                    CausalRelationKind
                    .PRESERVED_OPTION_CHANGES_OUTCOME,
                    CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION,
                )
                unavailable = (
                    "future complement demand for residual %d was unavailable "
                    "at decision %d; the preceding 32 arrivals were the only "
                    "legal predictive signal"
                    % (
                        representative.alternative_remaining_after,
                        representative.decision_index,
                    )
                )
                proxies = (
                    "recent complement density for each candidate residual",
                    "difference between alternative and chosen recent density",
                )
                predictions = (
                    "the recent-density sign predicts which residual receives "
                    "more future complements on held-out suffixes",
                    "history shuffling destroys the intervention effect while "
                    "preserving the item multiset",
                )
            else:
                relations = (
                    CausalRelationKind
                    .INFORMATION_REVEALED_AFTER_COMMITMENT,
                    CausalRelationKind.COMMITMENT_DESTROYS_OPTION,
                    CausalRelationKind.ALTERNATIVE_PRESERVES_OPTION,
                    CausalRelationKind
                    .PRESERVED_OPTION_CHANGES_OUTCOME,
                )
                unavailable = (
                    "future complement demand was unavailable and the recent "
                    "arrival history was not a reliable predictor at decision "
                    "%d" % representative.decision_index
                )
                proxies = (
                    "open-bin residual diversity",
                    "large-item-compatible residual count",
                )
                predictions = (
                    "the intervention retains benefit after history shuffling",
                    "benefit concentrates where the alternative preserves a "
                    "residual option destroyed by the chosen placement",
                )
            trace_ids = tuple(
                trace_digest for _, _, trace_digest in group
            )
            evidence_ids = tuple(
                dict.fromkeys(
                    (
                        *trace_ids,
                        *(
                            record.artifact_digest
                            or failure_mining_digest
                            for record, _, _ in group
                        ),
                    )
                )
            )
            cluster_id = (
                "round-%d:causal-schema:%s"
                % (
                    round_index,
                    content_digest(
                        {"causal_signature": list(signature)}
                    )[:16],
                )
            )
            mean_effect = (
                mean(trace.outcome_delta for trace in supported)
                if supported
                else 0.0
            )
            if empirical_support:
                capacity = float(representative.instance.capacity)
                causal_prototypes.append(
                    CausalStatePrototype(
                        cluster_id=cluster_id,
                        item_fraction=representative.item / capacity,
                        progress=min(
                            1.0,
                            representative.decision_index / 256.0,
                        ),
                        fallback_remaining_fraction=(
                            representative.chosen_remaining_after / capacity
                        ),
                        alternative_remaining_fraction=(
                            representative.alternative_remaining_after
                            / capacity
                        ),
                        recent_proxy_advantage=max(
                            -1.0,
                            min(
                                1.0,
                                representative.recent_alternative_proxy
                                - representative.recent_chosen_proxy,
                            ),
                        ),
                        proxy_reliability=mean(
                            trace.proxy_reliability for trace in traces
                        ),
                        mediator=representative.mediator,
                    )
                )
            models.append(
                CausalFailureModel(
                    target_node_id=node_id,
                    cluster_id=cluster_id,
                    cluster_description=(
                        "%d adversarial sequence(s) share decision-level "
                        "signature %s for target %s; the earliest effective "
                        "intervention occurred at item %d and saved %.2f "
                        "suffix bins"
                        % (
                            len(group),
                            "/".join(signature),
                            target_ref,
                            representative.decision_index,
                            mean_effect,
                        )
                    ),
                    unavailable_information=unavailable,
                    information_available_after=(
                        "%d versus %d future near-complements were observed "
                        "for the chosen and alternative residuals only after "
                        "commitment"
                        % (
                            representative.future_chosen_complements,
                            representative.future_alternative_complements,
                        )
                    ),
                    irreversible_decision=(
                        "place item %d at decision %d into action %s, leaving "
                        "residual %d"
                        % (
                            representative.item,
                            representative.decision_index,
                            representative.chosen_action,
                            representative.chosen_remaining_after,
                        )
                    ),
                    decision_point=(
                        "the first replayed online placement whose feasible "
                        "one-step deviation changes the suffix outcome"
                    ),
                    alternative_action=(
                        "use feasible action %s at decision %d, leaving "
                        "residual %d, then resume the unchanged policy"
                        % (
                            representative.alternative_action,
                            representative.decision_index,
                            representative.alternative_remaining_after,
                        )
                    ),
                    changed_result=(
                        "decision-level suffix replay changes final bin count "
                        "by %.2f through %s"
                        % (mean_effect, representative.mediator)
                    ),
                    causal_chain=(
                        "future demand is hidden; the chosen placement changes "
                        "one residual irreversibly; the replayed alternative "
                        "changes %s; the unchanged suffix policy then uses "
                        "%.2f fewer bins" % (
                            representative.mediator,
                            mean_effect,
                        )
                    ),
                    causal_relations=relations,
                    observable_proxies=proxies,
                    evidence_ids=evidence_ids,
                    assumptions=(
                        "a one-step deviation followed by the unchanged policy "
                        "isolates an actionable local intervention",
                        "offline future data diagnoses causality but is never "
                        "exposed to the online candidate",
                    ),
                    distinguishing_predictions=predictions,
                    falsification_conditions=(
                        "the forced one-step action does not improve final "
                        "suffix bin count",
                        "the proposed mediator is unchanged by the forced "
                        "action under matched replay",
                    ),
                    modeler_ref=(
                        "binpacking-candidate-contrast-model-builder-v3"
                    ),
                    decision_trace_ids=trace_ids,
                    causal_signature=signature,
                    information_regime=regime.value,
                    mediator=representative.mediator,
                    counterfactual_effect=float(mean_effect),
                    proxy_reliability=mean(
                        trace.proxy_reliability for trace in traces
                    ),
                    empirically_supported=empirical_support,
                )
            )
        return (
            CausalFailureModelSet(
                target_node_id=node_id,
                failure_cluster_ids=tuple(
                    model.cluster_id for model in models
                ),
                models=tuple(models),
                source_artifact_ids=tuple(
                    dict.fromkeys(
                        (failure_mining_digest, *trace_artifact_ids)
                    )
                ),
                builder_ref=(
                    "binpacking-candidate-contrast-model-builder-v3"
                ),
            ),
            tuple(causal_prototypes),
        )

    def _repair_suite(
        self,
        round_index: int,
        node_id: str,
    ) -> Tuple[
        Tuple[BinPackingInstance, ...],
        str,
        CausalFailureModelSet,
        str,
        Tuple[CausalStatePrototype, ...],
    ]:
        round_seed = self.config.base_seed + round_index * 10_000_000
        target = self._failure_target or self.incumbent
        comparator = (
            self.incumbent
            if self._failure_target is not None
            else self.best_fit
        )
        target_ref = (
            self._failure_target_candidate_id
            or self.adapter.candidate_id(self.incumbent)
        )
        adversary = evolve_adversarial_sequences(
            AdversaryConfig(
                seed=round_seed + 101,
                evaluation_budget=self.config.adversary_budget_per_round,
                initial_population=(
                    self.config.adversary_initial_population
                ),
                length=self.config.development_length,
                capacity=self.config.capacity,
                minimum_item=20,
                maximum_item=100,
            ),
            target,
            comparator,
            artifact_store=self.store,
        )
        ranked = tuple(
            sorted(
                adversary.evaluated,
                key=lambda item: (
                    item.target_gap,
                    item.target_excess,
                    item.fitness,
                    item.instance.instance_id,
                ),
                reverse=True,
            )
        )
        repair = tuple(
            item.instance
            for item in ranked[: self.config.repair_case_count]
        )
        digest = self.store.put(
            "binpacking_v2_failure_mining_round",
            {
                **adversary.as_dict(),
                "causal_target_ref": target_ref,
                "causal_target_name": target.name,
                "comparator_name": comparator.name,
                "candidate_specific_feedback": (
                    self._failure_target is not None
                ),
            },
        )
        causal_models, causal_prototypes = self._causal_failure_models(
            node_id=node_id,
            round_index=round_index,
            adversary=adversary,
            failure_mining_digest=digest,
            target=target,
            target_ref=target_ref,
        )
        causal_model_digest = self.store.put(
            "binpacking_causal_failure_model_set",
            causal_models.as_dict(),
        )
        return (
            repair,
            digest,
            causal_models,
            causal_model_digest,
            causal_prototypes,
        )

    def _override_training_suite(
        self,
        round_index: int,
        repair: Sequence[BinPackingInstance],
        causal_prototypes: Sequence[CausalStatePrototype],
    ) -> Tuple[Tuple[BinPackingInstance, ...], Optional[str]]:
        target_count = self.config.override_training_case_count
        if target_count == 0:
            return tuple(repair), None
        cases_per_family = max(1, (target_count + 2) // 3)
        generated = _suite(
            families=("or_uniform", "bimodal", "complementary_pairs"),
            seed_start=(
                self.config.base_seed
                + round_index * 10_000_000
                + 650_000
            ),
            cases_per_family=cases_per_family,
            length=self.config.development_length,
            capacity=self.config.capacity,
        )
        repair_ids = {instance.instance_id for instance in repair}
        suite = tuple(
            instance
            for instance in generated
            if instance.instance_id not in repair_ids
        )[:target_count]
        if len(suite) != target_count:
            raise ValueError(
                "episode-transport suite could not be isolated from "
                "causal-prototype evidence"
            )
        suite_ids = {instance.instance_id for instance in suite}
        if repair_ids.intersection(suite_ids):
            raise ValueError(
                "causal-prototype evidence leaked into episode transport"
            )
        digest = self.store.put(
            "binpacking_override_episode_training_suite",
            {
                "schema": 1,
                "round_index": round_index,
                "role": "inner_episode_transport_only",
                "instance_count": len(suite),
                "repair_instance_ids": [
                    instance.instance_id for instance in repair
                ],
                "prototype_source_instance_ids": sorted(repair_ids),
                "generated_instance_ids": [
                    instance.instance_id for instance in suite
                ],
                "prototype_source_overlap_count": 0,
                "causal_cluster_ids": [
                    prototype.cluster_id for prototype in causal_prototypes
                ],
                "instances": [instance.as_dict() for instance in suite],
                "outer_partition_access": False,
            },
        )
        return suite, digest

    def _select_failure_target(
        self,
        outcomes: Mapping[str, IslandSearchOutcome],
        probe: Sequence[BinPackingInstance],
    ) -> Optional[Tuple[str, IslandCandidateRecord]]:
        """Choose a promising, nontrivial candidate whose failures come next."""
        incumbent_fingerprint = behaviour_fingerprint(
            self.incumbent,
            probe,
        )
        candidates = tuple(
            (island, record)
            for island, outcome in outcomes.items()
            for record in outcome.evaluated
            if (
                (
                    record.eligible
                    or (
                        record.exploration_lane
                        and record.discovery_assessment
                        .admitted_for_exploration
                    )
                )
                and record.repair_report.wins > 0
                and record.behavior_fingerprint != incumbent_fingerprint
            )
        )
        if not candidates:
            return None
        return max(candidates, key=lambda item: item[1].rank)

    def _search_one(
        self,
        *,
        round_index: int,
        island: str,
        repair: Sequence[BinPackingInstance],
        guard: Sequence[BinPackingInstance],
        carried: Sequence[OnlineHeuristic],
        proposer: Any,
        literature_context: LiteratureHypothesisContext,
    ) -> IslandSearchOutcome:
        exploration_lane = (
            island == "de_novo"
            and self.moonshot_exploration_lane
        )
        return run_island_search(
            IslandSearchConfig(
                island=island,
                seed=(
                    self.config.base_seed
                    + round_index * 10_000_000
                    + {
                        "funsearch_ancestry": 600_000,
                        "de_novo": 610_000,
                        "hybrid": 620_000,
                    }[island]
                ),
                evaluation_budget=(
                    self.config.candidate_budget_per_island
                ),
                initial_random=self.config.initial_random_candidates,
                residual_scale=self.config.residual_scale,
                research_guard_mean_delta_ceiling=0.0,
                research_guard_regression_fraction_ceiling=0.35,
                research_guard_max_regression=1,
                guard_mean_delta_ceiling=0.0,
                guard_regression_fraction_ceiling=0.0,
                guard_max_regression=1,
                exploration_lane=exploration_lane,
                minimum_mechanism_distance=(
                    3 if exploration_lane else 0
                ),
                require_incumbent_blind=exploration_lane,
                require_new_decision_primitive=exploration_lane,
                exploration_mean_regression_ceiling=4.0,
                exploration_regression_fraction_ceiling=0.85,
                exploration_max_regression=8,
            ),
            repair,
            guard,
            self.incumbent,
            carried_programs=carried,
            proposer=proposer,
            literature_context=literature_context,
            artifact_store=self.store,
        )

    @staticmethod
    def _deduplicated(values: Iterable[str]) -> Tuple[str, ...]:
        observed = set()
        result = []
        for value in values:
            if value in observed:
                continue
            observed.add(value)
            result.append(value)
        return tuple(result)

    def _register_outcome(
        self,
        leaf: GoalNodeSpec,
        outcome: IslandSearchOutcome,
        round_index: int,
        cross_sources: Tuple[str, ...] = (),
    ) -> Tuple[str, Mapping[str, str]]:
        family = self._FAMILY_BY_ISLAND[outcome.config.island]
        latest_best = ""
        registered: Dict[str, str] = {}
        for record in outcome.evaluated:
            previous_same = self._domain_lineage[family].get(
                record.program.candidate_id
            )
            parent_v2_ids = []
            for parent_id in record.parent_ids:
                mapped = self._domain_lineage[family].get(parent_id)
                if mapped is not None:
                    parent_v2_ids.append(mapped)
            if previous_same is not None:
                parent_v2_ids.append(previous_same)
            if family == SearchFamily.ANCESTRY and not parent_v2_ids:
                parent_v2_ids.append(
                    self.adapter.candidate_id(self.incumbent)
                )
            if family == SearchFamily.HYBRID:
                parent_v2_ids.extend(cross_sources)
            executable_digest = self.store.put(
                "domain_candidate",
                dict(self.adapter.candidate_as_dict(record.program)),
            )
            proposal = IslandCandidateProposal(
                node_id=leaf.node_id,
                family=family,
                executable_digest=executable_digest,
                mechanism_summary=(
                    "%s: %s"
                    % (
                        record.operator,
                        record.program.as_dict()["rendered"],
                    )
                ),
                ancestry_ids=self._deduplicated(parent_v2_ids),
                proposer_ref=outcome.proposer_name,
                round_index=round_index,
                exposed_information=default_information_views()[family],
                literature_context_id=outcome.literature_context_id,
                literature_evidence_ids=(
                    outcome.literature_evidence_ids
                ),
            )
            self.runtime.transact("submit_candidate", proposal)
            self._domain_lineage[family][
                record.program.candidate_id
            ] = proposal.candidate_id
            self._programs[proposal.candidate_id] = record.program
            registered[record.program.candidate_id] = proposal.candidate_id
            if (
                record.program.candidate_id
                == outcome.best.program.candidate_id
            ):
                latest_best = proposal.candidate_id
        if not latest_best:
            raise ValueError("search outcome did not register its best candidate")
        return latest_best, dict(registered)

    @staticmethod
    def _pareto_nominees(
        outcome: IslandSearchOutcome,
        limit: int,
    ) -> Tuple[IslandCandidateRecord, ...]:
        """Fix a small research shortlist before any audit evidence is read."""
        if outcome.config.exploration_lane:
            pool = tuple(
                record
                for record in outcome.evaluated
                if record.discovery_assessment.admitted_for_exploration
            )
        else:
            pool = tuple(
                record for record in outcome.evaluated if record.eligible
            )
        if not pool:
            pool = outcome.evaluated

        def objectives(record: IslandCandidateRecord) -> Tuple[float, ...]:
            truth_objectives = (
                record.repair_report.mean_delta,
                record.guard_report.mean_delta,
                float(record.guard_report.losses),
                float(record.guard_report.maximum_regression),
                float(record.program.complexity),
            )
            if not outcome.config.exploration_lane:
                return truth_objectives
            return (
                -record.discovery_assessment.discovery_score,
                -float(
                    record.discovery_assessment
                    .mechanism_distance.structural_distance
                ),
                -record.discovery_assessment.behavior_distance,
                *truth_objectives,
            )

        frontier = []
        for candidate in pool:
            candidate_objectives = objectives(candidate)
            dominated = any(
                all(
                    left <= right
                    for left, right in zip(
                        objectives(other),
                        candidate_objectives,
                    )
                )
                and any(
                    left < right
                    for left, right in zip(
                        objectives(other),
                        candidate_objectives,
                    )
                )
                for other in pool
                if other.program.candidate_id
                != candidate.program.candidate_id
            )
            if not dominated:
                frontier.append(candidate)
        ordered = sorted(
            frontier or list(pool),
            key=lambda record: (
                *objectives(record),
                record.program.candidate_id,
            ),
        )
        return tuple(ordered[:limit])

    def _initialize_novelty_probe(self) -> Tuple[
        BinPackingInstance, ...
    ]:
        probe = _suite(
            families=tuple(sorted(GENERATORS)),
            seed_start=self.config.base_seed + 120_000_000,
            cases_per_family=20,
            length=self.config.development_length,
            capacity=self.config.capacity,
        )
        controls = {
            **baseline_heuristics(),
            **literature_heuristics(),
            "prior_exact_fill_action": ActionHybridProgram(
                Expression.binary(
                    "sub",
                    Expression.const(0.0),
                    Expression.feature("remaining_after"),
                ),
                Expression.const(1.0),
                self.config.residual_scale,
            ),
        }
        self._known_novelty_fingerprints = {
            name: behaviour_fingerprint(candidate, probe)
            for name, candidate in controls.items()
        }
        self.store.put(
            "binpacking_v2_preregistered_novelty_probe",
            {
                "experiments": [item.as_dict() for item in probe],
                "excluded_fingerprints": dict(
                    sorted(self._known_novelty_fingerprints.items())
                ),
                "excluded_mechanisms": (
                    "best-fit and exact-fill behavior",
                    "published FunSearch tight-fit behavior",
                    "first-fit, worst-fit, and next-fit controls",
                ),
            },
        )
        return probe

    def _novelty_audit(
        self,
        candidate_id: str,
        probe: Sequence[BinPackingInstance],
    ) -> Mapping[str, Any]:
        candidate = self._programs[candidate_id]
        fingerprint = behaviour_fingerprint(candidate, probe)
        matches = tuple(
            name
            for name, known in sorted(
                self._known_novelty_fingerprints.items()
            )
            if fingerprint == known
        )
        semantic = assess_semantic_novelty(
            candidate,
            probe,
            capacity=self.config.capacity,
        )
        report = {
            "candidate_id": candidate_id,
            "candidate_fingerprint": fingerprint,
            "matched_prior_behaviors": list(matches),
            "semantic_assessment": semantic,
            "passed": not matches and semantic["passed"],
            "interpretation": (
                "behaviorally and semantically distinct from registered "
                "prior mechanism families; literature closure is still "
                "required"
                if not matches and semantic["passed"]
                else "candidate duplicates or reduces to a registered "
                "prior mechanism family"
            ),
        }
        digest = self.store.put(
            "binpacking_v2_novelty_audit",
            report,
        )
        completed = {**report, "artifact_digest": digest}
        self._semantic_novelty_results[candidate_id] = completed
        return completed

    def _contribution_audit(
        self,
        candidate_id: str,
        instances: Sequence[BinPackingInstance],
        *,
        stage: str,
    ) -> Mapping[str, Any]:
        report = dict(
            assess_composite_contribution(
                self._programs[candidate_id],
                self.incumbent,
                instances,
                minimum_action_disagreement_rate=(
                    self.config
                    .minimum_module_action_disagreement_rate
                ),
                minimum_action_disagreements=(
                    self.config.minimum_module_action_disagreements
                ),
            )
        )
        report["stage"] = stage
        report["suite_digest"] = content_digest(
            {
                "stage": stage,
                "instances": [
                    instance.as_dict() for instance in instances
                ],
            }
        )
        digest = self.store.put(
            "binpacking_composite_contribution_audit",
            report,
        )
        completed = {**report, "artifact_digest": digest}
        self._contribution_results[candidate_id] = completed
        return completed

    def _run_search(
        self,
        leaf: GoalNodeSpec,
        contract: IslandCampaignContract,
    ) -> Tuple[Optional[str], Mapping[str, Any]]:
        audit_gate = next(
            gate
            for gate in contract.gates
            if gate.kind == GateKind.REPLICATION_NOMINATION
        )
        replication_gate = next(
            gate
            for gate in contract.gates
            if gate.kind == GateKind.INCUMBENT_ADVANCE
        )
        novelty_probe = self._initialize_novelty_probe()
        carried: Dict[str, Tuple[OnlineHeuristic, ...]] = {
            "funsearch_ancestry": (),
            "de_novo": (),
            "hybrid": (),
        }
        previous_best_programs: Dict[str, OnlineHeuristic] = {}
        previous_best_ids: Dict[str, str] = {}
        previous_de_novo_sources: Tuple[MoonshotProgram, ...] = ()
        previous_de_novo_ids: Tuple[str, ...] = ()
        round_reports = []
        selected_candidate_id: Optional[str] = None
        selected_audit_delta = 0.0
        replication_record = None
        replication_decision = None
        replication_contribution = None

        for round_index in range(self.config.rounds):
            causal_target_ref = (
                self._failure_target_candidate_id
                or self.adapter.candidate_id(self.incumbent)
            )
            candidate_specific_feedback = self._failure_target is not None
            (
                repair,
                failure_mining_digest,
                causal_failure_models,
                causal_failure_model_digest,
                causal_state_prototypes,
            ) = self._repair_suite(round_index, leaf.node_id)
            (
                round_literature,
                literature_contexts,
                literature_context_artifacts,
            ) = self._literature_contexts_for_round(
                leaf,
                causal_failure_models,
                round_index,
            )
            guard = _multiscale_or_suite(
                self.config,
                seed_start=(
                    self.config.base_seed
                    + round_index * 10_000_000
                    + 2_000_000
                ),
                cases_per_length=self.config.guard_cases_per_length,
            )
            audit = _multiscale_or_suite(
                self.config,
                seed_start=(
                    self.config.base_seed
                    + round_index * 10_000_000
                    + 4_000_000
                ),
                cases_per_length=self.config.audit_cases_per_length,
            )
            outcomes: Dict[str, IslandSearchOutcome] = {}
            best_ids: Dict[str, str] = {}
            round_candidate_ids: Dict[str, str] = {}
            round_audits: Dict[str, list[Mapping[str, Any]]] = {}
            override_value_training: Optional[Mapping[str, Any]] = None
            outcomes["funsearch_ancestry"] = self._search_one(
                round_index=round_index,
                island="funsearch_ancestry",
                repair=repair,
                guard=guard,
                carried=carried["funsearch_ancestry"],
                proposer=self._ancestry_proposer(
                    literature_contexts["funsearch_ancestry"]
                ),
                literature_context=(
                    literature_contexts["funsearch_ancestry"]
                ),
            )
            outcomes["de_novo"] = self._search_one(
                round_index=round_index,
                island="de_novo",
                repair=repair,
                guard=guard,
                carried=carried["de_novo"],
                proposer=self._de_novo_proposer(
                    literature_contexts["de_novo"]
                ),
                literature_context=literature_contexts["de_novo"],
            )
            if round_index >= contract.isolation_rounds:
                ancestry_source = previous_best_programs[
                    "funsearch_ancestry"
                ]
                hybrid_proposer = self._hybrid_proposer(
                    ancestry_source,
                    previous_de_novo_sources,
                    literature_contexts["hybrid"],
                )
                (
                    override_training_suite,
                    override_training_suite_digest,
                ) = self._override_training_suite(
                    round_index,
                    repair,
                    causal_state_prototypes,
                )
                try:
                    training_result = fit_calibrated_override_value_model(
                        override_training_suite,
                        ancestry_source,
                        seed=(
                            self.config.base_seed
                            + round_index * 10_000_000
                            + 615_000
                        ),
                        causal_prototypes=causal_state_prototypes,
                        max_trace_decisions_per_instance=(
                            self.config
                            .override_trace_decisions_per_instance
                        ),
                        require_causal_prototypes=True,
                    )
                except ValueError as error:
                    training_value = {
                        "schema": 1,
                        "training_version": (
                            "binpacking-trajectory-credit-override-value-v6"
                        ),
                        "round_index": round_index,
                        "ancestry_candidate_id": (
                            ancestry_source.candidate_id
                        ),
                        "outcome": "insufficient_nested_holdout_evidence",
                        "reason": str(error),
                        "training_suite_digest": (
                            override_training_suite_digest
                        ),
                        "training_instance_count": len(
                            override_training_suite
                        ),
                        "causal_prototype_count": len(
                            causal_state_prototypes
                        ),
                    }
                    training_digest = self.store.put(
                        "binpacking_calibrated_override_value_training",
                        training_value,
                    )
                    self._override_value_training_artifacts[
                        round_index
                    ] = training_digest
                    override_value_training = {
                        "artifact_digest": training_digest,
                        "deployment_enabled": False,
                        "outcome": training_value["outcome"],
                        "reason": str(error),
                    }
                else:
                    trace_artifact_ids = tuple(
                        self.store.put(
                            "binpacking_action_value_counterfactual_trace",
                            trace.as_dict(),
                        )
                        for trace in training_result.traces
                    )
                    rollout_artifact_ids = tuple(
                        self.store.put(
                            "binpacking_closed_loop_override_rollout",
                            rollout.as_dict(),
                        )
                        for rollout in training_result.closed_loop_rollouts
                    )
                    trajectory_credit_artifact_ids = tuple(
                        self.store.put(
                            "binpacking_trajectory_intervention_credit",
                            credit.as_dict(),
                        )
                        for credit in training_result.trajectory_credits
                    )
                    training_value = {
                        **training_result.as_dict(),
                        "round_index": round_index,
                        "ancestry_candidate_id": (
                            ancestry_source.candidate_id
                        ),
                        "trace_artifact_ids": list(trace_artifact_ids),
                        "closed_loop_rollout_artifact_ids": list(
                            rollout_artifact_ids
                        ),
                        "trajectory_credit_artifact_ids": list(
                            trajectory_credit_artifact_ids
                        ),
                        "outer_evaluation_partitions": [
                            "development_guard",
                            "audit",
                            "replication",
                        ],
                        "training_suite_digest": (
                            override_training_suite_digest
                        ),
                        "training_instance_count": len(
                            override_training_suite
                        ),
                        "causal_prototype_count": len(
                            causal_state_prototypes
                        ),
                    }
                    training_digest = self.store.put(
                        "binpacking_calibrated_override_value_training",
                        training_value,
                    )
                    self._override_value_training_artifacts[
                        round_index
                    ] = training_digest
                    override_value_training = {
                        "artifact_digest": training_digest,
                        "model_id": training_result.model.model_id,
                        "deployment_enabled": (
                            training_result.model.deployment_enabled
                        ),
                        "trace_count": training_result.trace_count,
                        "action_row_count": training_result.action_row_count,
                        "trajectory_credit_count": len(
                            training_result.trajectory_credits
                        ),
                        "training_instance_count": len(
                            override_training_suite
                        ),
                        "causal_prototype_count": len(
                            causal_state_prototypes
                        ),
                        "partition_metrics": {
                            name: dict(metrics)
                            for name, metrics
                            in training_result.partition_metrics
                        },
                        "calibration_metrics": dict(
                            training_result.model.calibration_metrics
                        ),
                    }
                    if training_result.model.deployment_enabled:
                        hybrid_proposer = CalibratedOverrideHybridProposer(
                            hybrid_proposer,
                            ancestry_source,
                            training_result.model,
                        )
                outcomes["hybrid"] = self._search_one(
                    round_index=round_index,
                    island="hybrid",
                    repair=repair,
                    guard=guard,
                    carried=carried["hybrid"],
                    proposer=hybrid_proposer,
                    literature_context=literature_contexts["hybrid"],
                )

            for island, outcome in outcomes.items():
                cross_sources = (
                    (
                        previous_best_ids["funsearch_ancestry"],
                        *previous_de_novo_ids,
                    )
                    if island == "hybrid"
                    else ()
                )
                (
                    best_ids[island],
                    proposal_ids_by_program,
                ) = self._register_outcome(
                    leaf,
                    outcome,
                    round_index,
                    cross_sources=cross_sources,
                )
                round_candidate_ids.update(proposal_ids_by_program)
                nominees = self._pareto_nominees(
                    outcome,
                    self.config.audit_nominees_per_island,
                )
                round_audits[island] = []
                for nominee in nominees:
                    candidate_id = proposal_ids_by_program[
                        nominee.program.candidate_id
                    ]
                    record, decision = (
                        self.runtime.evaluate_and_record_batch(
                            adapter=self.adapter,
                            node_id=leaf.node_id,
                            candidate_id=candidate_id,
                            candidate=self._programs[candidate_id],
                            incumbent=self.incumbent,
                            experiments=audit,
                            partition=EvidencePartition.AUDIT,
                            gate_contract_id=audit_gate.contract_id,
                        )
                    )
                    novelty = self._novelty_audit(
                        candidate_id,
                        novelty_probe,
                    )
                    contribution = self._contribution_audit(
                        candidate_id,
                        audit,
                        stage="audit",
                    )
                    self._audit_results[candidate_id] = (record, decision)
                    round_audits[island].append(
                        {
                            "candidate_id": candidate_id,
                            "research_eligible": nominee.eligible,
                            "development_deployment_safe": (
                                nominee.deployment_safe
                            ),
                            "exploration_lane": (
                                nominee.exploration_lane
                            ),
                            "discovery_assessment": (
                                nominee.discovery_assessment.as_dict()
                            ),
                            "behavior_fingerprint": (
                                nominee.behavior_fingerprint
                            ),
                            "verification": record.as_dict(),
                            "gate_decision": decision.as_dict(),
                            "novelty": novelty,
                            "causal_contribution": contribution,
                        }
                    )
                    if (
                        decision.passed
                        and novelty["passed"]
                        and contribution["passed"]
                        and (
                            selected_candidate_id is None
                            or record.metrics["primary_delta"]
                            < selected_audit_delta
                        )
                    ):
                        selected_candidate_id = candidate_id
                        selected_audit_delta = record.metrics[
                            "primary_delta"
                        ]

            any_gate_passed = any(
                audit_item["gate_decision"]["passed"]
                and audit_item["novelty"]["passed"]
                and audit_item["causal_contribution"]["passed"]
                for island_audits in round_audits.values()
                for audit_item in island_audits
            )
            next_failure_target = self._select_failure_target(
                outcomes,
                (*repair, *guard),
            )
            candidate_failure_digest = None
            if next_failure_target is not None:
                target_island, target_record = next_failure_target
                next_target_id = round_candidate_ids[
                    target_record.program.candidate_id
                ]
                candidate_failure_digest = self.store.put(
                    "binpacking_candidate_failure_contrast",
                    {
                        "round_index": round_index,
                        "candidate_id": next_target_id,
                        "island": target_island,
                        "candidate": target_record.program.as_dict(),
                        "behavior_fingerprint": (
                            target_record.behavior_fingerprint
                        ),
                        "research_eligible": target_record.eligible,
                        "development_deployment_safe": (
                            target_record.deployment_safe
                        ),
                        "exploration_lane": (
                            target_record.exploration_lane
                        ),
                        "discovery_assessment": (
                            target_record.discovery_assessment.as_dict()
                        ),
                        "repair_report": (
                            target_record.repair_report.as_dict()
                        ),
                        "guard_report": (
                            target_record.guard_report.as_dict()
                        ),
                        "next_round_use": (
                            "mine and causally trace this candidate's losses "
                            "against the incumbent"
                        ),
                    },
                )
                self._failure_target = target_record.program
                self._failure_target_candidate_id = next_target_id
            if (
                round_index == self.config.rounds - 1
                and selected_candidate_id is not None
            ):
                replication = _multiscale_or_suite(
                    self.config,
                    seed_start=self.config.base_seed + 160_000_000,
                    cases_per_length=(
                        self.config.replication_cases_per_length
                    ),
                )
                replication_record, replication_decision = (
                    self.runtime.evaluate_and_record_batch(
                        adapter=self.adapter,
                        node_id=leaf.node_id,
                        candidate_id=selected_candidate_id,
                        candidate=self._programs[selected_candidate_id],
                        incumbent=self.incumbent,
                        experiments=replication,
                        partition=EvidencePartition.REPLICATION,
                        gate_contract_id=replication_gate.contract_id,
                    )
                )
                replication_contribution = self._contribution_audit(
                    selected_candidate_id,
                    replication,
                    stage="replication",
                )
                if (
                    replication_decision.passed
                    and replication_contribution["passed"]
                ):
                    self.runtime.transact(
                        "nominate_local_candidate",
                        leaf.node_id,
                        selected_candidate_id,
                    )
            campaign = self.control.campaigns[contract.campaign_id]
            round_proposals = tuple(
                proposal
                for proposal in campaign.proposals.values()
                if proposal.round_index == round_index
            )
            attempts_by_family = {
                family: sum(
                    proposal.family == family
                    for proposal in round_proposals
                )
                for family in (
                    SearchFamily.ANCESTRY,
                    SearchFamily.DE_NOVO,
                    SearchFamily.HYBRID,
                )
            }
            ancestries_by_family = {
                family: len(
                    {
                        (
                            proposal.ancestry_ids
                            if proposal.ancestry_ids
                            else (proposal.candidate_id,)
                        )
                        for proposal in round_proposals
                        if proposal.family == family
                    }
                )
                for family in (
                    SearchFamily.ANCESTRY,
                    SearchFamily.DE_NOVO,
                    SearchFamily.HYBRID,
                )
            }
            verified_effects = tuple(
                verification.effect_size
                for proposal in round_proposals
                for verification in campaign.verifications.get(
                    proposal.candidate_id,
                    (),
                )
            )
            diagnosis = self.runtime.transact(
                "complete_campaign_round",
                CampaignRoundSummary(
                    node_id=leaf.node_id,
                    round_index=round_index,
                    attempts_by_family=attempts_by_family,
                    distinct_ancestries_by_family=ancestries_by_family,
                    best_verified_effect=max(verified_effects),
                    confidence_sufficient=any_gate_passed,
                    failure_signature=(
                        "audit_gate_passed"
                        if any_gate_passed
                        else "no_prior_art_distinct_audit_advance"
                    ),
                    compute_spent=float(
                        sum(attempts_by_family.values())
                    ),
                    budget_complete=True,
                    causal_failure_models=causal_failure_models,
                ),
            )
            round_reports.append(
                {
                    "round_index": round_index,
                    "failure_mining_digest": failure_mining_digest,
                    "literature_assessment_id": (
                        round_literature.assessment_id
                    ),
                    "literature_searched_at": (
                        round_literature.searched_at
                    ),
                    "literature_context_ids": {
                        island: context.context_id
                        for island, context in sorted(
                            literature_contexts.items()
                        )
                    },
                    "literature_context_artifacts": dict(
                        sorted(literature_context_artifacts.items())
                    ),
                    "literature_source_counts": {
                        island: len(context.source_work_ids)
                        for island, context in sorted(
                            literature_contexts.items()
                        )
                    },
                    "causal_failure_model_digest": (
                        causal_failure_model_digest
                    ),
                    "causal_failure_model_set_id": (
                        causal_failure_models.model_set_id
                    ),
                    "causal_target_ref": causal_target_ref,
                    "candidate_specific_feedback": (
                        candidate_specific_feedback
                    ),
                    "next_candidate_failure_contrast_digest": (
                        candidate_failure_digest
                    ),
                    "failure_cluster_count": len(
                        causal_failure_models.failure_cluster_ids
                    ),
                    "override_value_training": override_value_training,
                    "best_candidate_ids": dict(sorted(best_ids.items())),
                    "behavior_diversity_by_family": {
                        self._FAMILY_BY_ISLAND[island].value: len(
                            {
                                record.behavior_fingerprint
                                for record in outcome.evaluated
                            }
                        )
                        for island, outcome in outcomes.items()
                    },
                    "discovery_by_family": {
                        self._FAMILY_BY_ISLAND[island].value: {
                            "exploration_lane": (
                                outcome.config.exploration_lane
                            ),
                            "admitted_count": sum(
                                record.discovery_assessment
                                .admitted_for_exploration
                                for record in outcome.evaluated
                            ),
                            "best_discovery_score": max(
                                record.discovery_assessment
                                .discovery_score
                                for record in outcome.evaluated
                            ),
                            "decision_topologies": sorted(
                                {
                                    record.discovery_assessment
                                    .mechanism_distance
                                    .candidate_topology
                                    for record in outcome.evaluated
                                }
                            ),
                            "structural_module_topologies": sorted(
                                {
                                    (
                                        record.program.moonshot.topology
                                        if isinstance(
                                            record.program,
                                            (
                                                MoonshotHybridProgram,
                                                StructuralHybridProgram,
                                            ),
                                        )
                                        else (
                                            "causal_cluster_episode_"
                                            "transport_override"
                                        )
                                    )
                                    for record in outcome.evaluated
                                    if isinstance(
                                        record.program,
                                        (
                                            MoonshotHybridProgram,
                                            StructuralHybridProgram,
                                            CalibratedOverrideHybridProgram,
                                        ),
                                    )
                                }
                            ),
                            "research_eligible_count": sum(
                                record.eligible
                                for record in outcome.evaluated
                            ),
                        }
                        for island, outcome in outcomes.items()
                    },
                    "audits": dict(sorted(round_audits.items())),
                    "plateau": diagnosis.as_dict(),
                }
            )
            previous_best_programs = {
                island: outcome.best.program
                for island, outcome in outcomes.items()
                if island != "hybrid"
            }
            previous_best_ids = {
                island: candidate_id
                for island, candidate_id in best_ids.items()
                if island != "hybrid"
            }
            de_novo_representatives = {}
            for record in sorted(
                outcomes["de_novo"].evaluated,
                key=lambda item: item.rank,
                reverse=True,
            ):
                if not isinstance(record.program, MoonshotProgram):
                    raise ValueError(
                        "de-novo topology archive contains another type"
                    )
                de_novo_representatives.setdefault(
                    record.program.topology,
                    record.program,
                )
            previous_de_novo_sources = tuple(
                de_novo_representatives[topology]
                for topology in MOONSHOT_TOPOLOGIES
                if topology in de_novo_representatives
            )
            if not previous_de_novo_sources:
                raise ValueError(
                    "de-novo search produced no topology representative"
                )
            previous_de_novo_ids = tuple(
                round_candidate_ids[source.candidate_id]
                for source in previous_de_novo_sources
            )
            for island, outcome in outcomes.items():
                carried[island] = tuple(
                    record.program
                    for record in sorted(
                        outcome.archive,
                        key=lambda item: item.rank,
                        reverse=True,
                    )[:6]
                )

        if selected_candidate_id is None:
            return None, {
                "rounds": round_reports,
                "selection": "no prior-art-distinct audit gate passed",
            }
        assert replication_record is not None
        assert replication_decision is not None
        if not replication_decision.passed:
            return None, {
                "rounds": round_reports,
                "selected_candidate_id": selected_candidate_id,
                "replication": replication_record.as_dict(),
                "replication_gate_decision": (
                    replication_decision.as_dict()
                ),
                "replication_contribution": (
                    replication_contribution
                ),
                "selection": "frozen replication gate failed",
            }
        assert replication_contribution is not None
        if not replication_contribution["passed"]:
            return None, {
                "rounds": round_reports,
                "selected_candidate_id": selected_candidate_id,
                "replication": replication_record.as_dict(),
                "replication_gate_decision": (
                    replication_decision.as_dict()
                ),
                "replication_contribution": (
                    replication_contribution
                ),
                "selection": (
                    "frozen replication causal-contribution gate failed"
                ),
            }
        return selected_candidate_id, {
            "rounds": round_reports,
            "selected_candidate_id": selected_candidate_id,
            "replication": replication_record.as_dict(),
            "replication_gate_decision": (
                replication_decision.as_dict()
            ),
            "replication_contribution": replication_contribution,
            "selection": "frozen replication gate passed",
        }

    def run(self) -> Mapping[str, Any]:
        root, capability, leaf, contract = self._bootstrap()
        candidate_id, search_report = self._run_search(leaf, contract)
        result: Dict[str, Any] = {
            "schema": 1,
            "program_version": BINPACKING_GOAL_PROGRAM_VERSION,
            "run_phase": self.run_phase,
            "representation": self.representation,
            "research_goal": RESEARCH_GOAL,
            "config": self.config.as_dict(),
            "goal_id": self.control.goal.goal_id,
            "root_node_id": root.node_id,
            "capability_node_id": capability.node_id,
            "leaf_node_id": leaf.node_id,
            "campaign_id": contract.campaign_id,
            "scientific_method_prior_digest": (
                self._method_prior_digest
            ),
            "search": search_report,
            "claim_status": {
                "replicated_effect": False,
                "frontier_advance": False,
                "scientifically_novel": False,
                "breakthrough": False,
            },
        }
        if candidate_id is None:
            result["outcome"] = "no_replication_qualified_candidate"
            result["status"] = self.runtime.status()
            return result

        candidate = self._programs[candidate_id]
        result["claim_status"]["replicated_effect"] = True
        result["candidate"] = dict(
            self.adapter.candidate_as_dict(candidate)
        )
        result["candidate_artifact"] = self.store.put(
            "domain_candidate",
            result["candidate"],
        )
        shift_suite = _suite(
            families=tuple(sorted(GENERATORS)),
            seed_start=self.config.base_seed + 180_000_000,
            cases_per_family=self.config.integration_cases_per_family,
            length=self.config.development_length,
            capacity=self.config.capacity,
        )
        shift_metrics, shift_evidence, shift_dataset = _verified_batch(
            self.store,
            self.adapter,
            candidate,
            self.incumbent,
            shift_suite,
            kind="binpacking_v2_parent_shift",
        )
        shift_contribution = self._contribution_audit(
            candidate_id,
            shift_suite,
            stage="generated_shift",
        )
        shift_passed = (
            shift_metrics["aggregate_improvement_ci_lower"] > 0.0
            and shift_metrics["mean_improvement_ci_lower"] > 0.0
            and shift_contribution["passed"]
        )
        shift_deployment = {
            "gate": "deployment_safety_only",
            "passed": shift_metrics["maximum_regression"] <= 1.0,
            "maximum_allowed_regression": 1.0,
            "observed_maximum_regression": shift_metrics[
                "maximum_regression"
            ],
            "observed_loss_rate": shift_metrics["loss_rate"],
            "does_not_control_discovery": True,
        }
        self.runtime.transact(
            "record_parent_integration",
            ParentIntegrationRecord(
                node_id=leaf.node_id,
                parent_id=capability.node_id,
                candidate_id=candidate_id,
                preregistered_test_ref=(
                    leaf.leaf_contract.parent_integration_test
                ),
                evaluator_ref=self.adapter.evaluator_ref,
                verifier_ref=self.adapter.verifier_ref,
                partition=EvidencePartition.REPLICATION,
                evidence_ids=shift_evidence,
                metric_deltas=shift_metrics,
                passed=shift_passed,
                causal_interpretation=(
                    "the frozen code was evaluated unchanged across all "
                    "declared generated distribution shifts"
                ),
                failure_mode=(
                    None
                    if shift_passed
                    else "generated_distribution_shift_regression"
                ),
            ),
        )
        result["shift_integration"] = {
            "dataset_digest": shift_dataset,
            "metrics": dict(shift_metrics),
            "causal_contribution": shift_contribution,
            "deployment_qualification": shift_deployment,
            "passed": shift_passed,
        }
        if not shift_passed:
            result["outcome"] = "parent_integration_failed"
            result["status"] = self.runtime.status()
            return result

        source_manifest = load_source_manifest(
            self.orlib_root / "SOURCES.json"
        )
        source_checksums = verify_orlib_files(
            self.orlib_root,
            source_manifest,
        )
        records = load_orlib_corpus(self.orlib_root)
        external_suite = tuple(record.instance for record in records)
        external_metrics, external_evidence, external_dataset = (
            _verified_batch(
                self.store,
                self.adapter,
                candidate,
                self.incumbent,
                external_suite,
                kind="binpacking_v2_external_orlib",
            )
        )
        external_contribution = self._contribution_audit(
            candidate_id,
            external_suite,
            stage="external_confirmation",
        )
        expected_corpus_digest = corpus_digest(records)
        external_passed = (
            external_metrics["aggregate_improvement_ci_lower"] > 0.0
            and external_metrics["mean_improvement_ci_lower"] > 0.0
            and external_contribution["passed"]
        )
        external_deployment = {
            "gate": "deployment_safety_only",
            "passed": external_metrics["maximum_regression"] <= 1.0,
            "maximum_allowed_regression": 1.0,
            "observed_maximum_regression": external_metrics[
                "maximum_regression"
            ],
            "observed_loss_rate": external_metrics["loss_rate"],
            "does_not_control_discovery": True,
        }
        self.runtime.transact(
            "record_parent_integration",
            ParentIntegrationRecord(
                node_id=capability.node_id,
                parent_id=root.node_id,
                candidate_id=candidate_id,
                preregistered_test_ref=(
                    "checksummed OR-Library external paired comparison"
                ),
                evaluator_ref=self.adapter.evaluator_ref,
                verifier_ref=self.adapter.verifier_ref,
                partition=EvidencePartition.EXTERNAL_CONFIRMATION,
                evidence_ids=external_evidence,
                metric_deltas=external_metrics,
                passed=external_passed,
                causal_interpretation=(
                    "the unchanged integrated policy was compared against "
                    "the published executable incumbent on the checksummed "
                    "external corpus"
                ),
                failure_mode=(
                    None
                    if external_passed
                    else "external_corpus_did_not_confirm_improvement"
                ),
            ),
        )
        result["external_integration"] = {
            "artifact_dataset_digest": external_dataset,
            "corpus_digest": expected_corpus_digest,
            "source_checksums": dict(sorted(source_checksums.items())),
            "metrics": dict(external_metrics),
            "causal_contribution": external_contribution,
            "deployment_qualification": external_deployment,
            "passed": external_passed,
        }
        if not external_passed:
            result["outcome"] = "external_integration_failed"
            result["status"] = self.runtime.status()
            return result
        result["claim_status"]["frontier_advance"] = True

        novelty = self._semantic_novelty_results[candidate_id]
        semantic = novelty["semantic_assessment"]
        mechanism_review = {
            "reduced_mechanism_labels": list(
                reduced_mechanism_labels(
                    candidate,
                    self.config.capacity,
                )
            ),
            "known_family_matches": list(
                semantic["known_family_matches"]
            ),
            "semantic_novelty_passed": semantic["passed"],
            "causal_contribution_passed": (
                external_contribution["passed"]
            ),
            "causal_contribution_applicable": (
                external_contribution["applicable"]
            ),
            "causal_contribution_assessment_id": (
                external_contribution["assessment_id"]
            ),
        }
        root_review = self._review_literature(
            root,
            trigger=LiteratureTrigger.CLAIM_ESCALATION,
            candidate_delta=(
                "frozen candidate %s: %s"
                % (
                    candidate_id,
                    candidate.as_dict()["rendered"],
                )
            ),
            mechanism_review=mechanism_review,
        )
        self.runtime.transact(
            "register_literature_assessment",
            root_review,
        )
        root_gate = GateContract(
            kind=GateKind.PUBLIC_CLAIM,
            evidence_partition=EvidencePartition.EXTERNAL_CONFIRMATION,
            criteria=(
                GateCriterion(
                    metric="aggregate_improvement_ci_lower",
                    operator=">",
                    threshold=0.0,
                    description=(
                        "external aggregate episode improvement has a positive "
                        "95% confidence bound"
                    ),
                ),
                GateCriterion(
                    metric="mean_improvement_ci_lower",
                    operator=">",
                    threshold=0.0,
                    description=(
                        "external mean episode improvement excludes zero"
                    ),
                ),
                GateCriterion(
                    metric="causal_contribution_passed",
                    operator="==",
                    threshold=1.0,
                    description=(
                        "the full policy beats its strongest parent and the "
                        "new module changes enough same-state actions"
                    ),
                ),
                GateCriterion(
                    metric="semantic_novelty_passed",
                    operator="==",
                    threshold=1.0,
                    description=(
                        "the reduced mechanism is distinct from registered "
                        "prior policy families"
                    ),
                ),
                GateCriterion(
                    metric="literature_novelty_passed",
                    operator="==",
                    threshold=1.0,
                    description=(
                        "candidate-specific prior-art review supports a "
                        "scientifically novel mechanism candidate"
                    ),
                ),
            ),
            minimum_evidence_count=len(external_suite),
        )
        root_metrics = {
            **external_metrics,
            "causal_contribution_passed": float(
                external_contribution["passed"]
            ),
            "semantic_novelty_passed": float(semantic["passed"]),
            "literature_novelty_passed": float(
                root_review.classification
                == ClaimClassification.NOVEL_CANDIDATE
            ),
        }
        root_decision = evaluate_gate(
            root_gate,
            candidate_id=candidate_id,
            incumbent_id=self.adapter.candidate_id(self.incumbent),
            metrics=root_metrics,
            evidence_count=len(external_suite),
        )
        authorization = evaluate_claim_authorization(
            root_review,
            claim_id=content_digest(
                {
                    "candidate_id": candidate_id,
                    "external_corpus": expected_corpus_digest,
                }
            ),
            requested_level=ClaimLevel.FRONTIER_ADVANCE,
            frontier_comparison_evidence_ids=external_evidence,
        )
        result["claim_status"] = {
            "replicated_effect": True,
            "frontier_advance": True,
            "scientifically_novel": (
                semantic["passed"]
                and root_review.classification
                == ClaimClassification.NOVEL_CANDIDATE
                and authorization.authorized
            ),
            "breakthrough": False,
            "literature_classification": (
                root_review.classification.value
            ),
            "mechanism_review": mechanism_review,
        }
        result["claim_authorization"] = authorization.as_dict()
        result["claim_escalation_literature"] = root_review.as_dict()
        if not authorization.authorized:
            result["root_gate"] = {
                "passed": False,
                "gate_decision": root_decision.as_dict(),
                "reasons": [
                    "claim authorization denied: %s" % reason
                    for reason in authorization.reasons
                ],
            }
            result["outcome"] = "claim_authorization_failed"
            result["status"] = self.runtime.status()
            return result
        evaluation = self.runtime.transact(
            "evaluate_root",
            root_gate,
            root_decision,
            external_evidence,
            self.control.goal.integration_requirements,
            (
                "claim is limited to online one-dimensional capacity-150 "
                "instances in the declared generated and OR-Library scope",
                "behavioral non-equivalence does not prove conceptual novelty",
            ),
            authorization,
        )
        result["root_gate"] = evaluation.as_dict()
        result["outcome"] = (
            "scientifically_novel_frontier_candidate"
            if evaluation.passed
            else "root_gate_failed"
        )
        result["status"] = self.runtime.status()
        return result


def _contextual_revision_leaf(
    goal: HighLevelGoal,
    config: BinPackingGoalRunConfig,
) -> GoalNodeSpec:
    budget = config.maximum_search_compute + 200.0
    contract = ExecutableLeafContract(
        hypothesis=(
            "Replacing symbolic expression trees with contextual linear "
            "policies over rolling sequence and load-distribution state can "
            "turn the failed audit-local regime signal into a replicated "
            "improvement."
        ),
        parent_decision=(
            "freeze a contextual policy for multi-distribution integration"
        ),
        root_metric_link=(
            "candidate-minus-FunSearch paired bin count feeds the root metric"
        ),
        metric=_primary_metric(),
        success_conditions=(
            "frozen replication aggregate primary_delta is negative",
            "maximum per-instance regression is at most one bin",
            "the novelty probe excludes exact-fill and known-policy behavior",
        ),
        falsification_conditions=(
            "the contextual audit gain reverses under replication",
            "independent packing verification fails",
            "the policy matches a preregistered prior mechanism",
            "a composed policy fails its parent contribution ablation",
        ),
        testbed_ref="binpacking-contextual-linear-adapter-v1",
        parent_integration_test=(
            "frozen multi-family generated shift suite v1"
        ),
        experiment_budget=budget,
        preregistration_ref=(
            "binpacking-v2-contextual-revision-2026-07-30"
        ),
    )
    return GoalNodeSpec(
        goal_id=goal.goal_id,
        title="Contextual state-conditioned code-evolution campaign",
        question=(
            "Can rolling sequence and load-distribution state produce a "
            "replicable policy beyond symbolic-tree and exact-fill behavior?"
        ),
        kind=GoalNodeKind.EXECUTABLE_LEAF,
        rationale=(
            "The previous symbolic finalist saved five audit bins but lost "
            "two bins on 240 frozen replication cases. The causal revision "
            "tests whether the missing variable is broader contextual state "
            "rather than more mutation of the same expression tree."
        ),
        success_conditions=contract.success_conditions,
        falsification_conditions=contract.falsification_conditions,
        expected_artifact=(
            "frozen contextual coefficient vector and verified evidence"
        ),
        critical=True,
        leaf_contract=contract,
        tags=(
            "three-island",
            "graph-revision",
            "contextual-linear",
            "executable",
        ),
    )


def _regime_router_revision_leaf(
    goal: HighLevelGoal,
    config: BinPackingGoalRunConfig,
) -> GoalNodeSpec:
    budget = config.maximum_search_compute + 200.0
    contract = ExecutableLeafContract(
        hypothesis=(
            "Routing each arrival among complete packing policies from "
            "rolling sequence and global load-regime state can produce a "
            "replicated improvement that is not reducible to exact-fill or "
            "one known policy."
        ),
        parent_decision=(
            "freeze a policy-router matrix for multi-distribution integration"
        ),
        root_metric_link=(
            "candidate-minus-FunSearch paired bin count feeds the root metric"
        ),
        metric=_primary_metric(),
        success_conditions=(
            "frozen replication aggregate primary_delta is negative",
            "maximum per-instance regression is at most one bin",
            "the novelty probe excludes all routed pure-policy and exact-fill "
            "behaviors",
        ),
        falsification_conditions=(
            "the router collapses to an excluded known policy",
            "an audit gain reverses under frozen replication",
            "independent packing verification fails",
        ),
        testbed_ref="binpacking-policy-router-adapter-v1",
        parent_integration_test=(
            "frozen multi-family generated shift suite v1"
        ),
        experiment_budget=budget,
        preregistration_ref=(
            "binpacking-v2-policy-router-revision-2026-07-30"
        ),
    )
    return GoalNodeSpec(
        goal_id=goal.goal_id,
        title="State-conditioned policy-portfolio routing campaign",
        question=(
            "Can an online regime router combine complete policies into a "
            "replicable behavior beyond exact-fill and every constituent?"
        ),
        kind=GoalNodeKind.EXECUTABLE_LEAF,
        rationale=(
            "The contextual action-score campaign again converged to "
            "exact-fill behavior. This causal revision changes the evolved "
            "unit from a per-bin score to a policy-level state router while "
            "retaining frozen behavioral novelty and replication gates."
        ),
        success_conditions=contract.success_conditions,
        falsification_conditions=contract.falsification_conditions,
        expected_artifact=(
            "frozen policy-router coefficient matrix and verified evidence"
        ),
        critical=True,
        leaf_contract=contract,
        tags=(
            "three-island",
            "graph-revision",
            "regime-policy-router",
            "executable",
        ),
    )


def _demand_memory_revision_leaf(
    goal: HighLevelGoal,
    config: BinPackingGoalRunConfig,
) -> GoalNodeSpec:
    budget = config.maximum_search_compute
    contract = ExecutableLeafContract(
        hypothesis=(
            "Estimating complement demand from recent arrivals and scoring "
            "the preservation or creation of matching residual capacities can "
            "improve on FunSearch without collapsing to a known policy."
        ),
        parent_decision=(
            "freeze a demand-memory scorer for multi-distribution integration"
        ),
        root_metric_link=(
            "candidate-minus-FunSearch paired bin count feeds the root metric"
        ),
        metric=_primary_metric(),
        success_conditions=(
            "frozen replication aggregate primary_delta is negative",
            "maximum per-instance regression is at most one bin",
            "behavior is distinct from exact-fill and all known policies",
        ),
        falsification_conditions=(
            "demand-memory candidates reproduce an excluded behavior",
            "audit improvements reverse under frozen replication",
            "independent packing verification fails",
        ),
        testbed_ref="binpacking-empirical-demand-memory-adapter-v1",
        parent_integration_test=(
            "frozen multi-family generated shift suite v1"
        ),
        experiment_budget=budget,
        preregistration_ref=(
            "binpacking-v2-demand-memory-revision-2026-07-30"
        ),
    )
    return GoalNodeSpec(
        goal_id=goal.goal_id,
        title="Empirical complement-demand memory campaign",
        question=(
            "Can recent empirical demand for residual capacities guide a "
            "replicable online placement improvement?"
        ),
        kind=GoalNodeKind.EXECUTABLE_LEAF,
        rationale=(
            "The policy router retained FunSearch when safe and suffered "
            "large regressions when it deviated. This final bounded revision "
            "adds an action-specific signal unavailable to the router: the "
            "estimated future demand for each post-placement residual."
        ),
        success_conditions=contract.success_conditions,
        falsification_conditions=contract.falsification_conditions,
        expected_artifact=(
            "frozen demand-memory coefficient vector and verified evidence"
        ),
        critical=True,
        leaf_contract=contract,
        tags=(
            "three-island",
            "graph-revision",
            "empirical-demand-memory",
            "executable",
        ),
    )


class ContextualBinPackingRevisionProgram(BinPackingGoalProgram):
    run_phase = "plateau_revision_contextual_linear"
    representation = (
        "contextual_ancestry_plus_structural_moonshot_de_novo"
    )
    moonshot_exploration_lane = True
    cycle_index = 1
    quarantine_ref = "contextual-revision-sequestered-evidence-v1"
    # The root compute ledger counts candidate evaluations. Literature,
    # checkpointing, and graph transactions are required control-plane work,
    # not an uncharged campaign reserve. A non-zero reserve made the same set
    # of campaigns feasible or infeasible solely from Elo-selected order.
    campaign_overhead = 0.0

    def __init__(
        self,
        runtime: GoalGraphRuntime,
        store: ArtifactStore,
        config: BinPackingGoalRunConfig,
        *,
        orlib_root: Path,
        plateaued_leaf_id: str,
        revision_evidence_ids: Sequence[str],
        selected_hypothesis: Optional[TournamentHypothesis] = None,
    ) -> None:
        super().__init__(
            runtime,
            store,
            config,
            orlib_root=orlib_root,
            selected_hypothesis=selected_hypothesis,
        )
        if not plateaued_leaf_id or not revision_evidence_ids:
            raise ValueError(
                "plateau revision requires a target and its evidence"
            )
        self.plateaued_leaf_id = plateaued_leaf_id
        self.revision_evidence_ids = tuple(revision_evidence_ids)

    def _revision_leaf(self) -> GoalNodeSpec:
        return _contextual_revision_leaf(
            self.control.goal,
            self.config,
        )

    def _campaign_budget(self) -> float:
        return self.config.maximum_search_compute + self.campaign_overhead

    def _revision_literature(
        self,
        leaf: GoalNodeSpec,
    ) -> PriorArtAssessment:
        return contextual_literature_assessment(leaf)

    def _revision_rule_rationale(self) -> str:
        return (
            "the symbolic-tree leaf exhausted its campaign budget after "
            "an audit-positive but replication-negative finalist; replace "
            "the representation rather than repeat the same search"
        )

    def _revision_reasoning(self) -> Tuple[str, ...]:
        return (
            "frozen replication reversed the symbolic finalist's "
            "audit improvement",
        )

    def _revision_assumptions(self) -> Tuple[str, ...]:
        return (
            "recent-window state may explain the audit-to-replication shift",
            "linear coefficients provide a distinct search geometry",
            "the published FunSearch policy remains the incumbent",
        )

    def _revision_predictions(self) -> Tuple[str, ...]:
        return (
            "a genuine contextual mechanism passes fresh multiscale "
            "replication",
            "another surrogate exploit again reverses outside its audit batch",
        )

    def _scheduling_basis(self) -> Tuple[str, ...]:
        return (
            "the active control action requires graph revision",
            "the representation tests the diagnosed missing state",
        )

    def _ancestry_proposer(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        patch = (
            None
            if self.selected_hypothesis_contract is None
            else self.selected_hypothesis_contract.generator_patch
        )
        return ContextualEvolutionProposer(
            "ancestry",
            patch,
            literature_context,
        )

    def _de_novo_proposer(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        # Graph revision must not collapse the de-novo island into the active
        # representation.  It remains incumbent-blind and topology-changing.
        return RiskTakingMoonshotProposer(literature_context)

    def _hybrid_proposer(
        self,
        ancestry_source: OnlineHeuristic,
        de_novo_source: Any,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        if not isinstance(ancestry_source, ContextualLinearProgram):
            raise ValueError(
                "contextual cross-island survivors have incompatible types"
            )
        de_novo_sources = (
            tuple(de_novo_source)
            if isinstance(de_novo_source, (tuple, list))
            else (de_novo_source,)
        )
        if not de_novo_sources or not all(
            isinstance(source, MoonshotProgram)
            for source in de_novo_sources
        ):
            raise ValueError(
                "contextual hybrid requires a structural de-novo survivor"
            )
        if ancestry_source.mode != "ancestry":
            raise ValueError("contextual ancestry survivor has another mode")
        return CrossRepresentationMoonshotHybridProposer(
            ancestry_source,
            de_novo_sources,
            literature_context,
        )

    def _bootstrap(
        self,
    ) -> Tuple[
        GoalNodeSpec,
        GoalNodeSpec,
        GoalNodeSpec,
        IslandCampaignContract,
    ]:
        if self.control.active_campaign_ids:
            return self._resume_pristine_campaign()
        graph = self.control.graph
        root = graph.nodes[graph.root_id]
        old_leaf = graph.nodes.get(self.plateaued_leaf_id)
        if old_leaf is None:
            raise ValueError("revision target is not in the goal graph")
        if graph.status(old_leaf.node_id) not in (
            GoalNodeStatus.PLATEAUED,
            GoalNodeStatus.BLOCKED,
            GoalNodeStatus.INTEGRATION_FAILED,
        ):
            raise ValueError("revision target is not revisable")
        parents = graph.parents_of(old_leaf.node_id)
        if len(parents) != 1:
            raise ValueError("revision target must have one active parent")
        capability = graph.nodes[parents[0]]
        active_rule = graph.active_rule(capability.node_id)
        if active_rule is None:
            raise ValueError("revision parent has no active decomposition")
        leaf = self._revision_leaf()
        revised_rule = ParentCompositionRule(
            parent_id=capability.node_id,
            child_ids=(leaf.node_id,),
            operator=CompositionOperator.ALL,
            integration_test=active_rule.integration_test,
            rationale=self._revision_rule_rationale(),
            decomposer_ref="binpacking-plateau-revision-planner-v1",
            supersedes_rule_id=active_rule.rule_id,
        )
        self.runtime.transact(
            "revise_decomposition",
            (leaf,),
            revised_rule,
            self.revision_evidence_ids,
            self._revision_reasoning(),
            assumptions=self._revision_assumptions(),
            distinguishing_predictions=self._revision_predictions(),
        )
        leaf_literature = self._review_literature(
            leaf,
            planned=self._revision_literature(leaf),
        )
        self.runtime.transact(
            "register_literature_assessment",
            leaf_literature,
        )
        reproduction = _suite(
            families=("or_uniform",),
            seed_start=self.config.base_seed + 90_000_000,
            cases_per_family=30,
            length=self.config.development_length,
            capacity=self.config.capacity,
        )
        baselines = baseline_heuristics()
        portfolio = IncumbentPortfolio(
            node_id=leaf.node_id,
            literature_assessment_id=leaf_literature.assessment_id,
            entries=(
                _reproduction_entry(
                    self.store,
                    self.adapter,
                    baselines["next_fit"],
                    reproduction,
                    name="Next Fit null control",
                    role=IncumbentRole.NULL,
                    source_locator="internal:next-fit-control",
                ),
                _reproduction_entry(
                    self.store,
                    self.adapter,
                    self.best_fit,
                    reproduction,
                    name="Best Fit",
                    role=IncumbentRole.CHEAPEST_CREDIBLE,
                    source_locator="published:best-fit",
                ),
                _reproduction_entry(
                    self.store,
                    self.adapter,
                    self.incumbent,
                    reproduction,
                    name="Published FunSearch OR heuristic",
                    role=IncumbentRole.BEST_PUBLISHED_COMPONENT,
                    source_locator=(
                        "https://doi.org/10.1038/s41586-023-06924-6"
                    ),
                    source_work_id=FUNSEARCH_WORK_ID,
                ),
            ),
            primary_incumbent_id=self.adapter.candidate_id(self.incumbent),
            selection_rationale=(
                "The representation changed, but the strongest matching "
                "executable incumbent was freshly reproduced on the revised "
                "leaf's development distribution."
            ),
        )
        self.runtime.transact(
            "register_incumbent_portfolio",
            portfolio,
        )
        self.runtime.transact(
            "assess_nodes",
            (
                NodeSchedulingAssessment(
                    node_id=leaf.node_id,
                    root_relevance=1.0,
                    value_of_information=0.95,
                    success_probability=0.20,
                    integration_leverage=1.0,
                    uncertainty=0.95,
                    estimated_cost=self.config.maximum_search_compute,
                    basis=self._scheduling_basis(),
                    assessor_ref="binpacking-v2-revision-scheduler-v1",
                ),
            ),
        )
        schedule = self.runtime.transact(
            "schedule_frontier",
            1,
            self.config.maximum_search_compute,
        )
        if schedule.node_ids != (leaf.node_id,):
            raise ValueError("scheduler did not authorize the revised leaf")
        audit_gate, replication_gate = _campaign_gates(self.config)
        campaign_budget = self._campaign_budget()
        contract = IslandCampaignContract(
            node_id=leaf.node_id,
            leaf_contract_id=leaf.leaf_contract.contract_id,
            incumbent_portfolio_id=portfolio.portfolio_id,
            evaluator_ref=self.adapter.evaluator_ref,
            verifier_ref=self.adapter.verifier_ref,
            quarantined_test_ref=self.quarantine_ref,
            total_compute_budget=campaign_budget,
            max_rounds=self.config.rounds,
            cycle_index=self.cycle_index,
            isolation_rounds=self.config.isolation_rounds,
            information_views=default_information_views(),
            gates=(audit_gate, replication_gate),
            selected_hypothesis_id=(
                None
                if self.selected_hypothesis is None
                else self.selected_hypothesis.hypothesis_id
            ),
            selected_executable_digest=(
                None
                if self.selected_hypothesis_contract is None
                else self.selected_hypothesis_contract.executable_digest
            ),
            selected_diagnostic_id=(
                None
                if self.selected_hypothesis is None
                or self.selected_hypothesis.diagnostic_result is None
                else self.selected_hypothesis.diagnostic_result.diagnostic_id
            ),
        )
        self.runtime.transact(
            "start_campaign",
            contract,
            CampaignPlateauPolicy(
                minimum_complete_rounds=self.config.rounds,
                no_improvement_window=min(2, self.config.rounds),
                minimum_attempts_per_island=(
                    self.config.candidate_budget_per_island
                ),
                minimum_distinct_ancestries_per_island=2,
                minimum_meaningful_effect=0.001,
                stable_failure_window=min(2, self.config.rounds),
            ),
        )
        return root, capability, leaf, contract

    def _resume_pristine_campaign(
        self,
    ) -> Tuple[
        GoalNodeSpec,
        GoalNodeSpec,
        GoalNodeSpec,
        IslandCampaignContract,
    ]:
        active = self.control.active_campaign_ids
        if len(active) != 1:
            raise ValueError(
                "revision recovery requires exactly one active campaign"
            )
        leaf_id, campaign_id = next(iter(active.items()))
        campaign = self.control.campaigns[campaign_id]
        contract = campaign.contract
        expected_leaf = self._revision_leaf()
        if (
            leaf_id != contract.node_id
            or leaf_id != expected_leaf.node_id
            or contract.cycle_index != self.cycle_index
            or contract.max_rounds != self.config.rounds
            or contract.total_compute_budget != self._campaign_budget()
        ):
            raise ValueError(
                "active campaign does not match the reconstructed revision"
            )
        if (
            campaign.rounds
            or campaign.proposals
            or campaign.verifications
            or campaign.compute_spent != 0.0
        ):
            raise ValueError(
                "only a pristine interrupted campaign can be resumed "
                "without replaying partial experimental evidence"
            )
        selected_id = contract.selected_hypothesis_id
        if selected_id != (
            None
            if self.selected_hypothesis is None
            else self.selected_hypothesis.hypothesis_id
        ):
            raise ValueError(
                "recovered hypothesis disagrees with the active campaign"
            )
        graph = self.control.graph
        leaf = graph.nodes[leaf_id]
        parents = graph.parents_of(leaf_id)
        if len(parents) != 1:
            raise ValueError("active revision leaf must have one parent")
        capability = graph.nodes[parents[0]]
        root = graph.nodes[graph.root_id]
        return root, capability, leaf, contract


class RegimeRouterBinPackingRevisionProgram(
    ContextualBinPackingRevisionProgram
):
    run_phase = "plateau_revision_regime_policy_router"
    representation = "state_conditioned_complete_policy_router"
    cycle_index = 2
    quarantine_ref = "policy-router-revision-sequestered-evidence-v1"

    def _revision_leaf(self) -> GoalNodeSpec:
        return _regime_router_revision_leaf(
            self.control.goal,
            self.config,
        )

    def _revision_literature(
        self,
        leaf: GoalNodeSpec,
    ) -> PriorArtAssessment:
        return regime_router_literature_assessment(leaf)

    def _revision_rule_rationale(self) -> str:
        return (
            "the contextual action-score representation converged to "
            "excluded exact-fill behavior across its isolated search "
            "campaign; replace the evolved unit with a state-conditioned "
            "router among complete policies"
        )

    def _revision_reasoning(self) -> Tuple[str, ...]:
        return (
            "the contextual campaign produced no prior-art-distinct "
            "replication qualifier",
            "its strongest audit candidates matched exact-fill behavior",
        )

    def _revision_assumptions(self) -> Tuple[str, ...]:
        return (
            "different arrival and load regimes may favor different complete "
            "policies",
            "policy-level routing is causally distinct from per-bin scoring",
            "the published FunSearch policy remains the primary incumbent",
        )

    def _revision_predictions(self) -> Tuple[str, ...]:
        return (
            "a useful router changes selected policies across online states",
            "a collapsed router matches a preregistered pure policy and is "
            "excluded",
            "a genuine portfolio effect passes frozen multiscale replication",
        )

    def _scheduling_basis(self) -> Tuple[str, ...]:
        return (
            "the active contextual leaf is plateaued",
            "the previous representation converged to an explicit novelty "
            "exclusion",
            "policy routing tests a different causal abstraction",
        )

    def _ancestry_proposer(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        patch = (
            None
            if self.selected_hypothesis_contract is None
            else self.selected_hypothesis_contract.generator_patch
        )
        return RegimeRouterEvolutionProposer(
            "ancestry",
            patch,
            literature_context,
        )

    def _de_novo_proposer(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        return RiskTakingMoonshotProposer(literature_context)

    def _hybrid_proposer(
        self,
        ancestry_source: OnlineHeuristic,
        de_novo_source: Any,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        if not isinstance(ancestry_source, RegimeRouterProgram):
            raise ValueError(
                "policy-router cross-island survivors have incompatible types"
            )
        de_novo_sources = (
            tuple(de_novo_source)
            if isinstance(de_novo_source, (tuple, list))
            else (de_novo_source,)
        )
        if not de_novo_sources or not all(
            isinstance(source, MoonshotProgram)
            for source in de_novo_sources
        ):
            raise ValueError(
                "policy-router hybrid requires a structural de-novo survivor"
            )
        if ancestry_source.mode != "ancestry":
            raise ValueError("policy-router ancestry survivor has another mode")
        return CrossRepresentationMoonshotHybridProposer(
            ancestry_source,
            de_novo_sources,
            literature_context,
        )


class DemandMemoryBinPackingRevisionProgram(
    ContextualBinPackingRevisionProgram
):
    run_phase = "plateau_revision_empirical_demand_memory"
    representation = "empirical_recent_demand_action_score"
    cycle_index = 3
    quarantine_ref = "demand-memory-revision-sequestered-evidence-v1"
    campaign_overhead = 0.0

    def _revision_leaf(self) -> GoalNodeSpec:
        return _demand_memory_revision_leaf(
            self.control.goal,
            self.config,
        )

    def _revision_literature(
        self,
        leaf: GoalNodeSpec,
    ) -> PriorArtAssessment:
        return demand_memory_literature_assessment(leaf)

    def _revision_rule_rationale(self) -> str:
        return (
            "the complete-policy router either reproduced FunSearch or "
            "introduced large audit regressions; replace policy selection "
            "with an action-specific empirical complement-demand signal"
        )

    def _revision_reasoning(self) -> Tuple[str, ...]:
        return (
            "safe router candidates collapsed to the published incumbent",
            "novel router candidates incurred aggregate audit regressions of "
            "more than fifty bins",
        )

    def _revision_assumptions(self) -> Tuple[str, ...]:
        return (
            "recent arrivals provide a bounded online estimate of near-future "
            "item-size demand",
            "residual-capacity demand is an action-specific signal absent "
            "from the policy router",
            "the published FunSearch policy remains the primary incumbent",
        )

    def _revision_predictions(self) -> Tuple[str, ...]:
        return (
            "a useful scorer preserves residuals matching recurrent arrivals",
            "a spurious memory signal fails on frozen multiscale replication",
            "a collapsed tight-fit scorer matches an exclusion and is rejected",
        )

    def _scheduling_basis(self) -> Tuple[str, ...]:
        return (
            "the active policy-router leaf is plateaued",
            "the observed failure isolates missing action-specific demand",
            "the remaining root budget permits one matched two-round campaign",
        )

    def _ancestry_proposer(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        patch = (
            None
            if self.selected_hypothesis_contract is None
            else self.selected_hypothesis_contract.generator_patch
        )
        return DemandMemoryEvolutionProposer(
            "ancestry",
            patch,
            literature_context,
        )

    def _de_novo_proposer(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        return RiskTakingMoonshotProposer(literature_context)

    def _hybrid_proposer(
        self,
        ancestry_source: OnlineHeuristic,
        de_novo_source: Any,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> Any:
        if not isinstance(ancestry_source, DemandMemoryProgram):
            raise ValueError(
                "demand-memory cross-island survivors have incompatible types"
            )
        de_novo_sources = (
            tuple(de_novo_source)
            if isinstance(de_novo_source, (tuple, list))
            else (de_novo_source,)
        )
        if not de_novo_sources or not all(
            isinstance(source, MoonshotProgram)
            for source in de_novo_sources
        ):
            raise ValueError(
                "demand-memory hybrid requires a structural de-novo survivor"
            )
        if ancestry_source.mode != "ancestry":
            raise ValueError("demand-memory ancestry survivor has another mode")
        return CrossRepresentationMoonshotHybridProposer(
            ancestry_source,
            de_novo_sources,
            literature_context,
        )


def _curated_binpacking_transfer_templates(
    node: GoalNodeSpec,
) -> CrossDomainInspirationPortfolio:
    tags = set(node.tags)
    if "contextual-linear" in tags:
        generator_ref = "binpacking-regime-router-generator-v1"
        specs = (
            (
                "ecology",
                "organisms switch strategies across changing niches",
                "state-dependent niche strategy selection",
                "concept:ecological-niche-switching",
                "a strategy can be locally effective only in a matching regime",
                (
                    (
                        "environmental niche",
                        "arrival and load regime",
                        "both summarize conditions that change strategy fitness",
                    ),
                    (
                        "species strategy",
                        "complete packing policy",
                        "both are intact behaviors selected at a higher level",
                    ),
                ),
                "A state-conditioned router among complete policies can "
                "outperform one global action-scoring rule.",
                (
                    "the selected policy changes across preregistered regimes",
                    "no single constituent reproduces the router fingerprint",
                ),
                (
                    "the router collapses to one constituent policy",
                    "regime switching does not survive frozen replication",
                ),
                "evolve a small online regime-to-policy routing matrix",
                (3, 3, 3, 2, 1),
            ),
            (
                "finance",
                "capital is allocated across assets under regime shifts",
                "regime-switching portfolio allocation",
                "concept:regime-switching-portfolio",
                "diversification helps only when allocation responds to state",
                (
                    (
                        "market regime",
                        "sequence regime",
                        "both are partially observed nonstationary contexts",
                    ),
                    (
                        "asset allocation",
                        "policy selection",
                        "both distribute decision authority across alternatives",
                    ),
                ),
                "Soft allocation across heuristic policies may reduce "
                "distribution-specific failure.",
                (
                    "allocation entropy changes with sequence statistics",
                    "a mixed router beats every pure allocation on development",
                ),
                (
                    "one policy receives all allocation in every state",
                    "the mixture increases maximum regression",
                ),
                "learn regime features and a sparse policy-allocation rule",
                (3, 2, 2, 2, 1),
            ),
            (
                "operating systems",
                "schedulers switch disciplines as workload composition changes",
                "workload-aware scheduling discipline selection",
                "concept:adaptive-operating-system-scheduling",
                "queue composition determines which complete discipline works",
                (
                    (
                        "workload composition",
                        "recent item-size composition",
                        "both describe the demand presented to a scheduler",
                    ),
                    (
                        "scheduling discipline",
                        "packing heuristic",
                        "both are complete online allocation rules",
                    ),
                ),
                "A workload classifier can select a safer complete heuristic.",
                (
                    "classifier decisions vary with item-size composition",
                    "switch points correspond to distinct failure clusters",
                ),
                (
                    "switching adds no behavior beyond the incumbent",
                    "classification errors dominate any local benefit",
                ),
                "route among frozen policies from bounded workload statistics",
                (2, 3, 2, 2, 2),
            ),
        )
    elif "regime-policy-router" in tags:
        generator_ref = "binpacking-demand-memory-generator-v1"
        specs = (
            (
                "inventory science",
                "stock is reserved using empirical demand forecasts",
                "forecast-conditioned residual resource reservation",
                "concept:inventory-demand-forecasting",
                "residual capacity has option value when future demand matches it",
                (
                    (
                        "forecast item demand",
                        "recent empirical item-size distribution",
                        "both estimate near-future resource requests",
                    ),
                    (
                        "reserved stock",
                        "preserved bin residual",
                        "both retain capacity for probable future demand",
                    ),
                ),
                "Scoring each action by empirical demand for its resulting "
                "residual can improve on complete-policy switching.",
                (
                    "winning actions leave residuals near density modes",
                    "removing demand-density features removes the gain",
                ),
                (
                    "demand memory reproduces tight-fit behavior",
                    "the empirical signal reverses on frozen multiscale cases",
                ),
                "estimate recent complement density and add it to action scores",
                (3, 3, 3, 2, 1),
            ),
            (
                "telecommunications",
                "admission controllers reserve bandwidth for probable requests",
                "probabilistic residual-capacity reservation",
                "concept:network-admission-control",
                "using capacity now has an opportunity cost under future demand",
                (
                    (
                        "bandwidth request distribution",
                        "item-size distribution",
                        "both consume indivisible residual resource",
                    ),
                    (
                        "reserved link capacity",
                        "unfilled bin capacity",
                        "both can be preserved for forecast demand",
                    ),
                ),
                "An opportunity-cost term can prevent locally tight but "
                "globally harmful placements.",
                (
                    "the override occurs when residual demand is concentrated",
                    "benefit grows with demand autocorrelation",
                ),
                (
                    "the term only opens unnecessary new bins",
                    "benefit disappears under independent replication",
                ),
                "score the opportunity cost of consuming demanded residuals",
                (3, 2, 2, 2, 1),
            ),
            (
                "molecular recognition",
                "binding sites are selected by geometric complementarity",
                "repertoire matching by complement affinity",
                "concept:molecular-complementarity",
                "compatibility depends on the complement left by a pairing",
                (
                    (
                        "binding-pocket complement",
                        "post-placement residual capacity",
                        "both encode what future counterpart can fit",
                    ),
                    (
                        "ligand repertoire",
                        "recent item-size repertoire",
                        "both define an empirical set of likely complements",
                    ),
                ),
                "A complement-affinity kernel can rank packing actions.",
                (
                    "rankings change with the observed item repertoire",
                    "kernel bandwidth has a falsifiable optimum",
                ),
                (
                    "affinity reduces to exact-fill",
                    "kernel ranking causes large guard regressions",
                ),
                "apply a bounded complement-affinity kernel to each residual",
                (2, 3, 2, 1, 2),
            ),
        )
    elif "empirical-demand-memory" in tags:
        generator_ref = "binpacking-sparse-repair-generator-v1"
        specs = (
            (
                "error-correcting codes",
                "structured syndromes identify localized correction operators",
                "syndrome-guided sparse repair",
                "concept:error-correcting-syndrome-decoding",
                "failure signatures can select a small targeted correction",
                (
                    (
                        "error syndrome",
                        "packing failure signature",
                        "both compress where a baseline mechanism fails",
                    ),
                    (
                        "sparse correction pattern",
                        "conditional placement override",
                        "both alter only states implicated by the signature",
                    ),
                ),
                "Sparse syndrome-triggered overrides may preserve the "
                "incumbent while repairing recurrent failure states.",
                (
                    "overrides activate only on held-out matching syndromes",
                    "ablating the syndrome removes gains but preserves controls",
                ),
                (
                    "the override fires broadly rather than sparsely",
                    "held-out syndromes do not predict repair benefit",
                ),
                "cluster verified failures and evolve sparse guarded overrides",
                (3, 3, 3, 2, 2),
            ),
            (
                "neuroscience",
                "predictive coding updates representations from residual error",
                "hierarchical prediction-error correction",
                "concept:predictive-coding",
                "unexpected residuals should update the active internal model",
                (
                    (
                        "prediction error",
                        "observed packing regret proxy",
                        "both quantify mismatch from an internal expectation",
                    ),
                    (
                        "hierarchical latent state",
                        "multiscale sequence state",
                        "both support correction at more than one timescale",
                    ),
                ),
                "Multiscale prediction-error state can gate rare overrides.",
                (
                    "override frequency follows prediction error",
                    "different timescales explain different failure clusters",
                ),
                (
                    "prediction error is unrelated to downstream bin delta",
                    "the state overfits exposed development sequences",
                ),
                "track multiscale residual surprise and gate corrections",
                (3, 2, 2, 2, 2),
            ),
            (
                "statistical physics",
                "renormalization preserves relevant structure across scales",
                "multiscale coarse-graining by relevant variables",
                "concept:renormalization-group",
                "useful mechanisms remain predictive under scale changes",
                (
                    (
                        "coarse-grained order parameter",
                        "multiscale load-and-arrival statistic",
                        "both discard detail while preserving relevant state",
                    ),
                    (
                        "scale-invariant behavior",
                        "length-generalizing heuristic effect",
                        "both persist when system size changes",
                    ),
                ),
                "Features selected for cross-scale stability may transfer "
                "better than development-optimal features.",
                (
                    "selected features retain sign across validation lengths",
                    "scale-stable candidates improve the worst length slice",
                ),
                (
                    "feature effects change sign across scales",
                    "coarse-graining removes all discriminating signal",
                ),
                "select proposal features by cross-length stability before search",
                (2, 3, 2, 2, 2),
            ),
        )
    else:
        generator_ref = "binpacking-contextual-linear-generator-v1"
        specs = (
            (
                "control theory",
                "feedback laws condition actions on measured system state",
                "state-feedback control",
                "concept:state-feedback-control",
                "a fixed action rule can fail when omitted state changes dynamics",
                (
                    (
                        "measured plant state",
                        "recent arrivals and current load distribution",
                        "both summarize information needed for the next action",
                    ),
                    (
                        "feedback control law",
                        "state-conditioned placement score",
                        "both map current state and action to a decision",
                    ),
                ),
                "Adding bounded sequence and load state to placement scoring "
                "can repair a symbolic policy's generalization failure.",
                (
                    "winning coefficients use non-action state features",
                    "state ablation removes any replicated improvement",
                ),
                (
                    "the scorer collapses to a state-free known policy",
                    "state-conditioned gains reverse under frozen replication",
                ),
                "evolve a compact contextual residual on top of the incumbent",
                (3, 3, 3, 2, 1),
            ),
            (
                "statistical mechanics",
                "macroscopic order parameters predict collective behavior",
                "order-parameter state compression",
                "concept:statistical-mechanics-order-parameters",
                "global moments can expose regimes invisible to local variables",
                (
                    (
                        "particle ensemble",
                        "open-bin load ensemble",
                        "both contain many interacting resource states",
                    ),
                    (
                        "order parameter",
                        "load-distribution moment",
                        "both compress global configuration into causal state",
                    ),
                ),
                "Load-distribution moments can condition a transferable scorer.",
                (
                    "global moments separate known failure clusters",
                    "moment-conditioned actions differ at equal local residual",
                ),
                (
                    "moments add no information beyond local load",
                    "moment-sensitive candidates fail scale transfer",
                ),
                "add load mean and variance to a bounded residual scorer",
                (3, 2, 2, 2, 1),
            ),
            (
                "signal processing",
                "sliding windows detect nonstationary signal regimes",
                "bounded online change and trend detection",
                "concept:sliding-window-change-detection",
                "recent temporal structure can predict the next operating regime",
                (
                    (
                        "signal window",
                        "recent item window",
                        "both are causal bounded observations of a stream",
                    ),
                    (
                        "trend and variance features",
                        "arrival-regime features",
                        "both identify local nonstationarity",
                    ),
                ),
                "Recent-window trend and dispersion can gate placement changes.",
                (
                    "actions change after detected sequence shifts",
                    "window features outperform shuffled-history controls",
                ),
                (
                    "history shuffling preserves the apparent gain",
                    "window-conditioned behavior matches exact-fill",
                ),
                "add causal recent-window statistics to action scoring",
                (2, 3, 2, 2, 2),
            ),
        )

    inspirations = []
    evaluations = []
    for spec in specs:
        (
            source_domain,
            source_problem,
            source_mechanism,
            source_reference,
            invariant,
            mapping_values,
            hypothesis,
            predictions,
            falsification,
            implementation,
            grades,
        ) = spec
        inspiration = CrossDomainInspiration(
            target_node_id=node.node_id,
            target_domain="online one-dimensional bin packing",
            source_domain=source_domain,
            source_problem=source_problem,
            source_mechanism=source_mechanism,
            source_reference=source_reference,
            invariant=invariant,
            mappings=tuple(
                MechanismMapping(*mapping) for mapping in mapping_values
            ),
            boundary_conditions=(
                "the transfer may use only causal online state",
                "the frozen bin-packing objective and verifier do not change",
            ),
            broken_assumptions=(
                "the source domain's dynamics and utility are not identical "
                "to irrevocable bin placement",
            ),
            transferred_hypothesis=hypothesis,
            distinguishing_predictions=predictions,
            falsification_conditions=falsification,
            implementation_sketch=implementation,
            generator_ref=generator_ref,
        )
        inspirations.append(inspiration)
        evaluations.append(
            TransferEvaluation(
                inspiration_id=inspiration.inspiration_id,
                structural_fit=grades[0],
                surprise=grades[1],
                testability=grades[2],
                evidence_grounding=grades[3],
                assumption_risk=grades[4],
                estimated_compute=100.0,
                rationale=(
                    "ordinal review balances structural correspondence, "
                    "surprise, testability, grounding, and analogy risk"
                ),
            )
        )
    selected = max(
        evaluations,
        key=lambda item: (
            item.priority_score,
            item.inspiration_id,
        ),
    )
    return CrossDomainInspirationPortfolio(
        target_node_id=node.node_id,
        inspirations=tuple(inspirations),
        evaluations=tuple(evaluations),
        selected_inspiration_ids=(selected.inspiration_id,),
        selection_rationale=(
            "select the highest-priority structurally mapped transfer; retain "
            "the other domains as explicit competing hypotheses"
        ),
        synthesizer_ref="binpacking-cross-domain-synthesizer-v1",
    )


_REGISTERED_REVISION_GENERATOR_REFS = frozenset(
    (
        "binpacking-contextual-linear-generator-v1",
        "binpacking-regime-router-generator-v1",
        "binpacking-demand-memory-generator-v1",
    )
)


def _mechanism_catalog_key(
    inspiration: CrossDomainInspiration,
) -> str:
    return "-".join(
        (
            inspiration.source_domain,
            inspiration.source_mechanism,
        )
    ).casefold().replace(" ", "-")


def _binpacking_transfer_template_corpus(
    node: GoalNodeSpec,
) -> Mapping[str, CrossDomainInspiration]:
    tag_variants = (
        ("executable",),
        ("contextual-linear",),
        ("regime-policy-router",),
        ("empirical-demand-memory",),
    )
    corpus: Dict[str, CrossDomainInspiration] = {}
    for tags in tag_variants:
        template_node = replace(node, tags=tags)
        portfolio = _curated_binpacking_transfer_templates(
            template_node
        )
        for inspiration in portfolio.inspirations:
            restored_target = replace(
                inspiration,
                target_node_id=node.node_id,
            )
            corpus[
                _mechanism_catalog_key(restored_target)
            ] = restored_target
    return corpus


_MECHANISM_CAPABILITIES = {
    "control theory": (
        "state",
        "feedback",
        "contextual",
        "adaptive",
        "load",
    ),
    "statistical mechanics": (
        "global",
        "state",
        "moments",
        "contextual",
        "multiscale",
    ),
    "signal processing": (
        "recent",
        "window",
        "change",
        "contextual",
        "nonstationary",
    ),
    "ecology": (
        "regime",
        "policy",
        "switching",
        "router",
        "diversity",
    ),
    "finance": (
        "regime",
        "allocation",
        "switching",
        "router",
        "risk",
    ),
    "operating systems": (
        "workload",
        "policy",
        "scheduling",
        "router",
        "adaptive",
    ),
    "inventory science": (
        "demand",
        "forecast",
        "residual",
        "complement",
        "memory",
    ),
    "telecommunications": (
        "demand",
        "reservation",
        "residual",
        "capacity",
        "memory",
    ),
    "molecular recognition": (
        "complement",
        "affinity",
        "residual",
        "repertoire",
        "memory",
    ),
    "error-correcting codes": (
        "failure",
        "signature",
        "sparse",
        "repair",
        "override",
    ),
    "neuroscience": (
        "prediction",
        "error",
        "multiscale",
        "repair",
        "override",
    ),
    "statistical physics": (
        "multiscale",
        "scale",
        "stability",
        "repair",
        "generalization",
    ),
}


_MECHANISM_PRIMARY_REFERENCES = {
    "control theory": "doi:10.1115/1.3662552",
    "statistical mechanics": "doi:10.1016/0370-1573(74)90023-4",
    "signal processing": "doi:10.1093/biomet/41.1-2.100",
    "ecology": "doi:10.1101/SQB.1957.022.01.039",
    "finance": "doi:10.2307/1912559",
    "operating systems": "doi:10.1145/1460833.1460871",
    "inventory science": "book:Arrow-Harris-Marschak-1951",
    "telecommunications": "doi:10.1214/aoap/1177005988",
    "molecular recognition": "doi:10.1002/cber.18940270364",
    "error-correcting codes": "doi:10.1002/j.1538-7305.1950.tb00463.x",
    "neuroscience": "doi:10.1038/nn0199_79",
    "statistical physics": "doi:10.1016/0370-1573(74)90023-4",
}


def _binpacking_mechanism_query(
    node: GoalNodeSpec,
    control_plane: Optional[AutonomousScientistControlPlane],
    literature_context: Optional[
        LiteratureHypothesisContext
    ] = None,
) -> MechanismDiscoveryQuery:
    if control_plane is None:
        raise ValueError(
            "relational mechanism retrieval requires observed causal "
            "failure models"
        )
    causal_failure_models = (
        control_plane.current_causal_failure_models(node.node_id)
    )
    if causal_failure_models is None:
        raise ValueError(
            "no cluster-complete causal failure model is available"
        )
    tags = set(node.tags)
    if "empirical-demand-memory" in tags:
        desired = (
            "failure signature",
            "sparse repair",
            "guarded override",
            "multiscale generalization",
        )
    elif "regime-policy-router" in tags:
        desired = (
            "demand forecast",
            "residual complement",
            "capacity reservation",
            "recent memory",
        )
    elif "contextual-linear" in tags:
        desired = (
            "regime switching",
            "complete policy router",
            "workload adaptation",
            "strategy diversity",
        )
    else:
        desired = (
            "state feedback",
            "nonstationary context",
            "global load state",
            "recent window",
        )
    failure_signatures = ["plateau_without_replication_advance"]
    excluded_domains = set()
    excluded_generators = set()
    if control_plane is not None:
        for campaign in control_plane.campaigns.values():
            if campaign.contract.node_id != node.node_id:
                continue
            failure_signatures.extend(
                summary.failure_signature
                for summary in campaign.rounds
            )
        for history in control_plane.cross_domain_inspirations.values():
            for portfolio in history:
                excluded_domains.update(
                    inspiration.source_domain
                    for inspiration in portfolio.inspirations
                    if inspiration.inspiration_id
                    in portfolio.selected_inspiration_ids
                )
        for graph_node in control_plane.graph.nodes.values():
            graph_tags = set(graph_node.tags)
            if "contextual-linear" in graph_tags:
                excluded_generators.add(
                    "binpacking-contextual-linear-generator-v1"
                )
            if "regime-policy-router" in graph_tags:
                excluded_generators.add(
                    "binpacking-regime-router-generator-v1"
                )
            if "empirical-demand-memory" in graph_tags:
                excluded_generators.add(
                    "binpacking-demand-memory-generator-v1"
                )
    query_terms = tuple(
        dict.fromkeys(
            token
            for phrase in (*desired, *failure_signatures)
            for token in phrase.replace("_", " ").split()
        )
    )
    causal_discrimination = assess_causal_discrimination(
        causal_failure_models,
        minimum_supported_schemas=2,
        minimum_replay_support_rate=0.25,
        maximum_schema_fraction=0.85,
        minimum_proxy_reliability=0.55,
        assessor_ref="binpacking-causal-discrimination-gate-v1",
    )
    return MechanismDiscoveryQuery(
        target_node_id=node.node_id,
        target_domain="online one-dimensional bin packing",
        causal_failure_models=causal_failure_models,
        causal_discrimination=causal_discrimination,
        failure_signatures=tuple(dict.fromkeys(failure_signatures)),
        desired_capabilities=desired,
        query_terms=query_terms,
        excluded_source_domains=tuple(sorted(excluded_domains)),
        excluded_generator_refs=tuple(sorted(excluded_generators)),
        literature_context_id=(
            None
            if literature_context is None
            else literature_context.context_id
        ),
        literature_evidence_ids=(
            ()
            if literature_context is None
            else literature_context.source_work_ids
        ),
        query_generator_ref=(
            "binpacking-causal-relational-mechanism-query-v2"
        ),
    )


def _source_causal_mechanism(
    inspiration: CrossDomainInspiration,
) -> SourceCausalMechanism:
    generator_ref = inspiration.generator_ref
    if generator_ref == "binpacking-contextual-linear-generator-v1":
        relations = (
            CausalRelationKind
            .INFORMATION_REVEALED_AFTER_COMMITMENT,
            CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION,
            CausalRelationKind.STATE_SELECTS_POLICY,
        )
    elif generator_ref == "binpacking-regime-router-generator-v1":
        relations = (
            CausalRelationKind
            .INFORMATION_REVEALED_AFTER_COMMITMENT,
            CausalRelationKind.STATE_SELECTS_POLICY,
            CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION,
        )
    elif generator_ref == "binpacking-demand-memory-generator-v1":
        relations = (
            CausalRelationKind
            .INFORMATION_REVEALED_AFTER_COMMITMENT,
            CausalRelationKind.COMMITMENT_DESTROYS_OPTION,
            CausalRelationKind.ALTERNATIVE_PRESERVES_OPTION,
            CausalRelationKind.PRESERVED_OPTION_CHANGES_OUTCOME,
            CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION,
        )
    else:
        relations = (
            CausalRelationKind.COMMITMENT_DESTROYS_OPTION,
            CausalRelationKind.ALTERNATIVE_PRESERVES_OPTION,
            CausalRelationKind.PRESERVED_OPTION_CHANGES_OUTCOME,
            CausalRelationKind.STATE_SELECTS_POLICY,
        )
    return SourceCausalMechanism(
        unavailable_information=(
            "future disturbances, demand, or compatibility in %s are not "
            "fully observed when the current choice is made"
            % inspiration.source_domain
        ),
        irreversible_decision=(
            "the source system commits scarce capacity or a policy before "
            "that latent state is revealed"
        ),
        alternative_action=(
            "use %s to preserve or redirect an option until informative "
            "state is available" % inspiration.source_mechanism
        ),
        changed_result=(
            "the preserved option reduces mismatch between later demand "
            "and the capacity committed earlier"
        ),
        causal_chain=(
            "latent future state precedes commitment; commitment removes an "
            "option; the source mechanism preserves or reroutes the option; "
            "the later realized state produces less mismatch"
        ),
        causal_relations=relations,
        broken_assumptions=(
            "source and target state variables are directly interchangeable",
            "source interventions are reversible at the target decision point",
        ),
        distinguishing_predictions=(
            "the mechanism helps mainly when information arrives after a "
            "capacity commitment",
            "removing the option-preserving intervention eliminates the "
            "advantage under matched latent-state uncertainty",
        ),
    )


def _binpacking_mechanism_catalog(
    node: GoalNodeSpec,
    literature_context: Optional[
        LiteratureHypothesisContext
    ] = None,
) -> Tuple[
    Mapping[str, CrossDomainInspiration],
    Tuple[MechanismCatalogEntry, ...],
]:
    templates = _binpacking_transfer_template_corpus(node)
    generator_mechanisms = {
        "binpacking-contextual-linear-generator-v1": {
            "change_detection",
            "uncertainty_robustness",
        },
        "binpacking-regime-router-generator-v1": {
            "state_conditioned_policy_selection",
            "change_detection",
        },
        "binpacking-demand-memory-generator-v1": {
            "predictive_profile_reservation",
            "adaptive_pattern_memory",
            "option_preservation",
        },
        "binpacking-sparse-repair-generator-v1": {
            "failure_syndrome_intervention",
            "uncertainty_robustness",
        },
    }

    def grounded_values(
        inspiration: CrossDomainInspiration,
    ) -> Tuple[str, int, int]:
        source_reference = _MECHANISM_PRIMARY_REFERENCES.get(
            inspiration.source_domain,
            inspiration.source_reference,
        )
        grounding = 3
        surprise = (
            4
            if inspiration.source_domain
            in (
                "molecular recognition",
                "error-correcting codes",
                "statistical physics",
            )
            else 3
        )
        if literature_context is None:
            return source_reference, grounding, surprise
        entry_terms = {
            token
            for value in (
                inspiration.source_domain,
                inspiration.source_problem,
                inspiration.source_mechanism,
                *_MECHANISM_CAPABILITIES[
                    inspiration.source_domain
                ],
            )
            for token in value.casefold().replace("-", " ").split()
            if len(token) > 3
        }
        supported = tuple(
            evidence
            for evidence in literature_context.evidence
            if len(
                entry_terms.intersection(
                    (
                        evidence.title
                        + " "
                        + evidence.evidence_excerpt
                    ).casefold().replace("-", " ").split()
                )
            )
            >= 2
        )
        if supported:
            best = max(
                supported,
                key=lambda item: (
                    item.is_latest_cohort,
                    item.year,
                    item.work_id,
                ),
            )
            source_reference = best.locator
            grounding = 4
        published_target_overlap = generator_mechanisms.get(
            inspiration.generator_ref,
            set(),
        ).intersection(literature_context.known_mechanisms)
        if published_target_overlap:
            surprise = max(0, surprise - 1)
        return source_reference, grounding, surprise

    entries = []
    for catalog_key, inspiration in sorted(templates.items()):
        source_reference, grounding, surprise = grounded_values(
            inspiration
        )
        entries.append(
            MechanismCatalogEntry(
            catalog_key=catalog_key,
            source_domain=inspiration.source_domain,
            source_problem=inspiration.source_problem,
            source_mechanism=inspiration.source_mechanism,
            source_reference=source_reference,
            invariant=inspiration.invariant,
            capability_tags=_MECHANISM_CAPABILITIES[
                inspiration.source_domain
            ],
            generator_ref=inspiration.generator_ref,
            surprise_prior=surprise,
            grounding_prior=grounding,
            causal_model=_source_causal_mechanism(inspiration),
        )
        )
    return templates, tuple(entries)


def _discover_binpacking_mechanisms(
    node: GoalNodeSpec,
    control_plane: Optional[AutonomousScientistControlPlane],
    literature_context: Optional[
        LiteratureHypothesisContext
    ] = None,
) -> Tuple[
    MechanismDiscoveryTrace,
    Tuple[CrossDomainInspiration, ...],
    Tuple[TransferEvaluation, ...],
]:
    templates, entries = _binpacking_mechanism_catalog(
        node,
        literature_context,
    )
    query = _binpacking_mechanism_query(
        node,
        control_plane,
        literature_context,
    )
    trace = CatalogMechanismScout(
        entries,
        scout_ref="binpacking-dynamic-mechanism-scout-v1",
    ).discover(query, limit=6)
    selected_discoveries = {
        discovery.discovery_id: discovery
        for discovery in trace.candidates
        if discovery.discovery_id in trace.selected_discovery_ids
    }
    inspirations = []
    evaluations = []
    for discovery_id in trace.selected_discovery_ids:
        discovery = selected_discoveries[discovery_id]
        template = templates[discovery.catalog_key]
        inspiration = replace(
            template,
            source_reference=discovery.source_reference,
            generator_ref=discovery.generator_ref,
            mappings=tuple(
                MechanismMapping(
                    source_element=mapping.source_element,
                    target_element=mapping.target_element,
                    transfer_argument=mapping.correspondence,
                    causal_role=mapping.causal_role,
                    target_model_id=mapping.target_model_id,
                )
                for mapping in discovery.relational_mappings
            ),
            broken_assumptions=tuple(
                dict.fromkeys(
                    (
                        *template.broken_assumptions,
                        *discovery.broken_assumptions,
                    )
                )
            ),
            distinguishing_predictions=tuple(
                dict.fromkeys(
                    (
                        *template.distinguishing_predictions,
                        *discovery.distinguishing_predictions,
                    )
                )
            ),
        )
        inspirations.append(inspiration)
        evaluations.append(
            TransferEvaluation(
                inspiration_id=inspiration.inspiration_id,
                structural_fit=min(3, discovery.structural_fit),
                surprise=min(3, discovery.surprise),
                testability=(
                    3
                    if discovery.generator_ref
                    in _REGISTERED_REVISION_GENERATOR_REFS
                    else 1
                ),
                evidence_grounding=min(
                    3,
                    discovery.evidence_grounding,
                ),
                assumption_risk=(
                    1
                    if discovery.structural_fit >= 3
                    else 2
                ),
                estimated_compute=100.0,
                rationale=(
                    "causal-relation retrieval plus complete role mapping; "
                    "grades are an internal review, not evidence"
                ),
            )
        )
    return trace, tuple(inspirations), tuple(evaluations)


def _contract_mechanism_signature(
    contract: ExecutableHypothesisContract,
    causal_models: CausalFailureModelSet,
    *,
    intervention_operator: str | None = None,
    information_source: str | None = None,
    boundary_conditions: Sequence[str] = (),
) -> MechanismSignature:
    by_cluster = {
        model.cluster_id: model for model in causal_models.models
    }
    target_classes = tuple(
        sorted(
            {
                "|".join(by_cluster[cluster_id].causal_signature)
                for cluster_id in contract.target_cluster_ids
            }
        )
    )
    generator_ref = contract.generator_patch.generator_ref
    default_information_source = {
        "binpacking-contextual-linear-generator-v1": (
            "bounded_recent_sequence_state"
        ),
        "binpacking-regime-router-generator-v1": (
            "bounded_regime_state"
        ),
        "binpacking-demand-memory-generator-v1": (
            "recent_empirical_demand_distribution"
        ),
        "binpacking-sparse-repair-generator-v1": (
            "verified_failure_syndrome"
        ),
    }.get(generator_ref, "observable_failure_proxy")
    default_operator = {
        "binpacking-contextual-linear-generator-v1": (
            "context_conditioned_action_score"
        ),
        "binpacking-regime-router-generator-v1": (
            "state_conditioned_complete_policy_selection"
        ),
        "binpacking-demand-memory-generator-v1": (
            "demand_conditioned_residual_score"
        ),
        "binpacking-sparse-repair-generator-v1": (
            "syndrome_gated_sparse_override"
        ),
    }.get(generator_ref, "compiled_action_intervention")
    return MechanismSignature(
        target_failure_classes=target_classes,
        information_regime=contract.information_regime.value,
        information_source=(
            default_information_source
            if information_source is None
            else information_source
        ),
        intervention_operator=(
            default_operator
            if intervention_operator is None
            else intervention_operator
        ),
        mediator=contract.mediator,
        protected_resource="usable_post_placement_residual",
        outcome="fewer_bins_on_targeted_online_instances",
        boundary_conditions=tuple(dict.fromkeys(boundary_conditions)),
        signature_ref="binpacking-domain-neutral-mechanism-signature-v1",
    )


def _contract_prediction_profile(
    contract: ExecutableHypothesisContract,
    *,
    boundary_predictions: Sequence[Tuple[str, str]] = (),
) -> HypothesisPredictionProfile:
    return HypothesisPredictionProfile(
        target_effect="positive_fewer_bins",
        target_control_relation="target_effect_exceeds_matched_control",
        information_ablation_response=(
            "history_mask_removes_at_least_half_effect"
            if contract.information_regime
            == InformationRegime.PREDICTIVE_PROXY
            else "history_mask_preserves_at_least_half_effect"
        ),
        mediator_response=(
            "heldout_alternative_action_match_rate_at_least_0.25_with_"
            "multiple_action_classes"
        ),
        mechanism_ablation_response="zero_patch_recovers_incumbent",
        boundary_predictions=tuple(boundary_predictions),
        measurement_ref="binpacking-compiled-diagnostic-suite-v3",
    )


def _island_hypothesis_seeds(
    node: GoalNodeSpec,
    control_plane: AutonomousScientistControlPlane,
) -> Tuple[TournamentHypothesis, ...]:
    campaigns = tuple(
        campaign
        for campaign in control_plane.campaigns.values()
        if campaign.contract.node_id == node.node_id
    )
    if not campaigns:
        return ()
    campaign = max(
        campaigns,
        key=lambda item: (
            len(item.rounds),
            item.contract.campaign_id,
        ),
    )
    if not campaign.rounds:
        return ()
    final_round = max(summary.round_index for summary in campaign.rounds)
    seeds = []
    for family in (
        SearchFamily.ANCESTRY,
        SearchFamily.DE_NOVO,
        SearchFamily.HYBRID,
    ):
        proposals = tuple(
            proposal
            for proposal in campaign.proposals.values()
            if proposal.family == family
            and proposal.round_index == final_round
        )
        scored = []
        for proposal in proposals:
            observed = tuple(
                verification
                for verification in campaign.verifications.get(
                    proposal.candidate_id,
                    (),
                )
                if verification.partition
                not in (
                    EvidencePartition.REPLICATION,
                    EvidencePartition.EXTERNAL_CONFIRMATION,
                )
            )
            if observed:
                scored.append(
                    (
                        max(
                            verification.effect_size
                            for verification in observed
                        ),
                        proposal,
                        observed,
                    )
                )
        if not scored:
            continue
        _, proposal, observed = max(
            scored,
            key=lambda item: (
                item[0],
                item[1].candidate_id,
            ),
        )
        seeds.append(
            TournamentHypothesis(
                target_node_id=node.node_id,
                statement=(
                    "The strongest development-stage %s island mechanism "
                    "contains a reusable causal fragment even though the "
                    "representation-level campaign plateaued."
                    % family.value
                ),
                mechanism=proposal.mechanism_summary,
                origin=HypothesisOrigin.ISLAND,
                source_ref=proposal.candidate_id,
                generator_ref=(
                    "plateaued-island-candidate:"
                    + proposal.candidate_id
                ),
                predictions=(
                    "the fragment retains its development effect when "
                    "embedded in a distinct representation",
                    "ablating the fragment worsens matched development score",
                ),
                falsification_conditions=(
                    "the fragment is behaviorally identical to prior art",
                    "its effect vanishes outside its original candidate",
                ),
                assumptions=(
                    "pre-replication campaign evidence can identify a "
                    "reusable mechanism without exposing replication or "
                    "external-confirmation data",
                ),
                evidence_ids=tuple(
                    verification.verification_id
                    for verification in observed
                ),
                mechanism_signature=MechanismSignature(
                    target_failure_classes=(
                        "observed_plateau_fragment",
                    ),
                    information_regime="development_observation",
                    information_source=(
                        family.value + "_island_search"
                    ),
                    intervention_operator=(
                        "transfer_observed_candidate_fragment"
                    ),
                    mediator="uncompiled_candidate_fragment",
                    protected_resource="incumbent_fallback_behavior",
                    outcome="development_score_retention_after_transfer",
                    boundary_conditions=(family.value,),
                    signature_ref=(
                        "binpacking-island-fragment-signature-v1"
                    ),
                ),
                prediction_profile=HypothesisPredictionProfile(
                    target_effect="retain_positive_development_effect",
                    target_control_relation=(
                        "embedded_fragment_exceeds_fragment_ablation"
                    ),
                    information_ablation_response=(
                        "not_applicable_no_information_proxy"
                    ),
                    mediator_response=(
                        "fragment_changes_embedded_candidate_behavior"
                    ),
                    mechanism_ablation_response=(
                        "fragment_ablation_worsens_development_score"
                    ),
                    boundary_predictions=(
                        (
                            "source_representation_removed",
                            "effect_retained",
                        ),
                    ),
                    measurement_ref=(
                        "binpacking-island-fragment-transfer-test-v1"
                    ),
                ),
                island_family=family.value,
                revision_eligible=False,
            )
        )
    return tuple(seeds)


def _hypothesis_patch(
    inspiration: CrossDomainInspiration,
    information_regime: InformationRegime,
    *,
    causal_operator: CausalEvolutionOperator,
) -> GeneratorPatch:
    scale = 0.75 + (
        int(inspiration.inspiration_id[:4], 16) % 5
    ) * 0.25
    if (
        inspiration.generator_ref
        == "binpacking-contextual-linear-generator-v1"
    ):
        weights = (
            (
                (
                    "recent_mean",
                    0.5 * scale,
                ),
                ("recent_trend", scale),
                ("remaining_x_recent_mean", scale),
                ("is_new_bin", -0.5),
            )
            if information_regime == InformationRegime.PREDICTIVE_PROXY
            else (
                ("remaining_squared", scale),
                ("load_std", -0.5 * scale),
                ("is_new_bin", -0.5),
                ("negative_remaining_after", 0.25),
            )
        )
    elif (
        inspiration.generator_ref
        == "binpacking-regime-router-generator-v1"
    ):
        weights = (
            (
                ("best_fit:recent_mean", scale),
                ("funsearch:recent_trend", -0.5 * scale),
                ("worst_fit:recent_large_fraction", 0.5 * scale),
            )
            if information_regime == InformationRegime.PREDICTIVE_PROXY
            else (
                ("worst_fit:fullest_remaining", scale),
                ("best_fit:load_std", -0.5 * scale),
                ("funsearch:bias", 0.25),
            )
        )
    elif (
        inspiration.generator_ref
        == "binpacking-demand-memory-generator-v1"
    ):
        weights = (
            (
                ("demand_density_after", scale),
                ("exact_complement_rate", 0.5 * scale),
                ("demand_density_preserved", 0.5 * scale),
                ("negative_remaining_after", 0.25),
            )
            if information_regime == InformationRegime.PREDICTIVE_PROXY
            else (
                ("demand_density_preserved", scale),
                ("large_item_slot", 0.75 * scale),
                ("small_item_fragment", -0.5 * scale),
                ("is_new_bin", -0.25),
            )
        )
    else:
        # The mechanism remains analyzable but cannot win the executable slot.
        weights = (("unsupported_generator_marker", scale),)
    return GeneratorPatch(
        generator_ref=inspiration.generator_ref,
        information_regime=information_regime,
        causal_operator=causal_operator,
        feature_weights=tuple(weights),
        protected_option=(
            "a post-placement residual that remains usable under hidden "
            "future demand"
        ),
        compiler_ref="binpacking-causal-hypothesis-compiler-v1",
    )


def _compiled_program_for_patch(
    patch: GeneratorPatch,
) -> Optional[OnlineHeuristic]:
    if (
        patch.generator_ref
        == "binpacking-contextual-linear-generator-v1"
    ):
        return ContextualLinearProgram(
            "ancestry",
            _contextual_weights(dict(patch.feature_weights)),
            0.10,
        )
    if (
        patch.generator_ref
        == "binpacking-demand-memory-generator-v1"
    ):
        return DemandMemoryProgram(
            "ancestry",
            _demand_memory_weights(dict(patch.feature_weights)),
            0.10,
        )
    if patch.generator_ref == "binpacking-regime-router-generator-v1":
        values: Dict[str, Dict[str, float]] = {}
        for name, weight in patch.feature_weights:
            policy, separator, feature = name.partition(":")
            if (
                not separator
                or policy not in REGIME_ROUTER_POLICIES
                or feature not in REGIME_ROUTER_FEATURES
            ):
                return None
            values.setdefault(policy, {})[feature] = weight
        return RegimeRouterProgram("ancestry", _regime_matrix(values))
    return None


def _compile_hypothesis_contract(
    inspiration: CrossDomainInspiration,
    causal_models: CausalFailureModelSet,
    *,
    causal_operator: CausalEvolutionOperator = (
        CausalEvolutionOperator.SOURCE_TRANSFER
    ),
) -> ExecutableHypothesisContract:
    supported = tuple(
        model
        for model in causal_models.models
        if model.empirically_supported
    )
    if not supported:
        raise ValueError(
            "cannot compile a hypothesis without counterfactual support"
        )
    preferred_regime = (
        InformationRegime.PREDICTIVE_PROXY
        if inspiration.generator_ref
        in (
            "binpacking-contextual-linear-generator-v1",
            "binpacking-demand-memory-generator-v1",
        )
        else InformationRegime.ROBUST_OPTIONALITY
    )
    regime_candidates = tuple(
        model
        for model in supported
        if model.information_regime == preferred_regime.value
    )
    if not regime_candidates:
        regime_candidates = supported
        preferred_regime = InformationRegime(
            regime_candidates[0].information_regime
        )
    representative = max(
        regime_candidates,
        key=lambda model: (
            model.counterfactual_effect,
            model.proxy_reliability,
            model.model_id,
        ),
    )
    targets = tuple(
        model
        for model in regime_candidates
        if model.mediator == representative.mediator
    )
    patch = _hypothesis_patch(
        inspiration,
        preferred_regime,
        causal_operator=causal_operator,
    )
    return ExecutableHypothesisContract(
        target_node_id=inspiration.target_node_id,
        target_cluster_ids=tuple(
            model.cluster_id for model in targets
        ),
        observable_trigger=representative.observable_proxies[0],
        action_change=representative.alternative_action,
        protected_option=patch.protected_option,
        mediator=representative.mediator,
        information_regime=preferred_regime,
        # This is declared before executing the compiled program. The causal
        # replay establishes direction, not the compiled policy's effect.
        expected_effect=0.25,
        effect_unit="fewer bins per targeted diagnostic instance",
        matched_control_prediction=(
            "effect is larger on target causal clusters than on other "
            "counterfactual clusters"
        ),
        ablation=(
            "set every compiled patch coefficient to zero and recover the "
            "unchanged FunSearch incumbent"
        ),
        shuffled_information_prediction=(
            "masking arrival history removes at least half the benefit"
            if preferred_regime == InformationRegime.PREDICTIVE_PROXY
            else "masking arrival history preserves at least half the benefit"
        ),
        prior_art_distinction=(
            "the policy must differ behaviorally from FunSearch, Best Fit, "
            "and the preregistered exact-fill action on diagnostic probes"
        ),
        generator_patch=patch,
        diagnostic_budget=max(
            1,
            sum(len(model.decision_trace_ids) for model in targets),
        ),
        contract_ref="binpacking-causal-hypothesis-compiler-v1",
    )


def _decision_trace_payload(
    store: ArtifactStore,
    artifact_id: str,
) -> Mapping[str, Any]:
    envelope = store.get(artifact_id)
    if envelope["kind"] != "binpacking_decision_counterfactual_trace":
        raise ValueError("causal model references a non-trace artifact")
    return envelope["value"]


def _instance_from_trace_payload(
    payload: Mapping[str, Any],
) -> BinPackingInstance:
    value = payload["instance"]
    return BinPackingInstance(
        instance_id=str(value["instance_id"]),
        family=str(value["family"]),
        seed=int(value["seed"]),
        capacity=int(value["capacity"]),
        items=tuple(int(item) for item in value["items"]),
    )


def _diagnose_compiled_hypothesis(
    contract: ExecutableHypothesisContract,
    causal_models: CausalFailureModelSet,
    store: ArtifactStore,
    *,
    evaluation_target_cluster_ids: Optional[
        Sequence[str]
    ] = None,
    training_cluster_ids: Sequence[str] = (),
    training_trace_ids: Sequence[str] = (),
    minimum_source_decisions: int = 2,
    minimum_alternative_action_classes: int = 1,
    online_learnability_accuracy: Optional[float] = None,
    online_learnability_gain: Optional[float] = None,
) -> HypothesisDiagnosticResult:
    by_cluster = {
        model.cluster_id: model for model in causal_models.models
    }
    evaluation_ids = tuple(
        contract.target_cluster_ids
        if evaluation_target_cluster_ids is None
        else evaluation_target_cluster_ids
    )
    if not set(evaluation_ids).issubset(contract.target_cluster_ids):
        raise ValueError(
            "diagnostic evaluation clusters are outside the contract target"
        )
    if minimum_source_decisions < 1:
        raise ValueError("minimum source decisions must be positive")
    if minimum_alternative_action_classes < 1:
        raise ValueError(
            "minimum alternative-action classes must be positive"
        )
    target_models = tuple(
        by_cluster[cluster_id]
        for cluster_id in evaluation_ids
    )
    control_models = tuple(
        model
        for model in causal_models.models
        if model.cluster_id not in contract.target_cluster_ids
        and model.empirically_supported
    )
    candidate = _compiled_program_for_patch(contract.generator_patch)
    target_payloads = tuple(
        _decision_trace_payload(store, trace_id)
        for model in target_models
        for trace_id in model.decision_trace_ids
    )
    control_payloads = tuple(
        _decision_trace_payload(store, trace_id)
        for model in control_models
        for trace_id in model.decision_trace_ids
    )
    target_instances = tuple(
        _instance_from_trace_payload(payload)
        for payload in target_payloads
    )
    control_instances = tuple(
        _instance_from_trace_payload(payload)
        for payload in control_payloads
    )
    source_decision_keys = tuple(
        dict.fromkeys(
            (
                str(payload["instance"]["instance_id"]),
                int(payload["decision_index"]),
            )
            for payload in target_payloads
        )
    )
    alternative_action_classes = tuple(
        sorted(
            {
                (
                    "open_new_bin"
                    if int(payload["alternative_action"]) < 0
                    else "place_existing_bin"
                )
                for payload in target_payloads
            }
        )
    )
    evaluation_trace_ids = {
        str(payload["trace_id"]) for payload in target_payloads
    }
    fit_trace_overlap = evaluation_trace_ids.intersection(
        str(trace_id) for trace_id in training_trace_ids
    )
    cluster_overlap = set(evaluation_ids).intersection(
        str(cluster_id) for cluster_id in training_cluster_ids
    )

    incumbent = literature_heuristics()["funsearch_or_reference"]

    def suffix_replays(
        payloads: Sequence[Mapping[str, Any]],
        label: str,
    ) -> Tuple[
        Tuple[BinPackingInstance, Mapping[str, Any], bool],
        ...,
    ]:
        cases = []
        for payload_index, payload in enumerate(payloads):
            original = _instance_from_trace_payload(payload)
            cases.append((original, payload, False))
            split = int(payload["decision_index"]) + 1
            prefix = original.items[:split]
            suffix = original.items[split:]
            observed = {original.items}
            for replay_index in range(3):
                replay_seed = int(
                    content_digest(
                        {
                            "contract_id": contract.contract_id,
                            "label": label,
                            "payload_index": payload_index,
                            "replay_index": replay_index,
                        }
                    )[:16],
                    16,
                )
                shuffled = list(suffix)
                random.Random(replay_seed).shuffle(shuffled)
                items = prefix + tuple(shuffled)
                if items in observed:
                    continue
                observed.add(items)
                replay = BinPackingInstance(
                    instance_id=content_digest(
                        {
                            "kind": "causal_suffix_replay",
                            "source_instance_id": original.instance_id,
                            "contract_id": contract.contract_id,
                            "label": label,
                            "replay_index": replay_index,
                            "items": list(items),
                        }
                    ),
                    family=original.family + "_causal_suffix_replay",
                    seed=replay_seed,
                    capacity=original.capacity,
                    items=items,
                )
                cases.append((replay, payload, True))
        return tuple(cases)

    target_cases = suffix_replays(target_payloads, "target")
    control_cases = suffix_replays(control_payloads, "control")
    replay_suite_digest = store.put(
        "binpacking_hypothesis_suffix_replay_suite",
        {
            "contract_id": contract.contract_id,
            "target_source_count": len(target_payloads),
            "control_source_count": len(control_payloads),
            "unique_target_source_decision_count": len(
                source_decision_keys
            ),
            "evaluation_target_cluster_ids": list(evaluation_ids),
            "training_cluster_ids": list(training_cluster_ids),
            "fit_evaluation_trace_overlap_count": len(
                fit_trace_overlap
            ),
            "fit_evaluation_cluster_overlap_count": len(cluster_overlap),
            "alternative_action_classes": list(
                alternative_action_classes
            ),
            "target_replay_count": sum(
                independent for _, _, independent in target_cases
            ),
            "control_replay_count": sum(
                independent for _, _, independent in control_cases
            ),
            "target_instances": [
                instance.as_dict() for instance, _, _ in target_cases
            ],
            "control_instances": [
                instance.as_dict() for instance, _, _ in control_cases
            ],
            "construction": (
                "hold the online prefix through the causal decision fixed "
                "and deterministically permute the previously unseen suffix"
            ),
            "independence_boundary": (
                "suffix permutations are robustness checks only; promotion "
                "counts unique source decisions and held-out clusters"
            ),
            "online_learnability_accuracy": (
                online_learnability_accuracy
            ),
            "online_learnability_gain": online_learnability_gain,
        },
    )

    def effects(
        heuristic: Optional[OnlineHeuristic],
        cases: Sequence[
            Tuple[BinPackingInstance, Mapping[str, Any], bool]
        ],
    ) -> Tuple[float, ...]:
        if heuristic is None:
            return ()
        return tuple(
            float(pack(instance, incumbent).bin_count)
            - pack(instance, heuristic).bin_count
            for instance, _, _ in cases
        )

    target_effects = effects(candidate, target_cases)
    control_effects = effects(candidate, control_cases)
    source_target_effects = effects(
        candidate,
        tuple(
            case for case in target_cases if not case[2]
        ),
    )
    target_effect = mean(target_effects) if target_effects else 0.0
    control_effect = mean(control_effects) if control_effects else 0.0
    masked_candidate = (
        None
        if candidate is None
        else FunctionalHeuristic(
            name="history_masked_" + candidate.name,
            chooser=lambda item, loads, capacity, item_index, history: (
                candidate.choose_bin(
                    item,
                    loads,
                    capacity,
                    item_index,
                    (),
                )
            ),
        )
    )
    masked_effects = effects(masked_candidate, target_cases)
    masked_effect = mean(masked_effects) if masked_effects else 0.0
    mediator_matches = 0
    if candidate is not None:
        for instance, payload, _ in target_cases:
            result = pack(instance, candidate)
            index = int(payload["decision_index"])
            candidate_action = result.placements[index].bin_index
            loads_before = tuple(int(item) for item in payload["loads_before"])
            if candidate_action >= len(loads_before):
                candidate_action = -1
            if candidate_action == int(payload["alternative_action"]):
                mediator_matches += 1
    mediator_consistency = (
        mediator_matches / float(len(target_cases))
        if target_cases
        else 0.0
    )
    prior_art_distinct = False
    if candidate is not None and target_instances:
        exact_fill = ActionHybridProgram(
            Expression.binary(
                "sub",
                Expression.const(0.0),
                Expression.feature("remaining_after"),
            ),
            Expression.const(1.0),
            0.10,
        )
        known = (
            literature_heuristics()["funsearch_or_reference"],
            baseline_heuristics()["best_fit"],
            exact_fill,
        )
        candidate_fingerprint = behaviour_fingerprint(
            candidate,
            target_instances,
        )
        prior_art_distinct = all(
            candidate_fingerprint
            != behaviour_fingerprint(control, target_instances)
            for control in known
        )
    prediction_log_score = max(
        -4.0,
        2.0
        - abs(target_effect - contract.expected_effect)
        / contract.expected_effect,
    )
    failures = []
    if candidate is None:
        failures.append("no_registered_executable_compiler")
    if not target_effects:
        failures.append("no_target_replays")
    elif target_effect <= 0:
        failures.append("compiled_intervention_did_not_improve_targets")
    if len(source_decision_keys) < minimum_source_decisions:
        failures.append("insufficient_independent_source_decisions")
    if (
        len(alternative_action_classes)
        < minimum_alternative_action_classes
    ):
        failures.append(
            "insufficient_alternative_action_heterogeneity"
        )
    if fit_trace_overlap:
        failures.append("training_evaluation_trace_overlap")
    if cluster_overlap:
        failures.append("training_evaluation_cluster_overlap")
    if source_target_effects and (
        sum(effect > 0 for effect in source_target_effects)
        / float(len(source_target_effects))
        < 0.5
    ):
        failures.append(
            "effect_did_not_hold_across_source_decisions"
        )
    if not control_effects:
        failures.append("no_matched_control_replays")
    elif target_effect <= control_effect:
        failures.append("target_effect_not_larger_than_matched_control")
    if mediator_consistency < 0.25:
        failures.append("compiled_action_did_not_engage_the_mediator")
    if (
        contract.information_regime == InformationRegime.PREDICTIVE_PROXY
        and online_learnability_accuracy is not None
        and online_learnability_accuracy < 0.50
    ):
        failures.append(
            "heldout_action_prediction_below_threshold"
        )
    if (
        contract.information_regime == InformationRegime.PREDICTIVE_PROXY
        and online_learnability_gain is not None
        and online_learnability_gain < 0.10
    ):
        failures.append(
            "online_history_not_predictive_of_beneficial_action"
        )
    if (
        contract.information_regime == InformationRegime.PREDICTIVE_PROXY
        and target_effect > 0
        and masked_effect > 0.5 * target_effect
    ):
        failures.append("history_mask_did_not_remove_predictive_effect")
    if (
        contract.information_regime == InformationRegime.ROBUST_OPTIONALITY
        and target_effect > 0
        and masked_effect < 0.5 * target_effect
    ):
        failures.append("robust_optionality_depended_on_history")
    if not prior_art_distinct:
        failures.append("compiled_policy_matches_preregistered_prior_art")
    return HypothesisDiagnosticResult(
        contract_id=contract.contract_id,
        executable_digest=contract.executable_digest,
        target_replay_count=len(target_effects),
        matched_control_count=len(control_effects),
        target_effect=target_effect,
        matched_control_effect=control_effect,
        ablation_effect=0.0,
        shuffled_information_effect=masked_effect,
        mediator_consistency=mediator_consistency,
        prediction_log_score=prediction_log_score,
        prior_art_distinct=prior_art_distinct,
        passed=not failures,
        failure_reasons=tuple(failures),
        evidence_ids=tuple(
            (
                *dict.fromkeys(
                    trace_id
                    for model in (*target_models, *control_models)
                    for trace_id in model.decision_trace_ids
                ),
                replay_suite_digest,
            )
        ),
        diagnostic_ref="binpacking-compiled-diagnostic-suite-v3",
    )


def _mediator_recovery_literature_assessment(
    node: GoalNodeSpec,
    base: PriorArtAssessment,
    causal_models: CausalFailureModelSet,
    champion: TournamentHypothesis,
) -> PriorArtAssessment:
    mediators = tuple(
        dict.fromkeys(
            model.mediator
            for model in causal_models.models
            if model.empirically_supported
        )
    )
    queries = tuple(
        LiteratureQuery(
            query=query,
            facet=facet,
            provider=provider,
        )
        for facet, query in (
            (SearchFacet.PROBLEM, "online bin packing heuristic"),
            (
                SearchFacet.INTERVENTION,
                "target engagement intervention",
            ),
            (
                SearchFacet.MECHANISM,
                "mediator measurement causal inference",
            ),
            (
                SearchFacet.MECHANISM,
                "persistent excitation system identification",
            ),
            (
                SearchFacet.EVALUATION,
                "causal mediation intervention analysis",
            ),
        )
        for provider in ("Google Scholar", "Semantic Scholar")
    )
    return PriorArtAssessment(
        signature=ClaimSignature(
            subject_id=node.node_id,
            statement=node.question,
            problem=base.signature.problem,
            phenomenon=(
                "the Elo champion failed to engage its proposed mediator"
            ),
            intervention=(
                "identify an action-level mediator proxy, apply bounded "
                "persistent excitation, and require target engagement before "
                "outcome optimization"
            ),
            mechanism="; ".join(mediators),
            evaluation=(
                "decision-trace target engagement, matched causal-schema "
                "controls, suffix replay, history masking, and ablation"
            ),
        ),
        trigger=LiteratureTrigger.PERIODIC_DELTA,
        queries=queries,
        closest_works=base.closest_works,
        classification=ClaimClassification.NOVEL_CANDIDATE,
        rationale=(
            "The final tournament champion did not manipulate the proposed "
            "mediator. This review retrieves measurement and intervention "
            "methods before fitting another executable action rule."
        ),
        novel_delta=(
            "mediator engagement is measured before outcome optimization",
            "target traces and other causal schemas form matched controls",
            "only a diagnostic-passing intervention may revise the graph",
        ),
        citation_snowball_complete=base.citation_snowball_complete,
        searched_at=base.searched_at,
        reviewer_ref=(
            "binpacking-mediator-recovery-literature-planner-v1:"
            + champion.hypothesis_id
        ),
        executable_incumbent_id=base.executable_incumbent_id,
    )


def _acquire_causal_qualification_models(
    contract: ExecutableHypothesisContract,
    causal_models: CausalFailureModelSet,
    store: ArtifactStore,
    *,
    minimum_per_action_class: int = 3,
    maximum_attempts: int = 280,
) -> Tuple[
    ExecutableHypothesisContract,
    CausalFailureModelSet,
    Mapping[str, Any],
]:
    """Mine fresh, action-balanced causal decisions before intervention fit."""

    by_cluster = {
        model.cluster_id: model for model in causal_models.models
    }
    existing_targets = tuple(
        by_cluster[cluster_id]
        for cluster_id in contract.target_cluster_ids
    )

    def action_class(model: CausalFailureModel) -> str:
        payload = _decision_trace_payload(
            store,
            model.decision_trace_ids[0],
        )
        return (
            "open_new_bin"
            if int(payload["alternative_action"]) < 0
            else "place_existing_bin"
        )

    class_counts = {
        label: sum(
            action_class(model) == label
            for model in existing_targets
        )
        for label in ("open_new_bin", "place_existing_bin")
    }
    if min(class_counts.values()) >= minimum_per_action_class:
        return contract, causal_models, {
            "acquisition_ref": (
                "binpacking-causal-qualification-acquisition-v1"
            ),
            "attempted": 0,
            "accepted_target_count": 0,
            "accepted_control_count": 0,
            "target_action_class_counts": class_counts,
            "outcome": "existing_evidence_sufficient",
        }

    incumbent = literature_heuristics()["funsearch_or_reference"]
    seed_base = int(
        content_digest(
            {
                "contract_id": contract.contract_id,
                "purpose": "causal-qualification-acquisition",
            }
        )[:12],
        16,
    )
    existing_instance_ids = {
        str(
            _decision_trace_payload(
                store,
                trace_id,
            )["instance"]["instance_id"]
        )
        for model in causal_models.models
        for trace_id in model.decision_trace_ids
    }
    target_models = []
    control_models = []
    attempted = 0

    def model_from_trace(
        trace: DecisionCounterfactualTrace,
        trace_digest: str,
        sequence: int,
    ) -> CausalFailureModel:
        predictive = (
            trace.information_regime
            == InformationRegime.PREDICTIVE_PROXY
        )
        relations = (
            CausalRelationKind
            .INFORMATION_REVEALED_AFTER_COMMITMENT,
            CausalRelationKind.COMMITMENT_DESTROYS_OPTION,
            CausalRelationKind.ALTERNATIVE_PRESERVES_OPTION,
            CausalRelationKind.PRESERVED_OPTION_CHANGES_OUTCOME,
            *(
                (
                    CausalRelationKind
                    .FEEDBACK_CORRECTS_FUTURE_ACTION,
                )
                if predictive
                else ()
            ),
        )
        alternative_class = (
            "open_new_bin"
            if trace.alternative_action < 0
            else "place_existing_bin"
        )
        return CausalFailureModel(
            target_node_id=contract.target_node_id,
            cluster_id=(
                "qualification:%s:%04d"
                % (trace.trace_id[:16], sequence)
            ),
            cluster_description=(
                "fresh held-out causal decision with %s alternative"
                % alternative_class
            ),
            unavailable_information=(
                "future complement demand unavailable at the online "
                "placement decision"
            ),
            information_available_after=(
                "after the irreversible placement and subsequent arrivals"
            ),
            irreversible_decision=(
                "commit the current item to an existing or new bin"
            ),
            decision_point=(
                "decision %d before future items are observed"
                % trace.decision_index
            ),
            alternative_action=(
                "open a new bin"
                if trace.alternative_action < 0
                else "place in existing bin %d"
                % trace.alternative_action
            ),
            changed_result=(
                "%d fewer bin(s) under the forced one-step replay"
                % trace.outcome_delta
            ),
            causal_chain=(
                "hidden future demand; irreversible placement; changed "
                "residual option; changed complete-suffix bin count"
            ),
            causal_relations=relations,
            observable_proxies=(
                (
                    "recent complement density"
                    if predictive
                    else "current residual-option structure"
                ),
            ),
            evidence_ids=(trace_digest,),
            assumptions=(
                "the generated instance was fixed before intervention fit",
                "only legal online history is available to the policy",
            ),
            distinguishing_predictions=(
                "the alternative action recurs in an untouched cluster",
                "full-policy improvement survives source-decision holdout",
            ),
            falsification_conditions=(
                "the alternative action class is not reproduced",
                "the held-out complete-policy effect is non-positive",
            ),
            modeler_ref=(
                "binpacking-causal-qualification-acquisition-v1"
            ),
            decision_trace_ids=(trace_digest,),
            causal_signature=trace.causal_signature,
            information_regime=trace.information_regime.value,
            mediator=trace.mediator,
            counterfactual_effect=float(trace.outcome_delta),
            proxy_reliability=trace.proxy_reliability,
            empirically_supported=True,
        )

    families = tuple(sorted(GENERATORS))
    for attempt_index in range(maximum_attempts):
        attempted += 1
        family = families[attempt_index % len(families)]
        instance = generate_instance(
            family,
            seed_base + attempt_index,
            120,
            150,
        )
        if instance.instance_id in existing_instance_ids:
            continue
        trace = trace_first_effective_decision(
            contract.target_node_id,
            instance,
            incumbent,
        )
        if trace.status != CounterfactualStatus.SUPPORTED:
            continue
        is_target = (
            trace.mediator == contract.mediator
            and trace.information_regime.value
            == contract.information_regime.value
        )
        label = (
            "open_new_bin"
            if trace.alternative_action < 0
            else "place_existing_bin"
        )
        if is_target and class_counts[label] >= 12:
            continue
        if not is_target and len(control_models) >= 24:
            continue
        trace_digest = store.put(
            "binpacking_decision_counterfactual_trace",
            {
                **trace.as_dict(),
                "qualification_acquisition": True,
                "qualification_contract_id": contract.contract_id,
                "qualification_attempt_index": attempt_index,
            },
        )
        model = model_from_trace(
            trace,
            trace_digest,
            attempt_index,
        )
        if is_target:
            target_models.append(model)
            class_counts[label] += 1
        else:
            control_models.append(model)
        if min(class_counts.values()) >= minimum_per_action_class:
            break

    expanded_targets = (*existing_targets, *target_models)
    expanded_models = (
        *causal_models.models,
        *target_models,
        *control_models,
    )
    acquisition_value = {
        "acquisition_ref": (
            "binpacking-causal-qualification-acquisition-v1"
        ),
        "contract_id": contract.contract_id,
        "attempted": attempted,
        "maximum_attempts": maximum_attempts,
        "accepted_target_count": len(target_models),
        "accepted_control_count": len(control_models),
        "target_action_class_counts": dict(class_counts),
        "minimum_per_action_class": minimum_per_action_class,
        "source_families": list(families),
        "outcome": (
            "action_balanced_target_evidence_acquired"
            if min(class_counts.values()) >= minimum_per_action_class
            else "action_balanced_target_evidence_unavailable"
        ),
    }
    acquisition_digest = store.put(
        "binpacking_causal_qualification_acquisition",
        acquisition_value,
    )
    expanded_set = CausalFailureModelSet(
        target_node_id=causal_models.target_node_id,
        failure_cluster_ids=tuple(
            model.cluster_id for model in expanded_models
        ),
        models=tuple(expanded_models),
        source_artifact_ids=tuple(
            dict.fromkeys(
                (
                    *causal_models.source_artifact_ids,
                    *(
                        trace_id
                        for model in (*target_models, *control_models)
                        for trace_id in model.decision_trace_ids
                    ),
                    acquisition_digest,
                )
            )
        ),
        builder_ref=(
            "binpacking-causal-qualification-acquisition-v1"
        ),
    )
    expanded_contract = replace(
        contract,
        target_cluster_ids=tuple(
            model.cluster_id for model in expanded_targets
        ),
        diagnostic_budget=max(
            contract.diagnostic_budget,
            len(expanded_targets),
        ),
        contract_ref=(
            contract.contract_ref
            + ":fresh-action-balanced-qualification"
        ),
    )
    return (
        expanded_contract,
        expanded_set,
        {
            **acquisition_value,
            "acquisition_digest": acquisition_digest,
            "expanded_contract_id": expanded_contract.contract_id,
            "expanded_model_set_id": expanded_set.model_set_id,
        },
    )


def _retarget_contract_for_causal_coverage(
    contract: ExecutableHypothesisContract,
    causal_models: CausalFailureModelSet,
    store: ArtifactStore,
) -> Tuple[ExecutableHypothesisContract, Mapping[str, Any]]:
    """Prefer a learnable mediator over the largest local effect."""

    supported = tuple(
        model
        for model in causal_models.models
        if model.empirically_supported
    )
    groups: Dict[
        Tuple[str, str],
        list[CausalFailureModel],
    ] = {}
    for model in supported:
        groups.setdefault(
            (model.information_regime, model.mediator),
            [],
        ).append(model)

    def group_summary(
        key: Tuple[str, str],
        models: Sequence[CausalFailureModel],
    ) -> Mapping[str, Any]:
        counts = {
            "open_new_bin": 0,
            "place_existing_bin": 0,
        }
        for model in models:
            for trace_id in model.decision_trace_ids:
                payload = _decision_trace_payload(store, trace_id)
                label = (
                    "open_new_bin"
                    if int(payload["alternative_action"]) < 0
                    else "place_existing_bin"
                )
                counts[label] += 1
        score = (
            min(counts.values()),
            sum(value > 0 for value in counts.values()),
            sum(counts.values()),
            mean(model.proxy_reliability for model in models),
            mean(model.counterfactual_effect for model in models),
        )
        return {
            "information_regime": key[0],
            "mediator": key[1],
            "cluster_ids": [model.cluster_id for model in models],
            "action_class_counts": counts,
            "coverage_score": list(score),
        }

    summaries = tuple(
        group_summary(key, models)
        for key, models in sorted(groups.items())
    )
    if not summaries:
        return contract, {
            "retargeting_ref": (
                "binpacking-causal-coverage-retargeter-v1"
            ),
            "outcome": "no_supported_causal_group",
            "original_contract_id": contract.contract_id,
            "groups": [],
        }
    selected = max(
        summaries,
        key=lambda item: (
            tuple(item["coverage_score"]),
            item["information_regime"],
            item["mediator"],
        ),
    )
    selected_key = (
        str(selected["information_regime"]),
        str(selected["mediator"]),
    )
    original_key = (
        contract.information_regime.value,
        contract.mediator,
    )
    selected_models = tuple(groups[selected_key])
    if selected_key == original_key:
        return contract, {
            "retargeting_ref": (
                "binpacking-causal-coverage-retargeter-v1"
            ),
            "outcome": "original_target_has_best_causal_coverage",
            "original_contract_id": contract.contract_id,
            "selected_contract_id": contract.contract_id,
            "groups": list(summaries),
        }
    regime = InformationRegime(selected_key[0])
    representative = max(
        selected_models,
        key=lambda model: (
            model.proxy_reliability,
            model.counterfactual_effect,
            model.model_id,
        ),
    )
    patch = replace(
        contract.generator_patch,
        information_regime=regime,
        causal_operator=(
            CausalEvolutionOperator.SUBSTITUTE_PROXY
        ),
    )
    retargeted = replace(
        contract,
        target_cluster_ids=tuple(
            model.cluster_id for model in selected_models
        ),
        observable_trigger=representative.observable_proxies[0],
        action_change=representative.alternative_action,
        mediator=representative.mediator,
        information_regime=regime,
        shuffled_information_prediction=(
            "masking arrival history removes at least half the benefit"
            if regime == InformationRegime.PREDICTIVE_PROXY
            else "masking arrival history preserves at least half the benefit"
        ),
        generator_patch=patch,
        diagnostic_budget=max(
            1,
            sum(
                len(model.decision_trace_ids)
                for model in selected_models
            ),
        ),
        contract_ref=(
            contract.contract_ref
            + ":causal-coverage-retarget"
        ),
    )
    return retargeted, {
        "retargeting_ref": (
            "binpacking-causal-coverage-retargeter-v1"
        ),
        "outcome": "retargeted_to_action_heterogeneous_causal_group",
        "original_contract_id": contract.contract_id,
        "selected_contract_id": retargeted.contract_id,
        "original_information_regime": original_key[0],
        "original_mediator": original_key[1],
        "selected_information_regime": selected_key[0],
        "selected_mediator": selected_key[1],
        "changed_assumption": (
            "the largest local counterfactual effect identifies the most "
            "learnable intervention target"
        ),
        "new_distinguishing_prediction": (
            "a lower-effect mediator with both alternative-action classes "
            "transports better under cluster holdout"
        ),
        "groups": list(summaries),
    }


def _mediator_intervention_study(
    champion: TournamentHypothesis,
    causal_models: CausalFailureModelSet,
    store: ArtifactStore,
    literature: PriorArtAssessment,
) -> Tuple[Mapping[str, Any], Optional[TournamentHypothesis]]:
    contract = champion.executable_contract
    if contract is None:
        raise ValueError(
            "mediator recovery requires an executable champion contract"
        )
    if (
        contract.generator_patch.generator_ref
        != "binpacking-demand-memory-generator-v1"
    ):
        raise ValueError(
            "mediator recovery currently requires the registered "
            "demand-memory intervention"
        )
    contract, retargeting = _retarget_contract_for_causal_coverage(
        contract,
        causal_models,
        store,
    )
    contract, causal_models, acquisition = (
        _acquire_causal_qualification_models(
            contract,
            causal_models,
            store,
        )
    )
    by_cluster = {
        model.cluster_id: model for model in causal_models.models
    }
    target_models = tuple(
        by_cluster[cluster_id]
        for cluster_id in contract.target_cluster_ids
    )
    control_models = tuple(
        model
        for model in causal_models.models
        if model.cluster_id not in contract.target_cluster_ids
        and model.empirically_supported
    )

    def training_example(
        payload: Mapping[str, Any],
        desired_key: str,
        cluster_id: str,
    ) -> Mapping[str, Any]:
        instance = _instance_from_trace_payload(payload)
        decision_index = int(payload["decision_index"])
        item = int(payload["item"])
        loads = tuple(int(value) for value in payload["loads_before"])
        rows = demand_memory_action_features(
            item,
            loads,
            instance.capacity,
            instance.items[:decision_index],
        )
        desired_value = int(payload[desired_key])
        desired_action = (
            None if desired_value < 0 else desired_value
        )
        if not any(row[0] == desired_action for row in rows):
            raise ValueError(
                "causal trace desired action is not feasible"
            )
        return {
            "trace_id": str(payload["trace_id"]),
            "cluster_id": cluster_id,
            "desired_action": desired_action,
            "desired_action_class": (
                "open_new_bin"
                if desired_action is None
                else "place_existing_bin"
            ),
            "chosen_action": (
                None
                if int(payload["chosen_action"]) < 0
                else int(payload["chosen_action"])
            ),
            "rows": rows,
        }

    ordered_target_models = tuple(
        sorted(
            target_models,
            key=lambda model: (
                content_digest(
                    {
                        "contract_id": contract.contract_id,
                        "cluster_id": model.cluster_id,
                    }
                ),
                model.cluster_id,
            ),
        )
    )
    if len(ordered_target_models) < 6:
        return {
            "schema": 2,
            "study_ref": "binpacking-mediator-intervention-study-v2",
            "causal_coverage_retargeting": dict(retargeting),
            "causal_qualification_acquisition": dict(acquisition),
            "champion_hypothesis_id": champion.hypothesis_id,
            "literature_assessment_id": literature.assessment_id,
            "target_cluster_ids": list(contract.target_cluster_ids),
            "target_cluster_count": len(ordered_target_models),
            "candidate_count": 0,
            "candidates": [],
            "qualified_contract_id": None,
            "outcome": "insufficient_cluster_heldout_targets",
            "failure_reasons": [
                "cross-fitting requires at least two disjoint train, "
                "validation, and test target clusters"
            ],
        }, None

    def model_action_class(model: CausalFailureModel) -> str:
        payload = _decision_trace_payload(
            store,
            model.decision_trace_ids[0],
        )
        return (
            "open_new_bin"
            if int(payload["alternative_action"]) < 0
            else "place_existing_bin"
        )

    models_by_action = {
        label: tuple(
            model
            for model in ordered_target_models
            if model_action_class(model) == label
        )
        for label in ("open_new_bin", "place_existing_bin")
    }
    if min(len(models) for models in models_by_action.values()) < 3:
        return {
            "schema": 2,
            "study_ref": "binpacking-mediator-intervention-study-v2",
            "causal_coverage_retargeting": dict(retargeting),
            "causal_qualification_acquisition": dict(acquisition),
            "champion_hypothesis_id": champion.hypothesis_id,
            "literature_assessment_id": literature.assessment_id,
            "target_cluster_ids": list(contract.target_cluster_ids),
            "target_cluster_count": len(ordered_target_models),
            "target_action_class_counts": {
                label: len(models)
                for label, models in models_by_action.items()
            },
            "candidate_count": 0,
            "candidates": [],
            "qualified_contract_id": None,
            "outcome": "insufficient_alternative_action_heterogeneity",
            "failure_reasons": [
                "each alternative-action class requires independent train, "
                "validation, and test clusters"
            ],
        }, None
    training_models_list = []
    validation_models_list = []
    test_models_list = []
    for models in models_by_action.values():
        per_holdout = max(1, len(models) // 4)
        test_models_list.extend(models[:per_holdout])
        validation_models_list.extend(
            models[per_holdout : 2 * per_holdout]
        )
        training_models_list.extend(models[2 * per_holdout :])
    training_models = tuple(training_models_list)
    validation_models = tuple(validation_models_list)
    test_models = tuple(test_models_list)
    if not training_models or not validation_models or not test_models:
        raise ValueError("cross-fit target partition is empty")

    def target_examples_for(
        models: Sequence[CausalFailureModel],
    ) -> Tuple[Mapping[str, Any], ...]:
        return tuple(
            training_example(
                _decision_trace_payload(store, trace_id),
                "alternative_action",
                model.cluster_id,
            )
            for model in models
            for trace_id in model.decision_trace_ids
        )

    training_target_examples = target_examples_for(training_models)
    validation_target_examples = target_examples_for(
        validation_models
    )
    test_target_examples = target_examples_for(test_models)
    all_target_examples = (
        *training_target_examples,
        *validation_target_examples,
        *test_target_examples,
    )
    control_examples = tuple(
        training_example(
            _decision_trace_payload(store, trace_id),
            "chosen_action",
            model.cluster_id,
        )
        for model in control_models
        for trace_id in model.decision_trace_ids
    )
    if not training_target_examples:
        raise ValueError("mediator recovery has no target decision traces")
    action_classes = {
        str(example["desired_action_class"])
        for example in all_target_examples
    }
    training_action_classes = {
        str(example["desired_action_class"])
        for example in training_target_examples
    }
    if len(action_classes) < 2 or len(training_action_classes) < 2:
        return {
            "schema": 2,
            "study_ref": "binpacking-mediator-intervention-study-v2",
            "causal_coverage_retargeting": dict(retargeting),
            "causal_qualification_acquisition": dict(acquisition),
            "champion_hypothesis_id": champion.hypothesis_id,
            "literature_assessment_id": literature.assessment_id,
            "target_cluster_ids": list(contract.target_cluster_ids),
            "training_cluster_ids": [
                model.cluster_id for model in training_models
            ],
            "validation_cluster_ids": [
                model.cluster_id for model in validation_models
            ],
            "test_cluster_ids": [
                model.cluster_id for model in test_models
            ],
            "target_trace_count": len(all_target_examples),
            "alternative_action_classes": sorted(action_classes),
            "training_alternative_action_classes": sorted(
                training_action_classes
            ),
            "candidate_count": 0,
            "candidates": [],
            "qualified_contract_id": None,
            "outcome": "insufficient_alternative_action_heterogeneity",
            "failure_reasons": [
                "the target and fitting partitions must each contain both "
                "open-new-bin and place-existing-bin alternatives"
            ],
        }, None

    feature_count = len(DEMAND_MEMORY_FEATURES)

    def row_for(
        example: Mapping[str, Any],
        action: Optional[int],
    ) -> Tuple[Optional[int], Tuple[float, ...], float, int]:
        return next(
            row for row in example["rows"] if row[0] == action
        )

    def predicted_action(
        weights: Sequence[float],
        example: Mapping[str, Any],
    ) -> Optional[int]:
        return max(
            example["rows"],
            key=lambda row: (
                row[2]
                + 0.10
                * sum(
                    weight * feature
                    for weight, feature in zip(weights, row[1])
                ),
                -row[3],
            ),
        )[0]

    history_feature_names = {
        "demand_density_after",
        "exact_complement_rate",
        "demand_density_preserved",
        "large_item_slot",
        "small_item_fragment",
    }
    history_feature_indices = {
        index
        for index, feature in enumerate(DEMAND_MEMORY_FEATURES)
        if feature in history_feature_names
    }

    def learnability_metrics(
        weights: Sequence[float],
        examples: Sequence[Mapping[str, Any]],
    ) -> Mapping[str, float]:
        if not examples:
            return {
                "accuracy": 0.0,
                "history_masked_accuracy": 0.0,
                "history_gain": 0.0,
            }
        masked = tuple(
            0.0 if index in history_feature_indices else float(weight)
            for index, weight in enumerate(weights)
        )
        accuracy = sum(
            predicted_action(weights, example)
            == example["desired_action"]
            for example in examples
        ) / float(len(examples))
        masked_accuracy = sum(
            predicted_action(masked, example)
            == example["desired_action"]
            for example in examples
        ) / float(len(examples))
        return {
            "accuracy": accuracy,
            "history_masked_accuracy": masked_accuracy,
            "history_gain": accuracy - masked_accuracy,
        }

    def fitted_weights(
        initial: Sequence[float],
        control_weight: float,
        epochs: int = 48,
    ) -> Tuple[float, ...]:
        weights = [float(value) for value in initial]
        examples = (
            *(
                (example, 1.0)
                for example in training_target_examples
            ),
            *(
                (example, control_weight)
                for example in control_examples
                if control_weight > 0
            ),
        )
        for _ in range(epochs):
            changed = False
            for example, example_weight in examples:
                desired = example["desired_action"]
                predicted = predicted_action(weights, example)
                if predicted == desired:
                    continue
                desired_row = row_for(example, desired)
                predicted_row = row_for(example, predicted)
                for index in range(feature_count):
                    update = (
                        4.0
                        * example_weight
                        * (
                            desired_row[1][index]
                            - predicted_row[1][index]
                        )
                    )
                    weights[index] = max(
                        -64.0,
                        min(64.0, weights[index] + update),
                    )
                changed = True
            if not changed:
                break
        return tuple(round(value, 6) for value in weights)

    base_weights = _demand_memory_weights(
        dict(contract.generator_patch.feature_weights)
    )
    weight_candidates = []
    for seed_name, initial in (
        ("zero", (0.0,) * feature_count),
        ("champion", base_weights),
    ):
        for control_weight in (0.0, 0.25, 1.0, 2.0):
            weight_candidates.append(
                (
                    "ranking_perceptron:%s:control=%g"
                    % (seed_name, control_weight),
                    fitted_weights(initial, control_weight),
                )
            )

    mean_differences = []
    for feature_index in range(feature_count):
        differences = []
        for example in training_target_examples:
            desired = row_for(
                example,
                example["desired_action"],
            )
            chosen = row_for(
                example,
                example["chosen_action"],
            )
            differences.append(
                desired[1][feature_index] - chosen[1][feature_index]
            )
        mean_differences.append(mean(differences))
    maximum_difference = max(
        1e-12,
        max(abs(value) for value in mean_differences),
    )
    normalized_difference = tuple(
        value / maximum_difference for value in mean_differences
    )
    for scale in (8.0, 32.0, 64.0):
        weight_candidates.append(
            (
                "mean_target_contrast:scale=%g" % scale,
                tuple(
                    round(scale * value, 6)
                    for value in normalized_difference
                ),
            )
        )

    candidates = []
    observed_weights = set()
    fitting_cluster_ids = tuple(
        model.cluster_id for model in training_models
    )
    fitting_trace_ids = tuple(
        str(example["trace_id"])
        for example in training_target_examples
    )
    validation_cluster_ids = tuple(
        model.cluster_id for model in validation_models
    )
    validation_trace_ids = tuple(
        str(example["trace_id"])
        for example in validation_target_examples
    )
    test_cluster_ids = tuple(
        model.cluster_id for model in test_models
    )
    for design_ref, weights in weight_candidates:
        if weights in observed_weights or not any(
            abs(value) > 1e-12 for value in weights
        ):
            continue
        observed_weights.add(weights)
        patch = replace(
            contract.generator_patch,
            causal_operator=(
                CausalEvolutionOperator.SUBSTITUTE_INTERVENTION
            ),
            feature_weights=tuple(
                zip(DEMAND_MEMORY_FEATURES, weights)
            ),
            compiler_ref=(
                "binpacking-mediator-directed-ranking-compiler-v1"
            ),
        )
        candidate_contract = replace(
            contract,
            observable_trigger=(
                contract.observable_trigger
                + "; directly measured action-level target engagement"
            ),
            action_change=(
                "apply a bounded pairwise-ranking intervention fitted to "
                "training-cluster alternatives, selected on disjoint "
                "validation clusters, and tested on untouched clusters"
            ),
            generator_patch=patch,
            contract_ref=(
                "binpacking-mediator-intervention-study-v2:"
                + design_ref
            ),
        )
        validation_learnability = learnability_metrics(
            weights,
            validation_target_examples,
        )
        validation_diagnostic = _diagnose_compiled_hypothesis(
            candidate_contract,
            causal_models,
            store,
            evaluation_target_cluster_ids=validation_cluster_ids,
            training_cluster_ids=fitting_cluster_ids,
            training_trace_ids=fitting_trace_ids,
            minimum_source_decisions=2,
            minimum_alternative_action_classes=2,
            online_learnability_accuracy=(
                validation_learnability["accuracy"]
            ),
            online_learnability_gain=(
                validation_learnability["history_gain"]
            ),
        )
        candidates.append(
            {
                "design_ref": design_ref,
                "contract": candidate_contract,
                "weights": weights,
                "diagnostic": validation_diagnostic,
                "validation_learnability": validation_learnability,
            }
        )

    ordered = sorted(
        candidates,
        key=lambda item: (
            item["diagnostic"].passed,
            item["diagnostic"].mediator_consistency,
            (
                item["diagnostic"].target_effect
                - item["diagnostic"].matched_control_effect
            ),
            item["diagnostic"].target_effect,
            item["diagnostic"].prior_art_distinct,
            item["contract"].contract_id,
        ),
        reverse=True,
    )
    best = ordered[0] if ordered else None
    validation_qualified = next(
        (
            item
            for item in ordered
            if item["diagnostic"].passed
        ),
        None,
    )
    qualified = None
    final_test_diagnostic = None
    final_test_learnability = None
    if validation_qualified is not None:
        final_test_learnability = learnability_metrics(
            validation_qualified["weights"],
            test_target_examples,
        )
        final_test_diagnostic = _diagnose_compiled_hypothesis(
            validation_qualified["contract"],
            causal_models,
            store,
            evaluation_target_cluster_ids=test_cluster_ids,
            training_cluster_ids=(
                *fitting_cluster_ids,
                *validation_cluster_ids,
            ),
            training_trace_ids=(
                *fitting_trace_ids,
                *validation_trace_ids,
            ),
            minimum_source_decisions=2,
            minimum_alternative_action_classes=2,
            online_learnability_accuracy=(
                final_test_learnability["accuracy"]
            ),
            online_learnability_gain=(
                final_test_learnability["history_gain"]
            ),
        )
        if final_test_diagnostic.passed:
            qualified = {
                **validation_qualified,
                "validation_diagnostic": (
                    validation_qualified["diagnostic"]
                ),
                "diagnostic": final_test_diagnostic,
                "test_learnability": final_test_learnability,
            }
    proxy_rankings = sorted(
        (
            {
                "feature": feature,
                "mean_alternative_minus_chosen": difference,
                "absolute_contrast": abs(difference),
            }
            for feature, difference in zip(
                DEMAND_MEMORY_FEATURES,
                mean_differences,
            )
        ),
        key=lambda item: (
            item["absolute_contrast"],
            item["feature"],
        ),
        reverse=True,
    )
    study_value = {
        "schema": 2,
        "study_ref": "binpacking-mediator-intervention-study-v2",
        "causal_coverage_retargeting": dict(retargeting),
        "causal_qualification_acquisition": dict(acquisition),
        "champion_hypothesis_id": champion.hypothesis_id,
        "literature_assessment_id": literature.assessment_id,
        "target_cluster_ids": list(contract.target_cluster_ids),
        "training_cluster_ids": list(fitting_cluster_ids),
        "validation_cluster_ids": list(validation_cluster_ids),
        "test_cluster_ids": list(test_cluster_ids),
        "target_trace_count": len(all_target_examples),
        "training_trace_count": len(training_target_examples),
        "validation_trace_count": len(validation_target_examples),
        "test_trace_count": len(test_target_examples),
        "control_trace_count": len(control_examples),
        "alternative_action_classes": sorted(action_classes),
        "training_alternative_action_classes": sorted(
            training_action_classes
        ),
        "target_alternative_new_bin_fraction": (
            sum(
                example["desired_action"] is None
                for example in all_target_examples
            )
            / float(len(all_target_examples))
        ),
        "proxy_rankings": proxy_rankings,
        "candidate_count": len(ordered),
        "candidates": [
            {
                "design_ref": item["design_ref"],
                "contract": item["contract"].as_dict(),
                "validation_diagnostic": (
                    item["diagnostic"].as_dict()
                ),
                "validation_learnability": dict(
                    item["validation_learnability"]
                ),
                "final_test_diagnostic": (
                    None
                    if final_test_diagnostic is None
                    or validation_qualified is None
                    or item["contract"].contract_id
                    != validation_qualified["contract"].contract_id
                    else final_test_diagnostic.as_dict()
                ),
                "final_test_learnability": (
                    None
                    if final_test_learnability is None
                    or validation_qualified is None
                    or item["contract"].contract_id
                    != validation_qualified["contract"].contract_id
                    else dict(final_test_learnability)
                ),
                # Backward-compatible summary key used by the autonomous
                # boundary reporter.  It is final-test evidence for the
                # selected design and validation evidence otherwise.
                "diagnostic": (
                    final_test_diagnostic.as_dict()
                    if (
                        final_test_diagnostic is not None
                        and validation_qualified is not None
                        and item["contract"].contract_id
                        == validation_qualified["contract"].contract_id
                    )
                    else item["diagnostic"].as_dict()
                ),
            }
            for item in ordered
        ],
        "best_contract_id": (
            None if best is None else best["contract"].contract_id
        ),
        "qualified_contract_id": (
            None
            if qualified is None
            else qualified["contract"].contract_id
        ),
        "outcome": (
            "crossfit_test_qualified_intervention"
            if qualified is not None
            else (
                "untouched_test_rejected_selected_intervention"
                if validation_qualified is not None
                else "no_validation_qualified_intervention"
            )
        ),
    }
    if qualified is None:
        return study_value, None
    recovered_contract = qualified["contract"]
    recovered_diagnostic = qualified["diagnostic"]
    champion_failure = classify_hypothesis_diagnostic(
        champion.hypothesis_id,
        champion.diagnostic_result,
        assessor_ref="binpacking-mediator-recovery-failure-classifier-v1",
    )
    literature_refs = tuple(
        dict.fromkeys(
            (
                *(
                    work.locator
                    for work in literature.closest_works
                ),
                literature.assessment_id,
            )
        )
    )
    recovered = TournamentHypothesis(
        target_node_id=champion.target_node_id,
        statement=(
            "A cross-fitted mediator-directed ranking intervention uses "
            + (
                "legal online history to predict"
                if recovered_contract.information_regime
                == InformationRegime.PREDICTIVE_PROXY
                else "current residual-option structure to select"
            )
            + " heterogeneous beneficial actions and improves untouched "
            "target clusters beyond matched causal-schema controls."
        ),
        mechanism=(
            "demand-memory target engagement recovered by "
            + qualified["design_ref"]
        ),
        origin=HypothesisOrigin.EVOLUTION,
        source_ref=literature.reviewer_ref,
        generator_ref=recovered_contract.generator_patch.generator_ref,
        predictions=(
            *champion.predictions,
            "the compiled action engages multiple alternative-action classes "
            "on untouched clusters and the information ablation follows the "
            "retargeted regime prediction",
        ),
        falsification_conditions=(
            *champion.falsification_conditions,
            "held-out action accuracy, history gain, or untouched-cluster "
            "outcome fails its preregistered threshold",
        ),
        assumptions=champion.assumptions,
        evidence_ids=tuple(
            dict.fromkeys(
                (
                    literature.assessment_id,
                    *recovered_diagnostic.evidence_ids,
                )
            )
        ),
        mechanism_signature=_contract_mechanism_signature(
            recovered_contract,
            causal_models,
        ),
        prediction_profile=_contract_prediction_profile(
            recovered_contract
        ),
        parent_ids=(champion.hypothesis_id,),
        inspiration_ids=champion.inspiration_ids,
        generation=champion.generation + 1,
        revision_eligible=True,
        executable_contract=recovered_contract,
        diagnostic_result=recovered_diagnostic,
        causal_operator=(
            CausalEvolutionOperator.SUBSTITUTE_INTERVENTION
        ),
        evolution_basis=HypothesisEvolutionBasis(
            failed_hypothesis_ids=(champion.hypothesis_id,),
            failure_kind=champion_failure.failure_kind,
            failed_prediction=champion_failure.failed_prediction,
            evidence_ids=champion_failure.evidence_ids,
            changed_assumption=(
                str(
                    retargeting.get(
                        "changed_assumption",
                        (
                            "the source-inspired demand-memory coefficients "
                            "directly engage the proposed mediator"
                        ),
                    )
                )
            ),
            literature_refs=literature_refs,
            new_distinguishing_prediction=(
                str(
                    retargeting.get(
                        "new_distinguishing_prediction",
                        (
                            "the mediator-directed action first exceeds "
                            "matched-control engagement and then improves "
                            "the target suffix outcome"
                        ),
                    )
                )
            ),
            evolution_ref=(
                "binpacking-mediator-directed-evolution-v2"
            ),
        ),
    )
    return study_value, recovered


def _cross_domain_hypothesis_seeds(
    inspirations: Sequence[CrossDomainInspiration],
    causal_models: CausalFailureModelSet,
    store: ArtifactStore,
) -> Tuple[TournamentHypothesis, ...]:
    seeds = []
    for inspiration in inspirations:
        contract = _compile_hypothesis_contract(
            inspiration,
            causal_models,
        )
        diagnostic = _diagnose_compiled_hypothesis(
            contract,
            causal_models,
            store,
        )
        source_structure = {
            "error-correcting codes": (
                "verified_failure_syndrome",
                "syndrome_gated_sparse_override",
                (
                    (
                        "held_out_matching_syndrome",
                        "override_activates_sparsely",
                    ),
                ),
            ),
            "neuroscience": (
                "multiscale_prediction_error",
                "prediction_error_gated_override",
                (
                    (
                        "prediction_error_increases",
                        "override_frequency_increases",
                    ),
                ),
            ),
            "statistical physics": (
                "cross_scale_relevance_statistic",
                "scale_stable_feature_selection",
                (
                    (
                        "sequence_length_changes",
                        "selected_feature_sign_is_stable",
                    ),
                ),
            ),
        }.get(inspiration.source_domain)
        if source_structure is None:
            signature = _contract_mechanism_signature(
                contract,
                causal_models,
            )
            prediction_profile = _contract_prediction_profile(contract)
        else:
            source, operator, boundary = source_structure
            signature = _contract_mechanism_signature(
                contract,
                causal_models,
                information_source=source,
                intervention_operator=operator,
                boundary_conditions=tuple(name for name, _ in boundary),
            )
            prediction_profile = _contract_prediction_profile(
                contract,
                boundary_predictions=boundary,
            )
        store.put(
            "binpacking_executable_hypothesis_diagnostic",
            {
                "contract": contract.as_dict(),
                "diagnostic": diagnostic.as_dict(),
                "inspiration_id": inspiration.inspiration_id,
            },
        )
        seeds.append(
            TournamentHypothesis(
            target_node_id=inspiration.target_node_id,
            statement=inspiration.transferred_hypothesis,
            mechanism=(
                inspiration.source_domain
                + ": "
                + inspiration.source_mechanism
            ),
            origin=HypothesisOrigin.CROSS_DOMAIN,
            source_ref=inspiration.source_reference,
            generator_ref=inspiration.generator_ref,
            predictions=inspiration.distinguishing_predictions,
            falsification_conditions=(
                inspiration.falsification_conditions
            ),
            assumptions=inspiration.broken_assumptions,
            evidence_ids=(),
            mechanism_signature=signature,
            prediction_profile=prediction_profile,
            inspiration_ids=(inspiration.inspiration_id,),
            revision_eligible=(
                inspiration.generator_ref
                in _REGISTERED_REVISION_GENERATOR_REFS
                and diagnostic.passed
            ),
            executable_contract=contract,
            diagnostic_result=diagnostic,
        )
        )
    return tuple(seeds)


def _failure_learning_mechanism_catalog(
    causal_models: CausalFailureModelSet,
) -> Tuple[MechanismCatalogEntry, ...]:
    """Literature about manipulating and measuring mechanisms, not analogies."""

    target_relations = tuple(
        dict.fromkeys(
            relation
            for model in causal_models.models
            for relation in model.causal_relations
        )
    )
    specs = (
        (
            "target-engagement-pharmacology",
            "experimental pharmacology",
            "drug candidates fail when exposure, binding, or functional "
            "activity is not demonstrated",
            "exposure-binding-functional-activity target engagement",
            "doi:10.1038/nrd3681",
            "measure intervention exposure and mediator engagement before "
            "interpreting the downstream outcome",
            ("target engagement", "mediator measurement", "null result"),
            "literature-only:target-engagement",
            (
                "binding and functional modulation are not directly observed "
                "from the clinical outcome"
            ),
            "advance a candidate without verifying target engagement",
            "measure exposure, binding, and functional activity in sequence",
            "a downstream null is interpretable only after target engagement",
            (
                "exposure precedes binding; binding precedes functional "
                "modulation; outcome interpretation is conditional on all "
                "three measurements"
            ),
            (
                "the target mediator has a measurable engagement marker",
                "the intervention reaches the target decision state",
            ),
            (
                "mediator engagement rises before outcome improvement",
                "without mediator engagement, outcome nulls do not separate "
                "the causal hypotheses",
            ),
        ),
        (
            "persistent-excitation-system-identification",
            "control engineering",
            "input-output dynamics cannot be identified without informative "
            "interventions",
            "persistent-excitation system identification",
            "book:Ljung-System-Identification-1987",
            "vary the intervention enough to identify its effect on state",
            ("system identification", "persistent excitation", "mediator"),
            "literature-only:system-identification",
            "the internal state transition is unavailable from passive output",
            "fit a causal response from an intervention that does not vary",
            "apply bounded, informative perturbations and measure state response",
            "identified input-state coupling distinguishes inactive actuators",
            (
                "intervention variation excites the relevant state; measured "
                "response identifies whether the actuator changes it"
            ),
            (
                "bounded perturbations preserve the system operating region",
                "observed proxy response corresponds to the proposed mediator",
            ),
            (
                "an informative perturbation changes the mediator distribution",
                "an unresponsive mediator rejects the actuator before outcome "
                "optimization",
            ),
        ),
        (
            "mutation-adequacy-software-testing",
            "software testing",
            "tests are inadequate when behavior-changing mutants survive",
            "mutation testing for intervention adequacy",
            "doi:10.1109/C-M.1978.218136",
            "require a compiled intervention to be killed by a mediator test",
            ("mutation testing", "compiler validation", "behavior change"),
            "literature-only:mutation-adequacy",
            "source-level changes do not guarantee executed behavior changes",
            "accept a compiled patch without observing a semantic difference",
            "inject a controlled mutation and test whether behavior changes",
            "surviving mutations reveal an inadequate operationalization test",
            (
                "compile a mutation; execute a mediator-sensitive test; "
                "reject the compiler path if the mutation survives"
            ),
            (
                "the mutation represents the intended causal intervention",
                "the mediator test is sensitive to that intervention",
            ),
            (
                "a valid compiler makes the controlled mutation observable",
                "a surviving mutation predicts zero mediator engagement",
            ),
        ),
        (
            "instrumental-variable-causal-identification",
            "econometrics",
            "treatment assignment may change exposure without guaranteeing "
            "treatment receipt",
            "instrumental-variable compliance identification",
            "doi:10.1080/01621459.1996.10476902",
            "separate assignment, mediator compliance, and outcome response",
            ("causal identification", "compliance", "mediator"),
            "literature-only:instrumental-variables",
            "actual mediator compliance is unavailable from assignment alone",
            "interpret assignment as if every unit received the intervention",
            "measure compliance and estimate outcomes for affected units",
            "the effect is identified only for units whose mediator responds",
            (
                "randomized encouragement changes compliance; compliance "
                "changes exposure; outcomes identify a local causal effect"
            ),
            (
                "the encouragement affects outcomes only through compliance",
                "responsive and nonresponsive cases are distinguishable",
            ),
            (
                "the intervention effect concentrates in mediator responders",
                "nonresponders show no effect despite assignment",
            ),
        ),
        (
            "information-gain-experimental-design",
            "Bayesian experimental design",
            "experiments differ in how much they separate parameter beliefs",
            "expected-information experiment selection",
            "doi:10.1214/aoms/1177728069",
            "choose the feasible intervention with maximum expected separation",
            ("experiment design", "information gain", "discrimination"),
            "literature-only:information-gain",
            "the most discriminating outcome is unavailable before experiment",
            "spend budget on an experiment with identical hypothesis predictions",
            "select the intervention with greatest expected belief change",
            "observations separate hypotheses with minimum experimental waste",
            (
                "predict outcomes under each hypothesis; select the experiment "
                "with the largest expected information gain"
            ),
            (
                "hypothesis predictions are calibrated enough for comparison",
                "the selected experiment is feasible under the budget",
            ),
            (
                "selected experiments expose a prediction disagreement",
                "experiments with identical predictions receive no allocation",
            ),
        ),
    )
    return tuple(
        MechanismCatalogEntry(
            catalog_key=key,
            source_domain=domain,
            source_problem=problem,
            source_mechanism=mechanism,
            source_reference=reference,
            invariant=invariant,
            capability_tags=capabilities,
            generator_ref=generator_ref,
            surprise_prior=3,
            grounding_prior=3,
            causal_model=SourceCausalMechanism(
                unavailable_information=unavailable,
                irreversible_decision=irreversible,
                alternative_action=alternative,
                changed_result=changed,
                causal_chain=chain,
                causal_relations=target_relations,
                broken_assumptions=assumptions,
                distinguishing_predictions=predictions,
            ),
        )
        for (
            key,
            domain,
            problem,
            mechanism,
            reference,
            invariant,
            capabilities,
            generator_ref,
            unavailable,
            irreversible,
            alternative,
            changed,
            chain,
            assumptions,
            predictions,
        ) in specs
    )


def _failure_directed_literature_survey(
    node: GoalNodeSpec,
    causal_models: CausalFailureModelSet,
    hypotheses: Sequence[TournamentHypothesis],
    store: ArtifactStore,
) -> Tuple[
    MechanismDiscoveryTrace,
    Tuple[HypothesisFailureAssessment, ...],
]:
    """Retrieve measurements and interventions after classifying results."""

    assessments = tuple(
        classify_hypothesis_diagnostic(
            hypothesis.hypothesis_id,
            hypothesis.diagnostic_result,
            assessor_ref="binpacking-typed-failure-classifier-v1",
        )
        for hypothesis in hypotheses
    )
    failure_signatures = tuple(
        dict.fromkeys(
            assessment.failure_kind.value
            for assessment in assessments
        )
    )
    literature_questions = tuple(
        dict.fromkeys(
            question
            for assessment in assessments
            for question in assessment.literature_questions
        )
    )
    query_terms = tuple(
        dict.fromkeys(
            token
            for phrase in (
                *failure_signatures,
                *literature_questions,
            )
            for token in phrase.replace("_", " ").split()
        )
    )
    query = MechanismDiscoveryQuery(
        target_node_id=node.node_id,
        target_domain="online one-dimensional bin packing",
        causal_failure_models=causal_models,
        causal_discrimination=assess_causal_discrimination(
            causal_models,
            minimum_supported_schemas=2,
            minimum_replay_support_rate=0.25,
            maximum_schema_fraction=0.85,
            minimum_proxy_reliability=0.55,
            assessor_ref=(
                "binpacking-post-experiment-discrimination-gate-v1"
            ),
        ),
        failure_signatures=failure_signatures,
        desired_capabilities=literature_questions,
        query_terms=query_terms,
        query_generator_ref=(
            "binpacking-failure-directed-literature-query-v1"
        ),
    )
    entries = _failure_learning_mechanism_catalog(causal_models)
    trace = CatalogMechanismScout(
        entries,
        scout_ref="binpacking-post-experiment-literature-scout-v1",
    ).discover(query, limit=min(6, len(entries)))
    store.put(
        "binpacking_failure_directed_literature_survey",
        {
            "failure_assessments": [
                assessment.as_dict() for assessment in assessments
            ],
            "discovery_trace": trace.as_dict(),
            "purpose": (
                "retrieve interventions, failed operationalizations, "
                "boundary conditions, and mediator measurements after "
                "observing typed diagnostic failures"
            ),
        },
    )
    return trace, assessments


def _hypothesis_failure_literature_assessment(
    node: GoalNodeSpec,
    causal_models: CausalFailureModelSet,
    failure_assessments: Sequence[HypothesisFailureAssessment],
    base: PriorArtAssessment,
) -> PriorArtAssessment:
    failure_kinds = tuple(
        dict.fromkeys(
            assessment.failure_kind.value
            for assessment in failure_assessments
        )
    )
    questions = tuple(
        dict.fromkeys(
            question
            for assessment in failure_assessments
            for question in assessment.literature_questions
        )
    )
    failure_query_map = {
        "Which boundary conditions reverse or erase this mechanism?": (
            "causal mechanism transport boundary conditions"
        ),
        "Which source assumptions fail during target-domain transport?": (
            "causal mechanism transportability source target assumptions"
        ),
        "Which interventions directly manipulate this mediator?": (
            "causal mediator direct intervention manipulation"
        ),
        "Which measurements detect mediator engagement before outcomes?": (
            "causal mediator engagement process measurement"
        ),
        "Which failed implementations left the mediator unchanged?": (
            "intervention implementation failure mediator engagement"
        ),
        "How has this mediator been operationalized in executable systems?": (
            "causal mediator operationalization adaptive systems"
        ),
        "Which proxy-to-action interfaces preserve the causal semantics?": (
            "causal proxy action interface mechanism fidelity"
        ),
    }
    retrieval_queries = tuple(
        dict.fromkeys(
            failure_query_map.get(
                question,
                "causal mechanism diagnostic boundary conditions",
            )
            for question in questions[:6]
        )
    )
    queries = tuple(
        LiteratureQuery(
            query=query,
            facet=SearchFacet.MECHANISM,
            provider=provider,
        )
        for query in retrieval_queries
        for provider in ("Google Scholar", "Semantic Scholar")
    )
    mediators = tuple(
        dict.fromkeys(
            model.mediator for model in causal_models.models
        )
    )
    return PriorArtAssessment(
        signature=ClaimSignature(
            subject_id=node.node_id,
            statement=node.question,
            problem=base.signature.problem,
            phenomenon=(
                "compiled cross-domain hypotheses failed as %s"
                % ", ".join(failure_kinds)
            ),
            intervention=(
                "retrieve measurements, direct interventions, null "
                "implementations, broken transport assumptions, and "
                "boundary conditions before evolving hypotheses"
            ),
            mechanism=(
                "; ".join((*mediators, *questions))
                or base.signature.mechanism
            ),
            evaluation=(
                "updated compiled causal diagnostic with target/control, "
                "mediator, history-mask, ablation, and suffix-permutation "
                "tests"
            ),
        ),
        trigger=LiteratureTrigger.PERIODIC_DELTA,
        queries=(*base.queries, *queries),
        closest_works=base.closest_works,
        classification=ClaimClassification.NOVEL_CANDIDATE,
        rationale=(
            "Typed diagnostic failures determine the new literature "
            "questions. The resulting evidence may change a proxy, "
            "intervention, assumption, boundary, or falsifying prediction; "
            "it cannot merely reword the failed hypothesis."
        ),
        novel_delta=(
            "follow-up search is conditioned on typed diagnostic failures",
            "evolution cites newly retrieved intervention evidence",
            "unchanged causal signatures remain merged",
        ),
        citation_snowball_complete=base.citation_snowball_complete,
        searched_at=base.searched_at,
        reviewer_ref="failure-directed-web-literature-planner-v1",
        executable_incumbent_id=base.executable_incumbent_id,
    )


def _evolve_executable_contract(
    parent: ExecutableHypothesisContract,
    operator: CausalEvolutionOperator,
    generation: int,
    causal_models: CausalFailureModelSet,
    store: ArtifactStore,
) -> Tuple[ExecutableHypothesisContract, HypothesisDiagnosticResult]:
    weights = list(parent.generator_patch.feature_weights)
    feature, weight = weights[0]
    if (
        parent.generator_patch.generator_ref
        == "binpacking-contextual-linear-generator-v1"
    ):
        feature_space = tuple(CONTEXTUAL_FEATURES)
    elif (
        parent.generator_patch.generator_ref
        == "binpacking-demand-memory-generator-v1"
    ):
        feature_space = tuple(DEMAND_MEMORY_FEATURES)
    elif (
        parent.generator_patch.generator_ref
        == "binpacking-regime-router-generator-v1"
    ):
        feature_space = tuple(
            "%s:%s" % (policy, router_feature)
            for policy in REGIME_ROUTER_POLICIES
            for router_feature in REGIME_ROUTER_FEATURES
        )
    else:
        feature_space = tuple(name for name, _ in weights)
    if operator == CausalEvolutionOperator.SUBSTITUTE_PROXY:
        occupied = {name for name, _ in weights[1:]}
        start = feature_space.index(feature) if feature in feature_space else -1
        replacements = tuple(
            feature_space[(start + offset) % len(feature_space)]
            for offset in range(1, len(feature_space) + 1)
            if feature_space[(start + offset) % len(feature_space)]
            not in occupied
        )
        replacement = replacements[
            (generation - 1) % len(replacements)
        ]
        weights[0] = (replacement, weight)
        trigger = (
            parent.observable_trigger
            + "; replace proxy %s with observable %s"
            % (feature, replacement)
        )
        action = parent.action_change
        clusters = parent.target_cluster_ids
    elif operator == CausalEvolutionOperator.SPECIALIZE_FAILURE_CLUSTER:
        retained = 1 + (
            int(content_digest(parent.target_cluster_ids[0])[:4], 16)
            % len(weights)
        )
        weights = [
            (
                name,
                coefficient * (1.0 + 0.10 * generation),
            )
            for name, coefficient in weights[:retained]
        ]
        trigger = parent.observable_trigger
        action = parent.action_change
        clusters = (
            parent.target_cluster_ids[
                (generation - 1) % len(parent.target_cluster_ids)
            ],
        )
    else:
        weights = [
            (name, -coefficient)
            for name, coefficient in weights
        ]
        trigger = parent.observable_trigger
        action = (
            parent.action_change
            + "; invert the leading intervention coefficient"
        )
        clusters = parent.target_cluster_ids
    patch = replace(
        parent.generator_patch,
        causal_operator=operator,
        feature_weights=tuple(weights),
        compiler_ref="binpacking-causal-module-synthesis-v2",
    )
    contract = replace(
        parent,
        target_cluster_ids=clusters,
        observable_trigger=trigger,
        action_change=action,
        generator_patch=patch,
        contract_ref=(
            "binpacking-causal-module-synthesis-v2:generation-%d"
            % generation
        ),
    )
    diagnostic = _diagnose_compiled_hypothesis(
        contract,
        causal_models,
        store,
    )
    store.put(
        "binpacking_evolved_hypothesis_diagnostic",
        {
            "operator": operator.value,
            "generation": generation,
            "contract": contract.as_dict(),
            "diagnostic": diagnostic.as_dict(),
        },
    )
    return contract, diagnostic


def _combine_island_fragment_contract(
    parent: ExecutableHypothesisContract,
    island: TournamentHypothesis,
    generation: int,
    causal_models: CausalFailureModelSet,
    store: ArtifactStore,
) -> Tuple[ExecutableHypothesisContract, HypothesisDiagnosticResult]:
    """Compile an island mechanism into the executable feature topology."""
    patch = parent.generator_patch
    if patch.generator_ref == "binpacking-contextual-linear-generator-v1":
        feature_space = tuple(CONTEXTUAL_FEATURES)
    elif patch.generator_ref == "binpacking-demand-memory-generator-v1":
        feature_space = tuple(DEMAND_MEMORY_FEATURES)
    elif patch.generator_ref == "binpacking-regime-router-generator-v1":
        feature_space = tuple(
            "%s:%s" % (policy, feature)
            for policy in REGIME_ROUTER_POLICIES
            for feature in REGIME_ROUTER_FEATURES
        )
    else:
        return _evolve_executable_contract(
            parent,
            CausalEvolutionOperator.SUBSTITUTE_PROXY,
            generation,
            causal_models,
            store,
        )
    fragment_text = " ".join(
        (island.statement, island.mechanism)
    ).casefold()
    existing = dict(patch.feature_weights)
    lexical_matches = tuple(
        feature
        for feature in feature_space
        if feature.split(":")[-1].replace("_", " ") in fragment_text
    )
    if lexical_matches:
        selected_features = lexical_matches[:2]
    else:
        start = int(island.hypothesis_id[:8], 16) % len(feature_space)
        selected_features = (
            feature_space[start],
            feature_space[(start + generation) % len(feature_space)],
        )
    for index, feature in enumerate(selected_features):
        direction = (
            1.0
            if int(
                content_digest(
                    {
                        "island_id": island.hypothesis_id,
                        "feature": feature,
                    }
                )[:2],
                16,
            )
            % 2
            == 0
            else -1.0
        )
        existing[feature] = round(
            existing.get(feature, 0.0)
            + direction * (0.25 + 0.10 * generation) / (index + 1),
            4,
        )
    combined_patch = replace(
        patch,
        causal_operator=(
            CausalEvolutionOperator.COMPLEMENTARY_CAUSAL_COMBINATION
        ),
        feature_weights=tuple(sorted(existing.items())),
        compiler_ref="binpacking-island-fragment-code-synthesis-v2",
    )
    contract = replace(
        parent,
        observable_trigger=(
            parent.observable_trigger
            + "; compiled island fragment features "
            + ", ".join(selected_features)
        ),
        action_change=(
            parent.action_change
            + "; confidence-gate the island-derived causal module"
        ),
        generator_patch=combined_patch,
        contract_ref=(
            "binpacking-island-fragment-code-synthesis-v2:generation-%d"
            % generation
        ),
    )
    diagnostic = _diagnose_compiled_hypothesis(
        contract,
        causal_models,
        store,
    )
    store.put(
        "binpacking_island_fragment_hypothesis_diagnostic",
        {
            "generation": generation,
            "island_hypothesis_id": island.hypothesis_id,
            "selected_features": list(selected_features),
            "contract": contract.as_dict(),
            "diagnostic": diagnostic.as_dict(),
        },
    )
    return contract, diagnostic


def _binpacking_hypothesis_tournament(
    node: GoalNodeSpec,
    island_seeds: Sequence[TournamentHypothesis],
    inspirations: Sequence[CrossDomainInspiration],
    evaluations: Sequence[TransferEvaluation],
    causal_models: CausalFailureModelSet,
    store: ArtifactStore,
    literature_assessment: Optional[
        PriorArtAssessment
    ] = None,
    literature_reviewer: Optional[
        LiveWebPriorArtReviewer
    ] = None,
) -> Optional[HypothesisTournament]:
    if {
        seed.island_family for seed in island_seeds
    } != {"ancestry", "de_novo", "hybrid"}:
        return None
    transfer_evaluations = {
        evaluation.inspiration_id: evaluation
        for evaluation in evaluations
    }
    cross_domain_seeds = _cross_domain_hypothesis_seeds(
        inspirations,
        causal_models,
        store,
    )
    followup_trace, initial_failure_assessments = (
        _failure_directed_literature_survey(
            node,
            causal_models,
            cross_domain_seeds,
            store,
        )
    )
    followup_web_literature = None
    if literature_assessment is not None:
        planned_followup = (
            _hypothesis_failure_literature_assessment(
                node,
                causal_models,
                initial_failure_assessments,
                literature_assessment,
            )
        )
        followup_web_literature = (
            planned_followup
            if literature_reviewer is None
            else literature_reviewer.review(planned_followup)
        )
        if not followup_web_literature.closure_passed:
            raise ValueError(
                "failure-directed literature survey did not close"
            )
        store.put(
            "hypothesis_failure_directed_literature_assessment",
            followup_web_literature.as_dict(),
        )
    selected_followup = tuple(
        candidate
        for candidate in followup_trace.candidates
        if candidate.discovery_id
        in followup_trace.selected_discovery_ids
    )
    literature_refs = tuple(
        dict.fromkeys(
            (
                *(
                    candidate.source_reference
                    for candidate in selected_followup
                ),
                *(
                    ()
                    if followup_web_literature is None
                    else (
                        work.locator
                        for work
                        in followup_web_literature.closest_works
                    )
                ),
            )
        )
    )
    initial_assessment_by_id = {
        assessment.hypothesis_id: assessment
        for assessment in initial_failure_assessments
    }

    def experimental_compare(
        first: TournamentHypothesis,
        second: TournamentHypothesis,
    ) -> Optional[Tuple[int, str]]:
        if (
            first.executable_contract is None
            or second.executable_contract is None
        ):
            return None
        first_program = _compiled_program_for_patch(
            first.executable_contract.generator_patch
        )
        second_program = _compiled_program_for_patch(
            second.executable_contract.generator_patch
        )
        if first_program is None or second_program is None:
            return None
        disagreements = []
        first_support = 0
        second_support = 0
        for model in causal_models.models:
            if not model.empirically_supported:
                continue
            for trace_id in model.decision_trace_ids:
                payload = _decision_trace_payload(store, trace_id)
                instance = _instance_from_trace_payload(payload)
                decision_index = int(payload["decision_index"])
                loads = tuple(
                    int(value) for value in payload["loads_before"]
                )
                history = instance.items[:decision_index]

                def normalized_action(
                    program: OnlineHeuristic,
                ) -> int:
                    action = program.choose_bin(
                        int(payload["item"]),
                        loads,
                        instance.capacity,
                        decision_index,
                        history,
                    )
                    return -1 if action is None else int(action)

                first_action = normalized_action(first_program)
                second_action = normalized_action(second_program)
                if first_action == second_action:
                    continue
                alternative = int(payload["alternative_action"])
                first_local = first_action == alternative
                second_local = second_action == alternative
                first_bins = pack(instance, first_program).bin_count
                second_bins = pack(instance, second_program).bin_count
                if first_local and not second_local:
                    first_support += 1
                elif second_local and not first_local:
                    second_support += 1
                elif first_bins < second_bins:
                    first_support += 1
                elif second_bins < first_bins:
                    second_support += 1
                disagreements.append(
                    {
                        "trace_id": trace_id,
                        "cluster_id": model.cluster_id,
                        "first_action": first_action,
                        "second_action": second_action,
                        "counterfactual_alternative": alternative,
                        "first_matches_alternative": first_local,
                        "second_matches_alternative": second_local,
                        "first_full_policy_bins": first_bins,
                        "second_full_policy_bins": second_bins,
                    }
                )
        if not disagreements:
            return None
        evidence_digest = store.put(
            "binpacking_hypothesis_prediction_disagreement_experiment",
            {
                "first_hypothesis_id": first.hypothesis_id,
                "second_hypothesis_id": second.hypothesis_id,
                "disagreement_count": len(disagreements),
                "first_support": first_support,
                "second_support": second_support,
                "cases": disagreements,
                "selection_rule": (
                    "local causal-alternative agreement, with complete-policy "
                    "bin count only as a tie breaker"
                ),
            },
        )
        outcome = (
            1
            if first_support > second_support
            else -1
            if second_support > first_support
            else 0
        )
        return outcome, (
            "prediction-disagreement experiment %s tested %d independent "
            "causal decisions (%d support first, %d support second)"
            % (
                evidence_digest,
                len(disagreements),
                first_support,
                second_support,
            )
        )

    def failure_assessment(
        hypothesis: TournamentHypothesis,
    ) -> HypothesisFailureAssessment:
        return initial_assessment_by_id.get(
            hypothesis.hypothesis_id,
            classify_hypothesis_diagnostic(
                hypothesis.hypothesis_id,
                hypothesis.diagnostic_result,
                assessor_ref="binpacking-typed-failure-classifier-v1",
            ),
        )

    def review(hypothesis: TournamentHypothesis) -> HypothesisReview:
        if hypothesis.origin == HypothesisOrigin.ISLAND:
            return HypothesisReview(
                hypothesis_id=hypothesis.hypothesis_id,
                goal_alignment=4,
                plausibility=2,
                novelty=1,
                testability=4,
                feasibility=4,
                evidence_grounding=3,
                diversity_value=1,
                assumption_risk=2,
                critique=(
                    "the parent representation already plateaued",
                    "development evidence is not replication evidence",
                ),
                improvement_directions=(
                    "transfer only the causal fragment into a new family",
                ),
                reviewer_ref="binpacking-structured-reflection-v1",
                evidence_update=0,
            )
        related = tuple(
            transfer_evaluations[inspiration_id]
            for inspiration_id in hypothesis.inspiration_ids
            if inspiration_id in transfer_evaluations
        )
        structural_fit = max(
            (item.structural_fit for item in related),
            default=2,
        )
        surprise = max(
            (item.surprise for item in related),
            default=2,
        )
        grounding = max(
            (item.evidence_grounding for item in related),
            default=2,
        )
        testability = max(
            (item.testability for item in related),
            default=2,
        )
        evolved = hypothesis.origin == HypothesisOrigin.EVOLUTION
        evidence_update = (
            0
            if hypothesis.diagnostic_result is None
            else hypothesis.diagnostic_result.evidence_update
        )
        diagnostic_critique = (
            ()
            if hypothesis.diagnostic_result is not None
            and hypothesis.diagnostic_result.passed
            else (
                "compiled diagnostic failed: "
                + ", ".join(
                    ()
                    if hypothesis.diagnostic_result is None
                    else hypothesis.diagnostic_result.failure_reasons
                ),
            )
        )
        typed_failure = failure_assessment(hypothesis)
        return HypothesisReview(
            hypothesis_id=hypothesis.hypothesis_id,
            goal_alignment=min(4, structural_fit + 1),
            plausibility=min(4, grounding + (1 if evolved else 0)),
            novelty=min(4, surprise + (1 if evolved else 0)),
            testability=min(4, testability + 1),
            feasibility=4 if hypothesis.revision_eligible else 1,
            evidence_grounding=min(
                4,
                grounding + (1 if hypothesis.evidence_ids else 0),
            ),
            diversity_value=min(4, surprise + 1),
            assumption_risk=2 if evolved else 1,
            critique=(
                "cross-domain fit remains a hypothesis until tested",
                "Elo preference cannot authorize a scientific claim",
                "typed diagnostic interpretation: "
                + typed_failure.failure_kind.value,
                *diagnostic_critique,
            ),
            improvement_directions=(
                "make the transferred invariant executable and ablatable",
            ),
            reviewer_ref="binpacking-structured-reflection-v1",
            evidence_update=evidence_update,
        )

    def evolve(
        generation: int,
        ranked: Tuple[TournamentHypothesis, ...],
        reviews: Mapping[str, HypothesisReview],
    ) -> Tuple[TournamentHypothesis, ...]:
        del reviews
        transferable = tuple(
            hypothesis
            for hypothesis in ranked
            if hypothesis.inspiration_ids
            and failure_assessment(hypothesis).failure_kind
            not in (
                HypothesisFailureKind.NOT_EVALUATED,
                HypothesisFailureKind.PASSED,
                HypothesisFailureKind.COMPILATION,
            )
        )
        if not transferable:
            return ()
        primary = transferable[0]
        island = next(
            hypothesis
            for hypothesis in ranked
            if hypothesis.origin == HypothesisOrigin.ISLAND
        )
        alternative = next(
            (
                hypothesis
                for hypothesis in transferable[1:]
                if hypothesis.generator_ref != primary.generator_ref
            ),
            primary,
        )

        def merged(values: Iterable[str]) -> Tuple[str, ...]:
            return tuple(dict.fromkeys(values))

        primary_contract = primary.executable_contract
        alternative_contract = alternative.executable_contract
        if primary_contract is None or alternative_contract is None:
            return ()
        primary_failure = failure_assessment(primary)
        alternative_failure = failure_assessment(alternative)
        combined_contract, combined_diagnostic = (
            _combine_island_fragment_contract(
                primary_contract,
                island,
                generation,
                causal_models,
                store,
            )
        )
        simplified_contract, simplified_diagnostic = (
            _evolve_executable_contract(
                primary_contract,
                CausalEvolutionOperator.SPECIALIZE_FAILURE_CLUSTER,
                generation,
                causal_models,
                store,
            )
        )
        divergent_contract, divergent_diagnostic = (
            _evolve_executable_contract(
                alternative_contract,
                CausalEvolutionOperator.SUBSTITUTE_INTERVENTION,
                generation,
                causal_models,
                store,
            )
        )
        combined = TournamentHypothesis(
            target_node_id=node.node_id,
            statement=(
                "Generation %d: combine the transfer '%s' with the strongest "
                "%s-island causal fragment while retaining explicit ablation."
                % (
                    generation,
                    primary.statement,
                    island.island_family,
                )
            ),
            mechanism=(
                primary.mechanism
                + " + island fragment: "
                + island.mechanism
            ),
            origin=HypothesisOrigin.EVOLUTION,
            source_ref="hypothesis-evolution:combine",
            generator_ref=primary.generator_ref,
            predictions=(
                "generation %d substituted proxy improves at least 0.25 "
                "bins per targeted diagnostic instance" % generation,
                "generation %d proxy masking removes at least half of the "
                "effect" % generation,
            ),
            falsification_conditions=(
                "the substituted proxy fails to change target actions",
                "its executable digest or prediction duplicates a parent",
            ),
            assumptions=merged(
                (*primary.assumptions, *island.assumptions)
            ),
            evidence_ids=merged(
                (
                    *primary.evidence_ids,
                    *island.evidence_ids,
                    *combined_diagnostic.evidence_ids,
                )
            ),
            mechanism_signature=_contract_mechanism_signature(
                combined_contract,
                causal_models,
                intervention_operator=(
                    "complementary_island_fragment_intervention"
                ),
                boundary_conditions=(
                    "island_fragment_present",
                ),
            ),
            prediction_profile=_contract_prediction_profile(
                combined_contract,
                boundary_predictions=(
                    (
                        "island_fragment_ablation",
                        "combined_effect_is_reduced",
                    ),
                ),
            ),
            parent_ids=(
                primary.hypothesis_id,
                island.hypothesis_id,
            ),
            inspiration_ids=primary.inspiration_ids,
            generation=generation,
            revision_eligible=combined_diagnostic.passed,
            executable_contract=combined_contract,
            diagnostic_result=combined_diagnostic,
            causal_operator=(
                CausalEvolutionOperator.COMPLEMENTARY_CAUSAL_COMBINATION
            ),
            evolution_basis=HypothesisEvolutionBasis(
                failed_hypothesis_ids=(primary.hypothesis_id,),
                failure_kind=primary_failure.failure_kind,
                failed_prediction=primary_failure.failed_prediction,
                evidence_ids=primary_failure.evidence_ids,
                changed_assumption=(
                    "the transferred intervention alone is sufficient to "
                    "engage the target mediator"
                ),
                literature_refs=literature_refs,
                new_distinguishing_prediction=(
                    "ablating the island fragment selectively reduces the "
                    "combined effect"
                ),
                evolution_ref=(
                    "binpacking-evidence-linked-evolution-v1"
                ),
            ),
        )
        simplified = TournamentHypothesis(
            target_node_id=node.node_id,
            statement=(
                "Generation %d: isolate the smallest ablatable form of '%s'."
                % (generation, primary.statement)
            ),
            mechanism=(
                "minimal executable invariant: " + primary.mechanism
            ),
            origin=HypothesisOrigin.EVOLUTION,
            source_ref="hypothesis-evolution:simplify",
            generator_ref=primary.generator_ref,
            predictions=(
                "generation %d specialized intervention improves its named "
                "cluster" % generation,
                "generation %d effect exceeds the matched non-target control"
                % generation,
            ),
            falsification_conditions=(
                "the named cluster shows no positive compiled effect",
                "the effect is no larger than matched controls",
            ),
            assumptions=primary.assumptions,
            evidence_ids=merged(
                (
                    *primary.evidence_ids,
                    *simplified_diagnostic.evidence_ids,
                )
            ),
            mechanism_signature=_contract_mechanism_signature(
                simplified_contract,
                causal_models,
                intervention_operator=(
                    "failure_cluster_specialized_intervention"
                ),
                boundary_conditions=(
                    "selected_failure_cluster_only",
                ),
            ),
            prediction_profile=_contract_prediction_profile(
                simplified_contract,
                boundary_predictions=(
                    (
                        "outside_selected_failure_cluster",
                        "effect_is_absent_or_smaller",
                    ),
                ),
            ),
            parent_ids=(primary.hypothesis_id,),
            inspiration_ids=primary.inspiration_ids,
            generation=generation,
            revision_eligible=simplified_diagnostic.passed,
            executable_contract=simplified_contract,
            diagnostic_result=simplified_diagnostic,
            causal_operator=(
                CausalEvolutionOperator.SPECIALIZE_FAILURE_CLUSTER
            ),
            evolution_basis=HypothesisEvolutionBasis(
                failed_hypothesis_ids=(primary.hypothesis_id,),
                failure_kind=primary_failure.failure_kind,
                failed_prediction=primary_failure.failed_prediction,
                evidence_ids=primary_failure.evidence_ids,
                changed_assumption=(
                    "one intervention transports uniformly across all "
                    "failure clusters"
                ),
                literature_refs=literature_refs,
                new_distinguishing_prediction=(
                    "the effect is confined to the selected causal failure "
                    "cluster"
                ),
                evolution_ref=(
                    "binpacking-evidence-linked-evolution-v1"
                ),
            ),
        )
        divergent = TournamentHypothesis(
            target_node_id=node.node_id,
            statement=(
                "Generation %d out-of-box alternative: use '%s' to challenge "
                "the current tournament leader rather than merely refining it."
                % (generation, alternative.statement)
            ),
            mechanism=(
                "divergent transfer: " + alternative.mechanism
            ),
            origin=HypothesisOrigin.EVOLUTION,
            source_ref="hypothesis-evolution:diverge",
            generator_ref=alternative.generator_ref,
            predictions=(
                "generation %d substituted action changes the diagnosed "
                "mediator" % generation,
                "generation %d changed mediator lowers target suffix bin "
                "count" % generation,
            ),
            falsification_conditions=(
                "the substituted action never engages the mediator",
                "the target effect is non-positive",
            ),
            assumptions=alternative.assumptions,
            evidence_ids=merged(
                (
                    *alternative.evidence_ids,
                    *divergent_diagnostic.evidence_ids,
                )
            ),
            mechanism_signature=_contract_mechanism_signature(
                divergent_contract,
                causal_models,
                intervention_operator=(
                    "direction_substituted_mediator_intervention"
                ),
                boundary_conditions=(
                    "mediator_engagement_precedes_outcome_test",
                ),
            ),
            prediction_profile=_contract_prediction_profile(
                divergent_contract,
                boundary_predictions=(
                    (
                        "mediator_not_engaged",
                        "outcome_is_not_interpreted_as_causal_refutation",
                    ),
                ),
            ),
            parent_ids=(
                primary.hypothesis_id,
                alternative.hypothesis_id,
            )
            if primary.hypothesis_id != alternative.hypothesis_id
            else (primary.hypothesis_id,),
            inspiration_ids=alternative.inspiration_ids,
            generation=generation,
            revision_eligible=divergent_diagnostic.passed,
            executable_contract=divergent_contract,
            diagnostic_result=divergent_diagnostic,
            causal_operator=(
                CausalEvolutionOperator.SUBSTITUTE_INTERVENTION
            ),
            evolution_basis=HypothesisEvolutionBasis(
                failed_hypothesis_ids=(
                    alternative.hypothesis_id,
                ),
                failure_kind=alternative_failure.failure_kind,
                failed_prediction=alternative_failure.failed_prediction,
                evidence_ids=alternative_failure.evidence_ids,
                changed_assumption=(
                    "the source-inspired coefficient direction manipulates "
                    "the target mediator"
                ),
                literature_refs=literature_refs,
                new_distinguishing_prediction=(
                    "the substituted action first engages the mediator, then "
                    "improves the target outcome"
                ),
                evolution_ref=(
                    "binpacking-evidence-linked-evolution-v1"
                ),
            ),
        )
        return combined, simplified, divergent

    return run_hypothesis_tournament(
        (
            *tuple(island_seeds),
            *cross_domain_seeds,
        ),
        review=review,
        evolve=evolve,
        generations=2,
        survivor_count=5,
        tournament_ref=(
            "binpacking-evidence-updated-causal-elo-tournament-v3"
        ),
        literature_query_ids=(followup_trace.query.query_id,),
        literature_source_refs=literature_refs,
        experimental_compare=experimental_compare,
    )


def _cross_domain_literature_assessment(
    node: GoalNodeSpec,
    causal_models: CausalFailureModelSet,
) -> PriorArtAssessment:
    base = literature_assessment(
        node,
        trigger=LiteratureTrigger.NEW_INTERVENTION,
    )
    causal_terms = tuple(
        dict.fromkeys(
            (
                model.mediator,
                *(
                    relation.value
                    for relation in model.causal_relations
                ),
                *model.observable_proxies,
            )
            for model in causal_models.models
        )
    )
    flattened = tuple(
        dict.fromkeys(
            term
            for group in causal_terms
            for term in group
        )
    )
    observed_relations = {
        relation
        for model in causal_models.models
        for relation in model.causal_relations
    }
    irreversible_option_chain = {
        CausalRelationKind.INFORMATION_REVEALED_AFTER_COMMITMENT,
        CausalRelationKind.COMMITMENT_DESTROYS_OPTION,
        CausalRelationKind.ALTERNATIVE_PRESERVES_OPTION,
        CausalRelationKind.PRESERVED_OPTION_CHANGES_OUTCOME,
    }
    if irreversible_option_chain.issubset(observed_relations):
        compact_causal_query = (
            "irreversible decision making under uncertainty"
        )
    elif (
        CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION
        in observed_relations
    ):
        compact_causal_query = "adaptive control delayed information"
    elif CausalRelationKind.STATE_SELECTS_POLICY in observed_relations:
        compact_causal_query = "state dependent policy selection"
    else:
        compact_causal_query = (
            "irreversible decision delayed information causal mechanism"
        )
    cross_domain_queries = tuple(
        LiteratureQuery(
            query=query,
            facet=SearchFacet.MECHANISM,
            provider=provider,
        )
        for query in (
            (
                "irreversible decisions hidden future information preserve "
                "option causal mechanism"
            ),
            (
                "resource reservation uncertain future demand adaptive "
                "control mechanism"
            ),
            (
                "state conditioned intervention delayed information "
                "counterfactual outcome"
            ),
            compact_causal_query,
        )
        if query.strip()
        for provider in ("Google Scholar", "Semantic Scholar")
    )
    return PriorArtAssessment(
        signature=ClaimSignature(
            subject_id=node.node_id,
            statement=node.question,
            problem=base.signature.problem,
            phenomenon=(
                "causal structures shared by irreversible online decisions "
                "under information revealed after commitment"
            ),
            intervention=(
                "relational retrieval of source mechanisms followed by "
                "explicit source-to-target mapping and compilation"
            ),
            mechanism="; ".join(flattened),
            evaluation=(
                "causal replay, mechanism ablation, suffix permutation, "
                "matched controls, and frozen end-to-end replication"
            ),
        ),
        trigger=LiteratureTrigger.NEW_INTERVENTION,
        queries=(*base.queries, *cross_domain_queries),
        closest_works=base.closest_works,
        classification=ClaimClassification.NOVEL_CANDIDATE,
        rationale=(
            "This survey precedes cross-domain selection. It retrieves "
            "source evidence for the observed causal relation and penalizes "
            "target mechanisms already established in bin-packing work."
        ),
        novel_delta=(
            "source mechanisms are grounded by current web literature",
            "retrieval is ranked by causal mapping rather than keywords",
            "known target-domain mechanisms lower discovery priority",
        ),
        citation_snowball_complete=base.citation_snowball_complete,
        searched_at=base.searched_at,
        reviewer_ref="cross-domain-literature-planner-v1",
        executable_incumbent_id=base.executable_incumbent_id,
    )


def _binpacking_cross_domain_inspiration_portfolio(
    node: GoalNodeSpec,
    control_plane: Optional[
        AutonomousScientistControlPlane
    ] = None,
    store: Optional[ArtifactStore] = None,
    literature_assessment: Optional[
        PriorArtAssessment
    ] = None,
    literature_reviewer: Optional[
        LiveWebPriorArtReviewer
    ] = None,
) -> CrossDomainInspirationPortfolio:
    literature_context = (
        None
        if literature_assessment is None
        else build_literature_hypothesis_context(
            literature_assessment,
            "cross_domain",
            vocabulary=BINPACKING_LITERATURE_VOCABULARY,
            causal_questions=(
                ()
                if control_plane is None
                or control_plane.current_causal_failure_models(
                    node.node_id
                )
                is None
                else BinPackingGoalProgram._causal_literature_questions(
                    control_plane.current_causal_failure_models(
                        node.node_id
                    )
                )
            ),
        )
    )
    if store is not None and literature_context is not None:
        store.put(
            "cross_domain_literature_hypothesis_context",
            literature_context.as_dict(),
        )
    trace, inspirations, evaluations = _discover_binpacking_mechanisms(
        node,
        control_plane,
        literature_context,
    )
    selected = max(
        evaluations,
        key=lambda item: (
            item.priority_score,
            item.inspiration_id,
        ),
    )
    tournament = None
    selected_inspiration_ids = (selected.inspiration_id,)
    if control_plane is not None and store is not None:
        causal_models = trace.query.causal_failure_models
        tournament = _binpacking_hypothesis_tournament(
            node,
            _island_hypothesis_seeds(node, control_plane),
            inspirations,
            evaluations,
            causal_models,
            store,
            literature_assessment,
            literature_reviewer,
        )
        if (
            tournament is not None
            and tournament.eligible_champion_id is not None
        ):
            eligible_champion = next(
                hypothesis
                for hypothesis in tournament.hypotheses
                if hypothesis.hypothesis_id
                == tournament.eligible_champion_id
            )
            selected_inspiration_ids = (
                eligible_champion.inspiration_ids
            )
    rationale = (
        "cluster-complete causal failure models drove relational retrieval; "
        "every selected source maps unavailable information, irreversible "
        "decision, alternative action, and changed result"
    )
    if tournament is not None:
        rationale += (
            "; three island ideas and all transfers then competed through "
            "two generations of pairwise Elo debate"
        )
    return CrossDomainInspirationPortfolio(
        target_node_id=node.node_id,
        inspirations=inspirations,
        evaluations=evaluations,
        selected_inspiration_ids=selected_inspiration_ids,
        selection_rationale=rationale,
        synthesizer_ref=(
            "binpacking-dynamic-cross-domain-tournament-synthesizer-v1"
        ),
        causal_failure_models=trace.query.causal_failure_models,
        discovery_trace=trace,
        tournament=tournament,
    )


def _default_contextual_revision_config() -> BinPackingGoalRunConfig:
    return BinPackingGoalRunConfig(
        rounds=4,
        candidate_budget_per_island=32,
        initial_random_candidates=8,
        adversary_budget_per_round=64,
        adversary_initial_population=16,
        repair_case_count=16,
        guard_cases_per_length=6,
        audit_cases_per_length=10,
        replication_cases_per_length=100,
        integration_cases_per_family=24,
        capacity=150,
        development_length=120,
        validation_lengths=(120, 250, 500),
        base_seed=530_072_026,
        residual_scale=0.10,
    )


def _default_regime_router_revision_config() -> BinPackingGoalRunConfig:
    return BinPackingGoalRunConfig(
        rounds=3,
        candidate_budget_per_island=32,
        initial_random_candidates=8,
        adversary_budget_per_round=64,
        adversary_initial_population=16,
        repair_case_count=16,
        guard_cases_per_length=6,
        audit_cases_per_length=10,
        replication_cases_per_length=100,
        integration_cases_per_family=24,
        capacity=150,
        development_length=120,
        validation_lengths=(120, 250, 500),
        base_seed=730_072_026,
        residual_scale=0.10,
    )


def _default_demand_memory_revision_config() -> BinPackingGoalRunConfig:
    return BinPackingGoalRunConfig(
        rounds=2,
        candidate_budget_per_island=65,
        initial_random_candidates=10,
        adversary_budget_per_round=64,
        adversary_initial_population=16,
        repair_case_count=16,
        guard_cases_per_length=6,
        audit_cases_per_length=10,
        replication_cases_per_length=100,
        integration_cases_per_family=24,
        capacity=150,
        development_length=120,
        validation_lengths=(120, 250, 500),
        base_seed=930_072_026,
        residual_scale=0.10,
    )


class _BinPackingRevisionActionHandler:
    name = "binpacking-evidence-backed-revision-handler-v3"
    _PROGRAM_CLASS_BY_GENERATOR_REF = {
        "binpacking-contextual-linear-generator-v1": (
            ContextualBinPackingRevisionProgram
        ),
        "binpacking-regime-router-generator-v1": (
            RegimeRouterBinPackingRevisionProgram
        ),
        "binpacking-demand-memory-generator-v1": (
            DemandMemoryBinPackingRevisionProgram
        ),
    }

    def __init__(
        self,
        store: ArtifactStore,
        config: Optional[BinPackingGoalRunConfig],
        *,
        orlib_root: Path,
        revision_evidence_ids: Sequence[str],
    ) -> None:
        self.store = store
        self.config_override = config
        self.orlib_root = Path(orlib_root)
        self.revision_evidence_ids = tuple(revision_evidence_ids)
        self.revised_node_ids: set[str] = set()
        self.cycle_results: list[Mapping[str, Any]] = []
        self.cycle_configs: list[Mapping[str, Any]] = []
        self.cycle_result: Optional[Mapping[str, Any]] = None
        literature_config = config or BinPackingGoalRunConfig()
        self.literature_reviewer = (
            default_live_web_reviewer(
                store,
                timeout_seconds=(
                    literature_config.literature_timeout_seconds
                ),
                results_per_query=(
                    literature_config.literature_results_per_query
                ),
            )
            if literature_config.require_web_literature
            else None
        )

    def _config_for(
        self,
        program_class: Any,
    ) -> BinPackingGoalRunConfig:
        if self.config_override is not None:
            return self.config_override
        if program_class is ContextualBinPackingRevisionProgram:
            return _default_contextual_revision_config()
        if program_class is RegimeRouterBinPackingRevisionProgram:
            return _default_regime_router_revision_config()
        if program_class is DemandMemoryBinPackingRevisionProgram:
            return _default_demand_memory_revision_config()
        raise ValueError("no revision configuration for program class")

    @classmethod
    def _program_class_for_inspiration(
        cls,
        portfolio: CrossDomainInspirationPortfolio,
    ) -> Tuple[Optional[Any], Tuple[CrossDomainInspiration, ...]]:
        by_id = {
            inspiration.inspiration_id: inspiration
            for inspiration in portfolio.inspirations
        }
        selected = tuple(
            by_id[inspiration_id]
            for inspiration_id in portfolio.selected_inspiration_ids
        )
        generator_refs = {
            inspiration.generator_ref for inspiration in selected
        }
        if len(generator_refs) != 1:
            raise ValueError(
                "selected transfers do not identify one revision generator"
            )
        generator_ref = next(iter(generator_refs))
        return cls._PROGRAM_CLASS_BY_GENERATOR_REF.get(generator_ref), selected

    @classmethod
    def _program_class_for_portfolio(
        cls,
        portfolio: CrossDomainInspirationPortfolio,
    ) -> Tuple[
        Optional[Any],
        Tuple[CrossDomainInspiration, ...],
        Optional[TournamentHypothesis],
    ]:
        if portfolio.tournament is None:
            program_class, inspirations = (
                cls._program_class_for_inspiration(portfolio)
            )
            return program_class, inspirations, None
        tournament = portfolio.tournament
        selected_champion_id = tournament.eligible_champion_id
        if selected_champion_id is None:
            diagnosed = tuple(
                hypothesis
                for hypothesis in tournament.hypotheses
                if hypothesis.inspiration_ids
                and hypothesis.diagnostic_result is not None
            )
            if not diagnosed:
                raise ValueError(
                    "tournament produced no executable diagnostic"
                )
            registered_diagnosed = tuple(
                hypothesis
                for hypothesis in diagnosed
                if hypothesis.generator_ref
                in cls._PROGRAM_CLASS_BY_GENERATOR_REF
            )
            comparison_pool = registered_diagnosed or diagnosed
            champion = max(
                comparison_pool,
                key=lambda hypothesis: (
                    hypothesis.diagnostic_result.prediction_log_score,
                    tournament.final_ratings[hypothesis.hypothesis_id],
                    hypothesis.hypothesis_id,
                ),
            )
        else:
            champion = next(
                hypothesis
                for hypothesis in tournament.hypotheses
                if hypothesis.hypothesis_id == selected_champion_id
            )
        by_id = {
            inspiration.inspiration_id: inspiration
            for inspiration in portfolio.inspirations
        }
        inspirations = tuple(
            by_id[inspiration_id]
            for inspiration_id in champion.inspiration_ids
        )
        if not inspirations:
            raise ValueError(
                "tournament champion has no cross-domain mechanism"
            )
        if any(
            inspiration.generator_ref != champion.generator_ref
            for inspiration in inspirations
        ):
            raise ValueError(
                "tournament champion and supporting transfer disagree"
            )
        return (
            (
                cls._PROGRAM_CLASS_BY_GENERATOR_REF.get(
                    champion.generator_ref
                )
                if champion.revision_eligible
                else None
            ),
            inspirations,
            champion,
        )

    @staticmethod
    def _program_class_for_active_node(
        node: GoalNodeSpec,
    ) -> Any:
        tags = set(node.tags)
        matches = tuple(
            program_class
            for tag, program_class in (
                (
                    "contextual-linear",
                    ContextualBinPackingRevisionProgram,
                ),
                (
                    "regime-policy-router",
                    RegimeRouterBinPackingRevisionProgram,
                ),
                (
                    "empirical-demand-memory",
                    DemandMemoryBinPackingRevisionProgram,
                ),
            )
            if tag in tags
        )
        if len(matches) != 1:
            raise ValueError(
                "active revision node does not identify one representation"
            )
        return matches[0]

    def _recover_active_campaign_hypothesis(
        self,
        runtime: GoalGraphRuntime,
        program_class: Any,
        selected_hypothesis_id: Optional[str],
    ) -> Tuple[Optional[TournamentHypothesis], str]:
        if selected_hypothesis_id is None:
            raise ValueError(
                "active revision campaign has no selected hypothesis"
            )
        control = runtime.control_plane
        evidence_ids = tuple(
            dict.fromkeys(
                evidence_id
                for event in control.memory.events
                for evidence_id in event.payload.get("evidence_ids", ())
            )
        )
        stored_hypotheses = []
        for evidence_id in evidence_ids:
            try:
                artifact = self.store.get(str(evidence_id))
            except (FileNotFoundError, KeyError, ValueError):
                continue
            if (
                artifact.get("kind")
                != "binpacking_recovered_tournament_hypothesis"
            ):
                continue
            stored_hypotheses.append(
                tournament_hypothesis_from_dict(artifact["value"])
            )

        for source_node_id, portfolios in (
            control.cross_domain_inspirations.items()
        ):
            for portfolio in reversed(portfolios):
                (
                    routed_class,
                    _,
                    champion,
                ) = self._program_class_for_portfolio(portfolio)
                if champion is None:
                    continue
                champion_class = (
                    routed_class
                    or self._PROGRAM_CLASS_BY_GENERATOR_REF.get(
                        champion.generator_ref
                    )
                )
                if champion_class is not program_class:
                    continue
                if (
                    champion.hypothesis_id
                    == selected_hypothesis_id
                ):
                    return champion, source_node_id
                for stored in stored_hypotheses:
                    if (
                        stored.hypothesis_id
                        == selected_hypothesis_id
                        and champion.hypothesis_id
                        in stored.parent_ids
                    ):
                        return stored, source_node_id
                if champion.revision_eligible:
                    continue
                causal_models = (
                    control.current_causal_failure_models(
                        source_node_id
                    )
                )
                literature = control.current_literature(
                    source_node_id
                )
                if causal_models is None or literature is None:
                    continue
                _, recovered = _mediator_intervention_study(
                    champion,
                    causal_models,
                    self.store,
                    literature,
                )
                if (
                    recovered is not None
                    and recovered.hypothesis_id
                    == selected_hypothesis_id
                ):
                    return recovered, source_node_id
        raise ValueError(
            "could not restore the selected hypothesis for the active "
            "campaign"
        )

    def dispatch(
        self,
        action: ControlAction,
        runtime: GoalGraphRuntime,
    ) -> ActionDispatchResult:
        if (
            action.kind
            == ControlActionKind.SEEK_CROSS_DOMAIN_INSPIRATION
        ):
            node = runtime.control_plane.graph.nodes.get(action.node_id)
            if node is None:
                return ActionDispatchResult(
                    progressed=False,
                    stop=True,
                    outcome="missing_inspiration_target",
                    details={"node_id": action.node_id},
                )
            try:
                causal_models = (
                    runtime.control_plane
                    .current_causal_failure_models(node.node_id)
                )
                if causal_models is None:
                    raise ValueError(
                        "cross-domain literature requires causal models"
                    )
                # Fail before broad retrieval when the causal ontology has
                # collapsed.  Literature cannot repair an unidentified
                # target mechanism.
                _binpacking_mechanism_query(
                    node,
                    runtime.control_plane,
                )
                planned_literature = (
                    _cross_domain_literature_assessment(
                        node,
                        causal_models,
                    )
                )
                cross_domain_literature = (
                    runtime.control_plane.current_literature(
                        node.node_id
                    )
                )
                if (
                    cross_domain_literature is None
                    or cross_domain_literature.signature.signature_id
                    != planned_literature.signature.signature_id
                ):
                    cross_domain_literature = (
                        planned_literature
                        if self.literature_reviewer is None
                        else self.literature_reviewer.review(
                            planned_literature
                        )
                    )
                    runtime.transact(
                        "register_literature_assessment",
                        cross_domain_literature,
                    )
                elif not cross_domain_literature.closure_passed:
                    raise ValueError(
                        "current cross-domain literature is not closed"
                    )
                cross_domain_literature_digest = self.store.put(
                    "cross_domain_literature_assessment",
                    cross_domain_literature.as_dict(),
                )
                portfolio = _binpacking_cross_domain_inspiration_portfolio(
                    node,
                    runtime.control_plane,
                    self.store,
                    cross_domain_literature,
                    self.literature_reviewer,
                )
            except ValueError as error:
                model_set = (
                    runtime.control_plane.current_causal_failure_models(
                        node.node_id
                    )
                )
                assessment = (
                    None
                    if model_set is None
                    else assess_causal_discrimination(
                        model_set,
                        minimum_supported_schemas=2,
                        minimum_replay_support_rate=0.25,
                        maximum_schema_fraction=0.85,
                        minimum_proxy_reliability=0.55,
                        assessor_ref=(
                            "binpacking-causal-discrimination-gate-v1"
                        ),
                    )
                )
                assessment_digest = (
                    None
                    if assessment is None
                    else self.store.put(
                        "binpacking_causal_discrimination_assessment",
                        assessment.as_dict(),
                    )
                )
                discrimination_failed = (
                    assessment is not None and not assessment.passed
                )
                return ActionDispatchResult(
                    progressed=False,
                    stop=True,
                    outcome=(
                        "causal_discrimination_failed"
                        if discrimination_failed
                        else "mechanism_discovery_failed"
                    ),
                    details={
                        "node_id": node.node_id,
                        "reason": str(error),
                        "assessment": (
                            None
                            if assessment is None
                            else assessment.as_dict()
                        ),
                        "assessment_digest": assessment_digest,
                    },
                )
            if portfolio.tournament is None:
                return ActionDispatchResult(
                    progressed=False,
                    stop=True,
                    outcome="hypothesis_tournament_incomplete",
                    details={
                        "node_id": action.node_id,
                        "reason": (
                            "all three island hypotheses must enter the "
                            "cross-domain tournament"
                        ),
                    },
                )
            portfolio_id = runtime.transact(
                "register_cross_domain_inspiration",
                portfolio,
            )
            portfolio_digest = self.store.put(
                "binpacking_cross_domain_inspiration_portfolio",
                portfolio.as_dict(),
            )
            self.revision_evidence_ids = (
                *self.revision_evidence_ids,
                cross_domain_literature_digest,
                portfolio_digest,
            )
            return ActionDispatchResult(
                progressed=True,
                stop=False,
                outcome="cross_domain_inspiration_registered",
                details={
                    "node_id": action.node_id,
                    "portfolio_id": portfolio_id,
                    "portfolio_digest": portfolio_digest,
                    "literature_assessment_id": (
                        cross_domain_literature.assessment_id
                    ),
                    "literature_assessment_digest": (
                        cross_domain_literature_digest
                    ),
                    "literature_searched_at": (
                        cross_domain_literature.searched_at
                    ),
                    "selected_inspiration_ids": list(
                        portfolio.selected_inspiration_ids
                    ),
                    "source_domains": [
                        item.source_domain
                        for item in portfolio.inspirations
                    ],
                    "mechanism_discovery_trace_id": (
                        portfolio.discovery_trace.trace_id
                    ),
                    "hypothesis_tournament_id": (
                        portfolio.tournament.tournament_id
                    ),
                    "tournament_hypothesis_count": len(
                        portfolio.tournament.hypotheses
                    ),
                    "tournament_match_count": len(
                        portfolio.tournament.matches
                    ),
                    "tournament_champion_id": (
                        portfolio.tournament.champion_id
                    ),
                    "eligible_tournament_champion_id": (
                        portfolio.tournament.eligible_champion_id
                    ),
                },
            )
        if action.kind == ControlActionKind.CONTINUE_CAMPAIGN:
            node = runtime.control_plane.graph.nodes.get(action.node_id)
            if node is None:
                return ActionDispatchResult(
                    progressed=False,
                    stop=True,
                    outcome="missing_active_campaign_node",
                    details={"node_id": action.node_id},
                )
            try:
                campaign_id = (
                    runtime.control_plane.active_campaign_ids[
                        action.node_id
                    ]
                )
                campaign = runtime.control_plane.campaigns[campaign_id]
                program_class = self._program_class_for_active_node(node)
                selected_hypothesis, plateaued_leaf_id = (
                    self._recover_active_campaign_hypothesis(
                        runtime,
                        program_class,
                        campaign.contract.selected_hypothesis_id,
                    )
                )
                cycle_config = self._config_for(program_class)
                program = program_class(
                    runtime,
                    self.store,
                    cycle_config,
                    orlib_root=self.orlib_root,
                    plateaued_leaf_id=plateaued_leaf_id,
                    revision_evidence_ids=self.revision_evidence_ids,
                    selected_hypothesis=selected_hypothesis,
                )
                self.cycle_result = dict(program.run())
            except (KeyError, ValueError) as error:
                return ActionDispatchResult(
                    progressed=False,
                    stop=True,
                    outcome="active_campaign_resume_failed",
                    details={
                        "node_id": action.node_id,
                        "reason": str(error),
                    },
                )
            self.cycle_results.append(self.cycle_result)
            self.cycle_configs.append(cycle_config.as_dict())
            cycle_digest = self.store.put(
                "binpacking_v2_revision_cycle",
                self.cycle_result,
            )
            self.revision_evidence_ids = (cycle_digest,)
            return ActionDispatchResult(
                progressed=True,
                stop=False,
                outcome="active_revision_campaign_completed",
                details={
                    "cycle_digest": cycle_digest,
                    "outcome": self.cycle_result["outcome"],
                    "leaf_node_id": self.cycle_result["leaf_node_id"],
                    "campaign_id": self.cycle_result["campaign_id"],
                    "revision_config": cycle_config.as_dict(),
                    "selected_hypothesis_id": (
                        selected_hypothesis.hypothesis_id
                    ),
                    "recovered_from_interrupted_campaign": True,
                },
            )
        if action.kind != ControlActionKind.REVISE_GRAPH:
            return ActionDispatchResult(
                progressed=False,
                stop=True,
                outcome="unsupported_control_action",
                details={"action": action.as_dict()},
            )
        if action.node_id in self.revised_node_ids:
            return ActionDispatchResult(
                progressed=False,
                stop=True,
                outcome="repeated_revision_action",
                details={
                    "node_id": action.node_id,
                    "reason": "the same plateau was already revised",
                },
            )
        node = runtime.control_plane.graph.nodes.get(action.node_id)
        if node is None:
            return ActionDispatchResult(
                progressed=False,
                stop=True,
                outcome="missing_revision_target",
                details={"node_id": action.node_id},
            )
        portfolio = (
            runtime.control_plane.current_cross_domain_inspiration(
                action.node_id
            )
        )
        if portfolio is None:
            return ActionDispatchResult(
                progressed=False,
                stop=True,
                outcome="missing_cross_domain_inspiration",
                details={"node_id": action.node_id},
            )
        try:
            (
                program_class,
                selected_inspirations,
                selected_hypothesis,
            ) = (
                self._program_class_for_portfolio(portfolio)
            )
        except (KeyError, ValueError) as error:
            return ActionDispatchResult(
                progressed=False,
                stop=True,
                outcome="invalid_cross_domain_inspiration_routing",
                details={
                    "node_id": action.node_id,
                    "portfolio_id": portfolio.portfolio_id,
                    "reason": str(error),
                },
            )
        selected_inspiration_ids = [
            inspiration.inspiration_id
            for inspiration in selected_inspirations
        ]
        selected_generator_ref = (
            selected_inspirations[0].generator_ref
            if selected_hypothesis is None
            else selected_hypothesis.generator_ref
        )
        tournament_details = {
            "hypothesis_tournament_id": (
                None
                if portfolio.tournament is None
                else portfolio.tournament.tournament_id
            ),
            "selected_tournament_hypothesis_id": (
                None
                if selected_hypothesis is None
                else selected_hypothesis.hypothesis_id
            ),
            "tournament_elo": (
                None
                if selected_hypothesis is None
                else portfolio.tournament.final_ratings[
                    selected_hypothesis.hypothesis_id
                ]
            ),
        }
        tags = set(node.tags)
        if program_class is None:
            minimum_viable_compute = 5.0
            available_budget = (
                runtime.control_plane.compute_available_for_new_campaigns
            )
            if (
                "empirical-demand-memory" in tags
                and available_budget < minimum_viable_compute
            ):
                certificate = runtime.transact(
                    "issue_unresolved_certificate",
                    RootUnresolvedReason.BUDGET_EXHAUSTED,
                    (
                        "remaining compute %.1f is below the %.1f minimum "
                        "for a two-round matched three-island campaign"
                        % (available_budget, minimum_viable_compute),
                        "all four registered representation families "
                        "plateaued without a replication-qualified candidate",
                    ),
                    self.revision_evidence_ids,
                    (
                        "no superior bin-packing heuristic was established",
                        "the result is limited to the preregistered generated "
                        "and OR-style online scope",
                        "unused sub-quantum compute cannot support a valid "
                        "matched campaign",
                    ),
                    minimum_viable_compute,
                )
                return ActionDispatchResult(
                    progressed=True,
                    stop=False,
                    outcome="root_unresolved_budget_exhausted",
                    details={
                        "node_id": action.node_id,
                        "certificate": certificate.as_dict(),
                        "remaining_compute": available_budget,
                        "minimum_viable_compute": minimum_viable_compute,
                        "portfolio_id": portfolio.portfolio_id,
                        "selected_inspiration_ids": (
                            selected_inspiration_ids
                        ),
                        "selected_generator_ref": (
                            selected_generator_ref
                        ),
                        **tournament_details,
                    },
                )
            diagnostic_failed = (
                selected_hypothesis is not None
                and not selected_hypothesis.revision_eligible
            )
            diagnostic = (
                None
                if selected_hypothesis is None
                else selected_hypothesis.diagnostic_result
            )
            if diagnostic_failed:
                if (
                    selected_hypothesis.generator_ref
                    != "binpacking-demand-memory-generator-v1"
                ):
                    return ActionDispatchResult(
                        progressed=False,
                        stop=True,
                        outcome="no_compiled_mediator_intervention",
                        details={
                            "node_id": node.node_id,
                            "reason": (
                                "the focused mediator intervention study is "
                                "compiled only for demand-memory action "
                                "features; the failed tournament hypothesis "
                                "uses %s"
                                % selected_hypothesis.generator_ref
                            ),
                            "required_next_evidence": (
                                "a representation-specific mediator or "
                                "intervention compiler with target-engagement "
                                "and matched-control diagnostics"
                            ),
                            "diagnostic_id": (
                                None
                                if diagnostic is None
                                else diagnostic.diagnostic_id
                            ),
                            "diagnostic_failure_reasons": (
                                []
                                if diagnostic is None
                                else list(
                                    diagnostic.failure_reasons
                                )
                            ),
                            "portfolio_id": portfolio.portfolio_id,
                            "selected_inspiration_ids": (
                                selected_inspiration_ids
                            ),
                            "selected_generator_ref": (
                                selected_generator_ref
                            ),
                            **tournament_details,
                        },
                    )
                try:
                    causal_models = (
                        runtime.control_plane
                        .current_causal_failure_models(node.node_id)
                    )
                    if causal_models is None:
                        raise ValueError(
                            "mediator study requires causal failure models"
                        )
                    base_literature = (
                        runtime.control_plane.current_literature(
                            node.node_id
                        )
                    )
                    if base_literature is None:
                        raise ValueError(
                            "mediator study requires closed literature"
                        )
                    planned_recovery_literature = (
                        _mediator_recovery_literature_assessment(
                            node,
                            base_literature,
                            causal_models,
                            selected_hypothesis,
                        )
                    )
                    recovery_literature = base_literature
                    if (
                        recovery_literature.signature.signature_id
                        != planned_recovery_literature.signature.signature_id
                    ):
                        recovery_literature = (
                            planned_recovery_literature
                            if self.literature_reviewer is None
                            else self.literature_reviewer.review(
                                planned_recovery_literature
                            )
                        )
                        runtime.transact(
                            "register_literature_assessment",
                            recovery_literature,
                        )
                    recovery_literature_digest = self.store.put(
                        "binpacking_mediator_recovery_literature_assessment",
                        recovery_literature.as_dict(),
                    )
                    study_value, recovered_hypothesis = (
                        _mediator_intervention_study(
                            selected_hypothesis,
                            causal_models,
                            self.store,
                            recovery_literature,
                        )
                    )
                    study_digest = self.store.put(
                        "binpacking_mediator_intervention_study",
                        study_value,
                    )
                    recovered_hypothesis_digest = (
                        None
                        if recovered_hypothesis is None
                        else self.store.put(
                            "binpacking_recovered_tournament_hypothesis",
                            recovered_hypothesis.as_dict(),
                        )
                    )
                except ValueError as error:
                    return ActionDispatchResult(
                        progressed=False,
                        stop=True,
                        outcome="mediator_intervention_study_failed",
                        details={
                            "node_id": node.node_id,
                            "portfolio_id": portfolio.portfolio_id,
                            "reason": str(error),
                            "diagnostic_id": (
                                None
                                if diagnostic is None
                                else diagnostic.diagnostic_id
                            ),
                            **tournament_details,
                        },
                    )
                self.revision_evidence_ids = (
                    *self.revision_evidence_ids,
                    recovery_literature_digest,
                    study_digest,
                    *(
                        ()
                        if recovered_hypothesis_digest is None
                        else (recovered_hypothesis_digest,)
                    ),
                )
                if recovered_hypothesis is None:
                    best_candidate = (
                        study_value["candidates"][0]
                        if study_value["candidates"]
                        else None
                    )
                    return ActionDispatchResult(
                        progressed=False,
                        stop=True,
                        outcome=(
                            "no_diagnostic_qualified_mediator_intervention"
                        ),
                        details={
                            "node_id": node.node_id,
                            "reason": (
                                "bounded mediator-directed interventions "
                                "failed the unchanged causal diagnostic"
                            ),
                            "portfolio_id": portfolio.portfolio_id,
                            "mediator_study_digest": study_digest,
                            "mediator_study_outcome": study_value["outcome"],
                            "mediator_candidate_count": (
                                study_value["candidate_count"]
                            ),
                            "best_mediator_diagnostic": (
                                None
                                if best_candidate is None
                                else best_candidate["diagnostic"]
                            ),
                            "recovery_literature_assessment_id": (
                                recovery_literature.assessment_id
                            ),
                            "recovery_literature_digest": (
                                recovery_literature_digest
                            ),
                            **tournament_details,
                        },
                    )
                selected_hypothesis = recovered_hypothesis
                selected_generator_ref = (
                    recovered_hypothesis.generator_ref
                )
                program_class = self._PROGRAM_CLASS_BY_GENERATOR_REF.get(
                    selected_generator_ref
                )
                tournament_details = {
                    **tournament_details,
                    "mediator_recovered_hypothesis_id": (
                        recovered_hypothesis.hypothesis_id
                    ),
                    "mediator_recovered_diagnostic_id": (
                        recovered_hypothesis
                        .diagnostic_result.diagnostic_id
                    ),
                    "mediator_study_digest": study_digest,
                    "recovery_literature_assessment_id": (
                        recovery_literature.assessment_id
                    ),
                }
            if program_class is None:
                return ActionDispatchResult(
                    progressed=False,
                    stop=True,
                    outcome="no_registered_revision_strategy",
                    details={
                        "node_id": action.node_id,
                        "reason": (
                            "the selected cross-domain transfer has no "
                            "registered executable revision generator"
                        ),
                        "diagnostic_id": (
                            None
                            if diagnostic is None
                            else diagnostic.diagnostic_id
                        ),
                        "diagnostic_failure_reasons": (
                            []
                            if diagnostic is None
                            else list(diagnostic.failure_reasons)
                        ),
                        "portfolio_id": portfolio.portfolio_id,
                        "selected_inspiration_ids": (
                            selected_inspiration_ids
                        ),
                        "selected_generator_ref": (
                            selected_generator_ref
                        ),
                        **tournament_details,
                    },
                )
        cycle_config = self._config_for(program_class)
        required_budget = (
            cycle_config.maximum_search_compute
            + program_class.campaign_overhead
        )
        available_budget = (
            runtime.control_plane.compute_available_for_new_campaigns
        )
        if required_budget > available_budget:
            return ActionDispatchResult(
                progressed=False,
                stop=True,
                outcome="revision_budget_exhausted",
                details={
                    "node_id": action.node_id,
                    "required_budget": required_budget,
                    "available_budget": available_budget,
                    "strategy": program_class.representation,
                    "portfolio_id": portfolio.portfolio_id,
                    "selected_inspiration_ids": selected_inspiration_ids,
                    "selected_generator_ref": selected_generator_ref,
                    **tournament_details,
                },
            )
        self.revised_node_ids.add(action.node_id)
        program = program_class(
            runtime,
            self.store,
            cycle_config,
            orlib_root=self.orlib_root,
            plateaued_leaf_id=action.node_id,
            revision_evidence_ids=self.revision_evidence_ids,
            selected_hypothesis=selected_hypothesis,
        )
        self.cycle_result = dict(program.run())
        self.cycle_results.append(self.cycle_result)
        self.cycle_configs.append(cycle_config.as_dict())
        cycle_digest = self.store.put(
            "binpacking_v2_revision_cycle",
            self.cycle_result,
        )
        self.revision_evidence_ids = (cycle_digest,)
        return ActionDispatchResult(
            progressed=True,
            stop=False,
            outcome="revision_cycle_completed",
            details={
                "cycle_digest": cycle_digest,
                "outcome": self.cycle_result["outcome"],
                "leaf_node_id": self.cycle_result["leaf_node_id"],
                "campaign_id": self.cycle_result["campaign_id"],
                "revision_config": cycle_config.as_dict(),
                "portfolio_id": portfolio.portfolio_id,
                "selected_inspiration_ids": selected_inspiration_ids,
                "selected_generator_ref": selected_generator_ref,
                "selected_executable_digest": (
                    None
                    if selected_hypothesis is None
                    or selected_hypothesis.executable_contract is None
                    else selected_hypothesis.executable_contract.executable_digest
                ),
                "selected_diagnostic_id": (
                    None
                    if selected_hypothesis is None
                    or selected_hypothesis.diagnostic_result is None
                    else selected_hypothesis.diagnostic_result.diagnostic_id
                ),
                **tournament_details,
            },
        )


def run_clean_goal_program(
    *,
    checkpoint_path: Path,
    artifact_root: Path,
    orlib_root: Path,
    config: Optional[BinPackingGoalRunConfig] = None,
) -> Mapping[str, Any]:
    config = config or BinPackingGoalRunConfig()
    checkpoint_path = Path(checkpoint_path)
    if checkpoint_path.exists():
        raise ValueError("checkpoint already exists; refusing to overwrite")
    artifact_root = Path(artifact_root)
    if artifact_root.exists() and any(artifact_root.iterdir()):
        raise ValueError(
            "artifact root is not empty; refusing to mix a clean run "
            "with existing execution information"
        )
    benchmark_conformance = verify_funsearch_benchmark_conformance(
        orlib_root
    )
    store = ArtifactStore(artifact_root)
    conformance_digest = store.put(
        "binpacking_funsearch_benchmark_conformance",
        benchmark_conformance.as_dict(),
    )
    control = build_control_plane(config, artifact_store=store)
    runtime = GoalGraphRuntime(
        control,
        checkpoint_path,
        artifact_store=store,
    )
    program = BinPackingGoalProgram(
        runtime,
        store,
        config,
        orlib_root=orlib_root,
    )
    result = dict(program.run())
    result["benchmark_conformance_digest"] = conformance_digest
    result["benchmark_conformance_passed"] = True
    summary_digest = store.put(
        "binpacking_v2_clean_goal_run_summary",
        result,
    )
    manifest_id = (
        "binpacking-v2-clean-"
        + content_digest(
            {
                "goal_id": control.goal.goal_id,
                "config": config.as_dict(),
                "summary_digest": summary_digest,
            }
        )[:32]
    )
    manifest_path = store.write_manifest(
        manifest_id,
        {
            "schema": 1,
            "kind": "binpacking_v2_clean_goal_run",
            "manifest_id": manifest_id,
            "research_goal": RESEARCH_GOAL,
            "goal_id": control.goal.goal_id,
            "checkpoint": str(checkpoint_path.resolve()),
            "summary_digest": summary_digest,
            "benchmark_conformance_digest": conformance_digest,
            "outcome": result["outcome"],
            "memory_head_event_id": (
                control.memory.events[-1].event_id
            ),
        },
    )
    return {
        **result,
        "summary_digest": summary_digest,
        "manifest": str(manifest_path.resolve()),
    }


def continue_goal_program(
    *,
    checkpoint_path: Path,
    artifact_root: Path,
    prior_manifest_path: Path,
    orlib_root: Path,
    config: Optional[BinPackingGoalRunConfig] = None,
) -> Mapping[str, Any]:
    checkpoint_path = Path(checkpoint_path)
    artifact_root = Path(artifact_root)
    prior_manifest_path = Path(prior_manifest_path)
    if not checkpoint_path.is_file():
        raise ValueError("continuation checkpoint does not exist")
    if not prior_manifest_path.is_file():
        raise ValueError("continuation manifest does not exist")
    benchmark_conformance = verify_funsearch_benchmark_conformance(
        orlib_root
    )
    with prior_manifest_path.open("r", encoding="utf-8") as handle:
        prior_manifest = json.load(handle)
    manifest_kind = prior_manifest.get("kind")
    manifest_contracts = {
        "binpacking_v2_clean_goal_run": (
            "summary_digest",
            "binpacking_v2_clean_goal_run_summary",
        ),
        "binpacking_v2_goal_continuation": (
            "continuation_digest",
            "binpacking_v2_goal_continuation_summary",
        ),
    }
    if manifest_kind not in manifest_contracts:
        raise ValueError(
            "prior manifest is not a bin-packing goal-run checkpoint boundary"
        )
    store = ArtifactStore(artifact_root)
    conformance_digest = store.put(
        "binpacking_funsearch_benchmark_conformance",
        benchmark_conformance.as_dict(),
    )
    digest_field, expected_summary_kind = manifest_contracts[manifest_kind]
    prior_digest = str(prior_manifest[digest_field])
    prior_summary = store.get(prior_digest)
    if prior_summary.get("kind") != expected_summary_kind:
        raise ValueError("prior manifest references another summary kind")
    prior_value = prior_summary["value"]
    if prior_value.get("research_goal") != RESEARCH_GOAL:
        raise ValueError("prior run belongs to another research goal")
    prior_boundary = (
        prior_value.get("executive", {}).get("boundary")
    )
    if (
        prior_boundary
        == "no_diagnostic_qualified_mediator_intervention"
        and prior_value.get("program_version")
        == BINPACKING_GOAL_PROGRAM_VERSION
    ):
        raise ValueError(
            "the prior continuation falsified every bounded mediator "
            "intervention available to this architecture version; refusing "
            "to replay the same branch without a new executable "
            "representation or program-version change"
        )
    runtime = GoalGraphRuntime.from_checkpoint(
        checkpoint_path,
        artifact_store=store,
    )
    if runtime.control_plane.goal.goal_id != prior_manifest.get("goal_id"):
        raise ValueError("checkpoint and prior manifest disagree")
    current_memory_head = (
        runtime.control_plane.memory.events[-1].event_id
    )
    prior_memory_head = prior_manifest.get("memory_head_event_id")
    checkpoint_recovery = current_memory_head != prior_memory_head
    if checkpoint_recovery:
        event_ids = {
            event.event_id
            for event in runtime.control_plane.memory.events
        }
        recoverable_actions = {
            action.kind
            for action in runtime.control_plane.next_actions()
        }
        if (
            not runtime.control_plane.memory.verify_chain()
            or prior_memory_head not in event_ids
            or ControlActionKind.CONTINUE_CAMPAIGN
            not in recoverable_actions
        ):
            raise ValueError(
                "checkpoint advanced beyond the supplied manifest outside "
                "a recoverable active campaign"
            )
    handler = _BinPackingRevisionActionHandler(
        store,
        config,
        orlib_root=orlib_root,
        revision_evidence_ids=(prior_digest,),
    )
    executive = AutonomousGoalExecutive(runtime, handler)
    executive_outcome = executive.run(max_steps=10)
    revision_cycles = [
        dict(cycle) for cycle in handler.cycle_results
    ]
    result = {
        "schema": 1,
        "kind": "binpacking_v2_goal_continuation",
        "program_version": BINPACKING_GOAL_PROGRAM_VERSION,
        "benchmark_conformance_digest": conformance_digest,
        "benchmark_conformance_passed": True,
        "research_goal": RESEARCH_GOAL,
        "prior_manifest": str(prior_manifest_path.resolve()),
        "prior_summary_digest": prior_digest,
        "prior_evidence_digest": prior_digest,
        "checkpoint_recovery": {
            "used": checkpoint_recovery,
            "prior_memory_head_event_id": prior_memory_head,
            "recovered_memory_head_event_id": current_memory_head,
        },
        "revision_config": (
            None if config is None else config.as_dict()
        ),
        "revision_configs": [
            dict(item) for item in handler.cycle_configs
        ],
        "executive": executive_outcome.as_dict(),
        "revision_cycles": revision_cycles,
        "revision_cycle": (
            None
            if handler.cycle_result is None
            else dict(handler.cycle_result)
        ),
        "status": runtime.status(),
    }
    continuation_digest = store.put(
        "binpacking_v2_goal_continuation_summary",
        result,
    )
    manifest_id = (
        "binpacking-v2-continuation-"
        + content_digest(
            {
                "goal_id": runtime.control_plane.goal.goal_id,
                "prior_evidence_digest": prior_digest,
                "continuation_digest": continuation_digest,
            }
        )[:32]
    )
    manifest_path = store.write_manifest(
        manifest_id,
        {
            "schema": 1,
            "kind": "binpacking_v2_goal_continuation",
            "manifest_id": manifest_id,
            "research_goal": RESEARCH_GOAL,
            "goal_id": runtime.control_plane.goal.goal_id,
            "checkpoint": str(checkpoint_path.resolve()),
            "prior_manifest": str(prior_manifest_path.resolve()),
            "prior_summary_digest": prior_digest,
            "prior_evidence_digest": prior_digest,
            "checkpoint_recovery_used": checkpoint_recovery,
            "continuation_digest": continuation_digest,
            "executive_boundary": executive_outcome.boundary,
            "cycle_outcome": (
                None
                if handler.cycle_result is None
                else handler.cycle_result["outcome"]
            ),
            "cycle_outcomes": [
                cycle["outcome"] for cycle in revision_cycles
            ],
            "cycle_count": len(revision_cycles),
            "memory_head_event_id": (
                runtime.control_plane.memory.events[-1].event_id
            ),
        },
    )
    return {
        **result,
        "continuation_digest": continuation_digest,
        "manifest": str(manifest_path.resolve()),
    }
