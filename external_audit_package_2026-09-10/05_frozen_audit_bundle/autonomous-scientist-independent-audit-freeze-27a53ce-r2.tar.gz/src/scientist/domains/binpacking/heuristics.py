from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Protocol, Sequence, Tuple

from scientist.domains.binpacking.models import (
    BinPackingInstance,
    PackingResult,
    Placement,
)


class OnlineHeuristic(Protocol):
    name: str

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        """Return a feasible existing bin index, or None to open a new bin."""


Chooser = Callable[
    [int, Sequence[int], int, int, Sequence[int]],
    Optional[int],
]


@dataclass(frozen=True)
class FunctionalHeuristic:
    name: str
    chooser: Chooser

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        return self.chooser(item, loads, capacity, item_index, history)


def _feasible(item: int, loads: Sequence[int], capacity: int) -> List[int]:
    return [
        index
        for index, load in enumerate(loads)
        if load + item <= capacity
    ]


def _first_fit(
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
) -> Optional[int]:
    feasible = _feasible(item, loads, capacity)
    return feasible[0] if feasible else None


def _best_fit(
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
) -> Optional[int]:
    feasible = _feasible(item, loads, capacity)
    return (
        min(feasible, key=lambda index: capacity - loads[index] - item)
        if feasible
        else None
    )


def _worst_fit(
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
) -> Optional[int]:
    feasible = _feasible(item, loads, capacity)
    return (
        max(feasible, key=lambda index: capacity - loads[index] - item)
        if feasible
        else None
    )


def _next_fit(
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
) -> Optional[int]:
    if loads and loads[-1] + item <= capacity:
        return len(loads) - 1
    return None


def baseline_heuristics() -> Dict[str, OnlineHeuristic]:
    heuristics = (
        FunctionalHeuristic("first_fit", _first_fit),
        FunctionalHeuristic("best_fit", _best_fit),
        FunctionalHeuristic("worst_fit", _worst_fit),
        FunctionalHeuristic("next_fit", _next_fit),
    )
    return {heuristic.name: heuristic for heuristic in heuristics}


@dataclass(frozen=True)
class FunSearchORReference:
    """Published FunSearch OR-distribution heuristic (provenance baseline)."""

    name: str = "funsearch_or_reference"

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        actions: List[Tuple[float, int, Optional[int]]] = []
        for index, load in enumerate(loads):
            if load + item <= capacity:
                actions.append(
                    (
                        self._score(capacity - load - item),
                        -index,
                        index,
                    )
                )
        actions.append(
            (
                self._score(capacity - item),
                -len(loads),
                None,
            )
        )
        return max(actions, key=lambda value: (value[0], value[1]))[2]

    @staticmethod
    def _score(remaining_after: int) -> float:
        return funsearch_or_score(remaining_after)


def funsearch_or_score(remaining_after: int) -> float:
    """Published FunSearch score for the OR-Library distribution."""

    thresholds = (
        (2, 4.0),
        (3, 3.0),
        (5, 2.0),
        (7, 1.0),
        (9, 0.90),
        (12, 0.95),
        (15, 0.97),
        (18, 0.98),
        (20, 0.98),
        (21, 0.98),
    )
    for threshold, score in thresholds:
        if remaining_after <= threshold:
            return score
    return 0.99


def literature_heuristics() -> Dict[str, OnlineHeuristic]:
    heuristics = (FunSearchORReference(),)
    return {heuristic.name: heuristic for heuristic in heuristics}


def pack(
    instance: BinPackingInstance,
    heuristic: OnlineHeuristic,
) -> PackingResult:
    loads: List[int] = []
    placements: List[Placement] = []
    history: List[int] = []

    for item_index, item in enumerate(instance.items):
        bin_index = heuristic.choose_bin(
            item=item,
            loads=tuple(loads),
            capacity=instance.capacity,
            item_index=item_index,
            history=tuple(history),
        )

        if bin_index is None:
            loads.append(item)
            bin_index = len(loads) - 1
        else:
            if bin_index < 0 or bin_index >= len(loads):
                raise ValueError(
                    "%s selected nonexistent bin %s" % (heuristic.name, bin_index)
                )
            if loads[bin_index] + item > instance.capacity:
                raise ValueError(
                    "%s selected infeasible bin %s" % (heuristic.name, bin_index)
                )
            loads[bin_index] += item

        history.append(item)
        placements.append(
            Placement(
                item_index=item_index,
                item=item,
                bin_index=bin_index,
                loads_after=tuple(loads),
            )
        )

    return PackingResult(
        heuristic=heuristic.name,
        instance_id=instance.instance_id,
        bin_count=len(loads),
        placements=tuple(placements),
    )
