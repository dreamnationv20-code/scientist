from __future__ import annotations

import math
import random
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import _apply_action, _parse_action
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.domains.binpacking.monte_carlo_policy_improvement import _paired_stats
from scientist.program.discovery_evidence import paired_episode_evidence


HORIZON_TRANSPORT_POTENTIAL_VERSION = "horizon-transport-typed-potential-v1"


def portfolio_potential_primitives(
    loads: Sequence[int], *, future_horizon: int, capacity: int = 150
) -> Mapping[str, float]:
    residuals = tuple(capacity - int(load) for load in loads)
    if not residuals:
        residuals = (capacity,)
    item_values = tuple(range(20, 101))
    option_counts = []
    tightest_slacks = []
    for item in item_values:
        feasible = tuple(residual - item for residual in residuals if residual >= item)
        option_counts.append(len(feasible))
        tightest_slacks.append(min(feasible) if feasible else capacity - item)
    option_mean = mean(option_counts)
    option_variance = mean((value - option_mean) ** 2 for value in option_counts)
    dead = tuple(value for value in residuals if value < 20)
    support = tuple(value for value in residuals if 20 <= value <= 100)
    oversized = tuple(value for value in residuals if value > 100)
    normalized_horizon = future_horizon / 384.0
    absorption_deficit = 0.0
    near_closure_deficit = 0.0
    for residual in residuals:
        fit_probability = (
            0.0
            if residual < 20
            else min(81, residual - 19) / 81.0
        )
        no_fit_probability = (1.0 - fit_probability) ** max(0, future_horizon)
        absorption_deficit += residual * no_fit_probability
        lower = max(20, residual - 5)
        upper = min(100, residual)
        near_probability = max(0, upper - lower + 1) / 81.0
        no_near_probability = (1.0 - near_probability) ** max(0, future_horizon)
        near_closure_deficit += residual * no_near_probability
    sorted_residuals = sorted(residuals)
    residual_entropy = 0.0
    counts: Dict[int, int] = {}
    for residual in residuals:
        bucket = min(7, residual // 20)
        counts[bucket] = counts.get(bucket, 0) + 1
    for count in counts.values():
        probability = count / float(len(residuals))
        residual_entropy -= probability * math.log(probability)
    return {
        "dead_residual_mass": float(sum(dead)),
        "dead_residual_count": float(len(dead)),
        "support_residual_count": float(len(support)),
        "oversized_residual_excess": float(sum(value - 100 for value in oversized)),
        "expected_no_fit_probability": sum(value == 0 for value in option_counts) / 81.0,
        "expected_single_fit_probability": sum(value == 1 for value in option_counts) / 81.0,
        "expected_fit_option_count": option_mean,
        "fit_option_count_variance": option_variance,
        "expected_tightest_fit_slack": mean(tightest_slacks),
        "tightest_fit_slack_l2": mean(value * value for value in tightest_slacks) ** 0.5,
        "absorption_deficit": absorption_deficit,
        "near_closure_deficit": near_closure_deficit,
        "residual_l2": sum(value * value for value in residuals) ** 0.5,
        "residual_entropy": residual_entropy,
        "small_residual_count": float(sum(value <= 40 for value in residuals)),
        "medium_residual_count": float(sum(40 < value <= 80 for value in residuals)),
        "large_residual_count": float(sum(value > 80 for value in residuals)),
        "minimum_residual": float(sorted_residuals[0]),
        "maximum_residual": float(sorted_residuals[-1]),
        "future_horizon_scaled": normalized_horizon,
        "horizon_x_expected_tightest_slack": normalized_horizon
        * mean(tightest_slacks),
        "horizon_x_option_variance": normalized_horizon * option_variance,
        "horizon_x_residual_entropy": normalized_horizon * residual_entropy,
    }


def _transport_suffix_bank(
    probe: Mapping[str, Any],
    *,
    bank: str,
    sample_count: int,
    terminal_horizon: int,
) -> Tuple[int, Tuple[Tuple[int, ...], ...]]:
    material = {
        "version": HORIZON_TRANSPORT_POTENTIAL_VERSION,
        "probe_id": str(probe["probe_id"]),
        "bank": bank,
        "sample_count": sample_count,
        "terminal_horizon": terminal_horizon,
    }
    seed = int(content_digest(material)[:16], 16)
    rng = random.Random(seed)
    return seed, tuple(
        tuple(rng.randint(20, 100) for _ in range(terminal_horizon))
        for _ in range(sample_count)
    )


def _branch_checkpoint_and_terminal(
    probe: Mapping[str, Any],
    *,
    action_ref: str,
    suffix: Sequence[int],
    short_horizon: int,
) -> Tuple[Tuple[int, ...], int]:
    baseline = literature_heuristics()["funsearch_or_reference"]
    loads = _apply_action(
        _parse_action(action_ref),
        int(probe["item"]),
        tuple(int(value) for value in probe["loads"]),
        150,
    )
    history = (
        *tuple(int(value) for value in probe["history"]),
        int(probe["item"]),
    )[-128:]
    checkpoint: Optional[Tuple[int, ...]] = None
    for offset, item in enumerate(suffix, start=1):
        action = baseline.choose_bin(
            int(item),
            loads,
            150,
            int(probe["item_index"]) + offset,
            history,
        )
        loads = _apply_action(action, int(item), loads, 150)
        history = (*history, int(item))[-128:]
        if offset == short_horizon:
            checkpoint = loads
    if checkpoint is None:
        raise ValueError("terminal horizon ended before the short checkpoint")
    return checkpoint, len(loads)


def evaluate_probe_horizon_contrasts(
    probe: Mapping[str, Any],
    *,
    terminal_horizon: int,
    short_horizon: int = 96,
    sample_count: int = 128,
    bank: str = "horizon_transport_development_v1",
) -> Tuple[Mapping[str, Any], ...]:
    if terminal_horizon <= short_horizon:
        raise ValueError("terminal horizon must extend beyond the short checkpoint")
    seed, suffixes = _transport_suffix_bank(
        probe,
        bank=bank,
        sample_count=sample_count,
        terminal_horizon=terminal_horizon,
    )
    baseline_ref = str(probe["baseline_action_ref"])
    baseline_rows = tuple(
        _branch_checkpoint_and_terminal(
            probe,
            action_ref=baseline_ref,
            suffix=suffix,
            short_horizon=short_horizon,
        )
        for suffix in suffixes
    )
    feature_names = tuple(
        portfolio_potential_primitives(
            baseline_rows[0][0],
            future_horizon=terminal_horizon - short_horizon,
        )
    )
    records = []
    for action_ref in (str(value) for value in probe["action_refs"]):
        if action_ref == baseline_ref:
            continue
        candidate_rows = tuple(
            _branch_checkpoint_and_terminal(
                probe,
                action_ref=action_ref,
                suffix=suffix,
                short_horizon=short_horizon,
            )
            for suffix in suffixes
        )
        short_advantages = []
        terminal_advantages = []
        feature_deltas = {name: [] for name in feature_names}
        for (baseline_checkpoint, baseline_terminal), (
            candidate_checkpoint,
            candidate_terminal,
        ) in zip(baseline_rows, candidate_rows):
            short_advantages.append(
                float(len(baseline_checkpoint) - len(candidate_checkpoint))
            )
            terminal_advantages.append(
                float(baseline_terminal - candidate_terminal)
            )
            baseline_features = portfolio_potential_primitives(
                baseline_checkpoint,
                future_horizon=terminal_horizon - short_horizon,
            )
            candidate_features = portfolio_potential_primitives(
                candidate_checkpoint,
                future_horizon=terminal_horizon - short_horizon,
            )
            for name in feature_names:
                feature_deltas[name].append(
                    float(baseline_features[name] - candidate_features[name])
                )
        correction = tuple(
            terminal - short
            for terminal, short in zip(terminal_advantages, short_advantages)
        )
        identity = {
            "probe_id": str(probe["probe_id"]),
            "action_ref": action_ref,
            "bank_seed": seed,
        }
        records.append(
            {
                **identity,
                "record_id": content_digest(identity),
                "instance_id": str(probe["instance_id"]),
                "length": int(probe["length"]),
                "item_index": int(probe["item_index"]),
                "terminal_horizon": terminal_horizon,
                "short_horizon": short_horizon,
                "sample_count": sample_count,
                "short_advantage": _paired_stats(
                    short_advantages, mean_critical_value=1.96, harm_z=1.96
                ),
                "terminal_advantage": _paired_stats(
                    terminal_advantages, mean_critical_value=1.96, harm_z=1.96
                ),
                "post_checkpoint_correction": _paired_stats(
                    correction, mean_critical_value=1.96, harm_z=1.96
                ),
                "mean_potential_feature_deltas": {
                    name: mean(values) for name, values in feature_deltas.items()
                },
                "short_positive_terminal_nonpositive": (
                    mean(short_advantages) > 0.0
                    and mean(terminal_advantages) <= 0.0
                ),
                "short_positive_terminal_positive": (
                    mean(short_advantages) > 0.0
                    and mean(terminal_advantages) > 0.0
                ),
                "actual_future_items_used": False,
            }
        )
    return tuple(records)


def _fit_no_intercept(
    rows: Sequence[Mapping[str, Any]], feature_names: Sequence[str], *, ridge: float = 1e-6
) -> Tuple[float, ...]:
    names = tuple(feature_names)
    if len(names) == 1:
        xx = ridge
        xy = 0.0
        for row in rows:
            x = float(row["mean_potential_feature_deltas"][names[0]])
            y = float(
                row["post_checkpoint_correction"]["mean_terminal_advantage"]
            )
            xx += x * x
            xy += x * y
        return (xy / xx,)
    if len(names) != 2:
        raise ValueError("typed potential synthesis supports one or two primitives")
    a = ridge
    b = 0.0
    d = ridge
    y0 = 0.0
    y1 = 0.0
    for row in rows:
        x0 = float(row["mean_potential_feature_deltas"][names[0]])
        x1 = float(row["mean_potential_feature_deltas"][names[1]])
        target = float(
            row["post_checkpoint_correction"]["mean_terminal_advantage"]
        )
        a += x0 * x0
        b += x0 * x1
        d += x1 * x1
        y0 += x0 * target
        y1 += x1 * target
    determinant = a * d - b * b
    return ((d * y0 - b * y1) / determinant, (a * y1 - b * y0) / determinant)


def predict_terminal_advantage(
    row: Mapping[str, Any], hypothesis: Mapping[str, Any]
) -> float:
    correction = sum(
        float(coefficient)
        * float(row["mean_potential_feature_deltas"][feature_name])
        for feature_name, coefficient in zip(
            hypothesis["feature_names"], hypothesis["coefficients"]
        )
    )
    return float(row["short_advantage"]["mean_terminal_advantage"]) + correction


def plan_probe_with_frozen_potential(
    probe: Mapping[str, Any],
    hypothesis: Mapping[str, Any],
    *,
    terminal_horizon: int,
    short_horizon: int = 96,
    sample_count: int = 128,
    bank: str = "frozen_absorptive_diversity_full_trajectory_v1",
) -> Mapping[str, Any]:
    if terminal_horizon < short_horizon:
        raise ValueError("frozen potential cannot cross the terminal boundary")
    seed, suffixes = _transport_suffix_bank(
        probe,
        bank=bank,
        sample_count=sample_count,
        terminal_horizon=short_horizon,
    )
    baseline_ref = str(probe["baseline_action_ref"])
    baseline_checkpoints = tuple(
        _branch_checkpoint_and_terminal(
            probe,
            action_ref=baseline_ref,
            suffix=suffix,
            short_horizon=short_horizon,
        )[0]
        for suffix in suffixes
    )
    candidates = []
    for order, action_ref in enumerate(str(value) for value in probe["action_refs"]):
        if action_ref == baseline_ref:
            continue
        candidate_checkpoints = tuple(
            _branch_checkpoint_and_terminal(
                probe,
                action_ref=action_ref,
                suffix=suffix,
                short_horizon=short_horizon,
            )[0]
            for suffix in suffixes
        )
        short_advantages = tuple(
            float(len(baseline) - len(candidate))
            for baseline, candidate in zip(
                baseline_checkpoints, candidate_checkpoints
            )
        )
        deltas = {name: [] for name in hypothesis["feature_names"]}
        for baseline, candidate in zip(baseline_checkpoints, candidate_checkpoints):
            baseline_features = portfolio_potential_primitives(
                baseline,
                future_horizon=terminal_horizon - short_horizon,
            )
            candidate_features = portfolio_potential_primitives(
                candidate,
                future_horizon=terminal_horizon - short_horizon,
            )
            for name in deltas:
                deltas[name].append(
                    float(baseline_features[name] - candidate_features[name])
                )
        mean_deltas = {name: mean(values) for name, values in deltas.items()}
        predicted = mean(short_advantages) + sum(
            float(coefficient) * mean_deltas[name]
            for name, coefficient in zip(
                hypothesis["feature_names"], hypothesis["coefficients"]
            )
        )
        candidates.append(
            {
                "action_ref": action_ref,
                "action_order": order,
                "short_advantage": _paired_stats(
                    short_advantages, mean_critical_value=1.96, harm_z=1.96
                ),
                "mean_potential_feature_deltas": mean_deltas,
                "predicted_terminal_advantage": predicted,
            }
        )
    selected = (
        max(
            candidates,
            key=lambda row: (
                float(row["predicted_terminal_advantage"]),
                -int(row["action_order"]),
            ),
        )
        if candidates
        else None
    )
    if selected is not None and float(selected["predicted_terminal_advantage"]) <= float(
        hypothesis["activation_threshold"]
    ):
        selected = None
    return {
        "probe_id": str(probe["probe_id"]),
        "instance_id": str(probe["instance_id"]),
        "item_index": int(probe["item_index"]),
        "terminal_horizon": terminal_horizon,
        "short_horizon": short_horizon,
        "sample_count": sample_count,
        "planning_bank_seed": seed,
        "hypothesis_id": str(hypothesis["hypothesis_id"]),
        "candidate_count": len(candidates),
        "candidates": candidates,
        "planner_activated": selected is not None,
        "selected_action": selected,
        "actual_future_items_used": False,
    }


def synthesize_typed_potential(
    records: Sequence[Mapping[str, Any]],
    *,
    folds: int = 5,
    maximum_terms: int = 2,
    activation_threshold: float = 0.02,
) -> Mapping[str, Any]:
    if maximum_terms != 2:
        raise ValueError("v1 synthesis is frozen to at most two primitives")
    feature_names = tuple(sorted(records[0]["mean_potential_feature_deltas"]))
    candidate_features = tuple((name,) for name in feature_names) + tuple(
        (left, right)
        for left_index, left in enumerate(feature_names)
        for right in feature_names[left_index + 1 :]
    )
    fold_by_episode = {
        str(row["instance_id"]): int(
            content_digest({"episode": row["instance_id"], "folds": folds})[:8], 16
        )
        % folds
        for row in records
    }
    candidates = []
    baseline_squared_errors = tuple(
        (
            float(row["short_advantage"]["mean_terminal_advantage"])
            - float(row["terminal_advantage"]["mean_terminal_advantage"])
        )
        ** 2
        for row in records
    )
    for names in candidate_features:
        predictions = [0.0] * len(records)
        fold_coefficients = []
        for fold in range(folds):
            training = tuple(
                row
                for row in records
                if fold_by_episode[str(row["instance_id"])] != fold
            )
            coefficients = _fit_no_intercept(training, names)
            fold_coefficients.append(list(coefficients))
            for index, row in enumerate(records):
                if fold_by_episode[str(row["instance_id"])] != fold:
                    continue
                predictions[index] = float(
                    row["short_advantage"]["mean_terminal_advantage"]
                ) + sum(
                    coefficient
                    * float(row["mean_potential_feature_deltas"][name])
                    for name, coefficient in zip(names, coefficients)
                )
        squared_errors = tuple(
            (
                prediction
                - float(row["terminal_advantage"]["mean_terminal_advantage"])
            )
            ** 2
            for prediction, row in zip(predictions, records)
        )
        candidates.append(
            {
                "feature_names": list(names),
                "fold_coefficients": fold_coefficients,
                "oof_mse": mean(squared_errors),
                "oof_mse_improvement_fraction_over_short_only": (
                    1.0 - mean(squared_errors) / mean(baseline_squared_errors)
                    if mean(baseline_squared_errors) > 0.0
                    else 0.0
                ),
            }
        )
    best = min(
        candidates,
        key=lambda row: (float(row["oof_mse"]), len(row["feature_names"]), row["feature_names"]),
    )
    final_coefficients = _fit_no_intercept(records, best["feature_names"])
    body = {
        "schema": 1,
        "version": HORIZON_TRANSPORT_POTENTIAL_VERSION,
        "program_kind": "typed_residual_portfolio_potential",
        "semantic_name": "pending_codex_abductive_interpretation",
        "feature_names": list(best["feature_names"]),
        "coefficients": list(final_coefficients),
        "activation_threshold": activation_threshold,
        "development_record_count": len(records),
        "development_episode_count": len({str(row["instance_id"]) for row in records}),
        "cross_fit_folds": folds,
        "candidate_program_count": len(candidates),
        "selected_cross_fit_diagnostics": best,
        "short_only_oof_mse": mean(baseline_squared_errors),
        "actual_future_items_used_as_features": False,
        "incumbent_code_or_score_exposed_to_program_synthesis": False,
    }
    body["hypothesis_id"] = content_digest(body)
    return body


def assess_frozen_potential(
    records: Sequence[Mapping[str, Any]],
    hypothesis: Mapping[str, Any],
    *,
    minimum_mse_improvement_fraction: float = 0.02,
    minimum_persistence_accuracy_improvement: float = 0.05,
    minimum_selected_episodes: int = 50,
) -> Mapping[str, Any]:
    predictions = tuple(predict_terminal_advantage(row, hypothesis) for row in records)
    outcomes = tuple(
        float(row["terminal_advantage"]["mean_terminal_advantage"])
        for row in records
    )
    short_predictions = tuple(
        float(row["short_advantage"]["mean_terminal_advantage"])
        for row in records
    )
    baseline_mse = mean((x - y) ** 2 for x, y in zip(short_predictions, outcomes))
    model_mse = mean((x - y) ** 2 for x, y in zip(predictions, outcomes))
    relevant = tuple(
        index
        for index, value in enumerate(short_predictions)
        if value > float(hypothesis["activation_threshold"])
    )
    baseline_accuracy = (
        sum(outcomes[index] > 0.0 for index in relevant) / float(len(relevant))
        if relevant
        else 0.0
    )
    model_accuracy = (
        sum((predictions[index] > 0.0) == (outcomes[index] > 0.0) for index in relevant)
        / float(len(relevant))
        if relevant
        else 0.0
    )
    by_episode: Dict[str, list[int]] = {}
    for index, row in enumerate(records):
        by_episode.setdefault(str(row["instance_id"]), []).append(index)
    selected = []
    for episode_id, indices in sorted(by_episode.items()):
        eligible = tuple(
            index
            for index in indices
            if predictions[index] > float(hypothesis["activation_threshold"])
        )
        if not eligible:
            continue
        index = max(eligible, key=lambda value: (predictions[value], -value))
        selected.append((episode_id, index))
    selected_values = tuple(outcomes[index] for _, index in selected)
    evidence = (
        None
        if len(selected) < 2
        else paired_episode_evidence(
            selected_values, tuple(episode_id for episode_id, _ in selected)
        ).as_dict()
    )
    by_length = {}
    for length in sorted({int(row["length"]) for row in records}):
        length_values = tuple(
            outcomes[index]
            for _, index in selected
            if int(records[index]["length"]) == length
        )
        by_length[str(length)] = {
            "selected_episode_count": len(length_values),
            "mean_expected_terminal_advantage": (
                mean(length_values) if length_values else 0.0
            ),
        }
    mse_improvement = 1.0 - model_mse / baseline_mse if baseline_mse > 0.0 else 0.0
    accuracy_improvement = model_accuracy - baseline_accuracy
    gates = {
        "terminal_prediction_mse_improvement_minimum": (
            mse_improvement >= minimum_mse_improvement_fraction
        ),
        "persistence_sign_accuracy_improvement_minimum": (
            accuracy_improvement >= minimum_persistence_accuracy_improvement
        ),
        "selected_episode_count_minimum": len(selected) >= minimum_selected_episodes,
        "selected_expected_terminal_advantage_95_percent_ci_lower_positive": (
            evidence is not None and float(evidence["mean_improvement_ci_lower"]) > 0.0
        ),
        "mean_selected_terminal_advantage_each_length_nonnegative": all(
            row["mean_expected_terminal_advantage"] >= 0.0
            for row in by_length.values()
        ),
    }
    body = {
        "schema": 1,
        "version": HORIZON_TRANSPORT_POTENTIAL_VERSION,
        "hypothesis_id": str(hypothesis["hypothesis_id"]),
        "validation_record_count": len(records),
        "validation_episode_count": len(by_episode),
        "short_only_terminal_prediction_mse": baseline_mse,
        "frozen_potential_terminal_prediction_mse": model_mse,
        "terminal_prediction_mse_improvement_fraction": mse_improvement,
        "short_positive_record_count": len(relevant),
        "short_only_persistence_sign_accuracy": baseline_accuracy,
        "frozen_potential_persistence_sign_accuracy": model_accuracy,
        "persistence_sign_accuracy_improvement": accuracy_improvement,
        "selected_episode_count": len(selected),
        "selected_expected_terminal_evidence": evidence,
        "by_length": by_length,
        "gates": gates,
        "typed_potential_validation_passed": all(gates.values()),
    }
    body["assessment_id"] = content_digest(body)
    return body
