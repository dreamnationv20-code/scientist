from __future__ import annotations

from scientist.program.literature_grounding import LiteratureMechanismVocabulary


BINPACKING_LITERATURE_VOCABULARY = LiteratureMechanismVocabulary(
    mechanism_terms={
        "tight_fit_priority": (
            "tight fit", "tight-fit", "exact fill", "best fit", "priority function",
        ),
        "parameterized_score_evolution": (
            "parameterized score", "score matrix", "policy matrix",
            "program evolution", "heuristic generation", "program search",
        ),
        "predictive_profile_reservation": (
            "with predictions", "predicted item", "frequency profile",
            "reservation", "forecast",
        ),
        "adaptive_pattern_memory": (
            "pattern based", "pattern-based", "historical item",
            "history-derived", "distribution estimation", "packing pattern",
        ),
        "state_conditioned_policy_selection": (
            "state dependent selector", "state-dependent selector",
            "policy selection", "selection hyper", "policy portfolio", "routing",
        ),
        "counterfactual_lookahead": (
            "counterfactual", "lookahead", "rollout", "scenario rollout",
            "model predictive control", "counterfactual regret",
            "one-step deviation", "alternative action",
        ),
        "option_preservation": (
            "preserve", "protected option", "residual option",
            "capacity reservation", "complement demand",
        ),
        "change_detection": (
            "change detection", "abrupt distribution", "nonstationary",
            "regime shift", "recent trend", "state feedback",
            "adaptive control", "hidden disturbances",
        ),
        "uncertainty_robustness": (
            "robust fallback", "robustness", "safe policy improvement",
            "baseline bootstrapping", "selective prediction", "abstention",
            "future demand", "unavailable information", "hidden future",
        ),
        "calibrated_override_value": (
            "action value", "pairwise advantage", "baseline action",
            "preference learning", "strict improvement",
            "offline policy improvement", "confidence calibration",
            "learning to defer", "selective policy", "counterfactual policy",
            "counterfactual action value", "safe intervention",
            "selective intervention", "episode return", "nested validation",
            "causal state abstraction", "distribution shift",
        ),
        "failure_syndrome_intervention": (
            "failure syndrome", "error correcting", "error-correcting",
            "sparse repair", "guarded override",
        ),
    },
    contrastive_frontier={
        "tight_fit_priority": ("option_preservation",),
        "parameterized_score_evolution": ("state_conditioned_policy_selection",),
        "predictive_profile_reservation": (
            "change_detection", "uncertainty_robustness",
        ),
        "adaptive_pattern_memory": ("change_detection", "uncertainty_robustness"),
        "state_conditioned_policy_selection": ("failure_syndrome_intervention",),
        "counterfactual_lookahead": ("calibrated_override_value",),
        "uncertainty_robustness": ("calibrated_override_value",),
    },
    vocabulary_ref="binpacking-literature-mechanism-vocabulary-v1",
    channel_exclusions={"de_novo": ("tight_fit_priority",)},
)
