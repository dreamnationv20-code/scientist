from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Tuple


@dataclass(frozen=True)
class BinPackingInstance:
    instance_id: str
    family: str
    seed: int
    capacity: int
    items: Tuple[int, ...]

    def __post_init__(self) -> None:
        if self.capacity <= 0:
            raise ValueError("capacity must be positive")
        if not self.items:
            raise ValueError("items must not be empty")
        if any(item <= 0 or item > self.capacity for item in self.items):
            raise ValueError("every item must be in [1, capacity]")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "instance_id": self.instance_id,
            "family": self.family,
            "seed": self.seed,
            "capacity": self.capacity,
            "items": list(self.items),
        }


@dataclass(frozen=True)
class Placement:
    item_index: int
    item: int
    bin_index: int
    loads_after: Tuple[int, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "item_index": self.item_index,
            "item": self.item,
            "bin_index": self.bin_index,
            "loads_after": list(self.loads_after),
        }


@dataclass(frozen=True)
class PackingResult:
    heuristic: str
    instance_id: str
    bin_count: int
    placements: Tuple[Placement, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "heuristic": self.heuristic,
            "instance_id": self.instance_id,
            "bin_count": self.bin_count,
            "placements": [placement.as_dict() for placement in self.placements],
        }

