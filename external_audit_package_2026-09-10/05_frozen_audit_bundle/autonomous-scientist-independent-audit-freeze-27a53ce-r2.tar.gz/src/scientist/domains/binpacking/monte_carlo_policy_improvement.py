from __future__ import annotations

import math
import random
from statistics import mean, stdev
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import (
    GenesisConfig,
    GenesisPartition,
    _action_ref,
    _apply_action,
    _parse_action,
    _percentile,
    _probe_indices,
    _terminal_after_synthetic_suffix,
    genesis_suite,
    representative_actions,
)
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.program.discovery_evidence import paired_episode_evidence


MONTE_CARLO_POLICY_IMPROVEMENT_VERSION = (
    "selector-free-double-sampled-monte-carlo-policy-improvement-v1"
)


def build_funsearch_state_atlas(
    config: GenesisConfig,
    partition: GenesisPartition,
) -> Mapping[str, Any]:
    """Record observable FunSearch states and actions without outcome labels."""

    baseline = literature_heuristics()["funsearch_or_reference"]
    instances = genesis_suite(config, partition)
    probes = []
    for instance in instances:
        selected_indices = set(_probe_indices(config, len(instance.items)))
        loads: Tuple[int, ...] = ()
        history: Tuple[int, ...] = ()
        for item_index, item in enumerate(instance.items):
            baseline_action = baseline.choose_bin(
                item, loads, instance.capacity, item_index, history
            )
            if item_index in selected_indices:
                actions = representative_actions(
                    item,
                    loads,
                    instance.capacity,
                    baseline_action,
                    config.maximum_action_representatives,
                )
                body = {
                    "partition": partition.name,
                    "instance_id": instance.instance_id,
                    "length": len(instance.items),
                    "seed": instance.seed,
                    "item_index": item_index,
                    "item": item,
                    "loads": list(loads),
                    "history": list(history[-128:]),
                    "baseline_action_ref": _action_ref(baseline_action),
                    "action_refs": [_action_ref(action) for action in actions],
                    "actual_future_items_stored": False,
                    "outcome_labels_stored": False,
                }
                body["probe_id"] = content_digest(body)
                probes.append(body)
            loads = _apply_action(
                baseline_action, item, loads, instance.capacity
            )
            history = (*history, item)[-128:]
    body: Dict[str, Any] = {
        "schema": 1,
        "version": MONTE_CARLO_POLICY_IMPROVEMENT_VERSION,
        "partition": partition.name,
        "config": config.as_dict(),
        "partition_config": {
            "seed_offset": partition.seed_offset,
            "episodes_per_length": partition.episodes_per_length,
        },
        "trajectory_policy": "funsearch_or_reference",
        "instance_count": len(instances),
        "probe_count": len(probes),
        "action_ref_count": sum(len(probe["action_refs"]) for probe in probes),
        "actual_future_items_stored": False,
        "outcome_labels_stored": False,
        "episode_seed_commitment": content_digest(
            [(len(instance.items), instance.seed) for instance in instances]
        ),
        "probes": probes,
    }
    body["atlas_id"] = content_digest(body)
    return body


def _suffix_bank(
    probe: Mapping[str, Any],
    *,
    bank: str,
    sample_count: int,
    suffix_horizon: int,
) -> Tuple[int, Tuple[Tuple[int, ...], ...]]:
    material = {
        "version": MONTE_CARLO_POLICY_IMPROVEMENT_VERSION,
        "probe_id": probe["probe_id"],
        "bank": bank,
        "sample_count": sample_count,
        "suffix_horizon": suffix_horizon,
    }
    seed = int(content_digest(material)[:16], 16)
    rng = random.Random(seed)
    suffixes = tuple(
        tuple(rng.randint(20, 100) for _ in range(suffix_horizon))
        for _ in range(sample_count)
    )
    return seed, suffixes


def _outcomes(
    probe: Mapping[str, Any],
    action_ref: str,
    suffixes: Sequence[Sequence[int]],
) -> Tuple[int, ...]:
    continuation = literature_heuristics()["funsearch_or_reference"]
    return tuple(
        _terminal_after_synthetic_suffix(
            item=int(probe["item"]),
            item_index=int(probe["item_index"]),
            loads=tuple(int(value) for value in probe["loads"]),
            history=tuple(int(value) for value in probe["history"]),
            capacity=150,
            action=_parse_action(action_ref),
            suffix=suffix,
            continuation=continuation,
        )
        for suffix in suffixes
    )


def _wilson_upper(success_count: int, sample_count: int, *, z: float) -> float:
    if sample_count <= 0 or not 0 <= success_count <= sample_count:
        raise ValueError("invalid Wilson interval inputs")
    probability = success_count / float(sample_count)
    denominator = 1.0 + z * z / sample_count
    center = (probability + z * z / (2.0 * sample_count)) / denominator
    radius = (
        z
        * math.sqrt(
            probability * (1.0 - probability) / sample_count
            + z * z / (4.0 * sample_count * sample_count)
        )
        / denominator
    )
    return min(1.0, center + radius)


def _paired_stats(
    paired: Sequence[float], *, mean_critical_value: float, harm_z: float
) -> Mapping[str, Any]:
    if len(paired) < 2:
        raise ValueError("Monte Carlo action credit needs repeated suffixes")
    center = mean(paired)
    standard_error = stdev(paired) / math.sqrt(len(paired))
    harmful_count = sum(value < 0.0 for value in paired)
    return {
        "sample_count": len(paired),
        "mean_terminal_advantage": center,
        "standard_error": standard_error,
        "mean_ci_lower": center - mean_critical_value * standard_error,
        "mean_ci_upper": center + mean_critical_value * standard_error,
        "helpful_suffix_count": sum(value > 0.0 for value in paired),
        "neutral_suffix_count": sum(value == 0.0 for value in paired),
        "harmful_suffix_count": harmful_count,
        "harmful_suffix_rate": harmful_count / float(len(paired)),
        "harmful_suffix_rate_wilson_upper": _wilson_upper(
            harmful_count, len(paired), z=harm_z
        ),
    }


def evaluate_probe_with_double_sampling(
    probe: Mapping[str, Any],
    *,
    planning_sample_count: int = 256,
    audit_sample_count: int = 256,
    suffix_horizon: int = 96,
    planning_mean_critical_value: float = 3.0,
    planning_harm_z: float = 3.0,
    maximum_planning_harm_rate_upper: float = 0.40,
) -> Mapping[str, Any]:
    """Choose on one scenario bank and audit on a disjoint scenario bank."""

    baseline_ref = str(probe["baseline_action_ref"])
    action_refs = tuple(str(value) for value in probe["action_refs"])
    if baseline_ref not in action_refs:
        raise ValueError("FunSearch baseline action is absent from the action set")
    planning_seed, planning_suffixes = _suffix_bank(
        probe,
        bank="planning",
        sample_count=planning_sample_count,
        suffix_horizon=suffix_horizon,
    )
    baseline_outcomes = _outcomes(probe, baseline_ref, planning_suffixes)
    candidates = []
    for order, action_ref in enumerate(action_refs):
        if action_ref == baseline_ref:
            continue
        action_outcomes = _outcomes(probe, action_ref, planning_suffixes)
        paired = tuple(
            float(baseline_value - action_value)
            for baseline_value, action_value in zip(
                baseline_outcomes, action_outcomes
            )
        )
        stats = _paired_stats(
            paired,
            mean_critical_value=planning_mean_critical_value,
            harm_z=planning_harm_z,
        )
        candidates.append(
            {
                "action_ref": action_ref,
                "action_order": order,
                **stats,
            }
        )
    selected: Optional[Mapping[str, Any]] = None
    if candidates:
        best = max(
            candidates,
            key=lambda row: (
                float(row["mean_terminal_advantage"]),
                -int(row["action_order"]),
            ),
        )
        if (
            float(best["mean_ci_lower"]) > 0.0
            and float(best["harmful_suffix_rate_wilson_upper"])
            <= maximum_planning_harm_rate_upper
        ):
            selected = best
    result: Dict[str, Any] = {
        "probe_id": probe["probe_id"],
        "instance_id": probe["instance_id"],
        "length": probe["length"],
        "item_index": probe["item_index"],
        "baseline_action_ref": baseline_ref,
        "planning_bank_seed": planning_seed,
        "planning_sample_count": planning_sample_count,
        "planning_suffix_horizon": suffix_horizon,
        "planning_common_random_numbers_across_actions": True,
        "learned_selector_used": False,
        "latent_concept_used": False,
        "candidate_action_count": len(candidates),
        "planning_candidates": candidates,
        "selected_action_ref": (
            None if selected is None else selected["action_ref"]
        ),
        "planner_activated": selected is not None,
        "audit": None,
    }
    if selected is None:
        return result
    audit_seed, audit_suffixes = _suffix_bank(
        probe,
        bank="independent_audit",
        sample_count=audit_sample_count,
        suffix_horizon=suffix_horizon,
    )
    if audit_seed == planning_seed:
        raise RuntimeError("planning and audit scenario banks are not independent")
    audit_baseline = _outcomes(probe, baseline_ref, audit_suffixes)
    audit_selected = _outcomes(
        probe, str(selected["action_ref"]), audit_suffixes
    )
    audit_paired = tuple(
        float(baseline_value - selected_value)
        for baseline_value, selected_value in zip(audit_baseline, audit_selected)
    )
    audit_stats = _paired_stats(
        audit_paired, mean_critical_value=1.96, harm_z=1.96
    )
    result["audit"] = {
        "audit_bank_seed": audit_seed,
        "audit_bank_independent_of_planning": True,
        "planning_bank_reused_for_evaluation": False,
        "rollout_suffixes_counted_as_independent_evidence": False,
        **audit_stats,
        "paired_rollout_advantages": list(audit_paired),
    }
    return result


def _cluster_bootstrap_harmful_rate_upper(
    results: Sequence[Mapping[str, Any]],
    episode_ids: Sequence[str],
    *,
    seed: int = 948_104_026,
    draws: int = 5_000,
) -> float:
    by_episode: Dict[str, list[Mapping[str, Any]]] = {
        str(episode_id): [] for episode_id in episode_ids
    }
    for result in results:
        if result["planner_activated"]:
            by_episode[str(result["instance_id"])].append(result)
    independent_ids = sorted(by_episode)
    rng = random.Random(seed)
    samples = []
    for _ in range(draws):
        sampled_ids = tuple(
            independent_ids[rng.randrange(len(independent_ids))]
            for _ in independent_ids
        )
        selected = tuple(
            result
            for episode_id in sampled_ids
            for result in by_episode[episode_id]
        )
        if not selected:
            samples.append(0.0)
            continue
        samples.append(
            sum(
                float(result["audit"]["mean_terminal_advantage"]) < 0.0
                for result in selected
            )
            / float(len(selected))
        )
    return _percentile(tuple(sorted(samples)), 0.99)


def summarize_double_sampled_evaluation(
    atlas: Mapping[str, Any],
    results: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    if len(results) != len(atlas["probes"]):
        raise ValueError("planner result count does not match the state atlas")
    aligned = tuple(
        str(result["probe_id"]) == str(probe["probe_id"])
        for result, probe in zip(results, atlas["probes"])
    )
    if not all(aligned):
        raise ValueError("planner results do not align with state atlas probes")
    episode_lengths = {
        str(probe["instance_id"]): int(probe["length"])
        for probe in atlas["probes"]
    }
    episode_ids = sorted(episode_lengths)
    by_episode = {episode_id: 0.0 for episode_id in episode_ids}
    activated = tuple(result for result in results if result["planner_activated"])
    for result in activated:
        by_episode[str(result["instance_id"])] += float(
            result["audit"]["mean_terminal_advantage"]
        )
    evidence = paired_episode_evidence(
        tuple(by_episode[episode_id] for episode_id in episode_ids), episode_ids
    )
    by_length = {}
    for length in sorted(set(episode_lengths.values())):
        ids = tuple(
            episode_id
            for episode_id in episode_ids
            if episode_lengths[episode_id] == length
        )
        by_length[str(length)] = {
            "episode_count": len(ids),
            "mean_expected_bins_saved_per_episode": mean(
                by_episode[episode_id] for episode_id in ids
            ),
            "activation_count": sum(
                result["planner_activated"]
                and int(result["length"]) == length
                for result in results
            ),
        }
    harmful_upper = _cluster_bootstrap_harmful_rate_upper(
        results, episode_ids
    )
    gates = {
        "activation_count_minimum_100": len(activated) >= 100,
        "selected_expected_return_95_percent_ci_lower_positive": (
            evidence.mean_ci_lower > 0.0
        ),
        "harmful_action_rate_cluster_bootstrap_99_percent_upper_at_most_0_40": (
            harmful_upper <= 0.40
        ),
        "mean_expected_bins_saved_each_length_nonnegative": all(
            row["mean_expected_bins_saved_per_episode"] >= 0.0
            for row in by_length.values()
        ),
    }
    body = {
        "version": MONTE_CARLO_POLICY_IMPROVEMENT_VERSION,
        "state_atlas_id": atlas["atlas_id"],
        "episode_count": len(episode_ids),
        "probe_count": len(results),
        "activation_count": len(activated),
        "helpful_audit_action_count": sum(
            float(result["audit"]["mean_terminal_advantage"]) > 0.0
            for result in activated
        ),
        "neutral_audit_action_count": sum(
            float(result["audit"]["mean_terminal_advantage"]) == 0.0
            for result in activated
        ),
        "harmful_audit_action_count": sum(
            float(result["audit"]["mean_terminal_advantage"]) < 0.0
            for result in activated
        ),
        "harmful_audit_action_rate": (
            sum(
                float(result["audit"]["mean_terminal_advantage"]) < 0.0
                for result in activated
            )
            / float(len(activated))
            if activated
            else 0.0
        ),
        "harmful_action_rate_episode_cluster_bootstrap_99_percent_upper": (
            harmful_upper
        ),
        "selected_expected_counterfactual_return": evidence.as_dict(),
        "by_length": by_length,
        "learned_selector_used": False,
        "latent_concept_used": False,
        "planning_and_audit_banks_disjoint": all(
            result["audit"] is None
            or result["planning_bank_seed"] != result["audit"]["audit_bank_seed"]
            for result in results
        ),
        "gates": gates,
        "isolated_policy_improvement_passed": all(gates.values()),
    }
    body["assessment_id"] = content_digest(body)
    return body
