from __future__ import annotations

import argparse
import json
import math
import random
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.binpacking.adversary import (
    AdversaryConfig,
    AdversarialSequenceRecord,
    evolve_adversarial_sequences,
)
from scientist.domains.binpacking.generators import (
    GENERATORS,
    generate_instance,
)
from scientist.domains.binpacking.heuristics import (
    FunSearchORReference,
    OnlineHeuristic,
    baseline_heuristics,
    pack,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.orlib import (
    corpus_digest,
    load_orlib_corpus,
)
from scientist.domains.binpacking.programs import (
    FunSearchResidualProgram,
    MoonshotHybridProgram,
    program_from_dict,
)


VALIDATION_VERSION = "binpacking-frozen-novelty-validation-v1"
FROZEN_SUMMARY_DIGEST = (
    "7bccb5ba44c0aa688cde5b60c057b50c5cd57527a6e06ecf1bf3899209ebfde4"
)
FROZEN_PROGRAM_ID = (
    "ae5af2b8c3820fcc43810339b953ddece552e77ec53cd5445faec4d241702667"
)
FROZEN_CAPACITY = 150
FRESH_SEED_BASE = 1_000_000_000
IID_LENGTHS = (60, 120, 250, 500, 1000)
IID_SEEDS_PER_CELL = 64
TRANSITION_SEEDS_PER_PAIR = 20
ORLIB_PERMUTATIONS = 10
ADVERSARY_SEEDS_PER_DIRECTION = 6
ADVERSARY_BUDGET = 256
ADVERSARY_LENGTH = 250


@dataclass(frozen=True)
class SumOfSquaresHeuristic:
    """Published SS rule: minimize the squared residual-profile counts."""

    name: str = "sum_of_squares"

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        del item_index, history
        gap_counts = Counter(
            capacity - load
            for load in loads
            if 0 < capacity - load < capacity
        )
        newest_index_by_gap = {
            capacity - load: index
            for index, load in enumerate(loads)
            if load + item <= capacity
        }
        actions: Tuple[Optional[int], ...] = (
            *tuple(newest_index_by_gap.values()),
            None,
        )

        def increase(action: Optional[int]) -> int:
            if action is None:
                new_gap = capacity - item
                return (
                    0
                    if new_gap == 0
                    else 2 * gap_counts[new_gap] + 1
                )
            old_gap = capacity - loads[action]
            new_gap = old_gap - item
            delta = -2 * gap_counts[old_gap] + 1
            if new_gap > 0:
                delta += 2 * gap_counts[new_gap] + 1
            return delta

        def tie_key(action: Optional[int]) -> Tuple[int, int, int]:
            level = 0 if action is None else loads[action]
            newest = len(loads) if action is None else action
            return (increase(action), -level, -newest)

        return min(actions, key=tie_key)


def _one_sided_sign_p(wins: int, losses: int) -> float:
    trials = wins + losses
    if trials == 0:
        return 1.0
    logarithms = [
        (
            math.lgamma(trials + 1)
            - math.lgamma(successes + 1)
            - math.lgamma(trials - successes + 1)
        )
        for successes in range(wins, trials + 1)
    ]
    maximum = max(logarithms)
    log_probability = (
        maximum
        + math.log(sum(math.exp(value - maximum) for value in logarithms))
        - trials * math.log(2.0)
    )
    return min(1.0, math.exp(log_probability))


def _paired_summary(deltas: Sequence[int]) -> Dict[str, Any]:
    if not deltas:
        raise ValueError("paired summary requires at least one delta")
    wins = sum(delta < 0 for delta in deltas)
    losses = sum(delta > 0 for delta in deltas)
    return {
        "case_count": len(deltas),
        "primary_delta": sum(deltas),
        "mean_primary_delta": mean(deltas),
        "wins": wins,
        "losses": losses,
        "ties": len(deltas) - wins - losses,
        "maximum_regression": max(deltas),
        "maximum_improvement": -min(deltas),
        "one_sided_sign_p": _one_sided_sign_p(wins, losses),
    }


def _trace_frozen_candidate(
    instance: BinPackingInstance,
    candidate: MoonshotHybridProgram,
    fallback: FunSearchResidualProgram,
) -> Dict[str, int]:
    loads = []
    history = []
    activations = 0
    disagreements = 0
    for item_index, item in enumerate(instance.items):
        loads_before = tuple(loads)
        history_before = tuple(history)
        activation = candidate.moonshot.activation(
            item,
            loads_before,
            instance.capacity,
            history_before,
        )
        fallback_action = fallback.choose_bin(
            item,
            loads_before,
            instance.capacity,
            item_index,
            history_before,
        )
        if activation >= candidate.gate_threshold:
            activations += 1
            action = candidate.moonshot.choose_bin(
                item,
                loads_before,
                instance.capacity,
                item_index,
                history_before,
            )
            disagreements += action != fallback_action
        else:
            action = fallback_action
        if action is None:
            loads.append(item)
        else:
            loads[action] += item
        history.append(item)
    return {
        "decisions": len(instance.items),
        "activations": activations,
        "action_disagreements": disagreements,
        "bin_count": len(loads),
    }


def _compare_suite(
    instances: Sequence[BinPackingInstance],
    algorithms: Mapping[str, OnlineHeuristic],
    *,
    baseline_name: str,
    traced_candidate: Optional[MoonshotHybridProgram] = None,
    traced_fallback: Optional[FunSearchResidualProgram] = None,
) -> Dict[str, Any]:
    if baseline_name not in algorithms:
        raise ValueError("baseline is not present in algorithm portfolio")
    totals = Counter()
    deltas_by_algorithm: Dict[str, list[int]] = {
        name: [] for name in algorithms if name != baseline_name
    }
    frozen_by_family: Dict[str, list[int]] = defaultdict(list)
    frozen_by_length: Dict[int, list[int]] = defaultdict(list)
    observations = []
    trace_totals = Counter()

    for instance in instances:
        trace = None
        if traced_candidate is not None and traced_fallback is not None:
            trace = _trace_frozen_candidate(
                instance,
                traced_candidate,
                traced_fallback,
            )
        counts = {}
        for name, algorithm in algorithms.items():
            counts[name] = (
                trace["bin_count"]
                if name == "frozen_candidate" and trace is not None
                else pack(instance, algorithm).bin_count
            )
        for name, count in counts.items():
            totals[name] += count
        baseline_count = counts[baseline_name]
        for name in deltas_by_algorithm:
            delta = counts[name] - baseline_count
            deltas_by_algorithm[name].append(delta)
            if name == "frozen_candidate":
                frozen_by_family[instance.family].append(delta)
                frozen_by_length[len(instance.items)].append(delta)
        if "frozen_candidate" in counts:
            observations.append(
                {
                    "instance_id": instance.instance_id,
                    "family": instance.family,
                    "seed": instance.seed,
                    "length": len(instance.items),
                    "candidate_bins": counts["frozen_candidate"],
                    "funsearch_bins": baseline_count,
                    "primary_delta": (
                        counts["frozen_candidate"] - baseline_count
                    ),
                }
            )
        if trace is not None:
            if trace["bin_count"] != counts["frozen_candidate"]:
                raise AssertionError("candidate trace disagrees with packer")
            trace_totals.update(trace)

    report: Dict[str, Any] = {
        "suite_digest": content_digest(
            [instance.as_dict() for instance in instances]
        ),
        "case_count": len(instances),
        "algorithm_total_bins": dict(sorted(totals.items())),
        "paired_against_funsearch": {
            name: _paired_summary(deltas)
            for name, deltas in sorted(deltas_by_algorithm.items())
        },
        "frozen_candidate_by_family": {
            family: _paired_summary(deltas)
            for family, deltas in sorted(frozen_by_family.items())
        },
        "frozen_candidate_by_length": {
            str(length): _paired_summary(deltas)
            for length, deltas in sorted(frozen_by_length.items())
        },
        "observations": observations,
    }
    if trace_totals:
        report["intervention_trace"] = {
            **dict(trace_totals),
            "activation_fraction": (
                trace_totals["activations"]
                / float(trace_totals["decisions"])
            ),
            "action_disagreement_fraction": (
                trace_totals["action_disagreements"]
                / float(trace_totals["decisions"])
            ),
            "conditional_disagreement_fraction": (
                trace_totals["action_disagreements"]
                / float(max(1, trace_totals["activations"]))
            ),
        }
    return report


def _fresh_iid_suite() -> Tuple[BinPackingInstance, ...]:
    families = tuple(sorted(GENERATORS))
    return tuple(
        generate_instance(
            family,
            (
                FRESH_SEED_BASE
                + length_index * 10_000_000
                + family_index * 100_000
                + offset
            ),
            length,
            FROZEN_CAPACITY,
        )
        for length_index, length in enumerate(IID_LENGTHS)
        for family_index, family in enumerate(families)
        for offset in range(IID_SEEDS_PER_CELL)
    )


def _standalone_ablation_suite(
    iid_suite: Sequence[BinPackingInstance],
) -> Tuple[BinPackingInstance, ...]:
    seen = Counter()
    selected = []
    for instance in iid_suite:
        length = len(instance.items)
        limit = 8 if length == 60 else 4 if length == 120 else 0
        cell = (instance.family, length)
        if seen[cell] < limit:
            selected.append(instance)
            seen[cell] += 1
    if len(selected) != len(GENERATORS) * 12:
        raise AssertionError("standalone ablation suite has the wrong size")
    return tuple(selected)


def _transition_suite() -> Tuple[BinPackingInstance, ...]:
    families = tuple(sorted(GENERATORS))
    instances = []
    pair_index = 0
    for source in families:
        for target in families:
            if source == target:
                continue
            for offset in range(TRANSITION_SEEDS_PER_PAIR):
                seed = FRESH_SEED_BASE + 100_000_000 + pair_index * 10_000 + offset
                first = generate_instance(
                    source,
                    seed,
                    200,
                    FROZEN_CAPACITY,
                )
                second = generate_instance(
                    target,
                    seed + 5_000_000,
                    200,
                    FROZEN_CAPACITY,
                )
                items = (*first.items, *second.items)
                instances.append(
                    BinPackingInstance(
                        instance_id=content_digest(
                            {
                                "validation_version": VALIDATION_VERSION,
                                "kind": "abrupt_transition",
                                "source": source,
                                "target": target,
                                "seed": seed,
                                "items": list(items),
                            }
                        )[:20],
                        family="transition:%s->%s" % (source, target),
                        seed=seed,
                        capacity=FROZEN_CAPACITY,
                        items=items,
                    )
                )
            pair_index += 1
    return tuple(instances)


def _orlib_permutation_suite(
    orlib_root: Path,
) -> Tuple[Tuple[BinPackingInstance, ...], str]:
    records = load_orlib_corpus(orlib_root)
    instances = []
    for record_index, record in enumerate(records):
        for permutation_index in range(ORLIB_PERMUTATIONS):
            seed = (
                FRESH_SEED_BASE
                + 200_000_000
                + record_index * 1_000
                + permutation_index
            )
            items = list(record.instance.items)
            random.Random(seed).shuffle(items)
            instances.append(
                BinPackingInstance(
                    instance_id=content_digest(
                        {
                            "validation_version": VALIDATION_VERSION,
                            "kind": "orlib_permutation",
                            "source_instance_id": (
                                record.instance.instance_id
                            ),
                            "permutation_seed": seed,
                            "items": items,
                        }
                    )[:20],
                    family="orlib_permuted:%s" % record.source_file,
                    seed=seed,
                    capacity=record.instance.capacity,
                    items=tuple(items),
                )
            )
    return tuple(instances), corpus_digest(records)


def _top_adversaries(
    records: Iterable[AdversarialSequenceRecord],
    count: int = 12,
) -> Sequence[Mapping[str, Any]]:
    ranked = sorted(
        records,
        key=lambda record: (
            record.target_gap,
            record.fitness,
            record.instance.instance_id,
        ),
        reverse=True,
    )
    return [
        {
            "instance": record.instance.as_dict(),
            "target_gap": record.target_gap,
            "target_bin_count": record.target_bin_count,
            "comparator_bin_count": record.comparator_bin_count,
            "operator": record.operator,
            "parent_ids": list(record.parent_ids),
        }
        for record in ranked[:count]
    ]


def _adversarial_direction(
    *,
    direction_index: int,
    target: OnlineHeuristic,
    comparator: OnlineHeuristic,
) -> Dict[str, Any]:
    outcomes = []
    records = []
    for offset in range(ADVERSARY_SEEDS_PER_DIRECTION):
        config = AdversaryConfig(
            seed=(
                FRESH_SEED_BASE
                + 300_000_000
                + direction_index * 1_000_000
                + offset
            ),
            evaluation_budget=ADVERSARY_BUDGET,
            initial_population=32,
            length=ADVERSARY_LENGTH,
            capacity=FROZEN_CAPACITY,
            minimum_item=20,
            maximum_item=100,
            mean_tolerance_fraction=0.12,
        )
        outcome = evolve_adversarial_sequences(
            config,
            target,
            comparator,
        )
        outcomes.append(
            {
                "config": config.as_dict(),
                "evaluated_count": len(outcome.evaluated),
                "archive_size": len(outcome.archive),
                "best_target_gap": outcome.best.target_gap,
                "best_instance_id": outcome.best.instance.instance_id,
            }
        )
        records.extend(outcome.evaluated)
    gaps = [record.target_gap for record in records]
    return {
        "target": target.name,
        "comparator": comparator.name,
        "run_summaries": outcomes,
        "evaluated_count": len(records),
        "positive_target_gaps": sum(gap > 0 for gap in gaps),
        "zero_target_gaps": sum(gap == 0 for gap in gaps),
        "negative_target_gaps": sum(gap < 0 for gap in gaps),
        "aggregate_target_gap": sum(gaps),
        "mean_target_gap": mean(gaps),
        "maximum_target_gap": max(gaps),
        "minimum_target_gap": min(gaps),
        "top_adversaries": _top_adversaries(records),
    }


def _load_frozen_candidate(
    source_run: Path,
) -> Tuple[MoonshotHybridProgram, Mapping[str, Any]]:
    store = ArtifactStore(source_run / "artifacts")
    envelope = store.get(FROZEN_SUMMARY_DIGEST)
    value = envelope["value"]
    candidate = program_from_dict(value["candidate"])
    if not isinstance(candidate, MoonshotHybridProgram):
        raise ValueError("frozen candidate is not a moonshot hybrid")
    if candidate.candidate_id != FROZEN_PROGRAM_ID:
        raise ValueError("frozen candidate identity changed")
    if candidate.as_dict()["decision_topology"] != "sparse_moonshot_override":
        raise ValueError("frozen candidate topology changed")
    if value["config"]["capacity"] != FROZEN_CAPACITY:
        raise ValueError("frozen capacity changed")
    return candidate, value


def run_validation(
    *,
    source_run: Path,
    output: Path,
    orlib_root: Path,
) -> Mapping[str, Any]:
    output = Path(output)
    if output.exists() and any(output.iterdir()):
        raise ValueError("validation output directory must be absent or empty")
    output.mkdir(parents=True, exist_ok=True)

    candidate, source_summary = _load_frozen_candidate(source_run)
    incumbent = FunSearchORReference()
    fallback = FunSearchResidualProgram(
        candidate.ancestry_expression,
        candidate.residual_scale,
    )
    thresholds = {
        "gate_0.55": MoonshotHybridProgram(
            candidate.ancestry_expression,
            candidate.moonshot,
            gate_threshold=0.55,
            residual_scale=candidate.residual_scale,
        ),
        "gate_0.75": MoonshotHybridProgram(
            candidate.ancestry_expression,
            candidate.moonshot,
            gate_threshold=0.75,
            residual_scale=candidate.residual_scale,
        ),
    }
    classical = baseline_heuristics()
    iid_algorithms: Dict[str, OnlineHeuristic] = {
        "funsearch": incumbent,
        "frozen_candidate": candidate,
        "frozen_fallback": fallback,
        "sum_of_squares": SumOfSquaresHeuristic(),
        **classical,
    }
    transfer_algorithms: Dict[str, OnlineHeuristic] = {
        "funsearch": incumbent,
        "frozen_candidate": candidate,
        "frozen_fallback": fallback,
        "sum_of_squares": SumOfSquaresHeuristic(),
        "best_fit": classical["best_fit"],
    }

    iid_suite = _fresh_iid_suite()
    standalone_suite = _standalone_ablation_suite(iid_suite)
    transition_suite = _transition_suite()
    permutation_suite, orlib_digest = _orlib_permutation_suite(orlib_root)

    result = {
        "schema": 1,
        "validation_version": VALIDATION_VERSION,
        "protocol": (
            "docs/experiments/binpacking-frozen-novelty-validation-v1.md"
        ),
        "source": {
            "run": str(Path(source_run).resolve()),
            "summary_digest": FROZEN_SUMMARY_DIGEST,
            "source_outcome": source_summary["outcome"],
            "program_id": candidate.candidate_id,
            "program": candidate.as_dict(),
        },
        "sequestration": {
            "fresh_seed_base": FRESH_SEED_BASE,
            "candidate_search_or_tuning_performed": False,
            "candidate_mutated": False,
        },
        "fresh_iid": _compare_suite(
            iid_suite,
            iid_algorithms,
            baseline_name="funsearch",
            traced_candidate=candidate,
            traced_fallback=fallback,
        ),
        "standalone_controller_ablation": _compare_suite(
            standalone_suite,
            {
                "funsearch": incumbent,
                "frozen_candidate": candidate,
                "frozen_fallback": fallback,
                "residual_portfolio_alone": candidate.moonshot,
                **thresholds,
            },
            baseline_name="funsearch",
            traced_candidate=candidate,
            traced_fallback=fallback,
        ),
        "abrupt_transitions": _compare_suite(
            transition_suite,
            transfer_algorithms,
            baseline_name="funsearch",
            traced_candidate=candidate,
            traced_fallback=fallback,
        ),
        "orlib_permutations": {
            "source_corpus_digest": orlib_digest,
            **_compare_suite(
                permutation_suite,
                transfer_algorithms,
                baseline_name="funsearch",
                traced_candidate=candidate,
                traced_fallback=fallback,
            ),
        },
        "symmetric_adversarial": {
            "candidate_target": _adversarial_direction(
                direction_index=0,
                target=candidate,
                comparator=incumbent,
            ),
            "funsearch_target": _adversarial_direction(
                direction_index=1,
                target=incumbent,
                comparator=candidate,
            ),
        },
    }
    store = ArtifactStore(output / "artifacts")
    result_digest = store.put(
        "binpacking_frozen_novelty_validation",
        result,
    )
    manifest = {
        "schema": 1,
        "validation_version": VALIDATION_VERSION,
        "result_digest": result_digest,
        "source_summary_digest": FROZEN_SUMMARY_DIGEST,
        "program_id": candidate.candidate_id,
    }
    manifest_path = store.write_manifest(
        "binpacking-frozen-novelty-validation-v1",
        manifest,
    )
    return {
        "result_digest": result_digest,
        "manifest": str(manifest_path.resolve()),
        "output": str(output.resolve()),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run frozen empirical novelty validation."
    )
    parser.add_argument("--source-run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--orlib-root",
        type=Path,
        default=Path("data/orlib"),
    )
    arguments = parser.parse_args()
    print(
        json.dumps(
            run_validation(
                source_run=arguments.source_run,
                output=arguments.output,
                orlib_root=arguments.orlib_root,
            ),
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
