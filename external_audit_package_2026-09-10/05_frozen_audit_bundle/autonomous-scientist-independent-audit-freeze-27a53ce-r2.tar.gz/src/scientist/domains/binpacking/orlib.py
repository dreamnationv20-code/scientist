from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.models import BinPackingInstance


ORLIB_LOADER_VERSION = "orlib-binpacking-loader-v1"


@dataclass(frozen=True)
class ORLibraryRecord:
    instance: BinPackingInstance
    source_file: str
    source_sha256: str
    source_identifier: str
    best_known_bin_count: int

    def __post_init__(self) -> None:
        if self.best_known_bin_count <= 0:
            raise ValueError("best-known bin count must be positive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "instance": self.instance.as_dict(),
            "source_file": self.source_file,
            "source_sha256": self.source_sha256,
            "source_identifier": self.source_identifier,
            "best_known_bin_count": self.best_known_bin_count,
        }


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_orlib_text(
    text: str,
    *,
    source_file: str,
    source_sha256: str,
) -> Tuple[ORLibraryRecord, ...]:
    tokens = iter(text.split())

    def take(label: str) -> str:
        try:
            return next(tokens)
        except StopIteration as error:
            raise ValueError("truncated OR-Library file while reading %s" % label) from error

    try:
        problem_count = int(take("problem count"))
    except ValueError as error:
        raise ValueError("invalid OR-Library problem count") from error
    if problem_count <= 0:
        raise ValueError("OR-Library problem count must be positive")

    records = []
    identifiers = set()
    for problem_index in range(problem_count):
        identifier = take("problem identifier")
        if identifier in identifiers:
            raise ValueError("duplicate OR-Library identifier: %s" % identifier)
        identifiers.add(identifier)
        try:
            capacity = int(take("capacity"))
            item_count = int(take("item count"))
            best_known = int(take("best-known bin count"))
            items = tuple(
                int(take("item %d" % item_index))
                for item_index in range(item_count)
            )
        except ValueError as error:
            raise ValueError(
                "invalid numeric field in OR-Library problem %s" % identifier
            ) from error
        if capacity <= 0 or item_count <= 0:
            raise ValueError(
                "capacity and item count must be positive for %s" % identifier
            )
        instance_id = content_digest(
            {
                "loader_version": ORLIB_LOADER_VERSION,
                "source_sha256": source_sha256,
                "source_identifier": identifier,
                "capacity": capacity,
                "items": list(items),
            }
        )
        records.append(
            ORLibraryRecord(
                instance=BinPackingInstance(
                    instance_id=instance_id,
                    family="orlib_%s" % source_file.removesuffix(".txt"),
                    seed=problem_index,
                    capacity=capacity,
                    items=items,
                ),
                source_file=source_file,
                source_sha256=source_sha256,
                source_identifier=identifier,
                best_known_bin_count=best_known,
            )
        )

    trailing = list(tokens)
    if trailing:
        raise ValueError(
            "unexpected trailing tokens in %s: %s"
            % (source_file, " ".join(trailing[:3]))
        )
    return tuple(records)


def load_source_manifest(path: Path) -> Mapping[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    if manifest.get("schema") != 1:
        raise ValueError("unsupported OR-Library source manifest schema")
    if not isinstance(manifest.get("files"), list) or not manifest["files"]:
        raise ValueError("OR-Library source manifest contains no files")
    return manifest


def verify_orlib_files(
    root: Path,
    source_manifest: Mapping[str, Any],
) -> Mapping[str, str]:
    observed: Dict[str, str] = {}
    for entry in source_manifest["files"]:
        name = str(entry["name"])
        expected = str(entry["sha256"])
        path = Path(root) / name
        if not path.is_file():
            raise FileNotFoundError("missing OR-Library file: %s" % path)
        actual = file_sha256(path)
        if actual != expected:
            raise ValueError(
                "checksum mismatch for %s: expected %s, observed %s"
                % (name, expected, actual)
            )
        observed[name] = actual
    return observed


def load_orlib_corpus(
    root: Path,
    source_manifest_path: Optional[Path] = None,
) -> Tuple[ORLibraryRecord, ...]:
    root = Path(root)
    manifest_path = (
        root / "SOURCES.json"
        if source_manifest_path is None
        else Path(source_manifest_path)
    )
    source_manifest = load_source_manifest(manifest_path)
    observed = verify_orlib_files(root, source_manifest)
    records = []
    for entry in source_manifest["files"]:
        name = str(entry["name"])
        path = root / name
        records.extend(
            parse_orlib_text(
                path.read_text(encoding="utf-8"),
                source_file=name,
                source_sha256=observed[name],
            )
        )
    if len({record.instance.instance_id for record in records}) != len(records):
        raise ValueError("OR-Library corpus contains duplicate instance identities")
    return tuple(records)


def corpus_digest(records: Iterable[ORLibraryRecord]) -> str:
    return content_digest(
        {
            "loader_version": ORLIB_LOADER_VERSION,
            "records": [record.as_dict() for record in records],
        }
    )
