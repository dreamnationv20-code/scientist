from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance


OVERRIDE_VALUE_VERSION = "binpacking-trajectory-credit-override-value-v6"
ON_POLICY_AGGREGATION_ITERATIONS = 2
DEFAULT_MAX_INTERVENTIONS = 3
DEFAULT_COOLDOWN_DECISIONS = 8
MINIMUM_CAUSAL_AFFINITY = 0.20
ACTION_VALUE_FEATURES = (
    "bias",
    "negative_remaining_after",
    "exact_fill",
    "near_fill",
    "item",
    "load_before",
    "remaining_squared",
    "is_new_bin",
    "bin_index",
    "open_bins",
    "recent_mean",
    "recent_std",
    "recent_large_fraction",
    "recent_trend",
    "post_residual_diversity",
    "post_small_fragment_fraction",
)
OVERRIDE_STATE_FEATURES = (
    "bias",
    "item",
    "progress",
    "open_bins",
    "recent_mean",
    "recent_std",
    "recent_large_fraction",
    "recent_trend",
    "load_mean",
    "load_std",
    "small_fragment_fraction",
    "action_score_margin",
    "proposal_score_advantage",
    "proposal_is_new_bin",
    "fallback_is_new_bin",
)
SEQUENCE_CREDIT_FEATURES = (
    *OVERRIDE_STATE_FEATURES,
    "raw_override_value",
    "causal_affinity",
    "overrides_used_fraction",
    "has_prior_override",
    "override_lag",
)


def _clip(value: float, limit: float = 32.0) -> float:
    if not math.isfinite(value):
        return 0.0
    return max(-limit, min(limit, float(value)))


def _sigmoid(value: float) -> float:
    value = max(-40.0, min(40.0, value))
    return 1.0 / (1.0 + math.exp(-value))


def _vector_dot(weights: Sequence[float], values: Sequence[float]) -> float:
    return sum(weight * value for weight, value in zip(weights, values))


def _moments(values: Sequence[float]) -> Tuple[float, float]:
    if not values:
        return 0.0, 0.0
    center = sum(values) / float(len(values))
    variance = sum((value - center) ** 2 for value in values) / float(
        len(values)
    )
    return center, math.sqrt(max(0.0, variance))


def _recent_features(
    history: Sequence[int],
    capacity: int,
) -> Tuple[float, float, float, float]:
    recent = tuple(history[-24:])
    normalized = tuple(value / float(capacity) for value in recent)
    recent_mean, recent_std = _moments(normalized)
    recent_large = sum(value > 0.5 for value in normalized) / float(
        max(1, len(normalized))
    )
    split = len(normalized) // 2
    recent_trend = (
        mean(normalized[split:]) - mean(normalized[:split])
        if split and normalized[split:]
        else 0.0
    )
    return recent_mean, recent_std, recent_large, recent_trend


def _post_loads(
    loads: Sequence[int],
    item: int,
    action: Optional[int],
) -> Tuple[int, ...]:
    result = list(loads)
    if action is None:
        result.append(item)
    else:
        result[action] += item
    return tuple(result)


def _action_features(
    item: int,
    loads: Sequence[int],
    capacity: int,
    history: Sequence[int],
    action: Optional[int],
) -> Tuple[float, ...]:
    load = 0 if action is None else loads[action]
    remaining = capacity - load - item
    normalized_remaining = remaining / float(capacity)
    recent_mean, recent_std, recent_large, recent_trend = (
        _recent_features(history, capacity)
    )
    post = _post_loads(loads, item, action)
    residuals = tuple(capacity - value for value in post)
    bands = {
        min(7, int(8 * residual / float(capacity)))
        for residual in residuals
        if residual > 0
    }
    small_cutoff = max(1, capacity // 8)
    small_fraction = sum(
        0 < residual < small_cutoff for residual in residuals
    ) / float(max(1, len(residuals)))
    numeric_index = len(loads) if action is None else action
    return (
        1.0,
        -normalized_remaining,
        float(remaining == 0),
        float(0 < remaining <= max(1, capacity // 20)),
        item / float(capacity),
        load / float(capacity),
        normalized_remaining * normalized_remaining,
        float(action is None),
        numeric_index / float(max(1, len(loads))),
        min(1.0, len(loads) / 32.0),
        recent_mean,
        recent_std,
        recent_large,
        recent_trend,
        len(bands) / 8.0,
        small_fraction,
    )


def _candidate_actions(
    item: int,
    loads: Sequence[int],
    capacity: int,
    fallback_action: Optional[int],
    limit: int = 8,
) -> Tuple[Optional[int], ...]:
    feasible = tuple(
        index
        for index, load in enumerate(loads)
        if load + item <= capacity
    )
    actions: Tuple[Optional[int], ...] = (*feasible, None)
    if len(actions) <= limit:
        return actions
    ranked = tuple(
        sorted(
            actions,
            key=lambda action: (
                capacity
                - (0 if action is None else loads[action])
                - item,
                len(loads) if action is None else action,
            ),
        )
    )
    positions = (
        0,
        len(ranked) // 5,
        (2 * len(ranked)) // 5,
        (3 * len(ranked)) // 5,
        (4 * len(ranked)) // 5,
        len(ranked) - 1,
    )
    selected = list(dict.fromkeys(ranked[position] for position in positions))
    if fallback_action not in selected:
        selected.append(fallback_action)
    if None not in selected:
        selected.append(None)
    return tuple(selected[:limit])


@dataclass(frozen=True)
class ActionValueRow:
    action: Optional[int]
    features: Tuple[float, ...]
    outcome_delta: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "action": -1 if self.action is None else self.action,
            "features": list(self.features),
            "outcome_delta": self.outcome_delta,
        }


@dataclass(frozen=True)
class ActionValueTrace:
    instance_id: str
    decision_index: int
    item: int
    loads_before: Tuple[int, ...]
    history: Tuple[int, ...]
    fallback_action: Optional[int]
    rows: Tuple[ActionValueRow, ...]
    behavior_policy: str = "ancestry_single_deviation"
    overrides_used_before: int = 0
    last_override_index: int = -1_000_000

    @property
    def state_id(self) -> str:
        return content_digest(
            {
                "instance_id": self.instance_id,
                "decision_index": self.decision_index,
                "item": self.item,
                "loads_before": list(self.loads_before),
                "history": list(self.history),
                "fallback_action": (
                    -1 if self.fallback_action is None else self.fallback_action
                ),
                "behavior_policy": self.behavior_policy,
                "overrides_used_before": self.overrides_used_before,
                "last_override_index": self.last_override_index,
            }
        )

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict())

    def row(self, action: Optional[int]) -> ActionValueRow:
        return next(row for row in self.rows if row.action == action)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "state_id": self.state_id,
            "instance_id": self.instance_id,
            "decision_index": self.decision_index,
            "item": self.item,
            "loads_before": list(self.loads_before),
            "history": list(self.history),
            "fallback_action": (
                -1 if self.fallback_action is None else self.fallback_action
            ),
            "behavior_policy": self.behavior_policy,
            "overrides_used_before": self.overrides_used_before,
            "last_override_index": self.last_override_index,
            "rows": [row.as_dict() for row in self.rows],
        }


@dataclass(frozen=True)
class CausalStatePrototype:
    cluster_id: str
    item_fraction: float
    progress: float
    fallback_remaining_fraction: float
    alternative_remaining_fraction: float
    recent_proxy_advantage: float
    proxy_reliability: float
    mediator: str

    def __post_init__(self) -> None:
        if not self.cluster_id or not self.mediator:
            raise ValueError("causal state prototype is incomplete")
        fractions = (
            self.item_fraction,
            self.progress,
            self.fallback_remaining_fraction,
            self.alternative_remaining_fraction,
            self.proxy_reliability,
        )
        if any(not 0.0 <= value <= 1.0 for value in fractions):
            raise ValueError("causal state prototype fraction is invalid")
        if not -1.0 <= self.recent_proxy_advantage <= 1.0:
            raise ValueError("causal proxy advantage is invalid")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "cluster_id": self.cluster_id,
            "item_fraction": self.item_fraction,
            "progress": self.progress,
            "fallback_remaining_fraction": (
                self.fallback_remaining_fraction
            ),
            "alternative_remaining_fraction": (
                self.alternative_remaining_fraction
            ),
            "recent_proxy_advantage": self.recent_proxy_advantage,
            "proxy_reliability": self.proxy_reliability,
            "mediator": self.mediator,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "CausalStatePrototype":
        return cls(
            str(value["cluster_id"]),
            float(value["item_fraction"]),
            float(value["progress"]),
            float(value["fallback_remaining_fraction"]),
            float(value["alternative_remaining_fraction"]),
            float(value["recent_proxy_advantage"]),
            float(value["proxy_reliability"]),
            str(value["mediator"]),
        )


@dataclass(frozen=True)
class ClosedLoopRollout:
    instance_id: str
    partition: str
    threshold_index: int
    raw_threshold: float
    minimum_causal_affinity: float
    minimum_sequence_credit: float
    max_interventions: int
    cooldown_decisions: int
    baseline_bin_count: int
    candidate_bin_count: int
    intervention_indices: Tuple[int, ...]

    @property
    def outcome_gain(self) -> int:
        return self.baseline_bin_count - self.candidate_bin_count

    @property
    def rollout_id(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "rollout_version": OVERRIDE_VALUE_VERSION,
            "instance_id": self.instance_id,
            "partition": self.partition,
            "threshold_index": self.threshold_index,
            "raw_threshold": self.raw_threshold,
            "minimum_causal_affinity": self.minimum_causal_affinity,
            "minimum_sequence_credit": self.minimum_sequence_credit,
            "max_interventions": self.max_interventions,
            "cooldown_decisions": self.cooldown_decisions,
            "baseline_bin_count": self.baseline_bin_count,
            "candidate_bin_count": self.candidate_bin_count,
            "outcome_gain": self.outcome_gain,
            "intervention_indices": list(self.intervention_indices),
            "intervention_count": len(self.intervention_indices),
        }


@dataclass(frozen=True)
class TrajectoryCreditReport:
    """Closed-loop subset credit for one bounded intervention sequence."""

    instance_id: str
    partition: str
    policy_index: int
    baseline_bin_count: int
    full_candidate_bin_count: int
    intervention_indices: Tuple[int, ...]
    intervention_features: Tuple[Tuple[float, ...], ...]
    subset_outcome_gains: Tuple[Tuple[int, int], ...]

    def __post_init__(self) -> None:
        if len(self.intervention_indices) != len(self.intervention_features):
            raise ValueError("trajectory credit intervention evidence is misaligned")
        if any(
            len(features) != len(SEQUENCE_CREDIT_FEATURES)
            for features in self.intervention_features
        ):
            raise ValueError("trajectory credit feature count is invalid")
        masks = {mask for mask, _ in self.subset_outcome_gains}
        full_mask = (1 << len(self.intervention_indices)) - 1
        if 0 not in masks or full_mask not in masks:
            raise ValueError("trajectory credit subset lattice is incomplete")
        if len(masks) != 1 << len(self.intervention_indices):
            raise ValueError("trajectory credit subset lattice is incomplete")

    @property
    def full_outcome_gain(self) -> int:
        full_mask = (1 << len(self.intervention_indices)) - 1
        return dict(self.subset_outcome_gains)[full_mask]

    @property
    def leave_one_out_credits(self) -> Tuple[int, ...]:
        gains = dict(self.subset_outcome_gains)
        full_mask = (1 << len(self.intervention_indices)) - 1
        return tuple(
            gains[full_mask] - gains[full_mask & ~(1 << position)]
            for position in range(len(self.intervention_indices))
        )

    @property
    def singleton_credits(self) -> Tuple[int, ...]:
        gains = dict(self.subset_outcome_gains)
        empty = gains[0]
        return tuple(
            gains[1 << position] - empty
            for position in range(len(self.intervention_indices))
        )

    @property
    def pairwise_interactions(self) -> Tuple[Tuple[int, int, int], ...]:
        gains = dict(self.subset_outcome_gains)
        empty = gains[0]
        return tuple(
            (
                left,
                right,
                gains[(1 << left) | (1 << right)]
                - gains[1 << left]
                - gains[1 << right]
                + empty,
            )
            for left in range(len(self.intervention_indices))
            for right in range(left + 1, len(self.intervention_indices))
        )

    @property
    def attributable_gain(self) -> int:
        marginals = self.leave_one_out_credits
        if (
            self.full_outcome_gain > 0
            and marginals
            and min(marginals) >= 0
            and max(marginals) > 0
        ):
            return self.full_outcome_gain
        return 0

    @property
    def credit_id(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "credit_version": OVERRIDE_VALUE_VERSION,
            "instance_id": self.instance_id,
            "partition": self.partition,
            "policy_index": self.policy_index,
            "baseline_bin_count": self.baseline_bin_count,
            "full_candidate_bin_count": self.full_candidate_bin_count,
            "full_outcome_gain": self.full_outcome_gain,
            "intervention_indices": list(self.intervention_indices),
            "intervention_features": [
                list(features) for features in self.intervention_features
            ],
            "subset_outcome_gains": [
                {"mask": mask, "outcome_gain": gain}
                for mask, gain in self.subset_outcome_gains
            ],
            "singleton_credits": list(self.singleton_credits),
            "leave_one_out_credits": list(self.leave_one_out_credits),
            "pairwise_interactions": [
                {"left": left, "right": right, "interaction": interaction}
                for left, right, interaction in self.pairwise_interactions
            ],
            "attributable_gain": self.attributable_gain,
        }


def _loads_before(placements: Sequence[Any], index: int) -> Tuple[int, ...]:
    if index == 0:
        return ()
    return tuple(placements[index - 1].loads_after)


def _replay_suffix(
    instance: BinPackingInstance,
    fallback: OnlineHeuristic,
    decision_index: int,
    loads_before: Sequence[int],
    action: Optional[int],
) -> int:
    loads = list(_post_loads(loads_before, instance.items[decision_index], action))
    history = list(instance.items[: decision_index + 1])
    for suffix_index in range(decision_index + 1, len(instance.items)):
        item = instance.items[suffix_index]
        selected = fallback.choose_bin(
            item,
            tuple(loads),
            instance.capacity,
            suffix_index,
            tuple(history),
        )
        if selected is None:
            loads.append(item)
        else:
            loads[selected] += item
        history.append(item)
    return len(loads)


def _sample_decisions(length: int, limit: int) -> Tuple[int, ...]:
    if length <= 1:
        return ()
    available = tuple(range(1, length))
    if limit <= 0:
        return available
    if len(available) <= limit:
        return available
    return tuple(
        dict.fromkeys(
            available[
                round(position * (len(available) - 1) / float(limit - 1))
            ]
            for position in range(limit)
        )
    )


def collect_action_value_traces(
    instances: Iterable[BinPackingInstance],
    fallback: OnlineHeuristic,
    *,
    max_decisions_per_instance: int = 0,
) -> Tuple[ActionValueTrace, ...]:
    """Replay bounded legal actions without exposing suffixes as features."""

    traces = []
    for instance in instances:
        baseline = pack(instance, fallback)
        for decision_index in _sample_decisions(
            len(instance.items),
            max_decisions_per_instance,
        ):
            placement = baseline.placements[decision_index]
            loads_before = _loads_before(baseline.placements, decision_index)
            fallback_action = (
                placement.bin_index
                if placement.bin_index < len(loads_before)
                else None
            )
            item = placement.item
            history = tuple(instance.items[:decision_index])
            actions = _candidate_actions(
                item,
                loads_before,
                instance.capacity,
                fallback_action,
            )
            if len(actions) < 2:
                continue
            rows = tuple(
                ActionValueRow(
                    action,
                    _action_features(
                        item,
                        loads_before,
                        instance.capacity,
                        history,
                        action,
                    ),
                    (
                        0
                        if action == fallback_action
                        else baseline.bin_count
                        - _replay_suffix(
                            instance,
                            fallback,
                            decision_index,
                            loads_before,
                            action,
                        )
                    ),
                )
                for action in actions
            )
            traces.append(
                ActionValueTrace(
                    instance.instance_id,
                    decision_index,
                    item,
                    loads_before,
                    history,
                    fallback_action,
                    rows,
                )
            )
    return tuple(traces)


def _predicted_action(
    weights: Sequence[float],
    rows: Sequence[ActionValueRow],
    fallback_action: Optional[int],
) -> Optional[int]:
    return max(
        rows,
        key=lambda row: (
            _vector_dot(weights, row.features),
            row.action == fallback_action,
            -(1_000_000 if row.action is None else row.action),
        ),
    ).action


def _oracle_action(trace: ActionValueTrace) -> Optional[int]:
    return max(
        trace.rows,
        key=lambda row: (
            row.outcome_delta,
            row.action == trace.fallback_action,
            -(1_000_000 if row.action is None else row.action),
        ),
    ).action


def _state_features(
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
    fallback_action: Optional[int],
    proposal: Optional[int],
    rows: Sequence[Tuple[Optional[int], Tuple[float, ...], float]],
) -> Tuple[float, ...]:
    scores = sorted((row[2] for row in rows), reverse=True)
    margin = scores[0] - scores[1] if len(scores) > 1 else 0.0
    score_by_action = {row[0]: row[2] for row in rows}
    proposal_advantage = score_by_action[proposal] - score_by_action.get(
        fallback_action,
        score_by_action[proposal],
    )
    recent_mean, recent_std, recent_large, recent_trend = (
        _recent_features(history, capacity)
    )
    normalized_loads = tuple(load / float(capacity) for load in loads)
    load_mean, load_std = _moments(normalized_loads)
    residuals = tuple(capacity - load for load in loads)
    small_cutoff = max(1, capacity // 8)
    small_fraction = sum(
        0 < residual < small_cutoff for residual in residuals
    ) / float(max(1, len(residuals)))
    return (
        1.0,
        item / float(capacity),
        min(1.0, item_index / 256.0),
        min(1.0, len(loads) / 32.0),
        recent_mean,
        recent_std,
        recent_large,
        recent_trend,
        load_mean,
        load_std,
        small_fraction,
        _clip(margin, 4.0) / 4.0,
        _clip(proposal_advantage, 4.0) / 4.0,
        float(proposal is None),
        float(fallback_action is None),
    )


def _sequence_credit_features(
    state_features: Sequence[float],
    raw_value: float,
    causal_affinity: float,
    overrides_used: int,
    last_override_index: int,
    item_index: int,
) -> Tuple[float, ...]:
    has_prior = last_override_index >= 0
    lag = item_index - last_override_index if has_prior else 256
    return (
        *tuple(state_features),
        _clip(raw_value, 8.0) / 8.0,
        causal_affinity,
        min(1.0, overrides_used / float(DEFAULT_MAX_INTERVENTIONS)),
        float(has_prior),
        min(1.0, max(0, lag) / 64.0),
    )


def _remaining_fraction(
    item: int,
    loads: Sequence[int],
    capacity: int,
    action: Optional[int],
) -> float:
    load = 0 if action is None else loads[action]
    return (capacity - load - item) / float(capacity)


def _recent_complement_density(
    history: Sequence[int],
    target: int,
) -> float:
    recent = tuple(history[-32:])
    if not recent:
        return 0.0
    return sum(abs(value - target) <= 2 for value in recent) / float(
        len(recent)
    )


def _causal_state_affinity(
    prototypes: Sequence[CausalStatePrototype],
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
    fallback_action: Optional[int],
    proposal: Optional[int],
) -> float:
    if not prototypes:
        return 1.0
    fallback_remaining = _remaining_fraction(
        item,
        loads,
        capacity,
        fallback_action,
    )
    proposal_remaining = _remaining_fraction(
        item,
        loads,
        capacity,
        proposal,
    )
    proxy_advantage = _recent_complement_density(
        history,
        round(proposal_remaining * capacity),
    ) - _recent_complement_density(
        history,
        round(fallback_remaining * capacity),
    )
    observed = (
        item / float(capacity),
        min(1.0, item_index / 256.0),
        fallback_remaining,
        proposal_remaining,
        proxy_advantage,
    )
    affinities = []
    for prototype in prototypes:
        expected = (
            prototype.item_fraction,
            prototype.progress,
            prototype.fallback_remaining_fraction,
            prototype.alternative_remaining_fraction,
            prototype.recent_proxy_advantage,
        )
        distance = sum(
            abs(left - right) for left, right in zip(observed, expected)
        ) / float(len(observed))
        reliability_weight = 0.5 + 0.5 * prototype.proxy_reliability
        affinities.append(math.exp(-8.0 * distance) * reliability_weight)
    return max(affinities, default=0.0)


@dataclass(frozen=True)
class CalibratedOverrideValueModel:
    action_weights: Tuple[float, ...]
    state_weights: Tuple[float, ...]
    sequence_weights: Tuple[float, ...]
    raw_threshold: float
    temperature: float
    deployment_enabled: bool
    fit_instance_ids: Tuple[str, ...]
    action_holdout_instance_ids: Tuple[str, ...]
    policy_fit_instance_ids: Tuple[str, ...]
    gate_holdout_instance_ids: Tuple[str, ...]
    fit_trace_ids: Tuple[str, ...]
    action_holdout_trace_ids: Tuple[str, ...]
    policy_fit_trace_ids: Tuple[str, ...]
    gate_holdout_trace_ids: Tuple[str, ...]
    causal_prototypes: Tuple[CausalStatePrototype, ...]
    minimum_causal_affinity: float
    minimum_sequence_credit: float
    selected_action_design: str
    selected_policy_design: str
    minimum_gate_instances: int
    max_interventions: int
    cooldown_decisions: int
    aggregation_iterations: int
    calibration_metrics: Tuple[Tuple[str, float], ...]

    def __post_init__(self) -> None:
        if len(self.action_weights) != len(ACTION_VALUE_FEATURES):
            raise ValueError("override action model has the wrong feature count")
        if len(self.state_weights) != len(OVERRIDE_STATE_FEATURES):
            raise ValueError("override state model has the wrong feature count")
        if len(self.sequence_weights) != len(SEQUENCE_CREDIT_FEATURES):
            raise ValueError("override sequence model has the wrong feature count")
        if self.temperature <= 0.0 or not math.isfinite(self.temperature):
            raise ValueError("override calibration temperature must be positive")
        if self.minimum_gate_instances < 2:
            raise ValueError("override calibration needs independent instances")
        if self.max_interventions < 1:
            raise ValueError("override intervention budget must be positive")
        if self.cooldown_decisions < 0:
            raise ValueError("override cooldown cannot be negative")
        if self.aggregation_iterations < 1:
            raise ValueError("override trace aggregation must be iterative")
        if not 0.0 <= self.minimum_causal_affinity <= 1.0:
            raise ValueError("override causal affinity threshold is invalid")
        if not math.isfinite(self.minimum_sequence_credit):
            raise ValueError("override sequence credit threshold is invalid")
        if not self.selected_policy_design:
            raise ValueError("override policy design is missing")
        prototype_ids = tuple(
            prototype.cluster_id for prototype in self.causal_prototypes
        )
        if len(set(prototype_ids)) != len(prototype_ids):
            raise ValueError("override causal prototypes are duplicated")
        partitions = (
            set(self.fit_instance_ids),
            set(self.action_holdout_instance_ids),
            set(self.policy_fit_instance_ids),
            set(self.gate_holdout_instance_ids),
        )
        if any(not partition for partition in partitions):
            raise ValueError("override model partitions must be non-empty")
        if any(
            left.intersection(right)
            for index, left in enumerate(partitions)
            for right in partitions[index + 1 :]
        ):
            raise ValueError("override model instance partitions overlap")
        trace_partitions = (
            set(self.fit_trace_ids),
            set(self.action_holdout_trace_ids),
            set(self.policy_fit_trace_ids),
            set(self.gate_holdout_trace_ids),
        )
        if any(
            left.intersection(right)
            for index, left in enumerate(trace_partitions)
            for right in trace_partitions[index + 1 :]
        ):
            raise ValueError("override model trace partitions overlap")

    @property
    def model_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def complexity(self) -> int:
        return (
            8
            + len(self.causal_prototypes)
            + sum(abs(value) > 1e-12 for value in self.action_weights)
            + sum(abs(value) > 1e-12 for value in self.state_weights)
            + sum(abs(value) > 1e-12 for value in self.sequence_weights)
        )

    def ranked_action(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
        fallback_action: Optional[int],
    ) -> Tuple[
        Optional[int],
        Tuple[Tuple[Optional[int], Tuple[float, ...], float], ...],
    ]:
        rows = tuple(
            (
                action,
                _action_features(item, loads, capacity, history, action),
                _vector_dot(
                    self.action_weights,
                    _action_features(item, loads, capacity, history, action),
                ),
            )
            for action in _candidate_actions(
                item,
                loads,
                capacity,
                fallback_action,
            )
        )
        proposal = max(
            rows,
            key=lambda row: (
                row[2],
                row[0] == fallback_action,
                -(1_000_000 if row[0] is None else row[0]),
            ),
        )[0]
        return proposal, rows

    def _contextual_proposed_override(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
        fallback_action: Optional[int],
        overrides_used: int,
        last_override_index: int,
    ) -> Tuple[Optional[int], float, float, float]:
        proposal, rows = self.ranked_action(
            item,
            loads,
            capacity,
            history,
            fallback_action,
        )
        if proposal == fallback_action or not self.deployment_enabled:
            return proposal, 0.0, float("-inf"), float("-inf")
        features = _state_features(
            item,
            loads,
            capacity,
            item_index,
            history,
            fallback_action,
            proposal,
            rows,
        )
        raw_value = _vector_dot(self.state_weights, features)
        causal_affinity = _causal_state_affinity(
            self.causal_prototypes,
            item,
            loads,
            capacity,
            item_index,
            history,
            fallback_action,
            proposal,
        )
        sequence_features = _sequence_credit_features(
            features,
            raw_value,
            causal_affinity,
            overrides_used,
            last_override_index,
            item_index,
        )
        sequence_credit = _vector_dot(
            self.sequence_weights,
            sequence_features,
        )
        if (
            causal_affinity < self.minimum_causal_affinity
            or sequence_credit < self.minimum_sequence_credit
        ):
            return proposal, 0.0, raw_value, sequence_credit
        confidence = _sigmoid(
            (raw_value - self.raw_threshold) / self.temperature
        )
        return proposal, confidence, raw_value, sequence_credit

    def proposed_override(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
        fallback_action: Optional[int],
    ) -> Tuple[Optional[int], float, float]:
        proposal, confidence, raw_value, _ = (
            self._contextual_proposed_override(
                item,
                loads,
                capacity,
                item_index,
                history,
                fallback_action,
                0,
                -1_000_000,
            )
        )
        return proposal, confidence, raw_value

    def _replay_budget_state(
        self,
        history: Sequence[int],
        capacity: int,
        fallback: OnlineHeuristic,
        confidence_threshold: float,
    ) -> Tuple[int, int]:
        """Recover policy state without mutable cross-instance memory."""

        loads = []
        prefix = []
        interventions = 0
        last_override = -1_000_000
        for item_index, item in enumerate(history):
            fallback_action = fallback.choose_bin(
                item,
                tuple(loads),
                capacity,
                item_index,
                tuple(prefix),
            )
            proposal, confidence, _, _ = self._contextual_proposed_override(
                item,
                tuple(loads),
                capacity,
                item_index,
                tuple(prefix),
                fallback_action,
                interventions,
                last_override,
            )
            may_intervene = (
                interventions < self.max_interventions
                and item_index - last_override > self.cooldown_decisions
            )
            if (
                may_intervene
                and proposal != fallback_action
                and confidence >= confidence_threshold
            ):
                action = proposal
                interventions += 1
                last_override = item_index
            else:
                action = fallback_action
            loads = list(_post_loads(loads, item, action))
            prefix.append(item)
        return interventions, last_override

    def budgeted_proposed_override(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
        fallback: OnlineHeuristic,
        fallback_action: Optional[int],
        confidence_threshold: float,
    ) -> Tuple[Optional[int], float, float]:
        interventions, last_override = self._replay_budget_state(
            history,
            capacity,
            fallback,
            confidence_threshold,
        )
        proposal, confidence, raw_value, _ = (
            self._contextual_proposed_override(
                item,
                loads,
                capacity,
                item_index,
                history,
                fallback_action,
                interventions,
                last_override,
            )
        )
        may_intervene = (
            interventions < self.max_interventions
            and item_index - last_override > self.cooldown_decisions
        )
        if not may_intervene:
            return proposal, 0.0, raw_value
        return proposal, confidence, raw_value

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "model_version": OVERRIDE_VALUE_VERSION,
            "action_features": list(ACTION_VALUE_FEATURES),
            "state_features": list(OVERRIDE_STATE_FEATURES),
            "sequence_features": list(SEQUENCE_CREDIT_FEATURES),
            "action_weights": list(self.action_weights),
            "state_weights": list(self.state_weights),
            "sequence_weights": list(self.sequence_weights),
            "raw_threshold": self.raw_threshold,
            "temperature": self.temperature,
            "deployment_enabled": self.deployment_enabled,
            "fit_instance_ids": list(self.fit_instance_ids),
            "action_holdout_instance_ids": list(
                self.action_holdout_instance_ids
            ),
            "policy_fit_instance_ids": list(self.policy_fit_instance_ids),
            "gate_holdout_instance_ids": list(
                self.gate_holdout_instance_ids
            ),
            "fit_trace_ids": list(self.fit_trace_ids),
            "action_holdout_trace_ids": list(
                self.action_holdout_trace_ids
            ),
            "policy_fit_trace_ids": list(self.policy_fit_trace_ids),
            "gate_holdout_trace_ids": list(self.gate_holdout_trace_ids),
            "causal_prototypes": [
                prototype.as_dict() for prototype in self.causal_prototypes
            ],
            "minimum_causal_affinity": self.minimum_causal_affinity,
            "minimum_sequence_credit": self.minimum_sequence_credit,
            "selected_action_design": self.selected_action_design,
            "selected_policy_design": self.selected_policy_design,
            "minimum_gate_instances": self.minimum_gate_instances,
            "max_interventions": self.max_interventions,
            "cooldown_decisions": self.cooldown_decisions,
            "aggregation_iterations": self.aggregation_iterations,
            "calibration_metrics": dict(self.calibration_metrics),
        }
        if include_id:
            value["model_id"] = self.model_id
        return value

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
    ) -> "CalibratedOverrideValueModel":
        if value.get("model_version") != OVERRIDE_VALUE_VERSION:
            raise ValueError("unsupported override-value model version")
        model = cls(
            action_weights=tuple(
                float(item) for item in value["action_weights"]
            ),
            state_weights=tuple(
                float(item) for item in value["state_weights"]
            ),
            sequence_weights=tuple(
                float(item) for item in value["sequence_weights"]
            ),
            raw_threshold=float(value["raw_threshold"]),
            temperature=float(value["temperature"]),
            deployment_enabled=bool(value["deployment_enabled"]),
            fit_instance_ids=tuple(
                str(item) for item in value["fit_instance_ids"]
            ),
            action_holdout_instance_ids=tuple(
                str(item) for item in value["action_holdout_instance_ids"]
            ),
            policy_fit_instance_ids=tuple(
                str(item) for item in value["policy_fit_instance_ids"]
            ),
            gate_holdout_instance_ids=tuple(
                str(item) for item in value["gate_holdout_instance_ids"]
            ),
            fit_trace_ids=tuple(str(item) for item in value["fit_trace_ids"]),
            action_holdout_trace_ids=tuple(
                str(item) for item in value["action_holdout_trace_ids"]
            ),
            policy_fit_trace_ids=tuple(
                str(item) for item in value["policy_fit_trace_ids"]
            ),
            gate_holdout_trace_ids=tuple(
                str(item) for item in value["gate_holdout_trace_ids"]
            ),
            causal_prototypes=tuple(
                CausalStatePrototype.from_dict(item)
                for item in value["causal_prototypes"]
            ),
            minimum_causal_affinity=float(value["minimum_causal_affinity"]),
            minimum_sequence_credit=float(value["minimum_sequence_credit"]),
            selected_action_design=str(value["selected_action_design"]),
            selected_policy_design=str(value["selected_policy_design"]),
            minimum_gate_instances=int(value["minimum_gate_instances"]),
            max_interventions=int(value["max_interventions"]),
            cooldown_decisions=int(value["cooldown_decisions"]),
            aggregation_iterations=int(value["aggregation_iterations"]),
            calibration_metrics=tuple(
                (str(key), float(metric))
                for key, metric in sorted(
                    dict(value["calibration_metrics"]).items()
                )
            ),
        )
        expected = value.get("model_id")
        if expected is not None and model.model_id != expected:
            raise ValueError("override-value model identity mismatch")
        return model


@dataclass(frozen=True)
class OverrideValueTrainingResult:
    model: CalibratedOverrideValueModel
    traces: Tuple[ActionValueTrace, ...]
    closed_loop_rollouts: Tuple[ClosedLoopRollout, ...]
    trajectory_credits: Tuple[TrajectoryCreditReport, ...]
    trace_count: int
    action_row_count: int
    partition_metrics: Tuple[Tuple[str, Tuple[Tuple[str, float], ...]], ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "training_version": OVERRIDE_VALUE_VERSION,
            "model": self.model.as_dict(),
            "trace_count": self.trace_count,
            "trace_ids": [trace.trace_id for trace in self.traces],
            "action_row_count": self.action_row_count,
            "closed_loop_rollout_count": len(self.closed_loop_rollouts),
            "closed_loop_rollout_ids": [
                rollout.rollout_id for rollout in self.closed_loop_rollouts
            ],
            "trajectory_credit_count": len(self.trajectory_credits),
            "trajectory_credit_ids": [
                credit.credit_id for credit in self.trajectory_credits
            ],
            "partition_metrics": {
                partition: dict(metrics)
                for partition, metrics in self.partition_metrics
            },
            "leakage_checks": {
                "instance_partitions_disjoint": True,
                "trace_partitions_disjoint": True,
                "suffix_outcomes_excluded_from_features": True,
                "outer_guard_and_audit_excluded_from_fitting": True,
                "gate_thresholds_derived_without_gate_outcomes": True,
                "calibration_clustered_by_instance": True,
                "outcome_equivalent_pairs_excluded_from_updates": True,
                "ancestry_is_default_reference_action": True,
                "episode_policy_fit_and_gate_disjoint": True,
                "authorization_selected_from_complete_episode_returns": True,
                "action_diagnostic_is_not_a_deployment_veto": True,
                "gate_evaluates_one_frozen_policy": True,
                "causal_prototypes_derived_before_policy_fitting": True,
                "sequence_credit_weights_fit_only_on_fit_instances": True,
                "sequence_credit_subsets_rerun_closed_loop": True,
                "sequence_credit_features_exclude_future_information": True,
            },
        }


def _fit_action_weights(
    traces: Sequence[ActionValueTrace],
    *,
    learning_rate: float,
    epochs: int,
) -> Tuple[float, ...]:
    """Learn strict alternative-versus-ancestry advantage margins.

    Every alternative is compared with the action selected by the ancestry
    policy in the same state. Outcome-equivalent pairs carry no learning
    signal. Strict improvements are pushed above ancestry and strict
    regressions below it; a zero score therefore preserves ancestry.
    """

    weights = [0.0] * len(ACTION_VALUE_FEATURES)
    for _ in range(epochs):
        updates = 0
        for trace in traces:
            ancestry_row = trace.row(trace.fallback_action)
            for alternative_row in trace.rows:
                if alternative_row.action == trace.fallback_action:
                    continue
                outcome_delta = alternative_row.outcome_delta
                if outcome_delta == 0:
                    continue
                direction = 1.0 if outcome_delta > 0 else -1.0
                feature_difference = tuple(
                    alternative - ancestry
                    for alternative, ancestry in zip(
                        alternative_row.features,
                        ancestry_row.features,
                    )
                )
                signed_margin = direction * _vector_dot(
                    weights,
                    feature_difference,
                )
                if signed_margin >= 1.0:
                    continue
                strength = abs(float(outcome_delta))
                for index, difference in enumerate(feature_difference):
                    weights[index] = _clip(
                        weights[index]
                        + learning_rate
                        * direction
                        * strength
                        * difference
                    )
                updates += 1
        if not updates:
            break
    return tuple(round(value, 8) for value in weights)


def _action_metrics(
    weights: Sequence[float],
    traces: Sequence[ActionValueTrace],
) -> Dict[str, float]:
    realized = []
    correct = 0
    strict_pair_count = 0
    strict_pair_correct = 0
    positive_pair_count = 0
    negative_pair_count = 0
    neutral_pair_count = 0
    for trace in traces:
        predicted = _predicted_action(weights, trace.rows, trace.fallback_action)
        realized.append(trace.row(predicted).outcome_delta)
        correct += int(predicted == _oracle_action(trace))
        ancestry_row = trace.row(trace.fallback_action)
        ancestry_score = _vector_dot(weights, ancestry_row.features)
        for alternative_row in trace.rows:
            if alternative_row.action == trace.fallback_action:
                continue
            if alternative_row.outcome_delta == 0:
                neutral_pair_count += 1
                continue
            strict_pair_count += 1
            margin = (
                _vector_dot(weights, alternative_row.features)
                - ancestry_score
            )
            if alternative_row.outcome_delta > 0:
                positive_pair_count += 1
                strict_pair_correct += int(margin > 0.0)
            else:
                negative_pair_count += 1
                strict_pair_correct += int(margin < 0.0)
    return {
        "trace_count": float(len(traces)),
        "oracle_action_accuracy": correct / float(max(1, len(traces))),
        "strict_pair_count": float(strict_pair_count),
        "positive_pair_count": float(positive_pair_count),
        "negative_pair_count": float(negative_pair_count),
        "neutral_pair_count": float(neutral_pair_count),
        "strict_pair_accuracy": strict_pair_correct
        / float(max(1, strict_pair_count)),
        "aggregate_outcome_gain": float(sum(realized)),
        "mean_outcome_gain": mean(realized) if realized else 0.0,
        "win_rate": sum(value > 0 for value in realized)
        / float(max(1, len(realized))),
        "loss_rate": sum(value < 0 for value in realized)
        / float(max(1, len(realized))),
        "maximum_regression": float(
            max((0, *(-value for value in realized)))
        ),
    }


def _trace_state_row(
    action_weights: Sequence[float],
    trace: ActionValueTrace,
    capacity: int,
) -> Tuple[Tuple[float, ...], int, bool]:
    scored_rows = tuple(
        (
            row.action,
            row.features,
            _vector_dot(action_weights, row.features),
        )
        for row in trace.rows
    )
    proposal = max(
        scored_rows,
        key=lambda row: (
            row[2],
            row[0] == trace.fallback_action,
            -(1_000_000 if row[0] is None else row[0]),
        ),
    )[0]
    features = _state_features(
        trace.item,
        trace.loads_before,
        capacity,
        trace.decision_index,
        trace.history,
        trace.fallback_action,
        proposal,
        scored_rows,
    )
    return (
        features,
        trace.row(proposal).outcome_delta,
        proposal != trace.fallback_action,
    )


def _fit_state_weights(
    rows: Sequence[Tuple[Tuple[float, ...], int, bool]],
) -> Tuple[float, ...]:
    weights = [0.0] * len(OVERRIDE_STATE_FEATURES)
    for epoch in range(240):
        learning_rate = 0.04 / (1.0 + epoch / 40.0)
        for features, label, changed in rows:
            target = float(label) if changed and label != 0 else -0.25
            error = target - _vector_dot(weights, features)
            for index, feature in enumerate(features):
                weights[index] = _clip(
                    weights[index]
                    + learning_rate
                    * (error * feature - 0.002 * weights[index]),
                    16.0,
                )
    return tuple(round(value, 8) for value in weights)


def _fit_sequence_credit_weights(
    rows: Sequence[Tuple[Tuple[float, ...], int]],
) -> Tuple[float, ...]:
    """Fit observable intervention context to strict trajectory marginals."""

    weights = [0.0] * len(SEQUENCE_CREDIT_FEATURES)
    strict_rows = tuple((features, label) for features, label in rows if label)
    for epoch in range(320):
        if not strict_rows:
            break
        learning_rate = 0.025 / (1.0 + epoch / 60.0)
        for features, label in strict_rows:
            target = _clip(float(label), 2.0)
            prediction = _vector_dot(weights, features)
            error = _clip(target - prediction, 2.0)
            for index, feature in enumerate(features):
                weights[index] = _clip(
                    weights[index]
                    + learning_rate
                    * (error * feature - 0.003 * weights[index]),
                    16.0,
                )
    return tuple(round(value, 8) for value in weights)


def _sequence_credit_metrics(
    weights: Sequence[float],
    rows: Sequence[Tuple[Tuple[float, ...], int]],
) -> Dict[str, float]:
    strict = tuple((features, label) for features, label in rows if label)
    predictions = tuple(
        (_vector_dot(weights, features), label) for features, label in strict
    )
    return {
        "trajectory_marginal_count": float(len(rows)),
        "strict_trajectory_marginal_count": float(len(strict)),
        "positive_trajectory_marginal_count": float(
            sum(label > 0 for _, label in strict)
        ),
        "negative_trajectory_marginal_count": float(
            sum(label < 0 for _, label in strict)
        ),
        "trajectory_marginal_sign_accuracy": (
            sum(
                (prediction > 0.0) == (label > 0)
                for prediction, label in predictions
            )
            / float(max(1, len(predictions)))
        ),
    }


def _partition_instance_ids(
    instance_ids: Sequence[str],
    seed: int,
) -> Tuple[
    Tuple[str, ...],
    Tuple[str, ...],
    Tuple[str, ...],
    Tuple[str, ...],
]:
    ordered = tuple(
        sorted(
            set(instance_ids),
            key=lambda instance_id: content_digest(
                {"seed": seed, "instance_id": instance_id}
            ),
        )
    )
    if len(ordered) < 12:
        raise ValueError(
            "episode-transport override fitting requires at least twelve "
            "instances"
        )
    holdout_count = max(3, len(ordered) // 5)
    fit_count = len(ordered) - 3 * holdout_count
    return (
        ordered[:fit_count],
        ordered[fit_count : fit_count + holdout_count],
        ordered[
            fit_count + holdout_count : fit_count + 2 * holdout_count
        ],
        ordered[fit_count + 2 * holdout_count :],
    )


def _quantile(values: Sequence[float], fraction: float) -> float:
    ordered = tuple(sorted(values))
    if not ordered:
        return 0.0
    position = max(0, min(len(ordered) - 1, round(
        fraction * (len(ordered) - 1)
    )))
    return float(ordered[position])


def _scored_policy_state(
    action_weights: Sequence[float],
    state_weights: Sequence[float],
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
    fallback_action: Optional[int],
) -> Tuple[
    Optional[int],
    float,
    Tuple[Tuple[Optional[int], Tuple[float, ...], float], ...],
]:
    scored_rows = tuple(
        (
            action,
            _action_features(item, loads, capacity, history, action),
            _vector_dot(
                action_weights,
                _action_features(item, loads, capacity, history, action),
            ),
        )
        for action in _candidate_actions(
            item,
            loads,
            capacity,
            fallback_action,
        )
    )
    proposal = max(
        scored_rows,
        key=lambda row: (
            row[2],
            row[0] == fallback_action,
            -(1_000_000 if row[0] is None else row[0]),
        ),
    )[0]
    features = _state_features(
        item,
        loads,
        capacity,
        item_index,
        history,
        fallback_action,
        proposal,
        scored_rows,
    )
    return proposal, _vector_dot(state_weights, features), scored_rows


def _closed_loop_action(
    fallback: OnlineHeuristic,
    action_weights: Sequence[float],
    state_weights: Sequence[float],
    raw_threshold: float,
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
    overrides_used: int,
    last_override_index: int,
    max_interventions: int,
    cooldown_decisions: int,
    causal_prototypes: Sequence[CausalStatePrototype],
    minimum_causal_affinity: float,
    sequence_weights: Sequence[float] = (),
    minimum_sequence_credit: float = -1_000_000.0,
) -> Tuple[
    Optional[int],
    Optional[int],
    bool,
    float,
    Tuple[float, ...],
]:
    fallback_action = fallback.choose_bin(
        item,
        loads,
        capacity,
        item_index,
        history,
    )
    proposal, raw_value, scored_rows = _scored_policy_state(
        action_weights,
        state_weights,
        item,
        loads,
        capacity,
        item_index,
        history,
        fallback_action,
    )
    may_intervene = (
        overrides_used < max_interventions
        and item_index - last_override_index > cooldown_decisions
    )
    causal_affinity = _causal_state_affinity(
        causal_prototypes,
        item,
        loads,
        capacity,
        item_index,
        history,
        fallback_action,
        proposal,
    )
    state_features = _state_features(
        item,
        loads,
        capacity,
        item_index,
        history,
        fallback_action,
        proposal,
        scored_rows,
    )
    sequence_features = _sequence_credit_features(
        state_features,
        raw_value,
        causal_affinity,
        overrides_used,
        last_override_index,
        item_index,
    )
    sequence_credit = (
        _vector_dot(sequence_weights, sequence_features)
        if sequence_weights
        else 0.0
    )
    intervened = (
        may_intervene
        and proposal != fallback_action
        and raw_value >= raw_threshold
        and causal_affinity >= minimum_causal_affinity
        and sequence_credit >= minimum_sequence_credit
    )
    return (
        proposal if intervened else fallback_action,
        fallback_action,
        intervened,
        raw_value,
        sequence_features,
    )


def _rollout_closed_loop_policy(
    instance: BinPackingInstance,
    fallback: OnlineHeuristic,
    action_weights: Sequence[float],
    state_weights: Sequence[float],
    raw_threshold: float,
    max_interventions: int,
    cooldown_decisions: int,
    causal_prototypes: Sequence[CausalStatePrototype],
    minimum_causal_affinity: float,
    sequence_weights: Sequence[float] = (),
    minimum_sequence_credit: float = -1_000_000.0,
    allowed_intervention_indices: Optional[Sequence[int]] = None,
) -> Tuple[int, Tuple[int, ...], Tuple[Tuple[float, ...], ...]]:
    loads = []
    history = []
    intervention_indices = []
    intervention_features = []
    last_override_index = -1_000_000
    allowed = (
        None
        if allowed_intervention_indices is None
        else set(allowed_intervention_indices)
    )
    for item_index, item in enumerate(instance.items):
        action, fallback_action, intervened, _, sequence_features = (
            _closed_loop_action(
            fallback,
            action_weights,
            state_weights,
            raw_threshold,
            item,
            tuple(loads),
            instance.capacity,
            item_index,
            tuple(history),
            len(intervention_indices),
            last_override_index,
            max_interventions,
            cooldown_decisions,
            causal_prototypes,
            minimum_causal_affinity,
            sequence_weights,
            minimum_sequence_credit,
            )
        )
        if intervened and allowed is not None and item_index not in allowed:
            action = fallback_action
            intervened = False
        if intervened:
            intervention_indices.append(item_index)
            intervention_features.append(sequence_features)
            last_override_index = item_index
        loads = list(_post_loads(loads, item, action))
        history.append(item)
    return (
        len(loads),
        tuple(intervention_indices),
        tuple(intervention_features),
    )


def _trajectory_credit_report(
    instance: BinPackingInstance,
    fallback: OnlineHeuristic,
    action_weights: Sequence[float],
    state_weights: Sequence[float],
    raw_threshold: float,
    max_interventions: int,
    cooldown_decisions: int,
    causal_prototypes: Sequence[CausalStatePrototype],
    minimum_causal_affinity: float,
    sequence_weights: Sequence[float],
    minimum_sequence_credit: float,
    partition: str,
    policy_index: int,
    baseline_bin_count: int,
) -> TrajectoryCreditReport:
    """Enumerate the bounded intervention lattice with closed-loop reruns."""

    (
        full_candidate_bins,
        intervention_indices,
        intervention_features,
    ) = _rollout_closed_loop_policy(
        instance,
        fallback,
        action_weights,
        state_weights,
        raw_threshold,
        max_interventions,
        cooldown_decisions,
        causal_prototypes,
        minimum_causal_affinity,
        sequence_weights,
        minimum_sequence_credit,
    )
    subset_gains = []
    full_mask = (1 << len(intervention_indices)) - 1
    for mask in range(full_mask + 1):
        if mask == full_mask:
            candidate_bins = full_candidate_bins
        else:
            allowed = tuple(
                intervention_indices[position]
                for position in range(len(intervention_indices))
                if mask & (1 << position)
            )
            candidate_bins, _, _ = _rollout_closed_loop_policy(
                instance,
                fallback,
                action_weights,
                state_weights,
                raw_threshold,
                max_interventions,
                cooldown_decisions,
                causal_prototypes,
                minimum_causal_affinity,
                sequence_weights,
                minimum_sequence_credit,
                allowed,
            )
        subset_gains.append((mask, baseline_bin_count - candidate_bins))
    return TrajectoryCreditReport(
        instance_id=instance.instance_id,
        partition=partition,
        policy_index=policy_index,
        baseline_bin_count=baseline_bin_count,
        full_candidate_bin_count=full_candidate_bins,
        intervention_indices=intervention_indices,
        intervention_features=intervention_features,
        subset_outcome_gains=tuple(subset_gains),
    )


def _replay_closed_loop_suffix(
    instance: BinPackingInstance,
    fallback: OnlineHeuristic,
    action_weights: Sequence[float],
    state_weights: Sequence[float],
    raw_threshold: float,
    decision_index: int,
    loads_before: Sequence[int],
    forced_action: Optional[int],
    fallback_action: Optional[int],
    overrides_used_before: int,
    last_override_index: int,
    max_interventions: int,
    cooldown_decisions: int,
    causal_prototypes: Sequence[CausalStatePrototype],
    minimum_causal_affinity: float,
) -> int:
    forced_override = forced_action != fallback_action
    loads = list(
        _post_loads(
            loads_before,
            instance.items[decision_index],
            forced_action,
        )
    )
    history = list(instance.items[: decision_index + 1])
    interventions = overrides_used_before + int(forced_override)
    last_override = decision_index if forced_override else last_override_index
    for suffix_index in range(decision_index + 1, len(instance.items)):
        item = instance.items[suffix_index]
        action, _, intervened, _, _ = _closed_loop_action(
            fallback,
            action_weights,
            state_weights,
            raw_threshold,
            item,
            tuple(loads),
            instance.capacity,
            suffix_index,
            tuple(history),
            interventions,
            last_override,
            max_interventions,
            cooldown_decisions,
            causal_prototypes,
            minimum_causal_affinity,
        )
        if intervened:
            interventions += 1
            last_override = suffix_index
        loads = list(_post_loads(loads, item, action))
        history.append(item)
    return len(loads)


def _collect_closed_loop_action_traces(
    instances: Sequence[BinPackingInstance],
    fallback: OnlineHeuristic,
    action_weights: Sequence[float],
    state_weights: Sequence[float],
    raw_threshold: float,
    max_interventions: int,
    cooldown_decisions: int,
    behavior_policy: str,
    causal_prototypes: Sequence[CausalStatePrototype],
    minimum_causal_affinity: float,
    max_trace_decisions_per_instance: int = 0,
) -> Tuple[ActionValueTrace, ...]:
    traces = []
    for instance in instances:
        sampled_decisions = set(
            _sample_decisions(
                len(instance.items),
                max_trace_decisions_per_instance,
            )
        )
        loads = []
        history = []
        interventions = 0
        last_override_index = -1_000_000
        for decision_index, item in enumerate(instance.items):
            (
                deployed_action,
                fallback_action,
                intervened,
                _,
                _,
            ) = _closed_loop_action(
                fallback,
                action_weights,
                state_weights,
                raw_threshold,
                item,
                tuple(loads),
                instance.capacity,
                decision_index,
                tuple(history),
                interventions,
                last_override_index,
                max_interventions,
                cooldown_decisions,
                causal_prototypes,
                minimum_causal_affinity,
            )
            may_intervene = (
                interventions < max_interventions
                and decision_index - last_override_index > cooldown_decisions
            )
            actions = _candidate_actions(
                item,
                tuple(loads),
                instance.capacity,
                fallback_action,
            )
            if (
                may_intervene
                and decision_index in sampled_decisions
                and len(actions) >= 2
            ):
                reference_bins = _replay_closed_loop_suffix(
                    instance,
                    fallback,
                    action_weights,
                    state_weights,
                    raw_threshold,
                    decision_index,
                    tuple(loads),
                    fallback_action,
                    fallback_action,
                    interventions,
                    last_override_index,
                    max_interventions,
                    cooldown_decisions,
                    causal_prototypes,
                    minimum_causal_affinity,
                )
                rows = tuple(
                    ActionValueRow(
                        action,
                        _action_features(
                            item,
                            tuple(loads),
                            instance.capacity,
                            tuple(history),
                            action,
                        ),
                        (
                            0
                            if action == fallback_action
                            else reference_bins
                            - _replay_closed_loop_suffix(
                                instance,
                                fallback,
                                action_weights,
                                state_weights,
                                raw_threshold,
                                decision_index,
                                tuple(loads),
                                action,
                                fallback_action,
                                interventions,
                                last_override_index,
                                max_interventions,
                                cooldown_decisions,
                                causal_prototypes,
                                minimum_causal_affinity,
                            )
                        ),
                    )
                    for action in actions
                )
                traces.append(
                    ActionValueTrace(
                        instance.instance_id,
                        decision_index,
                        item,
                        tuple(loads),
                        tuple(history),
                        fallback_action,
                        rows,
                        behavior_policy,
                        interventions,
                        last_override_index,
                    )
                )
            if intervened:
                interventions += 1
                last_override_index = decision_index
            loads = list(_post_loads(loads, item, deployed_action))
            history.append(item)
    return tuple(traces)


def _fit_single_deviation_override_value_ablation(
    instances: Sequence[BinPackingInstance],
    fallback: OnlineHeuristic,
    *,
    seed: int,
) -> OverrideValueTrainingResult:
    """Retain the rejected one-deviation estimator as non-deployable control."""

    traces = collect_action_value_traces(instances, fallback)
    fit_ids, action_ids, policy_ids, gate_ids = _partition_instance_ids(
        tuple(instance.instance_id for instance in instances),
        seed,
    )
    by_partition = {
        "fit": tuple(trace for trace in traces if trace.instance_id in fit_ids),
        "action_holdout": tuple(
            trace for trace in traces if trace.instance_id in action_ids
        ),
        "policy_fit": tuple(
            trace for trace in traces if trace.instance_id in policy_ids
        ),
        "gate_holdout": tuple(
            trace for trace in traces if trace.instance_id in gate_ids
        ),
    }
    if any(not values for values in by_partition.values()):
        raise ValueError("calibrated override trace partition is empty")

    action_candidates = []
    for learning_rate in (0.10, 0.25, 0.50):
        for epochs in (12, 36):
            weights = _fit_action_weights(
                by_partition["fit"],
                learning_rate=learning_rate,
                epochs=epochs,
            )
            metrics = _action_metrics(
                weights,
                by_partition["action_holdout"],
            )
            action_candidates.append(
                (
                    "conservative_pairwise_advantage:lr=%g:epochs=%d"
                    % (learning_rate, epochs),
                    weights,
                    metrics,
                )
            )
    selected_design, action_weights, action_metrics = max(
        action_candidates,
        key=lambda item: (
            item[2]["aggregate_outcome_gain"],
            -item[2]["maximum_regression"],
            item[2]["strict_pair_accuracy"],
            item[2]["win_rate"] - item[2]["loss_rate"],
            item[0],
        ),
    )
    capacity_by_instance = {
        instance.instance_id: instance.capacity for instance in instances
    }
    state_rows = {
        partition: tuple(
            _trace_state_row(
                action_weights,
                trace,
                capacity_by_instance[trace.instance_id],
            )
            for trace in partition_traces
        )
        for partition, partition_traces in by_partition.items()
    }
    state_weights = _fit_state_weights(state_rows["fit"])
    gate_scored = tuple(
        (
            _vector_dot(state_weights, features),
            outcome,
            changed,
        )
        for features, outcome, changed in state_rows["gate_holdout"]
    )
    eligible_scores = tuple(score for score, _, changed in gate_scored if changed)
    minimum_selections = max(3, int(math.ceil(len(gate_scored) * 0.08)))
    threshold_reports = []
    for threshold in sorted(set(eligible_scores)):
        selected = tuple(
            outcome
            for score, outcome, changed in gate_scored
            if changed and score >= threshold
        )
        if len(selected) < minimum_selections:
            continue
        threshold_reports.append(
            {
                "threshold": threshold,
                "selection_count": len(selected),
                "aggregate_outcome_gain": sum(selected),
                "mean_outcome_gain": mean(selected),
                "wins": sum(value > 0 for value in selected),
                "losses": sum(value < 0 for value in selected),
                "maximum_regression": max(
                    (0, *(-value for value in selected))
                ),
            }
        )
    safe_reports = tuple(
        report
        for report in threshold_reports
        if report["aggregate_outcome_gain"] > 0
        and report["mean_outcome_gain"] > 0.0
        and report["wins"] > report["losses"]
        and report["maximum_regression"] <= 1
    )
    selected_gate = (
        max(
            safe_reports,
            key=lambda report: (
                report["aggregate_outcome_gain"],
                report["mean_outcome_gain"],
                report["wins"] - report["losses"],
                report["selection_count"],
                report["threshold"],
            ),
        )
        if safe_reports
        else None
    )
    deployment_enabled = selected_gate is not None
    raw_threshold = (
        float(selected_gate["threshold"])
        if selected_gate is not None
        else max(eligible_scores, default=0.0) + 1.0
    )
    raw_scores = tuple(score for score, _, _ in gate_scored)
    _, raw_std = _moments(raw_scores)
    temperature = max(0.05, raw_std)
    probabilities = tuple(
        _sigmoid((score - raw_threshold) / temperature)
        for score, _, _ in gate_scored
    )
    binary_labels = tuple(float(outcome > 0) for _, outcome, _ in gate_scored)
    brier = mean(
        (probability - label) ** 2
        for probability, label in zip(probabilities, binary_labels)
    )
    selected_values = (
        ()
        if selected_gate is None
        else tuple(
            outcome
            for score, outcome, changed in gate_scored
            if changed and score >= raw_threshold
        )
    )
    calibration_metrics = tuple(
        sorted(
            {
                "gate_trace_count": float(len(gate_scored)),
                "selected_trace_count": float(len(selected_values)),
                "selected_aggregate_outcome_gain": float(sum(selected_values)),
                "selected_mean_outcome_gain": (
                    mean(selected_values) if selected_values else 0.0
                ),
                "selected_win_rate": sum(value > 0 for value in selected_values)
                / float(max(1, len(selected_values))),
                "selected_loss_rate": sum(value < 0 for value in selected_values)
                / float(max(1, len(selected_values))),
                "brier_score": brier,
            }.items()
        )
    )
    trace_ids = {
        partition: tuple(trace.trace_id for trace in partition_traces)
        for partition, partition_traces in by_partition.items()
    }
    model = CalibratedOverrideValueModel(
        action_weights=action_weights,
        state_weights=state_weights,
        sequence_weights=(0.0,) * len(SEQUENCE_CREDIT_FEATURES),
        raw_threshold=raw_threshold,
        temperature=temperature,
        deployment_enabled=False,
        fit_instance_ids=fit_ids,
        action_holdout_instance_ids=action_ids,
        policy_fit_instance_ids=policy_ids,
        gate_holdout_instance_ids=gate_ids,
        fit_trace_ids=trace_ids["fit"],
        action_holdout_trace_ids=trace_ids["action_holdout"],
        policy_fit_trace_ids=trace_ids["policy_fit"],
        gate_holdout_trace_ids=trace_ids["gate_holdout"],
        causal_prototypes=(),
        minimum_causal_affinity=0.0,
        minimum_sequence_credit=1.0,
        selected_action_design=selected_design,
        selected_policy_design="single_deviation_control_only",
        minimum_gate_instances=max(2, len(gate_ids)),
        max_interventions=DEFAULT_MAX_INTERVENTIONS,
        cooldown_decisions=DEFAULT_COOLDOWN_DECISIONS,
        aggregation_iterations=1,
        calibration_metrics=calibration_metrics,
    )
    partition_metrics = (
        ("fit", tuple(sorted(_action_metrics(action_weights, by_partition["fit"]).items()))),
        ("action_holdout", tuple(sorted(action_metrics.items()))),
        (
            "gate_holdout",
            tuple(
                sorted(
                    {
                        "trace_count": float(len(gate_scored)),
                        "deployment_enabled": 0.0,
                        "control_only": 1.0,
                        "safe_threshold_count": float(len(safe_reports)),
                        "selected_trace_count": float(len(selected_values)),
                        "selected_aggregate_outcome_gain": float(
                            sum(selected_values)
                        ),
                    }.items()
                )
            ),
        ),
    )
    return OverrideValueTrainingResult(
        model=model,
        traces=traces,
        closed_loop_rollouts=(),
        trajectory_credits=(),
        trace_count=len(traces),
        action_row_count=sum(len(trace.rows) for trace in traces),
        partition_metrics=partition_metrics,
    )


def _fit_decision_threshold_override_value_ablation_v3(
    instances: Sequence[BinPackingInstance],
    fallback: OnlineHeuristic,
    *,
    seed: int,
) -> OverrideValueTrainingResult:
    """Retain the historical v3 ablation without exposing stale wiring."""

    return _fit_single_deviation_override_value_ablation(
        instances,
        fallback,
        seed=seed,
    )


def _episode_policy_report(
    instances: Sequence[BinPackingInstance],
    fallback: OnlineHeuristic,
    action_weights: Sequence[float],
    state_weights: Sequence[float],
    raw_threshold: float,
    minimum_causal_affinity: float,
    sequence_weights: Sequence[float],
    minimum_sequence_credit: float,
    max_interventions: int,
    cooldown_decisions: int,
    causal_prototypes: Sequence[CausalStatePrototype],
    partition: str,
    policy_index: int,
    baseline_bins: Mapping[str, int],
) -> Tuple[
    Tuple[ClosedLoopRollout, ...],
    Tuple[TrajectoryCreditReport, ...],
    Dict[str, float],
]:
    rollouts = []
    credits = []
    for instance in instances:
        credit = _trajectory_credit_report(
            instance,
            fallback,
            action_weights,
            state_weights,
            raw_threshold,
            max_interventions,
            cooldown_decisions,
            causal_prototypes,
            minimum_causal_affinity,
            sequence_weights,
            minimum_sequence_credit,
            partition,
            policy_index,
            baseline_bins[instance.instance_id],
        )
        credits.append(credit)
        rollouts.append(
            ClosedLoopRollout(
                instance.instance_id,
                partition,
                policy_index,
                raw_threshold,
                minimum_causal_affinity,
                minimum_sequence_credit,
                max_interventions,
                cooldown_decisions,
                baseline_bins[instance.instance_id],
                credit.full_candidate_bin_count,
                credit.intervention_indices,
            )
        )
    gains = tuple(rollout.outcome_gain for rollout in rollouts)
    aggregate_gain = sum(gains)
    marginals = tuple(
        marginal
        for credit in credits
        for marginal in credit.leave_one_out_credits
    )
    pairwise_interactions = tuple(
        interaction
        for credit in credits
        for _, _, interaction in credit.pairwise_interactions
    )
    attributable_gains = tuple(credit.attributable_gain for credit in credits)
    aggregate_attributed_gain = sum(attributable_gains)
    harmful_marginal_instance_count = sum(
        any(marginal < 0 for marginal in credit.leave_one_out_credits)
        for credit in credits
    )
    report = {
        "policy_index": float(policy_index),
        "raw_threshold": float(raw_threshold),
        "minimum_causal_affinity": float(minimum_causal_affinity),
        "minimum_sequence_credit": float(minimum_sequence_credit),
        "max_interventions": float(max_interventions),
        "cooldown_decisions": float(cooldown_decisions),
        "instance_count": float(len(gains)),
        "aggregate_outcome_gain": float(aggregate_gain),
        "mean_outcome_gain": mean(gains) if gains else 0.0,
        "wins": float(sum(value > 0 for value in gains)),
        "losses": float(sum(value < 0 for value in gains)),
        "maximum_regression": float(max((0, *(-value for value in gains)))),
        "intervention_count": float(
            sum(len(rollout.intervention_indices) for rollout in rollouts)
        ),
        "intervened_instance_count": float(
            sum(bool(rollout.intervention_indices) for rollout in rollouts)
        ),
        "leave_one_instance_out_min_gain": float(
            min(
                (aggregate_gain - value for value in gains),
                default=0,
            )
        ),
        "trajectory_credit_instance_count": float(
            sum(bool(credit.intervention_indices) for credit in credits)
        ),
        "trajectory_credit_subset_count": float(
            sum(len(credit.subset_outcome_gains) for credit in credits)
        ),
        "trajectory_marginal_count": float(len(marginals)),
        "aggregate_marginal_credit": float(sum(marginals)),
        "minimum_marginal_credit": float(min(marginals, default=0)),
        "harmful_marginal_instance_count": float(
            harmful_marginal_instance_count
        ),
        "credited_win_count": float(
            sum(value > 0 for value in attributable_gains)
        ),
        "aggregate_attributed_gain": float(aggregate_attributed_gain),
        "credit_leave_one_instance_out_min_gain": float(
            min(
                (
                    aggregate_attributed_gain - value
                    for value in attributable_gains
                ),
                default=0,
            )
        ),
        "aggregate_pairwise_interaction": float(
            sum(pairwise_interactions)
        ),
        "maximum_pairwise_antagonism": float(
            max((0, *(-value for value in pairwise_interactions)))
        ),
    }
    return tuple(rollouts), tuple(credits), report


def _episode_policy_is_safe(report: Mapping[str, float]) -> bool:
    return (
        report["instance_count"] >= 3.0
        and report["aggregate_outcome_gain"] > 0.0
        and report["mean_outcome_gain"] > 0.0
        and report["wins"] >= 2.0
        and report["wins"] > report["losses"]
        and report["maximum_regression"] <= 1.0
        and report["intervened_instance_count"] >= 2.0
        and report["leave_one_instance_out_min_gain"] > 0.0
        and report["trajectory_credit_instance_count"] >= 2.0
        and report["credited_win_count"] >= 2.0
        and report["aggregate_attributed_gain"] > 0.0
        and report["credit_leave_one_instance_out_min_gain"] > 0.0
        and report["aggregate_marginal_credit"] > 0.0
        and report["minimum_marginal_credit"] >= -1.0
        and report["credited_win_count"]
        > report["harmful_marginal_instance_count"]
        and report["maximum_pairwise_antagonism"] <= 1.0
    )


def fit_calibrated_override_value_model(
    instances: Sequence[BinPackingInstance],
    fallback: OnlineHeuristic,
    *,
    seed: int,
    causal_prototypes: Sequence[CausalStatePrototype] = (),
    max_trace_decisions_per_instance: int = 32,
    require_causal_prototypes: bool = False,
) -> OverrideValueTrainingResult:
    """Fit actions on traces and authorization on independent episodes."""

    if require_causal_prototypes and not causal_prototypes:
        raise ValueError(
            "episode-transport authorization requires an empirically "
            "supported causal-state prototype"
        )

    fit_ids, action_ids, policy_ids, gate_ids = _partition_instance_ids(
        tuple(instance.instance_id for instance in instances),
        seed,
    )
    instance_by_id = {instance.instance_id: instance for instance in instances}
    instance_partitions = {
        "fit": tuple(instance_by_id[item] for item in fit_ids),
        "action_holdout": tuple(instance_by_id[item] for item in action_ids),
        "policy_fit": tuple(instance_by_id[item] for item in policy_ids),
        "gate_holdout": tuple(instance_by_id[item] for item in gate_ids),
    }
    trace_source_instances = (
        *instance_partitions["fit"],
        *instance_partitions["action_holdout"],
    )
    initial_traces = collect_action_value_traces(
        trace_source_instances,
        fallback,
        max_decisions_per_instance=max_trace_decisions_per_instance,
    )
    initial_by_partition = {
        "fit": tuple(
            trace for trace in initial_traces if trace.instance_id in fit_ids
        ),
        "action_holdout": tuple(
            trace
            for trace in initial_traces
            if trace.instance_id in action_ids
        ),
    }
    if any(not values for values in initial_by_partition.values()):
        raise ValueError("episode-transport action trace partition is empty")

    prototypes = tuple(
        sorted(
            {prototype.cluster_id: prototype for prototype in causal_prototypes}
            .values(),
            key=lambda prototype: prototype.cluster_id,
        )
    )
    exploratory_affinity = MINIMUM_CAUSAL_AFFINITY if prototypes else 0.0

    action_candidates = []
    for learning_rate in (0.10, 0.25, 0.50):
        for epochs in (12, 36):
            weights = _fit_action_weights(
                initial_by_partition["fit"],
                learning_rate=learning_rate,
                epochs=epochs,
            )
            metrics = _action_metrics(
                weights,
                initial_by_partition["action_holdout"],
            )
            action_candidates.append(
                (
                    "conservative_pairwise_advantage:lr=%g:epochs=%d"
                    % (learning_rate, epochs),
                    learning_rate,
                    epochs,
                    weights,
                    metrics,
                )
            )
    (
        selected_action_design,
        selected_learning_rate,
        selected_epochs,
        action_weights,
        _,
    ) = max(
        action_candidates,
        key=lambda item: (
            item[4]["aggregate_outcome_gain"],
            -item[4]["maximum_regression"],
            item[4]["strict_pair_accuracy"],
            item[4]["win_rate"] - item[4]["loss_rate"],
            item[0],
        ),
    )

    capacity_by_instance = {
        instance.instance_id: instance.capacity for instance in instances
    }
    fit_traces = list(initial_by_partition["fit"])
    seen_fit_trace_ids = {trace.trace_id for trace in fit_traces}
    state_weights = (0.0,) * len(OVERRIDE_STATE_FEATURES)
    for aggregation_iteration in range(ON_POLICY_AGGREGATION_ITERATIONS):
        fit_state_rows = tuple(
            _trace_state_row(
                action_weights,
                trace,
                capacity_by_instance[trace.instance_id],
            )
            for trace in fit_traces
        )
        state_weights = _fit_state_weights(fit_state_rows)
        changed_fit_scores = tuple(
            _vector_dot(state_weights, features)
            for features, _, changed in fit_state_rows
            if changed
        )
        exploratory_threshold = _quantile(changed_fit_scores, 0.75)
        on_policy_traces = _collect_closed_loop_action_traces(
            instance_partitions["fit"],
            fallback,
            action_weights,
            state_weights,
            exploratory_threshold,
            DEFAULT_MAX_INTERVENTIONS,
            DEFAULT_COOLDOWN_DECISIONS,
            "closed_loop_fit_iteration_%d" % (aggregation_iteration + 1),
            prototypes,
            exploratory_affinity,
            max_trace_decisions_per_instance,
        )
        for trace in on_policy_traces:
            if trace.trace_id not in seen_fit_trace_ids:
                seen_fit_trace_ids.add(trace.trace_id)
                fit_traces.append(trace)
        action_weights = _fit_action_weights(
            fit_traces,
            learning_rate=selected_learning_rate,
            epochs=selected_epochs,
        )

    fit_state_rows = tuple(
        _trace_state_row(
            action_weights,
            trace,
            capacity_by_instance[trace.instance_id],
        )
        for trace in fit_traces
    )
    state_weights = _fit_state_weights(fit_state_rows)
    changed_fit_scores = tuple(
        _vector_dot(state_weights, features)
        for features, _, changed in fit_state_rows
        if changed
    )
    threshold_candidates = tuple(
        dict.fromkeys(
            _quantile(changed_fit_scores, fraction)
            for fraction in (0.50, 0.65, 0.80, 0.90, 0.95)
        )
    ) or (1.0,)

    affinity_candidates = (
        (0.20, 0.35, 0.50, 0.65) if prototypes else (0.0,)
    )
    fit_baseline_bins = {
        instance.instance_id: pack(instance, fallback).bin_count
        for instance in instance_partitions["fit"]
    }
    trajectory_fit_credits = []
    trajectory_fit_rows = []
    exploratory_affinities = tuple(
        dict.fromkeys(
            (
                affinity_candidates[0],
                affinity_candidates[len(affinity_candidates) // 2],
            )
        )
    )
    trajectory_policy_index = 0
    for threshold in threshold_candidates:
        for minimum_affinity in exploratory_affinities:
            for max_interventions in (2, 3):
                for instance in instance_partitions["fit"]:
                    credit = _trajectory_credit_report(
                        instance,
                        fallback,
                        action_weights,
                        state_weights,
                        threshold,
                        max_interventions,
                        DEFAULT_COOLDOWN_DECISIONS,
                        prototypes,
                        minimum_affinity,
                        (),
                        -1_000_000.0,
                        "trajectory_credit_fit",
                        trajectory_policy_index,
                        fit_baseline_bins[instance.instance_id],
                    )
                    trajectory_fit_credits.append(credit)
                    trajectory_fit_rows.extend(
                        zip(
                            credit.intervention_features,
                            credit.leave_one_out_credits,
                        )
                    )
                trajectory_policy_index += 1
    sequence_weights = _fit_sequence_credit_weights(trajectory_fit_rows)
    sequence_fit_metrics = _sequence_credit_metrics(
        sequence_weights,
        trajectory_fit_rows,
    )
    predicted_positive_marginals = tuple(
        _vector_dot(sequence_weights, features)
        for features, marginal in trajectory_fit_rows
        if marginal > 0
    )
    sequence_threshold_candidates = (
        tuple(
            dict.fromkeys(
                max(0.0, _quantile(predicted_positive_marginals, fraction))
                for fraction in (0.25, 0.50, 0.75)
            )
        )
        if predicted_positive_marginals
        else (1.0,)
    )

    action_exploration_threshold = _quantile(changed_fit_scores, 0.75)
    closed_loop_action_holdout = _collect_closed_loop_action_traces(
        instance_partitions["action_holdout"],
        fallback,
        action_weights,
        state_weights,
        action_exploration_threshold,
        DEFAULT_MAX_INTERVENTIONS,
        DEFAULT_COOLDOWN_DECISIONS,
        "closed_loop_action_holdout",
        prototypes,
        exploratory_affinity,
        max_trace_decisions_per_instance,
    )
    initial_action_metrics = _action_metrics(
        action_weights,
        initial_by_partition["action_holdout"],
    )
    closed_loop_action_metrics = _action_metrics(
        action_weights,
        closed_loop_action_holdout,
    )
    action_holdout_passed = (
        initial_action_metrics["aggregate_outcome_gain"] > 0.0
        and initial_action_metrics["mean_outcome_gain"] > 0.0
        and initial_action_metrics["win_rate"]
        > initial_action_metrics["loss_rate"]
        and initial_action_metrics["maximum_regression"] <= 1.0
        and closed_loop_action_metrics["aggregate_outcome_gain"] > 0.0
        and closed_loop_action_metrics["mean_outcome_gain"] > 0.0
        and closed_loop_action_metrics["win_rate"]
        > closed_loop_action_metrics["loss_rate"]
        and closed_loop_action_metrics["maximum_regression"] <= 1.0
    )

    baseline_bins = {
        instance.instance_id: pack(instance, fallback).bin_count
        for partition in ("policy_fit", "gate_holdout")
        for instance in instance_partitions[partition]
    }
    all_rollouts = []
    all_trajectory_credits = list(trajectory_fit_credits)
    policy_candidates = []
    policy_index = 0
    for threshold in threshold_candidates:
        for minimum_affinity in affinity_candidates:
            for minimum_sequence_credit in sequence_threshold_candidates:
                for max_interventions in (1, 2, 3):
                    rollouts, credits, report = _episode_policy_report(
                        instance_partitions["policy_fit"],
                        fallback,
                        action_weights,
                        state_weights,
                        threshold,
                        minimum_affinity,
                        sequence_weights,
                        minimum_sequence_credit,
                        max_interventions,
                        DEFAULT_COOLDOWN_DECISIONS,
                        prototypes,
                        "policy_fit",
                        policy_index,
                        baseline_bins,
                    )
                    all_rollouts.extend(rollouts)
                    all_trajectory_credits.extend(credits)
                    policy_candidates.append((report, rollouts, credits))
                    policy_index += 1
    safe_policy_candidates = tuple(
        candidate
        for candidate in policy_candidates
        if _episode_policy_is_safe(candidate[0])
    )
    selected_policy = (
        max(
            safe_policy_candidates,
            key=lambda candidate: (
                candidate[0]["leave_one_instance_out_min_gain"],
                candidate[0]["credit_leave_one_instance_out_min_gain"],
                candidate[0]["aggregate_attributed_gain"],
                candidate[0]["aggregate_outcome_gain"],
                candidate[0]["wins"] - candidate[0]["losses"],
                -candidate[0]["intervention_count"],
                candidate[0]["minimum_causal_affinity"],
                -candidate[0]["max_interventions"],
                candidate[0]["raw_threshold"],
            ),
        )
        if safe_policy_candidates
        else None
    )

    gate_report: Optional[Dict[str, float]] = None
    if selected_policy is not None:
        selected_report = selected_policy[0]
        gate_rollouts, gate_credits, gate_report = _episode_policy_report(
            instance_partitions["gate_holdout"],
            fallback,
            action_weights,
            state_weights,
            selected_report["raw_threshold"],
            selected_report["minimum_causal_affinity"],
            sequence_weights,
            selected_report["minimum_sequence_credit"],
            int(selected_report["max_interventions"]),
            int(selected_report["cooldown_decisions"]),
            prototypes,
            "gate_holdout",
            int(selected_report["policy_index"]),
            baseline_bins,
        )
        all_rollouts.extend(gate_rollouts)
        all_trajectory_credits.extend(gate_credits)
    gate_passed = gate_report is not None and _episode_policy_is_safe(
        gate_report
    )
    deployment_enabled = bool(
        selected_policy is not None and gate_passed
    )

    selected_report = selected_policy[0] if selected_policy is not None else None
    raw_threshold = (
        float(selected_report["raw_threshold"])
        if selected_report is not None
        else max(threshold_candidates) + 1.0
    )
    minimum_causal_affinity = (
        float(selected_report["minimum_causal_affinity"])
        if selected_report is not None
        else (1.0 if prototypes else 0.0)
    )
    minimum_sequence_credit = (
        float(selected_report["minimum_sequence_credit"])
        if selected_report is not None
        else max(sequence_threshold_candidates) + 1.0
    )
    max_interventions = (
        int(selected_report["max_interventions"])
        if selected_report is not None
        else DEFAULT_MAX_INTERVENTIONS
    )
    selected_policy_design = (
        "trajectory_credit_transport:threshold=%g:affinity=%g:"
        "sequence_credit=%g:budget=%d"
        % (
            raw_threshold,
            minimum_causal_affinity,
            minimum_sequence_credit,
            max_interventions,
        )
        if selected_report is not None
        else "no_policy_fit_candidate_passed"
    )
    _, raw_std = _moments(changed_fit_scores)
    temperature = max(0.05, raw_std)

    action_calibration_rows = tuple(
        _trace_state_row(
            action_weights,
            trace,
            capacity_by_instance[trace.instance_id],
        )
        for trace in closed_loop_action_holdout
    )
    calibration_pairs = tuple(
        (
            _sigmoid(
                (_vector_dot(state_weights, features) - raw_threshold)
                / temperature
            ),
            float(outcome > 0),
        )
        for features, outcome, changed in action_calibration_rows
        if changed
    )
    brier = (
        mean(
            (probability - label) ** 2
            for probability, label in calibration_pairs
        )
        if calibration_pairs
        else 1.0
    )
    minimum_gate_instances = len(instance_partitions["gate_holdout"])
    calibration_metrics = tuple(
        sorted(
            {
                "action_holdout_passed": float(action_holdout_passed),
                "closed_loop_action_holdout_gain": float(
                    closed_loop_action_metrics["aggregate_outcome_gain"]
                ),
                "causal_prototype_count": float(len(prototypes)),
                "policy_fit_instance_count": float(
                    len(instance_partitions["policy_fit"])
                ),
                "policy_candidate_count": float(len(policy_candidates)),
                "sequence_threshold_candidate_count": float(
                    len(sequence_threshold_candidates)
                ),
                **sequence_fit_metrics,
                "safe_policy_fit_count": float(
                    len(safe_policy_candidates)
                ),
                "selected_policy_fit_aggregate_gain": float(
                    selected_report["aggregate_outcome_gain"]
                    if selected_report is not None
                    else 0.0
                ),
                "selected_policy_fit_leave_one_out_min_gain": float(
                    selected_report["leave_one_instance_out_min_gain"]
                    if selected_report is not None
                    else 0.0
                ),
                "selected_policy_fit_attributed_gain": float(
                    selected_report["aggregate_attributed_gain"]
                    if selected_report is not None
                    else 0.0
                ),
                "selected_policy_fit_credit_leave_one_out_min_gain": float(
                    selected_report["credit_leave_one_instance_out_min_gain"]
                    if selected_report is not None
                    else 0.0
                ),
                "gate_opened": float(gate_report is not None),
                "gate_instance_count": float(minimum_gate_instances),
                "gate_passed": float(gate_passed),
                "selected_aggregate_outcome_gain": float(
                    gate_report["aggregate_outcome_gain"]
                    if gate_report is not None
                    else 0.0
                ),
                "selected_mean_outcome_gain": float(
                    gate_report["mean_outcome_gain"]
                    if gate_report is not None
                    else 0.0
                ),
                "selected_win_rate": float(
                    gate_report["wins"] / minimum_gate_instances
                    if gate_report is not None
                    else 0.0
                ),
                "selected_loss_rate": float(
                    gate_report["losses"] / minimum_gate_instances
                    if gate_report is not None
                    else 0.0
                ),
                "selected_maximum_regression": float(
                    gate_report["maximum_regression"]
                    if gate_report is not None
                    else 0.0
                ),
                "leave_one_instance_out_min_gain": float(
                    gate_report["leave_one_instance_out_min_gain"]
                    if gate_report is not None
                    else 0.0
                ),
                "selected_attributed_gain": float(
                    gate_report["aggregate_attributed_gain"]
                    if gate_report is not None
                    else 0.0
                ),
                "selected_credit_leave_one_out_min_gain": float(
                    gate_report["credit_leave_one_instance_out_min_gain"]
                    if gate_report is not None
                    else 0.0
                ),
                "decision_brier_score": brier,
            }.items()
        )
    )

    action_evidence = tuple(
        dict.fromkeys(
            (
                *initial_by_partition["action_holdout"],
                *closed_loop_action_holdout,
            )
        )
    )
    trace_partitions = {
        "fit": tuple(fit_traces),
        "action_holdout": action_evidence,
        "policy_fit": (),
        "gate_holdout": (),
    }
    model = CalibratedOverrideValueModel(
        action_weights=action_weights,
        state_weights=state_weights,
        sequence_weights=sequence_weights,
        raw_threshold=raw_threshold,
        temperature=temperature,
        deployment_enabled=deployment_enabled,
        fit_instance_ids=fit_ids,
        action_holdout_instance_ids=action_ids,
        policy_fit_instance_ids=policy_ids,
        gate_holdout_instance_ids=gate_ids,
        fit_trace_ids=tuple(
            trace.trace_id for trace in trace_partitions["fit"]
        ),
        action_holdout_trace_ids=tuple(
            trace.trace_id for trace in trace_partitions["action_holdout"]
        ),
        policy_fit_trace_ids=(),
        gate_holdout_trace_ids=(),
        causal_prototypes=prototypes,
        minimum_causal_affinity=minimum_causal_affinity,
        minimum_sequence_credit=minimum_sequence_credit,
        selected_action_design=selected_action_design,
        selected_policy_design=selected_policy_design,
        minimum_gate_instances=minimum_gate_instances,
        max_interventions=max_interventions,
        cooldown_decisions=DEFAULT_COOLDOWN_DECISIONS,
        aggregation_iterations=ON_POLICY_AGGREGATION_ITERATIONS,
        calibration_metrics=calibration_metrics,
    )
    policy_fit_metrics = {
        "instance_count": float(len(instance_partitions["policy_fit"])),
        "candidate_policy_count": float(len(policy_candidates)),
        "safe_policy_count": float(len(safe_policy_candidates)),
        "selected_aggregate_outcome_gain": float(
            selected_report["aggregate_outcome_gain"]
            if selected_report is not None
            else 0.0
        ),
        "selected_leave_one_instance_out_min_gain": float(
            selected_report["leave_one_instance_out_min_gain"]
            if selected_report is not None
            else 0.0
        ),
        "selected_attributed_gain": float(
            selected_report["aggregate_attributed_gain"]
            if selected_report is not None
            else 0.0
        ),
        "selected_credit_leave_one_instance_out_min_gain": float(
            selected_report["credit_leave_one_instance_out_min_gain"]
            if selected_report is not None
            else 0.0
        ),
    }
    gate_metrics = {
        "instance_count": float(minimum_gate_instances),
        "gate_opened": float(gate_report is not None),
        "deployment_enabled": float(deployment_enabled),
        "safe_threshold_count": float(gate_passed),
        "selected_aggregate_outcome_gain": float(
            gate_report["aggregate_outcome_gain"]
            if gate_report is not None
            else 0.0
        ),
        "leave_one_instance_out_min_gain": float(
            gate_report["leave_one_instance_out_min_gain"]
            if gate_report is not None
            else 0.0
        ),
        "selected_attributed_gain": float(
            gate_report["aggregate_attributed_gain"]
            if gate_report is not None
            else 0.0
        ),
        "selected_credit_leave_one_instance_out_min_gain": float(
            gate_report["credit_leave_one_instance_out_min_gain"]
            if gate_report is not None
            else 0.0
        ),
    }
    partition_metrics = (
        (
            "fit",
            tuple(sorted(_action_metrics(action_weights, fit_traces).items())),
        ),
        (
            "action_holdout",
            tuple(
                sorted(
                    {
                        **closed_loop_action_metrics,
                        "diagnostic_passed": float(
                            action_holdout_passed
                        ),
                        "initial_aggregate_outcome_gain": (
                            initial_action_metrics["aggregate_outcome_gain"]
                        ),
                        "initial_mean_outcome_gain": (
                            initial_action_metrics["mean_outcome_gain"]
                        ),
                    }.items()
                )
            ),
        ),
        ("policy_fit", tuple(sorted(policy_fit_metrics.items()))),
        ("gate_holdout", tuple(sorted(gate_metrics.items()))),
    )
    all_traces = tuple(
        trace
        for partition in ("fit", "action_holdout")
        for trace in trace_partitions[partition]
    )
    return OverrideValueTrainingResult(
        model=model,
        traces=all_traces,
        closed_loop_rollouts=tuple(all_rollouts),
        trajectory_credits=tuple(all_trajectory_credits),
        trace_count=len(all_traces),
        action_row_count=sum(len(trace.rows) for trace in all_traces),
        partition_metrics=partition_metrics,
    )
