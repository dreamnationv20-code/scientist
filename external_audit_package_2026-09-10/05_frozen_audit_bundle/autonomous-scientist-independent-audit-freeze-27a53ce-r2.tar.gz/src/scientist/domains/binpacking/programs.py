from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import (
    Any,
    Dict,
    Iterable,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
    Union,
)

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import (
    FunSearchORReference,
    OnlineHeuristic,
    funsearch_or_score,
)
from scientist.domains.binpacking.code_policy import (
    GeneratedPolicyModuleProgram,
    GeneratedPolicyProgram,
)
from scientist.domains.binpacking.override_value import (
    CalibratedOverrideValueModel,
)


DSL_VERSION = "binpacking-priority-dsl-v2"
MAX_ABS_VALUE = 1_000_000.0
CONTEXTUAL_FEATURE_VERSION = "contextual-linear-features-v1"
CONTEXTUAL_FEATURES = (
    "bias",
    "negative_remaining_after",
    "exact_fill",
    "near_fill",
    "item",
    "load",
    "item_x_load",
    "remaining_squared",
    "is_new_bin",
    "bin_index",
    "open_bins",
    "recent_mean",
    "recent_std",
    "recent_large_fraction",
    "recent_trend",
    "load_mean",
    "load_std",
    "remaining_x_recent_mean",
    "remaining_x_recent_large_fraction",
    "item_x_recent_mean",
)
REGIME_ROUTER_VERSION = "regime-policy-router-v1"
REGIME_ROUTER_POLICIES = (
    "funsearch",
    "best_fit",
    "first_fit",
    "worst_fit",
    "next_fit",
)
REGIME_ROUTER_FEATURES = (
    "bias",
    "item",
    "recent_mean",
    "recent_std",
    "recent_large_fraction",
    "recent_trend",
    "open_bins",
    "load_mean",
    "load_std",
    "fullest_remaining",
)
DEMAND_MEMORY_VERSION = "empirical-demand-memory-v1"
DEMAND_MEMORY_FEATURES = (
    "bias",
    "negative_remaining_after",
    "exact_fill",
    "near_fill",
    "item",
    "load",
    "is_new_bin",
    "bin_index",
    "open_bins",
    "demand_density_after",
    "exact_complement_rate",
    "demand_density_preserved",
    "large_item_slot",
    "small_item_fragment",
)
MOONSHOT_PROGRAM_VERSION = "binpacking-moonshot-policy-v6"
MOONSHOT_TOPOLOGIES = (
    "robust_counterfactual_rollout",
    "residual_portfolio_controller",
    "bin_role_automaton",
    "sparse_syndrome_repair",
)
MOONSHOT_PARAMETER_COUNT = 6

FEATURES = (
    "item",
    "load",
    "remaining_before",
    "remaining_after",
    "fill_after",
    "bin_index",
    "open_bins",
    "is_new_bin",
    "seen_mean",
    "seen_min",
    "seen_std",
    "seen_large_fraction",
)
UNARY_OPERATORS = ("abs", "neg", "square", "sqrt", "step")
BINARY_OPERATORS = ("add", "sub", "mul", "safe_div", "min", "max")
CONSTANTS = (
    -2.0,
    -1.0,
    -0.5,
    -0.25,
    -0.1,
    -0.05,
    -0.02,
    0.0,
    0.02,
    0.05,
    0.1,
    0.25,
    0.5,
    1.0,
    2.0,
)


def _bounded(value: float) -> float:
    if not math.isfinite(value):
        return 0.0
    return max(-MAX_ABS_VALUE, min(MAX_ABS_VALUE, float(value)))


@dataclass(frozen=True)
class Expression:
    op: str
    value: Optional[Any] = None
    children: Tuple["Expression", ...] = ()

    def __post_init__(self) -> None:
        if self.op == "const":
            if self.children or not isinstance(self.value, (int, float)):
                raise ValueError("const requires a numeric value and no children")
            if not math.isfinite(float(self.value)):
                raise ValueError("const must be finite")
        elif self.op == "feature":
            if self.children or self.value not in FEATURES:
                raise ValueError("feature requires a known feature name")
        elif self.op in UNARY_OPERATORS:
            if self.value is not None or len(self.children) != 1:
                raise ValueError("%s requires one child" % self.op)
        elif self.op in BINARY_OPERATORS:
            if self.value is not None or len(self.children) != 2:
                raise ValueError("%s requires two children" % self.op)
        else:
            raise ValueError("unknown expression operation: %s" % self.op)

    @classmethod
    def const(cls, value: float) -> "Expression":
        return cls("const", float(value))

    @classmethod
    def feature(cls, name: str) -> "Expression":
        return cls("feature", name)

    @classmethod
    def unary(cls, op: str, child: "Expression") -> "Expression":
        return cls(op, None, (child,))

    @classmethod
    def binary(
        cls,
        op: str,
        left: "Expression",
        right: "Expression",
    ) -> "Expression":
        return cls(op, None, (left, right))

    @property
    def node_count(self) -> int:
        return 1 + sum(child.node_count for child in self.children)

    @property
    def depth(self) -> int:
        return 1 + max((child.depth for child in self.children), default=0)

    def evaluate(self, features: Mapping[str, float]) -> float:
        if self.op == "const":
            return float(self.value)
        if self.op == "feature":
            return _bounded(float(features[str(self.value)]))

        values = [child.evaluate(features) for child in self.children]
        if self.op == "abs":
            result = abs(values[0])
        elif self.op == "neg":
            result = -values[0]
        elif self.op == "square":
            result = values[0] * values[0]
        elif self.op == "sqrt":
            result = math.sqrt(abs(values[0]))
        elif self.op == "step":
            result = 1.0 if values[0] >= 0.0 else 0.0
        elif self.op == "add":
            result = values[0] + values[1]
        elif self.op == "sub":
            result = values[0] - values[1]
        elif self.op == "mul":
            result = values[0] * values[1]
        elif self.op == "safe_div":
            denominator = values[1]
            if abs(denominator) < 1e-6:
                denominator = 1e-6 if denominator >= 0 else -1e-6
            result = values[0] / denominator
        elif self.op == "min":
            result = min(values)
        elif self.op == "max":
            result = max(values)
        else:
            raise AssertionError("unreachable operation: %s" % self.op)
        return _bounded(result)

    def as_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {"op": self.op}
        if self.value is not None:
            result["value"] = self.value
        if self.children:
            result["children"] = [child.as_dict() for child in self.children]
        return result

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "Expression":
        return cls(
            op=str(value["op"]),
            value=value.get("value"),
            children=tuple(
                cls.from_dict(child) for child in value.get("children", ())
            ),
        )

    def render(self) -> str:
        if self.op == "const":
            return "%g" % float(self.value)
        if self.op == "feature":
            return str(self.value)
        if self.op == "neg":
            return "(-%s)" % self.children[0].render()
        if self.op == "abs":
            return "abs(%s)" % self.children[0].render()
        if self.op == "square":
            return "square(%s)" % self.children[0].render()
        if self.op == "sqrt":
            return "sqrt(abs(%s))" % self.children[0].render()
        if self.op == "step":
            return "step(%s)" % self.children[0].render()
        symbol = {
            "add": "+",
            "sub": "-",
            "mul": "*",
            "safe_div": "/",
            "min": "min",
            "max": "max",
        }[self.op]
        left, right = self.children
        if self.op in ("min", "max"):
            return "%s(%s, %s)" % (symbol, left.render(), right.render())
        return "(%s %s %s)" % (left.render(), symbol, right.render())


Path = Tuple[int, ...]


def expression_paths(expression: Expression) -> Tuple[Path, ...]:
    paths: List[Path] = [()]
    for index, child in enumerate(expression.children):
        paths.extend(
            (index,) + child_path
            for child_path in expression_paths(child)
        )
    return tuple(paths)


def expression_at(expression: Expression, path: Path) -> Expression:
    current = expression
    for index in path:
        current = current.children[index]
    return current


def replace_expression(
    expression: Expression,
    path: Path,
    replacement: Expression,
) -> Expression:
    if not path:
        return replacement
    index = path[0]
    children = list(expression.children)
    children[index] = replace_expression(children[index], path[1:], replacement)
    return Expression(expression.op, expression.value, tuple(children))


def random_expression(
    rng: random.Random,
    max_depth: int = 3,
) -> Expression:
    if max_depth <= 1 or rng.random() < 0.38:
        if rng.random() < 0.78:
            return Expression.feature(rng.choice(FEATURES))
        return Expression.const(rng.choice(CONSTANTS))
    if rng.random() < 0.30:
        return Expression.unary(
            rng.choice(UNARY_OPERATORS),
            random_expression(rng, max_depth - 1),
        )
    return Expression.binary(
        rng.choice(BINARY_OPERATORS),
        random_expression(rng, max_depth - 1),
        random_expression(rng, max_depth - 1),
    )


def _within_limits(
    expression: Expression,
    max_depth: int,
    max_nodes: int,
) -> bool:
    return (
        expression.depth <= max_depth
        and expression.node_count <= max_nodes
    )


def mutate_expression(
    expression: Expression,
    rng: random.Random,
    max_depth: int = 5,
    max_nodes: int = 31,
) -> Expression:
    for _ in range(24):
        path = rng.choice(expression_paths(expression))
        target = expression_at(expression, path)
        strategy = rng.choice(("replace", "operator", "wrap"))

        if strategy == "replace":
            replacement = random_expression(rng, rng.randint(1, 3))
        elif strategy == "operator":
            if target.op == "feature":
                replacement = Expression.feature(rng.choice(FEATURES))
            elif target.op == "const":
                replacement = Expression.const(
                    float(target.value) + rng.choice(CONSTANTS)
                )
            elif target.op in UNARY_OPERATORS:
                replacement = Expression.unary(
                    rng.choice(UNARY_OPERATORS),
                    target.children[0],
                )
            else:
                replacement = Expression.binary(
                    rng.choice(BINARY_OPERATORS),
                    target.children[0],
                    target.children[1],
                )
        elif rng.random() < 0.40:
            replacement = Expression.unary(
                rng.choice(UNARY_OPERATORS),
                target,
            )
        else:
            other = random_expression(rng, 2)
            if rng.random() < 0.5:
                left, right = target, other
            else:
                left, right = other, target
            replacement = Expression.binary(
                rng.choice(BINARY_OPERATORS),
                left,
                right,
            )

        candidate = replace_expression(expression, path, replacement)
        if candidate != expression and _within_limits(
            candidate,
            max_depth,
            max_nodes,
        ):
            return candidate

    fallback = random_expression(rng, min(3, max_depth))
    return fallback if _within_limits(fallback, max_depth, max_nodes) else expression


def crossover_expressions(
    left: Expression,
    right: Expression,
    rng: random.Random,
    max_depth: int = 5,
    max_nodes: int = 31,
) -> Expression:
    for _ in range(24):
        left_path = rng.choice(expression_paths(left))
        right_path = rng.choice(expression_paths(right))
        candidate = replace_expression(
            left,
            left_path,
            expression_at(right, right_path),
        )
        if candidate != left and _within_limits(
            candidate,
            max_depth,
            max_nodes,
        ):
            return candidate
    return mutate_expression(left, rng, max_depth, max_nodes)


@dataclass(frozen=True)
class PriorityProgram:
    expression: Expression

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "dsl_version": DSL_VERSION,
                "expression": self.expression.as_dict(),
            }
        )

    @property
    def name(self) -> str:
        return "program_" + self.candidate_id[:12]

    @property
    def complexity(self) -> int:
        return self.expression.node_count

    def as_dict(self) -> Dict[str, Any]:
        return {
            "dsl_version": DSL_VERSION,
            "candidate_id": self.candidate_id,
            "expression": self.expression.as_dict(),
            "rendered": self.expression.render(),
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        return _choose_priority_bin(
            self.expression,
            item,
            loads,
            capacity,
            history,
            residual_scale=1.0,
            include_funsearch_incumbent=False,
        )


@dataclass(frozen=True)
class FunSearchResidualProgram:
    """A searchable residual around the exact published FunSearch policy."""

    expression: Expression
    residual_scale: float = 0.05

    def __post_init__(self) -> None:
        if not math.isfinite(self.residual_scale) or self.residual_scale <= 0:
            raise ValueError("residual_scale must be positive and finite")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "funsearch_residual",
                "dsl_version": DSL_VERSION,
                "residual_scale": self.residual_scale,
                "expression": self.expression.as_dict(),
            }
        )

    @property
    def name(self) -> str:
        return "funsearch_residual_" + self.candidate_id[:12]

    @property
    def complexity(self) -> int:
        return self.expression.node_count

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "funsearch_residual",
            "dsl_version": DSL_VERSION,
            "candidate_id": self.candidate_id,
            "incumbent": "funsearch_or_reference",
            "residual_scale": self.residual_scale,
            "expression": self.expression.as_dict(),
            "rendered": (
                "funsearch_score + %g * (%s)"
                % (self.residual_scale, self.expression.render())
            ),
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        return _choose_priority_bin(
            self.expression,
            item,
            loads,
            capacity,
            history,
            residual_scale=self.residual_scale,
            include_funsearch_incumbent=True,
        )


@dataclass(frozen=True)
class HybridPolicyProgram:
    """Route each arrival between FunSearch and a de novo priority policy."""

    router_expression: Expression
    de_novo_expression: Expression

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "hybrid_router",
                "dsl_version": DSL_VERSION,
                "router_expression": self.router_expression.as_dict(),
                "de_novo_expression": self.de_novo_expression.as_dict(),
            }
        )

    @property
    def name(self) -> str:
        return "hybrid_" + self.candidate_id[:12]

    @property
    def complexity(self) -> int:
        return (
            1
            + self.router_expression.node_count
            + self.de_novo_expression.node_count
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "hybrid_router",
            "dsl_version": DSL_VERSION,
            "candidate_id": self.candidate_id,
            "router": self.router_expression.as_dict(),
            "router_rendered": self.router_expression.render(),
            "de_novo_policy": self.de_novo_expression.as_dict(),
            "de_novo_rendered": self.de_novo_expression.render(),
            "rendered": (
                "if %s >= 0: funsearch; else: priority(%s)"
                % (
                    self.router_expression.render(),
                    self.de_novo_expression.render(),
                )
            ),
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        features = _router_features(item, loads, capacity, history)
        if self.router_expression.evaluate(features) >= 0.0:
            return FunSearchORReference().choose_bin(
                item,
                loads,
                capacity,
                item_index,
                history,
            )
        return PriorityProgram(self.de_novo_expression).choose_bin(
            item,
            loads,
            capacity,
            item_index,
            history,
        )


@dataclass(frozen=True)
class ActionHybridProgram:
    """Gate a de novo action score inside the inherited FunSearch score."""

    router_expression: Expression
    de_novo_expression: Expression
    residual_scale: float = 0.10

    def __post_init__(self) -> None:
        if not math.isfinite(self.residual_scale) or self.residual_scale <= 0:
            raise ValueError("residual_scale must be positive and finite")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "action_hybrid_score",
                "dsl_version": DSL_VERSION,
                "residual_scale": self.residual_scale,
                "router_expression": self.router_expression.as_dict(),
                "de_novo_expression": self.de_novo_expression.as_dict(),
            }
        )

    @property
    def name(self) -> str:
        return "action_hybrid_" + self.candidate_id[:12]

    @property
    def complexity(self) -> int:
        return (
            2
            + self.router_expression.node_count
            + self.de_novo_expression.node_count
        )

    @property
    def gated_expression(self) -> Expression:
        return Expression.binary(
            "mul",
            Expression.unary("step", self.router_expression),
            self.de_novo_expression,
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "action_hybrid_score",
            "dsl_version": DSL_VERSION,
            "candidate_id": self.candidate_id,
            "incumbent": "funsearch_or_reference",
            "residual_scale": self.residual_scale,
            "router": self.router_expression.as_dict(),
            "router_rendered": self.router_expression.render(),
            "de_novo_policy": self.de_novo_expression.as_dict(),
            "de_novo_rendered": self.de_novo_expression.render(),
            "rendered": (
                "funsearch_score + %g * step(%s) * (%s)"
                % (
                    self.residual_scale,
                    self.router_expression.render(),
                    self.de_novo_expression.render(),
                )
            ),
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        return _choose_priority_bin(
            self.gated_expression,
            item,
            loads,
            capacity,
            history,
            residual_scale=self.residual_scale,
            include_funsearch_incumbent=True,
        )


def _unit_interval(value: float) -> float:
    if value >= 0.0:
        exponential = math.exp(-min(value, 40.0))
        return 1.0 / (1.0 + exponential)
    exponential = math.exp(max(value, -40.0))
    return exponential / (1.0 + exponential)


def _moonshot_scenarios(
    history: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    recent = tuple(int(item) for item in history[-16:])
    if not recent:
        return (
            max(1, capacity // 4),
            max(1, capacity // 2),
            max(1, (3 * capacity) // 4),
        )
    ordered = sorted(recent)
    indices = (
        0,
        len(ordered) // 4,
        len(ordered) // 2,
        (3 * len(ordered)) // 4,
        len(ordered) - 1,
    )
    return tuple(
        dict.fromkeys(
            max(1, min(capacity, ordered[index]))
            for index in indices
        )
    )


def _moonshot_suffixes(
    history: Sequence[int],
    capacity: int,
    horizon: int,
) -> Tuple[Tuple[int, ...], ...]:
    """Build a bounded, deterministic scenario ensemble from online history."""

    horizon = max(1, min(4, int(horizon)))
    recent = tuple(
        max(1, min(capacity, int(item)))
        for item in history[-32:]
    )
    quantiles = _moonshot_scenarios(recent, capacity)
    scenarios = []
    if recent:
        starts = tuple(
            dict.fromkeys(
                (
                    0,
                    max(0, len(recent) // 4),
                    max(0, len(recent) // 2),
                    max(0, (3 * len(recent)) // 4),
                    max(0, len(recent) - horizon),
                )
            )
        )
        for start in starts:
            suffix = tuple(
                recent[(start + offset) % len(recent)]
                for offset in range(horizon)
            )
            scenarios.append(suffix)
    for shift in range(min(5, len(quantiles))):
        scenarios.append(
            tuple(
                quantiles[(shift + offset) % len(quantiles)]
                for offset in range(horizon)
            )
        )
    return tuple(dict.fromkeys(scenarios))[:8]


def _post_action_loads(
    loads: Sequence[int],
    item: int,
    action: Optional[int],
) -> Tuple[int, ...]:
    if action is None:
        return (*loads, item)
    changed = list(loads)
    changed[action] += item
    return tuple(changed)


def _best_fit_action(
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Optional[int]:
    feasible = tuple(
        index
        for index, load in enumerate(loads)
        if load + item <= capacity
    )
    if not feasible:
        return None
    return min(
        feasible,
        key=lambda index: (
            capacity - loads[index] - item,
            index,
        ),
    )


def _moonshot_candidate_actions(
    item: int,
    loads: Sequence[int],
    capacity: int,
    *,
    limit: int = 8,
) -> Tuple[Optional[int], ...]:
    """Keep rollout branching structural but computationally bounded."""

    feasible = tuple(
        index
        for index, load in enumerate(loads)
        if load + item <= capacity
    )
    if len(feasible) <= max(1, limit - 1):
        return (*feasible, None)
    by_remaining = tuple(
        sorted(
            feasible,
            key=lambda index: (
                capacity - loads[index] - item,
                index,
            ),
        )
    )
    positions = (
        0,
        len(by_remaining) // 5,
        (2 * len(by_remaining)) // 5,
        (3 * len(by_remaining)) // 5,
        (4 * len(by_remaining)) // 5,
        len(by_remaining) - 1,
    )
    selected = tuple(
        dict.fromkeys(by_remaining[position] for position in positions)
    )
    return (*selected[: max(1, limit - 1)], None)


@dataclass(frozen=True)
class MoonshotProgram:
    """Incumbent-blind policies with non-scalar decision topologies."""

    topology: str
    parameters: Tuple[float, ...]

    def __post_init__(self) -> None:
        if self.topology not in MOONSHOT_TOPOLOGIES:
            raise ValueError("unsupported moonshot topology")
        if len(self.parameters) != MOONSHOT_PARAMETER_COUNT:
            raise ValueError("moonshot program has the wrong parameter count")
        if not all(math.isfinite(value) for value in self.parameters):
            raise ValueError("moonshot parameters must be finite")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "moonshot_policy",
                "dsl_version": DSL_VERSION,
                "moonshot_version": MOONSHOT_PROGRAM_VERSION,
                "topology": self.topology,
                "parameters": list(self.parameters),
            }
        )

    @property
    def name(self) -> str:
        return "moonshot_%s_%s" % (
            self.topology,
            self.candidate_id[:12],
        )

    @property
    def complexity(self) -> int:
        return 8 + sum(abs(value) > 1e-12 for value in self.parameters)

    @property
    def decision_topology(self) -> str:
        return "moonshot:" + self.topology

    @property
    def new_decision_primitives(self) -> Tuple[str, ...]:
        return {
            "robust_counterfactual_rollout": (
                "counterfactual_action_simulation",
                "history_derived_scenario_rollout",
                "robust_tail_objective",
                "uncertainty_adjusted_regret",
                "abstaining_override",
            ),
            "residual_portfolio_controller": (
                "residual_portfolio_coverage",
                "multi_target_option_preservation",
            ),
            "bin_role_automaton": (
                "state_dependent_bin_roles",
                "lexicographic_role_transition",
            ),
            "sparse_syndrome_repair": (
                "failure_syndrome_trigger",
                "sparse_corrective_override",
            ),
        }[self.topology]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "moonshot_policy",
            "dsl_version": DSL_VERSION,
            "moonshot_version": MOONSHOT_PROGRAM_VERSION,
            "candidate_id": self.candidate_id,
            "topology": self.topology,
            "parameters": list(self.parameters),
            "incumbent": None,
            "incumbent_blind": True,
            "decision_topology": self.decision_topology,
            "new_decision_primitives": list(
                self.new_decision_primitives
            ),
            "rendered": "%s%s" % (
                self.topology,
                tuple(round(value, 4) for value in self.parameters),
            ),
            "complexity": self.complexity,
        }

    def activation(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> float:
        residuals = tuple(capacity - load for load in loads)
        feasible_residuals = tuple(
            residual for residual in residuals if residual >= item
        )
        recent = tuple(history[-16:])
        recent_mean = (
            sum(recent) / float(len(recent) * capacity)
            if recent
            else 0.5
        )
        stranded_fraction = (
            sum(0 < residual < max(1, min(item, capacity // 4))
                for residual in residuals)
            / float(max(1, len(residuals)))
        )
        scarcity = 1.0 / float(1 + len(feasible_residuals))
        return max(
            0.0,
            min(
                1.0,
                0.35 * (item / float(capacity))
                + 0.30 * stranded_fraction
                + 0.20 * scarcity
                + 0.15 * abs(recent_mean - 0.5),
            ),
        )

    def _robust_rollout(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> Optional[int]:
        return self._robust_rollout_profile(
            item,
            loads,
            capacity,
            history,
        )[0]

    def _robust_rollout_profile(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> Tuple[
        Optional[int],
        Mapping[Optional[int], Tuple[float, Tuple[float, ...]]],
    ]:
        robust_weight = _unit_interval(self.parameters[0])
        fragmentation_weight = 2.0 * _unit_interval(self.parameters[1])
        open_cost = 0.25 + 2.75 * _unit_interval(self.parameters[2])
        dispersion_weight = 2.0 * _unit_interval(self.parameters[3])
        horizon = 1 + int(
            3.0 * _unit_interval(self.parameters[4])
        )
        uncertainty_weight = 2.0 * _unit_interval(
            self.parameters[5]
        )
        suffixes = _moonshot_suffixes(
            history,
            capacity,
            horizon,
        )
        minimum_scenario = min(
            item
            for suffix in suffixes
            for item in suffix
        )
        actions = _moonshot_candidate_actions(
            item,
            loads,
            capacity,
        )
        ranked = []
        profiles = {}
        for action in actions:
            post = _post_action_loads(loads, item, action)
            scenario_costs = []
            for suffix in suffixes:
                future = post
                future_opens = 0
                for future_item in suffix:
                    future_action = _best_fit_action(
                        future_item,
                        future,
                        capacity,
                    )
                    future_opens += int(future_action is None)
                    future = _post_action_loads(
                        future,
                        future_item,
                        future_action,
                    )
                residuals = tuple(capacity - load for load in future)
                stranded = sum(
                    residual
                    for residual in residuals
                    if 0 < residual < minimum_scenario
                ) / float(capacity)
                mean_residual = (
                    sum(residuals) / float(len(residuals))
                    if residuals
                    else 0.0
                )
                dispersion = (
                    sum(
                        abs(residual - mean_residual)
                        for residual in residuals
                    )
                    / float(max(1, len(residuals)) * capacity)
                )
                scenario_costs.append(
                    future_opens
                    + fragmentation_weight * stranded
                    + dispersion_weight * dispersion
                )
            expected = sum(scenario_costs) / len(scenario_costs)
            robust = max(scenario_costs)
            uncertainty = robust - min(scenario_costs)
            action_cost = (
                open_cost * float(action is None)
                + (1.0 - robust_weight) * expected
                + robust_weight * robust
                + uncertainty_weight * uncertainty
            )
            numeric = len(loads) if action is None else action
            ranked.append((action_cost, numeric, action))
            profiles[action] = (
                action_cost,
                tuple(scenario_costs),
            )
        selected = min(
            ranked,
            key=lambda value: (value[0], value[1]),
        )[2]
        return selected, profiles

    def proposed_override(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
        fallback_action: Optional[int],
    ) -> Tuple[Optional[int], float]:
        """Return a proposal and confidence after uncertainty-adjusted regret."""

        if self.topology != "robust_counterfactual_rollout":
            return (
                self.choose_bin(
                    item,
                    loads,
                    capacity,
                    len(history),
                    history,
                ),
                self.activation(
                    item,
                    loads,
                    capacity,
                    history,
                ),
            )
        selected, profiles = self._robust_rollout_profile(
            item,
            loads,
            capacity,
            history,
        )
        if (
            selected == fallback_action
            or fallback_action not in profiles
        ):
            return selected, 0.0
        selected_cost, selected_scenarios = profiles[selected]
        fallback_cost, fallback_scenarios = profiles[fallback_action]
        advantage = fallback_cost - selected_cost
        if advantage <= 0.0:
            return selected, 0.0
        paired_regrets = tuple(
            fallback - proposal
            for fallback, proposal in zip(
                fallback_scenarios,
                selected_scenarios,
            )
        )
        support = sum(regret > 0.0 for regret in paired_regrets) / float(
            len(paired_regrets)
        )
        adverse = max(
            (max(0.0, -regret) for regret in paired_regrets),
            default=0.0,
        )
        normalized_advantage = advantage / (
            1.0 + abs(fallback_cost)
        )
        uncertainty_penalty = adverse / (
            1.0 + abs(fallback_cost)
        )
        confidence = support * max(
            0.0,
            normalized_advantage - uncertainty_penalty,
        )
        return selected, max(0.0, min(1.0, confidence))

    def _residual_portfolio(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> Optional[int]:
        coverage_weight = 0.5 + 3.5 * _unit_interval(
            self.parameters[0]
        )
        closeness_weight = 2.0 * _unit_interval(self.parameters[1])
        open_cost = 0.25 + 2.75 * _unit_interval(self.parameters[2])
        diversity_weight = 2.0 * _unit_interval(self.parameters[3])
        targets = _moonshot_scenarios(history, capacity)
        actions: Tuple[Optional[int], ...] = (
            *(
                index
                for index, load in enumerate(loads)
                if load + item <= capacity
            ),
            None,
        )
        ranked = []
        for action in actions:
            post = _post_action_loads(loads, item, action)
            residuals = tuple(capacity - load for load in post)
            uncovered = sum(
                not any(residual >= target for residual in residuals)
                for target in targets
            ) / float(len(targets))
            closeness = sum(
                min(abs(residual - target) for residual in residuals)
                for target in targets
            ) / float(len(targets) * capacity)
            occupied_bands = len(
                {
                    min(5, int(6 * residual / float(capacity)))
                    for residual in residuals
                    if residual > 0
                }
            )
            diversity_gap = 1.0 - occupied_bands / 6.0
            cost = (
                open_cost * float(action is None)
                + coverage_weight * uncovered
                + closeness_weight * closeness
                + diversity_weight * diversity_gap
            )
            numeric = len(loads) if action is None else action
            ranked.append((cost, numeric, action))
        return min(ranked, key=lambda value: (value[0], value[1]))[2]

    def _bin_role_automaton(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> Optional[int]:
        lower = 0.20 + 0.25 * _unit_interval(self.parameters[0])
        upper = 0.50 + 0.30 * _unit_interval(self.parameters[1])
        reserve_threshold = (
            0.15 + 0.35 * _unit_interval(self.parameters[2])
        )
        normalized_item = item / float(capacity)
        recent_large = (
            sum(value > capacity / 2 for value in history[-16:])
            / float(max(1, len(history[-16:])))
        )
        actions: Tuple[Optional[int], ...] = (
            *(
                index
                for index, load in enumerate(loads)
                if load + item <= capacity
            ),
            None,
        )
        ranked = []
        for action in actions:
            load = 0 if action is None else loads[action]
            remaining = capacity - load - item
            normalized_remaining = remaining / float(capacity)
            if normalized_item >= upper:
                role_mismatch = abs(
                    normalized_remaining - reserve_threshold
                )
                role = 0
            elif normalized_item <= lower:
                role_mismatch = normalized_remaining
                role = 1
            else:
                desired = (
                    reserve_threshold
                    + 0.25 * recent_large
                )
                role_mismatch = abs(normalized_remaining - desired)
                role = 2
            open_penalty = (
                (0.5 + _unit_interval(self.parameters[3]))
                * float(action is None)
            )
            numeric = len(loads) if action is None else action
            ranked.append(
                (role, role_mismatch + open_penalty, numeric, action)
            )
        return min(
            ranked,
            key=lambda value: (value[0], value[1], value[2]),
        )[3]

    def _sparse_syndrome_repair(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        history: Sequence[int],
    ) -> Optional[int]:
        trigger = 0.20 + 0.65 * _unit_interval(self.parameters[0])
        activation = self.activation(
            item,
            loads,
            capacity,
            history,
        )
        feasible = tuple(
            index
            for index, load in enumerate(loads)
            if load + item <= capacity
        )
        if activation < trigger:
            return feasible[0] if feasible else None
        targets = _moonshot_scenarios(history, capacity)
        actions: Tuple[Optional[int], ...] = (*feasible, None)
        ranked = []
        for action in actions:
            post = _post_action_loads(loads, item, action)
            residuals = tuple(capacity - load for load in post)
            coverage = sum(
                any(residual >= target for residual in residuals)
                for target in targets
            )
            smallest_positive = min(
                (residual for residual in residuals if residual > 0),
                default=capacity,
            )
            numeric = len(loads) if action is None else action
            ranked.append(
                (
                    -coverage,
                    -smallest_positive,
                    float(action is None),
                    numeric,
                    action,
                )
            )
        return min(ranked, key=lambda value: value[:4])[4]

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        del item_index
        if self.topology == "robust_counterfactual_rollout":
            return self._robust_rollout(
                item,
                loads,
                capacity,
                history,
            )
        if self.topology == "residual_portfolio_controller":
            return self._residual_portfolio(
                item,
                loads,
                capacity,
                history,
            )
        if self.topology == "bin_role_automaton":
            return self._bin_role_automaton(
                item,
                loads,
                capacity,
                history,
            )
        return self._sparse_syndrome_repair(
            item,
            loads,
            capacity,
            history,
        )


@dataclass(frozen=True)
class MoonshotHybridProgram:
    """A bounded sparse gate between inherited and moonshot mechanisms."""

    ancestry_expression: Expression
    moonshot: MoonshotProgram
    gate_threshold: float = 0.65
    residual_scale: float = 0.10

    def __post_init__(self) -> None:
        if not 0.0 <= self.gate_threshold <= 1.0:
            raise ValueError("moonshot hybrid gate must be in [0, 1]")
        if not math.isfinite(self.residual_scale) or self.residual_scale <= 0:
            raise ValueError("residual scale must be positive and finite")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "moonshot_hybrid",
                "dsl_version": DSL_VERSION,
                "moonshot_version": MOONSHOT_PROGRAM_VERSION,
                "ancestry_expression": self.ancestry_expression.as_dict(),
                "moonshot": self.moonshot.as_dict(),
                "gate_threshold": self.gate_threshold,
                "residual_scale": self.residual_scale,
            }
        )

    @property
    def name(self) -> str:
        return "moonshot_hybrid_" + self.candidate_id[:12]

    @property
    def complexity(self) -> int:
        return (
            3
            + self.ancestry_expression.node_count
            + self.moonshot.complexity
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "moonshot_hybrid",
            "dsl_version": DSL_VERSION,
            "moonshot_version": MOONSHOT_PROGRAM_VERSION,
            "candidate_id": self.candidate_id,
            "incumbent": "funsearch_or_reference",
            "ancestry_expression": self.ancestry_expression.as_dict(),
            "moonshot": self.moonshot.as_dict(),
            "gate_threshold": self.gate_threshold,
            "residual_scale": self.residual_scale,
            "decision_topology": "sparse_moonshot_override",
            "new_decision_primitives": [
                "failure_syndrome_gate",
                *self.moonshot.new_decision_primitives,
            ],
            "rendered": (
                "if moonshot_override_confidence >= %.3f: %s; "
                "else: funsearch_residual(%s)"
                % (
                    self.gate_threshold,
                    self.moonshot.topology,
                    self.ancestry_expression.render(),
                )
            ),
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        fallback = FunSearchResidualProgram(
            self.ancestry_expression,
            self.residual_scale,
        ).choose_bin(
            item,
            loads,
            capacity,
            item_index,
            history,
        )
        proposal, confidence = self.moonshot.proposed_override(
            item,
            loads,
            capacity,
            history,
            fallback,
        )
        if confidence >= self.gate_threshold:
            return proposal
        return fallback


@dataclass(frozen=True)
class StructuralHybridProgram:
    """A sparse structural override around any registered ancestry policy.

    Revision campaigns use this representation to keep the de-novo island's
    decision primitive intact.  It avoids translating a moonshot back into
    the active revision's coefficient vector merely to make hybridization
    type-compatible.
    """

    ancestry: OnlineHeuristic
    moonshot: MoonshotProgram
    gate_threshold: float = 0.65

    def __post_init__(self) -> None:
        if not 0.0 <= self.gate_threshold <= 1.0:
            raise ValueError("structural hybrid gate must be in [0, 1]")
        if not callable(getattr(self.ancestry, "choose_bin", None)):
            raise ValueError("structural hybrid ancestry is not executable")
        if not callable(getattr(self.ancestry, "as_dict", None)):
            raise ValueError(
                "structural hybrid ancestry is not serializable"
            )

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "structural_hybrid",
                "dsl_version": DSL_VERSION,
                "moonshot_version": MOONSHOT_PROGRAM_VERSION,
                "ancestry": self.ancestry.as_dict(),
                "moonshot": self.moonshot.as_dict(),
                "gate_threshold": self.gate_threshold,
            }
        )

    @property
    def name(self) -> str:
        return "structural_hybrid_" + self.candidate_id[:12]

    @property
    def complexity(self) -> int:
        return (
            3
            + int(getattr(self.ancestry, "complexity", 1))
            + self.moonshot.complexity
        )

    def as_dict(self) -> Dict[str, Any]:
        ancestry_value = self.ancestry.as_dict()
        return {
            "program_kind": "structural_hybrid",
            "dsl_version": DSL_VERSION,
            "moonshot_version": MOONSHOT_PROGRAM_VERSION,
            "candidate_id": self.candidate_id,
            "incumbent": ancestry_value.get(
                "candidate_id",
                self.ancestry.name,
            ),
            "ancestry": ancestry_value,
            "moonshot": self.moonshot.as_dict(),
            "gate_threshold": self.gate_threshold,
            "decision_topology": "typed_structural_override",
            "new_decision_primitives": [
                "state_conditioned_structural_override",
                *self.moonshot.new_decision_primitives,
            ],
            "rendered": (
                "if moonshot_override_confidence >= %.3f: %s; "
                "else: ancestry[%s]"
                % (
                    self.gate_threshold,
                    self.moonshot.topology,
                    ancestry_value.get(
                        "decision_topology",
                        ancestry_value.get(
                            "program_kind",
                            self.ancestry.name,
                        ),
                    ),
                )
            ),
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        fallback = self.ancestry.choose_bin(
            item,
            loads,
            capacity,
            item_index,
            history,
        )
        proposal, confidence = self.moonshot.proposed_override(
            item,
            loads,
            capacity,
            history,
            fallback,
        )
        if confidence >= self.gate_threshold:
            return proposal
        return fallback


@dataclass(frozen=True)
class CalibratedOverrideActionProgram:
    """The learned action ranker without its calibrated abstention gate."""

    ancestry: OnlineHeuristic
    override_model: CalibratedOverrideValueModel

    def __post_init__(self) -> None:
        if not callable(getattr(self.ancestry, "choose_bin", None)):
            raise ValueError("calibrated action ancestry is not executable")
        if not callable(getattr(self.ancestry, "as_dict", None)):
            raise ValueError("calibrated action ancestry is not serializable")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "calibrated_override_action",
                "dsl_version": DSL_VERSION,
                "ancestry": self.ancestry.as_dict(),
                "override_model": self.override_model.as_dict(),
            }
        )

    @property
    def name(self) -> str:
        return "calibrated_override_action_" + self.candidate_id[:12]

    @property
    def complexity(self) -> int:
        return 2 + self.override_model.complexity

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "calibrated_override_action",
            "dsl_version": DSL_VERSION,
            "candidate_id": self.candidate_id,
            "ancestry": self.ancestry.as_dict(),
            "override_model": self.override_model.as_dict(),
            "decision_topology": "learned_counterfactual_action_ranker",
            "rendered": (
                "counterfactual_action_value_ranker[%s]"
                % self.override_model.model_id[:12]
            ),
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        fallback = self.ancestry.choose_bin(
            item,
            loads,
            capacity,
            item_index,
            history,
        )
        proposal, _ = self.override_model.ranked_action(
            item,
            loads,
            capacity,
            history,
            fallback,
        )
        return proposal


@dataclass(frozen=True)
class CalibratedOverrideHybridProgram:
    """A budgeted closed-loop selector gated by clustered calibration."""

    ancestry: OnlineHeuristic
    override_model: CalibratedOverrideValueModel
    confidence_threshold: float = 0.5

    def __post_init__(self) -> None:
        if not callable(getattr(self.ancestry, "choose_bin", None)):
            raise ValueError("calibrated override ancestry is not executable")
        if not callable(getattr(self.ancestry, "as_dict", None)):
            raise ValueError("calibrated override ancestry is not serializable")
        if not 0.0 <= self.confidence_threshold <= 1.0:
            raise ValueError("calibrated confidence threshold is invalid")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "calibrated_override_hybrid",
                "dsl_version": DSL_VERSION,
                "ancestry": self.ancestry.as_dict(),
                "override_model": self.override_model.as_dict(),
                "confidence_threshold": self.confidence_threshold,
            }
        )

    @property
    def name(self) -> str:
        return "calibrated_override_hybrid_" + self.candidate_id[:12]

    @property
    def complexity(self) -> int:
        return (
            4
            + int(getattr(self.ancestry, "complexity", 1))
            + self.override_model.complexity
        )

    @property
    def new_decision_primitives(self) -> Tuple[str, ...]:
        return (
            "strict_pairwise_advantage_supervision",
            "ancestry_default_action_margin",
            "on_policy_trace_aggregation",
            "four_way_nested_instance_holdout",
            "complete_episode_policy_selection",
            "closed_loop_intervention_subset_ablation",
            "leave_one_intervention_out_trajectory_credit",
            "pairwise_intervention_interaction_credit",
            "fit_only_sequence_credit_model",
            "causal_cluster_authorization",
            "single_frozen_policy_gate",
            "instance_clustered_calibration",
            "leave_one_instance_out_stability",
            "budgeted_override_with_cooldown",
            "abstaining_learned_override",
        )

    def as_dict(self) -> Dict[str, Any]:
        ancestry_value = self.ancestry.as_dict()
        return {
            "program_kind": "calibrated_override_hybrid",
            "dsl_version": DSL_VERSION,
            "candidate_id": self.candidate_id,
            "incumbent": ancestry_value.get(
                "candidate_id",
                self.ancestry.name,
            ),
            "ancestry": ancestry_value,
            "override_model": self.override_model.as_dict(),
            "confidence_threshold": self.confidence_threshold,
            "decision_topology": (
                "trajectory_credit_episode_transport_override"
            ),
            "new_decision_primitives": list(self.new_decision_primitives),
            "rendered": (
                "if closed_loop_value_probability >= %.3f and "
                "predicted_trajectory_marginal >= %.3f and "
                "budget[%d]/cooldown[%d] allow: "
                "causal_cluster_episode_ranker[%s]; "
                "else: ancestry[%s]"
                % (
                    self.confidence_threshold,
                    self.override_model.minimum_sequence_credit,
                    self.override_model.max_interventions,
                    self.override_model.cooldown_decisions,
                    self.override_model.model_id[:12],
                    ancestry_value.get(
                        "decision_topology",
                        ancestry_value.get("program_kind", self.ancestry.name),
                    ),
                )
            ),
            "complexity": self.complexity,
        }

    def override_decision(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Tuple[Optional[int], Optional[int], float, float]:
        fallback = self.ancestry.choose_bin(
            item,
            loads,
            capacity,
            item_index,
            history,
        )
        proposal, confidence, raw_value = (
            self.override_model.budgeted_proposed_override(
                item,
                loads,
                capacity,
                item_index,
                history,
                self.ancestry,
                fallback,
                self.confidence_threshold,
            )
        )
        return fallback, proposal, confidence, raw_value

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        fallback, proposal, confidence, _ = self.override_decision(
            item,
            loads,
            capacity,
            item_index,
            history,
        )
        if confidence >= self.confidence_threshold:
            return proposal
        return fallback


@dataclass(frozen=True)
class ContextualLinearProgram:
    """A non-symbolic policy over recent sequence and load-distribution state."""

    mode: str
    weights: Tuple[float, ...]
    residual_scale: float = 0.10

    def __post_init__(self) -> None:
        if self.mode not in ("ancestry", "de_novo", "hybrid"):
            raise ValueError("unsupported contextual policy mode")
        if len(self.weights) != len(CONTEXTUAL_FEATURES):
            raise ValueError("contextual policy has the wrong weight count")
        if not all(math.isfinite(weight) for weight in self.weights):
            raise ValueError("contextual weights must be finite")
        if not math.isfinite(self.residual_scale) or self.residual_scale <= 0:
            raise ValueError("residual_scale must be positive and finite")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "contextual_linear",
                "dsl_version": DSL_VERSION,
                "feature_version": CONTEXTUAL_FEATURE_VERSION,
                "mode": self.mode,
                "weights": list(self.weights),
                "residual_scale": self.residual_scale,
            }
        )

    @property
    def name(self) -> str:
        return "contextual_%s_%s" % (
            self.mode,
            self.candidate_id[:12],
        )

    @property
    def complexity(self) -> int:
        return 1 + sum(abs(weight) > 1e-12 for weight in self.weights)

    def as_dict(self) -> Dict[str, Any]:
        terms = tuple(
            "%g*%s" % (weight, feature)
            for feature, weight in zip(CONTEXTUAL_FEATURES, self.weights)
            if abs(weight) > 1e-12
        )
        linear = " + ".join(terms) if terms else "0"
        if self.mode == "de_novo":
            rendered = linear
        elif self.mode == "hybrid":
            rendered = (
                "confidence_gate(%s, margin >= %g, "
                "fallback=funsearch_action)"
                % (linear, self.residual_scale)
            )
        else:
            rendered = "funsearch_score + %g * (%s)" % (
                self.residual_scale,
                linear,
            )
        return {
            "program_kind": "contextual_linear",
            "dsl_version": DSL_VERSION,
            "feature_version": CONTEXTUAL_FEATURE_VERSION,
            "candidate_id": self.candidate_id,
            "mode": self.mode,
            "weights": list(self.weights),
            "feature_names": list(CONTEXTUAL_FEATURES),
            "residual_scale": self.residual_scale,
            "incumbent": (
                None
                if self.mode == "de_novo"
                else "funsearch_or_reference"
            ),
            "rendered": rendered,
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        recent = tuple(history[-16:])
        normalized_recent = tuple(
            value / float(capacity) for value in recent
        )
        if normalized_recent:
            recent_mean = sum(normalized_recent) / len(normalized_recent)
            recent_variance = sum(
                (value - recent_mean) ** 2
                for value in normalized_recent
            ) / len(normalized_recent)
            recent_std = math.sqrt(recent_variance)
            recent_large_fraction = sum(
                value > 0.5 for value in normalized_recent
            ) / float(len(normalized_recent))
            midpoint = len(normalized_recent) // 2
            if midpoint:
                earlier = normalized_recent[:midpoint]
                later = normalized_recent[midpoint:]
                recent_trend = (
                    sum(later) / len(later)
                    - sum(earlier) / len(earlier)
                )
            else:
                recent_trend = 0.0
        else:
            recent_mean = 0.0
            recent_std = 0.0
            recent_large_fraction = 0.0
            recent_trend = 0.0

        normalized_loads = tuple(
            load / float(capacity) for load in loads
        )
        load_mean = (
            sum(normalized_loads) / len(normalized_loads)
            if normalized_loads
            else 0.0
        )
        load_variance = (
            sum(
                (value - load_mean) ** 2
                for value in normalized_loads
            ) / len(normalized_loads)
            if normalized_loads
            else 0.0
        )
        load_std = math.sqrt(load_variance)
        normalized_item = item / float(capacity)
        denominator = max(1, len(loads))
        actions: List[Tuple[Optional[int], int, float]] = [
            (index, load, 0.0)
            for index, load in enumerate(loads)
            if load + item <= capacity
        ]
        actions.append((None, 0, 1.0))
        scores: List[
            Tuple[float, float, int, Optional[int]]
        ] = []
        for action_index, load, is_new_bin in actions:
            numeric_index = (
                len(loads) if action_index is None else action_index
            )
            remaining_after_units = capacity - load - item
            remaining_after = remaining_after_units / float(capacity)
            normalized_load = load / float(capacity)
            features = (
                1.0,
                -remaining_after,
                float(remaining_after_units == 0),
                float(0 < remaining_after_units <= 8),
                normalized_item,
                normalized_load,
                normalized_item * normalized_load,
                remaining_after * remaining_after,
                is_new_bin,
                numeric_index / float(denominator),
                min(1.0, len(loads) / 20.0),
                recent_mean,
                recent_std,
                recent_large_fraction,
                recent_trend,
                load_mean,
                load_std,
                remaining_after * recent_mean,
                remaining_after * recent_large_fraction,
                normalized_item * recent_mean,
            )
            linear_score = sum(
                weight * feature
                for weight, feature in zip(self.weights, features)
            )
            incumbent_score = (
                0.0
                if self.mode == "de_novo"
                else funsearch_or_score(remaining_after_units)
            )
            scores.append(
                (
                    linear_score,
                    incumbent_score,
                    -numeric_index,
                    action_index,
                )
            )
        if self.mode == "de_novo":
            return max(scores, key=lambda value: (value[0], value[2]))[3]
        if self.mode == "ancestry":
            return max(
                scores,
                key=lambda value: (
                    value[1] + self.residual_scale * value[0],
                    value[2],
                ),
            )[3]
        incumbent_action = max(
            scores,
            key=lambda value: (value[1], value[2]),
        )[3]
        learned = sorted(
            scores,
            key=lambda value: (value[0], value[2]),
            reverse=True,
        )
        learned_action = learned[0][3]
        learned_margin = (
            learned[0][0] - learned[1][0]
            if len(learned) > 1
            else float("inf")
        )
        return (
            learned_action
            if (
                learned_action != incumbent_action
                and learned_margin >= self.residual_scale
            )
            else incumbent_action
        )


def demand_memory_action_features(
    item: int,
    loads: Sequence[int],
    capacity: int,
    history: Sequence[int],
) -> Tuple[
    Tuple[Optional[int], Tuple[float, ...], float, int],
    ...,
]:
    """Expose the exact action features used by the demand-memory policy."""

    recent = tuple(history[-32:])
    normalized_recent = tuple(
        value / float(capacity) for value in recent
    )

    def demand_density(remaining: float) -> float:
        if not normalized_recent:
            return 0.0
        bandwidth = 0.08
        return sum(
            max(0.0, 1.0 - abs(remaining - value) / bandwidth)
            for value in normalized_recent
        ) / len(normalized_recent)

    large_fraction = (
        sum(value > 0.5 for value in normalized_recent)
        / float(len(normalized_recent))
        if normalized_recent
        else 0.0
    )
    small_floor = (
        sorted(normalized_recent)[
            max(0, len(normalized_recent) // 4 - 1)
        ]
        if normalized_recent
        else 0.0
    )
    normalized_item = item / float(capacity)
    denominator = max(1, len(loads))
    actions: List[Tuple[Optional[int], int, float]] = [
        (index, load, 0.0)
        for index, load in enumerate(loads)
        if load + item <= capacity
    ]
    actions.append((None, 0, 1.0))
    featured = []
    for action_index, load, is_new_bin in actions:
        numeric_index = (
            len(loads) if action_index is None else action_index
        )
        remaining_before = (capacity - load) / float(capacity)
        remaining_after_units = capacity - load - item
        remaining_after = remaining_after_units / float(capacity)
        density_before = demand_density(remaining_before)
        density_after = demand_density(remaining_after)
        complement_rate = (
            sum(
                abs(value - remaining_after_units) <= 2
                for value in recent
            ) / float(len(recent))
            if recent
            else 0.0
        )
        features = (
            1.0,
            -remaining_after,
            float(remaining_after_units == 0),
            float(0 < remaining_after_units <= 8),
            normalized_item,
            load / float(capacity),
            is_new_bin,
            numeric_index / float(denominator),
            min(1.0, len(loads) / 20.0),
            density_after,
            complement_rate,
            density_after - density_before,
            large_fraction * remaining_after,
            float(0.0 < remaining_after < small_floor),
        )
        featured.append(
            (
                action_index,
                features,
                funsearch_or_score(remaining_after_units),
                numeric_index,
            )
        )
    return tuple(featured)


@dataclass(frozen=True)
class DemandMemoryProgram:
    """Score placements using an empirical recent-demand distribution."""

    mode: str
    weights: Tuple[float, ...]
    residual_scale: float = 0.10

    def __post_init__(self) -> None:
        if self.mode not in ("ancestry", "de_novo", "hybrid"):
            raise ValueError("unsupported demand-memory policy mode")
        if len(self.weights) != len(DEMAND_MEMORY_FEATURES):
            raise ValueError("demand-memory policy has the wrong weight count")
        if not all(math.isfinite(weight) for weight in self.weights):
            raise ValueError("demand-memory weights must be finite")
        if not math.isfinite(self.residual_scale) or self.residual_scale <= 0:
            raise ValueError("residual_scale must be positive and finite")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "demand_memory",
                "dsl_version": DSL_VERSION,
                "feature_version": DEMAND_MEMORY_VERSION,
                "mode": self.mode,
                "weights": list(self.weights),
                "residual_scale": self.residual_scale,
            }
        )

    @property
    def name(self) -> str:
        return "demand_memory_%s_%s" % (
            self.mode,
            self.candidate_id[:12],
        )

    @property
    def complexity(self) -> int:
        return 1 + sum(abs(weight) > 1e-12 for weight in self.weights)

    def as_dict(self) -> Dict[str, Any]:
        terms = tuple(
            "%g*%s" % (weight, feature)
            for feature, weight in zip(DEMAND_MEMORY_FEATURES, self.weights)
            if abs(weight) > 1e-12
        )
        linear = " + ".join(terms) if terms else "0"
        if self.mode == "de_novo":
            rendered = linear
        elif self.mode == "hybrid":
            rendered = (
                "confidence_gate(demand_memory(%s), margin >= %g, "
                "fallback=funsearch_action)"
                % (linear, self.residual_scale)
            )
        else:
            rendered = "funsearch_score + %g * demand_memory(%s)" % (
                self.residual_scale,
                linear,
            )
        return {
            "program_kind": "demand_memory",
            "dsl_version": DSL_VERSION,
            "feature_version": DEMAND_MEMORY_VERSION,
            "candidate_id": self.candidate_id,
            "mode": self.mode,
            "weights": list(self.weights),
            "feature_names": list(DEMAND_MEMORY_FEATURES),
            "residual_scale": self.residual_scale,
            "incumbent": (
                None
                if self.mode == "de_novo"
                else "funsearch_or_reference"
            ),
            "rendered": rendered,
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        scores: List[
            Tuple[float, float, int, Optional[int]]
        ] = []
        for (
            action_index,
            features,
            incumbent_score,
            numeric_index,
        ) in demand_memory_action_features(
            item,
            loads,
            capacity,
            history,
        ):
            linear_score = sum(
                weight * feature
                for weight, feature in zip(self.weights, features)
            )
            scores.append(
                (
                    linear_score,
                    (
                        0.0
                        if self.mode == "de_novo"
                        else incumbent_score
                    ),
                    -numeric_index,
                    action_index,
                )
            )
        if self.mode == "de_novo":
            return max(scores, key=lambda value: (value[0], value[2]))[3]
        if self.mode == "ancestry":
            return max(
                scores,
                key=lambda value: (
                    value[1] + self.residual_scale * value[0],
                    value[2],
                ),
            )[3]
        incumbent_action = max(
            scores,
            key=lambda value: (value[1], value[2]),
        )[3]
        learned = sorted(
            scores,
            key=lambda value: (value[0], value[2]),
            reverse=True,
        )
        learned_action = learned[0][3]
        learned_margin = (
            learned[0][0] - learned[1][0]
            if len(learned) > 1
            else float("inf")
        )
        return (
            learned_action
            if (
                learned_action != incumbent_action
                and learned_margin >= self.residual_scale
            )
            else incumbent_action
        )


@dataclass(frozen=True)
class RegimeRouterProgram:
    """Route arrivals among complete policies using only online state."""

    mode: str
    policy_weights: Tuple[Tuple[float, ...], ...]

    def __post_init__(self) -> None:
        if self.mode not in ("ancestry", "de_novo", "hybrid"):
            raise ValueError("unsupported regime-router mode")
        if len(self.policy_weights) != len(REGIME_ROUTER_POLICIES):
            raise ValueError("regime router has the wrong policy count")
        if any(
            len(row) != len(REGIME_ROUTER_FEATURES)
            for row in self.policy_weights
        ):
            raise ValueError("regime router has the wrong feature count")
        if not all(
            math.isfinite(weight)
            for row in self.policy_weights
            for weight in row
        ):
            raise ValueError("regime-router weights must be finite")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "program_kind": "regime_router",
                "dsl_version": DSL_VERSION,
                "router_version": REGIME_ROUTER_VERSION,
                "mode": self.mode,
                "policy_weights": [
                    list(row) for row in self.policy_weights
                ],
            }
        )

    @property
    def name(self) -> str:
        return "regime_router_%s_%s" % (
            self.mode,
            self.candidate_id[:12],
        )

    @property
    def complexity(self) -> int:
        return 1 + sum(
            abs(weight) > 1e-12
            for row in self.policy_weights
            for weight in row
        )

    def as_dict(self) -> Dict[str, Any]:
        rows = []
        for policy, weights in zip(
            REGIME_ROUTER_POLICIES,
            self.policy_weights,
        ):
            terms = tuple(
                "%g*%s" % (weight, feature)
                for feature, weight in zip(
                    REGIME_ROUTER_FEATURES,
                    weights,
                )
                if abs(weight) > 1e-12
            )
            rows.append(
                "%s=[%s]" % (
                    policy,
                    " + ".join(terms) if terms else "0",
                )
            )
        return {
            "program_kind": "regime_router",
            "dsl_version": DSL_VERSION,
            "router_version": REGIME_ROUTER_VERSION,
            "candidate_id": self.candidate_id,
            "mode": self.mode,
            "policies": list(REGIME_ROUTER_POLICIES),
            "feature_names": list(REGIME_ROUTER_FEATURES),
            "policy_weights": [
                list(row) for row in self.policy_weights
            ],
            "rendered": (
                (
                    "confidence_gate(route_policy(%s), margin >= 0.25, "
                    "fallback=funsearch)"
                )
                if self.mode == "hybrid"
                else "route_policy(%s)"
            )
            % "; ".join(rows),
            "complexity": self.complexity,
        }

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        recent = tuple(
            value / float(capacity) for value in history[-16:]
        )
        if recent:
            recent_mean = sum(recent) / len(recent)
            recent_variance = sum(
                (value - recent_mean) ** 2 for value in recent
            ) / len(recent)
            recent_std = math.sqrt(recent_variance)
            recent_large_fraction = sum(
                value > 0.5 for value in recent
            ) / float(len(recent))
            midpoint = len(recent) // 2
            recent_trend = (
                sum(recent[midpoint:]) / len(recent[midpoint:])
                - sum(recent[:midpoint]) / len(recent[:midpoint])
                if midpoint
                else 0.0
            )
        else:
            recent_mean = 0.0
            recent_std = 0.0
            recent_large_fraction = 0.0
            recent_trend = 0.0
        normalized_loads = tuple(
            load / float(capacity) for load in loads
        )
        load_mean = (
            sum(normalized_loads) / len(normalized_loads)
            if normalized_loads
            else 0.0
        )
        load_variance = (
            sum(
                (value - load_mean) ** 2
                for value in normalized_loads
            ) / len(normalized_loads)
            if normalized_loads
            else 0.0
        )
        features = (
            1.0,
            item / float(capacity),
            recent_mean,
            recent_std,
            recent_large_fraction,
            recent_trend,
            min(1.0, len(loads) / 20.0),
            load_mean,
            math.sqrt(load_variance),
            (
                (capacity - max(loads)) / float(capacity)
                if loads
                else 1.0
            ),
        )
        policy_scores = tuple(
            sum(
                weight * feature
                for weight, feature in zip(
                    self.policy_weights[index],
                    features,
                )
            )
            for index in range(len(REGIME_ROUTER_POLICIES))
        )
        if self.mode == "de_novo":
            policy_index = max(
                range(1, len(REGIME_ROUTER_POLICIES)),
                key=lambda index: (policy_scores[index], -index),
            )
        elif self.mode == "hybrid":
            alternative = max(
                range(1, len(REGIME_ROUTER_POLICIES)),
                key=lambda index: (policy_scores[index], -index),
            )
            policy_index = (
                alternative
                if policy_scores[alternative] >= policy_scores[0] + 0.25
                else 0
            )
        else:
            policy_index = max(
                range(len(REGIME_ROUTER_POLICIES)),
                key=lambda index: (policy_scores[index], -index),
            )
        policy = REGIME_ROUTER_POLICIES[policy_index]
        feasible = tuple(
            index
            for index, load in enumerate(loads)
            if load + item <= capacity
        )
        if not feasible:
            return None
        if policy == "funsearch":
            return FunSearchORReference().choose_bin(
                item,
                loads,
                capacity,
                item_index,
                history,
            )
        if policy == "best_fit":
            return min(
                feasible,
                key=lambda index: capacity - loads[index] - item,
            )
        if policy == "first_fit":
            return feasible[0]
        if policy == "worst_fit":
            return max(
                feasible,
                key=lambda index: capacity - loads[index] - item,
            )
        if loads[-1] + item <= capacity:
            return len(loads) - 1
        return None


def _router_features(
    item: int,
    loads: Sequence[int],
    capacity: int,
    history: Sequence[int],
) -> Mapping[str, float]:
    if history:
        normalized_history = [value / float(capacity) for value in history]
        seen_mean = sum(normalized_history) / len(normalized_history)
        seen_min = min(normalized_history)
        seen_variance = sum(
            (value - seen_mean) ** 2 for value in normalized_history
        ) / len(normalized_history)
        seen_std = math.sqrt(seen_variance)
        seen_large_fraction = sum(
            value > capacity / 2.0 for value in history
        ) / float(len(history))
    else:
        seen_mean = 0.0
        seen_min = 1.0
        seen_std = 0.0
        seen_large_fraction = 0.0
    fullest_load = max(loads, default=0)
    mean_load = sum(loads) / float(len(loads)) if loads else 0.0
    return {
        "item": item / float(capacity),
        "load": mean_load / float(capacity),
        "remaining_before": (capacity - fullest_load) / float(capacity),
        "remaining_after": (
            capacity - fullest_load - item
        ) / float(capacity),
        "fill_after": (fullest_load + item) / float(capacity),
        "bin_index": 0.0,
        "open_bins": min(1.0, len(loads) / 20.0),
        "is_new_bin": 0.0,
        "seen_mean": seen_mean,
        "seen_min": seen_min,
        "seen_std": seen_std,
        "seen_large_fraction": seen_large_fraction,
    }


def _choose_priority_bin(
    expression: Expression,
    item: int,
    loads: Sequence[int],
    capacity: int,
    history: Sequence[int],
    *,
    residual_scale: float,
    include_funsearch_incumbent: bool,
) -> Optional[int]:
    if history:
        normalized_history = [value / float(capacity) for value in history]
        seen_mean = sum(normalized_history) / len(normalized_history)
        seen_min = min(normalized_history)
        seen_variance = sum(
            (value - seen_mean) ** 2 for value in normalized_history
        ) / len(normalized_history)
        seen_std = math.sqrt(seen_variance)
        seen_large_fraction = sum(
            1 for value in history if value > capacity / 2.0
        ) / float(len(history))
    else:
        seen_mean = 0.0
        seen_min = 1.0
        seen_std = 0.0
        seen_large_fraction = 0.0

    scores: List[Tuple[float, int, Optional[int]]] = []
    actions: List[Tuple[Optional[int], int, float]] = [
        (index, load, 0.0)
        for index, load in enumerate(loads)
        if load + item <= capacity
    ]
    actions.append((None, 0, 1.0))
    denominator = max(1, len(loads))
    for action_index, load, is_new_bin in actions:
        numeric_index = len(loads) if action_index is None else action_index
        remaining_after = capacity - load - item
        features = {
            "item": item / float(capacity),
            "load": load / float(capacity),
            "remaining_before": (capacity - load) / float(capacity),
            "remaining_after": remaining_after / float(capacity),
            "fill_after": (load + item) / float(capacity),
            "bin_index": numeric_index / float(denominator),
            "open_bins": min(1.0, len(loads) / 20.0),
            "is_new_bin": is_new_bin,
            "seen_mean": seen_mean,
            "seen_min": seen_min,
            "seen_std": seen_std,
            "seen_large_fraction": seen_large_fraction,
        }
        incumbent_score = (
            funsearch_or_score(remaining_after)
            if include_funsearch_incumbent
            else 0.0
        )
        scores.append(
            (
                incumbent_score
                + residual_scale * expression.evaluate(features),
                -numeric_index,
                action_index,
            )
        )
    return max(scores, key=lambda value: (value[0], value[1]))[2]


def seed_programs() -> Tuple[PriorityProgram, ...]:
    return (
        PriorityProgram(
            Expression.unary(
                "neg",
                Expression.feature("remaining_after"),
            )
        ),
        PriorityProgram(
            Expression.binary(
                "sub",
                Expression.feature("remaining_after"),
                Expression.binary(
                    "mul",
                    Expression.const(2.0),
                    Expression.feature("is_new_bin"),
                ),
            )
        ),
        PriorityProgram(
            Expression.unary("neg", Expression.feature("bin_index"))
        ),
        PriorityProgram(Expression.feature("fill_after")),
    )


def program_from_dict(
    value: Mapping[str, Any],
) -> Union[
    PriorityProgram,
    FunSearchResidualProgram,
    HybridPolicyProgram,
    ActionHybridProgram,
    MoonshotProgram,
    MoonshotHybridProgram,
    StructuralHybridProgram,
    CalibratedOverrideActionProgram,
    CalibratedOverrideHybridProgram,
    ContextualLinearProgram,
    DemandMemoryProgram,
    RegimeRouterProgram,
    GeneratedPolicyModuleProgram,
    GeneratedPolicyProgram,
]:
    """Reconstruct a frozen executable program and verify its identity."""

    if value.get("program_kind") == "generated_python_policy":
        return GeneratedPolicyProgram.from_dict(value)
    if value.get("program_kind") == "generated_python_module_policy":
        return GeneratedPolicyModuleProgram.from_dict(value)

    if value.get("dsl_version") != DSL_VERSION:
        raise ValueError("unsupported bin-packing DSL version")
    kind = value.get("program_kind")
    if kind == "funsearch_residual":
        program: Union[
            PriorityProgram,
            FunSearchResidualProgram,
            HybridPolicyProgram,
            ActionHybridProgram,
            MoonshotProgram,
            MoonshotHybridProgram,
            StructuralHybridProgram,
            CalibratedOverrideActionProgram,
            CalibratedOverrideHybridProgram,
            ContextualLinearProgram,
            DemandMemoryProgram,
            RegimeRouterProgram,
        ] = FunSearchResidualProgram(
            Expression.from_dict(value["expression"]),
            float(value["residual_scale"]),
        )
    elif kind == "hybrid_router":
        program = HybridPolicyProgram(
            Expression.from_dict(value["router"]),
            Expression.from_dict(value["de_novo_policy"]),
        )
    elif kind == "action_hybrid_score":
        program = ActionHybridProgram(
            Expression.from_dict(value["router"]),
            Expression.from_dict(value["de_novo_policy"]),
            float(value["residual_scale"]),
        )
    elif kind == "moonshot_policy":
        if value.get("moonshot_version") != MOONSHOT_PROGRAM_VERSION:
            raise ValueError("unsupported moonshot program version")
        program = MoonshotProgram(
            str(value["topology"]),
            tuple(float(item) for item in value["parameters"]),
        )
    elif kind == "moonshot_hybrid":
        if value.get("moonshot_version") != MOONSHOT_PROGRAM_VERSION:
            raise ValueError("unsupported moonshot program version")
        moonshot_value = value["moonshot"]
        program = MoonshotHybridProgram(
            Expression.from_dict(value["ancestry_expression"]),
            MoonshotProgram(
                str(moonshot_value["topology"]),
                tuple(
                    float(item)
                    for item in moonshot_value["parameters"]
                ),
            ),
            float(value["gate_threshold"]),
            float(value["residual_scale"]),
        )
    elif kind == "structural_hybrid":
        if value.get("moonshot_version") != MOONSHOT_PROGRAM_VERSION:
            raise ValueError("unsupported moonshot program version")
        moonshot_value = value["moonshot"]
        program = StructuralHybridProgram(
            program_from_dict(value["ancestry"]),
            MoonshotProgram(
                str(moonshot_value["topology"]),
                tuple(
                    float(item)
                    for item in moonshot_value["parameters"]
                ),
            ),
            float(value["gate_threshold"]),
        )
    elif kind == "calibrated_override_action":
        program = CalibratedOverrideActionProgram(
            program_from_dict(value["ancestry"]),
            CalibratedOverrideValueModel.from_dict(
                value["override_model"]
            ),
        )
    elif kind == "calibrated_override_hybrid":
        program = CalibratedOverrideHybridProgram(
            program_from_dict(value["ancestry"]),
            CalibratedOverrideValueModel.from_dict(
                value["override_model"]
            ),
            float(value["confidence_threshold"]),
        )
    elif kind == "contextual_linear":
        if value.get("feature_version") != CONTEXTUAL_FEATURE_VERSION:
            raise ValueError("unsupported contextual feature version")
        program = ContextualLinearProgram(
            str(value["mode"]),
            tuple(float(weight) for weight in value["weights"]),
            float(value["residual_scale"]),
        )
    elif kind == "demand_memory":
        if value.get("feature_version") != DEMAND_MEMORY_VERSION:
            raise ValueError("unsupported demand-memory feature version")
        program = DemandMemoryProgram(
            str(value["mode"]),
            tuple(float(weight) for weight in value["weights"]),
            float(value["residual_scale"]),
        )
    elif kind == "regime_router":
        if value.get("router_version") != REGIME_ROUTER_VERSION:
            raise ValueError("unsupported regime-router version")
        program = RegimeRouterProgram(
            str(value["mode"]),
            tuple(
                tuple(float(weight) for weight in row)
                for row in value["policy_weights"]
            ),
        )
    elif kind is None:
        program = PriorityProgram(
            Expression.from_dict(value["expression"])
        )
    else:
        raise ValueError("unsupported program kind: %s" % kind)
    if (
        value.get("candidate_id") is not None
        and value["candidate_id"] != program.candidate_id
    ):
        raise ValueError("frozen candidate identity does not match payload")
    return program
