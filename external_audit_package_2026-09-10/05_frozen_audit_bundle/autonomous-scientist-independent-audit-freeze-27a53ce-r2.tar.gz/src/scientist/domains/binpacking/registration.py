from __future__ import annotations

from dataclasses import replace

from scientist.domains.binpacking.adapter import BinPackingAdapter
from scientist.domains.binpacking.generators import generate_instance
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.domains.binpacking.programs import seed_programs
from scientist.domains.binpacking.standard import campaign_contract, problem_charter
from scientist.kernel.domain_registry import (
    DomainConformanceFixture,
    ScientificDomainBundle,
)
from scientist.kernel.interfaces import ExperimentRequest
from scientist.kernel.contracts import BudgetContract


def _positive_argument(arguments, *names, default=1):
    for name in names:
        value = getattr(arguments, name, None)
        if value is not None:
            return max(1, int(value))
    return default


def adapt_command_contract(arguments, standard):
    validation_lengths = getattr(arguments, "validation_lengths", ()) or ()
    replication_lengths = getattr(arguments, "lengths", ()) or ()
    audit_cases = _positive_argument(
        arguments,
        "audit_seed_count_per_length",
        "validation_seed_count",
        "validation_seed_count_per_length",
    ) * max(1, len(validation_lengths))
    replication_cases = _positive_argument(
        arguments,
        "instances_per_length",
        "validation_seed_count",
        "seed_count",
    ) * max(1, len(replication_lengths))
    replication_cases *= _positive_argument(arguments, "replicates", default=1)
    return replace(
        standard,
        budget=BudgetContract(
            outer_rounds=_positive_argument(arguments, "rounds", "replicates"),
            proposals_per_family_per_round=_positive_argument(
                arguments, "candidate_budget", "arm_budget", "budget", "scout_budget"
            ),
            failure_mining_evaluations_per_round=_positive_argument(
                arguments, "adversary_budget", "budget"
            ),
            audit_cases_per_proposal=audit_cases,
            replication_cases=replication_cases,
        ),
    )


class BinPackingExperimentFactory:
    name = "binpacking-instance-factory"
    factory_version = "binpacking-seeded-generator-v1"

    def generate(self, request: ExperimentRequest):
        family = request.mechanism_tags[0] if request.mechanism_tags else "or_uniform"
        length = {
            "toy": 30,
            "small": 120,
            "medium": 250,
            "large": 500,
        }.get(request.difficulty, 120)
        return tuple(
            generate_instance(family, request.seed_start + index, length, 150)
            for index in range(request.count)
        )


def domain_bundle() -> ScientificDomainBundle:
    adapter = BinPackingAdapter()
    incumbent = literature_heuristics()["funsearch_or_reference"]

    def fixture() -> DomainConformanceFixture:
        return DomainConformanceFixture(
            candidate=seed_programs()[0],
            control=incumbent,
            experiment=generate_instance("or_uniform", 9_999_991, 30, 150),
        )

    return ScientificDomainBundle(
        domain_id=adapter.domain_id,
        adapter=adapter,
        charter_factory=problem_charter,
        campaign_factory=lambda incumbent_id: campaign_contract(
            incumbent_id or adapter.candidate_id(incumbent)
        ),
        fixture_factory=fixture,
        capability_manifest=adapter.capabilities,
        bundle_ref="binpacking-scientific-domain-bundle-v1",
        experiment_factory=BinPackingExperimentFactory(),
        command_contract_adapter=adapt_command_contract,
    )
