from __future__ import annotations

from dataclasses import dataclass
import math
import random
from statistics import mean, stdev
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import GeneratedPolicyModuleProgram
from scientist.domains.binpacking.first_principles_oracle import exact_action_values
from scientist.domains.binpacking.heuristics import OnlineHeuristic, literature_heuristics
from scientist.domains.binpacking.models import BinPackingInstance


REPRESENTATION_CAPACITY_VERSION = "de-novo-representation-capacity-v2"
_SPLITS = ("development", "adaptive_validation", "sealed_audit")
_FAMILIES = ("uniform", "complementary", "regime_switch", "trimodal")


def _action_ref(action: Optional[int]) -> str:
    return "new" if action is None else "bin:%d" % int(action)


def _parse_action(action_ref: str) -> Optional[int]:
    if action_ref == "new":
        return None
    if not action_ref.startswith("bin:"):
        raise ValueError("invalid action reference")
    return int(action_ref.split(":", 1)[1])


def _legal_actions(
    item: int, loads: Sequence[int], capacity: int
) -> Tuple[Optional[int], ...]:
    return (
        *(
            index
            for index, load in enumerate(loads)
            if load + item <= capacity
        ),
        None,
    )


def _apply_action(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    if action is None:
        return (*loads, item)
    if action < 0 or action >= len(loads) or loads[action] + item > capacity:
        raise ValueError("representation selector produced an illegal action")
    successor = list(loads)
    successor[action] += item
    return tuple(successor)


def _successor_signature(
    action: Optional[int], item: int, loads: Sequence[int], capacity: int
) -> Tuple[int, ...]:
    return tuple(sorted(_apply_action(action, item, loads, capacity), reverse=True))


def _spread(values: Sequence[float]) -> float:
    if not values:
        return 0.0
    center = mean(values)
    return math.sqrt(mean((float(value) - center) ** 2 for value in values))


@dataclass(frozen=True)
class RepresentationCapacityConfig:
    capacity: int = 150
    sequence_lengths: Tuple[int, ...] = (120, 250, 500)
    exact_suffix_horizon: int = 5
    minimum_history_items: int = 12
    probes_per_instance: int = 18
    development_instances: int = 24
    adaptive_validation_instances: int = 12
    sealed_audit_instances: int = 12
    base_seed: int = 91_840_026

    def __post_init__(self) -> None:
        if (
            self.capacity < 10
            or not self.sequence_lengths
            or min(self.sequence_lengths) < 24
            or len(set(self.sequence_lengths)) != len(self.sequence_lengths)
        ):
            raise ValueError("invalid representation-capacity problem scale")
        if not 2 <= self.exact_suffix_horizon <= 8:
            raise ValueError("invalid exact suffix horizon")
        if self.minimum_history_items < 0 or self.probes_per_instance < 4:
            raise ValueError("invalid probe schedule")
        counts = (
            self.development_instances,
            self.adaptive_validation_instances,
            self.sealed_audit_instances,
        )
        minimum_coverage = len(_FAMILIES) * len(self.sequence_lengths)
        if min(counts) < minimum_coverage:
            raise ValueError(
                "every split must cover each family at every sequence length"
            )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "capacity": self.capacity,
            "sequence_lengths": list(self.sequence_lengths),
            "exact_suffix_horizon": self.exact_suffix_horizon,
            "minimum_history_items": self.minimum_history_items,
            "probes_per_instance": self.probes_per_instance,
            "development_instances": self.development_instances,
            "adaptive_validation_instances": (
                self.adaptive_validation_instances
            ),
            "sealed_audit_instances": self.sealed_audit_instances,
            "base_seed": self.base_seed,
        }


@dataclass(frozen=True)
class RepresentationProbe:
    probe_id: str
    split: str
    instance_id: str
    family: str
    item: int
    loads: Tuple[int, ...]
    capacity: int
    item_index: int
    history: Tuple[int, ...]
    action_values: Tuple[Tuple[str, int], ...]
    incumbent_action_ref: str
    remaining_items: Tuple[int, ...] = ()

    @property
    def values(self) -> Mapping[str, int]:
        return dict(self.action_values)

    @property
    def incumbent_regret(self) -> int:
        values = self.values
        return values[self.incumbent_action_ref] - min(values.values())

    def as_dict(self, *, include_labels: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "probe_id": self.probe_id,
            "split": self.split,
            "instance_id": self.instance_id,
            "family": self.family,
            "item": self.item,
            "loads": list(self.loads),
            "capacity": self.capacity,
            "item_index": self.item_index,
            "history": list(self.history),
            "incumbent_action_ref": self.incumbent_action_ref,
        }
        if include_labels:
            value["action_values"] = [
                {"action_ref": action_ref, "exact_terminal_bins": bins}
                for action_ref, bins in self.action_values
            ]
            value["incumbent_exact_action_regret"] = self.incumbent_regret
            value["remaining_items"] = list(self.remaining_items)
        return value


@dataclass(frozen=True)
class RepresentationCorpus:
    config: RepresentationCapacityConfig
    instances: Tuple[BinPackingInstance, ...]
    probes: Tuple[RepresentationProbe, ...]
    report: Mapping[str, Any]

    def split(self, name: str) -> Tuple[RepresentationProbe, ...]:
        if name not in _SPLITS:
            raise ValueError("unknown representation-capacity split")
        return tuple(probe for probe in self.probes if probe.split == name)

    def split_instances(self, name: str) -> Tuple[BinPackingInstance, ...]:
        if name not in _SPLITS:
            raise ValueError("unknown representation-capacity split")
        prefix = "representation-%s-" % name
        return tuple(
            instance
            for instance in self.instances
            if instance.instance_id.startswith(prefix)
        )


def _family_items(
    family: str,
    *,
    capacity: int,
    length: int,
    seed: int,
) -> Tuple[int, ...]:
    rng = random.Random(seed)
    scale = capacity / 150.0

    def scaled(value: int) -> int:
        return max(1, min(capacity, int(round(scale * value))))

    if family == "uniform":
        return tuple(scaled(rng.randint(20, 100)) for _ in range(length))
    if family == "complementary":
        pairs = ((45, 105), (50, 100), (55, 95), (60, 90), (65, 85), (70, 80))
        values = []
        while len(values) < length:
            left, right = pairs[rng.randrange(len(pairs))]
            jitter = rng.randint(-4, 4)
            pair = [left + jitter, right - jitter]
            if rng.random() < 0.5:
                pair.reverse()
            values.extend(pair)
        return tuple(scaled(value) for value in values[:length])
    if family == "regime_switch":
        values = []
        segment = max(8, length // 6)
        while len(values) < length:
            phase = (len(values) // segment) % 3
            bounds = ((22, 52), (72, 108), (45, 82))[phase]
            values.extend(rng.randint(*bounds) for _ in range(segment))
        if seed % 2:
            values.reverse()
        return tuple(scaled(value) for value in values[:length])
    if family == "trimodal":
        modes = ((20, 42), (56, 78), (88, 112))
        values = []
        for index in range(length):
            low, high = modes[(index + rng.randrange(3)) % 3]
            values.append(rng.randint(low, high))
        return tuple(scaled(value) for value in values)
    raise ValueError("unknown representation-capacity family")


def _instances(config: RepresentationCapacityConfig) -> Tuple[BinPackingInstance, ...]:
    split_counts = (
        ("development", config.development_instances, 100_000_000),
        (
            "adaptive_validation",
            config.adaptive_validation_instances,
            300_000_000,
        ),
        ("sealed_audit", config.sealed_audit_instances, 700_000_000),
    )
    instances = []
    for split, count, offset in split_counts:
        for index in range(count):
            family = _FAMILIES[index % len(_FAMILIES)]
            length = config.sequence_lengths[
                (index // len(_FAMILIES)) % len(config.sequence_lengths)
            ]
            seed = config.base_seed + offset + index
            instances.append(
                BinPackingInstance(
                    instance_id="representation-%s-%s-n%d-%03d"
                    % (split, family, length, index),
                    family="representation_%s" % family,
                    seed=seed,
                    capacity=config.capacity,
                    items=_family_items(
                        family,
                        capacity=config.capacity,
                        length=length,
                        seed=seed,
                    ),
                )
            )
    return tuple(instances)


def build_representation_corpus(
    config: RepresentationCapacityConfig = RepresentationCapacityConfig(),
) -> RepresentationCorpus:
    """Build disjoint development, adaptive-validation, and sealed exact states."""

    incumbent = literature_heuristics()["funsearch_or_reference"]
    probes = []
    instances = _instances(config)
    split_by_instance = {}
    for instance in instances:
        for split in _SPLITS:
            if instance.instance_id.startswith("representation-%s-" % split):
                split_by_instance[instance.instance_id] = split
                break
    for instance in instances:
        split = split_by_instance[instance.instance_id]
        first = config.minimum_history_items
        last = len(instance.items) - 2
        if last < first:
            raise ValueError("instance is too short for representation probes")
        if config.probes_per_instance == 1:
            selected_indices = {first}
        else:
            selected_indices = {
                int(
                    round(
                        first
                        + rank
                        * (last - first)
                        / float(config.probes_per_instance - 1)
                    )
                )
                for rank in range(config.probes_per_instance)
            }
        loads: Tuple[int, ...] = ()
        history: Tuple[int, ...] = ()
        for item_index, item in enumerate(instance.items):
            incumbent_action = incumbent.choose_bin(
                item, loads, instance.capacity, item_index, history
            )
            is_probe = (
                item_index in selected_indices
                and item_index + 1 < len(instance.items)
            )
            if is_probe:
                values = exact_action_values(
                    item=item,
                    loads=loads,
                    remaining_items=instance.items[
                        item_index + 1 :
                        item_index + 1 + config.exact_suffix_horizon
                    ],
                    capacity=instance.capacity,
                )
                action_values = tuple(
                    (_action_ref(action), int(value))
                    for action, value in values.items()
                )
                probe_body = {
                    "version": REPRESENTATION_CAPACITY_VERSION,
                    "split": split,
                    "instance_id": instance.instance_id,
                    "item_index": item_index,
                    "item": item,
                    "loads": list(loads),
                    "history": list(history[-128:]),
                    "action_values": action_values,
                    "incumbent_action_ref": _action_ref(incumbent_action),
                }
                probes.append(
                    RepresentationProbe(
                        probe_id=content_digest(probe_body),
                        split=split,
                        instance_id=instance.instance_id,
                        family=instance.family,
                        item=item,
                        loads=loads,
                        capacity=instance.capacity,
                        item_index=item_index,
                        history=history[-128:],
                        action_values=action_values,
                        incumbent_action_ref=_action_ref(incumbent_action),
                        remaining_items=instance.items[item_index + 1 :],
                    )
                )
            loads = _apply_action(
                incumbent_action, item, loads, instance.capacity
            )
            history = (*history, item)

    split_reports = {}
    for split in _SPLITS:
        selected = tuple(probe for probe in probes if probe.split == split)
        split_reports[split] = {
            "instance_count": len({probe.instance_id for probe in selected}),
            "probe_count": len(selected),
            "incumbent_opportunity_count": sum(
                probe.incumbent_regret > 0 for probe in selected
            ),
            "aggregate_incumbent_regret": sum(
                probe.incumbent_regret for probe in selected
            ),
            "families": sorted({probe.family for probe in selected}),
            "sequence_lengths": sorted(
                {
                    len(instance.items)
                    for instance in instances
                    if split_by_instance[instance.instance_id] == split
                }
            ),
            "seed_commitment": content_digest(
                sorted(
                    instance.seed
                    for instance in instances
                    if split_by_instance[instance.instance_id] == split
                )
            ),
        }
    report: Dict[str, Any] = {
        "schema": 1,
        "version": REPRESENTATION_CAPACITY_VERSION,
        "config": config.as_dict(),
        "trajectory_policy": "funsearch_or_reference",
        "candidate_future_access": False,
        "split_reports": split_reports,
        "split_instance_ids_disjoint": all(
            not set(probe.instance_id for probe in probes if probe.split == left)
            .intersection(
                probe.instance_id for probe in probes if probe.split == right
            )
            for index, left in enumerate(_SPLITS)
            for right in _SPLITS[index + 1 :]
        ),
        "sealed_labels_available_to_fitting": False,
    }
    report["corpus_id"] = content_digest(
        {
            **report,
            "probe_ids": [probe.probe_id for probe in probes],
        }
    )
    return RepresentationCorpus(config, instances, tuple(probes), report)


def observable_action_features(
    program: GeneratedPolicyModuleProgram,
    probe: RepresentationProbe,
    action_ref: str,
    *,
    include_candidate_representation: bool,
) -> Mapping[str, float]:
    """Return legal state-action features without incumbent or future labels."""

    action = _parse_action(action_ref)
    if action not in _legal_actions(probe.item, probe.loads, probe.capacity):
        raise ValueError("action is not legal in representation probe")
    successor = _apply_action(
        action, probe.item, probe.loads, probe.capacity
    )
    residuals = tuple(
        (probe.capacity - load) / float(probe.capacity)
        for load in probe.loads
    )
    successor_residuals = tuple(
        (probe.capacity - load) / float(probe.capacity)
        for load in successor
    )
    selected_load = 0 if action is None else probe.loads[action]
    post_residual = (
        probe.capacity - probe.item
        if action is None
        else probe.capacity - selected_load - probe.item
    )
    recent = probe.history[-64:]
    complement_frequency = sum(
        abs(value - post_residual) <= max(1, probe.capacity // 30)
        for value in recent
    ) / float(max(1, len(recent)))
    features: Dict[str, float] = {
        "generic_item_ratio": probe.item / float(probe.capacity),
        "generic_bin_count": float(len(probe.loads)),
        "generic_bins_per_item": len(probe.loads)
        / float(max(1, probe.item_index)),
        "generic_feasible_count": float(
            len(_legal_actions(probe.item, probe.loads, probe.capacity)) - 1
        ),
        "generic_history_count": float(len(probe.history)),
        "generic_log_item_index": math.log1p(probe.item_index),
        "generic_action_is_new": float(action is None),
        "generic_action_index_ratio": (
            len(probe.loads) if action is None else action
        )
        / float(max(1, len(probe.loads))),
        "generic_selected_load_ratio": selected_load / float(probe.capacity),
        "generic_post_residual_ratio": post_residual / float(probe.capacity),
        "generic_mean_residual": mean(residuals) if residuals else 1.0,
        "generic_residual_spread": _spread(residuals),
        "generic_successor_mean_residual": (
            mean(successor_residuals) if successor_residuals else 1.0
        ),
        "generic_successor_residual_spread": _spread(successor_residuals),
        "generic_history_mean_ratio": (
            mean(recent) / probe.capacity if recent else 0.0
        ),
        "generic_history_spread_ratio": _spread(recent) / probe.capacity,
        "generic_complement_frequency": complement_frequency,
        "generic_exact_fill": float(post_residual == 0),
    }
    if not include_candidate_representation:
        return features
    current_state = program.observable_state_features(
        probe.item,
        probe.loads,
        probe.capacity,
        probe.item_index,
        probe.history,
    )
    successor_state = program.observable_state_features(
        probe.item,
        successor,
        probe.capacity,
        probe.item_index + 1,
        (*probe.history, probe.item),
    )
    for name, value in current_state.items():
        features["representation_current_%s" % name] = float(value)
    for name, value in successor_state.items():
        features["representation_successor_%s" % name] = float(value)
        if name in current_state:
            features["representation_delta_%s" % name] = float(
                value - current_state[name]
            )
    return features


@dataclass(frozen=True)
class LinearAdvantageModel:
    feature_names: Tuple[str, ...]
    centers: Tuple[float, ...]
    scales: Tuple[float, ...]
    weights: Tuple[float, ...]
    bias: float
    training_config: Mapping[str, Any]

    def predict(self, features: Mapping[str, float]) -> float:
        return self.bias + sum(
            weight
            * max(-10.0, min(10.0, (float(features.get(name, 0.0)) - center) / scale))
            for name, center, scale, weight in zip(
                self.feature_names,
                self.centers,
                self.scales,
                self.weights,
            )
        )

    def as_dict(self) -> Dict[str, Any]:
        value = {
            "feature_names": list(self.feature_names),
            "centers": list(self.centers),
            "scales": list(self.scales),
            "weights": list(self.weights),
            "bias": self.bias,
            "training_config": dict(self.training_config),
        }
        return {**value, "model_id": content_digest(value)}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "LinearAdvantageModel":
        model = cls(
            feature_names=tuple(str(item) for item in value["feature_names"]),
            centers=tuple(float(item) for item in value["centers"]),
            scales=tuple(float(item) for item in value["scales"]),
            weights=tuple(float(item) for item in value["weights"]),
            bias=float(value["bias"]),
            training_config=dict(value["training_config"]),
        )
        sizes = {
            len(model.feature_names),
            len(model.centers),
            len(model.scales),
            len(model.weights),
        }
        if len(sizes) != 1 or not model.feature_names:
            raise ValueError("linear advantage-model dimensions do not match")
        if any(scale <= 0.0 for scale in model.scales):
            raise ValueError("linear advantage-model scales must be positive")
        supplied_id = value.get("model_id")
        observed_id = model.as_dict()["model_id"]
        if supplied_id is not None and supplied_id != observed_id:
            raise ValueError("linear advantage-model identity mismatch")
        return model


@dataclass(frozen=True)
class AdvantageTrainingExample:
    state_id: str
    instance_id: str
    action_ref: str
    features: Mapping[str, float]
    advantage: float
    informative: bool


def _value_rows(
    program: GeneratedPolicyModuleProgram,
    probes: Sequence[RepresentationProbe],
    *,
    include_candidate_representation: bool,
) -> Tuple[AdvantageTrainingExample, ...]:
    rows = []
    for probe in probes:
        values = probe.values
        incumbent_value = values[probe.incumbent_action_ref]
        informative = len(set(values.values())) > 1
        for action_ref, action_value in probe.action_values:
            rows.append(
                AdvantageTrainingExample(
                    state_id=probe.probe_id,
                    instance_id=probe.instance_id,
                    action_ref=action_ref,
                    features=observable_action_features(
                        program,
                        probe,
                        action_ref,
                        include_candidate_representation=(
                            include_candidate_representation
                        ),
                    ),
                    advantage=float(incumbent_value - action_value),
                    informative=informative,
                )
            )
    return tuple(rows)


def fit_linear_advantage_model(
    rows: Sequence[AdvantageTrainingExample],
    *,
    seed: int,
    epochs: int,
    learning_rate: float,
    ridge: float,
    informative_weight: float,
) -> LinearAdvantageModel:
    if not rows:
        raise ValueError("selector fitting requires development rows")
    feature_names = tuple(
        sorted(set().union(*(set(row.features) for row in rows)))
    )
    columns = tuple(
        tuple(float(row.features.get(name, 0.0)) for row in rows)
        for name in feature_names
    )
    centers = tuple(mean(column) for column in columns)
    scales = tuple(max(1e-6, _spread(column)) for column in columns)
    weights = [0.0] * len(feature_names)
    bias = mean(row.advantage for row in rows)
    order = list(range(len(rows)))
    rng = random.Random(seed)
    for epoch in range(epochs):
        rng.shuffle(order)
        rate = learning_rate / math.sqrt(epoch + 1.0)
        for row_index in order:
            row = rows[row_index]
            standardized = tuple(
                max(
                    -10.0,
                    min(
                        10.0,
                        (float(row.features.get(name, 0.0)) - center) / scale,
                    ),
                )
                for name, center, scale in zip(
                    feature_names, centers, scales
                )
            )
            prediction = bias + sum(
                weight * value
                for weight, value in zip(weights, standardized)
            )
            importance = informative_weight if row.informative else 1.0
            error = max(-4.0, min(4.0, prediction - row.advantage))
            bias -= rate * importance * error
            bias = max(-10.0, min(10.0, bias))
            for index, value in enumerate(standardized):
                gradient = importance * error * value + ridge * weights[index]
                weights[index] -= rate * gradient
                weights[index] = max(-10.0, min(10.0, weights[index]))
    return LinearAdvantageModel(
        feature_names=feature_names,
        centers=centers,
        scales=scales,
        weights=tuple(weights),
        bias=bias,
        training_config={
            "seed": seed,
            "epochs": epochs,
            "learning_rate": learning_rate,
            "ridge": ridge,
            "informative_weight": informative_weight,
        },
    )


def _predicted_actions(
    model: LinearAdvantageModel,
    program: GeneratedPolicyModuleProgram,
    probe: RepresentationProbe,
    *,
    include_candidate_representation: bool,
) -> Tuple[str, float, float]:
    scored = []
    incumbent_score = None
    for order, (action_ref, _) in enumerate(probe.action_values):
        score = model.predict(
            observable_action_features(
                program,
                probe,
                action_ref,
                include_candidate_representation=include_candidate_representation,
            )
        )
        scored.append((score, -order, action_ref))
        if action_ref == probe.incumbent_action_ref:
            incumbent_score = score
    if incumbent_score is None:
        raise ValueError("incumbent action is absent from legal actions")
    best_score, _, best_action_ref = max(
        scored, key=lambda item: (item[0], item[1])
    )
    return best_action_ref, best_score, float(incumbent_score)


def _mean_ci(values: Sequence[float]) -> Tuple[float, float, float]:
    if not values:
        return 0.0, 0.0, 0.0
    center = mean(values)
    if len(values) < 2:
        return center, center, center
    standard_error = stdev(values) / math.sqrt(len(values))
    radius = 1.96 * standard_error
    return center, center - radius, center + radius


def _selection_summary(
    probes: Sequence[RepresentationProbe],
    selected_action_refs: Mapping[str, str],
) -> Mapping[str, Any]:
    helpful = harmful = tied = overrides = regret = net = 0
    by_instance: Dict[str, int] = {}
    for probe in probes:
        selected = selected_action_refs[probe.probe_id]
        values = probe.values
        if selected not in values:
            raise ValueError("selector returned an action outside exact labels")
        incumbent_value = values[probe.incumbent_action_ref]
        selected_value = values[selected]
        advantage = incumbent_value - selected_value
        regret += selected_value - min(values.values())
        by_instance[probe.instance_id] = (
            by_instance.get(probe.instance_id, 0) + advantage
        )
        if _successor_signature(
            _parse_action(selected), probe.item, probe.loads, probe.capacity
        ) == _successor_signature(
            _parse_action(probe.incumbent_action_ref),
            probe.item,
            probe.loads,
            probe.capacity,
        ):
            continue
        overrides += 1
        net += advantage
        if advantage > 0:
            helpful += 1
        elif advantage < 0:
            harmful += 1
        else:
            tied += 1
    instance_values = tuple(by_instance[key] for key in sorted(by_instance))
    ci_mean, ci_lower, ci_upper = _mean_ci(instance_values)
    return {
        "probe_count": len(probes),
        "instance_count": len(instance_values),
        "override_count": overrides,
        "helpful_override_count": helpful,
        "harmful_override_count": harmful,
        "tied_override_count": tied,
        "aggregate_advantage_bins": net,
        "selected_exact_action_regret": regret,
        "mean_instance_advantage": ci_mean,
        "mean_instance_advantage_ci_lower": ci_lower,
        "mean_instance_advantage_ci_upper": ci_upper,
    }


def _selector_actions(
    model: LinearAdvantageModel,
    program: GeneratedPolicyModuleProgram,
    probes: Sequence[RepresentationProbe],
    *,
    include_candidate_representation: bool,
    shield_threshold: Optional[float],
) -> Tuple[Mapping[str, str], Tuple[float, ...]]:
    actions = {}
    margins = []
    for probe in probes:
        selected, best_score, incumbent_score = _predicted_actions(
            model,
            program,
            probe,
            include_candidate_representation=include_candidate_representation,
        )
        margin = best_score - incumbent_score
        margins.append(margin)
        if shield_threshold is not None and margin <= shield_threshold:
            selected = probe.incumbent_action_ref
        actions[probe.probe_id] = selected
    return actions, tuple(margins)


def _threshold_candidates(margins: Sequence[float]) -> Tuple[float, ...]:
    positive = sorted(set(value for value in margins if value > 0.0))
    if not positive:
        return (0.0,)
    indices = tuple(
        sorted(
            set(
                int(round(fraction * (len(positive) - 1)))
                for fraction in (0.0, 0.25, 0.5, 0.75, 0.9)
            )
        )
    )
    return tuple(sorted({0.0, *(positive[index] for index in indices)}))


@dataclass(frozen=True)
class RepresentationSelectorPolicy:
    program: GeneratedPolicyModuleProgram
    model: LinearAdvantageModel
    include_candidate_representation: bool
    shield_threshold: Optional[float]
    incumbent: OnlineHeuristic
    name: str

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        actions = _legal_actions(item, loads, capacity)
        state = RepresentationProbe(
            probe_id="online",
            split="development",
            instance_id="online",
            family="online",
            item=item,
            loads=tuple(loads),
            capacity=capacity,
            item_index=item_index,
            history=tuple(history[-128:]),
            action_values=tuple((_action_ref(action), 0) for action in actions),
            incumbent_action_ref=_action_ref(
                self.incumbent.choose_bin(
                    item, loads, capacity, item_index, history
                )
            ),
        )
        selected, best_score, incumbent_score = _predicted_actions(
            self.model,
            self.program,
            state,
            include_candidate_representation=(
                self.include_candidate_representation
            ),
        )
        if (
            self.shield_threshold is not None
            and best_score - incumbent_score <= self.shield_threshold
        ):
            selected = state.incumbent_action_ref
        return _parse_action(selected)


@dataclass(frozen=True)
class RepresentationCapacityResult:
    report: Mapping[str, Any]
    generic_pure_policy: RepresentationSelectorPolicy
    generic_shielded_policy: RepresentationSelectorPolicy
    representation_pure_policy: RepresentationSelectorPolicy
    representation_shielded_policy: RepresentationSelectorPolicy


def _fit_mode(
    program: GeneratedPolicyModuleProgram,
    development: Sequence[RepresentationProbe],
    validation: Sequence[RepresentationProbe],
    *,
    include_candidate_representation: bool,
    seed: int,
) -> Tuple[LinearAdvantageModel, float, Mapping[str, Any]]:
    training_rows = _value_rows(
        program,
        development,
        include_candidate_representation=include_candidate_representation,
    )
    configurations = (
        (36, 0.0025, 0.001, 3.0),
        (52, 0.0018, 0.003, 6.0),
        (68, 0.0012, 0.01, 10.0),
    )
    best = None
    attempts = []
    for index, (epochs, rate, ridge, weight) in enumerate(configurations):
        model = fit_linear_advantage_model(
            training_rows,
            seed=seed + index,
            epochs=epochs,
            learning_rate=rate,
            ridge=ridge,
            informative_weight=weight,
        )
        _, margins = _selector_actions(
            model,
            program,
            validation,
            include_candidate_representation=include_candidate_representation,
            shield_threshold=None,
        )
        for threshold in _threshold_candidates(margins):
            actions, _ = _selector_actions(
                model,
                program,
                validation,
                include_candidate_representation=(
                    include_candidate_representation
                ),
                shield_threshold=threshold,
            )
            summary = _selection_summary(validation, actions)
            attempt = {
                "model": model,
                "threshold": threshold,
                "summary": summary,
            }
            attempts.append(
                {
                    "model_id": model.as_dict()["model_id"],
                    "shield_threshold": threshold,
                    "validation": summary,
                }
            )
            rank = (
                summary["aggregate_advantage_bins"],
                -summary["selected_exact_action_regret"],
                summary["helpful_override_count"],
                -summary["harmful_override_count"],
                -summary["override_count"],
                -threshold,
            )
            if best is None or rank > best[0]:
                best = (rank, attempt)
    if best is None:
        raise RuntimeError("selector model search produced no attempt")
    selected = best[1]
    return (
        selected["model"],
        float(selected["threshold"]),
        {
            "attempt_count": len(attempts),
            "selected_model": selected["model"].as_dict(),
            "selected_shield_threshold": selected["threshold"],
            "adaptive_validation": selected["summary"],
            "selection_rank": list(best[0]),
        },
    )


def assess_representation_capacity(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
) -> RepresentationCapacityResult:
    """Test representation potential separately from the compiled controller."""

    development = corpus.split("development")
    validation = corpus.split("adaptive_validation")
    # Models and shield thresholds are completely selected before this binding.
    generic_model, generic_threshold, generic_selection = _fit_mode(
        program,
        development,
        validation,
        include_candidate_representation=False,
        seed=corpus.config.base_seed + 11_000,
    )
    representation_model, representation_threshold, representation_selection = (
        _fit_mode(
            program,
            development,
            validation,
            include_candidate_representation=True,
            seed=corpus.config.base_seed + 29_000,
        )
    )
    sealed = corpus.split("sealed_audit")
    incumbent = literature_heuristics()["funsearch_or_reference"]

    def policy(
        model: LinearAdvantageModel,
        include_representation: bool,
        threshold: Optional[float],
        suffix: str,
    ) -> RepresentationSelectorPolicy:
        return RepresentationSelectorPolicy(
            program=program,
            model=model,
            include_candidate_representation=include_representation,
            shield_threshold=threshold,
            incumbent=incumbent,
            name="representation_%s_%s" % (program.hypothesis_id[:8], suffix),
        )

    generic_pure = policy(generic_model, False, None, "generic_pure")
    generic_shielded = policy(
        generic_model, False, generic_threshold, "generic_shielded"
    )
    representation_pure = policy(
        representation_model, True, None, "candidate_pure"
    )
    representation_shielded = policy(
        representation_model,
        True,
        representation_threshold,
        "candidate_shielded",
    )

    def local_report(
        model: LinearAdvantageModel,
        include_representation: bool,
        threshold: float,
    ) -> Mapping[str, Any]:
        pure_actions, _ = _selector_actions(
            model,
            program,
            sealed,
            include_candidate_representation=include_representation,
            shield_threshold=None,
        )
        shielded_actions, _ = _selector_actions(
            model,
            program,
            sealed,
            include_candidate_representation=include_representation,
            shield_threshold=threshold,
        )
        return {
            "pure": _selection_summary(sealed, pure_actions),
            "shielded": _selection_summary(sealed, shielded_actions),
        }

    incumbent_actions = {
        probe.probe_id: probe.incumbent_action_ref for probe in sealed
    }
    oracle_actions = {
        probe.probe_id: min(
            probe.action_values,
            key=lambda item: (item[1], item[0] == "new", item[0]),
        )[0]
        for probe in sealed
    }
    compiled_actions = {
        probe.probe_id: _action_ref(
            program.choose_bin(
                probe.item,
                probe.loads,
                probe.capacity,
                probe.item_index,
                probe.history,
            )
        )
        for probe in sealed
    }
    generic_local = local_report(generic_model, False, generic_threshold)
    representation_local = local_report(
        representation_model, True, representation_threshold
    )
    incremental = (
        representation_local["shielded"]["aggregate_advantage_bins"]
        - generic_local["shielded"]["aggregate_advantage_bins"]
    )
    report: Dict[str, Any] = {
        "schema": 1,
        "version": REPRESENTATION_CAPACITY_VERSION,
        "candidate_id": program.candidate_id,
        "hypothesis_id": program.hypothesis_id,
        "corpus_id": corpus.report["corpus_id"],
        "candidate_future_access": False,
        "all_legal_actions_evaluated": True,
        "sealed_labels_available_during_model_selection": False,
        "generic_model_selection": generic_selection,
        "candidate_representation_model_selection": representation_selection,
        "sealed_audit": {
            "incumbent": _selection_summary(sealed, incumbent_actions),
            "all_action_oracle": _selection_summary(sealed, oracle_actions),
            "compiled_controller": _selection_summary(
                sealed, compiled_actions
            ),
            "generic_features": generic_local,
            "candidate_representation_features": representation_local,
            "candidate_minus_generic_shielded_advantage_bins": incremental,
        },
        "representation_adds_sealed_selective_value": bool(incremental > 0),
        "representation_selector_beats_incumbent_locally": bool(
            representation_local["shielded"]["aggregate_advantage_bins"] > 0
            and representation_local["shielded"]["helpful_override_count"]
            > representation_local["shielded"]["harmful_override_count"]
        ),
    }
    report["assessment_id"] = content_digest(report)
    return RepresentationCapacityResult(
        report=report,
        generic_pure_policy=generic_pure,
        generic_shielded_policy=generic_shielded,
        representation_pure_policy=representation_pure,
        representation_shielded_policy=representation_shielded,
    )
