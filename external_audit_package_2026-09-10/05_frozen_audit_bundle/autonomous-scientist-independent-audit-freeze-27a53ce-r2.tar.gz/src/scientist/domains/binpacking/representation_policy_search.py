from __future__ import annotations

import math
import random
from dataclasses import dataclass
from statistics import mean
from typing import Any, Callable, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.closed_loop_de_novo import (
    _abstract_actions,
    _post_loads,
    _stable_quantiles,
)
from scientist.domains.binpacking.heuristics import pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.program.discovery_evidence import paired_episode_evidence
from scientist.program.trajectory_improvement import (
    AbsoluteTrajectoryEvaluation,
    FrozenTrajectoryBatch,
    TrajectoryImprovementConfig,
    run_absolute_trajectory_improvement,
)


REPRESENTATION_POLICY_VERSION = "binpacking-representation-policy-v1"
MEMORY_TOPOLOGIES = (
    "multiscale_empirical_memory",
    "recency_regime_memory",
    "conditional_transition_memory",
    "quantile_sketch_memory",
)
STATE_TOPOLOGIES = (
    "completion_graph_state",
    "residual_supply_demand_state",
    "cohort_role_state",
    "fragmentation_geometry_state",
)
CONTROL_TOPOLOGIES = (
    "lexicographic_controller",
    "pareto_frontier_controller",
    "quota_automaton_controller",
    "scenario_consensus_controller",
)


def _memory_observations(
    topology: str,
    item: int,
    history: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    if not history:
        return tuple(
            dict.fromkeys(
                (
                    int(item),
                    max(1, capacity // 4),
                    max(1, capacity // 2),
                    max(1, (3 * capacity) // 4),
                )
            )
        )
    if topology == "multiscale_empirical_memory":
        recent = tuple(int(value) for value in history[-16:])
        background = tuple(int(value) for value in history[-96:-16:4])
        return (*recent, *background) or recent
    if topology == "recency_regime_memory":
        recent = tuple(int(value) for value in history[-20:])
        return (*recent, *recent[-8:])
    if topology == "conditional_transition_memory":
        selected = tuple(
            int(history[index + 1])
            for index in range(max(0, len(history) - 96), len(history) - 1)
            if abs(int(history[index]) - item) <= max(3, capacity // 15)
        )
        return selected[-32:] if len(selected) >= 4 else tuple(history[-48:])
    return _stable_quantiles(tuple(int(value) for value in history[-96:]), 9)


def _completion_tables(
    observed: Sequence[int],
    capacity: int,
) -> Tuple[Tuple[float, ...], Tuple[float, ...]]:
    tolerance = max(1, capacity // 75)
    support = _stable_quantiles(observed, min(11, len(observed)))
    single = tuple(
        sum(abs(value - residual) <= tolerance for value in observed)
        / float(len(observed))
        for residual in range(capacity + 1)
    )
    pair = tuple(
        sum(
            abs(left + right - residual) <= tolerance
            for left in support
            for right in support
        )
        / float(len(support) ** 2)
        for residual in range(capacity + 1)
    )
    return single, pair


def _state_descriptor(
    state_topology: str,
    loads: Sequence[int],
    capacity: int,
    observed: Sequence[int],
    single: Sequence[float],
    pair: Sequence[float],
) -> Dict[str, float]:
    residuals = tuple(capacity - load for load in loads)
    positive = tuple(residual for residual in residuals if residual > 0)
    minimum = min(observed)
    demands = _stable_quantiles(observed, 5)
    dead_mass = sum(
        residual for residual in positive if residual < minimum
    ) / float(capacity)
    uncovered = sum(
        not any(residual >= demand for residual in residuals)
        for demand in demands
    ) / float(len(demands))
    scarcity = sum(
        1.0 / (1.0 + sum(residual >= demand for residual in residuals))
        for demand in demands
    ) / float(len(demands))
    completion_denominator = float(max(1, len(positive)))
    single_completion = sum(single[value] for value in positive) / completion_denominator
    pair_completion = sum(pair[value] for value in positive) / completion_denominator
    residual_mean = sum(residuals) / float(len(residuals))
    dispersion = sum(
        abs(residual - residual_mean) for residual in residuals
    ) / float(len(residuals) * capacity)

    band_count = 8
    supply = [0.0] * band_count
    target = [0.0] * band_count
    for residual in residuals:
        band = min(
            band_count - 1,
            int(band_count * residual / float(capacity + 1)),
        )
        supply[band] += 1.0 / len(residuals)
    for value in observed:
        complement = capacity - value
        band = min(
            band_count - 1,
            int(band_count * complement / float(capacity + 1)),
        )
        target[band] += 1.0 / len(observed)
    market_imbalance = sum(
        abs(actual - desired) for actual, desired in zip(supply, target)
    )
    occupied_bands = sum(value > 0.0 for value in supply)
    cohort_gap = abs(occupied_bands - min(5, len(demands))) / 5.0

    descriptor = {
        "dead_mass": dead_mass,
        "uncovered": uncovered,
        "scarcity": scarcity,
        "single_completion": single_completion,
        "pair_completion": pair_completion,
        "market_imbalance": market_imbalance,
        "cohort_gap": cohort_gap,
        "dispersion": dispersion,
    }
    active = {
        "completion_graph_state": (
            "single_completion",
            "pair_completion",
            "dead_mass",
        ),
        "residual_supply_demand_state": (
            "uncovered",
            "scarcity",
            "market_imbalance",
        ),
        "cohort_role_state": (
            "cohort_gap",
            "market_imbalance",
            "single_completion",
        ),
        "fragmentation_geometry_state": (
            "dead_mass",
            "dispersion",
            "uncovered",
        ),
    }[state_topology]
    descriptor["active_primary"] = descriptor[active[0]]
    descriptor["active_secondary"] = descriptor[active[1]]
    descriptor["active_tertiary"] = descriptor[active[2]]
    return descriptor


@dataclass(frozen=True)
class RepresentationPolicy:
    memory_topology: str
    state_topology: str
    control_topology: str

    def __post_init__(self) -> None:
        if self.memory_topology not in MEMORY_TOPOLOGIES:
            raise ValueError("unsupported representation memory topology")
        if self.state_topology not in STATE_TOPOLOGIES:
            raise ValueError("unsupported representation state topology")
        if self.control_topology not in CONTROL_TOPOLOGIES:
            raise ValueError("unsupported representation control topology")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "version": REPRESENTATION_POLICY_VERSION,
                "memory_topology": self.memory_topology,
                "state_topology": self.state_topology,
                "control_topology": self.control_topology,
            }
        )

    @property
    def name(self) -> str:
        return "representation_policy_" + self.candidate_id[:12]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "representation_policy",
            "version": REPRESENTATION_POLICY_VERSION,
            "candidate_id": self.candidate_id,
            "name": self.name,
            "memory_topology": self.memory_topology,
            "state_topology": self.state_topology,
            "control_topology": self.control_topology,
            "numeric_parameter_count": 0,
            "complete_policy": True,
            "full_episode_training_signal": True,
            "incumbent": None,
            "incumbent_blind": True,
            "fallback_policy": None,
            "future_arrivals_available": False,
            "representation_search": True,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RepresentationPolicy":
        if value.get("version") != REPRESENTATION_POLICY_VERSION:
            raise ValueError("unsupported representation-policy version")
        policy = cls(
            str(value["memory_topology"]),
            str(value["state_topology"]),
            str(value["control_topology"]),
        )
        if value.get("candidate_id") != policy.candidate_id:
            raise ValueError("representation-policy identity mismatch")
        return policy

    @staticmethod
    def _pareto_choice(
        rows: Sequence[Mapping[str, Any]],
    ) -> Optional[int]:
        objectives = (
            "open",
            "active_primary",
            "active_secondary",
            "active_tertiary",
        )
        frontier = []
        for row in rows:
            dominated = any(
                all(other[key] <= row[key] for key in objectives)
                and any(other[key] < row[key] for key in objectives)
                for other in rows
                if other is not row
            )
            if not dominated:
                frontier.append(row)
        minima = {key: min(row[key] for row in rows) for key in objectives}
        maxima = {key: max(row[key] for row in rows) for key in objectives}

        def maximum_regret(row: Mapping[str, Any]) -> Tuple[float, int]:
            regrets = []
            for key in objectives:
                spread = maxima[key] - minima[key]
                regrets.append(
                    0.0 if spread <= 1e-12 else (row[key] - minima[key]) / spread
                )
            return max(regrets), int(row["numeric"])

        return min(frontier, key=maximum_regret)["action"]

    @staticmethod
    def _scenario_vote(
        rows: Sequence[Mapping[str, Any]],
        observed: Sequence[int],
        capacity: int,
    ) -> Optional[int]:
        scenarios = _stable_quantiles(observed, 7)
        votes = {row["numeric"]: 0 for row in rows}
        regret = {row["numeric"]: 0.0 for row in rows}
        for future_item in scenarios:
            outcomes = []
            for row in rows:
                residuals = row["residuals"]
                feasible_after = tuple(
                    residual - future_item
                    for residual in residuals
                    if residual >= future_item
                )
                opens = int(not feasible_after)
                closest = (
                    capacity - future_item
                    if not feasible_after
                    else min(feasible_after)
                )
                outcomes.append(
                    (
                        opens,
                        closest / float(capacity),
                        row["active_primary"],
                        row["numeric"],
                    )
                )
            best = min(outcomes)
            votes[best[3]] += 1
            for outcome in outcomes:
                regret[outcome[3]] += (
                    outcome[0] - best[0]
                    + outcome[1] - best[1]
                )
        selected_numeric = min(
            votes,
            key=lambda numeric: (-votes[numeric], regret[numeric], numeric),
        )
        return next(
            row["action"] for row in rows if row["numeric"] == selected_numeric
        )

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        del item_index
        observed = _memory_observations(
            self.memory_topology, item, history, capacity
        )
        single, pair = _completion_tables(observed, capacity)
        rows = []
        for action in _abstract_actions(item, loads, capacity, limit=18):
            post = _post_loads(item, loads, action)
            descriptor = _state_descriptor(
                self.state_topology,
                post,
                capacity,
                observed,
                single,
                pair,
            )
            remaining = capacity - (item if action is None else loads[action] + item)
            # Completion rewards are benefits; controllers minimize descriptors.
            descriptor["single_completion"] *= -1.0
            descriptor["pair_completion"] *= -1.0
            if self.state_topology == "completion_graph_state":
                descriptor["active_primary"] = descriptor["single_completion"]
                descriptor["active_secondary"] = descriptor["pair_completion"]
            rows.append(
                {
                    **descriptor,
                    "action": action,
                    "numeric": len(loads) if action is None else action,
                    "open": float(action is None),
                    "remaining": remaining,
                    "exact": float(remaining == 0),
                    "residuals": tuple(capacity - load for load in post),
                }
            )
        if self.control_topology == "pareto_frontier_controller":
            return self._pareto_choice(rows)
        if self.control_topology == "scenario_consensus_controller":
            return self._scenario_vote(rows, observed, capacity)
        if self.control_topology == "quota_automaton_controller":
            ordered = sorted(observed)
            lower = ordered[len(ordered) // 3]
            upper = ordered[(2 * len(ordered)) // 3]
            if item <= lower:
                target = capacity - upper
                mode = 0
            elif item >= upper:
                target = 0
                mode = 1
            else:
                target = capacity - ordered[len(ordered) // 2]
                mode = 2
            return min(
                rows,
                key=lambda row: (
                    row["open"],
                    mode,
                    abs(row["remaining"] - target),
                    row["active_primary"],
                    row["numeric"],
                ),
            )["action"]
        return min(
            rows,
            key=lambda row: (
                row["open"],
                -row["exact"],
                row["active_primary"],
                row["active_secondary"],
                row["active_tertiary"],
                row["numeric"],
            ),
        )["action"]


def initial_representation_population() -> Tuple[RepresentationPolicy, ...]:
    specifications = (
        (
            "multiscale_empirical_memory",
            "completion_graph_state",
            "lexicographic_controller",
        ),
        (
            "recency_regime_memory",
            "residual_supply_demand_state",
            "pareto_frontier_controller",
        ),
        (
            "conditional_transition_memory",
            "completion_graph_state",
            "scenario_consensus_controller",
        ),
        (
            "quantile_sketch_memory",
            "cohort_role_state",
            "quota_automaton_controller",
        ),
        (
            "multiscale_empirical_memory",
            "fragmentation_geometry_state",
            "pareto_frontier_controller",
        ),
        (
            "recency_regime_memory",
            "cohort_role_state",
            "scenario_consensus_controller",
        ),
        (
            "conditional_transition_memory",
            "residual_supply_demand_state",
            "quota_automaton_controller",
        ),
        (
            "quantile_sketch_memory",
            "fragmentation_geometry_state",
            "lexicographic_controller",
        ),
    )
    return tuple(RepresentationPolicy(*specification) for specification in specifications)


def mutate_representation_policy(
    parent: RepresentationPolicy,
    rng: random.Random,
    generation: int,
    child_index: int,
) -> RepresentationPolicy:
    del generation, child_index
    fields = [
        parent.memory_topology,
        parent.state_topology,
        parent.control_topology,
    ]
    spaces = (MEMORY_TOPOLOGIES, STATE_TOPOLOGIES, CONTROL_TOPOLOGIES)
    mutation_count = 1 if rng.random() < 0.75 else 2
    for index in rng.sample(range(3), mutation_count):
        fields[index] = rng.choice(
            tuple(value for value in spaces[index] if value != fields[index])
        )
    return RepresentationPolicy(*fields)


@dataclass(frozen=True)
class RepresentationSearchConfig:
    lengths: Tuple[int, ...] = (120, 250, 500)
    development_episodes_per_length: Tuple[int, ...] = (3, 5, 7)
    selection_episodes_per_length: int = 10
    validation_episodes_per_length: int = 40
    capacity: int = 150
    item_low: int = 20
    item_high: int = 100
    base_seed: int = 121_082_026
    population_size: int = 8
    elite_count: int = 3
    selection_pool_size: int = 4
    mutation_seed: int = 91_731

    def __post_init__(self) -> None:
        if not self.lengths or min(self.lengths) <= 1:
            raise ValueError("representation episode lengths must exceed one")
        if min(
            *self.development_episodes_per_length,
            self.selection_episodes_per_length,
            self.validation_episodes_per_length,
        ) < 2:
            raise ValueError("representation partitions need two episodes per length")
        if self.population_size != len(initial_representation_population()):
            raise ValueError("population size must match representation seeds")
        if not 0 < self.elite_count < self.population_size:
            raise ValueError("invalid representation elite count")
        if not 0 < self.selection_pool_size <= self.population_size:
            raise ValueError("invalid representation selection pool")
        if not 0 < self.item_low <= self.item_high <= self.capacity:
            raise ValueError("invalid representation IID distribution")

    @property
    def improvement_config(self) -> TrajectoryImprovementConfig:
        return TrajectoryImprovementConfig(
            population_size=self.population_size,
            elite_count=self.elite_count,
            selection_pool_size=self.selection_pool_size,
            generation_count=len(self.development_episodes_per_length),
            mutation_seed=self.mutation_seed,
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": REPRESENTATION_POLICY_VERSION,
            "lengths": list(self.lengths),
            "development_episodes_per_length": list(
                self.development_episodes_per_length
            ),
            "selection_episodes_per_length": self.selection_episodes_per_length,
            "validation_episodes_per_length": self.validation_episodes_per_length,
            "capacity": self.capacity,
            "item_low_inclusive": self.item_low,
            "item_high_inclusive": self.item_high,
            "base_seed": self.base_seed,
            "improvement": self.improvement_config.as_dict(),
        }


_PARTITION_OFFSETS = {
    "representation_development_0": 130_000_000,
    "representation_development_1": 330_000_000,
    "representation_development_2": 530_000_000,
    "representation_selection": 730_000_000,
    "representation_validation": 930_000_000,
}


def _instances(
    config: RepresentationSearchConfig,
    partition: str,
    episodes_per_length: int,
) -> Tuple[BinPackingInstance, ...]:
    instances = []
    for length_index, length in enumerate(config.lengths):
        for episode_index in range(episodes_per_length):
            seed = (
                config.base_seed
                + _PARTITION_OFFSETS[partition]
                + length_index * 10_000_000
                + episode_index
            )
            rng = random.Random(seed)
            instances.append(
                BinPackingInstance(
                    "%s:length=%d:seed=%d" % (partition, length, seed),
                    "iid_or_uniform_%d_%d" % (config.item_low, config.item_high),
                    seed,
                    config.capacity,
                    tuple(
                        rng.randint(config.item_low, config.item_high)
                        for _ in range(length)
                    ),
                )
            )
    return tuple(instances)


def _batch(
    config: RepresentationSearchConfig,
    partition: str,
    episodes_per_length: int,
) -> FrozenTrajectoryBatch[BinPackingInstance]:
    instances = _instances(config, partition, episodes_per_length)
    return FrozenTrajectoryBatch(
        partition,
        tuple(instance.instance_id for instance in instances),
        instances,
    )


def representation_search_commitment(
    config: RepresentationSearchConfig,
) -> Dict[str, Any]:
    development = tuple(
        _batch(config, "representation_development_%d" % index, count)
        for index, count in enumerate(config.development_episodes_per_length)
    )
    selection = _batch(
        config, "representation_selection", config.selection_episodes_per_length
    )
    validation = _batch(
        config, "representation_validation", config.validation_episodes_per_length
    )
    all_ids = tuple(
        episode_id
        for batch in (*development, selection, validation)
        for episode_id in batch.episode_ids
    )
    if len(set(all_ids)) != len(all_ids):
        raise AssertionError("representation-search partitions overlap")
    commitment: Dict[str, Any] = {
        "schema": 1,
        "version": REPRESENTATION_POLICY_VERSION,
        "config": config.as_dict(),
        "representation_grammar": {
            "memory_topologies": list(MEMORY_TOPOLOGIES),
            "state_topologies": list(STATE_TOPOLOGIES),
            "control_topologies": list(CONTROL_TOPOLOGIES),
            "numeric_parameter_count": 0,
        },
        "initial_population": [
            policy.as_dict() for policy in initial_representation_population()
        ],
        "structural_mutation_only": True,
        "development_batches": [batch.as_dict() for batch in development],
        "selection_batch": selection.as_dict(),
        "validation_batch": validation.as_dict(),
        "optimization_signal": (
            "negative terminal excess-bin count per complete episode; "
            "no incumbent-relative development signal"
        ),
        "comparator_access": "only after frozen selection_id",
        "candidate_fallback_policy": None,
        "prior_validation_reused": False,
    }
    commitment["commitment_id"] = content_digest(commitment)
    return commitment


def _evaluate_absolute_return(
    candidate: RepresentationPolicy,
    batch: FrozenTrajectoryBatch[BinPackingInstance],
) -> AbsoluteTrajectoryEvaluation:
    returns = []
    rows = []
    for instance in batch.experiments:
        result = pack(instance, candidate)
        lower_bound = math.ceil(sum(instance.items) / float(instance.capacity))
        excess = result.bin_count - lower_bound
        returns.append(-float(excess))
        rows.append(
            {
                "instance_id": instance.instance_id,
                "length": len(instance.items),
                "bin_count": result.bin_count,
                "volume_lower_bound": lower_bound,
                "excess_bins": excess,
                "return": -float(excess),
            }
        )
    return AbsoluteTrajectoryEvaluation(
        candidate.candidate_id,
        batch.batch_id,
        batch.episode_ids,
        tuple(returns),
        {"episodes": rows},
    )


def _compare_after_freeze(
    candidate: RepresentationPolicy,
    instances: Sequence[BinPackingInstance],
    selection_id: str,
) -> Dict[str, Any]:
    from scientist.domains.binpacking.heuristics import FunSearchORReference

    comparator = FunSearchORReference()
    rows = []
    for instance in instances:
        candidate_bins = pack(instance, candidate).bin_count
        funsearch_bins = pack(instance, comparator).bin_count
        rows.append(
            {
                "instance_id": instance.instance_id,
                "length": len(instance.items),
                "candidate_bins": candidate_bins,
                "funsearch_bins": funsearch_bins,
                "improvement": funsearch_bins - candidate_bins,
            }
        )
    evidence = paired_episode_evidence(
        (row["improvement"] for row in rows),
        tuple(row["instance_id"] for row in rows),
    )
    by_length = {}
    for length in sorted({row["length"] for row in rows}):
        selected = tuple(row for row in rows if row["length"] == length)
        by_length[str(length)] = paired_episode_evidence(
            (row["improvement"] for row in selected),
            tuple(row["instance_id"] for row in selected),
        ).as_dict()
    return {
        "selection_id": selection_id,
        "candidate_id": candidate.candidate_id,
        "comparator": comparator.name,
        "comparator_opened_after_selection": True,
        "evidence": evidence.as_dict(),
        "by_length": by_length,
        "screen_passed": (
            evidence.mean_ci_lower > 0.0
            and all(value["mean_improvement"] >= 0.0 for value in by_length.values())
        ),
        "episodes": rows,
    }


def run_representation_policy_search(
    config: RepresentationSearchConfig,
    *,
    commitment: Optional[Mapping[str, Any]] = None,
    progress: Optional[Callable[[str, Mapping[str, Any]], None]] = None,
) -> Dict[str, Any]:
    frozen_commitment = representation_search_commitment(config)
    if commitment is not None and dict(commitment) != frozen_commitment:
        raise ValueError("representation-search commitment does not match config")
    development = tuple(
        _batch(config, "representation_development_%d" % index, count)
        for index, count in enumerate(config.development_episodes_per_length)
    )
    selection = _batch(
        config, "representation_selection", config.selection_episodes_per_length
    )
    outcome = run_absolute_trajectory_improvement(
        config.improvement_config,
        initial_representation_population(),
        development,
        selection,
        _evaluate_absolute_return,
        mutate_representation_policy,
        progress=progress,
    )
    frozen_selection = {
        "status": "frozen_before_comparator_access",
        "selection_id": outcome.selection_id,
        "candidate_id": outcome.selected_candidate.candidate_id,
        "candidate": outcome.selected_candidate.as_dict(),
        "improvement_demonstrated": outcome.improvement_demonstrated,
        "funsearch_evaluated_during_search": False,
    }
    validation = _compare_after_freeze(
        outcome.selected_candidate,
        _instances(
            config,
            "representation_validation",
            config.validation_episodes_per_length,
        ),
        outcome.selection_id,
    )
    if progress is not None:
        progress(
            "representation_validation_complete",
            {
                "screen_passed": validation["screen_passed"],
                "mean_improvement": validation["evidence"]["mean_improvement"],
                "mean_ci_lower": validation["evidence"]["mean_improvement_ci_lower"],
                "mean_ci_upper": validation["evidence"]["mean_improvement_ci_upper"],
            },
        )
    report: Dict[str, Any] = {
        "schema": 1,
        "version": REPRESENTATION_POLICY_VERSION,
        "status": "completed",
        "commitment": frozen_commitment,
        "search": outcome.as_dict(),
        "selection": frozen_selection,
        "validation": validation,
        "architecture_audit": {
            "numeric_parameter_search": False,
            "typed_structural_mutation_only": True,
            "memory_state_and_control_are_identity_bearing": True,
            "complete_policies_only": True,
            "full_episode_absolute_return_only": True,
            "generic_search_has_incumbent_input": False,
            "candidate_fallback_policy": None,
            "prior_validation_reused": False,
            "comparator_opened_only_after_selection": True,
        },
        "confirmation_executed": False,
    }
    report["report_id"] = content_digest(report)
    return report
