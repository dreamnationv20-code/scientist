from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.mechanism_hypothesis import (
    ExecutableMechanismFingerprint,
)
from scientist.program.research_strategy import (
    RepresentationChangeProposal,
    RepresentationContract,
    RepresentationDimension,
    ResearchProgramContract,
    ResearchProgramDiagnosis,
    StrategyDisposition,
)


BINPACKING_RESEARCH_STRATEGY_VERSION = (
    "binpacking-representation-strategist-v2-first-principles"
)


def initial_binpacking_research_program(
    node_id: str,
    candidate_budget: int,
) -> ResearchProgramContract:
    representation = RepresentationContract(
        domain_id="online_one_dimensional_bin_packing",
        name="lane-typed-current-placement-controller",
        research_object_type="causal online placement policy",
        observation_schema=(
            "current item size",
            "current open-bin loads",
            "item index",
            "at most 128 past item sizes",
        ),
        state_schema=(
            "bounded numeric features computed from the legal observation",
        ),
        action_schema=(
            "choose one feasible current open bin",
            "open one new bin when returning the distinguished fallback",
        ),
        hypothesis_language=(
            "causal mechanism contract",
            "first-principles ideal-to-approximation derivation",
            "executable mechanism fingerprint",
            "bounded build_state plus choose_action Python module",
        ),
        composition_operators=(
            "host-enforced baseline plus abstaining ancestry intervention",
            "complete controller compiled from an objective derivation",
            "state construction followed by direct host selection",
            "optional state-dependent expert routing",
        ),
        objective_schema=(
            "minimize complete-episode bin count under the legal online action law",
            "use incumbent-relative improvement only as a paired measurement",
        ),
        experimental_unit="independently seeded complete packing episode",
        compiler_ref="bounded-generated-binpacking-module-v4-host-fallback",
        evaluator_ref="binpacking-sequential-packer-v1",
    )
    return ResearchProgramContract(
        node_id=node_id,
        question=(
            "Can a bounded causal current-placement policy improve on the "
            "reproduced FunSearch incumbent?"
        ),
        representation=representation,
        hypothesis_classes=(
            "incumbent-mechanism revision",
            "first-principles objective derivation",
            "relational cross-domain transfer",
            "state-dependent hybrid composition",
        ),
        assumptions=(
            "a productive intervention is expressible as one bounded module",
            "the current observation and direct host action expose the bottleneck",
            "exact or analytic micro-oracles expose harmful approximation gaps",
        ),
        success_criteria=(
            "a candidate has a positive episode-level confidence bound",
            "the derivation predicts and the executable realizes objective progress",
        ),
        kill_criteria=(
            "a matched three-channel cycle yields no supported improvement",
            "behavioral diversity remains inside one conceptual family",
        ),
        candidate_budget=candidate_budget,
        strategy_ref=BINPACKING_RESEARCH_STRATEGY_VERSION,
    )


class BinPackingRepresentationStrategist:
    """Turn a program diagnosis into a materially different policy language."""

    name = BINPACKING_RESEARCH_STRATEGY_VERSION

    def propose_change(
        self,
        program: ResearchProgramContract,
        diagnosis: ResearchProgramDiagnosis,
    ) -> RepresentationChangeProposal:
        if diagnosis.program_id != program.program_id:
            raise ValueError("representation strategist received another program")
        if diagnosis.disposition != StrategyDisposition.CHANGE_REPRESENTATION:
            raise ValueError("diagnosis does not request representation change")
        if program.representation.domain_id != "online_one_dimensional_bin_packing":
            raise ValueError("bin-packing strategist received another domain")

        first_revision = program.parent_program_id is None
        required = set(diagnosis.required_dimensions)
        required.update(
            {
                RepresentationDimension.STATE,
                RepresentationDimension.HYPOTHESIS_LANGUAGE,
                RepresentationDimension.COMPOSITION,
                RepresentationDimension.OBJECTIVE,
            }
        )
        changed_dimensions = tuple(
            dimension
            for dimension in RepresentationDimension
            if dimension in required
        )
        if first_revision:
            name = "residual-capacity-role-controller"
            state_schema = (
                "explicit residual-capacity role ledger reconstructed from loads",
                "bounded demand-regime evidence reconstructed from observed history",
                "confidence and abstention state for role interventions",
            )
            action_schema = (
                "select a typed legal role transition for the current item",
                "realize that transition by choosing one feasible host or opening",
            )
            language = (
                "typed role-lifecycle hypothesis with named causal mediator",
                "separate role selection, host realization, and robust fallback",
                "executable information and mechanism ablations",
            )
            composition = (
                "infer demand regime",
                "assign or update residual-capacity roles",
                "select one role-level intervention",
                "select a feasible member bin",
                "abstain to the reproduced fallback",
            )
            objective = (
                "preserve a portfolio of complementary residual-capacity roles",
                "improve episode bins subject to explicit intervention coverage",
            )
            hypothesis_classes = (
                "role creation and retirement",
                "capacity-portfolio coverage control",
                "confidence-gated role intervention",
                "cross-domain resource-lifecycle transfer",
            )
            removed = (
                "treating each feasible bin as an independently ranked action",
                "allowing free-form topology prose without an executable controller stage",
            )
            affordances = (
                "explicit bin-role lifecycle",
                "role-level interventions before host selection",
                "abstention when the role hypothesis is unsupported",
            )
        else:
            name = "counterfactual-option-graph-controller"
            state_schema = (
                "bounded causal option graph over residual-capacity classes",
                "observed support and contradiction counters on graph edges",
                "current legal intervention frontier",
            )
            action_schema = (
                "select a supported option-graph intervention node",
                "realize it as one legal current feasible-bin choice or opening",
            )
            language = (
                "typed causal graph with intervention and mediator nodes",
                "edge-level distinguishing predictions and kill conditions",
                "compiled controller plus graph-edge ablation",
            )
            composition = (
                "construct bounded option graph",
                "prune unsupported causal edges",
                "select an intervention node without scalar blending",
                "realize a legal host action",
                "fall back when no edge has support",
            )
            objective = (
                "maximize supported option preservation rather than local residual score",
                "penalize causal-edge contradictions before episode ranking",
            )
            hypothesis_classes = (
                "counterfactual option graph",
                "causal edge activation and retirement",
                "intervention-frontier control",
                "relational transfer of causal graph structure",
            )
            removed = (
                "fixed bin-role taxonomies",
                "routing among whole heuristics without causal edge tests",
            )
            affordances = (
                "candidate-specific causal graph structure",
                "edge-level falsification before episode evaluation",
                "automatic retirement of contradicted intervention edges",
            )

        revised_representation = RepresentationContract(
            domain_id=program.representation.domain_id,
            name=name,
            research_object_type="typed causal online controller",
            observation_schema=program.representation.observation_schema,
            state_schema=state_schema,
            action_schema=action_schema,
            hypothesis_language=language,
            composition_operators=composition,
            objective_schema=objective,
            experimental_unit=(
                "independent episode plus preregistered representation ablation"
            ),
            compiler_ref="bounded-typed-controller-compiler-v1",
            evaluator_ref=program.representation.evaluator_ref,
            parent_representation_id=(
                program.representation.representation_id
            ),
            changed_dimensions=changed_dimensions,
        )
        revised_program = ResearchProgramContract(
            node_id=program.node_id,
            question=program.question,
            representation=revised_representation,
            hypothesis_classes=hypothesis_classes,
            assumptions=(
                "the revised typed controller exposes a previously collapsed decision object",
                "the new controller stages are executable under the unchanged online action law",
                "representation ablation can distinguish the revision from prompt variation",
            ),
            success_criteria=program.success_criteria,
            kill_criteria=(
                "one matched three-channel cycle yields no supported effect",
                "compiled objects fail the revised representation ablation",
            ),
            candidate_budget=program.candidate_budget,
            strategy_ref=self.name,
            parent_program_id=program.program_id,
        )
        return RepresentationChangeProposal(
            diagnosis_id=diagnosis.diagnosis_id,
            prior_program_id=program.program_id,
            revised_program=revised_program,
            preserved_invariants=(
                "strict online irrevocable arrival order",
                "only a current feasible host choice or new-bin opening is legal",
                "same incumbent, evidence partitions, evaluator, and truth gates",
            ),
            removed_constraints=removed,
            new_affordances=affordances,
            migration_steps=(
                "bind the revised representation identity into every candidate",
                "generate hypotheses in the revised typed language",
                "compile each declared controller stage into bounded executable code",
                "reject executables that fail structural representation compliance",
                "run representation ablation before episode screening",
            ),
            falsification_tests=(
                "the revised source omits a required executable controller stage",
                "state or controller ablation never changes an action",
                "the revised population remains behaviorally equivalent to the prior representation",
                "a matched cycle yields no confidence-supported episode effect",
            ),
            proposer_ref=self.name,
        )


@dataclass(frozen=True)
class RepresentationComplianceAssessment:
    representation_id: str
    source_digest: str
    passed: bool
    checks: Mapping[str, bool]
    failure_reasons: Tuple[str, ...]
    assessor_ref: str = "binpacking-executable-representation-auditor-v1"

    @property
    def assessment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "representation_id": self.representation_id,
            "source_digest": self.source_digest,
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "failure_reasons": list(self.failure_reasons),
            "assessor_ref": self.assessor_ref,
        }
        if include_id:
            value["assessment_id"] = self.assessment_id
        return value


def assess_compiled_representation(
    source: str,
    fingerprint: ExecutableMechanismFingerprint,
    representation: RepresentationContract,
) -> RepresentationComplianceAssessment:
    """Fail closed on executable aspects of a representation revision."""

    checks: Dict[str, bool] = {}
    failures = []
    try:
        tree = ast.parse(source, mode="exec")
    except SyntaxError:
        tree = ast.Module(body=[], type_ignores=[])
        failures.append("representation_source_is_not_valid_python")
    functions = {
        item.name: item
        for item in tree.body
        if isinstance(item, ast.FunctionDef)
    }
    build_state = functions.get("build_state")
    choose_action = functions.get("choose_action")
    checks["declared_module_boundary"] = (
        build_state is not None and choose_action is not None
    )
    changed = set(representation.changed_dimensions)
    if representation.parent_representation_id is None:
        checks["initial_representation"] = True
    else:
        if build_state is None or choose_action is None:
            failures.append("revised_representation_omits_required_functions")
        else:
            build_reads = {
                node.id
                for node in ast.walk(build_state)
                if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)
            }
            choose_reads = {
                node.id
                for node in ast.walk(choose_action)
                if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)
            }
            if RepresentationDimension.STATE in changed:
                checks["state_uses_loads_and_history"] = {
                    "loads",
                    "history",
                }.issubset(build_reads)
                checks["controller_consumes_state"] = "state" in choose_reads
            if (
                RepresentationDimension.ACTION in changed
                or RepresentationDimension.COMPOSITION in changed
            ):
                if_count = sum(
                    isinstance(node, ast.If) for node in ast.walk(choose_action)
                )
                loop_count = sum(
                    isinstance(node, ast.For) for node in ast.walk(choose_action)
                )
                checks["multi_stage_controller"] = if_count >= 2 and loop_count >= 1
            if RepresentationDimension.HYPOTHESIS_LANGUAGE in changed:
                checks["non_scalar_fingerprint"] = (
                    fingerprint.decision_topology != "greedy_scalar_action_score"
                    and fingerprint.structural_distance >= 3
                )
            if RepresentationDimension.OBJECTIVE in changed:
                checks["coupled_intervention_objective"] = (
                    fingerprint.action_coupling
                    not in {"independent_action_scoring", "none"}
                    and bool(fingerprint.optimization_object.strip())
                )
    failures.extend(
        "failed_%s" % name for name, passed in checks.items() if not passed
    )
    failures = list(dict.fromkeys(failures))
    return RepresentationComplianceAssessment(
        representation_id=representation.representation_id,
        source_digest=content_digest(source.strip()),
        passed=not failures,
        checks=checks,
        failure_reasons=tuple(failures),
    )
