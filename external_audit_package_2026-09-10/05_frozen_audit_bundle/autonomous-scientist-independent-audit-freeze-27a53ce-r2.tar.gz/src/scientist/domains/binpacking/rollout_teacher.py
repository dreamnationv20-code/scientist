from __future__ import annotations

from dataclasses import dataclass
import random
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import (
    OnlineHeuristic,
    baseline_heuristics,
    literature_heuristics,
)
from scientist.domains.binpacking.stochastic_value import (
    StochasticValueConfig,
    _action_ref,
    _apply_action,
    _iid_episode,
    _rollout_from_loads,
    _selected_state_indices,
)


ROLLOUT_TEACHER_VERSION = "binpacking-de-novo-rollout-teacher-v1"


@dataclass(frozen=True)
class RolloutTeacherConfig:
    capacity: int = 150
    item_low: int = 20
    item_high: int = 100
    episode_lengths: Tuple[int, ...] = (120, 250, 500)
    episodes_per_length: int = 3
    states_per_episode: int = 2
    suffix_samples_per_action: int = 4
    base_seed: int = 91_730_026

    def __post_init__(self) -> None:
        if self.capacity <= 0 or not 0 < self.item_low <= self.item_high:
            raise ValueError("invalid rollout-teacher distribution")
        if self.item_high > self.capacity:
            raise ValueError("rollout-teacher items exceed capacity")
        if not self.episode_lengths or min(self.episode_lengths) <= 2:
            raise ValueError("rollout-teacher episodes are too short")
        if min(
            self.episodes_per_length,
            self.states_per_episode,
            self.suffix_samples_per_action,
        ) <= 0:
            raise ValueError("rollout-teacher counts must be positive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "capacity": self.capacity,
            "item_low": self.item_low,
            "item_high": self.item_high,
            "episode_lengths": list(self.episode_lengths),
            "episodes_per_length": self.episodes_per_length,
            "states_per_episode": self.states_per_episode,
            "suffix_samples_per_action": self.suffix_samples_per_action,
            "base_seed": self.base_seed,
        }


@dataclass(frozen=True)
class RolloutTeacherProbe:
    probe_id: str
    item: int
    loads: Tuple[int, ...]
    capacity: int
    item_index: int
    history: Tuple[int, ...]
    action_values: Tuple[Tuple[str, float], ...]
    incumbent_action_ref: str

    @property
    def values(self) -> Mapping[str, float]:
        return dict(self.action_values)

    @property
    def best_value(self) -> float:
        return min(value for _, value in self.action_values)

    @property
    def incumbent_value(self) -> float:
        return self.values[self.incumbent_action_ref]

    @property
    def headroom(self) -> float:
        return self.incumbent_value - self.best_value

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe_id": self.probe_id,
            "item": self.item,
            "loads": list(self.loads),
            "capacity": self.capacity,
            "item_index": self.item_index,
            "history": list(self.history),
            "action_values": [
                {"action_ref": action_ref, "expected_terminal_bins": value}
                for action_ref, value in self.action_values
            ],
            "incumbent_action_ref": self.incumbent_action_ref,
            "best_expected_terminal_bins": self.best_value,
            "incumbent_expected_terminal_bins": self.incumbent_value,
            "estimated_headroom_bins": self.headroom,
        }


@dataclass(frozen=True)
class RolloutTeacherResult:
    config: RolloutTeacherConfig
    probes: Tuple[RolloutTeacherProbe, ...]
    report: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            **dict(self.report),
            "config": self.config.as_dict(),
            "probes": [probe.as_dict() for probe in self.probes],
        }


def _legal_actions(
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[Optional[int], ...]:
    return (
        *(
            index
            for index, load in enumerate(loads)
            if load + item <= capacity
        ),
        None,
    )


def build_rollout_teacher(
    config: RolloutTeacherConfig = RolloutTeacherConfig(),
) -> RolloutTeacherResult:
    """Build a privileged offline action-value teacher on observable states.

    Common sampled continuations are used for every legal action. The deployed
    candidate never receives a sampled continuation; it only sees fitted numeric
    parameters frozen before admission.
    """

    controls = baseline_heuristics()
    incumbent = literature_heuristics()["funsearch_or_reference"]
    state_policies = (controls["best_fit"], incumbent)
    completion_policies = (controls["best_fit"], incumbent)
    stochastic_config = StochasticValueConfig(
        capacity=config.capacity,
        item_low=config.item_low,
        item_high=config.item_high,
        training_lengths=config.episode_lengths,
        training_episodes_per_length=max(
            4, config.episodes_per_length
        ),
        states_per_episode=config.states_per_episode,
        actions_per_state=1,
        suffix_samples_per_action=config.suffix_samples_per_action,
        grouped_cv_folds=2,
        validation_episodes_per_length=2,
        replication_episodes_per_length=2,
        base_seed=config.base_seed,
        fit_epochs=1,
    )
    probes = []
    for length_index, length in enumerate(config.episode_lengths):
        for episode_index in range(config.episodes_per_length):
            episode_seed = (
                config.base_seed
                + length_index * 10_000_000
                + episode_index
            )
            items = _iid_episode(stochastic_config, length, episode_seed)
            state_policy = state_policies[
                (length_index + episode_index) % len(state_policies)
            ]
            selected = set(
                _selected_state_indices(
                    length,
                    config.states_per_episode,
                    episode_seed ^ 0x51F15EED,
                )
            )
            loads: Tuple[int, ...] = ()
            history: Tuple[int, ...] = ()
            for item_index, item in enumerate(items):
                state_action = state_policy.choose_bin(
                    item, loads, config.capacity, item_index, history
                )
                if item_index in selected:
                    actions = _legal_actions(item, loads, config.capacity)
                    suffixes = []
                    remaining_length = length - item_index - 1
                    for sample_index in range(
                        config.suffix_samples_per_action
                    ):
                        suffix_seed = int(
                            content_digest(
                                {
                                    "version": ROLLOUT_TEACHER_VERSION,
                                    "episode_seed": episode_seed,
                                    "item_index": item_index,
                                    "sample_index": sample_index,
                                }
                            )[:16],
                            16,
                        )
                        suffixes.append(
                            _iid_episode(
                                stochastic_config,
                                remaining_length,
                                suffix_seed,
                            )
                        )
                    values = []
                    value_by_successor: Dict[Tuple[int, ...], float] = {}
                    for action in actions:
                        forced_loads = _apply_action(
                            loads, item, action, config.capacity
                        )
                        successor_key = tuple(sorted(forced_loads))
                        action_value = value_by_successor.get(successor_key)
                        if action_value is None:
                            returns = []
                            for suffix in suffixes:
                                returns.append(
                                    min(
                                        _rollout_from_loads(
                                            forced_loads,
                                            (*history, item),
                                            suffix,
                                            config.capacity,
                                            completion_policy,
                                        )
                                        for completion_policy in completion_policies
                                    )
                                )
                            action_value = mean(returns)
                            value_by_successor[successor_key] = action_value
                        values.append((_action_ref(action), action_value))
                    incumbent_action = incumbent.choose_bin(
                        item,
                        loads,
                        config.capacity,
                        item_index,
                        history,
                    )
                    probe_material = {
                        "episode_seed": episode_seed,
                        "item_index": item_index,
                        "item": item,
                        "loads": list(loads),
                    }
                    probes.append(
                        RolloutTeacherProbe(
                            probe_id=content_digest(probe_material),
                            item=item,
                            loads=loads,
                            capacity=config.capacity,
                            item_index=item_index,
                            history=history,
                            action_values=tuple(values),
                            incumbent_action_ref=_action_ref(incumbent_action),
                        )
                    )
                loads = _apply_action(
                    loads, item, state_action, config.capacity
                )
                history = (*history, item)

    headrooms = tuple(probe.headroom for probe in probes)
    report: Dict[str, Any] = {
        "schema": 1,
        "teacher_version": ROLLOUT_TEACHER_VERSION,
        "probe_count": len(probes),
        "state_generators": [policy.name for policy in state_policies],
        "completion_portfolio": [
            policy.name for policy in completion_policies
        ],
        "candidate_future_access": False,
        "common_random_numbers_across_actions": True,
        "mean_estimated_action_headroom_bins": mean(headrooms),
        "positive_headroom_probe_count": sum(value > 0 for value in headrooms),
        "zero_headroom_probe_count": sum(value == 0 for value in headrooms),
        "maximum_estimated_action_headroom_bins": max(headrooms),
        "headroom_detected": any(value > 0 for value in headrooms),
    }
    report["teacher_id"] = content_digest(
        {
            **report,
            "config": config.as_dict(),
            "probe_ids": [probe.probe_id for probe in probes],
        }
    )
    return RolloutTeacherResult(config, tuple(probes), report)


def score_policy_on_rollout_teacher(
    policy: OnlineHeuristic,
    probes: Sequence[RolloutTeacherProbe],
) -> Mapping[str, Any]:
    regrets = []
    exact_best = 0
    missing = 0
    for probe in probes:
        action = policy.choose_bin(
            probe.item,
            probe.loads,
            probe.capacity,
            probe.item_index,
            probe.history,
        )
        values = probe.values
        action_value = values.get(_action_ref(action))
        if action_value is None:
            missing += 1
            regrets.append(max(values.values()) - probe.best_value + 1.0)
            continue
        regret = action_value - probe.best_value
        regrets.append(regret)
        exact_best += int(regret == 0.0)
    return {
        "probe_count": len(probes),
        "mean_rollout_regret_bins": mean(regrets) if regrets else 0.0,
        "aggregate_rollout_regret_bins": sum(regrets),
        "teacher_best_action_count": exact_best,
        "teacher_best_action_rate": (
            exact_best / float(len(probes)) if probes else 0.0
        ),
        "missing_action_count": missing,
    }
