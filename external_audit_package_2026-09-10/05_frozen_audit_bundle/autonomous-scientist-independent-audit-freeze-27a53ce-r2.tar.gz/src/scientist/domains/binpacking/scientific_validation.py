from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import (
    GeneratedPolicyRejected,
    GeneratedPolicyModuleProgram,
    GeneratedPolicyProgram,
)
from scientist.domains.binpacking.equivalence import (
    behaviour_fingerprint,
    direct_action_comparison,
)
from scientist.domains.binpacking.heuristics import (
    FunctionalHeuristic,
    FunSearchORReference,
    OnlineHeuristic,
    baseline_heuristics,
    literature_heuristics,
    pack,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.programs import (
    ActionHybridProgram,
    CalibratedOverrideActionProgram,
    CalibratedOverrideHybridProgram,
    ContextualLinearProgram,
    DemandMemoryProgram,
    Expression,
    FunSearchResidualProgram,
    HybridPolicyProgram,
    MoonshotProgram,
    MoonshotHybridProgram,
    PriorityProgram,
    RegimeRouterProgram,
    StructuralHybridProgram,
)


SCIENTIFIC_VALIDATION_VERSION = "binpacking-scientific-validation-v7"


@dataclass(frozen=True)
class PolicyOutcomeComparison:
    candidate_id: str
    reference_id: str
    case_count: int
    aggregate_delta: int
    wins: int
    losses: int
    ties: int
    maximum_regression: int
    changed_outcome_cases: int

    @property
    def improved(self) -> bool:
        return self.aggregate_delta < 0

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "reference_id": self.reference_id,
            "case_count": self.case_count,
            "aggregate_delta": self.aggregate_delta,
            "wins": self.wins,
            "losses": self.losses,
            "ties": self.ties,
            "maximum_regression": self.maximum_regression,
            "changed_outcome_cases": self.changed_outcome_cases,
            "improved": self.improved,
        }


@dataclass(frozen=True)
class CompositeAblations:
    composition_kind: str
    fallback: OnlineHeuristic
    module_only: OnlineHeuristic


def _policy_id(policy: OnlineHeuristic) -> str:
    value = getattr(policy, "candidate_id", None)
    if value:
        return str(value)
    return str(policy.name)


def _rendered(policy: OnlineHeuristic) -> str:
    serializer = getattr(policy, "as_dict", None)
    if serializer is None:
        return str(policy.name)
    return str(serializer().get("rendered", policy.name))


def compare_policy_outcomes(
    candidate: OnlineHeuristic,
    reference: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
) -> PolicyOutcomeComparison:
    deltas = tuple(
        pack(instance, candidate).bin_count
        - pack(instance, reference).bin_count
        for instance in instances
    )
    return PolicyOutcomeComparison(
        candidate_id=_policy_id(candidate),
        reference_id=_policy_id(reference),
        case_count=len(deltas),
        aggregate_delta=sum(deltas),
        wins=sum(delta < 0 for delta in deltas),
        losses=sum(delta > 0 for delta in deltas),
        ties=sum(delta == 0 for delta in deltas),
        maximum_regression=max(deltas, default=0),
        changed_outcome_cases=sum(delta != 0 for delta in deltas),
    )


def composite_ablations(
    candidate: OnlineHeuristic,
) -> Optional[CompositeAblations]:
    incumbent = FunSearchORReference()
    if isinstance(candidate, FunSearchResidualProgram):
        return CompositeAblations(
            composition_kind="funsearch_residual",
            fallback=incumbent,
            module_only=PriorityProgram(candidate.expression),
        )
    if isinstance(candidate, MoonshotHybridProgram):
        return CompositeAblations(
            composition_kind="moonshot_hybrid",
            fallback=FunSearchResidualProgram(
                candidate.ancestry_expression,
                candidate.residual_scale,
            ),
            module_only=candidate.moonshot,
        )
    if isinstance(candidate, StructuralHybridProgram):
        return CompositeAblations(
            composition_kind="typed_structural_hybrid",
            fallback=candidate.ancestry,
            module_only=candidate.moonshot,
        )
    if isinstance(candidate, CalibratedOverrideHybridProgram):
        return CompositeAblations(
            composition_kind="calibrated_override_value_hybrid",
            fallback=candidate.ancestry,
            module_only=CalibratedOverrideActionProgram(
                candidate.ancestry,
                candidate.override_model,
            ),
        )
    if isinstance(candidate, ActionHybridProgram):
        return CompositeAblations(
            composition_kind="action_score_hybrid",
            fallback=incumbent,
            module_only=PriorityProgram(candidate.gated_expression),
        )
    if isinstance(candidate, HybridPolicyProgram):
        return CompositeAblations(
            composition_kind="policy_router_hybrid",
            fallback=incumbent,
            module_only=PriorityProgram(candidate.de_novo_expression),
        )
    if (
        isinstance(candidate, ContextualLinearProgram)
        and candidate.mode in ("ancestry", "hybrid")
    ):
        return CompositeAblations(
            composition_kind=(
                "contextual_linear_%s" % candidate.mode
            ),
            fallback=incumbent,
            module_only=ContextualLinearProgram(
                "de_novo",
                candidate.weights,
                candidate.residual_scale,
            ),
        )
    if (
        isinstance(candidate, DemandMemoryProgram)
        and candidate.mode in ("ancestry", "hybrid")
    ):
        return CompositeAblations(
            composition_kind="demand_memory_%s" % candidate.mode,
            fallback=incumbent,
            module_only=DemandMemoryProgram(
                "de_novo",
                candidate.weights,
                candidate.residual_scale,
            ),
        )
    if (
        isinstance(candidate, RegimeRouterProgram)
        and candidate.mode in ("ancestry", "hybrid")
    ):
        return CompositeAblations(
            composition_kind="regime_router_%s" % candidate.mode,
            fallback=incumbent,
            module_only=RegimeRouterProgram(
                "de_novo",
                candidate.policy_weights,
            ),
        )
    return None


def _moonshot_activation_count(
    candidate: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
) -> Optional[int]:
    if not isinstance(
        candidate,
        (
            MoonshotHybridProgram,
            StructuralHybridProgram,
            CalibratedOverrideHybridProgram,
        ),
    ):
        return None
    activations = 0
    if isinstance(candidate, CalibratedOverrideHybridProgram):
        for instance in instances:
            loads = []
            history = []
            for item_index, item in enumerate(instance.items):
                _, _, confidence, _ = candidate.override_decision(
                    item,
                    tuple(loads),
                    instance.capacity,
                    item_index,
                    tuple(history),
                )
                if confidence >= candidate.confidence_threshold:
                    activations += 1
                action = candidate.choose_bin(
                    item,
                    tuple(loads),
                    instance.capacity,
                    item_index,
                    tuple(history),
                )
                if action is None:
                    loads.append(item)
                else:
                    loads[action] += item
                history.append(item)
        return activations
    fallback_policy: OnlineHeuristic = (
        FunSearchResidualProgram(
            candidate.ancestry_expression,
            candidate.residual_scale,
        )
        if isinstance(candidate, MoonshotHybridProgram)
        else candidate.ancestry
    )
    for instance in instances:
        loads = []
        history = []
        for item_index, item in enumerate(instance.items):
            fallback_action = fallback_policy.choose_bin(
                item,
                tuple(loads),
                instance.capacity,
                item_index,
                tuple(history),
            )
            _, confidence = candidate.moonshot.proposed_override(
                item,
                tuple(loads),
                instance.capacity,
                tuple(history),
                fallback_action,
            )
            if confidence >= candidate.gate_threshold:
                activations += 1
            action = candidate.choose_bin(
                item,
                tuple(loads),
                instance.capacity,
                item_index,
                tuple(history),
            )
            if action is None:
                loads.append(item)
            else:
                loads[action] += item
            history.append(item)
    return activations


def assess_composite_contribution(
    candidate: OnlineHeuristic,
    incumbent: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
    *,
    minimum_action_disagreement_rate: float = 0.001,
    minimum_action_disagreements: int = 2,
    maximum_parent_regression: int = 1,
) -> Mapping[str, Any]:
    ablations = composite_ablations(candidate)
    full_vs_incumbent = compare_policy_outcomes(
        candidate,
        incumbent,
        instances,
    )
    if ablations is None:
        report = {
            "schema": 1,
            "validation_version": SCIENTIFIC_VALIDATION_VERSION,
            "applicable": False,
            "candidate_id": _policy_id(candidate),
            "composition_kind": "not_composite",
            "full_vs_incumbent": full_vs_incumbent.as_dict(),
            "passed": True,
            "failure_reasons": [],
            "interpretation": (
                "candidate is not a composed policy; parent contribution "
                "ablation is not applicable"
            ),
        }
        return {
            **report,
            "assessment_id": content_digest(report),
        }

    fallback_vs_incumbent = compare_policy_outcomes(
        ablations.fallback,
        incumbent,
        instances,
    )
    module_vs_incumbent = compare_policy_outcomes(
        ablations.module_only,
        incumbent,
        instances,
    )
    full_vs_fallback = compare_policy_outcomes(
        candidate,
        ablations.fallback,
        instances,
    )
    action_comparison = direct_action_comparison(
        candidate,
        ablations.fallback,
        instances,
    )
    minimum_disagreements = max(
        minimum_action_disagreements,
        int(
            math.ceil(
                action_comparison.decision_count
                * minimum_action_disagreement_rate
            )
        ),
    )
    activation_count = _moonshot_activation_count(candidate, instances)
    failures = []
    if not full_vs_fallback.improved:
        failures.append("full_composition_did_not_beat_strongest_parent")
    if full_vs_fallback.maximum_regression > maximum_parent_regression:
        failures.append("full_composition_regressed_beyond_parent_limit")
    if action_comparison.disagreements < minimum_disagreements:
        failures.append("module_action_intervention_below_minimum")
    if full_vs_fallback.wins == 0:
        failures.append("no_parent_relative_win_attributable_to_module")
    if (
        activation_count is not None
        and activation_count > 0
        and action_comparison.disagreements == 0
    ):
        failures.append("module_activated_without_changing_any_action")

    report = {
        "schema": 1,
        "validation_version": SCIENTIFIC_VALIDATION_VERSION,
        "applicable": True,
        "candidate_id": _policy_id(candidate),
        "composition_kind": ablations.composition_kind,
        "fallback": {
            "candidate_id": _policy_id(ablations.fallback),
            "rendered": _rendered(ablations.fallback),
        },
        "module_only": {
            "candidate_id": _policy_id(ablations.module_only),
            "rendered": _rendered(ablations.module_only),
        },
        "full_vs_incumbent": full_vs_incumbent.as_dict(),
        "fallback_vs_incumbent": fallback_vs_incumbent.as_dict(),
        "module_vs_incumbent": module_vs_incumbent.as_dict(),
        "full_vs_fallback": full_vs_fallback.as_dict(),
        "same_state_action_comparison": action_comparison.as_dict(),
        "module_activation_count": activation_count,
        "minimum_action_disagreements": minimum_disagreements,
        "passed": not failures,
        "failure_reasons": failures,
        "interpretation": (
            "the composed mechanism adds a measurable, parent-relative "
            "causal contribution"
            if not failures
            else "the composed mechanism cannot receive credit for the "
            "observed incumbent-relative result"
        ),
    }
    return {
        **report,
        "assessment_id": content_digest(report),
    }


def _exact_fill_control(prefer_last: bool) -> FunctionalHeuristic:
    incumbent = FunSearchORReference()

    def choose(
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        exact = tuple(
            index
            for index, load in enumerate(loads)
            if load + item == capacity
        )
        if exact:
            return exact[-1] if prefer_last else exact[0]
        return incumbent.choose_bin(
            item,
            loads,
            capacity,
            item_index,
            history,
        )

    return FunctionalHeuristic(
        "exact_fill_%s_then_funsearch"
        % ("last" if prefer_last else "first"),
        choose,
    )


def semantic_control_policies() -> Mapping[str, OnlineHeuristic]:
    return {
        **baseline_heuristics(),
        **literature_heuristics(),
        "exact_fill_first_then_funsearch": _exact_fill_control(False),
        "exact_fill_last_then_funsearch": _exact_fill_control(True),
    }


def _expression_exact_fill_localized(
    expression: Expression,
    capacity: int,
) -> bool:
    def vector(remaining_units: int) -> Tuple[float, ...]:
        values = []
        for bin_index in (0.0, 0.5, 1.0):
            remaining = remaining_units / float(capacity)
            features = {
                "item": 0.5,
                "load": max(0.0, 0.5 - remaining),
                "remaining_before": 0.5 + remaining,
                "remaining_after": remaining,
                "fill_after": 1.0 - remaining,
                "bin_index": bin_index,
                "open_bins": 0.5,
                "is_new_bin": 0.0,
                "seen_mean": 0.5,
                "seen_min": 0.2,
                "seen_std": 0.2,
                "seen_large_fraction": 0.5,
            }
            values.append(expression.evaluate(features))
        return tuple(values)

    exact = vector(0)
    positive = tuple(
        vector(value)
        for value in range(1, min(capacity, 12) + 1)
    )
    first_positive = positive[0]
    exact_effect = max(
        abs(left - right)
        for left, right in zip(exact, first_positive)
    )
    positive_variation = max(
        (
            abs(left - right)
            for current in positive[1:]
            for left, right in zip(current, first_positive)
        ),
        default=0.0,
    )
    return exact_effect > 1e-9 and positive_variation <= 1e-9


def reduced_mechanism_labels(
    candidate: OnlineHeuristic,
    capacity: int,
) -> Tuple[str, ...]:
    labels = []
    residual: Optional[FunSearchResidualProgram] = None
    if isinstance(candidate, GeneratedPolicyModuleProgram):
        fingerprint = candidate.mechanism_fingerprint
        labels.extend(
            (
                "topology:%s" % fingerprint.decision_topology,
                "memory:%s" % fingerprint.memory,
                "horizon:%s" % fingerprint.horizon,
                "action_coupling:%s" % fingerprint.action_coupling,
                "optimization:%s" % fingerprint.optimization_object,
                "intervention:%s" % fingerprint.intervention_structure,
                "fallback:%s" % fingerprint.fallback,
                "known_family:%s" % fingerprint.known_family,
            )
        )
    elif isinstance(candidate, GeneratedPolicyProgram):
        labels.append("legacy_uncontracted_scalar_generated_policy")
    elif isinstance(candidate, FunSearchResidualProgram):
        residual = candidate
    elif isinstance(candidate, MoonshotProgram):
        labels.append(
            {
                "robust_counterfactual_rollout": (
                    "uncertainty_adjusted_counterfactual_shadow_rollout"
                ),
                "residual_portfolio_controller": (
                    "multi_target_residual_option_portfolio"
                ),
                "bin_role_automaton": (
                    "state_dependent_bin_role_automaton"
                ),
                "sparse_syndrome_repair": (
                    "failure_syndrome_sparse_repair"
                ),
            }[candidate.topology]
        )
    elif isinstance(candidate, MoonshotHybridProgram):
        residual = FunSearchResidualProgram(
            candidate.ancestry_expression,
            candidate.residual_scale,
        )
        labels.append(
            "sparse_%s_override" % candidate.moonshot.topology
        )
    elif isinstance(candidate, StructuralHybridProgram):
        labels.append(
            "regret_gated_%s_override"
            % candidate.moonshot.topology
        )
    elif isinstance(candidate, CalibratedOverrideHybridProgram):
        labels.append(
            "nested_holdout_trajectory_credit_episode_transport_override"
        )
    elif isinstance(candidate, CalibratedOverrideActionProgram):
        labels.append("counterfactual_action_value_ranker")
    elif isinstance(candidate, ActionHybridProgram):
        if _expression_exact_fill_localized(
            candidate.gated_expression,
            capacity,
        ):
            labels.append("exact_fill_only_score_adjustment")
    elif isinstance(candidate, ContextualLinearProgram):
        active = tuple(
            feature
            for feature, weight in zip(
                (
                    "bias",
                    "negative_remaining_after",
                    "exact_fill",
                    "near_fill",
                    "item",
                    "load",
                    "item_x_load",
                    "remaining_squared",
                    "is_new_bin",
                    "bin_index",
                    "open_bins",
                    "recent_mean",
                    "recent_std",
                    "recent_large_fraction",
                    "recent_trend",
                    "load_mean",
                    "load_std",
                    "remaining_x_recent_mean",
                    "remaining_x_recent_large_fraction",
                    "item_x_recent_mean",
                ),
                candidate.weights,
            )
            if abs(weight) > 1e-12
        )
        labels.append(
            "contextual_linear[%s]" % ",".join(active)
        )
    elif isinstance(candidate, DemandMemoryProgram):
        labels.append("history_derived_demand_profile_scoring")
    elif isinstance(candidate, RegimeRouterProgram):
        labels.append("state_conditioned_policy_hyperheuristic")

    if residual is not None:
        if _expression_exact_fill_localized(
            residual.expression,
            capacity,
        ):
            labels.append("exact_fill_tie_break_on_funsearch_plateau")
        else:
            labels.append("funsearch_residual_score_adjustment")
    return tuple(labels or ("unclassified_executable_policy",))


def assess_semantic_novelty(
    candidate: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
    *,
    capacity: int,
    maximum_equivalent_action_distance: float = 0.001,
    minimum_known_control_action_distance: float = 0.001,
) -> Mapping[str, Any]:
    if not 0.0 <= minimum_known_control_action_distance <= 1.0:
        raise ValueError("known-control action distance must be in [0, 1]")
    comparisons = {}
    known_matches = []
    candidate_fingerprint = behaviour_fingerprint(candidate, instances)
    for name, control in semantic_control_policies().items():
        outcome = compare_policy_outcomes(candidate, control, instances)
        actions = direct_action_comparison(candidate, control, instances)
        exact_trace_match = (
            candidate_fingerprint
            == behaviour_fingerprint(control, instances)
        )
        semantically_equivalent = (
            exact_trace_match
            or (
                outcome.aggregate_delta == 0
                and actions.disagreement_rate
                <= maximum_equivalent_action_distance
            )
        )
        comparisons[name] = {
            "outcome": outcome.as_dict(),
            "same_state_action_comparison": actions.as_dict(),
            "exact_trace_match": exact_trace_match,
            "semantically_equivalent": semantically_equivalent,
        }
        if semantically_equivalent:
            known_matches.append(name)

    labels = reduced_mechanism_labels(candidate, capacity)
    ablations = composite_ablations(candidate)
    exact_fill_only = (
        "exact_fill_tie_break_on_funsearch_plateau" in labels
        or "exact_fill_only_score_adjustment" in labels
    )
    failures = []
    if known_matches:
        failures.append("outcome_and_action_equivalent_to_known_policy")
    closest_control = min(
        comparisons,
        key=lambda name: comparisons[name][
            "same_state_action_comparison"
        ]["disagreement_rate"],
    )
    closest_control_distance = comparisons[closest_control][
        "same_state_action_comparison"
    ]["disagreement_rate"]
    if (
        not known_matches
        and closest_control_distance
        < minimum_known_control_action_distance
    ):
        failures.append("insufficient_action_distance_from_known_policy")
    if (
        exact_fill_only
        and (
            ablations is None
            or isinstance(candidate, FunSearchResidualProgram)
        )
    ):
        failures.append("reduced_mechanism_is_known_exact_fill_family")
    if (
        exact_fill_only
        and isinstance(candidate, ActionHybridProgram)
    ):
        failures.append("reduced_mechanism_is_known_exact_fill_family")
    if isinstance(candidate, GeneratedPolicyProgram):
        failures.append("generated_policy_lacks_precode_mechanism_contract")
        failures.append("generated_policy_lacks_candidate_specific_literature")
    if isinstance(candidate, GeneratedPolicyModuleProgram):
        fingerprint = candidate.mechanism_fingerprint
        if not candidate.candidate_literature_assessment_id:
            failures.append("generated_policy_lacks_candidate_specific_literature")
        canonical_mechanism = candidate.canonical_mechanism.as_dict()
    else:
        fingerprint = None
        canonical_mechanism = None

    if known_matches or "insufficient_action_distance_from_known_policy" in failures:
        prior_art_relation = "behavioral_duplicate_or_dominated_extension"
    elif fingerprint is not None and fingerprint.is_known_family:
        prior_art_relation = "known_family_with_distinct_executable_intervention"
    else:
        prior_art_relation = "no_close_registered_control"

    report = {
        "schema": 1,
        "validation_version": SCIENTIFIC_VALIDATION_VERSION,
        "candidate_id": _policy_id(candidate),
        "candidate_fingerprint": candidate_fingerprint,
        "reduced_mechanism_labels": list(labels),
        "known_family_matches": sorted(known_matches),
        "closest_known_control": closest_control,
        "closest_known_control_action_distance": closest_control_distance,
        "minimum_known_control_action_distance": (
            minimum_known_control_action_distance
        ),
        "canonical_executable_mechanism": canonical_mechanism,
        "prior_art_relation": prior_art_relation,
        "novelty_authority": "external_behavior_and_canonical_structure",
        "control_comparisons": dict(sorted(comparisons.items())),
        "maximum_equivalent_action_distance": (
            maximum_equivalent_action_distance
        ),
        "passed": not failures,
        "failure_reasons": sorted(set(failures)),
        "interpretation": (
            "candidate is distinct from registered semantic control families"
            if not failures
            else "candidate is behaviorally too close to a registered control "
            "or fails an executable novelty requirement"
        ),
    }
    return {
        **report,
        "assessment_id": content_digest(report),
    }


def assess_distinguishing_mechanism(
    candidate: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
) -> Mapping[str, Any]:
    """Run the compiled information ablation before episode-performance screens."""

    if not isinstance(candidate, GeneratedPolicyModuleProgram):
        report = {
            "schema": 1,
            "candidate_id": _policy_id(candidate),
            "applicable": False,
            "passed": False,
            "action_count": 0,
            "changed_actions": 0,
            "change_rate": 0.0,
            "failure_reasons": ["no_compiled_distinguishing_ablation"],
        }
        return {**report, "assessment_id": content_digest(report)}

    original_actions = []
    ablated_actions = []
    try:
        for instance in instances:
            original_loads = []
            ablated_loads = []
            history = []
            for item_index, item in enumerate(instance.items):
                original = candidate.choose_bin(
                    item,
                    tuple(original_loads),
                    instance.capacity,
                    item_index,
                    tuple(history),
                )
                ablated = candidate.choose_bin_ablated(
                    item,
                    tuple(ablated_loads),
                    instance.capacity,
                    item_index,
                    tuple(history),
                )
                original_actions.append(-1 if original is None else original)
                ablated_actions.append(-1 if ablated is None else ablated)
                if original is None:
                    original_loads.append(item)
                else:
                    original_loads[original] += item
                if ablated is None:
                    ablated_loads.append(item)
                else:
                    ablated_loads[ablated] += item
                history.append(item)
    except GeneratedPolicyRejected as error:
        report = {
            "schema": 1,
            "candidate_id": candidate.candidate_id,
            "hypothesis_id": candidate.hypothesis_id,
            "applicable": True,
            "distinguishing_prediction": candidate.distinguishing_prediction,
            "information_ablation": candidate.information_ablation,
            "mechanism_ablation": candidate.mechanism_ablation,
            "action_count": len(original_actions),
            "changed_actions": 0,
            "change_rate": 0.0,
            "mediator_activated": False,
            "passed": False,
            "failure_reasons": [
                "generated_policy_rejected_during_distinguishing_diagnostic"
            ],
            "runtime_rejection": str(error),
            "claim_authority": "diagnostic_only_not_episode_performance",
        }
        return {**report, "assessment_id": content_digest(report)}
    changed = sum(
        first != second
        for first, second in zip(original_actions, ablated_actions)
    )
    count = len(original_actions)
    failures = [] if changed else [
        "compiled_information_ablation_never_changes_an_action"
    ]
    report = {
        "schema": 1,
        "candidate_id": candidate.candidate_id,
        "hypothesis_id": candidate.hypothesis_id,
        "applicable": True,
        "distinguishing_prediction": candidate.distinguishing_prediction,
        "information_ablation": candidate.information_ablation,
        "mechanism_ablation": candidate.mechanism_ablation,
        "action_count": count,
        "changed_actions": changed,
        "change_rate": 0.0 if not count else changed / float(count),
        "mediator_activated": changed > 0,
        "passed": not failures,
        "failure_reasons": failures,
        "claim_authority": "diagnostic_only_not_episode_performance",
    }
    return {**report, "assessment_id": content_digest(report)}


def assess_host_baseline_authority(
    candidate: OnlineHeuristic,
    incumbent: OnlineHeuristic,
    instances: Sequence[BinPackingInstance],
) -> Mapping[str, Any]:
    """Verify ancestry abstention against the executable host baseline.

    The generated module never implements the fallback.  This diagnostic
    forces the host path at every visited state and separately measures how
    often the generated intervention retains causal authority.
    """

    applicable = (
        isinstance(candidate, GeneratedPolicyModuleProgram)
        and candidate.island_family == "ancestry"
    )
    if not applicable:
        report = {
            "schema": 1,
            "candidate_id": _policy_id(candidate),
            "applicable": False,
            "passed": True,
            "baseline_ref_matches": True,
            "decision_count": 0,
            "forced_fallback_mismatches": 0,
            "intervention_count": 0,
            "intervention_rate": 0.0,
            "failure_reasons": [],
        }
        return {**report, "assessment_id": content_digest(report)}

    decisions = 0
    interventions = 0
    mismatches = 0
    for instance in instances:
        loads = []
        history = []
        for item_index, item in enumerate(instance.items):
            loads_before = tuple(loads)
            history_before = tuple(history)
            expected = incumbent.choose_bin(
                item,
                loads_before,
                instance.capacity,
                item_index,
                history_before,
            )
            forced = candidate.choose_bin_fallback(
                item,
                loads_before,
                instance.capacity,
                item_index,
                history_before,
            )
            action, intervened = candidate.choose_bin_with_authority(
                item,
                loads_before,
                instance.capacity,
                item_index,
                history_before,
            )
            decisions += 1
            interventions += int(intervened)
            mismatches += int(forced != expected)
            if action is None:
                loads.append(item)
            else:
                loads[action] += item
            history.append(item)
    baseline_ref_matches = candidate.baseline_policy_ref == incumbent.name
    failures = []
    if not baseline_ref_matches:
        failures.append("ancestry_host_baseline_ref_mismatch")
    if mismatches:
        failures.append("ancestry_forced_fallback_differs_from_incumbent")
    report = {
        "schema": 1,
        "candidate_id": candidate.candidate_id,
        "applicable": True,
        "passed": not failures,
        "baseline_policy_ref": candidate.baseline_policy_ref,
        "incumbent_name": incumbent.name,
        "baseline_ref_matches": baseline_ref_matches,
        "decision_count": decisions,
        "forced_fallback_mismatches": mismatches,
        "intervention_count": interventions,
        "intervention_rate": (
            interventions / float(decisions) if decisions else 0.0
        ),
        "failure_reasons": failures,
        "claim_authority": "host_enforced_executable_fallback",
    }
    return {**report, "assessment_id": content_digest(report)}
