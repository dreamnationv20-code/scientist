from __future__ import annotations

from dataclasses import dataclass
import math
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import GeneratedPolicyModuleProgram
from scientist.domains.binpacking.heuristics import literature_heuristics, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.representation_capacity import (
    AdvantageTrainingExample,
    LinearAdvantageModel,
    RepresentationCorpus,
    RepresentationProbe,
    fit_linear_advantage_model,
    observable_action_features,
)
from scientist.domains.binpacking.terminal_intervention import (
    TerminalInterventionLabels,
    TerminalInterventionPolicy,
    _parse_action,
    _scored_action,
    _signature,
)
from scientist.program.discovery_evidence import paired_episode_evidence


SINGLE_INTERVENTION_VERSION = "de-novo-single-intervention-crossfit-v1"


@dataclass(frozen=True)
class SingleInterventionConfig:
    fold_count: int = 5
    threshold_quantiles: Tuple[float, ...] = (
        0.50,
        0.75,
        0.90,
        0.95,
        0.975,
    )
    fit_epochs: int = 42
    learning_rate: float = 0.0022
    ridge: float = 0.001
    informative_weight: float = 3.0
    maximum_regression: float = 1.0

    def __post_init__(self) -> None:
        if self.fold_count < 2:
            raise ValueError("single-intervention cross-fit needs at least two folds")
        if (
            not self.threshold_quantiles
            or len(set(self.threshold_quantiles)) != len(self.threshold_quantiles)
            or any(not 0.0 <= value < 1.0 for value in self.threshold_quantiles)
        ):
            raise ValueError("invalid single-intervention threshold quantiles")
        if (
            self.fit_epochs <= 0
            or self.learning_rate <= 0.0
            or self.ridge < 0.0
            or self.informative_weight <= 0.0
            or self.maximum_regression < 0.0
        ):
            raise ValueError("invalid single-intervention fitting controls")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": SINGLE_INTERVENTION_VERSION,
            "fold_count": self.fold_count,
            "threshold_quantiles": list(self.threshold_quantiles),
            "fit_epochs": self.fit_epochs,
            "learning_rate": self.learning_rate,
            "ridge": self.ridge,
            "informative_weight": self.informative_weight,
            "maximum_intervention_budget": 1,
            "maximum_regression": self.maximum_regression,
        }


def _examples(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    instance_ids: Sequence[str],
    *,
    include_candidate_representation: bool,
) -> Tuple[AdvantageTrainingExample, ...]:
    allowed = set(instance_ids)
    probe_by_id = {probe.probe_id: probe for probe in corpus.probes}
    rows = []
    for label in labels.split("development"):
        if label.instance_id not in allowed:
            continue
        probe = probe_by_id[label.probe_id]
        values = label.values
        incumbent_value = label.incumbent_terminal_bins
        informative = len(set(values.values())) > 1
        for action_ref, terminal_bins in label.action_terminal_bins:
            rows.append(
                AdvantageTrainingExample(
                    state_id=probe.probe_id,
                    instance_id=probe.instance_id,
                    action_ref=action_ref,
                    features=observable_action_features(
                        program,
                        probe,
                        action_ref,
                        include_candidate_representation=(
                            include_candidate_representation
                        ),
                    ),
                    advantage=float(incumbent_value - terminal_bins),
                    informative=informative,
                )
            )
    if not rows:
        raise ValueError("single-intervention fold contains no training examples")
    return tuple(rows)


def _stratified_folds(
    corpus: RepresentationCorpus,
    fold_count: int,
) -> Tuple[Tuple[str, ...], ...]:
    strata: Dict[Tuple[str, int], list[BinPackingInstance]] = {}
    for instance in corpus.split_instances("development"):
        strata.setdefault((instance.family, len(instance.items)), []).append(instance)
    folds: list[list[str]] = [[] for _ in range(fold_count)]
    for key in sorted(strata):
        selected = sorted(strata[key], key=lambda instance: instance.instance_id)
        if len(selected) < fold_count:
            raise ValueError(
                "each family-length stratum must cover every cross-fit fold"
            )
        for index, instance in enumerate(selected):
            folds[index % fold_count].append(instance.instance_id)
    result = tuple(tuple(sorted(fold)) for fold in folds)
    flattened = tuple(instance_id for fold in result for instance_id in fold)
    expected = tuple(
        instance.instance_id
        for instance in corpus.split_instances("development")
    )
    if len(flattened) != len(set(flattened)) or set(flattened) != set(expected):
        raise RuntimeError("cross-fit folds do not partition development episodes")
    return result


def _threshold(
    model: LinearAdvantageModel,
    program: GeneratedPolicyModuleProgram,
    probes: Sequence[RepresentationProbe],
    quantile: float,
    *,
    include_candidate_representation: bool,
) -> float:
    margins = sorted(
        margin
        for probe in probes
        for _, margin in (
            _scored_action(
                model,
                program,
                probe,
                include_candidate_representation=(
                    include_candidate_representation
                ),
            ),
        )
        if margin > 0.0
    )
    if not margins:
        return 0.0
    index = int(round(quantile * (len(margins) - 1)))
    return float(margins[index])


def evaluate_single_intervention_policy(
    instances: Sequence[BinPackingInstance],
    policy: TerminalInterventionPolicy,
) -> Mapping[str, Any]:
    incumbent = literature_heuristics()["funsearch_or_reference"]
    improvements = []
    intervention_counts = []
    incumbent_bin_counts = []
    candidate_bin_counts = []
    for instance in instances:
        incumbent_bins = pack(instance, incumbent).bin_count
        candidate_bins = pack(instance, policy).bin_count
        incumbent_bin_counts.append(incumbent_bins)
        candidate_bin_counts.append(candidate_bins)
        improvements.append(float(incumbent_bins - candidate_bins))
        intervention_counts.append(policy.interventions_used)
    evidence = paired_episode_evidence(
        improvements,
        tuple(instance.instance_id for instance in instances),
    )
    by_length: Dict[int, list[float]] = {}
    for instance, improvement in zip(instances, improvements):
        by_length.setdefault(len(instance.items), []).append(improvement)
    return {
        "evidence": evidence.as_dict(),
        "incumbent_mean_bins": mean(incumbent_bin_counts),
        "candidate_mean_bins": mean(candidate_bin_counts),
        "incumbent_bin_counts": incumbent_bin_counts,
        "candidate_bin_counts": candidate_bin_counts,
        "aggregate_interventions": sum(intervention_counts),
        "mean_interventions_per_episode": mean(intervention_counts),
        "maximum_interventions_in_episode": max(intervention_counts),
        "aggregate_improvement_by_length": {
            str(length): sum(values)
            for length, values in sorted(by_length.items())
        },
        "mean_improvement_by_length": {
            str(length): mean(values)
            for length, values in sorted(by_length.items())
        },
    }


def _fit_model(
    examples: Sequence[AdvantageTrainingExample],
    config: SingleInterventionConfig,
    seed: int,
) -> LinearAdvantageModel:
    return fit_linear_advantage_model(
        examples,
        seed=seed,
        epochs=config.fit_epochs,
        learning_rate=config.learning_rate,
        ridge=config.ridge,
        informative_weight=config.informative_weight,
    )


def _crossfit_mode(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: SingleInterventionConfig,
    *,
    include_candidate_representation: bool,
    seed: int,
) -> Tuple[TerminalInterventionPolicy, Mapping[str, Any]]:
    folds = _stratified_folds(corpus, config.fold_count)
    development_instances = corpus.split_instances("development")
    instance_by_id = {
        instance.instance_id: instance for instance in development_instances
    }
    probes = corpus.split("development")
    all_ids = set(instance_by_id)
    candidates: Tuple[Optional[float], ...] = (
        None,
        *config.threshold_quantiles,
    )
    results: Dict[Optional[float], list[Mapping[str, Any]]] = {
        value: [] for value in candidates
    }
    fold_models = []
    mode = "representation" if include_candidate_representation else "generic"

    for fold_index, holdout_ids in enumerate(folds):
        holdout = tuple(instance_by_id[value] for value in holdout_ids)
        training_ids = tuple(sorted(all_ids.difference(holdout_ids)))
        examples = _examples(
            program,
            corpus,
            labels,
            training_ids,
            include_candidate_representation=include_candidate_representation,
        )
        model = _fit_model(examples, config, seed + fold_index)
        training_probes = tuple(
            probe for probe in probes if probe.instance_id in set(training_ids)
        )
        fold_models.append(
            {
                "fold_index": fold_index,
                "holdout_instance_ids": list(holdout_ids),
                "training_instance_count": len(training_ids),
                "training_example_count": len(examples),
                "model_id": model.as_dict()["model_id"],
            }
        )
        for quantile in candidates:
            threshold = (
                0.0
                if quantile is None
                else _threshold(
                    model,
                    program,
                    training_probes,
                    quantile,
                    include_candidate_representation=(
                        include_candidate_representation
                    ),
                )
            )
            policy = TerminalInterventionPolicy(
                program=program,
                model=model,
                include_candidate_representation=(
                    include_candidate_representation
                ),
                threshold=threshold,
                maximum_interventions=0 if quantile is None else 1,
                cooldown=0,
                minimum_item_index=corpus.config.minimum_history_items,
                name="single_crossfit_%s_fold%d" % (mode, fold_index),
            )
            audit = evaluate_single_intervention_policy(holdout, policy)
            results[quantile].append(
                {
                    "fold_index": fold_index,
                    "threshold": threshold,
                    "audit": audit,
                }
            )

    attempts = []
    eligible_attempts = []
    for quantile in candidates:
        fold_results = results[quantile]
        improvements_by_id: Dict[str, float] = {}
        interventions = 0
        for fold, fold_result in zip(folds, fold_results):
            fold_improvements = fold_result["audit"]["evidence"]["improvements"]
            improvements_by_id.update(zip(fold, fold_improvements))
            interventions += fold_result["audit"]["aggregate_interventions"]
        ordered_improvements = tuple(
            improvements_by_id[instance.instance_id]
            for instance in development_instances
        )
        evidence = paired_episode_evidence(
            ordered_improvements,
            tuple(instance.instance_id for instance in development_instances),
        )
        by_length: Dict[int, list[float]] = {}
        for instance, improvement in zip(
            development_instances, ordered_improvements
        ):
            by_length.setdefault(len(instance.items), []).append(improvement)
        length_aggregates = {
            str(length): sum(values)
            for length, values in sorted(by_length.items())
        }
        fold_aggregates = tuple(
            result["audit"]["evidence"]["aggregate_improvement"]
            for result in fold_results
        )
        eligible = bool(
            quantile is not None
            and evidence.aggregate_improvement > 0.0
            and evidence.wins > evidence.losses
            and min(fold_aggregates) >= 0.0
            and min(length_aggregates.values()) >= 0.0
        )
        rank = (
            min(length_aggregates.values()),
            min(fold_aggregates),
            evidence.aggregate_improvement,
            evidence.wins - evidence.losses,
            -interventions,
            quantile if quantile is not None else -1.0,
        )
        attempt = {
            "threshold_quantile": quantile,
            "eligible": eligible,
            "pooled_evidence": evidence.as_dict(),
            "fold_aggregates": list(fold_aggregates),
            "aggregate_improvement_by_length": length_aggregates,
            "aggregate_interventions": interventions,
            "fold_results": fold_results,
            "selection_rank": list(rank),
        }
        attempts.append(attempt)
        if eligible:
            eligible_attempts.append((rank, attempt))

    selected = (
        max(eligible_attempts, key=lambda item: item[0])[1]
        if eligible_attempts
        else attempts[0]
    )
    all_examples = _examples(
        program,
        corpus,
        labels,
        tuple(instance_by_id),
        include_candidate_representation=include_candidate_representation,
    )
    final_model = _fit_model(
        all_examples,
        config,
        seed + config.fold_count + 10_000,
    )
    selected_quantile = selected["threshold_quantile"]
    final_threshold = (
        0.0
        if selected_quantile is None
        else _threshold(
            final_model,
            program,
            probes,
            selected_quantile,
            include_candidate_representation=include_candidate_representation,
        )
    )
    policy = TerminalInterventionPolicy(
        program=program,
        model=final_model,
        include_candidate_representation=include_candidate_representation,
        threshold=final_threshold,
        maximum_interventions=0 if selected_quantile is None else 1,
        cooldown=0,
        minimum_item_index=corpus.config.minimum_history_items,
        name="single_terminal_%s_%s" % (program.hypothesis_id[:8], mode),
    )
    return policy, {
        "mode": mode,
        "fold_count": config.fold_count,
        "folds": fold_models,
        "attempts": attempts,
        "selected_crossfit_attempt": selected,
        "crossfit_eligible": selected["eligible"],
        "final_training_instance_count": len(instance_by_id),
        "final_training_example_count": len(all_examples),
        "selected_policy": policy.as_dict(),
    }


def _paired_policy_difference(
    instances: Sequence[BinPackingInstance],
    left: Mapping[str, Any],
    right: Mapping[str, Any],
) -> Mapping[str, Any]:
    differences = tuple(
        float(left_value - right_value)
        for left_value, right_value in zip(
            left["evidence"]["improvements"],
            right["evidence"]["improvements"],
        )
    )
    return paired_episode_evidence(
        differences,
        tuple(instance.instance_id for instance in instances),
    ).as_dict()


@dataclass(frozen=True)
class SingleInterventionResult:
    report: Mapping[str, Any]
    generic_policy: TerminalInterventionPolicy
    representation_policy: TerminalInterventionPolicy

    @property
    def promoted(self) -> bool:
        return bool(self.report["promotion_gate"]["passed"])


def assess_single_intervention(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: SingleInterventionConfig = SingleInterventionConfig(),
) -> SingleInterventionResult:
    """Cross-fit a label-aligned one-intervention policy before sealed access."""

    if "sealed_audit" in labels.report.get("labeled_splits", ()):
        raise ValueError("single-intervention selection forbids materialized sealed labels")
    required = {"development"}
    if not required.issubset(labels.report.get("labeled_splits", ())):
        raise ValueError("single-intervention selection labels are incomplete")
    generic_policy, generic_crossfit = _crossfit_mode(
        program,
        corpus,
        labels,
        config,
        include_candidate_representation=False,
        seed=corpus.config.base_seed + 141_000,
    )
    representation_policy, representation_crossfit = _crossfit_mode(
        program,
        corpus,
        labels,
        config,
        include_candidate_representation=True,
        seed=corpus.config.base_seed + 167_000,
    )
    validation_instances = corpus.split_instances("adaptive_validation")
    generic_validation = evaluate_single_intervention_policy(
        validation_instances, generic_policy
    )
    representation_validation = evaluate_single_intervention_policy(
        validation_instances, representation_policy
    )
    representation_minus_generic = _paired_policy_difference(
        validation_instances,
        representation_validation,
        generic_validation,
    )
    evidence = representation_validation["evidence"]
    reasons = []
    if not representation_crossfit["crossfit_eligible"]:
        reasons.append("candidate_representation_not_stable_across_crossfit_folds")
    if evidence["mean_improvement_ci_lower"] <= 0.0:
        reasons.append("validation_improvement_confidence_interval_includes_zero")
    if evidence["aggregate_improvement"] <= 0.0:
        reasons.append("validation_aggregate_improvement_not_positive")
    if min(
        representation_validation["aggregate_improvement_by_length"].values()
    ) < 0.0:
        reasons.append("at_least_one_validation_length_regressed")
    if representation_minus_generic["mean_improvement_ci_lower"] <= 0.0:
        reasons.append("representation_gain_over_generic_not_established")
    if evidence["maximum_regression"] > config.maximum_regression:
        reasons.append("maximum_episode_regression_exceeds_limit")
    promotion = {
        "passed": not reasons,
        "reasons": reasons,
        "criteria": {
            "crossfit_stable_across_all_folds_and_lengths": True,
            "validation_positive_95_percent_lower_ci": True,
            "validation_positive_aggregate": True,
            "every_validation_length_nonnegative": True,
            "representation_gain_over_generic_positive_95_percent_lower_ci": True,
            "maximum_episode_regression": config.maximum_regression,
        },
    }
    report: Dict[str, Any] = {
        "schema": 1,
        "version": SINGLE_INTERVENTION_VERSION,
        "candidate_id": program.candidate_id,
        "hypothesis_id": program.hypothesis_id,
        "corpus_id": corpus.report["corpus_id"],
        "terminal_label_set_id": labels.report["label_set_id"],
        "config": config.as_dict(),
        "credit_deployment_alignment": {
            "label_interventions": 1,
            "maximum_deployed_interventions": 1,
            "aligned": True,
        },
        "selection_unit": "independent_complete_episode",
        "sealed_labels_materialized": False,
        "sealed_episodes_accessed": False,
        "generic_crossfit": generic_crossfit,
        "candidate_representation_crossfit": representation_crossfit,
        "adaptive_validation": {
            "generic": generic_validation,
            "candidate_representation": representation_validation,
            "candidate_minus_generic": representation_minus_generic,
        },
        "promotion_gate": promotion,
    }
    report["assessment_id"] = content_digest(report)
    return SingleInterventionResult(
        report=report,
        generic_policy=generic_policy,
        representation_policy=representation_policy,
    )


def _correlation(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right) or not left:
        raise ValueError("diagnostic correlation dimensions do not match")
    left_mean = mean(left)
    right_mean = mean(right)
    numerator = sum(
        (x - left_mean) * (y - right_mean) for x, y in zip(left, right)
    )
    left_scale = math.sqrt(sum((value - left_mean) ** 2 for value in left))
    right_scale = math.sqrt(sum((value - right_mean) ** 2 for value in right))
    if left_scale == 0.0 or right_scale == 0.0:
        return 0.0
    return numerator / (left_scale * right_scale)


def _episode_strategy_summary(
    instances: Sequence[BinPackingInstance],
    improvements: Mapping[str, float],
) -> Mapping[str, Any]:
    ordered = tuple(float(improvements[instance.instance_id]) for instance in instances)
    evidence = paired_episode_evidence(
        ordered,
        tuple(instance.instance_id for instance in instances),
    )
    by_length: Dict[int, list[float]] = {}
    for instance, improvement in zip(instances, ordered):
        by_length.setdefault(len(instance.items), []).append(improvement)
    return {
        "evidence": evidence.as_dict(),
        "aggregate_improvement_by_length": {
            str(length): sum(values)
            for length, values in sorted(by_length.items())
        },
        "mean_improvement_by_length": {
            str(length): mean(values)
            for length, values in sorted(by_length.items())
        },
    }


def _diagnose_mode(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: SingleInterventionConfig,
    *,
    include_candidate_representation: bool,
    seed: int,
) -> Mapping[str, Any]:
    folds = _stratified_folds(corpus, config.fold_count)
    development_instances = corpus.split_instances("development")
    instance_by_id = {
        instance.instance_id: instance for instance in development_instances
    }
    all_ids = set(instance_by_id)
    label_by_probe = {
        label.probe_id: label for label in labels.split("development")
    }
    probes = corpus.split("development")
    probe_rows = []
    fold_reports = []
    mode = "representation" if include_candidate_representation else "generic"
    quantile_keys = {
        quantile: "q%.3f" % quantile for quantile in config.threshold_quantiles
    }

    for fold_index, holdout_ids in enumerate(folds):
        holdout_set = set(holdout_ids)
        training_ids = tuple(sorted(all_ids.difference(holdout_set)))
        examples = _examples(
            program,
            corpus,
            labels,
            training_ids,
            include_candidate_representation=include_candidate_representation,
        )
        model = _fit_model(examples, config, seed + fold_index)
        training_set = set(training_ids)
        training_probes = tuple(
            probe for probe in probes if probe.instance_id in training_set
        )
        thresholds = {
            quantile_keys[quantile]: _threshold(
                model,
                program,
                training_probes,
                quantile,
                include_candidate_representation=(
                    include_candidate_representation
                ),
            )
            for quantile in config.threshold_quantiles
        }
        fold_reports.append(
            {
                "fold_index": fold_index,
                "holdout_instance_ids": list(holdout_ids),
                "model_id": model.as_dict()["model_id"],
                "thresholds": thresholds,
            }
        )
        for probe in probes:
            if probe.instance_id not in holdout_set:
                continue
            label = label_by_probe[probe.probe_id]
            selected_ref, margin = _scored_action(
                model,
                program,
                probe,
                include_candidate_representation=(
                    include_candidate_representation
                ),
            )
            values = label.values
            advantage = float(
                label.incumbent_terminal_bins - values[selected_ref]
            )
            changes_successor = bool(
                _signature(
                    _parse_action(selected_ref),
                    probe.item,
                    probe.loads,
                    probe.capacity,
                )
                != _signature(
                    _parse_action(probe.incumbent_action_ref),
                    probe.item,
                    probe.loads,
                    probe.capacity,
                )
            )
            effective_margin = float(margin if changes_successor else 0.0)
            probe_rows.append(
                {
                    "probe_id": probe.probe_id,
                    "instance_id": probe.instance_id,
                    "family": probe.family,
                    "item_index": probe.item_index,
                    "sequence_length": len(instance_by_id[probe.instance_id].items),
                    "fold_index": fold_index,
                    "selected_action_ref": selected_ref,
                    "incumbent_action_ref": probe.incumbent_action_ref,
                    "changes_successor": changes_successor,
                    "predicted_margin": float(margin),
                    "effective_margin": effective_margin,
                    "selected_terminal_advantage": advantage,
                    "oracle_terminal_advantage": float(label.best_advantage),
                    "crosses_threshold": {
                        key: bool(effective_margin > threshold)
                        for key, threshold in thresholds.items()
                    },
                }
            )

    if len(probe_rows) != len(probes):
        raise RuntimeError("cross-fit diagnostic did not score every development probe")
    opportunities = [row for row in probe_rows if row["oracle_terminal_advantage"] > 0.0]
    helpful = [row for row in probe_rows if row["selected_terminal_advantage"] > 0.0]
    harmful = [row for row in probe_rows if row["selected_terminal_advantage"] < 0.0]
    helpful_opportunities = [
        row for row in opportunities if row["selected_terminal_advantage"] > 0.0
    ]
    exact_oracle = [
        row
        for row in opportunities
        if row["selected_terminal_advantage"] == row["oracle_terminal_advantage"]
    ]
    rows_by_instance: Dict[str, list[Mapping[str, Any]]] = {}
    for row in probe_rows:
        rows_by_instance.setdefault(str(row["instance_id"]), []).append(row)

    model_realizable = {}
    oracle_realizable = {}
    timing_reports = {}
    for instance in development_instances:
        rows = sorted(
            rows_by_instance[instance.instance_id],
            key=lambda row: int(row["item_index"]),
        )
        model_realizable[instance.instance_id] = max(
            0.0,
            *(float(row["selected_terminal_advantage"]) for row in rows),
        )
        oracle_realizable[instance.instance_id] = max(
            0.0,
            *(float(row["oracle_terminal_advantage"]) for row in rows),
        )
    for quantile, key in quantile_keys.items():
        first_crossing = {}
        offline_highest_margin = {}
        crossing_rows = []
        for instance in development_instances:
            rows = sorted(
                rows_by_instance[instance.instance_id],
                key=lambda row: int(row["item_index"]),
            )
            crossed = [row for row in rows if row["crosses_threshold"][key]]
            crossing_rows.extend(crossed)
            first_crossing[instance.instance_id] = (
                0.0
                if not crossed
                else float(crossed[0]["selected_terminal_advantage"])
            )
            offline_highest_margin[instance.instance_id] = (
                0.0
                if not crossed
                else float(
                    max(
                        crossed,
                        key=lambda row: float(row["effective_margin"]),
                    )["selected_terminal_advantage"]
                )
            )
        timing_reports[key] = {
            "threshold_quantile": quantile,
            "crossing_probe_count": len(crossing_rows),
            "crossing_helpful_count": sum(
                row["selected_terminal_advantage"] > 0.0
                for row in crossing_rows
            ),
            "crossing_harmful_count": sum(
                row["selected_terminal_advantage"] < 0.0
                for row in crossing_rows
            ),
            "crossing_tie_count": sum(
                row["selected_terminal_advantage"] == 0.0
                for row in crossing_rows
            ),
            "first_scheduled_crossing": _episode_strategy_summary(
                development_instances, first_crossing
            ),
            "offline_highest_margin_crossing": _episode_strategy_summary(
                development_instances, offline_highest_margin
            ),
        }

    summary: Dict[str, Any] = {
        "mode": mode,
        "fold_count": config.fold_count,
        "folds": fold_reports,
        "probe_count": len(probe_rows),
        "terminal_opportunity_probe_count": len(opportunities),
        "selected_helpful_probe_count": len(helpful),
        "selected_harmful_probe_count": len(harmful),
        "selected_tie_probe_count": len(probe_rows) - len(helpful) - len(harmful),
        "helpful_action_recall_on_opportunity_probes": (
            len(helpful_opportunities) / float(max(1, len(opportunities)))
        ),
        "exact_oracle_action_rate_on_opportunity_probes": (
            len(exact_oracle) / float(max(1, len(opportunities)))
        ),
        "margin_terminal_advantage_correlation": _correlation(
            tuple(float(row["effective_margin"]) for row in probe_rows),
            tuple(float(row["selected_terminal_advantage"]) for row in probe_rows),
        ),
        "model_action_oracle_timing_upper_bound": _episode_strategy_summary(
            development_instances, model_realizable
        ),
        "full_action_and_timing_oracle_upper_bound": _episode_strategy_summary(
            development_instances, oracle_realizable
        ),
        "timing_by_threshold": timing_reports,
        "decision_rows_are_independent_evidence": False,
        "episode_is_unit_of_independence": True,
        "probe_rows": probe_rows,
    }
    summary["diagnostic_id"] = content_digest(summary)
    return summary


def diagnose_single_intervention(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: SingleInterventionConfig = SingleInterventionConfig(),
) -> Mapping[str, Any]:
    """Separate held-out action ranking from intervention-timing quality."""

    if set(labels.report.get("labeled_splits", ())) != {"development"}:
        raise ValueError("diagnostic accepts development terminal labels only")
    generic = _diagnose_mode(
        program,
        corpus,
        labels,
        config,
        include_candidate_representation=False,
        seed=corpus.config.base_seed + 141_000,
    )
    representation = _diagnose_mode(
        program,
        corpus,
        labels,
        config,
        include_candidate_representation=True,
        seed=corpus.config.base_seed + 167_000,
    )
    report: Dict[str, Any] = {
        "schema": 1,
        "version": SINGLE_INTERVENTION_VERSION,
        "diagnostic": "crossfit_action_ranking_versus_intervention_timing",
        "candidate_id": program.candidate_id,
        "hypothesis_id": program.hypothesis_id,
        "corpus_id": corpus.report["corpus_id"],
        "terminal_label_set_id": labels.report["label_set_id"],
        "sealed_labels_materialized": False,
        "sealed_episodes_accessed": False,
        "generic": generic,
        "candidate_representation": representation,
    }
    report["diagnostic_id"] = content_digest(report)
    return report
