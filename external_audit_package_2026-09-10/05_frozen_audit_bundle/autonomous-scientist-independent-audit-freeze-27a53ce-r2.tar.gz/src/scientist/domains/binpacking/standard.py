from __future__ import annotations

from scientist.domains.binpacking.adapter import BinPackingAdapter
from scientist.kernel.contracts import (
    AnalysisKind,
    BudgetContract,
    CampaignContract,
    EvidenceAnalysisContract,
    EvidencePartition,
    GateContract,
    GateCriterion,
    GateKind,
    MetricDirection,
    MetricSpec,
    ProblemCharter,
    SearchFamily,
)


def problem_charter() -> ProblemCharter:
    return ProblemCharter(
        name="Online one-dimensional bin-packing repair",
        statement=(
            "Find an online policy that uses fewer bins than the confirmed "
            "exact-fill FunSearch variant under a declared sequence "
            "distribution without reordering future items."
        ),
        domain_id=BinPackingAdapter.domain_id,
        scope=(
            "one-dimensional integer item sizes",
            "online irrevocable placement",
            "declared capacity and sequence distribution",
            "paired comparison with an executable incumbent",
        ),
        anti_scope=(
            "offline item reordering",
            "multi-dimensional packing",
            "claims of global optimality",
            "transfer beyond tested distributions and scales",
        ),
        metrics=(
            MetricSpec(
                name="improvement",
                direction=MetricDirection.MAXIMIZE,
                unit="bins saved",
                aggregation="paired mean with confidence interval",
                primary=True,
            ),
            MetricSpec(
                name="primary_delta",
                direction=MetricDirection.MINIMIZE,
                unit="bins",
                aggregation="paired sum candidate minus incumbent",
            ),
            MetricSpec(
                name="maximum_regression",
                direction=MetricDirection.MINIMIZE,
                unit="bins",
                aggregation="maximum paired instance delta",
            ),
        ),
        success_definition=(
            "A frozen candidate has negative aggregate paired bin delta on "
            "independent replication and satisfies the declared regression "
            "contract."
        ),
        falsification_conditions=(
            "replication aggregate delta is non-negative",
            "the improvement depends on benchmark exposure during search",
            "the independent verifier rejects any packing",
        ),
        risk_tier="research_only",
    )


def campaign_contract(
    incumbent_candidate_id: str,
) -> CampaignContract:
    adapter = BinPackingAdapter()
    charter = problem_charter()
    return CampaignContract(
        charter_id=charter.charter_id,
        domain_adapter_ref=adapter.adapter_version,
        incumbent_candidate_id=incumbent_candidate_id,
        search_families=(
            SearchFamily.ANCESTRY,
            SearchFamily.DE_NOVO,
            SearchFamily.HYBRID,
        ),
        budget=BudgetContract(
            outer_rounds=6,
            proposals_per_family_per_round=40,
            failure_mining_evaluations_per_round=80,
            audit_cases_per_proposal=24,
            replication_cases=600,
        ),
        evaluator_ref=adapter.evaluator_ref,
        verifier_ref=adapter.verifier_ref,
        development_partitions=(
            EvidencePartition.DEVELOPMENT,
            EvidencePartition.GUARD,
        ),
        gates=(
            GateContract(
                kind=GateKind.DEPLOYMENT,
                evidence_partition=EvidencePartition.AUDIT,
                criteria=(
                    GateCriterion(
                        metric="maximum_regression",
                        operator="<=",
                        threshold=0.0,
                        description=(
                            "automatic deployment has no audit regression"
                        ),
                    ),
                    GateCriterion(
                        metric="primary_delta",
                        operator="<",
                        threshold=0.0,
                        description=(
                            "automatic deployment improves aggregate bins"
                        ),
                    ),
                ),
                minimum_evidence_count=24,
            ),
            GateContract(
                kind=GateKind.REPLICATION_NOMINATION,
                evidence_partition=EvidencePartition.AUDIT,
                criteria=(
                    GateCriterion(
                        metric="primary_delta",
                        operator="<",
                        threshold=0.0,
                        description="audit has a directional improvement",
                    ),
                    GateCriterion(
                        metric="wins",
                        operator=">=",
                        threshold=2.0,
                        description="improvement is not a single audit case",
                    ),
                    GateCriterion(
                        metric="maximum_regression",
                        operator="<=",
                        threshold=1.0,
                        description=(
                            "directional nomination tolerates at most one "
                            "extra bin on an instance"
                        ),
                    ),
                ),
                minimum_evidence_count=24,
            ),
            GateContract(
                kind=GateKind.INCUMBENT_ADVANCE,
                evidence_partition=EvidencePartition.REPLICATION,
                criteria=(
                    GateCriterion(
                        metric="primary_delta",
                        operator="<",
                        threshold=0.0,
                        description=(
                            "frozen replication improves aggregate bins"
                        ),
                    ),
                    GateCriterion(
                        metric="batch_win_rate",
                        operator=">",
                        threshold=0.5,
                        description=(
                            "the effect transfers across replication batches"
                        ),
                    ),
                ),
                minimum_evidence_count=600,
            ),
        ),
        evidence_analysis=EvidenceAnalysisContract(
            analysis_kind=AnalysisKind.PAIRED_MEAN_CONFIDENCE,
            primary_metric="improvement",
            independent_unit="complete item-sequence episode",
            group_keys=("instance_id",),
            analyzer_ref="binpacking-paired-episode-evidence-v1",
            minimum_independent_units=24,
            confidence_level=0.95,
        ),
        plateau_window=2,
    )
