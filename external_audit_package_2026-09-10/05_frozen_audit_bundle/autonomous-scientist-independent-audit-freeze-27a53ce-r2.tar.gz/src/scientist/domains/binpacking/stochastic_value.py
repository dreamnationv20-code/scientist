from __future__ import annotations

import math
import random
from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.program.discovery_evidence import (
    DiscoveryQualification,
    paired_episode_evidence,
    qualify_discovery,
)


STOCHASTIC_VALUE_VERSION = (
    "iid-or-suffix-state-action-value-v2-common-random-numbers"
)
VALUE_FEATURES = (
    "bias",
    "item",
    "remaining_after",
    "fill_after",
    "is_new_bin",
    "bin_index",
    "open_bin_count",
    "mean_load",
    "load_spread",
    "mean_residual",
    "residual_spread",
    "history_mean",
    "history_spread",
    "item_minus_history_mean",
    "exact_fill",
    "near_fill",
    "small_residual",
    "complement_frequency",
    "fragmentation",
    "progress",
    "remaining_squared",
    "item_x_remaining",
    "item_x_fill",
    "new_x_item",
    "remaining_x_complement_frequency",
    "remaining_x_fragmentation",
    "load_spread_x_remaining",
    "history_deviation_x_remaining",
)


@dataclass(frozen=True)
class StochasticValueConfig:
    capacity: int = 150
    item_low: int = 20
    item_high: int = 100
    training_lengths: Tuple[int, ...] = (120, 250, 500)
    training_episodes_per_length: int = 400
    # One state per independently seeded episode prevents correlated decision
    # rows from masquerading as additional evidence. Three actions retain the
    # ancestry action plus two counterfactual alternatives.
    states_per_episode: int = 1
    actions_per_state: int = 3
    suffix_samples_per_action: int = 32
    grouped_cv_folds: int = 5
    validation_episodes_per_length: int = 200
    replication_episodes_per_length: int = 400
    base_seed: int = 74_120_026
    fit_epochs: int = 30
    learning_rate: float = 0.02
    ridge: float = 0.0001

    def __post_init__(self) -> None:
        if self.capacity <= 0 or not 0 < self.item_low <= self.item_high:
            raise ValueError("invalid i.i.d. OR distribution")
        if self.item_high > self.capacity:
            raise ValueError("i.i.d. OR items must fit an empty bin")
        if not self.training_lengths or min(self.training_lengths) <= 1:
            raise ValueError("training lengths must exceed one")
        counts = (
            self.training_episodes_per_length,
            self.states_per_episode,
            self.actions_per_state,
            self.suffix_samples_per_action,
            self.grouped_cv_folds,
            self.validation_episodes_per_length,
            self.replication_episodes_per_length,
            self.fit_epochs,
        )
        if min(counts) <= 0:
            raise ValueError("stochastic-value counts must be positive")
        if self.training_episode_count < self.grouped_cv_folds * 2:
            raise ValueError("too few independent episodes for grouped CV")
        if self.validation_episode_count < 2:
            raise ValueError("episode advantage gate requires two episodes")
        if self.learning_rate <= 0.0 or self.ridge < 0.0:
            raise ValueError("invalid value-model optimization parameters")

    @property
    def training_episode_count(self) -> int:
        return len(self.training_lengths) * self.training_episodes_per_length

    @property
    def validation_episode_count(self) -> int:
        return len(self.training_lengths) * self.validation_episodes_per_length

    @property
    def replication_episode_count(self) -> int:
        return len(self.training_lengths) * self.replication_episodes_per_length

    @property
    def production_evidence_contract_passed(self) -> bool:
        return (
            self.training_episode_count >= 1_000
            and self.validation_episode_count >= 500
            and self.replication_episode_count >= 1_000
            and self.suffix_samples_per_action >= 32
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": STOCHASTIC_VALUE_VERSION,
            "distribution": {
                "kind": "iid_discrete_uniform",
                "item_low_inclusive": self.item_low,
                "item_high_inclusive": self.item_high,
                "capacity": self.capacity,
            },
            "training_lengths": list(self.training_lengths),
            "training_episodes_per_length": self.training_episodes_per_length,
            "training_episode_count": self.training_episode_count,
            "states_per_episode": self.states_per_episode,
            "actions_per_state": self.actions_per_state,
            "suffix_samples_per_action": self.suffix_samples_per_action,
            "grouped_cv_folds": self.grouped_cv_folds,
            "validation_episodes_per_length": self.validation_episodes_per_length,
            "validation_episode_count": self.validation_episode_count,
            "replication_episodes_per_length": self.replication_episodes_per_length,
            "replication_episode_count": self.replication_episode_count,
            "base_seed": self.base_seed,
            "fit_epochs": self.fit_epochs,
            "learning_rate": self.learning_rate,
            "ridge": self.ridge,
            "production_evidence_contract_passed": (
                self.production_evidence_contract_passed
            ),
            "independence_unit": "episode_seed_and_length",
            "common_random_numbers_across_actions": True,
        }


@dataclass(frozen=True)
class CounterfactualValueRow:
    episode_id: str
    state_id: str
    features: Tuple[float, ...]
    advantage: float
    action_ref: str
    ancestry_action_ref: str


@dataclass(frozen=True)
class LinearValueModel:
    feature_names: Tuple[str, ...]
    centers: Tuple[float, ...]
    scales: Tuple[float, ...]
    weights: Tuple[float, ...]

    def predict(self, features: Sequence[float]) -> float:
        if len(features) != len(self.weights):
            raise ValueError("value features do not match trained model")
        return sum(
            weight * ((float(value) - center) / scale)
            for weight, value, center, scale in zip(
                self.weights,
                features,
                self.centers,
                self.scales,
            )
        )

    @property
    def model_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "feature_names": list(self.feature_names),
            "centers": list(self.centers),
            "scales": list(self.scales),
            "weights": list(self.weights),
        }
        if include_id:
            value["model_id"] = self.model_id
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "LinearValueModel":
        model = cls(
            feature_names=tuple(str(item) for item in value["feature_names"]),
            centers=tuple(float(item) for item in value["centers"]),
            scales=tuple(float(item) for item in value["scales"]),
            weights=tuple(float(item) for item in value["weights"]),
        )
        supplied_id = value.get("model_id")
        if supplied_id is not None and supplied_id != model.model_id:
            raise ValueError("stochastic value-model identity mismatch")
        return model


@dataclass(frozen=True)
class DistilledStochasticValuePolicy:
    value_model: LinearValueModel
    name: str = "iid_or_distilled_state_action_value"

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "version": STOCHASTIC_VALUE_VERSION,
                "value_model": self.value_model.as_dict(),
            }
        )

    @property
    def complexity(self) -> int:
        return len(self.value_model.weights)

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        actions = _candidate_actions(item, loads, capacity, limit=None)
        scored = []
        for order, action in enumerate(actions):
            features = _action_features(
                item,
                loads,
                capacity,
                item_index,
                history,
                action,
                max(item_index + 1, len(history) + 1),
            )
            scored.append((self.value_model.predict(features), -order, action))
        return max(scored, key=lambda item: (item[0], item[1]))[2]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "distilled_stochastic_value_policy",
            "version": STOCHASTIC_VALUE_VERSION,
            "candidate_id": self.candidate_id,
            "name": self.name,
            "complexity": self.complexity,
            "value_model": self.value_model.as_dict(),
            "distribution": "iid discrete uniform OR(20..100, capacity 150)",
        }


@dataclass(frozen=True)
class StochasticValueTrainingResult:
    config: StochasticValueConfig
    value_model: LinearValueModel
    cross_validation: Mapping[str, Any]
    episode_advantage_gate: DiscoveryQualification
    distilled_policy: Optional[DistilledStochasticValuePolicy]
    replication_manifest: Mapping[str, Any]
    training_row_count: int

    @property
    def passed(self) -> bool:
        return self.distilled_policy is not None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": STOCHASTIC_VALUE_VERSION,
            "config": self.config.as_dict(),
            "training_row_count": self.training_row_count,
            "decision_rows_are_independent_evidence": False,
            "value_model": self.value_model.as_dict(),
            "grouped_cross_validation": dict(self.cross_validation),
            "episode_advantage_gate": self.episode_advantage_gate.as_dict(),
            "distillation_permitted": self.passed,
            "distilled_policy": (
                None
                if self.distilled_policy is None
                else self.distilled_policy.as_dict()
            ),
            "untouched_replication_manifest": dict(self.replication_manifest),
        }


def _iid_episode(config: StochasticValueConfig, length: int, seed: int) -> Tuple[int, ...]:
    rng = random.Random(seed)
    return tuple(
        rng.randint(config.item_low, config.item_high) for _ in range(length)
    )


def _spread(values: Sequence[float]) -> float:
    if not values:
        return 0.0
    center = mean(values)
    return math.sqrt(mean((value - center) ** 2 for value in values))


def _action_ref(action: Optional[int]) -> str:
    return "new" if action is None else "bin:%d" % action


def _candidate_actions(
    item: int,
    loads: Sequence[int],
    capacity: int,
    limit: Optional[int],
) -> Tuple[Optional[int], ...]:
    feasible = tuple(
        index
        for index, load in enumerate(loads)
        if load + item <= capacity
    )
    actions: Tuple[Optional[int], ...] = (*feasible, None)
    if limit is None or len(actions) <= limit:
        return actions
    ranked = sorted(
        feasible,
        key=lambda index: (capacity - loads[index] - item, index),
    )
    selected: List[Optional[int]] = []
    for index in (
        0,
        len(ranked) - 1,
        len(ranked) // 2,
        len(ranked) // 4,
        (3 * len(ranked)) // 4,
    ):
        action = ranked[index]
        if action not in selected:
            selected.append(action)
        if len(selected) >= limit - 1:
            break
    selected.append(None)
    return tuple(selected[:limit])


def _apply_action(
    loads: Sequence[int],
    item: int,
    action: Optional[int],
    capacity: int,
) -> Tuple[int, ...]:
    result = list(loads)
    if action is None:
        result.append(item)
    else:
        if action < 0 or action >= len(result) or result[action] + item > capacity:
            raise ValueError("counterfactual action is infeasible")
        result[action] += item
    return tuple(result)


def _rollout_from_loads(
    loads: Sequence[int],
    history: Sequence[int],
    suffix: Sequence[int],
    capacity: int,
    policy: OnlineHeuristic,
) -> int:
    current_loads = list(loads)
    current_history = list(history)
    for item in suffix:
        action = policy.choose_bin(
            item,
            tuple(current_loads),
            capacity,
            len(current_history),
            tuple(current_history),
        )
        current_loads = list(_apply_action(current_loads, item, action, capacity))
        current_history.append(item)
    return len(current_loads)


def _action_features(
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
    action: Optional[int],
    episode_length: int,
) -> Tuple[float, ...]:
    remaining = (
        capacity - item
        if action is None
        else capacity - loads[action] - item
    )
    fill_after = capacity - remaining
    residuals = tuple(capacity - load for load in loads)
    complement = remaining
    complement_frequency = sum(
        abs(value - complement) <= 5 for value in history[-64:]
    ) / float(max(1, min(64, len(history))))
    fragmentation = sum(value < item for value in residuals) / float(
        max(1, len(residuals))
    )
    history_mean = mean(history) if history else 0.0
    item_fraction = item / capacity
    remaining_fraction = remaining / capacity
    fill_fraction = fill_after / capacity
    load_spread = _spread(loads) / capacity
    history_deviation = (item - history_mean) / capacity
    return (
        1.0,
        item_fraction,
        remaining_fraction,
        fill_fraction,
        float(action is None),
        (len(loads) if action is None else action) / float(max(1, len(loads))),
        len(loads) / float(max(1, episode_length)),
        (mean(loads) if loads else 0.0) / capacity,
        load_spread,
        (mean(residuals) if residuals else capacity) / capacity,
        _spread(residuals) / capacity,
        history_mean / capacity,
        _spread(history) / capacity,
        history_deviation,
        float(remaining == 0),
        float(0 < remaining <= 5),
        float(5 < remaining <= 20),
        complement_frequency,
        fragmentation,
        item_index / float(max(1, episode_length - 1)),
        remaining_fraction * remaining_fraction,
        item_fraction * remaining_fraction,
        item_fraction * fill_fraction,
        float(action is None) * item_fraction,
        remaining_fraction * complement_frequency,
        remaining_fraction * fragmentation,
        load_spread * remaining_fraction,
        history_deviation * remaining_fraction,
    )


def _selected_state_indices(length: int, count: int, seed: int) -> Tuple[int, ...]:
    candidates = list(range(max(1, length // 10), length - 1))
    rng = random.Random(seed)
    rng.shuffle(candidates)
    return tuple(sorted(candidates[: min(count, len(candidates))]))


def _common_counterfactual_suffixes(
    config: StochasticValueConfig,
    *,
    episode_seed: int,
    item_index: int,
    remaining_length: int,
) -> Tuple[Tuple[int, ...], ...]:
    """Sample one frozen continuation panel shared by every legal action."""

    return tuple(
        _iid_episode(
            config,
            remaining_length,
            int(
                content_digest(
                    {
                        "version": STOCHASTIC_VALUE_VERSION,
                        "episode_seed": episode_seed,
                        "state": item_index,
                        "sample": sample_index,
                    }
                )[:16],
                16,
            ),
        )
        for sample_index in range(config.suffix_samples_per_action)
    )


def _collect_value_rows(
    config: StochasticValueConfig,
    ancestry: OnlineHeuristic,
) -> Tuple[CounterfactualValueRow, ...]:
    rows: List[CounterfactualValueRow] = []
    for length_index, length in enumerate(config.training_lengths):
        for episode_index in range(config.training_episodes_per_length):
            episode_seed = (
                config.base_seed + length_index * 10_000_000 + episode_index
            )
            episode_id = "train:length=%d:seed=%d" % (length, episode_seed)
            items = _iid_episode(config, length, episode_seed)
            selected = set(
                _selected_state_indices(
                    length,
                    config.states_per_episode,
                    episode_seed ^ 0x5F3759DF,
                )
            )
            loads: Tuple[int, ...] = ()
            history: Tuple[int, ...] = ()
            for item_index, item in enumerate(items):
                ancestry_action = ancestry.choose_bin(
                    item, loads, config.capacity, item_index, history
                )
                if item_index in selected:
                    actions = list(
                        _candidate_actions(
                            item,
                            loads,
                            config.capacity,
                            config.actions_per_state,
                        )
                    )
                    if ancestry_action not in actions:
                        actions[-1] = ancestry_action
                    estimates: Dict[Optional[int], float] = {}
                    remaining_length = length - item_index - 1
                    suffixes = _common_counterfactual_suffixes(
                        config,
                        episode_seed=episode_seed,
                        item_index=item_index,
                        remaining_length=remaining_length,
                    )
                    for action in actions:
                        returns = []
                        forced_loads = _apply_action(
                            loads,
                            item,
                            action,
                            config.capacity,
                        )
                        forced_history = (*history, item)
                        for suffix in suffixes:
                            returns.append(
                                -float(
                                    _rollout_from_loads(
                                        forced_loads,
                                        forced_history,
                                        suffix,
                                        config.capacity,
                                        ancestry,
                                    )
                                )
                            )
                        estimates[action] = mean(returns)
                    ancestry_value = estimates[ancestry_action]
                    state_id = "%s:item=%d" % (episode_id, item_index)
                    for action in actions:
                        rows.append(
                            CounterfactualValueRow(
                                episode_id=episode_id,
                                state_id=state_id,
                                features=_action_features(
                                    item,
                                    loads,
                                    config.capacity,
                                    item_index,
                                    history,
                                    action,
                                    item_index + 1,
                                ),
                                advantage=(
                                    estimates[action] - ancestry_value
                                ),
                                action_ref=_action_ref(action),
                                ancestry_action_ref=_action_ref(
                                    ancestry_action
                                ),
                            )
                        )
                loads = _apply_action(
                    loads,
                    item,
                    ancestry_action,
                    config.capacity,
                )
                history = (*history, item)
    return tuple(rows)


def _fit_linear_value(
    rows: Sequence[CounterfactualValueRow],
    config: StochasticValueConfig,
    seed: int,
) -> LinearValueModel:
    if not rows:
        raise ValueError("value fitting requires counterfactual rows")
    columns = tuple(zip(*(row.features for row in rows)))
    centers = tuple(mean(column) for column in columns)
    scales = tuple(max(1e-6, _spread(column)) for column in columns)
    weights = [0.0] * len(VALUE_FEATURES)
    order = list(range(len(rows)))
    rng = random.Random(seed)
    for epoch in range(config.fit_epochs):
        rng.shuffle(order)
        rate = config.learning_rate / math.sqrt(epoch + 1.0)
        for index in order:
            row = rows[index]
            standardized = tuple(
                (value - center) / scale
                for value, center, scale in zip(
                    row.features, centers, scales
                )
            )
            prediction = sum(
                weight * value for weight, value in zip(weights, standardized)
            )
            error = prediction - row.advantage
            for feature_index, value in enumerate(standardized):
                gradient = error * value + config.ridge * weights[feature_index]
                weights[feature_index] -= rate * gradient
                weights[feature_index] = max(-1e4, min(1e4, weights[feature_index]))
    return LinearValueModel(
        feature_names=VALUE_FEATURES,
        centers=centers,
        scales=scales,
        weights=tuple(weights),
    )


def _grouped_cross_validation(
    rows: Sequence[CounterfactualValueRow],
    config: StochasticValueConfig,
) -> Mapping[str, Any]:
    episode_ids = tuple(sorted({row.episode_id for row in rows}))
    fold_by_episode = {
        episode_id: int(content_digest(episode_id)[:8], 16)
        % config.grouped_cv_folds
        for episode_id in episode_ids
    }
    folds = []
    for fold_index in range(config.grouped_cv_folds):
        training = tuple(
            row
            for row in rows
            if fold_by_episode[row.episode_id] != fold_index
        )
        heldout = tuple(
            row
            for row in rows
            if fold_by_episode[row.episode_id] == fold_index
        )
        if not training or not heldout:
            raise ValueError("grouped CV produced an empty fold")
        model = _fit_linear_value(training, config, config.base_seed + fold_index)
        squared_errors_by_episode: Dict[str, List[float]] = {}
        for row in heldout:
            error = model.predict(row.features) - row.advantage
            squared_errors_by_episode.setdefault(row.episode_id, []).append(
                error * error
            )
        episode_mse = tuple(
            mean(values) for values in squared_errors_by_episode.values()
        )
        folds.append(
            {
                "fold": fold_index,
                "training_episode_count": len(
                    {row.episode_id for row in training}
                ),
                "heldout_episode_count": len(squared_errors_by_episode),
                "heldout_decision_row_count": len(heldout),
                "mean_episode_mse": mean(episode_mse),
            }
        )
    return {
        "split_unit": "episode_seed_and_length",
        "decision_rows_used_as_independent_observations": False,
        "fold_count": config.grouped_cv_folds,
        "folds": folds,
        "mean_fold_episode_mse": mean(
            item["mean_episode_mse"] for item in folds
        ),
    }


def _validation_episodes(
    config: StochasticValueConfig,
) -> Tuple[BinPackingInstance, ...]:
    instances = []
    for length_index, length in enumerate(config.training_lengths):
        for episode_index in range(config.validation_episodes_per_length):
            seed = (
                config.base_seed
                + 500_000_000
                + length_index * 10_000_000
                + episode_index
            )
            instances.append(
                BinPackingInstance(
                    instance_id="value-validation:length=%d:seed=%d"
                    % (length, seed),
                    family="iid_or_uniform_20_100",
                    seed=seed,
                    capacity=config.capacity,
                    items=_iid_episode(config, length, seed),
                )
            )
    return tuple(instances)


def iid_or_episode_suite(
    config: StochasticValueConfig,
    *,
    partition: str,
    episodes_per_length: int,
    seed_offset: int,
) -> Tuple[BinPackingInstance, ...]:
    if not partition or episodes_per_length <= 0 or seed_offset < 0:
        raise ValueError("invalid i.i.d. OR episode-suite request")
    return tuple(
        BinPackingInstance(
            instance_id="%s:length=%d:seed=%d" % (partition, length, seed),
            family="iid_or_uniform_20_100",
            seed=seed,
            capacity=config.capacity,
            items=_iid_episode(config, length, seed),
        )
        for length_index, length in enumerate(config.training_lengths)
        for episode_index in range(episodes_per_length)
        for seed in (
            config.base_seed
            + seed_offset
            + length_index * 10_000_000
            + episode_index,
        )
    )


def _replication_manifest(config: StochasticValueConfig) -> Mapping[str, Any]:
    seeds = tuple(
        config.base_seed
        + 900_000_000
        + length_index * 10_000_000
        + episode_index
        for length_index, _ in enumerate(config.training_lengths)
        for episode_index in range(config.replication_episodes_per_length)
    )
    return {
        "status": "sealed_unopened",
        "distribution": "iid_discrete_uniform_%d_%d"
        % (config.item_low, config.item_high),
        "lengths": list(config.training_lengths),
        "episode_count": len(seeds),
        "seed_commitment": content_digest(seeds),
        "opened_during_training": False,
    }


def train_stochastic_suffix_value(
    config: StochasticValueConfig,
    ancestry: OnlineHeuristic,
) -> StochasticValueTrainingResult:
    """Train from sampled futures and distill only after episode advantage."""

    rows = _collect_value_rows(config, ancestry)
    cross_validation = _grouped_cross_validation(rows, config)
    model = _fit_linear_value(rows, config, config.base_seed ^ 0xA11CE)
    provisional = DistilledStochasticValuePolicy(model)
    validation = _validation_episodes(config)
    improvements = tuple(
        float(
            pack(instance, ancestry).bin_count
            - pack(instance, provisional).bin_count
        )
        for instance in validation
    )
    evidence = paired_episode_evidence(
        improvements,
        tuple(instance.instance_id for instance in validation),
    )
    qualification = qualify_discovery(
        evidence,
        minimum_independent_episodes=config.validation_episode_count,
    )
    return StochasticValueTrainingResult(
        config=config,
        value_model=model,
        cross_validation=cross_validation,
        episode_advantage_gate=qualification,
        distilled_policy=(provisional if qualification.passed else None),
        replication_manifest=_replication_manifest(config),
        training_row_count=len(rows),
    )
