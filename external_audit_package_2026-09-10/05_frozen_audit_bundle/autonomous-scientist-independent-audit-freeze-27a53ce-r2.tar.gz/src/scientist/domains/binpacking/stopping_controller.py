from __future__ import annotations

from dataclasses import dataclass, replace
import math
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import GeneratedPolicyModuleProgram
from scientist.domains.binpacking.heuristics import literature_heuristics, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.representation_capacity import (
    AdvantageTrainingExample,
    LinearAdvantageModel,
    RepresentationCorpus,
    RepresentationProbe,
    fit_linear_advantage_model,
    observable_action_features,
)
from scientist.domains.binpacking.single_intervention import (
    SingleInterventionConfig,
    _examples,
    _stratified_folds,
)
from scientist.domains.binpacking.terminal_intervention import (
    TerminalInterventionLabels,
    _apply_action,
    _online_probe,
    _parse_action,
    _scored_action,
    _signature,
    _terminal_after_single_intervention,
)
from scientist.program.discovery_evidence import paired_episode_evidence


STOPPING_CONTROLLER_VERSION = "de-novo-two-head-stopping-controller-v1"


@dataclass(frozen=True)
class StoppingControllerConfig:
    fold_count: int = 5
    phase_count: int = 6
    labeled_candidates_per_phase: int = 2
    action_margin_quantiles: Tuple[float, ...] = (0.75, 0.90)
    episode_max_score_quantiles: Tuple[float, ...] = (0.50, 0.75, 0.90)
    action_fit_epochs: int = 42
    action_learning_rate: float = 0.0022
    action_ridge: float = 0.001
    action_informative_weight: float = 3.0
    stopping_fit_epochs: int = 48
    stopping_learning_rate: float = 0.002
    stopping_ridge: float = 0.003
    stopping_informative_weight: float = 6.0
    maximum_regression: float = 1.0

    def __post_init__(self) -> None:
        quantiles = (
            *self.action_margin_quantiles,
            *self.episode_max_score_quantiles,
        )
        if self.fold_count < 2 or self.phase_count < 2:
            raise ValueError("invalid stopping-controller fold or phase count")
        if self.labeled_candidates_per_phase < 1:
            raise ValueError("stopping controller needs labeled phase candidates")
        if (
            not self.action_margin_quantiles
            or not self.episode_max_score_quantiles
            or any(not 0.0 <= value < 1.0 for value in quantiles)
        ):
            raise ValueError("invalid stopping-controller quantiles")
        counts = (self.action_fit_epochs, self.stopping_fit_epochs)
        rates = (
            self.action_learning_rate,
            self.action_informative_weight,
            self.stopping_learning_rate,
            self.stopping_informative_weight,
        )
        if min(counts) <= 0 or min(rates) <= 0.0:
            raise ValueError("invalid stopping-controller fit controls")
        if (
            self.action_ridge < 0.0
            or self.stopping_ridge < 0.0
            or self.maximum_regression < 0.0
        ):
            raise ValueError("invalid stopping-controller regularization or risk")

    @property
    def labeled_candidates_per_episode(self) -> int:
        return self.phase_count * self.labeled_candidates_per_phase

    @property
    def action_config(self) -> SingleInterventionConfig:
        return SingleInterventionConfig(
            fold_count=self.fold_count,
            threshold_quantiles=self.action_margin_quantiles,
            fit_epochs=self.action_fit_epochs,
            learning_rate=self.action_learning_rate,
            ridge=self.action_ridge,
            informative_weight=self.action_informative_weight,
            maximum_regression=self.maximum_regression,
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": STOPPING_CONTROLLER_VERSION,
            "fold_count": self.fold_count,
            "phase_count": self.phase_count,
            "labeled_candidates_per_phase": self.labeled_candidates_per_phase,
            "labeled_candidates_per_episode_upper_bound": (
                self.labeled_candidates_per_episode
            ),
            "action_margin_quantiles": list(self.action_margin_quantiles),
            "episode_max_score_quantiles": list(
                self.episode_max_score_quantiles
            ),
            "action_fit": {
                "epochs": self.action_fit_epochs,
                "learning_rate": self.action_learning_rate,
                "ridge": self.action_ridge,
                "informative_weight": self.action_informative_weight,
            },
            "stopping_fit": {
                "epochs": self.stopping_fit_epochs,
                "learning_rate": self.stopping_learning_rate,
                "ridge": self.stopping_ridge,
                "informative_weight": self.stopping_informative_weight,
            },
            "maximum_interventions": 1,
            "maximum_regression": self.maximum_regression,
            "threshold_calibration_unit": "episode_max_over_full_trajectory_scan",
        }


@dataclass(frozen=True)
class ScannedInterventionCandidate:
    instance_id: str
    sequence_length: int
    probe: RepresentationProbe
    selected_action_ref: str
    action_margin: float
    stopping_features: Mapping[str, float]


def _stopping_features(
    program: GeneratedPolicyModuleProgram,
    probe: RepresentationProbe,
    selected_action_ref: str,
    action_margin: float,
    *,
    previous_max_margin: float,
    candidate_count: int,
    include_candidate_representation: bool,
) -> Mapping[str, float]:
    features = dict(
        observable_action_features(
            program,
            probe,
            selected_action_ref,
            include_candidate_representation=include_candidate_representation,
        )
    )
    log_index = math.log1p(probe.item_index)
    margin_over_record = action_margin - previous_max_margin
    features.update(
        {
            "stopping_action_margin": action_margin,
            "stopping_action_margin_squared": action_margin * action_margin,
            "stopping_previous_max_margin": previous_max_margin,
            "stopping_margin_over_record": margin_over_record,
            "stopping_is_new_record": float(action_margin > previous_max_margin),
            "stopping_candidate_count": float(candidate_count),
            "stopping_log_candidate_count": math.log1p(candidate_count),
            "stopping_log_item_index": log_index,
            "stopping_margin_x_log_item_index": action_margin * log_index,
            "stopping_phase_proxy_50": probe.item_index
            / float(probe.item_index + 50),
            "stopping_phase_proxy_150": probe.item_index
            / float(probe.item_index + 150),
            "stopping_phase_proxy_500": probe.item_index
            / float(probe.item_index + 500),
        }
    )
    return features


def _scan_instance(
    program: GeneratedPolicyModuleProgram,
    action_model: LinearAdvantageModel,
    instance: BinPackingInstance,
    *,
    include_candidate_representation: bool,
    minimum_item_index: int,
) -> Tuple[ScannedInterventionCandidate, ...]:
    incumbent = literature_heuristics()["funsearch_or_reference"]
    loads: Tuple[int, ...] = ()
    history: Tuple[int, ...] = ()
    previous_max_margin = 0.0
    candidate_count = 0
    rows = []
    for item_index, item in enumerate(instance.items):
        incumbent_action = incumbent.choose_bin(
            item, loads, instance.capacity, item_index, history
        )
        if item_index >= minimum_item_index:
            probe = _online_probe(
                incumbent,
                item,
                loads,
                instance.capacity,
                item_index,
                history,
            )
            selected_ref, margin = _scored_action(
                action_model,
                program,
                probe,
                include_candidate_representation=(
                    include_candidate_representation
                ),
            )
            changes_successor = bool(
                _signature(
                    _parse_action(selected_ref), item, loads, instance.capacity
                )
                != _signature(
                    incumbent_action, item, loads, instance.capacity
                )
            )
            if changes_successor and margin > 0.0:
                candidate_count += 1
                features = _stopping_features(
                    program,
                    probe,
                    selected_ref,
                    float(margin),
                    previous_max_margin=previous_max_margin,
                    candidate_count=candidate_count,
                    include_candidate_representation=(
                        include_candidate_representation
                    ),
                )
                rows.append(
                    ScannedInterventionCandidate(
                        instance_id=instance.instance_id,
                        sequence_length=len(instance.items),
                        probe=replace(
                            probe,
                            remaining_items=instance.items[item_index + 1 :],
                        ),
                        selected_action_ref=selected_ref,
                        action_margin=float(margin),
                        stopping_features=features,
                    )
                )
                previous_max_margin = max(previous_max_margin, float(margin))
        loads = _apply_action(
            incumbent_action, item, loads, instance.capacity
        )
        history = (*history, item)[-128:]
    return tuple(rows)


def _scan_instances(
    program: GeneratedPolicyModuleProgram,
    action_model: LinearAdvantageModel,
    instances: Sequence[BinPackingInstance],
    *,
    include_candidate_representation: bool,
    minimum_item_index: int,
) -> Mapping[str, Tuple[ScannedInterventionCandidate, ...]]:
    return {
        instance.instance_id: _scan_instance(
            program,
            action_model,
            instance,
            include_candidate_representation=include_candidate_representation,
            minimum_item_index=minimum_item_index,
        )
        for instance in instances
    }


def _phase_balanced_candidates(
    instances: Sequence[BinPackingInstance],
    scanned: Mapping[str, Tuple[ScannedInterventionCandidate, ...]],
    config: StoppingControllerConfig,
) -> Tuple[ScannedInterventionCandidate, ...]:
    selected = []
    for instance in instances:
        phases: Dict[int, list[ScannedInterventionCandidate]] = {
            index: [] for index in range(config.phase_count)
        }
        for candidate in scanned[instance.instance_id]:
            phase = min(
                config.phase_count - 1,
                candidate.probe.item_index
                * config.phase_count
                // len(instance.items),
            )
            phases[phase].append(candidate)
        for phase in range(config.phase_count):
            ranked = sorted(
                phases[phase],
                key=lambda row: (-row.action_margin, row.probe.item_index),
            )
            selected.extend(ranked[: config.labeled_candidates_per_phase])
    return tuple(selected)


def _stopping_examples(
    instances: Sequence[BinPackingInstance],
    candidates: Sequence[ScannedInterventionCandidate],
) -> Tuple[AdvantageTrainingExample, ...]:
    incumbent = literature_heuristics()["funsearch_or_reference"]
    incumbent_bins = {
        instance.instance_id: pack(instance, incumbent).bin_count
        for instance in instances
    }
    rows = []
    for candidate in candidates:
        terminal_bins = _terminal_after_single_intervention(
            candidate.probe,
            candidate.selected_action_ref,
            incumbent,
        )
        advantage = float(
            incumbent_bins[candidate.instance_id] - terminal_bins
        )
        row_id = content_digest(
            {
                "version": STOPPING_CONTROLLER_VERSION,
                "instance_id": candidate.instance_id,
                "probe_id": candidate.probe.probe_id,
                "action_ref": candidate.selected_action_ref,
            }
        )
        rows.append(
            AdvantageTrainingExample(
                state_id=row_id,
                instance_id=candidate.instance_id,
                action_ref=candidate.selected_action_ref,
                features=candidate.stopping_features,
                advantage=advantage,
                informative=advantage != 0.0,
            )
        )
    if not rows:
        raise ValueError("stopping fit found no full-scan candidate states")
    return tuple(rows)


def _fit_action_model(
    examples: Sequence[AdvantageTrainingExample],
    config: StoppingControllerConfig,
    seed: int,
) -> LinearAdvantageModel:
    return fit_linear_advantage_model(
        examples,
        seed=seed,
        epochs=config.action_fit_epochs,
        learning_rate=config.action_learning_rate,
        ridge=config.action_ridge,
        informative_weight=config.action_informative_weight,
    )


def _fit_stopping_model(
    examples: Sequence[AdvantageTrainingExample],
    config: StoppingControllerConfig,
    seed: int,
) -> LinearAdvantageModel:
    return fit_linear_advantage_model(
        examples,
        seed=seed,
        epochs=config.stopping_fit_epochs,
        learning_rate=config.stopping_learning_rate,
        ridge=config.stopping_ridge,
        informative_weight=config.stopping_informative_weight,
    )


def _quantile(values: Sequence[float], quantile: float) -> float:
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return 0.0
    index = int(round(quantile * (len(ordered) - 1)))
    return ordered[index]


def _calibrated_thresholds(
    instances: Sequence[BinPackingInstance],
    scanned: Mapping[str, Tuple[ScannedInterventionCandidate, ...]],
    stopping_model: LinearAdvantageModel,
    config: StoppingControllerConfig,
) -> Mapping[Tuple[float, float], Tuple[float, float]]:
    all_margins = tuple(
        candidate.action_margin
        for instance in instances
        for candidate in scanned[instance.instance_id]
    )
    result = {}
    for action_quantile in config.action_margin_quantiles:
        action_threshold = _quantile(all_margins, action_quantile)
        episode_max_scores = []
        for instance in instances:
            scores = tuple(
                stopping_model.predict(candidate.stopping_features)
                for candidate in scanned[instance.instance_id]
                if candidate.action_margin > action_threshold
            )
            if scores:
                episode_max_scores.append(max(scores))
        for stop_quantile in config.episode_max_score_quantiles:
            stop_threshold = _quantile(episode_max_scores, stop_quantile)
            result[(action_quantile, stop_quantile)] = (
                action_threshold,
                stop_threshold,
            )
    return result


class TwoHeadStoppingPolicy:
    """Action ranker plus a stateful, single-use stopping controller."""

    def __init__(
        self,
        *,
        program: GeneratedPolicyModuleProgram,
        action_model: LinearAdvantageModel,
        stopping_model: LinearAdvantageModel,
        include_candidate_representation: bool,
        action_margin_threshold: float,
        stopping_score_threshold: float,
        minimum_item_index: int,
        deployment_enabled: bool,
        name: str,
    ) -> None:
        if minimum_item_index < 0:
            raise ValueError("invalid two-head minimum item index")
        self.program = program
        self.action_model = action_model
        self.stopping_model = stopping_model
        self.include_candidate_representation = bool(
            include_candidate_representation
        )
        self.action_margin_threshold = float(action_margin_threshold)
        self.stopping_score_threshold = float(stopping_score_threshold)
        self.minimum_item_index = int(minimum_item_index)
        self.deployment_enabled = bool(deployment_enabled)
        self.name = str(name)
        self.incumbent = literature_heuristics()["funsearch_or_reference"]
        self._last_seen_index = -1
        self._interventions_used = 0
        self._previous_max_margin = 0.0
        self._candidate_count = 0

    @property
    def interventions_used(self) -> int:
        return self._interventions_used

    def _reset_if_new_episode(self, item_index: int) -> None:
        if item_index == 0 or item_index <= self._last_seen_index:
            self._interventions_used = 0
            self._previous_max_margin = 0.0
            self._candidate_count = 0
        self._last_seen_index = item_index

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        self._reset_if_new_episode(item_index)
        incumbent_action = self.incumbent.choose_bin(
            item, loads, capacity, item_index, history
        )
        if (
            not self.deployment_enabled
            or self._interventions_used >= 1
            or item_index < self.minimum_item_index
        ):
            return incumbent_action
        probe = _online_probe(
            self.incumbent,
            item,
            loads,
            capacity,
            item_index,
            history,
        )
        selected_ref, margin = _scored_action(
            self.action_model,
            self.program,
            probe,
            include_candidate_representation=(
                self.include_candidate_representation
            ),
        )
        selected = _parse_action(selected_ref)
        if (
            margin <= 0.0
            or _signature(selected, item, loads, capacity)
            == _signature(incumbent_action, item, loads, capacity)
        ):
            return incumbent_action
        self._candidate_count += 1
        features = _stopping_features(
            self.program,
            probe,
            selected_ref,
            float(margin),
            previous_max_margin=self._previous_max_margin,
            candidate_count=self._candidate_count,
            include_candidate_representation=(
                self.include_candidate_representation
            ),
        )
        self._previous_max_margin = max(self._previous_max_margin, float(margin))
        if margin <= self.action_margin_threshold:
            return incumbent_action
        stopping_score = self.stopping_model.predict(features)
        if stopping_score <= self.stopping_score_threshold:
            return incumbent_action
        self._interventions_used = 1
        return selected

    def as_dict(self) -> Dict[str, Any]:
        value = {
            "version": STOPPING_CONTROLLER_VERSION,
            "program_candidate_id": self.program.candidate_id,
            "action_model": self.action_model.as_dict(),
            "stopping_model": self.stopping_model.as_dict(),
            "include_candidate_representation": (
                self.include_candidate_representation
            ),
            "action_margin_threshold": self.action_margin_threshold,
            "stopping_score_threshold": self.stopping_score_threshold,
            "minimum_item_index": self.minimum_item_index,
            "maximum_interventions": 1,
            "deployment_enabled": self.deployment_enabled,
            "incumbent": "funsearch_or_reference",
        }
        return {**value, "policy_id": content_digest(value), "name": self.name}

    @classmethod
    def from_dict(
        cls,
        *,
        program: GeneratedPolicyModuleProgram,
        value: Mapping[str, Any],
    ) -> "TwoHeadStoppingPolicy":
        if value.get("version") != STOPPING_CONTROLLER_VERSION:
            raise ValueError("unsupported two-head stopping policy version")
        if value.get("program_candidate_id") != program.candidate_id:
            raise ValueError("two-head stopping program identity mismatch")
        if value.get("incumbent") != "funsearch_or_reference":
            raise ValueError("unsupported two-head stopping incumbent")
        if int(value.get("maximum_interventions", -1)) != 1:
            raise ValueError("two-head stopping budget identity mismatch")
        policy = cls(
            program=program,
            action_model=LinearAdvantageModel.from_dict(value["action_model"]),
            stopping_model=LinearAdvantageModel.from_dict(
                value["stopping_model"]
            ),
            include_candidate_representation=bool(
                value["include_candidate_representation"]
            ),
            action_margin_threshold=float(value["action_margin_threshold"]),
            stopping_score_threshold=float(value["stopping_score_threshold"]),
            minimum_item_index=int(value["minimum_item_index"]),
            deployment_enabled=bool(value["deployment_enabled"]),
            name=str(value.get("name", "frozen_two_head_stopping")),
        )
        supplied_id = value.get("policy_id")
        if supplied_id is not None and supplied_id != policy.as_dict()["policy_id"]:
            raise ValueError("two-head stopping policy identity mismatch")
        return policy


def evaluate_two_head_policy(
    instances: Sequence[BinPackingInstance],
    policy: TwoHeadStoppingPolicy,
) -> Mapping[str, Any]:
    incumbent = literature_heuristics()["funsearch_or_reference"]
    improvements = []
    interventions = []
    incumbent_counts = []
    candidate_counts = []
    for instance in instances:
        incumbent_bins = pack(instance, incumbent).bin_count
        candidate_bins = pack(instance, policy).bin_count
        incumbent_counts.append(incumbent_bins)
        candidate_counts.append(candidate_bins)
        improvements.append(float(incumbent_bins - candidate_bins))
        interventions.append(policy.interventions_used)
    evidence = paired_episode_evidence(
        improvements,
        tuple(instance.instance_id for instance in instances),
    )
    by_length: Dict[int, list[float]] = {}
    for instance, improvement in zip(instances, improvements):
        by_length.setdefault(len(instance.items), []).append(improvement)
    return {
        "evidence": evidence.as_dict(),
        "incumbent_mean_bins": mean(incumbent_counts),
        "candidate_mean_bins": mean(candidate_counts),
        "aggregate_interventions": sum(interventions),
        "mean_interventions_per_episode": mean(interventions),
        "maximum_interventions_in_episode": max(interventions),
        "aggregate_improvement_by_length": {
            str(length): sum(values)
            for length, values in sorted(by_length.items())
        },
        "mean_improvement_by_length": {
            str(length): mean(values)
            for length, values in sorted(by_length.items())
        },
    }


def _fit_bundle(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: StoppingControllerConfig,
    instances: Sequence[BinPackingInstance],
    *,
    include_candidate_representation: bool,
    seed: int,
) -> Tuple[
    LinearAdvantageModel,
    LinearAdvantageModel,
    Mapping[str, Tuple[ScannedInterventionCandidate, ...]],
    Mapping[str, Any],
]:
    instance_ids = tuple(instance.instance_id for instance in instances)
    action_examples = _examples(
        program,
        corpus,
        labels,
        instance_ids,
        include_candidate_representation=include_candidate_representation,
    )
    action_model = _fit_action_model(action_examples, config, seed)
    scanned = _scan_instances(
        program,
        action_model,
        instances,
        include_candidate_representation=include_candidate_representation,
        minimum_item_index=corpus.config.minimum_history_items,
    )
    labeled_candidates = _phase_balanced_candidates(instances, scanned, config)
    stopping_examples = _stopping_examples(instances, labeled_candidates)
    stopping_model = _fit_stopping_model(
        stopping_examples,
        config,
        seed + 50_000,
    )
    advantages = tuple(row.advantage for row in stopping_examples)
    report = {
        "action_model_id": action_model.as_dict()["model_id"],
        "stopping_model_id": stopping_model.as_dict()["model_id"],
        "training_instance_count": len(instances),
        "action_training_example_count": len(action_examples),
        "full_scan_candidate_count": sum(len(value) for value in scanned.values()),
        "stopping_training_example_count": len(stopping_examples),
        "stopping_helpful_label_count": sum(value > 0.0 for value in advantages),
        "stopping_harmful_label_count": sum(value < 0.0 for value in advantages),
        "stopping_tie_label_count": sum(value == 0.0 for value in advantages),
    }
    return action_model, stopping_model, scanned, report


def _crossfit_mode(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: StoppingControllerConfig,
    *,
    include_candidate_representation: bool,
    seed: int,
) -> Tuple[TwoHeadStoppingPolicy, Mapping[str, Any]]:
    folds = _stratified_folds(corpus, config.fold_count)
    development_instances = corpus.split_instances("development")
    instance_by_id = {
        instance.instance_id: instance for instance in development_instances
    }
    all_ids = set(instance_by_id)
    configurations: Tuple[Optional[Tuple[float, float]], ...] = (
        None,
        *(
            (action_quantile, stop_quantile)
            for action_quantile in config.action_margin_quantiles
            for stop_quantile in config.episode_max_score_quantiles
        ),
    )
    results: Dict[Optional[Tuple[float, float]], list[Mapping[str, Any]]] = {
        value: [] for value in configurations
    }
    fold_reports = []
    mode = "representation" if include_candidate_representation else "generic"
    for fold_index, holdout_ids in enumerate(folds):
        holdout_set = set(holdout_ids)
        training_instances = tuple(
            instance_by_id[value]
            for value in sorted(all_ids.difference(holdout_set))
        )
        holdout_instances = tuple(instance_by_id[value] for value in holdout_ids)
        action_model, stopping_model, scanned, fit_report = _fit_bundle(
            program,
            corpus,
            labels,
            config,
            training_instances,
            include_candidate_representation=include_candidate_representation,
            seed=seed + fold_index,
        )
        thresholds = _calibrated_thresholds(
            training_instances,
            scanned,
            stopping_model,
            config,
        )
        fold_reports.append(
            {
                "fold_index": fold_index,
                "holdout_instance_ids": list(holdout_ids),
                "fit": fit_report,
                "calibrated_thresholds": {
                    "action_q%.3f_stop_q%.3f" % key: list(value)
                    for key, value in thresholds.items()
                },
            }
        )
        for candidate in configurations:
            action_threshold, stop_threshold = (
                (0.0, 0.0) if candidate is None else thresholds[candidate]
            )
            policy = TwoHeadStoppingPolicy(
                program=program,
                action_model=action_model,
                stopping_model=stopping_model,
                include_candidate_representation=(
                    include_candidate_representation
                ),
                action_margin_threshold=action_threshold,
                stopping_score_threshold=stop_threshold,
                minimum_item_index=corpus.config.minimum_history_items,
                deployment_enabled=candidate is not None,
                name="two_head_%s_fold%d" % (mode, fold_index),
            )
            results[candidate].append(
                {
                    "fold_index": fold_index,
                    "action_margin_threshold": action_threshold,
                    "stopping_score_threshold": stop_threshold,
                    "audit": evaluate_two_head_policy(holdout_instances, policy),
                }
            )

    attempts = []
    eligible_attempts = []
    for candidate in configurations:
        fold_results = results[candidate]
        by_id: Dict[str, float] = {}
        intervention_count = 0
        for fold, fold_result in zip(folds, fold_results):
            values = fold_result["audit"]["evidence"]["improvements"]
            by_id.update(zip(fold, values))
            intervention_count += fold_result["audit"]["aggregate_interventions"]
        improvements = tuple(
            by_id[instance.instance_id] for instance in development_instances
        )
        evidence = paired_episode_evidence(
            improvements,
            tuple(instance.instance_id for instance in development_instances),
        )
        by_length: Dict[int, list[float]] = {}
        for instance, improvement in zip(development_instances, improvements):
            by_length.setdefault(len(instance.items), []).append(improvement)
        length_aggregates = {
            str(length): sum(values)
            for length, values in sorted(by_length.items())
        }
        fold_aggregates = tuple(
            value["audit"]["evidence"]["aggregate_improvement"]
            for value in fold_results
        )
        eligible = bool(
            candidate is not None
            and evidence.aggregate_improvement > 0.0
            and evidence.wins > evidence.losses
            and min(fold_aggregates) >= 0.0
            and min(length_aggregates.values()) >= 0.0
        )
        rank = (
            min(length_aggregates.values()),
            min(fold_aggregates),
            evidence.aggregate_improvement,
            evidence.wins - evidence.losses,
            -intervention_count,
            -1.0 if candidate is None else candidate[0] + candidate[1],
        )
        attempt = {
            "action_margin_quantile": None if candidate is None else candidate[0],
            "episode_max_score_quantile": (
                None if candidate is None else candidate[1]
            ),
            "eligible": eligible,
            "pooled_evidence": evidence.as_dict(),
            "fold_aggregates": list(fold_aggregates),
            "aggregate_improvement_by_length": length_aggregates,
            "aggregate_interventions": intervention_count,
            "fold_results": fold_results,
            "selection_rank": list(rank),
        }
        attempts.append(attempt)
        if eligible:
            eligible_attempts.append((rank, candidate, attempt))
    selected_rank, selected_config, selected_attempt = (
        max(eligible_attempts, key=lambda item: item[0])
        if eligible_attempts
        else ((0.0,) * 6, None, attempts[0])
    )

    final_action, final_stopping, final_scanned, final_fit = _fit_bundle(
        program,
        corpus,
        labels,
        config,
        development_instances,
        include_candidate_representation=include_candidate_representation,
        seed=seed + config.fold_count + 100_000,
    )
    final_thresholds = _calibrated_thresholds(
        development_instances,
        final_scanned,
        final_stopping,
        config,
    )
    action_threshold, stop_threshold = (
        (0.0, 0.0)
        if selected_config is None
        else final_thresholds[selected_config]
    )
    policy = TwoHeadStoppingPolicy(
        program=program,
        action_model=final_action,
        stopping_model=final_stopping,
        include_candidate_representation=include_candidate_representation,
        action_margin_threshold=action_threshold,
        stopping_score_threshold=stop_threshold,
        minimum_item_index=corpus.config.minimum_history_items,
        deployment_enabled=selected_config is not None,
        name="two_head_%s_%s" % (program.hypothesis_id[:8], mode),
    )
    return policy, {
        "mode": mode,
        "fold_count": config.fold_count,
        "folds": fold_reports,
        "attempts": attempts,
        "selected_crossfit_attempt": selected_attempt,
        "crossfit_eligible": selected_attempt["eligible"],
        "selection_rank": list(selected_rank),
        "final_fit": final_fit,
        "selected_policy": policy.as_dict(),
    }


def _paired_difference(
    instances: Sequence[BinPackingInstance],
    left: Mapping[str, Any],
    right: Mapping[str, Any],
) -> Mapping[str, Any]:
    values = tuple(
        float(left_value - right_value)
        for left_value, right_value in zip(
            left["evidence"]["improvements"],
            right["evidence"]["improvements"],
        )
    )
    return paired_episode_evidence(
        values,
        tuple(instance.instance_id for instance in instances),
    ).as_dict()


@dataclass(frozen=True)
class StoppingControllerResult:
    report: Mapping[str, Any]
    generic_policy: TwoHeadStoppingPolicy
    representation_policy: TwoHeadStoppingPolicy

    @property
    def promoted(self) -> bool:
        return bool(self.report["promotion_gate"]["passed"])


def assess_stopping_controller(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: StoppingControllerConfig = StoppingControllerConfig(),
) -> StoppingControllerResult:
    """Cross-fit action ranking and stopping before adaptive validation."""

    if set(labels.report.get("labeled_splits", ())) != {"development"}:
        raise ValueError("stopping controller accepts development labels only")
    generic_policy, generic_crossfit = _crossfit_mode(
        program,
        corpus,
        labels,
        config,
        include_candidate_representation=False,
        seed=corpus.config.base_seed + 241_000,
    )
    representation_policy, representation_crossfit = _crossfit_mode(
        program,
        corpus,
        labels,
        config,
        include_candidate_representation=True,
        seed=corpus.config.base_seed + 267_000,
    )
    validation_instances = corpus.split_instances("adaptive_validation")
    generic_validation = evaluate_two_head_policy(
        validation_instances, generic_policy
    )
    representation_validation = evaluate_two_head_policy(
        validation_instances, representation_policy
    )
    representation_minus_generic = _paired_difference(
        validation_instances,
        representation_validation,
        generic_validation,
    )
    evidence = representation_validation["evidence"]
    reasons = []
    if not representation_crossfit["crossfit_eligible"]:
        reasons.append("two_head_representation_not_crossfit_stable")
    if evidence["mean_improvement_ci_lower"] <= 0.0:
        reasons.append("validation_improvement_confidence_interval_includes_zero")
    if evidence["aggregate_improvement"] <= 0.0:
        reasons.append("validation_aggregate_improvement_not_positive")
    if min(
        representation_validation["aggregate_improvement_by_length"].values()
    ) < 0.0:
        reasons.append("at_least_one_validation_length_regressed")
    if representation_minus_generic["mean_improvement_ci_lower"] <= 0.0:
        reasons.append("two_head_representation_gain_over_generic_not_established")
    if evidence["maximum_regression"] > config.maximum_regression:
        reasons.append("maximum_episode_regression_exceeds_limit")
    report: Dict[str, Any] = {
        "schema": 1,
        "version": STOPPING_CONTROLLER_VERSION,
        "candidate_id": program.candidate_id,
        "hypothesis_id": program.hypothesis_id,
        "corpus_id": corpus.report["corpus_id"],
        "terminal_label_set_id": labels.report["label_set_id"],
        "config": config.as_dict(),
        "architecture": {
            "action_head": "terminal-advantage action ranker",
            "stopping_head": "on-policy terminal-advantage stopping model",
            "threshold_calibration": "episode maxima over full scans",
            "maximum_interventions": 1,
        },
        "adaptive_or_sealed_labels_used_for_fitting": False,
        "sealed_episodes_accessed": False,
        "generic_crossfit": generic_crossfit,
        "candidate_representation_crossfit": representation_crossfit,
        "adaptive_validation": {
            "generic": generic_validation,
            "candidate_representation": representation_validation,
            "candidate_minus_generic": representation_minus_generic,
        },
        "promotion_gate": {
            "passed": not reasons,
            "reasons": reasons,
        },
    }
    report["assessment_id"] = content_digest(report)
    return StoppingControllerResult(
        report=report,
        generic_policy=generic_policy,
        representation_policy=representation_policy,
    )
