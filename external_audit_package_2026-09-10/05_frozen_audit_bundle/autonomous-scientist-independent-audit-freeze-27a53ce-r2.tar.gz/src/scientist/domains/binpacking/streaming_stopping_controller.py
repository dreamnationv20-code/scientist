from __future__ import annotations

from dataclasses import dataclass
import math
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import GeneratedPolicyModuleProgram
from scientist.domains.binpacking.heuristics import literature_heuristics, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.representation_capacity import (
    LinearAdvantageModel,
    RepresentationCorpus,
)
from scientist.domains.binpacking.single_intervention import _stratified_folds
from scientist.domains.binpacking.stopping_controller import (
    ScannedInterventionCandidate,
    StoppingControllerConfig,
    _fit_bundle,
    _stopping_features,
)
from scientist.domains.binpacking.terminal_intervention import (
    TerminalInterventionLabels,
    _online_probe,
    _parse_action,
    _scored_action,
    _signature,
)
from scientist.program.discovery_evidence import paired_episode_evidence


STREAMING_STOPPING_VERSION = "de-novo-target-streaming-stopping-controller-v1"


@dataclass(frozen=True)
class StreamingStoppingConfig:
    controller: StoppingControllerConfig = StoppingControllerConfig()
    minimum_streaming_candidates: int = 8

    def __post_init__(self) -> None:
        if self.minimum_streaming_candidates < 3:
            raise ValueError("streaming calibration needs at least three candidates")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": STREAMING_STOPPING_VERSION,
            "controller": self.controller.as_dict(),
            "minimum_streaming_candidates": self.minimum_streaming_candidates,
            "threshold_space": "online_prior_only_z_score",
            "future_length_access": False,
        }


def _prior_z(
    value: float,
    count: int,
    center: float,
    squared_deviation: float,
    minimum_count: int,
) -> float:
    if count < minimum_count or count < 2:
        return 0.0
    scale = math.sqrt(max(0.0, squared_deviation / float(count - 1)))
    if scale <= 1e-9:
        return 0.0
    return max(-10.0, min(10.0, (float(value) - center) / scale))


def _updated_stats(
    value: float,
    count: int,
    center: float,
    squared_deviation: float,
) -> Tuple[int, float, float]:
    next_count = count + 1
    delta = float(value) - center
    next_center = center + delta / next_count
    next_squared_deviation = squared_deviation + delta * (
        float(value) - next_center
    )
    return next_count, next_center, next_squared_deviation


@dataclass(frozen=True)
class StreamingCandidateScore:
    action_z: float
    stopping_z: float


def _stream_scores(
    candidates: Sequence[ScannedInterventionCandidate],
    stopping_model: LinearAdvantageModel,
    minimum_count: int,
) -> Tuple[StreamingCandidateScore, ...]:
    action_count = stop_count = 0
    action_center = action_m2 = stop_center = stop_m2 = 0.0
    result = []
    for candidate in candidates:
        stop_score = stopping_model.predict(candidate.stopping_features)
        action_z = _prior_z(
            candidate.action_margin,
            action_count,
            action_center,
            action_m2,
            minimum_count,
        )
        stopping_z = _prior_z(
            stop_score,
            stop_count,
            stop_center,
            stop_m2,
            minimum_count,
        )
        result.append(StreamingCandidateScore(action_z, stopping_z))
        action_count, action_center, action_m2 = _updated_stats(
            candidate.action_margin,
            action_count,
            action_center,
            action_m2,
        )
        stop_count, stop_center, stop_m2 = _updated_stats(
            stop_score,
            stop_count,
            stop_center,
            stop_m2,
        )
    return tuple(result)


def _quantile(values: Sequence[float], quantile: float) -> float:
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return 0.0
    return ordered[int(round(quantile * (len(ordered) - 1)))]


def _streaming_thresholds(
    instances: Sequence[BinPackingInstance],
    scanned: Mapping[str, Tuple[ScannedInterventionCandidate, ...]],
    stopping_model: LinearAdvantageModel,
    config: StreamingStoppingConfig,
) -> Mapping[Tuple[float, float], Tuple[float, float]]:
    streamed = {
        instance.instance_id: _stream_scores(
            scanned[instance.instance_id],
            stopping_model,
            config.minimum_streaming_candidates,
        )
        for instance in instances
    }
    action_values = tuple(
        score.action_z
        for instance in instances
        for index, score in enumerate(streamed[instance.instance_id])
        if index >= config.minimum_streaming_candidates
    )
    result = {}
    for action_quantile in config.controller.action_margin_quantiles:
        action_threshold = _quantile(action_values, action_quantile)
        episode_maxima = []
        for instance in instances:
            eligible = tuple(
                score.stopping_z
                for index, score in enumerate(streamed[instance.instance_id])
                if index >= config.minimum_streaming_candidates
                and score.action_z > action_threshold
            )
            if eligible:
                episode_maxima.append(max(eligible))
        for stopping_quantile in config.controller.episode_max_score_quantiles:
            result[(action_quantile, stopping_quantile)] = (
                action_threshold,
                _quantile(episode_maxima, stopping_quantile),
            )
    return result


class StreamingTwoHeadStoppingPolicy:
    """Single intervention gated by prior-only streaming-normalized scores."""

    def __init__(
        self,
        *,
        program: GeneratedPolicyModuleProgram,
        action_model: LinearAdvantageModel,
        stopping_model: LinearAdvantageModel,
        include_candidate_representation: bool,
        action_z_threshold: float,
        stopping_z_threshold: float,
        minimum_item_index: int,
        minimum_streaming_candidates: int,
        deployment_enabled: bool,
        name: str,
    ) -> None:
        if minimum_item_index < 0 or minimum_streaming_candidates < 3:
            raise ValueError("invalid streaming stopping deployment controls")
        self.program = program
        self.action_model = action_model
        self.stopping_model = stopping_model
        self.include_candidate_representation = bool(
            include_candidate_representation
        )
        self.action_z_threshold = float(action_z_threshold)
        self.stopping_z_threshold = float(stopping_z_threshold)
        self.minimum_item_index = int(minimum_item_index)
        self.minimum_streaming_candidates = int(minimum_streaming_candidates)
        self.deployment_enabled = bool(deployment_enabled)
        self.name = str(name)
        self.incumbent = literature_heuristics()["funsearch_or_reference"]
        self._last_seen_index = -1
        self._interventions_used = 0
        self._previous_max_margin = 0.0
        self._candidate_count = 0
        self._action_count = 0
        self._action_center = 0.0
        self._action_m2 = 0.0
        self._stop_count = 0
        self._stop_center = 0.0
        self._stop_m2 = 0.0

    @property
    def interventions_used(self) -> int:
        return self._interventions_used

    def _reset_if_new_episode(self, item_index: int) -> None:
        if item_index == 0 or item_index <= self._last_seen_index:
            self._interventions_used = 0
            self._previous_max_margin = 0.0
            self._candidate_count = 0
            self._action_count = 0
            self._action_center = 0.0
            self._action_m2 = 0.0
            self._stop_count = 0
            self._stop_center = 0.0
            self._stop_m2 = 0.0
        self._last_seen_index = item_index

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        self._reset_if_new_episode(item_index)
        incumbent_action = self.incumbent.choose_bin(
            item, loads, capacity, item_index, history
        )
        if (
            not self.deployment_enabled
            or self._interventions_used >= 1
            or item_index < self.minimum_item_index
        ):
            return incumbent_action
        probe = _online_probe(
            self.incumbent,
            item,
            loads,
            capacity,
            item_index,
            history,
        )
        selected_ref, margin = _scored_action(
            self.action_model,
            self.program,
            probe,
            include_candidate_representation=(
                self.include_candidate_representation
            ),
        )
        selected = _parse_action(selected_ref)
        if (
            margin <= 0.0
            or _signature(selected, item, loads, capacity)
            == _signature(incumbent_action, item, loads, capacity)
        ):
            return incumbent_action
        self._candidate_count += 1
        features = _stopping_features(
            self.program,
            probe,
            selected_ref,
            float(margin),
            previous_max_margin=self._previous_max_margin,
            candidate_count=self._candidate_count,
            include_candidate_representation=(
                self.include_candidate_representation
            ),
        )
        stop_score = self.stopping_model.predict(features)
        action_z = _prior_z(
            float(margin),
            self._action_count,
            self._action_center,
            self._action_m2,
            self.minimum_streaming_candidates,
        )
        stopping_z = _prior_z(
            stop_score,
            self._stop_count,
            self._stop_center,
            self._stop_m2,
            self.minimum_streaming_candidates,
        )
        self._action_count, self._action_center, self._action_m2 = _updated_stats(
            float(margin),
            self._action_count,
            self._action_center,
            self._action_m2,
        )
        self._stop_count, self._stop_center, self._stop_m2 = _updated_stats(
            stop_score,
            self._stop_count,
            self._stop_center,
            self._stop_m2,
        )
        self._previous_max_margin = max(self._previous_max_margin, float(margin))
        if (
            self._candidate_count <= self.minimum_streaming_candidates
            or action_z <= self.action_z_threshold
            or stopping_z <= self.stopping_z_threshold
        ):
            return incumbent_action
        self._interventions_used = 1
        return selected

    def as_dict(self) -> Dict[str, Any]:
        value = {
            "version": STREAMING_STOPPING_VERSION,
            "program_candidate_id": self.program.candidate_id,
            "action_model": self.action_model.as_dict(),
            "stopping_model": self.stopping_model.as_dict(),
            "include_candidate_representation": (
                self.include_candidate_representation
            ),
            "action_z_threshold": self.action_z_threshold,
            "stopping_z_threshold": self.stopping_z_threshold,
            "minimum_item_index": self.minimum_item_index,
            "minimum_streaming_candidates": self.minimum_streaming_candidates,
            "maximum_interventions": 1,
            "deployment_enabled": self.deployment_enabled,
            "incumbent": "funsearch_or_reference",
        }
        return {**value, "policy_id": content_digest(value), "name": self.name}

    @classmethod
    def from_dict(
        cls,
        *,
        program: GeneratedPolicyModuleProgram,
        value: Mapping[str, Any],
    ) -> "StreamingTwoHeadStoppingPolicy":
        if value.get("version") != STREAMING_STOPPING_VERSION:
            raise ValueError("unsupported streaming stopping policy version")
        if value.get("program_candidate_id") != program.candidate_id:
            raise ValueError("streaming stopping program identity mismatch")
        if value.get("incumbent") != "funsearch_or_reference":
            raise ValueError("unsupported streaming stopping incumbent")
        if int(value.get("maximum_interventions", -1)) != 1:
            raise ValueError("streaming stopping budget mismatch")
        policy = cls(
            program=program,
            action_model=LinearAdvantageModel.from_dict(value["action_model"]),
            stopping_model=LinearAdvantageModel.from_dict(
                value["stopping_model"]
            ),
            include_candidate_representation=bool(
                value["include_candidate_representation"]
            ),
            action_z_threshold=float(value["action_z_threshold"]),
            stopping_z_threshold=float(value["stopping_z_threshold"]),
            minimum_item_index=int(value["minimum_item_index"]),
            minimum_streaming_candidates=int(
                value["minimum_streaming_candidates"]
            ),
            deployment_enabled=bool(value["deployment_enabled"]),
            name=str(value.get("name", "frozen_streaming_stopping")),
        )
        supplied_id = value.get("policy_id")
        if supplied_id is not None and supplied_id != policy.as_dict()["policy_id"]:
            raise ValueError("streaming stopping policy identity mismatch")
        return policy


def evaluate_streaming_policy(
    instances: Sequence[BinPackingInstance],
    policy: StreamingTwoHeadStoppingPolicy,
) -> Mapping[str, Any]:
    incumbent = literature_heuristics()["funsearch_or_reference"]
    improvements = []
    interventions = []
    incumbent_counts = []
    candidate_counts = []
    for instance in instances:
        incumbent_bins = pack(instance, incumbent).bin_count
        candidate_bins = pack(instance, policy).bin_count
        incumbent_counts.append(incumbent_bins)
        candidate_counts.append(candidate_bins)
        improvements.append(float(incumbent_bins - candidate_bins))
        interventions.append(policy.interventions_used)
    evidence = paired_episode_evidence(
        improvements,
        tuple(instance.instance_id for instance in instances),
    )
    by_length: Dict[int, list[float]] = {}
    for instance, improvement in zip(instances, improvements):
        by_length.setdefault(len(instance.items), []).append(improvement)
    return {
        "evidence": evidence.as_dict(),
        "incumbent_mean_bins": mean(incumbent_counts),
        "candidate_mean_bins": mean(candidate_counts),
        "aggregate_interventions": sum(interventions),
        "mean_interventions_per_episode": mean(interventions),
        "maximum_interventions_in_episode": max(interventions),
        "aggregate_improvement_by_length": {
            str(length): sum(values)
            for length, values in sorted(by_length.items())
        },
        "mean_improvement_by_length": {
            str(length): mean(values)
            for length, values in sorted(by_length.items())
        },
    }


def _crossfit_mode(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: StreamingStoppingConfig,
    *,
    include_candidate_representation: bool,
    seed: int,
) -> Tuple[StreamingTwoHeadStoppingPolicy, Mapping[str, Any]]:
    controller = config.controller
    folds = _stratified_folds(corpus, controller.fold_count)
    development = corpus.split_instances("development")
    instance_by_id = {instance.instance_id: instance for instance in development}
    all_ids = set(instance_by_id)
    configurations: Tuple[Optional[Tuple[float, float]], ...] = (
        None,
        *(
            (action, stopping)
            for action in controller.action_margin_quantiles
            for stopping in controller.episode_max_score_quantiles
        ),
    )
    results: Dict[Optional[Tuple[float, float]], list[Mapping[str, Any]]] = {
        value: [] for value in configurations
    }
    fold_reports = []
    mode = "representation" if include_candidate_representation else "generic"
    for fold_index, holdout_ids in enumerate(folds):
        holdout_set = set(holdout_ids)
        training = tuple(
            instance_by_id[value]
            for value in sorted(all_ids.difference(holdout_set))
        )
        holdout = tuple(instance_by_id[value] for value in holdout_ids)
        action_model, stopping_model, scanned, fit_report = _fit_bundle(
            program,
            corpus,
            labels,
            controller,
            training,
            include_candidate_representation=include_candidate_representation,
            seed=seed + fold_index,
        )
        thresholds = _streaming_thresholds(
            training,
            scanned,
            stopping_model,
            config,
        )
        fold_reports.append(
            {
                "fold_index": fold_index,
                "holdout_instance_ids": list(holdout_ids),
                "fit": fit_report,
                "streaming_thresholds": {
                    "action_q%.3f_stop_q%.3f" % key: list(value)
                    for key, value in thresholds.items()
                },
            }
        )
        for candidate in configurations:
            action_threshold, stopping_threshold = (
                (0.0, 0.0) if candidate is None else thresholds[candidate]
            )
            policy = StreamingTwoHeadStoppingPolicy(
                program=program,
                action_model=action_model,
                stopping_model=stopping_model,
                include_candidate_representation=include_candidate_representation,
                action_z_threshold=action_threshold,
                stopping_z_threshold=stopping_threshold,
                minimum_item_index=corpus.config.minimum_history_items,
                minimum_streaming_candidates=config.minimum_streaming_candidates,
                deployment_enabled=candidate is not None,
                name="streaming_%s_fold%d" % (mode, fold_index),
            )
            results[candidate].append(
                {
                    "fold_index": fold_index,
                    "action_z_threshold": action_threshold,
                    "stopping_z_threshold": stopping_threshold,
                    "audit": evaluate_streaming_policy(holdout, policy),
                }
            )

    attempts = []
    eligible_attempts = []
    for candidate in configurations:
        fold_results = results[candidate]
        by_id: Dict[str, float] = {}
        intervention_count = 0
        for fold, fold_result in zip(folds, fold_results):
            values = fold_result["audit"]["evidence"]["improvements"]
            by_id.update(zip(fold, values))
            intervention_count += fold_result["audit"]["aggregate_interventions"]
        improvements = tuple(by_id[instance.instance_id] for instance in development)
        evidence = paired_episode_evidence(
            improvements,
            tuple(instance.instance_id for instance in development),
        )
        by_length: Dict[int, list[float]] = {}
        for instance, improvement in zip(development, improvements):
            by_length.setdefault(len(instance.items), []).append(improvement)
        length_aggregates = {
            str(length): sum(values)
            for length, values in sorted(by_length.items())
        }
        fold_aggregates = tuple(
            value["audit"]["evidence"]["aggregate_improvement"]
            for value in fold_results
        )
        eligible = bool(
            candidate is not None
            and evidence.aggregate_improvement > 0.0
            and evidence.wins > evidence.losses
            and min(fold_aggregates) >= 0.0
            and min(length_aggregates.values()) >= 0.0
        )
        rank = (
            min(length_aggregates.values()),
            min(fold_aggregates),
            evidence.aggregate_improvement,
            evidence.wins - evidence.losses,
            -intervention_count,
            -1.0 if candidate is None else candidate[0] + candidate[1],
        )
        attempt = {
            "action_stream_quantile": None if candidate is None else candidate[0],
            "episode_max_stop_stream_quantile": (
                None if candidate is None else candidate[1]
            ),
            "eligible": eligible,
            "pooled_evidence": evidence.as_dict(),
            "fold_aggregates": list(fold_aggregates),
            "aggregate_improvement_by_length": length_aggregates,
            "aggregate_interventions": intervention_count,
            "fold_results": fold_results,
            "selection_rank": list(rank),
        }
        attempts.append(attempt)
        if eligible:
            eligible_attempts.append((rank, candidate, attempt))
    selected_rank, selected_config, selected_attempt = (
        max(eligible_attempts, key=lambda item: item[0])
        if eligible_attempts
        else ((0.0,) * 6, None, attempts[0])
    )
    action_model, stopping_model, scanned, fit_report = _fit_bundle(
        program,
        corpus,
        labels,
        controller,
        development,
        include_candidate_representation=include_candidate_representation,
        seed=seed + controller.fold_count + 100_000,
    )
    thresholds = _streaming_thresholds(
        development,
        scanned,
        stopping_model,
        config,
    )
    action_threshold, stopping_threshold = (
        (0.0, 0.0)
        if selected_config is None
        else thresholds[selected_config]
    )
    policy = StreamingTwoHeadStoppingPolicy(
        program=program,
        action_model=action_model,
        stopping_model=stopping_model,
        include_candidate_representation=include_candidate_representation,
        action_z_threshold=action_threshold,
        stopping_z_threshold=stopping_threshold,
        minimum_item_index=corpus.config.minimum_history_items,
        minimum_streaming_candidates=config.minimum_streaming_candidates,
        deployment_enabled=selected_config is not None,
        name="streaming_%s_%s" % (program.hypothesis_id[:8], mode),
    )
    return policy, {
        "mode": mode,
        "fold_count": controller.fold_count,
        "folds": fold_reports,
        "attempts": attempts,
        "selected_crossfit_attempt": selected_attempt,
        "crossfit_eligible": selected_attempt["eligible"],
        "selection_rank": list(selected_rank),
        "final_fit": fit_report,
        "selected_policy": policy.as_dict(),
    }


def _difference(
    instances: Sequence[BinPackingInstance],
    left: Mapping[str, Any],
    right: Mapping[str, Any],
) -> Mapping[str, Any]:
    values = tuple(
        float(left_value - right_value)
        for left_value, right_value in zip(
            left["evidence"]["improvements"],
            right["evidence"]["improvements"],
        )
    )
    return paired_episode_evidence(
        values,
        tuple(instance.instance_id for instance in instances),
    ).as_dict()


@dataclass(frozen=True)
class StreamingStoppingResult:
    report: Mapping[str, Any]
    generic_policy: StreamingTwoHeadStoppingPolicy
    representation_policy: StreamingTwoHeadStoppingPolicy

    @property
    def promoted(self) -> bool:
        return bool(self.report["promotion_gate"]["passed"])


def assess_streaming_stopping_controller(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    config: StreamingStoppingConfig = StreamingStoppingConfig(),
) -> StreamingStoppingResult:
    if set(labels.report.get("labeled_splits", ())) != {"development"}:
        raise ValueError("streaming stopping accepts development labels only")
    generic, generic_crossfit = _crossfit_mode(
        program,
        corpus,
        labels,
        config,
        include_candidate_representation=False,
        seed=corpus.config.base_seed + 341_000,
    )
    representation, representation_crossfit = _crossfit_mode(
        program,
        corpus,
        labels,
        config,
        include_candidate_representation=True,
        seed=corpus.config.base_seed + 367_000,
    )
    validation = corpus.split_instances("adaptive_validation")
    generic_audit = evaluate_streaming_policy(validation, generic)
    representation_audit = evaluate_streaming_policy(validation, representation)
    difference = _difference(validation, representation_audit, generic_audit)
    evidence = representation_audit["evidence"]
    reasons = []
    if not representation_crossfit["crossfit_eligible"]:
        reasons.append("streaming_representation_not_crossfit_stable")
    if evidence["mean_improvement_ci_lower"] <= 0.0:
        reasons.append("validation_improvement_confidence_interval_includes_zero")
    if min(representation_audit["aggregate_improvement_by_length"].values()) < 0.0:
        reasons.append("at_least_one_validation_length_regressed")
    if difference["mean_improvement_ci_lower"] <= 0.0:
        reasons.append("streaming_representation_gain_over_generic_not_established")
    if evidence["maximum_regression"] > config.controller.maximum_regression:
        reasons.append("maximum_episode_regression_exceeds_limit")
    report: Dict[str, Any] = {
        "schema": 1,
        "version": STREAMING_STOPPING_VERSION,
        "candidate_id": program.candidate_id,
        "hypothesis_id": program.hypothesis_id,
        "corpus_id": corpus.report["corpus_id"],
        "target_distribution": corpus.report.get("target_distribution"),
        "terminal_label_set_id": labels.report["label_set_id"],
        "config": config.as_dict(),
        "adaptive_or_sealed_labels_used_for_fitting": False,
        "sealed_episodes_accessed": False,
        "generic_crossfit": generic_crossfit,
        "candidate_representation_crossfit": representation_crossfit,
        "adaptive_validation": {
            "generic": generic_audit,
            "candidate_representation": representation_audit,
            "candidate_minus_generic": difference,
        },
        "promotion_gate": {
            "passed": not reasons,
            "reasons": reasons,
        },
    }
    report["assessment_id"] = content_digest(report)
    return StreamingStoppingResult(report, generic, representation)
