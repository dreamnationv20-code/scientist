from __future__ import annotations

import random
from typing import Any, Dict, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.first_principles_oracle import exact_action_values
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.representation_capacity import (
    RepresentationCapacityConfig,
    RepresentationCorpus,
    RepresentationProbe,
    _action_ref,
    _apply_action,
)


TARGET_IID_CORPUS_VERSION = "binpacking-target-iid-representation-corpus-v1"
_SPLITS = ("development", "adaptive_validation", "sealed_audit")


def _iid_items(
    *,
    length: int,
    seed: int,
    item_low: int,
    item_high: int,
) -> Tuple[int, ...]:
    rng = random.Random(seed)
    return tuple(rng.randint(item_low, item_high) for _ in range(length))


def _instances(
    config: RepresentationCapacityConfig,
    *,
    item_low: int,
    item_high: int,
) -> Tuple[BinPackingInstance, ...]:
    split_counts = (
        ("development", config.development_instances, 1_100_000_000),
        (
            "adaptive_validation",
            config.adaptive_validation_instances,
            1_300_000_000,
        ),
        ("sealed_audit", config.sealed_audit_instances, 1_700_000_000),
    )
    result = []
    for split, count, offset in split_counts:
        for index in range(count):
            length = config.sequence_lengths[index % len(config.sequence_lengths)]
            length_index = config.sequence_lengths.index(length)
            seed = config.base_seed + offset + length_index * 10_000_000 + index
            result.append(
                BinPackingInstance(
                    instance_id=(
                        "representation-%s-iid_or_uniform-n%d-%03d"
                        % (split, length, index)
                    ),
                    family="iid_or_uniform_20_100",
                    seed=seed,
                    capacity=config.capacity,
                    items=_iid_items(
                        length=length,
                        seed=seed,
                        item_low=item_low,
                        item_high=item_high,
                    ),
                )
            )
    return tuple(result)


def build_target_iid_representation_corpus(
    config: RepresentationCapacityConfig,
    *,
    item_low: int = 20,
    item_high: int = 100,
) -> RepresentationCorpus:
    """Build target-distribution splits with trajectory-spanning probes."""

    if not 0 < item_low <= item_high <= config.capacity:
        raise ValueError("invalid target IID item range")
    counts = (
        config.development_instances,
        config.adaptive_validation_instances,
        config.sealed_audit_instances,
    )
    if any(count % len(config.sequence_lengths) for count in counts):
        raise ValueError("target IID split counts must balance sequence lengths")
    incumbent = literature_heuristics()["funsearch_or_reference"]
    instances = _instances(
        config,
        item_low=item_low,
        item_high=item_high,
    )
    probes = []
    split_by_instance = {}
    for instance in instances:
        split = next(
            value
            for value in _SPLITS
            if instance.instance_id.startswith("representation-%s-" % value)
        )
        split_by_instance[instance.instance_id] = split
        first = config.minimum_history_items
        last = len(instance.items) - 2
        selected_indices = {
            int(
                round(
                    first
                    + rank
                    * (last - first)
                    / float(config.probes_per_instance - 1)
                )
            )
            for rank in range(config.probes_per_instance)
        }
        loads: Tuple[int, ...] = ()
        history: Tuple[int, ...] = ()
        for item_index, item in enumerate(instance.items):
            incumbent_action = incumbent.choose_bin(
                item,
                loads,
                instance.capacity,
                item_index,
                history,
            )
            if item_index in selected_indices and item_index + 1 < len(instance.items):
                values = exact_action_values(
                    item=item,
                    loads=loads,
                    remaining_items=instance.items[
                        item_index + 1 :
                        item_index + 1 + config.exact_suffix_horizon
                    ],
                    capacity=instance.capacity,
                )
                action_values = tuple(
                    (_action_ref(action), int(value))
                    for action, value in values.items()
                )
                probe_body = {
                    "version": TARGET_IID_CORPUS_VERSION,
                    "split": split,
                    "instance_id": instance.instance_id,
                    "item_index": item_index,
                    "item": item,
                    "loads": list(loads),
                    "history": list(history[-128:]),
                    "action_values": action_values,
                    "incumbent_action_ref": _action_ref(incumbent_action),
                }
                probes.append(
                    RepresentationProbe(
                        probe_id=content_digest(probe_body),
                        split=split,
                        instance_id=instance.instance_id,
                        family=instance.family,
                        item=item,
                        loads=loads,
                        capacity=instance.capacity,
                        item_index=item_index,
                        history=history[-128:],
                        action_values=action_values,
                        incumbent_action_ref=_action_ref(incumbent_action),
                        remaining_items=instance.items[item_index + 1 :],
                    )
                )
            loads = _apply_action(
                incumbent_action,
                item,
                loads,
                instance.capacity,
            )
            history = (*history, item)

    split_reports = {}
    for split in _SPLITS:
        selected_instances = tuple(
            instance
            for instance in instances
            if split_by_instance[instance.instance_id] == split
        )
        selected_probes = tuple(probe for probe in probes if probe.split == split)
        split_reports[split] = {
            "instance_count": len(selected_instances),
            "probe_count": len(selected_probes),
            "incumbent_opportunity_count": sum(
                probe.incumbent_regret > 0 for probe in selected_probes
            ),
            "aggregate_incumbent_regret": sum(
                probe.incumbent_regret for probe in selected_probes
            ),
            "families": ["iid_or_uniform_20_100"],
            "sequence_lengths": sorted(
                {len(instance.items) for instance in selected_instances}
            ),
            "seed_commitment": content_digest(
                sorted(instance.seed for instance in selected_instances)
            ),
        }
    report: Dict[str, Any] = {
        "schema": 1,
        "version": TARGET_IID_CORPUS_VERSION,
        "config": config.as_dict(),
        "target_distribution": {
            "kind": "iid_discrete_uniform",
            "item_low_inclusive": item_low,
            "item_high_inclusive": item_high,
            "capacity": config.capacity,
        },
        "trajectory_policy": "funsearch_or_reference",
        "candidate_future_access": False,
        "split_reports": split_reports,
        "split_instance_ids_disjoint": True,
        "sealed_labels_available_to_fitting": False,
    }
    report["corpus_id"] = content_digest(
        {**report, "probe_ids": [probe.probe_id for probe in probes]}
    )
    return RepresentationCorpus(config, instances, tuple(probes), report)
