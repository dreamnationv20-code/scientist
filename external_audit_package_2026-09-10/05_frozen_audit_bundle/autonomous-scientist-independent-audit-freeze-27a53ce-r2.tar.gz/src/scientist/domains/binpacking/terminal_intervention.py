from __future__ import annotations

from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.code_policy import GeneratedPolicyModuleProgram
from scientist.domains.binpacking.heuristics import OnlineHeuristic, literature_heuristics, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.representation_capacity import (
    AdvantageTrainingExample,
    LinearAdvantageModel,
    RepresentationCorpus,
    RepresentationProbe,
    fit_linear_advantage_model,
    observable_action_features,
)
from scientist.program.discovery_evidence import paired_episode_evidence


TERMINAL_INTERVENTION_VERSION = "de-novo-terminal-intervention-credit-v1"


def _action_ref(action: Optional[int]) -> str:
    return "new" if action is None else "bin:%d" % int(action)


def _parse_action(action_ref: str) -> Optional[int]:
    if action_ref == "new":
        return None
    if not action_ref.startswith("bin:"):
        raise ValueError("invalid terminal-intervention action reference")
    return int(action_ref.split(":", 1)[1])


def _legal_actions(
    item: int, loads: Sequence[int], capacity: int
) -> Tuple[Optional[int], ...]:
    return (
        *(
            index
            for index, load in enumerate(loads)
            if load + item <= capacity
        ),
        None,
    )


def _apply_action(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    if action is None:
        return (*loads, item)
    if action < 0 or action >= len(loads) or loads[action] + item > capacity:
        raise ValueError("terminal intervention action is illegal")
    updated = list(loads)
    updated[action] += item
    return tuple(updated)


def _signature(
    action: Optional[int],
    item: int,
    loads: Sequence[int],
    capacity: int,
) -> Tuple[int, ...]:
    return tuple(sorted(_apply_action(action, item, loads, capacity), reverse=True))


def _terminal_after_single_intervention(
    probe: RepresentationProbe,
    action_ref: str,
    continuation: OnlineHeuristic,
) -> int:
    action = _parse_action(action_ref)
    loads = _apply_action(action, probe.item, probe.loads, probe.capacity)
    history = (*probe.history, probe.item)
    item_index = probe.item_index + 1
    for item in probe.remaining_items:
        next_action = continuation.choose_bin(
            item,
            loads,
            probe.capacity,
            item_index,
            history,
        )
        loads = _apply_action(next_action, item, loads, probe.capacity)
        history = (*history, item)[-128:]
        item_index += 1
    return len(loads)


@dataclass(frozen=True)
class TerminalInterventionLabel:
    probe_id: str
    split: str
    instance_id: str
    action_terminal_bins: Tuple[Tuple[str, int], ...]
    incumbent_action_ref: str

    @property
    def values(self) -> Mapping[str, int]:
        return dict(self.action_terminal_bins)

    @property
    def incumbent_terminal_bins(self) -> int:
        return self.values[self.incumbent_action_ref]

    @property
    def best_advantage(self) -> int:
        values = self.values
        return self.incumbent_terminal_bins - min(values.values())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe_id": self.probe_id,
            "split": self.split,
            "instance_id": self.instance_id,
            "action_terminal_bins": [
                {"action_ref": action_ref, "terminal_bins": bins}
                for action_ref, bins in self.action_terminal_bins
            ],
            "incumbent_action_ref": self.incumbent_action_ref,
            "best_terminal_intervention_advantage": self.best_advantage,
        }


@dataclass(frozen=True)
class TerminalInterventionLabels:
    labels: Tuple[TerminalInterventionLabel, ...]
    report: Mapping[str, Any]

    def split(self, name: str) -> Tuple[TerminalInterventionLabel, ...]:
        return tuple(label for label in self.labels if label.split == name)


def build_terminal_intervention_labels(
    corpus: RepresentationCorpus,
    *,
    splits: Sequence[str] = (
        "development",
        "adaptive_validation",
        "sealed_audit",
    ),
) -> TerminalInterventionLabels:
    """Credit one forced action by terminal bins after incumbent continuation."""

    selected_splits = tuple(str(split) for split in splits)
    allowed_splits = {
        "development",
        "adaptive_validation",
        "sealed_audit",
    }
    if (
        not selected_splits
        or len(set(selected_splits)) != len(selected_splits)
        or not set(selected_splits).issubset(allowed_splits)
    ):
        raise ValueError("invalid terminal-intervention label splits")
    continuation = literature_heuristics()["funsearch_or_reference"]
    labels = []
    for probe in corpus.probes:
        if probe.split not in selected_splits:
            continue
        terminal_values = tuple(
            (
                action_ref,
                _terminal_after_single_intervention(
                    probe, action_ref, continuation
                ),
            )
            for action_ref, _ in probe.action_values
        )
        labels.append(
            TerminalInterventionLabel(
                probe_id=probe.probe_id,
                split=probe.split,
                instance_id=probe.instance_id,
                action_terminal_bins=terminal_values,
                incumbent_action_ref=probe.incumbent_action_ref,
            )
        )
    split_reports = {}
    for split in selected_splits:
        selected = tuple(label for label in labels if label.split == split)
        split_reports[split] = {
            "probe_count": len(selected),
            "instance_count": len({label.instance_id for label in selected}),
            "terminal_opportunity_count": sum(
                label.best_advantage > 0 for label in selected
            ),
            "terminal_oracle_upper_bound_bins": sum(
                label.best_advantage for label in selected
            ),
        }
    report: Dict[str, Any] = {
        "schema": 1,
        "version": TERMINAL_INTERVENTION_VERSION,
        "corpus_id": corpus.report["corpus_id"],
        "continuation_policy": "funsearch_or_reference",
        "credit_unit": "one_forced_action_then_incumbent_to_terminal",
        "candidate_future_access": False,
        "decision_rows_are_independent_evidence": False,
        "labeled_splits": list(selected_splits),
        "sealed_labels_materialized": "sealed_audit" in selected_splits,
        "split_reports": split_reports,
        "sealed_labels_available_during_model_or_policy_selection": False,
    }
    report["label_set_id"] = content_digest(
        {
            **report,
            "label_ids": [content_digest(label.as_dict()) for label in labels],
        }
    )
    return TerminalInterventionLabels(tuple(labels), report)


def _training_examples(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    *,
    include_candidate_representation: bool,
) -> Tuple[AdvantageTrainingExample, ...]:
    probe_by_id = {probe.probe_id: probe for probe in corpus.probes}
    examples = []
    for label in labels.split("development"):
        probe = probe_by_id[label.probe_id]
        values = label.values
        incumbent_value = label.incumbent_terminal_bins
        informative = len(set(values.values())) > 1
        for action_ref, terminal_bins in label.action_terminal_bins:
            examples.append(
                AdvantageTrainingExample(
                    state_id=probe.probe_id,
                    instance_id=probe.instance_id,
                    action_ref=action_ref,
                    features=observable_action_features(
                        program,
                        probe,
                        action_ref,
                        include_candidate_representation=(
                            include_candidate_representation
                        ),
                    ),
                    advantage=float(incumbent_value - terminal_bins),
                    informative=informative,
                )
            )
    return tuple(examples)


def _online_probe(
    incumbent: OnlineHeuristic,
    item: int,
    loads: Sequence[int],
    capacity: int,
    item_index: int,
    history: Sequence[int],
) -> RepresentationProbe:
    incumbent_action = incumbent.choose_bin(
        item, loads, capacity, item_index, history
    )
    actions = _legal_actions(item, loads, capacity)
    return RepresentationProbe(
        probe_id="online",
        split="development",
        instance_id="online",
        family="online",
        item=item,
        loads=tuple(loads),
        capacity=capacity,
        item_index=item_index,
        history=tuple(history[-128:]),
        action_values=tuple((_action_ref(action), 0) for action in actions),
        incumbent_action_ref=_action_ref(incumbent_action),
    )


def _scored_action(
    model: LinearAdvantageModel,
    program: GeneratedPolicyModuleProgram,
    probe: RepresentationProbe,
    *,
    include_candidate_representation: bool,
) -> Tuple[str, float]:
    scored = []
    incumbent_score = None
    for order, (action_ref, _) in enumerate(probe.action_values):
        score = model.predict(
            observable_action_features(
                program,
                probe,
                action_ref,
                include_candidate_representation=(
                    include_candidate_representation
                ),
            )
        )
        scored.append((score, -order, action_ref))
        if action_ref == probe.incumbent_action_ref:
            incumbent_score = score
    if incumbent_score is None:
        raise ValueError("incumbent action was not legal")
    best_score, _, best_action = max(scored, key=lambda row: (row[0], row[1]))
    return best_action, float(best_score - incumbent_score)


class TerminalInterventionPolicy:
    """A conservative stateful overlay whose budget resets each episode."""

    def __init__(
        self,
        *,
        program: GeneratedPolicyModuleProgram,
        model: LinearAdvantageModel,
        include_candidate_representation: bool,
        threshold: float,
        maximum_interventions: int,
        cooldown: int,
        minimum_item_index: int,
        name: str,
    ) -> None:
        if maximum_interventions < 0 or cooldown < 0 or minimum_item_index < 0:
            raise ValueError("invalid terminal intervention deployment controls")
        self.program = program
        self.model = model
        self.include_candidate_representation = bool(
            include_candidate_representation
        )
        self.threshold = float(threshold)
        self.maximum_interventions = int(maximum_interventions)
        self.cooldown = int(cooldown)
        self.minimum_item_index = int(minimum_item_index)
        self.name = str(name)
        self.incumbent = literature_heuristics()["funsearch_or_reference"]
        self._last_seen_index = -1
        self._last_intervention_index = -10**9
        self._interventions_used = 0

    @property
    def interventions_used(self) -> int:
        return self._interventions_used

    def _reset_if_new_episode(self, item_index: int) -> None:
        if item_index == 0 or item_index <= self._last_seen_index:
            self._last_intervention_index = -10**9
            self._interventions_used = 0
        self._last_seen_index = item_index

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        self._reset_if_new_episode(item_index)
        incumbent_action = self.incumbent.choose_bin(
            item, loads, capacity, item_index, history
        )
        if (
            self._interventions_used >= self.maximum_interventions
            or item_index < self.minimum_item_index
            or item_index - self._last_intervention_index < self.cooldown
        ):
            return incumbent_action
        probe = _online_probe(
            self.incumbent,
            item,
            loads,
            capacity,
            item_index,
            history,
        )
        selected_ref, margin = _scored_action(
            self.model,
            self.program,
            probe,
            include_candidate_representation=(
                self.include_candidate_representation
            ),
        )
        selected = _parse_action(selected_ref)
        if (
            margin <= self.threshold
            or _signature(selected, item, loads, capacity)
            == _signature(incumbent_action, item, loads, capacity)
        ):
            return incumbent_action
        self._interventions_used += 1
        self._last_intervention_index = item_index
        return selected

    def as_dict(self) -> Dict[str, Any]:
        value = {
            "version": TERMINAL_INTERVENTION_VERSION,
            "program_candidate_id": self.program.candidate_id,
            "model": self.model.as_dict(),
            "include_candidate_representation": (
                self.include_candidate_representation
            ),
            "threshold": self.threshold,
            "maximum_interventions": self.maximum_interventions,
            "cooldown": self.cooldown,
            "minimum_item_index": self.minimum_item_index,
            "incumbent": "funsearch_or_reference",
        }
        return {**value, "policy_id": content_digest(value), "name": self.name}

    @classmethod
    def from_dict(
        cls,
        *,
        program: GeneratedPolicyModuleProgram,
        value: Mapping[str, Any],
    ) -> "TerminalInterventionPolicy":
        if value.get("version") != TERMINAL_INTERVENTION_VERSION:
            raise ValueError("unsupported terminal-intervention policy version")
        if value.get("program_candidate_id") != program.candidate_id:
            raise ValueError("terminal-intervention program identity mismatch")
        if value.get("incumbent") != "funsearch_or_reference":
            raise ValueError("unsupported terminal-intervention incumbent")
        policy = cls(
            program=program,
            model=LinearAdvantageModel.from_dict(value["model"]),
            include_candidate_representation=bool(
                value["include_candidate_representation"]
            ),
            threshold=float(value["threshold"]),
            maximum_interventions=int(value["maximum_interventions"]),
            cooldown=int(value["cooldown"]),
            minimum_item_index=int(value["minimum_item_index"]),
            name=str(value.get("name", "frozen_terminal_intervention")),
        )
        supplied_id = value.get("policy_id")
        observed_id = policy.as_dict()["policy_id"]
        if supplied_id is not None and supplied_id != observed_id:
            raise ValueError("terminal-intervention policy identity mismatch")
        return policy


def _episode_evidence(
    instances: Sequence[BinPackingInstance],
    policy: TerminalInterventionPolicy,
) -> Mapping[str, Any]:
    incumbent = literature_heuristics()["funsearch_or_reference"]
    improvements = []
    intervention_counts = []
    for instance in instances:
        incumbent_bins = pack(instance, incumbent).bin_count
        candidate_bins = pack(instance, policy).bin_count
        improvements.append(float(incumbent_bins - candidate_bins))
        intervention_counts.append(policy.interventions_used)
    evidence = paired_episode_evidence(
        improvements,
        tuple(instance.instance_id for instance in instances),
    )
    by_length: Dict[int, list[float]] = {}
    for instance, improvement in zip(instances, improvements):
        by_length.setdefault(len(instance.items), []).append(improvement)
    return {
        "evidence": evidence.as_dict(),
        "intervention_counts": intervention_counts,
        "aggregate_interventions": sum(intervention_counts),
        "mean_interventions_per_episode": mean(intervention_counts),
        "mean_improvement_by_length": {
            str(length): mean(values)
            for length, values in sorted(by_length.items())
        },
    }


def _margin_thresholds(
    model: LinearAdvantageModel,
    program: GeneratedPolicyModuleProgram,
    probes: Sequence[RepresentationProbe],
    *,
    include_candidate_representation: bool,
) -> Tuple[float, ...]:
    margins = sorted(
        margin
        for probe in probes
        for _, margin in (
            _scored_action(
                model,
                program,
                probe,
                include_candidate_representation=(
                    include_candidate_representation
                ),
            ),
        )
        if margin > 0.0
    )
    if not margins:
        return (0.0,)
    values = {0.0}
    for fraction in (0.5, 0.75, 0.9):
        index = int(round(fraction * (len(margins) - 1)))
        values.add(margins[index])
    return tuple(sorted(values))


def _fit_and_select_mode(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
    *,
    include_candidate_representation: bool,
    seed: int,
) -> Tuple[TerminalInterventionPolicy, Mapping[str, Any]]:
    examples = _training_examples(
        program,
        corpus,
        labels,
        include_candidate_representation=include_candidate_representation,
    )
    model_configs = (
        (42, 0.0022, 0.001, 3.0),
        (58, 0.0015, 0.003, 6.0),
        (74, 0.0010, 0.01, 10.0),
    )
    validation_instances = corpus.split_instances("adaptive_validation")
    validation_probes = corpus.split("adaptive_validation")
    attempts = []
    best = None
    mode = "representation" if include_candidate_representation else "generic"

    # Abstention is a real candidate: it exactly reproduces the incumbent.
    for model_index, (epochs, rate, ridge, weight) in enumerate(model_configs):
        model = fit_linear_advantage_model(
            examples,
            seed=seed + model_index,
            epochs=epochs,
            learning_rate=rate,
            ridge=ridge,
            informative_weight=weight,
        )
        deployment_configs = [
            (0.0, 0, 0),
            *(
                (threshold, budget, cooldown)
                for threshold in _margin_thresholds(
                    model,
                    program,
                    validation_probes,
                    include_candidate_representation=(
                        include_candidate_representation
                    ),
                )
                for budget in (1, 2, 3)
                for cooldown in (48, 96)
            ),
        ]
        for threshold, budget, cooldown in deployment_configs:
            policy = TerminalInterventionPolicy(
                program=program,
                model=model,
                include_candidate_representation=(
                    include_candidate_representation
                ),
                threshold=threshold,
                maximum_interventions=budget,
                cooldown=cooldown,
                minimum_item_index=corpus.config.minimum_history_items,
                name="terminal_%s_%s" % (program.hypothesis_id[:8], mode),
            )
            validation = _episode_evidence(validation_instances, policy)
            evidence = validation["evidence"]
            rank = (
                evidence["aggregate_improvement"],
                evidence["wins"] - evidence["losses"],
                -evidence["maximum_regression"],
                -validation["aggregate_interventions"],
                -budget,
                -cooldown,
            )
            attempt = {
                "policy": policy,
                "validation": validation,
                "rank": rank,
            }
            attempts.append(
                {
                    "model_id": model.as_dict()["model_id"],
                    "threshold": threshold,
                    "maximum_interventions": budget,
                    "cooldown": cooldown,
                    "validation": validation,
                }
            )
            if best is None or rank > best[0]:
                best = (rank, attempt)
    if best is None:
        raise RuntimeError("terminal intervention selection produced no policy")
    selected = best[1]
    policy = selected["policy"]
    return policy, {
        "mode": mode,
        "training_example_count": len(examples),
        "training_instance_count": len(
            {example.instance_id for example in examples}
        ),
        "decision_rows_are_independent_evidence": False,
        "attempt_count": len(attempts),
        "selected_policy": policy.as_dict(),
        "adaptive_validation": selected["validation"],
        "selection_rank": list(best[0]),
    }


@dataclass(frozen=True)
class TerminalInterventionResult:
    report: Mapping[str, Any]
    generic_policy: TerminalInterventionPolicy
    representation_policy: TerminalInterventionPolicy


def assess_terminal_intervention_credit(
    program: GeneratedPolicyModuleProgram,
    corpus: RepresentationCorpus,
    labels: TerminalInterventionLabels,
) -> TerminalInterventionResult:
    """Fit on terminal marginal credit and select only by complete episodes."""

    generic_policy, generic_selection = _fit_and_select_mode(
        program,
        corpus,
        labels,
        include_candidate_representation=False,
        seed=corpus.config.base_seed + 41_000,
    )
    representation_policy, representation_selection = _fit_and_select_mode(
        program,
        corpus,
        labels,
        include_candidate_representation=True,
        seed=corpus.config.base_seed + 67_000,
    )
    # No sealed label or episode is accessed before both policies are frozen.
    sealed_instances = corpus.split_instances("sealed_audit")
    generic_sealed = _episode_evidence(sealed_instances, generic_policy)
    representation_sealed = _episode_evidence(
        sealed_instances, representation_policy
    )
    generic_aggregate = generic_sealed["evidence"]["aggregate_improvement"]
    representation_aggregate = representation_sealed["evidence"][
        "aggregate_improvement"
    ]
    report: Dict[str, Any] = {
        "schema": 1,
        "version": TERMINAL_INTERVENTION_VERSION,
        "candidate_id": program.candidate_id,
        "hypothesis_id": program.hypothesis_id,
        "corpus_id": corpus.report["corpus_id"],
        "terminal_label_set_id": labels.report["label_set_id"],
        "candidate_future_access": False,
        "credit_unit": "one_forced_action_then_funsearch_to_terminal",
        "deployment_selection_unit": "complete_episode",
        "sealed_labels_available_during_selection": False,
        "generic_selection": generic_selection,
        "candidate_representation_selection": representation_selection,
        "sealed_episode_audit": {
            "generic": generic_sealed,
            "candidate_representation": representation_sealed,
            "candidate_minus_generic_aggregate_improvement": (
                representation_aggregate - generic_aggregate
            ),
        },
        "representation_adds_sealed_terminal_value": bool(
            representation_aggregate > generic_aggregate
        ),
        "representation_beats_incumbent_on_sealed_episodes": bool(
            representation_aggregate > 0.0
        ),
    }
    report["assessment_id"] = content_digest(report)
    return TerminalInterventionResult(
        report=report,
        generic_policy=generic_policy,
        representation_policy=representation_policy,
    )
