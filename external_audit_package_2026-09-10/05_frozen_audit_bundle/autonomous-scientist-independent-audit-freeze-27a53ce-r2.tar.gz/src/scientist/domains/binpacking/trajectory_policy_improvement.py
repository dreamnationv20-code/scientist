from __future__ import annotations

import math
import random
from dataclasses import dataclass
from statistics import mean
from typing import Any, Callable, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.closed_loop_de_novo import (
    _abstract_actions,
    _history_sample,
    _post_loads,
    _stable_quantiles,
)
from scientist.domains.binpacking.heuristics import pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.program.discovery_evidence import paired_episode_evidence
from scientist.program.trajectory_improvement import (
    AbsoluteTrajectoryEvaluation,
    FrozenTrajectoryBatch,
    TrajectoryImprovementConfig,
    run_absolute_trajectory_improvement,
)


BINPACKING_TRAJECTORY_POLICY_VERSION = (
    "binpacking-trajectory-value-policy-v2-raw-terminal-return"
)
TRAJECTORY_PARAMETER_NAMES = (
    "planning_horizon",
    "scenario_count",
    "beam_width",
    "tail_risk_weight",
    "dead_capacity_weight",
    "service_coverage_weight",
    "single_completion_reward",
    "pair_completion_reward",
    "residual_market_weight",
    "service_scarcity_weight",
    "residual_dispersion_weight",
)


@dataclass(frozen=True)
class TrajectoryValuePolicy:
    parameters: Tuple[float, ...]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "parameters",
            tuple(float(value) for value in self.parameters),
        )
        if len(self.parameters) != len(TRAJECTORY_PARAMETER_NAMES):
            raise ValueError("trajectory-value policy has the wrong parameter count")
        if not all(math.isfinite(value) for value in self.parameters):
            raise ValueError("trajectory-value parameters must be finite")
        horizon, scenario_count, beam_width = self.parameters[:3]
        if not 1 <= round(horizon) <= 3:
            raise ValueError("trajectory planning horizon must be in [1, 3]")
        if not 3 <= round(scenario_count) <= 7:
            raise ValueError("trajectory scenario count must be in [3, 7]")
        if not 3 <= round(beam_width) <= 8:
            raise ValueError("trajectory beam width must be in [3, 8]")
        if not 0.0 <= self.parameters[3] <= 1.0:
            raise ValueError("trajectory tail-risk weight must be in [0, 1]")
        if any(not 0.0 <= value <= 2.5 for value in self.parameters[4:10]):
            raise ValueError("trajectory state-value weights must be in [0, 2.5]")
        if not -1.5 <= self.parameters[10] <= 1.5:
            raise ValueError("trajectory dispersion weight must be in [-1.5, 1.5]")

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "version": BINPACKING_TRAJECTORY_POLICY_VERSION,
                "parameters": list(self.parameters),
            }
        )

    @property
    def name(self) -> str:
        return "trajectory_value_policy_" + self.candidate_id[:12]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "trajectory_value_policy",
            "version": BINPACKING_TRAJECTORY_POLICY_VERSION,
            "candidate_id": self.candidate_id,
            "name": self.name,
            "parameters": list(self.parameters),
            "parameter_map": dict(zip(TRAJECTORY_PARAMETER_NAMES, self.parameters)),
            "complete_policy": True,
            "full_episode_training_signal": True,
            "incumbent": None,
            "incumbent_blind": True,
            "fallback_policy": None,
            "future_arrivals_available": False,
            "decision_topology": (
                "receding-horizon scenario tree with a trajectory-trained "
                "global terminal-state value"
            ),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TrajectoryValuePolicy":
        if value.get("version") != BINPACKING_TRAJECTORY_POLICY_VERSION:
            raise ValueError("unsupported trajectory-value policy version")
        policy = cls(tuple(float(item) for item in value["parameters"]))
        if value.get("candidate_id") != policy.candidate_id:
            raise ValueError("trajectory-value policy identity mismatch")
        return policy

    def _suffixes(
        self,
        item: int,
        history: Sequence[int],
        capacity: int,
        horizon: int,
        scenario_count: int,
    ) -> Tuple[Tuple[int, ...], ...]:
        observed = _history_sample(item, history, capacity, 64)
        quantiles = _stable_quantiles(observed, min(7, scenario_count))
        starts = _stable_quantiles(tuple(range(len(observed))), scenario_count)
        suffixes = [
            tuple(
                observed[(start + offset) % len(observed)]
                for offset in range(horizon)
            )
            for start in starts
        ]
        suffixes.extend(
            tuple(
                quantiles[(shift + offset) % len(quantiles)]
                for offset in range(horizon)
            )
            for shift in range(len(quantiles))
        )
        return tuple(dict.fromkeys(suffixes))[:scenario_count]

    def _state_context(
        self,
        observed: Sequence[int],
        capacity: int,
    ) -> Dict[str, Any]:
        minimum = min(observed)
        demands = _stable_quantiles(observed, 5)
        support = _stable_quantiles(observed, min(11, len(observed)))
        tolerance = max(1, round(capacity / 75.0))
        single = []
        pair = []
        for residual in range(capacity + 1):
            single.append(
                sum(abs(value - residual) <= tolerance for value in observed)
                / float(len(observed))
            )
            pair.append(
                sum(
                    abs(left + right - residual) <= tolerance
                    for left in support
                    for right in support
                )
                / float(len(support) ** 2)
            )
        band_count = 9
        market_target = [0.0] * band_count
        for value in observed:
            complement = max(0, capacity - value)
            band = min(
                band_count - 1,
                int(band_count * complement / float(capacity + 1)),
            )
            market_target[band] += 1.0 / len(observed)
        return {
            "minimum": minimum,
            "demands": demands,
            "single": tuple(single),
            "pair": tuple(pair),
            "market_target": tuple(market_target),
            "band_count": band_count,
        }

    def _terminal_cost(
        self,
        loads: Sequence[int],
        capacity: int,
        context: Mapping[str, Any],
    ) -> float:
        (
            _,
            _,
            _,
            _,
            dead_weight,
            coverage_weight,
            single_weight,
            pair_weight,
            market_weight,
            scarcity_weight,
            dispersion_weight,
        ) = self.parameters
        residuals = tuple(capacity - load for load in loads)
        positive = tuple(residual for residual in residuals if residual > 0)
        dead_mass = sum(
            residual
            for residual in positive
            if residual < context["minimum"]
        ) / float(capacity)
        uncovered = sum(
            not any(residual >= demand for residual in residuals)
            for demand in context["demands"]
        ) / float(len(context["demands"]))
        completion_denominator = float(max(1, len(positive)))
        single_completion = sum(
            context["single"][residual] for residual in positive
        ) / completion_denominator
        pair_completion = sum(
            context["pair"][residual] for residual in positive
        ) / completion_denominator
        supply = [0.0] * context["band_count"]
        for residual in residuals:
            band = min(
                context["band_count"] - 1,
                int(
                    context["band_count"]
                    * residual
                    / float(capacity + 1)
                ),
            )
            supply[band] += 1.0 / len(residuals)
        market_imbalance = sum(
            abs(actual - target)
            for actual, target in zip(supply, context["market_target"])
        )
        scarcity = sum(
            1.0 / (1.0 + sum(residual >= demand for residual in residuals))
            for demand in context["demands"]
        ) / len(context["demands"])
        residual_mean = sum(residuals) / float(len(residuals))
        dispersion = sum(
            abs(residual - residual_mean) for residual in residuals
        ) / float(len(residuals) * capacity)
        return (
            len(loads)
            + dead_weight * dead_mass
            + coverage_weight * uncovered
            - single_weight * single_completion
            - pair_weight * pair_completion
            + market_weight * market_imbalance
            + scarcity_weight * scarcity
            + dispersion_weight * dispersion
        )

    def _beam_cost(
        self,
        initial: Sequence[int],
        suffix: Sequence[int],
        capacity: int,
        context: Mapping[str, Any],
        beam_width: int,
        terminal_cache: Dict[Tuple[int, ...], float],
    ) -> float:
        def cached_cost(state: Tuple[int, ...]) -> float:
            if state not in terminal_cache:
                terminal_cache[state] = self._terminal_cost(
                    state, capacity, context
                )
            return terminal_cache[state]

        frontier = (tuple(sorted(initial)),)
        for item in suffix:
            expanded: Dict[Tuple[int, ...], float] = {}
            for state in frontier:
                for action in _abstract_actions(item, state, capacity, limit=6):
                    post = tuple(sorted(_post_loads(item, state, action)))
                    if post not in expanded:
                        expanded[post] = cached_cost(post)
            frontier = tuple(
                state
                for state, _ in sorted(
                    expanded.items(), key=lambda pair: (pair[1], pair[0])
                )[:beam_width]
            )
        return min(
            cached_cost(state) for state in frontier
        )

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        del item_index
        horizon = round(self.parameters[0])
        scenario_count = round(self.parameters[1])
        beam_width = round(self.parameters[2])
        risk_weight = self.parameters[3]
        observed = _history_sample(item, history, capacity, 64)
        context = self._state_context(observed, capacity)
        terminal_cache: Dict[Tuple[int, ...], float] = {}
        suffixes = self._suffixes(
            item, history, capacity, horizon, scenario_count
        )
        ranked = []
        for action in _abstract_actions(item, loads, capacity, limit=8):
            post = _post_loads(item, loads, action)
            costs = tuple(
                self._beam_cost(
                    post,
                    suffix,
                    capacity,
                    context,
                    beam_width,
                    terminal_cache,
                )
                for suffix in suffixes
            )
            expected = mean(costs)
            robust = max(costs)
            score = (1.0 - risk_weight) * expected + risk_weight * robust
            numeric = len(loads) if action is None else action
            ranked.append((score, numeric, action))
        return min(ranked, key=lambda row: (row[0], row[1]))[2]


def initial_trajectory_population() -> Tuple[TrajectoryValuePolicy, ...]:
    return tuple(
        TrajectoryValuePolicy(parameters)
        for parameters in (
            (3, 6, 6, 0.45, 0.80, 0.65, 0.00, 0.00, 0.00, 0.00, 0.00),
            (2, 5, 5, 0.20, 0.60, 0.50, 0.70, 0.30, 0.00, 0.20, 0.00),
            (2, 5, 6, 0.30, 0.70, 0.40, 0.25, 0.60, 0.50, 0.30, 0.00),
            (3, 5, 5, 0.55, 0.90, 0.70, 0.30, 0.30, 0.20, 0.60, 0.25),
            (2, 6, 6, 0.10, 0.40, 0.30, 0.80, 0.80, 0.40, 0.20, -0.25),
        )
    )


def mutate_trajectory_policy(
    parent: TrajectoryValuePolicy,
    rng: random.Random,
    generation: int,
    child_index: int,
) -> TrajectoryValuePolicy:
    del generation, child_index
    values = list(parent.parameters)
    mutation_count = 1 if rng.random() < 0.55 else 2
    for _ in range(mutation_count):
        index = rng.randrange(len(values))
        if index == 0:
            values[index] = min(3.0, max(1.0, values[index] + rng.choice((-1, 1))))
        elif index == 1:
            values[index] = min(7.0, max(3.0, values[index] + rng.choice((-1, 1))))
        elif index == 2:
            values[index] = min(8.0, max(3.0, values[index] + rng.choice((-1, 1))))
        elif index == 3:
            values[index] = min(
                1.0, max(0.0, values[index] + rng.choice((-0.20, -0.10, 0.10, 0.20)))
            )
        elif index < 10:
            values[index] = min(
                2.5, max(0.0, values[index] + rng.choice((-0.50, -0.25, 0.25, 0.50)))
            )
        else:
            values[index] = min(
                1.5, max(-1.5, values[index] + rng.choice((-0.50, -0.25, 0.25, 0.50)))
            )
    return TrajectoryValuePolicy(tuple(round(value, 4) for value in values))


@dataclass(frozen=True)
class BinPackingTrajectoryConfig:
    lengths: Tuple[int, ...] = (120, 250, 500)
    development_episodes_per_length: Tuple[int, ...] = (3, 5)
    selection_episodes_per_length: int = 10
    validation_episodes_per_length: int = 40
    capacity: int = 150
    item_low: int = 20
    item_high: int = 100
    base_seed: int = 91_082_026
    population_size: int = 5
    elite_count: int = 2
    selection_pool_size: int = 3
    mutation_seed: int = 77_311

    def __post_init__(self) -> None:
        if not self.lengths or min(self.lengths) <= 1:
            raise ValueError("trajectory episode lengths must exceed one")
        if not self.development_episodes_per_length:
            raise ValueError("trajectory improvement needs development generations")
        counts = (
            *self.development_episodes_per_length,
            self.selection_episodes_per_length,
            self.validation_episodes_per_length,
        )
        if min(counts) < 2:
            raise ValueError("trajectory partitions need two episodes per length")
        if self.population_size != len(initial_trajectory_population()):
            raise ValueError("population size must match the frozen semantic seeds")
        if not 0 < self.elite_count < self.population_size:
            raise ValueError("invalid trajectory elite count")
        if not 0 < self.selection_pool_size <= self.population_size:
            raise ValueError("invalid trajectory selection-pool size")
        if not 0 < self.item_low <= self.item_high <= self.capacity:
            raise ValueError("invalid trajectory IID distribution")

    @property
    def improvement_config(self) -> TrajectoryImprovementConfig:
        return TrajectoryImprovementConfig(
            population_size=self.population_size,
            elite_count=self.elite_count,
            selection_pool_size=self.selection_pool_size,
            generation_count=len(self.development_episodes_per_length),
            mutation_seed=self.mutation_seed,
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": BINPACKING_TRAJECTORY_POLICY_VERSION,
            "lengths": list(self.lengths),
            "development_episodes_per_length": list(
                self.development_episodes_per_length
            ),
            "selection_episodes_per_length": self.selection_episodes_per_length,
            "validation_episodes_per_length": self.validation_episodes_per_length,
            "capacity": self.capacity,
            "item_low_inclusive": self.item_low,
            "item_high_inclusive": self.item_high,
            "base_seed": self.base_seed,
            "improvement": self.improvement_config.as_dict(),
        }


_PARTITION_OFFSETS = {
    "trajectory_development_0": 110_000_000,
    "trajectory_development_1": 310_000_000,
    "trajectory_selection": 510_000_000,
    "trajectory_validation": 910_000_000,
}


def _instances(
    config: BinPackingTrajectoryConfig,
    partition: str,
    episodes_per_length: int,
) -> Tuple[BinPackingInstance, ...]:
    instances = []
    for length_index, length in enumerate(config.lengths):
        for episode_index in range(episodes_per_length):
            seed = (
                config.base_seed
                + _PARTITION_OFFSETS[partition]
                + length_index * 10_000_000
                + episode_index
            )
            rng = random.Random(seed)
            instances.append(
                BinPackingInstance(
                    instance_id="%s:length=%d:seed=%d"
                    % (partition, length, seed),
                    family="iid_or_uniform_%d_%d"
                    % (config.item_low, config.item_high),
                    seed=seed,
                    capacity=config.capacity,
                    items=tuple(
                        rng.randint(config.item_low, config.item_high)
                        for _ in range(length)
                    ),
                )
            )
    return tuple(instances)


def _batch(
    config: BinPackingTrajectoryConfig,
    partition: str,
    episodes_per_length: int,
) -> FrozenTrajectoryBatch[BinPackingInstance]:
    instances = _instances(config, partition, episodes_per_length)
    return FrozenTrajectoryBatch(
        batch_id=partition,
        episode_ids=tuple(instance.instance_id for instance in instances),
        experiments=instances,
    )


def trajectory_policy_commitment(
    config: BinPackingTrajectoryConfig,
) -> Dict[str, Any]:
    development_batches = tuple(
        _batch(config, "trajectory_development_%d" % index, count)
        for index, count in enumerate(config.development_episodes_per_length)
    )
    selection_batch = _batch(
        config, "trajectory_selection", config.selection_episodes_per_length
    )
    validation = _batch(
        config, "trajectory_validation", config.validation_episodes_per_length
    )
    all_ids = tuple(
        episode_id
        for batch in (*development_batches, selection_batch, validation)
        for episode_id in batch.episode_ids
    )
    if len(set(all_ids)) != len(all_ids):
        raise AssertionError("trajectory partitions must be disjoint")
    commitment: Dict[str, Any] = {
        "schema": 1,
        "version": BINPACKING_TRAJECTORY_POLICY_VERSION,
        "config": config.as_dict(),
        "initial_population": [
            candidate.as_dict() for candidate in initial_trajectory_population()
        ],
        "mutation_operator": {
            "name": "bounded_semantic_complete_policy_mutation",
            "parameter_names": list(TRAJECTORY_PARAMETER_NAMES),
            "future_information": False,
            "incumbent_information": False,
        },
        "development_batches": [batch.as_dict() for batch in development_batches],
        "selection_batch": selection_batch.as_dict(),
        "validation_batch": validation.as_dict(),
        "optimization_signal": (
            "negative terminal excess-bin count per complete episode; "
            "ranking-equivalent to negative terminal bins on common episodes"
        ),
        "comparator_access": "after selection_id is frozen",
        "candidate_fallback_policy": None,
        "previous_closed_loop_validation_reused": False,
    }
    commitment["commitment_id"] = content_digest(commitment)
    return commitment


def _evaluate_absolute_return(
    candidate: TrajectoryValuePolicy,
    batch: FrozenTrajectoryBatch[BinPackingInstance],
) -> AbsoluteTrajectoryEvaluation:
    returns = []
    rows = []
    for instance in batch.experiments:
        result = pack(instance, candidate)
        lower_bound = math.ceil(sum(instance.items) / float(instance.capacity))
        excess = result.bin_count - lower_bound
        # On a common episode, maximizing negative terminal excess is exactly
        # equivalent to minimizing terminal bins.  Keeping the unit as one bin
        # also prevents short episodes from receiving disproportionate weight.
        terminal_return = -float(excess)
        returns.append(terminal_return)
        rows.append(
            {
                "instance_id": instance.instance_id,
                "length": len(instance.items),
                "bin_count": result.bin_count,
                "volume_lower_bound": lower_bound,
                "excess_bins": excess,
                "return": terminal_return,
            }
        )
    return AbsoluteTrajectoryEvaluation(
        candidate_id=candidate.candidate_id,
        batch_id=batch.batch_id,
        episode_ids=batch.episode_ids,
        returns=tuple(returns),
        diagnostics={"episodes": rows},
    )


def _compare_frozen_to_funsearch(
    candidate: TrajectoryValuePolicy,
    instances: Sequence[BinPackingInstance],
    selection_id: str,
) -> Dict[str, Any]:
    # Deliberately local: the improvement code has no comparator object or
    # incumbent signal.  This import is reachable only after selection freezes.
    from scientist.domains.binpacking.heuristics import FunSearchORReference

    incumbent = FunSearchORReference()
    rows = []
    for instance in instances:
        candidate_bins = pack(instance, candidate).bin_count
        incumbent_bins = pack(instance, incumbent).bin_count
        rows.append(
            {
                "instance_id": instance.instance_id,
                "length": len(instance.items),
                "candidate_bins": candidate_bins,
                "funsearch_bins": incumbent_bins,
                "improvement": incumbent_bins - candidate_bins,
            }
        )
    evidence = paired_episode_evidence(
        (row["improvement"] for row in rows),
        tuple(row["instance_id"] for row in rows),
    )
    by_length = {}
    for length in sorted({row["length"] for row in rows}):
        selected = tuple(row for row in rows if row["length"] == length)
        by_length[str(length)] = paired_episode_evidence(
            (row["improvement"] for row in selected),
            tuple(row["instance_id"] for row in selected),
        ).as_dict()
    return {
        "selection_id": selection_id,
        "candidate_id": candidate.candidate_id,
        "comparator": incumbent.name,
        "comparator_opened_after_selection": True,
        "evidence": evidence.as_dict(),
        "by_length": by_length,
        "screen_passed": (
            evidence.mean_ci_lower > 0.0
            and all(value["mean_improvement"] >= 0.0 for value in by_length.values())
        ),
        "episodes": rows,
    }


def run_binpacking_trajectory_improvement(
    config: BinPackingTrajectoryConfig,
    *,
    commitment: Optional[Mapping[str, Any]] = None,
    progress: Optional[Callable[[str, Mapping[str, Any]], None]] = None,
) -> Dict[str, Any]:
    frozen_commitment = trajectory_policy_commitment(config)
    if commitment is not None and dict(commitment) != frozen_commitment:
        raise ValueError("trajectory commitment does not match run config")
    development_batches = tuple(
        _batch(config, "trajectory_development_%d" % index, count)
        for index, count in enumerate(config.development_episodes_per_length)
    )
    selection_batch = _batch(
        config, "trajectory_selection", config.selection_episodes_per_length
    )
    outcome = run_absolute_trajectory_improvement(
        config.improvement_config,
        initial_trajectory_population(),
        development_batches,
        selection_batch,
        _evaluate_absolute_return,
        mutate_trajectory_policy,
        progress=progress,
    )
    selection = {
        "status": "frozen_before_comparator_access",
        "selection_id": outcome.selection_id,
        "candidate_id": outcome.selected_candidate.candidate_id,
        "candidate": outcome.selected_candidate.as_dict(),
        "funsearch_evaluated_during_improvement": False,
        "optimization_signal": frozen_commitment["optimization_signal"],
    }
    validation_instances = _instances(
        config,
        "trajectory_validation",
        config.validation_episodes_per_length,
    )
    validation = _compare_frozen_to_funsearch(
        outcome.selected_candidate,
        validation_instances,
        outcome.selection_id,
    )
    if progress is not None:
        progress(
            "trajectory_validation_complete",
            {
                "screen_passed": validation["screen_passed"],
                "mean_improvement": validation["evidence"]["mean_improvement"],
                "mean_ci_lower": validation["evidence"]["mean_improvement_ci_lower"],
                "mean_ci_upper": validation["evidence"]["mean_improvement_ci_upper"],
            },
        )
    report: Dict[str, Any] = {
        "schema": 1,
        "version": BINPACKING_TRAJECTORY_POLICY_VERSION,
        "status": "completed",
        "commitment": frozen_commitment,
        "improvement": outcome.as_dict(),
        "selection": selection,
        "validation": validation,
        "architecture_audit": {
            "generic_improver_has_incumbent_input": False,
            "complete_policies_only": True,
            "full_episode_absolute_return_only": True,
            "fresh_episode_batch_each_generation": True,
            "fresh_absolute_selection_panel": True,
            "prior_validation_reused": False,
            "candidate_fallback_policy": None,
            "comparator_opened_only_after_selection": True,
        },
        "confirmation_executed": False,
    }
    report["report_id"] = content_digest(report)
    return report
