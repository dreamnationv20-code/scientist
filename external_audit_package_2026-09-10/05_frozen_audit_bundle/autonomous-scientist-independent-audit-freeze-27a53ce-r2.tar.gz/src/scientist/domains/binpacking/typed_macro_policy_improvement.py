from __future__ import annotations

import random
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import (
    _action_ref,
    _apply_action,
    _parse_action,
)
from scientist.domains.binpacking.heuristics import (
    funsearch_or_score,
    literature_heuristics,
)
from scientist.domains.binpacking.monte_carlo_policy_improvement import (
    _paired_stats,
    summarize_double_sampled_evaluation,
)


TYPED_MACRO_POLICY_IMPROVEMENT_VERSION = (
    "selector-free-double-sampled-typed-macro-policy-improvement-v1"
)


def typed_macros(
    probe: Mapping[str, Any],
    *,
    commitment_spans: Sequence[int] = (8, 24),
    closure_slack_thresholds: Sequence[int] = (5, 20),
) -> Tuple[Mapping[str, Any], ...]:
    macros = []
    for action_ref in probe["action_refs"]:
        for span in commitment_spans:
            for threshold in closure_slack_thresholds:
                body = {
                    "family": "protect_then_close_distinguished_residual",
                    "initial_action_ref": str(action_ref),
                    "commitment_span": int(span),
                    "closure_slack_threshold": int(threshold),
                }
                macros.append({**body, "macro_id": content_digest(body)})
    return tuple(macros)


def _funsearch_action_excluding(
    item: int,
    loads: Sequence[int],
    capacity: int,
    excluded_bin: int,
) -> Optional[int]:
    actions = []
    for index, load in enumerate(loads):
        if index != excluded_bin and load + item <= capacity:
            actions.append(
                (funsearch_or_score(capacity - load - item), -index, index)
            )
    actions.append(
        (funsearch_or_score(capacity - item), -len(loads), None)
    )
    return max(actions, key=lambda row: (row[0], row[1]))[2]


def _macro_next_action(
    *,
    item: int,
    loads: Sequence[int],
    item_index: int,
    history: Sequence[int],
    distinguished_bin: int,
    macro_offset: int,
    commitment_span: int,
    closure_slack_threshold: int,
) -> Optional[int]:
    baseline = literature_heuristics()["funsearch_or_reference"]
    action = baseline.choose_bin(item, loads, 150, item_index, history)
    if macro_offset > commitment_span:
        return action
    distinguished_load = loads[distinguished_bin]
    if distinguished_load + item > 150:
        return action
    remaining = 150 - distinguished_load - item
    if remaining <= closure_slack_threshold:
        return distinguished_bin
    if action == distinguished_bin:
        return _funsearch_action_excluding(
            item, loads, 150, distinguished_bin
        )
    return action


def _pure_funsearch_outcomes(
    probe: Mapping[str, Any], suffixes: Sequence[Sequence[int]]
) -> Tuple[int, ...]:
    baseline = literature_heuristics()["funsearch_or_reference"]
    outcomes = []
    for suffix in suffixes:
        loads = _apply_action(
            _parse_action(str(probe["baseline_action_ref"])),
            int(probe["item"]),
            tuple(int(value) for value in probe["loads"]),
            150,
        )
        history = (*tuple(int(value) for value in probe["history"]), int(probe["item"]))[-128:]
        for offset, next_item in enumerate(suffix, start=1):
            action = baseline.choose_bin(
                next_item,
                loads,
                150,
                int(probe["item_index"]) + offset,
                history,
            )
            loads = _apply_action(action, next_item, loads, 150)
            history = (*history, next_item)[-128:]
        outcomes.append(len(loads))
    return tuple(outcomes)


def _macro_outcomes(
    probe: Mapping[str, Any],
    macro: Mapping[str, Any],
    suffixes: Sequence[Sequence[int]],
) -> Tuple[int, ...]:
    initial_action = _parse_action(str(macro["initial_action_ref"]))
    original_loads = tuple(int(value) for value in probe["loads"])
    distinguished_bin = (
        len(original_loads) if initial_action is None else initial_action
    )
    outcomes = []
    for suffix in suffixes:
        loads = _apply_action(
            initial_action, int(probe["item"]), original_loads, 150
        )
        history = (*tuple(int(value) for value in probe["history"]), int(probe["item"]))[-128:]
        for offset, next_item in enumerate(suffix, start=1):
            action = _macro_next_action(
                item=next_item,
                loads=loads,
                item_index=int(probe["item_index"]) + offset,
                history=history,
                distinguished_bin=distinguished_bin,
                macro_offset=offset,
                commitment_span=int(macro["commitment_span"]),
                closure_slack_threshold=int(
                    macro["closure_slack_threshold"]
                ),
            )
            loads = _apply_action(action, next_item, loads, 150)
            history = (*history, next_item)[-128:]
        outcomes.append(len(loads))
    return tuple(outcomes)


def _macro_suffix_bank(
    probe: Mapping[str, Any],
    *,
    bank: str,
    sample_count: int,
    suffix_horizon: int,
) -> Tuple[int, Tuple[Tuple[int, ...], ...]]:
    material = {
        "version": TYPED_MACRO_POLICY_IMPROVEMENT_VERSION,
        "probe_id": probe["probe_id"],
        "bank": bank,
        "sample_count": sample_count,
        "suffix_horizon": suffix_horizon,
    }
    seed = int(content_digest(material)[:16], 16)
    rng = random.Random(seed)
    return seed, tuple(
        tuple(rng.randint(20, 100) for _ in range(suffix_horizon))
        for _ in range(sample_count)
    )


def evaluate_probe_with_typed_macros(
    probe: Mapping[str, Any],
    *,
    planning_sample_count: int = 256,
    audit_sample_count: int = 256,
    suffix_horizon: int = 96,
    planning_mean_critical_value: float = 3.5,
    planning_harm_z: float = 3.5,
    maximum_planning_harm_rate_upper: float = 0.40,
    commitment_spans: Sequence[int] = (8, 24),
    closure_slack_thresholds: Sequence[int] = (5, 20),
) -> Mapping[str, Any]:
    planning_seed, planning_suffixes = _macro_suffix_bank(
        probe,
        bank="planning",
        sample_count=planning_sample_count,
        suffix_horizon=suffix_horizon,
    )
    baseline_outcomes = _pure_funsearch_outcomes(probe, planning_suffixes)
    candidates = []
    for order, macro in enumerate(
        typed_macros(
            probe,
            commitment_spans=commitment_spans,
            closure_slack_thresholds=closure_slack_thresholds,
        )
    ):
        macro_outcomes = _macro_outcomes(probe, macro, planning_suffixes)
        paired = tuple(
            float(baseline_value - macro_value)
            for baseline_value, macro_value in zip(
                baseline_outcomes, macro_outcomes
            )
        )
        stats = _paired_stats(
            paired,
            mean_critical_value=planning_mean_critical_value,
            harm_z=planning_harm_z,
        )
        candidates.append({**macro, "macro_order": order, **stats})
    selected: Optional[Mapping[str, Any]] = None
    if candidates:
        best = max(
            candidates,
            key=lambda row: (
                float(row["mean_terminal_advantage"]),
                -int(row["macro_order"]),
            ),
        )
        if (
            float(best["mean_ci_lower"]) > 0.0
            and float(best["harmful_suffix_rate_wilson_upper"])
            <= maximum_planning_harm_rate_upper
        ):
            selected = best
    result: Dict[str, Any] = {
        "probe_id": probe["probe_id"],
        "instance_id": probe["instance_id"],
        "length": probe["length"],
        "item_index": probe["item_index"],
        "baseline_action_ref": probe["baseline_action_ref"],
        "planning_bank_seed": planning_seed,
        "planning_sample_count": planning_sample_count,
        "planning_suffix_horizon": suffix_horizon,
        "planning_common_random_numbers_across_macros": True,
        "learned_selector_used": False,
        "latent_concept_used": False,
        "candidate_macro_count": len(candidates),
        "planning_candidates": candidates,
        "selected_macro": None if selected is None else {
            key: selected[key]
            for key in (
                "macro_id",
                "family",
                "initial_action_ref",
                "commitment_span",
                "closure_slack_threshold",
            )
        },
        "planner_activated": selected is not None,
        "audit": None,
    }
    if selected is None:
        return result
    audit_seed, audit_suffixes = _macro_suffix_bank(
        probe,
        bank="independent_audit",
        sample_count=audit_sample_count,
        suffix_horizon=suffix_horizon,
    )
    if audit_seed == planning_seed:
        raise RuntimeError("macro planning and audit banks are not independent")
    audit_baseline = _pure_funsearch_outcomes(probe, audit_suffixes)
    audit_macro = _macro_outcomes(probe, selected, audit_suffixes)
    audit_paired = tuple(
        float(baseline_value - macro_value)
        for baseline_value, macro_value in zip(audit_baseline, audit_macro)
    )
    result["audit"] = {
        "audit_bank_seed": audit_seed,
        "audit_bank_independent_of_planning": True,
        "planning_bank_reused_for_evaluation": False,
        "rollout_suffixes_counted_as_independent_evidence": False,
        **_paired_stats(
            audit_paired, mean_critical_value=1.96, harm_z=1.96
        ),
        "paired_rollout_advantages": list(audit_paired),
    }
    return result


def summarize_typed_macro_evaluation(
    atlas: Mapping[str, Any],
    results: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    base = dict(summarize_double_sampled_evaluation(atlas, results))
    base.pop("assessment_id", None)
    passed = bool(base.pop("isolated_policy_improvement_passed"))
    base["version"] = TYPED_MACRO_POLICY_IMPROVEMENT_VERSION
    base["isolated_macro_policy_improvement_passed"] = passed
    base["selected_macro_family_counts"] = {}
    for result in results:
        if not result["planner_activated"]:
            continue
        macro = result["selected_macro"]
        key = "span=%d,closure=%d" % (
            int(macro["commitment_span"]),
            int(macro["closure_slack_threshold"]),
        )
        base["selected_macro_family_counts"][key] = (
            base["selected_macro_family_counts"].get(key, 0) + 1
        )
    base["assessment_id"] = content_digest(base)
    return base
