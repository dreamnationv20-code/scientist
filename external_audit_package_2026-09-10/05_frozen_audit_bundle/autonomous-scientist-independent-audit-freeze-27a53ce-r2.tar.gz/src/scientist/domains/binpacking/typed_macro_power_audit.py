from __future__ import annotations

import math
from statistics import mean, stdev
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.abductive_genesis import (
    _apply_action,
    _parse_action,
)
from scientist.domains.binpacking.heuristics import literature_heuristics
from scientist.domains.binpacking.monte_carlo_policy_improvement import (
    _paired_stats,
)
from scientist.domains.binpacking.typed_macro_policy_improvement import (
    _funsearch_action_excluding,
    _macro_suffix_bank,
    _pure_funsearch_outcomes,
)


TYPED_MACRO_POWER_AUDIT_VERSION = "typed-macro-power-versus-expressivity-audit-v1"


def _best_planning_macro(result: Mapping[str, Any]) -> Mapping[str, Any]:
    candidates = tuple(result["planning_candidates"])
    if not candidates:
        raise ValueError("a typed-macro result has no planning candidates")
    return max(
        candidates,
        key=lambda row: (
            float(row["mean_terminal_advantage"]),
            -int(row["macro_order"]),
        ),
    )


def _macro_identity(candidate: Mapping[str, Any]) -> Mapping[str, Any]:
    macro = {
        "family": str(candidate["family"]),
        "initial_action_ref": str(candidate["initial_action_ref"]),
        "commitment_span": int(candidate["commitment_span"]),
        "closure_slack_threshold": int(candidate["closure_slack_threshold"]),
    }
    expected_id = content_digest(macro)
    if str(candidate["macro_id"]) != expected_id:
        raise ValueError("frozen macro identity does not match its controller fields")
    return {**macro, "macro_id": expected_id}


def _case(
    result: Mapping[str, Any],
    *,
    stratum: str,
) -> Mapping[str, Any]:
    best = _best_planning_macro(result)
    return {
        "probe_id": str(result["probe_id"]),
        "instance_id": str(result["instance_id"]),
        "length": int(result["length"]),
        "item_index": int(result["item_index"]),
        "stratum": stratum,
        "frozen_best_macro": _macro_identity(best),
        "source_planning_evidence": {
            key: best[key]
            for key in (
                "mean_terminal_advantage",
                "standard_error",
                "mean_ci_lower",
                "mean_ci_upper",
                "harmful_suffix_rate",
                "harmful_suffix_rate_wilson_upper",
                "sample_count",
                "macro_order",
            )
        },
    }


def _take_unique_episodes(
    candidates: Sequence[Mapping[str, Any]],
    *,
    count: int,
    used_episode_ids: set[str],
) -> Tuple[Mapping[str, Any], ...]:
    selected = []
    for candidate in candidates:
        episode_id = str(candidate["instance_id"])
        if episode_id in used_episode_ids:
            continue
        selected.append(candidate)
        used_episode_ids.add(episode_id)
        if len(selected) == count:
            break
    if len(selected) != count:
        raise ValueError(
            f"could select only {len(selected)} of {count} unique source episodes"
        )
    return tuple(selected)


def select_power_audit_cases(
    atlas: Mapping[str, Any],
    source_evaluation: Mapping[str, Any],
    *,
    lengths: Sequence[int] = (120, 250, 500),
    positive_uncertain_per_length: int = 20,
    near_zero_per_length: int = 10,
    clearly_negative_per_length: int = 10,
) -> Mapping[str, Any]:
    """Select a deterministic, episode-independent audit sample.

    Selection uses only the already-opened planning bank. No new suffix outcomes or
    actual instance futures are available here.
    """

    probes = {str(probe["probe_id"]): probe for probe in atlas["probes"]}
    results = tuple(source_evaluation["results"])
    if len(results) != len(probes):
        raise ValueError("source result count does not match the source atlas")
    eligible: Dict[int, Dict[str, list[Mapping[str, Any]]]] = {
        int(length): {"positive_uncertain": [], "nonpositive": []}
        for length in lengths
    }
    for result in results:
        if bool(result["planner_activated"]):
            continue
        probe_id = str(result["probe_id"])
        if probe_id not in probes:
            raise ValueError("source evaluation contains an unknown probe")
        length = int(result["length"])
        if length not in eligible:
            continue
        best = _best_planning_macro(result)
        center = float(best["mean_terminal_advantage"])
        lower = float(best["mean_ci_lower"])
        if center > 0.0 and lower <= 0.0:
            eligible[length]["positive_uncertain"].append(
                _case(result, stratum="strongest_positive_but_uncertain")
            )
        elif center <= 0.0:
            eligible[length]["nonpositive"].append(
                _case(result, stratum="unassigned_nonpositive")
            )

    used_episode_ids: set[str] = set()
    selected = []
    for length in lengths:
        positive = sorted(
            eligible[int(length)]["positive_uncertain"],
            key=lambda row: (
                -float(
                    row["source_planning_evidence"]["mean_terminal_advantage"]
                ),
                str(row["probe_id"]),
            ),
        )
        selected.extend(
            _take_unique_episodes(
                positive,
                count=positive_uncertain_per_length,
                used_episode_ids=used_episode_ids,
            )
        )

        nonpositive = eligible[int(length)]["nonpositive"]
        near_zero = sorted(
            nonpositive,
            key=lambda row: (
                abs(
                    float(
                        row["source_planning_evidence"][
                            "mean_terminal_advantage"
                        ]
                    )
                ),
                str(row["probe_id"]),
            ),
        )
        chosen_near = _take_unique_episodes(
            near_zero,
            count=near_zero_per_length,
            used_episode_ids=used_episode_ids,
        )
        selected.extend(
            {**row, "stratum": "near_zero_nonpositive"}
            for row in chosen_near
        )

        clearly_negative = sorted(
            (
                row
                for row in nonpositive
                if str(row["instance_id"]) not in used_episode_ids
            ),
            key=lambda row: (
                float(
                    row["source_planning_evidence"]["mean_terminal_advantage"]
                ),
                str(row["probe_id"]),
            ),
        )
        chosen_negative = _take_unique_episodes(
            clearly_negative,
            count=clearly_negative_per_length,
            used_episode_ids=used_episode_ids,
        )
        selected.extend(
            {**row, "stratum": "clearly_negative"}
            for row in chosen_negative
        )

    expected_count = len(tuple(lengths)) * (
        positive_uncertain_per_length
        + near_zero_per_length
        + clearly_negative_per_length
    )
    if len(selected) != expected_count:
        raise RuntimeError("power audit selection has the wrong size")
    if len({str(row["instance_id"]) for row in selected}) != len(selected):
        raise RuntimeError("power audit selection reuses a source episode")
    body: Dict[str, Any] = {
        "schema": 1,
        "version": TYPED_MACRO_POWER_AUDIT_VERSION,
        "source_state_atlas_id": str(atlas["atlas_id"]),
        "source_evaluation_run_id": str(
            source_evaluation["evaluation_run_id"]
        ),
        "actual_future_items_available_to_selection": False,
        "new_suffix_outcomes_available_to_selection": False,
        "one_probe_per_source_episode": True,
        "lengths": [int(value) for value in lengths],
        "selection_counts_per_length": {
            "strongest_positive_but_uncertain": positive_uncertain_per_length,
            "near_zero_nonpositive": near_zero_per_length,
            "clearly_negative": clearly_negative_per_length,
        },
        "selection_rules": {
            "strongest_positive_but_uncertain": (
                "best planning mean > 0 and original familywise lower bound <= 0; "
                "descending best planning mean"
            ),
            "near_zero_nonpositive": (
                "best planning mean <= 0; ascending absolute best planning mean"
            ),
            "clearly_negative": (
                "remaining best planning means <= 0; ascending signed mean "
                "(most negative first)"
            ),
            "ties": "ascending probe_id",
            "episode_collision": "keep the first ranked probe and skip later probes",
        },
        "cases": selected,
    }
    body["selection_manifest_id"] = content_digest(body)
    return body


def _descriptive_stats(values: Sequence[float]) -> Mapping[str, Any]:
    values = tuple(float(value) for value in values)
    if not values:
        return {
            "sample_count": 0,
            "mean_terminal_advantage": None,
            "standard_error": None,
            "mean_ci_lower": None,
            "mean_ci_upper": None,
            "helpful_suffix_count": 0,
            "neutral_suffix_count": 0,
            "harmful_suffix_count": 0,
        }
    if len(values) == 1:
        value = values[0]
        return {
            "sample_count": 1,
            "mean_terminal_advantage": value,
            "standard_error": None,
            "mean_ci_lower": None,
            "mean_ci_upper": None,
            "helpful_suffix_count": int(value > 0.0),
            "neutral_suffix_count": int(value == 0.0),
            "harmful_suffix_count": int(value < 0.0),
        }
    return _paired_stats(values, mean_critical_value=1.96, harm_z=1.96)


def _macro_outcomes_and_events(
    probe: Mapping[str, Any],
    macro: Mapping[str, Any],
    suffixes: Sequence[Sequence[int]],
) -> Tuple[Tuple[int, ...], Tuple[Mapping[str, int], ...]]:
    baseline = literature_heuristics()["funsearch_or_reference"]
    initial_action = _parse_action(str(macro["initial_action_ref"]))
    original_loads = tuple(int(value) for value in probe["loads"])
    distinguished_bin = (
        len(original_loads) if initial_action is None else initial_action
    )
    outcomes = []
    event_rows = []
    for suffix in suffixes:
        loads = _apply_action(
            initial_action, int(probe["item"]), original_loads, 150
        )
        history = (
            *tuple(int(value) for value in probe["history"]),
            int(probe["item"]),
        )[-128:]
        events = {
            "forced_closure_override_count": 0,
            "baseline_already_closed_count": 0,
            "protection_diversion_count": 0,
            "distinguished_bin_infeasible_count": 0,
            "delegated_within_span_count": 0,
        }
        for offset, next_item in enumerate(suffix, start=1):
            action = baseline.choose_bin(
                next_item,
                loads,
                150,
                int(probe["item_index"]) + offset,
                history,
            )
            if offset <= int(macro["commitment_span"]):
                distinguished_load = loads[distinguished_bin]
                if distinguished_load + next_item > 150:
                    events["distinguished_bin_infeasible_count"] += 1
                else:
                    remaining = 150 - distinguished_load - next_item
                    if remaining <= int(macro["closure_slack_threshold"]):
                        if action == distinguished_bin:
                            events["baseline_already_closed_count"] += 1
                        else:
                            events["forced_closure_override_count"] += 1
                        action = distinguished_bin
                    elif action == distinguished_bin:
                        events["protection_diversion_count"] += 1
                        action = _funsearch_action_excluding(
                            next_item, loads, 150, distinguished_bin
                        )
                    else:
                        events["delegated_within_span_count"] += 1
            loads = _apply_action(action, next_item, loads, 150)
            history = (*history, next_item)[-128:]
        outcomes.append(len(loads))
        event_rows.append(events)
    return tuple(outcomes), tuple(event_rows)


def _event_conditioning_summary(
    paired: Sequence[float], event_rows: Sequence[Mapping[str, int]]
) -> Mapping[str, Any]:
    if len(paired) != len(event_rows):
        raise ValueError("event rows do not align with paired outcomes")
    signatures: Dict[str, list[float]] = {}
    for value, events in zip(paired, event_rows):
        closure = int(events["forced_closure_override_count"]) > 0
        protection = int(events["protection_diversion_count"]) > 0
        signature = "closure=%d,protection=%d" % (closure, protection)
        signatures.setdefault(signature, []).append(float(value))
    event_contrasts = {}
    for event_name in (
        "forced_closure_override_count",
        "protection_diversion_count",
    ):
        present = [
            float(value)
            for value, events in zip(paired, event_rows)
            if int(events[event_name]) > 0
        ]
        absent = [
            float(value)
            for value, events in zip(paired, event_rows)
            if int(events[event_name]) == 0
        ]
        event_contrasts[event_name] = {
            "present": _descriptive_stats(present),
            "absent": _descriptive_stats(absent),
            "present_minus_absent_mean": (
                None
                if not present or not absent
                else mean(present) - mean(absent)
            ),
        }
    return {
        "descriptive_not_causal": True,
        "suffixes_are_not_independent_research_replications": True,
        "by_event_signature": {
            key: _descriptive_stats(values)
            for key, values in sorted(signatures.items())
        },
        "event_presence_contrasts": event_contrasts,
    }


def audit_frozen_macro(
    probe: Mapping[str, Any],
    macro: Mapping[str, Any],
    *,
    bank: str,
    audit_sample_count: int = 2_048,
    suffix_horizon: int = 96,
    individual_mean_critical_value: float = 3.6,
    individual_harm_z: float = 3.6,
) -> Mapping[str, Any]:
    macro = _macro_identity(macro)
    audit_seed, suffixes = _macro_suffix_bank(
        probe,
        bank=bank,
        sample_count=audit_sample_count,
        suffix_horizon=suffix_horizon,
    )
    source_planning_seed, _ = _macro_suffix_bank(
        probe,
        bank="planning",
        sample_count=256,
        suffix_horizon=suffix_horizon,
    )
    source_audit_seed, _ = _macro_suffix_bank(
        probe,
        bank="independent_audit",
        sample_count=256,
        suffix_horizon=suffix_horizon,
    )
    if audit_seed in (source_planning_seed, source_audit_seed):
        raise RuntimeError("power audit reused a source experiment suffix bank")
    baseline_outcomes = _pure_funsearch_outcomes(probe, suffixes)
    macro_outcomes, event_rows = _macro_outcomes_and_events(
        probe, macro, suffixes
    )
    paired = tuple(
        float(baseline_value - macro_value)
        for baseline_value, macro_value in zip(
            baseline_outcomes, macro_outcomes
        )
    )
    stats = _paired_stats(
        paired,
        mean_critical_value=individual_mean_critical_value,
        harm_z=individual_harm_z,
    )
    return {
        "probe_id": str(probe["probe_id"]),
        "instance_id": str(probe["instance_id"]),
        "length": int(probe["length"]),
        "item_index": int(probe["item_index"]),
        "frozen_macro": macro,
        "audit_bank": bank,
        "audit_bank_seed": audit_seed,
        "source_planning_bank_seed": source_planning_seed,
        "source_independent_audit_bank_seed": source_audit_seed,
        "audit_bank_independent_of_both_source_banks": True,
        "actual_instance_future_items_used": False,
        "common_random_numbers_between_funsearch_and_macro": True,
        **stats,
        "paired_rollout_advantages": list(paired),
        "event_conditioning": _event_conditioning_summary(paired, event_rows),
    }


def _state_level_summary(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    values = tuple(float(row["mean_terminal_advantage"]) for row in rows)
    if len({str(row["instance_id"]) for row in rows}) != len(rows):
        raise ValueError("state-level evidence is not episode independent")
    center = mean(values)
    standard_error = stdev(values) / math.sqrt(len(values))
    return {
        "state_count": len(rows),
        "mean_expected_bins_saved_per_state": center,
        "state_level_standard_error": standard_error,
        "mean_95_percent_ci_lower": center - 1.96 * standard_error,
        "mean_95_percent_ci_upper": center + 1.96 * standard_error,
        "positive_audit_mean_count": sum(value > 0.0 for value in values),
        "zero_audit_mean_count": sum(value == 0.0 for value in values),
        "negative_audit_mean_count": sum(value < 0.0 for value in values),
    }


def summarize_power_audit(
    manifest: Mapping[str, Any],
    audit_rows: Sequence[Mapping[str, Any]],
    *,
    maximum_harm_rate_upper: float = 0.40,
    power_limited_survivor_minimum: int = 12,
    sparse_total_survivor_maximum: int = 3,
) -> Mapping[str, Any]:
    cases = {str(row["probe_id"]): row for row in manifest["cases"]}
    if {str(row["probe_id"]) for row in audit_rows} != set(cases):
        raise ValueError("audit rows do not match the frozen selection manifest")
    if len({str(row["instance_id"]) for row in audit_rows}) != len(audit_rows):
        raise ValueError("audit rows reuse source episodes")
    enriched = []
    for row in audit_rows:
        case = cases[str(row["probe_id"])]
        survives = (
            float(row["mean_ci_lower"]) > 0.0
            and float(row["harmful_suffix_rate_wilson_upper"])
            <= maximum_harm_rate_upper
        )
        enriched.append({**row, "stratum": case["stratum"], "survives": survives})
    strata = {}
    survivor_count_by_stratum = {}
    for stratum in (
        "strongest_positive_but_uncertain",
        "near_zero_nonpositive",
        "clearly_negative",
    ):
        rows = tuple(row for row in enriched if row["stratum"] == stratum)
        survivors = sum(bool(row["survives"]) for row in rows)
        survivor_count_by_stratum[stratum] = survivors
        strata[stratum] = {
            **_state_level_summary(rows),
            "familywise_individual_survivor_count": survivors,
            "familywise_individual_survivor_fraction": survivors / len(rows),
        }
    strong_survivors = survivor_count_by_stratum[
        "strongest_positive_but_uncertain"
    ]
    total_survivors = sum(survivor_count_by_stratum.values())
    strong_group_positive = (
        float(
            strata["strongest_positive_but_uncertain"][
                "mean_95_percent_ci_lower"
            ]
        )
        > 0.0
    )
    if strong_survivors >= power_limited_survivor_minimum and strong_group_positive:
        outcome = "statistical_power_is_a_material_coverage_limit"
        next_action = (
            "Keep the frozen macro family and test adaptive best-arm racing: spend "
            "additional suffixes only on candidates whose confidence intervals can "
            "still cross the acceptance boundary."
        )
    elif total_survivors <= sparse_total_survivor_maximum:
        outcome = "current_macro_family_has_sparse_high_confidence_coverage"
        next_action = (
            "Abandon this macro family. More suffixes do not address its missing "
            "behavioral expressivity; any next controller must be justified by the "
            "recorded event-conditioned contrasts."
        )
    else:
        outcome = "mixed_power_and_expressivity_evidence"
        next_action = (
            "Do not scale blind sampling or invent another macro. Use decision-level "
            "trajectory ablations on the surviving states to test an explicitly "
            "event-conditioned controller."
        )
    return {
        "schema": 1,
        "version": TYPED_MACRO_POWER_AUDIT_VERSION,
        "selection_manifest_id": str(manifest["selection_manifest_id"]),
        "independence_unit": "source FunSearch episode",
        "source_episode_reused": False,
        "suffix_rollouts_counted_as_independent_research_replications": False,
        "strata": strata,
        "total_familywise_individual_survivor_count": total_survivors,
        "decision_thresholds": {
            "power_limited_strong_positive_survivor_minimum": (
                power_limited_survivor_minimum
            ),
            "power_limited_also_requires_strong_group_95_percent_ci_lower_positive": True,
            "sparse_total_survivor_maximum": sparse_total_survivor_maximum,
            "individual_harm_rate_wilson_upper_maximum": maximum_harm_rate_upper,
        },
        "diagnostic_outcome": outcome,
        "next_action": next_action,
        "not_a_full_trajectory_policy_test": True,
        "not_evidence_of_a_binpacking_breakthrough": True,
    }
