from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from statistics import mean
from typing import Any, Callable, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.binpacking.closed_loop_de_novo import (
    _abstract_actions,
    _post_loads,
    _stable_quantiles,
)
from scientist.domains.binpacking.heuristics import baseline_heuristics, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.program.discovery_evidence import paired_episode_evidence
from scientist.program.trajectory_improvement import (
    AbsoluteTrajectoryEvaluation,
    FrozenTrajectoryBatch,
    TrajectoryImprovementConfig,
    run_absolute_trajectory_improvement,
)


TYPED_POLICY_SYNTHESIS_VERSION = (
    "binpacking-open-typed-policy-synthesis-v7-frontier-history-backfill"
)
REGISTER_COUNT = 3
MAX_EXPRESSION_DEPTH = 4
MAX_CONTROLLER_DEPTH = 5
MAX_PROGRAM_NODES = 96

ACTION_FEATURES = (
    "item",
    "remaining_after",
    "fill_after",
    "is_new",
    "exact_fill",
    "bin_index",
    "open_bins",
    "feasible_fraction",
    "progress",
    "history_mean",
    "history_std",
    "history_large_fraction",
    "mean_residual",
    "residual_std",
    "dead_mass",
    "completion_frequency",
    "pair_completion_frequency",
    "coverage_gap",
    "selected_load_before",
    "memory_0",
    "memory_1",
    "memory_2",
    "memory_0_x2",
    "memory_1_x2",
    "memory_2_x2",
)
EXPR_ARITY = {
    "const": 0,
    "feature": 0,
    "neg": 1,
    "abs": 1,
    "tanh": 1,
    "square": 1,
    "sign": 1,
    "add": 2,
    "sub": 2,
    "mul": 2,
    "min": 2,
    "max": 2,
    "safe_div": 2,
}
UNARY_OPS = ("neg", "abs", "tanh", "square", "sign")
BINARY_OPS = ("add", "sub", "mul", "min", "max", "safe_div")
CONTROLLER_KINDS = ("score", "lexicographic", "pareto", "switch", "vote")
UPDATE_KINDS = ("ema", "accumulate", "assign", "signed_peak")
CONTEXT_GATE_FEATURES = (
    "item",
    "open_bins",
    "feasible_fraction",
    "progress",
    "history_mean",
    "history_std",
    "history_large_fraction",
    "mean_residual",
    "residual_std",
    "memory_0",
    "memory_1",
    "memory_2",
)


def _bounded(value: float, limit: float = 8.0) -> float:
    if not math.isfinite(value):
        return 0.0
    return max(-limit, min(limit, value))


@dataclass(frozen=True)
class TypedExpr:
    op: str
    argument: str | float | None = None
    children: Tuple["TypedExpr", ...] = ()

    def __post_init__(self) -> None:
        if self.op not in EXPR_ARITY:
            raise ValueError("unsupported typed expression operator")
        if len(self.children) != EXPR_ARITY[self.op]:
            raise ValueError("typed expression has the wrong arity")
        if self.op == "feature":
            if self.argument not in ACTION_FEATURES:
                raise ValueError("unknown typed-policy feature")
        elif self.op == "const":
            if not isinstance(self.argument, (int, float)) or not math.isfinite(
                float(self.argument)
            ):
                raise ValueError("typed constant must be finite")
        elif self.argument is not None:
            raise ValueError("only leaves may have expression arguments")
        if self.depth > MAX_EXPRESSION_DEPTH:
            raise ValueError("typed expression exceeds its depth bound")

    @property
    def depth(self) -> int:
        return 1 + max((child.depth for child in self.children), default=0)

    @property
    def node_count(self) -> int:
        return 1 + sum(child.node_count for child in self.children)

    def evaluate(self, features: Mapping[str, float]) -> float:
        if self.op == "const":
            return float(self.argument)
        if self.op == "feature":
            return _bounded(float(features.get(str(self.argument), 0.0)))
        values = tuple(child.evaluate(features) for child in self.children)
        if self.op == "neg":
            return -values[0]
        if self.op == "abs":
            return abs(values[0])
        if self.op == "tanh":
            return math.tanh(values[0])
        if self.op == "square":
            return _bounded(values[0] * values[0])
        if self.op == "sign":
            return float(values[0] > 0.0) - float(values[0] < 0.0)
        if self.op == "add":
            return _bounded(values[0] + values[1])
        if self.op == "sub":
            return _bounded(values[0] - values[1])
        if self.op == "mul":
            return _bounded(values[0] * values[1])
        if self.op == "min":
            return min(values)
        if self.op == "max":
            return max(values)
        denominator = values[1]
        return _bounded(values[0] / denominator) if abs(denominator) > 1e-6 else 0.0

    def as_dict(self) -> Dict[str, Any]:
        return {
            "op": self.op,
            "argument": self.argument,
            "children": [child.as_dict() for child in self.children],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TypedExpr":
        return cls(
            str(value["op"]),
            value.get("argument"),
            tuple(cls.from_dict(child) for child in value.get("children", ())),
        )

    @classmethod
    def feature(cls, name: str) -> "TypedExpr":
        return cls("feature", name)

    @classmethod
    def const(cls, value: float) -> "TypedExpr":
        return cls("const", float(value))


@dataclass(frozen=True)
class TypedController:
    kind: str
    expressions: Tuple[TypedExpr, ...] = ()
    children: Tuple["TypedController", ...] = ()

    def __post_init__(self) -> None:
        if self.kind not in CONTROLLER_KINDS:
            raise ValueError("unsupported typed controller")
        if self.kind == "score" and (
            len(self.expressions) != 1 or self.children
        ):
            raise ValueError("score controller requires one expression")
        if self.kind in ("lexicographic", "pareto") and (
            not 2 <= len(self.expressions) <= 4 or self.children
        ):
            raise ValueError("multi-objective controller requires 2-4 expressions")
        if self.kind == "switch" and (
            len(self.expressions) != 1 or len(self.children) != 2
        ):
            raise ValueError("switch controller requires a gate and two branches")
        if self.kind == "vote" and (
            self.expressions or not 2 <= len(self.children) <= 3
        ):
            raise ValueError("vote controller requires 2-3 children")
        if self.depth > MAX_CONTROLLER_DEPTH:
            raise ValueError("typed controller exceeds its depth bound")

    @property
    def depth(self) -> int:
        return 1 + max((child.depth for child in self.children), default=0)

    @property
    def node_count(self) -> int:
        return (
            1
            + sum(expr.node_count for expr in self.expressions)
            + sum(child.node_count for child in self.children)
        )

    def choose(
        self,
        rows: Sequence[Mapping[str, Any]],
        state_features: Mapping[str, float],
    ) -> Optional[int]:
        if self.kind == "score":
            expression = self.expressions[0]
            return max(
                rows,
                key=lambda row: (
                    expression.evaluate(row["features"]),
                    -int(row["numeric"]),
                ),
            )["action"]
        if self.kind == "lexicographic":
            return max(
                rows,
                key=lambda row: (
                    *(expr.evaluate(row["features"]) for expr in self.expressions),
                    -int(row["numeric"]),
                ),
            )["action"]
        if self.kind == "pareto":
            vectors = {
                int(row["numeric"]): tuple(
                    expr.evaluate(row["features"]) for expr in self.expressions
                )
                for row in rows
            }
            frontier = []
            for row in rows:
                vector = vectors[int(row["numeric"])]
                dominated = any(
                    all(left >= right for left, right in zip(other, vector))
                    and any(left > right for left, right in zip(other, vector))
                    for numeric, other in vectors.items()
                    if numeric != int(row["numeric"])
                )
                if not dominated:
                    frontier.append(row)
            minima = tuple(min(vector[i] for vector in vectors.values()) for i in range(len(self.expressions)))
            maxima = tuple(max(vector[i] for vector in vectors.values()) for i in range(len(self.expressions)))

            def balance(row: Mapping[str, Any]) -> Tuple[float, int]:
                vector = vectors[int(row["numeric"])]
                normalized = tuple(
                    0.0
                    if maxima[i] - minima[i] <= 1e-12
                    else (vector[i] - minima[i]) / (maxima[i] - minima[i])
                    for i in range(len(vector))
                )
                return min(normalized), -int(row["numeric"])

            return max(frontier, key=balance)["action"]
        if self.kind == "switch":
            branch = 0 if self.expressions[0].evaluate(state_features) >= 0.0 else 1
            return self.children[branch].choose(rows, state_features)
        votes: Dict[int, int] = {}
        by_numeric = {int(row["numeric"]): row["action"] for row in rows}
        for child in self.children:
            action = child.choose(rows, state_features)
            numeric = next(
                int(row["numeric"]) for row in rows if row["action"] == action
            )
            votes[numeric] = votes.get(numeric, 0) + 1
        winner = min(votes, key=lambda numeric: (-votes[numeric], numeric))
        return by_numeric[winner]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind,
            "expressions": [expr.as_dict() for expr in self.expressions],
            "children": [child.as_dict() for child in self.children],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TypedController":
        return cls(
            str(value["kind"]),
            tuple(
                TypedExpr.from_dict(expr) for expr in value.get("expressions", ())
            ),
            tuple(cls.from_dict(child) for child in value.get("children", ())),
        )


@dataclass(frozen=True)
class StateUpdate:
    register: int
    kind: str
    source: TypedExpr
    rate: float

    def __post_init__(self) -> None:
        if not 0 <= self.register < REGISTER_COUNT:
            raise ValueError("state update targets an unknown register")
        if self.kind not in UPDATE_KINDS:
            raise ValueError("unsupported persistent-state update")
        if not 0.01 <= self.rate <= 1.0:
            raise ValueError("state-update rate must be in [0.01, 1]")

    def apply(self, old: float, features: Mapping[str, float]) -> float:
        source = self.source.evaluate(features)
        if self.kind == "ema":
            value = (1.0 - self.rate) * old + self.rate * source
        elif self.kind == "accumulate":
            value = old + self.rate * source
        elif self.kind == "assign":
            value = source
        else:
            value = source if abs(source) > abs(old) else old
        return _bounded(value, 4.0)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "register": self.register,
            "kind": self.kind,
            "source": self.source.as_dict(),
            "rate": self.rate,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "StateUpdate":
        return cls(
            int(value["register"]),
            str(value["kind"]),
            TypedExpr.from_dict(value["source"]),
            float(value["rate"]),
        )


@dataclass
class TypedPolicyProgram:
    controller: TypedController
    updates: Tuple[StateUpdate, ...]
    _memory: list[float] = field(
        default_factory=lambda: [0.0] * REGISTER_COUNT,
        init=False,
        repr=False,
        compare=False,
    )

    def __post_init__(self) -> None:
        if len(self.updates) not in (0, REGISTER_COUNT):
            raise ValueError("typed policy requires one update per register")
        if self.updates and tuple(update.register for update in self.updates) != tuple(
            range(REGISTER_COUNT)
        ):
            raise ValueError("typed policy updates must cover registers in order")
        if self.complexity > MAX_PROGRAM_NODES:
            raise ValueError("typed policy exceeds its node budget")

    @property
    def complexity(self) -> int:
        return 1 + self.controller.node_count + sum(
            1 + update.source.node_count for update in self.updates
        )

    @property
    def candidate_id(self) -> str:
        return content_digest(
            {
                "version": TYPED_POLICY_SYNTHESIS_VERSION,
                "controller": self.controller.as_dict(),
                "updates": [update.as_dict() for update in self.updates],
            }
        )

    @property
    def name(self) -> str:
        return "typed_policy_" + self.candidate_id[:12]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_kind": "open_typed_persistent_policy",
            "version": TYPED_POLICY_SYNTHESIS_VERSION,
            "candidate_id": self.candidate_id,
            "name": self.name,
            "controller": self.controller.as_dict(),
            "updates": [update.as_dict() for update in self.updates],
            "controller_kind": self.controller.kind,
            "persistent_register_count": len(self.updates),
            "complexity": self.complexity,
            "complete_policy": True,
            "incumbent": None,
            "incumbent_blind": True,
            "fallback_policy": None,
            "future_arrivals_available": False,
            "open_ended_typed_synthesis": True,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TypedPolicyProgram":
        if value.get("version") != TYPED_POLICY_SYNTHESIS_VERSION:
            raise ValueError("unsupported typed-policy version")
        policy = cls(
            TypedController.from_dict(value["controller"]),
            tuple(StateUpdate.from_dict(item) for item in value["updates"]),
        )
        if value.get("candidate_id") != policy.candidate_id:
            raise ValueError("typed-policy identity mismatch")
        return policy

    def without_persistent_state(self) -> "TypedPolicyProgram":
        return TypedPolicyProgram(self.controller, ())

    def _base_features(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
        memory: Optional[Sequence[float]] = None,
    ) -> Dict[str, float]:
        observed = tuple(int(value) for value in history[-64:]) or (item,)
        history_mean = mean(observed) / capacity
        history_std = math.sqrt(
            mean((value / capacity - history_mean) ** 2 for value in observed)
        )
        residuals = tuple(capacity - load for load in loads)
        feasible_count = sum(load + item <= capacity for load in loads)
        return {
            "item": item / float(capacity),
            "remaining_after": 0.0,
            "fill_after": 0.0,
            "is_new": 0.0,
            "exact_fill": 0.0,
            "bin_index": 0.0,
            "open_bins": min(1.0, len(loads) / 100.0),
            "feasible_fraction": feasible_count / float(max(1, len(loads))),
            "progress": item_index / float(item_index + 100),
            "history_mean": history_mean,
            "history_std": history_std,
            "history_large_fraction": sum(
                value > capacity / 2 for value in observed
            )
            / float(len(observed)),
            "mean_residual": (
                mean(residuals) / capacity if residuals else 1.0
            ),
            "residual_std": (
                math.sqrt(
                    mean(
                        (
                            residual / capacity
                            - mean(residuals) / capacity
                        )
                        ** 2
                        for residual in residuals
                    )
                )
                if residuals
                else 0.0
            ),
            "dead_mass": 0.0,
            "completion_frequency": 0.0,
            "pair_completion_frequency": 0.0,
            "coverage_gap": 0.0,
            "selected_load_before": 0.0,
            **{
                "memory_%d" % index: value
                for index, value in enumerate(
                    self._memory if memory is None else memory
                )
            },
            **{
                "memory_%d_x2" % index: _bounded(2.0 * value)
                for index, value in enumerate(
                    self._memory if memory is None else memory
                )
            },
        }

    def _action_rows(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        base: Mapping[str, float],
        history: Sequence[int],
    ) -> Tuple[Dict[str, Any], ...]:
        feasible_count = sum(load + item <= capacity for load in loads)
        observed = tuple(int(value) for value in history[-64:]) or (item,)
        support = _stable_quantiles(observed, min(9, len(observed)))
        minimum = min(observed)
        demand_quantiles = _stable_quantiles(observed, 5)
        rows = []
        for action in _abstract_actions(item, loads, capacity, limit=20):
            post = _post_loads(item, loads, action)
            residuals = tuple(capacity - load for load in post)
            remaining = capacity - (
                item if action is None else loads[action] + item
            )
            completion = sum(
                abs(value - remaining) <= 2 for value in observed
            ) / float(len(observed))
            pair_completion = sum(
                abs(left + right - remaining) <= 2
                for left in support
                for right in support
            ) / float(len(support) ** 2)
            dead_mass = sum(
                residual for residual in residuals if 0 < residual < minimum
            ) / float(max(1, len(residuals)) * capacity)
            coverage_gap = sum(
                not any(residual >= demand for residual in residuals)
                for demand in demand_quantiles
            ) / float(len(demand_quantiles))
            features = {
                **base,
                "remaining_after": remaining / float(capacity),
                "fill_after": 1.0 - remaining / float(capacity),
                "is_new": float(action is None),
                "exact_fill": float(remaining == 0),
                "bin_index": (
                    len(loads) if action is None else action
                )
                / float(max(1, len(loads))),
                "feasible_fraction": feasible_count / float(max(1, len(loads))),
                "dead_mass": dead_mass,
                "completion_frequency": completion,
                "pair_completion_frequency": pair_completion,
                "coverage_gap": coverage_gap,
                "selected_load_before": (
                    0.0 if action is None else loads[action] / float(capacity)
                ),
            }
            rows.append(
                {
                    "action": action,
                    "numeric": len(loads) if action is None else action,
                    "features": features,
                }
            )
        return tuple(rows)

    def choose_bin(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
    ) -> Optional[int]:
        if item_index == 0:
            self._memory = [0.0] * REGISTER_COUNT
        action = self.peek_action(
            item,
            loads,
            capacity,
            item_index,
            history,
            tuple(self._memory),
        )
        self.apply_forced_action(
            item,
            loads,
            capacity,
            item_index,
            history,
            action,
        )
        return action

    def peek_action(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
        memory: Sequence[float],
        controller: Optional[TypedController] = None,
    ) -> Optional[int]:
        if len(memory) != REGISTER_COUNT:
            raise ValueError("typed-policy memory snapshot has the wrong size")
        base = self._base_features(
            item, loads, capacity, item_index, history, memory
        )
        rows = self._action_rows(item, loads, capacity, base, history)
        return (controller or self.controller).choose(rows, base)

    def apply_forced_action(
        self,
        item: int,
        loads: Sequence[int],
        capacity: int,
        item_index: int,
        history: Sequence[int],
        action: Optional[int],
    ) -> None:
        base = self._base_features(item, loads, capacity, item_index, history)
        rows = self._action_rows(item, loads, capacity, base, history)
        matching = tuple(row for row in rows if row["action"] == action)
        if len(matching) != 1:
            raise ValueError("forced typed-policy action is unavailable")
        selected = matching[0]
        if self.updates:
            old = tuple(self._memory)
            self._memory = [
                update.apply(old[update.register], selected["features"])
                for update in self.updates
            ]


@dataclass(frozen=True)
class PolicyDecisionSnapshot:
    item_index: int
    item: int
    loads: Tuple[int, ...]
    history: Tuple[int, ...]
    memory_before: Tuple[float, ...]
    action: Optional[int]


@dataclass(frozen=True)
class MechanismCreditReport:
    candidate_id: str
    episode_count: int
    decision_count: int
    counterfactual_decision_count: int
    evaluated_intervention_count: int
    mechanisms: Mapping[str, Mapping[str, Any]]
    interventions: Tuple[Mapping[str, Any], ...]
    episodes: Tuple[Mapping[str, Any], ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "episode_count": self.episode_count,
            "decision_count": self.decision_count,
            "counterfactual_decision_count": self.counterfactual_decision_count,
            "evaluated_intervention_count": self.evaluated_intervention_count,
            "credit_definition": (
                "counterfactual terminal bins minus original terminal bins; "
                "positive means the original decision helped"
            ),
            "mechanisms": {
                name: dict(value) for name, value in self.mechanisms.items()
            },
            "interventions": [dict(value) for value in self.interventions],
            "episodes": [dict(value) for value in self.episodes],
        }


def _place_action(
    loads: list[int],
    item: int,
    action: Optional[int],
    capacity: int,
) -> None:
    if action is None:
        loads.append(item)
        return
    if not 0 <= action < len(loads) or loads[action] + item > capacity:
        raise ValueError("mechanism intervention selected an infeasible action")
    loads[action] += item


def _trace_episode(
    candidate: TypedPolicyProgram,
    instance: BinPackingInstance,
) -> Tuple[Tuple[PolicyDecisionSnapshot, ...], int]:
    policy = TypedPolicyProgram(candidate.controller, candidate.updates)
    loads: list[int] = []
    history: list[int] = []
    snapshots = []
    for item_index, item in enumerate(instance.items):
        memory_before = tuple(policy._memory)
        action = policy.choose_bin(
            item,
            tuple(loads),
            instance.capacity,
            item_index,
            tuple(history),
        )
        snapshots.append(
            PolicyDecisionSnapshot(
                item_index,
                item,
                tuple(loads),
                tuple(history),
                memory_before,
                action,
            )
        )
        _place_action(loads, item, action, instance.capacity)
        history.append(item)
    return tuple(snapshots), len(loads)


def _decision_alternatives(
    candidate: TypedPolicyProgram,
    snapshot: PolicyDecisionSnapshot,
    capacity: int,
) -> Mapping[Optional[int], Tuple[str, ...]]:
    sources_by_action: Dict[Optional[int], set[str]] = {}

    def add(action: Optional[int], source: str) -> None:
        if action != snapshot.action:
            sources_by_action.setdefault(action, set()).add(source)

    zero_memory = (0.0,) * REGISTER_COUNT
    add(
        candidate.peek_action(
            snapshot.item,
            snapshot.loads,
            capacity,
            snapshot.item_index,
            snapshot.history,
            zero_memory,
        ),
        "persistent_state",
    )
    for register in range(REGISTER_COUNT):
        ablated = list(snapshot.memory_before)
        ablated[register] = 0.0
        add(
            candidate.peek_action(
                snapshot.item,
                snapshot.loads,
                capacity,
                snapshot.item_index,
                snapshot.history,
                tuple(ablated),
            ),
            "register_%d" % register,
        )
        amplified_controller = _rename_feature_in_controller(
            candidate.controller,
            "memory_%d" % register,
            "memory_%d_x2" % register,
        )
        if amplified_controller != candidate.controller:
            add(
                candidate.peek_action(
                    snapshot.item,
                    snapshot.loads,
                    capacity,
                    snapshot.item_index,
                    snapshot.history,
                    snapshot.memory_before,
                    amplified_controller,
                ),
                "register_%d_x2" % register,
            )
    if candidate.controller.kind == "switch":
        base = candidate._base_features(
            snapshot.item,
            snapshot.loads,
            capacity,
            snapshot.item_index,
            snapshot.history,
            snapshot.memory_before,
        )
        active = (
            0
            if candidate.controller.expressions[0].evaluate(base) >= 0.0
            else 1
        )
        inactive = 1 - active
        add(
            candidate.peek_action(
                snapshot.item,
                snapshot.loads,
                capacity,
                snapshot.item_index,
                snapshot.history,
                snapshot.memory_before,
                candidate.controller.children[inactive],
            ),
            "controller_branch_%d" % active,
        )
    return {
        action: tuple(sorted(sources))
        for action, sources in sources_by_action.items()
    }


def _spread_sample(values: Sequence[Any], limit: int) -> Tuple[Any, ...]:
    if len(values) <= limit:
        return tuple(values)
    if limit == 1:
        return (values[len(values) // 2],)
    positions = tuple(
        dict.fromkeys(
            round(index * (len(values) - 1) / float(limit - 1))
            for index in range(limit)
        )
    )
    return tuple(values[position] for position in positions)


def _counterfactual_terminal_bins(
    candidate: TypedPolicyProgram,
    instance: BinPackingInstance,
    snapshot: PolicyDecisionSnapshot,
    forced_action: Optional[int],
) -> int:
    policy = TypedPolicyProgram(candidate.controller, candidate.updates)
    policy._memory = list(snapshot.memory_before)
    loads = list(snapshot.loads)
    history = list(snapshot.history)
    policy.apply_forced_action(
        snapshot.item,
        tuple(loads),
        instance.capacity,
        snapshot.item_index,
        tuple(history),
        forced_action,
    )
    _place_action(loads, snapshot.item, forced_action, instance.capacity)
    history.append(snapshot.item)
    for item_index in range(snapshot.item_index + 1, len(instance.items)):
        item = instance.items[item_index]
        action = policy.choose_bin(
            item,
            tuple(loads),
            instance.capacity,
            item_index,
            tuple(history),
        )
        _place_action(loads, item, action, instance.capacity)
        history.append(item)
    return len(loads)


def assign_mechanism_credit(
    candidate: TypedPolicyProgram,
    instances: Sequence[BinPackingInstance],
    *,
    maximum_decisions_per_episode: int = 3,
    maximum_alternatives_per_decision: int = 2,
) -> MechanismCreditReport:
    if maximum_decisions_per_episode <= 0 or maximum_alternatives_per_decision <= 0:
        raise ValueError("mechanism-credit intervention limits must be positive")
    interventions = []
    episode_rows = []
    total_decisions = 0
    counterfactual_decisions = 0
    for instance in instances:
        snapshots, baseline_bins = _trace_episode(candidate, instance)
        total_decisions += len(snapshots)
        actionable = []
        for snapshot in snapshots:
            alternatives = _decision_alternatives(
                candidate, snapshot, instance.capacity
            )
            if alternatives:
                actionable.append((snapshot, alternatives))
        counterfactual_decisions += len(actionable)
        selected = _spread_sample(actionable, maximum_decisions_per_episode)
        for snapshot, alternatives in selected:
            ranked_alternatives = sorted(
                alternatives.items(),
                key=lambda value: (
                    -int(
                        any(
                            source.startswith("controller_branch_")
                            or source.endswith("_x2")
                            for source in value[1]
                        )
                    ),
                    -len(value[1]),
                    len(snapshot.loads) if value[0] is None else int(value[0]),
                ),
            )[:maximum_alternatives_per_decision]
            for alternative, sources in ranked_alternatives:
                base = candidate._base_features(
                    snapshot.item,
                    snapshot.loads,
                    instance.capacity,
                    snapshot.item_index,
                    snapshot.history,
                    snapshot.memory_before,
                )
                counterfactual_bins = _counterfactual_terminal_bins(
                    candidate, instance, snapshot, alternative
                )
                interventions.append(
                    {
                        "instance_id": instance.instance_id,
                        "item_index": snapshot.item_index,
                        "original_action": snapshot.action,
                        "counterfactual_action": alternative,
                        "sources": list(sources),
                        "context": {
                            feature: float(base[feature])
                            for feature in CONTEXT_GATE_FEATURES
                        },
                        "original_terminal_bins": baseline_bins,
                        "counterfactual_terminal_bins": counterfactual_bins,
                        "original_action_credit": (
                            counterfactual_bins - baseline_bins
                        ),
                    }
                )
        episode_rows.append(
            {
                "instance_id": instance.instance_id,
                "length": len(instance.items),
                "baseline_bin_count": baseline_bins,
                "counterfactual_decision_count": len(actionable),
                "evaluated_intervention_count": sum(
                    row["instance_id"] == instance.instance_id
                    for row in interventions
                ),
            }
        )
    by_mechanism: Dict[str, list[int]] = {}
    for intervention in interventions:
        for source in intervention["sources"]:
            by_mechanism.setdefault(str(source), []).append(
                int(intervention["original_action_credit"])
            )
    mechanisms = {}
    for source, credits in sorted(by_mechanism.items()):
        mechanisms[source] = {
            "intervention_count": len(credits),
            "mean_original_action_credit": mean(credits),
            "helped_count": sum(value > 0 for value in credits),
            "neutral_count": sum(value == 0 for value in credits),
            "hurt_count": sum(value < 0 for value in credits),
            "minimum_credit": min(credits),
            "maximum_credit": max(credits),
        }
    return MechanismCreditReport(
        candidate.candidate_id,
        len(instances),
        total_decisions,
        counterfactual_decisions,
        len(interventions),
        mechanisms,
        tuple(interventions),
        tuple(episode_rows),
    )


@dataclass(frozen=True)
class ContextGateRule:
    feature: str
    lower: Optional[float]
    upper: Optional[float]
    polarity: str
    score: float
    captured_target_credit: float
    captured_opposing_credit: float
    matched_count: int
    training_count: int

    def __post_init__(self) -> None:
        if self.feature not in CONTEXT_GATE_FEATURES:
            raise ValueError("context gate uses an unsupported feature")
        if self.polarity not in ("harm", "help"):
            raise ValueError("context gate has an unsupported credit polarity")
        if self.lower is None and self.upper is None:
            raise ValueError("context gate must have at least one boundary")
        if (
            self.lower is not None
            and self.upper is not None
            and self.lower > self.upper
        ):
            raise ValueError("context gate interval is inverted")

    @property
    def expression(self) -> TypedExpr:
        feature = TypedExpr.feature(self.feature)
        if self.lower is None:
            return TypedExpr(
                "sub",
                children=(TypedExpr.const(float(self.upper)), feature),
            )
        if self.upper is None:
            return TypedExpr(
                "sub",
                children=(feature, TypedExpr.const(float(self.lower))),
            )
        return TypedExpr(
            "min",
            children=(
                TypedExpr(
                    "sub",
                    children=(feature, TypedExpr.const(float(self.lower))),
                ),
                TypedExpr(
                    "sub",
                    children=(TypedExpr.const(float(self.upper)), feature),
                ),
            ),
        )

    def matches(self, value: float) -> bool:
        return (
            (self.lower is None or value >= self.lower)
            and (self.upper is None or value <= self.upper)
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "feature": self.feature,
            "lower_inclusive": self.lower,
            "upper_inclusive": self.upper,
            "polarity": self.polarity,
            "score": self.score,
            "captured_target_credit": self.captured_target_credit,
            "captured_opposing_credit": self.captured_opposing_credit,
            "matched_count": self.matched_count,
            "training_count": self.training_count,
        }


def learn_context_gates(
    credit: MechanismCreditReport,
    mechanism: str,
    *,
    polarity: str = "harm",
    limit: int = 16,
) -> Tuple[ContextGateRule, ...]:
    rows = tuple(
        row
        for row in credit.interventions
        if mechanism in row["sources"]
    )
    if polarity not in ("harm", "help"):
        raise ValueError("unsupported context-gate credit polarity")
    if limit <= 0:
        raise ValueError("context-gate limit must be positive")
    target_sign = -1 if polarity == "harm" else 1
    if not rows or not any(
        target_sign * row["original_action_credit"] > 0 for row in rows
    ):
        return ()
    rules = []
    for feature in CONTEXT_GATE_FEATURES:
        values = sorted({float(row["context"][feature]) for row in rows})
        if not values:
            continue
        if len(values) == 1:
            intervals = [(values[0], values[0])]
        else:
            boundaries = [None]
            boundaries.extend(
                (left + right) / 2.0
                for left, right in zip(values, values[1:])
            )
            boundaries.append(None)
            intervals = []
            for start in range(len(values)):
                lower = boundaries[start]
                for end in range(start, len(values)):
                    upper = boundaries[end + 1]
                    if lower is not None or upper is not None:
                        intervals.append((lower, upper))
        for lower, upper in intervals:
            matched = tuple(
                row
                for row in rows
                if (lower is None or float(row["context"][feature]) >= lower)
                and (upper is None or float(row["context"][feature]) <= upper)
            )
            captured_target = sum(
                target_sign * float(row["original_action_credit"])
                for row in matched
                if target_sign * row["original_action_credit"] > 0
            )
            if captured_target <= 0.0:
                continue
            captured_opposing = sum(
                -target_sign * float(row["original_action_credit"])
                for row in matched
                if target_sign * row["original_action_credit"] < 0
            )
            neutral_count = sum(
                row["original_action_credit"] == 0 for row in matched
            )
            score = (
                captured_target
                - 2.0 * captured_opposing
                - 0.02 * neutral_count
                - 0.001 * len(matched)
            )
            rules.append(
                ContextGateRule(
                    feature,
                    lower,
                    upper,
                    polarity,
                    score,
                    captured_target,
                    captured_opposing,
                    len(matched),
                    len(rows),
                )
            )
    ranked = sorted(
        rules,
        key=lambda rule: (
            -rule.score,
            -rule.captured_target_credit,
            rule.captured_opposing_credit,
            rule.matched_count,
            rule.feature,
            float("-inf") if rule.lower is None else rule.lower,
            float("inf") if rule.upper is None else rule.upper,
        ),
    )
    unique = []
    seen = set()
    for rule in ranked:
        identity = (rule.feature, rule.lower, rule.upper)
        if identity in seen:
            continue
        seen.add(identity)
        unique.append(rule)
        if len(unique) == limit:
            break
    return tuple(unique)


def _replace_feature_in_expression(
    expression: TypedExpr,
    feature: str,
) -> TypedExpr:
    if expression.op == "feature" and expression.argument == feature:
        return TypedExpr.const(0.0)
    if not expression.children:
        return expression
    return TypedExpr(
        expression.op,
        expression.argument,
        tuple(
            _replace_feature_in_expression(child, feature)
            for child in expression.children
        ),
    )


def _replace_feature_in_controller(
    controller: TypedController,
    feature: str,
) -> TypedController:
    return TypedController(
        controller.kind,
        tuple(
            _replace_feature_in_expression(expression, feature)
            for expression in controller.expressions
        ),
        tuple(
            _replace_feature_in_controller(child, feature)
            for child in controller.children
        ),
    )


def _rename_feature_in_expression(
    expression: TypedExpr,
    source: str,
    destination: str,
) -> TypedExpr:
    if expression.op == "feature" and expression.argument == source:
        return TypedExpr.feature(destination)
    if not expression.children:
        return expression
    return TypedExpr(
        expression.op,
        expression.argument,
        tuple(
            _rename_feature_in_expression(child, source, destination)
            for child in expression.children
        ),
    )


def _rename_feature_in_controller(
    controller: TypedController,
    source: str,
    destination: str,
) -> TypedController:
    return TypedController(
        controller.kind,
        tuple(
            _rename_feature_in_expression(expression, source, destination)
            for expression in controller.expressions
        ),
        tuple(
            _rename_feature_in_controller(child, source, destination)
            for child in controller.children
        ),
    )


def _frontier_rows(
    report: MechanismCreditReport,
    target: str,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    if target.startswith("frontier_register_"):
        register = int(target.rsplit("_", 1)[1])
        source = "register_%d_x2" % register
        for row in report.interventions:
            if source not in row["sources"]:
                continue
            rows.append(
                {
                    **row,
                    "sources": [target],
                    "original_action_credit": -float(
                        row["original_action_credit"]
                    ),
                    "frontier_action_changed": True,
                    "frontier_evidence_kind": "amplified_register_action",
                }
            )
        return tuple(rows)
    if target.startswith("frontier_branch_"):
        desired_branch = int(target.rsplit("_", 1)[1])
        for row in report.interventions:
            active_branches = tuple(
                branch
                for branch in (0, 1)
                if "controller_branch_%d" % branch in row["sources"]
            )
            for active_branch in active_branches:
                action_changed = active_branch != desired_branch
                credit = float(row["original_action_credit"])
                rows.append(
                    {
                        **row,
                        "sources": [target],
                        "original_action_credit": (
                            -credit if action_changed else credit
                        ),
                        "frontier_action_changed": action_changed,
                        "frontier_evidence_kind": (
                            "forced_inactive_branch"
                            if action_changed
                            else "retained_active_branch"
                        ),
                    }
                )
        return tuple(rows)
    raise ValueError("unsupported behavioral-frontier target")


def cross_batch_frontier_gates(
    candidate_id: str,
    history: Sequence[Tuple[str, MechanismCreditReport]],
    *,
    minimum_batches: int = 2,
    limit: int = 16,
) -> Tuple[Tuple[str, ContextGateRule, Mapping[str, Any]], ...]:
    """Find gates where a concrete action-changing mechanism helps.

    Branch evidence is expressed from the perspective of the desired branch:
    retaining it when active uses the original action credit, while forcing it
    when inactive negates that credit. Register evidence likewise measures the
    doubled-register action against the original action. This prevents positive
    credit for the status quo from being mistaken for evidence that a proposed
    amplification changes anything.
    """
    if minimum_batches < 2 or limit <= 0:
        raise ValueError("invalid cross-batch frontier-evidence requirement")
    matching_history = tuple(
        (batch_id, report)
        for batch_id, report in history
        if report.candidate_id == candidate_id
    )
    by_batch: Dict[str, list[MechanismCreditReport]] = {}
    for batch_id, report in matching_history:
        by_batch.setdefault(batch_id, []).append(report)
    if len(by_batch) < minimum_batches:
        return ()
    sources = {
        str(source)
        for _, report in matching_history
        for intervention in report.interventions
        for source in intervention["sources"]
    }
    targets = {
        "frontier_register_%d" % int(source.split("_")[1])
        for source in sources
        if source.startswith("register_") and source.endswith("_x2")
    }
    if any(source.startswith("controller_branch_") for source in sources):
        targets.update(("frontier_branch_0", "frontier_branch_1"))
    candidates = []
    for target in sorted(targets):
        transformed_by_batch = {
            batch_id: tuple(
                row
                for report in batch_reports
                for row in _frontier_rows(report, target)
            )
            for batch_id, batch_reports in by_batch.items()
        }
        transformed = tuple(
            row
            for batch_rows in transformed_by_batch.values()
            for row in batch_rows
        )
        if not transformed:
            continue
        pooled = MechanismCreditReport(
            candidate_id,
            sum(report.episode_count for _, report in matching_history),
            sum(report.decision_count for _, report in matching_history),
            sum(
                report.counterfactual_decision_count
                for _, report in matching_history
            ),
            len(transformed),
            {},
            transformed,
            (),
        )
        for rule in learn_context_gates(
            pooled,
            target,
            polarity="help",
            limit=limit,
        ):
            supporting_batches = []
            opposing_batches = []
            batch_evidence = {}
            positive_action_change_count = 0
            for batch_id, batch_rows in sorted(transformed_by_batch.items()):
                matched = tuple(
                    row
                    for row in batch_rows
                    if rule.matches(float(row["context"][rule.feature]))
                )
                net_advantage = sum(
                    float(row["original_action_credit"]) for row in matched
                )
                helped = sum(
                    row["original_action_credit"] > 0 for row in matched
                )
                hurt = sum(
                    row["original_action_credit"] < 0 for row in matched
                )
                action_changes = sum(
                    bool(row["frontier_action_changed"]) for row in matched
                )
                positive_changes = sum(
                    bool(row["frontier_action_changed"])
                    and row["original_action_credit"] > 0
                    for row in matched
                )
                positive_action_change_count += positive_changes
                batch_evidence[batch_id] = {
                    "matched_count": len(matched),
                    "net_terminal_advantage": net_advantage,
                    "helped_count": helped,
                    "hurt_count": hurt,
                    "action_change_count": action_changes,
                    "positive_action_change_count": positive_changes,
                }
                if helped > 0 and net_advantage > 0.0:
                    supporting_batches.append(batch_id)
                elif matched and net_advantage < 0.0:
                    opposing_batches.append(batch_id)
            if (
                len(supporting_batches) < minimum_batches
                or opposing_batches
                or positive_action_change_count == 0
            ):
                continue
            evidence = {
                "target": target,
                "advantage_definition": (
                    "terminal bins saved by selecting the target mechanism "
                    "instead of the original action"
                ),
                "candidate_specific_history": True,
                "supporting_batches": supporting_batches,
                "opposing_batches": opposing_batches,
                "minimum_required_batches": minimum_batches,
                "positive_action_change_count": positive_action_change_count,
                "batch_evidence": batch_evidence,
            }
            candidates.append((target, rule, evidence))
    ranked = sorted(
        candidates,
        key=lambda value: (
            -len(value[2]["supporting_batches"]),
            -value[2]["positive_action_change_count"],
            -value[1].score,
            value[0],
            value[1].feature,
        ),
    )
    return tuple(ranked[:limit])


def _random_expr(
    rng: random.Random,
    depth: int,
    *,
    require_memory: bool = False,
) -> TypedExpr:
    if require_memory:
        return TypedExpr.feature("memory_%d" % rng.randrange(REGISTER_COUNT))
    if depth <= 1 or rng.random() < 0.34:
        if rng.random() < 0.82:
            return TypedExpr.feature(rng.choice(ACTION_FEATURES))
        return TypedExpr.const(rng.choice((-1.0, -0.5, -0.1, 0.0, 0.1, 0.5, 1.0)))
    if rng.random() < 0.38:
        return TypedExpr(
            rng.choice(UNARY_OPS),
            children=(_random_expr(rng, depth - 1),),
        )
    return TypedExpr(
        rng.choice(BINARY_OPS),
        children=(
            _random_expr(rng, depth - 1),
            _random_expr(rng, depth - 1),
        ),
    )


def _random_leaf_controller(
    rng: random.Random,
    kind: Optional[str] = None,
) -> TypedController:
    selected = kind or rng.choice(("score", "lexicographic", "pareto"))
    count = 1 if selected == "score" else rng.choice((2, 3))
    expressions = tuple(_random_expr(rng, rng.choice((2, 3))) for _ in range(count))
    return TypedController(selected, expressions)


def _random_controller(
    rng: random.Random,
    depth: int,
    kind: Optional[str] = None,
) -> TypedController:
    selected = kind or rng.choice(CONTROLLER_KINDS)
    if depth <= 1 or selected in ("score", "lexicographic", "pareto"):
        return _random_leaf_controller(
            rng,
            selected if selected in ("score", "lexicographic", "pareto") else None,
        )
    if selected == "switch":
        return TypedController(
            "switch",
            (_random_expr(rng, 2, require_memory=True),),
            (
                _random_controller(rng, depth - 1),
                _random_controller(rng, depth - 1),
            ),
        )
    return TypedController(
        "vote",
        (),
        tuple(
            _random_controller(rng, depth - 1)
            for _ in range(rng.choice((2, 3)))
        ),
    )


def _default_updates() -> Tuple[StateUpdate, ...]:
    return (
        StateUpdate(0, "ema", TypedExpr.feature("item"), 0.10),
        StateUpdate(1, "ema", TypedExpr.feature("history_std"), 0.20),
        StateUpdate(
            2,
            "accumulate",
            TypedExpr(
                "sub",
                children=(
                    TypedExpr.feature("is_new"),
                    TypedExpr.feature("exact_fill"),
                ),
            ),
            0.05,
        ),
    )


def _random_updates(rng: random.Random) -> Tuple[StateUpdate, ...]:
    return tuple(
        StateUpdate(
            register,
            rng.choice(UPDATE_KINDS),
            _random_expr(rng, rng.choice((2, 3))),
            rng.choice((0.05, 0.10, 0.20, 0.35, 0.50, 1.0)),
        )
        for register in range(REGISTER_COUNT)
    )


def initial_typed_policy_population() -> Tuple[TypedPolicyProgram, ...]:
    rng = random.Random(202_608_03)
    seeds = [
        TypedPolicyProgram(
            TypedController(
                "score",
                (
                    TypedExpr(
                        "neg",
                        children=(TypedExpr.feature("remaining_after"),),
                    ),
                ),
            ),
            _default_updates(),
        ),
        TypedPolicyProgram(
            TypedController(
                "lexicographic",
                (
                    TypedExpr.feature("exact_fill"),
                    TypedExpr("neg", children=(TypedExpr.feature("is_new"),)),
                    TypedExpr("neg", children=(TypedExpr.feature("dead_mass"),)),
                ),
            ),
            _default_updates(),
        ),
        TypedPolicyProgram(
            TypedController(
                "pareto",
                (
                    TypedExpr.feature("exact_fill"),
                    TypedExpr("neg", children=(TypedExpr.feature("is_new"),)),
                    TypedExpr.feature("completion_frequency"),
                ),
            ),
            _default_updates(),
        ),
        TypedPolicyProgram(
            TypedController(
                "switch",
                (TypedExpr("sub", children=(TypedExpr.feature("item"), TypedExpr.feature("memory_0"))),),
                (
                    _random_leaf_controller(rng, "lexicographic"),
                    _random_leaf_controller(rng, "pareto"),
                ),
            ),
            _default_updates(),
        ),
    ]
    while len(seeds) < 12:
        candidate = TypedPolicyProgram(
            _random_controller(rng, rng.choice((1, 2, 3))),
            _random_updates(rng),
        )
        if candidate.candidate_id not in {seed.candidate_id for seed in seeds}:
            seeds.append(candidate)
    return tuple(seeds)


def _mutate_expr(expr: TypedExpr, rng: random.Random) -> TypedExpr:
    if rng.random() < 0.35:
        return _random_expr(rng, rng.choice((1, 2, 3)))
    if not expr.children:
        if expr.op == "feature":
            return TypedExpr.feature(rng.choice(ACTION_FEATURES))
        return TypedExpr.const(rng.choice((-1.0, -0.5, 0.0, 0.5, 1.0)))
    children = list(expr.children)
    index = rng.randrange(len(children))
    children[index] = _mutate_expr(children[index], rng)
    try:
        return TypedExpr(expr.op, expr.argument, tuple(children))
    except ValueError:
        return _random_expr(rng, 3)


def _mutate_controller(
    controller: TypedController,
    rng: random.Random,
) -> TypedController:
    if rng.random() < 0.24:
        return _random_controller(rng, rng.choice((1, 2, 3)))
    if controller.expressions and rng.random() < 0.72:
        expressions = list(controller.expressions)
        index = rng.randrange(len(expressions))
        expressions[index] = _mutate_expr(expressions[index], rng)
        try:
            return TypedController(controller.kind, tuple(expressions), controller.children)
        except ValueError:
            return _random_controller(rng, 2)
    if controller.children:
        children = list(controller.children)
        index = rng.randrange(len(children))
        children[index] = _mutate_controller(children[index], rng)
        try:
            return TypedController(controller.kind, controller.expressions, tuple(children))
        except ValueError:
            return _random_controller(rng, 2)
    return _random_controller(rng, 2)


def mutate_typed_policy(
    parent: TypedPolicyProgram,
    rng: random.Random,
    generation: int,
    child_index: int,
) -> TypedPolicyProgram:
    del generation, child_index
    for _ in range(32):
        controller = parent.controller
        updates = list(parent.updates)
        if rng.random() < 0.68:
            controller = _mutate_controller(controller, rng)
        else:
            index = rng.randrange(REGISTER_COUNT)
            old = updates[index]
            updates[index] = StateUpdate(
                index,
                rng.choice(UPDATE_KINDS) if rng.random() < 0.5 else old.kind,
                _mutate_expr(old.source, rng),
                rng.choice((0.05, 0.10, 0.20, 0.35, 0.50, 1.0)),
            )
        try:
            candidate = TypedPolicyProgram(controller, tuple(updates))
        except ValueError:
            continue
        if candidate.candidate_id != parent.candidate_id:
            return candidate
    raise RuntimeError("typed-policy mutation could not produce a bounded child")


def _negated_expression(expression: TypedExpr) -> TypedExpr:
    if expression.op == "neg":
        return expression.children[0]
    if expression.depth < MAX_EXPRESSION_DEPTH:
        return TypedExpr("neg", children=(expression,))
    return TypedExpr("neg", children=(expression.children[0],))


def _repair_register_update(
    parent: TypedPolicyProgram,
    register: int,
    child_index: int,
) -> Tuple[TypedPolicyProgram, str]:
    updates = list(parent.updates)
    old = updates[register]
    if child_index % 2 == 0:
        if old.kind in ("assign", "signed_peak"):
            repaired = StateUpdate(
                register,
                "ema",
                old.source,
                max(0.01, min(0.25, old.rate * 0.5)),
            )
        else:
            repaired = StateUpdate(
                register,
                old.kind,
                old.source,
                max(0.01, old.rate * 0.5),
            )
        repair_operator = "attenuate_responsible_state_update"
    else:
        repaired = StateUpdate(
            register,
            old.kind,
            _negated_expression(old.source),
            old.rate,
        )
        repair_operator = "reverse_responsible_state_signal"
    updates[register] = repaired
    candidate = TypedPolicyProgram(parent.controller, tuple(updates))
    return candidate, repair_operator


def _harmful_mechanisms(
    credit: Optional[MechanismCreditReport],
) -> Tuple[Tuple[float, int, int, str, Mapping[str, Any]], ...]:
    harmful = []
    if credit is not None:
        for mechanism, evidence in credit.mechanisms.items():
            if (
                int(evidence["hurt_count"]) > 0
                and float(evidence["mean_original_action_credit"]) < 0.0
            ):
                specificity = (
                    0
                    if mechanism.startswith("register_")
                    or mechanism.startswith("controller_branch_")
                    else 1
                )
                harmful.append(
                    (
                        float(evidence["mean_original_action_credit"]),
                        specificity,
                        -int(evidence["hurt_count"]),
                        mechanism,
                        evidence,
                    )
                )
    return tuple(sorted(harmful))


def positive_amplification_typed_policy(
    parent: TypedPolicyProgram,
    credit: Optional[MechanismCreditReport],
    history: Sequence[Tuple[str, MechanismCreditReport]],
    rng: random.Random,
    generation: int,
    variant: int,
    *,
    minimum_batches: int = 2,
) -> Tuple[TypedPolicyProgram, Mapping[str, Any]]:
    gates = cross_batch_frontier_gates(
        parent.candidate_id,
        history,
        minimum_batches=minimum_batches,
    )
    if not gates:
        return contextual_repair_typed_policy(
            parent, credit, rng, generation, variant
        )
    for offset in range(len(gates)):
        target, rule, evidence = gates[(variant + offset) % len(gates)]
        try:
            if target.startswith("frontier_register_"):
                register = int(target.rsplit("_", 1)[1])
                amplified = _rename_feature_in_controller(
                    parent.controller,
                    "memory_%d" % register,
                    "memory_%d_x2" % register,
                )
                operator = "behavioral_frontier_register_amplification"
            elif (
                target.startswith("frontier_branch_")
                and parent.controller.kind == "switch"
            ):
                branch = int(target.rsplit("_", 1)[1])
                amplified = parent.controller.children[branch]
                operator = "behavioral_frontier_branch_expansion"
            else:
                continue
            if amplified == parent.controller:
                continue
            controller = TypedController(
                "switch",
                (rule.expression,),
                (amplified, parent.controller),
            )
            child = TypedPolicyProgram(controller, parent.updates)
            if child.candidate_id == parent.candidate_id:
                continue
        except (ValueError, RuntimeError):
            continue
        return child, {
            "operator": operator,
            "target": target,
            "parent_id": parent.candidate_id,
            "contextual_gate_available": True,
            "context_gate": rule.as_dict(),
            "cross_batch_frontier_evidence": dict(evidence),
            "proposal_requires_niche_validation": True,
            "proposal_requires_behavioral_change": True,
        }
    return contextual_repair_typed_policy(
        parent, credit, rng, generation, variant
    )


def contextual_repair_typed_policy(
    parent: TypedPolicyProgram,
    credit: Optional[MechanismCreditReport],
    rng: random.Random,
    generation: int,
    variant: int,
) -> Tuple[TypedPolicyProgram, Mapping[str, Any]]:
    harmful = _harmful_mechanisms(credit)
    if not harmful or credit is None:
        return repair_typed_policy(parent, credit, rng, generation, variant)
    _, _, _, target, evidence = harmful[0]
    rules = learn_context_gates(credit, target)
    if not rules:
        child, record = repair_typed_policy(
            parent, credit, rng, generation, variant
        )
        return child, {
            **record,
            "contextual_gate_available": False,
        }
    rule = rules[variant % len(rules)]
    try:
        if target.startswith("register_"):
            register = int(target.rsplit("_", 1)[1])
            alternative = _replace_feature_in_controller(
                parent.controller, "memory_%d" % register
            )
            operator = "contextual_responsible_register_mask"
        elif (
            target.startswith("controller_branch_")
            and parent.controller.kind == "switch"
        ):
            branch = int(target.rsplit("_", 1)[1])
            alternative = parent.controller.children[1 - branch]
            operator = "contextual_harmful_branch_override"
        else:
            alternative = parent.controller
            for register in range(REGISTER_COUNT):
                alternative = _replace_feature_in_controller(
                    alternative, "memory_%d" % register
                )
            operator = "contextual_persistent_state_mask"
        controller = TypedController(
            "switch",
            (rule.expression,),
            (alternative, parent.controller),
        )
        child = TypedPolicyProgram(controller, parent.updates)
        if child.candidate_id == parent.candidate_id:
            raise ValueError("contextual repair did not change policy identity")
    except (ValueError, RuntimeError):
        child, fallback = repair_typed_policy(
            parent, credit, rng, generation, variant
        )
        return child, {
            **fallback,
            "contextual_gate_available": True,
            "contextual_repair_fell_back": True,
            "rejected_context_gate": rule.as_dict(),
        }
    return child, {
        "operator": operator,
        "target": target,
        "parent_id": parent.candidate_id,
        "mean_original_action_credit": evidence[
            "mean_original_action_credit"
        ],
        "hurt_count": evidence["hurt_count"],
        "helped_count": evidence["helped_count"],
        "contextual_gate_available": True,
        "context_gate": rule.as_dict(),
        "proposal_requires_niche_validation": True,
    }


def repair_typed_policy(
    parent: TypedPolicyProgram,
    credit: Optional[MechanismCreditReport],
    rng: random.Random,
    generation: int,
    child_index: int,
) -> Tuple[TypedPolicyProgram, Mapping[str, Any]]:
    harmful = list(_harmful_mechanisms(credit))
    if not harmful:
        child = mutate_typed_policy(
            parent, rng, generation, child_index
        )
        return child, {
            "operator": "structural_exploration_without_negative_credit",
            "target": None,
            "parent_id": parent.candidate_id,
        }
    _, _, _, target, evidence = min(harmful)
    try:
        if target.startswith("register_"):
            register = int(target.rsplit("_", 1)[1])
            child, operator = _repair_register_update(
                parent, register, child_index
            )
        elif (
            target.startswith("controller_branch_")
            and parent.controller.kind == "switch"
        ):
            branch = int(target.rsplit("_", 1)[1])
            if child_index % 2 == 0:
                controller = TypedController(
                    "switch",
                    (_negated_expression(parent.controller.expressions[0]),),
                    parent.controller.children,
                )
                operator = "redirect_harmful_switch_gate"
            else:
                children = list(parent.controller.children)
                children[branch] = children[1 - branch]
                controller = TypedController(
                    "switch",
                    parent.controller.expressions,
                    tuple(children),
                )
                operator = "replace_harmful_controller_branch"
            child = TypedPolicyProgram(controller, parent.updates)
        else:
            register_evidence = [
                value
                for value in harmful
                if value[3].startswith("register_")
            ]
            register = (
                int(min(register_evidence)[3].rsplit("_", 1)[1])
                if register_evidence
                else rng.randrange(REGISTER_COUNT)
            )
            child, _ = _repair_register_update(parent, register, child_index)
            operator = "repair_state_interaction_via_register_%d" % register
        if child.candidate_id == parent.candidate_id:
            raise ValueError("mechanism repair did not change policy identity")
    except (ValueError, RuntimeError):
        child = mutate_typed_policy(parent, rng, generation, child_index)
        operator = "bounded_structural_repair_fallback"
    return child, {
        "operator": operator,
        "target": target,
        "parent_id": parent.candidate_id,
        "mean_original_action_credit": evidence[
            "mean_original_action_credit"
        ],
        "hurt_count": evidence["hurt_count"],
        "helped_count": evidence["helped_count"],
    }


@dataclass(frozen=True)
class BehavioralFamilyReport:
    candidate_id: str
    family: str
    informative_decisions: int
    action_agreement: Mapping[str, float]
    terminal_match_rate: Mapping[str, float]
    persistent_state_effect_rate: float
    deliberate_open_rate: float
    stateful_and_unclassified: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "family": self.family,
            "informative_decisions": self.informative_decisions,
            "action_agreement": dict(self.action_agreement),
            "terminal_match_rate": dict(self.terminal_match_rate),
            "persistent_state_effect_rate": self.persistent_state_effect_rate,
            "deliberate_open_rate": self.deliberate_open_rate,
            "stateful_and_unclassified": self.stateful_and_unclassified,
        }


def classify_behavioral_family(
    candidate: TypedPolicyProgram,
    probes: Sequence[BinPackingInstance],
) -> BehavioralFamilyReport:
    baselines = baseline_heuristics()
    agreement = {name: 0 for name in baselines}
    informative = 0
    state_effects = 0
    deliberate_opens = 0
    total_decisions = 0
    candidate_counts = []
    baseline_counts = {name: [] for name in baselines}
    ablated = candidate.without_persistent_state()
    for instance in probes:
        loads = []
        history = []
        for item_index, item in enumerate(instance.items):
            state = tuple(loads)
            feasible = sum(load + item <= instance.capacity for load in state)
            action = candidate.choose_bin(
                item, state, instance.capacity, item_index, tuple(history)
            )
            ablated_action = ablated.choose_bin(
                item, state, instance.capacity, item_index, tuple(history)
            )
            total_decisions += 1
            deliberate_opens += int(action is None and feasible > 0)
            if feasible >= 2:
                informative += 1
                state_effects += int(action != ablated_action)
                for name, baseline in baselines.items():
                    agreement[name] += int(
                        action
                        == baseline.choose_bin(
                            item,
                            state,
                            instance.capacity,
                            item_index,
                            tuple(history),
                        )
                    )
            if action is None:
                loads.append(item)
            else:
                loads[action] += item
            history.append(item)
        candidate_counts.append(len(loads))
        for name, baseline in baselines.items():
            baseline_counts[name].append(pack(instance, baseline).bin_count)
    action_rates = {
        name: value / float(max(1, informative))
        for name, value in agreement.items()
    }
    terminal_rates = {
        name: sum(
            candidate_count == baseline_count
            for candidate_count, baseline_count in zip(
                candidate_counts, baseline_counts[name]
            )
        )
        / float(len(probes))
        for name in baselines
    }
    best_name = max(
        baselines,
        key=lambda name: (
            action_rates[name] + terminal_rates[name],
            action_rates[name],
            name,
        ),
    )
    family = (
        best_name + "_like"
        if action_rates[best_name] >= 0.78
        and terminal_rates[best_name] >= 0.70
        else "unclassified"
    )
    effect_rate = state_effects / float(max(1, informative))
    return BehavioralFamilyReport(
        candidate.candidate_id,
        family,
        informative,
        action_rates,
        terminal_rates,
        effect_rate,
        deliberate_opens / float(max(1, total_decisions)),
        family == "unclassified" and effect_rate >= 0.01,
    )


@dataclass(frozen=True)
class BehavioralDeltaReport:
    parent_id: str
    child_id: str
    episode_count: int
    decision_count: int
    changed_decision_count: int
    changed_episode_count: int
    terminal_change_episode_count: int
    mean_child_minus_parent_bins: float

    @property
    def action_change_rate(self) -> float:
        return self.changed_decision_count / float(max(1, self.decision_count))

    def as_dict(self) -> Dict[str, Any]:
        return {
            "parent_id": self.parent_id,
            "child_id": self.child_id,
            "episode_count": self.episode_count,
            "decision_count": self.decision_count,
            "changed_decision_count": self.changed_decision_count,
            "changed_episode_count": self.changed_episode_count,
            "action_change_rate": self.action_change_rate,
            "terminal_change_episode_count": self.terminal_change_episode_count,
            "mean_child_minus_parent_bins": self.mean_child_minus_parent_bins,
        }


def compare_policy_behavior(
    parent: TypedPolicyProgram,
    child: TypedPolicyProgram,
    probes: Sequence[BinPackingInstance],
) -> BehavioralDeltaReport:
    changed_decisions = 0
    changed_episodes = 0
    terminal_changes = 0
    terminal_deltas = []
    decision_count = 0
    for instance in probes:
        parent_result = pack(instance, parent)
        child_result = pack(instance, child)
        if len(parent_result.placements) != len(child_result.placements):
            raise AssertionError("complete policies must place every probe item")
        episode_changes = sum(
            parent_placement.bin_index != child_placement.bin_index
            for parent_placement, child_placement in zip(
                parent_result.placements, child_result.placements
            )
        )
        decision_count += len(parent_result.placements)
        changed_decisions += episode_changes
        changed_episodes += int(episode_changes > 0)
        terminal_delta = child_result.bin_count - parent_result.bin_count
        terminal_deltas.append(terminal_delta)
        terminal_changes += int(terminal_delta != 0)
    return BehavioralDeltaReport(
        parent.candidate_id,
        child.candidate_id,
        len(probes),
        decision_count,
        changed_decisions,
        changed_episodes,
        terminal_changes,
        mean(terminal_deltas) if terminal_deltas else 0.0,
    )


def _behavioral_niche(report: BehavioralFamilyReport) -> str:
    if report.stateful_and_unclassified:
        return "stateful_unclassified"
    return report.family


@dataclass(frozen=True)
class TypedPolicySynthesisConfig:
    lengths: Tuple[int, ...] = (120, 250, 500)
    development_episodes_per_length: Tuple[int, ...] = (2, 3, 5)
    selection_episodes_per_length: int = 10
    validation_episodes_per_length: int = 40
    probe_episode_count: int = 12
    probe_episode_length: int = 80
    capacity: int = 150
    item_low: int = 20
    item_high: int = 100
    base_seed: int = 141_082_026
    population_size: int = 12
    elite_count: int = 4
    selection_pool_size: int = 5
    mutation_seed: int = 124_771
    maximum_credit_decisions_per_episode: int = 3
    maximum_credit_alternatives_per_decision: int = 2
    maximum_contextual_repair_attempts: int = 4
    minimum_state_effect_rate: float = 0.05
    minimum_state_effect_retention: float = 0.50
    positive_evidence_minimum_batches: int = 2
    minimum_amplification_behavior_delta: float = 0.005

    def __post_init__(self) -> None:
        if not self.lengths or min(self.lengths) <= 1:
            raise ValueError("typed-policy episode lengths must exceed one")
        if min(
            *self.development_episodes_per_length,
            self.selection_episodes_per_length,
            self.validation_episodes_per_length,
            self.probe_episode_count,
            self.probe_episode_length,
        ) < 2:
            raise ValueError("typed-policy evidence counts must exceed one")
        if self.population_size != len(initial_typed_policy_population()):
            raise ValueError("typed-policy population must match frozen seeds")
        if not 0 < self.elite_count < self.population_size:
            raise ValueError("invalid typed-policy elite count")
        if not 0 < self.selection_pool_size <= self.population_size:
            raise ValueError("invalid typed-policy selection pool")
        if (
            self.maximum_credit_decisions_per_episode <= 0
            or self.maximum_credit_alternatives_per_decision <= 0
            or self.maximum_contextual_repair_attempts <= 0
        ):
            raise ValueError("invalid mechanism-credit intervention budget")
        if self.positive_evidence_minimum_batches < 2:
            raise ValueError("positive amplification requires multiple batches")
        if not 0.0 <= self.minimum_state_effect_rate <= 1.0:
            raise ValueError("invalid minimum state-effect rate")
        if not 0.0 <= self.minimum_state_effect_retention <= 1.0:
            raise ValueError("invalid state-effect retention fraction")
        if not 0.0 < self.minimum_amplification_behavior_delta <= 1.0:
            raise ValueError("invalid amplification behavior-delta threshold")
        if not 0 < self.item_low <= self.item_high <= self.capacity:
            raise ValueError("invalid typed-policy IID distribution")

    @property
    def improvement_config(self) -> TrajectoryImprovementConfig:
        return TrajectoryImprovementConfig(
            population_size=self.population_size,
            elite_count=self.elite_count,
            selection_pool_size=self.selection_pool_size,
            generation_count=len(self.development_episodes_per_length),
            mutation_seed=self.mutation_seed,
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": TYPED_POLICY_SYNTHESIS_VERSION,
            "lengths": list(self.lengths),
            "development_episodes_per_length": list(
                self.development_episodes_per_length
            ),
            "selection_episodes_per_length": self.selection_episodes_per_length,
            "validation_episodes_per_length": self.validation_episodes_per_length,
            "probe_episode_count": self.probe_episode_count,
            "probe_episode_length": self.probe_episode_length,
            "capacity": self.capacity,
            "item_low_inclusive": self.item_low,
            "item_high_inclusive": self.item_high,
            "base_seed": self.base_seed,
            "maximum_credit_decisions_per_episode": (
                self.maximum_credit_decisions_per_episode
            ),
            "maximum_credit_alternatives_per_decision": (
                self.maximum_credit_alternatives_per_decision
            ),
            "maximum_contextual_repair_attempts": (
                self.maximum_contextual_repair_attempts
            ),
            "minimum_state_effect_rate": self.minimum_state_effect_rate,
            "minimum_state_effect_retention": (
                self.minimum_state_effect_retention
            ),
            "positive_evidence_minimum_batches": (
                self.positive_evidence_minimum_batches
            ),
            "minimum_amplification_behavior_delta": (
                self.minimum_amplification_behavior_delta
            ),
            "improvement": self.improvement_config.as_dict(),
        }


_PARTITION_OFFSETS = {
    "typed_development_0": 150_000_000,
    "typed_development_1": 350_000_000,
    "typed_development_2": 550_000_000,
    "typed_selection": 750_000_000,
    "typed_validation": 950_000_000,
    "typed_behavior_probes": 1_150_000_000,
}


def _instances(
    config: TypedPolicySynthesisConfig,
    partition: str,
    episodes_per_length: int,
    lengths: Optional[Sequence[int]] = None,
) -> Tuple[BinPackingInstance, ...]:
    requested_lengths = tuple(lengths or config.lengths)
    instances = []
    for length_index, length in enumerate(requested_lengths):
        for episode_index in range(episodes_per_length):
            seed = (
                config.base_seed
                + _PARTITION_OFFSETS[partition]
                + length_index * 10_000_000
                + episode_index
            )
            rng = random.Random(seed)
            instances.append(
                BinPackingInstance(
                    "%s:length=%d:seed=%d" % (partition, length, seed),
                    "iid_or_uniform_%d_%d" % (config.item_low, config.item_high),
                    seed,
                    config.capacity,
                    tuple(
                        rng.randint(config.item_low, config.item_high)
                        for _ in range(length)
                    ),
                )
            )
    return tuple(instances)


def _batch(
    config: TypedPolicySynthesisConfig,
    partition: str,
    episodes_per_length: int,
) -> FrozenTrajectoryBatch[BinPackingInstance]:
    instances = _instances(config, partition, episodes_per_length)
    return FrozenTrajectoryBatch(
        partition,
        tuple(instance.instance_id for instance in instances),
        instances,
    )


def _behavior_probes(
    config: TypedPolicySynthesisConfig,
) -> Tuple[BinPackingInstance, ...]:
    return _instances(
        config,
        "typed_behavior_probes",
        config.probe_episode_count,
        (config.probe_episode_length,),
    )


def typed_policy_synthesis_commitment(
    config: TypedPolicySynthesisConfig,
) -> Dict[str, Any]:
    development = tuple(
        _batch(config, "typed_development_%d" % index, count)
        for index, count in enumerate(config.development_episodes_per_length)
    )
    selection = _batch(config, "typed_selection", config.selection_episodes_per_length)
    validation = _batch(
        config, "typed_validation", config.validation_episodes_per_length
    )
    probes = _behavior_probes(config)
    all_ids = tuple(
        episode_id
        for batch in (*development, selection, validation)
        for episode_id in batch.episode_ids
    ) + tuple(probe.instance_id for probe in probes)
    if len(set(all_ids)) != len(all_ids):
        raise AssertionError("typed-policy evidence partitions overlap")
    commitment: Dict[str, Any] = {
        "schema": 1,
        "version": TYPED_POLICY_SYNTHESIS_VERSION,
        "config": config.as_dict(),
        "typed_grammar": {
            "scalar_operators": sorted(EXPR_ARITY),
            "features": list(ACTION_FEATURES),
            "controller_kinds": list(CONTROLLER_KINDS),
            "persistent_update_kinds": list(UPDATE_KINDS),
            "register_count": REGISTER_COUNT,
            "maximum_expression_depth": MAX_EXPRESSION_DEPTH,
            "maximum_controller_depth": MAX_CONTROLLER_DEPTH,
            "maximum_program_nodes": MAX_PROGRAM_NODES,
        },
        "initial_population": [
            policy.as_dict() for policy in initial_typed_policy_population()
        ],
        "development_batches": [batch.as_dict() for batch in development],
        "selection_batch": selection.as_dict(),
        "validation_batch": validation.as_dict(),
        "behavior_probe_digest": content_digest(
            tuple(probe.instance_id for probe in probes)
        ),
        "behavioral_families": sorted(baseline_heuristics()),
        "behavioral_family_role": (
            "preserve one objective-ranked elite per behavioral niche; excluded "
            "from terminal fitness and qualified adoption"
        ),
        "mechanism_credit": {
            "intervention": (
                "force an alternative at a state-dependent decision, then replay "
                "the complete suffix with consistent persistent state"
            ),
            "signal": (
                "counterfactual terminal bins minus original terminal bins"
            ),
            "maximum_decisions_per_episode": (
                config.maximum_credit_decisions_per_episode
            ),
            "maximum_alternatives_per_decision": (
                config.maximum_credit_alternatives_per_decision
            ),
            "uses_development_trajectories_only": True,
            "evaluated_for_ranked_elite_parents_only": True,
            "new_elites_are_backfilled_on_available_development_batches": True,
            "future_development_batches_available": False,
            "used_by_adoption_rule": False,
        },
        "contextual_repair": {
            "gate_features": list(CONTEXT_GATE_FEATURES),
            "rule_family": "one-dimensional closed intervals",
            "maximum_attempts": config.maximum_contextual_repair_attempts,
            "targeted_child_must_preserve_parent_niche": True,
            "minimum_state_effect_rate": config.minimum_state_effect_rate,
            "minimum_state_effect_retention": (
                config.minimum_state_effect_retention
            ),
        },
        "positive_amplification": {
            "register_amplification_factor": 2.0,
            "interventions": [
                "replace a referenced register with its doubled feature",
                "force the inactive branch of a switch controller",
            ],
            "branch_credit_is_normalized_to_the_target_branch": True,
            "evidence_history_is_candidate_specific": True,
            "minimum_supporting_development_batches": (
                config.positive_evidence_minimum_batches
            ),
            "each_supporting_batch_requires_positive_net_terminal_credit": True,
            "gates_with_negative_net_credit_on_any_batch_are_rejected": True,
            "requires_positive_action_changing_counterfactual": True,
            "minimum_parent_child_action_change_rate": (
                config.minimum_amplification_behavior_delta
            ),
            "targeted_child_must_preserve_parent_niche": True,
            "used_by_adoption_rule": False,
        },
        "optimization_signal": (
            "negative terminal excess-bin count per complete episode"
        ),
        "mutation": (
            "candidate-specific cross-batch frontier gates expand helpful "
            "amplified-register actions or inactive branches only when they "
            "measurably change behavior; "
            "otherwise credit-targeted contextual gates mask harmful mechanisms; "
            "bounded structural exploration when no niche-preserving repair exists"
        ),
        "conservative_adoption": (
            "mutation requires positive paired 95% return confidence over the "
            "best initial typed policy"
        ),
        "comparator_access": "FunSearch only after frozen selection_id",
        "candidate_fallback_policy": None,
        "prior_validation_reused": False,
    }
    commitment["commitment_id"] = content_digest(commitment)
    return commitment


def _evaluate_absolute_return(
    candidate: TypedPolicyProgram,
    batch: FrozenTrajectoryBatch[BinPackingInstance],
) -> AbsoluteTrajectoryEvaluation:
    returns = []
    rows = []
    for instance in batch.experiments:
        result = pack(instance, candidate)
        lower_bound = math.ceil(sum(instance.items) / float(instance.capacity))
        excess = result.bin_count - lower_bound
        returns.append(-float(excess))
        rows.append(
            {
                "instance_id": instance.instance_id,
                "length": len(instance.items),
                "bin_count": result.bin_count,
                "volume_lower_bound": lower_bound,
                "excess_bins": excess,
                "return": -float(excess),
            }
        )
    return AbsoluteTrajectoryEvaluation(
        candidate.candidate_id,
        batch.batch_id,
        batch.episode_ids,
        tuple(returns),
        {"episodes": rows},
    )


def _compare_after_freeze(
    candidate: TypedPolicyProgram,
    instances: Sequence[BinPackingInstance],
    selection_id: str,
) -> Dict[str, Any]:
    from scientist.domains.binpacking.heuristics import FunSearchORReference

    comparator = FunSearchORReference()
    rows = []
    for instance in instances:
        candidate_bins = pack(instance, candidate).bin_count
        comparator_bins = pack(instance, comparator).bin_count
        rows.append(
            {
                "instance_id": instance.instance_id,
                "length": len(instance.items),
                "candidate_bins": candidate_bins,
                "funsearch_bins": comparator_bins,
                "improvement": comparator_bins - candidate_bins,
            }
        )
    evidence = paired_episode_evidence(
        (row["improvement"] for row in rows),
        tuple(row["instance_id"] for row in rows),
    )
    by_length = {}
    for length in sorted({row["length"] for row in rows}):
        selected = tuple(row for row in rows if row["length"] == length)
        by_length[str(length)] = paired_episode_evidence(
            (row["improvement"] for row in selected),
            tuple(row["instance_id"] for row in selected),
        ).as_dict()
    return {
        "selection_id": selection_id,
        "candidate_id": candidate.candidate_id,
        "comparator": comparator.name,
        "comparator_opened_after_selection": True,
        "evidence": evidence.as_dict(),
        "by_length": by_length,
        "screen_passed": (
            evidence.mean_ci_lower > 0.0
            and all(value["mean_improvement"] >= 0.0 for value in by_length.values())
        ),
        "episodes": rows,
    }


def run_typed_policy_synthesis(
    config: TypedPolicySynthesisConfig,
    *,
    commitment: Optional[Mapping[str, Any]] = None,
    progress: Optional[Callable[[str, Mapping[str, Any]], None]] = None,
) -> Dict[str, Any]:
    frozen_commitment = typed_policy_synthesis_commitment(config)
    if commitment is not None and dict(commitment) != frozen_commitment:
        raise ValueError("typed-policy commitment does not match config")
    development = tuple(
        _batch(config, "typed_development_%d" % index, count)
        for index, count in enumerate(config.development_episodes_per_length)
    )
    selection = _batch(config, "typed_selection", config.selection_episodes_per_length)
    probes = _behavior_probes(config)
    behavior_reports: Dict[str, BehavioralFamilyReport] = {}
    credit_reports: Dict[str, MechanismCreditReport] = {}
    latest_credit: Dict[str, MechanismCreditReport] = {}
    credit_history: Dict[str, list[Tuple[str, MechanismCreditReport]]] = {}
    repair_records: Dict[str, Mapping[str, Any]] = {}

    def behavior_report(candidate: TypedPolicyProgram) -> BehavioralFamilyReport:
        report = behavior_reports.get(candidate.candidate_id)
        if report is None:
            report = classify_behavioral_family(candidate, probes)
            behavior_reports[candidate.candidate_id] = report
        return report

    def prepare_mutation(
        parents: Sequence[TypedPolicyProgram],
        batch: FrozenTrajectoryBatch[BinPackingInstance],
    ) -> None:
        batch_index = next(
            index
            for index, development_batch in enumerate(development)
            if development_batch.batch_id == batch.batch_id
        )
        for candidate in parents:
            for evidence_batch in development[: batch_index + 1]:
                report_key = "%s:%s" % (
                    evidence_batch.batch_id,
                    candidate.candidate_id,
                )
                report = credit_reports.get(report_key)
                if report is None:
                    report = assign_mechanism_credit(
                        candidate,
                        evidence_batch.experiments,
                        maximum_decisions_per_episode=(
                            config.maximum_credit_decisions_per_episode
                        ),
                        maximum_alternatives_per_decision=(
                            config.maximum_credit_alternatives_per_decision
                        ),
                    )
                    credit_reports[report_key] = report
                    credit_history.setdefault(
                        candidate.candidate_id, []
                    ).append((evidence_batch.batch_id, report))
                if evidence_batch.batch_id == batch.batch_id:
                    latest_credit[candidate.candidate_id] = report

    def repair(
        parent: TypedPolicyProgram,
        rng: random.Random,
        generation: int,
        child_index: int,
    ) -> TypedPolicyProgram:
        parent_behavior = behavior_report(parent)
        base_variant = child_index // config.elite_count
        rejected_attempts = []
        child = None
        record: Mapping[str, Any] = {}
        for attempt in range(config.maximum_contextual_repair_attempts):
            proposal, proposal_record = positive_amplification_typed_policy(
                parent,
                latest_credit.get(parent.candidate_id),
                tuple(
                    credit_history.get(parent.candidate_id, ())
                ),
                rng,
                generation,
                base_variant + attempt,
                minimum_batches=config.positive_evidence_minimum_batches,
            )
            if proposal_record.get("target") is None:
                child, record = proposal, proposal_record
                break
            proposal_behavior = behavior_report(proposal)
            parent_niche = _behavioral_niche(parent_behavior)
            proposal_niche = _behavioral_niche(proposal_behavior)
            required_state_effect = (
                max(
                    config.minimum_state_effect_rate,
                    parent_behavior.persistent_state_effect_rate
                    * config.minimum_state_effect_retention,
                )
                if parent_behavior.stateful_and_unclassified
                else 0.0
            )
            niche_preserved = parent_niche == proposal_niche
            state_effect_preserved = (
                proposal_behavior.persistent_state_effect_rate
                >= required_state_effect
            )
            behavior_delta = compare_policy_behavior(parent, proposal, probes)
            behavior_change_required = bool(
                proposal_record.get("proposal_requires_behavioral_change")
            )
            behavior_changed = (
                not behavior_change_required
                or behavior_delta.action_change_rate
                >= config.minimum_amplification_behavior_delta
            )
            validation = {
                "parent_niche": parent_niche,
                "proposal_niche": proposal_niche,
                "parent_state_effect_rate": (
                    parent_behavior.persistent_state_effect_rate
                ),
                "proposal_state_effect_rate": (
                    proposal_behavior.persistent_state_effect_rate
                ),
                "required_state_effect_rate": required_state_effect,
                "niche_preserved": niche_preserved,
                "state_effect_preserved": state_effect_preserved,
                "behavior_change_required": behavior_change_required,
                "minimum_action_change_rate": (
                    config.minimum_amplification_behavior_delta
                    if behavior_change_required
                    else 0.0
                ),
                "behavior_changed": behavior_changed,
                "behavioral_delta": behavior_delta.as_dict(),
            }
            if niche_preserved and state_effect_preserved and behavior_changed:
                child = proposal
                record = {
                    **proposal_record,
                    "niche_validation": validation,
                    "rejected_contextual_attempts": rejected_attempts,
                }
                break
            rejected_attempts.append(
                {
                    "candidate_id": proposal.candidate_id,
                    "operator": proposal_record.get("operator"),
                    "context_gate": proposal_record.get("context_gate"),
                    "cross_batch_frontier_evidence": proposal_record.get(
                        "cross_batch_frontier_evidence"
                    ),
                    "niche_validation": validation,
                }
            )
        if child is None:
            child = mutate_typed_policy(
                parent, rng, generation, child_index
            )
            record = {
                "operator": (
                    "structural_exploration_after_contextual_niche_rejection"
                ),
                "target": None,
                "parent_id": parent.candidate_id,
                "rejected_contextual_attempts": rejected_attempts,
            }
        repair_records[child.candidate_id] = {
            **record,
            "child_id": child.candidate_id,
            "generation": generation,
            "child_index": child_index,
        }
        return child

    outcome = run_absolute_trajectory_improvement(
        config.improvement_config,
        initial_typed_policy_population(),
        development,
        selection,
        _evaluate_absolute_return,
        repair,
        diversity_key=lambda candidate: _behavioral_niche(
            behavior_report(candidate)
        ),
        prepare_mutation=prepare_mutation,
        progress=progress,
    )
    unique_candidates = {}
    for generation in outcome.generations:
        for record in generation:
            unique_candidates[record.candidate.candidate_id] = record.candidate
    for record in outcome.selection_records:
        unique_candidates[record.candidate.candidate_id] = record.candidate
    for candidate_id, candidate in sorted(unique_candidates.items()):
        behavior_report(candidate)
    selected_behavior = behavior_reports[outcome.selected_candidate.candidate_id]
    frozen_selection = {
        "status": "frozen_before_comparator_access",
        "selection_id": outcome.selection_id,
        "candidate_id": outcome.selected_candidate.candidate_id,
        "candidate": outcome.selected_candidate.as_dict(),
        "improvement_demonstrated": outcome.improvement_demonstrated,
        "improvement_evidence": outcome.improvement_evidence,
        "behavioral_family": selected_behavior.as_dict(),
        "novel_stateful_claim_eligible": (
            outcome.improvement_demonstrated
            and selected_behavior.stateful_and_unclassified
        ),
        "funsearch_evaluated_during_synthesis": False,
    }
    validation = _compare_after_freeze(
        outcome.selected_candidate,
        _instances(
            config,
            "typed_validation",
            config.validation_episodes_per_length,
        ),
        outcome.selection_id,
    )
    if progress is not None:
        progress(
            "typed_policy_validation_complete",
            {
                "screen_passed": validation["screen_passed"],
                "mean_improvement": validation["evidence"]["mean_improvement"],
                "mean_ci_lower": validation["evidence"]["mean_improvement_ci_lower"],
                "mean_ci_upper": validation["evidence"]["mean_improvement_ci_upper"],
                "behavioral_family": selected_behavior.family,
                "persistent_state_effect_rate": (
                    selected_behavior.persistent_state_effect_rate
                ),
            },
        )
    report: Dict[str, Any] = {
        "schema": 1,
        "version": TYPED_POLICY_SYNTHESIS_VERSION,
        "status": "completed",
        "commitment": frozen_commitment,
        "synthesis": outcome.as_dict(),
        "behavioral_classification": {
            candidate_id: value.as_dict()
            for candidate_id, value in behavior_reports.items()
        },
        "mechanism_credit_assignment": {
            "reports": {
                candidate_id: value.as_dict()
                for candidate_id, value in sorted(credit_reports.items())
            },
            "repairs": {
                candidate_id: dict(value)
                for candidate_id, value in sorted(repair_records.items())
            },
            "credit_used_as_fitness": False,
            "credit_used_for_targeted_repair_only": True,
        },
        "selection": frozen_selection,
        "validation": validation,
        "architecture_audit": {
            "open_ended_typed_programs": True,
            "persistent_state_identity_bearing": True,
            "compositional_non_scalar_controllers": True,
            "full_episode_absolute_return_only": True,
            "qualified_conservative_adoption": True,
            "known_family_classification": True,
            "behavioral_family_diversity_preserved_during_synthesis": True,
            "behavioral_novelty_not_added_to_objective": True,
            "mechanism_credit_from_exact_terminal_suffix_rollouts": True,
            "mechanism_credit_used_for_targeted_repair_only": True,
            "decision_conditional_repairs": True,
            "targeted_repairs_must_preserve_behavioral_niche": True,
            "targeted_repairs_must_retain_state_effect": True,
            "positive_mechanisms_require_cross_batch_support": True,
            "positive_mechanism_history_is_candidate_specific": True,
            "new_elite_history_is_backfilled_from_development_only": True,
            "positive_credit_is_normalized_to_proposed_target": True,
            "amplified_register_actions_are_counterfactually_tested": True,
            "inactive_controller_branches_are_counterfactually_tested": True,
            "positive_frontier_requires_action_changing_evidence": True,
            "positive_frontier_requires_parent_child_behavior_delta": True,
            "positive_amplification_is_decision_conditional": True,
            "candidate_fallback_policy": None,
            "generic_synthesis_has_incumbent_input": False,
            "prior_validation_reused": False,
            "comparator_opened_only_after_selection": True,
        },
        "confirmation_executed": False,
    }
    report["report_id"] = content_digest(report)
    return report
