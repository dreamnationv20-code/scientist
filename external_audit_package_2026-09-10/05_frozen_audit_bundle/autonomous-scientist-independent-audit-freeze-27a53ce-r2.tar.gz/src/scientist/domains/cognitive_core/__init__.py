"""Synthetic laboratory for cognitive-core hypotheses.

Exports are loaded lazily so importing a qualification submodule does not
execute unrelated domain adapters outside the audited dependency closure.
"""

from importlib import import_module
from typing import Any


_EXPORT_MODULES = {
    "CognitiveCoreAdapter": "scientist.domains.cognitive_core.adapter",
    "CognitiveProbeFactory": "scientist.domains.cognitive_core.generators",
    "generate_probe": "scientist.domains.cognitive_core.generators",
    "generate_suite": "scientist.domains.cognitive_core.generators",
    "knowledge_table": "scientist.domains.cognitive_core.generators",
    "ABSTAIN": "scientist.domains.cognitive_core.models",
    "CognitiveObservation": "scientist.domains.cognitive_core.models",
    "CognitiveProbe": "scientist.domains.cognitive_core.models",
    "ProbeInput": "scientist.domains.cognitive_core.models",
    "ProbeKind": "scientist.domains.cognitive_core.models",
    "PolicyKind": "scientist.domains.cognitive_core.policies",
    "ReferencePolicy": "scientist.domains.cognitive_core.policies",
}

__all__ = sorted(_EXPORT_MODULES)


def __getattr__(name: str) -> Any:
    try:
        module_name = _EXPORT_MODULES[name]
    except KeyError as error:
        raise AttributeError(name) from error
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value
