from __future__ import annotations

from typing import Any, Dict, Iterable, Mapping, Protocol, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.models import (
    ABSTAIN,
    CognitiveFailure,
    CognitiveObservation,
    CognitiveProbe,
    Decision,
    ProbeInput,
)
from scientist.domains.cognitive_core.semantics import reconstruct_expected
from scientist.kernel.contracts import ExecutionMode, SearchFamily
from scientist.kernel.capabilities import (
    ComparisonMode,
    DomainCapability,
    DomainCapabilityManifest,
    ResearchMode,
)
from scientist.kernel.interfaces import PairedComparison, VerificationResult


class CognitiveCandidate(Protocol):
    name: str

    def as_dict(self) -> Mapping[str, Any]:
        ...

    def predict(self, public_input: ProbeInput) -> Decision:
        ...


class CognitiveCoreAdapter:
    domain_id = "cognitive_core_minilab"
    adapter_version = "cognitive-core-adapter-v1"
    evaluator_ref = "cognitive-core-public-input-runner-v1"
    verifier_ref = "cognitive-core-independent-semantics-v1"
    execution_mode = ExecutionMode.DETERMINISTIC
    capabilities = DomainCapabilityManifest(
        domain_id=domain_id,
        research_modes=(
            ResearchMode.OPTIMIZATION,
            ResearchMode.PHENOMENON_DISCOVERY,
            ResearchMode.EXPLANATION,
        ),
        capabilities=(
            DomainCapability.PAIRED_COMPARISON,
            DomainCapability.BEHAVIOR_FINGERPRINT,
            DomainCapability.FAILURE_MINIMIZATION,
            DomainCapability.HYPOTHESIS_CONTRAST,
            DomainCapability.EXPERIMENT_GENERATION,
            DomainCapability.TRAINABLE_CANDIDATE,
            DomainCapability.INTERVENTION,
            DomainCapability.ABLATION,
        ),
        comparison_mode=ComparisonMode.PAIRED_INCUMBENT,
        primary_metric="improvement",
        independent_evidence_unit="probe world and seed",
        manifest_ref="cognitive-core-capabilities-v1",
    )

    def candidate_id(self, candidate: CognitiveCandidate) -> str:
        return content_digest(candidate.as_dict())

    def candidate_as_dict(
        self,
        candidate: CognitiveCandidate,
    ) -> Mapping[str, Any]:
        payload = dict(candidate.as_dict())
        payload["candidate_id"] = self.candidate_id(candidate)
        return payload

    def experiment_id(self, experiment: CognitiveProbe) -> str:
        return experiment.probe_id

    def experiment_as_dict(
        self,
        experiment: CognitiveProbe,
    ) -> Mapping[str, Any]:
        return experiment.as_dict()

    def observation_as_dict(
        self,
        observation: CognitiveObservation,
    ) -> Mapping[str, Any]:
        return observation.as_dict()

    def observation_id(
        self,
        observation: CognitiveObservation,
    ) -> str:
        return content_digest(observation.as_dict())

    def evaluate(
        self,
        candidate: CognitiveCandidate,
        experiment: CognitiveProbe,
    ) -> CognitiveObservation:
        decision = candidate.predict(experiment.public_input)
        return CognitiveObservation(
            candidate_id=self.candidate_id(candidate),
            probe_id=experiment.probe_id,
            predicted_answer=decision.label,
            confidence=decision.confidence,
            source=decision.source,
            reported_correct=decision.label == experiment.expected_answer,
        )

    def verify(
        self,
        experiment: CognitiveProbe,
        observation: CognitiveObservation,
    ) -> VerificationResult:
        reconstructed = reconstruct_expected(experiment)
        expected_matches = reconstructed == experiment.expected_answer
        label_valid = (
            observation.predicted_answer == ABSTAIN
            or 0
            <= observation.predicted_answer
            < experiment.public_input.value_modulus
        )
        confidence_valid = 0.0 <= observation.confidence <= 1.0
        identity_ok = observation.probe_id == experiment.probe_id
        correctness = observation.predicted_answer == reconstructed
        reported_correct = observation.reported_correct == correctness
        checks = {
            "probe_identity": identity_ok,
            "expected_answer_reconstructed": expected_matches,
            "prediction_in_label_space": label_valid,
            "confidence_in_range": confidence_valid,
            "reported_correct_reconstructed": reported_correct,
            "candidate_identity_present": bool(observation.candidate_id),
            "source_present": bool(observation.source),
        }
        return VerificationResult(
            passed=all(checks.values()),
            checks=checks,
            details={
                "reconstructed_answer": reconstructed,
                "reported_expected_answer": experiment.expected_answer,
                "prediction": observation.predicted_answer,
                "reconstructed_correct": correctness,
            },
            verifier_ref=self.verifier_ref,
        )

    def compare(
        self,
        candidate: CognitiveCandidate,
        incumbent: CognitiveCandidate,
        experiment: CognitiveProbe,
    ) -> PairedComparison:
        candidate_observation = self.evaluate(candidate, experiment)
        incumbent_observation = self.evaluate(incumbent, experiment)
        candidate_correct = float(candidate_observation.reported_correct)
        incumbent_correct = float(incumbent_observation.reported_correct)
        return PairedComparison(
            candidate_id=self.candidate_id(candidate),
            incumbent_id=self.candidate_id(incumbent),
            experiment_id=experiment.probe_id,
            metrics={
                "candidate_correct": candidate_correct,
                "incumbent_correct": incumbent_correct,
                "primary_delta": candidate_correct - incumbent_correct,
                "improvement": candidate_correct - incumbent_correct,
            },
        )

    def observation_metrics(
        self,
        experiment: CognitiveProbe,
        observation: CognitiveObservation,
    ) -> Mapping[str, float]:
        del experiment
        return {
            "correct": float(observation.reported_correct),
            "confidence": float(observation.confidence),
            "abstained": float(observation.predicted_answer == ABSTAIN),
        }

    def behavior_fingerprint(
        self,
        candidate: CognitiveCandidate,
        experiments: Iterable[CognitiveProbe],
    ) -> str:
        return content_digest(
            [
                {
                    "probe_id": experiment.probe_id,
                    "prediction": self.evaluate(
                        candidate,
                        experiment,
                    ).predicted_answer,
                }
                for experiment in experiments
            ]
        )

    def minimize_failure(
        self,
        experiment: CognitiveProbe,
        better: CognitiveCandidate,
        worse: CognitiveCandidate,
    ) -> CognitiveFailure:
        return CognitiveFailure(
            probe=experiment,
            better_answer=self.evaluate(
                better,
                experiment,
            ).predicted_answer,
            worse_answer=self.evaluate(
                worse,
                experiment,
            ).predicted_answer,
        )

    def search_families(self) -> Tuple[SearchFamily, ...]:
        return (
            SearchFamily.ANCESTRY,
            SearchFamily.DE_NOVO,
            SearchFamily.HYBRID,
        )
