from __future__ import annotations

import math
from collections import Counter, defaultdict
from statistics import mean, median
from typing import Any, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.internal_canonical_alignment_v52xa import (
    hidden_retrieval_metrics,
)


ALIGNMENT_FAILURE_DIAGNOSTIC_VERSION = (
    "general-cognitive-alignment-failure-diagnostic-v52xb"
)
M52XB_SEED = 53121
M52XB_M52XA_AUDIT_ID = (
    "1fd0a18592fc1df437060952c8feba1187c6fb5564c0b5efbb8ac98e6bdbbcc5"
)
M52XB_STEPS = (0, 30, 60, 120)
M52XB_RECIPROCAL_DIRECTION_PAIRS = (
    ("name->principle", "principle->name"),
    ("principle->action", "action->principle"),
)


def _ranking_groups(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[tuple[str, str, str, str], Tuple[Mapping[str, Any], ...]]:
    groups: dict[tuple[str, str, str, str], list[Mapping[str, Any]]] = defaultdict(
        list
    )
    for row in records:
        groups[
            (
                str(row["family"]),
                str(row["basis_state_key"]),
                str(row["basis_transformation"]),
                str(row["candidate_transformation"]),
            )
        ].append(row)
    return {key: tuple(value) for key, value in groups.items()}


def comparison_trajectories(
    records_by_step: Mapping[int, Sequence[Mapping[str, Any]]],
) -> Tuple[Mapping[str, Any], ...]:
    if tuple(sorted(records_by_step)) != M52XB_STEPS:
        raise ValueError("M52xb requires parent, step 30, step 60, and step 120")
    indices = {
        step: {str(row["record_id"]): row for row in records}
        for step, records in records_by_step.items()
    }
    if any(set(index) != set(indices[0]) for index in indices.values()):
        raise ValueError("M52xb checkpoint records must describe identical probe rows")
    trajectories = []
    for group in _ranking_groups(records_by_step[120]).values():
        positive = [row for row in group if row["target"] == "YES"]
        negatives = [row for row in group if row["target"] == "NO"]
        if len(positive) != 1 or len(negatives) != 3:
            raise ValueError("M52xb requires one positive and three negatives per group")
        positive_id = str(positive[0]["record_id"])
        for negative in negatives:
            negative_id = str(negative["record_id"])
            gaps = {
                str(step): float(indices[step][positive_id]["margin"])
                - float(indices[step][negative_id]["margin"])
                for step in M52XB_STEPS
            }
            trajectories.append(
                {
                    "family": str(positive[0]["family"]),
                    "direction": str(positive[0]["descriptor_direction"]),
                    "basis_state_key": str(positive[0]["basis_state_key"]),
                    "negative_candidate_state_key": str(
                        negative["candidate_state_key"]
                    ),
                    "basis_transformation": str(
                        positive[0]["basis_transformation"]
                    ),
                    "candidate_transformation": str(
                        positive[0]["candidate_transformation"]
                    ),
                    "positive_record_id": positive_id,
                    "negative_record_id": negative_id,
                    "gaps": gaps,
                }
            )
    return tuple(trajectories)


def horizon_metrics(
    trajectories: Sequence[Mapping[str, Any]],
    records_by_step: Mapping[int, Sequence[Mapping[str, Any]]],
    forecast_step: int = 240,
) -> Mapping[str, Any]:
    unresolved = [row for row in trajectories if float(row["gaps"]["120"]) <= 0.0]
    if not unresolved:
        raise ValueError("M52xb horizon diagnosis requires unresolved comparisons")
    improved_last = [
        float(row["gaps"]["120"]) > float(row["gaps"]["60"])
        for row in unresolved
    ]
    improved_parent = [
        float(row["gaps"]["120"]) > float(row["gaps"]["0"])
        for row in unresolved
    ]
    monotonic = [
        all(
            float(row["gaps"][str(right)]) > float(row["gaps"][str(left)])
            for left, right in zip(M52XB_STEPS, M52XB_STEPS[1:])
        )
        for row in unresolved
    ]
    projections = []
    interval = M52XB_STEPS[-1] - M52XB_STEPS[-2]
    for row in unresolved:
        gap_previous = float(row["gaps"][str(M52XB_STEPS[-2])])
        gap_final = float(row["gaps"][str(M52XB_STEPS[-1])])
        gain = gap_final - gap_previous
        projection = (
            float(M52XB_STEPS[-1]) + interval * (-gap_final) / gain
            if gain > 0.0
            else math.inf
        )
        projections.append(projection)
    finite = sorted(value for value in projections if math.isfinite(value))
    aggregate = {
        str(step): {
            "ranking_accuracy": hidden_retrieval_metrics(records)["ranking"][
                "ranking_accuracy"
            ],
            "top1_accuracy": hidden_retrieval_metrics(records)["ranking"][
                "top1_accuracy"
            ],
        }
        for step, records in records_by_step.items()
    }
    return {
        "comparison_count": len(trajectories),
        "unresolved_comparison_count": len(unresolved),
        "last_interval_improvement_count": sum(improved_last),
        "last_interval_improvement_rate": sum(improved_last) / len(unresolved),
        "last_interval_worsening_or_flat_count": len(unresolved)
        - sum(improved_last),
        "last_interval_worsening_or_flat_rate": 1.0
        - sum(improved_last) / len(unresolved),
        "parent_to_final_improvement_count": sum(improved_parent),
        "parent_to_final_improvement_rate": sum(improved_parent) / len(unresolved),
        "strictly_monotonic_improvement_count": sum(monotonic),
        "strictly_monotonic_improvement_rate": sum(monotonic) / len(unresolved),
        "finite_linear_projection_count": len(finite),
        "projected_crossing_by_step": int(forecast_step),
        "projected_crossing_by_step_count": sum(
            value <= float(forecast_step) for value in projections
        ),
        "projected_crossing_by_step_rate": sum(
            value <= float(forecast_step) for value in projections
        )
        / len(unresolved),
        "median_finite_projected_crossing_step": median(finite) if finite else None,
        "aggregate_checkpoint_metrics": aggregate,
        "aggregate_improves_monotonically": all(
            float(aggregate[str(left)]["ranking_accuracy"])
            < float(aggregate[str(right)]["ranking_accuracy"])
            and float(aggregate[str(left)]["top1_accuracy"])
            < float(aggregate[str(right)]["top1_accuracy"])
            for left, right in zip(M52XB_STEPS, M52XB_STEPS[1:])
        ),
    }


def _similarity_matrices(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[tuple[str, str, str, str], Mapping[tuple[str, str], float]]:
    matrices: dict[
        tuple[str, str, str, str], dict[tuple[str, str], float]
    ] = defaultdict(dict)
    for row in records:
        matrices[
            (
                str(row["family"]),
                str(row["descriptor_direction"]),
                str(row["basis_transformation"]),
                str(row["candidate_transformation"]),
            )
        ][(str(row["basis_state_key"]), str(row["candidate_state_key"]))] = float(
            row["margin"]
        )
    return matrices


def hubness_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    matrices = _similarity_matrices(records)
    wrong_attractors: Counter[tuple[str, str]] = Counter()
    selection_indegree: Counter[tuple[str, str]] = Counter()
    error_count = 0
    errors_to_highest_column = 0
    family_error_counts: Counter[str] = Counter()
    family_direction_error_counts: Counter[tuple[str, str]] = Counter()
    directions_by_family: dict[str, set[str]] = defaultdict(set)
    states_by_family: dict[str, set[str]] = defaultdict(set)
    for (family, direction, _, _), matrix in matrices.items():
        directions_by_family[family].add(direction)
        states = sorted({basis for basis, _ in matrix})
        states_by_family[family].update(states)
        column_means = {
            candidate: mean(matrix[(basis, candidate)] for basis in states)
            for candidate in states
        }
        highest_column = max(states, key=lambda candidate: column_means[candidate])
        for basis in states:
            predicted = max(
                states, key=lambda candidate: matrix[(basis, candidate)]
            )
            selection_indegree[(family, predicted)] += 1
            if predicted != basis:
                error_count += 1
                family_error_counts[family] += 1
                family_direction_error_counts[(family, direction)] += 1
                wrong_attractors[(family, predicted)] += 1
                errors_to_highest_column += predicted == highest_column
    matrix_count_by_family = {
        family: sum(1 for key in matrices if key[0] == family)
        for family in states_by_family
    }
    recurrent_threshold_by_family = {
        family: max(2, math.ceil(matrix_count / 2))
        for family, matrix_count in matrix_count_by_family.items()
    }
    recurrent_error_count = sum(
        count
        for (family, _), count in wrong_attractors.items()
        if count >= recurrent_threshold_by_family[family]
    )
    indegrees_by_family = {
        family: {
            state: int(selection_indegree[(family, state)])
            for state in sorted(states)
        }
        for family, states in states_by_family.items()
    }
    ideal_by_family = dict(matrix_count_by_family)
    maximum_indegree_ratio = max(
        max(indegrees_by_family[family].values()) / ideal_by_family[family]
        for family in indegrees_by_family
    )
    multiple_formulations = any(
        matrix_count_by_family[family] != len(directions_by_family[family])
        for family in states_by_family
    )
    result = {
        "top1_group_count": len(matrices) * 4,
        "top1_error_count": error_count,
        "errors_to_highest_mean_similarity_column": errors_to_highest_column,
        "errors_to_highest_mean_similarity_column_rate": errors_to_highest_column
        / max(error_count, 1),
        "errors_to_recurrent_family_attractor": recurrent_error_count,
        "errors_to_recurrent_family_attractor_rate": recurrent_error_count
        / max(error_count, 1),
        "recurrent_attractor_definition": (
            "a candidate selected incorrectly at least half as many times as there are "
            "transformation-specific direction matrices within its family (minimum two)"
            if multiple_formulations
            else "a candidate selected incorrectly by at least two basis queries within its "
            "family across trained directions"
        ),
        "maximum_candidate_selection_indegree_ratio_to_ideal": maximum_indegree_ratio,
        "selection_indegree_by_family": indegrees_by_family,
        "ideal_selection_indegree_by_family": ideal_by_family,
        "wrong_attractor_counts": {
            f"{family}|{candidate}": int(count)
            for (family, candidate), count in sorted(wrong_attractors.items())
        },
        "top1_errors_by_family": dict(sorted(family_error_counts.items())),
        "top1_errors_by_family_direction": {
            f"{family}|{direction}": int(count)
            for (family, direction), count in sorted(
                family_direction_error_counts.items()
            )
        },
    }
    if multiple_formulations:
        result["recurrent_attractor_threshold_by_family"] = {
            family: int(value)
            for family, value in recurrent_threshold_by_family.items()
        }
    return result


def _pearson(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right) or not left:
        raise ValueError("M52xb Pearson inputs must be equally sized and nonempty")
    left_mean = mean(left)
    right_mean = mean(right)
    numerator = sum(
        (x - left_mean) * (y - right_mean) for x, y in zip(left, right)
    )
    denominator = math.sqrt(
        sum((x - left_mean) ** 2 for x in left)
        * sum((y - right_mean) ** 2 for y in right)
    )
    return numerator / denominator if denominator else 0.0


def reciprocity_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    matrices = _similarity_matrices(records)
    retrieval = hidden_retrieval_metrics(records)
    families = sorted({key[0] for key in matrices})
    pairs = {}
    for forward, reverse in M52XB_RECIPROCAL_DIRECTION_PAIRS:
        correlations = []
        absolute_differences = []
        family_correlations: dict[str, list[float]] = defaultdict(list)
        family_differences: dict[str, list[float]] = defaultdict(list)
        for family in families:
            forward_keys = sorted(
                key
                for key in matrices
                if key[0] == family and key[1] == forward
            )
            for _, _, basis_transform, candidate_transform in forward_keys:
                forward_matrix = matrices[
                    (family, forward, basis_transform, candidate_transform)
                ]
                reverse_matrix = matrices[
                    (family, reverse, candidate_transform, basis_transform)
                ]
                semantic_pairs = sorted(forward_matrix)
                left = [forward_matrix[pair] for pair in semantic_pairs]
                right = [
                    reverse_matrix[(candidate, basis)]
                    for basis, candidate in semantic_pairs
                ]
                correlation = _pearson(left, right)
                difference = mean(abs(x - y) for x, y in zip(left, right))
                correlations.append(correlation)
                absolute_differences.append(difference)
                family_correlations[family].append(correlation)
                family_differences[family].append(difference)
        by_family = {}
        for family in families:
            value = {
                "reciprocal_correlation": mean(family_correlations[family]),
                "mean_absolute_similarity_difference": mean(
                    family_differences[family]
                ),
            }
            if len(family_correlations[family]) > 1:
                value.update(
                    {
                        "minimum_formulation_reciprocal_correlation": min(
                            family_correlations[family]
                        ),
                        "formulation_pair_count": len(
                            family_correlations[family]
                        ),
                    }
                )
            by_family[family] = value
        forward_ranking = float(
            retrieval["by_direction"][forward]["ranking"]["ranking_accuracy"]
        )
        reverse_ranking = float(
            retrieval["by_direction"][reverse]["ranking"]["ranking_accuracy"]
        )
        pairs[f"{forward}|{reverse}"] = {
            "mean_reciprocal_correlation": mean(correlations),
            "minimum_family_reciprocal_correlation": min(correlations),
            "mean_absolute_similarity_difference": mean(absolute_differences),
            "forward_ranking_accuracy": forward_ranking,
            "reverse_ranking_accuracy": reverse_ranking,
            "absolute_direction_ranking_gap": abs(
                forward_ranking - reverse_ranking
            ),
            "by_family": by_family,
        }
    return {
        "pairs": pairs,
        "weakest_pair_mean_reciprocal_correlation": min(
            value["mean_reciprocal_correlation"] for value in pairs.values()
        ),
        "maximum_direction_ranking_gap": max(
            value["absolute_direction_ranking_gap"] for value in pairs.values()
        ),
    }


def diagnostic_decision(
    horizon: Mapping[str, Any],
    hubness: Mapping[str, Any],
    reciprocity: Mapping[str, Any],
    contract: Mapping[str, Mapping[str, float]],
) -> Mapping[str, Any]:
    horizon_checks = {
        "minimum_last_interval_improvement_rate": float(
            horizon["last_interval_improvement_rate"]
        )
        >= float(contract["horizon"]["minimum_last_interval_improvement_rate"]),
        "minimum_parent_to_final_improvement_rate": float(
            horizon["parent_to_final_improvement_rate"]
        )
        >= float(contract["horizon"]["minimum_parent_to_final_improvement_rate"]),
        "minimum_projected_crossing_by_step_rate": float(
            horizon["projected_crossing_by_step_rate"]
        )
        >= float(contract["horizon"]["minimum_projected_crossing_by_step_rate"]),
        "maximum_last_interval_worsening_or_flat_rate": float(
            horizon["last_interval_worsening_or_flat_rate"]
        )
        <= float(
            contract["horizon"]["maximum_last_interval_worsening_or_flat_rate"]
        ),
    }
    hubness_checks = {
        "minimum_highest_column_error_rate": float(
            hubness["errors_to_highest_mean_similarity_column_rate"]
        )
        >= float(contract["hubness"]["minimum_highest_column_error_rate"]),
        "minimum_recurrent_attractor_error_rate": float(
            hubness["errors_to_recurrent_family_attractor_rate"]
        )
        >= float(contract["hubness"]["minimum_recurrent_attractor_error_rate"]),
        "minimum_maximum_indegree_ratio_to_ideal": float(
            hubness["maximum_candidate_selection_indegree_ratio_to_ideal"]
        )
        >= float(
            contract["hubness"]["minimum_maximum_indegree_ratio_to_ideal"]
        ),
        "minimum_unresolved_worsening_or_flat_rate": float(
            horizon["last_interval_worsening_or_flat_rate"]
        )
        >= float(
            contract["hubness"]["minimum_unresolved_worsening_or_flat_rate"]
        ),
    }
    role_checks = {
        "maximum_weakest_pair_mean_reciprocity_correlation": float(
            reciprocity["weakest_pair_mean_reciprocal_correlation"]
        )
        <= float(
            contract["role_asymmetry"][
                "maximum_weakest_pair_mean_reciprocity_correlation"
            ]
        ),
        "minimum_direction_ranking_gap": float(
            reciprocity["maximum_direction_ranking_gap"]
        )
        >= float(contract["role_asymmetry"]["minimum_direction_ranking_gap"]),
    }
    horizon_supported = all(horizon_checks.values())
    hubness_supported = all(hubness_checks.values())
    role_asymmetry_supported = all(role_checks.values())
    if hubness_supported and role_asymmetry_supported:
        diagnosis = "role_conditioned_hubness_limit"
        intervention = "role_balanced_hubness_corrected_multiview_alignment"
    elif hubness_supported:
        diagnosis = "hubness_limit"
        intervention = "hubness_corrected_multiview_alignment"
    elif horizon_supported:
        diagnosis = "training_horizon_limit"
        intervention = "preregistered_longer_alignment_schedule"
    else:
        diagnosis = "mixed_or_underdetermined"
        intervention = "new_discovery_only_discriminating_experiment"
    return {
        "diagnosis": diagnosis,
        "recommended_intervention": intervention,
        "horizon_supported": horizon_supported,
        "hubness_supported": hubness_supported,
        "role_asymmetry_supported": role_asymmetry_supported,
        "horizon_checks": horizon_checks,
        "hubness_checks": hubness_checks,
        "role_asymmetry_checks": role_checks,
    }
