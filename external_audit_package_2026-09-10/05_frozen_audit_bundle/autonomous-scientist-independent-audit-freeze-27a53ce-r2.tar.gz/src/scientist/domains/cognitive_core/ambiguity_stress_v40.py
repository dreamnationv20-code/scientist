from __future__ import annotations

import hashlib
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    enumerate_interventions,
    legal_values,
)
from scientist.domains.cognitive_core.evidence_algebra_v39 import (
    CandidateTrace,
    EvidenceCase,
    _canonical,
    analyze_evidence,
    evidence_cases,
    task_evidence_matrix,
)
from scientist.domains.cognitive_core.proposal_verification_v36 import fixed_case_partition
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    REPRESENTATIONS,
    RepairTask,
    _build_task,
    execute,
)


AMBIGUITY_STRESS_VERSION = "general-cognitive-ambiguity-stress-v40"
M40_SPLIT_SEEDS = {"development": 40061, "test": 40109}
MAX_CORRUPTED_OBSERVATIONS = 1
STATUSES = ("resolved", "experiment_required", "representation_inadequate")
REGIMES = (
    "partial_observation",
    "short_horizon_alias",
    "bounded_noise",
    "clean_resolvable",
    "missing_candidate",
    "two_fault_out_of_vocabulary",
)


@dataclass(frozen=True)
class AmbiguityScenario:
    scenario_id: str
    source_task_id: str
    representation: str
    regime: str
    expected_status: str
    cases: Tuple[EvidenceCase, ...]
    candidates: Tuple[CandidateTrace, ...]
    correct_candidate_id: str | None
    diagnostic_case: EvidenceCase | None = None
    diagnostic_predictions: Tuple[Any, ...] | None = None


def robust_evidence_policy(
    cases: Sequence[EvidenceCase],
    candidates: Sequence[CandidateTrace],
    *,
    max_corrupted_observations: int = MAX_CORRUPTED_OBSERVATIONS,
) -> Mapping[str, Any]:
    if max_corrupted_observations < 0:
        raise ValueError("max_corrupted_observations must be non-negative")
    base = analyze_evidence(cases, candidates)
    by_ordinal = sorted(candidates, key=lambda item: item.ordinal)
    contradictions = {
        candidate.candidate_id: len(
            base["candidates"][candidate.candidate_id]["contradiction_case_ids"]
        )
        for candidate in by_ordinal
    }
    robust_frontier = tuple(
        candidate.candidate_id
        for candidate in by_ordinal
        if contradictions[candidate.candidate_id] <= max_corrupted_observations
    )
    zero_contradiction = tuple(
        candidate.candidate_id
        for candidate in by_ordinal
        if contradictions[candidate.candidate_id] == 0
    )
    if (
        len(robust_frontier) == 1
        and len(zero_contradiction) == 1
        and robust_frontier == zero_contradiction
    ):
        status = "resolved"
        resolved = robust_frontier[0]
    elif robust_frontier:
        status = "experiment_required"
        resolved = None
    else:
        status = "representation_inadequate"
        resolved = None
    payload = {
        "version": AMBIGUITY_STRESS_VERSION,
        "status": status,
        "max_corrupted_observations": max_corrupted_observations,
        "robust_frontier_ids": list(robust_frontier),
        "zero_contradiction_ids": list(zero_contradiction),
        "resolved_candidate_id": resolved,
        "minimum_contradictions": min(contradictions.values()),
        "suspected_corruption": bool(robust_frontier and not zero_contradiction),
        "candidate_contradictions": contradictions,
        "base_analysis_id": base["analysis_id"],
        "base_status": base["status"],
        "calibrated_abstention": status != "resolved",
    }
    return {**payload, "policy_id": content_digest(payload)}


def build_m40_suite(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[RepairTask, ...]:
    if split not in M40_SPLIT_SEEDS:
        raise ValueError("unknown M40 split")
    rng = random.Random(M40_SPLIT_SEEDS[split])
    tasks = tuple(
        _build_task(f"m40_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("M40 task ids are not unique")
    return tasks


def _scenario_id(task: RepairTask, regime: str, variant: Any = None) -> str:
    payload = {
        "task_id": task.task_id,
        "regime": regime,
        "variant": variant,
        "version": AMBIGUITY_STRESS_VERSION,
    }
    return "m40-" + content_digest(payload)[:20]


def _correct_key(task: RepairTask) -> str:
    return f"{task.target_node}={json.dumps(task.correct_edit_value, sort_keys=True)}"


def _partial_scenario(task: RepairTask) -> AmbiguityScenario:
    selected = (evidence_cases(task, "passive")[0],)
    cases, traces, _ = task_evidence_matrix(
        task, "active", selected_cases=selected
    )
    return AmbiguityScenario(
        _scenario_id(task, "partial_observation"),
        task.task_id,
        task.representation,
        "partial_observation",
        "experiment_required",
        cases,
        traces,
        _correct_key(task),
    )


def _short_horizon_scenario(task: RepairTask) -> AmbiguityScenario | None:
    pool = evidence_cases(task, "active")
    for count in range(2, len(pool)):
        selected = pool[:count]
        cases, traces, _ = task_evidence_matrix(
            task, "active", selected_cases=selected
        )
        policy = robust_evidence_policy(cases, traces)
        if policy["status"] != "experiment_required":
            continue
        current = len(policy["robust_frontier_ids"])
        best = None
        for extra in pool[count:]:
            expanded_cases, expanded_traces, _ = task_evidence_matrix(
                task, "active", selected_cases=selected + (extra,)
            )
            expanded = robust_evidence_policy(expanded_cases, expanded_traces)
            reduction = current - len(expanded["robust_frontier_ids"])
            if reduction > 0 and (best is None or reduction > best[0]):
                best = (reduction, extra)
        if best is None:
            continue
        extra = best[1]
        diagnostic = EvidenceCase(f"case_{len(cases) + 1}", extra["expected"])
        predictions = []
        interventions = enumerate_interventions(task)
        for intervention in interventions:
            try:
                predictions.append(execute(task.representation, intervention.program, extra["input"]))
            except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
                predictions.append({"execution_error": True})
        return AmbiguityScenario(
            _scenario_id(task, "short_horizon_alias", count),
            task.task_id,
            task.representation,
            "short_horizon_alias",
            "experiment_required",
            cases,
            traces,
            _correct_key(task),
            diagnostic,
            tuple(predictions),
        )
    return None


def _clean_resolvable_scenario(task: RepairTask) -> AmbiguityScenario | None:
    cases, traces, _ = task_evidence_matrix(task, "active")
    policy = robust_evidence_policy(cases, traces)
    if policy["status"] != "resolved" or policy["resolved_candidate_id"] != _correct_key(task):
        return None
    return AmbiguityScenario(
        _scenario_id(task, "clean_resolvable"),
        task.task_id,
        task.representation,
        "clean_resolvable",
        "resolved",
        cases,
        traces,
        _correct_key(task),
    )


def _bounded_noise_scenario(
    task: RepairTask, clean: AmbiguityScenario
) -> AmbiguityScenario | None:
    correct = clean.correct_candidate_id
    assert correct is not None
    trace_by_id = {trace.candidate_id: trace for trace in clean.candidates}
    correct_trace = trace_by_id[correct]
    for case_index, case in enumerate(clean.cases):
        alternatives = sorted(clean.candidates, key=lambda item: item.ordinal)
        for alternative in alternatives:
            replacement = alternative.predictions[case_index]
            if _canonical(replacement) == _canonical(correct_trace.predictions[case_index]):
                continue
            corrupted_cases = list(clean.cases)
            corrupted_cases[case_index] = EvidenceCase(case.case_id, replacement)
            policy = robust_evidence_policy(tuple(corrupted_cases), clean.candidates)
            if (
                policy["status"] == "experiment_required"
                and correct in set(policy["robust_frontier_ids"])
            ):
                return AmbiguityScenario(
                    _scenario_id(task, "bounded_noise", case_index),
                    task.task_id,
                    task.representation,
                    "bounded_noise",
                    "experiment_required",
                    tuple(corrupted_cases),
                    clean.candidates,
                    correct,
                )
    return None


def _missing_candidate_scenario(
    task: RepairTask, clean: AmbiguityScenario
) -> AmbiguityScenario:
    remaining = tuple(
        candidate
        for candidate in clean.candidates
        if candidate.candidate_id != clean.correct_candidate_id
    )
    return AmbiguityScenario(
        _scenario_id(task, "missing_candidate"),
        task.task_id,
        task.representation,
        "missing_candidate",
        "representation_inadequate",
        clean.cases,
        remaining,
        None,
    )


def _double_fault_task(task: RepairTask, node: str, value: Any) -> RepairTask:
    candidate = dict(task.candidate)
    candidate[node] = value
    return RepairTask(
        task_id=task.task_id + "-double-" + hashlib.sha256(
            f"{node}={_canonical(value)}".encode("utf-8")
        ).hexdigest()[:8],
        split=task.split,
        representation=task.representation,
        candidate=candidate,
        authority=task.authority,
        target_node=task.target_node,
        failure_type=task.failure_type,
        visible_correct=task.visible_correct,
        counterexample=task.counterexample,
        hidden_cases=task.hidden_cases,
    )


def _two_fault_scenario(task: RepairTask) -> AmbiguityScenario | None:
    for node in sorted(task.candidate):
        if node == task.target_node:
            continue
        for value in legal_values(task, node):
            if value == task.authority[node]:
                continue
            double = _double_fault_task(task, node, value)
            cases, traces, _ = task_evidence_matrix(double, "active")
            policy = robust_evidence_policy(cases, traces)
            if policy["status"] == "representation_inadequate":
                return AmbiguityScenario(
                    _scenario_id(task, "two_fault_out_of_vocabulary", (node, value)),
                    task.task_id,
                    task.representation,
                    "two_fault_out_of_vocabulary",
                    "representation_inadequate",
                    cases,
                    traces,
                    None,
                )
    return None


def build_m40_scenarios(tasks: Sequence[RepairTask]) -> Tuple[AmbiguityScenario, ...]:
    scenarios = []
    for task in tasks:
        scenarios.append(_partial_scenario(task))
        short = _short_horizon_scenario(task)
        if short is not None:
            scenarios.append(short)
        clean = _clean_resolvable_scenario(task)
        if clean is not None:
            scenarios.append(clean)
            noisy = _bounded_noise_scenario(task, clean)
            if noisy is not None:
                scenarios.append(noisy)
            scenarios.append(_missing_candidate_scenario(task, clean))
        double = _two_fault_scenario(task)
        if double is not None:
            scenarios.append(double)
    if len({scenario.scenario_id for scenario in scenarios}) != len(scenarios):
        raise RuntimeError("M40 scenario ids are not unique")
    return tuple(scenarios)


def _opaque_invariance(scenario: AmbiguityScenario) -> bool:
    candidates = sorted(scenario.candidates, key=lambda item: item.ordinal)
    group_names = {
        group: f"opaque_group_{index + 1}"
        for index, group in enumerate(sorted({item.group_id for item in candidates}))
    }
    forward = {
        item.candidate_id: f"opaque_candidate_{len(candidates) - index:03d}"
        for index, item in enumerate(candidates)
    }
    opaque = tuple(
        CandidateTrace(
            forward[item.candidate_id],
            group_names[item.group_id],
            item.ordinal,
            item.predictions,
        )
        for item in reversed(candidates)
    )
    original_result = robust_evidence_policy(scenario.cases, scenario.candidates)
    opaque_result = robust_evidence_policy(scenario.cases, opaque)
    reverse = {value: key for key, value in forward.items()}
    return bool(
        original_result["status"] == opaque_result["status"]
        and set(original_result["robust_frontier_ids"])
        == {reverse[value] for value in opaque_result["robust_frontier_ids"]}
        and original_result["resolved_candidate_id"]
        == (
            reverse.get(opaque_result["resolved_candidate_id"])
            if opaque_result["resolved_candidate_id"] is not None
            else None
        )
    )


def _zero_noise_status(scenario: AmbiguityScenario) -> str:
    base = analyze_evidence(scenario.cases, scenario.candidates)["status"]
    return {
        "resolved": "resolved",
        "ambiguous": "experiment_required",
        "representation_inadequate": "representation_inadequate",
    }[base]


def _append_diagnostic(scenario: AmbiguityScenario) -> Mapping[str, Any] | None:
    if scenario.diagnostic_case is None or scenario.diagnostic_predictions is None:
        return None
    candidates = tuple(
        CandidateTrace(
            item.candidate_id,
            item.group_id,
            item.ordinal,
            item.predictions + (scenario.diagnostic_predictions[index],),
        )
        for index, item in enumerate(scenario.candidates)
    )
    return robust_evidence_policy(scenario.cases + (scenario.diagnostic_case,), candidates)


def evaluate_scenarios(scenarios: Sequence[AmbiguityScenario]) -> Mapping[str, Any]:
    records = []
    by_regime: Dict[str, list[Mapping[str, float]]] = {}
    by_representation: Dict[str, list[Mapping[str, float]]] = {}
    for scenario in scenarios:
        result = robust_evidence_policy(scenario.cases, scenario.candidates)
        baseline_status = _zero_noise_status(scenario)
        correct_retained = (
            scenario.correct_candidate_id in set(result["robust_frontier_ids"])
            if scenario.correct_candidate_id is not None
            else True
        )
        resolved_exact = (
            result["resolved_candidate_id"] == scenario.correct_candidate_id
            if result["status"] == "resolved"
            else True
        )
        diagnostic = _append_diagnostic(scenario)
        diagnostic_reduction = (
            len(result["robust_frontier_ids"]) - len(diagnostic["robust_frontier_ids"])
            if diagnostic is not None
            else 0
        )
        item = {
            "status_correct": float(result["status"] == scenario.expected_status),
            "baseline_status_correct": float(baseline_status == scenario.expected_status),
            "false_confident": float(
                result["status"] == "resolved" and scenario.expected_status != "resolved"
            ),
            "correct_retained": float(correct_retained),
            "correct_retention_eligible": float(scenario.correct_candidate_id is not None),
            "resolved_exact": float(resolved_exact),
            "resolved_exact_eligible": float(result["status"] == "resolved"),
            "nonresolved_expected": float(scenario.expected_status != "resolved"),
            "invariant": float(_opaque_invariance(scenario)),
            "diagnostic_reduction": float(diagnostic_reduction),
        }
        by_regime.setdefault(scenario.regime, []).append(item)
        by_representation.setdefault(scenario.representation, []).append(item)
        records.append(
            {
                "scenario_id": scenario.scenario_id,
                "source_task_id": scenario.source_task_id,
                "representation": scenario.representation,
                "regime": scenario.regime,
                "expected_status": scenario.expected_status,
                "predicted_status": result["status"],
                "correct_candidate_id": scenario.correct_candidate_id,
                "policy": result,
                "zero_noise_baseline_status": baseline_status,
                "label_invariant": bool(item["invariant"]),
                "diagnostic_result": diagnostic,
                "diagnostic_frontier_reduction": diagnostic_reduction,
            }
        )

    def summarize(items: Sequence[Mapping[str, float]]) -> Mapping[str, float]:
        retention_denominator = sum(item["correct_retention_eligible"] for item in items)
        resolution_denominator = sum(item["resolved_exact_eligible"] for item in items)
        nonresolved_denominator = sum(item["nonresolved_expected"] for item in items)
        return {
            "status_accuracy": sum(item["status_correct"] for item in items) / len(items),
            "zero_noise_baseline_accuracy": sum(
                item["baseline_status_correct"] for item in items
            ) / len(items),
            "false_confident_resolution_rate": sum(item["false_confident"] for item in items)
            / nonresolved_denominator
            if nonresolved_denominator
            else 0.0,
            "correct_candidate_retention_rate": sum(
                item["correct_retained"] * item["correct_retention_eligible"]
                for item in items
            )
            / retention_denominator
            if retention_denominator
            else 1.0,
            "correct_candidate_retention_eligible_count": retention_denominator,
            "resolved_candidate_accuracy": sum(
                item["resolved_exact"] * item["resolved_exact_eligible"]
                for item in items
            )
            / resolution_denominator
            if resolution_denominator
            else 1.0,
            "resolved_candidate_accuracy_eligible_count": resolution_denominator,
            "label_invariance_rate": sum(item["invariant"] for item in items) / len(items),
            "mean_diagnostic_frontier_reduction": sum(
                item["diagnostic_reduction"] for item in items
            ) / len(items),
        }

    overall = summarize(
        [item for items in by_regime.values() for item in items]
    )
    expected_counts = {status: 0 for status in STATUSES}
    expected_correct = {status: 0 for status in STATUSES}
    for record in records:
        expected_counts[record["expected_status"]] += 1
        expected_correct[record["expected_status"]] += int(
            record["expected_status"] == record["predicted_status"]
        )
    return {
        "scenario_count": len(records),
        **overall,
        "status_accuracy_gain_over_zero_noise": (
            overall["status_accuracy"] - overall["zero_noise_baseline_accuracy"]
        ),
        "recall_by_expected_status": {
            status: expected_correct[status] / expected_counts[status]
            for status in STATUSES
        },
        "counts_by_expected_status": expected_counts,
        "by_regime": {
            regime: {"scenario_count": len(items), **summarize(items)}
            for regime, items in sorted(by_regime.items())
        },
        "by_representation": {
            representation: {"scenario_count": len(items), **summarize(items)}
            for representation, items in sorted(by_representation.items())
        },
        "records": records,
    }


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def prepare_m40_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    tasks = build_m40_suite("test", 30)
    scenarios = build_m40_scenarios(tasks)
    public_hash = _write_jsonl(
        output / "test-public.jsonl",
        (
            {
                "scenario_id": scenario.scenario_id,
                "source_task_id": scenario.source_task_id,
                "representation": scenario.representation,
                "case_count": len(scenario.cases),
                "candidate_count": len(scenario.candidates),
            }
            for scenario in scenarios
        ),
    )
    authority_hash = _write_jsonl(
        output / "test-authority.jsonl",
        (
            {
                "scenario_id": scenario.scenario_id,
                "regime": scenario.regime,
                "expected_status": scenario.expected_status,
                "correct_candidate_id": scenario.correct_candidate_id,
            }
            for scenario in scenarios
        ),
    )
    counts_by_regime = {
        regime: sum(int(scenario.regime == regime) for scenario in scenarios)
        for regime in REGIMES
    }
    counts_by_representation = {
        representation: sum(
            int(scenario.representation == representation) for scenario in scenarios
        )
        for representation in REPRESENTATIONS
    }
    payload = {
        "version": AMBIGUITY_STRESS_VERSION,
        "split_seeds": M40_SPLIT_SEEDS,
        "representations": list(REPRESENTATIONS),
        "regimes": list(REGIMES),
        "statuses": list(STATUSES),
        "max_corrupted_observations": MAX_CORRUPTED_OBSERVATIONS,
        "counts": {
            "test_source_tasks": len(tasks),
            "test_scenarios": len(scenarios),
            "by_regime": counts_by_regime,
            "by_representation": counts_by_representation,
        },
        "hashes": {"test_public": public_hash, "test_authority": authority_hash},
        "policy_contract": {
            "resolved": "one_zero_contradiction_candidate_is_the_only_candidate_within_noise_budget",
            "experiment_required": "one_or_more_candidates_remain_within_noise_budget_but_resolution_is_not_unique_and_clean",
            "representation_inadequate": "every_candidate_exceeds_the_frozen_noise_budget",
            "regime_label_visible_to_policy": False,
            "model_use": False,
        },
        "gates": {
            "minimum_scenario_count": 600,
            "minimum_each_regime_count": 70,
            "minimum_overall_status_accuracy": 0.95,
            "minimum_experiment_required_recall": 0.95,
            "minimum_representation_inadequate_recall": 0.95,
            "minimum_resolved_recall": 0.98,
            "maximum_false_confident_resolution_rate": 0.02,
            "minimum_correct_candidate_retention": 0.98,
            "minimum_resolved_candidate_accuracy": 0.98,
            "minimum_label_invariance": 1.0,
            "minimum_each_representation_accuracy": 0.90,
            "minimum_two_fault_inadequacy_accuracy": 0.90,
            "minimum_bounded_noise_experiment_accuracy": 0.95,
            "minimum_short_horizon_diagnostic_reduction": 1.0,
            "minimum_gain_over_zero_noise_baseline": 0.10,
        },
        "claim_boundary": (
            "M40 tests deterministic decision calibration under a frozen one-corrupted-observation model "
            "on synthetic finite typed mechanisms. It includes partial evidence, aliases, bounded noise, "
            "missing candidates, and identifiable two-fault out-of-vocabulary cases. It does not invent "
            "experiments or representations and does not claim that noise and model inadequacy are separable "
            "without the stated corruption bound."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m40_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    tasks = build_m40_suite("test", 30)
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": content_digest(payload) == freeze["freeze_id"],
        "gates_and_policy_frozen": "gates" in freeze and "policy_contract" in freeze,
        "no_training_or_model_artifact": (
            not (output / "train.jsonl").exists()
            and freeze["policy_contract"]["model_use"] is False
        ),
        "diagnostic_and_final_cases_disjoint": all(
            {_canonical(case["input"]) for case in fixed_case_partition(task)[0]}.isdisjoint(
                {_canonical(case["input"]) for case in fixed_case_partition(task)[1]}
            )
            for task in tasks
        ),
        "all_regimes_present": all(
            freeze["counts"]["by_regime"][regime] > 0 for regime in REGIMES
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}


def evaluate_m40(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    scenarios = build_m40_scenarios(build_m40_suite("test", 30))
    evaluation = evaluate_scenarios(scenarios)
    records = evaluation.pop("records")
    store = ArtifactStore(output_root)
    predictions_digest = store.put("ambiguity_stress_predictions", records)
    payload = {
        "version": AMBIGUITY_STRESS_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "metrics": evaluation,
        "predictions_digest": predictions_digest,
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"ambiguity-stress-{manifest['evaluation_id']}", manifest)
    return manifest


def assess_m40(evaluation: Mapping[str, Any], benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["gates"]
    metrics = evaluation["metrics"]
    regimes = metrics["by_regime"]
    checks = {
        "same_benchmark_freeze": evaluation["benchmark_freeze_id"] == freeze["freeze_id"],
        "scenario_count": metrics["scenario_count"] >= gates["minimum_scenario_count"],
        "each_regime_count": all(
            row["scenario_count"] >= gates["minimum_each_regime_count"]
            for row in regimes.values()
        ),
        "overall_status_accuracy": metrics["status_accuracy"]
        >= gates["minimum_overall_status_accuracy"],
        "experiment_required_recall": metrics["recall_by_expected_status"]["experiment_required"]
        >= gates["minimum_experiment_required_recall"],
        "representation_inadequate_recall": metrics["recall_by_expected_status"][
            "representation_inadequate"
        ]
        >= gates["minimum_representation_inadequate_recall"],
        "resolved_recall": metrics["recall_by_expected_status"]["resolved"]
        >= gates["minimum_resolved_recall"],
        "false_confident_resolution": metrics["false_confident_resolution_rate"]
        <= gates["maximum_false_confident_resolution_rate"],
        "correct_candidate_retention": metrics["correct_candidate_retention_rate"]
        >= gates["minimum_correct_candidate_retention"],
        "resolved_candidate_accuracy": metrics["resolved_candidate_accuracy"]
        >= gates["minimum_resolved_candidate_accuracy"],
        "label_invariance": metrics["label_invariance_rate"]
        >= gates["minimum_label_invariance"],
        "each_representation_accuracy": all(
            row["status_accuracy"] >= gates["minimum_each_representation_accuracy"]
            for row in metrics["by_representation"].values()
        ),
        "two_fault_inadequacy_accuracy": regimes["two_fault_out_of_vocabulary"][
            "status_accuracy"
        ]
        >= gates["minimum_two_fault_inadequacy_accuracy"],
        "bounded_noise_experiment_accuracy": regimes["bounded_noise"]["status_accuracy"]
        >= gates["minimum_bounded_noise_experiment_accuracy"],
        "short_horizon_diagnostic_reduction": regimes["short_horizon_alias"][
            "mean_diagnostic_frontier_reduction"
        ]
        >= gates["minimum_short_horizon_diagnostic_reduction"],
        "gain_over_zero_noise_baseline": metrics["status_accuracy_gain_over_zero_noise"]
        >= gates["minimum_gain_over_zero_noise_baseline"],
    }
    payload = {
        "version": AMBIGUITY_STRESS_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "evaluation_id": evaluation["evaluation_id"],
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
    }
    return {**payload, "assessment_id": content_digest(payload)}
