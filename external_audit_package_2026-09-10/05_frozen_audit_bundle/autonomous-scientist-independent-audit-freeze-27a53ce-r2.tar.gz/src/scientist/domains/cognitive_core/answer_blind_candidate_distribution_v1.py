"""Teacher-forced candidate likelihoods and distribution distances."""
from __future__ import annotations

import hashlib
import math
import time
from typing import Any, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.answer_blind_verdict_likelihood_v2 import render_user_prompt


VERSION = "cognitive-repairability-answer-blind-candidate-distribution-v1"


def evaluate_candidate(
    *, model: Any, tokenizer: Any, job: Mapping[str, Any], runner_version: str
) -> Mapping[str, Any]:
    import mlx.core as mx

    rendered = render_user_prompt(tokenizer, str(job["prompt"]))
    completion = str(job["candidate_completion"])
    prefix_ids = tokenizer.encode(rendered, add_special_tokens=False)
    full_ids = tokenizer.encode(rendered + completion, add_special_tokens=False)
    if not prefix_ids or full_ids[: len(prefix_ids)] != prefix_ids:
        raise RuntimeError("candidate tokenization is not a prompt-prefix extension")
    candidate_ids = full_ids[len(prefix_ids) :]
    if not candidate_ids or len(full_ids) > 512:
        raise RuntimeError("candidate tokenization violates bounds")
    started = time.monotonic()
    logits = model(mx.array([full_ids[:-1]]))
    positions = mx.arange(len(prefix_ids) - 1, len(full_ids) - 1)
    continuation = logits[0, positions, :].astype(mx.float32)
    targets = mx.array(candidate_ids)
    selected = mx.take_along_axis(continuation, targets[:, None], axis=-1).squeeze(-1)
    token_logprobs = (selected - mx.logsumexp(continuation, axis=-1)).astype(mx.float32)
    total_value = mx.sum(token_logprobs).astype(mx.float32)
    mx.eval(token_logprobs, total_value)
    values = [float(value) for value in token_logprobs.tolist()]
    total = float(total_value.item())
    if not values or not math.isfinite(total) or not all(math.isfinite(value) for value in values):
        raise RuntimeError("candidate likelihood is missing or nonfinite")
    body = {
        **{key: value for key, value in job.items() if key not in {"prompt", "prompt_contract"}},
        "runner_version": runner_version,
        "distribution_version": VERSION,
        "rendered_prompt_sha256": hashlib.sha256(rendered.encode("utf-8")).hexdigest(),
        "candidate_token_ids": candidate_ids,
        "candidate_token_count": len(candidate_ids),
        "token_logprobabilities": values,
        "total_log_likelihood": total,
        "likelihood_accumulation_dtype": "float32",
        "elapsed_seconds": time.monotonic() - started,
        "executed": True,
        "autoregressive_generation_performed": False,
        "correctness_authority_accessed": False,
    }
    return {**body, "record_id": content_digest(body)}


def normalized_distribution(
    rows: Sequence[Mapping[str, Any]], candidates: Sequence[str]
) -> list[float]:
    by_candidate = {str(row["candidate"]): float(row["total_log_likelihood"]) for row in rows}
    if set(by_candidate) != set(candidates) or len(rows) != len(candidates):
        raise RuntimeError("candidate likelihood vector is incomplete")
    values = [by_candidate[candidate] for candidate in candidates]
    maximum = max(values)
    weights = [math.exp(value - maximum) for value in values]
    total = sum(weights)
    if not math.isfinite(total) or total <= 0:
        raise RuntimeError("candidate normalization failed")
    return [weight / total for weight in weights]


def jensen_shannon(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right) or not left:
        raise ValueError("distribution shape mismatch")
    middle = [(a + b) / 2 for a, b in zip(left, right)]

    def kl(first: Sequence[float], second: Sequence[float]) -> float:
        return sum(a * math.log(a / b) for a, b in zip(first, second) if a > 0)

    value = (kl(left, middle) + kl(right, middle)) / 2
    if not math.isfinite(value) or value < -1e-12:
        raise RuntimeError("invalid Jensen-Shannon divergence")
    return max(0.0, value)
