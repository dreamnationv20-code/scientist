from __future__ import annotations

import json
from typing import Any, Mapping

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.answer_blind_nonstreaming_generation_v1 import (
    ADAPTER_VERSION,
    generate_raw_payload,
)
from scientist.domains.cognitive_core.answer_blind_transport_v1 import (
    TRANSPORT_VERSION,
    encode_emission,
    prompt_view,
    verify_round_trip,
)
from scientist.domains.cognitive_core.answer_blind_typed_candidate_extractor_v1 import (
    schema_valid,
)


EXACT_FORMAT_CHANNEL_VERSION = "cognitive-repairability-answer-blind-exact-format-copy-channel-v1"
EXACT_FORMAT_CLASSIFICATIONS = frozenset(
    (
        "exact_format_compliant",
        "full_response_not_one_json_object",
        "schema_invalid_object",
        "public_content_mismatch",
        "truncated_output",
        "empty_output",
        "runtime_error_sentinel",
        "model_load_failure_sentinel",
        "wall_cap_sentinel",
        "worker_failure_sentinel",
    )
)
ALLOWED_OUTER_WHITESPACE = " \t\r\n"


class _DuplicateMemberError(ValueError):
    pass


def _unique_object(pairs: list[tuple[str, Any]]) -> Mapping[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise _DuplicateMemberError(key)
        value[key] = item
    return value


def _reject_nonstandard_constant(value: str) -> Any:
    raise ValueError(value)


def _canonical(value: Mapping[str, Any]) -> str:
    return json.dumps(dict(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def classify_exact_format_payload(
    raw_response: str,
    finish_reason: str,
    declared_output_type: str,
    public_fields: Mapping[str, Any],
    type_schemas: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    """Classify full-consumption JSON without repair, projection, or normalization."""

    if declared_output_type not in type_schemas:
        raise ValueError("unknown declared output type")
    stripped = raw_response.strip(ALLOWED_OUTER_WHITESPACE)
    base = {
        "classifier_version": EXACT_FORMAT_CHANNEL_VERSION,
        "declared_output_type": declared_output_type,
        "allowed_outer_whitespace_codepoints": [9, 10, 13, 32],
        "outer_whitespace_removed_characters": len(raw_response) - len(stripped),
        "full_response_consumed": False,
        "canonical_candidate": None,
        "public_fields_canonical": _canonical(public_fields),
        "repair_or_normalization": False,
    }
    if finish_reason == "length":
        return {**base, "classification": "truncated_output"}
    if raw_response == "" or stripped == "":
        return {**base, "classification": "empty_output"}
    try:
        value = json.loads(
            stripped,
            object_pairs_hook=_unique_object,
            parse_constant=_reject_nonstandard_constant,
        )
    except (json.JSONDecodeError, _DuplicateMemberError, ValueError):
        return {**base, "classification": "full_response_not_one_json_object"}
    if not isinstance(value, dict):
        return {**base, "classification": "full_response_not_one_json_object"}
    candidate = _canonical(value)
    parsed = {
        **base,
        "full_response_consumed": True,
        "canonical_candidate": candidate,
    }
    if not schema_valid(value, type_schemas[declared_output_type]):
        return {**parsed, "classification": "schema_invalid_object"}
    if value != dict(public_fields):
        return {**parsed, "classification": "public_content_mismatch"}
    return {**parsed, "classification": "exact_format_compliant"}


def sentinel_exact_format_classification(reason: str) -> str:
    mapping = {
        "runtime_error": "runtime_error_sentinel",
        "model_load_failure": "model_load_failure_sentinel",
        "wall_cap_reached": "wall_cap_sentinel",
        "worker_failure": "worker_failure_sentinel",
    }
    try:
        return mapping[reason]
    except KeyError as error:
        raise ValueError("unrecognized exact-format sentinel reason") from error


def execute_exact_format_copy(
    *,
    model: Any,
    tokenizer: Any,
    model_key: str,
    fixture_id: str,
    declared_output_type: str,
    prompt: str,
    public_fields: Mapping[str, Any],
    seed: int,
    maximum_input_tokens: int,
    maximum_new_tokens: int,
    type_schemas: Mapping[str, Mapping[str, Any]],
    record_kind: str,
    job_id: str | None,
    runner_version: str,
) -> Mapping[str, Any]:
    generation = generate_raw_payload(
        model, tokenizer, prompt, seed, maximum_input_tokens, maximum_new_tokens
    )
    raw = str(generation["raw_response"])
    envelope = encode_emission(raw, declared_output_type)
    view = prompt_view(envelope)
    round_trip = verify_round_trip(raw, declared_output_type, envelope)
    classification = classify_exact_format_payload(
        raw,
        str(generation["finish_reason"]),
        declared_output_type,
        public_fields,
        type_schemas,
    )
    operational_complete = bool(
        round_trip
        and json.loads(view)["payload_text"] == raw
        and classification["classification"] in EXACT_FORMAT_CLASSIFICATIONS
    )
    body = {
        "runner_version": runner_version,
        "exact_format_channel_version": EXACT_FORMAT_CHANNEL_VERSION,
        "generation_adapter_version": ADAPTER_VERSION,
        "transport_version": TRANSPORT_VERSION,
        "record_kind": record_kind,
        "job_id": job_id,
        "model_key": model_key,
        "fixture_id": fixture_id,
        "declared_output_type": declared_output_type,
        "seed": seed,
        "executed": True,
        "transport_envelope": envelope,
        "prompt_view": view,
        "round_trip_verified": round_trip,
        "format_classification": classification,
        "outcome_classification": classification["classification"],
        "operational_measurement_complete": operational_complete,
        **generation,
    }
    return {**body, "record_id": content_digest(body)}
