from __future__ import annotations

import json
from typing import Any, Mapping

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.answer_blind_nonstreaming_generation_v1 import (
    ADAPTER_VERSION,
    generate_raw_payload,
)
from scientist.domains.cognitive_core.answer_blind_transport_v1 import (
    TRANSPORT_VERSION,
    encode_emission,
    prompt_view,
    verify_round_trip,
)
from scientist.domains.cognitive_core.answer_blind_typed_candidate_extractor_v1 import (
    EXTRACTOR_VERSION,
    extract_typed_candidate,
)


MEASUREMENT_CHANNEL_VERSION = "cognitive-repairability-answer-blind-measurement-channel-v1"


def materialize_continuation_prompt(template: str, upstream_canonical: str) -> str:
    if template.count("{{UPSTREAM_CANONICAL_JSON}}") != 1:
        raise ValueError("continuation template must have exactly one upstream placeholder")
    parsed = json.loads(upstream_canonical)
    if not isinstance(parsed, dict):
        raise ValueError("upstream candidate must be a JSON object")
    return template.replace("{{UPSTREAM_CANONICAL_JSON}}", upstream_canonical)


def execute_measurement_channel(
    *,
    model: Any,
    tokenizer: Any,
    model_key: str,
    fixture_id: str,
    declared_output_type: str,
    prompt: str,
    seed: int,
    maximum_input_tokens: int,
    maximum_new_tokens: int,
    type_schemas: Mapping[str, Mapping[str, Any]],
    record_kind: str,
    job_id: str | None,
    runner_version: str,
) -> Mapping[str, Any]:
    generation = generate_raw_payload(
        model,
        tokenizer,
        prompt,
        seed,
        maximum_input_tokens,
        maximum_new_tokens,
    )
    raw_response = str(generation["raw_response"])
    envelope = encode_emission(raw_response, declared_output_type)
    view = prompt_view(envelope)
    round_trip = verify_round_trip(raw_response, declared_output_type, envelope)
    extraction = extract_typed_candidate(
        raw_response,
        declared_output_type,
        type_schemas,
    )
    passed = bool(
        raw_response
        and round_trip
        and json.loads(view)["payload_text"] == raw_response
        and extraction["status"] == "unique_schema_valid_candidate"
    )
    body = {
        "runner_version": runner_version,
        "measurement_channel_version": MEASUREMENT_CHANNEL_VERSION,
        "generation_adapter_version": ADAPTER_VERSION,
        "transport_version": TRANSPORT_VERSION,
        "extractor_version": EXTRACTOR_VERSION,
        "record_kind": record_kind,
        "job_id": job_id,
        "model_key": model_key,
        "fixture_id": fixture_id,
        "declared_output_type": declared_output_type,
        "seed": seed,
        "executed": True,
        "transport_envelope": envelope,
        "prompt_view": view,
        "round_trip_verified": round_trip,
        "extraction": extraction,
        "measurement_channel_passed": passed,
        **generation,
    }
    return {**body, "record_id": content_digest(body)}
