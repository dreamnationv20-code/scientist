from __future__ import annotations

import json
from typing import Any, Mapping

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.answer_blind_nonstreaming_generation_v1 import (
    ADAPTER_VERSION,
    generate_raw_payload,
)
from scientist.domains.cognitive_core.answer_blind_outcome_classifier_v1 import (
    CLASSIFIER_VERSION,
    classify_generated_response,
)
from scientist.domains.cognitive_core.answer_blind_transport_v1 import (
    TRANSPORT_VERSION,
    encode_emission,
    prompt_view,
    verify_round_trip,
)
from scientist.domains.cognitive_core.answer_blind_typed_candidate_extractor_v2 import (
    EXTRACTOR_VERSION,
    extract_typed_candidate,
)


MEASUREMENT_CHANNEL_VERSION = "cognitive-repairability-answer-blind-measurement-channel-v2.1"


def execute_measurement_channel(
    *,
    model: Any,
    tokenizer: Any,
    model_key: str,
    fixture_id: str,
    declared_output_type: str,
    prompt: str,
    seed: int,
    maximum_input_tokens: int,
    maximum_new_tokens: int,
    type_schemas: Mapping[str, Mapping[str, Any]],
    record_kind: str,
    job_id: str | None,
    runner_version: str,
) -> Mapping[str, Any]:
    generation = generate_raw_payload(
        model, tokenizer, prompt, seed, maximum_input_tokens, maximum_new_tokens
    )
    raw = str(generation["raw_response"])
    envelope = encode_emission(raw, declared_output_type)
    view = prompt_view(envelope)
    round_trip = verify_round_trip(raw, declared_output_type, envelope)
    extraction = extract_typed_candidate(raw, declared_output_type, type_schemas)
    classification = classify_generated_response(
        raw, str(generation["finish_reason"]), extraction
    )
    operational_complete = bool(
        round_trip and json.loads(view)["payload_text"] == raw and classification
    )
    body = {
        "runner_version": runner_version,
        "measurement_channel_version": MEASUREMENT_CHANNEL_VERSION,
        "generation_adapter_version": ADAPTER_VERSION,
        "transport_version": TRANSPORT_VERSION,
        "extractor_version": EXTRACTOR_VERSION,
        "classifier_version": CLASSIFIER_VERSION,
        "record_kind": record_kind,
        "job_id": job_id,
        "model_key": model_key,
        "fixture_id": fixture_id,
        "declared_output_type": declared_output_type,
        "seed": seed,
        "executed": True,
        "transport_envelope": envelope,
        "prompt_view": view,
        "round_trip_verified": round_trip,
        "extraction": extraction,
        "outcome_classification": classification,
        "operational_measurement_complete": operational_complete,
        **generation,
    }
    return {**body, "record_id": content_digest(body)}
