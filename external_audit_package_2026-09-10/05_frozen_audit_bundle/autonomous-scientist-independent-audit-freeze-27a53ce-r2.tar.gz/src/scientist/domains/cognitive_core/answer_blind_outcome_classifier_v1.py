from __future__ import annotations

from typing import Any, Mapping


CLASSIFIER_VERSION = "cognitive-repairability-answer-blind-outcome-classifier-v1"
CLASSIFICATIONS = frozenset(
    (
        "schema_valid_candidate",
        "schema_invalid_no_candidate",
        "schema_ambiguous_multiple_objects",
        "truncated_output",
        "empty_output",
        "runtime_error_sentinel",
        "model_load_failure_sentinel",
        "wall_cap_sentinel",
        "worker_failure_sentinel",
    )
)


def classify_generated_response(
    raw_response: str,
    finish_reason: str,
    extraction: Mapping[str, Any],
) -> str:
    if finish_reason == "length":
        return "truncated_output"
    if raw_response == "":
        return "empty_output"
    status = extraction.get("status")
    if status == "unique_schema_valid_candidate":
        return "schema_valid_candidate"
    if status == "ambiguous_multiple_json_objects":
        return "schema_ambiguous_multiple_objects"
    if status == "no_schema_valid_candidate":
        return "schema_invalid_no_candidate"
    raise ValueError("unrecognized deterministic extraction status")


def sentinel_classification(reason: str) -> str:
    mapping = {
        "runtime_error": "runtime_error_sentinel",
        "model_load_failure": "model_load_failure_sentinel",
        "wall_cap_reached": "wall_cap_sentinel",
        "worker_failure": "worker_failure_sentinel",
    }
    try:
        return mapping[reason]
    except KeyError as error:
        raise ValueError("unrecognized sentinel reason") from error
