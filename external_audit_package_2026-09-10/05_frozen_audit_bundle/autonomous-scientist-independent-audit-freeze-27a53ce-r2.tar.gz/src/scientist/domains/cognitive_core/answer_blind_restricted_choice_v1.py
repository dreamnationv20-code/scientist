from __future__ import annotations

import hashlib
import math
import time
from typing import Any, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.answer_blind_nonstreaming_generation_v1 import (
    render_prompt,
)


RESTRICTED_CHOICE_VERSION = "cognitive-repairability-answer-blind-restricted-choice-v1"


def execute_restricted_choice(
    *,
    model: Any,
    tokenizer: Any,
    model_key: str,
    fixture_id: str,
    declared_output_type: str,
    prompt: str,
    candidates: Sequence[Mapping[str, Any]],
    code_token_ids: Mapping[str, int],
    seed: int,
    maximum_input_tokens: int,
    record_kind: str,
    job_id: str | None,
    runner_version: str,
) -> Mapping[str, Any]:
    """Measure a restricted first-token choice without any correctness authority."""

    import mlx.core as mx

    codes = [str(row["code"]) for row in candidates]
    if not codes or len(codes) != len(set(codes)):
        raise RuntimeError("restricted-choice codes must be nonempty and unique")
    if set(codes) != set(code_token_ids):
        raise RuntimeError("restricted-choice token registry mismatch")
    token_ids = [int(code_token_ids[code]) for code in codes]
    if len(token_ids) != len(set(token_ids)):
        raise RuntimeError("restricted-choice token IDs collide")
    for code, token_id in zip(codes, token_ids):
        if tokenizer.encode(code, add_special_tokens=False) != [token_id]:
            raise RuntimeError("restricted-choice code is not the frozen single token")
        if tokenizer.decode([token_id], skip_special_tokens=False) != code:
            raise RuntimeError("restricted-choice token does not decode losslessly")

    rendered = render_prompt(tokenizer, prompt)
    prompt_ids = tokenizer.encode(rendered, add_special_tokens=False)
    if not prompt_ids or len(prompt_ids) > maximum_input_tokens:
        raise RuntimeError("restricted-choice prompt violates frozen input cap")

    mx.random.seed(seed)
    started = time.monotonic()
    logits = model(mx.array([prompt_ids]))
    restricted = logits[0, -1, mx.array(token_ids)]
    mx.eval(restricted)
    values = [float(value) for value in restricted.tolist()]
    elapsed = time.monotonic() - started
    if len(values) != len(codes) or not all(math.isfinite(value) for value in values):
        raise RuntimeError("restricted-choice logits are missing or nonfinite")
    selected_index = max(range(len(values)), key=lambda index: (values[index], -index))
    maximum = max(values)
    weights = [math.exp(value - maximum) for value in values]
    denominator = sum(weights)
    probabilities = [value / denominator for value in weights]
    vector = [
        {
            "code": code,
            "token_id": token_id,
            "logit": value,
            "restricted_probability": probability,
        }
        for code, token_id, value, probability in zip(codes, token_ids, values, probabilities)
    ]
    selected = candidates[selected_index]
    body = {
        "runner_version": runner_version,
        "restricted_choice_version": RESTRICTED_CHOICE_VERSION,
        "record_kind": record_kind,
        "job_id": job_id,
        "model_key": model_key,
        "fixture_id": fixture_id,
        "declared_output_type": declared_output_type,
        "seed": seed,
        "executed": True,
        "rendered_prompt_sha256": hashlib.sha256(rendered.encode("utf-8")).hexdigest(),
        "prompt_tokens": len(prompt_ids),
        "candidate_count": len(candidates),
        "allowed_code_logits": vector,
        "selected_index": selected_index,
        "selected_code": str(selected["code"]),
        "selected_candidate_canonical": str(selected["candidate_canonical"]),
        "elapsed_seconds": elapsed,
        "choice_complete": True,
        "decoder_path": "single_forward_last_position_restricted_argmax",
        "correctness_authority_accessed": False,
    }
    return {**body, "record_id": content_digest(body)}
