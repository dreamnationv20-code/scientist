from __future__ import annotations

import hashlib
import itertools
import json
from typing import Any, Mapping, Sequence

from scientist.core.artifacts import content_digest


FIXTURE_VERSION = "cognitive-repairability-answer-blind-semantic-observability-fixtures-v1"
AFFIRMATIVE_VERDICT = " The proposed result is logically consistent."
NEGATIVE_VERDICT = " The proposed result is logically inconsistent."
OUTPUT_TYPES = (
    "affine_packet",
    "indexed_packet",
    "parity_packet",
    "rendered_residue",
    "rendered_sequence",
    "tagged_packet",
)
SEQUENCE_TYPES = ("indexed_packet", "rendered_sequence", "tagged_packet")
RESIDUE_TYPES = ("affine_packet", "parity_packet", "rendered_residue")
MODEL_KEYS = ("qwen3_1p7b", "qwen2p5_3b")
MAXIMUM_INPUT_TOKENS = 384
MAXIMUM_VERDICT_TOKENS = 32


_ATOM_ROOTS = (
    "oriven", "pelorin", "quessan", "ravelle", "soradin", "tavernis", "ulmere", "valdrin",
    "wexora", "yorlin", "zareph", "belvara", "coriven", "dameris", "elvane", "farsin",
    "galdor", "heressa", "ilvorn", "joravel", "kelmira", "lorvane", "merovin", "noressa",
    "olverin", "peressa", "quelvor", "rimaren", "selvora", "toriven", "urelith", "vespara",
    "welorin", "xavelle", "yemaris", "zoriven", "brivane", "celorin", "dovarin", "eressa",
    "falvorn", "girelle", "halmira", "isorven", "jurelia", "koravel", "lemorin", "mavessa",
)


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _candidate_id(fixture_id: str, canonical: Mapping[str, Any]) -> str:
    return content_digest({"fixture_id": fixture_id, "candidate_canonical": canonical})


def _sequence_display(output_type: str, values: Sequence[str]) -> str:
    joined = ", ".join(values)
    if output_type == "indexed_packet":
        return "The proposed slot order is [%s]." % joined
    if output_type == "tagged_packet":
        return "The proposed tagged order is [%s], with the first two positions tagged near and the last two tagged far." % joined
    if output_type == "rendered_sequence":
        return "The proposed semantic sequence reads %s." % " then ".join(values)
    raise ValueError("unknown sequence output type")


def _residue_display(output_type: str, value: int) -> str:
    if output_type == "affine_packet":
        return "The proposed modular result has residue %d." % value
    if output_type == "parity_packet":
        return "The proposed modular result is %d, whose ordinary parity is %s." % (
            value,
            "even" if value % 2 == 0 else "odd",
        )
    if output_type == "rendered_residue":
        return "The proposed named remainder is %d." % value
    raise ValueError("unknown residue output type")


def _sequence_task(model_key: str, output_type: str, replicate: int, atoms: Sequence[str]) -> Mapping[str, Any]:
    fixture_id = "sop_%s_%s_%02d" % (model_key, output_type, replicate)
    seed = int(hashlib.sha256(fixture_id.encode()).hexdigest()[:8], 16)
    ranked = sorted(atoms, key=lambda atom: hashlib.sha256((fixture_id + atom).encode()).hexdigest())
    ranks = {atom: index + 1 for index, atom in enumerate(ranked)}
    direction = "ascending" if replicate == 0 else "descending"
    rule_id = "sop_public_rank_%s_%s_v1" % (direction, output_type)
    rule = (
        "A candidate is consistent exactly when its four symbols are ordered by their stated ranks from %s."
        % ("smallest to largest" if direction == "ascending" else "largest to smallest")
    )
    content = "The public symbol ranks are " + "; ".join("%s=%d" % (atom, ranks[atom]) for atom in atoms) + "."
    candidates = []
    for values in itertools.permutations(atoms):
        canonical = {"ordered_symbols": list(values), "semantic_type": output_type}
        display = _sequence_display(output_type, values)
        candidates.append(
            {
                "candidate_id": _candidate_id(fixture_id, canonical),
                "candidate_canonical": canonical,
                "candidate_display": display,
                "task_prompt": "Independent public observability fixture %s.\n%s\nRule: %s\n%s\nJudge whether the proposed result follows exactly from the public rule." % (fixture_id, content, rule, display),
                "taskless_null_prompt": "Independent public observability fixture %s.\n%s\n%s\nNo ordering rule or correctness relation is supplied. Consider only this public content." % (fixture_id, content, display),
            }
        )
    return {
        "fixture_version": FIXTURE_VERSION,
        "fixture_id": fixture_id,
        "fixture_kind": "task",
        "model_key": model_key,
        "output_type": output_type,
        "semantic_domain": "sequence",
        "replicate": replicate,
        "fixture_seed": seed,
        "semantic_atoms": list(atoms),
        "semantic_rule_id": rule_id,
        "public_parameters": {"ranks": ranks, "direction": direction},
        "candidate_count": len(candidates),
        "candidates": candidates,
    }


def _residue_task(model_key: str, output_type: str, replicate: int) -> Mapping[str, Any]:
    fixture_id = "sop_%s_%s_%02d" % (model_key, output_type, replicate)
    model_offset = 0 if model_key == "qwen3_1p7b" else 4
    u = (2 + model_offset + replicate * 3) % 11
    v = (7 + model_offset + replicate * 2) % 11
    w = (5 + model_offset + replicate * 5) % 11
    if output_type == "affine_packet":
        rule_id = "sop_three_term_weighted_sum_mod11_v1"
        rule = "Compute (u + 2*v + w) modulo 11."
    elif output_type == "parity_packet":
        rule_id = "sop_product_plus_triple_mod11_v1"
        rule = "Compute (u*v + 3*w) modulo 11; parity means the ordinary even/odd parity of that residue."
    elif output_type == "rendered_residue":
        rule_id = "sop_square_plus_pair_mod11_v1"
        rule = "Compute (u squared + v + w) modulo 11."
    else:
        raise ValueError("unknown residue output type")
    content = "The public inputs are u=%d, v=%d, and w=%d." % (u, v, w)
    candidates = []
    for value in range(11):
        canonical = {
            "residue": value,
            "semantic_type": output_type,
            **({"parity": "even" if value % 2 == 0 else "odd"} if output_type == "parity_packet" else {}),
        }
        display = _residue_display(output_type, value)
        candidates.append(
            {
                "candidate_id": _candidate_id(fixture_id, canonical),
                "candidate_canonical": canonical,
                "candidate_display": display,
                "task_prompt": "Independent public observability fixture %s.\n%s\nRule: %s\n%s\nJudge whether the proposed result follows exactly from the public rule." % (fixture_id, content, rule, display),
                "taskless_null_prompt": "Independent public observability fixture %s.\n%s\n%s\nNo arithmetic rule or correctness relation is supplied. Consider only this public content." % (fixture_id, content, display),
            }
        )
    return {
        "fixture_version": FIXTURE_VERSION,
        "fixture_id": fixture_id,
        "fixture_kind": "task",
        "model_key": model_key,
        "output_type": output_type,
        "semantic_domain": "residue",
        "replicate": replicate,
        "semantic_atoms": [fixture_id + "_operand_u", fixture_id + "_operand_v", fixture_id + "_operand_w", "sop_public_modulus_11"],
        "semantic_rule_id": rule_id,
        "public_parameters": {"u": u, "v": v, "w": w, "modulus": 11},
        "candidate_count": len(candidates),
        "candidates": candidates,
    }


def public_task_fixtures() -> list[Mapping[str, Any]]:
    fixtures: list[Mapping[str, Any]] = []
    atom_index = 0
    for model_key in MODEL_KEYS:
        for output_type in OUTPUT_TYPES:
            for replicate in range(2):
                if output_type in SEQUENCE_TYPES:
                    atoms = _ATOM_ROOTS[atom_index : atom_index + 4]
                    atom_index += 4
                    fixture = _sequence_task(model_key, output_type, replicate, atoms)
                else:
                    fixture = _residue_task(model_key, output_type, replicate)
                body = dict(fixture)
                fixtures.append({**body, "fixture_record_id": content_digest(body)})
    return fixtures


def public_control_fixtures() -> list[Mapping[str, Any]]:
    propositions = {
        "sequence": (
            "In the sequence [lumen, nareth, opaline], nareth occurs immediately after lumen.",
            "In the sequence [pavrin, quorel, riston], riston occurs before pavrin.",
            "If the rank of selune is 2 and the rank of torval is 5, selune has the smaller rank.",
            "Sorting [umbral=3, velora=1, wendin=2] from smallest rank to largest gives [umbral, wendin, velora].",
        ),
        "residue": (
            "Modulo 11, the residue of 8 plus 7 is 4.",
            "Modulo 11, the residue of 6 times 3 is 7.",
            "Modulo 11, the residue of 9 squared plus 2 is 5.",
            "The ordinary parity of the residue 7 is even.",
        ),
    }
    fixtures: list[Mapping[str, Any]] = []
    for model_key in MODEL_KEYS:
        for domain in ("sequence", "residue"):
            for index, proposition in enumerate(propositions[domain]):
                fixture_id = "sop_control_%s_%s_%02d" % (model_key, domain, index)
                task_prompt = "Independent public observability fixture %s.\nPublic proposition check.\nStatement: %s\nJudge whether the statement is logically true." % (fixture_id, proposition)
                null_prompt = "Independent public observability fixture %s.\nPublic statement text.\nStatement: %s\nNo truth or correctness relation is supplied. Consider only this public content." % (fixture_id, proposition)
                body = {
                    "fixture_version": FIXTURE_VERSION,
                    "fixture_id": fixture_id,
                    "fixture_kind": "truth_direction_control",
                    "model_key": model_key,
                    "semantic_domain": domain,
                    "control_index": index,
                    "public_proposition": proposition,
                    "task_prompt": task_prompt,
                    "taskless_null_prompt": null_prompt,
                }
                fixtures.append({**body, "fixture_record_id": content_digest(body)})
    return fixtures


def evaluation_schedule(
    task_fixtures: Sequence[Mapping[str, Any]],
    control_fixtures: Sequence[Mapping[str, Any]],
) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []

    def add_rows(fixture: Mapping[str, Any], candidate: Mapping[str, Any] | None) -> None:
        prompts = {
            "task": candidate["task_prompt"] if candidate is not None else fixture["task_prompt"],
            "taskless_null": candidate["taskless_null_prompt"] if candidate is not None else fixture["taskless_null_prompt"],
        }
        for context_kind in ("task", "taskless_null"):
            for verdict_kind, verdict in (
                ("affirmative", AFFIRMATIVE_VERDICT),
                ("negative", NEGATIVE_VERDICT),
            ):
                body = {
                    "fixture_version": FIXTURE_VERSION,
                    "fixture_kind": fixture["fixture_kind"],
                    "fixture_id": fixture["fixture_id"],
                    "model_key": fixture["model_key"],
                    "semantic_domain": fixture["semantic_domain"],
                    "output_type": fixture.get("output_type"),
                    "candidate_id": candidate.get("candidate_id") if candidate is not None else None,
                    "candidate_canonical": candidate.get("candidate_canonical") if candidate is not None else None,
                    "context_kind": context_kind,
                    "verdict_kind": verdict_kind,
                    "prompt": prompts[context_kind],
                    "verdict": verdict,
                    "maximum_input_tokens": MAXIMUM_INPUT_TOKENS,
                    "maximum_verdict_tokens": MAXIMUM_VERDICT_TOKENS,
                }
                evaluation_id = content_digest(body)
                row = {**body, "evaluation_id": evaluation_id}
                rows.append({**row, "job_id": content_digest(row)})

    for fixture in task_fixtures:
        for candidate in fixture["candidates"]:
            add_rows(fixture, candidate)
    for fixture in control_fixtures:
        add_rows(fixture, None)
    return [{**row, "schedule_index": index} for index, row in enumerate(rows)]
