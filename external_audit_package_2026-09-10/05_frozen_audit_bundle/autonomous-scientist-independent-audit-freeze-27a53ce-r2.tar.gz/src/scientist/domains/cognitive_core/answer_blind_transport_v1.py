from __future__ import annotations

import base64
import hashlib
import json
from typing import Any, Mapping

from scientist.core.artifacts import content_digest


TRANSPORT_VERSION = "cognitive-repairability-answer-blind-transport-v1"
ALLOWED_DECLARED_TYPES = frozenset(
    {
        "indexed_packet",
        "tagged_packet",
        "affine_packet",
        "parity_packet",
        "rendered_sequence",
        "rendered_residue",
    }
)


def encode_emission(raw_response: str, declared_output_type: str) -> Mapping[str, Any]:
    """Losslessly put an arbitrary model emission in a deterministic typed envelope."""

    if not isinstance(raw_response, str):
        raise TypeError("raw_response must be text")
    if declared_output_type not in ALLOWED_DECLARED_TYPES:
        raise ValueError("unsupported declared output type")
    payload = raw_response.encode("utf-8", errors="strict")
    body = {
        "transport_version": TRANSPORT_VERSION,
        "declared_output_type": declared_output_type,
        "payload_encoding": "base64_of_exact_utf8",
        "payload_base64": base64.b64encode(payload).decode("ascii"),
        "payload_sha256": hashlib.sha256(payload).hexdigest(),
        "payload_bytes": len(payload),
    }
    return {**body, "envelope_id": content_digest(body)}


def decode_emission(envelope: Mapping[str, Any]) -> str:
    """Validate an envelope and recover the byte-identical UTF-8 emission."""

    expected_keys = {
        "transport_version",
        "declared_output_type",
        "payload_encoding",
        "payload_base64",
        "payload_sha256",
        "payload_bytes",
        "envelope_id",
    }
    if set(envelope) != expected_keys:
        raise ValueError("transport envelope keys changed")
    if envelope["transport_version"] != TRANSPORT_VERSION:
        raise ValueError("transport version mismatch")
    if envelope["declared_output_type"] not in ALLOWED_DECLARED_TYPES:
        raise ValueError("transport declared type is unsupported")
    if envelope["payload_encoding"] != "base64_of_exact_utf8":
        raise ValueError("transport encoding mismatch")
    body = {key: value for key, value in envelope.items() if key != "envelope_id"}
    if envelope["envelope_id"] != content_digest(body):
        raise ValueError("transport envelope identity mismatch")
    try:
        payload = base64.b64decode(str(envelope["payload_base64"]), validate=True)
    except Exception as error:
        raise ValueError("transport payload is not canonical base64") from error
    if len(payload) != int(envelope["payload_bytes"]):
        raise ValueError("transport payload byte count mismatch")
    if hashlib.sha256(payload).hexdigest() != envelope["payload_sha256"]:
        raise ValueError("transport payload hash mismatch")
    return payload.decode("utf-8", errors="strict")


def prompt_view(envelope: Mapping[str, Any]) -> str:
    """Render transported text as escaped JSON data for a dependent prompt."""

    payload_text = decode_emission(envelope)
    return json.dumps(
        {
            "declared_output_type": envelope["declared_output_type"],
            "payload_text": payload_text,
        },
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    )


def verify_round_trip(
    raw_response: str,
    declared_output_type: str,
    envelope: Mapping[str, Any],
) -> bool:
    return bool(
        envelope.get("declared_output_type") == declared_output_type
        and decode_emission(envelope) == raw_response
        and prompt_view(envelope)
        == json.dumps(
            {
                "declared_output_type": declared_output_type,
                "payload_text": raw_response,
            },
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
        )
    )
