from __future__ import annotations

import json
import unicodedata
from typing import Any, Mapping


EXTRACTOR_VERSION = "cognitive-repairability-answer-blind-typed-candidate-extractor-v1"


def canonical_object(value: Mapping[str, Any]) -> str:
    def normalize(item: Any) -> Any:
        if isinstance(item, str):
            return unicodedata.normalize("NFC", item)
        if isinstance(item, list):
            return [normalize(child) for child in item]
        if isinstance(item, dict):
            return {str(key): normalize(child) for key, child in item.items()}
        return item

    return json.dumps(
        normalize(dict(value)),
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    )


def schema_valid(value: Any, schema: Mapping[str, Any]) -> bool:
    if not isinstance(value, dict) or sorted(value) != sorted(schema["exact_keys"]):
        return False
    if value.get("type") != schema["type_literal"]:
        return False
    if "modulus_literal" in schema and value.get("modulus") != schema["modulus_literal"]:
        return False
    if schema.get("value_type") == "integer" and (
        not isinstance(value.get("value"), int) or isinstance(value.get("value"), bool)
    ):
        return False
    if schema.get("value_type") == "string" and not isinstance(value.get("value"), str):
        return False
    if "items_length" in schema:
        items = value.get("items")
        if not isinstance(items, list) or len(items) != int(schema["items_length"]):
            return False
        for item in items:
            if not isinstance(item, dict) or sorted(item) != sorted(schema["item_exact_keys"]):
                return False
            if not isinstance(item.get("slot"), int) or isinstance(item.get("slot"), bool):
                return False
            if item.get("slot") not in schema["slot_allowed"]:
                return False
            if not isinstance(item.get("symbol"), str):
                return False
            if "band_allowed" in schema and item.get("band") not in schema["band_allowed"]:
                return False
    if (
        "band_allowed" in schema
        and "items_length" not in schema
        and value.get("band") not in schema["band_allowed"]
    ):
        return False
    return True


def extract_typed_candidate(
    raw_response: str,
    declared_output_type: str,
    type_schemas: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    if declared_output_type not in type_schemas:
        raise ValueError("unknown declared output type")
    text = unicodedata.normalize("NFC", raw_response)
    decoder = json.JSONDecoder()
    candidates: list[Mapping[str, Any]] = []
    spans: list[tuple[int, int]] = []
    for start, character in enumerate(text):
        if character != "{":
            continue
        try:
            value, length = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            continue
        end = start + length
        if schema_valid(value, type_schemas[declared_output_type]):
            candidates.append(value)
            spans.append((start, end))
    if len(candidates) == 0:
        return {
            "extractor_version": EXTRACTOR_VERSION,
            "declared_output_type": declared_output_type,
            "status": "no_schema_valid_candidate",
            "candidate_count": 0,
            "canonical_candidate": None,
            "candidate_span": None,
        }
    if len(candidates) > 1:
        return {
            "extractor_version": EXTRACTOR_VERSION,
            "declared_output_type": declared_output_type,
            "status": "ambiguous_multiple_schema_valid_candidates",
            "candidate_count": len(candidates),
            "canonical_candidate": None,
            "candidate_span": None,
        }
    return {
        "extractor_version": EXTRACTOR_VERSION,
        "declared_output_type": declared_output_type,
        "status": "unique_schema_valid_candidate",
        "candidate_count": 1,
        "canonical_candidate": canonical_object(candidates[0]),
        "candidate_span": list(spans[0]),
    }
