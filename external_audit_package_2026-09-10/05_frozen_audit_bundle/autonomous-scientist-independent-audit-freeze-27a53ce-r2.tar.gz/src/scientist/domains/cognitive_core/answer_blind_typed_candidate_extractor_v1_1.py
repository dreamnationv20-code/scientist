from __future__ import annotations

import json
import re
import unicodedata
from typing import Any, Mapping

from scientist.domains.cognitive_core.answer_blind_typed_candidate_extractor_v1 import (
    canonical_object,
    schema_valid,
)


EXTRACTOR_VERSION = "cognitive-repairability-answer-blind-typed-candidate-extractor-v1.1"
RENDERED_TYPES = frozenset(("rendered_sequence", "rendered_residue"))


def _rendered_value(value: Any, declared_output_type: str) -> str | None:
    if isinstance(value, str):
        return value
    if (
        declared_output_type == "rendered_sequence"
        and isinstance(value, list)
        and all(isinstance(item, str) for item in value)
    ):
        return "|".join(value)
    return None


def extract_typed_candidate(
    raw_response: str,
    declared_output_type: str,
    type_schemas: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    if declared_output_type not in type_schemas:
        raise ValueError("unknown declared output type")
    text = unicodedata.normalize("NFC", raw_response)
    decoder = json.JSONDecoder()
    strict: list[tuple[Mapping[str, Any], tuple[int, int]]] = []
    decoded_objects: list[tuple[Mapping[str, Any], tuple[int, int]]] = []
    for start, character in enumerate(text):
        if character != "{":
            continue
        try:
            value, length = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            continue
        if not isinstance(value, dict):
            continue
        span = (start, start + length)
        decoded_objects.append((value, span))
        if schema_valid(value, type_schemas[declared_output_type]):
            strict.append((value, span))
    if len(strict) == 1:
        value, span = strict[0]
        return {
            "extractor_version": EXTRACTOR_VERSION,
            "declared_output_type": declared_output_type,
            "status": "unique_schema_valid_candidate",
            "candidate_count": 1,
            "canonical_candidate": canonical_object(value),
            "candidate_span": list(span),
            "normalization_rule": "strict_exact_schema",
        }
    if len(strict) > 1:
        return {
            "extractor_version": EXTRACTOR_VERSION,
            "declared_output_type": declared_output_type,
            "status": "ambiguous_multiple_schema_valid_candidates",
            "candidate_count": len(strict),
            "canonical_candidate": None,
            "candidate_span": None,
            "normalization_rule": None,
        }
    if declared_output_type not in RENDERED_TYPES:
        return {
            "extractor_version": EXTRACTOR_VERSION,
            "declared_output_type": declared_output_type,
            "status": "no_schema_valid_candidate",
            "candidate_count": 0,
            "canonical_candidate": None,
            "candidate_span": None,
            "normalization_rule": None,
        }
    normalized: list[tuple[Mapping[str, Any], tuple[int, int] | None, str]] = []
    for value, span in decoded_objects:
        has_explicit_type = "type" in value
        explicit_type = value.get("type")
        if has_explicit_type and explicit_type != declared_output_type:
            continue
        if "value" in value:
            leaf = _rendered_value(value["value"], declared_output_type)
            if leaf is not None:
                rule = "project_type_and_value" if has_explicit_type else "insert_missing_declared_type"
                if isinstance(value["value"], list):
                    rule = "rendered_sequence_string_list_join"
                normalized.append(({"type": declared_output_type, "value": leaf}, span, rule))
                continue
        if set(value) == {declared_output_type}:
            leaf = _rendered_value(value[declared_output_type], declared_output_type)
            if leaf is not None:
                normalized.append(({"type": declared_output_type, "value": leaf}, span, "declared_type_key_as_value"))
    if not decoded_objects:
        match = re.fullmatch(
            r"\s*type:\s*(rendered_sequence|rendered_residue)\s*\r?\nvalue:\s*([^\r\n]+)\s*",
            text,
        )
        if match is not None and match.group(1) == declared_output_type:
            normalized.append(({"type": declared_output_type, "value": match.group(2)}, None, "exact_two_line_type_value_notation"))
    if len(normalized) == 1:
        value, span, rule = normalized[0]
        return {
            "extractor_version": EXTRACTOR_VERSION,
            "declared_output_type": declared_output_type,
            "status": "unique_schema_valid_candidate",
            "candidate_count": 1,
            "canonical_candidate": canonical_object(value),
            "candidate_span": None if span is None else list(span),
            "normalization_rule": rule,
        }
    return {
        "extractor_version": EXTRACTOR_VERSION,
        "declared_output_type": declared_output_type,
        "status": "ambiguous_multiple_schema_valid_candidates" if len(normalized) > 1 else "no_schema_valid_candidate",
        "candidate_count": len(normalized),
        "canonical_candidate": None,
        "candidate_span": None,
        "normalization_rule": None,
    }
