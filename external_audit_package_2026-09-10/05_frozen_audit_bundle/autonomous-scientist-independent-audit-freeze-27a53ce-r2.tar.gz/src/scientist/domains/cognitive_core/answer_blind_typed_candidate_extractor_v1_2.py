from __future__ import annotations

import json
import re
from typing import Any, Mapping

from scientist.domains.cognitive_core.answer_blind_typed_candidate_extractor_v1 import schema_valid


EXTRACTOR_VERSION = "cognitive-repairability-answer-blind-typed-candidate-extractor-v1.2"
RENDERED_TYPES = frozenset(("rendered_sequence", "rendered_residue"))


def _canonical_preserving_literals(value: Mapping[str, Any]) -> str:
    return json.dumps(dict(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _rendered_value(value: Any, declared_output_type: str) -> str | None:
    if isinstance(value, str):
        return value
    if (
        declared_output_type == "rendered_sequence"
        and isinstance(value, list)
        and all(isinstance(item, str) for item in value)
    ):
        return "|".join(value)
    return None


def _decoded_containers(text: str) -> list[tuple[Any, tuple[int, int]]]:
    decoder = json.JSONDecoder()
    decoded: list[tuple[Any, tuple[int, int]]] = []
    for start, character in enumerate(text):
        if character not in "{[":
            continue
        try:
            value, length = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, (dict, list)):
            decoded.append((value, (start, start + length)))
    return decoded


def _outermost_objects(
    decoded: list[tuple[Any, tuple[int, int]]],
) -> list[tuple[Mapping[str, Any], tuple[int, int]]]:
    outermost: list[tuple[Mapping[str, Any], tuple[int, int]]] = []
    for value, span in decoded:
        if not isinstance(value, dict):
            continue
        if any(
            other_span[0] <= span[0]
            and span[1] <= other_span[1]
            and other_span != span
            for _, other_span in decoded
        ):
            continue
        outermost.append((value, span))
    return outermost


def _failure(declared_output_type: str, status: str, count: int) -> Mapping[str, Any]:
    return {
        "extractor_version": EXTRACTOR_VERSION,
        "declared_output_type": declared_output_type,
        "status": status,
        "candidate_count": count,
        "canonical_candidate": None,
        "candidate_span": None,
        "normalization_rule": None,
    }


def extract_typed_candidate(
    raw_response: str,
    declared_output_type: str,
    type_schemas: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    if declared_output_type not in type_schemas:
        raise ValueError("unknown declared output type")
    text = raw_response
    outermost = _outermost_objects(_decoded_containers(text))
    if len(outermost) > 1:
        return _failure(declared_output_type, "ambiguous_multiple_json_objects", len(outermost))
    if len(outermost) == 1:
        value, span = outermost[0]
        if schema_valid(value, type_schemas[declared_output_type]):
            return {
                "extractor_version": EXTRACTOR_VERSION,
                "declared_output_type": declared_output_type,
                "status": "unique_schema_valid_candidate",
                "candidate_count": 1,
                "canonical_candidate": _canonical_preserving_literals(value),
                "candidate_span": list(span),
                "normalization_rule": "strict_exact_schema",
            }
        if declared_output_type not in RENDERED_TYPES:
            return _failure(declared_output_type, "no_schema_valid_candidate", 0)
        has_explicit_type = "type" in value
        explicit_type = value.get("type")
        if has_explicit_type and explicit_type != declared_output_type:
            return _failure(declared_output_type, "no_schema_valid_candidate", 0)
        candidate: Mapping[str, Any] | None = None
        rule: str | None = None
        if "value" in value:
            leaf = _rendered_value(value["value"], declared_output_type)
            if leaf is not None:
                candidate = {"type": declared_output_type, "value": leaf}
                rule = "project_type_and_value" if has_explicit_type else "insert_missing_declared_type"
                if isinstance(value["value"], list):
                    rule = "rendered_sequence_string_list_join"
        elif set(value) == {declared_output_type}:
            leaf = _rendered_value(value[declared_output_type], declared_output_type)
            if leaf is not None:
                candidate = {"type": declared_output_type, "value": leaf}
                rule = "declared_type_key_as_value"
        if candidate is None:
            return _failure(declared_output_type, "no_schema_valid_candidate", 0)
        return {
            "extractor_version": EXTRACTOR_VERSION,
            "declared_output_type": declared_output_type,
            "status": "unique_schema_valid_candidate",
            "candidate_count": 1,
            "canonical_candidate": _canonical_preserving_literals(candidate),
            "candidate_span": list(span),
            "normalization_rule": rule,
        }
    if declared_output_type in RENDERED_TYPES:
        match = re.fullmatch(
            r"\s*type:\s*(rendered_sequence|rendered_residue)\s*\r?\nvalue:\s*([^\r\n]+)\s*",
            text,
        )
        if match is not None and match.group(1) == declared_output_type:
            candidate = {"type": declared_output_type, "value": match.group(2)}
            return {
                "extractor_version": EXTRACTOR_VERSION,
                "declared_output_type": declared_output_type,
                "status": "unique_schema_valid_candidate",
                "candidate_count": 1,
                "canonical_candidate": _canonical_preserving_literals(candidate),
                "candidate_span": None,
                "normalization_rule": "exact_two_line_type_value_notation",
            }
    return _failure(declared_output_type, "no_schema_valid_candidate", 0)
