from __future__ import annotations

import json
from typing import Any, Mapping

from scientist.domains.cognitive_core.answer_blind_typed_candidate_extractor_v1 import schema_valid


EXTRACTOR_VERSION = "cognitive-repairability-answer-blind-typed-candidate-extractor-v2"


def _canonical_preserving_literals(value: Mapping[str, Any]) -> str:
    return json.dumps(dict(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _outermost_objects(text: str) -> list[tuple[Mapping[str, Any], tuple[int, int]]]:
    decoder = json.JSONDecoder()
    containers: list[tuple[Any, tuple[int, int]]] = []
    for start, character in enumerate(text):
        if character not in "{[":
            continue
        try:
            value, length = decoder.raw_decode(text[start:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, (dict, list)):
            containers.append((value, (start, start + length)))
    outermost: list[tuple[Mapping[str, Any], tuple[int, int]]] = []
    for value, span in containers:
        if not isinstance(value, dict):
            continue
        if any(
            other_span[0] <= span[0]
            and span[1] <= other_span[1]
            and other_span != span
            for _, other_span in containers
        ):
            continue
        outermost.append((value, span))
    return outermost


def _failure(declared_output_type: str, status: str, count: int) -> Mapping[str, Any]:
    return {
        "extractor_version": EXTRACTOR_VERSION,
        "declared_output_type": declared_output_type,
        "status": status,
        "candidate_count": count,
        "canonical_candidate": None,
        "candidate_span": None,
        "normalization_rule": None,
    }


def extract_typed_candidate(
    raw_response: str,
    declared_output_type: str,
    type_schemas: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    if declared_output_type not in type_schemas:
        raise ValueError("unknown declared output type")
    outermost = _outermost_objects(raw_response)
    if len(outermost) > 1:
        return _failure(declared_output_type, "ambiguous_multiple_json_objects", len(outermost))
    if len(outermost) == 0:
        return _failure(declared_output_type, "no_schema_valid_candidate", 0)
    value, span = outermost[0]
    if not schema_valid(value, type_schemas[declared_output_type]):
        return _failure(declared_output_type, "no_schema_valid_candidate", 0)
    return {
        "extractor_version": EXTRACTOR_VERSION,
        "declared_output_type": declared_output_type,
        "status": "unique_schema_valid_candidate",
        "candidate_count": 1,
        "canonical_candidate": _canonical_preserving_literals(value),
        "candidate_span": list(span),
        "normalization_rule": None,
    }
