from __future__ import annotations

import hashlib
import math
import time
from typing import Any, Mapping

from scientist.core.artifacts import content_digest


VERDICT_LIKELIHOOD_VERSION = "cognitive-repairability-answer-blind-verdict-likelihood-v1"


def render_user_prompt(tokenizer: Any, prompt: str) -> str:
    options = {"tokenize": False, "add_generation_prompt": True}
    try:
        return tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}],
            enable_thinking=False,
            **options,
        )
    except TypeError:
        return tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}],
            **options,
        )


def evaluate_teacher_forced_verdict(
    *,
    model: Any,
    tokenizer: Any,
    model_key: str,
    fixture_id: str,
    evaluation_id: str,
    context_kind: str,
    verdict_kind: str,
    prompt: str,
    verdict: str,
    maximum_input_tokens: int,
    maximum_verdict_tokens: int,
    runner_version: str,
) -> Mapping[str, Any]:
    """Return a full multi-token conditional log-likelihood without generation."""

    import mlx.core as mx

    if context_kind not in {"task", "taskless_null"}:
        raise ValueError("unknown context kind")
    if verdict_kind not in {"affirmative", "negative"}:
        raise ValueError("unknown verdict kind")
    rendered = render_user_prompt(tokenizer, prompt)
    prefix_ids = tokenizer.encode(rendered, add_special_tokens=False)
    full_ids = tokenizer.encode(rendered + verdict, add_special_tokens=False)
    if not prefix_ids or full_ids[: len(prefix_ids)] != prefix_ids:
        raise RuntimeError("verdict tokenization does not preserve the frozen prompt prefix")
    verdict_ids = full_ids[len(prefix_ids) :]
    if (
        len(full_ids) > maximum_input_tokens
        or len(verdict_ids) < 2
        or len(verdict_ids) > maximum_verdict_tokens
    ):
        raise RuntimeError("verdict tokenization violates frozen token bounds")

    started = time.monotonic()
    logits = model(mx.array([full_ids[:-1]]))
    positions = mx.arange(len(prefix_ids) - 1, len(full_ids) - 1)
    source_logits_dtype = str(logits.dtype)
    continuation_logits = logits[0, positions, :].astype(mx.float32)
    targets = mx.array(verdict_ids)
    selected = mx.take_along_axis(continuation_logits, targets[:, None], axis=-1).squeeze(-1)
    token_logprobs = selected - mx.logsumexp(continuation_logits, axis=-1)
    mx.eval(token_logprobs)
    values = [float(value) for value in token_logprobs.tolist()]
    elapsed = time.monotonic() - started
    if len(values) != len(verdict_ids) or not all(math.isfinite(value) for value in values):
        raise RuntimeError("teacher-forced verdict log-probabilities are missing or nonfinite")
    total = sum(values)
    mean = total / len(values)
    body = {
        "runner_version": runner_version,
        "verdict_likelihood_version": VERDICT_LIKELIHOOD_VERSION,
        "model_key": model_key,
        "fixture_id": fixture_id,
        "evaluation_id": evaluation_id,
        "context_kind": context_kind,
        "verdict_kind": verdict_kind,
        "executed": True,
        "rendered_prompt_sha256": hashlib.sha256(rendered.encode("utf-8")).hexdigest(),
        "full_input_sha256": hashlib.sha256((rendered + verdict).encode("utf-8")).hexdigest(),
        "prompt_tokens": len(prefix_ids),
        "verdict": verdict,
        "verdict_token_ids": verdict_ids,
        "verdict_token_count": len(verdict_ids),
        "token_logprobabilities": values,
        "total_log_likelihood": total,
        "mean_log_likelihood": mean,
        "elapsed_seconds": elapsed,
        "model_logits_dtype": source_logits_dtype,
        "likelihood_accumulation_dtype": "float32",
        "teacher_forced_complete": True,
        "autoregressive_generation_performed": False,
        "correctness_authority_accessed": False,
    }
    return {**body, "record_id": content_digest(body)}


def aggregate_candidate_evaluations(
    evaluations: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    required = {
        "task_affirmative",
        "task_negative",
        "taskless_null_affirmative",
        "taskless_null_negative",
    }
    if set(evaluations) != required:
        raise RuntimeError("candidate evaluation registry is incomplete")
    if not all(row.get("teacher_forced_complete") for row in evaluations.values()):
        raise RuntimeError("cannot aggregate an incomplete verdict evaluation")
    task_difference = (
        float(evaluations["task_affirmative"]["mean_log_likelihood"])
        - float(evaluations["task_negative"]["mean_log_likelihood"])
    )
    null_difference = (
        float(evaluations["taskless_null_affirmative"]["mean_log_likelihood"])
        - float(evaluations["taskless_null_negative"]["mean_log_likelihood"])
    )
    corrected = task_difference - null_difference
    if not all(math.isfinite(value) for value in (task_difference, null_difference, corrected)):
        raise RuntimeError("candidate verdict margin is nonfinite")
    return {
        "aggregation_rule": "mean_logp_affirmative_minus_mean_logp_negative_then_task_minus_taskless_null",
        "task_verdict_margin": task_difference,
        "taskless_null_verdict_margin": null_difference,
        "task_minus_null_verdict_margin": corrected,
    }
