from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.instrument_provider import (
    DeterministicValidationReceipt,
    InstrumentOutput,
    InstrumentValidatorStageProvider,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_structure_atlas_v1 import (
    ARM_ORDER,
    HORIZON_SLOTS,
    VERSION,
    select_panel,
)
from scientist.domains.cognitive_core.self_ask_incumbent_v1 import (
    MODEL_ORDER,
    OFFICIAL_COMMIT,
    answer_is_exact,
    digest,
    extract_final_answer,
    file_sha256,
    normalize_answer,
)
from scientist.program.research_kernel import (
    CounterfactualContrast,
    PhenomenonAtlas,
    PhenomenonCase,
    ResearchActionKind,
)


ATLAS_PROVIDER_VERSION = "cognitive-causal-structure-atlas-provider-v3"
ATLAS_EXECUTOR_VERSION = "cognitive-causal-structure-atlas-executor-v3"
ATLAS_BINDING_VERSION = "cognitive-causal-structure-atlas-binding-v1"
_SOURCE_FILES = (
    "src/scientist/domains/cognitive_core/causal_structure_atlas_v1.py",
    "src/scientist/domains/cognitive_core/self_ask_incumbent_v1.py",
    "src/scientist/domains/cognitive_core/atlas_provider_v3.py",
    "src/scientist/autonomy/mlx_receipt_runner.py",
    "src/scientist/autonomy/receipt_journal.py",
    "scripts/run_cognitive_causal_structure_atlas_v3.py",
    "scripts/run_cognitive_atlas_v3_qualification.py",
)


def _read_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("expected JSON object: %s" % path)
    return value


def _read_jsonl(path: Path) -> list[Mapping[str, Any]]:
    values = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    ]
    if any(not isinstance(value, Mapping) for value in values):
        raise ValueError("expected JSON-object rows: %s" % path)
    return values


def _write_immutable(path: Path, value: Any, *, jsonl: bool = False) -> None:
    if jsonl:
        payload = "".join(
            json.dumps(item, sort_keys=True, ensure_ascii=False) + "\n"
            for item in value
        ).encode("utf-8")
    else:
        payload = (
            json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
        ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.read_bytes() != payload:
            raise ValueError("refusing to replace frozen atlas artifact: %s" % path)
        return
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _mentions(response: str, value: str) -> bool:
    normalized = normalize_answer(value)
    return bool(normalized) and normalized in normalize_answer(response)


def _extract_final_answer_safe(response: str) -> str:
    """Treat a terminal empty answer marker as a scored abstention."""

    try:
        return extract_final_answer(response)
    except IndexError:
        return ""


def _command_receipt(
    command: Sequence[str],
    completed: subprocess.CompletedProcess[str],
    elapsed: float,
    *,
    journal_receipt_count_before: int,
    journal_receipt_count_after: int,
    new_generation_wall_seconds: float,
) -> Mapping[str, Any]:
    body = {
        "command_digest": content_digest(list(command)),
        "stdout_digest": content_digest(completed.stdout),
        "stderr_digest": content_digest(completed.stderr),
        "returncode": int(completed.returncode),
        "wall_seconds": float(elapsed),
        "journal_receipt_count_before": journal_receipt_count_before,
        "journal_receipt_count_after": journal_receipt_count_after,
        "new_generation_wall_seconds": float(new_generation_wall_seconds),
        "orchestration_wall_seconds": max(
            0.0, float(elapsed) - float(new_generation_wall_seconds)
        ),
    }
    return {**body, "receipt_id": content_digest(body)}


class AutonomyBoundAtlasRunner:
    measurement_ref = "deterministic-answer-blind-atlas-scorer-v3"

    def __init__(
        self,
        *,
        project_root: Path,
        mission_dir: Path,
        incumbent_bundle_dir: Path,
        python_executable: Path,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.mission_dir = Path(mission_dir).resolve()
        self.incumbent_bundle_dir = Path(incumbent_bundle_dir).resolve()
        self.python_executable = Path(python_executable).absolute()
        self.output = self.mission_dir / "phenomenon_atlas_v3"

    def _journal_rows(self, model_key: str) -> list[Mapping[str, Any]]:
        root = self.output / "journals" / model_key / "receipts"
        return [_read_json(path) for path in sorted(root.glob("*.json"))]

    def _journal_invocations(
        self,
        model_key: str,
        protocol: Mapping[str, Any],
        *,
        receipt_ids: set[str] | None = None,
    ) -> tuple[ExternalInvocation, ...]:
        invocations = []
        for journal_row in self._journal_rows(model_key):
            journal_receipt_id = str(journal_row["receipt_id"])
            if receipt_ids is not None and journal_receipt_id not in receipt_ids:
                continue
            payload = journal_row.get("payload")
            if not isinstance(payload, Mapping) or not isinstance(
                payload.get("receipt"), Mapping
            ):
                raise ValueError("atlas journal omitted its generation receipt")
            receipt = payload["receipt"]
            usage = ResourceUsage.from_dict(journal_row["usage"])
            invocations.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="evaluate_atlas_generation:%s:%s"
                    % (model_key, journal_row["unit_ref"]),
                    actor=ActorIdentity(
                        "experimental-mlx-atlas-instrument:%s" % model_key,
                        ActorKind.TOOL_RUNTIME,
                    ),
                    authority_scope=AuthorityScope.EXECUTE,
                    input_artifact_ids=(
                        str(protocol["freeze_id"]),
                        str(protocol["models"][model_key]["identity_id"]),
                        str(receipt["prompt_sha256"]),
                    ),
                    output_artifact_ids=(
                        journal_receipt_id,
                        str(receipt["receipt_id"]),
                    ),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=usage.wall_seconds,
                        compute_units=usage.compute_units,
                    ),
                )
            )
        return tuple(invocations)

    def _prepare_protocol(self, kernel) -> tuple[Mapping[str, Any], float]:
        started = time.perf_counter()
        protocol_path = self.output / "protocol-freeze-v3.json"
        if protocol_path.exists():
            return _read_json(protocol_path), time.perf_counter() - started
        repository = self.project_root / "third_party" / "self-ask"
        observed_commit = subprocess.run(
            ("git", "-C", str(repository), "rev-parse", "HEAD"),
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        if observed_commit != OFFICIAL_COMMIT:
            raise ValueError("official Self-Ask repository revision changed")
        dataset_path = repository / "datasets" / "compositional_celebrities.json"
        source = json.loads(dataset_path.read_text(encoding="utf-8"))
        if not isinstance(source, Mapping) or len(source.get("data", ())) != 8693:
            raise ValueError("official compositional dataset is invalid")
        incumbent_public_path = self.incumbent_bundle_dir / "public/items.jsonl"
        incumbent_public = _read_jsonl(incumbent_public_path)
        excluded = {str(row["source_row_digest"]) for row in incumbent_public}
        public, intervention, authority = select_panel(source["data"], excluded)
        public_path = self.output / "public/items.jsonl"
        intervention_path = self.output / "intervention/first-hop-state.jsonl"
        authority_path = self.output / "sealed/authority.jsonl"
        _write_immutable(public_path, public, jsonl=True)
        _write_immutable(intervention_path, intervention, jsonl=True)
        _write_immutable(authority_path, authority, jsonl=True)
        incumbent_protocol = _read_json(
            self.incumbent_bundle_dir / "protocol-freeze.json"
        )
        body = {
            "version": VERSION,
            "provider_version": ATLAS_PROVIDER_VERSION,
            "executor_version": ATLAS_EXECUTOR_VERSION,
            "mission_id": kernel.mission.mission_id,
            "incumbent_portfolio_id": kernel.incumbent.portfolio_id,
            "action_id": kernel.next_action().action_id,
            "official_commit": observed_commit,
            "official_dataset_sha256": file_sha256(dataset_path),
            "source_code_sha256": {
                str(self.project_root / source_name): file_sha256(
                    self.project_root / source_name
                )
                for source_name in _SOURCE_FILES
            },
            "runtime": incumbent_protocol["runtime"],
            "models": {
                key: incumbent_protocol["models"][key] for key in MODEL_ORDER
            },
            "selection": {
                "method": (
                    "answer-blind SHA-256 rank by frozen horizon/category slot "
                    "after incumbent-row exclusion"
                ),
                "horizon_slots": {
                    key: [list(slot) for slot in value]
                    for key, value in HORIZON_SLOTS.items()
                },
                "n": len(public),
                "excluded_incumbent_items": len(excluded),
                "incumbent_public_sha256": file_sha256(incumbent_public_path),
                "public_path": str(public_path),
                "public_sha256": file_sha256(public_path),
                "evidence_path": str(intervention_path),
                "evidence_sha256": file_sha256(intervention_path),
                "authority_path": str(authority_path),
                "authority_sha256": file_sha256(authority_path),
                "answers_used_for_selection": False,
            },
            "arm_order": list(ARM_ORDER),
            "decoding": {
                "temperature": 0.0,
                "top_p": 1.0,
                "maximum_new_tokens": 192,
                "thinking": False,
                "one_generation_per_item_arm_model": True,
            },
            "receipt_journal": {
                "per_generation_immutable": True,
                "resume_pending_only": True,
                "completed_unit_mutation_allowed": False,
            },
            "final_answers_available_to_model": False,
            "second_hop_answers_available_to_model": False,
            "development_qualification_only": True,
            "prospective_nature_evidence_claimed": False,
        }
        protocol = {**body, "freeze_id": content_digest(body)}
        _write_immutable(protocol_path, protocol)
        return protocol, time.perf_counter() - started

    def _command(
        self,
        command: Sequence[str],
        *,
        kernel,
        model_key: str,
        protocol: Mapping[str, Any],
        prior_invocations: Sequence[ExternalInvocation],
    ) -> tuple[Mapping[str, Any], tuple[ExternalInvocation, ...]]:
        environment = dict(os.environ)
        prior_path = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = (
            str(self.project_root / "src")
            if not prior_path
            else "%s%s%s"
            % (self.project_root / "src", os.pathsep, prior_path)
        )
        before_rows = self._journal_rows(model_key)
        before_ids = {str(row["receipt_id"]) for row in before_rows}
        started = time.perf_counter()
        completed = subprocess.run(
            tuple(command),
            cwd=str(self.project_root),
            env=environment,
            capture_output=True,
            text=True,
            check=False,
        )
        elapsed = time.perf_counter() - started
        after_rows = self._journal_rows(model_key)
        after_ids = {str(row["receipt_id"]) for row in after_rows}
        new_ids = after_ids.difference(before_ids)
        new_generation_wall = sum(
            ResourceUsage.from_dict(row["usage"]).wall_seconds
            for row in after_rows
            if str(row["receipt_id"]) in new_ids
        )
        receipt = _command_receipt(
            command,
            completed,
            elapsed,
            journal_receipt_count_before=len(before_ids),
            journal_receipt_count_after=len(after_ids),
            new_generation_wall_seconds=new_generation_wall,
        )
        outputs = [str(receipt["receipt_id"])]
        completion_path = self.output / (
            "control/%s-v3-completion.json" % model_key
        )
        if completed.returncode == 0 and completion_path.exists():
            completion = _read_json(completion_path)
            outputs.extend(
                (
                    str(completion["completion_id"]),
                    str(completion["receipts_sha256"]),
                    str(completion["journal_completion_id"]),
                )
            )
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation="execute_resumable_atlas_cell:%s" % model_key,
            actor=ActorIdentity(
                "local-mlx-resumable-atlas-runtime:%s" % model_key,
                ActorKind.TOOL_RUNTIME,
            ),
            authority_scope=AuthorityScope.EXECUTE,
            input_artifact_ids=(
                str(protocol["freeze_id"]),
                str(protocol["models"][model_key]["identity_id"]),
            ),
            output_artifact_ids=tuple(dict.fromkeys(outputs)),
            usage=ResourceUsage(
                tool_calls=1,
                wall_seconds=float(receipt["orchestration_wall_seconds"]),
            ),
        )
        new_generation_invocations = self._journal_invocations(
            model_key, protocol, receipt_ids=new_ids
        )
        if completed.returncode != 0:
            infrastructure = "No Metal device available" in completed.stderr
            attempts = (
                *prior_invocations,
                invocation,
                *new_generation_invocations,
            )
            case = TransitionCase(
                case_ref="resumable-atlas-cell-failure:%s:%s"
                % (model_key, receipt["receipt_id"]),
                phase="phenomenon_mapping",
                question="Can the frozen atlas cell complete without changing evidence?",
                observations=(
                    "model_key=%s" % model_key,
                    "returncode=%s" % completed.returncode,
                    "stderr_digest=%s" % receipt["stderr_digest"],
                ),
                available_actions=(
                    RecoveryAction.EXACT_RETRY,
                    RecoveryAction.REPAIR_IMPLEMENTATION,
                ),
                protected_invariants=(
                    "mission identity",
                    "incumbent identity",
                    "protocol identity",
                    "completed journal receipts",
                ),
                evidence_refs=tuple(
                    artifact_id
                    for item in attempts
                    for artifact_id in item.output_artifact_ids
                ),
                retrospective=False,
                domain=kernel.mission.domain_id,
            )
            profile = FailureEvidenceProfile(
                case_id=case.case_id,
                runtime_available=not infrastructure,
                external_dependency_missing=False,
                implementation_integrity_passed=None if infrastructure else False,
                interface_qualified=None,
                protocol_feasible=None,
                measurement_qualified=None,
                scientific_outcome_observed=False,
                scientific_gate_passed=None,
                representation_limit_demonstrated=False,
            )
            raise AdjudicableResearchFailure(
                "resumable atlas model cell failed",
                case=case,
                profile=profile,
                attempt_invocations=tuple(attempts),
            )
        return receipt, (
            invocation,
            *self._journal_invocations(model_key, protocol),
        )

    def __call__(self, kernel, domain) -> InstrumentOutput:
        del domain
        if kernel.mission is None or kernel.incumbent is None:
            raise ValueError("atlas execution requires a reproduced incumbent")
        if kernel.next_action().kind != ResearchActionKind.MAP_PHENOMENON:
            raise ValueError("atlas runner received another research action")
        protocol, preparation_wall = self._prepare_protocol(kernel)
        if (
            protocol.get("mission_id") != kernel.mission.mission_id
            or protocol.get("incumbent_portfolio_id")
            != kernel.incumbent.portfolio_id
            or protocol.get("action_id") != kernel.next_action().action_id
        ):
            raise ValueError("atlas protocol belongs to another frontier")
        binding_path = self.output / "fresh-run-binding.json"
        if binding_path.exists():
            binding = _read_json(binding_path)
            binding_body = dict(binding)
            supplied_binding_id = binding_body.pop("binding_id", None)
            if supplied_binding_id != content_digest(binding_body):
                raise ValueError("atlas binding identity mismatch")
            if any(
                (
                    binding.get("version") != ATLAS_BINDING_VERSION,
                    binding.get("mission_id") != kernel.mission.mission_id,
                    binding.get("incumbent_portfolio_id")
                    != kernel.incumbent.portfolio_id,
                    binding.get("action_id") != kernel.next_action().action_id,
                    binding.get("freeze_id") != protocol["freeze_id"],
                )
            ):
                raise ValueError("atlas binding belongs to another frontier")
            preparation_receipt = binding["preparation_receipt"]
            command_receipts = binding["model_command_receipts"]
            completions = {
                key: _read_json(
                    self.output / ("control/%s-v3-completion.json" % key)
                )
                for key in MODEL_ORDER
            }
        else:
            preparation_body = {
                "operation": "freeze_causal_structure_atlas_protocol",
                "mission_id": kernel.mission.mission_id,
                "incumbent_portfolio_id": kernel.incumbent.portfolio_id,
                "freeze_id": protocol["freeze_id"],
                "wall_seconds": preparation_wall,
            }
            preparation_receipt = {
                **preparation_body,
                "receipt_id": content_digest(preparation_body),
            }
            command_receipts = {}
            provisional_preparation = ExternalInvocation(
                kind=InvocationKind.TOOL,
                operation="freeze_causal_structure_atlas_protocol",
                actor=ActorIdentity(
                    "causal-atlas-protocol-runtime-v3", ActorKind.TOOL_RUNTIME
                ),
                authority_scope=AuthorityScope.EXECUTE,
                input_artifact_ids=(
                    kernel.mission.mission_id,
                    kernel.incumbent.portfolio_id,
                ),
                output_artifact_ids=(
                    str(protocol["freeze_id"]),
                    str(preparation_receipt["receipt_id"]),
                ),
                usage=ResourceUsage(tool_calls=1, wall_seconds=preparation_wall),
            )
            provisional_invocations = [provisional_preparation]
            for model_key in MODEL_ORDER:
                command = (
                    str(self.python_executable),
                    "scripts/run_cognitive_causal_structure_atlas_v3.py",
                    "--output",
                    str(self.output),
                    "--model-key",
                    model_key,
                    "--action-id",
                    kernel.next_action().action_id,
                )
                command_receipts[model_key], model_invocations = self._command(
                    command,
                    kernel=kernel,
                    model_key=model_key,
                    protocol=protocol,
                    prior_invocations=tuple(provisional_invocations),
                )
                provisional_invocations.extend(model_invocations)
            completions = {
                key: _read_json(
                    self.output / ("control/%s-v3-completion.json" % key)
                )
                for key in MODEL_ORDER
            }
            binding_body = {
                "version": ATLAS_BINDING_VERSION,
                "mission_id": kernel.mission.mission_id,
                "incumbent_portfolio_id": kernel.incumbent.portfolio_id,
                "action_id": kernel.next_action().action_id,
                "freeze_id": protocol["freeze_id"],
                "preparation_receipt": preparation_receipt,
                "model_command_receipts": command_receipts,
                "completion_ids": {
                    key: completions[key]["completion_id"] for key in MODEL_ORDER
                },
                "receipt_sha256": {
                    key: completions[key]["receipts_sha256"] for key in MODEL_ORDER
                },
                "journal_completion_ids": {
                    key: completions[key]["journal_completion_id"]
                    for key in MODEL_ORDER
                },
                "normalized_compute_definition": (
                    "sum-of-immutable-per-generation-wall-seconds"
                ),
                "normalized_compute_units": sum(
                    float(
                        _read_json(
                            self.output
                            / "journals"
                            / key
                            / "completion.json"
                        )["total_usage"]["compute_units"]
                    )
                    for key in MODEL_ORDER
                ),
                "normalized_compute_charge_complete": True,
                "human_interventions": 0,
                "out_of_band_interventions": 0,
                "development_qualification_only": True,
                "prospective_nature_evidence_claimed": False,
            }
            binding = {**binding_body, "binding_id": content_digest(binding_body)}
            _write_immutable(binding_path, binding)
        preparation_invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation="freeze_causal_structure_atlas_protocol",
            actor=ActorIdentity(
                "causal-atlas-protocol-runtime-v3", ActorKind.TOOL_RUNTIME
            ),
            authority_scope=AuthorityScope.EXECUTE,
            input_artifact_ids=(
                kernel.mission.mission_id,
                kernel.incumbent.portfolio_id,
            ),
            output_artifact_ids=(
                str(protocol["freeze_id"]),
                str(preparation_receipt["receipt_id"]),
            ),
            usage=ResourceUsage(
                tool_calls=1,
                wall_seconds=float(preparation_receipt["wall_seconds"]),
            ),
        )
        invocations = [preparation_invocation]
        for model_key in MODEL_ORDER:
            completion = completions[model_key]
            command_receipt = command_receipts[model_key]
            invocations.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="execute_resumable_atlas_cell:%s" % model_key,
                    actor=ActorIdentity(
                        "local-mlx-resumable-atlas-runtime:%s" % model_key,
                        ActorKind.TOOL_RUNTIME,
                    ),
                    authority_scope=AuthorityScope.EXECUTE,
                    input_artifact_ids=(
                        str(protocol["freeze_id"]),
                        str(protocol["models"][model_key]["identity_id"]),
                    ),
                    output_artifact_ids=(
                        str(command_receipt["receipt_id"]),
                        str(completion["completion_id"]),
                        str(completion["receipts_sha256"]),
                        str(completion["journal_completion_id"]),
                    ),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=float(
                            command_receipt["orchestration_wall_seconds"]
                        ),
                    ),
                )
            )
            invocations.extend(self._journal_invocations(model_key, protocol))
        atlas, evidence_id, summary = self._score(kernel, protocol, completions)
        score_invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation="score_causal_structure_atlas",
            actor=ActorIdentity(self.measurement_ref, ActorKind.TOOL_RUNTIME),
            authority_scope=AuthorityScope.MEASURE,
            input_artifact_ids=(
                str(protocol["freeze_id"]),
                str(protocol["selection"]["authority_sha256"]),
                str(binding["binding_id"]),
                *tuple(
                    str(completions[key]["completion_id"]) for key in MODEL_ORDER
                ),
            ),
            output_artifact_ids=(atlas.atlas_id, evidence_id),
            usage=ResourceUsage(tool_calls=1),
        )
        invocations.append(score_invocation)
        return InstrumentOutput(
            artifact=atlas,
            artifact_id=atlas.atlas_id,
            invocations=tuple(invocations),
            measurement_ref=self.measurement_ref,
            details={
                "atlas_provider_version": ATLAS_PROVIDER_VERSION,
                "freeze_id": protocol["freeze_id"],
                "fresh_run_binding_id": binding["binding_id"],
                "evidence_id": evidence_id,
                "completion_ids": binding["completion_ids"],
                "journal_completion_ids": binding["journal_completion_ids"],
                "summary": summary,
                "normalized_compute_charge_complete": True,
                "normalized_compute_definition": binding[
                    "normalized_compute_definition"
                ],
                "normalized_compute_units": binding["normalized_compute_units"],
                "generation_invocations": sum(
                    len(self._journal_rows(key)) for key in MODEL_ORDER
                ),
                "fresh_run_bound_execution": True,
                "development_only": True,
                "prospective_nature_evidence_claimed": False,
            },
        )

    def _score(self, kernel, protocol, completions):
        public = _read_jsonl(Path(str(protocol["selection"]["public_path"])))
        intervention = {
            str(row["item_id"]): row
            for row in _read_jsonl(Path(str(protocol["selection"]["evidence_path"])))
        }
        authority = {
            str(row["item_id"]): row
            for row in _read_jsonl(Path(str(protocol["selection"]["authority_path"])))
        }
        receipts_by_model = {}
        for model_key in MODEL_ORDER:
            completion = completions[model_key]
            if (
                completion.get("status")
                != "resumable_atlas_receipt_matrix_complete"
                or completion.get("freeze_id") != protocol["freeze_id"]
                or completion.get("action_id") != kernel.next_action().action_id
                or file_sha256(Path(str(completion["receipts_path"])))
                != completion["receipts_sha256"]
                or completion.get("final_answers_opened_before_receipts") is not False
                or completion.get("second_hop_answers_opened_before_receipts")
                is not False
            ):
                raise ValueError("resumable atlas completion is invalid")
            rows = _read_jsonl(Path(str(completion["receipts_path"])))
            if any(
                row.get("receipt_id")
                != content_digest(
                    {key: value for key, value in row.items() if key != "receipt_id"}
                )
                for row in rows
            ):
                raise ValueError("atlas receipt identity mismatch")
            keyed = {(str(row["item_id"]), str(row["arm"])): row for row in rows}
            if len(rows) != 12 * len(ARM_ORDER) or len(keyed) != len(rows):
                raise ValueError("atlas receipt matrix is incomplete")
            receipts_by_model[model_key] = keyed

        cases = []
        scored_rows = []
        case_context = {}
        for model_key in MODEL_ORDER:
            for item in public:
                item_id = str(item["item_id"])
                truth = authority[item_id]
                state = intervention[item_id]
                arm_rows = {
                    arm: receipts_by_model[model_key][(item_id, arm)]
                    for arm in ARM_ORDER
                }
                predictions = {
                    arm: _extract_final_answer_safe(str(row["response"]))
                    for arm, row in arm_rows.items()
                }
                correct = {
                    arm: answer_is_exact(value, truth["composed_answers"])
                    for arm, value in predictions.items()
                }
                current_mentions = {
                    arm: _mentions(
                        str(row["response"]), str(state["current_first_hop"])
                    )
                    for arm, row in arm_rows.items()
                }
                stale_mentions = {
                    arm: _mentions(
                        str(row["response"]), str(state["stale_first_hop"])
                    )
                    for arm, row in arm_rows.items()
                }
                metrics = {}
                for arm in ARM_ORDER:
                    metrics["%s_accuracy" % arm] = float(correct[arm])
                    metrics["%s_output_tokens" % arm] = float(
                        arm_rows[arm]["output_tokens"]
                    )
                    metrics["%s_current_mention" % arm] = float(
                        current_mentions[arm]
                    )
                    metrics["%s_stale_mention" % arm] = float(
                        stale_mentions[arm]
                    )
                case = PhenomenonCase(
                    case_ref="%s:%s" % (model_key, item_id),
                    regime=str(item["regime"]),
                    horizon=str(item["horizon"]),
                    incumbent_decision="incumbent_self_ask",
                    outcome_metrics=metrics,
                    evidence_ids=tuple(
                        str(arm_rows[arm]["receipt_id"]) for arm in ARM_ORDER
                    ),
                    trace_ref=content_digest(
                        {
                            "model_key": model_key,
                            "item_id": item_id,
                            "receipts": [
                                arm_rows[arm]["receipt_id"] for arm in ARM_ORDER
                            ],
                        }
                    ),
                )
                cases.append(case)
                row = {
                    "case_id": case.case_id,
                    "model_key": model_key,
                    "item_id": item_id,
                    "category": item["category"],
                    "regime": item["regime"],
                    "horizon": item["horizon"],
                    "predictions": predictions,
                    "correct": correct,
                    "current_first_hop_mentioned": current_mentions,
                    "stale_first_hop_mentioned": stale_mentions,
                }
                scored_rows.append(row)
                case_context[case.case_id] = (row, arm_rows)

        contrasts = []
        for case in cases:
            row, arm_rows = case_context[case.case_id]
            correct = row["correct"]
            transaction_differential = (
                correct["transaction_atomic_trusted"]
                != correct["transaction_interleaved_trusted"]
            )
            provenance_differential = (
                correct["transaction_atomic_trusted"]
                != correct["provenance_swapped_current"]
            )
            for forced_arm in ARM_ORDER[1:]:
                unexplained = (
                    bool(transaction_differential or provenance_differential)
                    if forced_arm
                    in (
                        "transaction_atomic_trusted",
                        "transaction_interleaved_trusted",
                    )
                    else bool(provenance_differential)
                    if forced_arm == "provenance_swapped_current"
                    else False
                )
                contrasts.append(
                    CounterfactualContrast(
                        case_id=case.case_id,
                        incumbent_decision="incumbent_self_ask",
                        forced_decision=forced_arm,
                        terminal_effect=float(
                            int(correct[forced_arm])
                            - int(correct["incumbent_self_ask"])
                        ),
                        matched_context=(
                            "Same frozen model and composed question; direct is the "
                            "no-state null."
                            if forced_arm == "direct"
                            else "Same model, question, values, decoding, and answer-blind boundary; only the frozen transaction/provenance arm changes."
                        ),
                        mediator_observation=(
                            "current_first_hop_mentioned=%d; stale_first_hop_mentioned=%d; forced_correct=%d; incumbent_correct=%d"
                            % (
                                row["current_first_hop_mentioned"][forced_arm],
                                row["stale_first_hop_mentioned"][forced_arm],
                                correct[forced_arm],
                                correct["incumbent_self_ask"],
                            )
                        ),
                        existing_descriptors=(
                            "model:%s" % row["model_key"],
                            "regime:%s" % row["regime"],
                            "horizon:%s" % row["horizon"],
                            "category:%s" % row["category"],
                            "frozen_first_hop_state:true",
                        ),
                        unexplained_by_current_representation=unexplained,
                        evidence_ids=(
                            str(arm_rows["incumbent_self_ask"]["receipt_id"]),
                            str(arm_rows[forced_arm]["receipt_id"]),
                        ),
                        analyst_ref=self.measurement_ref,
                    )
                )
        atlas = PhenomenonAtlas(
            mission_id=kernel.mission.mission_id,
            incumbent_portfolio_id=kernel.incumbent.portfolio_id,
            cases=tuple(cases),
            contrasts=tuple(contrasts),
            coverage_axes=(
                "model_size",
                "causal_regime",
                "development_horizon",
                "transaction_schedule",
                "proposition_provenance",
                "accuracy_and_generation_cost",
            ),
            sealed=True,
            builder_ref="deterministic-causal-structure-phenomenon-mapper:v3",
        )
        effects = [contrast.terminal_effect for contrast in contrasts]
        summary = {
            "cases": len(cases),
            "contrasts": len(contrasts),
            "unexplained_contrasts": sum(
                item.unexplained_by_current_representation for item in contrasts
            ),
            "positive_effects": sum(value > 0.0 for value in effects),
            "zero_effects": sum(value == 0.0 for value in effects),
            "negative_effects": sum(value < 0.0 for value in effects),
            "regimes": sorted({case.regime for case in cases}),
            "horizons": sorted({case.horizon for case in cases}),
            "readiness_failures": list(atlas.readiness_failures(kernel.policy)),
        }
        evidence_body = {
            "version": VERSION,
            "provider_version": ATLAS_PROVIDER_VERSION,
            "freeze_id": protocol["freeze_id"],
            "mission_id": kernel.mission.mission_id,
            "incumbent_portfolio_id": kernel.incumbent.portfolio_id,
            "summary": summary,
            "rows": scored_rows,
            "completion_ids": {
                key: completions[key]["completion_id"] for key in MODEL_ORDER
            },
            "final_answers_opened_after_receipts": True,
            "second_hop_answers_opened_after_receipts": True,
            "external_search_used": False,
            "codex_exchange_used": False,
        }
        evidence_id = content_digest(evidence_body)
        _write_immutable(
            self.output / "phenomenon-evidence-v3.json",
            {**evidence_body, "evidence_id": evidence_id},
        )
        _write_immutable(self.output / "phenomenon-atlas-v3.json", atlas.as_dict())
        return atlas, evidence_id, summary


def validate_autonomy_bound_atlas(
    output: InstrumentOutput, kernel, domain
) -> DeterministicValidationReceipt:
    del domain
    atlas = output.artifact
    if not isinstance(atlas, PhenomenonAtlas):
        raise ValueError("atlas instrument returned another artifact type")
    if kernel.mission is None or kernel.incumbent is None:
        raise ValueError("atlas validation requires mission incumbent state")
    summary = output.details["summary"]
    checks = {
        "artifact_identity": output.artifact_id == atlas.atlas_id,
        "mission_identity": atlas.mission_id == kernel.mission.mission_id,
        "incumbent_identity": atlas.incumbent_portfolio_id
        == kernel.incumbent.portfolio_id,
        "atlas_sealed": atlas.sealed,
        "kernel_readiness": not atlas.readiness_failures(kernel.policy),
        "case_count": int(summary["cases"]) == 24,
        "contrast_count": int(summary["contrasts"]) == 96,
        "three_regimes": len(summary["regimes"]) == 3,
        "three_horizons": len(summary["horizons"]) == 3,
        "journal_completions_retained": len(
            output.details["journal_completion_ids"]
        )
        == len(MODEL_ORDER),
        "all_generations_individually_charged": output.details[
            "generation_invocations"
        ]
        == 120,
        "generation_compute_definition_frozen": output.details[
            "normalized_compute_definition"
        ]
        == "sum-of-immutable-per-generation-wall-seconds",
        "generation_compute_positive": float(
            output.details["normalized_compute_units"]
        )
        > 0.0,
        "compute_charge_complete": output.details[
            "normalized_compute_charge_complete"
        ],
        "fresh_run_bound": output.details["fresh_run_bound_execution"],
        "nature_evidence_not_claimed": output.details[
            "prospective_nature_evidence_claimed"
        ]
        is False,
    }
    return DeterministicValidationReceipt(
        artifact_id=output.artifact_id,
        verifier_ref="independent-causal-atlas-validator-v3",
        checks=checks,
        evidence_ids=(
            str(output.details["freeze_id"]),
            str(output.details["fresh_run_binding_id"]),
            str(output.details["evidence_id"]),
            *tuple(
                str(output.details["completion_ids"][key]) for key in MODEL_ORDER
            ),
            *tuple(
                str(output.details["journal_completion_ids"][key])
                for key in MODEL_ORDER
            ),
        ),
    )


def build_autonomy_bound_atlas_stage_provider(
    *,
    project_root: Path,
    mission_dir: Path,
    incumbent_bundle_dir: Path,
    python_executable: Path,
) -> InstrumentValidatorStageProvider:
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.MAP_PHENOMENON,
        runner=AutonomyBoundAtlasRunner(
            project_root=project_root,
            mission_dir=mission_dir,
            incumbent_bundle_dir=incumbent_bundle_dir,
            python_executable=python_executable,
        ),
        validator=validate_autonomy_bound_atlas,
        outcome="causal_structure_phenomenon_atlas_mapped",
    )


__all__ = [
    "ATLAS_BINDING_VERSION",
    "ATLAS_EXECUTOR_VERSION",
    "ATLAS_PROVIDER_VERSION",
    "AutonomyBoundAtlasRunner",
    "build_autonomy_bound_atlas_stage_provider",
    "validate_autonomy_bound_atlas",
]
