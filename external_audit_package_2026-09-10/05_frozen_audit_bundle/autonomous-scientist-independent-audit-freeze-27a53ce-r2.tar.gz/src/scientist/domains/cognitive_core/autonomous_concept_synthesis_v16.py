from __future__ import annotations

import itertools
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION = (
    "cognitive-core-autonomous-concept-synthesis-v16"
)


class MetaEventKind(str, Enum):
    LEARN = "learn"
    QUERY = "query"
    SELECT = "select"
    UPDATE = "update"


class MetaActionKind(str, Enum):
    LEARNED = "learned"
    ANSWER = "answer"
    SELECTION = "selection"
    UPDATED = "updated"
    ABSTAIN = "abstain"


@dataclass(frozen=True)
class KnowledgeRow:
    row_id: str
    cells: Tuple[Any, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {"row_id": self.row_id, "cells": list(self.cells)}


@dataclass(frozen=True)
class MetaExample:
    inputs: Tuple[Any, ...]
    output: Any

    def as_dict(self) -> Dict[str, Any]:
        return {"inputs": list(self.inputs), "output": self.output}


@dataclass(frozen=True)
class MetaTaskSpec:
    task_ref: str
    evaluator_family: str
    examples: Tuple[MetaExample, ...]
    query_inputs: Tuple[Any, ...]
    expected_before: Any
    context: Tuple[KnowledgeRow, ...]
    expected_relevant_row_ids: Tuple[str, ...]
    metadata: Mapping[str, Any]
    update_address: Tuple[Any, ...]
    update_value: Any
    expected_after: Any

    def as_dict(self) -> Dict[str, Any]:
        return {
            "task_ref": self.task_ref,
            "evaluator_family": self.evaluator_family,
            "examples": [item.as_dict() for item in self.examples],
            "query_inputs": list(self.query_inputs),
            "expected_before": self.expected_before,
            "context": [item.as_dict() for item in self.context],
            "expected_relevant_row_ids": list(
                self.expected_relevant_row_ids
            ),
            "metadata": dict(self.metadata),
            "update_address": list(self.update_address),
            "update_value": self.update_value,
            "expected_after": self.expected_after,
        }


@dataclass(frozen=True)
class MetaEvent:
    event_id: str
    kind: MetaEventKind
    task_ref: str
    payload: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "kind": self.kind.value,
            "task_ref": self.task_ref,
            "payload": dict(self.payload),
        }


@dataclass(frozen=True)
class MetaProbe:
    probe_id: str
    event_id: str
    task_ref: str
    evaluator_family: str
    expected_kind: MetaActionKind
    expected_payload: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe_id": self.probe_id,
            "event_id": self.event_id,
            "task_ref": self.task_ref,
            "evaluator_family": self.evaluator_family,
            "expected_kind": self.expected_kind.value,
            "expected_payload": dict(self.expected_payload),
        }


@dataclass(frozen=True)
class MetaRegistry:
    partition: str
    tasks: Tuple[MetaTaskSpec, ...]
    events: Tuple[MetaEvent, ...]
    probes: Tuple[MetaProbe, ...]
    authority_ref: str
    exposure_stage: int

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "partition": self.partition,
            "tasks": [item.as_dict() for item in self.tasks],
            "events": [item.as_dict() for item in self.events],
            "probes": [item.as_dict() for item in self.probes],
            "authority_ref": self.authority_ref,
            "exposure_stage": self.exposure_stage,
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


def build_meta_registry(
    *,
    partition: str,
    tasks: Sequence[MetaTaskSpec],
    authority_ref: str,
    exposure_stage: int,
) -> MetaRegistry:
    task_rows = tuple(tasks)
    events = []
    probes = []
    for task in task_rows:
        event = MetaEvent(
            event_id="%s-learn" % task.task_ref,
            kind=MetaEventKind.LEARN,
            task_ref=task.task_ref,
            payload={
                "examples": [item.as_dict() for item in task.examples],
                "context": [item.as_dict() for item in task.context],
                "metadata": dict(task.metadata),
            },
        )
        events.append(event)
    for task in task_rows:
        query = MetaEvent(
            event_id="%s-query-before" % task.task_ref,
            kind=MetaEventKind.QUERY,
            task_ref=task.task_ref,
            payload={"inputs": list(task.query_inputs)},
        )
        select = MetaEvent(
            event_id="%s-select-before" % task.task_ref,
            kind=MetaEventKind.SELECT,
            task_ref=task.task_ref,
            payload={"inputs": list(task.query_inputs)},
        )
        events.extend((query, select))
        probes.extend(
            (
                MetaProbe(
                    "%s-probe-query-before" % task.task_ref,
                    query.event_id,
                    task.task_ref,
                    task.evaluator_family,
                    MetaActionKind.ANSWER,
                    {"value": task.expected_before},
                ),
                MetaProbe(
                    "%s-probe-select-before" % task.task_ref,
                    select.event_id,
                    task.task_ref,
                    task.evaluator_family,
                    MetaActionKind.SELECTION,
                    {"row_ids": list(task.expected_relevant_row_ids)},
                ),
            )
        )
    for task in task_rows:
        update = MetaEvent(
            event_id="%s-update" % task.task_ref,
            kind=MetaEventKind.UPDATE,
            task_ref=task.task_ref,
            payload={
                "address": list(task.update_address),
                "value": task.update_value,
            },
        )
        events.append(update)
        probes.append(
            MetaProbe(
                "%s-probe-update" % task.task_ref,
                update.event_id,
                task.task_ref,
                task.evaluator_family,
                MetaActionKind.UPDATED,
                {"accepted": True},
            )
        )
    for task in reversed(task_rows):
        query = MetaEvent(
            event_id="%s-query-after" % task.task_ref,
            kind=MetaEventKind.QUERY,
            task_ref=task.task_ref,
            payload={"inputs": list(task.query_inputs)},
        )
        select = MetaEvent(
            event_id="%s-select-after" % task.task_ref,
            kind=MetaEventKind.SELECT,
            task_ref=task.task_ref,
            payload={"inputs": list(task.query_inputs)},
        )
        events.extend((query, select))
        probes.extend(
            (
                MetaProbe(
                    "%s-probe-query-after" % task.task_ref,
                    query.event_id,
                    task.task_ref,
                    task.evaluator_family,
                    MetaActionKind.ANSWER,
                    {"value": task.expected_after},
                ),
                MetaProbe(
                    "%s-probe-select-after" % task.task_ref,
                    select.event_id,
                    task.task_ref,
                    task.evaluator_family,
                    MetaActionKind.SELECTION,
                    {"row_ids": list(task.expected_relevant_row_ids)},
                ),
            )
        )
    return MetaRegistry(
        partition=partition,
        tasks=task_rows,
        events=tuple(events),
        probes=tuple(probes),
        authority_ref=authority_ref,
        exposure_stage=exposure_stage,
    )


@dataclass(frozen=True)
class TypedExpression:
    kind: str
    arguments: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {"kind": self.kind, "arguments": dict(self.arguments)}


def _follow_path(
    rows: Sequence[KnowledgeRow],
    start: Any,
    relations: Sequence[Any],
) -> Tuple[Any | None, Tuple[str, ...]]:
    current = start
    used = []
    for relation in relations:
        matches = [
            row
            for row in rows
            if len(row.cells) == 3
            and row.cells[0] == current
            and row.cells[1] == relation
        ]
        if len(matches) != 1:
            return None, ()
        row = matches[0]
        used.append(row.row_id)
        current = row.cells[2]
    return current, tuple(used)


def execute_expression(
    expression: TypedExpression,
    inputs: Sequence[Any],
    context: Sequence[KnowledgeRow],
) -> Tuple[Any | None, Tuple[str, ...]]:
    if len(inputs) != 1:
        return None, ()
    value = inputs[0]
    if expression.kind == "table":
        table = {
            tuple(item[0]): item[1]
            for item in expression.arguments["items"]
        }
        return table.get(tuple(inputs)), ()
    if expression.kind == "polynomial_mod":
        modulus = int(expression.arguments["modulus"])
        total = 0
        power = 1
        for coefficient in expression.arguments["coefficients"]:
            total = (total + int(coefficient) * power) % modulus
            power = (power * int(value)) % modulus
        return total, ()
    if expression.kind == "relation_path":
        return _follow_path(
            context,
            value,
            expression.arguments["relations"],
        )
    return None, ()


def infer_typed_expression(
    examples: Sequence[MetaExample],
    context: Sequence[KnowledgeRow],
    metadata: Mapping[str, Any],
) -> TypedExpression | None:
    if not examples or any(len(item.inputs) != 1 for item in examples):
        return None
    if all(
        isinstance(item.inputs[0], int) and isinstance(item.output, int)
        for item in examples
    ) and isinstance(metadata.get("field_0"), int):
        modulus = int(metadata["field_0"])
        for degree in range(3):
            matches = []
            for coefficients in itertools.product(
                range(modulus), repeat=degree + 1
            ):
                expression = TypedExpression(
                    "polynomial_mod",
                    {"modulus": modulus, "coefficients": list(coefficients)},
                )
                if all(
                    execute_expression(
                        expression, item.inputs, context
                    )[0]
                    == item.output
                    for item in examples
                ):
                    matches.append(expression)
            if len(matches) == 1:
                return matches[0]
    relations = tuple(
        sorted(
            {row.cells[1] for row in context if len(row.cells) == 3},
            key=str,
        )
    )
    for length in range(1, 4):
        matches = []
        for path in itertools.product(relations, repeat=length):
            if all(
                _follow_path(context, item.inputs[0], path)[0]
                == item.output
                for item in examples
            ):
                matches.append(path)
        if len(matches) == 1:
            return TypedExpression(
                "relation_path", {"relations": list(matches[0])}
            )
    return None


@dataclass(frozen=True)
class PolicyProgram:
    address_mode: str
    induction_mode: str
    selection_mode: str
    update_mode: str
    retention_mode: str

    @property
    def program_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def complexity(self) -> int:
        return sum(
            value
            in {
                "equality_join",
                "enumerate_typed_expressions",
                "execution_slice",
                "in_place_addressed",
                "persistent_map",
            }
            for value in (
                self.address_mode,
                self.induction_mode,
                self.selection_mode,
                self.update_mode,
                self.retention_mode,
            )
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "node_type": "typed_policy_program",
            "address_mode": self.address_mode,
            "induction_mode": self.induction_mode,
            "selection_mode": self.selection_mode,
            "update_mode": self.update_mode,
            "retention_mode": self.retention_mode,
        }
        if include_id:
            value["program_id"] = self.program_id
        return value


def enumerate_policy_programs() -> Tuple[PolicyProgram, ...]:
    return tuple(
        PolicyProgram(*values)
        for values in itertools.product(
            ("last_seen", "equality_join"),
            ("memorize_examples", "enumerate_typed_expressions"),
            ("all_context", "execution_slice"),
            ("detached_append", "in_place_addressed"),
            ("single_slot", "persistent_map"),
        )
    )


@dataclass(frozen=True)
class MetaAction:
    kind: MetaActionKind
    payload: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {"kind": self.kind.value, "payload": dict(self.payload)}


@dataclass(frozen=True)
class TraceAccess:
    mode: str
    record_id: str
    cells: Tuple[Any, ...]
    created_at: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "mode": self.mode,
            "record_id": self.record_id,
            "cells": list(self.cells),
            "created_at": self.created_at,
        }


@dataclass(frozen=True)
class RuntimeStep:
    sequence: int
    event: MetaEvent
    action: MetaAction
    query_channels: Tuple[Tuple[Any, ...], ...]
    accesses: Tuple[TraceAccess, ...]
    intervention_write_ids: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "sequence": self.sequence,
            "event": self.event.as_dict(),
            "action": self.action.as_dict(),
            "query_channels": [list(item) for item in self.query_channels],
            "accesses": [item.as_dict() for item in self.accesses],
            "intervention_write_ids": list(self.intervention_write_ids),
        }


@dataclass
class _StoredSchema:
    task_ref: str
    expression: TypedExpression
    examples: Tuple[MetaExample, ...]
    context: Tuple[KnowledgeRow, ...]
    created_at: int
    last_intervention_write_id: str = ""


class TypedPolicyRuntime:
    """Generic interpreter for synthesized policy ASTs."""

    def __init__(self, program: PolicyProgram) -> None:
        self.program = program
        self.schemas: Dict[str, _StoredSchema] = {}
        self.last_key: str | None = None
        self.sequence = 0

    def _resolve(self, requested: str) -> _StoredSchema | None:
        key = (
            requested
            if self.program.address_mode == "equality_join"
            else self.last_key
        )
        return None if key is None else self.schemas.get(key)

    @staticmethod
    def _type_atom(value: Any) -> str:
        return "type:%s" % type(value).__name__

    def act(self, event: MetaEvent) -> RuntimeStep:
        sequence = self.sequence
        self.sequence += 1
        accesses = []
        intervention_ids: Tuple[str, ...] = ()
        query_channels: Tuple[Tuple[Any, ...], ...] = (
            (event.task_ref,),
            tuple(
                self._type_atom(item)
                for item in event.payload.get("inputs", ())
            ),
        )
        if event.kind == MetaEventKind.LEARN:
            examples = tuple(
                MetaExample(tuple(item["inputs"]), item["output"])
                for item in event.payload["examples"]
            )
            context = tuple(
                KnowledgeRow(str(item["row_id"]), tuple(item["cells"]))
                for item in event.payload["context"]
            )
            if self.program.induction_mode == "memorize_examples":
                expression = TypedExpression(
                    "table",
                    {
                        "items": [
                            [list(item.inputs), item.output]
                            for item in examples
                        ]
                    },
                )
            else:
                expression = infer_typed_expression(
                    examples, context, event.payload["metadata"]
                )
            if expression is None:
                action = MetaAction(
                    MetaActionKind.ABSTAIN,
                    {"reason": "no unique typed expression"},
                )
            else:
                if self.program.retention_mode == "single_slot":
                    self.schemas.clear()
                schema = _StoredSchema(
                    task_ref=event.task_ref,
                    expression=expression,
                    examples=examples,
                    context=context,
                    created_at=sequence,
                )
                self.schemas[event.task_ref] = schema
                self.last_key = event.task_ref
                record_id = "schema:%s" % event.task_ref
                cells = [event.task_ref, expression.kind]
                if expression.kind != "table":
                    cells.extend(
                        self._type_atom(item)
                        for item in examples[0].inputs
                    )
                accesses.append(
                    TraceAccess(
                        "write", record_id, tuple(cells), sequence
                    )
                )
                action = MetaAction(MetaActionKind.LEARNED, {"accepted": True})
        elif event.kind in (MetaEventKind.QUERY, MetaEventKind.SELECT):
            schema = self._resolve(event.task_ref)
            if schema is None:
                action = MetaAction(
                    MetaActionKind.ABSTAIN, {"reason": "no addressed schema"}
                )
            else:
                inputs = tuple(event.payload["inputs"])
                value, used_rows = execute_expression(
                    schema.expression, inputs, schema.context
                )
                record_id = "schema:%s" % schema.task_ref
                cells = [schema.task_ref, schema.expression.kind]
                if schema.expression.kind != "table":
                    cells.extend(self._type_atom(item) for item in inputs)
                accesses.append(
                    TraceAccess(
                        "read" if event.kind == MetaEventKind.QUERY else "resolve",
                        record_id,
                        tuple(cells),
                        schema.created_at,
                    )
                )
                intervention_ids = tuple(
                    item
                    for item in (schema.last_intervention_write_id,)
                    if item
                )
                if event.kind == MetaEventKind.QUERY:
                    action = (
                        MetaAction(MetaActionKind.ANSWER, {"value": value})
                        if value is not None
                        else MetaAction(
                            MetaActionKind.ABSTAIN,
                            {"reason": "expression is undefined"},
                        )
                    )
                else:
                    if self.program.selection_mode == "all_context":
                        selected = tuple(row.row_id for row in schema.context)
                    else:
                        selected = used_rows
                    selected_rows = {
                        row.row_id: row for row in schema.context
                    }
                    for row_id in selected:
                        row = selected_rows[row_id]
                        accesses.append(
                            TraceAccess(
                                "read",
                                "row:%s" % row.row_id,
                                row.cells,
                                schema.created_at,
                            )
                        )
                    action = MetaAction(
                        MetaActionKind.SELECTION,
                        {"row_ids": list(selected)},
                    )
        elif event.kind == MetaEventKind.UPDATE:
            schema = self._resolve(event.task_ref)
            if schema is None:
                action = MetaAction(
                    MetaActionKind.ABSTAIN, {"reason": "no addressed schema"}
                )
            else:
                address = tuple(event.payload["address"])
                value = event.payload["value"]
                if self.program.update_mode == "detached_append":
                    record_id = "detached:%s:%d" % (event.task_ref, sequence)
                else:
                    record_id = "schema:%s" % schema.task_ref
                    expression = schema.expression
                    context = list(schema.context)
                    if (
                        address[0] == "coefficient"
                        and expression.kind == "polynomial_mod"
                    ):
                        coefficients = list(expression.arguments["coefficients"])
                        coefficients[int(address[1])] = int(value)
                        expression = TypedExpression(
                            expression.kind,
                            {
                                **expression.arguments,
                                "coefficients": coefficients,
                            },
                        )
                    elif (
                        address[0] == "row"
                        and expression.kind == "relation_path"
                    ):
                        row_id = str(address[1])
                        cell_index = int(address[2])
                        context = [
                            KnowledgeRow(
                                row.row_id,
                                tuple(
                                    value if index == cell_index else cell
                                    for index, cell in enumerate(row.cells)
                                ),
                            )
                            if row.row_id == row_id
                            else row
                            for row in context
                        ]
                    else:
                        action = MetaAction(
                            MetaActionKind.ABSTAIN,
                            {"reason": "unsupported typed update address"},
                        )
                        return RuntimeStep(
                            sequence,
                            event,
                            action,
                            query_channels,
                            (),
                            (),
                        )
                    schema.expression = expression
                    schema.context = tuple(context)
                    schema.last_intervention_write_id = record_id
                accesses.append(
                    TraceAccess(
                        "write",
                        record_id,
                        (event.task_ref, *address, value),
                        sequence,
                    )
                )
                action = MetaAction(MetaActionKind.UPDATED, {"accepted": True})
        else:  # pragma: no cover - enum exhaustiveness
            action = MetaAction(
                MetaActionKind.ABSTAIN, {"reason": "unsupported event"}
            )
        return RuntimeStep(
            sequence=sequence,
            event=event,
            action=action,
            query_channels=query_channels,
            accesses=tuple(accesses),
            intervention_write_ids=intervention_ids,
        )


@dataclass(frozen=True)
class ProbeOutcome:
    probe: MetaProbe
    observed: MetaAction
    passed: bool
    trace: RuntimeStep

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe": self.probe.as_dict(),
            "observed": self.observed.as_dict(),
            "passed": self.passed,
            "trace": self.trace.as_dict(),
        }


@dataclass(frozen=True)
class PolicyEvaluation:
    program: PolicyProgram
    registry_id: str
    outcomes: Tuple[ProbeOutcome, ...]
    family_scores: Mapping[str, float]

    @property
    def score(self) -> float:
        return sum(item.passed for item in self.outcomes) / len(self.outcomes)

    @property
    def evaluation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "program": self.program.as_dict(),
            "registry_id": self.registry_id,
            "outcomes": [item.as_dict() for item in self.outcomes],
            "score": self.score,
            "family_scores": dict(sorted(self.family_scores.items())),
        }
        if include_id:
            value["evaluation_id"] = self.evaluation_id
        return value


def evaluate_policy(
    program: PolicyProgram, registry: MetaRegistry
) -> PolicyEvaluation:
    runtime = TypedPolicyRuntime(program)
    steps = tuple(runtime.act(event) for event in registry.events)
    by_event = {item.event.event_id: item for item in steps}
    outcomes = tuple(
        ProbeOutcome(
            probe=probe,
            observed=by_event[probe.event_id].action,
            passed=(
                by_event[probe.event_id].action.kind == probe.expected_kind
                and by_event[probe.event_id].action.payload
                == probe.expected_payload
            ),
            trace=by_event[probe.event_id],
        )
        for probe in registry.probes
    )
    families = sorted({item.evaluator_family for item in registry.probes})
    family_scores = {
        family: (
            sum(
                item.passed
                for item in outcomes
                if item.probe.evaluator_family == family
            )
            / sum(
                item.probe.evaluator_family == family for item in outcomes
            )
        )
        for family in families
    }
    return PolicyEvaluation(
        program=program,
        registry_id=registry.registry_id,
        outcomes=outcomes,
        family_scores=family_scores,
    )


@dataclass(frozen=True)
class NeutralTrace:
    trace_id: str
    query_channels: Tuple[Tuple[str, ...], ...]
    accesses: Tuple[TraceAccess, ...]
    intervention_write_ids: Tuple[str, ...]
    decision_sequence: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "query_channels": [list(item) for item in self.query_channels],
            "accesses": [item.as_dict() for item in self.accesses],
            "intervention_write_ids": list(self.intervention_write_ids),
            "decision_sequence": self.decision_sequence,
        }


@dataclass(frozen=True)
class NeutralContrast:
    contrast_id: str
    better: NeutralTrace
    worse: NeutralTrace
    return_delta: float

    def as_dict(self) -> Dict[str, Any]:
        return {
            "contrast_id": self.contrast_id,
            "better": self.better.as_dict(),
            "worse": self.worse.as_dict(),
            "return_delta": self.return_delta,
        }


@dataclass(frozen=True)
class NeutralContrastDossier:
    source_registry_id: str
    contrasts: Tuple[NeutralContrast, ...]
    removed_fields: Tuple[str, ...]
    allowed_information: Tuple[str, ...]

    @property
    def dossier_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "source_registry_id": self.source_registry_id,
            "contrasts": [item.as_dict() for item in self.contrasts],
            "removed_fields": list(self.removed_fields),
            "allowed_information": list(self.allowed_information),
        }
        if include_id:
            value["dossier_id"] = self.dossier_id
        return value


def _neutralize_step(step: RuntimeStep, trace_id: str) -> NeutralTrace:
    atoms: Dict[str, str] = {}
    records: Dict[str, str] = {}

    def atom(value: Any) -> str:
        key = repr(value)
        if key not in atoms:
            atoms[key] = "a%d" % len(atoms)
        return atoms[key]

    def record(value: str) -> str:
        if value not in records:
            records[value] = "r%d" % len(records)
        return records[value]

    channels = tuple(
        tuple(atom(value) for value in channel)
        for channel in step.query_channels
    )
    accesses = tuple(
        TraceAccess(
            mode=item.mode,
            record_id=record(item.record_id),
            cells=tuple(atom(value) for value in item.cells),
            created_at=item.created_at,
        )
        for item in step.accesses
    )
    intervention_ids = tuple(
        record(item) for item in step.intervention_write_ids
    )
    return NeutralTrace(
        trace_id=trace_id,
        query_channels=channels,
        accesses=accesses,
        intervention_write_ids=intervention_ids,
        decision_sequence=step.sequence,
    )


def build_neutral_contrast_dossier(
    registry: MetaRegistry,
) -> NeutralContrastDossier:
    evaluations = tuple(
        evaluate_policy(program, registry)
        for program in enumerate_policy_programs()
    )
    leader = max(
        evaluations,
        key=lambda item: (item.score, -item.program.complexity),
    )
    by_program = {item.program.program_id: item for item in evaluations}
    fields = (
        ("address_mode", "last_seen"),
        ("induction_mode", "memorize_examples"),
        ("selection_mode", "all_context"),
        ("update_mode", "detached_append"),
        ("retention_mode", "single_slot"),
    )
    contrasts = []
    for field, ablated_value in fields:
        ablated_program = replace(
            leader.program, **{field: ablated_value}
        )
        ablated = by_program[ablated_program.program_id]
        for better, worse in zip(leader.outcomes, ablated.outcomes):
            if better.passed and not worse.passed:
                contrast_id = "contrast-%03d" % len(contrasts)
                contrasts.append(
                    NeutralContrast(
                        contrast_id=contrast_id,
                        better=_neutralize_step(
                            better.trace, "%s-b" % contrast_id
                        ),
                        worse=_neutralize_step(
                            worse.trace, "%s-w" % contrast_id
                        ),
                        return_delta=1.0,
                    )
                )
    if not contrasts:
        raise ValueError("interventions produced no informative contrasts")
    return NeutralContrastDossier(
        source_registry_id=registry.registry_id,
        contrasts=tuple(contrasts),
        removed_fields=(
            "task and domain names",
            "event and probe identifiers",
            "expected and observed answers",
            "program component names",
            "evaluator-family labels",
        ),
        allowed_information=(
            "within-trace token equality",
            "record access topology",
            "read/write order and age",
            "paired terminal-return ordering",
        ),
    )


def _trace_features(trace: NeutralTrace) -> Mapping[str, bool]:
    access_cells = tuple(
        set(str(value) for value in item.cells) for item in trace.accesses
    )
    features: Dict[str, bool] = {}
    for index, channel in enumerate(trace.query_channels):
        features["channel_%d_overlap" % index] = any(
            set(channel).intersection(cells) for cells in access_cells
        )
    traversed_cells = tuple(
        set(str(value) for value in item.cells)
        for item in trace.accesses
        if item.mode == "read" and len(item.cells) >= 3
    )
    if not traversed_cells:
        features["access_subgraph_connected"] = len(access_cells) == 1
    elif len(traversed_cells) == 1:
        features["access_subgraph_connected"] = True
    else:
        ordered_cells = tuple(
            tuple(str(value) for value in item.cells)
            for item in trace.accesses
            if item.mode == "read" and len(item.cells) >= 3
        )
        endpoint_edges = {
            (left, right)
            for left, left_cells in enumerate(ordered_cells)
            for right, right_cells in enumerate(ordered_cells)
            if left != right
            and (
                left_cells[-1] == right_cells[0]
                or right_cells[-1] == left_cells[0]
            )
        }
        visited = {0}
        changed = True
        while changed:
            changed = False
            for left, right in endpoint_edges:
                if left in visited and right not in visited:
                    visited.add(right)
                    changed = True
                if right in visited and left not in visited:
                    visited.add(left)
                    changed = True
        features["access_subgraph_connected"] = len(visited) == len(
            ordered_cells
        )
    read_ids = {
        item.record_id
        for item in trace.accesses
        if item.mode in ("read", "resolve")
    }
    features["intervention_write_reused"] = bool(
        read_ids.intersection(trace.intervention_write_ids)
    )
    features["delayed_record_reused"] = any(
        item.mode == "read"
        and trace.decision_sequence - item.created_at >= 3
        for item in trace.accesses
    )
    return features


@dataclass(frozen=True)
class StructuralConcept:
    predicates: Tuple[str, ...]
    supporting_contrast_ids: Tuple[str, ...]
    contradicted_contrast_ids: Tuple[str, ...]
    predictive_accuracy: float
    falsifier: str

    @property
    def name(self) -> str:
        return "structural::" + "&".join(self.predicates)

    @property
    def concept_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "name": self.name,
            "predicates": list(self.predicates),
            "supporting_contrast_ids": list(self.supporting_contrast_ids),
            "contradicted_contrast_ids": list(self.contradicted_contrast_ids),
            "predictive_accuracy": self.predictive_accuracy,
            "falsifier": self.falsifier,
        }
        if include_id:
            value["concept_id"] = self.concept_id
        return value


@dataclass(frozen=True)
class ConceptBundle:
    dossier_id: str
    proposals: Tuple[StructuralConcept, ...]
    selected_concept_ids: Tuple[str, ...]
    covered_contrast_ids: Tuple[str, ...]
    uncovered_contrast_ids: Tuple[str, ...]
    proposer_ref: str

    @property
    def bundle_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def selected_predicates(self) -> Tuple[str, ...]:
        selected = set(self.selected_concept_ids)
        return tuple(
            sorted(
                {
                    predicate
                    for item in self.proposals
                    if item.concept_id in selected
                    for predicate in item.predicates
                }
            )
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "dossier_id": self.dossier_id,
            "proposals": [item.as_dict() for item in self.proposals],
            "selected_concept_ids": list(self.selected_concept_ids),
            "selected_predicates": list(self.selected_predicates),
            "covered_contrast_ids": list(self.covered_contrast_ids),
            "uncovered_contrast_ids": list(self.uncovered_contrast_ids),
            "proposer_ref": self.proposer_ref,
        }
        if include_id:
            value["bundle_id"] = self.bundle_id
        return value


def propose_structural_concepts(
    dossier: NeutralContrastDossier,
) -> ConceptBundle:
    feature_names = tuple(
        sorted(_trace_features(dossier.contrasts[0].better))
    )
    proposals = []
    for size in (1, 2):
        for predicates in itertools.combinations(feature_names, size):
            supports = []
            contradictions = []
            for contrast in dossier.contrasts:
                better = _trace_features(contrast.better)
                worse = _trace_features(contrast.worse)
                prediction = all(better[item] for item in predicates) and not all(
                    worse[item] for item in predicates
                )
                if prediction:
                    supports.append(contrast.contrast_id)
                else:
                    contradictions.append(contrast.contrast_id)
            if supports:
                proposals.append(
                    StructuralConcept(
                        predicates=predicates,
                        supporting_contrast_ids=tuple(supports),
                        contradicted_contrast_ids=tuple(contradictions),
                        predictive_accuracy=len(supports)
                        / len(dossier.contrasts),
                        falsifier=(
                            "a future higher-return trace lacks all predicates or "
                            "a lower-return trace uniquely satisfies them"
                        ),
                    )
                )
    proposals.sort(
        key=lambda item: (
            -item.predictive_accuracy,
            len(item.predicates),
            item.name,
        )
    )
    remaining = {item.contrast_id for item in dossier.contrasts}
    selected = []
    while remaining:
        candidate = max(
            proposals,
            key=lambda item: (
                len(remaining.intersection(item.supporting_contrast_ids)),
                item.predictive_accuracy,
                -len(item.predicates),
                item.name,
            ),
        )
        newly_covered = remaining.intersection(candidate.supporting_contrast_ids)
        if not newly_covered:
            break
        selected.append(candidate.concept_id)
        remaining.difference_update(newly_covered)
    covered = {
        contrast_id
        for item in proposals
        if item.concept_id in set(selected)
        for contrast_id in item.supporting_contrast_ids
    }
    return ConceptBundle(
        dossier_id=dossier.dossier_id,
        proposals=tuple(proposals[:12]),
        selected_concept_ids=tuple(selected),
        covered_contrast_ids=tuple(sorted(covered)),
        uncovered_contrast_ids=tuple(sorted(remaining)),
        proposer_ref="ontology-neutral-structural-proposer-v16",
    )


@dataclass(frozen=True)
class SynthesisTrial:
    concept_bundle_id: str
    development_registry_id: str
    requirements: Mapping[str, str]
    evaluated_program_ids: Tuple[str, ...]
    selected_program: PolicyProgram
    selected_evaluation: PolicyEvaluation
    unguided_baseline: PolicyEvaluation
    synthesizer_ref: str

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "concept_bundle_id": self.concept_bundle_id,
            "development_registry_id": self.development_registry_id,
            "requirements": dict(sorted(self.requirements.items())),
            "evaluated_program_ids": list(self.evaluated_program_ids),
            "selected_program": self.selected_program.as_dict(),
            "selected_evaluation": self.selected_evaluation.as_dict(),
            "unguided_baseline": self.unguided_baseline.as_dict(),
            "synthesizer_ref": self.synthesizer_ref,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def synthesize_policy_program(
    bundle: ConceptBundle,
    registry: MetaRegistry,
) -> SynthesisTrial:
    mapping = {
        "channel_0_overlap": ("address_mode", "equality_join"),
        "channel_1_overlap": (
            "induction_mode",
            "enumerate_typed_expressions",
        ),
        "access_subgraph_connected": (
            "selection_mode",
            "execution_slice",
        ),
        "intervention_write_reused": (
            "update_mode",
            "in_place_addressed",
        ),
        "delayed_record_reused": (
            "retention_mode",
            "persistent_map",
        ),
    }
    requirements = {
        field: value
        for predicate in bundle.selected_predicates
        if predicate in mapping
        for field, value in (mapping[predicate],)
    }
    programs = tuple(
        program
        for program in enumerate_policy_programs()
        if all(getattr(program, field) == value for field, value in requirements.items())
    )
    evaluations = tuple(evaluate_policy(program, registry) for program in programs)
    selected = max(
        evaluations,
        key=lambda item: (item.score, -item.program.complexity),
    )
    baseline_program = PolicyProgram(
        "last_seen",
        "memorize_examples",
        "all_context",
        "detached_append",
        "single_slot",
    )
    return SynthesisTrial(
        concept_bundle_id=bundle.bundle_id,
        development_registry_id=registry.registry_id,
        requirements=requirements,
        evaluated_program_ids=tuple(
            item.program.program_id for item in evaluations
        ),
        selected_program=selected.program,
        selected_evaluation=selected,
        unguided_baseline=evaluate_policy(baseline_program, registry),
        synthesizer_ref="typed-enumerative-policy-synthesizer-v16",
    )


@dataclass(frozen=True)
class SynthesizedCandidateFreeze:
    program: PolicyProgram
    concept_bundle_id: str
    synthesis_trial_id: str
    development_registry_id: str
    interpreter_source_digest: str
    freeze_stage: int

    @property
    def executable_digest(self) -> str:
        return content_digest(
            {
                "interpreter_source_digest": self.interpreter_source_digest,
                "program": self.program.as_dict(),
            }
        )

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "program": self.program.as_dict(),
            "concept_bundle_id": self.concept_bundle_id,
            "synthesis_trial_id": self.synthesis_trial_id,
            "development_registry_id": self.development_registry_id,
            "interpreter_source_digest": self.interpreter_source_digest,
            "executable_digest": self.executable_digest,
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_synthesized_candidate(
    trial: SynthesisTrial,
    *,
    interpreter_source_digest: str,
    freeze_stage: int = 4,
) -> SynthesizedCandidateFreeze:
    if trial.selected_evaluation.score != 1.0:
        raise ValueError("only a complete development program may be frozen")
    return SynthesizedCandidateFreeze(
        program=trial.selected_program,
        concept_bundle_id=trial.concept_bundle_id,
        synthesis_trial_id=trial.trial_id,
        development_registry_id=trial.development_registry_id,
        interpreter_source_digest=interpreter_source_digest,
        freeze_stage=freeze_stage,
    )


def make_numeric_task(
    *,
    task_ref: str,
    modulus: int,
    coefficients: Sequence[int],
    query: int,
    revised_constant: int,
    family: str,
) -> MetaTaskSpec:
    expression = TypedExpression(
        "polynomial_mod",
        {"modulus": modulus, "coefficients": list(coefficients)},
    )
    examples = tuple(
        MetaExample((value,), execute_expression(expression, (value,), ())[0])
        for value in range(len(coefficients) + 1)
    )
    before = execute_expression(expression, (query,), ())[0]
    revised = TypedExpression(
        "polynomial_mod",
        {
            "modulus": modulus,
            "coefficients": [revised_constant, *coefficients[1:]],
        },
    )
    after = execute_expression(revised, (query,), ())[0]
    return MetaTaskSpec(
        task_ref=task_ref,
        evaluator_family=family,
        examples=examples,
        query_inputs=(query,),
        expected_before=before,
        context=(),
        expected_relevant_row_ids=(),
        metadata={"field_0": modulus},
        update_address=("coefficient", 0),
        update_value=revised_constant,
        expected_after=after,
    )


def make_relational_task(
    *,
    task_ref: str,
    relations: Sequence[str],
    chain_count: int,
    revised_terminal: str,
    family: str,
) -> MetaTaskSpec:
    rows = []
    starts = []
    terminals = []
    chain_rows: Dict[int, Tuple[str, ...]] = {}
    for chain_index in range(chain_count):
        current = "%s-n-%d-0" % (task_ref, chain_index)
        starts.append(current)
        used = []
        for depth, relation in enumerate(relations):
            target = "%s-n-%d-%d" % (
                task_ref,
                chain_index,
                depth + 1,
            )
            row_id = "%s-r-%d-%d" % (task_ref, chain_index, depth)
            rows.append(KnowledgeRow(row_id, (current, relation, target)))
            used.append(row_id)
            current = target
        terminals.append(current)
        chain_rows[chain_index] = tuple(used)
    rows.extend(
        (
            KnowledgeRow(
                "%s-d-0" % task_ref,
                ("%s-x" % task_ref, relations[0], "%s-y" % task_ref),
            ),
            KnowledgeRow(
                "%s-d-1" % task_ref,
                ("%s-y" % task_ref, "noise", "%s-z" % task_ref),
            ),
        )
    )
    examples = tuple(
        MetaExample((starts[index],), terminals[index])
        for index in range(chain_count - 1)
    )
    query_index = chain_count - 1
    update_row = chain_rows[query_index][-1]
    return MetaTaskSpec(
        task_ref=task_ref,
        evaluator_family=family,
        examples=examples,
        query_inputs=(starts[query_index],),
        expected_before=terminals[query_index],
        context=tuple(rows),
        expected_relevant_row_ids=chain_rows[query_index],
        metadata={"field_0": "opaque"},
        update_address=("row", update_row, 2),
        update_value=revised_terminal,
        expected_after=revised_terminal,
    )


def build_development_registry() -> MetaRegistry:
    tasks = (
        make_numeric_task(
            task_ref="dev-a7",
            modulus=7,
            coefficients=(2, 3),
            query=5,
            revised_constant=4,
            family="development-numeric",
        ),
        make_relational_task(
            task_ref="dev-k2",
            relations=("u", "v"),
            chain_count=4,
            revised_terminal="dev-k2-revised",
            family="development-relational",
        ),
        make_numeric_task(
            task_ref="dev-c9",
            modulus=11,
            coefficients=(1, 4, 2),
            query=6,
            revised_constant=8,
            family="development-numeric",
        ),
        make_relational_task(
            task_ref="dev-m5",
            relations=("p", "q"),
            chain_count=4,
            revised_terminal="dev-m5-revised",
            family="development-relational",
        ),
    )
    return build_meta_registry(
        partition="development",
        tasks=tasks,
        authority_ref="development-intervention-authority-v16",
        exposure_stage=1,
    )


@dataclass(frozen=True)
class BlindTransferTrial:
    candidate_freeze: SynthesizedCandidateFreeze
    audit_commitment_id: str
    audit_materialization_id: str
    audit_registry_ids: Mapping[str, str]
    candidate_evaluations: Mapping[str, PolicyEvaluation]
    baseline_evaluations: Mapping[str, PolicyEvaluation]
    transfer_checks: Mapping[str, bool]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.transfer_checks.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "candidate_freeze": self.candidate_freeze.as_dict(),
            "audit_commitment_id": self.audit_commitment_id,
            "audit_materialization_id": self.audit_materialization_id,
            "audit_registry_ids": dict(sorted(self.audit_registry_ids.items())),
            "candidate_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.candidate_evaluations.items())
            },
            "baseline_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.baseline_evaluations.items())
            },
            "transfer_checks": dict(sorted(self.transfer_checks.items())),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def evaluate_blind_transfer(
    *,
    candidate_freeze: SynthesizedCandidateFreeze,
    audit_commitment_id: str,
    audit_materialization_id: str,
    registries: Mapping[str, MetaRegistry],
    materialization_stage: int,
) -> BlindTransferTrial:
    if candidate_freeze.freeze_stage >= materialization_stage:
        raise ValueError("audit data existed before the candidate freeze")
    candidate = {
        key: evaluate_policy(candidate_freeze.program, registry)
        for key, registry in registries.items()
    }
    baseline_program = PolicyProgram(
        "last_seen",
        "memorize_examples",
        "all_context",
        "detached_append",
        "single_slot",
    )
    baseline = {
        key: evaluate_policy(baseline_program, registry)
        for key, registry in registries.items()
    }
    registry_ids = {
        key: registry.registry_id for key, registry in registries.items()
    }
    checks = {
        "candidate_frozen_before_audit_materialization": (
            candidate_freeze.freeze_stage < materialization_stage
        ),
        "two_structurally_different_audit_families_are_present": (
            set(registries) == {"typed_numeric", "relational_composition"}
        ),
        "candidate_passes_every_hidden_probe": all(
            item.score == 1.0 for item in candidate.values()
        ),
        "candidate_passes_each_hidden_family": all(
            all(score == 1.0 for score in item.family_scores.values())
            for item in candidate.values()
        ),
        "weak_baseline_does_not_saturate_hidden_audit": all(
            item.score < 1.0 for item in baseline.values()
        ),
        "hidden_registry_identities_are_disjoint": (
            len(set(registry_ids.values())) == len(registry_ids)
            and candidate_freeze.development_registry_id
            not in set(registry_ids.values())
        ),
    }
    return BlindTransferTrial(
        candidate_freeze=candidate_freeze,
        audit_commitment_id=audit_commitment_id,
        audit_materialization_id=audit_materialization_id,
        audit_registry_ids=registry_ids,
        candidate_evaluations=candidate,
        baseline_evaluations=baseline,
        transfer_checks=checks,
        limitations=(
            "The proposer autonomously induces structural factors, but only from a fixed generic feature grammar.",
            "The policy AST is synthesized by the runtime, but its interpreter and typed primitive library are engineered infrastructure.",
            "Audit instances are runtime-blind and post-freeze; the benchmark family code is not hidden from the human code author.",
            "Both audit families are controlled symbolic microdomains, not external replication or a general cognitive-core test.",
        ),
    )
