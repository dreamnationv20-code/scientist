from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import (
    BlindTransferTrial,
    ConceptBundle,
    MetaActionKind,
    MetaRegistry,
    NeutralContrastDossier,
    PolicyEvaluation,
    SynthesisTrial,
    SynthesizedCandidateFreeze,
)
from scientist.domains.cognitive_core.blind_audit_authority_v16 import (
    HiddenAuditMaterialization,
)
from scientist.program.control_plane import AutonomousScientistControlPlane


AUTONOMOUS_SYNTHESIS_VERIFIER_REF = (
    "cognitive-core-autonomous-synthesis-independent-verifier-v16"
)


@dataclass(frozen=True)
class AutonomousSynthesisVerification:
    check_results: Mapping[str, bool]
    autonomy_criteria: Mapping[str, bool]
    independent_probe_match_rates: Mapping[str, float]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str = AUTONOMOUS_SYNTHESIS_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def bounded_autonomous_invention_demonstrated(self) -> bool:
        required = (
            "concept_induced_from_anonymized_contrasts",
            "candidate_ast_synthesized_by_runtime",
            "audit_instances_materialized_after_freeze",
            "two_hidden_structural_families_pass",
        )
        return all(self.autonomy_criteria[item] for item in required)

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "autonomy_criteria": dict(sorted(self.autonomy_criteria.items())),
            "bounded_autonomous_invention_demonstrated": (
                self.bounded_autonomous_invention_demonstrated
            ),
            "independent_probe_match_rates": dict(
                sorted(self.independent_probe_match_rates.items())
            ),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _independent_polynomial_value(
    coefficients: Sequence[int], modulus: int, argument: int
) -> int:
    return sum(
        int(coefficient) * pow(argument, index)
        for index, coefficient in enumerate(coefficients)
    ) % modulus


def _derive_numeric_coefficients(registry: MetaRegistry, task_ref: str) -> Tuple[int, ...]:
    task = next(item for item in registry.tasks if item.task_ref == task_ref)
    modulus = int(task.metadata["field_0"])
    for degree in range(3):
        matches = []
        import itertools

        for coefficients in itertools.product(range(modulus), repeat=degree + 1):
            if all(
                _independent_polynomial_value(
                    coefficients, modulus, int(example.inputs[0])
                )
                == int(example.output)
                for example in task.examples
            ):
                matches.append(coefficients)
        if len(matches) == 1:
            return matches[0]
    raise ValueError("independent verifier found no unique polynomial")


def _derive_relation_path(registry: MetaRegistry, task_ref: str) -> Tuple[Any, ...]:
    task = next(item for item in registry.tasks if item.task_ref == task_ref)
    relation_values = sorted(
        {row.cells[1] for row in task.context if len(row.cells) == 3}, key=str
    )
    import itertools

    for length in range(1, 4):
        matches = []
        for path in itertools.product(relation_values, repeat=length):
            valid = True
            for example in task.examples:
                current = example.inputs[0]
                for relation in path:
                    rows = [
                        row
                        for row in task.context
                        if row.cells[0] == current and row.cells[1] == relation
                    ]
                    if len(rows) != 1:
                        valid = False
                        break
                    current = rows[0].cells[2]
                if not valid or current != example.output:
                    valid = False
                    break
            if valid:
                matches.append(path)
        if len(matches) == 1:
            return matches[0]
    raise ValueError("independent verifier found no unique relation path")


def _independent_expected_actions(
    registry: MetaRegistry,
) -> Mapping[str, Tuple[MetaActionKind, Mapping[str, Any]]]:
    expected: Dict[str, Tuple[MetaActionKind, Mapping[str, Any]]] = {}
    for task in registry.tasks:
        if isinstance(task.metadata.get("field_0"), int):
            modulus = int(task.metadata["field_0"])
            coefficients = list(_derive_numeric_coefficients(registry, task.task_ref))
            before = _independent_polynomial_value(
                coefficients, modulus, int(task.query_inputs[0])
            )
            coefficients[int(task.update_address[1])] = int(task.update_value)
            after = _independent_polynomial_value(
                coefficients, modulus, int(task.query_inputs[0])
            )
            selected = []
        else:
            path = _derive_relation_path(registry, task.task_ref)
            rows = {row.row_id: list(row.cells) for row in task.context}

            def follow() -> Tuple[Any, list[str]]:
                current = task.query_inputs[0]
                used = []
                for relation in path:
                    matches = [
                        (row_id, cells)
                        for row_id, cells in rows.items()
                        if cells[0] == current and cells[1] == relation
                    ]
                    if len(matches) != 1:
                        raise ValueError("independent graph execution is ambiguous")
                    row_id, cells = matches[0]
                    used.append(row_id)
                    current = cells[2]
                return current, used

            before, selected = follow()
            rows[str(task.update_address[1])][int(task.update_address[2])] = (
                task.update_value
            )
            after, selected_after = follow()
            if selected_after != selected:
                raise ValueError("typed update unexpectedly changed dependency IDs")
        expected["%s-query-before" % task.task_ref] = (
            MetaActionKind.ANSWER,
            {"value": before},
        )
        expected["%s-select-before" % task.task_ref] = (
            MetaActionKind.SELECTION,
            {"row_ids": list(selected)},
        )
        expected["%s-update" % task.task_ref] = (
            MetaActionKind.UPDATED,
            {"accepted": True},
        )
        expected["%s-query-after" % task.task_ref] = (
            MetaActionKind.ANSWER,
            {"value": after},
        )
        expected["%s-select-after" % task.task_ref] = (
            MetaActionKind.SELECTION,
            {"row_ids": list(selected)},
        )
    return expected


def _independent_match_rate(
    registry: MetaRegistry, evaluation: PolicyEvaluation
) -> float:
    expected = _independent_expected_actions(registry)
    matched = 0
    for outcome in evaluation.outcomes:
        kind, payload = expected[outcome.probe.event_id]
        matched += outcome.observed.kind == kind and outcome.observed.payload == payload
    return matched / len(evaluation.outcomes)


def verify_autonomous_concept_synthesis(
    *,
    control: AutonomousScientistControlPlane,
    dossier: NeutralContrastDossier,
    concept_bundle: ConceptBundle,
    synthesis: SynthesisTrial,
    candidate_freeze: SynthesizedCandidateFreeze,
    materialization: HiddenAuditMaterialization,
    transfer: BlindTransferTrial,
    artifact_round_trip_checks: Mapping[str, bool],
) -> AutonomousSynthesisVerification:
    contrast_text = json.dumps(
        [item.as_dict() for item in dossier.contrasts], sort_keys=True
    ).lower()
    forbidden = (
        "affine",
        "modulus",
        "polynomial",
        "relation_path",
        "graph",
        "evaluator_family",
        "expected_before",
        "expected_after",
    )
    hidden_ids = set(transfer.audit_registry_ids.values())
    prefreeze_text = json.dumps(
        {
            "dossier": dossier.as_dict(),
            "concept_bundle": concept_bundle.as_dict(),
            "synthesis": synthesis.as_dict(),
            "candidate_freeze": candidate_freeze.as_dict(),
        },
        sort_keys=True,
    )
    match_rates = {
        key: _independent_match_rate(
            materialization.registries[key], evaluation
        )
        for key, evaluation in transfer.candidate_evaluations.items()
    }
    checks = {
        "all_content_addressed_artifacts_round_trip_exactly": all(
            artifact_round_trip_checks.values()
        ) and bool(artifact_round_trip_checks),
        "contrast_dossier_contains_only_anonymized_structural_information": (
            all(item not in contrast_text for item in forbidden)
            and all(
                value.startswith("a")
                for contrast in dossier.contrasts
                for trace in (contrast.better, contrast.worse)
                for channel in trace.query_channels
                for value in channel
            )
        ),
        "concepts_are_falsifiable_and_cover_every_observed_contrast": (
            bool(concept_bundle.proposals)
            and bool(concept_bundle.selected_concept_ids)
            and not concept_bundle.uncovered_contrast_ids
            and set(concept_bundle.covered_contrast_ids)
            == {item.contrast_id for item in dossier.contrasts}
            and all(item.falsifier for item in concept_bundle.proposals)
        ),
        "typed_candidate_is_a_runtime_selected_program_ast": (
            synthesis.selected_program.program_id
            in synthesis.evaluated_program_ids
            and synthesis.selected_evaluation.score == 1.0
            and synthesis.unguided_baseline.score < 1.0
            and candidate_freeze.program == synthesis.selected_program
            and candidate_freeze.synthesis_trial_id == synthesis.trial_id
        ),
        "candidate_identity_is_frozen_before_hidden_materialization": (
            candidate_freeze.freeze_stage < materialization.materialization_stage
            and materialization.candidate_freeze_id == candidate_freeze.freeze_id
            and transfer.candidate_freeze.freeze_id == candidate_freeze.freeze_id
        ),
        "no_hidden_registry_identity_appears_in_prefreeze_artifacts": all(
            item not in prefreeze_text for item in hidden_ids
        ),
        "two_disjoint_hidden_families_pass_completely": (
            transfer.passed
            and set(transfer.candidate_evaluations)
            == {"typed_numeric", "relational_composition"}
            and all(item.score == 1.0 for item in transfer.candidate_evaluations.values())
        ),
        "independent_reconstruction_matches_every_hidden_action": all(
            value == 1.0 for value in match_rates.values()
        ),
        "weak_control_fails_both_hidden_families": all(
            item.score < 1.0 for item in transfer.baseline_evaluations.values()
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    autonomy = {
        "concept_induced_from_anonymized_contrasts": checks[
            "contrast_dossier_contains_only_anonymized_structural_information"
        ]
        and checks["concepts_are_falsifiable_and_cover_every_observed_contrast"],
        "candidate_ast_synthesized_by_runtime": checks[
            "typed_candidate_is_a_runtime_selected_program_ast"
        ],
        "audit_instances_materialized_after_freeze": checks[
            "candidate_identity_is_frozen_before_hidden_materialization"
        ]
        and checks["no_hidden_registry_identity_appears_in_prefreeze_artifacts"],
        "two_hidden_structural_families_pass": checks[
            "two_disjoint_hidden_families_pass_completely"
        ],
        "audit_family_grammar_hidden_from_human_implementer": False,
        "external_replication_present": False,
        "general_cognitive_core_demonstrated": False,
    }
    return AutonomousSynthesisVerification(
        check_results=checks,
        autonomy_criteria=autonomy,
        independent_probe_match_rates=match_rates,
        supported_claim=(
            "The runtime autonomously induced a falsifiable structural factor "
            "bundle from anonymized contrasts, synthesized a typed policy AST, "
            "and transferred it after freezing to two controlled hidden families."
        ),
        rejected_claims=(
            "the system has unrestricted semantic hypothesis invention",
            "the benchmark is hidden from the human implementer",
            "a general cognitive core has been demonstrated",
            "external scientific replication has occurred",
        ),
        limitations=(
            "Structural predicates come from a fixed ontology-neutral feature grammar.",
            "The generic interpreter and typed primitive library remain engineered infrastructure.",
            "The two audit families are symbolic and generated inside this repository.",
        ),
    )
