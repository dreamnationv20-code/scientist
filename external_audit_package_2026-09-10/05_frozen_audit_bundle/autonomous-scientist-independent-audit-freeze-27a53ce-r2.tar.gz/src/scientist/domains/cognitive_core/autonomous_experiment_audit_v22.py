from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import MetaExample
from scientist.domains.cognitive_core.autonomous_experiment_v22 import (
    AUTONOMOUS_EXPERIMENT_VERSION,
    ExperimentPolicyFreeze,
    ExperimentTask,
)
from scientist.domains.cognitive_core.primitive_invention_v21 import (
    AffineBranch,
    InventedPrimitive,
    PredicateProgram,
)


EXPERIMENT_AUDIT_AUTHORITY_REF = "sealed-autonomous-experiment-audit-v22"


@dataclass(frozen=True)
class ExperimentAuditCommitment:
    seeds: Tuple[int, ...]
    tasks_per_family: int
    sealed_spec_digest: str

    @property
    def commitment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_EXPERIMENT_VERSION,
            "seeds": list(self.seeds),
            "tasks_per_family": self.tasks_per_family,
            "sealed_spec_digest": self.sealed_spec_digest,
            "authority_ref": EXPERIMENT_AUDIT_AUTHORITY_REF,
        }
        if include_id:
            value["commitment_id"] = self.commitment_id
        return value


@dataclass(frozen=True)
class ExperimentAuditMaterialization:
    commitment: ExperimentAuditCommitment
    policy_freeze_id: str
    tasks: Tuple[ExperimentTask, ...]
    materialization_stage: int

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_EXPERIMENT_VERSION,
            "commitment": self.commitment.as_dict(),
            "policy_freeze_id": self.policy_freeze_id,
            "candidate_tasks": [item.candidate_view() for item in self.tasks],
            "evaluator_digests": [
                content_digest(
                    {
                        "task_id": item.task_id,
                        "target": item.evaluator_target.as_dict(),
                        "outputs": dict(item.oracle_outputs),
                        "family": item.evaluator_family,
                    }
                )
                for item in self.tasks
            ],
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


class AutonomousExperimentAuditAuthority:
    def __init__(
        self,
        seeds: Tuple[int, ...] = (2203, 2221, 2237, 2267, 2281),
        tasks_per_family: int = 5,
    ) -> None:
        if len(seeds) < 5 or tasks_per_family < 4:
            raise ValueError("experiment audit requires five seeds and four tasks per family")
        self._seeds = seeds
        self._tasks_per_family = tasks_per_family
        self._sealed_spec = {
            "seeds": seeds,
            "tasks_per_family": tasks_per_family,
            "domain": tuple(range(16)),
            "initial_inputs": (0, 1, 14, 15),
            "query_budget": 4,
            "authority": EXPERIMENT_AUDIT_AUTHORITY_REF,
        }
        self.commitment = ExperimentAuditCommitment(
            seeds, tasks_per_family, content_digest(self._sealed_spec)
        )
        self._materialized = False

    @staticmethod
    def _task(seed: int, index: int, family: str) -> ExperimentTask:
        rng = random.Random(seed * 1013 + index * 929 + (family == "ordered"))
        domain = tuple(range(16))
        true_branch = AffineBranch(rng.choice((-3, -2, 2, 3)), rng.randint(-5, 5))
        false_branch = AffineBranch(rng.choice((-4, -1, 1, 4)), rng.randint(-5, 5))
        if family == "alternating":
            predicate = PredicateProgram("remainder_class", (2, rng.randint(0, 1)))
        else:
            predicate = PredicateProgram("ordered_cut", (rng.randint(5, 11),))
        target = InventedPrimitive(
            "guarded_dispatch", predicate, true_branch, false_branch
        )
        outputs = {value: target.evaluate(value) for value in domain}
        initial = tuple(
            MetaExample((value,), outputs[value]) for value in (0, 1, 14, 15)
        )
        return ExperimentTask(
            content_digest(
                {
                    "authority": EXPERIMENT_AUDIT_AUTHORITY_REF,
                    "seed": seed,
                    "index": index,
                    "family": family,
                }
            ),
            initial,
            domain,
            outputs,
            target,
            family,
            4,
        )

    def materialize(
        self, policy_freeze: ExperimentPolicyFreeze, *, materialization_stage: int = 5
    ) -> ExperimentAuditMaterialization:
        if self._materialized:
            raise ValueError("experiment audit may be materialized only once")
        if policy_freeze.freeze_stage >= materialization_stage:
            raise ValueError("experiment policy did not freeze before materialization")
        tasks = tuple(
            self._task(seed, index, family)
            for seed in self._seeds
            for family in ("alternating", "ordered")
            for index in range(self._tasks_per_family)
        )
        self._materialized = True
        return ExperimentAuditMaterialization(
            self.commitment, policy_freeze.freeze_id, tasks, materialization_stage
        )

    def verify(
        self,
        materialization: ExperimentAuditMaterialization,
        policy_freeze: ExperimentPolicyFreeze,
    ) -> bool:
        return (
            materialization.commitment == self.commitment
            and materialization.policy_freeze_id == policy_freeze.freeze_id
            and self.commitment.sealed_spec_digest == content_digest(self._sealed_spec)
        )


def build_experiment_development_tasks() -> Tuple[ExperimentTask, ...]:
    return tuple(
        AutonomousExperimentAuditAuthority._task(2197, index, family)
        for family in ("alternating", "ordered")
        for index in range(2)
    )
