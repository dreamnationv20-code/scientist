from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import MetaExample
from scientist.domains.cognitive_core.primitive_invention_v21 import (
    InventedPrimitive,
    enumerate_fitting_primitives,
)


AUTONOMOUS_EXPERIMENT_VERSION = "cognitive-core-autonomous-experiment-v22"


@dataclass(frozen=True)
class ExperimentTask:
    task_id: str
    initial_examples: Tuple[MetaExample, ...]
    domain: Tuple[int, ...]
    oracle_outputs: Mapping[int, int]
    evaluator_target: InventedPrimitive
    evaluator_family: str
    query_budget: int = 4

    def candidate_view(self) -> Dict[str, object]:
        return {
            "task_id": self.task_id,
            "initial_examples": [item.as_dict() for item in self.initial_examples],
            "domain": list(self.domain),
            "query_budget": self.query_budget,
        }

    def query(self, value: int) -> int:
        if value not in self.domain:
            raise ValueError("experiment is outside the registered domain")
        return int(self.oracle_outputs[value])


@dataclass(frozen=True)
class ExperimentDecision:
    query_input: int
    expected_information_bits: float
    worst_case_survivors: int
    version_space_before: int
    observed_output: int
    version_space_after: int

    def as_dict(self) -> Dict[str, object]:
        return {
            "query_input": self.query_input,
            "expected_information_bits": self.expected_information_bits,
            "worst_case_survivors": self.worst_case_survivors,
            "version_space_before": self.version_space_before,
            "observed_output": self.observed_output,
            "version_space_after": self.version_space_after,
        }


@dataclass(frozen=True)
class AutonomousExperimentTrace:
    task_id: str
    initial_version_space: int
    decisions: Tuple[ExperimentDecision, ...]
    final_version_space: int
    selected: InventedPrimitive | None
    stopped_reason: str

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_EXPERIMENT_VERSION,
            "task_id": self.task_id,
            "initial_version_space": self.initial_version_space,
            "decisions": [item.as_dict() for item in self.decisions],
            "final_version_space": self.final_version_space,
            "selected": None if self.selected is None else self.selected.as_dict(),
            "stopped_reason": self.stopped_reason,
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


def _output_buckets(
    hypotheses: Sequence[InventedPrimitive], value: int
) -> Mapping[int, Tuple[InventedPrimitive, ...]]:
    buckets: Dict[int, list[InventedPrimitive]] = {}
    for hypothesis in hypotheses:
        buckets.setdefault(hypothesis.evaluate(value), []).append(hypothesis)
    return {key: tuple(items) for key, items in buckets.items()}


def select_information_experiment(
    hypotheses: Sequence[InventedPrimitive],
    domain: Sequence[int],
    observed_inputs: Sequence[int],
) -> Tuple[int, float, int] | None:
    """Choose a legal query by maximum predictive entropy before seeing its outcome."""

    if len(hypotheses) <= 1:
        return None
    observed = set(observed_inputs)
    candidates = []
    for value in sorted(set(domain).difference(observed)):
        buckets = _output_buckets(hypotheses, value)
        if len(buckets) <= 1:
            continue
        total = len(hypotheses)
        entropy = -sum(
            (len(items) / total) * math.log2(len(items) / total)
            for items in buckets.values()
        )
        candidates.append(
            (entropy, -max(len(items) for items in buckets.values()), -value, value)
        )
    if not candidates:
        return None
    entropy, negative_worst, _, value = max(candidates)
    return value, entropy, -negative_worst


def run_autonomous_experiment(task: ExperimentTask) -> AutonomousExperimentTrace:
    hypotheses = enumerate_fitting_primitives(task.initial_examples, task.domain)
    initial = len(hypotheses)
    observed_inputs = [int(item.inputs[0]) for item in task.initial_examples]
    decisions = []
    for _ in range(task.query_budget):
        choice = select_information_experiment(hypotheses, task.domain, observed_inputs)
        if choice is None:
            break
        value, information, worst = choice
        observed = task.query(value)
        before = len(hypotheses)
        hypotheses = tuple(
            item for item in hypotheses if item.evaluate(value) == observed
        )
        observed_inputs.append(value)
        decisions.append(
            ExperimentDecision(
                value,
                information,
                worst,
                before,
                observed,
                len(hypotheses),
            )
        )
        if len(hypotheses) <= 1:
            break
    selected = hypotheses[0] if len(hypotheses) == 1 else None
    reason = (
        "identified"
        if selected is not None
        else "budget_exhausted"
        if len(decisions) >= task.query_budget
        else "observationally_indistinguishable"
    )
    return AutonomousExperimentTrace(
        task.task_id, initial, tuple(decisions), len(hypotheses), selected, reason
    )


@dataclass(frozen=True)
class ExperimentPolicyFreeze:
    source_primitive_freeze_id: str
    selection_rule: str
    policy_source_digest: str
    development_trace_ids: Tuple[str, ...]
    freeze_stage: int = 4

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_EXPERIMENT_VERSION,
            "source_primitive_freeze_id": self.source_primitive_freeze_id,
            "selection_rule": self.selection_rule,
            "policy_source_digest": self.policy_source_digest,
            "development_trace_ids": list(self.development_trace_ids),
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_experiment_policy(
    traces: Mapping[str, AutonomousExperimentTrace],
    *,
    source_primitive_freeze_id: str,
    policy_source_digest: str,
) -> ExperimentPolicyFreeze:
    if not traces or any(
        item.initial_version_space <= 1 or item.selected is None for item in traces.values()
    ):
        raise ValueError("experiment policy development did not resolve real ambiguity")
    return ExperimentPolicyFreeze(
        source_primitive_freeze_id,
        "maximum_predictive_entropy_then_minimum_worst_case_then_lowest_input",
        policy_source_digest,
        tuple(sorted(item.trace_id for item in traces.values())),
    )


@dataclass(frozen=True)
class AutonomousExperimentTrial:
    traces: Mapping[str, AutonomousExperimentTrace]
    identification_scores: Mapping[str, float]
    no_experiment_scores: Mapping[str, float]
    family_scores: Mapping[str, float]
    mean_queries: float
    query_sequence_count: int
    checks: Mapping[str, bool]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_EXPERIMENT_VERSION,
            "traces": {key: item.as_dict() for key, item in sorted(self.traces.items())},
            "identification_scores": dict(sorted(self.identification_scores.items())),
            "no_experiment_scores": dict(sorted(self.no_experiment_scores.items())),
            "family_scores": dict(sorted(self.family_scores.items())),
            "mean_queries": self.mean_queries,
            "query_sequence_count": self.query_sequence_count,
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def _same_behavior(left: InventedPrimitive, right: InventedPrimitive, domain: Sequence[int]) -> bool:
    return all(left.evaluate(value) == right.evaluate(value) for value in domain)


def run_experiment_trial(tasks: Sequence[ExperimentTask]) -> AutonomousExperimentTrial:
    traces = {task.task_id: run_autonomous_experiment(task) for task in tasks}
    scores = {
        task.task_id: float(
            traces[task.task_id].selected is not None
            and _same_behavior(
                traces[task.task_id].selected, task.evaluator_target, task.domain
            )
        )
        for task in tasks
    }
    no_experiment = {
        task.task_id: float(
            len(enumerate_fitting_primitives(task.initial_examples, task.domain)) == 1
        )
        for task in tasks
    }
    families = sorted({task.evaluator_family for task in tasks})
    family_scores = {
        family: sum(scores[item.task_id] for item in tasks if item.evaluator_family == family)
        / sum(item.evaluator_family == family for item in tasks)
        for family in families
    }
    mean_queries = sum(len(item.decisions) for item in traces.values()) / len(traces)
    sequences = {
        tuple(decision.query_input for decision in item.decisions)
        for item in traces.values()
    }
    checks = {
        "all_tasks_begin_with_real_predictive_ambiguity": all(
            item.initial_version_space > 1 for item in traces.values()
        ),
        "candidate_selects_every_query_before_observing_its_result": all(
            all(decision.expected_information_bits > 0 for decision in item.decisions)
            for item in traces.values()
        ),
        "active_policy_identifies_hidden_mechanism": min(family_scores.values()) >= 0.95,
        "query_ablation_fails": (
            sum(no_experiment.values()) / len(no_experiment) <= 0.05
        ),
        "policy_is_not_one_fixed_query_sequence": len(sequences) >= 2,
        "query_budget_is_respected": all(
            len(traces[task.task_id].decisions) <= task.query_budget for task in tasks
        ),
    }
    return AutonomousExperimentTrial(
        traces,
        scores,
        no_experiment,
        family_scores,
        mean_queries,
        len(sequences),
        checks,
    )
