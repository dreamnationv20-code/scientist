from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_experiment_audit_v22 import (
    ExperimentAuditMaterialization,
)
from scientist.domains.cognitive_core.autonomous_experiment_v22 import (
    AutonomousExperimentTrace,
    AutonomousExperimentTrial,
    ExperimentPolicyFreeze,
    run_autonomous_experiment,
    select_information_experiment,
)


EXPERIMENT_VERIFIER_REF = "autonomous-experiment-independent-verifier-v22"


@dataclass(frozen=True)
class AutonomousExperimentVerification:
    checks: Mapping[str, bool]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "verifier_ref": EXPERIMENT_VERIFIER_REF,
            "checks": dict(sorted(self.checks.items())),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_autonomous_experiments(
    *,
    development_traces: Mapping[str, AutonomousExperimentTrace],
    policy_freeze: ExperimentPolicyFreeze,
    materialization: ExperimentAuditMaterialization,
    trial: AutonomousExperimentTrial,
    source_primitive_freeze_id: str,
    artifact_round_trips: Mapping[str, bool],
) -> AutonomousExperimentVerification:
    candidate_text = json.dumps(
        [task.candidate_view() for task in materialization.tasks], sort_keys=True
    ).lower()
    policy_source = inspect.getsource(select_information_experiment).lower()
    runner_source = inspect.getsource(run_autonomous_experiment).lower()
    checks = {
        "development_requires_and_resolves_ambiguity": bool(development_traces)
        and all(
            item.initial_version_space > 1 and item.selected is not None
            for item in development_traces.values()
        ),
        "policy_reuses_frozen_primitive_language": (
            policy_freeze.source_primitive_freeze_id == source_primitive_freeze_id
        ),
        "evaluator_target_is_absent_from_candidate_view": all(
            token not in candidate_text
            for token in ("evaluator_target", "oracle_outputs", "evaluator_family")
        ),
        "query_selection_cannot_read_current_oracle_answer": (
            "oracle" not in policy_source and "query(" not in policy_source
        ),
        "oracle_is_called_only_after_policy_choice": (
            runner_source.index("select_information_experiment")
            < runner_source.index("task.query(")
        ),
        "sealed_audit_occurs_after_policy_freeze": (
            materialization.policy_freeze_id == policy_freeze.freeze_id
            and policy_freeze.freeze_stage < materialization.materialization_stage
        ),
        "fresh_active_identification_and_ablation_pass": trial.passed,
        "artifacts_round_trip_exactly": bool(artifact_round_trips)
        and all(artifact_round_trips.values()),
    }
    return AutonomousExperimentVerification(
        checks,
        (
            "Given multiple behaviorally consistent invented programs, the candidate "
            "autonomously selected legal maximum-information interventions and identified "
            "the hidden mechanism within a frozen query budget on fresh tasks."
        ),
        (
            "the system autonomously invents arbitrary physical experiments",
            "the query language is open-ended",
            "a general cognitive core is established",
        ),
        (
            "The legal intervention domain and scalar observation channel are supplied.",
            "Experiment choice is exact version-space information gain in a bounded program class.",
        ),
    )
