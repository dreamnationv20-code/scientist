from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Callable, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import MetaExample
from scientist.domains.cognitive_core.autonomous_experiment_v22 import (
    ExperimentDecision,
    select_information_experiment,
)
from scientist.domains.cognitive_core.naturalistic_transfer_v24 import (
    PythonTestCase,
    execute_python_function,
    render_python_program,
    score_python_source,
)
from scientist.domains.cognitive_core.primitive_invention_v21 import (
    InventedPrimitive,
    enumerate_fitting_primitives,
)
from scientist.domains.cognitive_core.representation_revision_v23 import (
    ObservedSequence,
    RepresentationTask,
    RevisedRepresentation,
    RepresentationRevisionTrace,
    revise_representation,
    score_representation,
    stateless_score,
)


AUTONOMOUS_SCIENTIFIC_CYCLE_VERSION = "cognitive-core-autonomous-scientific-cycle-v25"


class CycleStage(str, Enum):
    REGISTER_GOAL = "register_goal"
    OBSERVE = "observe"
    BASELINE = "baseline"
    DIAGNOSE = "diagnose"
    HYPOTHESIZE = "hypothesize"
    DESIGN_EXPERIMENT = "design_experiment"
    OBSERVE_EXPERIMENT = "observe_experiment"
    REVISE_REPRESENTATION = "revise_representation"
    FREEZE_CANDIDATE = "freeze_candidate"
    PREDICT = "predict"
    PROSPECTIVE_AUDIT = "prospective_audit"
    ADOPT = "adopt"
    PARK = "park"


@dataclass(frozen=True)
class CycleEvent:
    sequence: int
    stage: CycleStage
    rationale: str
    evidence: Mapping[str, object]

    @property
    def event_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "sequence": self.sequence,
            "stage": self.stage.value,
            "rationale": self.rationale,
            "evidence": dict(self.evidence),
        }
        if include_id:
            value["event_id"] = self.event_id
        return value


@dataclass(frozen=True)
class PythonProblemView:
    problem_id: str
    source: str
    initial_tests: Tuple[PythonTestCase, ...]
    query_domain: Tuple[int, ...]
    query_budget: int

    def as_dict(self) -> Dict[str, object]:
        return {
            "problem_id": self.problem_id,
            "source": self.source,
            "initial_tests": [item.as_dict() for item in self.initial_tests],
            "query_domain": list(self.query_domain),
            "query_budget": self.query_budget,
        }


@dataclass(frozen=True)
class SealedPythonScienceProblem:
    view: PythonProblemView
    oracle_outputs: Mapping[int, int]
    hidden_tests: Tuple[PythonTestCase, ...]
    evaluator_family: str
    expected_disposition: str = "adopt"

    def query(self, value: int) -> int:
        if value not in self.view.query_domain:
            raise ValueError("query is outside candidate-visible intervention domain")
        return int(self.oracle_outputs[value])


@dataclass(frozen=True)
class TemporalProblemView:
    problem_id: str
    visible_sequences: Tuple[ObservedSequence, ...]

    def as_dict(self) -> Dict[str, object]:
        return {
            "problem_id": self.problem_id,
            "visible_sequences": [item.as_dict() for item in self.visible_sequences],
        }


@dataclass(frozen=True)
class SealedTemporalScienceProblem:
    view: TemporalProblemView
    hidden_sequences: Tuple[ObservedSequence, ...]
    evaluator_family: str
    expected_disposition: str = "adopt"


@dataclass(frozen=True)
class ScientificCycleCandidate:
    problem_id: str
    interface_kind: str
    events: Tuple[CycleEvent, ...]
    program: InventedPrimitive | None = None
    repaired_source: str | None = None
    representation: RevisedRepresentation | None = None
    representation_trace: RepresentationRevisionTrace | None = None

    @property
    def candidate_freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_SCIENTIFIC_CYCLE_VERSION,
            "problem_id": self.problem_id,
            "interface_kind": self.interface_kind,
            "events": [item.as_dict() for item in self.events],
            "program": None if self.program is None else self.program.as_dict(),
            "repaired_source": self.repaired_source,
            "representation": (
                None if self.representation is None else self.representation.as_dict()
            ),
            "representation_trace": (
                None
                if self.representation_trace is None
                else self.representation_trace.as_dict()
            ),
        }
        if include_id:
            value["candidate_freeze_id"] = self.candidate_freeze_id
        return value


def _append(
    events: list[CycleEvent], stage: CycleStage, rationale: str, evidence: Mapping[str, object]
) -> None:
    events.append(CycleEvent(len(events), stage, rationale, evidence))


def produce_python_cycle_candidate(
    view: PythonProblemView,
    query: Callable[[int], int],
) -> ScientificCycleCandidate:
    """Run the candidate-controlled part of a full scientific cycle.

    This function has no hidden-test, evaluator-family, target-program, or adoption
    interface. Experimental outcomes can enter only through queries selected first.
    """

    events: list[CycleEvent] = []
    _append(events, CycleStage.REGISTER_GOAL, "repair executable behavior from evidence", {"problem_id": view.problem_id})
    _append(events, CycleStage.OBSERVE, "ingest raw Python and executable examples", {"example_count": len(view.initial_tests), "source_digest": content_digest(view.source)})
    original_visible = score_python_source(view.source, view.initial_tests)
    _append(events, CycleStage.BASELINE, "measure current implementation before changing it", {"visible_score": original_visible})
    examples = tuple(MetaExample((item.input_value,), item.expected_output) for item in view.initial_tests)
    hypotheses = enumerate_fitting_primitives(examples, view.query_domain)
    _append(
        events,
        CycleStage.DIAGNOSE,
        "current examples underdetermine the executable mechanism",
        {"version_space": len(hypotheses), "needs_intervention": len(hypotheses) != 1},
    )
    _append(events, CycleStage.HYPOTHESIZE, "compose all behaviorally consistent typed programs", {"hypothesis_count": len(hypotheses)})
    observed_inputs = [item.input_value for item in view.initial_tests]
    decisions = []
    for _ in range(view.query_budget):
        choice = select_information_experiment(hypotheses, view.query_domain, observed_inputs)
        if choice is None:
            break
        value, information, worst = choice
        _append(
            events,
            CycleStage.DESIGN_EXPERIMENT,
            "choose the intervention with maximum predictive information",
            {"query_input": value, "expected_information_bits": information, "worst_case_survivors": worst},
        )
        observed = query(value)
        before = len(hypotheses)
        hypotheses = tuple(item for item in hypotheses if item.evaluate(value) == observed)
        decisions.append(ExperimentDecision(value, information, worst, before, observed, len(hypotheses)))
        observed_inputs.append(value)
        _append(
            events,
            CycleStage.OBSERVE_EXPERIMENT,
            "update the version space only after observing the chosen intervention",
            {"query_input": value, "observed_output": observed, "survivors": len(hypotheses)},
        )
        if len(hypotheses) <= 1:
            break
    program = hypotheses[0] if len(hypotheses) == 1 else None
    repaired = None
    if program is not None:
        try:
            repaired = render_python_program(view.source, program)
        except (KeyError, SyntaxError, TypeError, ValueError):
            program = None
    _append(
        events,
        CycleStage.REVISE_REPRESENTATION,
        "extend the Python return language with the identified control-flow primitive",
        {"extension_created": program is not None, "program_id": None if program is None else program.program_id},
    )
    _append(
        events,
        CycleStage.FREEZE_CANDIDATE,
        "freeze code before any prospective audit is exposed",
        {"candidate_source_digest": None if repaired is None else content_digest(repaired), "experiment_count": len(decisions)},
    )
    _append(
        events,
        CycleStage.PREDICT,
        "predict that the frozen repair will generalize beyond queried inputs",
        {"predicted_hidden_floor": 0.95 if repaired is not None else 0.0},
    )
    return ScientificCycleCandidate(view.problem_id, "python", tuple(events), program, repaired)


def produce_temporal_cycle_candidate(view: TemporalProblemView) -> ScientificCycleCandidate:
    events: list[CycleEvent] = []
    _append(events, CycleStage.REGISTER_GOAL, "explain contradictory sequential behavior", {"problem_id": view.problem_id})
    _append(events, CycleStage.OBSERVE, "ingest raw event sequences", {"sequence_count": len(view.visible_sequences)})
    surrogate = RepresentationTask(view.problem_id, view.visible_sequences, (), "candidate_unlabeled")
    trace = revise_representation(surrogate)
    _append(events, CycleStage.BASELINE, "measure the best stateless representation", {"training_ceiling": trace.dossier.stateless_training_ceiling})
    _append(events, CycleStage.DIAGNOSE, "same visible input has incompatible outcomes", {"dossier_id": trace.dossier.dossier_id, "revision_required": trace.dossier.revision_required})
    _append(events, CycleStage.HYPOTHESIZE, "compose candidate state variables from observable history", {"fitting_representations": trace.fitting_representations})
    _append(events, CycleStage.REVISE_REPRESENTATION, "adopt the unique minimum-complexity history representation", {"representation_id": None if trace.selected is None else trace.selected.representation_id})
    _append(events, CycleStage.FREEZE_CANDIDATE, "freeze representation before prospective suffixes are exposed", {"candidate_present": trace.selected is not None})
    _append(events, CycleStage.PREDICT, "predict hidden sequential outcomes from the new state", {"predicted_hidden_floor": 0.95 if trace.selected is not None else 0.0})
    return ScientificCycleCandidate(
        view.problem_id,
        "temporal",
        tuple(events),
        representation=trace.selected,
        representation_trace=trace,
    )


@dataclass(frozen=True)
class ScientificCycleResult:
    candidate: ScientificCycleCandidate
    events: Tuple[CycleEvent, ...]
    baseline_score: float
    candidate_score: float
    improvement: float
    disposition: str
    evaluator_family: str

    @property
    def cycle_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_SCIENTIFIC_CYCLE_VERSION,
            "candidate": self.candidate.as_dict(),
            "events": [item.as_dict() for item in self.events],
            "baseline_score": self.baseline_score,
            "candidate_score": self.candidate_score,
            "improvement": self.improvement,
            "disposition": self.disposition,
            "evaluator_family": self.evaluator_family,
        }
        if include_id:
            value["cycle_id"] = self.cycle_id
        return value


def audit_python_cycle(
    candidate: ScientificCycleCandidate, problem: SealedPythonScienceProblem
) -> ScientificCycleResult:
    if candidate.problem_id != problem.view.problem_id or candidate.interface_kind != "python":
        raise ValueError("candidate does not belong to sealed Python problem")
    baseline = score_python_source(problem.view.source, problem.hidden_tests)
    score = score_python_source(candidate.repaired_source, problem.hidden_tests)
    improvement = score - baseline
    adopt = candidate.repaired_source is not None and score >= 0.95 and improvement >= 0.40
    events = list(candidate.events)
    _append(events, CycleStage.PROSPECTIVE_AUDIT, "open sealed tests only after candidate freeze", {"hidden_score": score, "baseline_score": baseline, "improvement": improvement})
    _append(events, CycleStage.ADOPT if adopt else CycleStage.PARK, "apply the preregistered conservative adoption rule", {"disposition": "adopt" if adopt else "park", "required_score": 0.95, "required_improvement": 0.40})
    return ScientificCycleResult(candidate, tuple(events), baseline, score, improvement, "adopt" if adopt else "park", problem.evaluator_family)


def audit_temporal_cycle(
    candidate: ScientificCycleCandidate, problem: SealedTemporalScienceProblem
) -> ScientificCycleResult:
    if candidate.problem_id != problem.view.problem_id or candidate.interface_kind != "temporal":
        raise ValueError("candidate does not belong to sealed temporal problem")
    baseline = stateless_score(problem.view.visible_sequences, problem.hidden_sequences)
    score = score_representation(candidate.representation, problem.hidden_sequences)
    improvement = score - baseline
    adopt = candidate.representation is not None and score >= 0.95 and improvement >= 0.25
    events = list(candidate.events)
    _append(events, CycleStage.PROSPECTIVE_AUDIT, "open sealed suffixes only after representation freeze", {"hidden_score": score, "baseline_score": baseline, "improvement": improvement})
    _append(events, CycleStage.ADOPT if adopt else CycleStage.PARK, "apply the preregistered conservative adoption rule", {"disposition": "adopt" if adopt else "park", "required_score": 0.95, "required_improvement": 0.25})
    return ScientificCycleResult(candidate, tuple(events), baseline, score, improvement, "adopt" if adopt else "park", problem.evaluator_family)


@dataclass(frozen=True)
class AutonomousCycleCoreFreeze:
    source_freeze_ids: Mapping[str, str]
    loop_source_digest: str
    development_cycle_ids: Tuple[str, ...]
    adoption_rules: Mapping[str, object]
    freeze_stage: int = 4

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_SCIENTIFIC_CYCLE_VERSION,
            "source_freeze_ids": dict(sorted(self.source_freeze_ids.items())),
            "loop_source_digest": self.loop_source_digest,
            "development_cycle_ids": list(self.development_cycle_ids),
            "adoption_rules": dict(self.adoption_rules),
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_autonomous_cycle_core(
    results: Sequence[ScientificCycleResult],
    *,
    source_freeze_ids: Mapping[str, str],
    loop_source_digest: str,
) -> AutonomousCycleCoreFreeze:
    if not results or not all(item.disposition == "adopt" for item in results):
        raise ValueError("cycle core development must adopt every positive development problem")
    return AutonomousCycleCoreFreeze(
        dict(source_freeze_ids),
        loop_source_digest,
        tuple(sorted(item.cycle_id for item in results)),
        {
            "python": {"score": 0.95, "improvement": 0.40},
            "temporal": {"score": 0.95, "improvement": 0.25},
        },
    )


@dataclass(frozen=True)
class AutonomousCycleTrial:
    results: Mapping[str, ScientificCycleResult]
    family_scores: Mapping[str, float]
    positive_adoption_rate: float
    negative_parking_rate: float
    mean_improvement: float
    checks: Mapping[str, bool]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": AUTONOMOUS_SCIENTIFIC_CYCLE_VERSION,
            "results": {key: item.as_dict() for key, item in sorted(self.results.items())},
            "family_scores": dict(sorted(self.family_scores.items())),
            "positive_adoption_rate": self.positive_adoption_rate,
            "negative_parking_rate": self.negative_parking_rate,
            "mean_improvement": self.mean_improvement,
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def run_autonomous_cycle_trial(
    python_problems: Sequence[SealedPythonScienceProblem],
    temporal_problems: Sequence[SealedTemporalScienceProblem],
) -> AutonomousCycleTrial:
    results: Dict[str, ScientificCycleResult] = {}
    for problem in python_problems:
        candidate = produce_python_cycle_candidate(problem.view, problem.query)
        results[problem.view.problem_id] = audit_python_cycle(candidate, problem)
    for problem in temporal_problems:
        candidate = produce_temporal_cycle_candidate(problem.view)
        results[problem.view.problem_id] = audit_temporal_cycle(candidate, problem)
    all_problems = (*python_problems, *temporal_problems)
    expected = {
        problem.view.problem_id: problem.expected_disposition for problem in all_problems
    }
    positives = [key for key, value in expected.items() if value == "adopt"]
    negatives = [key for key, value in expected.items() if value == "park"]
    adoption = sum(results[key].disposition == "adopt" for key in positives) / len(positives)
    parking = sum(results[key].disposition == "park" for key in negatives) / len(negatives) if negatives else 1.0
    families = sorted({results[key].evaluator_family for key in positives})
    family_scores = {
        family: sum(results[key].candidate_score for key in positives if results[key].evaluator_family == family)
        / sum(results[key].evaluator_family == family for key in positives)
        for family in families
    }
    mean_improvement = sum(results[key].improvement for key in positives) / len(positives)
    required = {CycleStage.REGISTER_GOAL, CycleStage.OBSERVE, CycleStage.BASELINE, CycleStage.DIAGNOSE, CycleStage.HYPOTHESIZE, CycleStage.REVISE_REPRESENTATION, CycleStage.FREEZE_CANDIDATE, CycleStage.PREDICT, CycleStage.PROSPECTIVE_AUDIT}
    checks = {
        "all_positive_problems_complete_and_adopt": adoption >= 0.95,
        "all_negative_controls_are_parked": parking == 1.0,
        "every_cycle_executes_required_scientific_stages": all(
            required.issubset({event.stage for event in result.events})
            and result.events[-1].stage in (CycleStage.ADOPT, CycleStage.PARK)
            for result in results.values()
        ),
        "active_experiments_occur_for_ambiguous_python_problems": all(
            CycleStage.DESIGN_EXPERIMENT in {event.stage for event in results[problem.view.problem_id].events}
            for problem in python_problems
            if problem.expected_disposition == "adopt"
        ),
        "prospective_audit_always_follows_candidate_freeze": all(
            next(i for i, event in enumerate(result.events) if event.stage == CycleStage.FREEZE_CANDIDATE)
            < next(i for i, event in enumerate(result.events) if event.stage == CycleStage.PROSPECTIVE_AUDIT)
            for result in results.values()
        ),
        "all_positive_families_clear_hidden_floor": min(family_scores.values()) >= 0.95,
    }
    return AutonomousCycleTrial(results, family_scores, adoption, parking, mean_improvement, checks)
