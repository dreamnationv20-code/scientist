from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_scientific_cycle_audit_v25 import (
    CycleAuditMaterialization,
)
from scientist.domains.cognitive_core.autonomous_scientific_cycle_v25 import (
    AutonomousCycleCoreFreeze,
    AutonomousCycleTrial,
    CycleStage,
    ScientificCycleResult,
    audit_python_cycle,
    audit_temporal_cycle,
    produce_python_cycle_candidate,
    produce_temporal_cycle_candidate,
)


CYCLE_VERIFIER_REF = "autonomous-scientific-cycle-independent-verifier-v25"


@dataclass(frozen=True)
class AutonomousCycleVerification:
    checks: Mapping[str, bool]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "verifier_ref": CYCLE_VERIFIER_REF,
            "checks": dict(sorted(self.checks.items())),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _freeze_before_audit(result: ScientificCycleResult) -> bool:
    stages = [event.stage for event in result.events]
    return stages.index(CycleStage.FREEZE_CANDIDATE) < stages.index(
        CycleStage.PROSPECTIVE_AUDIT
    )


def verify_autonomous_cycle(
    *,
    development_results: Sequence[ScientificCycleResult],
    cycle_freeze: AutonomousCycleCoreFreeze,
    required_source_freeze_ids: Mapping[str, str],
    materialization: CycleAuditMaterialization,
    trial: AutonomousCycleTrial,
    artifact_round_trips: Mapping[str, bool],
) -> AutonomousCycleVerification:
    python_signature = tuple(inspect.signature(produce_python_cycle_candidate).parameters)
    temporal_signature = tuple(inspect.signature(produce_temporal_cycle_candidate).parameters)
    candidate_source = "\n".join(
        (
            inspect.getsource(produce_python_cycle_candidate),
            inspect.getsource(produce_temporal_cycle_candidate),
        )
    ).lower()
    audit_source = "\n".join(
        (inspect.getsource(audit_python_cycle), inspect.getsource(audit_temporal_cycle))
    ).lower()
    candidate_views = json.dumps(
        {
            "python": [item.view.as_dict() for item in materialization.python_problems],
            "temporal": [item.view.as_dict() for item in materialization.temporal_problems],
        },
        sort_keys=True,
    ).lower()
    checks = {
        "development_completes_positive_cycles": bool(development_results)
        and all(item.disposition == "adopt" for item in development_results),
        "cycle_core_reuses_every_required_prior_freeze": all(
            cycle_freeze.source_freeze_ids.get(key) == value
            for key, value in required_source_freeze_ids.items()
        ),
        "candidate_functions_receive_only_visible_views_and_query_channel": (
            python_signature == ("view", "query")
            and temporal_signature == ("view",)
            and "hidden_tests" not in candidate_source
            and "hidden_sequences" not in candidate_source
            and "evaluator_family" not in candidate_source
        ),
        "prospective_evidence_is_confined_to_audit_functions": (
            "hidden_tests" in audit_source and "hidden_sequences" in audit_source
        ),
        "materialized_candidate_views_hide_evaluator_fields": all(
            token not in candidate_views
            for token in ("hidden_tests", "hidden_sequences", "evaluator_family", "expected_disposition")
        ),
        "audit_materializes_after_complete_loop_freeze": (
            materialization.cycle_freeze_id == cycle_freeze.freeze_id
            and cycle_freeze.freeze_stage < materialization.materialization_stage
        ),
        "every_hidden_audit_occurs_after_candidate_freeze": all(
            _freeze_before_audit(item) for item in trial.results.values()
        ),
        "complete_cycles_adopt_successes_and_park_negative_controls": trial.passed,
        "artifacts_round_trip_exactly": bool(artifact_round_trips)
        and all(artifact_round_trips.values()),
    }
    return AutonomousCycleVerification(
        checks,
        (
            "The frozen V1 loop autonomously executed goal registration, baseline "
            "measurement, diagnosis, hypothesis construction, intervention selection "
            "where needed, representation change, prediction, sealed audit, and "
            "conservative adoption or parking across Python and temporal problems."
        ),
        (
            "the loop autonomously chooses arbitrary real-world research goals",
            "unrestricted scientific discovery is solved",
            "the general cognitive core is established",
        ),
        (
            "Problem interfaces, legal interventions, and terminal metrics are supplied.",
            "The integrated loop remains bounded by the V21 and V23 meta-grammars.",
            "All current audits are local and procedurally generated.",
        ),
    )
