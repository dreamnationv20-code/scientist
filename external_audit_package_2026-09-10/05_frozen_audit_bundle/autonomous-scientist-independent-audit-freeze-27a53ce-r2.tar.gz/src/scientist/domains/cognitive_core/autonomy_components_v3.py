from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Optional

from scientist.autonomy.lifecycle_components import LifecycleStageProduct
from scientist.autonomy.literature_provider import (
    build_live_literature_stage_provider,
)
from scientist.autonomy.tracing import ComponentExecutionTrace
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.codex_exchange import CodexStructuredExchange
from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_diagnosis_v1 import (
    build_model_set,
    build_replay_audit,
    support_failures,
)
from scientist.domains.cognitive_core.repair_channel_sufficiency_v1 import (
    FORBIDDEN_PRIMITIVE_TERMS,
    ConceptCandidate,
    answer_blindness_failures,
    build_diagnostic_concept,
)
from scientist.program.research_kernel import (
    DiscriminatingExperimentPlan,
    ResearchActionKind,
)
from scientist.program.literature import (
    ClaimClassification,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)


COGNITIVE_CONCEPT_PROPOSAL_OPERATION = "invent_cognitive_causal_concept"
COGNITIVE_EXPERIMENT_PROPOSAL_OPERATION = (
    "design_cognitive_discriminating_experiment"
)


def _concept_response_schema() -> dict[str, Any]:
    string_array = {
        "type": "array",
        "minItems": 1,
        "items": {"type": "string"},
    }
    return {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "definition": {"type": "string"},
            "input_primitives": string_array,
            "computation": {"type": "string"},
            "causal_explanation": {"type": "string"},
            "covered_cluster_ids": string_array,
            "distinguishing_predictions": {
                **string_array,
                "minItems": 2,
            },
            "boundary_conditions": string_array,
            "falsification_conditions": {
                **string_array,
                "minItems": 2,
            },
            "selection_rationale": {"type": "string"},
        },
        "required": [
            "name",
            "definition",
            "input_primitives",
            "computation",
            "causal_explanation",
            "covered_cluster_ids",
            "distinguishing_predictions",
            "boundary_conditions",
            "falsification_conditions",
            "selection_rationale",
        ],
        "additionalProperties": False,
    }


class CognitiveConceptProposalStageProvider:
    """Ask an authenticated model for a concept, then enforce public constraints."""

    provider_version = "cognitive-concept-proposal-provider-v1"

    def __init__(self, exchange: CodexStructuredExchange) -> None:
        self.exchange = exchange

    def __call__(self, action, kernel, domain, component_ref):
        del domain
        if action.kind != ResearchActionKind.INVENT_LATENT_CONCEPT:
            raise ValueError("concept proposal provider received another action")
        if kernel.mission is None or kernel.atlas is None or kernel.diagnosis is None:
            raise ValueError("concept proposal requires an atlas-grounded diagnosis")
        public_packet = {
            "research_question": kernel.mission.research_question,
            "failure_cluster_ids": list(kernel.diagnosis.failure_cluster_ids),
            "causal_models": [model.as_dict() for model in kernel.diagnosis.models],
            "development_contrasts": [
                item.as_dict() for item in kernel.atlas.contrasts
            ],
            "forbidden_input_terms": list(FORBIDDEN_PRIMITIVE_TERMS),
            "requirements": {
                "cover_every_failure_cluster": True,
                "minimum_distinguishing_predictions": 2,
                "minimum_falsification_conditions": 2,
                "answer_or_outcome_information_allowed_as_input": False,
                "prospective_validation_cases": 24,
            },
        }
        prompt = (
            "Invent one missing, measurable latent variable that explains all "
            "registered causal failure clusters and makes prospective predictions. "
            "Use only the public diagnosis below. Input primitives must be available "
            "before intervention outcomes and must not contain any forbidden term. "
            "Do not claim validation. Return a full falsifiable concept matching the "
            "schema.\n\n%s"
            % json.dumps(public_packet, indent=2, sort_keys=True)
        )
        audited = self.exchange.request_audited(
            operation=COGNITIVE_CONCEPT_PROPOSAL_OPERATION,
            prompt=prompt,
            response_schema=_concept_response_schema(),
        )
        if not audited.worker.get("project_read_denial_preflight_passed"):
            raise ValueError("cognitive concept proposer was not source-sequestered")
        response = audited.response
        candidate = ConceptCandidate(
            name=str(response["name"]),
            definition=str(response["definition"]),
            input_primitives=tuple(str(item) for item in response["input_primitives"]),
            computation=str(response["computation"]),
            causal_explanation=str(response["causal_explanation"]),
            covered_cluster_ids=tuple(
                str(item) for item in response["covered_cluster_ids"]
            ),
            distinguishing_predictions=tuple(
                str(item) for item in response["distinguishing_predictions"]
            ),
            boundary_conditions=tuple(
                str(item) for item in response["boundary_conditions"]
            ),
            falsification_conditions=tuple(
                str(item) for item in response["falsification_conditions"]
            ),
        )
        if answer_blindness_failures(candidate):
            raise ValueError("proposed concept contains forbidden predictor primitives")
        if set(candidate.covered_cluster_ids) != set(
            kernel.diagnosis.failure_cluster_ids
        ):
            raise ValueError("proposed concept does not cover every failure cluster")
        concept = build_diagnostic_concept(
            kernel.atlas,
            kernel.diagnosis,
            candidate,
        )
        invocation = ExternalInvocation(
            kind=InvocationKind.MODEL,
            operation=COGNITIVE_CONCEPT_PROPOSAL_OPERATION,
            actor=ActorIdentity(
                "codex-proposal-model:%s" % audited.model_ref,
                ActorKind.PROPOSAL_MODEL,
            ),
            authority_scope=AuthorityScope.PROPOSE,
            input_artifact_ids=(audited.request_digest,),
            output_artifact_ids=(audited.response_digest,),
            usage=ResourceUsage(
                model_output_tokens=audited.reported_tokens_used,
                model_calls=1,
                wall_seconds=audited.wall_seconds,
            ),
        )
        return LifecycleStageProduct(
            artifact=concept,
            trace=ComponentExecutionTrace(
                action_id=action.action_id,
                component_ref=component_ref,
                invocations=(invocation,),
                complete=True,
                undeclared_external_access=False,
                sealed_authority_accessed=False,
            ),
            outcome="answer_blind_causal_concept_proposed",
            details={
                "provider_version": self.provider_version,
                "packet_id": audited.packet_id,
                "model_ref": audited.model_ref,
                "selection_rationale": str(response["selection_rationale"]),
                "answer_blindness_checked": True,
                "cluster_coverage_checked": True,
                "model_exercised_scientific_authority": False,
            },
        )


def _experiment_response_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "competing_hypothesis_ids": {
                "type": "array",
                "minItems": 2,
                "items": {"type": "string"},
            },
            "predicted_outcomes": {
                "type": "array",
                "minItems": 2,
                "items": {
                    "type": "object",
                    "properties": {
                        "hypothesis_id": {"type": "string"},
                        "outcomes": {
                            "type": "array",
                            "minItems": 1,
                            "items": {"type": "string"},
                        },
                    },
                    "required": ["hypothesis_id", "outcomes"],
                    "additionalProperties": False,
                },
            },
            "decision_rules": {
                "type": "array",
                "minItems": 2,
                "items": {
                    "type": "object",
                    "properties": {
                        "observed_pattern": {"type": "string"},
                        "research_action": {"type": "string"},
                    },
                    "required": ["observed_pattern", "research_action"],
                    "additionalProperties": False,
                },
            },
            "horizon_refs": {
                "type": "array",
                "minItems": 2,
                "items": {"type": "string"},
            },
            "expected_information_gain": {"type": "number"},
            "compute_cost": {"type": "number"},
            "development_partition_ref": {"type": "string"},
            "sealed_evaluation_partition_ref": {"type": "string"},
            "oracle_inputs": {
                "type": "array",
                "minItems": 1,
                "items": {"type": "string"},
            },
            "final_target_withheld": {"type": "boolean"},
            "frozen": {"type": "boolean"},
            "design_rationale": {"type": "string"},
        },
        "required": [
            "competing_hypothesis_ids",
            "predicted_outcomes",
            "decision_rules",
            "horizon_refs",
            "expected_information_gain",
            "compute_cost",
            "development_partition_ref",
            "sealed_evaluation_partition_ref",
            "oracle_inputs",
            "final_target_withheld",
            "frozen",
            "design_rationale",
        ],
        "additionalProperties": False,
    }


class CognitiveExperimentProposalStageProvider:
    """Propose an experiment while V3 retains partition and decision authority."""

    provider_version = "cognitive-experiment-proposal-provider-v1"

    def __init__(self, exchange: CodexStructuredExchange) -> None:
        self.exchange = exchange

    def __call__(self, action, kernel, domain, component_ref):
        del domain
        if action.kind != ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT:
            raise ValueError("experiment proposal provider received another action")
        if (
            kernel.mission is None
            or kernel.concept is None
            or kernel.concept_validation is None
            or not kernel.concept_validation.passed
        ):
            raise ValueError("experiment design requires a prospectively validated concept")
        public_packet = {
            "research_question": kernel.mission.research_question,
            "required_horizons": list(kernel.mission.required_horizons),
            "program_stop_rules": list(kernel.mission.program_stop_rules),
            "forbidden_shortcuts": list(kernel.mission.forbidden_shortcuts),
            "concept": kernel.concept.as_dict(),
            "concept_validation": kernel.concept_validation.as_dict(),
            "requirements": {
                "include_concept_and_at_least_one_competitor": True,
                "predictions_must_differ": True,
                "development_and_sealed_partitions_disjoint": True,
                "final_target_withheld": True,
                "all_required_horizons_included": True,
                "outcome_contingent_decision_rules_frozen": True,
            },
        }
        prompt = (
            "Design one answer-blind experiment that distinguishes the validated "
            "concept from at least one serious competing explanation. Freeze the "
            "partitions, horizon coverage, predicted outcomes, compute cost, and "
            "outcome-contingent research decisions before evaluation. The final "
            "target must remain withheld. Return only the typed design.\n\n%s"
            % json.dumps(public_packet, indent=2, sort_keys=True)
        )
        audited = self.exchange.request_audited(
            operation=COGNITIVE_EXPERIMENT_PROPOSAL_OPERATION,
            prompt=prompt,
            response_schema=_experiment_response_schema(),
        )
        if not audited.worker.get("project_read_denial_preflight_passed"):
            raise ValueError("cognitive experiment designer was not source-sequestered")
        response = audited.response
        hypothesis_ids = tuple(
            str(item) for item in response["competing_hypothesis_ids"]
        )
        predictions = {
            str(row["hypothesis_id"]): tuple(
                str(item) for item in row["outcomes"]
            )
            for row in response["predicted_outcomes"]
        }
        rules = {
            str(row["observed_pattern"]): str(row["research_action"])
            for row in response["decision_rules"]
        }
        plan = DiscriminatingExperimentPlan(
            mission_id=kernel.mission.mission_id,
            concept_id=kernel.concept.concept_id,
            competing_hypothesis_ids=hypothesis_ids,
            predicted_outcomes=predictions,
            decision_rules=rules,
            horizon_refs=tuple(str(item) for item in response["horizon_refs"]),
            expected_information_gain=float(response["expected_information_gain"]),
            compute_cost=float(response["compute_cost"]),
            development_partition_ref=str(response["development_partition_ref"]),
            sealed_evaluation_partition_ref=str(
                response["sealed_evaluation_partition_ref"]
            ),
            oracle_inputs=tuple(str(item) for item in response["oracle_inputs"]),
            final_target_withheld=bool(response["final_target_withheld"]),
            frozen=bool(response["frozen"]),
            designer_ref="codex-cognitive-experiment-designer-v1",
        )
        if kernel.concept.concept_id not in hypothesis_ids:
            raise ValueError("experiment omitted the validated concept hypothesis")
        invocation = ExternalInvocation(
            kind=InvocationKind.MODEL,
            operation=COGNITIVE_EXPERIMENT_PROPOSAL_OPERATION,
            actor=ActorIdentity(
                "codex-proposal-model:%s" % audited.model_ref,
                ActorKind.PROPOSAL_MODEL,
            ),
            authority_scope=AuthorityScope.PROPOSE,
            input_artifact_ids=(audited.request_digest,),
            output_artifact_ids=(audited.response_digest,),
            usage=ResourceUsage(
                model_output_tokens=audited.reported_tokens_used,
                model_calls=1,
                wall_seconds=audited.wall_seconds,
            ),
        )
        return LifecycleStageProduct(
            artifact=plan,
            trace=ComponentExecutionTrace(
                action_id=action.action_id,
                component_ref=component_ref,
                invocations=(invocation,),
                complete=True,
                undeclared_external_access=False,
                sealed_authority_accessed=False,
            ),
            outcome="discriminating_experiment_proposed_and_frozen",
            details={
                "provider_version": self.provider_version,
                "packet_id": audited.packet_id,
                "model_ref": audited.model_ref,
                "design_rationale": str(response["design_rationale"]),
                "model_exercised_scientific_authority": False,
            },
        )


class CausalReplayDiagnosisStageProvider:
    """Derive a fully evidenced causal model set from the registered atlas.

    The provider is deterministic: adaptive model suggestions are unnecessary
    when the atlas already contains the frozen counterfactual replay panel.
    """

    provider_version = "cognitive-causal-replay-diagnosis-provider-v1"

    def __call__(self, action, kernel, domain, component_ref):
        del domain
        if action.kind != ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS:
            raise ValueError("causal diagnosis provider received another action")
        if kernel.mission is None or kernel.atlas is None:
            raise ValueError("causal diagnosis requires a mission and phenomenon atlas")
        audit = build_replay_audit(kernel.atlas)
        failures = support_failures(audit)
        if failures:
            raise ValueError(
                "causal replay support is incomplete: %s" % ", ".join(failures)
            )
        diagnosis = build_model_set(
            kernel.mission.root_node_id,
            kernel.atlas,
            audit,
        )
        return LifecycleStageProduct(
            artifact=diagnosis,
            trace=ComponentExecutionTrace.deterministic(
                action.action_id, component_ref
            ),
            outcome="replay_supported_causal_diagnosis_built",
            details={
                "provider_version": self.provider_version,
                "atlas_id": kernel.atlas.atlas_id,
                "replay_audit_id": content_digest(audit),
                "failure_cluster_ids": list(diagnosis.failure_cluster_ids),
                "adaptive_model_used": False,
            },
        )


def build_causal_structure_prior_art_plan(kernel, domain) -> PriorArtAssessment:
    """Build the frozen query plan for the cognitive repairability mission."""

    if kernel.mission is None:
        raise ValueError("prior-art planning requires a frozen mission")
    if kernel.mission.domain_id != domain.domain_id:
        raise ValueError("prior-art mission and domain disagree")
    incumbent = PriorWork(
        work_id="doi:10.18653/v1/2023.findings-emnlp.378",
        title="Measuring and Narrowing the Compositionality Gap in Language Models",
        year=2023,
        locator="https://doi.org/10.18653/v1/2023.findings-emnlp.378",
        relation=PriorArtRelation.EXECUTABLE_BASELINE,
        matched_components=(
            "published self-ask intervention",
            "explicit decomposition state",
            "external search tool use",
            "publicly specified executable method",
        ),
        executable=True,
    )
    queries = tuple(
        LiteratureQuery(query=query, facet=facet, provider="frozen-causal-query-plan")
        for query, facet in (
            (
                "language model reasoning failures test time intervention",
                SearchFacet.PROBLEM,
            ),
            (
                "language model reasoning verification tools external memory",
                SearchFacet.INTERVENTION,
            ),
            (
                "language model state tracking updates consistency reasoning",
                SearchFacet.MECHANISM,
            ),
            (
                "language model source attribution provenance reasoning",
                SearchFacet.MECHANISM,
            ),
            (
                "causal evaluation language model reasoning interventions",
                SearchFacet.EVALUATION,
            ),
        )
    )
    return PriorArtAssessment(
        signature=kernel.mission.claim_signature,
        trigger=LiteratureTrigger.INITIAL_SCOPE,
        queries=queries,
        closest_works=(incumbent,),
        classification=ClaimClassification.INCREMENTAL_ADVANCE,
        rationale=(
            "The frozen initial position is conservative: explicit decomposition, "
            "verification, retrieval, memory, and test-time compute are established "
            "repair families. The survey tests whether prior work already joins "
            "transaction hazards and proposition provenance as answer-blind "
            "moderators of differential intervention effects."
        ),
        novel_delta=(
            "Prospectively predict a failure-level distribution over which qualified repair class will work, rather than report one intervention's average effect.",
            "Cross answer-preserving transaction-hazard and content-identical provenance manipulations to identify distinct repair-effect moderators.",
            "Freeze all predictor features before intervention outcomes and require transport across 1.7B/3B model sizes plus a held-out regime.",
        ),
        citation_snowball_complete=False,
        searched_at="2026-09-02",
        reviewer_ref="frozen-causal-query-plan:v1",
        executable_incumbent_id=incumbent.work_id,
    )


def build_cognitive_live_prior_art_provider(
    *,
    store_root: Path,
    reviewer_factory: Optional[Callable[[Any], Any]] = None,
    timeout_seconds: float = 20.0,
    results_per_query: int = 6,
):
    return build_live_literature_stage_provider(
        store_root=store_root,
        plan_builder=build_causal_structure_prior_art_plan,
        reviewer_factory=reviewer_factory,
        timeout_seconds=timeout_seconds,
        results_per_query=results_per_query,
    )


__all__ = [
    "COGNITIVE_CONCEPT_PROPOSAL_OPERATION",
    "COGNITIVE_EXPERIMENT_PROPOSAL_OPERATION",
    "CausalReplayDiagnosisStageProvider",
    "CognitiveConceptProposalStageProvider",
    "CognitiveExperimentProposalStageProvider",
    "build_causal_structure_prior_art_plan",
    "build_cognitive_live_prior_art_provider",
]
