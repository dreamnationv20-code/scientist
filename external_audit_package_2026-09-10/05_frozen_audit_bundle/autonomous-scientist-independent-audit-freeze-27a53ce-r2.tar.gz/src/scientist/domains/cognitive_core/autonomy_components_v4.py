from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.lifecycle_components import LifecycleStageProduct
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import (
    ComponentExecutionTrace,
    ExternalInvocation,
    InvocationKind,
)
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.codex_exchange import AuditedCodexResponse, CodexStructuredExchange
from scientist.domains.cognitive_core.repair_channel_sufficiency_v1 import (
    FORBIDDEN_PRIMITIVE_TERMS,
    ConceptCandidate,
    answer_blindness_failures,
    build_diagnostic_concept,
)
from scientist.program.research_kernel import (
    DiscriminatingExperimentPlan,
    ResearchActionKind,
)


COGNITIVE_PROPOSAL_TOURNAMENT_VERSION = "cognitive-proposal-tournament-v1"
ALL_RECOVERY_ACTIONS = tuple(RecoveryAction)


def _string_array(minimum: int = 1) -> Mapping[str, Any]:
    return {
        "type": "array",
        "minItems": minimum,
        "items": {"type": "string"},
    }


def _concept_schema() -> Mapping[str, Any]:
    return {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "definition": {"type": "string"},
            "input_primitives": _string_array(),
            "computation": {"type": "string"},
            "causal_explanation": {"type": "string"},
            "covered_cluster_ids": _string_array(),
            "distinguishing_predictions": _string_array(2),
            "boundary_conditions": _string_array(),
            "falsification_conditions": _string_array(2),
            "selection_rationale": {"type": "string"},
        },
        "required": [
            "name",
            "definition",
            "input_primitives",
            "computation",
            "causal_explanation",
            "covered_cluster_ids",
            "distinguishing_predictions",
            "boundary_conditions",
            "falsification_conditions",
            "selection_rationale",
        ],
        "additionalProperties": False,
    }


def _experiment_schema() -> Mapping[str, Any]:
    return {
        "type": "object",
        "properties": {
            "competitor_hypothesis_ids": _string_array(),
            "predicted_outcomes": {
                "type": "array",
                "minItems": 2,
                "items": {
                    "type": "object",
                    "properties": {
                        "hypothesis_id": {"type": "string"},
                        "outcomes": _string_array(),
                    },
                    "required": ["hypothesis_id", "outcomes"],
                    "additionalProperties": False,
                },
            },
            "decision_rules": {
                "type": "array",
                "minItems": 2,
                "items": {
                    "type": "object",
                    "properties": {
                        "observed_pattern": {"type": "string"},
                        "research_action": {"type": "string"},
                    },
                    "required": ["observed_pattern", "research_action"],
                    "additionalProperties": False,
                },
            },
            "horizon_refs": _string_array(2),
            "expected_information_gain": {"type": "number"},
            "compute_cost": {"type": "number"},
            "development_partition_ref": {"type": "string"},
            "sealed_evaluation_partition_ref": {"type": "string"},
            "oracle_inputs": _string_array(),
            "final_target_withheld": {"type": "boolean"},
            "frozen": {"type": "boolean"},
            "design_rationale": {"type": "string"},
        },
        "required": [
            "competitor_hypothesis_ids",
            "predicted_outcomes",
            "decision_rules",
            "horizon_refs",
            "expected_information_gain",
            "compute_cost",
            "development_partition_ref",
            "sealed_evaluation_partition_ref",
            "oracle_inputs",
            "final_target_withheld",
            "frozen",
            "design_rationale",
        ],
        "additionalProperties": False,
    }


def _invocation(operation: str, audited: AuditedCodexResponse) -> ExternalInvocation:
    return ExternalInvocation(
        kind=InvocationKind.MODEL,
        operation=operation,
        actor=ActorIdentity(
            "codex-proposal-model:%s" % audited.model_ref,
            ActorKind.PROPOSAL_MODEL,
        ),
        authority_scope=AuthorityScope.PROPOSE,
        input_artifact_ids=(audited.request_digest,),
        output_artifact_ids=(audited.response_digest,),
        usage=ResourceUsage(
            model_output_tokens=audited.reported_tokens_used,
            model_calls=1,
            wall_seconds=audited.wall_seconds,
        ),
    )


def _interface_failure(
    *,
    action,
    phase: str,
    question: str,
    observations: Sequence[str],
    invocations: Sequence[ExternalInvocation],
    domain: str,
) -> AdjudicableResearchFailure:
    evidence_refs = tuple(item.output_artifact_ids[0] for item in invocations)
    case = TransitionCase(
        case_ref="%s-proposal-tournament-exhausted" % phase,
        phase=phase,
        question=question,
        observations=tuple(observations),
        available_actions=ALL_RECOVERY_ACTIONS,
        protected_invariants=(
            "mission identity",
            "registered evidence",
            "sealed outcomes",
            "proposal budget",
        ),
        evidence_refs=evidence_refs,
        retrospective=False,
        domain=domain,
    )
    profile = FailureEvidenceProfile(
        case_id=case.case_id,
        runtime_available=True,
        external_dependency_missing=False,
        implementation_integrity_passed=True,
        interface_qualified=False,
        protocol_feasible=True,
        measurement_qualified=None,
        scientific_outcome_observed=False,
        scientific_gate_passed=None,
        representation_limit_demonstrated=False,
    )
    return AdjudicableResearchFailure(
        "bounded proposal tournament exhausted its interface-valid candidates",
        case=case,
        profile=profile,
        attempt_invocations=tuple(invocations),
    )


class BoundedCognitiveConceptProposalStageProvider:
    """Retain and account for rejected proposals before selecting a valid concept."""

    provider_version = "bounded-cognitive-concept-proposal-provider-v1"

    def __init__(
        self,
        exchange: CodexStructuredExchange,
        *,
        maximum_attempts: int = 3,
    ) -> None:
        if maximum_attempts <= 0:
            raise ValueError("concept proposal tournament requires a positive attempt cap")
        self.exchange = exchange
        self.maximum_attempts = maximum_attempts

    def __call__(self, action, kernel, domain, component_ref):
        if action.kind != ResearchActionKind.INVENT_LATENT_CONCEPT:
            raise ValueError("concept proposal provider received another action")
        if kernel.mission is None or kernel.atlas is None or kernel.diagnosis is None:
            raise ValueError("concept proposal requires an atlas-grounded diagnosis")
        public_packet = {
            "research_question": kernel.mission.research_question,
            "failure_cluster_ids": list(kernel.diagnosis.failure_cluster_ids),
            "causal_models": [model.as_dict() for model in kernel.diagnosis.models],
            "development_contrasts": [
                item.as_dict() for item in kernel.atlas.contrasts
            ],
            "forbidden_input_terms": list(FORBIDDEN_PRIMITIVE_TERMS),
            "requirements": {
                "cover_every_failure_cluster_exactly_once": True,
                "minimum_distinguishing_predictions": 2,
                "minimum_falsification_conditions": 2,
                "answer_or_outcome_information_allowed_as_input": False,
                "prospective_validation_cases": 24,
            },
        }
        base_prompt = (
            "Invent one measurable latent variable that explains every registered "
            "causal failure cluster and makes prospective predictions. Use only the "
            "public diagnosis. Input primitives must be available before intervention "
            "outcomes and contain none of the forbidden terms. Return a complete "
            "falsifiable concept.\n\n%s"
            % json.dumps(public_packet, indent=2, sort_keys=True)
        )
        invocations = []
        rejection_reasons = []
        for attempt in range(1, self.maximum_attempts + 1):
            repair = ""
            if rejection_reasons:
                repair = (
                    "\n\nThe preceding candidate was rejected for these purely "
                    "interface-level reasons: %s. Produce a new candidate; do not "
                    "change the scientific evidence."
                    % "; ".join(rejection_reasons[-1])
                )
            operation = "invent_cognitive_causal_concept_attempt_%d" % attempt
            audited = self.exchange.request_audited(
                operation=operation,
                prompt=base_prompt + repair,
                response_schema=_concept_schema(),
            )
            invocation = _invocation(operation, audited)
            invocations.append(invocation)
            response = audited.response
            reasons = []
            try:
                candidate = ConceptCandidate(
                    name=str(response["name"]),
                    definition=str(response["definition"]),
                    input_primitives=tuple(
                        str(item) for item in response["input_primitives"]
                    ),
                    computation=str(response["computation"]),
                    causal_explanation=str(response["causal_explanation"]),
                    covered_cluster_ids=tuple(
                        str(item) for item in response["covered_cluster_ids"]
                    ),
                    distinguishing_predictions=tuple(
                        str(item) for item in response["distinguishing_predictions"]
                    ),
                    boundary_conditions=tuple(
                        str(item) for item in response["boundary_conditions"]
                    ),
                    falsification_conditions=tuple(
                        str(item) for item in response["falsification_conditions"]
                    ),
                )
                forbidden = answer_blindness_failures(candidate)
                if forbidden:
                    reasons.append("forbidden input primitives: %s" % ", ".join(forbidden))
                if set(candidate.covered_cluster_ids) != set(
                    kernel.diagnosis.failure_cluster_ids
                ):
                    reasons.append("failure-cluster coverage is not exact")
                if len(candidate.covered_cluster_ids) != len(
                    set(candidate.covered_cluster_ids)
                ):
                    reasons.append("failure-cluster coverage contains duplicates")
                if not reasons:
                    concept = build_diagnostic_concept(
                        kernel.atlas, kernel.diagnosis, candidate
                    )
            except (KeyError, TypeError, ValueError) as error:
                reasons.append(str(error))
            if reasons:
                rejection_reasons.append(tuple(reasons))
                continue
            if not audited.worker.get("project_read_denial_preflight_passed"):
                raise ValueError("concept proposer was not source-sequestered")
            return LifecycleStageProduct(
                artifact=concept,
                trace=ComponentExecutionTrace(
                    action_id=action.action_id,
                    component_ref=component_ref,
                    invocations=tuple(invocations),
                    complete=True,
                    undeclared_external_access=False,
                    sealed_authority_accessed=False,
                ),
                outcome="answer_blind_causal_concept_selected",
                details={
                    "provider_version": self.provider_version,
                    "proposal_attempt_count": len(invocations),
                    "rejected_candidate_count": len(rejection_reasons),
                    "rejection_reasons": [list(item) for item in rejection_reasons],
                    "selected_packet_id": audited.packet_id,
                    "model_ref": audited.model_ref,
                    "selection_rationale": str(response["selection_rationale"]),
                    "model_exercised_scientific_authority": False,
                },
            )
        raise _interface_failure(
            action=action,
            phase="concept_proposal",
            question="Can a proposal satisfy the frozen answer-blind concept interface?",
            observations=tuple(
                "attempt %d: %s" % (index + 1, "; ".join(reasons))
                for index, reasons in enumerate(rejection_reasons)
            ),
            invocations=invocations,
            domain=domain.domain_id,
        )


class BoundedCognitiveExperimentProposalStageProvider:
    """Use a corrected hypothesis-set contract and bounded semantic re-proposal."""

    provider_version = "bounded-cognitive-experiment-proposal-provider-v1"

    def __init__(
        self,
        exchange: CodexStructuredExchange,
        *,
        maximum_attempts: int = 3,
    ) -> None:
        if maximum_attempts <= 0:
            raise ValueError("experiment proposal tournament requires a positive attempt cap")
        self.exchange = exchange
        self.maximum_attempts = maximum_attempts

    def __call__(self, action, kernel, domain, component_ref):
        if action.kind != ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT:
            raise ValueError("experiment proposal provider received another action")
        if (
            kernel.mission is None
            or kernel.concept is None
            or kernel.concept_validation is None
            or not kernel.concept_validation.passed
        ):
            raise ValueError("experiment design requires a prospectively validated concept")
        public_packet = {
            "research_question": kernel.mission.research_question,
            "required_horizons": list(kernel.mission.required_horizons),
            "program_stop_rules": list(kernel.mission.program_stop_rules),
            "forbidden_shortcuts": list(kernel.mission.forbidden_shortcuts),
            "validated_concept_hypothesis_id": kernel.concept.concept_id,
            "concept": kernel.concept.as_dict(),
            "concept_validation": kernel.concept_validation.as_dict(),
            "requirements": {
                "competitor_hypothesis_ids_exclude_validated_concept": True,
                "predicted_outcomes_cover_validated_concept_and_all_competitors": True,
                "predictions_must_differ": True,
                "development_and_sealed_partitions_disjoint": True,
                "final_target_withheld": True,
                "all_required_horizons_included_verbatim": True,
                "outcome_contingent_decision_rules_frozen": True,
            },
        }
        base_prompt = (
            "Design one answer-blind experiment that distinguishes the validated "
            "concept from at least one serious competitor. The field "
            "competitor_hypothesis_ids must exclude the validated concept. The "
            "predicted_outcomes table must contain exactly one row for the validated "
            "concept ID and exactly one row for every competitor ID. Copy every "
            "required horizon string verbatim. Freeze partitions, predictions, cost, "
            "and outcome-contingent decisions before evaluation.\n\n%s"
            % json.dumps(public_packet, indent=2, sort_keys=True)
        )
        invocations = []
        rejection_reasons = []
        for attempt in range(1, self.maximum_attempts + 1):
            repair = ""
            if rejection_reasons:
                repair = (
                    "\n\nThe preceding design was rejected for these purely "
                    "interface-level reasons: %s. Return a new design without "
                    "changing the registered evidence or outcome access."
                    % "; ".join(rejection_reasons[-1])
                )
            operation = "design_cognitive_discriminating_experiment_attempt_%d" % attempt
            audited = self.exchange.request_audited(
                operation=operation,
                prompt=base_prompt + repair,
                response_schema=_experiment_schema(),
            )
            invocation = _invocation(operation, audited)
            invocations.append(invocation)
            response = audited.response
            reasons = []
            competitors = tuple(
                str(item) for item in response["competitor_hypothesis_ids"]
            )
            if len(competitors) != len(set(competitors)):
                reasons.append("competitor identifiers are not unique")
            if kernel.concept.concept_id in competitors:
                reasons.append("competitor list contains the validated concept")
            hypothesis_ids = (kernel.concept.concept_id, *competitors)
            prediction_rows = response["predicted_outcomes"]
            prediction_ids = tuple(str(row["hypothesis_id"]) for row in prediction_rows)
            if len(prediction_ids) != len(set(prediction_ids)):
                reasons.append("prediction hypothesis identifiers are not unique")
            if set(prediction_ids) != set(hypothesis_ids):
                reasons.append("prediction table and hypothesis set differ")
            horizons = tuple(str(item) for item in response["horizon_refs"])
            if not set(kernel.mission.required_horizons).issubset(horizons):
                reasons.append("mission-required horizon strings are missing")
            rules = {
                str(row["observed_pattern"]): str(row["research_action"])
                for row in response["decision_rules"]
            }
            if len(rules) != len(response["decision_rules"]):
                reasons.append("decision patterns are not unique")
            predictions = {
                str(row["hypothesis_id"]): tuple(
                    str(item) for item in row["outcomes"]
                )
                for row in prediction_rows
            }
            if not reasons:
                try:
                    plan = DiscriminatingExperimentPlan(
                        mission_id=kernel.mission.mission_id,
                        concept_id=kernel.concept.concept_id,
                        competing_hypothesis_ids=hypothesis_ids,
                        predicted_outcomes=predictions,
                        decision_rules=rules,
                        horizon_refs=horizons,
                        expected_information_gain=float(
                            response["expected_information_gain"]
                        ),
                        compute_cost=float(response["compute_cost"]),
                        development_partition_ref=str(
                            response["development_partition_ref"]
                        ),
                        sealed_evaluation_partition_ref=str(
                            response["sealed_evaluation_partition_ref"]
                        ),
                        oracle_inputs=tuple(
                            str(item) for item in response["oracle_inputs"]
                        ),
                        final_target_withheld=bool(
                            response["final_target_withheld"]
                        ),
                        frozen=bool(response["frozen"]),
                        designer_ref="codex-cognitive-experiment-designer-v2",
                    )
                except (TypeError, ValueError) as error:
                    reasons.append(str(error))
            if reasons:
                rejection_reasons.append(tuple(reasons))
                continue
            if not audited.worker.get("project_read_denial_preflight_passed"):
                raise ValueError("experiment designer was not source-sequestered")
            return LifecycleStageProduct(
                artifact=plan,
                trace=ComponentExecutionTrace(
                    action_id=action.action_id,
                    component_ref=component_ref,
                    invocations=tuple(invocations),
                    complete=True,
                    undeclared_external_access=False,
                    sealed_authority_accessed=False,
                ),
                outcome="discriminating_experiment_selected_and_frozen",
                details={
                    "provider_version": self.provider_version,
                    "proposal_attempt_count": len(invocations),
                    "rejected_candidate_count": len(rejection_reasons),
                    "rejection_reasons": [list(item) for item in rejection_reasons],
                    "selected_packet_id": audited.packet_id,
                    "model_ref": audited.model_ref,
                    "design_rationale": str(response["design_rationale"]),
                    "model_exercised_scientific_authority": False,
                },
            )
        raise _interface_failure(
            action=action,
            phase="experiment_proposal",
            question="Can a proposal satisfy the frozen discriminating-experiment interface?",
            observations=tuple(
                "attempt %d: %s" % (index + 1, "; ".join(reasons))
                for index, reasons in enumerate(rejection_reasons)
            ),
            invocations=invocations,
            domain=domain.domain_id,
        )


__all__ = [
    "COGNITIVE_PROPOSAL_TOURNAMENT_VERSION",
    "BoundedCognitiveConceptProposalStageProvider",
    "BoundedCognitiveExperimentProposalStageProvider",
]
