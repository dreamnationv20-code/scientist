from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import (
    KnowledgeRow,
    MetaExample,
    TypedExpression,
    execute_expression,
    infer_typed_expression,
)
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    CausalAddressIntervention,
    LatentAction,
    LatentActionKind,
    LatentEvaluation,
    LatentEvent,
    LatentEventKind,
    LatentObject,
    LatentProbeOutcome,
    LatentRegistry,
    LatentStep,
    _clone_object,
    _decode_examples,
    _decode_rows,
    _infer_mutation,
    evaluate_latent_runtime,
)
from scientist.domains.cognitive_core.self_supervised_object_discovery_v18 import (
    EVIDENCE_MODES,
    CandidateVisibleEventStream,
    SelfSupervisedAddressModel,
    SelfSupervisedRegistry,
)


BEHAVIORAL_PREDICATE_DISCOVERY_VERSION = (
    "cognitive-core-behavioral-predicate-discovery-v19"
)


def _safe_fixed_execute(
    expression: TypedExpression,
    inputs: Sequence[Any],
    context: Sequence[KnowledgeRow],
) -> Tuple[Any | None, Tuple[str, ...]]:
    try:
        return execute_expression(expression, inputs, context)
    except (KeyError, TypeError, ValueError):
        return None, ()


def infer_fixed_schema(
    examples: Sequence[MetaExample],
    context: Sequence[KnowledgeRow],
    metadata: Mapping[str, Any],
) -> TypedExpression | None:
    """The deliberately frozen schema scaffold that Milestone 20 removes."""

    inferred = infer_typed_expression(examples, context, metadata)
    if inferred is not None:
        return inferred
    if examples and all(len(item.inputs) == 1 for item in examples):
        keys = tuple(tuple(item.inputs) for item in examples)
        if len(set(keys)) == len(keys):
            return TypedExpression(
                "table",
                {
                    "items": [
                        [list(item.inputs), item.output] for item in examples
                    ]
                },
            )
    return None


def _fixed_repair(
    obj: LatentObject, desired: Sequence[MetaExample]
) -> LatentObject | None:
    if obj.expression.kind != "table":
        return _infer_mutation(obj, desired)
    old_items = {
        tuple(item[0]): item[1]
        for item in obj.expression.arguments["items"]
    }
    desired_items = {tuple(item.inputs): item.output for item in desired}
    if set(old_items) != set(desired_items):
        return None
    changed = [key for key in old_items if old_items[key] != desired_items[key]]
    if len(changed) != 1:
        return None
    candidate = _clone_object(obj)
    candidate.expression = TypedExpression(
        "table",
        {
            "items": [
                [list(key), desired_items[key]]
                for key in old_items
            ]
        },
    )
    return candidate


@dataclass(frozen=True)
class BehavioralPredicateProgram:
    operator: str
    arguments: Mapping[str, Any]

    @property
    def program_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "operator": self.operator,
            "arguments": dict(sorted(self.arguments.items())),
        }
        if include_id:
            value["program_id"] = self.program_id
        return value


def enumerate_behavioral_predicates() -> Tuple[BehavioralPredicateProgram, ...]:
    programs = [BehavioralPredicateProgram("constant", {"value": 1.0})]
    programs.extend(
        BehavioralPredicateProgram(
            "replay_reduce",
            {"source": source, "test": test, "reducer": "mean"},
        )
        for source in ("locators", "desired_examples")
        for test in ("equals_observed", "is_defined")
    )
    programs.extend(
        (
            BehavioralPredicateProgram(
                "shape_relation",
                {"left": "locators", "right": "stored_examples"},
            ),
            BehavioralPredicateProgram(
                "local_edit_cardinality",
                {"source": "desired_examples", "test": "exactly_one"},
            ),
            BehavioralPredicateProgram(
                "query_replay",
                {"test": "is_defined"},
            ),
            BehavioralPredicateProgram(
                "query_replay",
                {"test": "uses_context"},
            ),
            BehavioralPredicateProgram(
                "set_overlap",
                {"left": "event_alias_atoms", "right": "history_alias_atoms"},
            ),
            BehavioralPredicateProgram(
                "time_kernel", {"power": 1}
            ),
            BehavioralPredicateProgram(
                "time_kernel", {"power": 2}
            ),
        )
    )
    programs.extend(
        BehavioralPredicateProgram("event_indicator", {"kind": kind.value})
        for kind in LatentEventKind
    )
    programs.extend(
        BehavioralPredicateProgram(
            "size_kernel", {"source": source}
        )
        for source in (
            "stored_examples",
            "stored_context",
            "locators",
            "desired_examples",
        )
    )
    return tuple(programs)


def evaluate_behavioral_predicate(
    program: BehavioralPredicateProgram,
    event: LatentEvent,
    obj: LatentObject,
    sequence: int,
) -> float:
    operator = program.operator
    arguments = program.arguments
    if operator == "constant":
        return float(arguments["value"])
    if operator == "replay_reduce":
        examples = _decode_examples(event.payload.get(arguments["source"], ()))
        if not examples:
            return 0.0
        predictions = tuple(
            _safe_fixed_execute(obj.expression, item.inputs, obj.context)[0]
            for item in examples
        )
        if arguments["test"] == "equals_observed":
            values = tuple(
                prediction == item.output
                for prediction, item in zip(predictions, examples)
            )
        else:
            values = tuple(prediction is not None for prediction in predictions)
        return sum(values) / len(values)
    if operator == "shape_relation":
        locators = _decode_examples(event.payload.get("locators", ()))
        if not locators or not obj.examples:
            return 0.0
        left = tuple(type(value).__name__ for value in locators[0].inputs)
        right = tuple(type(value).__name__ for value in obj.examples[0].inputs)
        return float(left == right)
    if operator == "local_edit_cardinality":
        desired = _decode_examples(event.payload.get(arguments["source"], ()))
        return float(bool(desired) and _fixed_repair(obj, desired) is not None)
    if operator == "query_replay":
        inputs = tuple(event.payload.get("inputs", ()))
        if not inputs:
            return 0.0
        value, used = _safe_fixed_execute(obj.expression, inputs, obj.context)
        if arguments["test"] == "uses_context":
            return float(bool(used))
        return float(value is not None)
    if operator == "set_overlap":
        left = set(event.alias.split("-"))
        right = {
            atom for alias in obj.aliases for atom in alias.split("-")
        }
        union = left | right
        return len(left & right) / len(union) if union else 0.0
    if operator == "time_kernel":
        lag = max(0, sequence - obj.last_touched)
        return 1.0 / ((1.0 + lag) ** int(arguments["power"]))
    if operator == "event_indicator":
        return float(event.kind.value == arguments["kind"])
    if operator == "size_kernel":
        source = arguments["source"]
        values = {
            "stored_examples": obj.examples,
            "stored_context": obj.context,
            "locators": event.payload.get("locators", ()),
            "desired_examples": event.payload.get("desired_examples", ()),
        }[source]
        return 1.0 / (1.0 + len(values))
    raise ValueError("unknown behavioral predicate operator")


def _raw_consequence_cost(event: LatentEvent, obj: LatentObject) -> float:
    locators = _decode_examples(event.payload.get("locators", ()))
    cost = 0.0
    if locators:
        predictions = tuple(
            _safe_fixed_execute(obj.expression, item.inputs, obj.context)[0]
            for item in locators
        )
        cost += 3.0 * (
            1.0
            - sum(
                prediction == item.output
                for prediction, item in zip(predictions, locators)
            )
            / len(locators)
        )
        cost += 1.0 * (
            1.0
            - sum(prediction is not None for prediction in predictions)
            / len(predictions)
        )
    if event.kind == LatentEventKind.UPDATE:
        desired = _decode_examples(event.payload.get("desired_examples", ()))
        cost += 3.0 * float(_fixed_repair(obj, desired) is None)
    if event.kind in (LatentEventKind.QUERY, LatentEventKind.SELECT):
        value, _ = _safe_fixed_execute(
            obj.expression,
            tuple(event.payload.get("inputs", ())),
            obj.context,
        )
        cost += 2.0 * float(value is None)
    if not locators:
        cost += 0.05 / (1.0 + obj.last_touched)
    return cost


@dataclass(frozen=True)
class PredicateContrast:
    event_id: str
    chosen_slot_id: str
    consequence_cost_by_slot: Mapping[str, float]
    predicate_values_by_slot: Mapping[str, Mapping[str, float]]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "chosen_slot_id": self.chosen_slot_id,
            "consequence_cost_by_slot": dict(
                sorted(self.consequence_cost_by_slot.items())
            ),
            "predicate_values_by_slot": {
                key: dict(sorted(value.items()))
                for key, value in sorted(self.predicate_values_by_slot.items())
            },
        }


@dataclass(frozen=True)
class PredicateDiscoveryTrace:
    development_registry_id: str
    candidate_stream_id: str
    predicate_pool: Tuple[BehavioralPredicateProgram, ...]
    contrasts: Tuple[PredicateContrast, ...]
    exposed_event_ids: Tuple[str, ...]
    objective: str

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": BEHAVIORAL_PREDICATE_DISCOVERY_VERSION,
            "development_registry_id": self.development_registry_id,
            "candidate_stream_id": self.candidate_stream_id,
            "predicate_pool": [item.as_dict() for item in self.predicate_pool],
            "contrasts": [item.as_dict() for item in self.contrasts],
            "exposed_event_ids": list(self.exposed_event_ids),
            "objective": self.objective,
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


class _ForcedFixedRuntime:
    """Build frozen-schema object state from self-supervised forced choices."""

    def __init__(self) -> None:
        self.objects: Dict[str, LatentObject] = {}
        self.sequence = 0

    def act(self, event: LatentEvent, forced_slot_id: str | None = None) -> None:
        sequence = self.sequence
        self.sequence += 1
        if event.kind == LatentEventKind.DISCOVER:
            examples = _decode_examples(event.payload["examples"])
            context = _decode_rows(event.payload["context"])
            metadata = dict(event.payload["metadata"])
            expression = infer_fixed_schema(examples, context, metadata)
            if expression is None:
                return
            slot_id = "slot-%04d" % len(self.objects)
            self.objects[slot_id] = LatentObject(
                slot_id=slot_id,
                expression=expression,
                examples=examples,
                context=context,
                metadata=metadata,
                aliases=(event.alias,),
                created_at=sequence,
                last_touched=sequence,
            )
            return
        if forced_slot_id is None or forced_slot_id not in self.objects:
            return
        obj = self.objects[forced_slot_id]
        if event.kind == LatentEventKind.ATTACH:
            rows = _decode_rows(event.payload["rows"])
            existing = {row.row_id for row in obj.context}
            obj.context = (
                *obj.context,
                *(row for row in rows if row.row_id not in existing),
            )
        elif event.kind == LatentEventKind.UPDATE:
            desired = _decode_examples(event.payload["desired_examples"])
            revised = _fixed_repair(obj, desired)
            if revised is not None:
                obj.expression = revised.expression
                obj.context = revised.context
        obj.aliases = (*obj.aliases, event.alias)
        obj.last_touched = sequence


def build_predicate_discovery_trace(
    stream: CandidateVisibleEventStream,
) -> PredicateDiscoveryTrace:
    pool = enumerate_behavioral_predicates()
    runtime = _ForcedFixedRuntime()
    contrasts = []
    exposed = []
    for event in stream.events:
        if event.kind == LatentEventKind.DISCOVER:
            runtime.act(event)
            continue
        costs = {
            slot_id: _raw_consequence_cost(event, obj)
            for slot_id, obj in runtime.objects.items()
        }
        values = {
            slot_id: {
                program.program_id: evaluate_behavioral_predicate(
                    program, event, obj, runtime.sequence
                )
                for program in pool
            }
            for slot_id, obj in runtime.objects.items()
        }
        chosen = min(
            costs,
            key=lambda slot_id: (costs[slot_id], slot_id),
        )
        contrasts.append(
            PredicateContrast(event.event_id, chosen, costs, values)
        )
        exposed.append(event.event_id)
        runtime.act(event, chosen)
    return PredicateDiscoveryTrace(
        development_registry_id=stream.registry_id,
        candidate_stream_id=stream.stream_id,
        predicate_pool=pool,
        contrasts=tuple(contrasts),
        exposed_event_ids=tuple(exposed),
        objective=(
            "synthesize compact predicates whose values rank event-slot pairs by "
            "candidate-visible replay and local-intervention consistency"
        ),
    )


@dataclass(frozen=True)
class DiscoveredPredicateModel:
    programs: Tuple[BehavioralPredicateProgram, ...]
    weights: Tuple[float, ...]
    discovery_trace_id: str
    pool_size: int
    training_steps: int
    learning_rate: float

    @property
    def model_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def score(self, values: Mapping[str, float]) -> float:
        return sum(
            weight * values[program.program_id]
            for program, weight in zip(self.programs, self.weights)
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": BEHAVIORAL_PREDICATE_DISCOVERY_VERSION,
            "programs": [item.as_dict() for item in self.programs],
            "weights": list(self.weights),
            "discovery_trace_id": self.discovery_trace_id,
            "pool_size": self.pool_size,
            "selected_program_count": len(self.programs),
            "training_steps": self.training_steps,
            "learning_rate": self.learning_rate,
        }
        if include_id:
            value["model_id"] = self.model_id
        return value


def synthesize_predicate_model(
    trace: PredicateDiscoveryTrace,
    *,
    max_programs: int = 8,
    steps: int = 800,
    learning_rate: float = 0.15,
) -> DiscoveredPredicateModel:
    pair_rows = []
    for contrast in trace.contrasts:
        positive = contrast.predicate_values_by_slot[contrast.chosen_slot_id]
        positive_cost = contrast.consequence_cost_by_slot[
            contrast.chosen_slot_id
        ]
        for slot_id, negative in contrast.predicate_values_by_slot.items():
            if slot_id == contrast.chosen_slot_id:
                continue
            if contrast.consequence_cost_by_slot[slot_id] <= positive_cost:
                continue
            pair_rows.append(
                {
                    program.program_id: (
                        positive[program.program_id]
                        - negative[program.program_id]
                    )
                    for program in trace.predicate_pool
                }
            )
    if not pair_rows:
        raise ValueError("predicate discovery found no ranked contrasts")
    ranked = []
    seen_signatures = set()
    for program in trace.predicate_pool:
        signature = tuple(round(row[program.program_id], 12) for row in pair_rows)
        alignment = sum(signature) / len(signature)
        magnitude = sum(abs(value) for value in signature) / len(signature)
        if magnitude == 0.0 or alignment <= 0.0 or signature in seen_signatures:
            continue
        seen_signatures.add(signature)
        ranked.append((alignment / magnitude, alignment, program.program_id, program))
    ranked.sort(reverse=True, key=lambda item: (item[0], item[1], item[2]))
    selected = tuple(item[3] for item in ranked[:max_programs])
    if not selected:
        raise ValueError("no consequence-aligned predicate program was synthesized")
    deltas = [
        [row[program.program_id] for program in selected]
        for row in pair_rows
    ]
    weights = [0.0 for _ in selected]
    for _ in range(steps):
        gradient = [0.0 for _ in selected]
        for delta in deltas:
            margin = sum(weight * value for weight, value in zip(weights, delta))
            scale = 1.0 / (1.0 + math.exp(min(40.0, max(-40.0, margin))))
            for index, value in enumerate(delta):
                gradient[index] -= scale * value
        for index in range(len(weights)):
            gradient[index] = gradient[index] / len(deltas) + 0.001 * weights[index]
            weights[index] -= learning_rate * gradient[index]
    return DiscoveredPredicateModel(
        programs=selected,
        weights=tuple(round(item, 12) for item in weights),
        discovery_trace_id=trace.trace_id,
        pool_size=len(trace.predicate_pool),
        training_steps=steps,
        learning_rate=learning_rate,
    )


class PredicateObjectRuntime:
    def __init__(
        self,
        model: DiscoveredPredicateModel,
        *,
        forced_slots: Mapping[str, str] | None = None,
    ) -> None:
        self.model = model
        self.forced_slots = dict(forced_slots or {})
        self.objects: Dict[str, LatentObject] = {}
        self.sequence = 0
        self.feature_evaluations = 0

    def feature_rows(
        self, event: LatentEvent
    ) -> Mapping[str, Mapping[str, float]]:
        return {
            slot_id: {
                program.program_id: evaluate_behavioral_predicate(
                    program, event, obj, self.sequence
                )
                for program in self.model.programs
            }
            for slot_id, obj in sorted(self.objects.items())
        }

    def _resolve(
        self, event: LatentEvent
    ) -> Tuple[LatentObject | None, Mapping[str, float]]:
        if event.event_id in self.forced_slots:
            slot_id = self.forced_slots[event.event_id]
            return self.objects.get(slot_id), {slot_id: float("inf")}
        rows = self.feature_rows(event)
        self.feature_evaluations += len(rows)
        if not rows:
            return None, {}
        scores = {slot_id: self.model.score(row) for slot_id, row in rows.items()}
        slot_id = max(
            scores,
            key=lambda item: (scores[item], self.objects[item].last_touched, item),
        )
        return self.objects[slot_id], scores

    def act(self, event: LatentEvent) -> LatentStep:
        sequence = self.sequence
        self.sequence += 1
        before = self.feature_evaluations
        scores: Mapping[str, float] = {}
        resolved: LatentObject | None = None
        if event.kind == LatentEventKind.DISCOVER:
            examples = _decode_examples(event.payload["examples"])
            context = _decode_rows(event.payload["context"])
            metadata = dict(event.payload["metadata"])
            expression = infer_fixed_schema(examples, context, metadata)
            if expression is None:
                action = LatentAction(
                    LatentActionKind.ABSTAIN,
                    {"reason": "no unique fixed schema"},
                )
            else:
                slot_id = "slot-%04d" % len(self.objects)
                resolved = LatentObject(
                    slot_id,
                    expression,
                    examples,
                    context,
                    metadata,
                    (event.alias,),
                    sequence,
                    sequence,
                )
                self.objects[slot_id] = resolved
                action = LatentAction(
                    LatentActionKind.DISCOVERED, {"accepted": True}
                )
        else:
            resolved, scores = self._resolve(event)
            if resolved is None:
                action = LatentAction(
                    LatentActionKind.ABSTAIN,
                    {"reason": "no compatible object"},
                )
            elif event.kind == LatentEventKind.ATTACH:
                rows = _decode_rows(event.payload["rows"])
                existing = {row.row_id for row in resolved.context}
                resolved.context = (
                    *resolved.context,
                    *(row for row in rows if row.row_id not in existing),
                )
                action = LatentAction(
                    LatentActionKind.ATTACHED, {"count": len(rows)}
                )
            elif event.kind in (LatentEventKind.QUERY, LatentEventKind.SELECT):
                value, used = _safe_fixed_execute(
                    resolved.expression,
                    tuple(event.payload["inputs"]),
                    resolved.context,
                )
                if value is None:
                    action = LatentAction(
                        LatentActionKind.ABSTAIN,
                        {"reason": "schema cannot execute query"},
                    )
                elif event.kind == LatentEventKind.QUERY:
                    action = LatentAction(
                        LatentActionKind.ANSWER, {"value": value}
                    )
                else:
                    action = LatentAction(
                        LatentActionKind.SELECTION, {"row_ids": list(used)}
                    )
            elif event.kind == LatentEventKind.UPDATE:
                desired = _decode_examples(event.payload["desired_examples"])
                revised = _fixed_repair(resolved, desired)
                if revised is None:
                    action = LatentAction(
                        LatentActionKind.ABSTAIN,
                        {"reason": "no unique fixed-schema repair"},
                    )
                else:
                    resolved.expression = revised.expression
                    resolved.context = revised.context
                    action = LatentAction(
                        LatentActionKind.UPDATED, {"accepted": True}
                    )
            else:  # pragma: no cover
                action = LatentAction(LatentActionKind.ABSTAIN, {})
            if resolved is not None:
                resolved.aliases = (*resolved.aliases, event.alias)
                resolved.last_touched = sequence
        return LatentStep(
            sequence,
            event,
            action,
            None if resolved is None else resolved.slot_id,
            scores,
            self.feature_evaluations - before,
        )


def evaluate_predicate_runtime(
    registry: LatentRegistry,
    model: DiscoveredPredicateModel,
    *,
    forced_slots: Mapping[str, str] | None = None,
) -> Tuple[LatentEvaluation, Tuple[LatentStep, ...]]:
    runtime = PredicateObjectRuntime(model, forced_slots=forced_slots)
    steps = tuple(runtime.act(event) for event in registry.events)
    by_event = {item.event.event_id: item for item in steps}
    expected_slot_by_object = {
        object_ref: by_event[event_id].resolved_slot_id
        for event_id, object_ref in registry.discovery_object_refs.items()
    }
    outcomes = tuple(
        LatentProbeOutcome(
            probe=probe,
            observed=by_event[probe.event_id].action,
            resolved_slot_id=by_event[probe.event_id].resolved_slot_id,
            expected_slot_id=expected_slot_by_object[probe.evaluator_object_ref],
            action_passed=(
                by_event[probe.event_id].action.kind == probe.expected_kind
                and by_event[probe.event_id].action.payload
                == probe.expected_payload
            ),
            address_passed=(
                by_event[probe.event_id].resolved_slot_id
                == expected_slot_by_object[probe.evaluator_object_ref]
            ),
        )
        for probe in registry.probes
    )
    families = sorted({item.probe.evaluator_family for item in outcomes})
    horizons = sorted({item.probe.horizon for item in outcomes})
    return (
        LatentEvaluation(
            address_mode="discovered_predicates",
            model_id=model.model_id,
            registry_id=registry.registry_id,
            outcomes=outcomes,
            family_scores={
                family: sum(
                    item.passed
                    for item in outcomes
                    if item.probe.evaluator_family == family
                )
                / sum(
                    item.probe.evaluator_family == family for item in outcomes
                )
                for family in families
            },
            horizon_scores={
                str(horizon): sum(
                    item.passed for item in outcomes if item.probe.horizon == horizon
                )
                / sum(item.probe.horizon == horizon for item in outcomes)
                for horizon in horizons
            },
            action_score=sum(item.action_passed for item in outcomes) / len(outcomes),
            address_score=sum(item.address_passed for item in outcomes) / len(outcomes),
            feature_evaluations=sum(item.feature_evaluations for item in steps),
            parameter_count=len(model.weights),
        ),
        steps,
    )


@dataclass(frozen=True)
class PredicateCoreFreeze:
    model: DiscoveredPredicateModel
    trace_id: str
    development_registry_id: str
    development_evaluation_id: str
    interpreter_source_digest: str
    freeze_stage: int

    @property
    def executable_digest(self) -> str:
        return content_digest(
            {
                "model": self.model.as_dict(),
                "interpreter_source_digest": self.interpreter_source_digest,
            }
        )

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": BEHAVIORAL_PREDICATE_DISCOVERY_VERSION,
            "model": self.model.as_dict(),
            "trace_id": self.trace_id,
            "development_registry_id": self.development_registry_id,
            "development_evaluation_id": self.development_evaluation_id,
            "interpreter_source_digest": self.interpreter_source_digest,
            "executable_digest": self.executable_digest,
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_predicate_core(
    *,
    model: DiscoveredPredicateModel,
    trace: PredicateDiscoveryTrace,
    development_evaluation: LatentEvaluation,
    interpreter_source_digest: str,
    freeze_stage: int = 4,
) -> PredicateCoreFreeze:
    if model.discovery_trace_id != trace.trace_id:
        raise ValueError("predicate model references another discovery trace")
    if development_evaluation.model_id != model.model_id:
        raise ValueError("development evaluation used another predicate model")
    if development_evaluation.joint_score < 0.95:
        raise ValueError("discovered predicates did not clear development floor")
    return PredicateCoreFreeze(
        model,
        trace.trace_id,
        trace.development_registry_id,
        development_evaluation.evaluation_id,
        interpreter_source_digest,
        freeze_stage,
    )


def run_predicate_causal_swap(
    registry: LatentRegistry, model: DiscoveredPredicateModel
) -> CausalAddressIntervention:
    normal, _ = evaluate_predicate_runtime(registry, model)
    candidates = tuple(
        item
        for item in normal.outcomes
        if item.probe.expected_kind == LatentActionKind.ANSWER
        and item.probe.horizon == 1
        and item.passed
    )
    left, right = next(
        (left, right)
        for left in candidates
        for right in candidates
        if left.probe.evaluator_family != right.probe.evaluator_family
        and left.observed.payload != right.observed.payload
    )
    forced = {
        left.probe.event_id: str(right.resolved_slot_id),
        right.probe.event_id: str(left.resolved_slot_id),
    }
    intervened, _ = evaluate_predicate_runtime(
        registry, model, forced_slots=forced
    )
    normal_by_probe = {item.probe.probe_id: item for item in normal.outcomes}
    changed = tuple(
        item.probe.probe_id
        for item in intervened.outcomes
        if item.observed != normal_by_probe[item.probe.probe_id].observed
        or item.resolved_slot_id
        != normal_by_probe[item.probe.probe_id].resolved_slot_id
    )
    targets = (left.probe.probe_id, right.probe.probe_id)
    non_targets = tuple(
        item for item in intervened.outcomes if item.probe.probe_id not in targets
    )
    invariance = sum(
        item.observed == normal_by_probe[item.probe.probe_id].observed
        and item.resolved_slot_id
        == normal_by_probe[item.probe.probe_id].resolved_slot_id
        for item in non_targets
    ) / len(non_targets)
    by_probe = {item.probe.probe_id: item for item in intervened.outcomes}
    return CausalAddressIntervention(
        registry.registry_id,
        targets,
        {
            left.probe.probe_id: str(left.resolved_slot_id),
            right.probe.probe_id: str(right.resolved_slot_id),
        },
        forced,
        changed,
        invariance,
        all(not by_probe[item].passed for item in targets),
    )


@dataclass(frozen=True)
class PredicateAuditTrial:
    candidate_freeze: PredicateCoreFreeze
    audit_commitment_id: str
    audit_materialization_id: str
    candidate_evaluations: Mapping[str, LatentEvaluation]
    v18_reference_scores: Mapping[str, float]
    evidence_mode_scores: Mapping[str, float]
    family_scores: Mapping[str, float]
    horizon_scores: Mapping[str, float]
    causal_intervention: CausalAddressIntervention
    check_results: Mapping[str, bool]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": BEHAVIORAL_PREDICATE_DISCOVERY_VERSION,
            "candidate_freeze": self.candidate_freeze.as_dict(),
            "audit_commitment_id": self.audit_commitment_id,
            "audit_materialization_id": self.audit_materialization_id,
            "candidate_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.candidate_evaluations.items())
            },
            "v18_reference_scores": dict(sorted(self.v18_reference_scores.items())),
            "evidence_mode_scores": dict(sorted(self.evidence_mode_scores.items())),
            "family_scores": dict(sorted(self.family_scores.items())),
            "horizon_scores": dict(sorted(self.horizon_scores.items())),
            "causal_intervention": self.causal_intervention.as_dict(),
            "check_results": dict(sorted(self.check_results.items())),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def run_predicate_audit(
    *,
    candidate_freeze: PredicateCoreFreeze,
    audit_commitment_id: str,
    audit_materialization_id: str,
    registries: Mapping[str, SelfSupervisedRegistry],
    causal_registry: SelfSupervisedRegistry,
    materialization_stage: int,
    v18_reference_model: SelfSupervisedAddressModel,
) -> PredicateAuditTrial:
    if candidate_freeze.freeze_stage >= materialization_stage:
        raise ValueError("predicate candidate was not frozen before audit")
    candidate = {
        key: evaluate_predicate_runtime(item.registry, candidate_freeze.model)[0]
        for key, item in registries.items()
    }
    reference = {
        key: (
            evaluate_latent_runtime(
                item.registry, address_mode="learned", model=v18_reference_model
            )[0].joint_score
            if not key.startswith("table-")
            else 0.0
        )
        for key, item in registries.items()
    }
    outcomes = tuple(
        outcome for evaluation in candidate.values() for outcome in evaluation.outcomes
    )
    families = sorted({item.probe.evaluator_family for item in outcomes})
    family_scores = {
        family: sum(
            item.passed for item in outcomes if item.probe.evaluator_family == family
        )
        / sum(item.probe.evaluator_family == family for item in outcomes)
        for family in families
    }
    horizons = sorted({item.probe.horizon for item in outcomes})
    horizon_scores = {
        str(horizon): sum(
            item.passed for item in outcomes if item.probe.horizon == horizon
        )
        / sum(item.probe.horizon == horizon for item in outcomes)
        for horizon in horizons
    }
    mode_values: Dict[str, list[bool]] = {mode: [] for mode in EVIDENCE_MODES}
    for key, evaluation in candidate.items():
        modes = registries[key].evidence_mode_by_event_id
        for outcome in evaluation.outcomes:
            mode = modes[outcome.probe.event_id]
            if mode in mode_values:
                mode_values[mode].append(outcome.passed)
    mode_scores = {
        mode: sum(values) / len(values)
        for mode, values in mode_values.items()
        if values
    }
    scores = {key: value.joint_score for key, value in candidate.items()}
    comparable = tuple(key for key in scores if not key.startswith("table-"))
    intervention = run_predicate_causal_swap(
        causal_registry.registry, candidate_freeze.model
    )
    checks = {
        "candidate_frozen_before_hidden_materialization": (
            candidate_freeze.freeze_stage < materialization_stage
        ),
        "fifteen_hidden_registries_cover_three_families": (
            len(registries) == 15
            and all(
                sum(key.startswith(prefix) for key in registries) == 5
                for prefix in ("numeric-", "relational-", "table-")
            )
        ),
        "every_hidden_registry_clears_ninety_percent": min(scores.values()) >= 0.90,
        "every_family_clears_ninety_five_percent": all(
            value >= 0.95 for value in family_scores.values()
        ),
        "every_evidence_mode_clears_ninety_five_percent": (
            set(mode_scores) == set(EVIDENCE_MODES)
            and all(value >= 0.95 for value in mode_scores.values())
        ),
        "all_horizons_through_sixty_four_clear_floor": all(
            value >= 0.95 for value in horizon_scores.values()
        ),
        "within_five_points_of_v18_on_comparable_families": (
            sum(scores[key] for key in comparable) / len(comparable)
            >= sum(reference[key] for key in comparable) / len(comparable) - 0.05
        ),
        "heldout_table_family_transfers": family_scores.get(
            "hidden_table_objects", 0.0
        ) >= 0.95,
        "predicate_compositions_were_selected_from_larger_pool": (
            0 < len(candidate_freeze.model.programs)
            <= 8
            < candidate_freeze.model.pool_size
        ),
        "causal_address_swap_is_selective": intervention.passed,
    }
    return PredicateAuditTrial(
        candidate_freeze,
        audit_commitment_id,
        audit_materialization_id,
        candidate,
        reference,
        mode_scores,
        family_scores,
        horizon_scores,
        intervention,
        checks,
        (
            "Predicate compositions are discovered, but their primitive execution, comparison, aggregation, and repair operators are engineered.",
            "Milestone 19 deliberately retains fixed schema inference and schema-specific local repair.",
            "The held-out lookup family is procedurally generated rather than a naturalistic external domain.",
        ),
    )
