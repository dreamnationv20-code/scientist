from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.behavioral_predicate_audit_authority_v19 import (
    PredicateAuditMaterialization,
)
from scientist.domains.cognitive_core.behavioral_predicate_discovery_v19 import (
    PredicateAuditTrial,
    PredicateCoreFreeze,
    PredicateDiscoveryTrace,
)
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    LatentAction,
    LatentActionKind,
    LatentEvaluation,
    LatentEventKind,
    LatentRegistry,
)
from scientist.domains.cognitive_core.latent_object_formation_verifier_v17 import (
    _independent_actions,
)
from scientist.domains.cognitive_core.self_supervised_object_discovery_v18 import (
    CandidateVisibleEventStream,
)
from scientist.program.control_plane import AutonomousScientistControlPlane


BEHAVIORAL_PREDICATE_VERIFIER_REF = (
    "cognitive-core-behavioral-predicate-independent-verifier-v19"
)


@dataclass(frozen=True)
class BehavioralPredicateVerification:
    check_results: Mapping[str, bool]
    cognitive_core_criteria: Mapping[str, bool]
    independent_match_rates: Mapping[str, float]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str = BEHAVIORAL_PREDICATE_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def predicate_discovery_milestone_demonstrated(self) -> bool:
        required = (
            "v18_address_features_are_absent",
            "predicate_compositions_are_selected_by_consequence",
            "unseen_behavioral_family_transfers",
            "persistent_objects_survive_lag_64",
            "discovered_addressing_has_selective_causal_effect",
        )
        return all(self.cognitive_core_criteria[item] for item in required)

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "cognitive_core_criteria": dict(
                sorted(self.cognitive_core_criteria.items())
            ),
            "independent_match_rates": dict(
                sorted(self.independent_match_rates.items())
            ),
            "predicate_discovery_milestone_demonstrated": (
                self.predicate_discovery_milestone_demonstrated
            ),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _independent_table_actions(registry: LatentRegistry) -> Mapping[str, LatentAction]:
    task_by_ref = {item.task_ref: item for item in registry.tasks}
    tables: Dict[str, Dict[Tuple[Any, ...], Any]] = {}
    actions = {}
    for event in registry.events:
        task_ref = registry.event_object_refs[event.event_id]
        task = task_by_ref[task_ref]
        if event.kind == LatentEventKind.DISCOVER:
            tables[task_ref] = {
                tuple(item.inputs): item.output for item in task.examples
            }
            actions[event.event_id] = LatentAction(
                LatentActionKind.DISCOVERED, {"accepted": True}
            )
        elif event.kind == LatentEventKind.ATTACH:
            actions[event.event_id] = LatentAction(
                LatentActionKind.ATTACHED, {"count": len(event.payload["rows"])}
            )
        elif event.kind == LatentEventKind.QUERY:
            actions[event.event_id] = LatentAction(
                LatentActionKind.ANSWER,
                {"value": tables[task_ref][tuple(event.payload["inputs"])]},
            )
        elif event.kind == LatentEventKind.SELECT:
            actions[event.event_id] = LatentAction(
                LatentActionKind.SELECTION, {"row_ids": []}
            )
        elif event.kind == LatentEventKind.UPDATE:
            tables[task_ref][task.query_inputs] = task.update_value
            actions[event.event_id] = LatentAction(
                LatentActionKind.UPDATED, {"accepted": True}
            )
    return actions


def _independent_joint_rate(
    registry: LatentRegistry, evaluation: LatentEvaluation
) -> float:
    if all(
        task.evaluator_family == "hidden_table_objects"
        for task in registry.tasks
    ):
        expected_actions = _independent_table_actions(registry)
    else:
        expected_actions = _independent_actions(registry)
    expected_slots = {}
    slot_index = 0
    for event in registry.events:
        if event.kind == LatentEventKind.DISCOVER:
            expected_slots[registry.discovery_object_refs[event.event_id]] = (
                "slot-%04d" % slot_index
            )
            slot_index += 1
    return sum(
        outcome.observed == expected_actions[outcome.probe.event_id]
        and outcome.resolved_slot_id
        == expected_slots[outcome.probe.evaluator_object_ref]
        for outcome in evaluation.outcomes
    ) / len(evaluation.outcomes)


def verify_behavioral_predicate_discovery(
    *,
    control: AutonomousScientistControlPlane,
    candidate_stream: CandidateVisibleEventStream,
    trace: PredicateDiscoveryTrace,
    candidate_freeze: PredicateCoreFreeze,
    materialization: PredicateAuditMaterialization,
    trial: PredicateAuditTrial,
    artifact_round_trip_checks: Mapping[str, bool],
) -> BehavioralPredicateVerification:
    visible_text = json.dumps(candidate_stream.as_dict(), sort_keys=True).lower()
    trace_text = json.dumps(trace.as_dict(), sort_keys=True).lower()
    hidden_event_ids = {
        event.event_id
        for item in materialization.registries.values()
        for event in item.registry.events
    }
    forbidden_v18_features = (
        "surface_overlap",
        "locator_fit",
        "locator_coverage",
        "type_compatibility",
        "mutation_feasible",
        "query_executable",
        "recency",
    )
    match_rates = {
        key: _independent_joint_rate(
            materialization.registries[key].registry, evaluation
        )
        for key, evaluation in trial.candidate_evaluations.items()
    }
    progress = control.graph.progress_by_role()["objective"]
    checks = {
        "all_artifacts_round_trip_exactly": (
            bool(artifact_round_trip_checks)
            and all(artifact_round_trip_checks.values())
        ),
        "candidate_stream_contains_no_evaluator_addresses_or_answers": all(
            token not in visible_text
            for token in (
                "task_ref",
                "object_ref",
                "evaluator_family",
                "update_address",
                "expected_payload",
            )
        ),
        "serialized_discovery_trace_contains_no_v18_address_features": all(
            token not in trace_text for token in forbidden_v18_features
        ),
        "predicate_model_is_bound_only_to_development_contrasts": (
            candidate_freeze.model.discovery_trace_id == trace.trace_id
            and candidate_freeze.trace_id == trace.trace_id
            and trace.candidate_stream_id == candidate_stream.stream_id
            and not hidden_event_ids.intersection(trace.exposed_event_ids)
        ),
        "predicate_programs_were_selected_from_a_larger_grammar": (
            0 < len(candidate_freeze.model.programs) <= 8
            < candidate_freeze.model.pool_size
            == len(trace.predicate_pool)
        ),
        "audit_materialized_after_predicate_freeze": (
            candidate_freeze.freeze_stage < materialization.materialization_stage
            and materialization.candidate_freeze_id == candidate_freeze.freeze_id
            and trial.candidate_freeze.freeze_id == candidate_freeze.freeze_id
        ),
        "all_preregistered_predicate_audits_pass": trial.passed,
        "independent_reconstruction_confirms_every_hidden_score": all(
            math.isclose(match_rates[key], evaluation.joint_score, abs_tol=1e-12)
            for key, evaluation in trial.candidate_evaluations.items()
        ),
        "causal_swap_changes_only_targeted_addresses": (
            trial.causal_intervention.passed
            and set(trial.causal_intervention.changed_probe_ids)
            == set(trial.causal_intervention.target_probe_ids)
        ),
        "objective_graph_is_not_advanced_by_microdomain_evidence": (
            progress["integrated"] == 0
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    criteria = {
        "v18_address_features_are_absent": checks[
            "serialized_discovery_trace_contains_no_v18_address_features"
        ],
        "predicate_compositions_are_selected_by_consequence": (
            checks["predicate_programs_were_selected_from_a_larger_grammar"]
            and candidate_freeze.model.training_steps > 0
        ),
        "unseen_behavioral_family_transfers": trial.check_results[
            "heldout_table_family_transfers"
        ],
        "persistent_objects_survive_lag_64": (
            trial.horizon_scores.get("64", 0.0) >= 0.95
        ),
        "discovered_addressing_has_selective_causal_effect": checks[
            "causal_swap_changes_only_targeted_addresses"
        ],
        "predicate_primitive_library_is_learned": False,
        "executable_schema_induction_is_self_supervised": False,
        "naturalistic_language_or_code_transfer_is_demonstrated": False,
        "general_cognitive_core_is_demonstrated": False,
    }
    return BehavioralPredicateVerification(
        checks,
        criteria,
        match_rates,
        (
            "A consequence-guided synthesizer selected interpretable behavioral "
            "predicate compositions without the V18 address features or identity "
            "labels, and the frozen representation transferred to three hidden "
            "families including a development-unseen lookup family."
        ),
        (
            "the predicate primitive library was learned from unrestricted raw data",
            "executable schemas were induced self-supervised",
            "the full cognitive core is solved",
            "natural-language or software-engineering transfer is established",
        ),
        (
            "Generic execute, compare, aggregate, time, and local-repair primitives remain engineered.",
            "Fixed schema inference and schema-specific mutation remain in the Milestone 19 runtime.",
            "All hidden families are procedural local generators.",
        ),
    )
