from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import (
    AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
    MetaRegistry,
    SynthesizedCandidateFreeze,
    build_meta_registry,
    make_numeric_task,
    make_relational_task,
)


BLIND_AUDIT_AUTHORITY_REF = "sealed-post-freeze-audit-authority-v16"


@dataclass(frozen=True)
class BlindAuditCommitment:
    commitment_digest: str
    promised_families: Tuple[str, ...]
    tasks_per_family: int
    materialization_rule: str
    authority_ref: str = BLIND_AUDIT_AUTHORITY_REF

    @property
    def commitment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "commitment_digest": self.commitment_digest,
            "promised_families": list(self.promised_families),
            "tasks_per_family": self.tasks_per_family,
            "materialization_rule": self.materialization_rule,
            "authority_ref": self.authority_ref,
        }
        if include_id:
            value["commitment_id"] = self.commitment_id
        return value


@dataclass(frozen=True)
class HiddenAuditMaterialization:
    commitment: BlindAuditCommitment
    candidate_freeze_id: str
    registries: Mapping[str, MetaRegistry]
    materialization_stage: int

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": AUTONOMOUS_CONCEPT_SYNTHESIS_VERSION,
            "commitment": self.commitment.as_dict(),
            "candidate_freeze_id": self.candidate_freeze_id,
            "registries": {
                key: item.as_dict()
                for key, item in sorted(self.registries.items())
            },
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


class BlindAuditAuthority:
    """Keeps audit instances private until a candidate identity is frozen."""

    def __init__(self, *, seed: int = 1609, tasks_per_family: int = 8) -> None:
        if tasks_per_family < 4:
            raise ValueError("blind audit needs at least four tasks per family")
        self._seed = int(seed)
        self._tasks_per_family = int(tasks_per_family)
        self._sealed_spec = {
            "seed": self._seed,
            "tasks_per_family": self._tasks_per_family,
            "numeric_moduli": (17, 19, 23, 29, 31, 37, 41, 43),
            "relational_path_lengths": (2, 3),
            "authority_ref": BLIND_AUDIT_AUTHORITY_REF,
        }
        self.commitment = BlindAuditCommitment(
            commitment_digest=content_digest(self._sealed_spec),
            promised_families=(
                "heldout_typed_numeric",
                "heldout_relational_composition",
            ),
            tasks_per_family=self._tasks_per_family,
            materialization_rule=(
                "instances and registry identities become available only to a "
                "frozen executable whose freeze stage precedes stage 5"
            ),
        )
        self._materialized = False

    def materialize(
        self,
        candidate_freeze: SynthesizedCandidateFreeze,
        *,
        materialization_stage: int = 5,
    ) -> HiddenAuditMaterialization:
        if self._materialized:
            raise ValueError("blind audit may be materialized only once")
        if candidate_freeze.freeze_stage >= materialization_stage:
            raise ValueError("candidate was not frozen before audit materialization")
        randomizer = random.Random(self._seed)
        moduli = self._sealed_spec["numeric_moduli"]
        numeric = []
        relational = []
        for index in range(self._tasks_per_family):
            modulus = moduli[index % len(moduli)]
            degree = 1 + (index % 2)
            coefficients = tuple(
                randomizer.randrange(modulus) for _ in range(degree + 1)
            )
            query = 5 + index
            revised = (coefficients[0] + index + 3) % modulus
            numeric.append(
                make_numeric_task(
                    task_ref="ha-%08x" % randomizer.getrandbits(32),
                    modulus=modulus,
                    coefficients=coefficients,
                    query=query,
                    revised_constant=revised,
                    family="heldout_typed_numeric",
                )
            )
            length = 2 + (index % 2)
            relations = tuple(
                "z%08x" % randomizer.getrandbits(32)
                for _ in range(length)
            )
            relational.append(
                make_relational_task(
                    task_ref="hb-%08x" % randomizer.getrandbits(32),
                    relations=relations,
                    chain_count=5,
                    revised_terminal="ht-%08x" % randomizer.getrandbits(32),
                    family="heldout_relational_composition",
                )
            )
        registries = {
            "typed_numeric": build_meta_registry(
                partition="audit",
                tasks=numeric,
                authority_ref=BLIND_AUDIT_AUTHORITY_REF,
                exposure_stage=materialization_stage,
            ),
            "relational_composition": build_meta_registry(
                partition="audit",
                tasks=relational,
                authority_ref=BLIND_AUDIT_AUTHORITY_REF,
                exposure_stage=materialization_stage,
            ),
        }
        self._materialized = True
        return HiddenAuditMaterialization(
            commitment=self.commitment,
            candidate_freeze_id=candidate_freeze.freeze_id,
            registries=registries,
            materialization_stage=materialization_stage,
        )

    def verify_commitment(
        self, materialization: HiddenAuditMaterialization
    ) -> bool:
        return (
            materialization.commitment == self.commitment
            and self.commitment.commitment_digest
            == content_digest(self._sealed_spec)
        )
