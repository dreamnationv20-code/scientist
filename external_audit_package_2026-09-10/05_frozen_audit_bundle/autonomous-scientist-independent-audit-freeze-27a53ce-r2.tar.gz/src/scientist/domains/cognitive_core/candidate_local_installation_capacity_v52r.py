from __future__ import annotations

import re
from functools import lru_cache
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.decoupled_relation_installation_v52q import (
    build_m52q_installation_rows,
)
from scientist.domains.cognitive_core.semantic_relation_competence_v52i import (
    semantic_relation_prompt,
)


CANDIDATE_LOCAL_INSTALLATION_CAPACITY_VERSION = (
    "general-cognitive-candidate-local-installation-capacity-v52r"
)
M52R_SEED = 52991
M52R_M52Q_AUDIT_ID = (
    "cc5c8a0dac042e871fa442f44c7a8552bc06f5dc18d5e87116cfce5a63cb3ecc"
)
_LOCAL_RESPONSE = re.compile(r"^\s*(YES|NO)\s*$", re.IGNORECASE)


@lru_cache(maxsize=1)
def build_m52r_candidate_local_rows() -> Tuple[Mapping[str, Any], ...]:
    unique: dict[tuple[str, ...], Mapping[str, Any]] = {}
    for row in build_m52q_installation_rows():
        metadata = row["metadata"]
        for slot in ("a", "b"):
            target = str(metadata[f"{slot}_relation_target"])
            candidate_key = str(metadata[f"candidate_{slot}_state_key"])
            candidate_text = str(metadata[f"candidate_{slot}_text"])
            identity = (
                str(metadata["family"]),
                str(metadata["basis_state_key"]),
                str(metadata["variant"]),
                candidate_key,
                target,
                candidate_text,
            )
            if identity in unique:
                continue
            record_id = "m52r-local-" + content_digest(
                {
                    "version": CANDIDATE_LOCAL_INSTALLATION_CAPACITY_VERSION,
                    "family": metadata["family"],
                    "basis_state_key": metadata["basis_state_key"],
                    "variant": metadata["variant"],
                    "candidate_state_key": candidate_key,
                    "target": target,
                }
            )[:24]
            unique[identity] = {
                "task": "candidate_local",
                "prompt": semantic_relation_prompt(
                    str(metadata["basis_text"]), candidate_text
                ),
                "completion": target,
                "metadata": {
                    "record_id": record_id,
                    "family": metadata["family"],
                    "variant": metadata["variant"],
                    "basis_state_key": metadata["basis_state_key"],
                    "candidate_state_key": candidate_key,
                    "basis_text": metadata["basis_text"],
                    "candidate_text": candidate_text,
                    "relation_target": target,
                },
            }
    return tuple(unique[key] for key in sorted(unique))


def parse_local_response(response: str) -> str | None:
    match = _LOCAL_RESPONSE.match(str(response))
    return None if match is None else match.group(1).upper()


def local_relation_records(
    rows: Sequence[Mapping[str, Any]], responses: Sequence[str]
) -> Tuple[Mapping[str, Any], ...]:
    if len(rows) != len(responses):
        raise ValueError("M52r local rows and responses must align")
    records = []
    for row, response in zip(rows, responses):
        metadata = row["metadata"]
        target = str(metadata["relation_target"])
        prediction = parse_local_response(str(response))
        records.append(
            {
                "record_id": metadata["record_id"],
                "family": metadata["family"],
                "variant": metadata["variant"],
                "target": target,
                "prediction": prediction,
                "correct": prediction == target,
                "grammar_valid": prediction is not None,
                "response": str(response),
            }
        )
    return tuple(records)


def local_relation_metrics(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    def summary(selected: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        recalls = []
        for target in ("YES", "NO"):
            values = [
                bool(row["correct"]) for row in selected if row["target"] == target
            ]
            recalls.append(sum(values) / max(len(values), 1))
        return {
            "record_count": len(selected),
            "balanced_accuracy": sum(recalls) / 2.0,
            "yes_recall": recalls[0],
            "no_recall": recalls[1],
            "grammar_valid_rate": sum(bool(row["grammar_valid"]) for row in selected)
            / max(len(selected), 1),
        }

    return {
        **summary(records),
        "by_family": {
            family: summary([row for row in records if row["family"] == family])
            for family in sorted({str(row["family"]) for row in records})
        },
        "by_variant": {
            variant: summary([row for row in records if row["variant"] == variant])
            for variant in sorted({str(row["variant"]) for row in records})
        },
    }


def local_gate_passed(
    metrics: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_grammar_valid_rate": float(metrics["grammar_valid_rate"])
        >= float(contract["minimum_grammar_valid_rate"]),
        "minimum_balanced_accuracy": float(metrics["balanced_accuracy"])
        >= float(contract["minimum_balanced_accuracy"]),
        "minimum_yes_recall": float(metrics["yes_recall"])
        >= float(contract["minimum_each_label_recall"]),
        "minimum_no_recall": float(metrics["no_recall"])
        >= float(contract["minimum_each_label_recall"]),
        "minimum_each_family_accuracy": min(
            float(row["balanced_accuracy"])
            for row in metrics["by_family"].values()
        )
        >= float(contract["minimum_each_family_accuracy"]),
    }
    return all(checks.values()), checks


def select_earliest_capacity_pass(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    passing = [row for row in candidates if bool(row["passed"])]
    if not passing:
        return None
    return min(passing, key=lambda row: int(row["iteration"]))
