from __future__ import annotations

import hashlib
import itertools
import json
import random
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_HISTORY_PATTERNS,
    M50_MODEL_SNAPSHOT,
    M50_OUTPUT_ALGEBRAS,
    M50_REPRESENTATIONS,
    _history_variant,
    _support,
    _task_signature,
)
from scientist.domains.cognitive_core.causal_controller_installation_v52 import (
    _slot_difference_targets,
    build_m52_cases,
)
from scientist.domains.cognitive_core.causal_pointer_readout_repair_v52b import (
    build_m52b_cases,
)
from scientist.domains.cognitive_core.output_only_controller_v49 import (
    controller_prompt,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
)


CAUSAL_ACTUATOR_VALIDATION_VERSION = (
    "general-cognitive-causal-actuator-validation-v52c"
)
M52C_CONFIRMATION_SEED = 52409
M52C_CASES_PER_REPRESENTATION = 20
M52C_REPRESENTATIONS = M50_REPRESENTATIONS
M52C_M52_CHECKPOINT_SHA256 = (
    "08ec0414d6386ea340c9fa2c227f9b9872af939810101070329e82949e708982"
)
M52C_M52_RESULT_ID = (
    "e840cf07c8de9b968744b9f4a8851568dd981904d59b4cc74a0d2452c30c55a9"
)


def _stable_seed(representation: str, source_index: int) -> int:
    material = f"{M52C_CONFIRMATION_SEED}:{representation}:{source_index}"
    return int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)


def _two_candidate_task(
    representation: str, source_index: int
) -> Tuple[Any, Tuple[Any, ...], Tuple[Any, ...]] | None:
    rng = random.Random(_stable_seed(representation, source_index))
    source = _build_task("m52c_confirmation", representation, source_index, rng)
    base = _m43_experiment_task(source)
    if base is None:
        return None
    candidates = sorted(base.frontier, key=lambda item: item.key)
    for left, right in itertools.combinations(candidates, 2):
        provisional = replace(base, frontier=(left, right))
        equal, unequal = _support(provisional)
        if equal and unequal:
            task_id = "m52c-task-" + content_digest(
                {
                    "representation": representation,
                    "source_index": source_index,
                    "frontier": [left.key, right.key],
                    "version": CAUSAL_ACTUATOR_VALIDATION_VERSION,
                }
            )[:24]
            return replace(provisional, task_id=task_id), equal, unequal
    return None


@lru_cache(maxsize=None)
def build_m52c_cases(
    per_representation: int = M52C_CASES_PER_REPRESENTATION,
    representations: Tuple[str, ...] = M52C_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    target = int(per_representation)
    if target <= 0 or target % len(M50_HISTORY_PATTERNS):
        raise ValueError("M52c cases must be a positive multiple of history patterns")
    excluded = {
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52_cases(split)
    }
    excluded.update(
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52b_cases(split)
    )
    used = set(excluded)
    cases = []
    for representation in representations:
        found = 0
        source_index = 0
        while found < target:
            candidate = _two_candidate_task(representation, source_index)
            source_index += 1
            if candidate is None:
                if source_index > target * 500:
                    raise RuntimeError(f"could not build M52c {representation} cases")
                continue
            task, equal_values, unequal_values = candidate
            signature = _task_signature(task)
            if signature in used:
                continue
            length, evidence_slot = M50_HISTORY_PATTERNS[
                found % len(M50_HISTORY_PATTERNS)
            ]
            history = []
            for slot in range(1, length + 1):
                pool = unequal_values if slot == evidence_slot else equal_values
                value = pool[(found + slot) % len(pool)]
                history.append(
                    {
                        "slot": slot,
                        "turn": slot,
                        "experiment": value,
                        "outputs": list(raw_candidate_outputs(task, value)),
                        "response": "EXPERIMENT: " + json.dumps(value),
                    }
                )
            used.add(signature)
            episode_id = "m52c-episode-" + content_digest(
                {
                    "task_signature": signature,
                    "history": history,
                    "evidence_slot": evidence_slot,
                    "version": CAUSAL_ACTUATOR_VALIDATION_VERSION,
                }
            )[:24]
            cases.append(
                {
                    "episode_id": episode_id,
                    "task": task,
                    "task_signature": signature,
                    "representation": representation,
                    "output_algebra": M50_OUTPUT_ALGEBRAS[representation],
                    "prefix_length": length,
                    "evidence_slot": evidence_slot,
                    "history": tuple(history),
                }
            )
            found += 1
    return tuple(cases)


def informative_slots(history: Sequence[Mapping[str, Any]]) -> Tuple[int, ...]:
    slots = []
    for row in history:
        left, right = row["outputs"]
        if json.dumps(left, sort_keys=True, separators=(",", ":")) != json.dumps(
            right, sort_keys=True, separators=(",", ":")
        ):
            slots.append(int(row["slot"]))
    return tuple(slots)


def execute_actuator_action(
    history: Sequence[Mapping[str, Any]], action: int, phase: str
) -> Mapping[str, Any]:
    action = int(action)
    informative = informative_slots(history)
    if phase == "initial":
        correct = action == 0 and not informative
        return {
            "phase": phase,
            "action": action,
            "informative_slots": list(informative),
            "transitioned": bool(correct),
            "terminal": not bool(correct),
            "success": False,
        }
    if phase != "post_revision":
        raise ValueError("unknown M52c actuator phase")
    selected = action if 1 <= action <= len(history) else None
    success = selected is not None and selected in informative
    return {
        "phase": phase,
        "action": action,
        "informative_slots": list(informative),
        "selected_slot": selected,
        "transitioned": False,
        "terminal": True,
        "success": bool(success),
    }


def build_m52c_rows(
    per_representation: int = M52C_CASES_PER_REPRESENTATION,
    representations: Tuple[str, ...] = M52C_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for case in build_m52c_cases(per_representation, representations):
        variants = (
            ("initial", _history_variant(case["history"], None), 0),
            (
                "post_revision",
                _history_variant(case["history"], int(case["evidence_slot"])),
                int(case["evidence_slot"]),
            ),
        )
        for phase, history, expected_action in variants:
            record_id = "m52c-record-" + content_digest(
                {
                    "episode_id": case["episode_id"],
                    "phase": phase,
                    "version": CAUSAL_ACTUATOR_VALIDATION_VERSION,
                }
            )[:24]
            rows.append(
                {
                    "prompt": controller_prompt(case["task"], history),
                    "metadata": {
                        "record_id": record_id,
                        "episode_id": case["episode_id"],
                        "task_id": case["task"].task_id,
                        "task_signature": case["task_signature"],
                        "representation": case["representation"],
                        "output_algebra": case["output_algebra"],
                        "prefix_length": case["prefix_length"],
                        "evidence_slot": case["evidence_slot"],
                        "phase": phase,
                        "history": list(history),
                        "slot_difference_targets": list(
                            _slot_difference_targets(history)
                        ),
                        "action_target": expected_action,
                    },
                }
            )
    return tuple(rows)


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52c artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json_payload(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def _jsonl_payload(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    m52_root = project / "runs/cognitive_core/causal_controller_installation_v52"
    m52_result = json.loads((m52_root / "causal-controller-result.json").read_text())
    checkpoint = m52_root / "adapter/0000160_adapters.safetensors"
    return {
        "version": CAUSAL_ACTUATOR_VALIDATION_VERSION,
        "parent_version": "general-cognitive-causal-controller-installation-v52",
        "scientific_question": (
            "Is the frozen M52 internal causal action behaviorally sufficient when "
            "executed directly, without passing through the shared language decoder?"
        ),
        "confirmation_seed": M52C_CONFIRMATION_SEED,
        "representations": list(M52C_REPRESENTATIONS),
        "cases_per_representation": M52C_CASES_PER_REPRESENTATION,
        "history_patterns": [list(value) for value in M50_HISTORY_PATTERNS],
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "m52_checkpoint_iteration": 160,
            "m52_checkpoint_source": (
                "runs/cognitive_core/causal_controller_installation_v52/adapter/"
                "0000160_adapters.safetensors"
            ),
            "m52_checkpoint_sha256": _sha256(checkpoint),
            "m52_result_id": m52_result["result_id"],
        },
        "actuator_contract": {
            "model_weight_updates": 0,
            "language_decoder_calls": 0,
            "direct_action": "argmax_over_internal_revise_plus_slot_logits",
            "initial_transition": (
                "REVISE advances to the preregistered environment consequence only "
                "when no observed slot distinguishes the mechanisms"
            ),
            "terminal_transition": (
                "SELECT succeeds only when the selected observed slot actually has "
                "different executable candidate outputs"
            ),
            "pointer_rotated_control": (
                "cyclically_rotate present slot logits while preserving revise logit "
                "and the multiset of pointer values"
            ),
            "branch_only_control": (
                "preserve native revise/select branch but map every SELECT to slot one"
            ),
        },
        "confirmation_contract": {
            "minimum_direct_episode_success": 0.85,
            "minimum_each_representation_direct_episode_success": 0.80,
            "minimum_each_evidence_slot_direct_episode_success": 0.80,
            "minimum_initial_revise_accuracy": 0.90,
            "minimum_terminal_select_accuracy": 0.85,
            "minimum_gain_over_pointer_rotated_control": 0.30,
            "minimum_gain_over_branch_only_control": 0.30,
            "require_zero_trainable_tensors": True,
            "require_checkpoint_unchanged": True,
        },
        "integrity_contract": {
            "all_m52_and_m52b_mechanisms_excluded": True,
            "representations_balanced": True,
            "history_patterns_balanced_within_representation": True,
            "exact_two_phase_episodes": True,
            "terminal_success_recomputed_from_candidate_outputs": True,
            "no_training_or_checkpoint_selection": True,
        },
        "claim_boundary": (
            "M52c tests behavioral sufficiency of the frozen M52 structured causal "
            "actuator on fresh synthetic two-step episodes. Passing supports a dynamic "
            "pointer test; it does not establish variable-cardinality generalization, "
            "natural-task transfer, autonomous tool use, or general reasoning parity."
        ),
    }


def prepare_m52c_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol_payload = _protocol_payload(project)
    protocol = {**protocol_payload, "protocol_freeze_id": content_digest(protocol_payload)}
    _write_immutable(output / "protocol-freeze.json", _json_payload(protocol))
    rows = build_m52c_rows()
    row_hash = _write_immutable(
        output / "actuator/confirmation.jsonl", _jsonl_payload(rows)
    )
    payload = {
        **protocol,
        "hashes": {"confirmation": row_hash},
        "counts": {
            "records": len(rows),
            "episodes": len(rows) // 2,
            "episodes_by_representation": {
                representation: sum(
                    row["metadata"]["representation"] == representation
                    and row["metadata"]["phase"] == "initial"
                    for row in rows
                )
                for representation in M52C_REPRESENTATIONS
            },
        },
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    _write_immutable(output / "benchmark-freeze.json", _json_payload(freeze))
    verification = verify_m52c_benchmark(output, project)
    _write_immutable(output / "benchmark-verification.json", _json_payload(verification))
    return freeze


def _rows(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(json.loads(line) for line in path.read_text().splitlines() if line)


def verify_m52c_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol_payload = {
        key: value for key, value in protocol.items() if key != "protocol_freeze_id"
    }
    freeze_payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    path = output / "actuator/confirmation.jsonl"
    stored = _rows(path)
    groups: Dict[str, list[Mapping[str, Any]]] = {}
    for row in stored:
        groups.setdefault(row["metadata"]["episode_id"], []).append(row)
    exact_episodes = True
    environment_valid = True
    for group in groups.values():
        phases = {row["metadata"]["phase"] for row in group}
        exact_episodes = exact_episodes and len(group) == 2 and phases == {
            "initial",
            "post_revision",
        }
        if len(group) != 2 or phases != {"initial", "post_revision"}:
            continue
        initial = next(row for row in group if row["metadata"]["phase"] == "initial")
        post = next(
            row for row in group if row["metadata"]["phase"] == "post_revision"
        )
        evidence_slot = int(post["metadata"]["evidence_slot"])
        environment_valid = environment_valid and (
            informative_slots(initial["metadata"]["history"]) == ()
            and informative_slots(post["metadata"]["history"]) == (evidence_slot,)
            and initial["metadata"]["action_target"] == 0
            and post["metadata"]["action_target"] == evidence_slot
        )
    counts = freeze["counts"]["episodes_by_representation"]
    balanced = len(set(counts.values())) == 1
    patterns_balanced = True
    repeats = M52C_CASES_PER_REPRESENTATION // len(M50_HISTORY_PATTERNS)
    for representation in M52C_REPRESENTATIONS:
        initial = [
            row
            for row in stored
            if row["metadata"]["representation"] == representation
            and row["metadata"]["phase"] == "initial"
        ]
        pattern_counts = {
            pattern: sum(
                (
                    int(row["metadata"]["prefix_length"]),
                    int(row["metadata"]["evidence_slot"]),
                )
                == pattern
                for row in initial
            )
            for pattern in M50_HISTORY_PATTERNS
        }
        patterns_balanced = patterns_balanced and all(
            count == repeats for count in pattern_counts.values()
        )
    old_signatures = {
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52_cases(split)
    }
    old_signatures.update(
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52b_cases(split)
    )
    current = {row["metadata"]["task_signature"] for row in stored}
    checkpoint = project / freeze["frozen_model"]["m52_checkpoint_source"]
    m52_result = json.loads(
        (
            project
            / "runs/cognitive_core/causal_controller_installation_v52/causal-controller-result.json"
        ).read_text()
    )
    checks = {
        "protocol_id_is_content_derived": content_digest(protocol_payload)
        == protocol["protocol_freeze_id"],
        "freeze_id_is_content_derived": content_digest(freeze_payload)
        == freeze["freeze_id"],
        "confirmation_hash_matches": _sha256(path)
        == freeze["hashes"]["confirmation"],
        "rows_reproduce": stored == build_m52c_rows(),
        "exact_two_phase_episodes": exact_episodes,
        "environment_semantics_valid": environment_valid,
        "representations_balanced": balanced,
        "history_patterns_balanced": patterns_balanced,
        "all_m52_and_m52b_mechanisms_excluded": not bool(current & old_signatures),
        "m52_checkpoint_matches": _sha256(checkpoint)
        == freeze["frozen_model"]["m52_checkpoint_sha256"]
        == M52C_M52_CHECKPOINT_SHA256,
        "m52_result_matches": m52_result["result_id"]
        == freeze["frozen_model"]["m52_result_id"]
        == M52C_M52_RESULT_ID,
        "protocol_has_no_training_or_selection": (
            freeze["actuator_contract"]["model_weight_updates"] == 0
            and "training_recipe" not in freeze
            and "checkpoint_selection" not in freeze
        ),
    }
    return {
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def _summarize(
    records: Sequence[Mapping[str, Any]], condition: str
) -> Mapping[str, Any]:
    if not records:
        return {
            "episode_count": 0,
            "episode_success": 0.0,
            "initial_revise_accuracy": 0.0,
            "terminal_select_accuracy": 0.0,
        }
    return {
        "episode_count": len(records),
        "episode_success": sum(
            bool(row[f"{condition}_episode_success"]) for row in records
        )
        / len(records),
        "initial_revise_accuracy": sum(
            bool(row[f"{condition}_initial_correct"]) for row in records
        )
        / len(records),
        "terminal_select_accuracy": sum(
            bool(row[f"{condition}_terminal_correct"]) for row in records
        )
        / len(records),
    }


def actuator_metrics(
    records: Sequence[Mapping[str, Any]], condition: str
) -> Mapping[str, Any]:
    overall = _summarize(records, condition)
    return {
        **overall,
        "by_representation": {
            representation: _summarize(
                [row for row in records if row["representation"] == representation],
                condition,
            )
            for representation in M52C_REPRESENTATIONS
        },
        "by_evidence_slot": {
            str(slot): _summarize(
                [row for row in records if int(row["evidence_slot"]) == slot],
                condition,
            )
            for slot in range(1, 5)
        },
        "by_prefix_length": {
            str(length): _summarize(
                [row for row in records if int(row["prefix_length"]) == length],
                condition,
            )
            for length in range(1, 5)
        },
        "records": list(records),
    }


def m52c_passed(
    direct: Mapping[str, Any],
    rotated: Mapping[str, Any],
    branch_only: Mapping[str, Any],
    contract: Mapping[str, Any],
    *,
    trainable_tensor_count: int,
    checkpoint_unchanged: bool,
) -> Tuple[bool, Mapping[str, bool]]:
    direct_success = float(direct["episode_success"])
    checks = {
        "direct_episode_success": direct_success
        >= contract["minimum_direct_episode_success"],
        "each_representation_direct_episode_success": min(
            row["episode_success"] for row in direct["by_representation"].values()
        )
        >= contract["minimum_each_representation_direct_episode_success"],
        "each_evidence_slot_direct_episode_success": min(
            row["episode_success"] for row in direct["by_evidence_slot"].values()
        )
        >= contract["minimum_each_evidence_slot_direct_episode_success"],
        "initial_revise_accuracy": direct["initial_revise_accuracy"]
        >= contract["minimum_initial_revise_accuracy"],
        "terminal_select_accuracy": direct["terminal_select_accuracy"]
        >= contract["minimum_terminal_select_accuracy"],
        "gain_over_pointer_rotated_control": (
            direct_success - float(rotated["episode_success"])
            >= contract["minimum_gain_over_pointer_rotated_control"]
        ),
        "gain_over_branch_only_control": (
            direct_success - float(branch_only["episode_success"])
            >= contract["minimum_gain_over_branch_only_control"]
        ),
        "zero_trainable_tensors": (
            trainable_tensor_count == 0
            if contract["require_zero_trainable_tensors"]
            else True
        ),
        "checkpoint_unchanged": (
            checkpoint_unchanged
            if contract["require_checkpoint_unchanged"]
            else True
        ),
    }
    return all(checks.values()), checks
