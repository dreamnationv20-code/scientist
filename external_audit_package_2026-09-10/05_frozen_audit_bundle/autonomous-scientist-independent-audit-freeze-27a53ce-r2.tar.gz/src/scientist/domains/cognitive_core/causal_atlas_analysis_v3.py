from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Dict, List, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.causal_factorial_mlx_v3 import (
    CAUSAL_FACTORIAL_PROTOCOL_REF,
    CausalArmSpec,
    FactorialRunResult,
    factorial_arm_catalog,
)
from scientist.domains.cognitive_core.diagnosis_v3 import Intervention
from scientist.program.diagnostics import DiagnosticDisposition


CAUSAL_ATLAS_ANALYSIS_VERSION = "cognitive-core-empirical-causal-atlas-v3"
CAUSAL_ATLAS_EFFECT_THRESHOLD = 0.04

FINAL_DIAGNOSTIC_METRICS = (
    "procedure_accuracy",
    "closed_book_accuracy",
    "oracle_evidence_accuracy",
    "irrelevant_evidence_accuracy",
    "conflicting_evidence_accuracy",
    "unknown_accuracy",
    "known_answer_destruction",
    "cognitive_core_score",
)

FROZEN_MODEL_PREDICTIONS: Mapping[str, Tuple[str, ...]] = {
    "null": (
        "No single-factor arm has a paired effect exceeding 0.04 after two-standard-error subtraction.",
        "Pairwise arms do not show a reproducible non-additive residual.",
    ),
    "capacity": (
        "Capacity headroom is the uniquely strongest single-factor response.",
        "The response is present at fixed raw corpus, order, routing cue, parameter count, and nominal FLOPs.",
    ),
    "kinetics": (
        "Training-trajectory reordering is the uniquely strongest single-factor response.",
        "Checkpoint effects precede or exceed final effects at fixed example multiset and optimizer-step count.",
    ),
    "representation": (
        "Representation factorization is the uniquely strongest single-factor response.",
        "The response occurs at equal active width per task and without a routing annotation.",
    ),
    "routing": (
        "Source control is the uniquely strongest single-factor response.",
        "Its largest effects are concentrated in evidence-sensitive metrics rather than raw procedure accuracy.",
    ),
    "mixed": (
        "At least two single-factor responses are independently detectable.",
        "The corresponding pairwise arm distinguishes additive from interaction-dependent explanations.",
    ),
}


def frozen_causal_atlas_preregistration() -> Dict[str, Any]:
    return {
        "analysis_version": CAUSAL_ATLAS_ANALYSIS_VERSION,
        "protocol_ref": CAUSAL_FACTORIAL_PROTOCOL_REF,
        "effect_threshold": CAUSAL_ATLAS_EFFECT_THRESHOLD,
        "final_diagnostic_metrics": list(FINAL_DIAGNOSTIC_METRICS),
        "arms": [arm.as_dict() for arm in factorial_arm_catalog()],
        "model_predictions": {
            key: list(value)
            for key, value in sorted(FROZEN_MODEL_PREDICTIONS.items())
        },
        "selection_rule": (
            "A factor is active only if at least one final metric has "
            "abs(paired mean)-2*SE > 0.04. One active factor supports its "
            "pure model, two or more produce a mixed disposition, a tightly "
            "bounded absence supports null, and all other cases are inconclusive."
        ),
    }


@dataclass(frozen=True)
class PairedEffect:
    mean: float
    standard_error: float
    samples: Tuple[float, ...]

    @property
    def conservative_magnitude(self) -> float:
        return max(0.0, abs(self.mean) - 2.0 * self.standard_error)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "mean": self.mean,
            "standard_error": self.standard_error,
            "samples": list(self.samples),
            "conservative_magnitude": self.conservative_magnitude,
        }


@dataclass(frozen=True)
class EmpiricalCausalAtlas:
    effects: Mapping[str, Mapping[str, PairedEffect]]
    interaction_residuals: Mapping[str, Mapping[str, PairedEffect]]
    response_strengths: Mapping[str, float]
    active_factor_ids: Tuple[str, ...]
    model_scores: Mapping[str, float]
    supported_model_ids: Tuple[str, ...]
    disposition: DiagnosticDisposition
    seed_count: int
    effect_threshold: float
    verification_passed: bool
    analysis_version: str = CAUSAL_ATLAS_ANALYSIS_VERSION

    @property
    def resolved(self) -> bool:
        return (
            self.verification_passed
            and self.disposition != DiagnosticDisposition.INCONCLUSIVE
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "analysis_version": self.analysis_version,
            "effects": {
                arm: {
                    metric: estimate.as_dict()
                    for metric, estimate in sorted(metrics.items())
                }
                for arm, metrics in sorted(self.effects.items())
            },
            "interaction_residuals": {
                arm: {
                    metric: estimate.as_dict()
                    for metric, estimate in sorted(metrics.items())
                }
                for arm, metrics in sorted(
                    self.interaction_residuals.items()
                )
            },
            "response_strengths": dict(
                sorted(self.response_strengths.items())
            ),
            "active_factor_ids": list(self.active_factor_ids),
            "model_scores": dict(sorted(self.model_scores.items())),
            "supported_model_ids": list(self.supported_model_ids),
            "disposition": self.disposition.value,
            "seed_count": self.seed_count,
            "effect_threshold": self.effect_threshold,
            "verification_passed": self.verification_passed,
            "resolved": self.resolved,
        }


def empirical_causal_atlas_from_dict(
    value: Mapping[str, Any],
) -> EmpiricalCausalAtlas:
    def effect(item: Mapping[str, Any]) -> PairedEffect:
        estimate = PairedEffect(
            mean=float(item["mean"]),
            standard_error=float(item["standard_error"]),
            samples=tuple(float(sample) for sample in item["samples"]),
        )
        supplied = item.get("conservative_magnitude")
        if supplied is not None and not math.isclose(
            float(supplied),
            estimate.conservative_magnitude,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            raise ValueError("causal atlas conservative magnitude mismatch")
        return estimate

    atlas = EmpiricalCausalAtlas(
        effects={
            str(arm): {
                str(metric): effect(estimate)
                for metric, estimate in metrics.items()
            }
            for arm, metrics in value["effects"].items()
        },
        interaction_residuals={
            str(arm): {
                str(metric): effect(estimate)
                for metric, estimate in metrics.items()
            }
            for arm, metrics in value["interaction_residuals"].items()
        },
        response_strengths={
            str(key): float(item)
            for key, item in value["response_strengths"].items()
        },
        active_factor_ids=tuple(
            str(item) for item in value["active_factor_ids"]
        ),
        model_scores={
            str(key): float(item) for key, item in value["model_scores"].items()
        },
        supported_model_ids=tuple(
            str(item) for item in value["supported_model_ids"]
        ),
        disposition=DiagnosticDisposition(value["disposition"]),
        seed_count=int(value["seed_count"]),
        effect_threshold=float(value["effect_threshold"]),
        verification_passed=bool(value["verification_passed"]),
        analysis_version=str(
            value.get("analysis_version", CAUSAL_ATLAS_ANALYSIS_VERSION)
        ),
    )
    if "resolved" in value and bool(value["resolved"]) != atlas.resolved:
        raise ValueError("causal atlas resolution mismatch")
    return atlas


def _mean_and_standard_error(samples: Sequence[float]) -> PairedEffect:
    if len(samples) < 2:
        raise ValueError("paired effect requires at least two seeds")
    mean = sum(samples) / float(len(samples))
    variance = sum((item - mean) ** 2 for item in samples) / float(
        len(samples) - 1
    )
    return PairedEffect(
        mean=mean,
        standard_error=math.sqrt(variance / len(samples)),
        samples=tuple(samples),
    )


def _checkpoint_metrics(run: FactorialRunResult) -> Dict[str, float]:
    values: Dict[str, float] = {}
    for checkpoint in run.checkpoints:
        if checkpoint.step == 0:
            continue
        for metric in (
            "procedure_accuracy",
            "closed_book_accuracy",
            "oracle_evidence_accuracy",
            "irrelevant_evidence_accuracy",
            "known_answer_destruction",
        ):
            values["step_%d.%s" % (checkpoint.step, metric)] = float(
                checkpoint.metrics[metric]
            )
    return values


def _all_metrics(run: FactorialRunResult) -> Dict[str, float]:
    values = {
        metric: float(run.metrics[metric])
        for metric in FINAL_DIAGNOSTIC_METRICS
    }
    values.update(_checkpoint_metrics(run))
    return values


def _single_arm_by_factor(
    arms: Mapping[str, CausalArmSpec],
) -> Dict[Intervention, str]:
    return {
        arm.factors[0]: arm_id
        for arm_id, arm in arms.items()
        if arm.causal_factor_count == 1
    }


def _score_models(
    strengths: Mapping[str, float],
    singles: Mapping[Intervention, str],
) -> Dict[str, float]:
    factor_ids = tuple(item.value for item in singles)
    scale = max(
        CAUSAL_ATLAS_EFFECT_THRESHOLD,
        max((strengths[singles[item]] for item in singles), default=0.0),
    )
    observed = {
        item.value: min(1.0, strengths[singles[item]] / scale)
        for item in singles
    }

    def score(active: Tuple[str, ...]) -> float:
        mse = sum(
            (
                observed[factor]
                - (1.0 if factor in active else 0.0)
            )
            ** 2
            for factor in factor_ids
        ) / float(len(factor_ids))
        # A small prospective complexity penalty prevents mixed from winning
        # merely by naming every response.
        return -(mse + 0.02 * len(active))

    scores = {"null": score(())}
    for factor in factor_ids:
        scores[factor] = score((factor,))
    for left in range(len(factor_ids)):
        for right in range(left + 1, len(factor_ids)):
            model_id = "mixed:%s+%s" % (
                factor_ids[left],
                factor_ids[right],
            )
            scores[model_id] = score(
                (factor_ids[left], factor_ids[right])
            )
    return scores


def build_empirical_causal_atlas(
    runs: Sequence[FactorialRunResult],
    *,
    verification_passed: bool,
) -> EmpiricalCausalAtlas:
    if not runs:
        raise ValueError("empirical atlas requires run evidence")
    arms = {run.arm.arm_id: run.arm for run in runs}
    seeds = tuple(sorted({run.config.model_seed for run in runs}))
    cells = {(run.config.model_seed, run.arm.arm_id): run for run in runs}
    if len(cells) != len(seeds) * len(arms) or "baseline" not in arms:
        raise ValueError("empirical atlas requires a complete seed-by-arm matrix")
    metric_names = tuple(sorted(_all_metrics(runs[0])))
    effects: Dict[str, Dict[str, PairedEffect]] = {}
    for arm_id in sorted(arms):
        if arm_id == "baseline":
            continue
        effects[arm_id] = {}
        for metric in metric_names:
            samples = tuple(
                _all_metrics(cells[(seed, arm_id)])[metric]
                - _all_metrics(cells[(seed, "baseline")])[metric]
                for seed in seeds
            )
            effects[arm_id][metric] = _mean_and_standard_error(samples)

    singles = _single_arm_by_factor(arms)
    interactions: Dict[str, Dict[str, PairedEffect]] = {}
    for arm_id, arm in sorted(arms.items()):
        if arm.causal_factor_count != 2:
            continue
        left_id, right_id = (singles[item] for item in arm.factors)
        interactions[arm_id] = {}
        for metric in metric_names:
            samples = tuple(
                (
                    _all_metrics(cells[(seed, arm_id)])[metric]
                    - _all_metrics(cells[(seed, "baseline")])[metric]
                )
                - (
                    _all_metrics(cells[(seed, left_id)])[metric]
                    - _all_metrics(cells[(seed, "baseline")])[metric]
                )
                - (
                    _all_metrics(cells[(seed, right_id)])[metric]
                    - _all_metrics(cells[(seed, "baseline")])[metric]
                )
                for seed in seeds
            )
            interactions[arm_id][metric] = _mean_and_standard_error(samples)

    strengths = {
        arm_id: max(
            effects[arm_id][metric].conservative_magnitude
            for metric in FINAL_DIAGNOSTIC_METRICS
        )
        for arm_id in effects
    }
    active = tuple(
        factor.value
        for factor, arm_id in singles.items()
        if strengths[arm_id] > CAUSAL_ATLAS_EFFECT_THRESHOLD
    )
    scores = _score_models(strengths, singles)
    ordered_scores = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    score_margin = (
        ordered_scores[0][1] - ordered_scores[1][1]
        if len(ordered_scores) > 1
        else 0.0
    )
    if not verification_passed:
        disposition = DiagnosticDisposition.INCONCLUSIVE
        supported: Tuple[str, ...] = ()
    elif len(active) == 1 and score_margin >= 0.03:
        disposition = DiagnosticDisposition.SUPPORTED
        supported = (active[0],)
    elif len(active) >= 2:
        disposition = DiagnosticDisposition.MIXED
        supported = tuple(
            model_id
            for model_id, _ in ordered_scores[:1]
            if model_id.startswith("mixed:")
        )
        if not supported:
            disposition = DiagnosticDisposition.INCONCLUSIVE
    else:
        null_tightly_bounded = all(
            abs(estimate.mean) + 2.0 * estimate.standard_error
            <= CAUSAL_ATLAS_EFFECT_THRESHOLD
            for factor, arm_id in singles.items()
            for metric, estimate in effects[arm_id].items()
            if metric in FINAL_DIAGNOSTIC_METRICS
        )
        if not active and null_tightly_bounded:
            disposition = DiagnosticDisposition.REFUTED
            supported = ("null",)
        else:
            disposition = DiagnosticDisposition.INCONCLUSIVE
            supported = ()
    return EmpiricalCausalAtlas(
        effects=effects,
        interaction_residuals=interactions,
        response_strengths=strengths,
        active_factor_ids=active,
        model_scores=scores,
        supported_model_ids=supported,
        disposition=disposition,
        seed_count=len(seeds),
        effect_threshold=CAUSAL_ATLAS_EFFECT_THRESHOLD,
        verification_passed=verification_passed,
    )
