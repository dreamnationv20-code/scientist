from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.domains.cognitive_core.causal_atlas_analysis_v3 import (
    CAUSAL_ATLAS_EFFECT_THRESHOLD,
    EmpiricalCausalAtlas,
    PairedEffect,
)
from scientist.domains.cognitive_core.diagnosis_v3 import Intervention


SIGNED_CAUSAL_AUDIT_VERSION = "cognitive-core-signed-causal-audit-v3"
SIGNED_CAUSAL_AUDIT_VERIFIER_REF = "signed-causal-audit-verifier-v3"


@dataclass(frozen=True)
class SignedFactorEffect:
    mean_utility_delta: float
    standard_error: float
    helpful_lower_bound: float
    harmful_lower_bound: float

    def as_dict(self) -> Dict[str, float]:
        return {
            "mean_utility_delta": self.mean_utility_delta,
            "standard_error": self.standard_error,
            "helpful_lower_bound": self.helpful_lower_bound,
            "harmful_lower_bound": self.harmful_lower_bound,
        }


@dataclass(frozen=True)
class SignedCausalAudit:
    factor_effects: Mapping[str, SignedFactorEffect]
    beneficial_leverage_ids: Tuple[str, ...]
    harmful_sensitivity_ids: Tuple[str, ...]
    causally_active_ids: Tuple[str, ...]
    checks: Mapping[str, bool]
    parent_model_update: Tuple[str, ...]
    prohibited_inferences: Tuple[str, ...]
    version: str = SIGNED_CAUSAL_AUDIT_VERSION

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "passed": self.passed,
            "factor_effects": {
                key: value.as_dict()
                for key, value in sorted(self.factor_effects.items())
            },
            "beneficial_leverage_ids": list(self.beneficial_leverage_ids),
            "harmful_sensitivity_ids": list(self.harmful_sensitivity_ids),
            "causally_active_ids": list(self.causally_active_ids),
            "checks": dict(sorted(self.checks.items())),
            "parent_model_update": list(self.parent_model_update),
            "prohibited_inferences": list(self.prohibited_inferences),
            "verifier_ref": SIGNED_CAUSAL_AUDIT_VERIFIER_REF,
        }


def _signed_effect(effect: PairedEffect) -> SignedFactorEffect:
    return SignedFactorEffect(
        mean_utility_delta=effect.mean,
        standard_error=effect.standard_error,
        helpful_lower_bound=max(
            0.0,
            effect.mean - 2.0 * effect.standard_error,
        ),
        harmful_lower_bound=max(
            0.0,
            -effect.mean - 2.0 * effect.standard_error,
        ),
    )


def audit_signed_causal_interpretation(
    atlas: EmpiricalCausalAtlas,
) -> SignedCausalAudit:
    singles = {
        arm_id: metrics["cognitive_core_score"]
        for arm_id, metrics in atlas.effects.items()
        if "+" not in arm_id
        and arm_id not in ("sham", "baseline")
    }
    required = {
        Intervention.CAPACITY_HEADROOM.value,
        Intervention.TRAINING_TRAJECTORY.value,
        Intervention.REPRESENTATION_FACTORIZATION.value,
        Intervention.SOURCE_CONTROL.value,
    }
    if set(singles) != required:
        raise ValueError("signed audit requires all four single-factor effects")
    factor_effects = {
        arm_id: _signed_effect(effect)
        for arm_id, effect in singles.items()
    }
    beneficial = tuple(
        arm_id
        for arm_id in sorted(factor_effects)
        if factor_effects[arm_id].helpful_lower_bound
        > CAUSAL_ATLAS_EFFECT_THRESHOLD
    )
    harmful = tuple(
        arm_id
        for arm_id in sorted(factor_effects)
        if factor_effects[arm_id].harmful_lower_bound
        > CAUSAL_ATLAS_EFFECT_THRESHOLD
    )
    active = tuple(
        arm_id
        for arm_id in sorted(factor_effects)
        if max(
            factor_effects[arm_id].helpful_lower_bound,
            factor_effects[arm_id].harmful_lower_bound,
        )
        > CAUSAL_ATLAS_EFFECT_THRESHOLD
    )
    sham = atlas.effects["sham"]["cognitive_core_score"]
    checks = {
        "upstream_factorial_verification_passed": atlas.verification_passed,
        "sham_utility_effect_is_exactly_zero": (
            sham.mean == 0.0 and sham.standard_error == 0.0
        ),
        "signed_and_absolute_roles_are_separated": (
            set(beneficial).isdisjoint(harmful)
        ),
        "at_least_one_beneficial_leverage_is_resolved": bool(beneficial),
        "harmful_intervention_is_not_called_a_beneficial_bottleneck": (
            Intervention.TRAINING_TRAJECTORY.value not in beneficial
        ),
        "routing_target_signature_is_positive": (
            atlas.effects[Intervention.SOURCE_CONTROL.value][
                "oracle_evidence_accuracy"
            ].mean
            - 2.0
            * atlas.effects[Intervention.SOURCE_CONTROL.value][
                "oracle_evidence_accuracy"
            ].standard_error
            > 0.4
        ),
    }
    parent_update = (
        "Pure single-mechanism explanations are inadequate at this micro horizon.",
        "Source routing is the strongest beneficial leverage; capacity allocation and representation factorization are smaller positive levers under the frozen threshold.",
        "Fully blocked training establishes severe path dependence and forgetting susceptibility, but its negative effect does not establish kinetics as a baseline bottleneck or repair target.",
        "Held-out model discrimination must test graded restorative interventions before architecture search begins.",
    )
    prohibited = (
        "Do not interpret the destructive blocked curriculum as evidence that more curriculum blocking will improve the baseline.",
        "Do not infer that source control is a deployable learned router; it is an oracle key-match intervention.",
        "Do not infer cross-scale, cross-task, or natural-language transport from this single micro horizon.",
        "Do not choose among the three beneficial levers until prospective held-out predictions distinguish pure and mixed models.",
    )
    return SignedCausalAudit(
        factor_effects=factor_effects,
        beneficial_leverage_ids=beneficial,
        harmful_sensitivity_ids=harmful,
        causally_active_ids=active,
        checks=checks,
        parent_model_update=parent_update,
        prohibited_inferences=prohibited,
    )
