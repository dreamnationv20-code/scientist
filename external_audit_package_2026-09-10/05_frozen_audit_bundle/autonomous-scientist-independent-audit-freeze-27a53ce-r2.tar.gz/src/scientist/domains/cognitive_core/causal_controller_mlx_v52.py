from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
import numpy as np
from mlx_lm.models.base import create_causal_mask


class CausalBottleneck(nn.Module):
    """Internal compare/aggregate/point controller installed after block 14."""

    def __init__(self, hidden_size: int, bottleneck_width: int = 64) -> None:
        super().__init__()
        self.difference_in = nn.Linear(hidden_size, bottleneck_width)
        self.difference_out = nn.Linear(bottleneck_width, 1)
        self.action_decoder = nn.Linear(5, hidden_size, bias=False)
        self.revise_threshold = mx.zeros((1,))

    def __call__(
        self, slot_states: mx.array, slot_mask: mx.array
    ) -> Tuple[mx.array, mx.array, mx.array]:
        features = nn.silu(self.difference_in(slot_states.astype(mx.float32)))
        raw_difference = self.difference_out(features).squeeze(-1)
        masked_difference = mx.where(
            slot_mask,
            raw_difference,
            mx.full(raw_difference.shape, -1e4, dtype=raw_difference.dtype),
        )
        revise = mx.broadcast_to(
            self.revise_threshold[None, :], (raw_difference.shape[0], 1)
        )
        action_logits = mx.concatenate((revise, masked_difference), axis=-1)
        action_code = mx.softmax(action_logits, axis=-1)
        return raw_difference, action_logits, action_code

    def decode(self, action_code: mx.array) -> mx.array:
        return self.action_decoder(action_code.astype(mx.float32))


class InstalledCausalController(nn.Module):
    def __init__(
        self,
        backbone: nn.Module,
        *,
        causal_layer: int = 14,
        bottleneck_width: int = 64,
    ) -> None:
        super().__init__()
        self.backbone = backbone
        self.causal_layer = int(causal_layer)
        self.bottleneck = CausalBottleneck(
            int(backbone.args.hidden_size), int(bottleneck_width)
        )

    @property
    def layers(self):
        return self.backbone.layers

    def _head_logits(self, h: mx.array) -> mx.array:
        out = self.backbone.model.norm(h)
        if self.backbone.args.tie_word_embeddings:
            return self.backbone.model.embed_tokens.as_linear(out)
        return self.backbone.lm_head(out)

    def encode_to_causal_site(
        self,
        inputs: mx.array,
        slot_positions: mx.array,
        slot_mask: mx.array,
    ) -> Tuple[mx.array, mx.array, mx.array, mx.array, mx.array]:
        h = self.backbone.model.embed_tokens(inputs)
        mask = create_causal_mask(h.shape[1])
        for index, layer in enumerate(self.backbone.model.layers, 1):
            h = layer(h, mask, None)
            if index == self.causal_layer:
                break
        batch_indices = mx.arange(h.shape[0])[:, None]
        safe_positions = mx.maximum(slot_positions, mx.array(0))
        slot_states = h[batch_indices, safe_positions]
        difference, action_logits, action_code = self.bottleneck(
            slot_states, slot_mask
        )
        return h, mask, difference, action_logits, action_code

    def continue_from_causal_site(
        self,
        h: mx.array,
        mask: mx.array,
        final_prompt_positions: mx.array,
        action_code: mx.array,
    ) -> mx.array:
        injection = self.bottleneck.decode(action_code).astype(h.dtype)
        positions = mx.arange(h.shape[1])[None, :]
        destination = positions == final_prompt_positions[:, None]
        h = h + destination[:, :, None].astype(h.dtype) * injection[:, None, :]
        for index, layer in enumerate(self.backbone.model.layers, 1):
            if index <= self.causal_layer:
                continue
            h = layer(h, mask, None)
        return self._head_logits(h)

    def forward_controller(
        self,
        inputs: mx.array,
        slot_positions: mx.array,
        slot_mask: mx.array,
        final_prompt_positions: mx.array,
        action_code_override: mx.array | None = None,
    ) -> Tuple[mx.array, mx.array, mx.array, mx.array]:
        h, mask, difference, action_logits, action_code = self.encode_to_causal_site(
            inputs, slot_positions, slot_mask
        )
        effective_code = action_code if action_code_override is None else action_code_override
        logits = self.continue_from_causal_site(
            h, mask, final_prompt_positions, effective_code
        )
        return logits, difference, action_logits, action_code


def _render_prompt(tokenizer: Any, prompt: str) -> str:
    return tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}],
        add_generation_prompt=True,
        tokenize=False,
    )


def prompt_token_layout(
    tokenizer: Any,
    prompt: str,
    history: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    rendered = _render_prompt(tokenizer, prompt)
    underlying = getattr(tokenizer, "_tokenizer", tokenizer)
    encoded = underlying(
        rendered,
        add_special_tokens=False,
        return_offsets_mapping=True,
    )
    prompt_tokens = tuple(int(item) for item in encoded["input_ids"])
    template_tokens = tuple(
        int(item)
        for item in tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}],
            add_generation_prompt=True,
            return_dict=False,
        )
    )
    if prompt_tokens != template_tokens:
        raise RuntimeError("M52 prompt tokenization does not match chat template")
    offsets = tuple((int(left), int(right)) for left, right in encoded["offset_mapping"])
    cursor = 0
    slot_positions = []
    for _ in history:
        start = rendered.find("    c2_output=", cursor)
        if start < 0:
            raise RuntimeError("could not locate an M52 c2 output line")
        end = rendered.find("\n", start)
        if end < 0:
            end = len(rendered)
        candidates = [
            index
            for index, (left, right) in enumerate(offsets)
            if right > start and left < end and right > left
        ]
        if not candidates:
            raise RuntimeError("could not bind an M52 output line to a token")
        slot_positions.append(max(candidates))
        cursor = end
    return {
        "rendered": rendered,
        "prompt_tokens": prompt_tokens,
        "slot_positions": tuple(slot_positions),
        "final_prompt_position": len(prompt_tokens) - 1,
    }


def tokenize_controller_row(tokenizer: Any, row: Mapping[str, Any]) -> Mapping[str, Any]:
    metadata = row["metadata"]
    layout = prompt_token_layout(tokenizer, row["prompt"], metadata["history"])
    messages = [{"role": "user", "content": row["prompt"]}]
    full_tokens = tuple(
        int(item)
        for item in tokenizer.apply_chat_template(
            messages + [{"role": "assistant", "content": row["completion"]}],
            return_dict=False,
        )
    )
    prompt_tokens = layout["prompt_tokens"]
    if full_tokens[: len(prompt_tokens)] != prompt_tokens:
        raise RuntimeError("M52 completion changed the frozen prompt prefix")
    if len(full_tokens) <= len(prompt_tokens):
        raise RuntimeError("M52 completion contains no supervised tokens")
    positions = list(layout["slot_positions"])
    targets = list(metadata["slot_difference_targets"])
    if len(positions) != int(metadata["prefix_length"]) or len(targets) != len(positions):
        raise RuntimeError("M52 slot positions do not align with causal targets")
    padded_positions = positions + [-1] * (4 - len(positions))
    padded_targets = targets + [0] * (4 - len(targets))
    slot_mask = [True] * len(positions) + [False] * (4 - len(positions))
    return {
        "tokens": full_tokens,
        "prompt_tokens": prompt_tokens,
        "final_prompt_position": int(layout["final_prompt_position"]),
        "completion_span": (len(prompt_tokens), len(full_tokens)),
        "slot_positions": tuple(padded_positions),
        "slot_mask": tuple(slot_mask),
        "difference_targets": tuple(padded_targets),
        "action_target": int(metadata["action_target"]),
        "metadata": metadata,
    }


class CausalPairDataset:
    def __init__(self, rows: Sequence[Mapping[str, Any]], tokenizer: Any) -> None:
        groups: dict[str, list[Mapping[str, Any]]] = {}
        for row in rows:
            groups.setdefault(row["metadata"]["intervention_pair_id"], []).append(row)
        pairs = []
        for pair_id, group in sorted(groups.items()):
            if len(group) != 2:
                raise ValueError(f"M52 pair {pair_id} does not contain two rows")
            null = next(row for row in group if row["metadata"]["variant"] == "output_null")
            evidence = next(
                row for row in group if row["metadata"]["variant"] == "output_evidence"
            )
            pairs.append((null, evidence))
        self.pairs = tuple(pairs)
        self.tokenizer = tokenizer
        self.cache: list[Any | None] = [None] * len(self.pairs)

    def __len__(self) -> int:
        return len(self.pairs)

    def __getitem__(self, index: int) -> Tuple[Mapping[str, Any], Mapping[str, Any]]:
        cached = self.cache[index]
        if cached is None:
            cached = tuple(
                tokenize_controller_row(self.tokenizer, row) for row in self.pairs[index]
            )
            self.cache[index] = cached
        return cached


def _pair_arrays(
    pair: Sequence[Mapping[str, Any]],
    tokenizer: Any,
    max_seq_length: int,
) -> Tuple[mx.array, ...]:
    lengths = [len(row["tokens"]) for row in pair]
    if max(lengths) > max_seq_length:
        raise ValueError("M52 refuses to truncate a causal training example")
    width = 1 + 32 * ((max(lengths) + 31) // 32)
    pad_id = getattr(tokenizer, "pad_token_id", None)
    if pad_id is None:
        pad_id = getattr(tokenizer, "eos_token_id", 0)
    tokens = np.full((2, width), int(pad_id), dtype=np.int32)
    spans = np.zeros((2, 2), dtype=np.int32)
    positions = np.zeros((2, 4), dtype=np.int32)
    masks = np.zeros((2, 4), dtype=np.bool_)
    differences = np.zeros((2, 4), dtype=np.float32)
    actions = np.zeros((2,), dtype=np.int32)
    for index, row in enumerate(pair):
        tokens[index, : lengths[index]] = row["tokens"]
        spans[index] = row["completion_span"]
        positions[index] = row["slot_positions"]
        masks[index] = row["slot_mask"]
        differences[index] = row["difference_targets"]
        actions[index] = row["action_target"]
    return (
        mx.array(tokens),
        mx.array(spans),
        mx.array(positions),
        mx.array(masks),
        mx.array(differences),
        mx.array(actions),
    )


def iterate_causal_pair_batches(
    dataset: CausalPairDataset,
    batch_size: int,
    max_seq_length: int,
    loop: bool = False,
    seed: int | None = 5201,
    comm_group: Any = None,
) -> Iterator[Tuple[mx.array, ...]]:
    del comm_group
    if batch_size != 1:
        raise ValueError("M52 frozen recipe uses one exact pair per microbatch")
    rng = np.random.default_rng(5201 if seed is None else seed)
    while True:
        for index in rng.permutation(len(dataset)):
            yield _pair_arrays(dataset[int(index)], dataset.tokenizer, max_seq_length)
        if not loop:
            break


def _binary_cross_entropy(logits: mx.array, targets: mx.array) -> mx.array:
    return mx.maximum(logits, 0.0) - logits * targets + mx.log1p(mx.exp(-mx.abs(logits)))


def causal_controller_loss(
    model: InstalledCausalController,
    batch: mx.array,
    spans: mx.array,
    slot_positions: mx.array,
    slot_mask: mx.array,
    difference_targets: mx.array,
    action_targets: mx.array,
) -> Tuple[mx.array, mx.array]:
    inputs = batch[:, :-1]
    targets = batch[:, 1:]
    final_prompt_positions = spans[:, 0] - 1
    h, mask, difference, action_logits, action_code = model.encode_to_causal_site(
        inputs, slot_positions, slot_mask
    )
    native_logits = model.continue_from_causal_site(
        h, mask, final_prompt_positions, action_code
    )
    steps = mx.arange(1, targets.shape[1] + 1)
    completion_mask = mx.logical_and(
        steps >= spans[:, 0:1], steps < spans[:, 1:2]
    )
    token_loss = nn.losses.cross_entropy(native_logits, targets).astype(mx.float32)
    token_count = mx.maximum(completion_mask.sum(), mx.array(1))
    completion_loss = (token_loss * completion_mask).sum() / token_count

    difference_loss_values = _binary_cross_entropy(
        difference.astype(mx.float32), difference_targets.astype(mx.float32)
    )
    difference_count = mx.maximum(slot_mask.sum(), mx.array(1))
    difference_loss = (
        difference_loss_values * slot_mask.astype(mx.float32)
    ).sum() / difference_count
    action_loss = nn.losses.cross_entropy(action_logits, action_targets).mean()

    donor_actions = action_targets[::-1]
    donor_code = mx.eye(5, dtype=mx.float32)[donor_actions]
    swapped_logits = model.continue_from_causal_site(
        h, mask, final_prompt_positions, donor_code
    )
    first_positions = spans[:, 0] - 1
    batch_indices = mx.arange(batch.shape[0])
    first_logits = swapped_logits[batch_indices, first_positions]
    native_first_targets = targets[batch_indices, first_positions]
    donor_first_targets = native_first_targets[::-1]
    interchange_loss = nn.losses.cross_entropy(
        first_logits, donor_first_targets
    ).mean()
    total = (
        completion_loss
        + difference_loss
        + action_loss
        + 0.75 * interchange_loss
    )
    return total, mx.array(1.0)


def load_jsonl(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    )
