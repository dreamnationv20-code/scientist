from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.causal_structure_atlas_v1 import ARM_ORDER
from scientist.program.causal_failure import (
    CausalFailureModel,
    CausalFailureModelSet,
    CausalRelationKind,
)
from scientist.program.research_kernel import PhenomenonAtlas, PhenomenonCase


VERSION = "cognitive-causal-structure-diagnosis-v1"


@dataclass(frozen=True)
class ReplaySpec:
    cluster_id: str
    baseline_arm: str
    alternative_arm: str
    cluster_description: str
    unavailable_information: str
    information_available_after: str
    irreversible_decision: str
    decision_point: str
    alternative_action: str
    changed_result: str
    causal_chain: str
    causal_relations: tuple[CausalRelationKind, ...]
    observable_proxies: tuple[str, ...]
    assumptions: tuple[str, ...]
    distinguishing_predictions: tuple[str, ...]
    falsification_conditions: tuple[str, ...]
    causal_signature: tuple[str, ...]
    information_regime: str
    mediator: str


REPLAY_SPECS = (
    ReplaySpec(
        cluster_id="decomposition-scaffold-availability",
        baseline_arm="direct",
        alternative_arm="incumbent_self_ask",
        cluster_description=(
            "A composed question fails under direct inference but succeeds when the "
            "model externalizes the two-hop decomposition."
        ),
        unavailable_information=(
            "an explicit intermediate-query schedule for the composed relation"
        ),
        information_available_after=(
            "the Self-Ask scaffold elicits follow-up questions and intermediate answers"
        ),
        irreversible_decision="commit directly to a composed answer",
        decision_point="before decomposing the composed question",
        alternative_action="externalize the constituent-question sequence",
        changed_result="the composed answer changes from incorrect to correct",
        causal_chain=(
            "missing decomposition schedule -> direct answer commitment -> externalized "
            "constituent sequence -> successful composition on rescued cases"
        ),
        causal_relations=(
            CausalRelationKind.STATE_SELECTS_POLICY,
            CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION,
        ),
        observable_proxies=(
            "follow-up protocol completion",
            "intermediate-answer emission",
            "direct-versus-decomposed paired accuracy",
        ),
        assumptions=(
            "the two arms use the same frozen model and composed question",
            "prompt length alone is not the causal mediator and requires a matched control later",
        ),
        distinguishing_predictions=(
            "decomposition helps when constituent relations are available but direct composition fails",
            "decomposition does not repair cases whose missing element is a constituent fact",
        ),
        falsification_conditions=(
            "a token-matched non-decomposition scaffold produces the same prospective gain",
            "decomposition provides no benefit on disjoint known-constituent failures",
        ),
        causal_signature=(
            "externalized_decomposition",
            "intermediate_query_schedule",
            "composed_answer",
        ),
        information_regime="composition schedule not explicit at direct-answer commitment",
        mediator="externalized constituent-query sequence",
    ),
    ReplaySpec(
        cluster_id="trusted-first-hop-state-availability",
        baseline_arm="incumbent_self_ask",
        alternative_arm="transaction_atomic_trusted",
        cluster_description=(
            "Self-Ask fails but an explicitly supplied, current, trusted first-hop state "
            "enables a correct second-hop composition."
        ),
        unavailable_information="the correct first-hop constituent value",
        information_available_after="the trusted first-hop value is committed as current state",
        irreversible_decision="continue composition from self-generated first-hop recall",
        decision_point="before selecting the first-hop value used for the second hop",
        alternative_action="install the trusted current first-hop state atomically",
        changed_result="the composed answer changes from incorrect to correct",
        causal_chain=(
            "first-hop value unavailable or unstable -> self-generated composition failure -> "
            "trusted state installation -> successful second-hop lookup on rescued cases"
        ),
        causal_relations=(
            CausalRelationKind.STATE_SELECTS_POLICY,
            CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION,
        ),
        observable_proxies=(
            "current first-hop value mention",
            "stale first-hop value mention",
            "atomic-state versus Self-Ask paired accuracy",
        ),
        assumptions=(
            "the supplied state contains neither the second-hop nor composed answer",
            "state-prompt overhead requires a cost-matched control before prospective promotion",
        ),
        distinguishing_predictions=(
            "trusted first-hop state helps only when the residual second-hop relation is available",
            "the same state is neutral or harmful when decomposition, provenance, or second-hop knowledge is limiting",
        ),
        falsification_conditions=(
            "shuffled first-hop values yield the same prospective benefit as correct values",
            "trusted first-hop state never rescues a disjoint Self-Ask failure",
        ),
        causal_signature=(
            "first_hop_availability",
            "explicit_current_state",
            "residual_second_hop_composition",
        ),
        information_regime="first-hop value externally available but absent from unaided inference",
        mediator="installed current first-hop state",
    ),
    ReplaySpec(
        cluster_id="interleaved-stale-write-hazard",
        baseline_arm="transaction_interleaved_trusted",
        alternative_arm="transaction_atomic_trusted",
        cluster_description=(
            "Content-identical current and stale states produce different answers when "
            "the stale write is interleaved rather than atomically invalidated."
        ),
        unavailable_information="whether a delayed stale write will compete after the current commit",
        information_available_after="the interleaved transaction schedule is serialized",
        irreversible_decision="resolve after exposing the delayed stale write",
        decision_point="when binding the current value for second-hop composition",
        alternative_action="commit current and invalidated values in one atomic transaction",
        changed_result="the composed answer changes from incorrect to correct",
        causal_chain=(
            "delayed conflicting state -> value-binding interference -> incorrect composition -> "
            "atomic invalidation removes the scheduling hazard and restores the answer"
        ),
        causal_relations=(
            CausalRelationKind.INFORMATION_REVEALED_AFTER_COMMITMENT,
            CausalRelationKind.COMMITMENT_DESTROYS_OPTION,
            CausalRelationKind.ALTERNATIVE_PRESERVES_OPTION,
            CausalRelationKind.PRESERVED_OPTION_CHANGES_OUTCOME,
        ),
        observable_proxies=(
            "current-versus-stale mention pattern",
            "atomic-versus-interleaved paired accuracy",
            "delayed-write conflict indicator",
        ),
        assumptions=(
            "the atomic and interleaved arms contain identical values and source roles",
            "word order is the manipulated transaction schedule rather than an incidental lexical cue",
        ),
        distinguishing_predictions=(
            "atomicity helps primarily when current and stale values conflict",
            "the atomic advantage vanishes when no delayed stale write is present",
        ),
        falsification_conditions=(
            "content-matched atomic and interleaved schedules show no prospective difference",
            "order-matched irrelevant text recreates the full atomic advantage",
        ),
        causal_signature=(
            "delayed_stale_write",
            "transaction_atomicity",
            "current_value_binding",
        ),
        information_regime="current and stale values both visible under different schedules",
        mediator="resistance to delayed stale-write interference",
    ),
    ReplaySpec(
        cluster_id="provenance-role-binding-contamination",
        baseline_arm="provenance_swapped_current",
        alternative_arm="transaction_atomic_trusted",
        cluster_description=(
            "The same current and stale values succeed under trusted-current provenance but "
            "fail when trusted and generated source roles are swapped."
        ),
        unavailable_information="which proposition source should authorize the current value",
        information_available_after="source roles are attached to the current and stale propositions",
        irreversible_decision="bind the current value to generated-unverified provenance",
        decision_point="when source role and version status jointly select the composition state",
        alternative_action="bind the current value to trusted-reference provenance",
        changed_result="the composed answer changes from incorrect to correct",
        causal_chain=(
            "current value receives low-trust provenance -> source-role conflict contaminates "
            "state use -> incorrect answer -> trusted-current binding restores successful composition"
        ),
        causal_relations=(
            CausalRelationKind.STATE_SELECTS_POLICY,
            CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION,
        ),
        observable_proxies=(
            "current-value source role",
            "stale-value source role",
            "trusted-current versus swapped-provenance paired accuracy",
        ),
        assumptions=(
            "the provenance pair preserves current value, stale value, and version status",
            "source-label wording requires independently phrased replication",
        ),
        distinguishing_predictions=(
            "trusted-current provenance outperforms generated-current provenance when values conflict",
            "the provenance effect shrinks when both propositions receive the same source role",
        ),
        falsification_conditions=(
            "independently paraphrased source labels eliminate the prospective effect",
            "swapping source roles without changing values never changes state uptake or accuracy",
        ),
        causal_signature=(
            "proposition_source_role",
            "version_status",
            "trusted_current_binding",
        ),
        information_regime="answer content fixed while proposition source roles are crossed",
        mediator="joint provenance-and-version binding",
    ),
)


def _receipt_id(case: PhenomenonCase, arm: str) -> str:
    if len(case.evidence_ids) != len(ARM_ORDER):
        raise ValueError("atlas case does not preserve the frozen arm receipt order")
    return case.evidence_ids[ARM_ORDER.index(arm)]


def build_replay_audit(atlas: PhenomenonAtlas) -> Mapping[str, Any]:
    clusters = []
    for spec in REPLAY_SPECS:
        rows = []
        for case in atlas.cases:
            baseline = int(case.outcome_metrics["%s_accuracy" % spec.baseline_arm])
            alternative = int(case.outcome_metrics["%s_accuracy" % spec.alternative_arm])
            effect = alternative - baseline
            rows.append(
                {
                    "case_id": case.case_id,
                    "case_ref": case.case_ref,
                    "regime": case.regime,
                    "horizon": case.horizon,
                    "baseline_correct": baseline,
                    "alternative_correct": alternative,
                    "effect": effect,
                    "baseline_evidence_id": _receipt_id(case, spec.baseline_arm),
                    "alternative_evidence_id": _receipt_id(case, spec.alternative_arm),
                    "trace_ref": case.trace_ref,
                }
            )
        positive = [row for row in rows if row["effect"] > 0]
        negative = [row for row in rows if row["effect"] < 0]
        nonzero = len(positive) + len(negative)
        clusters.append(
            {
                "cluster_id": spec.cluster_id,
                "baseline_arm": spec.baseline_arm,
                "alternative_arm": spec.alternative_arm,
                "n": len(rows),
                "positive_replays": len(positive),
                "negative_replays": len(negative),
                "neutral_replays": len(rows) - nonzero,
                "mean_paired_effect": sum(row["effect"] for row in rows) / len(rows),
                "directional_reliability": len(positive) / nonzero if nonzero else 0.0,
                "positive_case_ids": [row["case_id"] for row in positive],
                "negative_case_ids": [row["case_id"] for row in negative],
                "rows": rows,
            }
        )
    return {
        "version": VERSION,
        "atlas_id": atlas.atlas_id,
        "case_count": len(atlas.cases),
        "cluster_count": len(clusters),
        "clusters": clusters,
    }


def support_failures(audit: Mapping[str, Any]) -> tuple[str, ...]:
    failures = []
    clusters = audit["clusters"]
    if len(clusters) != len(REPLAY_SPECS):
        failures.append("incomplete_replay_specification")
    for row in clusters:
        cluster_id = str(row["cluster_id"])
        if int(row["positive_replays"]) < 1:
            failures.append("%s:no_positive_replay" % cluster_id)
        if float(row["mean_paired_effect"]) <= 0.0:
            failures.append("%s:nonpositive_full_panel_effect" % cluster_id)
    return tuple(failures)


def build_model_set(
    target_node_id: str,
    atlas: PhenomenonAtlas,
    audit: Mapping[str, Any],
) -> CausalFailureModelSet:
    failures = support_failures(audit)
    if failures:
        raise ValueError("replay support is incomplete: %s" % ", ".join(failures))
    by_cluster = {str(row["cluster_id"]): row for row in audit["clusters"]}
    models = []
    for spec in REPLAY_SPECS:
        summary = by_cluster[spec.cluster_id]
        positive_rows = [row for row in summary["rows"] if int(row["effect"]) > 0]
        evidence_ids = tuple(
            dict.fromkeys(
                evidence_id
                for row in positive_rows
                for evidence_id in (
                    str(row["baseline_evidence_id"]),
                    str(row["alternative_evidence_id"]),
                )
            )
        )
        models.append(
            CausalFailureModel(
                target_node_id=target_node_id,
                cluster_id=spec.cluster_id,
                cluster_description=spec.cluster_description,
                unavailable_information=spec.unavailable_information,
                information_available_after=spec.information_available_after,
                irreversible_decision=spec.irreversible_decision,
                decision_point=spec.decision_point,
                alternative_action=spec.alternative_action,
                changed_result=spec.changed_result,
                causal_chain=spec.causal_chain,
                causal_relations=spec.causal_relations,
                observable_proxies=spec.observable_proxies,
                evidence_ids=evidence_ids,
                assumptions=spec.assumptions,
                distinguishing_predictions=spec.distinguishing_predictions,
                falsification_conditions=spec.falsification_conditions,
                modeler_ref="deterministic-causal-replay-diagnostician-v1",
                decision_trace_ids=tuple(str(row["trace_ref"]) for row in positive_rows),
                causal_signature=spec.causal_signature,
                information_regime=spec.information_regime,
                mediator=spec.mediator,
                counterfactual_effect=float(summary["mean_paired_effect"]),
                proxy_reliability=float(summary["directional_reliability"]),
                empirically_supported=True,
            )
        )
    source_ids = tuple(
        dict.fromkeys(
            [
                evidence_id
                for model in models
                for evidence_id in model.evidence_ids
            ]
            + [atlas.atlas_id]
        )
    )
    return CausalFailureModelSet(
        target_node_id=target_node_id,
        failure_cluster_ids=tuple(spec.cluster_id for spec in REPLAY_SPECS),
        models=tuple(models),
        source_artifact_ids=source_ids,
        builder_ref="deterministic-causal-replay-diagnostician:v1",
    )


__all__ = [
    "REPLAY_SPECS",
    "VERSION",
    "ReplaySpec",
    "build_model_set",
    "build_replay_audit",
    "support_failures",
]
