from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
import platform
import time
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.diagnosis_v3 import Intervention
from scientist.domains.cognitive_core.learning import (
    ABSTAIN_CLASS,
    EVIDENCE_MATCH,
    LEARNING_CONTRACT_VERSION,
    NIBBLE_BASE,
    PAD,
    SEQUENCE_LENGTH,
    TASK_PROCEDURE,
    VOCAB_SIZE,
    EncodedExample,
    LearningConfig,
    evaluation_suite,
    family_counts,
    training_batch,
)


CAUSAL_FACTORIAL_LAB_VERSION = "cognitive-core-causal-factorial-mlx-v3"
CAUSAL_FACTORIAL_PROTOCOL_REF = "cognitive-core-matched-interventions-v3"
CAUSAL_FACTORIAL_EVALUATOR_REF = "causal-factorial-mlx-evaluator-v3"


@dataclass(frozen=True)
class CausalArmSpec:
    arm_id: str
    capacity_headroom: bool = False
    blocked_trajectory: bool = False
    factorized_representation: bool = False
    source_control: bool = False
    sham: bool = False

    def __post_init__(self) -> None:
        if not self.arm_id:
            raise ValueError("causal arm identity must not be empty")
        if self.sham and any(
            (
                self.capacity_headroom,
                self.blocked_trajectory,
                self.factorized_representation,
                self.source_control,
            )
        ):
            raise ValueError("sham must not activate a causal factor")

    @property
    def factors(self) -> Tuple[Intervention, ...]:
        values: List[Intervention] = []
        if self.capacity_headroom:
            values.append(Intervention.CAPACITY_HEADROOM)
        if self.blocked_trajectory:
            values.append(Intervention.TRAINING_TRAJECTORY)
        if self.factorized_representation:
            values.append(Intervention.REPRESENTATION_FACTORIZATION)
        if self.source_control:
            values.append(Intervention.SOURCE_CONTROL)
        if self.sham:
            values.append(Intervention.SHAM)
        return tuple(values)

    @property
    def causal_factor_count(self) -> int:
        return len(tuple(item for item in self.factors if item != Intervention.SHAM))

    def as_dict(self) -> Dict[str, Any]:
        return {
            "arm_id": self.arm_id,
            "capacity_headroom": self.capacity_headroom,
            "blocked_trajectory": self.blocked_trajectory,
            "factorized_representation": self.factorized_representation,
            "source_control": self.source_control,
            "sham": self.sham,
            "factors": [item.value for item in self.factors],
        }


BASELINE_ARM = CausalArmSpec("baseline")
SHAM_ARM = CausalArmSpec("sham", sham=True)


def _arm_id(factors: Sequence[Intervention]) -> str:
    return "+".join(item.value for item in factors)


def arm_for_factors(*factors: Intervention) -> CausalArmSpec:
    if not factors:
        return BASELINE_ARM
    if len(set(factors)) != len(factors):
        raise ValueError("causal arm factors must be unique")
    if Intervention.SHAM in factors:
        if len(factors) != 1:
            raise ValueError("sham cannot be combined with a causal factor")
        return SHAM_ARM
    supported = {
        Intervention.CAPACITY_HEADROOM,
        Intervention.TRAINING_TRAJECTORY,
        Intervention.REPRESENTATION_FACTORIZATION,
        Intervention.SOURCE_CONTROL,
    }
    if not set(factors).issubset(supported):
        raise ValueError("unsupported causal factor")
    return CausalArmSpec(
        arm_id=_arm_id(factors),
        capacity_headroom=Intervention.CAPACITY_HEADROOM in factors,
        blocked_trajectory=Intervention.TRAINING_TRAJECTORY in factors,
        factorized_representation=(
            Intervention.REPRESENTATION_FACTORIZATION in factors
        ),
        source_control=Intervention.SOURCE_CONTROL in factors,
    )


def factorial_arm_catalog(
    *,
    include_pairs: bool = True,
) -> Tuple[CausalArmSpec, ...]:
    causal = (
        Intervention.CAPACITY_HEADROOM,
        Intervention.TRAINING_TRAJECTORY,
        Intervention.REPRESENTATION_FACTORIZATION,
        Intervention.SOURCE_CONTROL,
    )
    arms: List[CausalArmSpec] = [BASELINE_ARM, SHAM_ARM]
    arms.extend(arm_for_factors(item) for item in causal)
    if include_pairs:
        arms.extend(
            arm_for_factors(causal[left], causal[right])
            for left in range(len(causal))
            for right in range(left + 1, len(causal))
        )
    return tuple(arms)


def _example_payload(example: EncodedExample) -> Dict[str, Any]:
    return {
        "tokens": list(example.tokens),
        "label": example.label,
        "family": example.family,
        "pair_id": example.pair_id,
    }


def _example_digest(example: EncodedExample) -> str:
    return content_digest(_example_payload(example))


@dataclass(frozen=True)
class FrozenTrainingPlan:
    batches: Tuple[Tuple[EncodedExample, ...], ...]
    raw_multiset_digest: str
    ordered_examples_digest: str
    family_counts: Mapping[str, int]
    example_count: int
    batch_size: int
    blocked: bool

    def as_dict(self, *, include_batches: bool = False) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "raw_multiset_digest": self.raw_multiset_digest,
            "ordered_examples_digest": self.ordered_examples_digest,
            "family_counts": dict(sorted(self.family_counts.items())),
            "example_count": self.example_count,
            "batch_size": self.batch_size,
            "step_count": len(self.batches),
            "blocked": self.blocked,
        }
        if include_batches:
            value["batches"] = [
                [_example_payload(example) for example in batch]
                for batch in self.batches
            ]
        return value


_FAMILY_BLOCK_ORDER = {
    "procedure": 0,
    "memory": 1,
    "oracle_evidence": 2,
    "irrelevant_evidence": 3,
    "conflicting_evidence": 4,
    "unknown": 5,
}


def build_frozen_training_plan(
    config: LearningConfig,
    *,
    blocked: bool,
) -> FrozenTrainingPlan:
    canonical = tuple(
        example
        for step in range(config.steps)
        for example in training_batch(config, step)
    )
    ordered: Tuple[EncodedExample, ...]
    if blocked:
        ordered = tuple(
            example
            for _, example in sorted(
                enumerate(canonical),
                key=lambda item: (
                    _FAMILY_BLOCK_ORDER[item[1].family],
                    item[0],
                ),
            )
        )
    else:
        ordered = canonical
    batches = tuple(
        tuple(ordered[start : start + config.batch_size])
        for start in range(0, len(ordered), config.batch_size)
    )
    if len(batches) != config.steps or any(
        len(batch) != config.batch_size for batch in batches
    ):
        raise AssertionError("frozen plan changed the training budget")
    example_digests = tuple(_example_digest(example) for example in ordered)
    return FrozenTrainingPlan(
        batches=batches,
        raw_multiset_digest=content_digest(sorted(example_digests)),
        ordered_examples_digest=content_digest(example_digests),
        family_counts=family_counts(ordered),
        example_count=len(ordered),
        batch_size=config.batch_size,
        blocked=blocked,
    )


def _decoded_key(tokens: Sequence[int], offset: int) -> int | None:
    high, low = tokens[offset], tokens[offset + 1]
    if high < NIBBLE_BASE or low < NIBBLE_BASE:
        return None
    return (high - NIBBLE_BASE) * 16 + (low - NIBBLE_BASE)


def annotate_source_control(tokens: Sequence[int]) -> Tuple[int, ...]:
    """Route matching evidence and suppress distractors using keys, not labels."""

    annotated = list(tokens)
    query = _decoded_key(tokens, 5)
    if query is None:
        return tuple(annotated)
    for key_offset, flag_offset in ((7, 10), (11, 14)):
        evidence_key = _decoded_key(tokens, key_offset)
        if evidence_key is None:
            annotated[flag_offset] = PAD
        elif evidence_key != query:
            annotated[key_offset : flag_offset + 1] = [PAD] * 4
        else:
            annotated[flag_offset] = EVIDENCE_MATCH
    return tuple(annotated)


def model_facing_tokens(
    examples: Sequence[EncodedExample],
    arm: CausalArmSpec,
) -> Tuple[Tuple[int, ...], ...]:
    values: List[Tuple[int, ...]] = []
    for example in examples:
        # Every arm computes the same key-match annotation. Source control only
        # determines whether that preregistered information is exposed.
        annotated = annotate_source_control(example.tokens)
        selected = annotated if arm.source_control else example.tokens
        if arm.sham:
            # A distinct, exactly reversible path is the negative intervention.
            selected = tuple(reversed(tuple(reversed(selected))))
        values.append(tuple(selected))
    return tuple(values)


class FactorizedCognitiveTransformer(nn.Module):
    """One full-width model with fixed masks implementing the causal factors."""

    def __init__(self, config: LearningConfig, arm: CausalArmSpec) -> None:
        super().__init__()
        if config.width % 4:
            raise ValueError("factorial lab width must be divisible by four")
        self.width = config.width
        self.base_active_width = config.width // 4
        self.active_width = (
            config.width // 2
            if arm.capacity_headroom
            else self.base_active_width
        )
        self.factorized_representation = arm.factorized_representation
        self.token_embedding = nn.Embedding(VOCAB_SIZE, config.width)
        self.position_embedding = nn.Embedding(SEQUENCE_LENGTH, config.width)
        self.layers = [
            nn.TransformerEncoderLayer(
                dims=config.width,
                num_heads=config.heads,
                mlp_dims=4 * config.width,
                dropout=0.0,
                norm_first=True,
            )
            for _ in range(config.layers)
        ]
        self.norm = nn.LayerNorm(config.width)
        self.output = nn.Linear(config.width, ABSTAIN_CLASS + 1)

    def _feature_mask(self, tokens: mx.array) -> mx.array:
        active = self.active_width
        procedure_values = [1.0] * active + [0.0] * (self.width - active)
        if self.factorized_representation:
            memory_values = (
                [0.0] * (self.width - active) + [1.0] * active
            )
        else:
            memory_values = procedure_values
        procedure_mask = mx.array(procedure_values).reshape((1, 1, self.width))
        memory_mask = mx.array(memory_values).reshape((1, 1, self.width))
        is_procedure = (tokens[:, 1] == TASK_PROCEDURE).reshape(
            (tokens.shape[0], 1, 1)
        )
        return mx.where(is_procedure, procedure_mask, memory_mask)

    def __call__(self, tokens: mx.array) -> mx.array:
        positions = mx.arange(tokens.shape[1])
        mask = self._feature_mask(tokens)
        hidden = (
            self.token_embedding(tokens)
            + self.position_embedding(positions)
        ) * mask
        for layer in self.layers:
            hidden = layer(hidden, None) * mask
        pooled = self.norm(hidden[:, 0, :]) * mask[:, 0, :]
        return self.output(pooled)


def factor_mask_signature(
    config: LearningConfig,
    arm: CausalArmSpec,
) -> Dict[str, Any]:
    active = config.width // 2 if arm.capacity_headroom else config.width // 4
    return {
        "full_width": config.width,
        "active_width_per_task": active,
        "procedure_dimensions": list(range(active)),
        "memory_dimensions": list(
            range(config.width - active, config.width)
            if arm.factorized_representation
            else range(active)
        ),
        "model_shape_changes": False,
    }


def _parameter_count(model: FactorizedCognitiveTransformer) -> int:
    return sum(
        math.prod(array.shape)
        for _, array in tree_flatten(model.parameters())
    )


def _parameter_digest(model: FactorizedCognitiveTransformer) -> str:
    digest = hashlib.sha256()
    for name, array in tree_flatten(model.parameters()):
        mx.eval(array)
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(array.shape)).encode("ascii"))
        digest.update(repr(array.tolist()).encode("utf-8"))
    return digest.hexdigest()


def _arrays(
    examples: Sequence[EncodedExample],
    arm: CausalArmSpec,
) -> Tuple[mx.array, mx.array]:
    return (
        mx.array(model_facing_tokens(examples, arm), dtype=mx.int32),
        mx.array([example.label for example in examples], dtype=mx.int32),
    )


def _predict(
    model: FactorizedCognitiveTransformer,
    examples: Sequence[EncodedExample],
    arm: CausalArmSpec,
    batch_size: int = 256,
) -> Tuple[int, ...]:
    predictions: List[int] = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        tokens, _ = _arrays(examples[start : start + batch_size], arm)
        batch_predictions = mx.argmax(model(tokens), axis=-1)
        mx.eval(batch_predictions)
        predictions.extend(int(value) for value in batch_predictions.tolist())
    model.train()
    return tuple(predictions)


def _evaluation_metrics(
    model: FactorizedCognitiveTransformer,
    examples: Sequence[EncodedExample],
    arm: CausalArmSpec,
) -> Dict[str, float]:
    predictions = _predict(model, examples, arm)
    correct: Dict[str, int] = {}
    total: Dict[str, int] = {}
    closed_book: Dict[str, bool] = {}
    irrelevant: Dict[str, bool] = {}
    for example, prediction in zip(examples, predictions):
        item_correct = prediction == example.label
        correct[example.family] = correct.get(example.family, 0) + int(
            item_correct
        )
        total[example.family] = total.get(example.family, 0) + 1
        if example.family == "closed_book":
            closed_book[example.pair_id] = item_correct
        elif example.family == "irrelevant_evidence":
            irrelevant[example.pair_id] = item_correct
    metrics = {
        family + "_accuracy": correct[family] / float(total[family])
        for family in sorted(total)
    }
    eligible = [pair for pair, item_correct in closed_book.items() if item_correct]
    metrics["known_answer_destruction"] = (
        sum(not irrelevant.get(pair, False) for pair in eligible)
        / float(len(eligible))
        if eligible
        else 0.0
    )
    components = (
        metrics["procedure_accuracy"],
        metrics["oracle_evidence_accuracy"],
        metrics["unknown_accuracy"],
        1.0 - metrics["known_answer_destruction"],
    )
    metrics["cognitive_core_score"] = math.prod(
        max(1e-6, component) for component in components
    ) ** (1.0 / len(components))
    return metrics


@dataclass(frozen=True)
class FactorialCheckpoint:
    step: int
    loss: float
    metrics: Mapping[str, float]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "loss": self.loss,
            "metrics": dict(sorted(self.metrics.items())),
        }


@dataclass(frozen=True)
class FactorialResourceLedger:
    parameter_count: int
    optimizer_steps: int
    training_examples: int
    raw_training_tokens: int
    evaluation_examples: int
    evaluation_passes: int
    full_width_token_passes: int
    nominal_transformer_flops: int

    @property
    def match_signature(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "parameter_count": self.parameter_count,
            "optimizer_steps": self.optimizer_steps,
            "training_examples": self.training_examples,
            "raw_training_tokens": self.raw_training_tokens,
            "evaluation_examples": self.evaluation_examples,
            "evaluation_passes": self.evaluation_passes,
            "full_width_token_passes": self.full_width_token_passes,
            "nominal_transformer_flops": self.nominal_transformer_flops,
        }


@dataclass(frozen=True)
class FactorialRunResult:
    run_id: str
    arm: CausalArmSpec
    config: LearningConfig
    initial_parameter_digest: str
    parameter_count: int
    raw_multiset_digest: str
    ordered_examples_digest: str
    model_input_digest: str
    model_input_flag_counts: Mapping[str, int]
    evaluation_digest: str
    mask_signature: Mapping[str, Any]
    resource_ledger: FactorialResourceLedger
    metrics: Mapping[str, float]
    checkpoints: Tuple[FactorialCheckpoint, ...]
    elapsed_seconds: float
    framework: str = "mlx-0.32"
    lab_version: str = CAUSAL_FACTORIAL_LAB_VERSION
    protocol_ref: str = CAUSAL_FACTORIAL_PROTOCOL_REF
    evaluator_ref: str = CAUSAL_FACTORIAL_EVALUATOR_REF

    def as_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "arm": self.arm.as_dict(),
            "config": self.config.as_dict(),
            "initial_parameter_digest": self.initial_parameter_digest,
            "parameter_count": self.parameter_count,
            "raw_multiset_digest": self.raw_multiset_digest,
            "ordered_examples_digest": self.ordered_examples_digest,
            "model_input_digest": self.model_input_digest,
            "model_input_flag_counts": dict(
                sorted(self.model_input_flag_counts.items())
            ),
            "evaluation_digest": self.evaluation_digest,
            "mask_signature": dict(self.mask_signature),
            "resource_ledger": {
                **self.resource_ledger.as_dict(),
                "match_signature": self.resource_ledger.match_signature,
            },
            "metrics": dict(sorted(self.metrics.items())),
            "checkpoints": [item.as_dict() for item in self.checkpoints],
            "elapsed_seconds": self.elapsed_seconds,
            "framework": self.framework,
            "hardware": platform.machine() + ":" + self.config.compute_device,
            "lab_version": self.lab_version,
            "learning_contract_version": LEARNING_CONTRACT_VERSION,
            "protocol_ref": self.protocol_ref,
            "evaluator_ref": self.evaluator_ref,
        }


def _evaluation_digest(examples: Iterable[EncodedExample]) -> str:
    return content_digest([_example_payload(example) for example in examples])


def _model_input_digest(
    plan: FrozenTrainingPlan,
    arm: CausalArmSpec,
) -> str:
    return content_digest(
        [
            list(tokens)
            for batch in plan.batches
            for tokens in model_facing_tokens(batch, arm)
        ]
    )


def _model_input_flag_counts(
    plan: FrozenTrainingPlan,
    arm: CausalArmSpec,
) -> Dict[str, int]:
    counts = {"retained_match": 0, "removed_nonmatch": 0}
    for batch in plan.batches:
        for example, tokens in zip(batch, model_facing_tokens(batch, arm)):
            annotated = annotate_source_control(example.tokens)
            for key_offset, flag_offset in ((7, 10), (11, 14)):
                counts["retained_match"] += int(
                    tokens[flag_offset] == EVIDENCE_MATCH
                )
                raw_key = _decoded_key(example.tokens, key_offset)
                query = _decoded_key(example.tokens, 5)
                counts["removed_nonmatch"] += int(
                    arm.source_control
                    and raw_key is not None
                    and query is not None
                    and raw_key != query
                    and all(
                        annotated[position] == PAD
                        for position in range(key_offset, flag_offset + 1)
                    )
                )
    return counts


def _resource_ledger(
    config: LearningConfig,
    parameter_count: int,
    evaluation_count: int,
) -> FactorialResourceLedger:
    checkpoint_passes = 1 + math.ceil(
        config.steps / float(config.checkpoint_interval)
    )
    evaluation_passes = checkpoint_passes + 1
    training_examples = config.steps * config.batch_size
    # A backward pass is conservatively counted as two forward equivalents.
    full_width_token_passes = SEQUENCE_LENGTH * (
        3 * training_examples + evaluation_passes * evaluation_count
    )
    per_token_flops = config.layers * 12 * config.width * config.width
    per_example_output_flops = 2 * config.width * (ABSTAIN_CLASS + 1)
    nominal_flops = (
        full_width_token_passes * per_token_flops
        + (
            3 * training_examples + evaluation_passes * evaluation_count
        )
        * per_example_output_flops
    )
    return FactorialResourceLedger(
        parameter_count=parameter_count,
        optimizer_steps=config.steps,
        training_examples=training_examples,
        raw_training_tokens=training_examples * SEQUENCE_LENGTH,
        evaluation_examples=evaluation_count,
        evaluation_passes=evaluation_passes,
        full_width_token_passes=full_width_token_passes,
        nominal_transformer_flops=nominal_flops,
    )


def train_factorial_arm(
    config: LearningConfig,
    arm: CausalArmSpec,
) -> FactorialRunResult:
    started = time.monotonic()
    if config.relevance_annotation:
        raise ValueError(
            "factorial source control requires unannotated frozen raw inputs"
        )
    mx.set_default_device(mx.cpu if config.compute_device == "cpu" else mx.gpu)
    plan = build_frozen_training_plan(
        config,
        blocked=arm.blocked_trajectory,
    )
    evaluation = evaluation_suite(config)
    mx.random.seed(config.model_seed)
    model = FactorizedCognitiveTransformer(config, arm)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    parameter_count = _parameter_count(model)
    optimizer = optim.AdamW(
        learning_rate=config.learning_rate,
        weight_decay=0.0001,
    )

    def loss_fn(
        active_model: FactorizedCognitiveTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens),
            labels,
            reduction="mean",
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    initial = _evaluation_metrics(model, evaluation, arm)
    checkpoints: List[FactorialCheckpoint] = [
        FactorialCheckpoint(step=0, loss=-1.0, metrics=initial)
    ]
    last_loss = float("nan")
    model.train()
    for step, batch in enumerate(plan.batches, start=1):
        tokens, labels = _arrays(batch, arm)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
        if step % config.checkpoint_interval == 0 or step == config.steps:
            checkpoints.append(
                FactorialCheckpoint(
                    step=step,
                    loss=last_loss,
                    metrics=_evaluation_metrics(model, evaluation, arm),
                )
            )
            model.train()
    metrics = _evaluation_metrics(model, evaluation, arm)
    metrics["final_training_loss"] = last_loss
    ledger = _resource_ledger(config, parameter_count, len(evaluation))
    payload = {
        "lab_version": CAUSAL_FACTORIAL_LAB_VERSION,
        "protocol_ref": CAUSAL_FACTORIAL_PROTOCOL_REF,
        "config": config.as_dict(),
        "arm": arm.as_dict(),
        "initial_parameter_digest": initial_parameter_digest,
        "raw_multiset_digest": plan.raw_multiset_digest,
        "ordered_examples_digest": plan.ordered_examples_digest,
        "evaluation_digest": _evaluation_digest(evaluation),
        "resource_signature": ledger.match_signature,
    }
    return FactorialRunResult(
        run_id=content_digest(payload)[:20],
        arm=arm,
        config=config,
        initial_parameter_digest=initial_parameter_digest,
        parameter_count=parameter_count,
        raw_multiset_digest=plan.raw_multiset_digest,
        ordered_examples_digest=plan.ordered_examples_digest,
        model_input_digest=_model_input_digest(plan, arm),
        model_input_flag_counts=_model_input_flag_counts(plan, arm),
        evaluation_digest=_evaluation_digest(evaluation),
        mask_signature=factor_mask_signature(config, arm),
        resource_ledger=ledger,
        metrics=metrics,
        checkpoints=tuple(checkpoints),
        elapsed_seconds=time.monotonic() - started,
    )
