from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.causal_factorial_mlx_v3 import (
    CAUSAL_FACTORIAL_EVALUATOR_REF,
    CausalArmSpec,
    FactorialRunResult,
)
from scientist.domains.cognitive_core.diagnosis_v3 import Intervention


CAUSAL_FACTORIAL_VERIFIER_REF = "causal-factorial-independent-verifier-v3"


@dataclass(frozen=True)
class FactorialVerificationReport:
    passed: bool
    checks: Mapping[str, bool]
    seed_count: int
    arm_count: int
    cell_count: int
    limitations: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "seed_count": self.seed_count,
            "arm_count": self.arm_count,
            "cell_count": self.cell_count,
            "limitations": list(self.limitations),
            "verifier_ref": CAUSAL_FACTORIAL_VERIFIER_REF,
        }


def _arm_fields(arm: CausalArmSpec) -> Tuple[bool, bool, bool, bool]:
    return (
        arm.capacity_headroom,
        arm.blocked_trajectory,
        arm.factorized_representation,
        arm.source_control,
    )


def _arm_contract_is_exact(arm: CausalArmSpec) -> bool:
    active = sum(_arm_fields(arm))
    if arm.arm_id == "baseline":
        return active == 0 and not arm.sham and not arm.factors
    if arm.sham:
        return (
            arm.arm_id == Intervention.SHAM.value
            and active == 0
            and arm.factors == (Intervention.SHAM,)
        )
    if active not in (1, 2) or arm.causal_factor_count != active:
        return False
    expected = "+".join(item.value for item in arm.factors)
    return arm.arm_id == expected


def _mask_contract_is_exact(result: FactorialRunResult) -> bool:
    signature = result.mask_signature
    width = result.config.width
    expected_active = width // 2 if result.arm.capacity_headroom else width // 4
    procedure = tuple(int(item) for item in signature["procedure_dimensions"])
    memory = tuple(int(item) for item in signature["memory_dimensions"])
    if (
        int(signature["full_width"]) != width
        or int(signature["active_width_per_task"]) != expected_active
        or bool(signature["model_shape_changes"])
        or len(procedure) != expected_active
        or len(memory) != expected_active
    ):
        return False
    if result.arm.factorized_representation:
        return not set(procedure).intersection(memory)
    return procedure == memory


def _metrics_identical(
    left: FactorialRunResult,
    right: FactorialRunResult,
) -> bool:
    if dict(left.metrics) != dict(right.metrics):
        return False
    return tuple(item.as_dict() for item in left.checkpoints) == tuple(
        item.as_dict() for item in right.checkpoints
    )


def verify_factorial_runs(
    runs: Sequence[FactorialRunResult],
    *,
    expected_seed_count: int = 6,
) -> FactorialVerificationReport:
    if not runs:
        raise ValueError("factorial verifier requires run evidence")
    arms = {run.arm.arm_id: run.arm for run in runs}
    seeds = {run.config.model_seed for run in runs}
    cells = {(run.config.model_seed, run.arm.arm_id): run for run in runs}
    baseline = {
        seed: cells.get((seed, "baseline"))
        for seed in seeds
    }
    sham = {seed: cells.get((seed, "sham")) for seed in seeds}

    complete = len(cells) == len(runs) == len(arms) * len(seeds)
    paired_initialization = all(
        len(
            {
                cells[(seed, arm_id)].initial_parameter_digest
                for arm_id in arms
                if (seed, arm_id) in cells
            }
        )
        == 1
        for seed in seeds
    ) if complete else False
    distinct_randomized_seeds = (
        len(
            {
                run.initial_parameter_digest
                for run in runs
                if run.arm.arm_id == "baseline"
            }
        )
        == len(seeds)
    )
    baseline_orders = {
        seed: baseline[seed].ordered_examples_digest
        for seed in seeds
        if baseline[seed] is not None
    }
    order_changes_only_for_kinetics = complete and all(
        (
            run.ordered_examples_digest != baseline_orders[run.config.model_seed]
        )
        == run.arm.blocked_trajectory
        for run in runs
    )
    input_groups: Dict[Tuple[int, bool, bool], set[str]] = {}
    for run in runs:
        key = (
            run.config.model_seed,
            run.arm.blocked_trajectory,
            run.arm.source_control,
        )
        input_groups.setdefault(key, set()).add(run.model_input_digest)
    input_changes_only_for_declared_factors = (
        all(len(values) == 1 for values in input_groups.values())
        and all(
            input_groups.get((seed, blocked, False))
            != input_groups.get((seed, blocked, True))
            for seed in seeds
            for blocked in (False, True)
            if (seed, blocked, True) in input_groups
        )
    )
    source_control_is_positive_manipulation = all(
        (
            run.model_input_flag_counts.get("retained_match", 0) > 0
            and run.model_input_flag_counts.get("removed_nonmatch", 0) > 0
        )
        if run.arm.source_control
        else (
            run.model_input_flag_counts.get("retained_match", 0) == 0
            and run.model_input_flag_counts.get("removed_nonmatch", 0) == 0
        )
        for run in runs
    )
    sham_is_exact_negative_control = complete and all(
        baseline[seed] is not None
        and sham[seed] is not None
        and baseline[seed].raw_multiset_digest == sham[seed].raw_multiset_digest
        and baseline[seed].ordered_examples_digest
        == sham[seed].ordered_examples_digest
        and baseline[seed].model_input_digest == sham[seed].model_input_digest
        and baseline[seed].mask_signature == sham[seed].mask_signature
        and _metrics_identical(baseline[seed], sham[seed])
        for seed in seeds
    )
    checks = {
        "complete_seed_by_arm_matrix": complete,
        "at_least_six_randomized_seeds": len(seeds) >= expected_seed_count,
        "all_arm_contracts_are_exact": all(
            _arm_contract_is_exact(arm) for arm in arms.values()
        ),
        "single_and_pairwise_interventions_present": (
            sum(arm.causal_factor_count == 1 for arm in arms.values()) == 4
            and sum(arm.causal_factor_count == 2 for arm in arms.values()) == 6
        ),
        "evaluator_and_verifier_are_independent": all(
            run.evaluator_ref == CAUSAL_FACTORIAL_EVALUATOR_REF
            and run.evaluator_ref != CAUSAL_FACTORIAL_VERIFIER_REF
            for run in runs
        ),
        "raw_training_multiset_is_exactly_shared": (
            len({run.raw_multiset_digest for run in runs}) == 1
        ),
        "evaluation_cases_are_exactly_shared": (
            len({run.evaluation_digest for run in runs}) == 1
        ),
        "parameter_count_is_exactly_shared": (
            len({run.parameter_count for run in runs}) == 1
        ),
        "resource_ledger_is_exactly_shared": (
            len({run.resource_ledger.match_signature for run in runs}) == 1
        ),
        "initial_parameters_are_paired_within_seed": paired_initialization,
        "randomized_seeds_have_distinct_initializations": (
            distinct_randomized_seeds
        ),
        "training_order_changes_only_for_kinetics": (
            order_changes_only_for_kinetics
        ),
        "model_inputs_change_only_for_kinetics_or_source_control": (
            input_changes_only_for_declared_factors
        ),
        "source_control_is_a_detectable_positive_manipulation": (
            source_control_is_positive_manipulation
        ),
        "feature_masks_implement_only_capacity_or_factorization": all(
            _mask_contract_is_exact(run) for run in runs
        ),
        "sham_is_an_exact_negative_control": sham_is_exact_negative_control,
    }
    limitations = (
        "Nominal FLOPs are matched exactly; wall-clock time is measured but not forced equal.",
        "Source control exposes exact key-match annotations and is therefore a do-style routing intervention, not a deployable learned router.",
        "The factorial lab diagnoses this fixed small-model testbed and does not itself establish cross-scale transport.",
    )
    return FactorialVerificationReport(
        passed=all(checks.values()),
        checks=checks,
        seed_count=len(seeds),
        arm_count=len(arms),
        cell_count=len(runs),
        limitations=limitations,
    )
