from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any, Dict, Mapping

import numpy as np
from safetensors import safe_open
from safetensors.numpy import save_file

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.general_contract_v27 import EvaluationGates


CAUSAL_INTERVENTION_VERSION = "general-cognitive-core-causal-intervention-v31"
RELATIONAL_OPERATIONS = (
    "causal_diagnosis",
    "latent_concept_invention",
    "representation_revision",
)
CONTROL_OPERATIONS = (
    "goal_decomposition",
    "tool_routing",
    "uncertainty_control",
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare_intervention_adapter(
    source: Path,
    destination: Path,
    intervention: str,
) -> Mapping[str, Any]:
    if intervention not in ("attention_ablation", "mlp_ablation", "recovery"):
        raise ValueError("unsupported intervention")
    source_weights = source / "adapters.safetensors"
    destination.mkdir(parents=True, exist_ok=True)
    with safe_open(source_weights, framework="numpy") as handle:
        metadata = handle.metadata()
        original = {key: handle.get_tensor(key) for key in handle.keys()}
    tensors: Dict[str, np.ndarray] = {}
    ablated = []
    preserved = []
    target_fragment = ".self_attn." if intervention == "attention_ablation" else ".mlp."
    for key, value in original.items():
        if intervention != "recovery" and target_fragment in key:
            tensors[key] = np.zeros_like(value)
            ablated.append(key)
        else:
            tensors[key] = value.copy()
            preserved.append(key)
    destination_weights = destination / "adapters.safetensors"
    save_file(tensors, destination_weights, metadata=metadata)
    shutil.copyfile(source / "adapter_config.json", destination / "adapter_config.json")
    verification = {
        "all_targeted_tensors_zero": all(not np.any(tensors[key]) for key in ablated),
        "all_preserved_tensors_exact": all(np.array_equal(tensors[key], original[key]) for key in preserved),
        "recovery_is_bitwise_equivalent_tensor_content": (
            intervention != "recovery"
            or all(np.array_equal(tensors[key], original[key]) for key in original)
        ),
    }
    payload = {
        "version": CAUSAL_INTERVENTION_VERSION,
        "intervention": intervention,
        "source_weights_sha256": _sha256(source_weights),
        "intervention_weights_sha256": _sha256(destination_weights),
        "ablated_tensor_count": len(ablated),
        "preserved_tensor_count": len(preserved),
        "ablated_keys": ablated,
        "verification": verification,
        "passed": all(verification.values()),
    }
    manifest = {**payload, "intervention_id": content_digest(payload)}
    (destination / "intervention-manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return manifest


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _specificity(
    intact_scores: Mapping[str, float],
    ablated_scores: Mapping[str, float],
    target_operations: tuple[str, ...],
    off_target_operations: tuple[str, ...],
    gates: EvaluationGates,
) -> Mapping[str, Any]:
    drops = {
        operation: float(intact_scores[operation]) - float(ablated_scores[operation])
        for operation in intact_scores
    }
    target_drop = _mean([drops[operation] for operation in target_operations])
    off_target_positive_drop = max(
        [max(0.0, drops[operation]) for operation in off_target_operations],
        default=0.0,
    )
    checks = {
        "target_drop": target_drop >= gates.minimum_selective_ablation_drop,
        "off_target_preserved": off_target_positive_drop <= gates.maximum_off_target_ablation_drop,
    }
    return {
        "drops_by_operation": drops,
        "target_operations": list(target_operations),
        "off_target_operations": list(off_target_operations),
        "mean_target_drop": target_drop,
        "maximum_off_target_positive_drop": off_target_positive_drop,
        "checks": checks,
        "selective": all(checks.values()),
    }


def finalize_causal_interventions(
    output_root: Path,
    intact_manifest_path: Path,
    attention_manifest_path: Path,
    mlp_manifest_path: Path,
    recovery_manifest_path: Path,
    *,
    interventions_root: Path,
    gates: EvaluationGates = EvaluationGates(),
) -> Mapping[str, Any]:
    manifests = {
        "intact": json.loads(intact_manifest_path.read_text(encoding="utf-8")),
        "attention_ablation": json.loads(attention_manifest_path.read_text(encoding="utf-8")),
        "mlp_ablation": json.loads(mlp_manifest_path.read_text(encoding="utf-8")),
        "recovery": json.loads(recovery_manifest_path.read_text(encoding="utf-8")),
    }
    scores = {
        condition: manifest["metrics"]["score_by_operation"]
        for condition, manifest in manifests.items()
    }
    attention = _specificity(
        scores["intact"],
        scores["attention_ablation"],
        RELATIONAL_OPERATIONS,
        CONTROL_OPERATIONS,
        gates,
    )
    mlp = _specificity(
        scores["intact"],
        scores["mlp_ablation"],
        CONTROL_OPERATIONS,
        RELATIONAL_OPERATIONS,
        gates,
    )
    recovery_deltas = {
        operation: abs(float(scores["intact"][operation]) - float(scores["recovery"][operation]))
        for operation in scores["intact"]
    }
    intervention_manifests = {
        name: json.loads(
            (interventions_root / name / "intervention-manifest.json").read_text(encoding="utf-8")
        )
        for name in ("attention_ablation", "mlp_ablation", "recovery")
    }
    checks = {
        "all_binary_interventions_verified": all(
            manifest["passed"] for manifest in intervention_manifests.values()
        ),
        "at_least_one_channel_is_selective": attention["selective"] or mlp["selective"],
        "recovery_restores_every_operation": max(recovery_deltas.values()) <= gates.recovery_tolerance,
        "recovery_restores_overall_score": abs(
            float(manifests["intact"]["metrics"]["overall_score"])
            - float(manifests["recovery"]["metrics"]["overall_score"])
        ) <= gates.recovery_tolerance,
    }
    payload: Dict[str, Any] = {
        "version": CAUSAL_INTERVENTION_VERSION,
        "evaluation_ids": {
            condition: manifest["evaluation_id"] for condition, manifest in manifests.items()
        },
        "attention_channel": attention,
        "mlp_channel": mlp,
        "recovery_deltas_by_operation": recovery_deltas,
        "intervention_ids": {
            name: manifest["intervention_id"] for name, manifest in intervention_manifests.items()
        },
        "checks": checks,
        "passed": all(checks.values()),
        "claim_boundary": (
            "Zeroing LoRA attention or MLP updates establishes causal necessity of adapter channels, "
            "not localization of a naturally emergent cognitive circuit. Activation patching and "
            "naturalistic tasks are still required for a neural-mechanism claim."
        ),
    }
    trial_id = content_digest(payload)[:20]
    manifest = {**payload, "trial_id": trial_id, "schema": 1}
    ArtifactStore(output_root).write_manifest("general-cognitive-core-causal-v31-" + trial_id, manifest)
    return manifest

