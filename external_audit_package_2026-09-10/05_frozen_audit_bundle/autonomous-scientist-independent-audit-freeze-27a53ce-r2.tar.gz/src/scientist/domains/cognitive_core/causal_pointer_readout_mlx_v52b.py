from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
import numpy as np

from scientist.domains.cognitive_core.causal_controller_mlx_v52 import (
    InstalledCausalController,
    tokenize_controller_row,
)


def tokenize_pointer_row(tokenizer: Any, row: Mapping[str, Any]) -> Mapping[str, Any]:
    patched = {
        **row,
        "metadata": {
            **row["metadata"],
            "action_target": int(row["metadata"]["intervention_action"]),
        },
    }
    return {**tokenize_controller_row(tokenizer, patched), "source_row": row}


class PointerReadoutDataset:
    def __init__(self, rows: Sequence[Mapping[str, Any]], tokenizer: Any) -> None:
        self.rows = tuple(rows)
        self.tokenizer = tokenizer
        self.cache: list[Any | None] = [None] * len(self.rows)

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, index: int) -> Mapping[str, Any]:
        cached = self.cache[index]
        if cached is None:
            cached = tokenize_pointer_row(self.tokenizer, self.rows[index])
            self.cache[index] = cached
        return cached


def _row_arrays(
    row: Mapping[str, Any], tokenizer: Any, max_sequence_length: int
) -> Tuple[mx.array, ...]:
    length = len(row["tokens"])
    if length > max_sequence_length:
        raise ValueError("M52b refuses to truncate a causal repair record")
    width = 1 + 32 * ((length + 31) // 32)
    pad_id = getattr(tokenizer, "pad_token_id", None)
    if pad_id is None:
        pad_id = getattr(tokenizer, "eos_token_id", 0)
    tokens = np.full((1, width), int(pad_id), dtype=np.int32)
    tokens[0, :length] = row["tokens"]
    return (
        mx.array(tokens),
        mx.array(np.asarray([row["completion_span"]], dtype=np.int32)),
        mx.array(np.asarray([row["slot_positions"]], dtype=np.int32)),
        mx.array(np.asarray([row["slot_mask"]], dtype=np.bool_)),
        mx.array(np.asarray([row["action_target"]], dtype=np.int32)),
    )


def iterate_pointer_batches(
    dataset: PointerReadoutDataset,
    batch_size: int,
    max_seq_length: int,
    loop: bool = False,
    seed: int | None = 5221,
    comm_group: Any = None,
) -> Iterator[Tuple[mx.array, ...]]:
    del comm_group
    if batch_size != 1:
        raise ValueError("M52b frozen recipe uses one intervention per microbatch")
    rng = np.random.default_rng(5221 if seed is None else seed)
    while True:
        for index in rng.permutation(len(dataset)):
            yield _row_arrays(dataset[int(index)], dataset.tokenizer, max_seq_length)
        if not loop:
            break


def pointer_readout_loss(
    model: InstalledCausalController,
    batch: mx.array,
    spans: mx.array,
    slot_positions: mx.array,
    slot_mask: mx.array,
    intervention_actions: mx.array,
) -> Tuple[mx.array, mx.array]:
    inputs = batch[:, :-1]
    targets = batch[:, 1:]
    final_prompt_positions = spans[:, 0] - 1
    h, mask, _, _, _ = model.encode_to_causal_site(inputs, slot_positions, slot_mask)
    h = mx.stop_gradient(h)
    code = mx.eye(5, dtype=mx.float32)[intervention_actions]
    logits = model.continue_from_causal_site(
        h, mask, final_prompt_positions, code
    )
    steps = mx.arange(1, targets.shape[1] + 1)
    completion_mask = mx.logical_and(
        steps >= spans[:, 0:1], steps < spans[:, 1:2]
    )
    losses = nn.losses.cross_entropy(logits, targets).astype(mx.float32)
    count = mx.maximum(completion_mask.sum(), mx.array(1))
    return (losses * completion_mask).sum() / count, mx.array(1.0)


def load_jsonl(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(json.loads(line) for line in path.read_text().splitlines() if line)
