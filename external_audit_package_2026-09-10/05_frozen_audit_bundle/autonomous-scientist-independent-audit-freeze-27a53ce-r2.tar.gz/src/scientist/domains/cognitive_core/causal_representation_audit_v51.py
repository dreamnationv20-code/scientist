from __future__ import annotations

import hashlib
import itertools
import json
import math
import random
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

import numpy as np

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_HISTORY_PATTERNS,
    M50_MODEL_SNAPSHOT,
    M50_OUTPUT_ALGEBRAS,
    M50_REPRESENTATIONS,
    _history_variant,
    _support,
    _task_signature,
)
from scientist.domains.cognitive_core.output_only_controller_v49 import (
    controller_prompt,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
)


CAUSAL_REPRESENTATION_AUDIT_VERSION = (
    "general-cognitive-causal-representation-audit-v51"
)
M51_SPLIT_SEEDS = {"discovery": 51037, "confirmation": 51091}
M51_PAIRS_PER_REPRESENTATION = {"discovery": 10, "confirmation": 20}
M51_REPRESENTATIONS = M50_REPRESENTATIONS
M51_MODEL_SPECS = (
    {
        "model_id": "m47_parent",
        "adapter_path": "runs/cognitive_core/sequential_policy_learning_v47/selected_adapter",
    },
    {
        "model_id": "m49_diagnostic_120",
        "adapter_path": "runs/cognitive_core/output_only_controller_v49/controller_adapter",
    },
    *(
        {
            "model_id": f"m50_seed_{seed}",
            "adapter_path": (
                "runs/cognitive_core/balanced_output_controller_v50/"
                f"selected_adapters/seed_{seed}"
            ),
        }
        for seed in (5001, 5002, 5003, 5004, 5005)
    ),
)


def _stable_seed(split: str, representation: str, source_index: int) -> int:
    material = f"{M51_SPLIT_SEEDS[split]}:{representation}:{source_index}"
    return int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)


def _two_candidate_task(
    split: str, representation: str, source_index: int
) -> Tuple[Any, Tuple[Any, ...], Tuple[Any, ...]] | None:
    rng = random.Random(_stable_seed(split, representation, source_index))
    source = _build_task(f"m51_{split}", representation, source_index, rng)
    base = _m43_experiment_task(source)
    if base is None:
        return None
    candidates = sorted(base.frontier, key=lambda item: item.key)
    for left, right in itertools.combinations(candidates, 2):
        provisional = replace(base, frontier=(left, right))
        equal, unequal = _support(provisional)
        if equal and unequal:
            task_id = "m51-task-" + content_digest(
                {
                    "split": split,
                    "representation": representation,
                    "source_index": source_index,
                    "frontier": [left.key, right.key],
                    "version": CAUSAL_REPRESENTATION_AUDIT_VERSION,
                }
            )[:24]
            return replace(provisional, task_id=task_id), equal, unequal
    return None


@lru_cache(maxsize=None)
def build_m51_cases(
    split: str,
    per_representation: int | None = None,
    representations: Tuple[str, ...] = M51_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    if split not in M51_SPLIT_SEEDS:
        raise ValueError("unknown M51 split")
    target = (
        M51_PAIRS_PER_REPRESENTATION[split]
        if per_representation is None
        else int(per_representation)
    )
    cases = []
    for representation in representations:
        found = 0
        source_index = 0
        while found < target:
            candidate = _two_candidate_task(split, representation, source_index)
            source_index += 1
            if candidate is None:
                if source_index > target * 100:
                    raise RuntimeError(
                        f"could not build enough M51 {representation} cases"
                    )
                continue
            task, equal_values, unequal_values = candidate
            length, evidence_slot = M50_HISTORY_PATTERNS[
                found % len(M50_HISTORY_PATTERNS)
            ]
            history = []
            for slot in range(1, length + 1):
                pool = unequal_values if slot == evidence_slot else equal_values
                value = pool[(found + slot) % len(pool)]
                outputs = raw_candidate_outputs(task, value)
                history.append(
                    {
                        "slot": slot,
                        "turn": slot,
                        "experiment": value,
                        "outputs": list(outputs),
                        "response": "EXPERIMENT: " + json.dumps(value),
                    }
                )
            signature = _task_signature(task)
            case_id = "m51-case-" + content_digest(
                {
                    "split": split,
                    "task_signature": signature,
                    "history": history,
                    "evidence_slot": evidence_slot,
                    "version": CAUSAL_REPRESENTATION_AUDIT_VERSION,
                }
            )[:24]
            cases.append(
                {
                    "case_id": case_id,
                    "task": task,
                    "task_signature": signature,
                    "representation": representation,
                    "output_algebra": M50_OUTPUT_ALGEBRAS[representation],
                    "prefix_length": length,
                    "evidence_slot": evidence_slot,
                    "history": tuple(history),
                }
            )
            found += 1
    return tuple(cases)


def build_m51_rows(
    split: str,
    per_representation: int | None = None,
    representations: Tuple[str, ...] = M51_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for case in build_m51_cases(split, per_representation, representations):
        null_history = _history_variant(case["history"], None)
        evidence_history = _history_variant(
            case["history"], int(case["evidence_slot"])
        )
        common = {
            "intervention_pair_id": case["case_id"],
            "task_id": case["task"].task_id,
            "task_signature": case["task_signature"],
            "representation": case["representation"],
            "output_algebra": case["output_algebra"],
            "prefix_length": case["prefix_length"],
            "evidence_slot": case["evidence_slot"],
        }
        rows.extend(
            (
                {
                    "prompt": controller_prompt(case["task"], null_history),
                    "completion": "REVISE",
                    "metadata": {
                        **common,
                        "variant": "output_null",
                        "history": list(null_history),
                    },
                },
                {
                    "prompt": controller_prompt(case["task"], evidence_history),
                    "completion": f"SELECT: {case['evidence_slot']}",
                    "metadata": {
                        **common,
                        "variant": "output_evidence",
                        "history": list(evidence_history),
                    },
                },
            )
        )
    return tuple(rows)


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M51 artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _json_payload(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def _jsonl_payload(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _model_manifest(project: Path) -> Tuple[Mapping[str, Any], ...]:
    manifest = []
    for spec in M51_MODEL_SPECS:
        adapter = project / spec["adapter_path"]
        manifest.append(
            {
                **spec,
                "adapter_config_sha256": _sha256(adapter / "adapter_config.json"),
                "adapter_weights_sha256": _sha256(
                    adapter / "adapters.safetensors"
                ),
            }
        )
    return tuple(manifest)


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    return {
        "version": CAUSAL_REPRESENTATION_AUDIT_VERSION,
        "parent_version": "general-cognitive-balanced-output-controller-v50",
        "scientific_question": (
            "Does the frozen 1.5B controller internally represent and causally use the "
            "representation-invariant compare-aggregate-point variables required by its "
            "revise/select policy?"
        ),
        "split_seeds": M51_SPLIT_SEEDS,
        "representations": list(M51_REPRESENTATIONS),
        "output_algebras": M50_OUTPUT_ALGEBRAS,
        "pairs_per_representation": M51_PAIRS_PER_REPRESENTATION,
        "history_patterns": [list(item) for item in M50_HISTORY_PATTERNS],
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "adapters": list(_model_manifest(project)),
        },
        "activation_contract": {
            "site": "last_prompt_token_residual_after_each_transformer_block",
            "layers": list(range(1, 29)),
            "model_hidden_size": 1536,
            "branch_variable": "any_candidate_output_difference",
            "pointer_variable": "first_and_only_evidence_slot",
            "discovery_only_selects_layer_and_directions": True,
            "confirmation_never_selects_layer_or_direction": True,
        },
        "probe_contract": {
            "branch_probe": "unit_mean_paired_evidence_minus_null_direction",
            "pointer_probe": "nearest_cosine_slot_prototype_on_paired_delta",
            "layer_selection": (
                "maximize_leave_one_representation_out_worst_branch_then_overall_branch_"
                "then_pointer_accuracy_then_earlier_layer"
            ),
            "minimum_loro_worst_branch_accuracy": 0.70,
            "minimum_confirmation_branch_accuracy": 0.80,
            "minimum_confirmation_each_representation_branch_accuracy": 0.65,
            "minimum_confirmation_pointer_accuracy": 0.60,
            "minimum_pointer_gain_over_prefix_chance": 0.15,
        },
        "causal_contract": {
            "intervention": (
                "replace_only_the_selected_one_dimensional_concept_projection_at_"
                "the_frozen_layer"
            ),
            "bidirectional": True,
            "control": "orthogonalized_fixed_rotation_of_concept_direction",
            "minimum_bidirectional_correct_shift_rate": 0.65,
            "minimum_each_representation_correct_shift_rate": 0.50,
            "minimum_gain_over_rotated_control": 0.10,
            "readout_success_threshold": 0.85,
        },
        "diagnosis_contract": {
            "ordering": [
                "representation_failure",
                "computation_or_causal_use_failure",
                "readout_or_control_failure",
                "controller_algorithm_present",
            ],
            "representation_requires_all_probe_gates": True,
            "causal_use_requires_all_causal_gates": True,
            "readout_failure_requires_causal_use_and_native_behavior_below_threshold": True,
        },
        "integrity_contract": {
            "fresh_mechanism_disjoint_splits": True,
            "exact_pairs_change_only_raw_outputs": True,
            "all_five_representations_balanced": True,
            "history_patterns_balanced_within_representation": True,
            "all_model_weights_frozen_before_activation_capture": True,
            "no_weight_updates_in_m51": True,
            "confirmation_excluded_from_layer_and_direction_selection": True,
        },
        "claim_boundary": (
            "M51 is a causal diagnosis of frozen small-model controller representations on "
            "fresh synthetic executable mechanisms. It does not train a repair, establish "
            "natural-task transfer, prove autonomous concept invention, or show 70B parity."
        ),
    }


def prepare_m51_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol_payload = _protocol_payload(project)
    protocol = {
        **protocol_payload,
        "protocol_freeze_id": content_digest(protocol_payload),
    }
    _write_immutable(output / "protocol-freeze.json", _json_payload(protocol))
    hashes: Dict[str, str] = {}
    counts: Dict[str, Any] = {}
    for split in M51_SPLIT_SEEDS:
        rows = build_m51_rows(split)
        hashes[split] = _write_immutable(
            output / f"controller/{split}.jsonl", _jsonl_payload(rows)
        )
        counts[split] = {
            "records": len(rows),
            "intervention_pairs": len(rows) // 2,
            "pairs_by_representation": {
                representation: sum(
                    row["metadata"]["representation"] == representation
                    and row["metadata"]["variant"] == "output_evidence"
                    for row in rows
                )
                for representation in M51_REPRESENTATIONS
            },
        }
    benchmark_payload = {**protocol, "hashes": hashes, "counts": counts}
    freeze = {**benchmark_payload, "freeze_id": content_digest(benchmark_payload)}
    _write_immutable(output / "benchmark-freeze.json", _json_payload(freeze))
    verification = verify_m51_benchmark(output, project)
    _write_immutable(
        output / "benchmark-verification.json", _json_payload(verification)
    )
    return freeze


def _rows(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    )


def _without_outputs(prompt: str) -> str:
    return "\n".join(
        line
        for line in prompt.splitlines()
        if "c1_output=" not in line and "c2_output=" not in line
    )


def verify_m51_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol_payload = {
        key: value for key, value in protocol.items() if key != "protocol_freeze_id"
    }
    freeze_payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    split_signatures: Dict[str, set[str]] = {}
    rows_reproduce = True
    exact = True
    balanced = True
    pattern_balanced = True
    hashes = {}
    for split in M51_SPLIT_SEEDS:
        path = output / f"controller/{split}.jsonl"
        hashes[split] = _sha256(path)
        stored = _rows(path)
        rows_reproduce = rows_reproduce and stored == build_m51_rows(split)
        groups: Dict[str, list[Mapping[str, Any]]] = {}
        for row in stored:
            groups.setdefault(row["metadata"]["intervention_pair_id"], []).append(row)
        for group in groups.values():
            if len(group) != 2:
                exact = False
                continue
            null = next(row for row in group if row["metadata"]["variant"] == "output_null")
            evidence = next(
                row for row in group if row["metadata"]["variant"] == "output_evidence"
            )
            exact = exact and (
                _without_outputs(null["prompt"]) == _without_outputs(evidence["prompt"])
                and null["completion"] == "REVISE"
                and evidence["completion"]
                == f"SELECT: {evidence['metadata']['evidence_slot']}"
            )
        counts = freeze["counts"][split]["pairs_by_representation"]
        balanced = balanced and len(set(counts.values())) == 1
        repeats = M51_PAIRS_PER_REPRESENTATION[split] // len(M50_HISTORY_PATTERNS)
        for representation in M51_REPRESENTATIONS:
            observed = {
                pattern: sum(
                    row["metadata"]["representation"] == representation
                    and row["metadata"]["variant"] == "output_evidence"
                    and (
                        row["metadata"]["prefix_length"],
                        row["metadata"]["evidence_slot"],
                    )
                    == pattern
                    for row in stored
                )
                for pattern in M50_HISTORY_PATTERNS
            }
            pattern_balanced = pattern_balanced and all(
                value == repeats for value in observed.values()
            )
        split_signatures[split] = {
            row["metadata"]["task_signature"] for row in stored
        }
    model_manifest = tuple(freeze["frozen_model"]["adapters"])
    weights_frozen = model_manifest == _model_manifest(project)
    checks = {
        "protocol_id_is_content_derived": content_digest(protocol_payload)
        == protocol["protocol_freeze_id"],
        "freeze_id_is_content_derived": content_digest(freeze_payload)
        == freeze["freeze_id"],
        "all_hashes_match": hashes == freeze["hashes"],
        "rows_reproduce": rows_reproduce,
        "exact_pairs_change_only_raw_outputs": exact,
        "representations_are_balanced": balanced,
        "history_patterns_are_balanced": pattern_balanced,
        "discovery_and_confirmation_are_disjoint": not (
            split_signatures["discovery"] & split_signatures["confirmation"]
        ),
        "all_seven_model_weights_are_frozen_and_match": weights_frozen
        and len(model_manifest) == 7,
        "no_weight_update_is_declared": freeze["integrity_contract"][
            "no_weight_updates_in_m51"
        ],
    }
    return {
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def unit_direction(deltas: Sequence[np.ndarray]) -> np.ndarray:
    if not deltas:
        raise ValueError("cannot fit a direction without paired deltas")
    direction = np.mean(np.stack(deltas).astype(np.float64), axis=0)
    norm = float(np.linalg.norm(direction))
    if not math.isfinite(norm) or norm <= 1e-12:
        return np.zeros_like(direction, dtype=np.float64)
    return direction / norm


def rotated_control(direction: np.ndarray) -> np.ndarray:
    if direction.ndim != 1:
        raise ValueError("direction must be one-dimensional")
    rolled = np.roll(direction, max(1, len(direction) // 3)).astype(np.float64)
    rolled = rolled - direction * float(np.dot(rolled, direction))
    norm = float(np.linalg.norm(rolled))
    if norm <= 1e-12:
        rolled = np.zeros_like(direction)
        rolled[0] = 1.0
        rolled = rolled - direction * float(np.dot(rolled, direction))
        norm = float(np.linalg.norm(rolled))
    return rolled / max(norm, 1e-12)


def fit_slot_prototypes(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[int, np.ndarray]:
    grouped: Dict[int, list[np.ndarray]] = {}
    for row in records:
        grouped.setdefault(int(row["evidence_slot"]), []).append(row["delta"])
    return {slot: unit_direction(values) for slot, values in grouped.items()}


def predict_slot(delta: np.ndarray, prototypes: Mapping[int, np.ndarray]) -> int:
    norm = float(np.linalg.norm(delta))
    normalized = delta / max(norm, 1e-12)
    return max(
        sorted(prototypes),
        key=lambda slot: float(np.dot(normalized, prototypes[slot])),
    )


def layer_probe_metrics(
    records: Sequence[Mapping[str, Any]],
    representations: Sequence[str] = M51_REPRESENTATIONS,
) -> Mapping[str, Any]:
    by_representation: Dict[str, Mapping[str, float]] = {}
    branch_correct = 0
    slot_correct = 0
    total = 0
    for heldout in representations:
        train = [row for row in records if row["representation"] != heldout]
        test = [row for row in records if row["representation"] == heldout]
        direction = unit_direction([row["delta"] for row in train])
        prototypes = fit_slot_prototypes(train)
        heldout_branch = sum(
            float(np.dot(row["delta"], direction)) > 0.0 for row in test
        )
        compatible = [row for row in test if int(row["evidence_slot"]) in prototypes]
        heldout_slot = sum(
            predict_slot(row["delta"], prototypes) == int(row["evidence_slot"])
            for row in compatible
        )
        branch_correct += heldout_branch
        slot_correct += heldout_slot
        total += len(test)
        by_representation[heldout] = {
            "pair_count": len(test),
            "branch_direction_accuracy": heldout_branch / max(len(test), 1),
            "pointer_accuracy": heldout_slot / max(len(compatible), 1),
        }
    return {
        "pair_count": total,
        "branch_direction_accuracy": branch_correct / max(total, 1),
        "worst_representation_branch_accuracy": min(
            row["branch_direction_accuracy"] for row in by_representation.values()
        ),
        "pointer_accuracy": slot_correct / max(total, 1),
        "by_representation": by_representation,
    }


def select_probe_layer(layer_metrics: Sequence[Mapping[str, Any]]) -> int:
    if not layer_metrics:
        raise ValueError("no layer metrics supplied")
    selected = max(
        layer_metrics,
        key=lambda row: (
            float(row["worst_representation_branch_accuracy"]),
            float(row["branch_direction_accuracy"]),
            float(row["pointer_accuracy"]),
            -int(row["layer"]),
        ),
    )
    return int(selected["layer"])


def confirmation_probe_metrics(
    discovery: Sequence[Mapping[str, Any]],
    confirmation: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    direction = unit_direction([row["delta"] for row in discovery])
    prototypes = fit_slot_prototypes(discovery)
    records = []
    for row in confirmation:
        branch_score = float(np.dot(row["delta"], direction))
        predicted_slot = predict_slot(row["delta"], prototypes)
        records.append(
            {
                "intervention_pair_id": row["intervention_pair_id"],
                "representation": row["representation"],
                "prefix_length": int(row["prefix_length"]),
                "evidence_slot": int(row["evidence_slot"]),
                "branch_score": branch_score,
                "branch_correct": branch_score > 0.0,
                "predicted_slot": predicted_slot,
                "slot_correct": predicted_slot == int(row["evidence_slot"]),
            }
        )

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        chance = sum(1.0 / int(row["prefix_length"]) for row in items) / max(
            len(items), 1
        )
        return {
            "pair_count": len(items),
            "branch_direction_accuracy": sum(row["branch_correct"] for row in items)
            / max(len(items), 1),
            "pointer_accuracy": sum(row["slot_correct"] for row in items)
            / max(len(items), 1),
            "prefix_chance_pointer_accuracy": chance,
        }

    overall = summarize(records)
    return {
        **overall,
        "pointer_gain_over_prefix_chance": overall["pointer_accuracy"]
        - overall["prefix_chance_pointer_accuracy"],
        "by_representation": {
            representation: summarize(
                [row for row in records if row["representation"] == representation]
            )
            for representation in M51_REPRESENTATIONS
        },
        "records": records,
        "direction": direction,
    }


def summarize_causal_records(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        if not items:
            return {
                "pair_count": 0,
                "native_paired_accuracy": 0.0,
                "concept_bidirectional_correct_shift_rate": 0.0,
                "control_bidirectional_correct_shift_rate": 0.0,
                "concept_interchange_flip_accuracy": 0.0,
                "mean_concept_null_to_evidence_shift": 0.0,
                "mean_concept_evidence_to_null_shift": 0.0,
            }
        return {
            "pair_count": len(items),
            "native_paired_accuracy": sum(row["native_pair_correct"] for row in items)
            / len(items),
            "concept_bidirectional_correct_shift_rate": sum(
                row["concept_bidirectional_shift_correct"] for row in items
            )
            / len(items),
            "control_bidirectional_correct_shift_rate": sum(
                row["control_bidirectional_shift_correct"] for row in items
            )
            / len(items),
            "concept_interchange_flip_accuracy": sum(
                row["concept_interchange_flip"] for row in items
            )
            / len(items),
            "mean_concept_null_to_evidence_shift": sum(
                row["concept_null_to_evidence_shift"] for row in items
            )
            / len(items),
            "mean_concept_evidence_to_null_shift": sum(
                row["concept_evidence_to_null_shift"] for row in items
            )
            / len(items),
        }

    overall = summarize(records)
    overall["concept_gain_over_rotated_control"] = (
        overall["concept_bidirectional_correct_shift_rate"]
        - overall["control_bidirectional_correct_shift_rate"]
    )
    return {
        **overall,
        "by_representation": {
            representation: summarize(
                [row for row in records if row["representation"] == representation]
            )
            for representation in M51_REPRESENTATIONS
        },
        "records": list(records),
    }


def classify_diagnosis(
    discovery: Mapping[str, Any],
    probe: Mapping[str, Any],
    causal: Mapping[str, Any],
    probe_contract: Mapping[str, Any],
    causal_contract: Mapping[str, Any],
) -> Mapping[str, Any]:
    probe_checks = {
        "loro_worst_branch_accuracy": discovery[
            "worst_representation_branch_accuracy"
        ]
        >= probe_contract["minimum_loro_worst_branch_accuracy"],
        "confirmation_branch_accuracy": probe["branch_direction_accuracy"]
        >= probe_contract["minimum_confirmation_branch_accuracy"],
        "confirmation_each_representation_branch_accuracy": min(
            row["branch_direction_accuracy"]
            for row in probe["by_representation"].values()
        )
        >= probe_contract["minimum_confirmation_each_representation_branch_accuracy"],
        "confirmation_pointer_accuracy": probe["pointer_accuracy"]
        >= probe_contract["minimum_confirmation_pointer_accuracy"],
        "pointer_gain_over_prefix_chance": probe["pointer_gain_over_prefix_chance"]
        >= probe_contract["minimum_pointer_gain_over_prefix_chance"],
    }
    representation_present = all(probe_checks.values())
    causal_checks = {
        "bidirectional_correct_shift_rate": causal[
            "concept_bidirectional_correct_shift_rate"
        ]
        >= causal_contract["minimum_bidirectional_correct_shift_rate"],
        "each_representation_correct_shift_rate": min(
            row["concept_bidirectional_correct_shift_rate"]
            for row in causal["by_representation"].values()
        )
        >= causal_contract["minimum_each_representation_correct_shift_rate"],
        "gain_over_rotated_control": causal["concept_gain_over_rotated_control"]
        >= causal_contract["minimum_gain_over_rotated_control"],
    }
    causal_use = representation_present and all(causal_checks.values())
    if not representation_present:
        diagnosis = "representation_failure"
    elif not causal_use:
        diagnosis = "computation_or_causal_use_failure"
    elif causal["native_paired_accuracy"] < causal_contract[
        "readout_success_threshold"
    ]:
        diagnosis = "readout_or_control_failure"
    else:
        diagnosis = "controller_algorithm_present"
    return {
        "diagnosis": diagnosis,
        "representation_present": representation_present,
        "causal_use_present": causal_use,
        "probe_checks": probe_checks,
        "causal_checks": causal_checks,
    }

