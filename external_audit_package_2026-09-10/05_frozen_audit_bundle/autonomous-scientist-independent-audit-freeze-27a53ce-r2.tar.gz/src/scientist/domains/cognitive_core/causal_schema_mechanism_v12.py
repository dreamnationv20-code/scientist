from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.functional_vertical_slice_v11 import (
    SliceCandidateDescriptor,
    SlicePartition,
    VerticalCandidateEvaluation,
    VerticalSliceExperiment,
    VerticalSliceRegistry,
    evaluate_vertical_candidate,
)
from scientist.domains.cognitive_core.shared_substrate_v10 import (
    CandidateAction,
    CandidateActionKind,
    CandidateCostLedger,
    CandidateEvent,
    CandidateEventKind,
    CandidateStep,
)


CAUSAL_SCHEMA_MECHANISM_VERSION = "cognitive-core-causal-schema-mechanism-v12"


@dataclass(frozen=True)
class CausalContrast:
    contrast_id: str
    work_package_key: str
    shared_observation: str
    successful_behavior: str
    failed_behavior: str
    missing_link: str

    def as_dict(self) -> Dict[str, str]:
        return {
            "contrast_id": self.contrast_id,
            "work_package_key": self.work_package_key,
            "shared_observation": self.shared_observation,
            "successful_behavior": self.successful_behavior,
            "failed_behavior": self.failed_behavior,
            "missing_link": self.missing_link,
        }


@dataclass(frozen=True)
class CausalContrastDossier:
    source_experiment_id: str
    allowed_partitions: Tuple[str, ...]
    excluded_partition: str
    contrasts: Tuple[CausalContrast, ...]
    common_failure: str
    representation_demand: str

    @property
    def dossier_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CAUSAL_SCHEMA_MECHANISM_VERSION,
            "source_experiment_id": self.source_experiment_id,
            "allowed_partitions": list(self.allowed_partitions),
            "excluded_partition": self.excluded_partition,
            "contrasts": [item.as_dict() for item in self.contrasts],
            "common_failure": self.common_failure,
            "representation_demand": self.representation_demand,
        }
        if include_id:
            value["dossier_id"] = self.dossier_id
        return value


@dataclass(frozen=True)
class CausalSchemaHypothesis:
    name: str
    dossier_id: str
    latent_concept: str
    mechanism: str
    predictions: Tuple[str, ...]
    falsifiers: Tuple[str, ...]
    scope_limits: Tuple[str, ...]

    @property
    def hypothesis_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CAUSAL_SCHEMA_MECHANISM_VERSION,
            "name": self.name,
            "dossier_id": self.dossier_id,
            "latent_concept": self.latent_concept,
            "mechanism": self.mechanism,
            "predictions": list(self.predictions),
            "falsifiers": list(self.falsifiers),
            "scope_limits": list(self.scope_limits),
        }
        if include_id:
            value["hypothesis_id"] = self.hypothesis_id
        return value


@dataclass(frozen=True)
class MechanismArm:
    arm_id: str
    schema_induction: bool
    causal_address_binding: bool
    expected_passes: Tuple[str, ...]
    expected_failures: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "arm_id": self.arm_id,
            "schema_induction": self.schema_induction,
            "causal_address_binding": self.causal_address_binding,
            "expected_passes": list(self.expected_passes),
            "expected_failures": list(self.expected_failures),
        }


@dataclass(frozen=True)
class CausalSchemaPreregistration:
    hypothesis: CausalSchemaHypothesis
    arms: Tuple[MechanismArm, ...]
    frozen_registry_id: str
    development_diagnostic_only: bool
    audit_unseen_during_diagnosis: bool
    adoption_rule: str

    @property
    def preregistration_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CAUSAL_SCHEMA_MECHANISM_VERSION,
            "hypothesis": self.hypothesis.as_dict(),
            "arms": [item.as_dict() for item in self.arms],
            "frozen_registry_id": self.frozen_registry_id,
            "development_diagnostic_only": self.development_diagnostic_only,
            "audit_unseen_during_diagnosis": self.audit_unseen_during_diagnosis,
            "adoption_rule": self.adoption_rule,
        }
        if include_id:
            value["preregistration_id"] = self.preregistration_id
        return value


@dataclass(frozen=True)
class CausalSchemaTrial:
    preregistration: CausalSchemaPreregistration
    evaluations: Mapping[str, VerticalCandidateEvaluation]
    prediction_results: Mapping[str, bool]

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def passed(self) -> bool:
        return all(self.prediction_results.values())

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CAUSAL_SCHEMA_MECHANISM_VERSION,
            "preregistration": self.preregistration.as_dict(),
            "evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.evaluations.items())
            },
            "prediction_results": dict(sorted(self.prediction_results.items())),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def build_contrast_dossier(
    source: VerticalSliceExperiment,
) -> CausalContrastDossier:
    baseline = source.evaluations["baseline"]
    positive = source.evaluations["positive_control"]
    allowed = {SlicePartition.DEVELOPMENT, SlicePartition.CALIBRATION}
    contrasts = []
    descriptions = {
        "procedure_representation": (
            "both candidates receive an explicit operation specification with a novel surface token",
            "normalizes the specification into an executable operation",
            "treats the surface token as an unknown canonical procedure and abstains",
            "surface identity is not connected to executable semantics",
        ),
        "task_inference": (
            "both candidates receive the same demonstrations before the latent query",
            "compiles demonstration constraints into an executable task model",
            "stores demonstrations but cannot use them to answer",
            "observations are stored without becoming an executable hypothesis",
        ),
        "relevance_representation": (
            "both candidates receive the same target, evidence graph, and distractors",
            "follows target-to-rule relations and selects only supporting evidence",
            "cannot ground the query target into the evidence relation graph",
            "target and evidence identifiers lack a shared causal address",
        ),
        "requested_change": (
            "both candidates acknowledge the same explicit change request",
            "mutates the task state that later execution reads",
            "stores the requested value while downstream behavior remains unchanged",
            "the written address is disconnected from the executable task state",
        ),
    }
    for key, rows in descriptions.items():
        baseline_rows = tuple(
            item
            for item in baseline.outcomes
            if item.probe.partition in allowed
            and item.probe.work_package_key == key
        )
        positive_rows = tuple(
            item
            for item in positive.outcomes
            if item.probe.partition in allowed
            and item.probe.work_package_key == key
        )
        if not baseline_rows or not positive_rows:
            raise ValueError("contrast dossier is missing a required probe family")
        if all(item.passed for item in baseline_rows):
            raise ValueError("baseline unexpectedly lacks the declared contrast")
        if not all(item.passed for item in positive_rows):
            raise ValueError("positive control does not establish the contrast")
        contrasts.append(
            CausalContrast(
                contrast_id="contrast-%s" % key,
                work_package_key=key,
                shared_observation=rows[0],
                successful_behavior=rows[1],
                failed_behavior=rows[2],
                missing_link=rows[3],
            )
        )
    return CausalContrastDossier(
        source_experiment_id=source.experiment_id,
        allowed_partitions=(
            SlicePartition.DEVELOPMENT.value,
            SlicePartition.CALIBRATION.value,
        ),
        excluded_partition=SlicePartition.AUDIT.value,
        contrasts=tuple(contrasts),
        common_failure=(
            "information is accepted into local storage but remains partitioned "
            "from the representation used by later decisions"
        ),
        representation_demand=(
            "one persistent object must carry executable semantics and a stable "
            "causal address shared by demonstrations, evidence, updates, and execution"
        ),
    )


def invent_causal_schema_hypothesis(
    dossier: CausalContrastDossier,
) -> CausalSchemaHypothesis:
    return CausalSchemaHypothesis(
        name="causally addressable executable schema",
        dossier_id=dossier.dossier_id,
        latent_concept=(
            "causally_addressable_executable_schema: a persistent task object whose "
            "content is directly executable and whose address is shared across all "
            "channels that describe, retrieve, or modify that task"
        ),
        mechanism=(
            "normalize explicit specifications or demonstration constraints into a "
            "minimal executable schema; bind task and evidence references to that "
            "schema; apply updates to schema fields read by the executor"
        ),
        predictions=(
            "schema induction alone repairs explicit procedure execution and latent task inference but not relevance or behavioral updating",
            "causal address binding alone repairs relational selection but cannot execute or behaviorally update an absent schema",
            "combining both factors repairs all four behavioral families on calibration and frozen audit partitions",
            "the same combined candidate remains inside the shared cost envelope without external services",
        ),
        falsifiers=(
            "either single factor alone passes every behavioral family",
            "the combined arm fails any held-out behavioral family",
            "the combined arm requires event-ID lookup, expected answers, a state reset, or an unmatched cost",
            "the predicted factorial signature differs between calibration and audit",
        ),
        scope_limits=(
            "the initial mechanism language uses low-degree finite-field programs",
            "the evidence binding mechanism initially supports explicit directed relation graphs",
            "success would validate the causal concept in this microdomain, not general cognitive competence",
        ),
    )


def preregister_causal_schema_trial(
    hypothesis: CausalSchemaHypothesis,
    registry: VerticalSliceRegistry,
) -> CausalSchemaPreregistration:
    arms = (
        MechanismArm(
            arm_id="schema_only",
            schema_induction=True,
            causal_address_binding=False,
            expected_passes=(
                "procedure_representation",
                "task_inference",
                "system_cost",
            ),
            expected_failures=(
                "relevance_representation",
                "requested_change",
            ),
        ),
        MechanismArm(
            arm_id="address_only",
            schema_induction=False,
            causal_address_binding=True,
            expected_passes=("relevance_representation", "system_cost"),
            expected_failures=(
                "procedure_representation",
                "task_inference",
                "requested_change",
            ),
        ),
        MechanismArm(
            arm_id="combined",
            schema_induction=True,
            causal_address_binding=True,
            expected_passes=(
                "procedure_representation",
                "task_inference",
                "relevance_representation",
                "requested_change",
                "system_cost",
            ),
            expected_failures=(),
        ),
    )
    return CausalSchemaPreregistration(
        hypothesis=hypothesis,
        arms=arms,
        frozen_registry_id=registry.registry_id,
        development_diagnostic_only=True,
        audit_unseen_during_diagnosis=True,
        adoption_rule=(
            "adopt no mechanism unless every preregistered arm signature matches on "
            "both calibration and audit, the combined arm passes all five gates, and "
            "both control factors remain necessary"
        ),
    )


class CausalSchemaCandidate:
    def __init__(
        self,
        *,
        hypothesis_id: str,
        arm: MechanismArm,
        interface_id: str,
    ) -> None:
        self.arm = arm
        self.descriptor = SliceCandidateDescriptor(
            candidate_id=content_digest(
                {
                    "version": CAUSAL_SCHEMA_MECHANISM_VERSION,
                    "hypothesis_id": hypothesis_id,
                    "schema_induction": arm.schema_induction,
                    "causal_address_binding": arm.causal_address_binding,
                }
            ),
            name="Causal schema candidate: %s" % arm.arm_id,
            executable_digest=content_digest(
                {
                    "runtime": "CausalSchemaCandidate",
                    "version": CAUSAL_SCHEMA_MECHANISM_VERSION,
                    "interface_id": interface_id,
                    "schema_induction": arm.schema_induction,
                    "causal_address_binding": arm.causal_address_binding,
                }
            ),
            role="mechanism_factorial_arm",
            admissible_for_search=True,
        )
        self.schemas: Dict[str, Tuple[int, Tuple[int, ...]]] = {}
        self.detached_updates: Dict[Tuple[str, str], int] = {}
        self.cost = CandidateCostLedger()

    def _state_id(self) -> str:
        return content_digest(
            {
                "schemas": {
                    key: [modulus, list(coefficients)]
                    for key, (modulus, coefficients) in sorted(self.schemas.items())
                },
                "detached_updates": {
                    "%s:%s" % key: value
                    for key, value in sorted(self.detached_updates.items())
                },
            }
        )

    @staticmethod
    def _execute(
        modulus: int,
        coefficients: Tuple[int, ...],
        argument: int,
    ) -> int:
        value = 0
        power = 1
        for coefficient in coefficients:
            value = (value + coefficient * power) % modulus
            power = (power * argument) % modulus
        return value

    @classmethod
    def _minimal_polynomial(
        cls,
        modulus: int,
        demonstrations: Tuple[Tuple[int, int], ...],
    ) -> Tuple[Tuple[int, ...] | None, int]:
        operations = 0
        for degree in range(3):
            candidates = [()]
            for _ in range(degree + 1):
                candidates = [
                    (*prefix, coefficient)
                    for prefix in candidates
                    for coefficient in range(modulus)
                ]
            matches = []
            for coefficients in candidates:
                operations += len(demonstrations) * (degree + 1)
                if all(
                    cls._execute(modulus, coefficients, x) == output
                    for x, output in demonstrations
                ):
                    matches.append(coefficients)
            if len(matches) == 1:
                return matches[0], operations
        return None, operations

    def act(self, event: CandidateEvent) -> CandidateStep:
        before_id = self._state_id()
        before_cost = self.cost
        payload = event.payload
        operations = 1
        retrievals = 0
        writes = 0
        if event.kind == CandidateEventKind.EXECUTE_PROCEDURE:
            if not self.arm.schema_induction:
                action = CandidateAction(
                    CandidateActionKind.ABSTAIN,
                    {"reason": "executable schema induction disabled"},
                )
            else:
                spec = payload["procedure_spec"]
                if spec.get("operator") != "affine_mod":
                    action = CandidateAction(
                        CandidateActionKind.ABSTAIN,
                        {"reason": "unsupported explicit algebra"},
                    )
                else:
                    coefficients = (int(spec["shift"]), int(spec["scale"]))
                    argument = int(payload["operands"][0])
                    action = CandidateAction(
                        CandidateActionKind.PROCEDURE_RESULT,
                        {
                            "value": self._execute(
                                int(spec["modulus"]), coefficients, argument
                            )
                        },
                    )
                    operations = 4
        elif event.kind == CandidateEventKind.OBSERVE_DEMONSTRATIONS:
            target = str(payload["task_token"])
            demos = tuple(
                (int(row["operands"][0]), int(row["output"]))
                for row in payload["demonstrations"]
            )
            if self.arm.schema_induction:
                coefficients, operations = self._minimal_polynomial(
                    int(payload["modulus"]), demos
                )
            else:
                coefficients = None
            if coefficients is not None:
                self.schemas[target] = (
                    int(payload["modulus"]), coefficients
                )
                writes = 1
            action = CandidateAction(
                CandidateActionKind.DEMONSTRATIONS_STORED,
                {"count": len(demos)},
            )
        elif event.kind == CandidateEventKind.ANSWER_TASK:
            target = str(payload["task_token"])
            schema = self.schemas.get(target)
            if schema is None:
                action = CandidateAction(
                    CandidateActionKind.ABSTAIN,
                    {"reason": "no executable task schema"},
                )
            else:
                modulus, coefficients = schema
                action = CandidateAction(
                    CandidateActionKind.TASK_RESULT,
                    {
                        "value": self._execute(
                            modulus, coefficients, int(payload["operands"][0])
                        )
                    },
                )
                operations = len(coefficients) * 2
        elif event.kind == CandidateEventKind.SELECT_RELEVANCE:
            if not self.arm.causal_address_binding:
                selected = []
            else:
                target = str(payload["query_target"])
                evidence = payload["evidence"]
                frontier = {target}
                selected = []
                for _ in range(2):
                    next_frontier = set()
                    for row in evidence:
                        if row["subject"] in frontier:
                            selected.append(str(row["evidence_id"]))
                            next_frontier.add(str(row["object"]))
                    frontier = next_frontier
                operations = len(evidence) * 2
            action = CandidateAction(
                CandidateActionKind.RELEVANCE_SELECTION,
                {"evidence_ids": selected},
            )
            retrievals = 1
        elif event.kind == CandidateEventKind.REQUEST_UPDATE:
            target = str(payload["task_token"])
            field = str(payload["field"])
            value = int(payload["value"])
            schema = self.schemas.get(target)
            if (
                self.arm.causal_address_binding
                and schema is not None
                and field == "shift"
            ):
                modulus, coefficients = schema
                revised = (value % modulus, *coefficients[1:])
                self.schemas[target] = (modulus, revised)
            else:
                self.detached_updates[(target, field)] = value
            writes = 1
            action = CandidateAction(
                CandidateActionKind.UPDATE_ACKNOWLEDGEMENT,
                {"key": str(payload["key"]), "stored": str(value)},
            )
        else:  # pragma: no cover - registry exhaustiveness
            action = CandidateAction(
                CandidateActionKind.ABSTAIN,
                {"reason": "unsupported event"},
            )
        self.cost = replace(
            self.cost,
            inference_events=self.cost.inference_events + 1,
            primitive_operations=self.cost.primitive_operations + operations,
            context_tokens=self.cost.context_tokens + len(str(dict(payload)).split()),
            persistent_memory_slots=len(self.schemas) + len(self.detached_updates),
            retrieval_calls=self.cost.retrieval_calls + retrievals,
            adaptation_writes=self.cost.adaptation_writes + writes,
        )
        return CandidateStep(
            event=event,
            action=action,
            state_before_id=before_id,
            state_after_id=self._state_id(),
            cost_before=before_cost,
            cost_after=self.cost,
        )


def run_causal_schema_factorial(
    preregistration: CausalSchemaPreregistration,
    registry: VerticalSliceRegistry,
) -> CausalSchemaTrial:
    if preregistration.frozen_registry_id != registry.registry_id:
        raise ValueError("mechanism trial registry differs from preregistration")
    evaluations: Dict[str, VerticalCandidateEvaluation] = {}
    for arm in preregistration.arms:
        runtime = CausalSchemaCandidate(
            hypothesis_id=preregistration.hypothesis.hypothesis_id,
            arm=arm,
            interface_id=registry.interface_id,
        )
        evaluations[arm.arm_id] = evaluate_vertical_candidate(
            runtime, runtime.descriptor, registry
        )
    predictions: Dict[str, bool] = {}
    for arm in preregistration.arms:
        evaluation = evaluations[arm.arm_id]
        for partition in (
            SlicePartition.CALIBRATION.value,
            SlicePartition.AUDIT.value,
        ):
            for key in arm.expected_passes:
                predictions[
                    "%s_%s_%s_passes" % (arm.arm_id, partition, key)
                ] = evaluation.partition_scores[partition][key] == 1.0
            for key in arm.expected_failures:
                predictions[
                    "%s_%s_%s_fails" % (arm.arm_id, partition, key)
                ] = evaluation.partition_scores[partition][key] < 1.0
    predictions["combined_all_functional_gates_pass"] = all(
        evaluations["combined"].functional_gates.values()
    )
    predictions["both_factors_are_necessary"] = (
        not all(evaluations["schema_only"].functional_gates.values())
        and not all(evaluations["address_only"].functional_gates.values())
    )
    predictions["all_arms_share_the_frozen_event_stream"] = (
        len({item.event_stream_digest for item in evaluations.values()}) == 1
    )
    return CausalSchemaTrial(
        preregistration=preregistration,
        evaluations=evaluations,
        prediction_results=predictions,
    )
