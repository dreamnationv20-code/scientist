from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_schema_mechanism_v12 import (
    CausalContrastDossier,
    CausalSchemaHypothesis,
    CausalSchemaPreregistration,
    CausalSchemaTrial,
)
from scientist.domains.cognitive_core.functional_vertical_slice_v11 import (
    SlicePartition,
    VerticalSliceExperiment,
)
from scientist.domains.cognitive_core.shared_substrate_v10 import WAVE_ONE_KEYS
from scientist.program.control_plane import AutonomousScientistControlPlane


CAUSAL_SCHEMA_MECHANISM_VERIFIER_REF = (
    "cognitive-core-causal-schema-independent-verifier-v12"
)


@dataclass(frozen=True)
class CausalSchemaMechanismVerification:
    check_results: Mapping[str, bool]
    dossier_id: str
    hypothesis_id: str
    preregistration_id: str
    trial_id: str
    arm_functional_gates: Mapping[str, Mapping[str, float]]
    combined_audit_scores: Mapping[str, float]
    limitations: Tuple[str, ...]
    verifier_ref: str = CAUSAL_SCHEMA_MECHANISM_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "dossier_id": self.dossier_id,
            "hypothesis_id": self.hypothesis_id,
            "preregistration_id": self.preregistration_id,
            "trial_id": self.trial_id,
            "arm_functional_gates": {
                key: dict(sorted(item.items()))
                for key, item in sorted(self.arm_functional_gates.items())
            },
            "combined_audit_scores": dict(
                sorted(self.combined_audit_scores.items())
            ),
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_causal_schema_mechanism(
    *,
    control: AutonomousScientistControlPlane,
    source_experiment: VerticalSliceExperiment,
    dossier: CausalContrastDossier,
    hypothesis: CausalSchemaHypothesis,
    preregistration: CausalSchemaPreregistration,
    trial: CausalSchemaTrial,
    replay: CausalSchemaTrial,
    phase_three_manifest: Mapping[str, Any],
) -> CausalSchemaMechanismVerification:
    schema_only = trial.evaluations["schema_only"]
    address_only = trial.evaluations["address_only"]
    combined = trial.evaluations["combined"]
    expected_schema_gates = {
        "procedure_representation": 1.0,
        "relevance_representation": 0.0,
        "requested_change": 0.0,
        "system_cost": 1.0,
        "task_inference": 1.0,
    }
    expected_address_gates = {
        "procedure_representation": 0.0,
        "relevance_representation": 1.0,
        "requested_change": 0.0,
        "system_cost": 1.0,
        "task_inference": 0.0,
    }
    expected_combined_gates = {key: 1.0 for key in WAVE_ONE_KEYS}
    trace_chains = all(
        all(
            left.state_after_id == right.state_before_id
            and left.cost_after == right.cost_before
            for left, right in zip(item.steps, item.steps[1:])
        )
        for item in trial.evaluations.values()
    )
    same_stream = {
        item.event_stream_digest for item in trial.evaluations.values()
    } == {source_experiment.evaluations["baseline"].event_stream_digest}
    factor_by_arm = {item.arm_id: item for item in preregistration.arms}
    control_value = control.as_dict()
    checks = {
        "phase_three_source_and_frozen_registry_are_bound": (
            bool(phase_three_manifest.get("passed"))
            and phase_three_manifest["experiment_id"]
            == source_experiment.experiment_id
            and phase_three_manifest["registry_id"]
            == preregistration.frozen_registry_id
            == source_experiment.registry.registry_id
        ),
        "diagnosis_uses_development_and_calibration_but_excludes_audit": (
            set(dossier.allowed_partitions)
            == {
                SlicePartition.DEVELOPMENT.value,
                SlicePartition.CALIBRATION.value,
            }
            and dossier.excluded_partition == SlicePartition.AUDIT.value
            and preregistration.development_diagnostic_only
            and preregistration.audit_unseen_during_diagnosis
        ),
        "four_behavioral_contrasts_share_one_representation_demand": (
            len(dossier.contrasts) == 4
            and {item.work_package_key for item in dossier.contrasts}
            == {
                "procedure_representation",
                "task_inference",
                "relevance_representation",
                "requested_change",
            }
            and all(item.missing_link for item in dossier.contrasts)
            and bool(dossier.common_failure)
            and bool(dossier.representation_demand)
        ),
        "hypothesis_is_bound_to_dossier_with_predictions_and_falsifiers": (
            hypothesis.dossier_id == dossier.dossier_id
            and "causally_addressable_executable_schema"
            in hypothesis.latent_concept
            and len(hypothesis.predictions) == 4
            and len(hypothesis.falsifiers) == 4
            and bool(hypothesis.scope_limits)
        ),
        "factorial_preregistration_freezes_two_factors_and_combination": (
            set(factor_by_arm) == {"schema_only", "address_only", "combined"}
            and factor_by_arm["schema_only"].schema_induction
            and not factor_by_arm["schema_only"].causal_address_binding
            and not factor_by_arm["address_only"].schema_induction
            and factor_by_arm["address_only"].causal_address_binding
            and factor_by_arm["combined"].schema_induction
            and factor_by_arm["combined"].causal_address_binding
        ),
        "schema_only_arm_has_preregistered_selective_effect": (
            schema_only.functional_gates == expected_schema_gates
        ),
        "address_only_arm_has_preregistered_selective_effect": (
            address_only.functional_gates == expected_address_gates
        ),
        "combined_arm_passes_every_wave_one_functional_gate": (
            combined.functional_gates == expected_combined_gates
            and all(
                combined.partition_scores[SlicePartition.AUDIT.value][key]
                == 1.0
                for key in WAVE_ONE_KEYS
            )
        ),
        "both_factors_are_necessary_and_jointly_sufficient_in_slice": (
            not all(schema_only.functional_gates.values())
            and not all(address_only.functional_gates.values())
            and all(combined.functional_gates.values())
        ),
        "all_preregistered_factorial_predictions_pass": (
            trial.passed and all(trial.prediction_results.values())
        ),
        "candidates_share_one_stream_and_persistent_trace": (
            same_stream and trace_chains
        ),
        "combined_candidate_is_search_admissible_and_not_id_memorizer": (
            combined.candidate.admissible_for_search
            and source_experiment.registry.registry_id
            not in combined.candidate.candidate_id
            and combined.candidate.role == "mechanism_factorial_arm"
        ),
        "trial_replay_is_content_identical": trial.trial_id == replay.trial_id,
        "phase_four_did_not_mutate_control_plane_or_claim_integration": (
            not control_value["campaigns"]
            and control.graph.progress_by_role()["objective"]
            == phase_three_manifest["checkpoint_status"]["objective_progress"]
            and control.graph.progress_by_role()["evidence"]
            == phase_three_manifest["checkpoint_status"]["evidence_progress"]
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    return CausalSchemaMechanismVerification(
        check_results=checks,
        dossier_id=dossier.dossier_id,
        hypothesis_id=hypothesis.hypothesis_id,
        preregistration_id=preregistration.preregistration_id,
        trial_id=trial.trial_id,
        arm_functional_gates={
            key: item.functional_gates
            for key, item in trial.evaluations.items()
        },
        combined_audit_scores=combined.partition_scores[
            SlicePartition.AUDIT.value
        ],
        limitations=(
            "The mechanism is validated only in the frozen symbolic vertical slice.",
            "Low-degree polynomial induction and explicit graph traversal are bounded implementations of the concept, not a universal representation.",
            "The combined candidate has not yet passed conservative adoption against independent expanded families or long trajectories.",
        ),
    )
