from __future__ import annotations

import hashlib
from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.self_ask_incumbent_v1 import (
    DIRECT_DEMONSTRATIONS,
    VERSION as INCUMBENT_VERSION,
    digest,
    direct_prompt,
    self_ask_prompt,
)


VERSION = "cognitive-causal-structure-phenomenon-atlas-v1"
ARM_ORDER = (
    "incumbent_self_ask",
    "direct",
    "transaction_atomic_trusted",
    "transaction_interleaved_trusted",
    "provenance_swapped_current",
)
HORIZON_SLOTS = {
    "mapping_development": (
        ("birthplace_capital", 0),
        ("birthplace_callingcode", 0),
        ("birthdate_uspresident", 0),
        ("birthyear_masterchamp", 0),
    ),
    "mapping_holdout": (
        ("birthplace_currency", 0),
        ("birthplace_tld", 0),
        ("birthyear_nobelLiterature", 0),
        ("birthdate_uspresident", 1),
    ),
    "mapping_replication": (
        ("birthplace_ccn3", 0),
        ("birthplace_capital", 1),
        ("birthyear_masterchamp", 1),
        ("birthyear_nobelLiterature", 1),
    ),
}


def regime_for_category(category: str) -> str:
    if category.startswith("birthplace_"):
        return "geographic_reference_composition"
    if category == "birthdate_uspresident":
        return "temporal_office_composition"
    return "temporal_award_composition"


def first_hop_group(category: str) -> str:
    if category.startswith("birthplace_"):
        return "birth_country"
    if category == "birthdate_uspresident":
        return "birth_date"
    return "birth_year"


def select_panel(
    rows: Sequence[Mapping[str, Any]],
    excluded_source_digests: set[str],
) -> tuple[
    list[Mapping[str, Any]],
    list[Mapping[str, Any]],
    list[Mapping[str, Any]],
]:
    selected: list[tuple[str, Mapping[str, Any]]] = []
    for horizon, slots in HORIZON_SLOTS.items():
        for category, ordinal in slots:
            candidates = [
                row
                for row in rows
                if row.get("category") == category
                and digest(row) not in excluded_source_digests
            ]
            ordered = sorted(
                candidates,
                key=lambda row: hashlib.sha256(
                    (
                        VERSION
                        + "\x1f"
                        + horizon
                        + "\x1f"
                        + category
                        + "\x1f"
                        + str(row["Question"])
                    ).encode("utf-8")
                ).hexdigest(),
            )
            if len(ordered) <= ordinal:
                raise ValueError("insufficient frozen candidates for %s" % category)
            selected.append((horizon, ordered[ordinal]))
    if len({digest(row) for _, row in selected}) != 12:
        raise ValueError("phenomenon panel selection duplicated a source row")

    by_group: dict[str, list[Mapping[str, Any]]] = {}
    for _, row in selected:
        by_group.setdefault(first_hop_group(str(row["category"])), []).append(row)
    stale_by_digest = {}
    for group_rows in by_group.values():
        for index, row in enumerate(group_rows):
            correct = str(row["A1"][0])
            alternatives = [
                str(candidate["A1"][0])
                for candidate in group_rows[index + 1 :] + group_rows[: index + 1]
                if str(candidate["A1"][0]).casefold() != correct.casefold()
            ]
            if not alternatives:
                raise ValueError("first-hop group has no distinct stale control")
            stale_by_digest[digest(row)] = alternatives[0]

    public = []
    evidence = []
    authority = []
    for index, (horizon, row) in enumerate(selected):
        source_digest = digest(row)
        item_id = "atlas-%02d-%s" % (index, source_digest[:12])
        category = str(row["category"])
        public.append(
            {
                "item_id": item_id,
                "category": category,
                "regime": regime_for_category(category),
                "horizon": horizon,
                "composed_question": str(row["Question"]),
                "first_hop_question": str(row["Q1"]),
                "source_row_digest": source_digest,
                "maximum_new_tokens": 192,
            }
        )
        evidence.append(
            {
                "item_id": item_id,
                "current_first_hop": str(row["A1"][0]),
                "stale_first_hop": stale_by_digest[source_digest],
                "contains_composed_answer": False,
                "contains_second_hop_answer": False,
            }
        )
        authority.append(
            {
                "item_id": item_id,
                "composed_answers": [str(value) for value in row["Answer"]],
                "second_hop_answers": [str(value) for value in row["A2"]],
                "source_row_digest": source_digest,
            }
        )
    return public, evidence, authority


def arm_prompt(
    item: Mapping[str, Any],
    evidence: Mapping[str, Any],
    arm: str,
) -> str:
    question = str(item["composed_question"])
    if arm == "incumbent_self_ask":
        return self_ask_prompt(question)
    if arm == "direct":
        return direct_prompt(question)
    current = str(evidence["current_first_hop"])
    stale = str(evidence["stale_first_hop"])
    first_hop_question = str(item["first_hop_question"])
    if arm == "transaction_atomic_trusted":
        state = """FIRST-HOP STATE TRANSACTION
Query represented by this state: {first_hop}
Atomic commit records:
- v1 | INVALIDATED | source=generated_guess | value={stale}
- v2 | CURRENT | source=trusted_reference | value={current}
Commit rule: use v2; v1 cannot overwrite or contaminate the current state.""".format(
            first_hop=first_hop_question,
            stale=stale,
            current=current,
        )
    elif arm == "transaction_interleaved_trusted":
        state = """FIRST-HOP STATE TRANSACTION
Query represented by this state: {first_hop}
Interleaved arrival records:
- v2 | CURRENT | source=trusted_reference | value={current}
- v1 | INVALIDATED_DELAYED_WRITE | source=generated_guess | value={stale}
Commit rule: v2 remains current; the delayed v1 write cannot overwrite or contaminate it.""".format(
            first_hop=first_hop_question,
            stale=stale,
            current=current,
        )
    elif arm == "provenance_swapped_current":
        state = """FIRST-HOP STATE TRANSACTION
Query represented by this state: {first_hop}
Atomic commit records with swapped provenance:
- v1 | INVALIDATED | source=trusted_archive | value={stale}
- v2 | CURRENT | source=generated_unverified | value={current}
Resolve the question while respecting both version status and source provenance.""".format(
            first_hop=first_hop_question,
            stale=stale,
            current=current,
        )
    else:
        raise ValueError("unknown atlas arm: %s" % arm)
    return (
        "%s\n\n%s\n\nQuestion: %s\nSo the final answer is:"
        % (DIRECT_DEMONSTRATIONS, state, question)
    )


def source_version() -> str:
    return "%s+%s" % (VERSION, INCUMBENT_VERSION)


__all__ = [
    "ARM_ORDER",
    "HORIZON_SLOTS",
    "VERSION",
    "arm_prompt",
    "first_hop_group",
    "regime_for_category",
    "select_panel",
    "source_version",
]
