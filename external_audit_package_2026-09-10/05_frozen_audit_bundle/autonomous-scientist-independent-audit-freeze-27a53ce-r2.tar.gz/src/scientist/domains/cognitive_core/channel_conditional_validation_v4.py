from __future__ import annotations

from dataclasses import dataclass
import math
from statistics import mean, stdev
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.evidence_invariant_selection_v4 import (
    INDEPENDENT_SELECTION_METRICS,
)
from scientist.domains.cognitive_core.heldout_model_selection_v3 import (
    HeldoutOutcome,
)
from scientist.domains.cognitive_core.model_ambiguity_dossier_v4 import (
    EVIDENCE_CHANNEL_METRICS,
    EVIDENCE_CHANNEL_SIGNS,
)
from scientist.program.diagnostics import DiagnosticDisposition


CHANNEL_VALIDATION_VERSION = "cognitive-core-channel-conditional-validation-v4"
CHANNEL_VALIDATION_EVALUATOR_REF = "channel-conditional-evaluator-v4"
CHANNEL_VALIDATION_VERIFIER_REF = "channel-conditional-independent-verifier-v4"

CHANNEL_ARM_IDS = (
    "baseline",
    "sham",
    "representation_half",
    "routing_half",
    "representation_half+routing_half",
)


@dataclass(frozen=True)
class FrozenChannelValidationRegistry:
    dossier_id: str
    concept_id: str
    data_seed: int
    model_seeds: Tuple[int, ...]
    total_steps: int
    arm_ids: Tuple[str, ...] = CHANNEL_ARM_IDS
    representation_channel_gap_floor: float = 0.05
    routing_channel_gap_floor: float = 0.05
    positive_effect_floor: float = 0.0
    maximum_evidence_interaction: float = 0.02
    minimum_leave_one_seed_fraction: float = 0.75
    version: str = CHANNEL_VALIDATION_VERSION

    def __post_init__(self) -> None:
        if not self.dossier_id or not self.concept_id:
            raise ValueError("channel validation requires frozen source identities")
        if len(set(self.model_seeds)) != len(self.model_seeds) or len(
            self.model_seeds
        ) < 8:
            raise ValueError("channel validation requires eight unique seeds")
        if self.arm_ids != CHANNEL_ARM_IDS:
            raise ValueError("channel validation arms must match the frozen 2x2 design")
        if self.total_steps < 1:
            raise ValueError("channel validation training horizon must be positive")
        if not 0.5 <= self.minimum_leave_one_seed_fraction <= 1.0:
            raise ValueError("leave-one-seed fraction is outside [0.5, 1]")

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, *, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": self.version,
            "dossier_id": self.dossier_id,
            "concept_id": self.concept_id,
            "data_seed": self.data_seed,
            "model_seeds": list(self.model_seeds),
            "total_steps": self.total_steps,
            "arm_ids": list(self.arm_ids),
            "independent_selection_metrics": list(
                INDEPENDENT_SELECTION_METRICS
            ),
            "report_only_derived_metrics": [
                "cognitive_core_score",
                "known_answer_destruction",
            ],
            "effect_gates": {
                "representation_channel_gap_floor": (
                    self.representation_channel_gap_floor
                ),
                "routing_channel_gap_floor": self.routing_channel_gap_floor,
                "positive_effect_floor": self.positive_effect_floor,
                "maximum_evidence_interaction": (
                    self.maximum_evidence_interaction
                ),
                "minimum_leave_one_seed_fraction": (
                    self.minimum_leave_one_seed_fraction
                ),
            },
            "decision_rule": (
                "support capability-channel conditional causality only when "
                "every prospective prediction and validity check passes"
            ),
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


def frozen_channel_validation_registry_from_dict(
    value: Mapping[str, Any],
) -> FrozenChannelValidationRegistry:
    gates = value["effect_gates"]
    registry = FrozenChannelValidationRegistry(
        dossier_id=str(value["dossier_id"]),
        concept_id=str(value["concept_id"]),
        data_seed=int(value["data_seed"]),
        model_seeds=tuple(int(item) for item in value["model_seeds"]),
        total_steps=int(value["total_steps"]),
        arm_ids=tuple(str(item) for item in value["arm_ids"]),
        representation_channel_gap_floor=float(
            gates["representation_channel_gap_floor"]
        ),
        routing_channel_gap_floor=float(gates["routing_channel_gap_floor"]),
        positive_effect_floor=float(gates["positive_effect_floor"]),
        maximum_evidence_interaction=float(
            gates["maximum_evidence_interaction"]
        ),
        minimum_leave_one_seed_fraction=float(
            gates["minimum_leave_one_seed_fraction"]
        ),
        version=str(value["version"]),
    )
    supplied = value.get("registry_id")
    if supplied is not None and str(supplied) != registry.registry_id:
        raise ValueError("channel validation registry identity mismatch")
    return registry


def _paired_samples(
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
    left_arm: str,
    right_arm: str | None,
    metric: str,
) -> Tuple[float, ...]:
    left = outcomes[left_arm][metric].samples
    right = (
        tuple(0.0 for _ in left)
        if right_arm is None
        else outcomes[right_arm][metric].samples
    )
    return tuple(a - b for a, b in zip(left, right))


def _evidence_samples(
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
    left_arm: str,
    right_arm: str | None,
) -> Tuple[float, ...]:
    values = {
        metric: _paired_samples(outcomes, left_arm, right_arm, metric)
        for metric in EVIDENCE_CHANNEL_METRICS
    }
    seed_count = len(next(iter(values.values())))
    return tuple(
        sum(
            EVIDENCE_CHANNEL_SIGNS[metric] * values[metric][seed]
            for metric in EVIDENCE_CHANNEL_METRICS
        )
        / float(len(EVIDENCE_CHANNEL_METRICS))
        for seed in range(seed_count)
    )


def _average(left: Sequence[float], right: Sequence[float]) -> Tuple[float, ...]:
    return tuple((a + b) / 2.0 for a, b in zip(left, right))


def _difference(left: Sequence[float], right: Sequence[float]) -> Tuple[float, ...]:
    return tuple(a - b for a, b in zip(left, right))


def _effect(samples: Sequence[float]) -> Dict[str, Any]:
    values = tuple(float(item) for item in samples)
    standard_error = stdev(values) / math.sqrt(len(values))
    return {
        "mean": mean(values),
        "standard_error": standard_error,
        "normal_95_interval": [
            mean(values) - 1.96 * standard_error,
            mean(values) + 1.96 * standard_error,
        ],
        "samples": list(values),
    }


def _leave_one_positive_fraction(samples: Sequence[float]) -> float:
    values = tuple(samples)
    winners = sum(
        mean(values[:index] + values[index + 1 :]) > 0.0
        for index in range(len(values))
    )
    return winners / float(len(values))


@dataclass(frozen=True)
class ChannelConditionalValidation:
    registry_id: str
    effects: Mapping[str, Mapping[str, Any]]
    prediction_checks: Mapping[str, bool]
    validity_checks: Mapping[str, bool]
    leave_one_seed_positive_fractions: Mapping[str, float]
    supported_model_ids: Tuple[str, ...]
    disposition: DiagnosticDisposition
    seed_count: int
    version: str = CHANNEL_VALIDATION_VERSION

    @property
    def resolved(self) -> bool:
        return (
            all(self.prediction_checks.values())
            and all(self.validity_checks.values())
            and self.disposition != DiagnosticDisposition.INCONCLUSIVE
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "registry_id": self.registry_id,
            "effects": {
                key: dict(value) for key, value in sorted(self.effects.items())
            },
            "prediction_checks": dict(sorted(self.prediction_checks.items())),
            "validity_checks": dict(sorted(self.validity_checks.items())),
            "leave_one_seed_positive_fractions": dict(
                sorted(self.leave_one_seed_positive_fractions.items())
            ),
            "supported_model_ids": list(self.supported_model_ids),
            "disposition": self.disposition.value,
            "seed_count": self.seed_count,
            "resolved": self.resolved,
        }


def validate_channel_conditional_concept(
    registry: FrozenChannelValidationRegistry,
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
) -> ChannelConditionalValidation:
    if set(outcomes) != set(CHANNEL_ARM_IDS) - {"baseline"}:
        raise ValueError("channel outcomes do not match the frozen design")
    seed_count = len(next(iter(next(iter(outcomes.values())).values())).samples)
    if seed_count != len(registry.model_seeds):
        raise ValueError("channel outcome seed count does not match registry")

    procedure_rep_at_zero = _paired_samples(
        outcomes, "representation_half", None, "procedure_accuracy"
    )
    procedure_rep_at_routing = _paired_samples(
        outcomes,
        "representation_half+routing_half",
        "routing_half",
        "procedure_accuracy",
    )
    evidence_rep_at_zero = _evidence_samples(
        outcomes, "representation_half", None
    )
    evidence_rep_at_routing = _evidence_samples(
        outcomes,
        "representation_half+routing_half",
        "routing_half",
    )
    procedure_route_at_zero = _paired_samples(
        outcomes, "routing_half", None, "procedure_accuracy"
    )
    procedure_route_at_rep = _paired_samples(
        outcomes,
        "representation_half+routing_half",
        "representation_half",
        "procedure_accuracy",
    )
    evidence_route_at_zero = _evidence_samples(outcomes, "routing_half", None)
    evidence_route_at_rep = _evidence_samples(
        outcomes,
        "representation_half+routing_half",
        "representation_half",
    )

    average_procedure_rep = _average(
        procedure_rep_at_zero, procedure_rep_at_routing
    )
    average_evidence_rep = _average(evidence_rep_at_zero, evidence_rep_at_routing)
    average_procedure_route = _average(
        procedure_route_at_zero, procedure_route_at_rep
    )
    average_evidence_route = _average(
        evidence_route_at_zero, evidence_route_at_rep
    )
    representation_gap = _difference(
        average_procedure_rep, average_evidence_rep
    )
    routing_gap = _difference(average_evidence_route, average_procedure_route)
    evidence_interaction = _difference(
        evidence_rep_at_routing, evidence_rep_at_zero
    )

    effect_samples = {
        "procedure_representation_at_zero_routing": procedure_rep_at_zero,
        "procedure_representation_at_half_routing": procedure_rep_at_routing,
        "procedure_representation_effect": average_procedure_rep,
        "evidence_representation_effect": average_evidence_rep,
        "representation_channel_gap": representation_gap,
        "procedure_routing_effect": average_procedure_route,
        "evidence_routing_effect": average_evidence_route,
        "routing_channel_gap": routing_gap,
        "evidence_representation_interaction": evidence_interaction,
    }
    effects = {key: _effect(value) for key, value in effect_samples.items()}
    leave_one = {
        "representation_channel_gap": _leave_one_positive_fraction(
            representation_gap
        ),
        "routing_channel_gap": _leave_one_positive_fraction(routing_gap),
    }
    predictions = {
        "representation_improves_procedure_without_routing": (
            effects["procedure_representation_at_zero_routing"]["mean"]
            > registry.positive_effect_floor
        ),
        "representation_improves_procedure_with_routing": (
            effects["procedure_representation_at_half_routing"]["mean"]
            > registry.positive_effect_floor
        ),
        "representation_is_procedure_selective": (
            effects["representation_channel_gap"]["mean"]
            >= registry.representation_channel_gap_floor
            and leave_one["representation_channel_gap"]
            >= registry.minimum_leave_one_seed_fraction
        ),
        "routing_improves_evidence_control": (
            effects["evidence_routing_effect"]["mean"]
            > registry.positive_effect_floor
        ),
        "routing_is_evidence_selective": (
            effects["routing_channel_gap"]["mean"]
            >= registry.routing_channel_gap_floor
            and leave_one["routing_channel_gap"]
            >= registry.minimum_leave_one_seed_fraction
        ),
        "routing_does_not_amplify_representation_evidence_effect": (
            effects["evidence_representation_interaction"]["mean"]
            <= registry.maximum_evidence_interaction
        ),
    }
    validity = {
        "at_least_eight_heldout_seeds": seed_count >= 8,
        "all_effects_are_finite": all(
            math.isfinite(float(value["mean"]))
            and math.isfinite(float(value["standard_error"]))
            for value in effects.values()
        ),
        "derived_metrics_are_report_only": set(
            INDEPENDENT_SELECTION_METRICS
        ).isdisjoint({"cognitive_core_score", "known_answer_destruction"}),
        "registry_matches_frozen_arm_design": registry.arm_ids == CHANNEL_ARM_IDS,
    }
    supported = (
        ("capability_channel_conditional_causality",)
        if all(predictions.values()) and all(validity.values())
        else ()
    )
    # The tested leaf asserts that the old global descriptors suffice.  A
    # replicated target-channel dependency refutes that assertion and requires
    # a representation revision.  Failure to replicate is kept inconclusive;
    # it does not establish sufficiency.
    disposition = (
        DiagnosticDisposition.REFUTED
        if supported
        else DiagnosticDisposition.INCONCLUSIVE
    )
    return ChannelConditionalValidation(
        registry_id=registry.registry_id,
        effects=effects,
        prediction_checks=predictions,
        validity_checks=validity,
        leave_one_seed_positive_fractions=leave_one,
        supported_model_ids=supported,
        disposition=disposition,
        seed_count=seed_count,
    )
