from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.channel_conditional_validation_v4 import (
    CHANNEL_VALIDATION_VERIFIER_REF,
    ChannelConditionalValidation,
    FrozenChannelValidationRegistry,
    validate_channel_conditional_concept,
)
from scientist.domains.cognitive_core.graded_causal_mlx_v3 import GradedRunResult
from scientist.domains.cognitive_core.heldout_model_selection_v3 import (
    FrozenModelPredictionRegistry,
    HeldoutModelSelection,
    build_heldout_outcomes,
)
from scientist.domains.cognitive_core.heldout_model_selection_verifier_v3 import (
    verify_heldout_model_selection,
)


@dataclass(frozen=True)
class ChannelConditionalVerification:
    passed: bool
    checks: Mapping[str, bool]
    seed_count: int
    arm_count: int
    cell_count: int
    reconstructed_validation: Mapping[str, Any]
    limitations: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "seed_count": self.seed_count,
            "arm_count": self.arm_count,
            "cell_count": self.cell_count,
            "reconstructed_validation": dict(self.reconstructed_validation),
            "limitations": list(self.limitations),
            "verifier_ref": CHANNEL_VALIDATION_VERIFIER_REF,
        }


def verify_channel_conditional_validation(
    runs: Sequence[GradedRunResult],
    channel_registry: FrozenChannelValidationRegistry,
    wiring_registry: FrozenModelPredictionRegistry,
    wiring_selection: HeldoutModelSelection,
    reported: ChannelConditionalValidation,
) -> ChannelConditionalVerification:
    wiring = verify_heldout_model_selection(
        runs,
        wiring_registry,
        wiring_selection,
    )
    outcomes = build_heldout_outcomes(runs)
    reconstructed = validate_channel_conditional_concept(
        channel_registry,
        outcomes,
    )
    seeds = {run.config.model_seed for run in runs}
    arms = {run.arm.arm_id for run in runs}
    checks = {
        **{"wiring.%s" % key: value for key, value in wiring.checks.items()},
        "wiring_verification_passed": wiring.passed,
        "channel_registry_seeds_match_runs": (
            seeds == set(channel_registry.model_seeds)
        ),
        "channel_registry_arms_match_runs": (
            arms == set(channel_registry.arm_ids)
        ),
        "channel_registry_data_seed_matches_runs": all(
            run.config.data_seed == channel_registry.data_seed for run in runs
        ),
        "reported_channel_validation_is_reconstructed": (
            reconstructed.as_dict() == reported.as_dict()
        ),
        "channel_validity_checks_pass": all(reported.validity_checks.values()),
    }
    limitations = (
        "This is a second micro-horizon synthetic learning test, not a cross-scale architecture validation.",
        "Routing is an externally supplied relevance intervention and does not test learned relevance inference.",
        "Representation separation is a fixed feature-mask intervention, so the result does not identify a production architecture.",
        "The capability-channel concept was discovered on the immediately preceding held-out run; this test supplies one prospective replication only.",
    )
    return ChannelConditionalVerification(
        passed=all(checks.values()),
        checks=checks,
        seed_count=len(seeds),
        arm_count=len(arms),
        cell_count=len(runs),
        reconstructed_validation=reconstructed.as_dict(),
        limitations=limitations,
    )

