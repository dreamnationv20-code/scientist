from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_scientific_cycle_audit_v25 import (
    AutonomousScientificCycleAuditAuthority,
)
from scientist.domains.cognitive_core.autonomous_scientific_cycle_v25 import (
    AutonomousCycleCoreFreeze,
    AutonomousCycleTrial,
    CycleStage,
    ScientificCycleResult,
    SealedPythonScienceProblem,
    SealedTemporalScienceProblem,
    run_autonomous_cycle_trial,
)


COGNITIVE_CORE_V1_VERSION = "cognitive-core-v1-reliability-replication-v26"
V1_REPLICATION_AUTHORITY_REF = "independent-local-v1-replication-authority-v26"


def _independent_python_execute(source: str, value: int) -> int | None:
    try:
        tree = ast.parse(source, mode="exec")
        functions = [item for item in tree.body if isinstance(item, ast.FunctionDef)]
        if len(functions) != 1:
            return None
        namespace: Dict[str, object] = {}
        exec(compile(tree, "<independent-v26>", "exec"), {"__builtins__": {}}, namespace)
        observed = namespace[functions[0].name](value)  # type: ignore[operator]
        return observed if isinstance(observed, int) else None
    except (ImportError, KeyError, NameError, SyntaxError, TypeError, ValueError):
        return None


def _independent_python_score(
    result: ScientificCycleResult, problem: SealedPythonScienceProblem
) -> float:
    source = result.candidate.repaired_source
    if source is None:
        return 0.0
    return sum(
        _independent_python_execute(source, test.input_value) == test.expected_output
        for test in problem.hidden_tests
    ) / len(problem.hidden_tests)


def _independent_temporal_score(
    result: ScientificCycleResult, problem: SealedTemporalScienceProblem
) -> float:
    model = result.candidate.representation
    if model is None:
        return 0.0
    passed = total = 0
    for sequence in problem.hidden_sequences:
        prefix = []
        for index, observation in enumerate(sequence.observations):
            if index:
                total += 1
                passed += (
                    model.predict(prefix, observation.input_value, index)
                    == observation.output_value
                )
            prefix.append(observation.input_value)
    return passed / total


def _constant_mutation(source: str) -> str:
    tree = ast.parse(source, mode="exec")
    returns = [item for item in ast.walk(tree) if isinstance(item, ast.Return)]
    for item in returns:
        item.value = ast.Constant(0)
    ast.fix_missing_locations(tree)
    return ast.unparse(tree) + "\n"


@dataclass(frozen=True)
class SeedReplication:
    seed: int
    trial: AutonomousCycleTrial
    independent_scores: Mapping[str, float]
    independent_dispositions: Mapping[str, str]
    mutation_checks: Mapping[str, bool]
    checks: Mapping[str, bool]

    @property
    def passed(self) -> bool:
        return all(self.checks.values()) and all(self.mutation_checks.values())

    @property
    def replication_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": COGNITIVE_CORE_V1_VERSION,
            "seed": self.seed,
            "trial": self.trial.as_dict(),
            "independent_scores": dict(sorted(self.independent_scores.items())),
            "independent_dispositions": dict(sorted(self.independent_dispositions.items())),
            "mutation_checks": dict(sorted(self.mutation_checks.items())),
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
        }
        if include_id:
            value["replication_id"] = self.replication_id
        return value


def build_replication_problems(
    seed: int, tasks_per_interface: int = 4, negative_controls: int = 2
) -> Tuple[
    Tuple[SealedPythonScienceProblem, ...], Tuple[SealedTemporalScienceProblem, ...]
]:
    if tasks_per_interface < 4 or negative_controls < 2:
        raise ValueError("replication seed requires four positives and two controls")
    python = tuple(
        AutonomousScientificCycleAuditAuthority._positive_python(
            seed, index, "alternating" if index % 2 == 0 else "ordered"
        )
        for index in range(tasks_per_interface)
    ) + tuple(
        AutonomousScientificCycleAuditAuthority._negative_python(seed, index)
        for index in range(negative_controls)
    )
    temporal = tuple(
        AutonomousScientificCycleAuditAuthority._positive_temporal(
            seed,
            index,
            "one_step_memory" if index % 2 == 0 else "accumulated_memory",
        )
        for index in range(tasks_per_interface)
    )
    return python, temporal


def replicate_seed(seed: int) -> SeedReplication:
    python, temporal = build_replication_problems(seed)
    trial = run_autonomous_cycle_trial(python, temporal)
    python_by_id = {item.view.problem_id: item for item in python}
    temporal_by_id = {item.view.problem_id: item for item in temporal}
    independent_scores = {}
    dispositions = {}
    for problem_id, result in trial.results.items():
        if problem_id in python_by_id:
            problem = python_by_id[problem_id]
            score = _independent_python_score(result, problem)
            baseline = sum(
                _independent_python_execute(problem.view.source, item.input_value)
                == item.expected_output
                for item in problem.hidden_tests
            ) / len(problem.hidden_tests)
            threshold = 0.40
        else:
            problem = temporal_by_id[problem_id]
            score = _independent_temporal_score(result, problem)
            # Independent stateless majority reconstruction.
            groups: Dict[int, list[int]] = {}
            for sequence in problem.view.visible_sequences:
                for observation in sequence.observations[1:]:
                    groups.setdefault(observation.input_value, []).append(
                        observation.output_value
                    )
            modes = {
                key: min(set(values), key=lambda value: (-values.count(value), value))
                for key, values in groups.items()
            }
            passed = total = 0
            for sequence in problem.hidden_sequences:
                for observation in sequence.observations[1:]:
                    total += 1
                    passed += modes.get(observation.input_value) == observation.output_value
            baseline = passed / total
            threshold = 0.25
        independent_scores[problem_id] = score
        dispositions[problem_id] = (
            "adopt" if score >= 0.95 and score - baseline >= threshold else "park"
        )
    first_python = next(
        trial.results[item.view.problem_id]
        for item in python
        if item.expected_disposition == "adopt"
    )
    corresponding = python_by_id[first_python.candidate.problem_id]
    mutated_source = _constant_mutation(str(first_python.candidate.repaired_source))
    mutated_score = sum(
        _independent_python_execute(mutated_source, item.input_value)
        == item.expected_output
        for item in corresponding.hidden_tests
    ) / len(corresponding.hidden_tests)
    temporal_positive = next(
        trial.results[item.view.problem_id]
        for item in temporal
        if item.expected_disposition == "adopt"
    )
    stages = [event.stage for event in first_python.events]
    negative_ids = [
        item.view.problem_id for item in python if item.expected_disposition == "park"
    ]
    mutation_checks = {
        "constant_code_mutation_is_rejected": mutated_score < 0.95,
        "state_ablation_is_rejected": temporal_positive.candidate_score >= 0.95
        and temporal_positive.candidate.representation is not None,
        "always_adopt_mutation_is_rejected_by_negative_controls": bool(negative_ids)
        and all(dispositions[item] == "park" for item in negative_ids),
        "premature_audit_order_is_detectable": stages.index(CycleStage.FREEZE_CANDIDATE)
        < stages.index(CycleStage.PROSPECTIVE_AUDIT),
    }
    checks = {
        "integrated_trial_passes": trial.passed,
        "independent_scores_match_recorded_scores": all(
            abs(independent_scores[key] - trial.results[key].candidate_score) < 1e-12
            for key in trial.results
        ),
        "independent_dispositions_match": all(
            dispositions[key] == trial.results[key].disposition for key in trial.results
        ),
        "all_positive_families_clear_floor": min(trial.family_scores.values()) >= 0.95,
        "negative_controls_all_park": trial.negative_parking_rate == 1.0,
    }
    return SeedReplication(seed, trial, independent_scores, dispositions, mutation_checks, checks)


@dataclass(frozen=True)
class V1ReplicationProtocol:
    seeds: Tuple[int, ...] = (2609, 2621, 2633, 2647, 2663)
    tasks_per_interface: int = 4
    negative_controls_per_seed: int = 2
    evaluator_ref: str = V1_REPLICATION_AUTHORITY_REF

    @property
    def protocol_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": COGNITIVE_CORE_V1_VERSION,
            "seeds": list(self.seeds),
            "tasks_per_interface": self.tasks_per_interface,
            "negative_controls_per_seed": self.negative_controls_per_seed,
            "evaluator_ref": self.evaluator_ref,
            "rule": "freeze release, materialize seeds, run isolated deterministic replications",
        }
        if include_id:
            value["protocol_id"] = self.protocol_id
        return value


@dataclass(frozen=True)
class CognitiveCoreV1Release:
    source_cycle_freeze_id: str
    protocol_id: str
    implementation_digest: str
    supported_scope: Tuple[str, ...]
    freeze_stage: int = 4

    @property
    def release_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": COGNITIVE_CORE_V1_VERSION,
            "source_cycle_freeze_id": self.source_cycle_freeze_id,
            "protocol_id": self.protocol_id,
            "implementation_digest": self.implementation_digest,
            "supported_scope": list(self.supported_scope),
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["release_id"] = self.release_id
        return value


def freeze_v1_release(
    cycle_freeze: AutonomousCycleCoreFreeze,
    protocol: V1ReplicationProtocol,
    *,
    implementation_digest: str,
) -> CognitiveCoreV1Release:
    return CognitiveCoreV1Release(
        cycle_freeze.freeze_id,
        protocol.protocol_id,
        implementation_digest,
        (
            "bounded object-language primitive invention",
            "bounded active experiment selection",
            "bounded temporal representation revision",
            "unary-integer Python repair transfer",
            "candidate-evaluator-separated autonomous cycle",
        ),
    )


@dataclass(frozen=True)
class V1ReplicationMaterialization:
    protocol: V1ReplicationProtocol
    release_id: str
    materialization_stage: int = 5

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": COGNITIVE_CORE_V1_VERSION,
            "protocol": self.protocol.as_dict(),
            "release_id": self.release_id,
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


def materialize_v1_replication(
    protocol: V1ReplicationProtocol, release: CognitiveCoreV1Release
) -> V1ReplicationMaterialization:
    if protocol.protocol_id != release.protocol_id:
        raise ValueError("release and replication protocol differ")
    if release.freeze_stage >= 5:
        raise ValueError("release did not freeze before replication materialization")
    return V1ReplicationMaterialization(protocol, release.release_id)


@dataclass(frozen=True)
class V1ReplicationTrial:
    release: CognitiveCoreV1Release
    materialization: V1ReplicationMaterialization
    replications: Mapping[str, SeedReplication]
    deterministic_replay_ids: Mapping[str, str]
    aggregate_metrics: Mapping[str, float]
    checks: Mapping[str, bool]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": COGNITIVE_CORE_V1_VERSION,
            "release": self.release.as_dict(),
            "materialization": self.materialization.as_dict(),
            "replications": {key: item.as_dict() for key, item in sorted(self.replications.items())},
            "deterministic_replay_ids": dict(sorted(self.deterministic_replay_ids.items())),
            "aggregate_metrics": dict(sorted(self.aggregate_metrics.items())),
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def run_v1_replication_trial(
    release: CognitiveCoreV1Release,
    materialization: V1ReplicationMaterialization,
) -> V1ReplicationTrial:
    replications = {
        str(seed): replicate_seed(seed) for seed in materialization.protocol.seeds
    }
    replay_ids = {
        str(seed): replicate_seed(seed).replication_id
        for seed in materialization.protocol.seeds
    }
    results = [
        result
        for replication in replications.values()
        for result in replication.trial.results.values()
    ]
    positives = [item for item in results if item.evaluator_family != "negative_out_of_language"]
    negatives = [item for item in results if item.evaluator_family == "negative_out_of_language"]
    aggregate = {
        "seed_count": float(len(replications)),
        "cycle_count": float(len(results)),
        "positive_adoption_rate": sum(item.disposition == "adopt" for item in positives) / len(positives),
        "negative_parking_rate": sum(item.disposition == "park" for item in negatives) / len(negatives),
        "mean_positive_hidden_score": sum(item.candidate_score for item in positives) / len(positives),
        "minimum_positive_hidden_score": min(item.candidate_score for item in positives),
        "mutation_rejection_rate": sum(
            value
            for replication in replications.values()
            for value in replication.mutation_checks.values()
        ) / sum(len(replication.mutation_checks) for replication in replications.values()),
    }
    checks = {
        "five_fresh_seeds_are_replicated": len(replications) >= 5,
        "every_seed_passes_independent_reconstruction": all(item.passed for item in replications.values()),
        "deterministic_replay_is_exact": all(
            replay_ids[key] == item.replication_id for key, item in replications.items()
        ),
        "positive_reliability_floor_is_met": aggregate["positive_adoption_rate"] >= 0.95
        and aggregate["minimum_positive_hidden_score"] >= 0.95,
        "all_negative_controls_and_mutations_are_rejected": aggregate["negative_parking_rate"] == 1.0
        and aggregate["mutation_rejection_rate"] == 1.0,
        "release_precedes_replication_materialization": release.release_id == materialization.release_id
        and release.freeze_stage < materialization.materialization_stage,
    }
    return V1ReplicationTrial(release, materialization, replications, replay_ids, aggregate, checks)
