from __future__ import annotations

import ast
import hashlib
import json
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.reasoning_posttraining_baseline_v53a import (
    FAMILIES,
    SOURCE_CONTRACT,
    _parse_plan as _parse_legacy_plan,
    execute_blocksworld,
    score_response as _score_response,
)


VERSION = "cognitive-core-compute-control-scaling-gap-v54"
SELECTION_SEED = 54001
ITEMS_PER_FAMILY = 16
TASK_COUNT = ITEMS_PER_FAMILY * len(FAMILIES)
QWEN3_TEMPLATE_SOURCE = {
    "repository": "Qwen/Qwen3-1.7B",
    "revision": "70d244cc86ccca08cf5af4e1e306ecf908b1ad5e",
    "nonthinking_generation_prefix": "<think>\n\n</think>\n\n",
    "reason": (
        "The pinned MLX conversion predates the enable_thinking template variable. "
        "Appending this exact prefix reproduces the current official Qwen3 hard switch."
    ),
}

# This is a bounded-compute diagnostic, not an attempt to reproduce the model
# card's unconstrained 32k-token reasoning setting. Every condition receives the
# same ceiling; natural early stopping determines actual compute.
TOKEN_BUDGETS = {
    "math": 2048,
    "code": 2048,
    "planning": 2048,
    "counterfactual": 2048,
    "tool_use": 768,
}

MODEL_CONTRACT = (
    {
        "key": "qwen3_1p7b",
        "repository": "Qwen/Qwen3-1.7B-MLX-4bit",
        "revision": "21457c6f51ed54a7c16e988c0844db973815c137",
        "parameters_billions": 1.7,
        "execution": "local",
    },
    {
        "key": "qwen3_4b",
        "repository": "Qwen/Qwen3-4B-MLX-4bit",
        "revision": "52a5ab34fa604bc8af6d3ce0cac0cab10b7eb495",
        "parameters_billions": 4.0,
        "execution": "local",
    },
    {
        "key": "qwen3_8b",
        "repository": "Qwen/Qwen3-8B-MLX-4bit",
        "revision": "383413e909f3bc5303ce195ebbdf0339c5a1a2a3",
        "parameters_billions": 8.2,
        "execution": "local",
    },
    {
        "key": "qwen2p5_72b",
        "repository": "mlx-community/Qwen2.5-72B-Instruct-4bit",
        "revision": "36a74b07390031bb18c9f12fb7c06699bc6273c4",
        "parameters_billions": 72.0,
        "execution": "external_required",
    },
)

CONDITION_CONTRACT = (
    {
        "key": "qwen3_1p7b_no_think",
        "model_key": "qwen3_1p7b",
        "enable_thinking": False,
        "temperature": 0.7,
        "top_p": 0.8,
        "top_k": 20,
        "role": "small-model concise acting control",
        "required_for_local_phase": True,
    },
    {
        "key": "qwen3_1p7b_think",
        "model_key": "qwen3_1p7b",
        "enable_thinking": True,
        "temperature": 0.6,
        "top_p": 0.95,
        "top_k": 20,
        "role": "same-checkpoint internal-compute condition",
        "required_for_local_phase": True,
    },
    {
        "key": "qwen3_4b_think",
        "model_key": "qwen3_4b",
        "enable_thinking": True,
        "temperature": 0.6,
        "top_p": 0.95,
        "top_k": 20,
        "role": "intermediate same-family scale control",
        "required_for_local_phase": True,
    },
    {
        "key": "qwen3_8b_think",
        "model_key": "qwen3_8b",
        "enable_thinking": True,
        "temperature": 0.6,
        "top_p": 0.95,
        "top_k": 20,
        "role": "largest laptop-feasible same-family scale control",
        "required_for_local_phase": True,
    },
    {
        "key": "qwen2p5_72b_reference",
        "model_key": "qwen2p5_72b",
        "enable_thinking": False,
        "temperature": 0.7,
        "top_p": 0.8,
        "top_k": 20,
        "role": "70B-class external reference",
        "required_for_local_phase": False,
    },
)


@dataclass(frozen=True)
class ScalingTask:
    task_id: str
    family: str
    prompt: str
    authority: Mapping[str, Any]
    source_id: str

    def public_dict(self) -> Mapping[str, Any]:
        return {
            "task_id": self.task_id,
            "family": self.family,
            "prompt": self.prompt,
            "source_id": self.source_id,
            "maximum_new_tokens": TOKEN_BUDGETS[self.family],
        }

    def authority_dict(self) -> Mapping[str, Any]:
        return {**self.public_dict(), "authority": dict(self.authority)}


def _read_jsonl(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    )


def _jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_immutable(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M54 artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")


def opened_source_ids(project: Path) -> frozenset[str]:
    paths = (
        project / "data/cognitive_core/reasoning_posttraining_baseline_v53a/tasks-public.jsonl",
        project / "data/cognitive_core/reasoning_posttraining_baseline_v53ar/tasks-public.jsonl",
    )
    values = set()
    for path in paths:
        if path.exists():
            values.update(str(row["source_id"]) for row in _read_jsonl(path))
    return frozenset(values)


def _stable_select(
    rows: Sequence[Mapping[str, Any]],
    identity_key: str,
    count: int,
    excluded_source_ids: frozenset[str],
    source_id,
) -> Tuple[Mapping[str, Any], ...]:
    available = [row for row in rows if source_id(row) not in excluded_source_ids]
    ranked = sorted(
        available,
        key=lambda row: hashlib.sha256(
            f"{SELECTION_SEED}:{row[identity_key]}".encode("utf-8")
        ).hexdigest(),
    )
    if len(ranked) < count:
        raise ValueError("not enough unopened source rows for frozen M54 sample")
    return tuple(ranked[:count])


def _math_tasks(project: Path, excluded: frozenset[str]) -> Tuple[ScalingTask, ...]:
    source = project / str(SOURCE_CONTRACT["gsm8k"]["path"])
    rows = tuple({**row, "row_id": index} for index, row in enumerate(_read_jsonl(source)))
    selected = _stable_select(
        rows,
        "row_id",
        ITEMS_PER_FAMILY,
        excluded,
        lambda row: f"gsm8k-test-{int(row['row_id'])}",
    )
    tasks = []
    for row in selected:
        row_id = int(row["row_id"])
        tasks.append(
            ScalingTask(
                f"m54-math-{row_id:04d}",
                "math",
                (
                    "Solve this grade-school mathematics problem. You may reason step by "
                    "step, but finish with exactly one line `FINAL: <number>`.\n\n"
                    + str(row["question"])
                ),
                {"answer": str(row["answer"]).rsplit("####", 1)[-1].strip()},
                f"gsm8k-test-{row_id}",
            )
        )
    return tuple(tasks)


def _code_tasks(project: Path, excluded: frozenset[str]) -> Tuple[ScalingTask, ...]:
    candidates = []
    for row in _read_jsonl(project / str(SOURCE_CONTRACT["cruxeval"]["path"])):
        try:
            ast.literal_eval(str(row["input"]))
            ast.literal_eval(str(row["output"]))
        except (SyntaxError, ValueError):
            continue
        if len(str(row["code"])) <= 900 and len(str(row["output"])) <= 240:
            candidates.append(row)
    selected = _stable_select(
        candidates,
        "id",
        ITEMS_PER_FAMILY,
        excluded,
        lambda row: str(row["id"]),
    )
    return tuple(
        ScalingTask(
            f"m54-code-{row['id']}",
            "code",
            (
                "Predict the exact Python value returned by this call without running it. "
                "You may reason step by step, but finish with exactly one line containing "
                "`FINAL: <Python literal>`.\n\n"
                f"{row['code']}\n\nCall: f({row['input']})"
            ),
            {"output": str(row["output"])},
            str(row["id"]),
        )
        for row in selected
    )


def _planning_tasks(project: Path, excluded: frozenset[str]) -> Tuple[ScalingTask, ...]:
    source = project / str(SOURCE_CONTRACT["planbench"]["path"])
    payload = json.loads(source.read_text(encoding="utf-8"))
    candidates = [
        row
        for row in payload["instances"]
        if 1 <= len(str(row["ground_truth_plan"]).splitlines()) <= 8
    ]
    selected = _stable_select(
        candidates,
        "instance_id",
        ITEMS_PER_FAMILY,
        excluded,
        lambda row: f"planbench-blocksworld-{int(row['instance_id'])}",
    )
    root = project / str(SOURCE_CONTRACT["planbench"]["instance_root"])
    tasks = []
    for row in selected:
        instance_id = int(row["instance_id"])
        tasks.append(
            ScalingTask(
                f"m54-planning-{instance_id:04d}",
                "planning",
                (
                    str(row["query"])
                    + "\nContinue only the plan after the final [PLAN] marker. Use exactly "
                    "one parenthesized PDDL action per line, such as `(pick-up a)` or "
                    "`(stack a b)`. Do not repeat the example. End with `FINAL: done`."
                ),
                {
                    "pddl": (root / f"instance-{instance_id}.pddl").read_text(
                        encoding="utf-8"
                    ),
                    "reference_plan": str(row["ground_truth_plan"]),
                },
                f"planbench-blocksworld-{instance_id}",
            )
        )
    return tuple(tasks)


def _counterfactual_tasks(
    project: Path, excluded: frozenset[str]
) -> Tuple[ScalingTask, ...]:
    rows = json.loads(
        (project / str(SOURCE_CONTRACT["cladder"]["path"])).read_text(
            encoding="utf-8"
        )
    )
    candidates = [
        row
        for row in rows
        if int(row.get("meta", {}).get("rung", 0)) == 3
        and str(row.get("answer", "")).casefold() in {"yes", "no"}
    ]
    selected = []
    for answer in ("yes", "no"):
        local = [row for row in candidates if str(row["answer"]).casefold() == answer]
        selected.extend(
            _stable_select(
                local,
                "question_id",
                ITEMS_PER_FAMILY // 2,
                excluded,
                lambda row: f"cladder-{int(row['question_id'])}",
            )
        )
    return tuple(
        ScalingTask(
            f"m54-counterfactual-{int(row['question_id']):05d}",
            "counterfactual",
            (
                "Answer the causal or counterfactual question using only the supplied "
                "structural/probabilistic information. You may reason step by step, but "
                "finish with exactly `FINAL: yes` or `FINAL: no`.\n\n"
                f"Information: {row['given_info']}\nQuestion: {row['question']}"
            ),
            {
                "answer": str(row["answer"]).casefold(),
                "query_type": str(row["meta"]["query_type"]),
                "story_id": str(row["meta"]["story_id"]),
            },
            f"cladder-{int(row['question_id'])}",
        )
        for row in selected
    )


def _tool_tasks(project: Path, excluded: frozenset[str]) -> Tuple[ScalingTask, ...]:
    questions = _read_jsonl(project / str(SOURCE_CONTRACT["bfcl"]["path"]))
    answers = {
        str(row["id"]): row
        for row in _read_jsonl(project / str(SOURCE_CONTRACT["bfcl"]["answer_path"]))
    }
    candidates = [
        row
        for row in questions
        if len(row.get("function", ())) == 1
        and str(row["id"]) in answers
        and len(answers[str(row["id"])].get("ground_truth", ())) == 1
    ]
    selected = _stable_select(
        candidates,
        "id",
        ITEMS_PER_FAMILY,
        excluded,
        lambda row: f"bfcl-{row['id']}",
    )
    tasks = []
    for row in selected:
        functions = row["function"]
        prompt = (
            "Choose the correct function and arguments for the user request. Do not execute "
            "the function. Finish with exactly one JSON line of the form "
            "`FINAL: {\"name\":\"function_name\",\"arguments\":{...}}`.\n\n"
            f"Functions: {json.dumps(functions, sort_keys=True)}\n"
            f"User: {row['question'][0][0]['content']}"
        )
        tasks.append(
            ScalingTask(
                f"m54-tool-{row['id']}",
                "tool_use",
                prompt,
                {
                    "ground_truth": answers[str(row["id"])]["ground_truth"],
                    "function_schema": functions[0],
                },
                f"bfcl-{row['id']}",
            )
        )
    return tuple(tasks)


def build_tasks(project: Path) -> Tuple[ScalingTask, ...]:
    excluded = opened_source_ids(project)
    tasks = (
        *_math_tasks(project, excluded),
        *_code_tasks(project, excluded),
        *_planning_tasks(project, excluded),
        *_counterfactual_tasks(project, excluded),
        *_tool_tasks(project, excluded),
    )
    if len(tasks) != TASK_COUNT:
        raise RuntimeError("M54 task count is not balanced")
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("M54 task IDs are not unique")
    if excluded & {task.source_id for task in tasks}:
        raise RuntimeError("M54 reuses an opened M53 item")
    return tuple(tasks)


def prepare_benchmark(project: Path, output: Path) -> Mapping[str, Any]:
    tasks = build_tasks(project)
    public_payload = _jsonl(task.public_dict() for task in tasks)
    authority_payload = _jsonl(task.authority_dict() for task in tasks)
    source_files = {}
    for name, contract in SOURCE_CONTRACT.items():
        keys = [key for key in ("path", "answer_path") if key in contract]
        source_files[name] = {
            str(contract[key]): _sha256(project / str(contract[key])) for key in keys
        }
    excluded = opened_source_ids(project)
    body = {
        "version": VERSION,
        "milestone": "M54",
        "question": (
            "How much of the small-to-large cognitive gap is closed by one checkpoint's "
            "internal thinking mode, and is there complementary evidence that can justify "
            "learning an internal think-versus-act controller?"
        ),
        "selection_seed": SELECTION_SEED,
        "families": list(FAMILIES),
        "items_per_family": ITEMS_PER_FAMILY,
        "task_count": len(tasks),
        "source_contract": SOURCE_CONTRACT,
        "source_file_hashes": source_files,
        "model_contract": list(MODEL_CONTRACT),
        "condition_contract": list(CONDITION_CONTRACT),
        "inference_contract": {
            "single_seeded_sample_per_task": True,
            "seed_derivation": "sha256(freeze_id, condition_key, task_id) truncated to uint32",
            "same_task_and_token_ceiling_for_every_condition": True,
            "family_token_budgets": TOKEN_BUDGETS,
            "qwen3_thinking_sampling": {
                "temperature": 0.6,
                "top_p": 0.95,
                "top_k": 20,
                "min_p": 0.0,
            },
            "qwen3_nonthinking_sampling": {
                "temperature": 0.7,
                "top_p": 0.8,
                "top_k": 20,
                "min_p": 0.0,
            },
            "sampling_source": "official Qwen3 model card",
            "qwen3_chat_template_control": QWEN3_TEMPLATE_SOURCE,
            "system_prompt": None,
            "model_specific_task_prompting": False,
            "tool_execution": False,
        },
        "measure_contract": {
            "primary": "exact task accuracy, macro-averaged over five families",
            "co_primary": [
                "per-family accuracy",
                "planning/tool parse and valid-action rate",
                "output tokens",
                "ceiling-hit rate",
                "wall time",
            ],
            "no_posthoc_scalar_utility": True,
            "oracle_mode_envelope": (
                "label-informed union of 1.7B thinking and non-thinking successes; diagnostic "
                "upper bound only and never a deployable result"
            ),
        },
        "gates": {
            "minimum_oracle_gain_over_best_fixed_1p7b": 0.05,
            "minimum_complementary_unique_successes_each_mode": 2,
            "minimum_families_with_oracle_gain": 2,
            "maximum_1p7b_oracle_gap_to_8b": 0.10,
            "future_72b_equivalence_margin_macro": 0.05,
            "future_72b_equivalence_margin_each_family": 0.10,
        },
        "decision_rule": (
            "M55 controller training is justified only if the two 1.7B modes are genuinely "
            "complementary and their label-informed oracle envelope approaches the 8B "
            "reference. If the oracle remains more than ten points behind 8B, a selector "
            "cannot be the sufficient mechanism and M55 must test representational change."
        ),
        "claim_boundary": (
            "This 80-task, one-sample, quantized, bounded-compute study is a scaling-gap "
            "calibration milestone. It is not a leaderboard result, a powered equivalence "
            "test, evidence of 1.7B/72B parity, or publication-grade generality. The BFCL "
            "slice tests call construction without executing tools. Full M54 requires the "
            "frozen 72B external reference; the laptop phase alone cannot complete parity."
        ),
        "prior_opened_source_ids_sha256": content_digest(sorted(excluded)),
        "prior_opened_source_id_count": len(excluded),
        "selected_overlap_count": 0,
        "public_tasks_sha256": hashlib.sha256(public_payload.encode()).hexdigest(),
        "authority_tasks_sha256": hashlib.sha256(authority_payload.encode()).hexdigest(),
        "labels_excluded_from_public_tasks": True,
        "no_development_selection": True,
    }
    freeze = {**body, "freeze_id": content_digest(body)}
    _write_immutable(output / "tasks-public.jsonl", public_payload)
    _write_immutable(output / "tasks-authority.jsonl", authority_payload)
    _write_immutable(
        output / "protocol-freeze.json",
        json.dumps(freeze, indent=2, sort_keys=True) + "\n",
    )
    verification = verify_benchmark(project, output)
    _write_immutable(
        output / "protocol-verification.json",
        json.dumps(verification, indent=2, sort_keys=True) + "\n",
    )
    return freeze


def verify_benchmark(project: Path, output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "protocol-freeze.json").read_text(encoding="utf-8"))
    public_path = output / "tasks-public.jsonl"
    authority_path = output / "tasks-authority.jsonl"
    public = _read_jsonl(public_path)
    authority = _read_jsonl(authority_path)
    body = {key: value for key, value in freeze.items() if key != "freeze_id"}
    selected = {str(row["source_id"]) for row in public}
    excluded = opened_source_ids(project)
    checks = {
        "freeze_id_is_content_derived": content_digest(body) == freeze["freeze_id"],
        "public_hash_matches": _sha256(public_path) == freeze["public_tasks_sha256"],
        "authority_hash_matches": _sha256(authority_path)
        == freeze["authority_tasks_sha256"],
        "balanced_80_item_panel": len(public) == TASK_COUNT
        and all(
            sum(row["family"] == family for row in public) == ITEMS_PER_FAMILY
            for family in FAMILIES
        ),
        "authority_absent_from_public": all("authority" not in row for row in public),
        "public_authority_order_matches": [row["task_id"] for row in public]
        == [row["task_id"] for row in authority],
        "zero_overlap_with_opened_m53_items": not (selected & excluded),
        "all_source_hashes_match": all(
            _sha256(project / path) == digest
            for files in freeze["source_file_hashes"].values()
            for path, digest in files.items()
        ),
        "same_ceiling_for_all_conditions": freeze["inference_contract"][
            "same_task_and_token_ceiling_for_every_condition"
        ],
        "official_sampling_frozen": freeze["inference_contract"][
            "qwen3_thinking_sampling"
        ]
        == {"temperature": 0.6, "top_p": 0.95, "top_k": 20, "min_p": 0.0},
        "official_nonthinking_prefix_frozen": freeze["inference_contract"][
            "qwen3_chat_template_control"
        ]
        == QWEN3_TEMPLATE_SOURCE,
        "external_72b_slot_frozen": any(
            model["key"] == "qwen2p5_72b" for model in freeze["model_contract"]
        ),
    }
    return {
        "version": VERSION,
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def deterministic_seed(freeze_id: str, condition_key: str, task_id: str) -> int:
    digest = hashlib.sha256(
        f"{freeze_id}:{condition_key}:{task_id}".encode("utf-8")
    ).digest()
    return int.from_bytes(digest[:4], "big")


def build_chat_prompt(tokenizer: Any, prompt: str, enable_thinking: bool) -> str:
    if not getattr(tokenizer, "chat_template", None):
        raise ValueError("M54 requires a model chat template")
    formatted = tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}],
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=enable_thinking,
    )
    # The frozen official MLX conversions contain Qwen3's original chat template,
    # which silently ignores enable_thinking. Current official Qwen3 templates
    # implement the hard switch by pre-filling an empty think block. Apply that
    # exact documented prefix when the conversion has not done it itself.
    prefix = str(QWEN3_TEMPLATE_SOURCE["nonthinking_generation_prefix"])
    if not enable_thinking and not formatted.endswith(prefix):
        formatted += prefix
    return formatted


def visible_response(response: str, enable_thinking: bool) -> str | None:
    if not enable_thinking:
        return response
    if "</think>" not in response:
        return None
    return response.rsplit("</think>", 1)[-1].lstrip()


_PLAN_OBJECTS = {
    "red": "a",
    "blue": "b",
    "orange": "c",
    "yellow": "d",
    "white": "e",
    "magenta": "f",
    "black": "g",
    "cyan": "h",
    "green": "i",
    "violet": "j",
    "silver": "k",
    "gold": "l",
}


def _plan_object(value: str) -> str | None:
    value = value.casefold()
    if len(value) == 1 and "a" <= value <= "l":
        return value
    return _PLAN_OBJECTS.get(value)


def parse_m54_plan(response: str) -> Tuple[Tuple[str, ...], ...]:
    region = response.rsplit("[PLAN]", 1)[-1].split("FINAL:", 1)[0]
    actions = []
    ignored = {"the", "block", "from", "on", "top", "of"}
    for inside in re.findall(r"\(([^()]*)\)", region):
        normalized = inside.casefold().replace("pick-up", "pick up").replace(
            "put-down", "put down"
        )
        tokens = [token for token in re.findall(r"[a-z]+", normalized) if token not in ignored]
        if tokens[:2] == ["pick", "up"]:
            tokens = ["pick-up", *tokens[2:]]
        elif tokens[:2] == ["put", "down"]:
            tokens = ["put-down", *tokens[2:]]
        if not tokens or tokens[0] not in {"pick-up", "put-down", "stack", "unstack"}:
            continue
        name = tokens[0]
        expected = 1 if name in {"pick-up", "put-down"} else 2
        objects = [_plan_object(token) for token in tokens[1:]]
        objects = [value for value in objects if value is not None]
        if len(objects) == expected:
            actions.append((name, *objects))
    if actions:
        return tuple(actions)
    return _parse_legacy_plan(response)


def score_m54_planning(authority: Mapping[str, Any], response: str) -> Mapping[str, Any]:
    actions = parse_m54_plan(response)
    execution = execute_blocksworld(str(authority["pddl"]), actions)
    return {
        "parsed": bool(actions),
        "correct": bool(actions) and bool(execution["goal_reached"]),
        "actions": [list(action) for action in actions],
        "execution": execution,
        "parser": "m54_compact_or_prose_plan_v2",
    }


def score_generated_response(
    family: str,
    authority: Mapping[str, Any],
    response: str,
    enable_thinking: bool,
) -> Mapping[str, Any]:
    visible = visible_response(response, enable_thinking)
    if visible is None:
        return {
            "parsed": False,
            "correct": False,
            "answer": None,
            "reason": "unfinished_thinking_block_has_no_scoreable_final_response",
        }
    if family == "planning":
        return score_m54_planning(authority, visible)
    return _score_response(family, authority, visible)


def wilson_interval(correct: int, count: int, z: float = 1.959963984540054) -> Tuple[float, float]:
    if count <= 0:
        raise ValueError("Wilson interval requires observations")
    p = correct / count
    denominator = 1.0 + z * z / count
    center = (p + z * z / (2.0 * count)) / denominator
    radius = z * math.sqrt(p * (1.0 - p) / count + z * z / (4.0 * count * count)) / denominator
    return max(0.0, center - radius), min(1.0, center + radius)


def ceiling_hit(row: Mapping[str, Any]) -> bool:
    # Retokenizing decoded text can omit EOS/special tokens, so MLX's explicit
    # finish reason is authoritative. The token comparison supports imported
    # records from backends that do not expose a finish reason.
    return (
        str(row.get("generation", {}).get("finish_reason", "")).casefold() == "length"
        or int(row["output_tokens"]) >= int(row["maximum_new_tokens"])
    )


def summarize_records(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    if len(records) != TASK_COUNT:
        raise ValueError(f"M54 condition requires {TASK_COUNT} records")
    by_family = {}
    for family in FAMILIES:
        local = [row for row in records if row["family"] == family]
        if len(local) != ITEMS_PER_FAMILY:
            raise ValueError(f"M54 incomplete family: {family}")
        correct = sum(bool(row["score"]["correct"]) for row in local)
        low, high = wilson_interval(correct, len(local))
        by_family[family] = {
            "count": len(local),
            "correct": correct,
            "accuracy": correct / len(local),
            "accuracy_wilson_95": [low, high],
            "parse_rate": sum(bool(row["score"]["parsed"]) for row in local)
            / len(local),
            "ceiling_rate": sum(ceiling_hit(row) for row in local) / len(local),
            "mean_output_tokens": sum(int(row["output_tokens"]) for row in local)
            / len(local),
            "mean_seconds": sum(float(row["elapsed_seconds"]) for row in local)
            / len(local),
        }
    correct = sum(bool(row["score"]["correct"]) for row in records)
    low, high = wilson_interval(correct, len(records))
    return {
        "count": len(records),
        "correct": correct,
        "macro_accuracy": sum(value["accuracy"] for value in by_family.values())
        / len(by_family),
        "micro_accuracy": correct / len(records),
        "accuracy_wilson_95": [low, high],
        "parse_rate": sum(bool(row["score"]["parsed"]) for row in records)
        / len(records),
        "ceiling_rate": sum(ceiling_hit(row) for row in records) / len(records),
        "total_output_tokens": sum(int(row["output_tokens"]) for row in records),
        "total_seconds": sum(float(row["elapsed_seconds"]) for row in records),
        "by_family": by_family,
    }


def analyze_local_conditions(
    records_by_condition: Mapping[str, Sequence[Mapping[str, Any]]],
    gates: Mapping[str, Any],
) -> Mapping[str, Any]:
    required = {
        "qwen3_1p7b_no_think",
        "qwen3_1p7b_think",
        "qwen3_4b_think",
        "qwen3_8b_think",
    }
    if not required.issubset(records_by_condition):
        missing = sorted(required - set(records_by_condition))
        return {"local_phase_complete": False, "missing_conditions": missing}
    mapped = {
        key: {str(row["task_id"]): row for row in rows}
        for key, rows in records_by_condition.items()
    }
    no_think = mapped["qwen3_1p7b_no_think"]
    think = mapped["qwen3_1p7b_think"]
    eight = mapped["qwen3_8b_think"]
    task_ids = sorted(no_think)
    unique_no = [
        task_id
        for task_id in task_ids
        if no_think[task_id]["score"]["correct"]
        and not think[task_id]["score"]["correct"]
    ]
    unique_think = [
        task_id
        for task_id in task_ids
        if think[task_id]["score"]["correct"]
        and not no_think[task_id]["score"]["correct"]
    ]
    oracle_correct = {
        task_id: bool(no_think[task_id]["score"]["correct"])
        or bool(think[task_id]["score"]["correct"])
        for task_id in task_ids
    }
    fixed_accuracies = {
        key: sum(bool(row["score"]["correct"]) for row in mapped[key].values())
        / len(task_ids)
        for key in ("qwen3_1p7b_no_think", "qwen3_1p7b_think")
    }
    oracle_accuracy = sum(oracle_correct.values()) / len(task_ids)
    oracle_by_family = {}
    families_with_gain = 0
    for family in FAMILIES:
        local_ids = [task_id for task_id in task_ids if no_think[task_id]["family"] == family]
        no_accuracy = sum(no_think[item]["score"]["correct"] for item in local_ids) / len(local_ids)
        think_accuracy = sum(think[item]["score"]["correct"] for item in local_ids) / len(local_ids)
        oracle_local = sum(oracle_correct[item] for item in local_ids) / len(local_ids)
        gain = oracle_local - max(no_accuracy, think_accuracy)
        families_with_gain += gain > 0
        oracle_by_family[family] = {
            "accuracy": oracle_local,
            "gain_over_best_fixed_mode": gain,
        }
    eight_accuracy = sum(
        bool(eight[task_id]["score"]["correct"]) for task_id in task_ids
    ) / len(task_ids)
    oracle_gain = oracle_accuracy - max(fixed_accuracies.values())
    oracle_gap_to_8b = eight_accuracy - oracle_accuracy
    gate_checks = {
        "oracle_gain_sufficient": oracle_gain
        >= float(gates["minimum_oracle_gain_over_best_fixed_1p7b"]),
        "both_modes_have_unique_successes": min(len(unique_no), len(unique_think))
        >= int(gates["minimum_complementary_unique_successes_each_mode"]),
        "complementarity_spans_families": families_with_gain
        >= int(gates["minimum_families_with_oracle_gain"]),
        "oracle_approaches_8b": oracle_gap_to_8b
        <= float(gates["maximum_1p7b_oracle_gap_to_8b"]),
    }
    return {
        "local_phase_complete": True,
        "fixed_1p7b_accuracy": fixed_accuracies,
        "unique_successes": {
            "no_think_only": unique_no,
            "think_only": unique_think,
        },
        "oracle_mode_envelope": {
            "accuracy": oracle_accuracy,
            "gain_over_best_fixed_1p7b": oracle_gain,
            "by_family": oracle_by_family,
            "diagnostic_only": True,
        },
        "qwen3_8b_think_accuracy": eight_accuracy,
        "oracle_gap_to_8b": oracle_gap_to_8b,
        "gate_checks": gate_checks,
        "controller_training_justified": all(gate_checks.values()),
        "selector_sufficient_in_principle": gate_checks["oracle_approaches_8b"],
        "next_mechanism_class": (
            "learned_internal_think_act_controller"
            if all(gate_checks.values())
            else "representation_or_recurrent_internal_compute"
        ),
        "full_m54_complete": "qwen2p5_72b_reference" in records_by_condition,
    }


def rescore_record(
    row: Mapping[str, Any], authority: Mapping[str, Mapping[str, Any]]
) -> Mapping[str, Any]:
    return score_generated_response(
        str(row["family"]),
        authority[str(row["task_id"])]["authority"],
        str(row["response"]),
        bool(row["enable_thinking"]),
    )
