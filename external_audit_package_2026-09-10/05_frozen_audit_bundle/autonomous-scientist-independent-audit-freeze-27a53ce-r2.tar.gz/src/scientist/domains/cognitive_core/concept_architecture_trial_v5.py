from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.measurement_v3 import (
    ABSTAIN,
    MODULUS,
    CapabilityAxis,
    MeasurementCase,
    generate_measurement_case,
)
from scientist.kernel.contracts import EvidencePartition


CONCEPT_ARCHITECTURE_TRIAL_VERSION = (
    "cognitive-core-concept-architecture-trial-v5"
)
CONCEPT_ARCHITECTURE_EVALUATOR_REF = (
    "cognitive-core-concept-architecture-evaluator-v5"
)


@dataclass(frozen=True)
class ConceptArchitectureArm:
    arm_id: str
    factor_enabled: bool
    protection_enabled: bool
    sham: bool = False

    def __post_init__(self) -> None:
        if not self.arm_id:
            raise ValueError("architecture arm identity must not be empty")
        if self.sham and (self.factor_enabled or self.protection_enabled):
            raise ValueError("sham arm cannot activate an intervention")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "arm_id": self.arm_id,
            "factor_enabled": self.factor_enabled,
            "protection_enabled": self.protection_enabled,
            "sham": self.sham,
        }


BASELINE_ARM = ConceptArchitectureArm("baseline", False, False)
FACTOR_ONLY_ARM = ConceptArchitectureArm("factor_only", True, False)
PROTECTION_ONLY_ARM = ConceptArchitectureArm(
    "protection_only", False, True
)
COMBINED_ARM = ConceptArchitectureArm("combined", True, True)
SHAM_ARM = ConceptArchitectureArm("sham", False, False, sham=True)
TRIAL_ARMS = (
    BASELINE_ARM,
    SHAM_ARM,
    FACTOR_ONLY_ARM,
    PROTECTION_ONLY_ARM,
    COMBINED_ARM,
)


@dataclass(frozen=True)
class ConceptArchitecturePair:
    pair_id: str
    factor_name: str
    protection_name: str
    factor_hypothesis_id: str
    protection_hypothesis_id: str
    target_axis: CapabilityAxis
    protected_axis: CapabilityAxis
    minimum_target_improvement: float
    minimum_protected_delta: float
    minimum_combined_joint_accuracy: float
    expected_factor_only_protection_harm: bool

    def __post_init__(self) -> None:
        if not all(
            (
                self.pair_id,
                self.factor_name,
                self.protection_name,
                self.factor_hypothesis_id,
                self.protection_hypothesis_id,
            )
        ):
            raise ValueError("concept architecture pair is incomplete")
        if self.target_axis == self.protected_axis:
            raise ValueError("target and protected axes must differ")
        if not 0.0 <= self.minimum_target_improvement <= 1.0:
            raise ValueError("target-improvement floor must lie in [0, 1]")
        if not -1.0 <= self.minimum_protected_delta <= 1.0:
            raise ValueError("protected-delta floor must lie in [-1, 1]")
        if not 0.0 <= self.minimum_combined_joint_accuracy <= 1.0:
            raise ValueError("joint-accuracy floor must lie in [0, 1]")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "pair_id": self.pair_id,
            "factor_name": self.factor_name,
            "protection_name": self.protection_name,
            "factor_hypothesis_id": self.factor_hypothesis_id,
            "protection_hypothesis_id": self.protection_hypothesis_id,
            "target_axis": self.target_axis.value,
            "protected_axis": self.protected_axis.value,
            "minimum_target_improvement": self.minimum_target_improvement,
            "minimum_protected_delta": self.minimum_protected_delta,
            "minimum_combined_joint_accuracy": (
                self.minimum_combined_joint_accuracy
            ),
            "expected_factor_only_protection_harm": (
                self.expected_factor_only_protection_harm
            ),
        }


@dataclass(frozen=True)
class FrozenConceptArchitectureRegistry:
    source_revision_id: str
    source_revision_artifact_id: str
    pairs: Tuple[ConceptArchitecturePair, ...]
    arms: Tuple[ConceptArchitectureArm, ...]
    partitions: Tuple[EvidencePartition, ...]
    partition_nonces: Mapping[str, int]
    seeds: Tuple[int, ...]
    required_checks: Tuple[str, ...]
    registrar_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.source_revision_id,
                self.source_revision_artifact_id,
                self.pairs,
                self.arms,
                self.partitions,
                self.partition_nonces,
                self.seeds,
                self.required_checks,
                self.registrar_ref,
            )
        ):
            raise ValueError("concept architecture registry is incomplete")
        for values, label in (
            (tuple(pair.pair_id for pair in self.pairs), "pair IDs"),
            (tuple(arm.arm_id for arm in self.arms), "arm IDs"),
            (tuple(item.value for item in self.partitions), "partitions"),
            (tuple(str(seed) for seed in self.seeds), "seeds"),
            (self.required_checks, "required checks"),
        ):
            if len(set(values)) != len(values) or not all(values):
                raise ValueError("registry %s must be non-empty and unique" % label)
        if set(self.partition_nonces) != {
            partition.value for partition in self.partitions
        }:
            raise ValueError("partition nonces do not cover the frozen partitions")
        if any(value <= 0 for value in self.partition_nonces.values()):
            raise ValueError("partition nonces must be positive")
        if len(set(self.partition_nonces.values())) != len(
            self.partition_nonces
        ):
            raise ValueError("partition nonces must be disjoint")
        if set(self.arms) != set(TRIAL_ARMS):
            raise ValueError("registry must contain the complete five-arm design")

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CONCEPT_ARCHITECTURE_TRIAL_VERSION,
            "source_revision_id": self.source_revision_id,
            "source_revision_artifact_id": self.source_revision_artifact_id,
            "pairs": [pair.as_dict() for pair in self.pairs],
            "arms": [arm.as_dict() for arm in self.arms],
            "partitions": [partition.value for partition in self.partitions],
            "partition_nonces": dict(sorted(self.partition_nonces.items())),
            "seeds": list(self.seeds),
            "required_checks": list(self.required_checks),
            "registrar_ref": self.registrar_ref,
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


def frozen_concept_architecture_registry(
    *,
    source_revision_id: str,
    source_revision_artifact_id: str,
    hypothesis_ids_by_factor: Mapping[str, str],
) -> FrozenConceptArchitectureRegistry:
    required_factors = {
        "ephemeral_procedure_slot",
        "uncertainty_gated_evidence_router",
        "key_scoped_mutable_memory",
        "update_locality_gate",
    }
    if set(hypothesis_ids_by_factor) != required_factors:
        raise ValueError("source revision does not expose the four frozen factors")
    return FrozenConceptArchitectureRegistry(
        source_revision_id=source_revision_id,
        source_revision_artifact_id=source_revision_artifact_id,
        pairs=(
            ConceptArchitecturePair(
                pair_id="adaptation_boundary_pair",
                factor_name="ephemeral_procedure_slot",
                protection_name="uncertainty_gated_evidence_router",
                factor_hypothesis_id=hypothesis_ids_by_factor[
                    "ephemeral_procedure_slot"
                ],
                protection_hypothesis_id=hypothesis_ids_by_factor[
                    "uncertainty_gated_evidence_router"
                ],
                target_axis=CapabilityAxis.RAPID_TASK_LEARNING,
                protected_axis=CapabilityAxis.KNOWLEDGE_BOUNDARY,
                minimum_target_improvement=0.5,
                minimum_protected_delta=0.0,
                minimum_combined_joint_accuracy=0.95,
                expected_factor_only_protection_harm=False,
            ),
            ConceptArchitecturePair(
                pair_id="update_retention_pair",
                factor_name="key_scoped_mutable_memory",
                protection_name="update_locality_gate",
                factor_hypothesis_id=hypothesis_ids_by_factor[
                    "key_scoped_mutable_memory"
                ],
                protection_hypothesis_id=hypothesis_ids_by_factor[
                    "update_locality_gate"
                ],
                target_axis=CapabilityAxis.KNOWLEDGE_UPDATE,
                protected_axis=CapabilityAxis.RETENTION,
                minimum_target_improvement=0.5,
                minimum_protected_delta=0.0,
                minimum_combined_joint_accuracy=0.95,
                expected_factor_only_protection_harm=True,
            ),
        ),
        arms=TRIAL_ARMS,
        partitions=(
            EvidencePartition.AUDIT,
            EvidencePartition.REPLICATION,
        ),
        partition_nonces={
            EvidencePartition.AUDIT.value: 8_170_031,
            EvidencePartition.REPLICATION.value: 8_170_097,
        },
        seeds=tuple(range(32)),
        required_checks=(
            "complete_pair_arm_partition_seed_matrix",
            "case_identities_are_disjoint_across_partitions",
            "candidate_inputs_exclude_expected_answers",
            "source_hypotheses_are_bound",
            "baseline_and_sham_are_exact",
            "resource_ledgers_are_matched",
            "input_case_digests_are_matched_within_pair_seed",
            "all_reported_correctness_is_reconstructed",
            "both_combined_target_improvement_gates_pass",
            "both_combined_protected_non_regression_gates_pass",
            "both_combined_joint_accuracy_gates_pass",
            "update_factor_only_harms_retention",
            "update_protection_repairs_factor_harm",
            "audit_and_replication_dispositions_agree",
        ),
        registrar_ref="cognitive-core-concept-architecture-registry-v5",
    )


def _public_digest(case: MeasurementCase) -> str:
    return content_digest(case.public_as_dict())


def _initial_memory(cases: Tuple[MeasurementCase, ...]) -> Dict[int, int]:
    memory: Dict[int, int] = {}
    for case in cases:
        if case.base_answer is not None:
            memory[case.query_key] = case.base_answer
    return memory


def _solve_affine(case: MeasurementCase) -> int:
    if len(case.demonstrations) < 2:
        return ABSTAIN
    (x1, y1), (x2, y2), *_ = case.demonstrations
    denominator = (x2 - x1) % MODULUS
    if not denominator:
        return ABSTAIN
    slope = ((y2 - y1) * pow(denominator, -1, MODULUS)) % MODULUS
    intercept = (y1 - slope * x1) % MODULUS
    return (slope * case.query_key + intercept) % MODULUS


def _adaptation_boundary_predictions(
    arm: ConceptArchitectureArm,
    target: MeasurementCase,
    protected: MeasurementCase,
) -> Tuple[int, int]:
    memory = _initial_memory((protected,))
    # Every arm computes every branch before selection. The intervention is a
    # gate over a fixed module allocation, not hidden extra compute.
    rapid_candidate = _solve_affine(target)
    boundary_candidate = memory.get(protected.query_key, ABSTAIN)
    baseline_target = 0
    baseline_protected = 0
    selected_target = (
        rapid_candidate if arm.factor_enabled else baseline_target
    )
    selected_protected = (
        boundary_candidate
        if arm.protection_enabled
        else baseline_protected
    )
    if arm.sham:
        selected_target = int(str(selected_target))
        selected_protected = int(str(selected_protected))
    return selected_target, selected_protected


def _matching_update(case: MeasurementCase) -> int:
    matches = tuple(
        item.value for item in case.evidence if item.key == case.query_key
    )
    return matches[0] if len(matches) == 1 else ABSTAIN


def _update_retention_predictions(
    arm: ConceptArchitectureArm,
    target: MeasurementCase,
    protected: MeasurementCase,
) -> Tuple[int, int]:
    memory = _initial_memory((target, protected))
    update_value = _matching_update(target)
    # Compute the unscoped and scoped candidate states for every arm so nominal
    # storage and inference work are matched before the factor gates select one.
    destructive = {key: update_value for key in memory}
    scoped = dict(memory)
    scoped[target.query_key] = update_value
    if not arm.factor_enabled:
        selected = memory
    elif arm.protection_enabled:
        selected = scoped
    else:
        selected = destructive
    target_prediction = selected.get(target.query_key, ABSTAIN)
    protected_prediction = selected.get(protected.query_key, ABSTAIN)
    if arm.sham:
        target_prediction = int(str(target_prediction))
        protected_prediction = int(str(protected_prediction))
    return target_prediction, protected_prediction


def _logical_resource_ledger(
    pair_id: str,
    target: MeasurementCase,
    protected: MeasurementCase,
) -> Dict[str, float]:
    public_values = (target.public_as_dict(), protected.public_as_dict())
    context_atoms = sum(len(repr(value)) for value in public_values)
    return {
        "trainable_parameters": 0.0,
        "training_tokens": 0.0,
        "context_bytes": float(context_atoms),
        "allocated_state_entries": 2.0,
        "candidate_branches_evaluated": 2.0,
        "nominal_integer_operations": (
            24.0 if pair_id == "adaptation_boundary_pair" else 16.0
        ),
    }


@dataclass(frozen=True)
class ConceptArchitectureTrace:
    registry_id: str
    pair_id: str
    arm_id: str
    partition: EvidencePartition
    seed: int
    target_case_id: str
    protected_case_id: str
    public_input_digest: str
    initial_state_digest: str
    target_prediction: int
    protected_prediction: int
    target_correct: bool
    protected_correct: bool
    resource_ledger: Mapping[str, float]
    evaluator_ref: str = CONCEPT_ARCHITECTURE_EVALUATOR_REF

    def __post_init__(self) -> None:
        if not all(
            (
                self.registry_id,
                self.pair_id,
                self.arm_id,
                self.target_case_id,
                self.protected_case_id,
                self.public_input_digest,
                self.initial_state_digest,
                self.resource_ledger,
                self.evaluator_ref,
            )
        ):
            raise ValueError("concept architecture trace is incomplete")
        if self.seed < 0 or not all(
            math.isfinite(value) and value >= 0.0
            for value in self.resource_ledger.values()
        ):
            raise ValueError("concept architecture trace values are invalid")

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CONCEPT_ARCHITECTURE_TRIAL_VERSION,
            "registry_id": self.registry_id,
            "pair_id": self.pair_id,
            "arm_id": self.arm_id,
            "partition": self.partition.value,
            "seed": self.seed,
            "target_case_id": self.target_case_id,
            "protected_case_id": self.protected_case_id,
            "public_input_digest": self.public_input_digest,
            "initial_state_digest": self.initial_state_digest,
            "target_prediction": self.target_prediction,
            "protected_prediction": self.protected_prediction,
            "target_correct": self.target_correct,
            "protected_correct": self.protected_correct,
            "joint_correct": self.target_correct and self.protected_correct,
            "resource_ledger": dict(sorted(self.resource_ledger.items())),
            "evaluator_ref": self.evaluator_ref,
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


def run_concept_architecture_trial(
    registry: FrozenConceptArchitectureRegistry,
) -> Tuple[ConceptArchitectureTrace, ...]:
    traces = []
    for pair in registry.pairs:
        for partition in registry.partitions:
            nonce = registry.partition_nonces[partition.value]
            for seed in registry.seeds:
                target = generate_measurement_case(
                    pair.target_axis,
                    seed,
                    partition,
                    partition_nonce=nonce,
                )
                protected = generate_measurement_case(
                    pair.protected_axis,
                    seed,
                    partition,
                    partition_nonce=nonce,
                )
                public_digest = content_digest(
                    [_public_digest(target), _public_digest(protected)]
                )
                initial_state = _initial_memory((target, protected))
                initial_state_digest = content_digest(
                    sorted(initial_state.items())
                )
                ledger = _logical_resource_ledger(
                    pair.pair_id, target, protected
                )
                for arm in registry.arms:
                    if pair.pair_id == "adaptation_boundary_pair":
                        predictions = _adaptation_boundary_predictions(
                            arm, target, protected
                        )
                    elif pair.pair_id == "update_retention_pair":
                        predictions = _update_retention_predictions(
                            arm, target, protected
                        )
                    else:
                        raise ValueError("unsupported concept architecture pair")
                    traces.append(
                        ConceptArchitectureTrace(
                            registry_id=registry.registry_id,
                            pair_id=pair.pair_id,
                            arm_id=arm.arm_id,
                            partition=partition,
                            seed=seed,
                            target_case_id=target.case_id,
                            protected_case_id=protected.case_id,
                            public_input_digest=public_digest,
                            initial_state_digest=initial_state_digest,
                            target_prediction=predictions[0],
                            protected_prediction=predictions[1],
                            target_correct=predictions[0]
                            == target.expected_answer,
                            protected_correct=predictions[1]
                            == protected.expected_answer,
                            resource_ledger=ledger,
                        )
                    )
    return tuple(traces)


def trial_metrics(
    traces: Tuple[ConceptArchitectureTrace, ...],
) -> Mapping[str, Mapping[str, Mapping[str, Mapping[str, float]]]]:
    metrics: Dict[str, Dict[str, Dict[str, Dict[str, float]]]] = {}
    for trace in traces:
        pair_values = metrics.setdefault(trace.pair_id, {})
        partition_values = pair_values.setdefault(trace.partition.value, {})
        arm_values = partition_values.setdefault(
            trace.arm_id,
            {
                "target_correct": 0.0,
                "protected_correct": 0.0,
                "joint_correct": 0.0,
                "count": 0.0,
            },
        )
        arm_values["target_correct"] += float(trace.target_correct)
        arm_values["protected_correct"] += float(trace.protected_correct)
        arm_values["joint_correct"] += float(
            trace.target_correct and trace.protected_correct
        )
        arm_values["count"] += 1.0
    for pair_values in metrics.values():
        for partition_values in pair_values.values():
            for arm_values in partition_values.values():
                count = arm_values.pop("count")
                for name in tuple(arm_values):
                    arm_values[name] /= count
    return metrics

