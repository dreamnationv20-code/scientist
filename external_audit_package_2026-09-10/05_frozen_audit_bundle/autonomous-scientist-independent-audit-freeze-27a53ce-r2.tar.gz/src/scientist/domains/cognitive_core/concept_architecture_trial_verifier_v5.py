from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.concept_architecture_trial_v5 import (
    CONCEPT_ARCHITECTURE_TRIAL_VERSION,
    ConceptArchitectureTrace,
    FrozenConceptArchitectureRegistry,
    trial_metrics,
)
from scientist.domains.cognitive_core.measurement_v3 import (
    ABSTAIN,
    MODULUS,
    MeasurementCase,
    generate_measurement_case,
)


CONCEPT_ARCHITECTURE_VERIFIER_REF = (
    "cognitive-core-concept-architecture-independent-verifier-v5"
)


@dataclass(frozen=True)
class ConceptArchitectureVerification:
    registry_id: str
    trace_count: int
    check_results: Mapping[str, bool]
    effects: Mapping[str, Mapping[str, Mapping[str, float]]]
    passing_pair_ids: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str = CONCEPT_ARCHITECTURE_VERIFIER_REF

    def __post_init__(self) -> None:
        if not self.registry_id or self.trace_count <= 0 or not self.check_results:
            raise ValueError("concept architecture verification is incomplete")
        if not self.limitations or len(set(self.limitations)) != len(
            self.limitations
        ):
            raise ValueError("verification limitations must be non-empty and unique")

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CONCEPT_ARCHITECTURE_TRIAL_VERSION,
            "registry_id": self.registry_id,
            "trace_count": self.trace_count,
            "check_results": dict(sorted(self.check_results.items())),
            "effects": {
                pair_id: {
                    partition: dict(sorted(values.items()))
                    for partition, values in sorted(partitions.items())
                }
                for pair_id, partitions in sorted(self.effects.items())
            },
            "passing_pair_ids": list(self.passing_pair_ids),
            "passed": self.passed,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _initial_memory(cases: Tuple[MeasurementCase, ...]) -> Dict[int, int]:
    return {
        case.query_key: int(case.base_answer)
        for case in cases
        if case.base_answer is not None
    }


def _independent_affine_prediction(case: MeasurementCase) -> int:
    if len(case.demonstrations) < 2:
        return ABSTAIN
    first, second = case.demonstrations[:2]
    delta_x = (second[0] - first[0]) % MODULUS
    if delta_x == 0:
        return ABSTAIN
    multiplier = (
        (second[1] - first[1]) * pow(delta_x, -1, MODULUS)
    ) % MODULUS
    offset = (first[1] - multiplier * first[0]) % MODULUS
    return (multiplier * case.query_key + offset) % MODULUS


def _independent_predictions(
    pair_id: str,
    factor_enabled: bool,
    protection_enabled: bool,
    target: MeasurementCase,
    protected: MeasurementCase,
) -> Tuple[int, int]:
    memory = _initial_memory((target, protected))
    if pair_id == "adaptation_boundary_pair":
        return (
            _independent_affine_prediction(target)
            if factor_enabled
            else 0,
            memory.get(protected.query_key, ABSTAIN)
            if protection_enabled
            else 0,
        )
    if pair_id == "update_retention_pair":
        matching = tuple(
            signal.value
            for signal in target.evidence
            if signal.key == target.query_key
        )
        update = matching[0] if len(matching) == 1 else ABSTAIN
        if not factor_enabled:
            selected = memory
        elif protection_enabled:
            selected = {**memory, target.query_key: update}
        else:
            selected = {key: update for key in memory}
        return (
            selected.get(target.query_key, ABSTAIN),
            selected.get(protected.query_key, ABSTAIN),
        )
    raise ValueError("independent verifier received an unknown pair")


def verify_concept_architecture_trial(
    *,
    registry: FrozenConceptArchitectureRegistry,
    traces: Tuple[ConceptArchitectureTrace, ...],
    source_revision: Mapping[str, Any],
) -> ConceptArchitectureVerification:
    arm_by_id = {arm.arm_id: arm for arm in registry.arms}
    pair_by_id = {pair.pair_id: pair for pair in registry.pairs}
    expected_keys = {
        (pair.pair_id, partition.value, seed, arm.arm_id)
        for pair in registry.pairs
        for partition in registry.partitions
        for seed in registry.seeds
        for arm in registry.arms
    }
    observed_keys = {
        (trace.pair_id, trace.partition.value, trace.seed, trace.arm_id)
        for trace in traces
    }
    programs = tuple(source_revision.get("generated_programs", ()))
    source_ids_by_factor = {
        str(program["causal_factor"]): str(program["hypothesis_id"])
        for program in programs
    }
    source_bound = (
        str(source_revision.get("revision_id")) == registry.source_revision_id
        and all(
            source_ids_by_factor.get(pair.factor_name)
            == pair.factor_hypothesis_id
            and source_ids_by_factor.get(pair.protection_name)
            == pair.protection_hypothesis_id
            for pair in registry.pairs
        )
    )

    reconstruction_passed = True
    correctness_passed = True
    identity_passed = True
    leakage_passed = True
    regenerated_case_ids: Dict[str, set[str]] = {
        partition.value: set() for partition in registry.partitions
    }
    grouped: Dict[Tuple[str, str, int], list[ConceptArchitectureTrace]] = {}
    for trace in traces:
        pair = pair_by_id.get(trace.pair_id)
        arm = arm_by_id.get(trace.arm_id)
        if pair is None or arm is None:
            reconstruction_passed = False
            continue
        nonce = registry.partition_nonces[trace.partition.value]
        target = generate_measurement_case(
            pair.target_axis,
            trace.seed,
            trace.partition,
            partition_nonce=nonce,
        )
        protected = generate_measurement_case(
            pair.protected_axis,
            trace.seed,
            trace.partition,
            partition_nonce=nonce,
        )
        regenerated_case_ids[trace.partition.value].update(
            (target.case_id, protected.case_id)
        )
        public_target = target.public_as_dict()
        public_protected = protected.public_as_dict()
        leakage_passed &= all(
            forbidden not in public
            for public in (public_target, public_protected)
            for forbidden in ("expected_answer", "base_answer")
        )
        expected_public_digest = content_digest(
            [content_digest(public_target), content_digest(public_protected)]
        )
        expected_state_digest = content_digest(
            sorted(_initial_memory((target, protected)).items())
        )
        expected_predictions = _independent_predictions(
            pair.pair_id,
            arm.factor_enabled,
            arm.protection_enabled,
            target,
            protected,
        )
        identity_passed &= (
            trace.registry_id == registry.registry_id
            and trace.target_case_id == target.case_id
            and trace.protected_case_id == protected.case_id
            and trace.public_input_digest == expected_public_digest
            and trace.initial_state_digest == expected_state_digest
        )
        reconstruction_passed &= expected_predictions == (
            trace.target_prediction,
            trace.protected_prediction,
        )
        correctness_passed &= (
            trace.target_correct
            == (trace.target_prediction == target.expected_answer)
            and trace.protected_correct
            == (trace.protected_prediction == protected.expected_answer)
        )
        grouped.setdefault(
            (trace.pair_id, trace.partition.value, trace.seed), []
        ).append(trace)

    baseline_sham_exact = all(
        next(item for item in values if item.arm_id == "baseline").target_prediction
        == next(item for item in values if item.arm_id == "sham").target_prediction
        and next(
            item for item in values if item.arm_id == "baseline"
        ).protected_prediction
        == next(item for item in values if item.arm_id == "sham").protected_prediction
        for values in grouped.values()
        if {item.arm_id for item in values} == set(arm_by_id)
    ) and len(grouped) == (
        len(registry.pairs) * len(registry.partitions) * len(registry.seeds)
    )
    ledgers_matched = all(
        len(
            {
                content_digest(dict(sorted(item.resource_ledger.items())))
                for item in values
            }
        )
        == 1
        for values in grouped.values()
    )
    inputs_matched = all(
        len({item.public_input_digest for item in values}) == 1
        and len({item.initial_state_digest for item in values}) == 1
        for values in grouped.values()
    )
    partitions_disjoint = all(
        regenerated_case_ids[left.value].isdisjoint(
            regenerated_case_ids[right.value]
        )
        for index, left in enumerate(registry.partitions)
        for right in registry.partitions[index + 1 :]
    )

    raw_metrics = trial_metrics(traces)
    effects: Dict[str, Dict[str, Dict[str, float]]] = {}
    pair_pass_by_partition: Dict[str, Dict[str, bool]] = {}
    target_gates = []
    protection_gates = []
    joint_gates = []
    update_harm = True
    update_repair = True
    for pair in registry.pairs:
        effects[pair.pair_id] = {}
        pair_pass_by_partition[pair.pair_id] = {}
        for partition in registry.partitions:
            values = raw_metrics[pair.pair_id][partition.value]
            baseline = values["baseline"]
            factor = values["factor_only"]
            combined = values["combined"]
            target_delta = (
                combined["target_correct"] - baseline["target_correct"]
            )
            protected_delta = (
                combined["protected_correct"]
                - baseline["protected_correct"]
            )
            repair_delta = (
                combined["protected_correct"]
                - factor["protected_correct"]
            )
            target_pass = target_delta >= pair.minimum_target_improvement
            protection_pass = protected_delta >= pair.minimum_protected_delta
            joint_pass = (
                combined["joint_correct"]
                >= pair.minimum_combined_joint_accuracy
            )
            target_gates.append(target_pass)
            protection_gates.append(protection_pass)
            joint_gates.append(joint_pass)
            pair_pass_by_partition[pair.pair_id][partition.value] = (
                target_pass and protection_pass and joint_pass
            )
            if pair.expected_factor_only_protection_harm:
                update_harm &= (
                    factor["protected_correct"]
                    <= baseline["protected_correct"] - 0.5
                )
                update_repair &= (
                    repair_delta >= 0.5
                    and combined["target_correct"]
                    >= factor["target_correct"]
                )
            effects[pair.pair_id][partition.value] = {
                "baseline_target_accuracy": baseline["target_correct"],
                "baseline_protected_accuracy": baseline[
                    "protected_correct"
                ],
                "factor_only_target_accuracy": factor["target_correct"],
                "factor_only_protected_accuracy": factor[
                    "protected_correct"
                ],
                "combined_target_accuracy": combined["target_correct"],
                "combined_protected_accuracy": combined[
                    "protected_correct"
                ],
                "combined_joint_accuracy": combined["joint_correct"],
                "combined_target_delta": target_delta,
                "combined_protected_delta": protected_delta,
                "protection_repair_delta": repair_delta,
            }
    dispositions_agree = all(
        len(set(values.values())) == 1
        for values in pair_pass_by_partition.values()
    )
    passing_pairs = tuple(
        pair_id
        for pair_id, values in pair_pass_by_partition.items()
        if all(values.values())
    )
    checks = {
        "complete_pair_arm_partition_seed_matrix": (
            observed_keys == expected_keys and len(traces) == len(expected_keys)
        ),
        "case_identities_are_disjoint_across_partitions": partitions_disjoint,
        "candidate_inputs_exclude_expected_answers": leakage_passed,
        "source_hypotheses_are_bound": source_bound,
        "baseline_and_sham_are_exact": baseline_sham_exact,
        "resource_ledgers_are_matched": ledgers_matched,
        "input_case_digests_are_matched_within_pair_seed": inputs_matched,
        "all_reported_correctness_is_reconstructed": (
            reconstruction_passed and correctness_passed and identity_passed
        ),
        "both_combined_target_improvement_gates_pass": all(target_gates),
        "both_combined_protected_non_regression_gates_pass": all(
            protection_gates
        ),
        "both_combined_joint_accuracy_gates_pass": all(joint_gates),
        "update_factor_only_harms_retention": update_harm,
        "update_protection_repairs_factor_harm": update_repair,
        "audit_and_replication_dispositions_agree": dispositions_agree,
    }
    if tuple(checks) != registry.required_checks:
        raise ValueError("verifier checks differ from the frozen registry")
    if not all(
        math.isfinite(value)
        for pair_values in effects.values()
        for partition_values in pair_values.values()
        for value in partition_values.values()
    ):
        raise ValueError("concept architecture effects must be finite")
    return ConceptArchitectureVerification(
        registry_id=registry.registry_id,
        trace_count=len(traces),
        check_results=checks,
        effects=effects,
        passing_pair_ids=passing_pairs,
        limitations=(
            "This is a symbolic micro-horizon mechanism-feasibility test, not a trained neural architecture result.",
            "The affine task family and keyed-memory semantics make the tested mechanisms executable but intentionally simple.",
            "Static module allocation and nominal logical work are matched; hardware latency is not measured.",
            "The architectural factors came from a curated vocabulary, so autonomous factor invention remains unproven.",
            "Passing does not satisfy the root cognitive-core Pareto gate or authorize a breakthrough claim.",
        ),
    )

