from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import MetricDirection, MetricSpec
from scientist.program.diagnostic_generation import (
    CapabilityChannelBranch,
    CapabilityEffectRole,
    ChannelConditionalHypothesisProgram,
    DiagnosticGroundedGeneratorRevision,
)
from scientist.program.goal_graph import (
    ExecutableLeafContract,
    GoalNodeKind,
    GoalNodeSpec,
)
from scientist.program.literature import (
    ClaimClassification,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)
from scientist.program.research_strategy import (
    RepresentationContract,
    RepresentationDimension,
)


CONCEPT_GENERATION_VERSION = "cognitive-core-concept-generation-v4"
CONCEPT_ID = "capability_channel_conditional_causality"
PRIOR_GENERATOR_REF = "aggregate-causal-hypothesis-generator-v3"
REVISED_GENERATOR_REF = "capability-channel-causal-generator-v4"
COMPILER_REF = "typed-capability-channel-branch-compiler-v1"
TARGET_LEAF_TITLE = "Prospective concept-grounded generation test"


@dataclass(frozen=True)
class FrozenCapabilityProbeProblem:
    problem_id: str
    capability_channels: Tuple[str, ...]
    factor_vocabulary: Tuple[str, ...]
    intervention_vocabulary: Tuple[str, ...]
    excluded_from_source_diagnostic: bool

    def __post_init__(self) -> None:
        if not self.problem_id or len(self.capability_channels) < 2:
            raise ValueError("capability probe problem is incomplete")
        for values in (
            self.capability_channels,
            self.factor_vocabulary,
            self.intervention_vocabulary,
        ):
            if not values or not all(values) or len(set(values)) != len(values):
                raise ValueError("probe vocabulary must be non-empty and unique")
        if not self.excluded_from_source_diagnostic:
            raise ValueError("generator probes must be unseen by the source diagnostic")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "problem_id": self.problem_id,
            "capability_channels": list(self.capability_channels),
            "factor_vocabulary": list(self.factor_vocabulary),
            "intervention_vocabulary": list(self.intervention_vocabulary),
            "excluded_from_source_diagnostic": (
                self.excluded_from_source_diagnostic
            ),
        }


@dataclass(frozen=True)
class FrozenGeneratorProbeRegistry:
    source_diagnostic_id: str
    source_concept_id: str
    problems: Tuple[FrozenCapabilityProbeProblem, ...]
    minimum_program_count: int
    minimum_problem_count: int
    minimum_target_channel_count: int
    required_checks: Tuple[str, ...]
    registrar_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.source_diagnostic_id,
                self.source_concept_id,
                self.problems,
                self.required_checks,
                self.registrar_ref,
            )
        ):
            raise ValueError("generator probe registry is incomplete")
        if self.source_concept_id != CONCEPT_ID:
            raise ValueError("registry uses an unsupported concept")
        problem_ids = tuple(problem.problem_id for problem in self.problems)
        if len(set(problem_ids)) != len(problem_ids):
            raise ValueError("generator probe problems must be unique")
        if min(
            self.minimum_program_count,
            self.minimum_problem_count,
            self.minimum_target_channel_count,
        ) < 2:
            raise ValueError("generator probe floors must require multiplicity")
        if self.minimum_problem_count > len(self.problems):
            raise ValueError("probe problem floor exceeds frozen problems")

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CONCEPT_GENERATION_VERSION,
            "source_diagnostic_id": self.source_diagnostic_id,
            "source_concept_id": self.source_concept_id,
            "problems": [problem.as_dict() for problem in self.problems],
            "minimum_program_count": self.minimum_program_count,
            "minimum_problem_count": self.minimum_problem_count,
            "minimum_target_channel_count": self.minimum_target_channel_count,
            "required_checks": list(self.required_checks),
            "registrar_ref": self.registrar_ref,
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


def frozen_generator_probe_registry(
    source_diagnostic_id: str,
) -> FrozenGeneratorProbeRegistry:
    return FrozenGeneratorProbeRegistry(
        source_diagnostic_id=source_diagnostic_id,
        source_concept_id=CONCEPT_ID,
        problems=(
            FrozenCapabilityProbeProblem(
                problem_id="rapid-adaptation-versus-boundary-control-v1",
                capability_channels=(
                    "rapid_task_learning",
                    "knowledge_boundary_control",
                ),
                factor_vocabulary=(
                    "ephemeral_procedure_slot",
                    "uncertainty_gated_evidence_router",
                ),
                intervention_vocabulary=(
                    "write_demonstrated_rule_to_ephemeral_slot",
                    "retrieve_or_abstain_at_low_support",
                    "route_demonstrations_by_relevance",
                    "preserve_closed_book_decision_path",
                ),
                excluded_from_source_diagnostic=True,
            ),
            FrozenCapabilityProbeProblem(
                problem_id="targeted-update-versus-retention-v1",
                capability_channels=(
                    "targeted_knowledge_update",
                    "unrelated_skill_retention",
                ),
                factor_vocabulary=(
                    "key_scoped_mutable_memory",
                    "update_locality_gate",
                ),
                intervention_vocabulary=(
                    "write_only_matching_memory_key",
                    "freeze_unrelated_procedure_state",
                    "route_update_through_locality_gate",
                    "reject_update_outside_declared_scope",
                ),
                excluded_from_source_diagnostic=True,
            ),
        ),
        minimum_program_count=4,
        minimum_problem_count=2,
        minimum_target_channel_count=4,
        required_checks=(
            "source_diagnostic_is_resolved",
            "concept_is_supported_by_source_diagnostic",
            "probe_registry_is_bound_before_generation",
            "every_program_has_channel_conditional_execution",
            "every_program_targets_and_protects_distinct_channels",
            "multiple_capability_channels_are_targeted",
            "multiple_unseen_probe_problems_are_covered",
            "revised_programs_are_behaviorally_distinct",
            "revised_behavior_exceeds_prior_behavioral_support",
            "channel_axis_changes_mechanism_identity",
        ),
        registrar_ref="cognitive-core-frozen-generator-probes-v4",
    )


def representation_pair() -> Tuple[
    RepresentationContract, RepresentationContract
]:
    prior = RepresentationContract(
        domain_id="domain-neutral-scientific-hypothesis",
        name="aggregate causal mechanism representation",
        research_object_type="typed causal hypothesis program",
        observation_schema=(
            "aggregate objective delta",
            "intervention identity",
            "global mediator state",
        ),
        state_schema=("global causal factor state",),
        action_schema=("single intervention applied to every outcome",),
        hypothesis_language=("causal factor -> aggregate objective",),
        composition_operators=("global intervention",),
        objective_schema=("aggregate objective improvement",),
        experimental_unit="matched intervention and aggregate outcome",
        compiler_ref="aggregate-causal-compiler-v3",
        evaluator_ref="aggregate-causal-evaluator-v3",
    )
    revised = RepresentationContract(
        domain_id="domain-neutral-scientific-hypothesis",
        name="capability-channel conditional causal representation",
        research_object_type="typed causal hypothesis program",
        observation_schema=(
            "capability channel identity",
            "channel-specific intervention effect",
            "channel-specific mediator state",
            "protected-channel effect",
        ),
        state_schema=(
            "requested capability channel",
            "channel-conditional causal factor state",
        ),
        action_schema=(
            "channel-conditioned intervention branch",
            "protected-channel state update",
        ),
        hypothesis_language=(
            "causal factor x capability channel -> channel effect",
            "target channel paired with protected channel",
            "branch-specific falsification condition",
        ),
        composition_operators=(
            "channel gate",
            "target-protection pair",
            "conditional causal composition",
        ),
        objective_schema=(
            "target-channel improvement",
            "protected-channel non-regression",
        ),
        experimental_unit="matched intervention by capability channel",
        compiler_ref=COMPILER_REF,
        evaluator_ref="channel-conditional-causal-evaluator-v1",
        parent_representation_id=prior.representation_id,
        changed_dimensions=(
            RepresentationDimension.OBSERVATION,
            RepresentationDimension.STATE,
            RepresentationDimension.ACTION,
            RepresentationDimension.HYPOTHESIS_LANGUAGE,
            RepresentationDimension.COMPOSITION,
            RepresentationDimension.OBJECTIVE,
            RepresentationDimension.EXPERIMENT,
        ),
    )
    return prior, revised


def _branch(
    channel_id: str,
    role: CapabilityEffectRole,
    intervention: str,
    state_update: str,
    expected: str,
) -> CapabilityChannelBranch:
    return CapabilityChannelBranch(
        channel_id=channel_id,
        effect_role=role,
        intervention_operator=intervention,
        state_update=state_update,
        expected_effect=expected,
        falsification_condition=(
            "matched execution does not produce the preregistered %s effect"
            % channel_id
        ),
    )


def generate_channel_conditional_revision(
    *,
    target_node_id: str,
    source_diagnostic_node_id: str,
    registry: FrozenGeneratorProbeRegistry,
    registry_artifact_id: str,
    evidence_ids: Tuple[str, ...],
) -> DiagnosticGroundedGeneratorRevision:
    prior, revised = representation_pair()
    boundary = (
        registry.registry_id,
        "probe channels excluded from the source diagnostic",
        "downstream objective improvement remains untested",
    )
    common = {
        "target_node_id": target_node_id,
        "source_concept_id": registry.source_concept_id,
        "source_diagnostic_id": registry.source_diagnostic_id,
        "boundary_conditions": boundary,
        "generator_ref": REVISED_GENERATOR_REF,
        "compiler_ref": revised.compiler_ref,
    }
    programs = (
        ChannelConditionalHypothesisProgram(
            probe_problem_id=registry.problems[0].problem_id,
            statement=(
                "An ephemeral procedure slot should accelerate new-rule "
                "acquisition while a confidence gate preserves boundary decisions."
            ),
            causal_factor="ephemeral_procedure_slot",
            mediator="task-rule acquisition without parametric overwrite",
            protected_resource="knowledge-boundary calibration",
            branches=(
                _branch(
                    "rapid_task_learning",
                    CapabilityEffectRole.IMPROVE,
                    "write_demonstrated_rule_to_ephemeral_slot",
                    "update_ephemeral_procedure_state",
                    "faster held-out rule acquisition",
                ),
                _branch(
                    "knowledge_boundary_control",
                    CapabilityEffectRole.PRESERVE,
                    "retrieve_or_abstain_at_low_support",
                    "preserve_parametric_confidence_state",
                    "no loss in answer-retrieve-abstain utility",
                ),
            ),
            **common,
        ),
        ChannelConditionalHypothesisProgram(
            probe_problem_id=registry.problems[0].problem_id,
            statement=(
                "A relevance router should admit demonstrations for rapid "
                "learning but leave supported closed-book answers untouched."
            ),
            causal_factor="uncertainty_gated_evidence_router",
            mediator="relevance-conditioned information flow",
            protected_resource="supported closed-book decision path",
            branches=(
                _branch(
                    "rapid_task_learning",
                    CapabilityEffectRole.PRESERVE,
                    "route_demonstrations_by_relevance",
                    "update_task_conditional_router_state",
                    "no loss of sample efficiency on unseen operations",
                ),
                _branch(
                    "knowledge_boundary_control",
                    CapabilityEffectRole.IMPROVE,
                    "preserve_closed_book_decision_path",
                    "update_only_boundary_calibration_state",
                    "better answer-retrieve-abstain utility without known-answer displacement",
                ),
            ),
            **common,
        ),
        ChannelConditionalHypothesisProgram(
            probe_problem_id=registry.problems[1].problem_id,
            statement=(
                "Key-scoped mutable memory should accept a targeted update "
                "without modifying unrelated reusable procedures."
            ),
            causal_factor="key_scoped_mutable_memory",
            mediator="address-local knowledge mutation",
            protected_resource="unrelated procedure parameters",
            branches=(
                _branch(
                    "targeted_knowledge_update",
                    CapabilityEffectRole.IMPROVE,
                    "write_only_matching_memory_key",
                    "update_target_key_value_state",
                    "higher accuracy on the changed fact",
                ),
                _branch(
                    "unrelated_skill_retention",
                    CapabilityEffectRole.PRESERVE,
                    "freeze_unrelated_procedure_state",
                    "no_update_outside_target_key",
                    "no loss on unrelated procedures and facts",
                ),
            ),
            **common,
        ),
        ChannelConditionalHypothesisProgram(
            probe_problem_id=registry.problems[1].problem_id,
            statement=(
                "An explicit locality gate should route admissible updates to "
                "mutable state and reject scope-violating writes."
            ),
            causal_factor="update_locality_gate",
            mediator="scope-conditioned write authorization",
            protected_resource="non-target capability state",
            branches=(
                _branch(
                    "targeted_knowledge_update",
                    CapabilityEffectRole.PRESERVE,
                    "route_update_through_locality_gate",
                    "commit_authorized_target_update",
                    "target update reliability is retained at matched cost",
                ),
                _branch(
                    "unrelated_skill_retention",
                    CapabilityEffectRole.IMPROVE,
                    "reject_update_outside_declared_scope",
                    "retain_non_target_state_checksum",
                    "higher non-target retention under adversarial update scope",
                ),
            ),
            **common,
        ),
    )
    prior_fingerprint = content_digest(
        {
            "generator_ref": PRIOR_GENERATOR_REF,
            "behavior": "one global intervention for every capability channel",
        }
    )
    return DiagnosticGroundedGeneratorRevision(
        target_node_id=target_node_id,
        source_diagnostic_node_id=source_diagnostic_node_id,
        source_diagnostic_id=registry.source_diagnostic_id,
        supported_concept_id=registry.source_concept_id,
        probe_registry_id=registry.registry_id,
        prior_representation_id=prior.representation_id,
        revised_representation_id=revised.representation_id,
        prior_generator_ref=PRIOR_GENERATOR_REF,
        revised_generator_ref=REVISED_GENERATOR_REF,
        prior_behavior_fingerprints=(prior_fingerprint,),
        generated_programs=programs,
        probe_problem_ids=tuple(
            problem.problem_id for problem in registry.problems
        ),
        evidence_ids=(registry_artifact_id, *evidence_ids),
        reviser_ref="cognitive-core-diagnostic-grounded-reviser-v4",
    )


GENERATION_SUCCESS_CONDITIONS = (
    "the source diagnostic is resolved and supports the named latent concept",
    "the revised hypothesis identity includes target and protected capability channels",
    "at least four typed programs cover two capability pairs excluded from the source diagnostic",
    "every program executes different branches for target and protected channels",
    "revised behavior has greater support and no collisions relative to the aggregate generator",
    "an independent verifier reconstructs all frozen probe traces",
)


def prospective_generation_leaf(parent: GoalNodeSpec) -> GoalNodeSpec:
    metric = MetricSpec(
        name="diagnostic_resolution",
        direction=MetricDirection.TARGET,
        unit="binary generative consequence gate",
        aggregation="all frozen concept-binding and behavior-distinctness checks",
        primary=True,
        target=1.0,
    )
    falsification = (
        "channel labels change prose but not executable action traces",
        "generated mechanisms collapse to one aggregate behavior fingerprint",
        "the source diagnostic does not support the concept used by the generator",
        "probe channels were used to discover or fit the source concept",
    )
    contract = ExecutableLeafContract(
        hypothesis=(
            "Binding capability channel into causal identity, state, action, and "
            "objective schemas produces behaviorally distinct typed hypothesis "
            "programs on capability pairs not used by the source diagnostic."
        ),
        parent_decision=(
            "whether capability-channel conditional causality is a generative "
            "concept or merely a retrospective explanation"
        ),
        root_metric_link=(
            "A diagnostic concept may constrain architecture search only after it "
            "changes executable hypothesis generation without collapsing behavior."
        ),
        metric=metric,
        success_conditions=GENERATION_SUCCESS_CONDITIONS,
        falsification_conditions=falsification,
        testbed_ref="cognitive-core-frozen-concept-generation-probes-v4",
        parent_integration_test=(
            "The validated concept must alter the hypothesis representation and "
            "produce independently reconstructed channel-conditional behavior on "
            "sequestered probe problems."
        ),
        experiment_budget=1.0,
        preregistration_ref=CONCEPT_GENERATION_VERSION,
    )
    return GoalNodeSpec(
        goal_id=parent.goal_id,
        title=TARGET_LEAF_TITLE,
        question=(
            "Does the validated latent concept change what executable causal "
            "hypotheses the scientist can generate?"
        ),
        kind=GoalNodeKind.EXECUTABLE_LEAF,
        rationale=(
            "A concept is not generatively useful until it creates distinct "
            "testable interventions rather than a new label for old behavior."
        ),
        success_conditions=GENERATION_SUCCESS_CONDITIONS,
        falsification_conditions=falsification,
        expected_artifact="diagnostic-grounded generator-revision certificate",
        critical=True,
        leaf_contract=contract,
        tags=(
            "cognitive-core-v4",
            "diagnostic",
            "latent-concept",
            "generator-revision",
            "prospective-probe",
        ),
    )


def generation_prior_art_assessment(
    leaf: GoalNodeSpec,
) -> PriorArtAssessment:
    """Closed scoping review for an internal generative-consequence test.

    The leaf makes no novelty or downstream-performance claim. The recorded
    works establish that rapid adaptation, boundary control, update locality,
    and retention are separate evaluation obligations rather than one scalar
    outcome.
    """

    signature = ClaimSignature(
        subject_id=leaf.node_id,
        statement=leaf.question,
        problem=(
            "test whether a validated causal concept changes executable "
            "hypothesis generation across distinct capability objectives"
        ),
        phenomenon=(
            "aggregate hypothesis languages can hide interventions that help "
            "one capability while harming another"
        ),
        intervention=(
            "bind target and protected capability channels into typed causal "
            "identity and executable branch selection"
        ),
        mechanism=(
            "capability-channel conditional causal effects create distinct "
            "target and protection branches"
        ),
        evaluation=leaf.expected_artifact,
    )
    return PriorArtAssessment(
        signature=signature,
        trigger=LiteratureTrigger.NEW_PHENOMENON,
        queries=(
            LiteratureQuery(
                query=signature.problem,
                facet=SearchFacet.PROBLEM,
                provider="PMLR and ACL Anthology",
            ),
            LiteratureQuery(
                query=signature.intervention,
                facet=SearchFacet.INTERVENTION,
                provider="OpenReview and PMLR",
            ),
            LiteratureQuery(
                query=signature.mechanism,
                facet=SearchFacet.MECHANISM,
                provider="ACL Anthology and OpenReview",
            ),
            LiteratureQuery(
                query="in-context learning knowledge boundary update locality retention",
                facet=SearchFacet.EVALUATION,
                provider="PMLR and OpenReview",
            ),
            LiteratureQuery(
                query="citation neighborhood ICL OOD WISE knowledge boundary",
                facet=SearchFacet.CITATION_NEIGHBORHOOD,
                provider="primary-source indexes",
            ),
        ),
        closest_works=(
            PriorWork(
                work_id="icl-ood-icml-2025-generation-scope",
                title=(
                    "When can in-context learning generalize out of task distribution?"
                ),
                year=2025,
                locator="https://proceedings.mlr.press/v267/goddard25a.html",
                relation=PriorArtRelation.ADJACENT,
                matched_components=(
                    "rapid learning",
                    "unseen task-family evaluation",
                    "task-distribution transfer",
                ),
                abstract=(
                    "Separates rapid in-context acquisition from ordinary "
                    "in-distribution task performance."
                ),
            ),
            PriorWork(
                work_id="wise-neurips-2024-generation-scope",
                title=(
                    "WISE: Rethinking the Knowledge Memory for Lifelong Model Editing of Large Language Models"
                ),
                year=2024,
                locator="https://openreview.net/forum?id=NpoDbZBPZH",
                relation=PriorArtRelation.ADJACENT,
                matched_components=(
                    "targeted knowledge updating",
                    "locality",
                    "unrelated retention",
                ),
                abstract=(
                    "Evaluates update reliability together with locality and "
                    "retention rather than an aggregate edit score."
                ),
            ),
        ),
        classification=ClaimClassification.NOT_APPLICABLE,
        rationale=(
            "This is an internal architecture-conformance test. Prior work "
            "supports treating the probe capabilities separately, but the "
            "result does not authorize a novelty or performance claim."
        ),
        novel_delta=(),
        citation_snowball_complete=True,
        searched_at="2026-08-17",
        reviewer_ref="cognitive-core-concept-generation-scope-v4",
    )
