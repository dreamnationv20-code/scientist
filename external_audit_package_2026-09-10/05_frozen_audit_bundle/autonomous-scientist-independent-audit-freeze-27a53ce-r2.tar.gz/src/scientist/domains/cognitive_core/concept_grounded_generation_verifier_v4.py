from __future__ import annotations

from dataclasses import replace

from scientist.domains.cognitive_core.concept_grounded_generation_v4 import (
    FrozenGeneratorProbeRegistry,
)
from scientist.program.diagnostic_generation import (
    DiagnosticGroundedGeneratorRevision,
    GeneratorRevisionVerification,
    verify_diagnostic_grounded_revision,
)
from scientist.program.diagnostics import LeafDiagnosticRecord
from scientist.program.research_strategy import RepresentationContract


CONCEPT_GENERATION_VERIFIER_REF = (
    "cognitive-core-concept-generation-independent-verifier-v4"
)


def verify_concept_grounded_generation(
    *,
    registry: FrozenGeneratorProbeRegistry,
    revision: DiagnosticGroundedGeneratorRevision,
    source_diagnostic: LeafDiagnosticRecord,
    prior_representation: RepresentationContract,
    revised_representation: RepresentationContract,
) -> GeneratorRevisionVerification:
    """Reconstruct the structural claim from frozen inputs, not prose fields."""

    base = verify_diagnostic_grounded_revision(
        revision,
        source_diagnostic_resolved=source_diagnostic.resolved,
        source_supported_model_ids=source_diagnostic.supported_model_ids,
        verifier_ref=CONCEPT_GENERATION_VERIFIER_REF,
    )
    program_problem_ids = {
        program.probe_problem_id for program in revision.generated_programs
    }
    registry_problem_ids = {problem.problem_id for problem in registry.problems}
    generated_channels = {
        branch.channel_id
        for program in revision.generated_programs
        for branch in program.branches
    }
    registry_channels = {
        channel
        for problem in registry.problems
        for channel in problem.capability_channels
    }
    checks = {
        **base.check_results,
        "registry_identity_is_reconstructed": (
            revision.probe_registry_id == registry.registry_id
        ),
        "source_diagnostic_identity_is_reconstructed": (
            revision.source_diagnostic_id == source_diagnostic.diagnostic_id
        ),
        "representations_form_a_declared_revision": (
            revision.prior_representation_id
            == prior_representation.representation_id
            and revision.revised_representation_id
            == revised_representation.representation_id
            and revised_representation.parent_representation_id
            == prior_representation.representation_id
        ),
        "all_and_only_frozen_probe_problems_are_covered": (
            program_problem_ids == registry_problem_ids
        ),
        "all_and_only_frozen_capability_channels_are_executed": (
            generated_channels == registry_channels
        ),
        "minimum_program_floor_is_met": (
            len(revision.generated_programs) >= registry.minimum_program_count
        ),
        "minimum_problem_floor_is_met": (
            base.probe_problem_count >= registry.minimum_problem_count
        ),
        "minimum_target_channel_floor_is_met": (
            base.target_channel_count >= registry.minimum_target_channel_count
        ),
        "every_frozen_required_check_is_present_and_passes": all(
            base.check_results.get(name, False)
            for name in registry.required_checks
        ),
        "probe_channels_were_excluded_from_source_diagnostic": all(
            problem.excluded_from_source_diagnostic
            and all(
                channel not in source_diagnostic.observed_outcomes
                for channel in problem.capability_channels
            )
            for problem in registry.problems
        ),
    }
    return replace(base, check_results=checks)

