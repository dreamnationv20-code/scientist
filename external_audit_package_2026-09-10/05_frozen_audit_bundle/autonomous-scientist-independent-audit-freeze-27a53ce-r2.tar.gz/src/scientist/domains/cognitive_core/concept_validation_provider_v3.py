from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Mapping, Sequence

from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.instrument_provider import (
    DeterministicValidationReceipt,
    InstrumentOutput,
    InstrumentValidatorStageProvider,
)
from scientist.autonomy.state import ActorIdentity, ActorKind, AuthorityScope, ResourceUsage
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.repair_channel_validation_v1 import (
    ARM_PRIMITIVES,
    HORIZON_SLOTS,
    OUTCOME_ARM_ORDER,
    PROBE_ORDER,
    REPAIR_ARM_ORDER,
    REPRESENTATION_THRESHOLD,
    SELECTION_PRIORITY,
    VERSION,
    agreement_score,
    binary_auc,
    case_prediction,
    complexity_score,
    prospective_case_id,
    select_panel,
)
from scientist.domains.cognitive_core.self_ask_incumbent_v1 import (
    MODEL_ORDER,
    OFFICIAL_COMMIT,
    answer_is_exact,
    extract_final_answer,
    file_sha256,
)
from scientist.program.research_kernel import ConceptValidationCertificate, ResearchActionKind


PROVIDER_VERSION = "cognitive-concept-validation-provider-v3"
EXECUTOR_VERSION = "cognitive-concept-validation-cell-executor-v3"
BINDING_VERSION = "cognitive-concept-validation-binding-v1"
_SOURCE_FILES = (
    "src/scientist/domains/cognitive_core/concept_validation_provider_v3.py",
    "src/scientist/domains/cognitive_core/repair_channel_validation_v1.py",
    "src/scientist/domains/cognitive_core/causal_structure_atlas_v1.py",
    "src/scientist/domains/cognitive_core/self_ask_incumbent_v1.py",
    "src/scientist/autonomy/mlx_receipt_runner.py",
    "src/scientist/autonomy/sequential_receipt_runner.py",
    "src/scientist/autonomy/receipt_journal.py",
    "scripts/run_cognitive_concept_validation_cell_v3.py",
    "scripts/run_cognitive_concept_validation_v3_qualification.py",
)


def _read(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("expected JSON object: %s" % path)
    return value


def _read_jsonl(path: Path) -> list[Mapping[str, Any]]:
    values = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    ]
    if any(not isinstance(row, Mapping) for row in values):
        raise ValueError("expected JSON-object rows: %s" % path)
    return values


def _write_immutable(path: Path, value: Any, *, jsonl: bool = False) -> None:
    payload = (
        "".join(
            json.dumps(item, sort_keys=True, ensure_ascii=False) + "\n"
            for item in value
        ).encode("utf-8")
        if jsonl
        else (
            json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
        ).encode("utf-8")
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.read_bytes() != payload:
            raise ValueError("refusing to replace frozen validation artifact: %s" % path)
        return
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _safe_extract(response: str) -> str:
    try:
        return extract_final_answer(response)
    except IndexError:
        return ""


def _safe_agreement(left: str, right: str) -> float:
    try:
        return agreement_score(left, right)
    except IndexError:
        return 0.0


def _identity(value: Mapping[str, Any], key: str) -> bool:
    body = dict(value)
    supplied = body.pop(key, None)
    return supplied == content_digest(body)


class AutonomyBoundConceptValidationRunner:
    measurement_ref = "deterministic-concept-validation-scorer-v3"

    def __init__(
        self,
        *,
        project_root: Path,
        mission_dir: Path,
        incumbent_bundle_dir: Path,
        atlas_bundle_dir: Path,
        python_executable: Path,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.mission_dir = Path(mission_dir).resolve()
        self.incumbent_bundle_dir = Path(incumbent_bundle_dir).resolve()
        self.atlas_bundle_dir = Path(atlas_bundle_dir).resolve()
        self.python_executable = Path(python_executable).absolute()
        self.output = self.mission_dir / "concept_validation_v3"

    def _journal_rows(self, phase: str, model_key: str) -> list[Mapping[str, Any]]:
        root = self.output / "journals" / phase / model_key / "receipts"
        return [_read(path) for path in sorted(root.glob("*.json"))]

    def _journal_invocations(
        self,
        phase: str,
        model_key: str,
        protocol: Mapping[str, Any],
        *,
        receipt_ids: set[str] | None = None,
    ) -> tuple[ExternalInvocation, ...]:
        values = []
        for outer in self._journal_rows(phase, model_key):
            outer_id = str(outer["receipt_id"])
            if receipt_ids is not None and outer_id not in receipt_ids:
                continue
            payload = outer.get("payload")
            if not isinstance(payload, Mapping) or not isinstance(payload.get("receipt"), Mapping):
                raise ValueError("validation journal omitted generation receipt")
            receipt = payload["receipt"]
            usage = ResourceUsage.from_dict(outer["usage"])
            values.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="evaluate_concept_validation:%s:%s:%s"
                    % (phase, model_key, outer["unit_ref"]),
                    actor=ActorIdentity(
                        "experimental-mlx-concept-validation:%s" % model_key,
                        ActorKind.TOOL_RUNTIME,
                    ),
                    authority_scope=AuthorityScope.EXECUTE,
                    input_artifact_ids=(
                        str(protocol["freeze_id"]),
                        str(protocol["models"][model_key]["identity_id"]),
                        str(receipt["prompt_sha256"]),
                    ),
                    output_artifact_ids=(outer_id, str(receipt["receipt_id"])),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=usage.wall_seconds,
                        compute_units=usage.compute_units,
                    ),
                )
            )
        return tuple(values)

    def _prepare_protocol(self, kernel) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
        started = time.perf_counter()
        path = self.output / "protocol-freeze-v3.json"
        if path.exists():
            protocol = _read(path)
            return protocol, {
                "wall_seconds": time.perf_counter() - started,
                "receipt_id": content_digest(("existing-validation-protocol", protocol["freeze_id"])),
            }
        repository = self.project_root / "third_party" / "self-ask"
        commit = subprocess.run(
            ("git", "-C", str(repository), "rev-parse", "HEAD"),
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        if commit != OFFICIAL_COMMIT:
            raise ValueError("official Self-Ask repository revision changed")
        dataset_path = repository / "datasets" / "compositional_celebrities.json"
        dataset = json.loads(dataset_path.read_text(encoding="utf-8"))
        incumbent_public = self.incumbent_bundle_dir / "public/items.jsonl"
        atlas_public = self.atlas_bundle_dir / "public/items.jsonl"
        prior = _read_jsonl(incumbent_public) + _read_jsonl(atlas_public)
        excluded = {str(row["source_row_digest"]) for row in prior}
        if len(excluded) != 20:
            raise ValueError("concept validation requires 20 disjoint prior rows")
        public, intervention, authority = select_panel(dataset["data"], excluded)
        public_path = self.output / "public/items.jsonl"
        intervention_path = self.output / "intervention/first-hop-state.jsonl"
        authority_path = self.output / "sealed/authority.jsonl"
        _write_immutable(public_path, public, jsonl=True)
        _write_immutable(intervention_path, intervention, jsonl=True)
        _write_immutable(authority_path, authority, jsonl=True)
        incumbent_protocol = _read(self.incumbent_bundle_dir / "protocol-freeze.json")
        family_rates = {}
        for arm in REPAIR_ARM_ORDER:
            correct = sum(case.outcome_metrics["%s_accuracy" % arm] for case in kernel.atlas.cases)
            family_rates[arm] = (correct + 1.0) / (len(kernel.atlas.cases) + 2.0)
        body = {
            "version": VERSION,
            "provider_version": PROVIDER_VERSION,
            "executor_version": EXECUTOR_VERSION,
            "mission_id": kernel.mission.mission_id,
            "concept_id": kernel.concept.concept_id,
            "atlas_id": kernel.atlas.atlas_id,
            "action_id": kernel.next_action().action_id,
            "official_commit": commit,
            "official_dataset_sha256": file_sha256(dataset_path),
            "source_code_sha256": {
                str(self.project_root / name): file_sha256(self.project_root / name)
                for name in _SOURCE_FILES
            },
            "runtime": incumbent_protocol["runtime"],
            "models": {key: incumbent_protocol["models"][key] for key in MODEL_ORDER},
            "selection": {
                "method": "answer-blind rank after incumbent and atlas exclusion",
                "horizon_slots": {key: [list(x) for x in slots] for key, slots in HORIZON_SLOTS.items()},
                "n_items": len(public),
                "excluded_prior_rows": len(excluded),
                "excluded_prior_digests": sorted(excluded),
                "incumbent_public_sha256": file_sha256(incumbent_public),
                "atlas_public_sha256": file_sha256(atlas_public),
                "public_path": str(public_path),
                "public_sha256": file_sha256(public_path),
                "intervention_path": str(intervention_path),
                "intervention_sha256": file_sha256(intervention_path),
                "authority_path": str(authority_path),
                "authority_sha256": file_sha256(authority_path),
                "answers_used_for_selection": False,
            },
            "phases": {
                "probe_order": list(PROBE_ORDER),
                "outcome_arm_order": list(OUTCOME_ARM_ORDER),
                "repair_arm_order": list(REPAIR_ARM_ORDER),
                "prediction_freeze_before_intervention": True,
                "authority_opened_after_all_outcomes": True,
            },
            "feature_contract": {
                "arm_primitives": ARM_PRIMITIVES,
                "representation_threshold": REPRESENTATION_THRESHOLD,
                "selection_priority": list(SELECTION_PRIORITY),
            },
            "predictive_gate": {
                "family_only_scores": family_rates,
                "required_predictive_score": kernel.concept.required_predictive_score,
                "minimum_predictive_improvement": kernel.concept.minimum_predictive_improvement,
                "positive_intervention_effect_required": True,
            },
            "decoding": {"temperature": 0.0, "top_p": 1.0, "thinking": False},
            "receipt_journal": {"per_generation_immutable": True, "resume_pending_only": True},
            "development_qualification_only": True,
            "prospective_nature_evidence_claimed": False,
        }
        protocol = {**body, "freeze_id": content_digest(body)}
        _write_immutable(path, protocol)
        receipt_body = {
            "operation": "freeze_concept_validation_protocol",
            "freeze_id": protocol["freeze_id"],
            "wall_seconds": time.perf_counter() - started,
        }
        receipt = {**receipt_body, "receipt_id": content_digest(receipt_body)}
        return protocol, receipt

    def _command(
        self,
        phase: str,
        model_key: str,
        protocol: Mapping[str, Any],
        kernel,
        prior_invocations: Sequence[ExternalInvocation],
    ) -> tuple[Mapping[str, Any], tuple[ExternalInvocation, ...], Mapping[str, Any]]:
        before = self._journal_rows(phase, model_key)
        before_ids = {str(row["receipt_id"]) for row in before}
        command = (
            str(self.python_executable),
            "scripts/run_cognitive_concept_validation_cell_v3.py",
            "--output",
            str(self.output),
            "--model-key",
            model_key,
            "--phase",
            phase,
            "--action-id",
            kernel.next_action().action_id,
        )
        environment = dict(os.environ)
        environment["PYTHONPATH"] = str(self.project_root / "src")
        started = time.perf_counter()
        completed = subprocess.run(
            command,
            cwd=str(self.project_root),
            env=environment,
            capture_output=True,
            text=True,
            check=False,
        )
        elapsed = time.perf_counter() - started
        after = self._journal_rows(phase, model_key)
        after_ids = {str(row["receipt_id"]) for row in after}
        new_ids = after_ids.difference(before_ids)
        generated_wall = sum(
            ResourceUsage.from_dict(row["usage"]).wall_seconds
            for row in after
            if str(row["receipt_id"]) in new_ids
        )
        receipt_body = {
            "command_digest": content_digest(command),
            "stdout_digest": content_digest(completed.stdout),
            "stderr_digest": content_digest(completed.stderr),
            "returncode": completed.returncode,
            "wall_seconds": elapsed,
            "orchestration_wall_seconds": max(0.0, elapsed - generated_wall),
            "journal_receipt_count_before": len(before_ids),
            "journal_receipt_count_after": len(after_ids),
            "stderr_tail": completed.stderr[-4000:],
            "stdout_tail": completed.stdout[-4000:],
        }
        receipt = {**receipt_body, "receipt_id": content_digest(receipt_body)}
        _write_immutable(
            self.output
            / "control"
            / "attempts"
            / ("%s-%s-%s.json" % (phase, model_key, receipt["receipt_id"])),
            receipt,
        )
        completion_path = self.output / (
            "control/%s-%s-v3-completion.json" % (phase, model_key)
        )
        outputs = [str(receipt["receipt_id"])]
        completion = _read(completion_path) if completion_path.exists() else {}
        if completion:
            outputs.extend(
                (
                    str(completion["completion_id"]),
                    str(completion["receipts_sha256"]),
                    str(completion["journal_completion_id"]),
                )
            )
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation="execute_resumable_concept_validation:%s:%s" % (phase, model_key),
            actor=ActorIdentity(
                "local-mlx-concept-validation-runtime:%s" % model_key,
                ActorKind.TOOL_RUNTIME,
            ),
            authority_scope=AuthorityScope.EXECUTE,
            input_artifact_ids=(
                str(protocol["freeze_id"]),
                str(protocol["models"][model_key]["identity_id"]),
            ),
            output_artifact_ids=tuple(outputs),
            usage=ResourceUsage(
                tool_calls=1,
                wall_seconds=float(receipt["orchestration_wall_seconds"]),
            ),
        )
        new_generation = self._journal_invocations(
            phase, model_key, protocol, receipt_ids=new_ids
        )
        if completed.returncode != 0:
            attempts = (*prior_invocations, invocation, *new_generation)
            infrastructure = "No Metal device available" in completed.stderr
            case = TransitionCase(
                case_ref="concept-validation-cell:%s:%s:%s"
                % (phase, model_key, receipt["receipt_id"]),
                phase="concept_validation",
                question="Can the frozen validation cell complete without changing evidence?",
                observations=(
                    "phase=%s" % phase,
                    "model=%s" % model_key,
                    "returncode=%s" % completed.returncode,
                    "stderr_digest=%s" % receipt["stderr_digest"],
                ),
                available_actions=(RecoveryAction.EXACT_RETRY, RecoveryAction.REPAIR_IMPLEMENTATION),
                protected_invariants=("mission", "concept", "protocol", "completed receipts"),
                evidence_refs=tuple(x for item in attempts for x in item.output_artifact_ids),
                retrospective=False,
                domain=kernel.mission.domain_id,
            )
            profile = FailureEvidenceProfile(
                case_id=case.case_id,
                runtime_available=not infrastructure,
                external_dependency_missing=False,
                implementation_integrity_passed=None if infrastructure else False,
                interface_qualified=None,
                protocol_feasible=None,
                measurement_qualified=None,
                scientific_outcome_observed=False,
                scientific_gate_passed=None,
                representation_limit_demonstrated=False,
            )
            raise AdjudicableResearchFailure(
                "resumable concept-validation cell failed",
                case=case,
                profile=profile,
                attempt_invocations=tuple(attempts),
            )
        return receipt, (invocation, *self._journal_invocations(phase, model_key, protocol)), completion

    def _freeze_predictions(
        self,
        kernel,
        protocol: Mapping[str, Any],
        completions: Mapping[str, Mapping[str, Any]],
    ) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
        path = self.output / "prediction-freeze-v3.json"
        if path.exists():
            prediction = _read(path)
            return prediction, prediction["preparation_receipt"]
        if any((self.output / "journals" / "outcomes" / key).exists() for key in MODEL_ORDER):
            raise ValueError("outcome execution began before prediction freeze")
        public = _read_jsonl(Path(str(protocol["selection"]["public_path"])))
        rows = []
        for model_key in MODEL_ORDER:
            receipts = _read_jsonl(Path(str(completions[model_key]["receipts_path"])))
            completion = completions[model_key]
            if (
                completion.get("status") != "resumable_validation_probes_complete"
                or completion.get("freeze_id") != protocol["freeze_id"]
                or completion.get("intervention_state_opened") is not False
                or completion.get("final_answers_opened_before_receipts") is not False
                or file_sha256(Path(str(completion["receipts_path"])))
                != completion["receipts_sha256"]
            ):
                raise ValueError("validation probe completion is invalid")
            by_key = {(str(row["item_id"]), str(row["unit"])): row for row in receipts}
            if len(receipts) != len(public) * len(PROBE_ORDER) or len(by_key) != len(receipts):
                raise ValueError("validation probe matrix is incomplete")
            for item in public:
                item_id = str(item["item_id"])
                probes = {kind: by_key[(item_id, kind)] for kind in PROBE_ORDER}
                internal = _safe_agreement(
                    str(probes["first_hop_demonstrated"]["response"]),
                    str(probes["first_hop_minimal"]["response"]),
                )
                residual = _safe_agreement(
                    str(probes["residual_demonstrated"]["response"]),
                    str(probes["residual_minimal"]["response"]),
                )
                rows.append(
                    {
                        "prospective_case_id": prospective_case_id(
                            str(protocol["freeze_id"]), model_key, item_id
                        ),
                        "model_key": model_key,
                        "item_id": item_id,
                        "category": item["category"],
                        "regime": item["regime"],
                        "horizon": item["horizon"],
                        "probe_receipt_ids": [str(probes[k]["receipt_id"]) for k in PROBE_ORDER],
                        "extracted_probe_values": {
                            kind: _safe_extract(str(probes[kind]["response"])) for kind in PROBE_ORDER
                        },
                        "prediction": case_prediction(internal, residual),
                        "baseline_scores": {
                            "family_only": {
                                arm: float(protocol["predictive_gate"]["family_only_scores"][arm])
                                for arm in REPAIR_ARM_ORDER
                            },
                            "complexity_only": {
                                arm: complexity_score(model_key, str(item["composed_question"]))
                                for arm in REPAIR_ARM_ORDER
                            },
                        },
                    }
                )
        receipt_body = {
            "operation": "freeze_answer_blind_concept_predictions",
            "probe_completion_ids": [completions[key]["completion_id"] for key in MODEL_ORDER],
        }
        preparation_receipt = {**receipt_body, "receipt_id": content_digest(receipt_body)}
        body = {
            "version": VERSION,
            "freeze_id": protocol["freeze_id"],
            "concept_id": kernel.concept.concept_id,
            "status": "answer_blind_predictions_frozen",
            "prospective_case_count": len(rows),
            "prediction_unit_count": len(rows) * len(REPAIR_ARM_ORDER),
            "rows": rows,
            "probe_completion_ids": [completions[key]["completion_id"] for key in MODEL_ORDER],
            "authority_opened": False,
            "intervention_state_opened": False,
            "outcome_receipts_observed": False,
            "feature_or_threshold_tuning_after_probe_observation": False,
            "scoring_rule_changed_after_protocol_freeze": False,
            "preparation_receipt": preparation_receipt,
        }
        prediction = {**body, "prediction_freeze_id": content_digest(body)}
        _write_immutable(path, prediction)
        return prediction, preparation_receipt

    def __call__(self, kernel, domain) -> InstrumentOutput:
        del domain
        if kernel.mission is None or kernel.atlas is None or kernel.concept is None:
            raise ValueError("concept validation requires mission, atlas, and concept")
        if kernel.next_action().kind != ResearchActionKind.VALIDATE_LATENT_CONCEPT:
            raise ValueError("concept validator received another action")
        protocol, preparation_receipt = self._prepare_protocol(kernel)
        if any(
            (
                protocol.get("mission_id") != kernel.mission.mission_id,
                protocol.get("atlas_id") != kernel.atlas.atlas_id,
                protocol.get("concept_id") != kernel.concept.concept_id,
                protocol.get("action_id") != kernel.next_action().action_id,
            )
        ):
            raise ValueError("concept-validation protocol belongs to another frontier")
        for source, expected_hash in protocol["source_code_sha256"].items():
            if file_sha256(Path(str(source))) != expected_hash:
                raise ValueError("concept-validation source changed: %s" % source)
        binding_path = self.output / "fresh-run-binding.json"
        invocation_prefix = [
            ExternalInvocation(
                kind=InvocationKind.TOOL,
                operation="freeze_concept_validation_protocol",
                actor=ActorIdentity("concept-validation-protocol-runtime-v3", ActorKind.TOOL_RUNTIME),
                authority_scope=AuthorityScope.EXECUTE,
                input_artifact_ids=(kernel.mission.mission_id, kernel.concept.concept_id),
                output_artifact_ids=(str(protocol["freeze_id"]), str(preparation_receipt["receipt_id"])),
                usage=ResourceUsage(tool_calls=1, wall_seconds=float(preparation_receipt.get("wall_seconds", 0.0))),
            )
        ]
        if binding_path.exists():
            binding = _read(binding_path)
            if not _identity(binding, "binding_id"):
                raise ValueError("concept-validation binding identity mismatch")
            if any(
                (
                    binding.get("mission_id") != kernel.mission.mission_id,
                    binding.get("concept_id") != kernel.concept.concept_id,
                    binding.get("action_id") != kernel.next_action().action_id,
                    binding.get("freeze_id") != protocol["freeze_id"],
                )
            ):
                raise ValueError("concept-validation binding belongs to another frontier")
            command_receipts = binding["command_receipts"]
            prediction = _read(self.output / "prediction-freeze-v3.json")
            if not _identity(prediction, "prediction_freeze_id"):
                raise ValueError("concept prediction-freeze identity mismatch")
            probe_completions = {
                key: _read(self.output / ("control/probes-%s-v3-completion.json" % key))
                for key in MODEL_ORDER
            }
            outcome_completions = {
                key: _read(self.output / ("control/outcomes-%s-v3-completion.json" % key))
                for key in MODEL_ORDER
            }
        else:
            command_receipts = {"probes": {}, "outcomes": {}}
            probe_completions = {}
            for model_key in MODEL_ORDER:
                receipt, items, completion = self._command(
                    "probes", model_key, protocol, kernel, tuple(invocation_prefix)
                )
                command_receipts["probes"][model_key] = receipt
                invocation_prefix.extend(items)
                probe_completions[model_key] = completion
            prediction, prediction_receipt = self._freeze_predictions(kernel, protocol, probe_completions)
            invocation_prefix.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="freeze_answer_blind_concept_predictions",
                    actor=ActorIdentity("answer-blind-prediction-freezer-v3", ActorKind.TOOL_RUNTIME),
                    authority_scope=AuthorityScope.MEASURE,
                    input_artifact_ids=tuple(str(probe_completions[key]["completion_id"]) for key in MODEL_ORDER),
                    output_artifact_ids=(str(prediction["prediction_freeze_id"]), str(prediction_receipt["receipt_id"])),
                    usage=ResourceUsage(tool_calls=1),
                )
            )
            outcome_completions = {}
            for model_key in MODEL_ORDER:
                receipt, items, completion = self._command(
                    "outcomes", model_key, protocol, kernel, tuple(invocation_prefix)
                )
                command_receipts["outcomes"][model_key] = receipt
                invocation_prefix.extend(items)
                outcome_completions[model_key] = completion
            normalized_compute = sum(
                float(
                    _read(self.output / "journals" / phase / key / "completion.json")["total_usage"]["compute_units"]
                )
                for phase in ("probes", "outcomes")
                for key in MODEL_ORDER
            )
            binding_body = {
                "version": BINDING_VERSION,
                "mission_id": kernel.mission.mission_id,
                "concept_id": kernel.concept.concept_id,
                "action_id": kernel.next_action().action_id,
                "freeze_id": protocol["freeze_id"],
                "preparation_receipt": preparation_receipt,
                "prediction_freeze_id": prediction["prediction_freeze_id"],
                "command_receipts": command_receipts,
                "probe_completion_ids": {key: probe_completions[key]["completion_id"] for key in MODEL_ORDER},
                "outcome_completion_ids": {key: outcome_completions[key]["completion_id"] for key in MODEL_ORDER},
                "normalized_compute_definition": "sum-of-immutable-per-generation-wall-seconds",
                "normalized_compute_units": normalized_compute,
                "normalized_compute_charge_complete": True,
                "human_interventions": 0,
                "out_of_band_interventions": 0,
                "development_qualification_only": True,
                "prospective_nature_evidence_claimed": False,
            }
            binding = {**binding_body, "binding_id": content_digest(binding_body)}
            _write_immutable(binding_path, binding)

        invocations = [invocation_prefix[0]]
        for phase, completions in (("probes", probe_completions), ("outcomes", outcome_completions)):
            if phase == "outcomes":
                prediction_receipt = prediction["preparation_receipt"]
                invocations.append(
                    ExternalInvocation(
                        kind=InvocationKind.TOOL,
                        operation="freeze_answer_blind_concept_predictions",
                        actor=ActorIdentity("answer-blind-prediction-freezer-v3", ActorKind.TOOL_RUNTIME),
                        authority_scope=AuthorityScope.MEASURE,
                        input_artifact_ids=tuple(str(probe_completions[key]["completion_id"]) for key in MODEL_ORDER),
                        output_artifact_ids=(str(prediction["prediction_freeze_id"]), str(prediction_receipt["receipt_id"])),
                        usage=ResourceUsage(tool_calls=1),
                    )
                )
            for model_key in MODEL_ORDER:
                receipt = command_receipts[phase][model_key]
                completion = completions[model_key]
                invocations.append(
                    ExternalInvocation(
                        kind=InvocationKind.TOOL,
                        operation="execute_resumable_concept_validation:%s:%s" % (phase, model_key),
                        actor=ActorIdentity("local-mlx-concept-validation-runtime:%s" % model_key, ActorKind.TOOL_RUNTIME),
                        authority_scope=AuthorityScope.EXECUTE,
                        input_artifact_ids=(str(protocol["freeze_id"]), str(protocol["models"][model_key]["identity_id"])),
                        output_artifact_ids=(
                            str(receipt["receipt_id"]),
                            str(completion["completion_id"]),
                            str(completion["receipts_sha256"]),
                            str(completion["journal_completion_id"]),
                        ),
                        usage=ResourceUsage(tool_calls=1, wall_seconds=float(receipt["orchestration_wall_seconds"])),
                    )
                )
                invocations.extend(self._journal_invocations(phase, model_key, protocol))

        certificate, evidence_id, summary = self._score(kernel, protocol, prediction, outcome_completions)
        invocations.append(
            ExternalInvocation(
                kind=InvocationKind.TOOL,
                operation="score_concept_validation",
                actor=ActorIdentity(self.measurement_ref, ActorKind.TOOL_RUNTIME),
                authority_scope=AuthorityScope.MEASURE,
                input_artifact_ids=(
                    str(protocol["freeze_id"]),
                    str(prediction["prediction_freeze_id"]),
                    str(protocol["selection"]["authority_sha256"]),
                    str(binding["binding_id"]),
                ),
                output_artifact_ids=(certificate.validation_id, evidence_id),
                usage=ResourceUsage(tool_calls=1),
            )
        )
        return InstrumentOutput(
            artifact=certificate,
            artifact_id=certificate.validation_id,
            invocations=tuple(invocations),
            measurement_ref=self.measurement_ref,
            details={
                "provider_version": PROVIDER_VERSION,
                "freeze_id": protocol["freeze_id"],
                "fresh_run_binding_id": binding["binding_id"],
                "prediction_freeze_id": prediction["prediction_freeze_id"],
                "evidence_id": evidence_id,
                "summary": summary,
                "generation_invocations": sum(
                    len(self._journal_rows(phase, key))
                    for phase in ("probes", "outcomes")
                    for key in MODEL_ORDER
                ),
                "normalized_compute_units": binding["normalized_compute_units"],
                "normalized_compute_charge_complete": True,
                "development_only": True,
                "prospective_nature_evidence_claimed": False,
            },
        )

    def _score(self, kernel, protocol, prediction, completions):
        public = _read_jsonl(Path(str(protocol["selection"]["public_path"])))
        authority = {
            str(row["item_id"]): row
            for row in _read_jsonl(Path(str(protocol["selection"]["authority_path"])))
        }
        predictions = {(str(row["model_key"]), str(row["item_id"])): row for row in prediction["rows"]}
        receipts_by_model = {}
        for model_key in MODEL_ORDER:
            completion = completions[model_key]
            if (
                completion.get("status") != "resumable_validation_outcomes_complete"
                or completion.get("freeze_id") != protocol["freeze_id"]
                or completion.get("prediction_freeze_id") != prediction["prediction_freeze_id"]
                or completion.get("final_answers_opened_before_receipts") is not False
                or file_sha256(Path(str(completion["receipts_path"]))) != completion["receipts_sha256"]
            ):
                raise ValueError("validation outcome completion is invalid")
            rows = _read_jsonl(Path(str(completion["receipts_path"])))
            receipts_by_model[model_key] = {(str(row["item_id"]), str(row["unit"])): row for row in rows}
        scored = []
        concept_scores: list[float] = []
        family_scores: list[float] = []
        complexity_scores: list[float] = []
        labels: list[bool] = []
        deltas = []
        for model_key in MODEL_ORDER:
            for item in public:
                item_id = str(item["item_id"])
                forecast = predictions[(model_key, item_id)]
                arms = {arm: receipts_by_model[model_key][(item_id, arm)] for arm in OUTCOME_ARM_ORDER}
                extracted = {arm: _safe_extract(str(row["response"])) for arm, row in arms.items()}
                correct = {arm: answer_is_exact(value, authority[item_id]["composed_answers"]) for arm, value in extracted.items()}
                for arm in REPAIR_ARM_ORDER:
                    concept_scores.append(float(forecast["prediction"]["repair_scores"][arm]))
                    family_scores.append(float(forecast["baseline_scores"]["family_only"][arm]))
                    complexity_scores.append(float(forecast["baseline_scores"]["complexity_only"][arm]))
                    labels.append(bool(correct[arm]))
                selected = str(forecast["prediction"]["selected_repair_class"])
                selected_correct = bool(correct["direct"] if selected == "representation_required" else correct[selected])
                delta = int(selected_correct) - int(correct["direct"])
                deltas.append(delta)
                scored.append(
                    {
                        "prospective_case_id": forecast["prospective_case_id"],
                        "model_key": model_key,
                        "item_id": item_id,
                        "prediction": forecast["prediction"],
                        "correct": correct,
                        "selected_repair_class": selected,
                        "selected_correct": selected_correct,
                        "direct_correct": bool(correct["direct"]),
                        "selected_effect": delta,
                        "outcome_receipt_ids": [str(arms[arm]["receipt_id"]) for arm in OUTCOME_ARM_ORDER],
                    }
                )
        concept_auc = binary_auc(concept_scores, labels)
        family_auc = binary_auc(family_scores, labels)
        complexity_auc = binary_auc(complexity_scores, labels)
        baseline_auc = max(family_auc, complexity_auc)
        effect = sum(deltas) / len(deltas)
        summary = {
            "prospective_cases": len(scored),
            "prediction_units": len(labels),
            "positive_repair_outcomes": sum(labels),
            "negative_repair_outcomes": len(labels) - sum(labels),
            "family_only_auc": family_auc,
            "complexity_only_auc": complexity_auc,
            "certificate_baseline_auc": baseline_auc,
            "repair_channel_sufficiency_auc": concept_auc,
            "predictive_improvement": concept_auc - baseline_auc,
            "selected_intervention_effect": effect,
            "selected_accuracy": sum(bool(row["selected_correct"]) for row in scored) / len(scored),
            "direct_accuracy": sum(bool(row["direct_correct"]) for row in scored) / len(scored),
        }
        evidence_body = {
            "version": VERSION,
            "provider_version": PROVIDER_VERSION,
            "freeze_id": protocol["freeze_id"],
            "mission_id": kernel.mission.mission_id,
            "concept_id": kernel.concept.concept_id,
            "prediction_freeze_id": prediction["prediction_freeze_id"],
            "summary": summary,
            "rows": scored,
            "authority_opened_after_prediction_freeze": True,
            "authority_opened_after_all_outcome_receipts": True,
            "scoring_rule_changed_after_outcomes": False,
            "external_search_used": False,
        }
        evidence_id = content_digest(evidence_body)
        certificate = ConceptValidationCertificate(
            concept_id=kernel.concept.concept_id,
            development_contrast_ids=kernel.concept.development_contrast_ids,
            prospective_case_ids=tuple(str(row["prospective_case_id"]) for row in scored),
            baseline_predictive_score=baseline_auc,
            augmented_predictive_score=concept_auc,
            intervention_effect=effect,
            required_predictive_score=float(protocol["predictive_gate"]["required_predictive_score"]),
            minimum_predictive_improvement=float(protocol["predictive_gate"]["minimum_predictive_improvement"]),
            evidence_ids=(str(prediction["prediction_freeze_id"]), evidence_id, *tuple(str(completions[key]["completion_id"]) for key in MODEL_ORDER)),
            evaluator_ref="deterministic-prospective-concept-validator-v3",
        )
        _write_immutable(self.output / "validation-evidence-v3.json", {**evidence_body, "evidence_id": evidence_id})
        _write_immutable(self.output / "validation-certificate-v3.json", certificate.as_dict())
        return certificate, evidence_id, summary


def validate_autonomy_bound_concept_validation(output, kernel, domain):
    del domain
    certificate = output.artifact
    checks = {
        "artifact_type": isinstance(certificate, ConceptValidationCertificate),
        "artifact_identity": output.artifact_id == certificate.validation_id,
        "concept_identity": certificate.concept_id == kernel.concept.concept_id,
        "prospective_case_count": len(certificate.prospective_case_ids) == 24,
        "development_contrasts_preserved": certificate.development_contrast_ids == kernel.concept.development_contrast_ids,
        "all_generations_charged": output.details["generation_invocations"] == 216,
        "compute_positive": output.details["normalized_compute_units"] > 0.0,
        "compute_complete": output.details["normalized_compute_charge_complete"],
        "nature_claim_closed": output.details["prospective_nature_evidence_claimed"] is False,
    }
    return DeterministicValidationReceipt(
        artifact_id=output.artifact_id,
        verifier_ref="independent-concept-validation-validator-v3",
        checks=checks,
        evidence_ids=(
            str(output.details["freeze_id"]),
            str(output.details["fresh_run_binding_id"]),
            str(output.details["prediction_freeze_id"]),
            str(output.details["evidence_id"]),
        ),
    )


def build_autonomy_bound_concept_validation_stage_provider(
    *,
    project_root: Path,
    mission_dir: Path,
    incumbent_bundle_dir: Path,
    atlas_bundle_dir: Path,
    python_executable: Path,
) -> InstrumentValidatorStageProvider:
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.VALIDATE_LATENT_CONCEPT,
        runner=AutonomyBoundConceptValidationRunner(
            project_root=project_root,
            mission_dir=mission_dir,
            incumbent_bundle_dir=incumbent_bundle_dir,
            atlas_bundle_dir=atlas_bundle_dir,
            python_executable=python_executable,
        ),
        validator=validate_autonomy_bound_concept_validation,
        outcome="prospective_concept_validation_completed",
    )


__all__ = [
    "AutonomyBoundConceptValidationRunner",
    "build_autonomy_bound_concept_validation_stage_provider",
    "validate_autonomy_bound_concept_validation",
]
