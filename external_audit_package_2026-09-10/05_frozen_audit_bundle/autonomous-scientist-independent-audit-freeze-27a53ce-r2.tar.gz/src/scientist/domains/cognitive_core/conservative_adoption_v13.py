from __future__ import annotations

import inspect
import random
from dataclasses import dataclass, replace
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_schema_mechanism_v12 import (
    CausalSchemaCandidate,
    CausalSchemaPreregistration,
)
from scientist.domains.cognitive_core.functional_vertical_slice_v11 import (
    SliceCandidateDescriptor,
    SlicePartition,
    VerticalCandidateEvaluation,
    VerticalEpisode,
    VerticalProbe,
    VerticalSliceRegistry,
    evaluate_vertical_candidate,
    make_vertical_episode,
)
from scientist.domains.cognitive_core.shared_substrate_v10 import (
    CandidateActionKind,
    CandidateEvent,
    CandidateEventKind,
    ReferenceSharedBaseline,
    SharedCandidateInterfaceContract,
    WAVE_ONE_KEYS,
    reference_shared_baseline,
)


CONSERVATIVE_ADOPTION_VERSION = "cognitive-core-conservative-adoption-v13"


@dataclass(frozen=True)
class FrozenCandidateIdentity:
    candidate_id: str
    executable_digest: str
    implementation_source_digest: str
    hypothesis_id: str
    source_preregistration_id: str

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, str]:
        value = {
            "candidate_id": self.candidate_id,
            "executable_digest": self.executable_digest,
            "implementation_source_digest": self.implementation_source_digest,
            "hypothesis_id": self.hypothesis_id,
            "source_preregistration_id": self.source_preregistration_id,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


@dataclass(frozen=True)
class ConservativeAdoptionTrial:
    candidate_freeze: FrozenCandidateIdentity
    registry: VerticalSliceRegistry
    sham_registry_id: str
    baseline: VerticalCandidateEvaluation
    candidate: VerticalCandidateEvaluation
    sham_candidate: VerticalCandidateEvaluation
    audit_deltas: Mapping[str, float]
    protected_retest_pass_rate: float
    adoption_checks: Mapping[str, bool]
    disposition: str
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.adoption_checks.values()) and self.disposition == "adopt_for_replication"

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": CONSERVATIVE_ADOPTION_VERSION,
            "candidate_freeze": self.candidate_freeze.as_dict(),
            "registry": self.registry.as_dict(),
            "sham_registry_id": self.sham_registry_id,
            "baseline": self.baseline.as_dict(),
            "candidate": self.candidate.as_dict(),
            "sham_candidate": self.sham_candidate.as_dict(),
            "audit_deltas": dict(sorted(self.audit_deltas.items())),
            "protected_retest_pass_rate": self.protected_retest_pass_rate,
            "adoption_checks": dict(sorted(self.adoption_checks.items())),
            "disposition": self.disposition,
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def freeze_combined_candidate(
    preregistration: CausalSchemaPreregistration,
    interface_id: str,
) -> FrozenCandidateIdentity:
    combined = next(
        item for item in preregistration.arms if item.arm_id == "combined"
    )
    runtime = CausalSchemaCandidate(
        hypothesis_id=preregistration.hypothesis.hypothesis_id,
        arm=combined,
        interface_id=interface_id,
    )
    return FrozenCandidateIdentity(
        candidate_id=runtime.descriptor.candidate_id,
        executable_digest=runtime.descriptor.executable_digest,
        implementation_source_digest=content_digest(
            inspect.getsource(CausalSchemaCandidate)
        ),
        hypothesis_id=preregistration.hypothesis.hypothesis_id,
        source_preregistration_id=preregistration.preregistration_id,
    )


def harden_vertical_episode(
    episode: VerticalEpisode,
    previous: Tuple[str, int, int, int] | None,
) -> Tuple[VerticalEpisode, Tuple[str, int, int, int]]:
    events = list(episode.events)
    probes = list(episode.probes)
    spec = events[0].payload["procedure_spec"]
    modulus = int(spec["modulus"])
    scale = int(spec["scale"])
    first_updated_shift = int(events[4].payload["value"])

    relevance = events[3]
    evidence = list(relevance.payload["evidence"])
    reordered = [evidence[3], evidence[0], evidence[4], evidence[1], evidence[5], evidence[2]]
    relabeled = [
        {
            **row,
            "relation": "edge_%s_%d" % (episode.episode_id, index),
        }
        for index, row in enumerate(reordered)
    ]
    events[3] = CandidateEvent(
        relevance.event_id,
        relevance.kind,
        {**relevance.payload, "evidence": relabeled},
    )

    second_shift = (first_updated_shift + 5) % modulus
    second_update = CandidateEvent(
        "%s-second-update" % episode.episode_id,
        CandidateEventKind.REQUEST_UPDATE,
        {
            "key": "task::%s::shift" % episode.task_token,
            "value": str(second_shift),
            "task_token": episode.task_token,
            "field": "shift",
        },
    )
    second_query_x = 10
    second_query = CandidateEvent(
        "%s-second-update-query" % episode.episode_id,
        CandidateEventKind.ANSWER_TASK,
        {"task_token": episode.task_token, "operands": [second_query_x]},
    )
    events.extend((second_update, second_query))
    probes.extend(
        (
            VerticalProbe(
                "%s-probe-second-update" % episode.episode_id,
                episode.partition,
                episode.episode_id,
                "requested_change",
                second_update.event_id,
                CandidateActionKind.UPDATE_ACKNOWLEDGEMENT,
                {
                    "key": "task::%s::shift" % episode.task_token,
                    "stored": str(second_shift),
                },
            ),
            VerticalProbe(
                "%s-probe-second-update-query" % episode.episode_id,
                episode.partition,
                episode.episode_id,
                "requested_change",
                second_query.event_id,
                CandidateActionKind.TASK_RESULT,
                {"value": (scale * second_query_x + second_shift) % modulus},
            ),
        )
    )
    if previous is not None:
        previous_task, previous_modulus, previous_scale, previous_shift = previous
        retention_x = 8
        retention_event = CandidateEvent(
            "%s-retain-previous-update" % episode.episode_id,
            CandidateEventKind.ANSWER_TASK,
            {"task_token": previous_task, "operands": [retention_x]},
        )
        events.append(retention_event)
        probes.append(
            VerticalProbe(
                "%s-probe-retain-previous-update" % episode.episode_id,
                episode.partition,
                episode.episode_id,
                "requested_change",
                retention_event.event_id,
                CandidateActionKind.TASK_RESULT,
                {
                    "value": (
                        previous_scale * retention_x + previous_shift
                    )
                    % previous_modulus
                },
            )
        )
    hardened = replace(episode, events=tuple(events), probes=tuple(probes))
    return hardened, (episode.task_token, modulus, scale, second_shift)


def build_expanded_adoption_registry(
    interface: SharedCandidateInterfaceContract,
) -> VerticalSliceRegistry:
    specifications = (
        (SlicePartition.DEVELOPMENT, 19, 1907, 4, 100),
        (SlicePartition.CALIBRATION, 23, 2309, 6, 200),
        (SlicePartition.AUDIT, 29, 2909, 8, 300),
    )
    episodes = []
    previous = None
    for partition, modulus, seed, count, offset in specifications:
        randomizer = random.Random(seed)
        pairs = []
        while len(pairs) < count:
            pair = (
                randomizer.randrange(1, modulus),
                randomizer.randrange(0, modulus),
            )
            if pair not in pairs:
                pairs.append(pair)
        for local_index, (scale, shift) in enumerate(pairs):
            base = make_vertical_episode(
                partition,
                offset + local_index,
                modulus=modulus,
                scale=scale,
                shift=shift,
            )
            hardened, previous = harden_vertical_episode(base, previous)
            episodes.append(hardened)
    event_count = sum(len(item.events) for item in episodes)
    scale = event_count / 72.0
    return VerticalSliceRegistry(
        interface_id=interface.interface_id,
        episodes=tuple(episodes),
        cost_envelope={
            "parameter_count": 0.0,
            "training_compute_flops": 0.0,
            "training_examples": 0.0,
            "inference_events": float(event_count),
            "primitive_operations": 50000.0 * scale,
            "context_tokens": 10000.0 * scale,
            "persistent_memory_slots": 100.0,
            "retrieval_calls": 24.0 * scale,
            "adaptation_writes": 100.0 * scale,
            "external_service_calls": 0.0,
        },
        frozen_partitions=(
            SlicePartition.DEVELOPMENT.value,
            SlicePartition.CALIBRATION.value,
            SlicePartition.AUDIT.value,
        ),
        shortcut_controls=(
            "all episode, task, surface, evidence, modulus, and coefficient identities differ from discovery",
            "evidence order and relation labels are changed without changing the causal graph",
            "each task receives two persistent updates",
            "earlier updated tasks are re-queried after intervening task episodes",
            "candidate source, hypothesis, and executable identities are frozen before evaluation",
        ),
    )


def build_surface_relation_sham_registry(
    registry: VerticalSliceRegistry,
) -> VerticalSliceRegistry:
    episodes = []
    for episode in registry.episodes:
        events = []
        for event in episode.events:
            payload = dict(event.payload)
            if event.kind == CandidateEventKind.EXECUTE_PROCEDURE:
                spec = dict(payload["procedure_spec"])
                spec["surface_token"] = "sham::%s" % spec["surface_token"]
                payload["operation"] = "sham::%s" % payload["operation"]
                payload["procedure_spec"] = spec
            if event.kind == CandidateEventKind.SELECT_RELEVANCE:
                payload["evidence"] = [
                    {**row, "relation": "sham::%s" % row["relation"]}
                    for row in payload["evidence"]
                ]
            events.append(CandidateEvent(event.event_id, event.kind, payload))
        episodes.append(replace(episode, events=tuple(events)))
    return replace(registry, episodes=tuple(episodes))


def run_conservative_adoption_trial(
    *,
    preregistration: CausalSchemaPreregistration,
    interface: SharedCandidateInterfaceContract,
    candidate_freeze: FrozenCandidateIdentity | None = None,
    registry: VerticalSliceRegistry | None = None,
) -> ConservativeAdoptionTrial:
    freeze = candidate_freeze or freeze_combined_candidate(
        preregistration, interface.interface_id
    )
    registry = registry or build_expanded_adoption_registry(interface)
    expected_freeze = freeze_combined_candidate(
        preregistration, interface.interface_id
    )
    if freeze != expected_freeze:
        raise ValueError("provided candidate freeze differs from the combined arm")
    if registry.interface_id != interface.interface_id:
        raise ValueError("provided adoption registry uses another interface")
    sham_registry = build_surface_relation_sham_registry(registry)
    baseline_spec = reference_shared_baseline(interface)
    baseline_descriptor = SliceCandidateDescriptor(
        candidate_id=baseline_spec.candidate_id,
        name=baseline_spec.name,
        executable_digest=baseline_spec.executable_digest,
        role="registered_incumbent",
        admissible_for_search=True,
    )
    combined_arm = next(
        item for item in preregistration.arms if item.arm_id == "combined"
    )
    candidate_runtime = CausalSchemaCandidate(
        hypothesis_id=preregistration.hypothesis.hypothesis_id,
        arm=combined_arm,
        interface_id=interface.interface_id,
    )
    sham_runtime = CausalSchemaCandidate(
        hypothesis_id=preregistration.hypothesis.hypothesis_id,
        arm=combined_arm,
        interface_id=interface.interface_id,
    )
    baseline = evaluate_vertical_candidate(
        ReferenceSharedBaseline(baseline_spec),
        baseline_descriptor,
        registry,
    )
    candidate = evaluate_vertical_candidate(
        candidate_runtime,
        candidate_runtime.descriptor,
        registry,
    )
    sham = evaluate_vertical_candidate(
        sham_runtime,
        sham_runtime.descriptor,
        sham_registry,
    )
    audit_deltas = {
        key: (
            candidate.partition_scores[SlicePartition.AUDIT.value][key]
            - baseline.partition_scores[SlicePartition.AUDIT.value][key]
        )
        for key in WAVE_ONE_KEYS
    }
    retention_outcomes = tuple(
        item
        for item in candidate.outcomes
        if "retain-previous-update" in item.probe.probe_id
    )
    protected_pass_rate = (
        sum(item.passed for item in retention_outcomes)
        / len(retention_outcomes)
    )
    checks = {
        "candidate_identity_matches_pre_outcome_freeze": (
            candidate.candidate.candidate_id == freeze.candidate_id
            and candidate.candidate.executable_digest == freeze.executable_digest
        ),
        "candidate_passes_all_expanded_calibration_and_audit_gates": all(
            candidate.functional_gates.values()
        ),
        "candidate_strictly_improves_four_behavioral_audit_metrics": all(
            audit_deltas[key] > 0.0
            for key in WAVE_ONE_KEYS
            if key != "system_cost"
        ),
        "candidate_system_cost_has_no_envelope_regression": (
            audit_deltas["system_cost"] >= 0.0
            and candidate.functional_gates["system_cost"] == 1.0
            and candidate.final_cost.external_service_calls == 0
        ),
        "all_delayed_protected_update_retests_pass": (
            bool(retention_outcomes) and protected_pass_rate == 1.0
        ),
        "surface_and_relation_sham_preserves_all_scores": (
            sham.partition_scores == candidate.partition_scores
            and sham.functional_gates == candidate.functional_gates
        ),
        "baseline_does_not_accidentally_pass_behavioral_gates": all(
            baseline.functional_gates[key] == 0.0
            for key in WAVE_ONE_KEYS
            if key != "system_cost"
        ),
        "all_three_runs_share_candidate_inputs_within_each_registry": (
            baseline.event_stream_digest == candidate.event_stream_digest
            and sham.registry_id == sham_registry.registry_id
        ),
    }
    disposition = (
        "adopt_for_replication" if all(checks.values()) else "reject_or_repair"
    )
    return ConservativeAdoptionTrial(
        candidate_freeze=freeze,
        registry=registry,
        sham_registry_id=sham_registry.registry_id,
        baseline=baseline,
        candidate=candidate,
        sham_candidate=sham,
        audit_deltas=audit_deltas,
        protected_retest_pass_rate=protected_pass_rate,
        adoption_checks=checks,
        disposition=disposition,
        limitations=(
            "Adoption means promotion to independent replication, not integration into the objective graph.",
            "Expanded cases remain synthetic finite-field and directed-graph tasks.",
            "Procedure composition, uncertain routing, evidence conflicts, and long-horizon interference remain untested downstream work packages.",
        ),
    )
