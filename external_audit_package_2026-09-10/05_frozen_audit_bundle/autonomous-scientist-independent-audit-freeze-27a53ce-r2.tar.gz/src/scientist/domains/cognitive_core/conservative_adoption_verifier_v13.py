from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_schema_mechanism_v12 import (
    CausalSchemaCandidate,
)
from scientist.domains.cognitive_core.conservative_adoption_v13 import (
    ConservativeAdoptionTrial,
)
from scientist.domains.cognitive_core.functional_vertical_slice_v11 import (
    SlicePartition,
    VerticalSliceExperiment,
)
from scientist.domains.cognitive_core.shared_substrate_v10 import WAVE_ONE_KEYS
from scientist.program.control_plane import AutonomousScientistControlPlane


CONSERVATIVE_ADOPTION_VERIFIER_REF = (
    "cognitive-core-conservative-adoption-independent-verifier-v13"
)


@dataclass(frozen=True)
class ConservativeAdoptionVerification:
    check_results: Mapping[str, bool]
    trial_id: str
    freeze_id: str
    registry_id: str
    candidate_id: str
    audit_deltas: Mapping[str, float]
    protected_retest_pass_rate: float
    disposition: str
    limitations: Tuple[str, ...]
    verifier_ref: str = CONSERVATIVE_ADOPTION_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "trial_id": self.trial_id,
            "freeze_id": self.freeze_id,
            "registry_id": self.registry_id,
            "candidate_id": self.candidate_id,
            "audit_deltas": dict(sorted(self.audit_deltas.items())),
            "protected_retest_pass_rate": self.protected_retest_pass_rate,
            "disposition": self.disposition,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_conservative_adoption(
    *,
    control: AutonomousScientistControlPlane,
    discovery_experiment: VerticalSliceExperiment,
    trial: ConservativeAdoptionTrial,
    replay: ConservativeAdoptionTrial,
    phase_four_manifest: Mapping[str, Any],
) -> ConservativeAdoptionVerification:
    registry = trial.registry
    episode_counts = {
        partition.value: sum(
            item.partition == partition for item in registry.episodes
        )
        for partition in SlicePartition
    }
    discovery_event_ids = {
        event.event_id
        for episode in discovery_experiment.registry.episodes
        for event in episode.events
    }
    adoption_event_ids = {
        event.event_id
        for episode in registry.episodes
        for event in episode.events
    }
    discovery_task_ids = {
        item.task_token for item in discovery_experiment.registry.episodes
    }
    adoption_task_ids = {item.task_token for item in registry.episodes}
    moduli = {
        int(episode.events[0].payload["procedure_spec"]["modulus"])
        for episode in registry.episodes
    }
    second_update_count = sum(
        "second-update" in event.event_id
        and "query" not in event.event_id
        for episode in registry.episodes
        for event in episode.events
    )
    retention_outcomes = tuple(
        item
        for item in trial.candidate.outcomes
        if "retain-previous-update" in item.probe.probe_id
    )
    evidence_hardening = all(
        all(
            str(row["relation"]).startswith("edge_")
            for row in episode.events[3].payload["evidence"]
        )
        for episode in registry.episodes
    )
    candidate_trace_valid = all(
        left.state_after_id == right.state_before_id
        and left.cost_after == right.cost_before
        for left, right in zip(
            trial.candidate.steps, trial.candidate.steps[1:]
        )
    )
    progress = control.graph.progress_by_role()
    control_value = control.as_dict()
    checks = {
        "phase_four_candidate_hypothesis_and_preregistration_are_bound": (
            bool(phase_four_manifest.get("passed"))
            and trial.candidate_freeze.candidate_id
            == phase_four_manifest["combined_candidate_id"]
            and trial.candidate_freeze.executable_digest
            == phase_four_manifest["combined_candidate_executable_digest"]
            and trial.candidate_freeze.hypothesis_id
            == phase_four_manifest["hypothesis_id"]
            and trial.candidate_freeze.source_preregistration_id
            == phase_four_manifest["preregistration_id"]
        ),
        "candidate_implementation_source_is_content_frozen": (
            trial.candidate_freeze.implementation_source_digest
            == content_digest(inspect.getsource(CausalSchemaCandidate))
        ),
        "expanded_registry_has_preregistered_partition_sizes_and_new_moduli": (
            episode_counts
            == {"development": 4, "calibration": 6, "audit": 8}
            and moduli == {19, 23, 29}
            and len(registry.episodes) == 18
        ),
        "expanded_registry_identifiers_are_disjoint_from_discovery": (
            adoption_event_ids.isdisjoint(discovery_event_ids)
            and adoption_task_ids.isdisjoint(discovery_task_ids)
        ),
        "expanded_registry_hardens_evidence_updates_and_delayed_retests": (
            evidence_hardening
            and second_update_count == 18
            and len(retention_outcomes) == 17
        ),
        "candidate_identity_remains_frozen_during_evaluation": (
            trial.candidate.candidate.candidate_id
            == trial.candidate_freeze.candidate_id
            and trial.candidate.candidate.executable_digest
            == trial.candidate_freeze.executable_digest
        ),
        "candidate_strictly_improves_all_four_behavioral_audit_metrics": all(
            trial.audit_deltas[key] > 0.0
            for key in WAVE_ONE_KEYS
            if key != "system_cost"
        ),
        "candidate_passes_every_expanded_functional_gate": all(
            trial.candidate.functional_gates.values()
        ),
        "system_cost_and_external_service_floors_hold": (
            trial.audit_deltas["system_cost"] >= 0.0
            and trial.candidate.functional_gates["system_cost"] == 1.0
            and trial.candidate.final_cost.external_service_calls == 0
        ),
        "every_delayed_protected_retest_passes": (
            trial.protected_retest_pass_rate == 1.0
            and all(item.passed for item in retention_outcomes)
        ),
        "surface_and_relation_sham_leave_candidate_behavior_unchanged": (
            trial.sham_candidate.partition_scores
            == trial.candidate.partition_scores
            and trial.sham_candidate.functional_gates
            == trial.candidate.functional_gates
        ),
        "baseline_fails_behavioral_gates_under_identical_inputs": (
            trial.baseline.event_stream_digest
            == trial.candidate.event_stream_digest
            and all(
                trial.baseline.functional_gates[key] == 0.0
                for key in WAVE_ONE_KEYS
                if key != "system_cost"
            )
        ),
        "candidate_uses_one_continuous_persistent_trace": candidate_trace_valid,
        "all_internal_adoption_checks_and_disposition_pass": (
            trial.passed
            and all(trial.adoption_checks.values())
            and trial.disposition == "adopt_for_replication"
        ),
        "trial_replay_is_content_identical": trial.trial_id == replay.trial_id,
        "adoption_does_not_prematurely_integrate_objective_nodes": (
            not control_value["campaigns"]
            and progress["objective"]["integrated"] == 0
            and progress["objective"]["total"] == 44
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    return ConservativeAdoptionVerification(
        check_results=checks,
        trial_id=trial.trial_id,
        freeze_id=trial.candidate_freeze.freeze_id,
        registry_id=registry.registry_id,
        candidate_id=trial.candidate_freeze.candidate_id,
        audit_deltas=trial.audit_deltas,
        protected_retest_pass_rate=trial.protected_retest_pass_rate,
        disposition=trial.disposition,
        limitations=(
            "The candidate is adopted only as the sole object entering Phase-6 replication.",
            "No functional leaf or parent objective is integrated until independent replication and long-horizon checks pass.",
            "The expanded task distribution remains a synthetic test of the mechanism's declared scope.",
        ),
    )
