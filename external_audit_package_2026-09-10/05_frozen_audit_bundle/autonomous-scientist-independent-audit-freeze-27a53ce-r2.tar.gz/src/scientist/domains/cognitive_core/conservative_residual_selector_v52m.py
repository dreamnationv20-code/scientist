from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence, Tuple

import numpy as np

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.joint_relational_comparator_v52l import (
    comparator_metrics,
)


CONSERVATIVE_RESIDUAL_SELECTOR_VERSION = (
    "general-cognitive-conservative-residual-selector-v52m"
)
M52M_SEED = 52941
M52M_M52L_AUDIT_ID = (
    "74528b1468316793d7e50e351fd580a4858833cbb35437f9b86def4ae3b0b6a2"
)
M52M_JOINT_CHECKPOINT_ITERATION = 160
M52M_JOINT_CHECKPOINT_SHA256 = (
    "96240e948521722ba9e11d1c22c44e036806db93e234aea7daf1f1ebe7778376"
)

M52M_SELECTOR_FEATURES = (
    "independent_log_min_margin",
    "independent_log_max_margin",
    "independent_log_mean_margin",
    "independent_log_swap_residual",
    "independent_swap_ratio",
    "joint_log_min_margin",
    "joint_log_max_margin",
    "joint_log_mean_margin",
    "joint_log_swap_residual",
    "joint_swap_ratio",
    "joint_minus_independent_log_min_margin",
    "joint_minus_independent_log_mean_margin",
    "independent_minus_joint_swap_ratio",
    "sign_disagreement_fraction",
    "normalized_score_alignment",
    "joint_to_independent_log_scale_ratio",
)


def _pair_features(
    independent_scores: Sequence[float], joint_scores: Sequence[float]
) -> Tuple[float, ...]:
    if len(independent_scores) != 2 or len(joint_scores) != 2:
        raise ValueError("M52m selector features require a complete swap pair")
    independent = np.asarray(independent_scores, dtype=np.float64)
    joint = np.asarray(joint_scores, dtype=np.float64)

    def geometry(values: np.ndarray) -> tuple[float, float, float, float, float]:
        absolute = np.abs(values)
        minimum = float(absolute.min())
        maximum = float(absolute.max())
        mean = float(absolute.mean())
        residual = float(abs(values.sum()))
        ratio = residual / max(float(absolute.sum()), 1e-8)
        return (
            math.log1p(minimum),
            math.log1p(maximum),
            math.log1p(mean),
            math.log1p(residual),
            ratio,
        )

    independent_geometry = geometry(independent)
    joint_geometry = geometry(joint)
    sign_disagreement = float(
        np.mean(np.signbit(independent) != np.signbit(joint))
    )
    denominator = max(
        float(np.linalg.norm(independent) * np.linalg.norm(joint)), 1e-8
    )
    alignment = float(np.dot(independent, joint) / denominator)
    scale_ratio = math.log(
        (float(np.abs(joint).mean()) + 1e-8)
        / (float(np.abs(independent).mean()) + 1e-8)
    )
    return (
        *independent_geometry,
        *joint_geometry,
        joint_geometry[0] - independent_geometry[0],
        joint_geometry[2] - independent_geometry[2],
        independent_geometry[4] - joint_geometry[4],
        sign_disagreement,
        alignment,
        scale_ratio,
    )


def selector_examples(
    independent_records: Sequence[Mapping[str, Any]],
    joint_records: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    independent = {str(row["record_id"]): row for row in independent_records}
    joint = {str(row["record_id"]): row for row in joint_records}
    if set(independent) != set(joint):
        raise ValueError("M52m selector controls must cover identical record ids")
    groups: dict[str, list[str]] = {}
    for record_id, row in independent.items():
        groups.setdefault(str(row["contrast_id"]), []).append(record_id)
    examples = []
    for contrast_id, record_ids in sorted(groups.items()):
        if len(record_ids) != 2:
            raise ValueError("M52m selector requires exact two-orientation contrasts")
        ordered = sorted(record_ids)
        independent_group = [independent[record_id] for record_id in ordered]
        joint_group = [joint[record_id] for record_id in ordered]
        independent_correct = all(bool(row["correct"]) for row in independent_group)
        joint_correct = all(bool(row["correct"]) for row in joint_group)
        first = independent_group[0]
        examples.append(
            {
                "contrast_id": contrast_id,
                "semantic_group_id": first["semantic_group_id"],
                "family": first["family"],
                "variant": first["variant"],
                "record_ids": ordered,
                "features": list(
                    _pair_features(
                        [float(row["score"]) for row in independent_group],
                        [float(row["score"]) for row in joint_group],
                    )
                ),
                "label_adopt_joint": bool(joint_correct and not independent_correct),
                "independent_correct": independent_correct,
                "joint_correct": joint_correct,
            }
        )
    return tuple(examples)


def fit_logistic_selector(
    examples: Sequence[Mapping[str, Any]],
    *,
    l2: float,
    positive_weight: float,
    steps: int = 2000,
    learning_rate: float = 0.05,
) -> Mapping[str, Any]:
    if not examples:
        raise ValueError("M52m selector training requires examples")
    x = np.asarray([row["features"] for row in examples], dtype=np.float64)
    y = np.asarray(
        [float(bool(row["label_adopt_joint"])) for row in examples],
        dtype=np.float64,
    )
    mean = x.mean(axis=0)
    scale = x.std(axis=0)
    scale = np.where(scale < 1e-8, 1.0, scale)
    normalized = (x - mean) / scale
    design = np.column_stack((np.ones(len(normalized)), normalized))
    weights = np.zeros(design.shape[1], dtype=np.float64)
    sample_weights = np.where(y > 0.5, float(positive_weight), 1.0)
    for _ in range(int(steps)):
        logits = np.clip(design @ weights, -30.0, 30.0)
        probabilities = 1.0 / (1.0 + np.exp(-logits))
        gradient = design.T @ (sample_weights * (probabilities - y))
        gradient /= max(float(sample_weights.sum()), 1.0)
        gradient[1:] += float(l2) * weights[1:]
        weights -= float(learning_rate) * gradient
    return {
        "feature_names": list(M52M_SELECTOR_FEATURES),
        "mean": mean.tolist(),
        "scale": scale.tolist(),
        "weights": weights.tolist(),
        "l2": float(l2),
        "positive_weight": float(positive_weight),
        "steps": int(steps),
        "learning_rate": float(learning_rate),
    }


def selector_probabilities(
    model: Mapping[str, Any], examples: Sequence[Mapping[str, Any]]
) -> Tuple[float, ...]:
    if list(model["feature_names"]) != list(M52M_SELECTOR_FEATURES):
        raise ValueError("M52m selector feature schema changed")
    x = np.asarray([row["features"] for row in examples], dtype=np.float64)
    mean = np.asarray(model["mean"], dtype=np.float64)
    scale = np.asarray(model["scale"], dtype=np.float64)
    weights = np.asarray(model["weights"], dtype=np.float64)
    design = np.column_stack((np.ones(len(x)), (x - mean) / scale))
    logits = np.clip(design @ weights, -30.0, 30.0)
    return tuple(float(value) for value in 1.0 / (1.0 + np.exp(-logits)))


def hybrid_records(
    independent_records: Sequence[Mapping[str, Any]],
    joint_records: Sequence[Mapping[str, Any]],
    adopted_contrasts: Sequence[str],
) -> Tuple[Mapping[str, Any], ...]:
    adopted = {str(value) for value in adopted_contrasts}
    independent = {str(row["record_id"]): row for row in independent_records}
    joint = {str(row["record_id"]): row for row in joint_records}
    if set(independent) != set(joint):
        raise ValueError("M52m hybrid controls must cover identical record ids")
    return tuple(
        dict(joint[record_id] if row["contrast_id"] in adopted else row)
        for record_id, row in sorted(independent.items())
    )


def selector_outcomes(
    examples: Sequence[Mapping[str, Any]], probabilities: Sequence[float], threshold: float
) -> Mapping[str, Any]:
    if len(examples) != len(probabilities):
        raise ValueError("M52m selector probabilities must align")
    adopted = [
        row
        for row, probability in zip(examples, probabilities)
        if float(probability) >= float(threshold)
    ]
    beneficial = sum(
        bool(row["joint_correct"]) and not bool(row["independent_correct"])
        for row in adopted
    )
    harmful = sum(
        bool(row["independent_correct"]) and not bool(row["joint_correct"])
        for row in adopted
    )
    recoverable = sum(bool(row["label_adopt_joint"]) for row in examples)
    informative = beneficial + harmful
    return {
        "contrast_count": len(examples),
        "intervention_count": len(adopted),
        "beneficial_interventions": beneficial,
        "harmful_interventions": harmful,
        "neutral_interventions": len(adopted) - informative,
        "recoverable_contrasts": recoverable,
        "recoverable_recall": beneficial / max(recoverable, 1),
        "informative_precision": beneficial / max(informative, 1),
        "adopted_contrasts": sorted(str(row["contrast_id"]) for row in adopted),
    }


def complement_dossier(
    independent_records: Sequence[Mapping[str, Any]],
    joint_records: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    independent = {str(row["record_id"]): row for row in independent_records}
    joint = {str(row["record_id"]): row for row in joint_records}
    if set(independent) != set(joint):
        raise ValueError("M52m controls must cover identical record ids")
    groups: dict[str, list[str]] = {}
    for record_id, row in independent.items():
        groups.setdefault(str(row["contrast_id"]), []).append(record_id)
    contrasts = []
    oracle_records = []
    for contrast_id, record_ids in sorted(groups.items()):
        if len(record_ids) != 2:
            raise ValueError("M52m requires exact two-orientation contrasts")
        independent_group = [independent[record_id] for record_id in record_ids]
        joint_group = [joint[record_id] for record_id in record_ids]
        independent_correct = all(bool(row["correct"]) for row in independent_group)
        joint_correct = all(bool(row["correct"]) for row in joint_group)
        if independent_correct and joint_correct:
            status = "both_correct"
            chosen = independent_group
        elif independent_correct:
            status = "independent_only"
            chosen = independent_group
        elif joint_correct:
            status = "joint_only_recoverable"
            chosen = joint_group
        else:
            status = "neither_correct"
            chosen = independent_group
        oracle_records.extend(chosen)
        first = independent_group[0]
        contrasts.append(
            {
                "contrast_id": contrast_id,
                "semantic_group_id": first["semantic_group_id"],
                "family": first["family"],
                "variant": first["variant"],
                "status": status,
                "independent_correct": independent_correct,
                "joint_correct": joint_correct,
                "record_ids": sorted(record_ids),
            }
        )
    statuses = (
        "both_correct",
        "independent_only",
        "joint_only_recoverable",
        "neither_correct",
    )

    def counts(selected: Sequence[Mapping[str, Any]]) -> Mapping[str, int]:
        return {
            status: sum(row["status"] == status for row in selected)
            for status in statuses
        }

    by_family = {
        family: counts([row for row in contrasts if row["family"] == family])
        for family in sorted({str(row["family"]) for row in contrasts})
    }
    by_variant = {
        variant: counts([row for row in contrasts if row["variant"] == variant])
        for variant in sorted({str(row["variant"]) for row in contrasts})
    }
    return {
        "contrast_count": len(contrasts),
        "status_counts": counts(contrasts),
        "by_family": by_family,
        "by_variant": by_variant,
        "recoverable_families": sorted(
            family
            for family, family_counts in by_family.items()
            if family_counts["joint_only_recoverable"] > 0
        ),
        "recoverable_variants": sorted(
            variant
            for variant, variant_counts in by_variant.items()
            if variant_counts["joint_only_recoverable"] > 0
        ),
        "independent_metrics": comparator_metrics(independent_records),
        "joint_metrics": comparator_metrics(joint_records),
        "oracle_metrics": comparator_metrics(oracle_records),
        "contrasts": contrasts,
        "oracle_records": oracle_records,
    }


def oracle_authorization_passed(
    dossier: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    statuses = dossier["status_counts"]
    checks = {
        "minimum_oracle_balanced_accuracy": dossier["oracle_metrics"][
            "balanced_accuracy"
        ]
        >= contract["minimum_oracle_balanced_accuracy"],
        "minimum_oracle_swap_pair_accuracy": dossier["oracle_metrics"][
            "swap_pair_accuracy"
        ]
        >= contract["minimum_oracle_swap_pair_accuracy"],
        "minimum_recoverable_contrasts": statuses["joint_only_recoverable"]
        >= contract["minimum_recoverable_contrasts"],
        "maximum_unavoidable_contrasts": statuses["neither_correct"]
        <= contract["maximum_unavoidable_contrasts"],
        "minimum_recoverable_families": len(dossier["recoverable_families"])
        >= contract["minimum_recoverable_families"],
        "minimum_recoverable_variants": len(dossier["recoverable_variants"])
        >= contract["minimum_recoverable_variants"],
    }
    return all(checks.values()), checks


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52m artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode()).hexdigest()


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    m52l_run = project / "runs/cognitive_core/joint_relational_comparator_v52l"
    m52l_data = project / "data/cognitive_core/joint_relational_comparator_v52l"
    m52l_audit = json.loads((m52l_run / "local-audit.json").read_text())
    m52l_freeze = json.loads((m52l_data / "benchmark-freeze.json").read_text())
    checkpoint = (
        m52l_run
        / "internal_adapter"
        / f"{M52M_JOINT_CHECKPOINT_ITERATION:07d}_adapters.safetensors"
    )
    return {
        "version": CONSERVATIVE_RESIDUAL_SELECTOR_VERSION,
        "parent_version": "general-cognitive-joint-relational-comparator-v52l",
        "scientific_question": (
            "Do the frozen independent scorer and the symmetry-repaired joint comparator "
            "make sufficiently complementary errors to justify learning a conservative "
            "selector rather than replacing the independent evidence path?"
        ),
        "seed": M52M_SEED,
        "source_contract": {
            "m52l_audit_id": m52l_audit["audit_id"],
            "development_rows": (
                "data/cognitive_core/joint_relational_comparator_v52l/development.jsonl"
            ),
            "development_rows_sha256": m52l_freeze["hashes"]["development"],
            "independent_records": (
                "runs/cognitive_core/joint_relational_comparator_v52l/"
                "development-records.json:independent_pair_midpoint"
            ),
            "joint_checkpoint_iteration": M52M_JOINT_CHECKPOINT_ITERATION,
            "joint_checkpoint_sha256": _sha256(checkpoint),
        },
        "oracle_contract": {
            "unit": "two-orientation contrast; a control is correct only if both swaps are correct",
            "oracle": (
                "use independent when correct; otherwise use joint only when the complete "
                "joint swap pair is correct"
            ),
            "minimum_oracle_balanced_accuracy": 0.90,
            "minimum_oracle_swap_pair_accuracy": 0.90,
            "minimum_recoverable_contrasts": 3,
            "maximum_unavoidable_contrasts": 3,
            "minimum_recoverable_families": 2,
            "minimum_recoverable_variants": 2,
        },
        "conditional_selector_contract": {
            "authorized_only_if_every_oracle_gate_passes": True,
            "frozen_independent_path": True,
            "allowed_action": "keep independent or adopt joint for a complete swap pair",
            "training_partitions": ["M52l train"],
            "selection_partition": "M52l development",
            "validation_partition": "unopened M52l validation",
            "no_harm_floor": (
                "selector may not reduce canonical, per-family, or overall performance "
                "relative to the independent control"
            ),
        },
        "staged_access": {
            "m52l_validation_opened_only_after_selector_passes_development": True,
            "m52l_confirmation_remains_sealed_until_validation_passes": True,
        },
        "claim_boundary": (
            "M52m-a measures error complement on already-exposed synthetic development "
            "families. Oracle success would authorize, but would not validate, a deployable "
            "residual selector. It does not establish semantic generalization, single-candidate "
            "applicability, autonomous invention, or general reasoning parity."
        ),
    }


def verify_m52m_protocol(output: Path, project: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "protocol-freeze.json").read_text())
    protocol = _protocol_payload(project)
    source = freeze["source_contract"]
    development = project / source["development_rows"]
    checkpoint = (
        project
        / "runs/cognitive_core/joint_relational_comparator_v52l/internal_adapter"
        / f"{int(source['joint_checkpoint_iteration']):07d}_adapters.safetensors"
    )
    checks = {
        "protocol_id_content_derived": content_digest(protocol)
        == freeze["protocol_freeze_id"],
        "freeze_id_content_derived": content_digest(
            {key: value for key, value in freeze.items() if key != "freeze_id"}
        )
        == freeze["freeze_id"],
        "m52l_audit_matches": source["m52l_audit_id"]
        == M52M_M52L_AUDIT_ID,
        "development_rows_match": _sha256(development)
        == source["development_rows_sha256"],
        "joint_checkpoint_identity_matches": int(
            source["joint_checkpoint_iteration"]
        )
        == M52M_JOINT_CHECKPOINT_ITERATION
        and _sha256(checkpoint)
        == source["joint_checkpoint_sha256"]
        == M52M_JOINT_CHECKPOINT_SHA256,
        "m52l_validation_is_still_unopened": not (
            project
            / "runs/cognitive_core/joint_relational_comparator_v52l/validation-result.json"
        ).exists(),
        "m52l_confirmation_is_still_unopened": not (
            project
            / "runs/cognitive_core/joint_relational_comparator_v52l/confirmation-result.json"
        ).exists(),
    }
    result = {
        "freeze_id": freeze["freeze_id"],
        "protocol_freeze_id": freeze["protocol_freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }
    (output / "protocol-verification.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    return result


def prepare_m52m_protocol(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol = _protocol_payload(project)
    freeze_payload = {**protocol, "protocol_freeze_id": content_digest(protocol)}
    freeze = {**freeze_payload, "freeze_id": content_digest(freeze_payload)}
    _write_immutable(
        output / "protocol-freeze.json",
        json.dumps(freeze, indent=2, sort_keys=True) + "\n",
    )
    return verify_m52m_protocol(output, project)
