from __future__ import annotations

import hashlib
import itertools
import json
import random
import time
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.experiment_invention_v41 import (
    EXPERIMENT_INVENTION_VERSION,
    ExperimentTask,
    _available_inputs,
    _canonical,
    _candidate_predictions,
    _program_text,
    build_m41_tasks,
    input_schema,
    oracle_experiment,
    parse_experiment,
    partition_metrics,
    random_experiment,
    score_experiment,
    search_experiment,
)
from scientist.domains.cognitive_core.internal_core_v28 import _batch_responses, _chat_prompt


CONTRAST_EXPERIMENT_VERSION = "general-cognitive-contrast-experiment-v42"
M42_REPRESENTATIONS = ("predicate", "causal", "program", "planning")
M42_TRAIN_REPRESENTATIONS = ("predicate", "causal")
M42_HELDOUT_REPRESENTATIONS = ("program", "planning")
M42_PER_REPRESENTATION = {"train": 60, "valid": 12, "test": 30}
M42_SEARCH_BUDGET = 8
MIN_EXCLUSIVE_FRACTION = 0.10


@dataclass(frozen=True)
class ContrastPair:
    pair_id: str
    representation: str
    left: ExperimentTask
    right: ExperimentTask
    left_target: Any
    right_target: Any
    minimum_exclusive_fraction: float
    diagnostic_jaccard_distance: float


def _correct_candidate(task: ExperimentTask) -> Any | None:
    key = f"{task.source.target_node}={json.dumps(task.source.correct_edit_value, sort_keys=True)}"
    return next((candidate for candidate in task.frontier if candidate.key == key), None)


def _diagnostic_keys(task: ExperimentTask) -> frozenset[str]:
    return frozenset(
        _canonical(value)
        for value in _available_inputs(task)
        if len(set(_candidate_predictions(task, value))) > 1
    )


def _ordered_frontier(
    correct: Any, distractor: Any, *, pair_id: str, member: str
) -> Tuple[Any, Any]:
    digest = hashlib.sha256(f"{pair_id}:{member}:order".encode("utf-8")).digest()
    return (correct, distractor) if digest[0] % 2 == 0 else (distractor, correct)


def _member_task(
    base: ExperimentTask,
    correct: Any,
    distractor: Any,
    *,
    pair_id: str,
    member: str,
) -> ExperimentTask:
    return replace(
        base,
        task_id=f"{pair_id}-{member}",
        frontier=_ordered_frontier(correct, distractor, pair_id=pair_id, member=member),
    )


def _specific_experiment(
    own: ExperimentTask, sibling: ExperimentTask, *, salt: str
) -> Any:
    candidates = []
    fallback = []
    for value in _available_inputs(own):
        own_info = partition_metrics(own, value)["normalized_information_gain"]
        sibling_info = partition_metrics(sibling, value)["normalized_information_gain"]
        score = (own_info - sibling_info, own_info, -sibling_info)
        fallback.append((score, _canonical(value), value))
        if own_info > 0.0 and sibling_info == 0.0:
            candidates.append(value)
    if candidates:
        ordered = sorted(candidates, key=_canonical)
        index = int(hashlib.sha256(salt.encode("utf-8")).hexdigest()[:16], 16) % len(ordered)
        return ordered[index]
    return max(fallback, key=lambda item: (item[0], item[1]))[2]


def _best_contrast_pair(
    base: ExperimentTask,
    *,
    version: str = CONTRAST_EXPERIMENT_VERSION,
    pair_prefix: str = "m42-pair",
    minimum_exclusive_fraction: float = MIN_EXCLUSIVE_FRACTION,
) -> ContrastPair | None:
    correct = _correct_candidate(base)
    if correct is None:
        return None
    distractors = sorted(
        (candidate for candidate in base.frontier if candidate.key != correct.key),
        key=lambda candidate: candidate.key,
    )
    diagnostic_sets = []
    for distractor in distractors:
        provisional = replace(base, frontier=(correct, distractor))
        diagnostic = _diagnostic_keys(provisional)
        if diagnostic:
            diagnostic_sets.append((distractor, diagnostic))
    options = []
    for (left, left_set), (right, right_set) in itertools.combinations(diagnostic_sets, 2):
        left_only = left_set - right_set
        right_only = right_set - left_set
        if not left_only or not right_only:
            continue
        minimum_exclusive = min(
            len(left_only) / len(left_set), len(right_only) / len(right_set)
        )
        union = left_set | right_set
        jaccard_distance = 1.0 - len(left_set & right_set) / len(union)
        score = (
            minimum_exclusive,
            jaccard_distance,
            len(left_only) + len(right_only),
            -len(left_set & right_set),
            left.key,
            right.key,
        )
        options.append((score, left, right))
    if not options:
        return None
    score, left_distractor, right_distractor = max(options, key=lambda item: item[0])
    if score[0] < minimum_exclusive_fraction:
        return None
    pair_id = pair_prefix + "-" + content_digest(
        {
            "base_task_id": base.task_id,
            "left": left_distractor.key,
            "right": right_distractor.key,
            "version": version,
        }
    )[:20]
    left = _member_task(
        base, correct, left_distractor, pair_id=pair_id, member="left"
    )
    right = _member_task(
        base, correct, right_distractor, pair_id=pair_id, member="right"
    )
    return ContrastPair(
        pair_id=pair_id,
        representation=base.representation,
        left=left,
        right=right,
        left_target=_specific_experiment(left, right, salt=f"{pair_id}:left"),
        right_target=_specific_experiment(right, left, salt=f"{pair_id}:right"),
        minimum_exclusive_fraction=float(score[0]),
        diagnostic_jaccard_distance=float(score[1]),
    )


def build_m42_pairs(
    split: str,
    per_representation: int | None = None,
    representations: Sequence[str] | None = None,
) -> Tuple[ContrastPair, ...]:
    if split not in M42_PER_REPRESENTATION:
        raise ValueError("unknown M42 split")
    if per_representation is None:
        per_representation = M42_PER_REPRESENTATION[split]
    if representations is None:
        representations = (
            M42_TRAIN_REPRESENTATIONS if split != "test" else M42_REPRESENTATIONS
        )
    bases = build_m41_tasks(split, per_representation, representations)
    return tuple(
        pair
        for base in bases
        for pair in (_best_contrast_pair(base),)
        if pair is not None
    )


def pair_members(pairs: Sequence[ContrastPair]) -> Tuple[ExperimentTask, ...]:
    return tuple(task for pair in pairs for task in (pair.left, pair.right))


def contrast_prompt(
    task: ExperimentTask,
    *,
    dossier: bool = True,
    dossier_task: ExperimentTask | None = None,
) -> str:
    observed = {_canonical(value) for value in task.observed_inputs}
    lines = [
        f"Representation: {task.representation}",
        f"Valid experiment input: {input_schema(task.representation)}.",
        "Invent one new input that makes the two unresolved executable mechanisms disagree.",
        "Derive the input from the exact mechanisms, not from a representation-typical default.",
        "The input must not repeat an observed input. Do not explain your answer.",
        "Observed inputs: " + json.dumps(sorted(observed)),
    ]
    if dossier:
        visible = dossier_task or task
        lines.append("Unresolved executable candidate mechanisms:")
        for index, intervention in enumerate(visible.frontier, 1):
            lines.append(f"  c{index}: {_program_text(intervention.program)}")
    lines.append("Return exactly: EXPERIMENT: <JSON list>")
    return "\n".join(lines)


def _pair_for_task(
    pairs: Sequence[ContrastPair], task_id: str
) -> Tuple[ContrastPair, ExperimentTask, ExperimentTask]:
    for pair in pairs:
        if task_id == pair.left.task_id:
            return pair, pair.left, pair.right
        if task_id == pair.right.task_id:
            return pair, pair.right, pair.left
    raise KeyError(task_id)


def _contrast_search(
    own: ExperimentTask,
    sibling: ExperimentTask,
    *,
    budget: int | None,
    salt: str,
) -> Any:
    values = list(_available_inputs(own))
    rng = random.Random(
        int(hashlib.sha256(salt.encode("utf-8")).hexdigest()[:16], 16)
    )
    rng.shuffle(values)
    if budget is not None:
        values = values[:budget]

    def key(value: Any) -> Tuple[float, float, float, str]:
        own_metrics = partition_metrics(own, value)
        sibling_metrics = partition_metrics(sibling, value)
        return (
            own_metrics["normalized_information_gain"]
            - sibling_metrics["normalized_information_gain"],
            own_metrics["normalized_information_gain"],
            -sibling_metrics["normalized_information_gain"],
            _canonical(value),
        )

    return max(values, key=key)


def contrast_search_experiment(
    own: ExperimentTask,
    sibling: ExperimentTask,
    budget: int = M42_SEARCH_BUDGET,
) -> Any:
    return _contrast_search(
        own,
        sibling,
        budget=budget,
        salt=f"m42-contrast-search:{own.task_id}",
    )


def contrast_oracle_experiment(own: ExperimentTask, sibling: ExperimentTask) -> Any:
    return _contrast_search(
        own,
        sibling,
        budget=None,
        salt=f"m42-contrast-oracle:{own.task_id}",
    )


def aggregate_contrasts(
    condition: str,
    pairs: Sequence[ContrastPair],
    values: Sequence[Any | None],
    responses: Sequence[str] | None = None,
) -> Mapping[str, Any]:
    tasks = pair_members(pairs)
    if len(tasks) != len(values):
        raise ValueError("tasks and values do not align")
    if responses is None:
        responses = ("",) * len(tasks)
    records = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    pair_rows = []
    for pair_index, pair in enumerate(pairs):
        pair_scores = []
        pair_values = []
        for offset, (member, sibling, label) in enumerate(
            ((pair.left, pair.right, "left"), (pair.right, pair.left, "right"))
        ):
            index = pair_index * 2 + offset
            value = values[index]
            own_score = score_experiment(member, value)
            sibling_score = score_experiment(sibling, value)
            contrast = {
                "own_normalized_information_gain": own_score[
                    "normalized_information_gain"
                ],
                "sibling_normalized_information_gain": sibling_score[
                    "normalized_information_gain"
                ],
                "own_minus_sibling_information_gain": own_score[
                    "normalized_information_gain"
                ]
                - sibling_score["normalized_information_gain"],
                "specific_probe": bool(
                    own_score["positive_information_gain"]
                    and not sibling_score["positive_information_gain"]
                ),
            }
            record = {
                "pair_id": pair.pair_id,
                "member": label,
                "task_id": member.task_id,
                "sibling_task_id": sibling.task_id,
                "representation": member.representation,
                "experiment": value,
                "response": responses[index],
                "assessment": own_score,
                "contrast": contrast,
            }
            records.append(record)
            pair_scores.append(contrast)
            pair_values.append(value)
            by_representation.setdefault(member.representation, []).append(record)
        advantage = sum(
            float(row["own_minus_sibling_information_gain"]) for row in pair_scores
        ) / 2.0
        differentiated = (
            pair_values[0] is not None
            and pair_values[1] is not None
            and _canonical(pair_values[0]) != _canonical(pair_values[1])
        )
        pair_rows.append(
            {
                "pair_id": pair.pair_id,
                "representation": pair.representation,
                "assignment_advantage": advantage,
                "correct_assignment": advantage > 0.0,
                "differentiated": differentiated,
            }
        )

    def summarize(
        item_records: Sequence[Mapping[str, Any]],
        items_pairs: Sequence[Mapping[str, Any]],
    ) -> Mapping[str, float]:
        if not item_records or not items_pairs:
            return {
                "valid_experiment_rate": 0.0,
                "novel_experiment_rate": 0.0,
                "positive_information_gain_rate": 0.0,
                "mean_normalized_information_gain": 0.0,
                "specific_probe_rate": 0.0,
                "mean_own_minus_sibling_information_gain": 0.0,
                "pair_differentiation_rate": 0.0,
                "correct_assignment_rate": 0.0,
                "mean_assignment_advantage": 0.0,
            }

        def mean_record(path: Tuple[str, str]) -> float:
            return sum(float(item[path[0]][path[1]]) for item in item_records) / len(
                item_records
            )

        def mean_pair(key: str) -> float:
            return sum(float(item[key]) for item in items_pairs) / len(items_pairs)

        return {
            "valid_experiment_rate": mean_record(("assessment", "valid")),
            "novel_experiment_rate": mean_record(("assessment", "novel")),
            "positive_information_gain_rate": mean_record(
                ("assessment", "positive_information_gain")
            ),
            "mean_normalized_information_gain": mean_record(
                ("assessment", "normalized_information_gain")
            ),
            "specific_probe_rate": mean_record(("contrast", "specific_probe")),
            "mean_own_minus_sibling_information_gain": mean_record(
                ("contrast", "own_minus_sibling_information_gain")
            ),
            "pair_differentiation_rate": mean_pair("differentiated"),
            "correct_assignment_rate": mean_pair("correct_assignment"),
            "mean_assignment_advantage": mean_pair("assignment_advantage"),
        }

    heldout_records = [
        record
        for record in records
        if record["representation"] in M42_HELDOUT_REPRESENTATIONS
    ]
    heldout_pairs = [
        row for row in pair_rows if row["representation"] in M42_HELDOUT_REPRESENTATIONS
    ]
    by_representation_metrics = {}
    for representation, item_records in sorted(by_representation.items()):
        item_pairs = [
            row for row in pair_rows if row["representation"] == representation
        ]
        by_representation_metrics[representation] = summarize(item_records, item_pairs)
    return {
        "metrics": {
            "condition": condition,
            "task_count": len(tasks),
            "pair_count": len(pairs),
            **summarize(records, pair_rows),
            "heldout": summarize(heldout_records, heldout_pairs),
            "by_representation": by_representation_metrics,
        },
        "records": records,
        "pair_records": pair_rows,
    }


def contrast_training_record(
    pair: ContrastPair, task: ExperimentTask, target: Any
) -> Mapping[str, Any]:
    return {
        "messages": [
            {"role": "user", "content": contrast_prompt(task, dossier=True)},
            {"role": "assistant", "content": "EXPERIMENT: " + json.dumps(target)},
        ],
        "metadata": {
            "pair_id": pair.pair_id,
            "task_id": task.task_id,
            "representation": task.representation,
            "mode": "paired_contrast_necessity",
        },
    }


def _training_records(pairs: Sequence[ContrastPair]) -> Iterable[Mapping[str, Any]]:
    for pair in pairs:
        yield contrast_training_record(pair, pair.left, pair.left_target)
        yield contrast_training_record(pair, pair.right, pair.right_target)


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def prepare_m42_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    data = output / "contrast"
    data.mkdir(parents=True, exist_ok=True)
    train = build_m42_pairs("train")
    valid = build_m42_pairs("valid")
    test = build_m42_pairs("test")
    train_hash, train_records = _write_jsonl(data / "train.jsonl", _training_records(train))
    valid_hash, valid_records = _write_jsonl(data / "valid.jsonl", _training_records(valid))
    public_hash, _ = _write_jsonl(
        output / "test-public.jsonl",
        (
            {
                "pair_id": pair.pair_id,
                "representation": pair.representation,
                "left_task_id": pair.left.task_id,
                "right_task_id": pair.right.task_id,
                "left_prompt_hash": hashlib.sha256(
                    contrast_prompt(pair.left, dossier=True).encode("utf-8")
                ).hexdigest(),
                "right_prompt_hash": hashlib.sha256(
                    contrast_prompt(pair.right, dossier=True).encode("utf-8")
                ).hexdigest(),
                "blind_prompt_identical": contrast_prompt(pair.left, dossier=False)
                == contrast_prompt(pair.right, dossier=False),
                "minimum_exclusive_fraction": pair.minimum_exclusive_fraction,
                "diagnostic_jaccard_distance": pair.diagnostic_jaccard_distance,
            }
            for pair in test
        ),
    )
    authority_hash, _ = _write_jsonl(
        output / "test-authority.jsonl",
        (
            {
                "pair_id": pair.pair_id,
                "left_target": pair.left_target,
                "right_target": pair.right_target,
                "authority_program": dict(pair.left.source.authority),
            }
            for pair in test
        ),
    )
    representation_counts = {
        split: {
            representation: sum(
                int(pair.representation == representation) for pair in pairs
            )
            for representation in M42_REPRESENTATIONS
        }
        for split, pairs in (("train", train), ("valid", valid), ("test", test))
    }
    payload = {
        "version": CONTRAST_EXPERIMENT_VERSION,
        "parent_version": EXPERIMENT_INVENTION_VERSION,
        "representations": list(M42_REPRESENTATIONS),
        "training_representations": list(M42_TRAIN_REPRESENTATIONS),
        "heldout_representations": list(M42_HELDOUT_REPRESENTATIONS),
        "per_representation_source_count": M42_PER_REPRESENTATION,
        "minimum_exclusive_fraction": MIN_EXCLUSIVE_FRACTION,
        "search_budget": M42_SEARCH_BUDGET,
        "counts": {
            "train_pairs": len(train),
            "valid_pairs": len(valid),
            "test_pairs": len(test),
            "train_records": train_records,
            "valid_records": valid_records,
            "test_tasks": len(test) * 2,
            "by_representation": representation_counts,
        },
        "hashes": {
            "contrast_train": train_hash,
            "contrast_valid": valid_hash,
            "test_public": public_hash,
            "test_authority": authority_hash,
        },
        "training_recipe": {
            "objective": "paired_frontier_specific_experiment_generation",
            "lora_layers": 8,
            "iterations": 250,
            "learning_rate": 2e-5,
            "gradient_accumulation_steps": 4,
            "checkpoint_interval": 50,
            "max_sequence_length": 1024,
            "seed": 42,
            "checkpoint_selection": "minimum_validation_loss",
        },
        "feasibility_gates": {
            "minimum_contrast_oracle_information_gain": 0.98,
            "minimum_contrast_oracle_specific_probe_rate": 0.98,
            "minimum_contrast_oracle_assignment_advantage": 0.98,
            "minimum_blind_prompt_identity_rate": 1.0,
        },
        "model_gates": {
            "minimum_valid_experiment_rate": 0.95,
            "minimum_novel_experiment_rate": 0.90,
            "minimum_positive_information_gain_rate": 0.75,
            "minimum_normalized_information_gain": 0.75,
            "minimum_heldout_information_gain": 0.65,
            "minimum_specific_probe_rate": 0.50,
            "minimum_own_minus_sibling_information_gain": 0.30,
            "minimum_pair_differentiation_rate": 0.80,
            "minimum_correct_assignment_rate": 0.70,
            "minimum_gain_over_base_correct": 0.15,
            "minimum_gain_over_adapted_blind": 0.10,
            "minimum_gain_over_adapted_mismatched": 0.20,
            "minimum_specificity_gain_over_adapted_blind": 0.25,
            "minimum_information_ratio_to_contrast_search8": 0.85,
            "minimum_information_ratio_to_contrast_oracle": 0.75,
        },
        "claim_boundary": (
            "M42 tests whether one-shot experiment proposals change appropriately when only the unresolved "
            "candidate frontier changes. Paired tasks have identical representation, input schema, and "
            "observed inputs, but different binary candidate frontiers with frontier-specific diagnostic "
            "regions. Predicate and causal pairs train the adapter; program and planning pairs are held out. "
            "The finite synthetic input spaces remain externally searchable, so M42 does not establish "
            "open-ended experiment invention in natural scientific domains."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m42_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "contrast_train": output / "contrast/train.jsonl",
        "contrast_valid": output / "contrast/valid.jsonl",
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    train_text = paths["contrast_train"].read_text(encoding="utf-8")
    train_ids = {pair.pair_id for pair in build_m42_pairs("train")}
    valid_ids = {pair.pair_id for pair in build_m42_pairs("valid")}
    test_pairs = build_m42_pairs("test")
    test_ids = {pair.pair_id for pair in test_pairs}
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": content_digest(payload) == freeze["freeze_id"],
        "heldout_representations_absent_from_training": (
            '"representation": "program"' not in train_text
            and '"representation": "planning"' not in train_text
        ),
        "splits_are_disjoint": not (
            train_ids & valid_ids or train_ids & test_ids or valid_ids & test_ids
        ),
        "test_not_available_to_mlx": not (output / "contrast/test.jsonl").exists(),
        "paired_blind_prompts_are_identical": all(
            contrast_prompt(pair.left, dossier=False)
            == contrast_prompt(pair.right, dossier=False)
            for pair in test_pairs
        ),
        "paired_observations_are_identical": all(
            pair.left.observed_inputs == pair.right.observed_inputs for pair in test_pairs
        ),
        "paired_frontiers_are_different": all(
            {candidate.key for candidate in pair.left.frontier}
            != {candidate.key for candidate in pair.right.frontier}
            for pair in test_pairs
        ),
        "specific_targets_are_frontier_dependent": all(
            score_experiment(pair.left, pair.left_target)["positive_information_gain"]
            and not score_experiment(pair.right, pair.left_target)[
                "positive_information_gain"
            ]
            and score_experiment(pair.right, pair.right_target)[
                "positive_information_gain"
            ]
            and not score_experiment(pair.left, pair.right_target)[
                "positive_information_gain"
            ]
            for pair in test_pairs
        ),
        "gates_and_recipe_frozen": (
            "feasibility_gates" in freeze
            and "model_gates" in freeze
            and "training_recipe" in freeze
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}


def _control_values(
    pairs: Sequence[ContrastPair], condition: str
) -> Tuple[Any, ...]:
    values = []
    for pair in pairs:
        for own, sibling in ((pair.left, pair.right), (pair.right, pair.left)):
            if condition == "random":
                value = random_experiment(own)
            elif condition == "search8":
                value = search_experiment(own, M42_SEARCH_BUDGET)
            elif condition == "oracle":
                value = oracle_experiment(own)
            elif condition == "contrast_search8":
                value = contrast_search_experiment(own, sibling)
            elif condition == "contrast_oracle":
                value = contrast_oracle_experiment(own, sibling)
            else:
                raise ValueError(condition)
            values.append(value)
    return tuple(values)


def run_m42_baselines(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    pairs = build_m42_pairs("test")
    conditions = ("random", "search8", "oracle", "contrast_search8", "contrast_oracle")
    results = {
        condition: aggregate_contrasts(
            condition, pairs, _control_values(pairs, condition)
        )
        for condition in conditions
    }
    contrast_oracle = results["contrast_oracle"]["metrics"]
    blind_identity = sum(
        int(
            contrast_prompt(pair.left, dossier=False)
            == contrast_prompt(pair.right, dossier=False)
        )
        for pair in pairs
    ) / len(pairs)
    gates = freeze["feasibility_gates"]
    checks = {
        "contrast_oracle_information_gain": contrast_oracle[
            "mean_normalized_information_gain"
        ]
        >= gates["minimum_contrast_oracle_information_gain"],
        "contrast_oracle_specific_probe_rate": contrast_oracle["specific_probe_rate"]
        >= gates["minimum_contrast_oracle_specific_probe_rate"],
        "contrast_oracle_assignment_advantage": contrast_oracle[
            "mean_assignment_advantage"
        ]
        >= gates["minimum_contrast_oracle_assignment_advantage"],
        "blind_prompt_identity": blind_identity
        >= gates["minimum_blind_prompt_identity_rate"],
    }
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "contrast_experiment_baselines",
        {
            condition: {
                "records": result["records"],
                "pair_records": result["pair_records"],
            }
            for condition, result in results.items()
        },
    )
    payload = {
        "version": CONTRAST_EXPERIMENT_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "metrics": {condition: result["metrics"] for condition, result in results.items()},
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
        "predictions_digest": predictions_digest,
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"contrast-experiment-baselines-{manifest['evaluation_id']}", manifest)
    return manifest


def evaluate_contrast_model(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    condition: str,
    *,
    dossier_mode: str,
    adapter_path: Optional[Path] = None,
    batch_size: int = 8,
    max_tokens: int = 40,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if dossier_mode not in {"correct", "blind", "mismatched"}:
        raise ValueError("invalid dossier mode")
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    pairs = build_m42_pairs("test")
    tasks = pair_members(pairs)
    prompts = []
    for task in tasks:
        pair, own, sibling = _pair_for_task(pairs, task.task_id)
        del pair
        if dossier_mode == "blind":
            prompt = contrast_prompt(own, dossier=False)
        elif dossier_mode == "mismatched":
            prompt = contrast_prompt(own, dossier=True, dossier_task=sibling)
        else:
            prompt = contrast_prompt(own, dossier=True)
        prompts.append(prompt)
    started = time.monotonic()
    load_args: Dict[str, Any] = {"return_config": True}
    if adapter_path is not None:
        load_args["adapter_path"] = str(adapter_path)
    model, tokenizer, config = load(model_path, **load_args)
    chat_prompts = tuple(_chat_prompt(tokenizer, prompt) for prompt in prompts)
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        chat_prompts,
        batch_size=batch_size,
        max_tokens=max_tokens,
        max_batch_tokens=12000,
    )
    values = tuple(parse_experiment(response) for response in responses)
    aggregate = aggregate_contrasts(condition, pairs, values, responses)
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "contrast_experiment_model_predictions",
        {"records": aggregate["records"], "pair_records": aggregate["pair_records"]},
    )
    payload = {
        "version": CONTRAST_EXPERIMENT_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "condition": condition,
        "dossier_mode": dossier_mode,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path) if adapter_path else None,
        "adapter_config_sha256": hashlib.sha256(
            (adapter_path / "adapter_config.json").read_bytes()
        ).hexdigest()
        if adapter_path
        else None,
        "adapter_weights_sha256": hashlib.sha256(
            (adapter_path / "adapters.safetensors").read_bytes()
        ).hexdigest()
        if adapter_path
        else None,
        "metrics": aggregate["metrics"],
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "generation": {"batch_size": batch_size, "max_tokens": max_tokens},
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(
        f"contrast-experiment-model-{condition}-{manifest['evaluation_id']}", manifest
    )
    return manifest


def assess_m42(
    candidate: Mapping[str, Any],
    base_correct: Mapping[str, Any],
    adapted_blind: Mapping[str, Any],
    adapted_mismatched: Mapping[str, Any],
    baselines: Mapping[str, Any],
    benchmark_root: Path,
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["model_gates"]
    metrics = candidate["metrics"]
    base = base_correct["metrics"]
    blind = adapted_blind["metrics"]
    mismatch = adapted_mismatched["metrics"]
    random_metrics = baselines["metrics"]["random"]
    search = baselines["metrics"]["contrast_search8"]
    oracle = baselines["metrics"]["contrast_oracle"]
    info = metrics["mean_normalized_information_gain"]
    checks = {
        "feasibility_passed": baselines["passed"],
        "same_benchmark_freeze": all(
            evaluation["benchmark_freeze_id"] == freeze["freeze_id"]
            for evaluation in (
                candidate,
                base_correct,
                adapted_blind,
                adapted_mismatched,
                baselines,
            )
        ),
        "same_exact_model": (
            candidate["model_path"]
            == base_correct["model_path"]
            == adapted_blind["model_path"]
            == adapted_mismatched["model_path"]
        ),
        "adapter_present": candidate["adapter_path"] is not None,
        "valid_experiment_rate": metrics["valid_experiment_rate"]
        >= gates["minimum_valid_experiment_rate"],
        "novel_experiment_rate": metrics["novel_experiment_rate"]
        >= gates["minimum_novel_experiment_rate"],
        "positive_information_gain_rate": metrics["positive_information_gain_rate"]
        >= gates["minimum_positive_information_gain_rate"],
        "normalized_information_gain": info
        >= gates["minimum_normalized_information_gain"],
        "heldout_information_gain": metrics["heldout"][
            "mean_normalized_information_gain"
        ]
        >= gates["minimum_heldout_information_gain"],
        "specific_probe_rate": metrics["specific_probe_rate"]
        >= gates["minimum_specific_probe_rate"],
        "own_minus_sibling_information_gain": metrics[
            "mean_own_minus_sibling_information_gain"
        ]
        >= gates["minimum_own_minus_sibling_information_gain"],
        "pair_differentiation_rate": metrics["pair_differentiation_rate"]
        >= gates["minimum_pair_differentiation_rate"],
        "correct_assignment_rate": metrics["correct_assignment_rate"]
        >= gates["minimum_correct_assignment_rate"],
        "gain_over_base_correct": info - base["mean_normalized_information_gain"]
        >= gates["minimum_gain_over_base_correct"],
        "gain_over_adapted_blind": info - blind["mean_normalized_information_gain"]
        >= gates["minimum_gain_over_adapted_blind"],
        "gain_over_adapted_mismatched": info
        - mismatch["mean_normalized_information_gain"]
        >= gates["minimum_gain_over_adapted_mismatched"],
        "specificity_gain_over_adapted_blind": metrics[
            "mean_own_minus_sibling_information_gain"
        ]
        - blind["mean_own_minus_sibling_information_gain"]
        >= gates["minimum_specificity_gain_over_adapted_blind"],
        "ratio_to_contrast_search8": info / search["mean_normalized_information_gain"]
        >= gates["minimum_information_ratio_to_contrast_search8"],
        "ratio_to_contrast_oracle": info / oracle["mean_normalized_information_gain"]
        >= gates["minimum_information_ratio_to_contrast_oracle"],
        "gain_over_random": info > random_metrics["mean_normalized_information_gain"],
    }
    payload = {
        "version": CONTRAST_EXPERIMENT_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "candidate_evaluation_id": candidate["evaluation_id"],
        "base_correct_evaluation_id": base_correct["evaluation_id"],
        "adapted_blind_evaluation_id": adapted_blind["evaluation_id"],
        "adapted_mismatched_evaluation_id": adapted_mismatched["evaluation_id"],
        "baseline_evaluation_id": baselines["evaluation_id"],
        "metrics": metrics,
        "controls": {
            "base_correct": base,
            "adapted_blind": blind,
            "adapted_mismatched": mismatch,
            **baselines["metrics"],
        },
        "deltas": {
            "information_gain_over_base_correct": info
            - base["mean_normalized_information_gain"],
            "information_gain_over_adapted_blind": info
            - blind["mean_normalized_information_gain"],
            "information_gain_over_adapted_mismatched": info
            - mismatch["mean_normalized_information_gain"],
            "specificity_gain_over_adapted_blind": metrics[
                "mean_own_minus_sibling_information_gain"
            ]
            - blind["mean_own_minus_sibling_information_gain"],
            "information_gain_ratio_to_contrast_search8": info
            / search["mean_normalized_information_gain"],
            "information_gain_ratio_to_contrast_oracle": info
            / oracle["mean_normalized_information_gain"],
        },
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
    }
    return {**payload, "assessment_id": content_digest(payload)}
