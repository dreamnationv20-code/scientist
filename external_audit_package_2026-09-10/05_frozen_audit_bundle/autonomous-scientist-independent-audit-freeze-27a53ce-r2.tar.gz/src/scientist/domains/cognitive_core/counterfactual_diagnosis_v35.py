from __future__ import annotations

import hashlib
import json
import random
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
    LOCALIZATION_TRAIN_REPRESENTATIONS,
    REPRESENTATIONS,
    RepairTask,
    _build_task,
    execute,
)


COUNTERFACTUAL_DIAGNOSIS_VERSION = "general-cognitive-counterfactual-diagnosis-v35"
M35_SPLIT_SEEDS = {"train": 35023, "valid": 35051, "test": 35107}
MAX_ACTIVE_QUERIES = 3


@dataclass(frozen=True)
class Intervention:
    node: str
    value: Any
    program: Mapping[str, Any]
    fixes_counterexample: bool
    visible_preserved: int
    visible_count: int

    @property
    def viable(self) -> bool:
        return self.fixes_counterexample and self.visible_preserved == self.visible_count

    @property
    def key(self) -> str:
        return f"{self.node}={json.dumps(self.value, sort_keys=True)}"


@dataclass(frozen=True)
class DiagnosisDossier:
    task: RepairTask
    interventions: Tuple[Intervention, ...]
    active_queries: Tuple[Mapping[str, Any], ...]
    viable_keys: Tuple[str, ...]
    diagnostic_case_ids: Tuple[str, ...]
    final_cases: Tuple[Mapping[str, Any], ...]

    @property
    def prompt(self) -> str:
        nodes = "; ".join(
            f"{node}={json.dumps(value, sort_keys=True)}"
            for node, value in sorted(self.task.candidate.items())
        )
        correct = "\n".join(
            f"  input={json.dumps(case['input'])} -> required={json.dumps(case['expected'])}"
            for case in self.task.visible_correct
        )
        bad = self.task.counterexample
        lines = [
            f"Representation: {self.task.representation}",
            f"Candidate: {nodes}",
            "Known invariants:",
            correct,
            (
                f"Failing case: input={json.dumps(bad['input'])}; "
                f"candidate_output={json.dumps(bad['candidate'])}; required={json.dumps(bad['expected'])}"
            ),
            "Executable one-node interventions:",
        ]
        for intervention in self.interventions:
            active_matches = sum(
                int(
                    _prediction(self.task, intervention, query)
                    == json.dumps(query["expected"], sort_keys=True)
                )
                for query in self.active_queries
            )
            lines.append(
                f"  {intervention.key} | fixes_failure={str(intervention.fixes_counterexample).lower()} "
                f"| preserves={intervention.visible_preserved}/{intervention.visible_count} "
                f"| active_matches={active_matches}/{len(self.active_queries)}"
            )
        if self.active_queries:
            lines.append("Active diagnostic queries:")
            for query in self.active_queries:
                lines.append(
                    f"  input={json.dumps(query['input'])} -> observed_required={json.dumps(query['expected'])}"
                )
        lines.extend(
            (
                "Select the single most strongly supported minimal intervention. Do not regenerate the mechanism.",
                "Return exactly: SELECT: node=<node>; value=<JSON value>",
            )
        )
        return "\n".join(lines)

    def training_record(self) -> Mapping[str, Any]:
        return {
            "messages": [
                {"role": "user", "content": self.prompt},
                {
                    "role": "assistant",
                    "content": (
                        f"SELECT: node={self.task.target_node}; "
                        f"value={json.dumps(self.task.correct_edit_value, sort_keys=True)}"
                    ),
                },
            ],
            "metadata": {
                "task_id": self.task.task_id,
                "representation": self.task.representation,
                "mode": "counterfactual_selection",
                "active_query_count": len(self.active_queries),
            },
        }


def build_m35_suite(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[RepairTask, ...]:
    if split not in M35_SPLIT_SEEDS:
        raise ValueError("unknown M35 split")
    rng = random.Random(M35_SPLIT_SEEDS[split])
    tasks = tuple(
        _build_task(f"m35_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("M35 task ids are not unique")
    return tasks


def legal_values(task: RepairTask, node: str) -> Tuple[Any, ...]:
    domains: Mapping[str, Sequence[Any]] = {
        "n1_source": (0, 2),
        "n2_weight": (1, 2, 3, 4),
        "n3_modulus": (3, 4, 5, 6),
        "n1_memory": ("current", "previous", "cumulative"),
        "n2_coefficient": (1, 2, 3, 4),
        "n3_offset": (0, 1, 2, 3, 4),
        "n4_modulus": (5, 7, 8, 9),
        "n1_cause": (0, 1, 2),
        "n3_baseline": (0, 1, 2),
        "n4_sign": (-1, 1),
        "n1_variable": (0, 1, 2),
        "n2_multiplier": (1, 2, 3, 4),
        "n1_blocked_stage": (1, 2, 3),
        "n2_recovery_action": ("repair_alpha", "repair_beta", "repair_gamma"),
        "n3_advance_action": ("advance_alpha", "advance_beta"),
        "n4_terminal_action": ("audit", "release"),
    }
    if node == "n4_residue":
        values: Sequence[Any] = tuple(range(int(task.candidate["n3_modulus"])))
    else:
        values = domains[node]
    return tuple(value for value in values if value != task.candidate[node])


def enumerate_interventions(task: RepairTask) -> Tuple[Intervention, ...]:
    interventions = []
    bad = task.counterexample
    for node in sorted(task.candidate):
        for value in legal_values(task, node):
            program = dict(task.candidate)
            program[node] = value
            try:
                fixes = execute(task.representation, program, bad["input"]) == bad["expected"]
            except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
                fixes = False
            preserved = 0
            for case in task.visible_correct:
                try:
                    preserved += int(
                        execute(task.representation, program, case["input"]) == case["expected"]
                    )
                except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
                    pass
            interventions.append(
                Intervention(
                    node=node,
                    value=value,
                    program=program,
                    fixes_counterexample=fixes,
                    visible_preserved=preserved,
                    visible_count=len(task.visible_correct),
                )
            )
    return tuple(interventions)


def _prediction(task: RepairTask, intervention: Intervention, case: Mapping[str, Any]) -> str:
    try:
        value = execute(task.representation, intervention.program, case["input"])
    except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
        value = "execution_error"
    return json.dumps(value, sort_keys=True)


def build_dossier(task: RepairTask, max_active_queries: int = MAX_ACTIVE_QUERIES) -> DiagnosisDossier:
    interventions = enumerate_interventions(task)
    survivors = [intervention for intervention in interventions if intervention.viable]
    if not survivors:
        raise RuntimeError("the correct edit must survive public counterfactual checks")
    diagnostic_count = min(max_active_queries, max(0, len(task.hidden_cases) // 2))
    diagnostic_pool = list(task.hidden_cases[: max(diagnostic_count * 2, diagnostic_count)])
    used: list[Mapping[str, Any]] = []
    while len(survivors) > 1 and diagnostic_pool and len(used) < max_active_queries:
        ranked = []
        for index, case in enumerate(diagnostic_pool):
            predictions = {_prediction(task, intervention, case) for intervention in survivors}
            ranked.append((len(predictions), -index, index, case))
        diversity, _, index, case = max(ranked, key=lambda item: (item[0], item[1]))
        if diversity <= 1:
            break
        used.append(case)
        diagnostic_pool.pop(index)
        expected = json.dumps(case["expected"], sort_keys=True)
        survivors = [
            intervention
            for intervention in survivors
            if _prediction(task, intervention, case) == expected
        ]
    used_markers = {json.dumps(case["input"], sort_keys=True) for case in used}
    final_cases = tuple(
        case
        for case in task.hidden_cases
        if json.dumps(case["input"], sort_keys=True) not in used_markers
    )
    return DiagnosisDossier(
        task=task,
        interventions=interventions,
        active_queries=tuple({"input": case["input"], "expected": case["expected"]} for case in used),
        viable_keys=tuple(sorted(intervention.key for intervention in survivors)),
        diagnostic_case_ids=tuple(sorted(used_markers)),
        final_cases=final_cases,
    )


_SELECT_RE = re.compile(
    r"SELECT\s*:\s*node\s*=\s*([^;\s]+)\s*;\s*value\s*=\s*([^\n\r]+)", re.IGNORECASE
)


def parse_selection(response: str) -> Tuple[str, Any] | None:
    matches = _SELECT_RE.findall(response)
    if not matches:
        return None
    node, raw = matches[-1]
    raw = raw.strip().rstrip(".;")
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        value = raw.strip("`\"'")
    return node.strip(), value


def apply_selection(task: RepairTask, response: str) -> Mapping[str, Any] | None:
    parsed = parse_selection(response)
    if parsed is None:
        return None
    node, value = parsed
    if node not in task.candidate or value not in legal_values(task, node):
        return None
    program = dict(task.candidate)
    program[node] = value
    return program


def score_on_cases(
    task: RepairTask,
    program: Mapping[str, Any] | None,
    cases: Sequence[Mapping[str, Any]],
) -> float:
    if program is None or not cases:
        return 0.0
    correct = 0
    for case in cases:
        try:
            correct += int(execute(task.representation, program, case["input"]) == case["expected"])
        except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
            pass
    return correct / len(cases)


def oracle_selection(dossier: DiagnosisDossier) -> Intervention:
    viable = [
        intervention for intervention in dossier.interventions if intervention.key in set(dossier.viable_keys)
    ]
    if not viable:
        raise RuntimeError("active diagnosis eliminated every intervention")
    return min(viable, key=lambda intervention: intervention.key)


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def prepare_m35_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    train = tuple(
        build_dossier(task)
        for task in build_m35_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)
    )
    valid = tuple(
        build_dossier(task)
        for task in build_m35_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)
    )
    test = tuple(build_dossier(task) for task in build_m35_suite("test", 30))
    (output / "selection").mkdir(parents=True, exist_ok=True)
    hashes = {
        "selection_train": _write_jsonl(
            output / "selection/train.jsonl", (dossier.training_record() for dossier in train)
        ),
        "selection_valid": _write_jsonl(
            output / "selection/valid.jsonl", (dossier.training_record() for dossier in valid)
        ),
        "test_public": _write_jsonl(
            output / "test-public.jsonl",
            (
                {
                    "task_id": dossier.task.task_id,
                    "representation": dossier.task.representation,
                    "prompt": dossier.prompt,
                }
                for dossier in test
            ),
        ),
        "test_authority": _write_jsonl(
            output / "test-authority.jsonl",
            (
                {
                    "task_id": dossier.task.task_id,
                    "representation": dossier.task.representation,
                    "target_node": dossier.task.target_node,
                    "correct_edit_value": dossier.task.correct_edit_value,
                    "viable_keys": list(dossier.viable_keys),
                    "active_queries": list(dossier.active_queries),
                    "final_cases": list(dossier.final_cases),
                }
                for dossier in test
            ),
        ),
    }
    payload = {
        "version": COUNTERFACTUAL_DIAGNOSIS_VERSION,
        "split_seeds": M35_SPLIT_SEEDS,
        "representations": list(REPRESENTATIONS),
        "training_representations": list(LOCALIZATION_TRAIN_REPRESENTATIONS),
        "heldout_representations": list(HELDOUT_LOCALIZATION_REPRESENTATIONS),
        "counts": {"train": len(train), "valid": len(valid), "test": len(test)},
        "max_active_queries": MAX_ACTIVE_QUERIES,
        "hashes": hashes,
        "oracle_gates": {
            "minimum_semantic_accuracy": 0.95,
            "minimum_preserved_correct_accuracy": 1.0,
            "minimum_exact_rate": 0.80,
            "minimum_singleton_resolution_rate": 0.75,
            "maximum_mean_active_queries": 3.0,
        },
        "selector_gates": {
            "minimum_parse_coverage": 0.98,
            "minimum_semantic_accuracy": 0.80,
            "minimum_preserved_correct_accuracy": 0.95,
            "minimum_exact_rate": 0.55,
            "minimum_heldout_semantic_accuracy": 0.75,
        },
        "revision_gates": {
            "minimum_two_step_semantic_accuracy": 0.88,
            "minimum_gain": 0.05,
            "minimum_preserved_correct_accuracy": 0.97,
            "minimum_exact_rate": 0.70,
        },
        "claim_boundary": (
            "M35 is a fresh synthetic single-fault benchmark. Active queries reveal at most three "
            "environment outputs and are removed from final scoring."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m35_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "selection_train": output / "selection/train.jsonl",
        "selection_valid": output / "selection/valid.jsonl",
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    train_representations = {
        json.loads(line)["metadata"]["representation"]
        for line in (output / "selection/train.jsonl").read_text(encoding="utf-8").splitlines()
    }
    train_ids = {task.task_id for task in build_m35_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    valid_ids = {task.task_id for task in build_m35_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    test_ids = {task.task_id for task in build_m35_suite("test", 30)}
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "heldout_representations_absent_from_training": set(
            HELDOUT_LOCALIZATION_REPRESENTATIONS
        ).isdisjoint(train_representations),
        "splits_are_disjoint": not (train_ids & valid_ids or train_ids & test_ids or valid_ids & test_ids),
        "test_not_exposed_to_mlx": not (output / "selection/test.jsonl").exists(),
        "gates_frozen": all(
            name in freeze for name in ("oracle_gates", "selector_gates", "revision_gates")
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}
