from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    COUNTERFACTUAL_DIAGNOSIS_VERSION,
    DiagnosisDossier,
    build_dossier,
    build_m35_suite,
    oracle_selection,
    score_on_cases,
)


COUNTERFACTUAL_ORACLE_VERSION = "general-cognitive-counterfactual-oracle-v35"


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def evaluate_oracle_dossiers(dossiers: Sequence[DiagnosisDossier]) -> Mapping[str, Any]:
    records = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    for dossier in dossiers:
        task = dossier.task
        selected = oracle_selection(dossier)
        semantic = score_on_cases(task, selected.program, dossier.final_cases)
        preserved = score_on_cases(task, selected.program, task.visible_correct)
        assessment = {
            "semantic_accuracy": semantic,
            "preserved_correct_accuracy": preserved,
            "exact": dict(selected.program) == dict(task.authority),
            "singleton_resolution": len(dossier.viable_keys) == 1,
            "active_query_count": len(dossier.active_queries),
            "remaining_viable_count": len(dossier.viable_keys),
        }
        records.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "selected_edit": selected.key,
                "assessment": assessment,
            }
        )
        by_representation.setdefault(task.representation, []).append(assessment)

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        return {
            "semantic_accuracy": _mean([float(item["semantic_accuracy"]) for item in items]),
            "preserved_correct_accuracy": _mean(
                [float(item["preserved_correct_accuracy"]) for item in items]
            ),
            "exact_rate": _mean([float(bool(item["exact"])) for item in items]),
            "singleton_resolution_rate": _mean(
                [float(bool(item["singleton_resolution"])) for item in items]
            ),
            "mean_active_queries": _mean([float(item["active_query_count"]) for item in items]),
            "mean_remaining_viable": _mean([float(item["remaining_viable_count"]) for item in items]),
        }

    assessments = [record["assessment"] for record in records]
    return {
        "metrics": {
            "task_count": len(dossiers),
            **summarize(assessments),
            "by_representation": {
                representation: summarize(items)
                for representation, items in sorted(by_representation.items())
            },
        },
        "records": records,
    }


def run_oracle(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    dossiers = tuple(build_dossier(task) for task in build_m35_suite("test", 30))
    result = evaluate_oracle_dossiers(dossiers)
    metrics = result["metrics"]
    gates = freeze["oracle_gates"]
    checks = {
        "same_benchmark_version": freeze["version"] == COUNTERFACTUAL_DIAGNOSIS_VERSION,
        "semantic_accuracy": metrics["semantic_accuracy"] >= gates["minimum_semantic_accuracy"],
        "preserved_correct_accuracy": (
            metrics["preserved_correct_accuracy"] >= gates["minimum_preserved_correct_accuracy"]
        ),
        "exact_rate": metrics["exact_rate"] >= gates["minimum_exact_rate"],
        "singleton_resolution_rate": (
            metrics["singleton_resolution_rate"] >= gates["minimum_singleton_resolution_rate"]
        ),
        "active_query_budget": metrics["mean_active_queries"] <= gates["maximum_mean_active_queries"],
    }
    store = ArtifactStore(output_root)
    predictions_digest = store.put("counterfactual_oracle_predictions", result["records"])
    payload = {
        "version": COUNTERFACTUAL_ORACLE_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "metrics": metrics,
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
        "predictions_digest": predictions_digest,
        "claim_boundary": (
            "The oracle uses exhaustive typed interventions and up to three environment queries. "
            "It is an evidence-sufficiency test, not a learned cognitive capability."
        ),
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"counterfactual-oracle-{manifest['evaluation_id']}", manifest)
    return manifest
