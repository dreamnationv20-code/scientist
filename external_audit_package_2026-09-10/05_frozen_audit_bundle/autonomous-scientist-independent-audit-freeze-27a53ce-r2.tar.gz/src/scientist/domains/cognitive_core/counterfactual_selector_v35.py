from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    COUNTERFACTUAL_DIAGNOSIS_VERSION,
    DiagnosisDossier,
    apply_selection,
    build_dossier,
    build_m35_suite,
    parse_selection,
    score_on_cases,
)
from scientist.domains.cognitive_core.internal_core_v28 import _batch_responses, _chat_prompt
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
)


COUNTERFACTUAL_SELECTOR_VERSION = "general-cognitive-counterfactual-selector-v35"


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def aggregate_selector(
    condition: str,
    dossiers: Sequence[DiagnosisDossier],
    responses: Sequence[str],
    *,
    elapsed_seconds: float = 0.0,
    peak_memory_gb: float = 0.0,
) -> Mapping[str, Any]:
    if len(dossiers) != len(responses):
        raise ValueError("dossiers and responses do not align")
    records = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    for dossier, response in zip(dossiers, responses):
        task = dossier.task
        parsed = parse_selection(response)
        program = apply_selection(task, response)
        selected_key = (
            f"{parsed[0]}={json.dumps(parsed[1], sort_keys=True)}" if parsed is not None else ""
        )
        assessment = {
            "parsed": parsed is not None,
            "legal_selection": program is not None,
            "evidence_consistent": selected_key in set(dossier.viable_keys),
            "target_correct": parsed is not None and parsed[0] == task.target_node,
            "semantic_accuracy": score_on_cases(task, program, dossier.final_cases),
            "preserved_correct_accuracy": score_on_cases(task, program, task.visible_correct),
            "exact": program is not None and dict(program) == dict(task.authority),
        }
        records.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "response": response,
                "selected_key": selected_key,
                "assessment": assessment,
            }
        )
        by_representation.setdefault(task.representation, []).append(assessment)

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        return {
            "parse_coverage": _mean([float(bool(item["parsed"])) for item in items]),
            "legal_selection_rate": _mean([float(bool(item["legal_selection"])) for item in items]),
            "evidence_consistent_rate": _mean(
                [float(bool(item["evidence_consistent"])) for item in items]
            ),
            "target_accuracy": _mean([float(bool(item["target_correct"])) for item in items]),
            "semantic_accuracy": _mean([float(item["semantic_accuracy"]) for item in items]),
            "preserved_correct_accuracy": _mean(
                [float(item["preserved_correct_accuracy"]) for item in items]
            ),
            "exact_rate": _mean([float(bool(item["exact"])) for item in items]),
        }

    assessments = [record["assessment"] for record in records]
    heldout = [
        record["assessment"]
        for record in records
        if record["representation"] in HELDOUT_LOCALIZATION_REPRESENTATIONS
    ]
    metrics = {
        "condition": condition,
        "task_count": len(dossiers),
        **summarize(assessments),
        "heldout_semantic_accuracy": summarize(heldout)["semantic_accuracy"],
        "by_representation": {
            representation: summarize(items)
            for representation, items in sorted(by_representation.items())
        },
        "elapsed_seconds": elapsed_seconds,
        "peak_memory_gb": peak_memory_gb,
    }
    return {"metrics": metrics, "records": records}


def evaluate_selector(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    condition: str,
    *,
    adapter_path: Optional[Path] = None,
    batch_size: int = 8,
    max_tokens: int = 48,
) -> Mapping[str, Any]:
    from mlx_lm import load

    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    dossiers = tuple(build_dossier(task) for task in build_m35_suite("test", 30))
    started = time.monotonic()
    load_arguments: Dict[str, Any] = {"return_config": True}
    if adapter_path is not None:
        load_arguments["adapter_path"] = str(adapter_path)
    model, tokenizer, config = load(model_path, **load_arguments)
    prompts = tuple(_chat_prompt(tokenizer, dossier.prompt) for dossier in dossiers)
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        prompts,
        batch_size=batch_size,
        max_tokens=max_tokens,
        max_batch_tokens=12000,
    )
    result = aggregate_selector(
        condition,
        dossiers,
        responses,
        elapsed_seconds=time.monotonic() - started,
        peak_memory_gb=peak_memory,
    )
    store = ArtifactStore(output_root)
    predictions_digest = store.put("counterfactual_selector_predictions", result["records"])
    payload = {
        "version": COUNTERFACTUAL_SELECTOR_VERSION,
        "benchmark_version": COUNTERFACTUAL_DIAGNOSIS_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "condition": condition,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path) if adapter_path else None,
        "adapter_config_sha256": (
            hashlib.sha256((adapter_path / "adapter_config.json").read_bytes()).hexdigest()
            if adapter_path else None
        ),
        "adapter_weights_sha256": (
            hashlib.sha256((adapter_path / "adapters.safetensors").read_bytes()).hexdigest()
            if adapter_path else None
        ),
        "metrics": result["metrics"],
        "predictions_digest": predictions_digest,
        "generation": {"batch_size": batch_size, "max_tokens": max_tokens},
        "claim_boundary": (
            "M35 selector evaluation measures use of externally constructed intervention evidence "
            "on synthetic mechanisms, including two unseen representation families."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest(f"counterfactual-selector-{condition}-{evaluation_id}", manifest)
    return manifest


def assess_selector(
    baseline: Mapping[str, Any],
    candidate: Mapping[str, Any],
    benchmark_root: Path,
    oracle: Mapping[str, Any],
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["selector_gates"]
    base = baseline["metrics"]
    metrics = candidate["metrics"]
    checks = {
        "oracle_prerequisite_passed": bool(oracle["passed"]),
        "same_benchmark_freeze": (
            baseline["benchmark_freeze_id"]
            == candidate["benchmark_freeze_id"]
            == oracle["benchmark_freeze_id"]
            == freeze["freeze_id"]
        ),
        "same_model": baseline["model_path"] == candidate["model_path"],
        "adapter_only_on_candidate": baseline.get("adapter_path") is None and candidate.get("adapter_path") is not None,
        "parse_coverage": metrics["parse_coverage"] >= gates["minimum_parse_coverage"],
        "semantic_accuracy": metrics["semantic_accuracy"] >= gates["minimum_semantic_accuracy"],
        "preserved_correct_accuracy": (
            metrics["preserved_correct_accuracy"] >= gates["minimum_preserved_correct_accuracy"]
        ),
        "exact_rate": metrics["exact_rate"] >= gates["minimum_exact_rate"],
        "heldout_semantic_accuracy": (
            metrics["heldout_semantic_accuracy"] >= gates["minimum_heldout_semantic_accuracy"]
        ),
    }
    payload = {
        "version": COUNTERFACTUAL_SELECTOR_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "baseline_evaluation_id": baseline["evaluation_id"],
        "candidate_evaluation_id": candidate["evaluation_id"],
        "gains": {
            key: metrics[key] - base[key]
            for key in (
                "parse_coverage",
                "evidence_consistent_rate",
                "target_accuracy",
                "semantic_accuracy",
                "preserved_correct_accuracy",
                "exact_rate",
                "heldout_semantic_accuracy",
            )
        },
        "metrics": metrics,
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
    }
    return {**payload, "assessment_id": content_digest(payload)}
