from __future__ import annotations

import hashlib
import itertools
import json
import random
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_MODEL_SNAPSHOT,
    M50_OUTPUT_ALGEBRAS,
    _support,
    _task_signature,
)
from scientist.domains.cognitive_core.causal_controller_installation_v52 import (
    _slot_difference_targets,
    build_m52_cases,
)
from scientist.domains.cognitive_core.latent_state_validity_v52g import (
    M52G_REPRESENTATIONS,
    M52G_STATE_FAMILIES,
    _state,
    build_m52g_trajectories,
    execute_semantic_action,
    latent_metrics,
    paraphrase_agreement,
    semantic_informative_slots,
    state_swap_metrics,
)
from scientist.domains.cognitive_core.output_only_controller_v49 import (
    _task_lines,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.sequential_controller_validation_v52e import (
    M52E_M52_CHECKPOINT_SHA256,
    M52E_STAGES,
)
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
)


COUNTERFACTUAL_SEMANTIC_BINDING_VERSION = (
    "general-cognitive-counterfactual-semantic-binding-v52h"
)
M52H_SEED = 52817
M52H_SPLITS = ("train", "valid", "confirmation")
M52H_TRAJECTORIES_PER_REPRESENTATION = {
    "train": 3,
    "valid": 1,
    "confirmation": 5,
}
M52H_TRAIN_VARIANTS = (
    "canonical_current",
    "counterfactual_current",
    "canonical_paraphrase",
    "counterfactual_paraphrase",
)
M52H_CONFIRMATION_CONTEXTS = (
    "persistent",
    "current_only",
    "basis_rotated",
    "paraphrase",
)
M52H_REPRESENTATIONS = M52G_REPRESENTATIONS
M52H_M52F_GATE_SHA256 = (
    "bafb7e80ad738b7d7c1945237e4bb0c98d34ff6d6028a641ac20f96527fbeaab"
)
M52H_M52G_RESULT_ID = (
    "28a4a4a82eb58084743091ed53c8c9b7d6e7fa0eb279bbee83a7202888837fa5"
)


M52H_EXTRA_FAMILIES: Mapping[str, Tuple[Mapping[str, str], ...]] = {
    "observation_noise": (
        _state(
            "noise_free",
            "Measurements are now effectively free of observation noise.",
            "Observed values match the underlying quantities with negligible error.",
            "The conclusion presupposes essentially noise-free measurements.",
            "This evidence assumes observations faithfully report the latent values.",
        ),
        _state(
            "gaussian_noise",
            "Measurements now contain independent Gaussian observation noise.",
            "Each observed value is perturbed by an independent normal error.",
            "The conclusion presupposes independent normally distributed measurement error.",
            "This evidence assumes uncorrelated bell-shaped observation noise.",
        ),
        _state(
            "sparse_outliers",
            "Measurements now contain rare but extreme outliers.",
            "Most observations are accurate while a small fraction are severely corrupted.",
            "The conclusion presupposes sparse high-magnitude measurement corruption.",
            "This evidence assumes occasional extreme errors among otherwise clean values.",
        ),
        _state(
            "correlated_noise",
            "Measurements now contain strongly correlated observation noise.",
            "Errors persist together across neighboring observations.",
            "The conclusion presupposes temporally correlated measurement error.",
            "This evidence assumes observation noise is shared across nearby samples.",
        ),
    ),
    "deployment_topology": (
        _state(
            "centralized",
            "The system now runs as one centralized service.",
            "A single coordinator owns all state and computation.",
            "The conclusion presupposes a single centralized deployment.",
            "This evidence assumes one coordinator controls the complete system.",
        ),
        _state(
            "sharded",
            "The system now partitions state across independent shards.",
            "Each worker owns a disjoint portion of the data.",
            "The conclusion presupposes a horizontally sharded deployment.",
            "This evidence assumes disjoint state partitions across workers.",
        ),
        _state(
            "replicated",
            "The system now maintains synchronized replicas of the same state.",
            "Multiple workers hold redundant copies coordinated for consistency.",
            "The conclusion presupposes a synchronously replicated deployment.",
            "This evidence assumes redundant state copies remain coordinated.",
        ),
        _state(
            "federated",
            "The system now trains across federated clients with private local data.",
            "Clients retain their data and exchange only model updates.",
            "The conclusion presupposes a federated deployment with local data custody.",
            "This evidence assumes clients share updates without sharing raw records.",
        ),
    ),
    "failure_behavior": (
        _state(
            "fail_stop",
            "Components now fail permanently and visibly when they break.",
            "A failed component stops responding and does not recover by itself.",
            "The conclusion presupposes detectable fail-stop component failures.",
            "This evidence assumes broken components halt permanently and openly.",
        ),
        _state(
            "transient_failure",
            "Components now experience brief failures followed by automatic recovery.",
            "A component can disappear temporarily and then resume normal operation.",
            "The conclusion presupposes transient self-recovering failures.",
            "This evidence assumes outages are temporary and resolve without replacement.",
        ),
        _state(
            "intermittent_failure",
            "Components now alternate unpredictably between working and failing.",
            "The same component repeatedly becomes unavailable and available again.",
            "The conclusion presupposes intermittent recurring failures.",
            "This evidence assumes availability flickers unpredictably over time.",
        ),
        _state(
            "correlated_failure",
            "Components now fail together in correlated groups.",
            "One component outage makes related component outages more likely.",
            "The conclusion presupposes correlated multi-component failures.",
            "This evidence assumes failures cascade across related components.",
        ),
    ),
}

M52H_FAMILIES_BY_SPLIT = {
    "train": (
        "execution_order",
        "feedback_regime",
        "resource_bottleneck",
        "label_availability",
        "distribution_dynamics",
        "interface_contract",
    ),
    "valid": ("observation_noise",),
    "confirmation": ("deployment_topology", "failure_behavior"),
}


def _family(name: str) -> Tuple[Mapping[str, str], ...]:
    if name in M52G_STATE_FAMILIES:
        return M52G_STATE_FAMILIES[name]
    return M52H_EXTRA_FAMILIES[name]


def _stable_seed(split: str, representation: str, source_index: int) -> int:
    material = f"{M52H_SEED}:{split}:{representation}:{source_index}"
    return int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)


def _two_candidate_task(
    split: str, representation: str, source_index: int
) -> Tuple[Any, Tuple[Any, ...], Tuple[Any, ...]] | None:
    rng = random.Random(_stable_seed(split, representation, source_index))
    source = _build_task(f"m52h_{split}", representation, source_index, rng)
    base = _m43_experiment_task(source)
    if base is None:
        return None
    candidates = sorted(base.frontier, key=lambda item: item.key)
    for left, right in itertools.combinations(candidates, 2):
        provisional = replace(base, frontier=(left, right))
        equal, unequal = _support(provisional)
        if equal and unequal:
            task_id = "m52h-task-" + content_digest(
                {
                    "split": split,
                    "representation": representation,
                    "source_index": source_index,
                    "frontier": [left.key, right.key],
                    "version": COUNTERFACTUAL_SEMANTIC_BINDING_VERSION,
                }
            )[:24]
            return replace(provisional, task_id=task_id), equal, unequal
    return None


def _display_history(
    history: Sequence[Mapping[str, Any]], material: str
) -> Tuple[Mapping[str, Any], ...]:
    ordered = list(history)
    seed = int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(ordered)
    return tuple({**row, "slot": slot} for slot, row in enumerate(ordered, 1))


def _current_only_history(
    history: Sequence[Mapping[str, Any]], current_state_key: str
) -> Tuple[Mapping[str, Any], ...]:
    selected = [
        row for row in history if str(row["semantic_state"]) == current_state_key
    ]
    return tuple({**row, "slot": index} for index, row in enumerate(selected, 1))


def _basis_rotated_history(
    history: Sequence[Mapping[str, Any]], stage: int
) -> Tuple[Mapping[str, Any], ...]:
    if len(history) <= 1:
        return tuple(dict(row) for row in history)
    bases = [str(row["applicability_basis"]) for row in history]
    shift = 1 + (stage * 3) % (len(bases) - 1)
    rotated = bases[-shift:] + bases[:-shift]
    return tuple(
        {**row, "applicability_basis": basis}
        for row, basis in zip(history, rotated)
    )


def _paraphrase_history(
    history: Sequence[Mapping[str, Any]], state_lookup: Mapping[str, Mapping[str, str]]
) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        {
            **row,
            "applicability_basis": state_lookup[str(row["semantic_state"])][
                "basis_paraphrase"
            ],
        }
        for row in history
    )


def counterfactual_binding_prompt(
    task: Any,
    history: Sequence[Mapping[str, Any]],
    current_state_text: str,
) -> str:
    lines = _task_lines(task)
    lines.extend(
        (
            "Evidence is shown in display-slot order.",
            "Evidence history:",
        )
    )
    for row in history:
        lines.append("  slot %d" % int(row["slot"]))
        lines.append("    Applicability basis: " + str(row["applicability_basis"]))
        lines.append("    experiment=" + json.dumps(row["experiment"]))
        lines.append("    c1_output=" + json.dumps(row["outputs"][0], sort_keys=True))
        lines.append("    c2_output=" + json.dumps(row["outputs"][1], sort_keys=True))
    lines.extend(
        (
            f"Current research state: {current_state_text}",
            "Decide whether the evidence supports a control decision in the current research state.",
            "Do not invent an experiment in this response.",
            "If a supporting slot achieves the goal, return exactly: SELECT: <slot number>",
            "If the evidence does not yet support selection, return exactly: REVISE",
        )
    )
    return "\n".join(lines)


def _prior_signatures() -> set[str]:
    result = {
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52_cases(split)
    }
    result.update(
        trajectory["task_signature"]
        for split in ("train", "valid", "confirmation")
        for trajectory in build_m52g_trajectories(split)
    )
    return result


@lru_cache(maxsize=None)
def build_m52h_trajectories(
    split: str,
    representations: Tuple[str, ...] = M52H_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    if split not in M52H_SPLITS:
        raise ValueError(f"unknown M52h split: {split}")
    used = _prior_signatures()
    split_index = M52H_SPLITS.index(split)
    for earlier in M52H_SPLITS[:split_index]:
        used.update(
            trajectory["task_signature"]
            for trajectory in build_m52h_trajectories(
                earlier, M52H_REPRESENTATIONS
            )
        )
    trajectories = []
    families = M52H_FAMILIES_BY_SPLIT[split]
    count = M52H_TRAJECTORIES_PER_REPRESENTATION[split]
    for representation in representations:
        source_index = 0
        for trajectory_index in range(count):
            while True:
                candidate = _two_candidate_task(split, representation, source_index)
                source_index += 1
                if candidate is None:
                    if source_index > 30_000:
                        raise RuntimeError(
                            f"could not build M52h {split} {representation} task"
                        )
                    continue
                task, equal_values, unequal_values = candidate
                signature = _task_signature(task)
                if signature in used:
                    continue
                used.add(signature)
                break
            family_name = families[trajectory_index % len(families)]
            family = _family(family_name)
            state_lookup = {str(item["key"]): item for item in family}
            chronological = []
            stages = []
            for stage, state in zip(M52E_STAGES, family):
                equal_value = equal_values[(trajectory_index + stage) % len(equal_values)]
                evidence_value = unequal_values[
                    (trajectory_index * 5 + stage) % len(unequal_values)
                ]
                chronological.append(
                    {
                        "slot": len(chronological) + 1,
                        "semantic_state": state["key"],
                        "applicability_basis": state["basis"],
                        "experiment": equal_value,
                        "outputs": list(raw_candidate_outputs(task, equal_value)),
                    }
                )
                pre = _display_history(
                    chronological,
                    f"{split}:{representation}:{trajectory_index}:{stage}:pre",
                )
                chronological.append(
                    {
                        "slot": len(chronological) + 1,
                        "semantic_state": state["key"],
                        "applicability_basis": state["basis"],
                        "experiment": evidence_value,
                        "outputs": list(raw_candidate_outputs(task, evidence_value)),
                    }
                )
                post = _display_history(
                    chronological,
                    f"{split}:{representation}:{trajectory_index}:{stage}:post",
                )
                stages.append(
                    {
                        "stage": stage,
                        "state": dict(state),
                        "pre_evidence_history": pre,
                        "post_evidence_history": post,
                    }
                )
            trajectory_id = "m52h-trajectory-" + content_digest(
                {
                    "split": split,
                    "representation": representation,
                    "trajectory_index": trajectory_index,
                    "task_signature": signature,
                    "family": family_name,
                    "version": COUNTERFACTUAL_SEMANTIC_BINDING_VERSION,
                }
            )[:24]
            trajectories.append(
                {
                    "trajectory_id": trajectory_id,
                    "representation": representation,
                    "output_algebra": M50_OUTPUT_ALGEBRAS[representation],
                    "task": task,
                    "task_signature": signature,
                    "family": family_name,
                    "state_lookup": state_lookup,
                    "stages": tuple(stages),
                }
            )
    return tuple(trajectories)


def _row(
    *,
    split: str,
    trajectory: Mapping[str, Any],
    stage: int,
    phase: str,
    context: str,
    prompt_history: Sequence[Mapping[str, Any]],
    environment_history: Sequence[Mapping[str, Any]],
    current_state_key: str,
    current_state_text: str,
    pair_id: str | None = None,
) -> Mapping[str, Any]:
    informative = semantic_informative_slots(environment_history, current_state_key)
    expected_action = informative[0] if informative else 0
    record_id = "m52h-record-" + content_digest(
        {
            "split": split,
            "trajectory_id": trajectory["trajectory_id"],
            "stage": stage,
            "phase": phase,
            "context": context,
            "current_state_key": current_state_key,
            "version": COUNTERFACTUAL_SEMANTIC_BINDING_VERSION,
        }
    )[:24]
    return {
        "prompt": counterfactual_binding_prompt(
            trajectory["task"], prompt_history, current_state_text
        ),
        "metadata": {
            "record_id": record_id,
            "intervention_pair_id": pair_id,
            "split": split,
            "trajectory_id": trajectory["trajectory_id"],
            "stage": stage,
            "phase": phase,
            "context_variant": context,
            "current_state_key": current_state_key,
            "current_state_text": current_state_text,
            "family": trajectory["family"],
            "task_id": trajectory["task"].task_id,
            "task_signature": trajectory["task_signature"],
            "representation": trajectory["representation"],
            "output_algebra": trajectory["output_algebra"],
            "prefix_length": len(prompt_history),
            "prompt_history": list(prompt_history),
            "environment_history": list(environment_history),
            "slot_difference_targets": list(_slot_difference_targets(prompt_history)),
            "slot_validity_targets": [
                int(str(item["semantic_state"]) == current_state_key)
                for item in prompt_history
            ],
            "action_target": int(expected_action),
            "stale_informative_slots": [
                int(item["slot"])
                for item in environment_history
                if str(item["semantic_state"]) != current_state_key
                and json.dumps(item["outputs"][0], sort_keys=True, separators=(",", ":"))
                != json.dumps(item["outputs"][1], sort_keys=True, separators=(",", ":"))
            ],
        },
    }


def _counter_state(
    trajectory: Mapping[str, Any], stage: int
) -> Mapping[str, str]:
    if stage == 1:
        return trajectory["stages"][1]["state"]
    return trajectory["stages"][stage - 2]["state"]


def build_m52h_rows(
    split: str,
    representations: Tuple[str, ...] = M52H_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for trajectory in build_m52h_trajectories(split, representations):
        for stage_state in trajectory["stages"]:
            stage = int(stage_state["stage"])
            state = stage_state["state"]
            state_key = str(state["key"])
            for phase, persistent in (
                ("pre_evidence", stage_state["pre_evidence_history"]),
                ("post_evidence", stage_state["post_evidence_history"]),
            ):
                if split in ("train", "valid"):
                    counter = _counter_state(trajectory, stage)
                    paraphrase_history = _paraphrase_history(
                        persistent, trajectory["state_lookup"]
                    )
                    pair_id = "m52h-pair-" + content_digest(
                        {
                            "split": split,
                            "trajectory_id": trajectory["trajectory_id"],
                            "stage": stage,
                            "phase": phase,
                            "version": COUNTERFACTUAL_SEMANTIC_BINDING_VERSION,
                        }
                    )[:24]
                    specifications = (
                        (
                            "canonical_current",
                            persistent,
                            state_key,
                            str(state["current"]),
                        ),
                        (
                            "counterfactual_current",
                            persistent,
                            str(counter["key"]),
                            str(counter["current"]),
                        ),
                        (
                            "canonical_paraphrase",
                            paraphrase_history,
                            state_key,
                            str(state["current_paraphrase"]),
                        ),
                        (
                            "counterfactual_paraphrase",
                            paraphrase_history,
                            str(counter["key"]),
                            str(counter["current_paraphrase"]),
                        ),
                    )
                    for context, prompt_history, current_key, current_text in specifications:
                        rows.append(
                            _row(
                                split=split,
                                trajectory=trajectory,
                                stage=stage,
                                phase=phase,
                                context=context,
                                prompt_history=prompt_history,
                                environment_history=persistent,
                                current_state_key=current_key,
                                current_state_text=current_text,
                                pair_id=pair_id,
                            )
                        )
                    continue
                contexts = {
                    "persistent": (persistent, persistent, str(state["current"])),
                    "current_only": (
                        _current_only_history(persistent, state_key),
                        _current_only_history(persistent, state_key),
                        str(state["current"]),
                    ),
                    "basis_rotated": (
                        _basis_rotated_history(persistent, stage),
                        persistent,
                        str(state["current"]),
                    ),
                    "paraphrase": (
                        _paraphrase_history(persistent, trajectory["state_lookup"]),
                        persistent,
                        str(state["current_paraphrase"]),
                    ),
                }
                for context in M52H_CONFIRMATION_CONTEXTS:
                    prompt_history, environment_history, current_text = contexts[context]
                    rows.append(
                        _row(
                            split=split,
                            trajectory=trajectory,
                            stage=stage,
                            phase=phase,
                            context=context,
                            prompt_history=prompt_history,
                            environment_history=environment_history,
                            current_state_key=state_key,
                            current_state_text=current_text,
                        )
                    )
            if split == "confirmation" and stage > 1:
                prior = _counter_state(trajectory, stage)
                persistent = stage_state["pre_evidence_history"]
                rows.append(
                    _row(
                        split=split,
                        trajectory=trajectory,
                        stage=stage,
                        phase="state_swap",
                        context="state_swapped",
                        prompt_history=persistent,
                        environment_history=persistent,
                        current_state_key=str(prior["key"]),
                        current_state_text=str(prior["current_paraphrase"]),
                    )
                )
    return tuple(rows)


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52h artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json_payload(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def _jsonl_payload(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    m52g_result = json.loads(
        (
            project
            / "runs/cognitive_core/latent_state_validity_v52g/"
            "latent-state-validity-result.json"
        ).read_text()
    )
    m52_checkpoint = (
        project
        / "runs/cognitive_core/causal_controller_installation_v52/adapter/"
        "0000160_adapters.safetensors"
    )
    m52f_gate = (
        project
        / "runs/cognitive_core/state_validity_installation_v52f/gate/"
        "selected_gate.safetensors"
    )
    return {
        "version": COUNTERFACTUAL_SEMANTIC_BINDING_VERSION,
        "parent_version": "general-cognitive-latent-state-validity-v52g",
        "scientific_question": (
            "Can span-level cross-attention plus paired counterfactual and paraphrase "
            "supervision make semantic evidence applicability causally depend on current state?"
        ),
        "seed": M52H_SEED,
        "representations": list(M52H_REPRESENTATIONS),
        "stages": list(M52E_STAGES),
        "families_by_split": {
            key: list(value) for key, value in M52H_FAMILIES_BY_SPLIT.items()
        },
        "trajectories_per_representation": dict(M52H_TRAJECTORIES_PER_REPRESENTATION),
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "m52_checkpoint_source": (
                "runs/cognitive_core/causal_controller_installation_v52/adapter/"
                "0000160_adapters.safetensors"
            ),
            "m52_checkpoint_sha256": _sha256(m52_checkpoint),
            "m52f_gate_source": (
                "runs/cognitive_core/state_validity_installation_v52f/gate/"
                "selected_gate.safetensors"
            ),
            "m52f_gate_sha256": _sha256(m52f_gate),
            "m52g_result_id": m52g_result["result_id"],
            "m52g_diagnosis": "semantic_applicability_representation_insufficient",
        },
        "architecture_contract": {
            "causal_layer": 14,
            "frozen_components": [
                "Qwen2.5-1.5B backbone",
                "M47 LoRA policy",
                "M52 difference scorer, pointer, revise threshold, and validity actuator",
                "language decoder",
            ],
            "trainable_component": "span_semantic_entailment_gate_only",
            "initialization": (
                "basis, current, relation, and output projections copied from M52f"
            ),
            "evidence_before_current_state": True,
            "semantic_binding": (
                "token-level cross-attention between complete evidence-assumption and "
                "current-state spans followed by learned relation pooling"
            ),
            "explicit_scope_identifiers": False,
            "chronology_or_turn_labels": False,
            "language_decoder_calls": 0,
        },
        "training_recipe": {
            "seed": M52H_SEED,
            "gate_width": 32,
            "validity_penalty_scale": 4.0,
            "learning_rate": 0.001,
            "iterations": 1800,
            "checkpoint_candidates": [300, 600, 900, 1200, 1500, 1800],
            "quartet_order": list(M52H_TRAIN_VARIANTS),
            "loss": (
                "native validity plus pointer action loss, 0.75 counterfactual current-state "
                "interchange loss, and 0.25 paraphrase consistency loss"
            ),
            "checkpoint_selection": (
                "highest counterfactual validation action accuracy, then paraphrase action "
                "accuracy, overall action accuracy, validity accuracy, and earliest checkpoint"
            ),
            "confirmation_access_during_selection": False,
        },
        "validation_stop_rule": {
            "minimum_counterfactual_action_accuracy": 0.80,
            "minimum_paraphrase_action_accuracy": 0.80,
            "minimum_overall_action_accuracy": 0.85,
            "minimum_validity_accuracy": 0.85,
            "confirmation_must_remain_closed_if_any_fail": True,
        },
        "confirmation_contract": {
            "minimum_persistent_decision_accuracy": 0.88,
            "minimum_persistent_stage_success": 0.80,
            "minimum_persistent_trajectory_success": 0.60,
            "minimum_each_representation_stage_success": 0.70,
            "minimum_each_later_stage_recovery_accuracy": 0.85,
            "minimum_terminal_select_accuracy": 0.85,
            "minimum_current_only_stage_success": 0.95,
            "minimum_semantic_validity_accuracy": 0.85,
            "minimum_paraphrase_decision_accuracy": 0.85,
            "minimum_paraphrase_action_agreement": 0.85,
            "minimum_state_swap_target_accuracy": 0.80,
            "minimum_state_swap_flip_rate": 0.80,
            "minimum_gain_over_m52_baseline": 0.45,
            "minimum_gain_over_basis_rotated": 0.25,
            "minimum_gain_over_validity_rotated": 0.30,
            "minimum_oracle_stage_success": 0.90,
            "require_m52_checkpoint_unchanged": True,
            "require_zero_trainable_base_tensors": True,
        },
        "integrity_contract": {
            "all_mechanisms_fresh_and_split_disjoint": True,
            "transition_families_disjoint_across_splits": True,
            "each_training_unit_has_identical-history_counterfactual_quartet": True,
            "evidence_token_states_are_causally_before_current_state": True,
            "confirmation_closed_by_validation_stop_rule": True,
            "terminal_outcomes_recomputed_from_semantic_applicability": True,
        },
        "claim_boundary": (
            "M52h tests counterfactual semantic binding on held-out synthetic transition "
            "families. Passing would not establish endogenous state discovery, natural-task "
            "transfer, autonomous tool use, or general reasoning parity."
        ),
    }


def prepare_m52h_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol_payload = _protocol_payload(project)
    protocol = {**protocol_payload, "protocol_freeze_id": content_digest(protocol_payload)}
    _write_immutable(output / "protocol-freeze.json", _json_payload(protocol))
    hashes = {}
    counts = {}
    for split in M52H_SPLITS:
        rows = build_m52h_rows(split)
        hashes[split] = _write_immutable(
            output / f"controller/{split}.jsonl", _jsonl_payload(rows)
        )
        counts[split] = len(rows)
    payload = {**protocol, "hashes": hashes, "counts": counts}
    freeze = {**payload, "freeze_id": content_digest(payload)}
    _write_immutable(output / "benchmark-freeze.json", _json_payload(freeze))
    verification = verify_m52h_benchmark(output, project)
    _write_immutable(output / "benchmark-verification.json", _json_payload(verification))
    return freeze


def _rows(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(json.loads(line) for line in path.read_text().splitlines() if line)


def verify_m52h_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol_payload = {
        key: value for key, value in protocol.items() if key != "protocol_freeze_id"
    }
    freeze_payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    stored = {
        split: _rows(output / f"controller/{split}.jsonl") for split in M52H_SPLITS
    }
    signatures = {
        split: {row["metadata"]["task_signature"] for row in rows}
        for split, rows in stored.items()
    }
    prior = _prior_signatures()
    quartet_valid = True
    semantics_valid = True
    current_after_evidence = True
    controls_valid = True
    forbidden_absent = True
    for split in ("train", "valid"):
        groups = {}
        for row in stored[split]:
            groups.setdefault(row["metadata"]["intervention_pair_id"], []).append(row)
        for group in groups.values():
            variants = {row["metadata"]["context_variant"] for row in group}
            canonical = {
                row["metadata"]["context_variant"]: row for row in group
            }
            quartet_valid = quartet_valid and (
                len(group) == 4
                and variants == set(M52H_TRAIN_VARIANTS)
                and canonical["canonical_current"]["metadata"]["prompt_history"]
                == canonical["counterfactual_current"]["metadata"]["prompt_history"]
                and canonical["canonical_paraphrase"]["metadata"]["prompt_history"]
                == canonical["counterfactual_paraphrase"]["metadata"]["prompt_history"]
            )
    for rows in stored.values():
        for row in rows:
            metadata = row["metadata"]
            expected_validity = [
                int(str(item["semantic_state"]) == metadata["current_state_key"])
                for item in metadata["prompt_history"]
            ]
            semantics_valid = semantics_valid and (
                expected_validity == metadata["slot_validity_targets"]
            )
            informative = semantic_informative_slots(
                metadata["environment_history"], metadata["current_state_key"]
            )
            expected_action = informative[0] if informative else 0
            semantics_valid = semantics_valid and (
                int(metadata["action_target"]) == int(expected_action)
            )
            current_after_evidence = current_after_evidence and (
                row["prompt"].rfind("Current research state:")
                > row["prompt"].rfind("c2_output=")
            )
            forbidden_absent = forbidden_absent and all(
                marker not in row["prompt"]
                for marker in ("scope_id", "scope_stage", "turn=", "valid only when")
            )
            if metadata["context_variant"] in (
                "basis_rotated",
                "paraphrase",
                "state_swapped",
            ):
                controls_valid = controls_valid and [
                    (item["slot"], item["experiment"], item["outputs"])
                    for item in metadata["prompt_history"]
                ] == [
                    (item["slot"], item["experiment"], item["outputs"])
                    for item in metadata["environment_history"]
                ]
    m52_checkpoint = project / freeze["frozen_model"]["m52_checkpoint_source"]
    m52f_gate = project / freeze["frozen_model"]["m52f_gate_source"]
    m52g_result = json.loads(
        (
            project
            / "runs/cognitive_core/latent_state_validity_v52g/"
            "latent-state-validity-result.json"
        ).read_text()
    )
    checks = {
        "protocol_id_is_content_derived": content_digest(protocol_payload)
        == protocol["protocol_freeze_id"],
        "freeze_id_is_content_derived": content_digest(freeze_payload)
        == freeze["freeze_id"],
        "stored_rows_reproduce": all(
            stored[split] == build_m52h_rows(split) for split in M52H_SPLITS
        ),
        "file_hashes_match": all(
            _sha256(output / f"controller/{split}.jsonl")
            == freeze["hashes"][split]
            for split in M52H_SPLITS
        ),
        "counts_match": all(
            len(stored[split]) == freeze["counts"][split] for split in M52H_SPLITS
        ),
        "prior_mechanisms_excluded": all(
            not bool(signatures[split] & prior) for split in M52H_SPLITS
        ),
        "mechanism_splits_disjoint": all(
            not bool(signatures[left] & signatures[right])
            for index, left in enumerate(M52H_SPLITS)
            for right in M52H_SPLITS[index + 1 :]
        ),
        "transition_families_disjoint": all(
            not bool(
                set(M52H_FAMILIES_BY_SPLIT[left])
                & set(M52H_FAMILIES_BY_SPLIT[right])
            )
            for index, left in enumerate(M52H_SPLITS)
            for right in M52H_SPLITS[index + 1 :]
        ),
        "counterfactual_paraphrase_quartets_exact": quartet_valid,
        "semantic_targets_and_actions_replay": semantics_valid,
        "evidence_precedes_current_state": current_after_evidence,
        "controls_preserve_task_evidence_and_positions": controls_valid,
        "explicit_scope_and_chronology_markers_absent": forbidden_absent,
        "m52_checkpoint_matches": _sha256(m52_checkpoint)
        == freeze["frozen_model"]["m52_checkpoint_sha256"]
        == M52E_M52_CHECKPOINT_SHA256,
        "m52f_initialization_matches": _sha256(m52f_gate)
        == freeze["frozen_model"]["m52f_gate_sha256"]
        == M52H_M52F_GATE_SHA256,
        "m52g_parent_result_matches": m52g_result["result_id"]
        == freeze["frozen_model"]["m52g_result_id"]
        == M52H_M52G_RESULT_ID,
    }
    return {
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def validation_stop_passed(
    metrics: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "counterfactual_action_accuracy": metrics["counterfactual_action_accuracy"]
        >= contract["minimum_counterfactual_action_accuracy"],
        "paraphrase_action_accuracy": metrics["paraphrase_action_accuracy"]
        >= contract["minimum_paraphrase_action_accuracy"],
        "overall_action_accuracy": metrics["action_accuracy"]
        >= contract["minimum_overall_action_accuracy"],
        "validity_accuracy": metrics["validity_accuracy"]
        >= contract["minimum_validity_accuracy"],
    }
    return all(checks.values()), checks


def select_m52h_checkpoint(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    if not candidates:
        raise ValueError("M52h checkpoint selection requires candidates")
    return sorted(
        candidates,
        key=lambda row: (
            -float(row["counterfactual_action_accuracy"]),
            -float(row["paraphrase_action_accuracy"]),
            -float(row["action_accuracy"]),
            -float(row["validity_accuracy"]),
            int(row["iteration"]),
        ),
    )[0]


def m52h_passed(*args: Any, **kwargs: Any) -> Tuple[bool, Mapping[str, bool]]:
    from scientist.domains.cognitive_core.latent_state_validity_v52g import (
        m52g_passed,
    )

    return m52g_passed(*args, **kwargs)


def span_validity_metrics(
    predictions: Sequence[Mapping[str, Any]], context: str = "persistent"
) -> Mapping[str, Any]:
    rows = [row for row in predictions if row["context_variant"] == context]

    def summarize(selected: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
        correct = sum(
            int(value) for row in selected for value in row["validity_correct"]
        )
        total = sum(len(row["validity_correct"]) for row in selected)
        return {"slot_count": total, "accuracy": correct / max(total, 1)}

    return {
        **summarize(rows),
        "by_representation": {
            representation: summarize(
                [row for row in rows if row["representation"] == representation]
            )
            for representation in M52H_REPRESENTATIONS
        },
        "by_family": {
            family: summarize([row for row in rows if row["family"] == family])
            for family in M52H_FAMILIES_BY_SPLIT["confirmation"]
        },
    }


def span_swap_metrics(predictions: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    return state_swap_metrics(predictions)


def span_paraphrase_agreement(
    predictions: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    return paraphrase_agreement(predictions)


def span_metrics(
    records: Sequence[Mapping[str, Any]], condition: str
) -> Mapping[str, Any]:
    return latent_metrics(records, condition)
