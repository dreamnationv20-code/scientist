from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import enumerate_interventions
from scientist.domains.cognitive_core.counterfactual_signature_v38 import (
    COUNTERFACTUAL_SIGNATURE_VERSION,
    EVIDENCE_MODES,
    build_m38_suite,
    signature_node_prompt,
    signature_value_prompt,
)
from scientist.domains.cognitive_core.factorized_ranker_model_v37 import _binary_margins
from scientist.domains.cognitive_core.factorized_ranking_v37 import factorized_ranking
from scientist.domains.cognitive_core.internal_core_v28 import _chat_prompt
from scientist.domains.cognitive_core.proposal_verification_v36 import (
    PROPOSAL_BUDGET,
    aggregate_proposal_sets,
)


COUNTERFACTUAL_SIGNATURE_MODEL_VERSION = "general-cognitive-counterfactual-signature-model-v38"


def _aggregate_mode(
    mode: str,
    tasks,
    node_by_task: Mapping[str, Mapping[str, float]],
    value_by_task: Mapping[str, Mapping[str, float]],
) -> Mapping[str, Any]:
    proposal_sets = []
    ranking_records = []
    exact_ranks = []
    node_top1 = []
    value_top1 = []
    ranking_by_representation: Dict[str, list[Mapping[str, float]]] = {}
    for task in tasks:
        ranked, score_rows = factorized_ranking(
            task, node_by_task[task.task_id], value_by_task[task.task_id]
        )
        proposal_sets.append(ranked[:PROPOSAL_BUDGET])
        correct_key = f"{task.target_node}={json.dumps(task.correct_edit_value, sort_keys=True)}"
        exact_rank = next(index for index, item in enumerate(ranked, 1) if item.key == correct_key)
        predicted_node = max(
            node_by_task[task.task_id],
            key=lambda node: (node_by_task[task.task_id][node], node),
        )
        target_values = [item for item in enumerate_interventions(task) if item.node == task.target_node]
        predicted_value_key = max(
            (item.key for item in target_values),
            key=lambda key: (value_by_task[task.task_id][key], key),
        )
        item_metrics = {
            "exact_rank": float(exact_rank),
            "exact_top1": float(exact_rank == 1),
            "target_node_top1": float(predicted_node == task.target_node),
            "target_value_top1_given_node": float(predicted_value_key == correct_key),
        }
        exact_ranks.append(float(exact_rank))
        node_top1.append(item_metrics["target_node_top1"])
        value_top1.append(item_metrics["target_value_top1_given_node"])
        ranking_by_representation.setdefault(task.representation, []).append(item_metrics)
        ranking_records.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "correct_key": correct_key,
                "node_margins": dict(node_by_task[task.task_id]),
                "ranked_edits": list(score_rows),
                "ranking_metrics": item_metrics,
            }
        )
    aggregate = aggregate_proposal_sets(f"model_{mode}", tasks, proposal_sets)

    def mean(items: Sequence[Mapping[str, float]], key: str) -> float:
        return sum(item[key] for item in items) / len(items)

    metrics = {
        **aggregate["metrics"],
        "scoring_completeness": 1.0,
        "mean_exact_rank": sum(exact_ranks) / len(exact_ranks),
        "exact_top1_accuracy": sum(float(rank == 1) for rank in exact_ranks) / len(exact_ranks),
        "target_node_top1_accuracy": sum(node_top1) / len(node_top1),
        "target_value_top1_given_node_accuracy": sum(value_top1) / len(value_top1),
        "ranking_by_representation": {
            representation: {
                "mean_exact_rank": mean(items, "exact_rank"),
                "exact_top1_accuracy": mean(items, "exact_top1"),
                "target_node_top1_accuracy": mean(items, "target_node_top1"),
                "target_value_top1_given_node_accuracy": mean(
                    items, "target_value_top1_given_node"
                ),
            }
            for representation, items in sorted(ranking_by_representation.items())
        },
    }
    return {"metrics": metrics, "rankings": ranking_records, "controller": aggregate["records"]}


def evaluate_signature_model(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    *,
    adapter_path: Path,
    batch_size: int = 24,
    max_batch_tokens: int = 24000,
    max_prompt_tokens: int = 1400,
) -> Mapping[str, Any]:
    from mlx_lm import load

    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m38_suite("test", 30)
    started = time.monotonic()
    model, tokenizer, config = load(
        model_path, adapter_path=str(adapter_path), return_config=True
    )
    prompts = []
    prompt_keys = []
    for mode in EVIDENCE_MODES:
        for task in tasks:
            for node in sorted(task.candidate):
                prompts.append(_chat_prompt(tokenizer, signature_node_prompt(task, node, mode)))
                prompt_keys.append((mode, task.task_id, "node", node))
            for intervention in enumerate_interventions(task):
                prompts.append(
                    _chat_prompt(tokenizer, signature_value_prompt(task, intervention, mode))
                )
                prompt_keys.append((mode, task.task_id, "value", intervention.key))
    margins, peak_memory = _binary_margins(
        model,
        tokenizer,
        prompts,
        batch_size=batch_size,
        max_batch_tokens=max_batch_tokens,
        max_prompt_tokens=max_prompt_tokens,
    )
    tables: Dict[str, Dict[str, Dict[str, Dict[str, float]]]] = {
        mode: {
            task.task_id: {"node": {}, "value": {}} for task in tasks
        }
        for mode in EVIDENCE_MODES
    }
    for (mode, task_id, stage, key), margin in zip(prompt_keys, margins):
        tables[mode][task_id][stage][key] = margin
    results = {}
    for mode in EVIDENCE_MODES:
        results[mode] = _aggregate_mode(
            mode,
            tasks,
            {task.task_id: tables[mode][task.task_id]["node"] for task in tasks},
            {task.task_id: tables[mode][task.task_id]["value"] for task in tasks},
        )
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "counterfactual_signature_model_predictions",
        {
            mode: {
                "rankings": results[mode]["rankings"],
                "controller": results[mode]["controller"],
            }
            for mode in EVIDENCE_MODES
        },
    )
    payload = {
        "version": COUNTERFACTUAL_SIGNATURE_MODEL_VERSION,
        "benchmark_version": COUNTERFACTUAL_SIGNATURE_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path),
        "adapter_config_sha256": hashlib.sha256(
            (adapter_path / "adapter_config.json").read_bytes()
        ).hexdigest(),
        "adapter_weights_sha256": hashlib.sha256(
            (adapter_path / "adapters.safetensors").read_bytes()
        ).hexdigest(),
        "metrics_by_evidence_mode": {
            mode: results[mode]["metrics"] for mode in EVIDENCE_MODES
        },
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "scoring": {
            "batch_size": batch_size,
            "max_prompt_tokens": max_prompt_tokens,
            "factorization": "softmax(node_margin)*softmax(value_margin_within_node)",
            "total_candidate_prompts": len(prompts),
        },
        "claim_boundary": (
            "The same trained 1.5B adapter scores raw, passive execution-signature, and active diagnostic-"
            "signature prompts. Execution, legal enumeration, experiment outcomes, verification, and fallback "
            "are external."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest(f"counterfactual-signature-model-{evaluation_id}", manifest)
    return manifest


def assess_signature_model(
    candidate: Mapping[str, Any],
    benchmark_root: Path,
    baselines: Mapping[str, Any],
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["model_gates"]
    modes = candidate["metrics_by_evidence_mode"]
    raw = modes["raw"]
    passive = modes["passive"]
    active = modes["active"]
    gain_raw = active["exact_repair_coverage_at_k"] - raw["exact_repair_coverage_at_k"]
    checks = {
        "deterministic_evidence_feasibility_passed": bool(baselines["passed"]),
        "same_benchmark_freeze": (
            candidate["benchmark_freeze_id"] == baselines["benchmark_freeze_id"] == freeze["freeze_id"]
        ),
        "adapter_present": candidate.get("adapter_path") is not None,
        "scoring_completeness_all_modes": all(
            modes[mode]["scoring_completeness"] >= gates["minimum_scoring_completeness"]
            for mode in EVIDENCE_MODES
        ),
        "active_exact_coverage": (
            active["exact_repair_coverage_at_k"] >= gates["minimum_active_exact_coverage_at_k"]
        ),
        "active_semantic_accuracy": (
            active["selected_semantic_accuracy"] >= gates["minimum_active_semantic_accuracy"]
        ),
        "active_preservation": (
            active["selected_preserved_correct_accuracy"] >= gates["minimum_active_preservation"]
        ),
        "active_heldout_semantic_accuracy": (
            active["heldout_selected_semantic_accuracy"]
            >= gates["minimum_active_heldout_semantic_accuracy"]
        ),
        "active_target_node_top1_accuracy": (
            active["target_node_top1_accuracy"]
            >= gates["minimum_active_target_node_top1_accuracy"]
        ),
        "active_target_value_top1_given_node_accuracy": (
            active["target_value_top1_given_node_accuracy"]
            >= gates["minimum_active_target_value_top1_given_node_accuracy"]
        ),
        "active_exact_coverage_gain_over_raw": (
            gain_raw >= gates["minimum_active_exact_coverage_gain_over_raw"]
        ),
    }
    tier_thresholds = {
        "exact_repair_coverage_at_k": gates["minimum_active_exact_coverage_at_k"],
        "selected_semantic_accuracy": gates["minimum_active_semantic_accuracy"],
        "selected_preserved_correct_accuracy": gates["minimum_active_preservation"],
        "target_node_top1_accuracy": gates["minimum_active_target_node_top1_accuracy"],
        "target_value_top1_given_node_accuracy": gates[
            "minimum_active_target_value_top1_given_node_accuracy"
        ],
    }
    tier_passes = {
        mode: all(modes[mode][metric] >= threshold for metric, threshold in tier_thresholds.items())
        for mode in EVIDENCE_MODES
    }
    earliest = next((mode for mode in EVIDENCE_MODES if tier_passes[mode]), None)
    payload = {
        "version": COUNTERFACTUAL_SIGNATURE_MODEL_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "candidate_evaluation_id": candidate["evaluation_id"],
        "baseline_evaluation_id": baselines["evaluation_id"],
        "metrics_by_evidence_mode": modes,
        "active_exact_coverage_gain_over_raw": gain_raw,
        "active_exact_coverage_gain_over_passive": (
            active["exact_repair_coverage_at_k"] - passive["exact_repair_coverage_at_k"]
        ),
        "tier_thresholds": tier_thresholds,
        "tier_passes": tier_passes,
        "earliest_sufficient_model_evidence_tier": earliest,
        "checks": checks,
        "gates": gates,
        "passed": all(checks.values()),
    }
    return {**payload, "assessment_id": content_digest(payload)}
