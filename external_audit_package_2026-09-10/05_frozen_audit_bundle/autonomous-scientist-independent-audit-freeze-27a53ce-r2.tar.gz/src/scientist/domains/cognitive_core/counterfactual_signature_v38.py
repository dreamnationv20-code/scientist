from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    Intervention,
    enumerate_interventions,
)
from scientist.domains.cognitive_core.factorized_ranking_v37 import (
    NEGATIVE_TOKEN,
    POSITIVE_TOKEN,
    factorized_ranking,
    node_scoring_prompt,
    value_scoring_prompt,
)
from scientist.domains.cognitive_core.proposal_verification_v36 import (
    PROPOSAL_BUDGET,
    aggregate_proposal_sets,
    fixed_case_partition,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
    LOCALIZATION_TRAIN_REPRESENTATIONS,
    REPRESENTATIONS,
    RepairTask,
    _build_task,
    execute,
)


COUNTERFACTUAL_SIGNATURE_VERSION = "general-cognitive-counterfactual-signature-v38"
M38_SPLIT_SEEDS = {"train": 38037, "valid": 38061, "test": 38109}
EVIDENCE_MODES = ("raw", "passive", "active")


def build_m38_suite(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[RepairTask, ...]:
    if split not in M38_SPLIT_SEEDS:
        raise ValueError("unknown M38 split")
    rng = random.Random(M38_SPLIT_SEEDS[split])
    tasks = tuple(
        _build_task(f"m38_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("M38 task ids are not unique")
    return tasks


def evidence_cases(task: RepairTask, mode: str) -> Tuple[Mapping[str, Any], ...]:
    if mode not in EVIDENCE_MODES:
        raise ValueError("unknown evidence mode")
    passive = tuple(task.visible_correct) + (
        {"input": task.counterexample["input"], "expected": task.counterexample["expected"]},
    )
    if mode in ("raw", "passive"):
        return passive
    diagnostic, _ = fixed_case_partition(task)
    return passive + tuple(diagnostic)


def intervention_signature(
    task: RepairTask,
    intervention: Intervention,
    mode: str,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    passive_count = len(task.visible_correct) + 1
    for index, case in enumerate(evidence_cases(task, mode)):
        try:
            output = execute(task.representation, intervention.program, case["input"])
        except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
            output = "execution_error"
        rows.append(
            {
                "case": (
                    f"observed_{index + 1}"
                    if index < passive_count
                    else f"diagnostic_{index - passive_count + 1}"
                ),
                "output": output,
                "required": case["expected"],
                "match": output == case["expected"],
            }
        )
    return tuple(rows)


def _signature_text(rows: Sequence[Mapping[str, Any]]) -> str:
    return json.dumps(
        [
            {
                "case": row["case"],
                "match": int(bool(row["match"])),
            }
            for row in rows
        ],
        sort_keys=True,
    )


def signature_node_prompt(task: RepairTask, node: str, mode: str) -> str:
    raw = node_scoring_prompt(task, node)
    if mode == "raw":
        return raw
    question = "Is this the faulty node? Answer exactly one token: Y or N."
    interventions = [item for item in enumerate_interventions(task) if item.node == node]
    table = "\n".join(
        f"  replacement={json.dumps(item.value, sort_keys=True)}; signature="
        f"{_signature_text(intervention_signature(task, item, mode))}"
        for item in interventions
    )
    return raw.replace(
        question,
        (
            f"External executor evidence mode: {mode}. Each row is an observed intervention consequence; "
            "diagnostic cases are experiments and are excluded from final scoring.\n"
            f"Candidate replacements for this node:\n{table}\n{question}"
        ),
    )


def signature_value_prompt(task: RepairTask, intervention: Intervention, mode: str) -> str:
    raw = value_scoring_prompt(task, intervention)
    if mode == "raw":
        return raw
    question = (
        "Would this exact typed replacement restore the intended mechanism, rather than merely fit the "
        "displayed examples? Answer exactly one token: Y or N."
    )
    signature = _signature_text(intervention_signature(task, intervention, mode))
    return raw.replace(
        question,
        (
            f"External executor evidence mode: {mode}. Intervention signature: {signature}\n"
            f"Diagnostic cases, when present, are experiments excluded from final scoring.\n{question}"
        ),
    )


def _record(
    task: RepairTask,
    mode: str,
    stage: str,
    prompt: str,
    positive: bool,
    *,
    node: str,
    value: Any = None,
    hard_negative: bool = False,
) -> Mapping[str, Any]:
    return {
        "messages": [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": POSITIVE_TOKEN if positive else NEGATIVE_TOKEN},
        ],
        "metadata": {
            "task_id": task.task_id,
            "representation": task.representation,
            "evidence_mode": mode,
            "stage": stage,
            "node": node,
            "value": value,
            "positive": positive,
            "hard_negative": hard_negative,
        },
    }


def signature_training_records(task: RepairTask, mode: str) -> Tuple[Mapping[str, Any], ...]:
    if mode not in EVIDENCE_MODES:
        raise ValueError("unknown evidence mode")
    records = []
    nodes = sorted(task.candidate)
    node_negatives = [node for node in nodes if node != task.target_node]
    positive_node = _record(
        task,
        mode,
        "node",
        signature_node_prompt(task, task.target_node, mode),
        True,
        node=task.target_node,
    )
    records.extend([positive_node] * len(node_negatives))
    records.extend(
        _record(
            task,
            mode,
            "node",
            signature_node_prompt(task, node, mode),
            False,
            node=node,
        )
        for node in node_negatives
    )
    interventions = tuple(enumerate_interventions(task))
    correct_key = f"{task.target_node}={json.dumps(task.correct_edit_value, sort_keys=True)}"
    correct = next(item for item in interventions if item.key == correct_key)
    wrong = [item for item in interventions if item.key != correct_key]
    positive_value = _record(
        task,
        mode,
        "value",
        signature_value_prompt(task, correct, mode),
        True,
        node=correct.node,
        value=correct.value,
    )
    records.extend([positive_value] * len(wrong))
    records.extend(
        _record(
            task,
            mode,
            "value",
            signature_value_prompt(task, item, mode),
            False,
            node=item.node,
            value=item.value,
            hard_negative=bool(item.viable),
        )
        for item in wrong
    )
    seed = int(
        hashlib.sha256((f"m38-{mode}-" + task.task_id).encode("utf-8")).hexdigest()[:16], 16
    )
    random.Random(seed).shuffle(records)
    return tuple(records)


def deterministic_signature_ranking(
    task: RepairTask, mode: str
) -> Tuple[Tuple[Intervention, ...], Tuple[Mapping[str, Any], ...]]:
    if mode not in ("passive", "active"):
        raise ValueError("deterministic signatures require passive or active evidence")
    interventions = tuple(enumerate_interventions(task))
    fractions = {}
    for item in interventions:
        signature = intervention_signature(task, item, mode)
        fractions[item.key] = sum(int(row["match"]) for row in signature) / len(signature)
    node_margins = {
        node: 8.0 * max(fractions[item.key] for item in interventions if item.node == node)
        for node in task.candidate
    }
    value_margins = {key: 8.0 * fraction for key, fraction in fractions.items()}
    return factorized_ranking(task, node_margins, value_margins)


def signature_ambiguity(tasks: Sequence[RepairTask], mode: str) -> Mapping[str, float]:
    counts = []
    for task in tasks:
        count = 0
        for item in enumerate_interventions(task):
            signature = intervention_signature(task, item, mode)
            count += int(all(bool(row["match"]) for row in signature))
        counts.append(count)
    return {
        "mean_perfect_signature_candidates": sum(counts) / len(counts),
        "unique_perfect_signature_rate": sum(int(count == 1) for count in counts) / len(counts),
    }


def random_m38_proposals(task: RepairTask) -> Tuple[Intervention, ...]:
    interventions = list(enumerate_interventions(task))
    seed = int(hashlib.sha256(("random-v38-" + task.task_id).encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(interventions)
    return tuple(interventions[:PROPOSAL_BUDGET])


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def prepare_m38_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    mixed = output / "mixed_evidence"
    mixed.mkdir(parents=True, exist_ok=True)
    train = build_m38_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)
    valid = build_m38_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)
    test = build_m38_suite("test", 30)
    train_hash, train_records = _write_jsonl(
        mixed / "train.jsonl",
        (
            record
            for task in train
            for mode in EVIDENCE_MODES
            for record in signature_training_records(task, mode)
        ),
    )
    valid_hash, valid_records = _write_jsonl(
        mixed / "valid.jsonl",
        (
            record
            for task in valid
            for mode in EVIDENCE_MODES
            for record in signature_training_records(task, mode)
        ),
    )
    public_hash, _ = _write_jsonl(
        output / "test-public.jsonl",
        (
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "prompt_hashes": {
                    mode: {
                        "nodes": {
                            node: hashlib.sha256(
                                signature_node_prompt(task, node, mode).encode("utf-8")
                            ).hexdigest()
                            for node in sorted(task.candidate)
                        },
                        "values": {
                            item.key: hashlib.sha256(
                                signature_value_prompt(task, item, mode).encode("utf-8")
                            ).hexdigest()
                            for item in enumerate_interventions(task)
                        },
                    }
                    for mode in EVIDENCE_MODES
                },
            }
            for task in test
        ),
    )
    authority_hash, _ = _write_jsonl(
        output / "test-authority.jsonl",
        (
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "target_node": task.target_node,
                "correct_edit_value": task.correct_edit_value,
                "final_cases": list(fixed_case_partition(task)[1]),
            }
            for task in test
        ),
    )
    payload = {
        "version": COUNTERFACTUAL_SIGNATURE_VERSION,
        "split_seeds": M38_SPLIT_SEEDS,
        "representations": list(REPRESENTATIONS),
        "training_representations": list(LOCALIZATION_TRAIN_REPRESENTATIONS),
        "heldout_representations": list(HELDOUT_LOCALIZATION_REPRESENTATIONS),
        "evidence_modes": list(EVIDENCE_MODES),
        "signature_fields_exposed_to_model": ["case", "match"],
        "proposal_budget": PROPOSAL_BUDGET,
        "counts": {
            "train_tasks": len(train),
            "valid_tasks": len(valid),
            "test_tasks": len(test),
            "train_contrast_records": train_records,
            "valid_contrast_records": valid_records,
        },
        "hashes": {
            "mixed_train": train_hash,
            "mixed_valid": valid_hash,
            "test_public": public_hash,
            "test_authority": authority_hash,
        },
        "training_recipe": {
            "objective": "balanced_binary_contrast_shared_across_raw_passive_active_evidence",
            "lora_layers": 8,
            "iterations": 300,
            "learning_rate": 2e-5,
            "gradient_accumulation_steps": 4,
            "checkpoint_interval": 75,
            "max_sequence_length": 1400,
            "seed": 38,
        },
        "feasibility_gates": {
            "minimum_full_enumeration_semantic_accuracy": 0.98,
            "minimum_full_enumeration_preservation": 1.0,
            "minimum_active_deterministic_exact_coverage_at_k": 0.95,
            "minimum_active_deterministic_semantic_accuracy": 0.95,
        },
        "model_gates": {
            "minimum_scoring_completeness": 1.0,
            "minimum_active_exact_coverage_at_k": 0.85,
            "minimum_active_semantic_accuracy": 0.90,
            "minimum_active_preservation": 1.0,
            "minimum_active_heldout_semantic_accuracy": 0.85,
            "minimum_active_target_node_top1_accuracy": 0.70,
            "minimum_active_target_value_top1_given_node_accuracy": 0.75,
            "minimum_active_exact_coverage_gain_over_raw": 0.20,
        },
        "claim_boundary": (
            "M38 isolates whether externally executed observed and diagnostic counterfactual signatures make "
            "finite typed repair attribution learnable. Diagnostic cases are excluded from final scoring. "
            "M38 does not test open-vocabulary concept invention."
        ),
        "pretraining_validation": (
            "Signatures use compact case/match vectors so every record fits the frozen context. This "
            "representation was validated before any M38 model training or evaluation."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m38_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "mixed_train": output / "mixed_evidence/train.jsonl",
        "mixed_valid": output / "mixed_evidence/valid.jsonl",
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    train_text = paths["mixed_train"].read_text(encoding="utf-8")
    train_ids = {task.task_id for task in build_m38_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    valid_ids = {task.task_id for task in build_m38_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    test_ids = {task.task_id for task in build_m38_suite("test", 30)}
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": (
            content_digest({key: value for key, value in freeze.items() if key != "freeze_id"})
            == freeze["freeze_id"]
        ),
        "heldout_representations_absent_from_training": (
            '\"representation\": \"program\"' not in train_text
            and '\"representation\": \"planning\"' not in train_text
        ),
        "all_evidence_modes_present_in_training": all(
            f'\"evidence_mode\": \"{mode}\"' in train_text for mode in EVIDENCE_MODES
        ),
        "splits_are_disjoint": not (train_ids & valid_ids or train_ids & test_ids or valid_ids & test_ids),
        "test_not_exposed_to_mlx": not (output / "mixed_evidence/test.jsonl").exists(),
        "gates_and_recipe_frozen": (
            "feasibility_gates" in freeze
            and "model_gates" in freeze
            and "training_recipe" in freeze
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}


def run_m38_baselines(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m38_suite("test", 30)
    full = aggregate_proposal_sets(
        "full_enumeration",
        tasks,
        [enumerate_interventions(task) for task in tasks],
        proposal_budget=None,
    )
    random_result = aggregate_proposal_sets(
        "random_k4", tasks, [random_m38_proposals(task) for task in tasks]
    )
    signature_results: Dict[str, Mapping[str, Any]] = {}
    ranked_records = {}
    for mode in ("passive", "active"):
        ranked = [deterministic_signature_ranking(task, mode) for task in tasks]
        result = aggregate_proposal_sets(
            f"deterministic_{mode}_signature",
            tasks,
            [item[0][:PROPOSAL_BUDGET] for item in ranked],
        )
        signature_results[mode] = {
            "metrics": result["metrics"],
            "ambiguity": signature_ambiguity(tasks, mode),
        }
        ranked_records[mode] = [
            {"task_id": task.task_id, "ranked_edits": list(item[1])}
            for task, item in zip(tasks, ranked)
        ]
    gates = freeze["feasibility_gates"]
    active = signature_results["active"]["metrics"]
    checks = {
        "full_semantic_accuracy": (
            full["metrics"]["selected_semantic_accuracy"]
            >= gates["minimum_full_enumeration_semantic_accuracy"]
        ),
        "full_preservation": (
            full["metrics"]["selected_preserved_correct_accuracy"]
            >= gates["minimum_full_enumeration_preservation"]
        ),
        "active_deterministic_exact_coverage": (
            active["exact_repair_coverage_at_k"]
            >= gates["minimum_active_deterministic_exact_coverage_at_k"]
        ),
        "active_deterministic_semantic_accuracy": (
            active["selected_semantic_accuracy"]
            >= gates["minimum_active_deterministic_semantic_accuracy"]
        ),
    }
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "counterfactual_signature_baselines",
        {
            "full_enumeration": full["records"],
            "random_k4": random_result["records"],
            "signature_rankings": ranked_records,
        },
    )
    payload = {
        "version": COUNTERFACTUAL_SIGNATURE_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "full_enumeration_metrics": full["metrics"],
        "random_k4_metrics": random_result["metrics"],
        "passive_signature": signature_results["passive"],
        "active_signature": signature_results["active"],
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
        "predictions_digest": predictions_digest,
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"counterfactual-signature-baselines-{manifest['evaluation_id']}", manifest)
    return manifest
