from __future__ import annotations

from typing import Any, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.representation_atlas_v52w import (
    absolute_metrics,
    ranking_metrics,
)


CROSS_CHANNEL_BINDING_VERSION = "general-cognitive-cross-channel-binding-v52x"
M52X_SEED = 53061
M52X_M52W_AUDIT_ID = (
    "f8e677f628223598a67ff909fb37250b3c356f4a3d0ca0b2a5b717aa8f2f46fe"
)

M52X_DESCRIPTOR_CHANNEL: Mapping[str, str] = {
    "canonical": "name",
    "designation_reference": "name",
    "method_identity": "name",
    "technique_alias": "name",
    "reference_designation": "name",
    "method_signature": "name",
    "technique_identity": "name",
    "terse_constraint": "principle",
    "invariant_abstraction": "principle",
    "contrastive_boundary": "principle",
    "governing_condition_reference": "principle",
    "decision_invariant_reference": "principle",
    "constraint_signature": "principle",
    "reference_governing_rule": "principle",
    "criterion_signature": "principle",
    "decision_rule_identity": "principle",
    "mechanistic_expansion": "action",
    "operational_trace": "action",
    "operational_behavior_reference": "action",
    "execution_pattern_reference": "action",
    "mechanism_trace_reference": "action",
    "reference_operation": "action",
    "behavior_signature": "action",
    "mechanism_identity": "action",
    "catalog_identifier": "name",
    "method_label_clue": "name",
    "algorithm_alias_marker": "name",
    "verification_identifier": "name",
    "algorithm_label_signature": "name",
    "method_alias_check": "name",
    "decision_criterion_statement": "principle",
    "invariant_clue": "principle",
    "constraint_rule_marker": "principle",
    "verification_criterion": "principle",
    "invariant_signature_check": "principle",
    "rule_identity_check": "principle",
    "runtime_operation_statement": "action",
    "execution_clue": "action",
    "behavior_trace_marker": "action",
    "verification_operation": "action",
    "execution_signature_check": "action",
    "behavior_identity_check": "action",
    "registry_designation": "name",
    "technique_reference_clue": "name",
    "method_alias_token": "name",
    "audit_designation": "name",
    "technique_signature_probe": "name",
    "method_identity_token": "name",
    "governing_test_statement": "principle",
    "criterion_reference_clue": "principle",
    "invariant_rule_token": "principle",
    "audit_governing_test": "principle",
    "criterion_signature_probe": "principle",
    "invariant_identity_token": "principle",
    "enacted_operation_statement": "action",
    "runtime_reference_clue": "action",
    "execution_trace_token": "action",
    "audit_enacted_operation": "action",
    "runtime_signature_probe": "action",
    "execution_identity_token": "action",
    "symmetric_catalogue_label": "name",
    "bidirectional_method_clue": "name",
    "paired_alias_key": "name",
    "reciprocal_audit_label": "name",
    "two_way_method_probe": "name",
    "paired_identity_key": "name",
    "symmetric_governing_rule": "principle",
    "bidirectional_criterion_clue": "principle",
    "paired_invariant_key": "principle",
    "reciprocal_audit_rule": "principle",
    "two_way_criterion_probe": "principle",
    "paired_rule_identity": "principle",
    "symmetric_runtime_operation": "action",
    "bidirectional_execution_clue": "action",
    "paired_behavior_key": "action",
    "reciprocal_audit_operation": "action",
    "two_way_execution_probe": "action",
    "paired_behavior_identity": "action",
    "evidence_frame_label": "name",
    "audit_grid_method": "name",
    "correspondence_card_name": "name",
    "verification_frame_label": "name",
    "mapping_grid_method": "name",
    "identity_card_name": "name",
    "transfer_frame_label": "name",
    "holdout_grid_method": "name",
    "validation_card_name": "name",
    "evidence_frame_rule": "principle",
    "audit_grid_criterion": "principle",
    "correspondence_card_rule": "principle",
    "verification_frame_rule": "principle",
    "mapping_grid_criterion": "principle",
    "identity_card_rule": "principle",
    "transfer_frame_rule": "principle",
    "holdout_grid_criterion": "principle",
    "validation_card_rule": "principle",
    "evidence_frame_operation": "action",
    "audit_grid_execution": "action",
    "correspondence_card_behavior": "action",
    "verification_frame_operation": "action",
    "mapping_grid_execution": "action",
    "identity_card_behavior": "action",
    "transfer_frame_operation": "action",
    "holdout_grid_execution": "action",
    "validation_card_behavior": "action",
    "semantic_transfer_label": "name",
    "family_holdout_method": "name",
    "concept_bridge_name": "name",
    "novel_family_label": "name",
    "unseen_domain_method": "name",
    "semantic_bridge_name": "name",
    "blind_transfer_label": "name",
    "sealed_family_method": "name",
    "latent_concept_name": "name",
    "independent_transfer_label": "name",
    "quarantine_family_method": "name",
    "final_concept_name": "name",
    "semantic_transfer_rule": "principle",
    "family_holdout_criterion": "principle",
    "concept_bridge_rule": "principle",
    "novel_family_rule": "principle",
    "unseen_domain_criterion": "principle",
    "semantic_bridge_rule": "principle",
    "blind_transfer_rule": "principle",
    "sealed_family_criterion": "principle",
    "latent_concept_rule": "principle",
    "independent_transfer_rule": "principle",
    "quarantine_family_criterion": "principle",
    "final_concept_rule": "principle",
    "semantic_transfer_operation": "action",
    "family_holdout_execution": "action",
    "concept_bridge_behavior": "action",
    "novel_family_operation": "action",
    "unseen_domain_execution": "action",
    "semantic_bridge_behavior": "action",
    "blind_transfer_operation": "action",
    "sealed_family_execution": "action",
    "latent_concept_behavior": "action",
    "independent_transfer_operation": "action",
    "quarantine_family_execution": "action",
    "final_concept_behavior": "action",
    **{
        f"{prefix}_{channel}_{style}": channel
        for prefix in (
            "episodic",
            "relational_audit",
            "unseen_diagnosis",
            "family_review",
            "quarantined_check",
            "independent_confirmation",
        )
        for channel in ("name", "principle", "action")
        for style in range(2)
    },
    **{
        f"{prefix}_{channel}_{style}": channel
        for prefix in (
            "joint_relation",
            "pair_equivalence",
            "unseen_concept",
            "novel_equivalence",
            "quarantined_pair",
            "independent_equivalence",
        )
        for channel in ("name", "principle", "action")
        for style in range(2)
    },
    **{
        f"{prefix}_{channel}_{style}": channel
        for prefix in (
            "factorized_check",
            "role_separated_trial",
            "unseen_factor",
            "novel_role_binding",
            "quarantined_factor",
            "independent_factor",
        )
        for channel in ("name", "principle", "action")
        for style in range(2)
    },
    **{
        f"{prefix}_{channel}_{style}": channel
        for prefix in (
            "interaction_correspondence",
            "joint_role_factor",
            "unseen_interaction",
            "novel_joint_factor",
            "quarantined_interaction",
            "independent_interaction",
        )
        for channel in ("name", "principle", "action")
        for style in range(2)
    },
}

M52X_TRAINED_DIRECTIONS = (
    "name->principle",
    "principle->name",
    "principle->action",
    "action->principle",
)
M52X_HELDOUT_DIRECTIONS = ("name->action", "action->name")
M52X_ALIGNED_DIRECTIONS = ("name->name", "principle->principle", "action->action")

M52X_PROBE_STYLE_PAIRS = {
    "name->principle": ("canonical", "terse_constraint"),
    "principle->name": ("terse_constraint", "canonical"),
    "principle->action": ("terse_constraint", "mechanistic_expansion"),
    "action->principle": ("mechanistic_expansion", "terse_constraint"),
    "name->name": ("canonical", "canonical"),
    "principle->principle": ("terse_constraint", "terse_constraint"),
    "action->action": ("mechanistic_expansion", "mechanistic_expansion"),
}


def descriptor_direction(row: Mapping[str, Any]) -> str:
    metadata = row.get("metadata", row)
    basis = M52X_DESCRIPTOR_CHANNEL[str(metadata["basis_transformation"])]
    candidate = M52X_DESCRIPTOR_CHANNEL[str(metadata["candidate_transformation"])]
    return f"{basis}->{candidate}"


def select_directions(
    rows: Sequence[Mapping[str, Any]], directions: Sequence[str]
) -> Tuple[Mapping[str, Any], ...]:
    allowed = set(directions)
    return tuple(row for row in rows if descriptor_direction(row) in allowed)


def select_probe_rows(
    rows: Sequence[Mapping[str, Any]], directions: Sequence[str]
) -> Tuple[Mapping[str, Any], ...]:
    allowed = set(directions)
    selected = []
    for row in rows:
        direction = descriptor_direction(row)
        if direction not in allowed:
            continue
        metadata = row["metadata"]
        expected = M52X_PROBE_STYLE_PAIRS[direction]
        if (
            str(metadata["basis_transformation"]),
            str(metadata["candidate_transformation"]),
        ) == expected:
            selected.append(row)
    return tuple(selected)


def _sliced_metrics(
    records: Sequence[Mapping[str, Any]], key: str
) -> Mapping[str, Mapping[str, Any]]:
    values = sorted({str(row[key]) for row in records})
    return {
        value: {
            "ranking": ranking_metrics(
                [row for row in records if str(row[key]) == value]
            ),
            "absolute": absolute_metrics(
                [row for row in records if str(row[key]) == value]
            ),
        }
        for value in values
    }


def binding_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    enriched = tuple(
        {**row, "descriptor_direction": descriptor_direction(row)} for row in records
    )
    return {
        "ranking": ranking_metrics(enriched),
        "absolute": absolute_metrics(enriched),
        "by_direction": _sliced_metrics(enriched, "descriptor_direction"),
        "by_family": _sliced_metrics(enriched, "family"),
    }


def probe_gate_passed(
    cross_metrics: Mapping[str, Any],
    aligned_metrics: Mapping[str, Any],
    contract: Mapping[str, float],
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_training_cross_ranking_accuracy": float(
            cross_metrics["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_training_cross_ranking_accuracy"]),
        "minimum_training_cross_top1_accuracy": float(
            cross_metrics["ranking"]["top1_accuracy"]
        )
        >= float(contract["minimum_training_cross_top1_accuracy"]),
        "minimum_each_trained_direction_ranking_accuracy": min(
            float(row["ranking"]["ranking_accuracy"])
            for row in cross_metrics["by_direction"].values()
        )
        >= float(contract["minimum_each_trained_direction_ranking_accuracy"]),
        "minimum_each_training_family_ranking_accuracy": min(
            float(row["ranking"]["ranking_accuracy"])
            for row in cross_metrics["by_family"].values()
        )
        >= float(contract["minimum_each_training_family_ranking_accuracy"]),
        "minimum_aligned_ranking_accuracy": float(
            aligned_metrics["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_aligned_ranking_accuracy"]),
        "minimum_aligned_top1_accuracy": float(
            aligned_metrics["ranking"]["top1_accuracy"]
        )
        >= float(contract["minimum_aligned_top1_accuracy"]),
    }
    return all(checks.values()), checks


def full_installation_gate_passed(
    cross_metrics: Mapping[str, Any],
    aligned_metrics: Mapping[str, Any],
    parent_aligned_metrics: Mapping[str, Any],
    contract: Mapping[str, float],
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_training_cross_ranking_accuracy": float(
            cross_metrics["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_training_cross_ranking_accuracy"]),
        "minimum_training_cross_top1_accuracy": float(
            cross_metrics["ranking"]["top1_accuracy"]
        )
        >= float(contract["minimum_training_cross_top1_accuracy"]),
        "minimum_each_trained_direction_ranking_accuracy": min(
            float(row["ranking"]["ranking_accuracy"])
            for row in cross_metrics["by_direction"].values()
        )
        >= float(contract["minimum_each_trained_direction_ranking_accuracy"]),
        "minimum_each_training_family_ranking_accuracy": min(
            float(row["ranking"]["ranking_accuracy"])
            for row in cross_metrics["by_family"].values()
        )
        >= float(contract["minimum_each_training_family_ranking_accuracy"]),
        "minimum_aligned_ranking_accuracy": float(
            aligned_metrics["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_aligned_ranking_accuracy"]),
        "minimum_aligned_top1_accuracy": float(
            aligned_metrics["ranking"]["top1_accuracy"]
        )
        >= float(contract["minimum_aligned_top1_accuracy"]),
        "maximum_aligned_ranking_decline": float(
            aligned_metrics["ranking"]["ranking_accuracy"]
        )
        - float(parent_aligned_metrics["ranking"]["ranking_accuracy"])
        >= -float(contract["maximum_aligned_ranking_decline"]),
        "maximum_aligned_top1_decline": float(
            aligned_metrics["ranking"]["top1_accuracy"]
        )
        - float(parent_aligned_metrics["ranking"]["top1_accuracy"])
        >= -float(contract["maximum_aligned_top1_decline"]),
    }
    return all(checks.values()), checks


def adoption_gate_passed(
    repair: Mapping[str, Mapping[str, Any]],
    parent: Mapping[str, Mapping[str, Any]],
    contract: Mapping[str, float],
) -> Tuple[bool, Mapping[str, bool]]:
    def value(source: Mapping[str, Mapping[str, Any]], section: str, metric: str) -> float:
        return float(source[section]["ranking"][metric])

    development_families = repair["development_all"]["by_family"]
    checks = {
        "minimum_discovery_held_direction_ranking_accuracy": value(
            repair, "discovery_held", "ranking_accuracy"
        )
        >= float(contract["minimum_discovery_held_direction_ranking_accuracy"]),
        "minimum_discovery_held_direction_ranking_delta": value(
            repair, "discovery_held", "ranking_accuracy"
        )
        - value(parent, "discovery_held", "ranking_accuracy")
        >= float(contract["minimum_discovery_held_direction_ranking_delta"]),
        "minimum_discovery_held_direction_top1_accuracy": value(
            repair, "discovery_held", "top1_accuracy"
        )
        >= float(contract["minimum_discovery_held_direction_top1_accuracy"]),
        "minimum_development_held_direction_ranking_accuracy": value(
            repair, "development_held", "ranking_accuracy"
        )
        >= float(contract["minimum_development_held_direction_ranking_accuracy"]),
        "minimum_development_held_direction_ranking_delta": value(
            repair, "development_held", "ranking_accuracy"
        )
        - value(parent, "development_held", "ranking_accuracy")
        >= float(contract["minimum_development_held_direction_ranking_delta"]),
        "minimum_development_held_direction_top1_accuracy": value(
            repair, "development_held", "top1_accuracy"
        )
        >= float(contract["minimum_development_held_direction_top1_accuracy"]),
        "minimum_development_cross_ranking_accuracy": value(
            repair, "development_cross", "ranking_accuracy"
        )
        >= float(contract["minimum_development_cross_ranking_accuracy"]),
        "minimum_development_cross_ranking_delta": value(
            repair, "development_cross", "ranking_accuracy"
        )
        - value(parent, "development_cross", "ranking_accuracy")
        >= float(contract["minimum_development_cross_ranking_delta"]),
        "minimum_development_cross_top1_accuracy": value(
            repair, "development_cross", "top1_accuracy"
        )
        >= float(contract["minimum_development_cross_top1_accuracy"]),
        "minimum_each_development_family_ranking_accuracy": min(
            float(row["ranking"]["ranking_accuracy"])
            for row in development_families.values()
        )
        >= float(contract["minimum_each_development_family_ranking_accuracy"]),
        "minimum_development_aligned_ranking_accuracy": value(
            repair, "development_aligned", "ranking_accuracy"
        )
        >= float(contract["minimum_development_aligned_ranking_accuracy"]),
        "maximum_development_aligned_ranking_decline": value(
            repair, "development_aligned", "ranking_accuracy"
        )
        - value(parent, "development_aligned", "ranking_accuracy")
        >= -float(contract["maximum_development_aligned_ranking_decline"]),
    }
    return all(checks.values()), checks


def select_earliest_probe_pass(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    passing = [row for row in candidates if bool(row["passed"])]
    return min(passing, key=lambda row: int(row["iteration"])) if passing else None
