from __future__ import annotations

from typing import Any, Mapping, Sequence, Tuple


CROSS_FITTED_COMPARATOR_SUPPORT_VERSION = (
    "general-cognitive-cross-fitted-comparator-support-v52n"
)
M52N_SEED = 52951
M52N_FOLD_COUNT = 4
M52N_M52M_AUDIT_ID = (
    "7acdc7b95b6f2ba7191badc923fff2f6e7b4c934349d951da22001287c4acbf8"
)


def build_crossfit_folds(
    families: Sequence[str], fold_count: int = M52N_FOLD_COUNT
) -> Tuple[Mapping[str, Any], ...]:
    ordered = tuple(sorted(str(value) for value in families))
    if len(ordered) != len(set(ordered)):
        raise ValueError("M52n cross-fit families must be unique")
    if fold_count < 2 or len(ordered) < fold_count:
        raise ValueError("M52n requires at least two populated cross-fit folds")
    folds = []
    for fold_index in range(int(fold_count)):
        heldout = tuple(
            family
            for index, family in enumerate(ordered)
            if index % int(fold_count) == fold_index
        )
        training = tuple(family for family in ordered if family not in heldout)
        if not heldout or not training:
            raise ValueError("M52n cross-fit fold may not be empty")
        folds.append(
            {
                "fold": fold_index,
                "seed": M52N_SEED + fold_index,
                "training_families": list(training),
                "heldout_families": list(heldout),
            }
        )
    return tuple(folds)


def crossfit_support_authorized(
    dossier: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    statuses = dossier["status_counts"]
    oracle_delta = float(dossier["oracle_metrics"]["balanced_accuracy"]) - float(
        dossier["independent_metrics"]["balanced_accuracy"]
    )
    checks = {
        "minimum_oracle_balanced_accuracy_delta": oracle_delta
        >= float(contract["minimum_oracle_balanced_accuracy_delta"]),
        "minimum_oracle_swap_pair_accuracy": float(
            dossier["oracle_metrics"]["swap_pair_accuracy"]
        )
        >= float(contract["minimum_oracle_swap_pair_accuracy"]),
        "minimum_recoverable_contrasts": int(statuses["joint_only_recoverable"])
        >= int(contract["minimum_recoverable_contrasts"]),
        "maximum_unavoidable_contrasts": int(statuses["neither_correct"])
        <= int(contract["maximum_unavoidable_contrasts"]),
        "minimum_recoverable_families": len(dossier["recoverable_families"])
        >= int(contract["minimum_recoverable_families"]),
        "minimum_recoverable_variants": len(dossier["recoverable_variants"])
        >= int(contract["minimum_recoverable_variants"]),
    }
    return all(checks.values()), checks
