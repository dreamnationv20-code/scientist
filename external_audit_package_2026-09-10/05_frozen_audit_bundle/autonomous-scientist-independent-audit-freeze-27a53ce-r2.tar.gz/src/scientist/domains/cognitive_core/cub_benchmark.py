from __future__ import annotations

import argparse
import json
import time
from dataclasses import dataclass
from pathlib import Path
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    Mapping,
    Optional,
    Sequence,
    Tuple,
)
from urllib.parse import urlencode
from urllib.request import urlopen
from urllib.error import HTTPError, URLError

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.prior_art import (
    evidence_utilization_scope_assessment,
)


CUB_ADAPTER_VERSION = "cognitive-core-cub-adapter-v1"
CUB_DATASET = "copenlu/cub-counterfact"
CUB_CONFIG = "qwen-1.5b-instruct"
CUB_SPLIT = "validation"
CUB_REPOSITORY = "https://github.com/copenlu/cmt-benchmark"
CUB_COMMIT = "f646e796047d22abcfdb2685e589911da6db587a"
CUB_ROWS_ENDPOINT = "https://datasets-server.huggingface.co/rows"
REQUIRED_FIELDS = frozenset(
    {
        "target_new",
        "pred",
        "pred_w_context",
        "context_type",
        "prompt",
        "prompt_w_context",
    }
)


def cub_row_id(row: Mapping[str, Any]) -> str:
    """Return the stable identifier used by any of the three CUB datasets."""

    for field in ("id", "example_id"):
        if field in row:
            return str(row[field])
    raise ValueError("CUB row has neither id nor example_id")


def _live_json(url: str) -> Mapping[str, Any]:
    last_error = None
    for attempt in range(4):
        try:
            with urlopen(url, timeout=30) as response:
                return json.load(response)
        except (HTTPError, URLError, TimeoutError) as error:
            last_error = error
            if attempt < 3:
                time.sleep(0.5 * (2**attempt))
    raise RuntimeError(
        "CUB dataset fetch failed after four attempts"
    ) from last_error


def fetch_cub_rows(
    dataset: str = CUB_DATASET,
    config: str = CUB_CONFIG,
    split: str = CUB_SPLIT,
    fetch_json: Callable[[str], Mapping[str, Any]] = _live_json,
    required_fields: Optional[Sequence[str]] = None,
) -> Tuple[Mapping[str, Any], ...]:
    required = frozenset(required_fields or REQUIRED_FIELDS)
    rows = []
    offset = 0
    total = None
    while total is None or offset < total:
        query = urlencode(
            {
                "dataset": dataset,
                "config": config,
                "split": split,
                "offset": offset,
                "length": 100,
            }
        )
        payload = fetch_json(CUB_ROWS_ENDPOINT + "?" + query)
        if payload.get("partial"):
            raise ValueError("CUB dataset response is partial")
        page = payload.get("rows")
        if not isinstance(page, list):
            raise ValueError("CUB dataset response has no rows")
        if total is None:
            total = int(payload["num_rows_total"])
        for item in page:
            if item.get("truncated_cells"):
                raise ValueError("CUB row contains truncated fields")
            row = item.get("row")
            if not isinstance(row, dict):
                raise ValueError("CUB row payload is malformed")
            missing = required.difference(row)
            if missing:
                raise ValueError(
                    "CUB row is missing fields: %s"
                    % ", ".join(sorted(missing))
                )
            cub_row_id(row)
            rows.append(dict(row))
        if not page:
            break
        offset += len(page)
    if total is None or len(rows) != total:
        raise ValueError(
            "CUB row count mismatch: fetched %d of %s"
            % (len(rows), total)
        )
    if len({cub_row_id(row) for row in rows}) != len(rows):
        raise ValueError("CUB row IDs are not unique")
    return tuple(rows)


def load_cub_jsonl(
    path: Path,
    required_fields: Optional[Sequence[str]] = None,
) -> Tuple[Mapping[str, Any], ...]:
    """Load and validate an official CUB JSONL snapshot."""

    required = frozenset(required_fields or REQUIRED_FIELDS)
    rows = []
    with path.open("r", encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(
                    "invalid CUB JSONL at line %d" % line_number
                ) from error
            if not isinstance(row, dict):
                raise ValueError(
                    "CUB JSONL line %d is not an object" % line_number
                )
            missing = required.difference(row)
            if missing:
                raise ValueError(
                    "CUB row is missing fields: %s"
                    % ", ".join(sorted(missing))
                )
            cub_row_id(row)
            rows.append(row)
    if not rows:
        raise ValueError("CUB JSONL is empty")
    if len({cub_row_id(row) for row in rows}) != len(rows):
        raise ValueError("CUB row IDs are not unique")
    return tuple(rows)


@dataclass(frozen=True)
class CubMetrics:
    context_accuracy_gold: float
    context_accuracy_edited: float
    memory_accuracy_irrelevant: float
    combined_score: float
    counts: Mapping[str, int]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "context_accuracy_gold": self.context_accuracy_gold,
            "context_accuracy_edited": self.context_accuracy_edited,
            "memory_accuracy_irrelevant": (
                self.memory_accuracy_irrelevant
            ),
            "combined_score": self.combined_score,
            "counts": dict(sorted(self.counts.items())),
        }


def evaluate_published_regular(
    rows: Sequence[Mapping[str, Any]],
    relevant_match: str = "prefix",
) -> CubMetrics:
    if relevant_match not in ("prefix", "exact"):
        raise ValueError("relevant_match must be prefix or exact")
    totals = {"gold": 0, "edited": 0, "irrelevant": 0}
    correct = {"gold": 0, "edited": 0, "irrelevant": 0}
    for row in rows:
        context_type = str(row["context_type"])
        if context_type not in totals:
            raise ValueError(
                "unsupported CUB context type %s" % context_type
            )
        totals[context_type] += 1
        prediction = str(row["pred_w_context"])
        if context_type in ("gold", "edited"):
            target = str(row["target_new"])
            if relevant_match == "prefix":
                matched = bool(prediction) and target.startswith(prediction)
            else:
                matched = prediction == target
            correct[context_type] += int(matched)
        else:
            correct[context_type] += int(
                prediction == str(row["pred"])
            )
    if any(not count for count in totals.values()):
        raise ValueError("CUB slice must contain all three context types")
    gold = correct["gold"] / totals["gold"]
    edited = correct["edited"] / totals["edited"]
    irrelevant = correct["irrelevant"] / totals["irrelevant"]
    return CubMetrics(
        context_accuracy_gold=gold,
        context_accuracy_edited=edited,
        memory_accuracy_irrelevant=irrelevant,
        combined_score=(gold + edited + irrelevant) / 3.0,
        counts={
            "gold": totals["gold"],
            "edited": totals["edited"],
            "irrelevant": totals["irrelevant"],
            "total": sum(totals.values()),
        },
    )


def run_published_baseline(
    output_root: Path,
    dataset: str = CUB_DATASET,
    config: str = CUB_CONFIG,
    split: str = CUB_SPLIT,
) -> Mapping[str, Any]:
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-baseline-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    rows = fetch_cub_rows(dataset, config, split)
    rows_digest = store.put(
        "cub_dataset_snapshot",
        {
            "dataset": dataset,
            "config": config,
            "split": split,
            "rows": list(rows),
        },
    )
    metrics = evaluate_published_regular(rows)
    payload = {
        "adapter_version": CUB_ADAPTER_VERSION,
        "dataset": dataset,
        "config": config,
        "split": split,
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "dataset_snapshot_digest": rows_digest,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "method": "published_regular_open_book_predictions",
        "metrics": metrics.as_dict(),
        "claim_boundary": (
            "Executable-incumbent reproduction only; this validates the "
            "CUB data and metric path and is not a candidate comparison."
        ),
    }
    baseline_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "baseline_id": baseline_id,
    }
    store.write_manifest(
        "cognitive-core-cub-baseline-" + baseline_id,
        manifest,
    )
    return manifest


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/cub_baseline_v1",
    )
    parser.add_argument("--dataset", default=CUB_DATASET)
    parser.add_argument("--config", default=CUB_CONFIG)
    parser.add_argument("--split", default=CUB_SPLIT)
    arguments = parser.parse_args(list(argv) or None)
    manifest = run_published_baseline(
        Path(arguments.output),
        arguments.dataset,
        arguments.config,
        arguments.split,
    )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
