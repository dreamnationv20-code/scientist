from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.cub_benchmark import (
    CUB_COMMIT,
    CUB_CONFIG,
    CUB_REPOSITORY,
    cub_row_id,
    load_cub_jsonl,
)
from scientist.domains.cognitive_core.cub_mlx_smoke import balanced_slice
from scientist.domains.cognitive_core.cub_semantic_router import (
    NQ_DATASET,
    _summary_for_responses,
    paired_relevance_changes,
    parse_relevance,
    target_literal_in_context,
)
from scientist.domains.cognitive_core.prior_art import (
    evidence_utilization_scope_assessment,
)


CUB_CAPACITY_UNION_VERSION = "cognitive-core-cub-capacity-union-v1"


def union_responses(
    first: Sequence[str],
    second: Sequence[str],
) -> Tuple[str, ...]:
    if len(first) != len(second):
        raise ValueError("capacity-union responses do not align")
    return tuple(
        (
            "Re"
            if (
                parse_relevance(left) is True
                or parse_relevance(right) is True
            )
            else "Ir"
        )
        for left, right in zip(first, second)
    )


def _response_map(
    root: Path,
    digest: str,
) -> Mapping[Tuple[str, str], str]:
    envelope = ArtifactStore(root).get(digest)
    if envelope["kind"] == "cub_semantic_relevance_predictions":
        return {
            (str(row["dataset"]), str(row["id"])): str(
                row["semantic_response"]
            )
            for row in envelope["value"]
        }
    if envelope["kind"] == "cub_frozen_veto_predictions":
        return {
            (str(row["dataset"]), str(row["id"])): str(
                row["official_response"]
            )
            for row in envelope["value"]
        }
    raise ValueError("unsupported relevance prediction artifact")


def run_capacity_union_evaluation(
    output_root: Path,
    dataset_jsonl: Path,
    first_root: Path,
    first_digest: str,
    second_root: Path,
    second_digest: str,
    dataset: str = NQ_DATASET,
    config: str = CUB_CONFIG,
    split: str = "test",
    per_context: int = 100,
    irrelevant_tolerance: float = 0.02,
) -> Mapping[str, Any]:
    started = time.monotonic()
    if dataset != NQ_DATASET:
        raise ValueError("capacity union v1 is frozen for CUB-NQ")
    rows = balanced_slice(load_cub_jsonl(dataset_jsonl), per_context)
    first_map = _response_map(first_root, first_digest)
    second_map = _response_map(second_root, second_digest)
    first = tuple(
        first_map[(dataset, cub_row_id(row))] for row in rows
    )
    second = tuple(
        second_map[(dataset, cub_row_id(row))] for row in rows
    )
    union = union_responses(first, second)
    selected_by_dataset = {dataset: rows}
    incumbent = _summary_for_responses(
        selected_by_dataset,
        {dataset: first},
    )
    candidate = _summary_for_responses(
        selected_by_dataset,
        {dataset: union},
    )
    changes = paired_relevance_changes(rows, first, union)
    incumbent_raw = incumbent["raw_metrics_by_dataset"][dataset]
    candidate_raw = candidate["raw_metrics_by_dataset"][dataset]
    raw_deltas = {
        context_type: (
            candidate_raw["accuracy_by_context"][context_type]
            - incumbent_raw["accuracy_by_context"][context_type]
        )
        for context_type in ("gold", "edited", "irrelevant")
    }
    balanced_delta = (
        candidate_raw["balanced_accuracy"]
        - incumbent_raw["balanced_accuracy"]
    )
    reasons = []
    if raw_deltas["gold"] < 0.0:
        reasons.append("gold relevance regressed")
    if raw_deltas["edited"] < 0.0:
        reasons.append("edited relevance regressed")
    if raw_deltas["irrelevant"] < -irrelevant_tolerance:
        reasons.append(
            "irrelevant accuracy delta %.3f is below -%.3f"
            % (raw_deltas["irrelevant"], irrelevant_tolerance)
        )
    if balanced_delta <= 0.0:
        reasons.append("balanced accuracy did not improve")
    if changes["net_corrections"] <= 0:
        reasons.append("paired net corrections are not positive")
    survived = not reasons

    records = [
        {
            "dataset": dataset,
            "id": cub_row_id(row),
            "context_type": row["context_type"],
            "answer_bearing_irrelevant": (
                str(row["context_type"]) == "irrelevant"
                and target_literal_in_context(row, dataset)
            ),
            "first_response": left,
            "second_response": right,
            "union_response": routed,
            "changed": routed != left,
        }
        for row, left, right, routed in zip(
            rows,
            first,
            second,
            union,
        )
    ]
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        CUB_CAPACITY_UNION_VERSION
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    predictions_digest = store.put(
        "cub_capacity_union_predictions",
        records,
    )
    payload = {
        "union_version": CUB_CAPACITY_UNION_VERSION,
        "evaluation_mode": "heldout_frozen_capacity_union",
        "dataset": dataset,
        "config": config,
        "split": split,
        "selection": {
            "method": "first_n_per_context_in_published_order",
            "per_context": per_context,
            "total": len(rows),
        },
        "dataset_jsonl": str(dataset_jsonl),
        "first_predictions": {
            "root": str(first_root),
            "digest": first_digest,
            "role": "1.5B published-prompt incumbent",
        },
        "second_predictions": {
            "root": str(second_root),
            "digest": second_digest,
            "role": "3B published-prompt capacity control",
        },
        "routing_rule": (
            "Relevant iff either frozen judge predicts Relevant; "
            "otherwise Irrelevant"
        ),
        "irrelevant_tolerance": irrelevant_tolerance,
        "incumbent_summary": incumbent,
        "candidate_summary": candidate,
        "raw_accuracy_delta_by_context": raw_deltas,
        "raw_balanced_accuracy_delta": balanced_delta,
        "paired_changes": changes,
        "survived_exploratory_holdout_gate": survived,
        "gate_reasons": reasons,
        "predictions_digest": predictions_digest,
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "This simple union was chosen on validation after the 3B "
            "capacity control. Validation missed the audited distractor "
            "gate by one case, so this is explicitly exploratory held-out "
            "evidence. It is an ensemble of established relevance judges, "
            "not novelty and not a complete cognitive-core solution."
        ),
        "next_action": (
            "If the exploratory gate survives, test downstream answer "
            "routing and then replicate on an untouched dataset. If it "
            "fails, close the prompt-capacity branch."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "evaluation_id": evaluation_id,
    }
    store.write_manifest(
        "cognitive-core-cub-capacity-union-" + evaluation_id,
        manifest,
    )
    return manifest


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/cub_capacity_union_test_v1",
    )
    parser.add_argument("--dataset-jsonl", required=True)
    parser.add_argument("--first-root", required=True)
    parser.add_argument("--first-digest", required=True)
    parser.add_argument("--second-root", required=True)
    parser.add_argument("--second-digest", required=True)
    parser.add_argument("--per-context", type=int, default=100)
    arguments = parser.parse_args(list(argv) or None)
    manifest = run_capacity_union_evaluation(
        Path(arguments.output),
        Path(arguments.dataset_jsonl),
        Path(arguments.first_root),
        arguments.first_digest,
        Path(arguments.second_root),
        arguments.second_digest,
        per_context=arguments.per_context,
    )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
