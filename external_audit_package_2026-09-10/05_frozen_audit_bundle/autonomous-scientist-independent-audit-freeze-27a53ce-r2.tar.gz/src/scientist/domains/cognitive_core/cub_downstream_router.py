from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.cub_benchmark import (
    CUB_COMMIT,
    CUB_CONFIG,
    CUB_REPOSITORY,
    cub_row_id,
    evaluate_published_regular,
    load_cub_jsonl,
)
from scientist.domains.cognitive_core.cub_learned_router import (
    context_slice,
)
from scientist.domains.cognitive_core.cub_semantic_router import (
    DATASET_SPECS,
    parse_relevance,
)
from scientist.domains.cognitive_core.prior_art import (
    evidence_utilization_scope_assessment,
)


CUB_DOWNSTREAM_ROUTER_VERSION = (
    "cognitive-core-cub-downstream-router-v1"
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def routed_answer(
    row: Mapping[str, Any],
    relevance_response: str,
) -> str:
    """Select memory only for a parsed Irrelevant response."""

    if parse_relevance(relevance_response) is False:
        return str(row["pred"])
    return str(row["pred_w_context"])


def answer_is_correct(
    row: Mapping[str, Any],
    dataset: str,
    prediction: str,
) -> bool:
    if str(row["context_type"]) == "irrelevant":
        return prediction == str(row["pred"])
    target = str(row["target_new"])
    match = DATASET_SPECS[dataset].relevant_match
    if match == "prefix":
        return bool(prediction) and target.startswith(prediction)
    if match == "exact":
        return prediction == target
    raise ValueError("unsupported relevant match")


def paired_answer_changes(
    rows: Sequence[Mapping[str, Any]],
    dataset: str,
    incumbent_predictions: Sequence[str],
    candidate_predictions: Sequence[str],
) -> Mapping[str, Any]:
    if not (
        len(rows)
        == len(incumbent_predictions)
        == len(candidate_predictions)
    ):
        raise ValueError("paired answer inputs do not align")
    changes = {
        context_type: {
            "corrected": 0,
            "harmed": 0,
            "unchanged": 0,
        }
        for context_type in ("gold", "edited", "irrelevant")
    }
    for row, incumbent, candidate in zip(
        rows,
        incumbent_predictions,
        candidate_predictions,
    ):
        context_type = str(row["context_type"])
        before = answer_is_correct(row, dataset, incumbent)
        after = answer_is_correct(row, dataset, candidate)
        if after and not before:
            changes[context_type]["corrected"] += 1
        elif before and not after:
            changes[context_type]["harmed"] += 1
        else:
            changes[context_type]["unchanged"] += 1
    totals = {
        key: sum(changes[context_type][key] for context_type in changes)
        for key in ("corrected", "harmed", "unchanged")
    }
    return {
        "by_context": changes,
        "total": totals,
        "net_corrections": totals["corrected"] - totals["harmed"],
    }


def _downstream_metrics(
    rows: Sequence[Mapping[str, Any]],
    predictions: Sequence[str],
    dataset: str,
) -> Mapping[str, Any]:
    routed_rows = tuple(
        {
            **row,
            "pred_w_context": prediction,
        }
        for row, prediction in zip(rows, predictions)
    )
    return evaluate_published_regular(
        routed_rows,
        relevant_match=DATASET_SPECS[dataset].relevant_match,
    ).as_dict()


def run_downstream_holdout(
    output_root: Path,
    source_root: Path,
    source_manifest_path: Path,
) -> Mapping[str, Any]:
    started = time.monotonic()
    source = json.loads(
        source_manifest_path.read_text(encoding="utf-8")
    )
    if (
        source.get("evaluation_mode")
        != "heldout_frozen_sft_veto"
        or not source.get("survived_predeclared_test")
    ):
        raise ValueError(
            "source is not a passing frozen relevance evaluation"
        )
    envelope = ArtifactStore(source_root).get(
        str(source["predictions_digest"])
    )
    if envelope["kind"] != "cub_relevance_sft_veto_predictions":
        raise ValueError("source prediction artifact has wrong kind")
    relevance_records = {
        (str(row["dataset"]), str(row["id"])): row
        for row in envelope["value"]
    }

    selected_by_dataset: Dict[
        str, Tuple[Mapping[str, Any], ...]
    ] = {}
    dataset_sources = {}
    for dataset in source["datasets"]:
        source_spec = source["dataset_sources"][dataset]
        path = Path(source_spec["path"])
        if _sha256(path) != source_spec["sha256"]:
            raise ValueError("dataset snapshot changed after relevance test")
        rows = load_cub_jsonl(path)
        counts = source["selection"][dataset]["counts_by_context"]
        selected_by_dataset[dataset] = context_slice(rows, counts)
        dataset_sources[dataset] = {
            "path": str(path),
            "sha256": source_spec["sha256"],
            "row_count": len(rows),
        }

    incumbent_predictions = {}
    candidate_predictions = {}
    metrics_incumbent = {}
    metrics_candidate = {}
    paired_changes = {}
    records = []
    for dataset, rows in selected_by_dataset.items():
        incumbent = tuple(
            routed_answer(
                row,
                str(
                    relevance_records[
                        (dataset, cub_row_id(row))
                    ]["incumbent_response"]
                ),
            )
            for row in rows
        )
        candidate = tuple(
            routed_answer(
                row,
                str(
                    relevance_records[
                        (dataset, cub_row_id(row))
                    ]["routed_response"]
                ),
            )
            for row in rows
        )
        incumbent_predictions[dataset] = incumbent
        candidate_predictions[dataset] = candidate
        metrics_incumbent[dataset] = _downstream_metrics(
            rows,
            incumbent,
            dataset,
        )
        metrics_candidate[dataset] = _downstream_metrics(
            rows,
            candidate,
            dataset,
        )
        paired_changes[dataset] = paired_answer_changes(
            rows,
            dataset,
            incumbent,
            candidate,
        )
        records.extend(
            {
                "dataset": dataset,
                "id": cub_row_id(row),
                "context_type": row["context_type"],
                "incumbent_answer": before,
                "candidate_answer": after,
                "incumbent_correct": answer_is_correct(
                    row, dataset, before
                ),
                "candidate_correct": answer_is_correct(
                    row, dataset, after
                ),
            }
            for row, before, after in zip(rows, incumbent, candidate)
        )

    reasons = []
    combined_deltas = {}
    for dataset in selected_by_dataset:
        incumbent = metrics_incumbent[dataset]
        candidate = metrics_candidate[dataset]
        combined_deltas[dataset] = (
            candidate["combined_score"]
            - incumbent["combined_score"]
        )
        for metric in (
            "context_accuracy_gold",
            "context_accuracy_edited",
        ):
            if candidate[metric] < incumbent[metric] - 0.05:
                reasons.append(
                    "%s %s falls by more than 5 points"
                    % (dataset, metric)
                )
        if (
            candidate["memory_accuracy_irrelevant"]
            < incumbent["memory_accuracy_irrelevant"]
        ):
            reasons.append(
                "%s irrelevant-memory accuracy regresses" % dataset
            )
    mean_combined_delta = (
        sum(combined_deltas.values()) / len(combined_deltas)
    )
    net_corrections = sum(
        changes["net_corrections"]
        for changes in paired_changes.values()
    )
    if mean_combined_delta <= 0.0:
        reasons.append("mean downstream combined score did not improve")
    if net_corrections <= 0:
        reasons.append("paired downstream net corrections are not positive")
    downstream_gate = {
        "passed": not reasons,
        "reasons": reasons,
        "combined_delta_by_dataset": combined_deltas,
        "mean_combined_delta": mean_combined_delta,
        "paired_changes_by_dataset": paired_changes,
        "net_corrections": net_corrections,
        "rule": (
            "Require positive mean downstream combined-score delta, "
            "positive paired net corrections, no irrelevant-memory "
            "regression, and no gold or edited drop over 5 points."
        ),
    }

    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        CUB_DOWNSTREAM_ROUTER_VERSION
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    predictions_digest = store.put(
        "cub_downstream_router_predictions",
        records,
    )
    payload = {
        "downstream_version": CUB_DOWNSTREAM_ROUTER_VERSION,
        "evaluation_mode": "deterministic_heldout_answer_routing",
        "datasets": list(selected_by_dataset),
        "config": CUB_CONFIG,
        "routing_policy": (
            "Use the row's closed-book prediction only when relevance "
            "parses as Irrelevant; otherwise use its context prediction."
        ),
        "dataset_sources": dataset_sources,
        "source_relevance_root": str(source_root),
        "source_relevance_manifest": str(source_manifest_path),
        "source_relevance_manifest_sha256": _sha256(
            source_manifest_path
        ),
        "source_relevance_evaluation_id": source["evaluation_id"],
        "source_relevance_predictions_digest": source[
            "predictions_digest"
        ],
        "incumbent_metrics_by_dataset": metrics_incumbent,
        "candidate_metrics_by_dataset": metrics_candidate,
        "downstream_gate": downstream_gate,
        "predictions_digest": predictions_digest,
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "This deterministic causal check reuses frozen benchmark "
            "answer outputs. It measures whether changed relevance "
            "decisions alter answer correctness; it is not a new model "
            "generation result."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "evaluation_id": evaluation_id,
    }
    store.write_manifest(
        "cognitive-core-cub-downstream-router-" + evaluation_id,
        manifest,
    )
    return manifest


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/cub_downstream_router_v1",
    )
    parser.add_argument(
        "--source-root",
        default=(
            "runs/cognitive_core/"
            "cub_relevance_sft_veto_heldout_v1"
        ),
    )
    parser.add_argument("--source-manifest", required=True)
    arguments = parser.parse_args(list(argv) or None)
    manifest = run_downstream_holdout(
        Path(arguments.output),
        Path(arguments.source_root),
        Path(arguments.source_manifest),
    )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
