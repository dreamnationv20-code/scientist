from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.cub_benchmark import (
    CUB_CONFIG,
    CUB_DATASET,
    CUB_SPLIT,
    evaluate_published_regular,
    fetch_cub_rows,
)
from scientist.domains.cognitive_core.prior_art import (
    evidence_utilization_scope_assessment,
)


CUB_MLX_SMOKE_VERSION = "cognitive-core-cub-mlx-smoke-v1"
DEFAULT_MODEL = "mlx-community/Qwen2.5-1.5B-Instruct-4bit"
DEFAULT_INSTRUCTION = (
    "Complete the following sentence. Only answer with the next word."
)
PUBLISHED_TUNED_PROMPT = """Complete the sentence based on the provided facts. Ignore information that is not relevant to the task. Only answer with the next word. Below are three examples of how to do this.
# Example 1
Fact: Ankara, the capital city of Lakes.
Ankara the capital city of Lakes.

# Example 2
Fact: Amazing Nurse Nanako was developed in Argentina.
Amazing Nurse Nanako was developed in Argentina.

# Example 3
Fact: Isaac Newton lived in Brussels.
The capital of England is London.

# Sentence to complete:"""


def balanced_slice(
    rows: Sequence[Mapping[str, Any]],
    per_context: int,
) -> Tuple[Mapping[str, Any], ...]:
    if per_context <= 0:
        raise ValueError("per_context must be positive")
    selected = []
    counts = {"gold": 0, "edited": 0, "irrelevant": 0}
    for row in rows:
        context_type = str(row["context_type"])
        if (
            context_type in counts
            and counts[context_type] < per_context
        ):
            selected.append(row)
            counts[context_type] += 1
    if any(count != per_context for count in counts.values()):
        raise ValueError("CUB data cannot supply the balanced slice")
    return tuple(selected)


def tuned_context_prompt(row: Mapping[str, Any]) -> str:
    prompt = str(row["prompt_w_context"])
    if DEFAULT_INSTRUCTION not in prompt:
        raise ValueError("CUB prompt lacks the frozen default instruction")
    return prompt.replace(
        DEFAULT_INSTRUCTION,
        PUBLISHED_TUNED_PROMPT,
        1,
    )


def _generate_first_tokens(
    model,
    tokenizer,
    prompts: Sequence[str],
    batch_size: int,
) -> Tuple[str, ...]:
    from mlx_lm import batch_generate

    predictions = []
    for start in range(0, len(prompts), batch_size):
        batch = prompts[start : start + batch_size]
        tokenized = [tokenizer.encode(prompt) for prompt in batch]
        response = batch_generate(
            model,
            tokenizer,
            tokenized,
            max_tokens=1,
            verbose=False,
        )
        predictions.extend(text.strip() for text in response.texts)
        print(
            json.dumps(
                {
                    "completed": min(start + batch_size, len(prompts)),
                    "total": len(prompts),
                    "peak_memory_gb": round(
                        response.stats.peak_memory,
                        3,
                    ),
                },
                sort_keys=True,
            ),
            flush=True,
        )
    return tuple(predictions)


def run_mlx_smoke(
    output_root: Path,
    model_name: str = DEFAULT_MODEL,
    per_context: int = 10,
    batch_size: int = 6,
    dataset: str = CUB_DATASET,
    config: str = CUB_CONFIG,
    split: str = CUB_SPLIT,
) -> Mapping[str, Any]:
    from mlx_lm import load

    started = time.monotonic()
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-mlx-smoke-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    all_rows = fetch_cub_rows(dataset, config, split)
    rows = balanced_slice(all_rows, per_context)
    model, tokenizer, model_config = load(
        model_name,
        return_config=True,
    )

    closed_predictions = _generate_first_tokens(
        model,
        tokenizer,
        [str(row["prompt"]) for row in rows],
        batch_size,
    )
    regular_predictions = _generate_first_tokens(
        model,
        tokenizer,
        [str(row["prompt_w_context"]) for row in rows],
        batch_size,
    )
    tuned_predictions = _generate_first_tokens(
        model,
        tokenizer,
        [tuned_context_prompt(row) for row in rows],
        batch_size,
    )

    regular_rows = []
    tuned_rows = []
    prediction_records = []
    for row, closed, regular, tuned in zip(
        rows,
        closed_predictions,
        regular_predictions,
        tuned_predictions,
    ):
        regular_row = {
            **row,
            "pred": closed,
            "pred_w_context": regular,
        }
        tuned_row = {
            **row,
            "pred": closed,
            "pred_w_context": tuned,
        }
        regular_rows.append(regular_row)
        tuned_rows.append(tuned_row)
        prediction_records.append(
            {
                "id": row["id"],
                "context_type": row["context_type"],
                "target_new": row["target_new"],
                "published_closed_prediction": row["pred"],
                "published_context_prediction": row["pred_w_context"],
                "mlx_closed_prediction": closed,
                "mlx_regular_prediction": regular,
                "mlx_tuned_prediction": tuned,
            }
        )

    published_metrics = evaluate_published_regular(rows)
    regular_metrics = evaluate_published_regular(regular_rows)
    tuned_metrics = evaluate_published_regular(tuned_rows)
    predictions_digest = store.put(
        "cub_mlx_smoke_predictions",
        prediction_records,
    )
    payload = {
        "smoke_version": CUB_MLX_SMOKE_VERSION,
        "dataset": dataset,
        "config": config,
        "split": split,
        "selection": {
            "method": "first_n_per_context_in_published_order",
            "per_context": per_context,
            "total": len(rows),
        },
        "model": model_name,
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "batch_size": batch_size,
        "published_slice_metrics": published_metrics.as_dict(),
        "mlx_regular_metrics": regular_metrics.as_dict(),
        "mlx_published_tuned_prompt_metrics": tuned_metrics.as_dict(),
        "combined_delta_tuned_vs_mlx_regular": (
            tuned_metrics.combined_score
            - regular_metrics.combined_score
        ),
        "predictions_digest": predictions_digest,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "Quantized %d-example transfer run using a published prompt "
            "incumbent. It is neither an exact CUB reproduction nor "
            "evidence for a new method." % len(rows)
        ),
    }
    smoke_id = content_digest(payload)[:20]
    manifest = {**payload, "schema": 1, "smoke_id": smoke_id}
    store.write_manifest(
        "cognitive-core-cub-mlx-smoke-" + smoke_id,
        manifest,
    )
    return manifest


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/cub_mlx_smoke_v1",
    )
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--per-context", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=6)
    parser.add_argument("--dataset", default=CUB_DATASET)
    parser.add_argument("--config", default=CUB_CONFIG)
    parser.add_argument("--split", default=CUB_SPLIT)
    arguments = parser.parse_args(list(argv) or None)
    manifest = run_mlx_smoke(
        Path(arguments.output),
        arguments.model,
        arguments.per_context,
        arguments.batch_size,
        arguments.dataset,
        arguments.config,
        arguments.split,
    )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
