from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.cub_benchmark import (
    CUB_COMMIT,
    CUB_CONFIG,
    CUB_REPOSITORY,
    cub_row_id,
    load_cub_jsonl,
)
from scientist.domains.cognitive_core.cub_learned_router import (
    _fold_for_group,
    context_slice,
    group_id,
    learned_router_admissibility,
)
from scientist.domains.cognitive_core.cub_mlx_smoke import DEFAULT_MODEL
from scientist.domains.cognitive_core.cub_semantic_router import (
    DRUID_DATASET,
    NQ_DATASET,
    _chat_prompt,
    _generate_relevance_labels,
    _generate_relevance_margins,
    _summary_for_responses,
    expected_relevant,
    paired_relevance_changes,
    parse_relevance,
    relevance_prompt,
)
from scientist.domains.cognitive_core.prior_art import (
    evidence_utilization_scope_assessment,
)


CUB_RELEVANCE_SFT_DATA_VERSION = "cognitive-core-cub-relevance-sft-data-v1"
CUB_RELEVANCE_SFT_EVAL_VERSION = "cognitive-core-cub-relevance-sft-eval-v1"
CUB_RELEVANCE_SFT_VETO_VERSION = (
    "cognitive-core-cub-relevance-sft-veto-v1"
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _chat_record(
    row: Mapping[str, Any],
    dataset: str,
) -> Mapping[str, Any]:
    return {
        "messages": [
            {
                "role": "user",
                "content": relevance_prompt(row, dataset),
            },
            {
                "role": "assistant",
                "content": (
                    "Relevant"
                    if expected_relevant(row)
                    else "Irrelevant"
                ),
            },
        ],
        "metadata": {
            "dataset": dataset,
            "id": cub_row_id(row),
            "group_id": group_id(row, dataset),
            "context_type": row["context_type"],
        },
    }


def prepare_sft_data(
    output_directory: Path,
    nq_jsonl: Path,
    druid_jsonl: Path,
    folds: int = 5,
    valid_fold: int = 0,
    tokenizer_name: Optional[str] = None,
    max_sequence_length: int = 4096,
) -> Mapping[str, Any]:
    if valid_fold < 0 or valid_fold >= folds:
        raise ValueError("validation fold is out of range")
    paths = {
        NQ_DATASET: nq_jsonl,
        DRUID_DATASET: druid_jsonl,
    }
    train = []
    valid = []
    source_counts = {}
    for dataset, path in paths.items():
        rows = load_cub_jsonl(path)
        source_counts[dataset] = len(rows)
        for row in rows:
            record = _chat_record(row, dataset)
            fold = _fold_for_group(
                str(record["metadata"]["group_id"]),
                folds,
            )
            if fold == valid_fold:
                valid.append(record)
            else:
                train.append(record)
                if str(row["context_type"]) == "irrelevant":
                    train.append(
                        {
                            **record,
                            "metadata": {
                                **record["metadata"],
                                "class_balance_replica": 1,
                            },
                        }
                    )
    token_filter: Mapping[str, Any] = {
        "enabled": False,
        "max_sequence_length": max_sequence_length,
        "excluded_train_records": [],
    }
    if tokenizer_name is not None:
        from transformers import AutoTokenizer

        tokenizer = AutoTokenizer.from_pretrained(
            tokenizer_name,
            local_files_only=True,
        )

        def token_length(record: Mapping[str, Any]) -> int:
            return len(
                tokenizer.apply_chat_template(
                    record["messages"],
                    return_dict=False,
                )
            )

        train_with_lengths = tuple(
            (record, token_length(record)) for record in train
        )
        valid_with_lengths = tuple(
            (record, token_length(record)) for record in valid
        )
        too_long_valid = tuple(
            (record, length)
            for record, length in valid_with_lengths
            if length > max_sequence_length
        )
        if too_long_valid:
            raise ValueError(
                "validation records exceed max sequence length: %s"
                % ", ".join(
                    str(record["metadata"]["id"])
                    for record, _ in too_long_valid
                )
            )
        excluded = tuple(
            {
                "dataset": record["metadata"]["dataset"],
                "id": record["metadata"]["id"],
                "context_type": record["metadata"]["context_type"],
                "token_length": length,
            }
            for record, length in train_with_lengths
            if length > max_sequence_length
        )
        train = [
            record
            for record, length in train_with_lengths
            if length <= max_sequence_length
        ]
        token_filter = {
            "enabled": True,
            "tokenizer": tokenizer_name,
            "max_sequence_length": max_sequence_length,
            "excluded_train_records": list(excluded),
            "excluded_train_count": len(excluded),
            "maximum_retained_train_length": max(
                length
                for _, length in train_with_lengths
                if length <= max_sequence_length
            ),
            "maximum_validation_length": max(
                length for _, length in valid_with_lengths
            ),
            "policy": (
                "Exclude over-limit training records; never truncate "
                "away the supervised target and never remove a "
                "validation record."
            ),
        }
    train.sort(
        key=lambda row: hashlib.sha256(
            (
                str(row["metadata"]["dataset"])
                + "|"
                + str(row["metadata"]["id"])
                + "|"
                + str(row["metadata"].get("class_balance_replica", 0))
            ).encode("utf-8")
        ).hexdigest()
    )
    valid.sort(
        key=lambda row: (
            str(row["metadata"]["dataset"]),
            str(row["metadata"]["id"]),
        )
    )
    if not train or not valid:
        raise ValueError("SFT split is empty")
    output_directory.mkdir(parents=True, exist_ok=True)
    train_path = output_directory / "train.jsonl"
    valid_path = output_directory / "valid.jsonl"
    train_path.write_text(
        "".join(
            json.dumps(row, sort_keys=True) + "\n" for row in train
        ),
        encoding="utf-8",
    )
    valid_path.write_text(
        "".join(
            json.dumps(row, sort_keys=True) + "\n" for row in valid
        ),
        encoding="utf-8",
    )
    test_path = output_directory / "test.jsonl"
    if test_path.exists():
        test_path.unlink()
    counts = {
        "train": len(train),
        "valid": len(valid),
        "train_by_label": {
            label: sum(
                row["messages"][-1]["content"] == label
                for row in train
            )
            for label in ("Relevant", "Irrelevant")
        },
        "valid_by_label": {
            label: sum(
                row["messages"][-1]["content"] == label
                for row in valid
            )
            for label in ("Relevant", "Irrelevant")
        },
    }
    payload = {
        "data_version": CUB_RELEVANCE_SFT_DATA_VERSION,
        "datasets": [NQ_DATASET, DRUID_DATASET],
        "config": CUB_CONFIG,
        "source_files": {
            dataset: {
                "path": str(path),
                "sha256": _sha256(path),
                "row_count": source_counts[dataset],
            }
            for dataset, path in paths.items()
        },
        "folds": folds,
        "valid_fold": valid_fold,
        "grouping": "normalized question or claimant-plus-claim sha256 fold",
        "class_balance": (
            "duplicate each irrelevant training example once; leave "
            "validation at its natural 2:1 relevant/irrelevant ratio"
        ),
        "token_length_filter": token_filter,
        "counts": counts,
        "files": {
            "train": {
                "path": str(train_path),
                "sha256": _sha256(train_path),
            },
            "valid": {
                "path": str(valid_path),
                "sha256": _sha256(valid_path),
            },
        },
        "fixed_training_recipe": {
            "base_model": DEFAULT_MODEL,
            "fine_tune_type": "lora",
            "mask_prompt": True,
            "num_layers": 8,
            "batch_size": 1,
            "gradient_accumulation_steps": 4,
            "iterations": 200,
            "learning_rate": 2e-5,
            "max_sequence_length": max_sequence_length,
            "seed": 17,
        },
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "claim_boundary": (
            "This is supervised development data for an established "
            "relevance-estimation intervention. Context labels appear "
            "only as training targets, never as inference inputs."
        ),
    }
    preparation_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "preparation_id": preparation_id,
    }
    manifest_path = output_directory / (
        "sft-data-manifest-" + preparation_id + ".json"
    )
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return manifest


def _response_map(
    root: Path,
    digest: str,
) -> Mapping[Tuple[str, str], str]:
    envelope = ArtifactStore(root).get(digest)
    if envelope["kind"] == "cub_semantic_relevance_predictions":
        return {
            (str(row["dataset"]), str(row["id"])): str(
                row["semantic_response"]
            )
            for row in envelope["value"]
        }
    if envelope["kind"] == "cub_frozen_veto_predictions":
        return {
            (str(row["dataset"]), str(row["id"])): str(
                row["official_response"]
            )
            for row in envelope["value"]
        }
    if envelope["kind"] == "cub_learned_router_features":
        return {
            (str(row["dataset"]), str(row["id"])): str(
                row["official_response"]
            )
            for row in envelope["value"]
        }
    raise ValueError("incumbent artifact has the wrong kind")


def _development_gate(
    candidate: Mapping[str, Any],
    incumbent: Mapping[str, Any],
    selected_by_dataset: Mapping[
        str, Sequence[Mapping[str, Any]]
    ],
    incumbent_by_dataset: Mapping[str, Sequence[str]],
    candidate_by_dataset: Mapping[str, Sequence[str]],
) -> Mapping[str, Any]:
    datasets = tuple(selected_by_dataset)
    safety = learned_router_admissibility(
        candidate,
        incumbent,
        datasets,
        capability_tolerance=0.05,
        minimum_coverage=0.95,
        irrelevant_tolerance=0.0,
    )
    paired_changes = {
        dataset: paired_relevance_changes(
            selected_by_dataset[dataset],
            incumbent_by_dataset[dataset],
            candidate_by_dataset[dataset],
        )
        for dataset in datasets
    }
    audited_balanced_delta = {
        dataset: (
            candidate["audited_metrics_by_dataset"][dataset][
                "balanced_accuracy"
            ]
            - incumbent["audited_metrics_by_dataset"][dataset][
                "balanced_accuracy"
            ]
        )
        for dataset in datasets
    }
    mean_audited_balanced_delta = (
        sum(audited_balanced_delta.values())
        / len(audited_balanced_delta)
    )
    net_corrections = sum(
        changes["net_corrections"]
        for changes in paired_changes.values()
    )
    return {
        "passed": bool(
            safety["admissible"]
            and mean_audited_balanced_delta > 0.0
            and net_corrections > 0
        ),
        "safety": safety,
        "audited_balanced_delta_by_dataset": (
            audited_balanced_delta
        ),
        "mean_audited_balanced_delta": (
            mean_audited_balanced_delta
        ),
        "paired_changes_by_dataset": paired_changes,
        "net_corrections": net_corrections,
        "rule": (
            "Promote only if every dataset keeps gold and edited "
            "accuracy within 5 percentage points of the incumbent, "
            "does not reduce audited irrelevant accuracy, improves "
            "mean audited balanced accuracy, and produces positive "
            "net paired corrections."
        ),
    }


def _veto_responses(
    incumbent_responses: Sequence[str],
    irrelevant_margins: Sequence[float],
    threshold: float,
) -> Tuple[str, ...]:
    if len(incumbent_responses) != len(irrelevant_margins):
        raise ValueError("veto inputs do not align")
    return tuple(
        "Ir"
        if parse_relevance(response) is True and margin > threshold
        else response
        for response, margin in zip(
            incumbent_responses,
            irrelevant_margins,
        )
    )


def _veto_thresholds(margins: Sequence[float]) -> Tuple[float, ...]:
    values = sorted({float(value) for value in margins})
    if not values:
        raise ValueError("no eligible veto margins")
    return tuple(
        [values[0] - 1e-9]
        + [
            (left + right) / 2.0
            for left, right in zip(values, values[1:])
        ]
        + [values[-1] + 1e-9]
    )


def evaluate_sft_adapter(
    output_root: Path,
    adapter_path: Path,
    local_jsonl_by_dataset: Mapping[str, Path],
    incumbent_root: Path,
    incumbent_digest: str,
    model_name: str = DEFAULT_MODEL,
    mode: str = "validation_fold",
    folds: int = 5,
    valid_fold: int = 0,
    test_counts: Mapping[str, int] = (
        {"gold": 17, "edited": 17, "irrelevant": 17}
    ),
    batch_size: int = 8,
    max_batch_tokens: int = 10000,
    max_prompt_tokens: int = 4096,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if mode not in ("validation_fold", "test_slice"):
        raise ValueError("unsupported SFT evaluation mode")
    started = time.monotonic()
    selected_by_dataset = {}
    for dataset, path in local_jsonl_by_dataset.items():
        rows = load_cub_jsonl(path)
        if mode == "validation_fold":
            selected = tuple(
                row
                for row in rows
                if _fold_for_group(group_id(row, dataset), folds)
                == valid_fold
            )
        else:
            selected = context_slice(rows, test_counts)
        if not selected:
            raise ValueError("SFT evaluation selection is empty")
        selected_by_dataset[dataset] = selected

    model, tokenizer, model_config = load(
        model_name,
        adapter_path=str(adapter_path),
        return_config=True,
    )
    prompts = []
    for dataset, rows in selected_by_dataset.items():
        prompts.extend(
            _chat_prompt(tokenizer, relevance_prompt(row, dataset))
            for row in rows
        )
    responses = _generate_relevance_labels(
        model,
        tokenizer,
        prompts,
        batch_size,
        1,
        max_batch_tokens,
        max_prompt_tokens,
    )
    responses_by_dataset: Dict[str, Tuple[str, ...]] = {}
    cursor = 0
    for dataset, rows in selected_by_dataset.items():
        responses_by_dataset[dataset] = responses[
            cursor : cursor + len(rows)
        ]
        cursor += len(rows)
    if cursor != len(responses):
        raise RuntimeError("SFT evaluation cursor mismatch")
    incumbent_map = _response_map(incumbent_root, incumbent_digest)
    incumbent_by_dataset = {
        dataset: tuple(
            incumbent_map[(dataset, cub_row_id(row))]
            for row in rows
        )
        for dataset, rows in selected_by_dataset.items()
    }
    incumbent = _summary_for_responses(
        selected_by_dataset,
        incumbent_by_dataset,
    )
    candidate = _summary_for_responses(
        selected_by_dataset,
        responses_by_dataset,
    )
    development_gate = _development_gate(
        candidate,
        incumbent,
        selected_by_dataset,
        incumbent_by_dataset,
        responses_by_dataset,
    )
    records = [
        {
            "dataset": dataset,
            "id": cub_row_id(row),
            "context_type": row["context_type"],
            "incumbent_response": incumbent_response,
            "adapter_response": adapter_response,
        }
        for dataset, rows in selected_by_dataset.items()
        for row, incumbent_response, adapter_response in zip(
            rows,
            incumbent_by_dataset[dataset],
            responses_by_dataset[dataset],
        )
    ]
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        CUB_RELEVANCE_SFT_EVAL_VERSION
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    predictions_digest = store.put(
        "cub_relevance_sft_predictions",
        records,
    )
    payload = {
        "evaluation_version": CUB_RELEVANCE_SFT_EVAL_VERSION,
        "evaluation_mode": mode,
        "datasets": list(selected_by_dataset),
        "config": CUB_CONFIG,
        "base_model": model_name,
        "adapter_path": str(adapter_path),
        "adapter_config_sha256": _sha256(
            adapter_path / "adapter_config.json"
        ),
        "adapter_weights_sha256": _sha256(
            adapter_path / "adapters.safetensors"
        ),
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "selection": (
            {
                "folds": folds,
                "valid_fold": valid_fold,
                "grouping": "normalized query group",
            }
            if mode == "validation_fold"
            else {"counts_by_context": dict(test_counts)}
        ),
        "incumbent_summary": incumbent,
        "candidate_summary": candidate,
        "development_gate": development_gate,
        "incumbent_predictions_digest": incumbent_digest,
        "predictions_digest": predictions_digest,
        "execution": {
            "batch_size_cap": batch_size,
            "max_batch_tokens": max_batch_tokens,
            "max_prompt_tokens": max_prompt_tokens,
        },
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "This evaluates an explicitly supervised relevance adapter. "
            "The method family is established prior art. Validation-fold "
            "results are development evidence; test results require a "
            "frozen adapter and predeclared gate."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "evaluation_id": evaluation_id,
    }
    store.write_manifest(
        "cognitive-core-cub-relevance-sft-" + evaluation_id,
        manifest,
    )
    return manifest


def search_sft_veto(
    output_root: Path,
    adapter_path: Path,
    local_jsonl_by_dataset: Mapping[str, Path],
    incumbent_root: Path,
    incumbent_digest: str,
    model_name: str = DEFAULT_MODEL,
    folds: int = 5,
    valid_fold: int = 0,
    batch_size: int = 8,
    max_batch_tokens: int = 10000,
    max_prompt_tokens: int = 4096,
) -> Mapping[str, Any]:
    from mlx_lm import load

    started = time.monotonic()
    selected_by_dataset = {
        dataset: tuple(
            row
            for row in load_cub_jsonl(path)
            if _fold_for_group(group_id(row, dataset), folds)
            == valid_fold
        )
        for dataset, path in local_jsonl_by_dataset.items()
    }
    if not selected_by_dataset or any(
        not rows for rows in selected_by_dataset.values()
    ):
        raise ValueError("SFT veto selection is empty")
    incumbent_map = _response_map(incumbent_root, incumbent_digest)
    incumbent_by_dataset = {
        dataset: tuple(
            incumbent_map[(dataset, cub_row_id(row))]
            for row in rows
        )
        for dataset, rows in selected_by_dataset.items()
    }
    incumbent = _summary_for_responses(
        selected_by_dataset,
        incumbent_by_dataset,
    )

    model, tokenizer, model_config = load(
        model_name,
        adapter_path=str(adapter_path),
        return_config=True,
    )
    prompts = []
    for dataset, rows in selected_by_dataset.items():
        prompts.extend(
            _chat_prompt(tokenizer, relevance_prompt(row, dataset))
            for row in rows
        )
    margin_records = _generate_relevance_margins(
        model,
        tokenizer,
        prompts,
        batch_size,
        max_batch_tokens,
        max_prompt_tokens,
    )
    margins_by_dataset: Dict[str, Tuple[float, ...]] = {}
    cursor = 0
    for dataset, rows in selected_by_dataset.items():
        dataset_records = margin_records[
            cursor : cursor + len(rows)
        ]
        margins_by_dataset[dataset] = tuple(
            float(record["margin_ir_minus_re"])
            for record in dataset_records
        )
        cursor += len(rows)
    if cursor != len(margin_records):
        raise RuntimeError("SFT veto margin cursor mismatch")

    eligible_margins = tuple(
        margin
        for dataset, responses in incumbent_by_dataset.items()
        for response, margin in zip(
            responses,
            margins_by_dataset[dataset],
        )
        if parse_relevance(response) is True
    )
    candidates = []
    for threshold in _veto_thresholds(eligible_margins):
        routed = {
            dataset: _veto_responses(
                incumbent_by_dataset[dataset],
                margins_by_dataset[dataset],
                threshold,
            )
            for dataset in selected_by_dataset
        }
        summary = _summary_for_responses(
            selected_by_dataset,
            routed,
        )
        gate = _development_gate(
            summary,
            incumbent,
            selected_by_dataset,
            incumbent_by_dataset,
            routed,
        )
        candidates.append(
            {
                "threshold": threshold,
                "summary": summary,
                "development_gate": gate,
                "responses": routed,
            }
        )

    def candidate_key(
        candidate: Mapping[str, Any],
    ) -> Tuple[float, float, float, float]:
        gate = candidate["development_gate"]
        irrelevant_deltas = tuple(
            candidate["summary"]["audited_metrics_by_dataset"][
                dataset
            ]["accuracy_by_context"]["irrelevant"]
            - incumbent["audited_metrics_by_dataset"][dataset][
                "accuracy_by_context"
            ]["irrelevant"]
            for dataset in selected_by_dataset
        )
        return (
            float(bool(gate["passed"])),
            min(irrelevant_deltas),
            float(gate["mean_audited_balanced_delta"]),
            float(gate["net_corrections"]),
        )

    selected = max(candidates, key=candidate_key)
    records = [
        {
            "dataset": dataset,
            "id": cub_row_id(row),
            "context_type": row["context_type"],
            "incumbent_response": incumbent_response,
            "adapter_margin_ir_minus_re": margin,
            "routed_response": routed_response,
        }
        for dataset, rows in selected_by_dataset.items()
        for row, incumbent_response, margin, routed_response in zip(
            rows,
            incumbent_by_dataset[dataset],
            margins_by_dataset[dataset],
            selected["responses"][dataset],
        )
    ]
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        CUB_RELEVANCE_SFT_VETO_VERSION
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    predictions_digest = store.put(
        "cub_relevance_sft_veto_predictions",
        records,
    )
    search_table = [
        {
            "threshold": candidate["threshold"],
            "passed": candidate["development_gate"]["passed"],
            "safety": candidate["development_gate"]["safety"],
            "audited_balanced_delta_by_dataset": candidate[
                "development_gate"
            ]["audited_balanced_delta_by_dataset"],
            "mean_audited_balanced_delta": candidate[
                "development_gate"
            ]["mean_audited_balanced_delta"],
            "net_corrections": candidate["development_gate"][
                "net_corrections"
            ],
        }
        for candidate in candidates
    ]
    payload = {
        "veto_version": CUB_RELEVANCE_SFT_VETO_VERSION,
        "evaluation_mode": "validation_fold_threshold_search",
        "datasets": list(selected_by_dataset),
        "config": CUB_CONFIG,
        "base_model": model_name,
        "adapter_path": str(adapter_path),
        "adapter_config_sha256": _sha256(
            adapter_path / "adapter_config.json"
        ),
        "adapter_weights_sha256": _sha256(
            adapter_path / "adapters.safetensors"
        ),
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "selection": {
            "folds": folds,
            "valid_fold": valid_fold,
            "grouping": "normalized query group",
        },
        "policy": (
            "Keep the incumbent response unless it parses as Relevant "
            "and the trained adapter's Irrelevant-minus-Relevant "
            "first-token log-probability margin exceeds the frozen "
            "threshold."
        ),
        "selected_threshold": selected["threshold"],
        "development_gate": selected["development_gate"],
        "incumbent_summary": incumbent,
        "candidate_summary": selected["summary"],
        "threshold_candidate_count": len(candidates),
        "search_table": search_table,
        "incumbent_predictions_digest": incumbent_digest,
        "predictions_digest": predictions_digest,
        "execution": {
            "batch_size_cap": batch_size,
            "max_batch_tokens": max_batch_tokens,
            "max_prompt_tokens": max_prompt_tokens,
        },
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "This is validation-only threshold selection for an "
            "established supervised relevance-estimation family. "
            "Passing it authorizes one frozen held-out test; it is not "
            "itself evidence of a breakthrough."
        ),
    }
    search_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "search_id": search_id,
    }
    store.write_manifest(
        "cognitive-core-cub-relevance-sft-veto-" + search_id,
        manifest,
    )
    return manifest


def evaluate_frozen_sft_veto(
    output_root: Path,
    validation_manifest_path: Path,
    adapter_path: Path,
    local_jsonl_by_dataset: Mapping[str, Path],
    incumbent_sources: Mapping[str, Tuple[Path, str]],
    test_counts_by_dataset: Mapping[str, Mapping[str, int]],
    model_name: str = DEFAULT_MODEL,
    batch_size: int = 8,
    max_batch_tokens: int = 10000,
    max_prompt_tokens: int = 4096,
) -> Mapping[str, Any]:
    from mlx_lm import load

    started = time.monotonic()
    validation_manifest = json.loads(
        validation_manifest_path.read_text(encoding="utf-8")
    )
    if (
        validation_manifest.get("veto_version")
        != CUB_RELEVANCE_SFT_VETO_VERSION
        or not validation_manifest.get("development_gate", {}).get(
            "passed"
        )
    ):
        raise ValueError(
            "source validation veto is incompatible or did not pass"
        )
    if (
        validation_manifest.get("adapter_config_sha256")
        != _sha256(adapter_path / "adapter_config.json")
        or validation_manifest.get("adapter_weights_sha256")
        != _sha256(adapter_path / "adapters.safetensors")
    ):
        raise ValueError(
            "frozen adapter does not match validation manifest"
        )
    if validation_manifest.get("base_model") != model_name:
        raise ValueError("frozen base model does not match validation")
    threshold = float(validation_manifest["selected_threshold"])
    datasets = tuple(local_jsonl_by_dataset)
    if set(incumbent_sources) != set(datasets):
        raise ValueError("incumbent sources do not match test datasets")
    if set(test_counts_by_dataset) != set(datasets):
        raise ValueError("test counts do not match test datasets")

    selected_by_dataset = {
        dataset: context_slice(
            load_cub_jsonl(path),
            test_counts_by_dataset[dataset],
        )
        for dataset, path in local_jsonl_by_dataset.items()
    }
    incumbent_maps = {
        dataset: _response_map(root, digest)
        for dataset, (root, digest) in incumbent_sources.items()
    }
    incumbent_by_dataset = {
        dataset: tuple(
            incumbent_maps[dataset][(dataset, cub_row_id(row))]
            for row in rows
        )
        for dataset, rows in selected_by_dataset.items()
    }
    incumbent = _summary_for_responses(
        selected_by_dataset,
        incumbent_by_dataset,
    )

    model, tokenizer, model_config = load(
        model_name,
        adapter_path=str(adapter_path),
        return_config=True,
    )
    prompts = []
    for dataset, rows in selected_by_dataset.items():
        prompts.extend(
            _chat_prompt(tokenizer, relevance_prompt(row, dataset))
            for row in rows
        )
    margin_records = _generate_relevance_margins(
        model,
        tokenizer,
        prompts,
        batch_size,
        max_batch_tokens,
        max_prompt_tokens,
    )
    margins_by_dataset: Dict[str, Tuple[float, ...]] = {}
    cursor = 0
    for dataset, rows in selected_by_dataset.items():
        dataset_records = margin_records[
            cursor : cursor + len(rows)
        ]
        margins_by_dataset[dataset] = tuple(
            float(record["margin_ir_minus_re"])
            for record in dataset_records
        )
        cursor += len(rows)
    if cursor != len(margin_records):
        raise RuntimeError("frozen SFT veto margin cursor mismatch")
    routed_by_dataset = {
        dataset: _veto_responses(
            incumbent_by_dataset[dataset],
            margins_by_dataset[dataset],
            threshold,
        )
        for dataset in datasets
    }
    candidate = _summary_for_responses(
        selected_by_dataset,
        routed_by_dataset,
    )
    heldout_gate = _development_gate(
        candidate,
        incumbent,
        selected_by_dataset,
        incumbent_by_dataset,
        routed_by_dataset,
    )
    records = [
        {
            "dataset": dataset,
            "id": cub_row_id(row),
            "context_type": row["context_type"],
            "incumbent_response": incumbent_response,
            "adapter_margin_ir_minus_re": margin,
            "routed_response": routed_response,
        }
        for dataset, rows in selected_by_dataset.items()
        for row, incumbent_response, margin, routed_response in zip(
            rows,
            incumbent_by_dataset[dataset],
            margins_by_dataset[dataset],
            routed_by_dataset[dataset],
        )
    ]
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        CUB_RELEVANCE_SFT_VETO_VERSION
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    predictions_digest = store.put(
        "cub_relevance_sft_veto_predictions",
        records,
    )
    payload = {
        "veto_version": CUB_RELEVANCE_SFT_VETO_VERSION,
        "evaluation_mode": "heldout_frozen_sft_veto",
        "datasets": list(datasets),
        "config": CUB_CONFIG,
        "base_model": model_name,
        "adapter_path": str(adapter_path),
        "adapter_config_sha256": _sha256(
            adapter_path / "adapter_config.json"
        ),
        "adapter_weights_sha256": _sha256(
            adapter_path / "adapters.safetensors"
        ),
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "frozen_threshold": threshold,
        "source_validation_manifest": str(
            validation_manifest_path
        ),
        "source_validation_manifest_sha256": _sha256(
            validation_manifest_path
        ),
        "source_search_id": validation_manifest["search_id"],
        "selection": {
            dataset: {
                "counts_by_context": dict(
                    test_counts_by_dataset[dataset]
                ),
                "method": (
                    "first_requested_count_per_context_in_"
                    "published_order"
                ),
            }
            for dataset in datasets
        },
        "dataset_sources": {
            dataset: {
                "path": str(local_jsonl_by_dataset[dataset]),
                "sha256": _sha256(
                    local_jsonl_by_dataset[dataset]
                ),
                "row_count": len(
                    load_cub_jsonl(
                        local_jsonl_by_dataset[dataset]
                    )
                ),
            }
            for dataset in datasets
        },
        "incumbent_sources": {
            dataset: {
                "root": str(incumbent_sources[dataset][0]),
                "predictions_digest": (
                    incumbent_sources[dataset][1]
                ),
            }
            for dataset in datasets
        },
        "incumbent_summary": incumbent,
        "candidate_summary": candidate,
        "heldout_gate": heldout_gate,
        "survived_predeclared_test": bool(heldout_gate["passed"]),
        "predictions_digest": predictions_digest,
        "execution": {
            "batch_size_cap": batch_size,
            "max_batch_tokens": max_batch_tokens,
            "max_prompt_tokens": max_prompt_tokens,
        },
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "The adapter checkpoint and veto threshold were selected "
            "on validation and applied once, unchanged, to deterministic "
            "held-out slices. Passing is component evidence for "
            "relevance routing, not a cognitive-core breakthrough."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "evaluation_id": evaluation_id,
    }
    store.write_manifest(
        "cognitive-core-cub-relevance-sft-veto-heldout-"
        + evaluation_id,
        manifest,
    )
    return manifest


def evaluate_frozen_sft_veto_spec(
    output_root: Path,
    spec_path: Path,
) -> Mapping[str, Any]:
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    datasets = tuple(spec["datasets"])
    dataset_paths = {
        dataset: Path(spec["dataset_sources"][dataset])
        for dataset in datasets
    }
    incumbent_sources = {
        dataset: (
            Path(spec["incumbent_sources"][dataset]["root"]),
            str(
                spec["incumbent_sources"][dataset][
                    "predictions_digest"
                ]
            ),
        )
        for dataset in datasets
    }
    counts = {
        dataset: {
            context_type: int(count)
            for context_type, count in spec["test_counts_by_dataset"][
                dataset
            ].items()
        }
        for dataset in datasets
    }
    return evaluate_frozen_sft_veto(
        output_root=output_root,
        validation_manifest_path=Path(
            spec["validation_manifest"]
        ),
        adapter_path=Path(spec["adapter_path"]),
        local_jsonl_by_dataset=dataset_paths,
        incumbent_sources=incumbent_sources,
        test_counts_by_dataset=counts,
        model_name=str(spec.get("base_model", DEFAULT_MODEL)),
    )


def _parse_dataset_paths(value: str) -> Mapping[str, Path]:
    parsed = {}
    for item in value.split(","):
        if not item.strip():
            continue
        if "=" not in item:
            raise ValueError("dataset paths must be dataset=path")
        dataset, path = item.split("=", 1)
        parsed[dataset.strip()] = Path(path.strip())
    return parsed


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--evaluate", action="store_true")
    parser.add_argument("--search-veto", action="store_true")
    parser.add_argument("--frozen-veto", action="store_true")
    parser.add_argument(
        "--output",
        default="data/cub/relevance_adapter_v1",
    )
    parser.add_argument(
        "--nq-jsonl",
        default="data/cub/cub-nq-qwen-1.5b-instruct-validation.jsonl",
    )
    parser.add_argument(
        "--druid-jsonl",
        default="data/cub/cub-druid-qwen-1.5b-instruct-validation.jsonl",
    )
    parser.add_argument("--adapter-path", default="")
    parser.add_argument("--dataset-paths", default="")
    parser.add_argument("--incumbent-root", default="")
    parser.add_argument("--incumbent-digest", default="")
    parser.add_argument("--test-spec", default="")
    parser.add_argument(
        "--mode",
        choices=("validation_fold", "test_slice"),
        default="validation_fold",
    )
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--valid-fold", type=int, default=0)
    parser.add_argument("--max-seq-length", type=int, default=4096)
    arguments = parser.parse_args(list(argv) or None)
    if sum(
        (
            arguments.prepare,
            arguments.evaluate,
            arguments.search_veto,
            arguments.frozen_veto,
        )
    ) != 1:
        parser.error(
            "select exactly one of --prepare, --evaluate, or "
            "--search-veto, or --frozen-veto"
        )
    if arguments.prepare:
        manifest = prepare_sft_data(
            Path(arguments.output),
            Path(arguments.nq_jsonl),
            Path(arguments.druid_jsonl),
            arguments.folds,
            arguments.valid_fold,
            DEFAULT_MODEL,
            arguments.max_seq_length,
        )
    elif arguments.frozen_veto:
        if not arguments.test_spec:
            parser.error("--frozen-veto requires --test-spec")
        manifest = evaluate_frozen_sft_veto_spec(
            Path(arguments.output),
            Path(arguments.test_spec),
        )
    else:
        if (
            not arguments.adapter_path
            or not arguments.dataset_paths
            or not arguments.incumbent_root
            or not arguments.incumbent_digest
        ):
            parser.error(
                "--evaluate requires adapter, dataset paths, and "
                "incumbent artifact arguments"
            )
        try:
            dataset_paths = _parse_dataset_paths(
                arguments.dataset_paths
            )
        except ValueError as error:
            parser.error(str(error))
        if arguments.evaluate:
            manifest = evaluate_sft_adapter(
                Path(arguments.output),
                Path(arguments.adapter_path),
                dataset_paths,
                Path(arguments.incumbent_root),
                arguments.incumbent_digest,
                mode=arguments.mode,
                folds=arguments.folds,
                valid_fold=arguments.valid_fold,
            )
        else:
            manifest = search_sft_veto(
                Path(arguments.output),
                Path(arguments.adapter_path),
                dataset_paths,
                Path(arguments.incumbent_root),
                arguments.incumbent_digest,
                folds=arguments.folds,
                valid_fold=arguments.valid_fold,
            )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
