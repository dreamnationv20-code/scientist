from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.cub_benchmark import (
    evaluate_published_regular,
    fetch_cub_rows,
)
from scientist.domains.cognitive_core.prior_art import (
    evidence_utilization_scope_assessment,
)


CUB_ROUTER_VERSION = "cognitive-core-cub-lexical-router-v1"
TOKEN_PATTERN = re.compile(r"[a-z0-9]+")
STOPWORDS = frozenset(
    {
        "a",
        "an",
        "and",
        "at",
        "by",
        "fact",
        "for",
        "from",
        "in",
        "is",
        "of",
        "on",
        "the",
        "that",
        "to",
        "was",
        "with",
    }
)


def fact_query_lines(prompt: str) -> Tuple[str, str]:
    user_marker = "<|im_start|>user\n"
    if user_marker not in prompt:
        raise ValueError("unsupported CUB chat prompt")
    user_content = prompt.split(user_marker, 1)[1].split(
        "<|im_end|>",
        1,
    )[0]
    lines = [
        line.strip()
        for line in user_content.splitlines()
        if line.strip()
    ]
    fact_lines = [
        line
        for line in lines
        if line.lower().startswith("fact:")
    ]
    if len(fact_lines) != 1:
        raise ValueError("CUB router requires exactly one context fact")
    query = lines[-1]
    if query == fact_lines[0]:
        raise ValueError("CUB prompt has no query after its fact")
    return fact_lines[0][5:].strip(), query


def lexical_relevance(prompt: str) -> float:
    """Fraction of content-bearing query tokens supported by the fact."""

    fact, query = fact_query_lines(prompt)
    fact_tokens = {
        token
        for token in TOKEN_PATTERN.findall(fact.lower())
        if token not in STOPWORDS
    }
    query_tokens = {
        token
        for token in TOKEN_PATTERN.findall(query.lower())
        if token not in STOPWORDS
    }
    if not query_tokens:
        return 0.0
    return len(fact_tokens.intersection(query_tokens)) / len(
        query_tokens
    )


@dataclass(frozen=True)
class RouterSelection:
    threshold: float
    metrics: Mapping[str, Any]
    tuned_fraction: float

    def as_dict(self) -> Dict[str, Any]:
        return {
            "threshold": self.threshold,
            "metrics": dict(self.metrics),
            "tuned_fraction": self.tuned_fraction,
        }


def _routed_rows(
    rows: Sequence[Mapping[str, Any]],
    prediction_records: Mapping[int, Mapping[str, Any]],
    threshold: float,
) -> Tuple[Tuple[Mapping[str, Any], ...], int]:
    routed = []
    tuned_count = 0
    for row in rows:
        record = prediction_records[int(row["id"])]
        use_tuned = lexical_relevance(
            str(row["prompt_w_context"])
        ) >= threshold
        tuned_count += int(use_tuned)
        prediction = (
            record["mlx_tuned_prediction"]
            if use_tuned
            else record["mlx_regular_prediction"]
        )
        routed.append(
            {
                **row,
                "pred": record["mlx_closed_prediction"],
                "pred_w_context": prediction,
            }
        )
    return tuple(routed), tuned_count


def tune_router(
    rows: Sequence[Mapping[str, Any]],
    prediction_records: Sequence[Mapping[str, Any]],
) -> Tuple[RouterSelection, Tuple[RouterSelection, ...]]:
    by_id = {
        int(record["id"]): record
        for record in prediction_records
    }
    if set(by_id) != {int(row["id"]) for row in rows}:
        raise ValueError("prediction records do not match CUB rows")
    scores = sorted(
        {
            lexical_relevance(str(row["prompt_w_context"]))
            for row in rows
        }
    )
    thresholds = [0.0]
    thresholds.extend(
        (left + right) / 2.0
        for left, right in zip(scores, scores[1:])
    )
    thresholds.append(1.0 + 1e-9)

    candidates = []
    for threshold in thresholds:
        routed, tuned_count = _routed_rows(
            rows,
            by_id,
            threshold,
        )
        metrics = evaluate_published_regular(routed).as_dict()
        candidates.append(
            RouterSelection(
                threshold=threshold,
                metrics=metrics,
                tuned_fraction=tuned_count / len(rows),
            )
        )

    def selection_key(candidate: RouterSelection):
        metrics = candidate.metrics
        capability_floor = min(
            metrics["context_accuracy_gold"],
            metrics["context_accuracy_edited"],
            metrics["memory_accuracy_irrelevant"],
        )
        return (
            capability_floor,
            metrics["combined_score"],
            -candidate.tuned_fraction,
        )

    return max(candidates, key=selection_key), tuple(candidates)


def run_router_validation(
    predictions_root: Path,
    output_root: Path,
    predictions_digest: str,
) -> Mapping[str, Any]:
    source_store = ArtifactStore(predictions_root)
    prediction_envelope = source_store.get(predictions_digest)
    if prediction_envelope["kind"] != "cub_mlx_smoke_predictions":
        raise ValueError("source object is not a CUB prediction artifact")
    prediction_records = tuple(prediction_envelope["value"])
    all_rows = fetch_cub_rows()
    selected_ids = {int(record["id"]) for record in prediction_records}
    rows = tuple(
        row
        for row in all_rows
        if int(row["id"]) in selected_ids
    )

    selected, candidates = tune_router(rows, prediction_records)
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-lexical-router-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    score_records = [
        {
            "id": row["id"],
            "context_type": row["context_type"],
            "lexical_relevance": lexical_relevance(
                str(row["prompt_w_context"])
            ),
        }
        for row in rows
    ]
    scores_digest = store.put(
        "cub_router_validation_scores",
        score_records,
    )
    payload = {
        "router_version": CUB_ROUTER_VERSION,
        "source_predictions_digest": predictions_digest,
        "selection_objective": (
            "maximize the worst of gold-context, edited-context, and "
            "irrelevant-memory accuracy; then combined score"
        ),
        "selected": selected.as_dict(),
        "candidate_count": len(candidates),
        "candidate_curve": [
            candidate.as_dict()
            for candidate in candidates
        ],
        "scores_digest": scores_digest,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "claim_boundary": (
            "Validation-tuned, label-free lexical routing baseline in the "
            "RE-RAG method family. This is an internal reproduction-stage "
            "candidate, not a novel mechanism or held-out result."
        ),
        "next_action": (
            "freeze the threshold and evaluate without retuning on CUB "
            "CounterFact test, then test semantic transfer on NQ and DRUID"
        ),
    }
    router_id = content_digest(payload)[:20]
    manifest = {**payload, "schema": 1, "router_id": router_id}
    store.write_manifest(
        "cognitive-core-cub-router-" + router_id,
        manifest,
    )
    return manifest


def run_router_holdout(
    predictions_root: Path,
    output_root: Path,
    predictions_digest: str,
    split: str,
    frozen_threshold: float,
) -> Mapping[str, Any]:
    source_store = ArtifactStore(predictions_root)
    prediction_envelope = source_store.get(predictions_digest)
    if prediction_envelope["kind"] != "cub_mlx_smoke_predictions":
        raise ValueError("source object is not a CUB prediction artifact")
    prediction_records = tuple(prediction_envelope["value"])
    by_id = {
        int(record["id"]): record
        for record in prediction_records
    }
    all_rows = fetch_cub_rows(split=split)
    rows = tuple(
        row
        for row in all_rows
        if int(row["id"]) in by_id
    )
    if len(rows) != len(prediction_records):
        raise ValueError("holdout rows and predictions do not align")

    routed_rows, tuned_count = _routed_rows(
        rows,
        by_id,
        frozen_threshold,
    )
    regular_rows = tuple(
        {
            **row,
            "pred": by_id[int(row["id"])]["mlx_closed_prediction"],
            "pred_w_context": by_id[int(row["id"])][
                "mlx_regular_prediction"
            ],
        }
        for row in rows
    )
    tuned_rows = tuple(
        {
            **row,
            "pred": by_id[int(row["id"])]["mlx_closed_prediction"],
            "pred_w_context": by_id[int(row["id"])][
                "mlx_tuned_prediction"
            ],
        }
        for row in rows
    )
    regular_metrics = evaluate_published_regular(
        regular_rows
    ).as_dict()
    tuned_metrics = evaluate_published_regular(tuned_rows).as_dict()
    routed_metrics = evaluate_published_regular(
        routed_rows
    ).as_dict()
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-lexical-router-holdout-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    payload = {
        "router_version": CUB_ROUTER_VERSION,
        "evaluation_mode": "frozen_holdout",
        "split": split,
        "sample_count": len(rows),
        "source_predictions_digest": predictions_digest,
        "frozen_threshold": frozen_threshold,
        "tuned_fraction": tuned_count / len(rows),
        "regular_metrics": regular_metrics,
        "published_tuned_prompt_metrics": tuned_metrics,
        "routed_metrics": routed_metrics,
        "combined_delta_router_vs_tuned": (
            routed_metrics["combined_score"]
            - tuned_metrics["combined_score"]
        ),
        "combined_delta_router_vs_regular": (
            routed_metrics["combined_score"]
            - regular_metrics["combined_score"]
        ),
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "claim_boundary": (
            "Frozen-threshold CounterFact holdout check in an established "
            "relevance-routing family. A subset or single dataset cannot "
            "establish broad semantic transfer or novelty."
        ),
        "next_action": (
            "test a semantic relevance estimator without retuning on NQ "
            "and DRUID; run the complete CounterFact test only if warranted"
        ),
    }
    router_id = content_digest(payload)[:20]
    manifest = {**payload, "schema": 1, "router_id": router_id}
    store.write_manifest(
        "cognitive-core-cub-router-holdout-" + router_id,
        manifest,
    )
    return manifest


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--predictions-root",
        default="runs/cognitive_core/cub_mlx_validation_v1",
    )
    parser.add_argument(
        "--fixed-threshold",
        type=float,
        default=None,
    )
    parser.add_argument("--split", default="validation")
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/cub_router_validation_v1",
    )
    parser.add_argument(
        "--predictions-digest",
        default=(
            "5e8c55b289e294d5c5e3fd0b0997d972e5ee98302800967"
            "ec60989662db1ed4a"
        ),
    )
    arguments = parser.parse_args(list(argv) or None)
    if arguments.fixed_threshold is None:
        manifest = run_router_validation(
            Path(arguments.predictions_root),
            Path(arguments.output),
            arguments.predictions_digest,
        )
    else:
        manifest = run_router_holdout(
            Path(arguments.predictions_root),
            Path(arguments.output),
            arguments.predictions_digest,
            arguments.split,
            arguments.fixed_threshold,
        )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
