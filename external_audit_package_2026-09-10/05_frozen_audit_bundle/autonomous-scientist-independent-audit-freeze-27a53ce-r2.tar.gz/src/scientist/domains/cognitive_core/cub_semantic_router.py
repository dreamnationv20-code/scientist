from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.cub_benchmark import (
    CUB_COMMIT,
    CUB_CONFIG,
    CUB_REPOSITORY,
    cub_row_id,
    evaluate_published_regular,
    fetch_cub_rows,
    load_cub_jsonl,
)
from scientist.domains.cognitive_core.cub_mlx_smoke import (
    DEFAULT_MODEL,
    balanced_slice,
)
from scientist.domains.cognitive_core.prior_art import (
    evidence_utilization_scope_assessment,
)


CUB_SEMANTIC_ROUTER_VERSION = "cognitive-core-cub-semantic-router-v1"
CUB_RELEVANCE_SEARCH_VERSION = "cognitive-core-cub-relevance-search-v1"
CUB_SELECTIVE_VETO_VERSION = "cognitive-core-cub-selective-veto-v1"
CUB_FROZEN_VETO_EVALUATION_VERSION = (
    "cognitive-core-cub-frozen-veto-evaluation-v1"
)
CUB_WITNESS_ROUTER_VERSION = "cognitive-core-cub-witness-router-v2"
NQ_DATASET = "copenlu/cub-nq"
DRUID_DATASET = "copenlu/cub-druid"
DEFAULT_OFFICIAL_RELEVANCE_ROOT = Path(
    "runs/cognitive_core/cub_semantic_relevance_v1"
)
DEFAULT_OFFICIAL_RELEVANCE_DIGEST = (
    "a5cc9c2532971833bc5bcff9713ccd35b21d9506ba08b45914adab5fc460450a"
)

NQ_RELEVANCE_PROMPT = """You are a relevance assessment expert. Your task is to evaluate whether the provided context is relevant to the question.

Context: {context}
Question: {question}

If the provided context is relevant to the question, answer "Relevant", otherwise answer "Irrelevant". Do not rely on your own knowledge or judge the factual accuracy of the context.
Answer:"""

DRUID_RELEVANCE_PROMPT = """You are a relevance assessment expert. Your task is to determine whether the provided evidence is relevant to the claim.

Claimant: {claimant}
Claim: {claim}
Evidence: {evidence}
Question: Is the claim True or False based on the accompanying evidence? If you are not sure or cannot answer, say None.

If the provided evidence is relevant to the claim, answer "Relevant", otherwise answer "Irrelevant". Do not rely on your own knowledge or judge the factual accuracy of the evidence.
Answer:"""

NQ_STRICT_RELATION_PROMPT = """You are a strict evidence router. Decide whether the passage itself provides evidence for the exact information requested by the question.

A passage is Relevant when it states or unambiguously entails a concrete answer to the requested relation. A conflicting, outdated, or factually wrong answer is still Relevant: do not compare against your own knowledge.
A passage is Irrelevant when it merely shares a topic, entity, or keywords but does not state the requested property or relation. A page title or entity name alone is not evidence for a relation.

Question: {question}
Passage: {context}

Silently identify the subject and the exact requested property, then test whether the passage supplies that property. Reply with exactly "Relevant" or "Irrelevant".
Answer:"""

DRUID_STRICT_RELATION_PROMPT = """You are a strict evidence router. Decide whether the evidence bears on the truth of the exact claim.

Evidence is Relevant when it supports, contradicts, or supplies facts that materially affect the specific asserted action, quotation, number, identity, or relation. It can be relevant even when it is insufficient for a final True/False decision.
Evidence is Irrelevant when it only mentions the same person, organisation, event, or topic but does not address the specific assertion. Do not judge factual accuracy using your own knowledge.

Claimant: {claimant}
Claim: {claim}
Evidence: {evidence}

Silently identify the claim's exact relation and test whether the evidence addresses that relation. Reply with exactly "Relevant" or "Irrelevant".
Answer:"""

NQ_CONTRASTIVE_PROMPT = """Classify whether a passage supplies evidence for the exact answer requested by a question. Topic or entity overlap alone is not enough. A passage containing a conflicting or surprising answer is still relevant; never fact-check it from memory.

Example 1
Question: When did Apollo 11 land on the Moon?
Passage: Apollo 11 carried Neil Armstrong, Buzz Aldrin, and Michael Collins.
Answer: Irrelevant

Example 2
Question: When did Apollo 11 land on the Moon?
Passage: The lunar module landed on July 20, 1969.
Answer: Relevant

Example 3
Question: Who wrote Hamlet?
Passage: Hamlet was written by Christopher Marlowe.
Answer: Relevant

Now classify this case.
Question: {question}
Passage: {context}
Answer (exactly Relevant or Irrelevant):"""

DRUID_CONTRASTIVE_PROMPT = """Classify whether evidence bears on the exact relation asserted by a claim. Sharing a person or topic is not enough. Evidence is relevant if it supports, contradicts, or materially informs the assertion, even when the final verdict would be uncertain. Never fact-check from memory.

Example 1
Claim: Dana said the city banned private cars in 2024.
Evidence: Dana gave a speech about the city's parks in 2024.
Answer: Irrelevant

Example 2
Claim: Dana said the city banned private cars in 2024.
Evidence: A recording shows Dana saying that private cars were not banned.
Answer: Relevant

Example 3
Claim: A vaccine causes a particular skin disease.
Evidence: The skin disease is caused by a bacterium and standard treatment uses antibiotics.
Answer: Relevant

Now classify this case.
Claimant: {claimant}
Claim: {claim}
Evidence: {evidence}
Answer (exactly Relevant or Irrelevant):"""

NQ_WITNESS_PROMPT = """You are an extractive QA parser. Copy the shortest exact span from the passage that answers the question.

Rules:
- Output only a one-to-eight-word span copied verbatim, or NONE.
- Never write a sentence, explanation, label, or prefix.
- A surprising or wrong answer is still an answer; copy it.
- A title, shared topic, or related fact is not an answer.
- Never answer from memory.

Example 1
Question: Who wrote Hamlet?
Passage: Hamlet is a tragedy written by William Shakespeare.
Output: William Shakespeare

Example 2
Question: Who wrote Hamlet?
Passage: Hamlet is set in Denmark and has five acts.
Output: NONE

Example 3
Question: Who wrote Hamlet?
Passage: A disputed manuscript says Hamlet was written by Alice Jones.
Output: Alice Jones

Now parse this case.
Question: {question}
Passage: {context}
Output:"""

DRUID_WITNESS_PROMPT = """You are an extractive relation parser. Copy the shortest exact span from the evidence that directly supports, contradicts, or materially bears on the specific relation asserted in the claim.

Rules:
- Output only one contiguous span copied verbatim, or NONE.
- Never write an explanation, label, or prefix.
- The span may support or contradict the claim and need not settle a final verdict.
- Sharing only a person, organisation, event, or topic is not enough.
- Never use outside knowledge.

Example 1
Claim: Dana said the city banned private cars.
Evidence: A recording has Dana saying, "Private cars are not banned."
Output: Private cars are not banned

Example 2
Claim: Dana said the city banned private cars.
Evidence: Dana spoke about the city's parks and buses.
Output: NONE

Now parse this case.
Claimant: {claimant}
Claim: {claim}
Evidence: {evidence}
Output:"""

PROMPT_VARIANTS = {
    "strict_relation": {
        NQ_DATASET: NQ_STRICT_RELATION_PROMPT,
        DRUID_DATASET: DRUID_STRICT_RELATION_PROMPT,
    },
    "contrastive_relation": {
        NQ_DATASET: NQ_CONTRASTIVE_PROMPT,
        DRUID_DATASET: DRUID_CONTRASTIVE_PROMPT,
    },
}
WITNESS_PROMPTS = {
    NQ_DATASET: NQ_WITNESS_PROMPT,
    DRUID_DATASET: DRUID_WITNESS_PROMPT,
}
TEXT_TOKEN_PATTERN = re.compile(r"[a-z0-9]+")


@dataclass(frozen=True)
class CubDatasetSpec:
    dataset: str
    relevant_match: str
    query_fields: Tuple[str, ...]
    context_field: str
    relevance_prompt: str


DATASET_SPECS = {
    NQ_DATASET: CubDatasetSpec(
        dataset=NQ_DATASET,
        relevant_match="prefix",
        query_fields=("question",),
        context_field="context",
        relevance_prompt=NQ_RELEVANCE_PROMPT,
    ),
    DRUID_DATASET: CubDatasetSpec(
        dataset=DRUID_DATASET,
        relevant_match="exact",
        query_fields=("claimant", "claim"),
        context_field="evidence",
        relevance_prompt=DRUID_RELEVANCE_PROMPT,
    ),
}


def relevance_prompt(
    row: Mapping[str, Any],
    dataset: str,
) -> str:
    try:
        spec = DATASET_SPECS[dataset]
    except KeyError as error:
        raise ValueError("unsupported CUB dataset %s" % dataset) from error
    fields = {
        field: str(row[field])
        for field in (*spec.query_fields, spec.context_field)
    }
    return spec.relevance_prompt.format(**fields)


def candidate_relevance_prompt(
    row: Mapping[str, Any],
    dataset: str,
    candidate: str,
) -> str:
    if candidate == "published_official":
        return relevance_prompt(row, dataset)
    try:
        template = PROMPT_VARIANTS[candidate][dataset]
        spec = DATASET_SPECS[dataset]
    except KeyError as error:
        raise ValueError(
            "unsupported relevance candidate %s for %s"
            % (candidate, dataset)
        ) from error
    fields = {
        field: str(row[field])
        for field in (*spec.query_fields, spec.context_field)
    }
    return template.format(**fields)


def target_literal_in_context(
    row: Mapping[str, Any],
    dataset: str,
) -> bool:
    """Conservative audit flag for answer-bearing alleged distractors."""

    if dataset != NQ_DATASET:
        return False
    target_tokens = TEXT_TOKEN_PATTERN.findall(
        str(row.get("target_true") or "").lower()
    )
    context_tokens = TEXT_TOKEN_PATTERN.findall(
        str(row["context"]).lower()
    )
    if not target_tokens:
        return False
    target_length = len(target_tokens)
    return any(
        context_tokens[start : start + target_length] == target_tokens
        for start in range(
            0,
            len(context_tokens) - target_length + 1,
        )
    )


def witness_prompt(
    row: Mapping[str, Any],
    dataset: str,
) -> str:
    try:
        template = WITNESS_PROMPTS[dataset]
        spec = DATASET_SPECS[dataset]
    except KeyError as error:
        raise ValueError("unsupported CUB dataset %s" % dataset) from error
    fields = {
        field: str(row[field])
        for field in (*spec.query_fields, spec.context_field)
    }
    return template.format(**fields)


def witness_is_grounded(
    response: str,
    row: Mapping[str, Any],
    dataset: str,
) -> bool:
    """Require the complete generated witness to occur in the evidence."""

    normalized = response.strip().strip("\"'`“”")
    if not normalized or normalized.lower().startswith("none"):
        return False
    try:
        context = str(row[DATASET_SPECS[dataset].context_field])
    except KeyError as error:
        raise ValueError("unsupported CUB dataset %s" % dataset) from error
    witness_tokens = TEXT_TOKEN_PATTERN.findall(normalized.lower())
    context_tokens = TEXT_TOKEN_PATTERN.findall(context.lower())
    if not witness_tokens:
        return False
    length = len(witness_tokens)
    return any(
        context_tokens[start : start + length] == witness_tokens
        for start in range(0, len(context_tokens) - length + 1)
    )


def witness_routed_responses(
    rows: Sequence[Mapping[str, Any]],
    dataset: str,
    official_responses: Sequence[str],
    witness_responses: Sequence[str],
    policy: str,
) -> Tuple[str, ...]:
    if not (
        len(rows)
        == len(official_responses)
        == len(witness_responses)
    ):
        raise ValueError("witness routing inputs do not align")
    if policy not in ("witness_only", "official_veto", "official_union"):
        raise ValueError("unsupported witness routing policy %s" % policy)
    routed = []
    for row, official_response, witness_response in zip(
        rows,
        official_responses,
        witness_responses,
    ):
        grounded = witness_is_grounded(
            witness_response,
            row,
            dataset,
        )
        official = parse_relevance(official_response)
        if policy == "witness_only":
            routed.append("Re" if grounded else "Ir")
        elif policy == "official_veto":
            routed.append(
                "Ir" if official is True and not grounded
                else official_response
            )
        else:
            routed.append(
                "Re" if official is False and grounded
                else official_response
            )
    return tuple(routed)


def audited_relevance_rows(
    rows: Sequence[Mapping[str, Any]],
    dataset: str,
) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        row
        for row in rows
        if not (
            str(row["context_type"]) == "irrelevant"
            and target_literal_in_context(row, dataset)
        )
    )


def expected_relevant(row: Mapping[str, Any]) -> bool:
    context_type = str(row["context_type"])
    if context_type not in ("gold", "edited", "irrelevant"):
        raise ValueError("unsupported CUB context type %s" % context_type)
    return context_type != "irrelevant"


def parse_relevance(response: str) -> Optional[bool]:
    normalized = response.strip().lower()
    if normalized.startswith("ir"):
        return False
    if normalized.startswith("re"):
        return True
    return None


@dataclass(frozen=True)
class RelevanceMetrics:
    accuracy: float
    balanced_accuracy: float
    coverage: float
    accuracy_by_context: Mapping[str, float]
    counts: Mapping[str, int]
    confusion: Mapping[str, int]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "accuracy": self.accuracy,
            "balanced_accuracy": self.balanced_accuracy,
            "coverage": self.coverage,
            "accuracy_by_context": dict(
                sorted(self.accuracy_by_context.items())
            ),
            "counts": dict(sorted(self.counts.items())),
            "confusion": dict(sorted(self.confusion.items())),
        }


def evaluate_relevance(
    rows: Sequence[Mapping[str, Any]],
    responses: Sequence[str],
) -> RelevanceMetrics:
    if len(rows) != len(responses):
        raise ValueError("rows and relevance responses do not align")
    totals = {"gold": 0, "edited": 0, "irrelevant": 0}
    correct = {"gold": 0, "edited": 0, "irrelevant": 0}
    confusion = {
        "true_relevant": 0,
        "false_relevant": 0,
        "true_irrelevant": 0,
        "false_irrelevant": 0,
        "unparsed": 0,
    }
    parsed_count = 0
    for row, response in zip(rows, responses):
        context_type = str(row["context_type"])
        if context_type not in totals:
            raise ValueError(
                "unsupported CUB context type %s" % context_type
            )
        expected = expected_relevant(row)
        predicted = parse_relevance(response)
        totals[context_type] += 1
        if predicted is None:
            confusion["unparsed"] += 1
            continue
        parsed_count += 1
        correct[context_type] += int(predicted == expected)
        if expected and predicted:
            confusion["true_relevant"] += 1
        elif expected:
            confusion["false_irrelevant"] += 1
        elif predicted:
            confusion["false_relevant"] += 1
        else:
            confusion["true_irrelevant"] += 1
    if any(not count for count in totals.values()):
        raise ValueError("CUB slice must contain all three context types")
    per_context = {
        context_type: correct[context_type] / totals[context_type]
        for context_type in totals
    }
    return RelevanceMetrics(
        accuracy=sum(correct.values()) / len(rows),
        balanced_accuracy=sum(per_context.values()) / len(per_context),
        coverage=parsed_count / len(rows),
        accuracy_by_context=per_context,
        counts={
            **totals,
            "total": len(rows),
        },
        confusion=confusion,
    )


def _generate_relevance_labels(
    model,
    tokenizer,
    prompts: Sequence[str],
    batch_size: int,
    max_tokens: int,
    max_batch_tokens: int,
    max_prompt_tokens: int,
) -> Tuple[str, ...]:
    from mlx_lm import batch_generate

    if max_batch_tokens <= 0 or max_prompt_tokens <= 0:
        raise ValueError("token budgets must be positive")
    encoded = [
        (
            index,
            tokenizer.encode(prompt)[-max_prompt_tokens:],
        )
        for index, prompt in enumerate(prompts)
    ]
    encoded.sort(key=lambda item: len(item[1]))
    predictions: list[Optional[str]] = [None] * len(prompts)
    completed = 0
    cursor = 0
    while cursor < len(encoded):
        end = min(cursor + batch_size, len(encoded))
        while end > cursor + 1:
            padded_tokens = (
                (end - cursor)
                * len(encoded[end - 1][1])
            )
            if padded_tokens <= max_batch_tokens:
                break
            end -= 1
        batch_records = encoded[cursor:end]
        tokenized = [tokens for _, tokens in batch_records]
        response = batch_generate(
            model,
            tokenizer,
            tokenized,
            max_tokens=max_tokens,
            verbose=False,
        )
        for (index, _), text in zip(batch_records, response.texts):
            predictions[index] = text.strip()
        completed += len(batch_records)
        print(
            json.dumps(
                {
                    "stage": "semantic_relevance",
                    "completed": completed,
                    "total": len(prompts),
                    "batch_size": len(batch_records),
                    "min_prompt_tokens": len(batch_records[0][1]),
                    "max_prompt_tokens": len(batch_records[-1][1]),
                    "peak_memory_gb": round(
                        response.stats.peak_memory,
                        3,
                    ),
                },
                sort_keys=True,
            ),
            flush=True,
        )
        cursor = end
    if any(prediction is None for prediction in predictions):
        raise RuntimeError("missing semantic relevance prediction")
    return tuple(str(prediction) for prediction in predictions)


def _single_token_id(tokenizer, text: str) -> int:
    tokens = tokenizer.encode(text, add_special_tokens=False)
    if len(tokens) != 1:
        raise ValueError(
            "expected %r to encode as one token, received %r"
            % (text, tokens)
        )
    return int(tokens[0])


def _generate_relevance_margins(
    model,
    tokenizer,
    prompts: Sequence[str],
    batch_size: int,
    max_batch_tokens: int,
    max_prompt_tokens: int,
) -> Tuple[Mapping[str, Any], ...]:
    import mlx.core as mx
    from mlx_lm.generate import BatchGenerator

    relevant_token = _single_token_id(tokenizer, "Re")
    irrelevant_token = _single_token_id(tokenizer, "Ir")
    encoded = [
        (
            index,
            tokenizer.encode(prompt)[-max_prompt_tokens:],
        )
        for index, prompt in enumerate(prompts)
    ]
    encoded.sort(key=lambda item: len(item[1]))
    results: list[Optional[Mapping[str, Any]]] = [None] * len(
        prompts
    )
    completed = 0
    cursor = 0
    while cursor < len(encoded):
        end = min(cursor + batch_size, len(encoded))
        while end > cursor + 1:
            padded_tokens = (
                (end - cursor)
                * len(encoded[end - 1][1])
            )
            if padded_tokens <= max_batch_tokens:
                break
            end -= 1
        batch_records = encoded[cursor:end]
        generator = BatchGenerator(
            model,
            stop_tokens=[
                [token]
                for token in tokenizer.eos_token_ids
            ],
            prefill_batch_size=len(batch_records),
            completion_batch_size=len(batch_records),
        )
        try:
            uids = generator.insert(
                [tokens for _, tokens in batch_records],
                [1] * len(batch_records),
            )
            index_by_uid = {
                uid: index
                for uid, (index, _) in zip(uids, batch_records)
            }
            with generator.stats() as stats:
                while responses := generator.next_generated():
                    for response in responses:
                        logprobs = response.logprobs
                        mx.eval(logprobs)
                        index = index_by_uid[response.uid]
                        results[index] = {
                            "margin_ir_minus_re": float(
                                (
                                    logprobs[irrelevant_token]
                                    - logprobs[relevant_token]
                                ).item()
                            ),
                            "argmax_token_id": int(response.token),
                            "argmax_text": tokenizer.decode(
                                [int(response.token)]
                            ),
                        }
        finally:
            generator.close()
        completed += len(batch_records)
        print(
            json.dumps(
                {
                    "stage": "semantic_relevance_margin",
                    "completed": completed,
                    "total": len(prompts),
                    "batch_size": len(batch_records),
                    "min_prompt_tokens": len(batch_records[0][1]),
                    "max_prompt_tokens": len(batch_records[-1][1]),
                    "peak_memory_gb": round(stats.peak_memory, 3),
                },
                sort_keys=True,
            ),
            flush=True,
        )
        cursor = end
    if any(result is None for result in results):
        raise RuntimeError("missing semantic relevance margin")
    return tuple(dict(result) for result in results if result is not None)


def _chat_prompt(tokenizer, prompt: str) -> str:
    return tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}],
        tokenize=False,
        add_generation_prompt=True,
    )


def run_relevance_qualification(
    output_root: Path,
    model_name: str = DEFAULT_MODEL,
    datasets: Sequence[str] = (NQ_DATASET, DRUID_DATASET),
    config: str = CUB_CONFIG,
    split: str = "validation",
    per_context: int = 66,
    batch_size: int = 6,
    max_tokens: int = 1,
    max_batch_tokens: int = 12000,
    max_prompt_tokens: int = 4096,
    local_jsonl_by_dataset: Optional[Mapping[str, Path]] = None,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if not datasets:
        raise ValueError("at least one CUB dataset is required")
    unsupported = set(datasets).difference(DATASET_SPECS)
    if unsupported:
        raise ValueError(
            "unsupported CUB datasets: %s"
            % ", ".join(sorted(unsupported))
        )
    started = time.monotonic()
    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-semantic-relevance-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    selected_by_dataset = {}
    dataset_sources = {}
    prompts = []
    local_jsonl_by_dataset = dict(local_jsonl_by_dataset or {})
    for dataset in datasets:
        local_path = local_jsonl_by_dataset.get(dataset)
        if local_path is None:
            all_rows = fetch_cub_rows(dataset, config, split)
            dataset_sources[dataset] = {
                "kind": "huggingface_rows_api",
                "dataset": dataset,
                "config": config,
                "split": split,
            }
        else:
            all_rows = load_cub_jsonl(local_path)
            dataset_sources[dataset] = {
                "kind": "official_jsonl_snapshot",
                "path": str(local_path),
                "sha256": hashlib.sha256(
                    local_path.read_bytes()
                ).hexdigest(),
                "row_count": len(all_rows),
            }
        selected = balanced_slice(all_rows, per_context)
        selected_by_dataset[dataset] = selected
        for row in selected:
            prompts.append(relevance_prompt(row, dataset))

    model, tokenizer, model_config = load(
        model_name,
        return_config=True,
    )
    chat_prompts = tuple(
        _chat_prompt(tokenizer, prompt)
        for prompt in prompts
    )
    responses = _generate_relevance_labels(
        model,
        tokenizer,
        chat_prompts,
        batch_size,
        max_tokens,
        max_batch_tokens,
        max_prompt_tokens,
    )

    records = []
    metrics_by_dataset = {}
    baseline_metrics_by_dataset = {}
    cursor = 0
    for dataset in datasets:
        rows = selected_by_dataset[dataset]
        dataset_responses = responses[cursor : cursor + len(rows)]
        cursor += len(rows)
        metrics_by_dataset[dataset] = evaluate_relevance(
            rows,
            dataset_responses,
        ).as_dict()
        baseline_metrics_by_dataset[dataset] = (
            evaluate_published_regular(
                rows,
                relevant_match=DATASET_SPECS[dataset].relevant_match,
            ).as_dict()
        )
        for row, response in zip(rows, dataset_responses):
            records.append(
                {
                    "dataset": dataset,
                    "id": cub_row_id(row),
                    "context_type": row["context_type"],
                    "expected_relevant": expected_relevant(row),
                    "semantic_response": response,
                    "predicted_relevant": parse_relevance(response),
                }
            )
    if cursor != len(responses):
        raise RuntimeError("semantic relevance result cursor mismatch")

    records_digest = store.put(
        "cub_semantic_relevance_predictions",
        records,
    )
    payload = {
        "router_version": CUB_SEMANTIC_ROUTER_VERSION,
        "evaluation_mode": "published_relevance_expert_reproduction",
        "datasets": list(datasets),
        "config": config,
        "split": split,
        "selection": {
            "method": "first_n_per_context_in_published_order",
            "per_context": per_context,
            "total": len(records),
        },
        "dataset_sources": dataset_sources,
        "model": model_name,
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "batch_size": batch_size,
        "max_relevance_tokens": max_tokens,
        "max_batch_tokens": max_batch_tokens,
        "max_prompt_tokens": max_prompt_tokens,
        "batching": "length_sorted_token_budgeted",
        "metrics_by_dataset": metrics_by_dataset,
        "published_regular_metrics_by_dataset": (
            baseline_metrics_by_dataset
        ),
        "predictions_digest": records_digest,
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "This is a local quantized reproduction of CUB's published "
            "multi-agent relevance-assessment stage. Context labels are "
            "used only after inference for evaluation. The method is an "
            "incumbent, not a new candidate."
        ),
        "next_action": (
            "If the published relevance expert is not sufficiently "
            "accurate on adversarial irrelevant contexts, develop on "
            "validation and freeze a stronger label-free semantic test "
            "before evaluating an answer router on held-out data."
        ),
    }
    run_id = content_digest(payload)[:20]
    manifest = {**payload, "schema": 1, "qualification_id": run_id}
    store.write_manifest(
        "cognitive-core-cub-semantic-relevance-" + run_id,
        manifest,
    )
    return manifest


def _candidate_selection_key(
    candidate: Mapping[str, Any],
    datasets: Sequence[str],
) -> Tuple[float, float, float]:
    audited_scores = []
    balanced_scores = []
    for dataset in datasets:
        audited = candidate["audited_metrics_by_dataset"][dataset]
        audited_scores.append(
            audited["accuracy_by_context"]["irrelevant"]
        )
        balanced_scores.append(audited["balanced_accuracy"])
    return (
        min(audited_scores),
        sum(audited_scores) / len(audited_scores),
        sum(balanced_scores) / len(balanced_scores),
    )


def candidate_admissibility(
    candidate: Mapping[str, Any],
    incumbent: Mapping[str, Any],
    datasets: Sequence[str],
    capability_tolerance: float = 0.05,
    minimum_coverage: float = 0.95,
) -> Mapping[str, Any]:
    reasons = []
    for dataset in datasets:
        candidate_raw = candidate["raw_metrics_by_dataset"][dataset]
        incumbent_raw = incumbent["raw_metrics_by_dataset"][dataset]
        coverage_floor = min(
            minimum_coverage,
            incumbent_raw["coverage"],
        )
        if candidate_raw["coverage"] < coverage_floor:
            reasons.append(
                "%s coverage %.3f is below %.3f"
                % (
                    dataset,
                    candidate_raw["coverage"],
                    coverage_floor,
                )
            )
        for context_type in ("gold", "edited"):
            candidate_score = candidate_raw["accuracy_by_context"][
                context_type
            ]
            incumbent_score = incumbent_raw["accuracy_by_context"][
                context_type
            ]
            floor = incumbent_score - capability_tolerance
            if candidate_score < floor:
                reasons.append(
                    "%s %s accuracy %.3f is below incumbent-relative "
                    "floor %.3f"
                    % (
                        dataset,
                        context_type,
                        candidate_score,
                        floor,
                    )
                )
    return {
        "admissible": not reasons,
        "reasons": reasons,
        "capability_tolerance": capability_tolerance,
        "minimum_coverage": minimum_coverage,
    }


def run_relevance_prompt_search(
    output_root: Path,
    official_predictions_root: Path = DEFAULT_OFFICIAL_RELEVANCE_ROOT,
    official_predictions_digest: str = (
        DEFAULT_OFFICIAL_RELEVANCE_DIGEST
    ),
    model_name: str = DEFAULT_MODEL,
    candidates: Sequence[str] = (
        "strict_relation",
        "contrastive_relation",
    ),
    datasets: Sequence[str] = (NQ_DATASET, DRUID_DATASET),
    config: str = CUB_CONFIG,
    split: str = "validation",
    per_context: int = 66,
    batch_size: int = 12,
    max_tokens: int = 1,
    max_batch_tokens: int = 12000,
    max_prompt_tokens: int = 4096,
) -> Mapping[str, Any]:
    from mlx_lm import load

    unsupported_candidates = set(candidates).difference(PROMPT_VARIANTS)
    if unsupported_candidates:
        raise ValueError(
            "unsupported relevance candidates: %s"
            % ", ".join(sorted(unsupported_candidates))
        )
    unsupported_datasets = set(datasets).difference(DATASET_SPECS)
    if unsupported_datasets:
        raise ValueError(
            "unsupported CUB datasets: %s"
            % ", ".join(sorted(unsupported_datasets))
        )
    started = time.monotonic()
    selected_by_dataset = {
        dataset: balanced_slice(
            fetch_cub_rows(dataset, config, split),
            per_context,
        )
        for dataset in datasets
    }

    source_store = ArtifactStore(official_predictions_root)
    official_envelope = source_store.get(
        official_predictions_digest
    )
    if (
        official_envelope["kind"]
        != "cub_semantic_relevance_predictions"
    ):
        raise ValueError(
            "official source is not a semantic relevance artifact"
        )
    official_by_key = {
        (str(record["dataset"]), str(record["id"])): str(
            record["semantic_response"]
        )
        for record in official_envelope["value"]
    }

    responses_by_candidate: Dict[
        str,
        Dict[str, Tuple[str, ...]],
    ] = {
        "published_official": {
            dataset: tuple(
                official_by_key[(dataset, cub_row_id(row))]
                for row in selected_by_dataset[dataset]
            )
            for dataset in datasets
        }
    }
    model, tokenizer, model_config = load(
        model_name,
        return_config=True,
    )
    for candidate in candidates:
        prompts = []
        for dataset in datasets:
            prompts.extend(
                _chat_prompt(
                    tokenizer,
                    candidate_relevance_prompt(
                        row,
                        dataset,
                        candidate,
                    ),
                )
                for row in selected_by_dataset[dataset]
            )
        print(
            json.dumps(
                {
                    "stage": "relevance_prompt_search",
                    "candidate": candidate,
                    "examples": len(prompts),
                },
                sort_keys=True,
            ),
            flush=True,
        )
        responses = _generate_relevance_labels(
            model,
            tokenizer,
            prompts,
            batch_size,
            max_tokens,
            max_batch_tokens,
            max_prompt_tokens,
        )
        responses_by_candidate[candidate] = {}
        cursor = 0
        for dataset in datasets:
            count = len(selected_by_dataset[dataset])
            responses_by_candidate[candidate][dataset] = (
                responses[cursor : cursor + count]
            )
            cursor += count
        if cursor != len(responses):
            raise RuntimeError("candidate result cursor mismatch")

    candidate_summaries = {}
    records = []
    for candidate, by_dataset in responses_by_candidate.items():
        raw_metrics = {}
        audited_metrics = {}
        for dataset in datasets:
            rows = selected_by_dataset[dataset]
            responses = by_dataset[dataset]
            raw_metrics[dataset] = evaluate_relevance(
                rows,
                responses,
            ).as_dict()
            audited_rows = audited_relevance_rows(rows, dataset)
            audited_responses = tuple(
                response
                for row, response in zip(rows, responses)
                if row in audited_rows
            )
            audited_metrics[dataset] = evaluate_relevance(
                audited_rows,
                audited_responses,
            ).as_dict()
            for row, response in zip(rows, responses):
                records.append(
                    {
                        "candidate": candidate,
                        "dataset": dataset,
                        "id": cub_row_id(row),
                        "context_type": row["context_type"],
                        "answer_bearing_irrelevant": (
                            str(row["context_type"]) == "irrelevant"
                            and target_literal_in_context(row, dataset)
                        ),
                        "expected_relevant": expected_relevant(row),
                        "response": response,
                        "predicted_relevant": parse_relevance(response),
                    }
                )
        candidate_summaries[candidate] = {
            "raw_metrics_by_dataset": raw_metrics,
            "audited_metrics_by_dataset": audited_metrics,
        }

    incumbent = candidate_summaries["published_official"]
    admissibility = {
        name: candidate_admissibility(
            summary,
            incumbent,
            datasets,
        )
        for name, summary in candidate_summaries.items()
    }
    admissible_names = [
        name
        for name, decision in admissibility.items()
        if decision["admissible"]
    ]
    if not admissible_names:
        raise RuntimeError("relevance search has no admissible incumbent")
    selected_name = max(
        admissible_names,
        key=lambda name: _candidate_selection_key(
            candidate_summaries[name],
            datasets,
        ),
    )
    selection_keys = {
        name: list(
            _candidate_selection_key(summary, datasets)
        )
        for name, summary in candidate_summaries.items()
    }

    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-relevance-prompt-search-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    records_digest = store.put(
        "cub_relevance_prompt_search_predictions",
        records,
    )
    label_audit = {
        dataset: {
            "answer_bearing_irrelevant": sum(
                1
                for row in selected_by_dataset[dataset]
                if (
                    str(row["context_type"]) == "irrelevant"
                    and target_literal_in_context(row, dataset)
                )
            ),
            "irrelevant_total": sum(
                str(row["context_type"]) == "irrelevant"
                for row in selected_by_dataset[dataset]
            ),
        }
        for dataset in datasets
    }
    payload = {
        "search_version": CUB_RELEVANCE_SEARCH_VERSION,
        "evaluation_mode": "validation_prompt_search",
        "datasets": list(datasets),
        "config": config,
        "split": split,
        "selection": {
            "method": "first_n_per_context_in_published_order",
            "per_context": per_context,
            "total_per_candidate": sum(
                len(rows)
                for rows in selected_by_dataset.values()
            ),
        },
        "model": model_name,
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "execution": {
            "batch_size_cap": batch_size,
            "max_batch_tokens": max_batch_tokens,
            "max_prompt_tokens": max_prompt_tokens,
            "max_relevance_tokens": max_tokens,
            "batching": "length_sorted_token_budgeted",
        },
        "official_predictions_digest": official_predictions_digest,
        "generated_candidates": list(candidates),
        "candidate_summaries": candidate_summaries,
        "selection_objective": (
            "first require at least 95% parse coverage and no gold or "
            "conflicting slice more than 5 points below the published "
            "incumbent; among admissible candidates maximize the worst "
            "audited irrelevant accuracy, then its cross-dataset mean"
        ),
        "admissibility": admissibility,
        "selection_keys": selection_keys,
        "selected_candidate": selected_name,
        "label_audit": label_audit,
        "predictions_digest": records_digest,
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "Validation-only search among prompting variants in an "
            "established relevance-routing family. The audited NQ view "
            "removes alleged irrelevant contexts that literally contain "
            "the gold answer. Neither raw nor audited validation scores "
            "establish a new method or held-out improvement."
        ),
        "next_action": (
            "Freeze the selected semantic test only if it materially "
            "improves the incumbent without collapsing gold/conflicting "
            "recognition; then evaluate answer routing on held-out NQ "
            "and DRUID subsets with the raw and audited views reported."
        ),
    }
    search_id = content_digest(payload)[:20]
    manifest = {**payload, "schema": 1, "search_id": search_id}
    store.write_manifest(
        "cognitive-core-cub-relevance-search-" + search_id,
        manifest,
    )
    return manifest


def rescore_relevance_prompt_search(
    source_manifest_path: Path,
    output_root: Path,
    capability_tolerance: float = 0.05,
    minimum_coverage: float = 0.95,
) -> Mapping[str, Any]:
    source = json.loads(
        source_manifest_path.read_text(encoding="utf-8")
    )
    summaries = source["candidate_summaries"]
    datasets = tuple(source["datasets"])
    incumbent = summaries["published_official"]
    admissibility = {
        name: candidate_admissibility(
            summary,
            incumbent,
            datasets,
            capability_tolerance,
            minimum_coverage,
        )
        for name, summary in summaries.items()
    }
    admissible_names = [
        name
        for name, decision in admissibility.items()
        if decision["admissible"]
    ]
    if not admissible_names:
        raise ValueError("rescoring removed the published incumbent")
    selection_keys = {
        name: list(_candidate_selection_key(summary, datasets))
        for name, summary in summaries.items()
    }
    selected_name = max(
        admissible_names,
        key=lambda name: _candidate_selection_key(
            summaries[name],
            datasets,
        ),
    )

    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-relevance-search-rescore-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    source_digest = store.put(
        "cub_relevance_search_source_manifest",
        source,
    )
    payload = {
        "search_version": CUB_RELEVANCE_SEARCH_VERSION,
        "evaluation_mode": "constraint_corrected_validation_rescore",
        "source_search_id": source["search_id"],
        "source_manifest_digest": source_digest,
        "datasets": list(datasets),
        "config": source["config"],
        "split": source["split"],
        "model": source["model"],
        "candidate_summaries": summaries,
        "label_audit": source["label_audit"],
        "admissibility": admissibility,
        "selection_objective": (
            "require minimum output coverage and incumbent-relative "
            "gold/conflicting capability floors before optimizing "
            "audited irrelevant-context accuracy"
        ),
        "selection_keys": selection_keys,
        "selected_candidate": selected_name,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "claim_boundary": (
            "Post-hoc correction of a validation selector before any "
            "holdout access. The original unconstrained choice is "
            "invalidated and retained as a failed decision artifact."
        ),
        "next_action": (
            "Do not advance either generated prompt to held-out answer "
            "routing. Preserve the published relevance expert as the "
            "incumbent and test a mechanism that can improve distractor "
            "rejection without suppressing relevant evidence."
        ),
    }
    rescore_id = content_digest(payload)[:20]
    manifest = {**payload, "schema": 1, "rescore_id": rescore_id}
    store.write_manifest(
        "cognitive-core-cub-relevance-rescore-" + rescore_id,
        manifest,
    )
    return manifest


def run_witness_router_search(
    output_root: Path,
    official_predictions_root: Path = DEFAULT_OFFICIAL_RELEVANCE_ROOT,
    official_predictions_digest: str = (
        DEFAULT_OFFICIAL_RELEVANCE_DIGEST
    ),
    model_name: str = DEFAULT_MODEL,
    datasets: Sequence[str] = (NQ_DATASET, DRUID_DATASET),
    config: str = CUB_CONFIG,
    split: str = "validation",
    per_context: int = 66,
    batch_size: int = 12,
    max_tokens: int = 24,
    max_batch_tokens: int = 12000,
    max_prompt_tokens: int = 4096,
    capability_tolerance: float = 0.02,
    minimum_coverage: float = 0.95,
    local_jsonl_by_dataset: Optional[Mapping[str, Path]] = None,
) -> Mapping[str, Any]:
    """Search grounded-witness routing policies on validation."""

    from mlx_lm import load

    started = time.monotonic()
    local_jsonl_by_dataset = dict(local_jsonl_by_dataset or {})
    selected_by_dataset = {}
    dataset_sources = {}
    for dataset in datasets:
        local_path = local_jsonl_by_dataset.get(dataset)
        if local_path is None:
            all_rows = fetch_cub_rows(dataset, config, split)
            dataset_sources[dataset] = {
                "kind": "huggingface_rows_api",
                "dataset": dataset,
                "config": config,
                "split": split,
            }
        else:
            all_rows = load_cub_jsonl(local_path)
            dataset_sources[dataset] = {
                "kind": "official_jsonl_snapshot",
                "path": str(local_path),
                "sha256": hashlib.sha256(
                    local_path.read_bytes()
                ).hexdigest(),
                "row_count": len(all_rows),
            }
        selected_by_dataset[dataset] = balanced_slice(
            all_rows,
            per_context,
        )

    source_store = ArtifactStore(official_predictions_root)
    official_envelope = source_store.get(
        official_predictions_digest
    )
    if (
        official_envelope["kind"]
        != "cub_semantic_relevance_predictions"
    ):
        raise ValueError(
            "official source is not a semantic relevance artifact"
        )
    official_by_key = {
        (str(record["dataset"]), str(record["id"])): str(
            record["semantic_response"]
        )
        for record in official_envelope["value"]
    }
    official_by_dataset = {
        dataset: tuple(
            official_by_key[(dataset, cub_row_id(row))]
            for row in selected_by_dataset[dataset]
        )
        for dataset in datasets
    }

    model, tokenizer, model_config = load(
        model_name,
        return_config=True,
    )
    prompts = []
    for dataset in datasets:
        prompts.extend(
            _chat_prompt(tokenizer, witness_prompt(row, dataset))
            for row in selected_by_dataset[dataset]
        )
    witness_responses = _generate_relevance_labels(
        model,
        tokenizer,
        prompts,
        batch_size,
        max_tokens,
        max_batch_tokens,
        max_prompt_tokens,
    )
    witness_by_dataset = {}
    cursor = 0
    for dataset in datasets:
        count = len(selected_by_dataset[dataset])
        witness_by_dataset[dataset] = witness_responses[
            cursor : cursor + count
        ]
        cursor += count
    if cursor != len(witness_responses):
        raise RuntimeError("witness result cursor mismatch")

    responses_by_policy = {
        "published_official": official_by_dataset,
    }
    for policy in ("witness_only", "official_veto", "official_union"):
        responses_by_policy[policy] = {
            dataset: witness_routed_responses(
                selected_by_dataset[dataset],
                dataset,
                official_by_dataset[dataset],
                witness_by_dataset[dataset],
                policy,
            )
            for dataset in datasets
        }

    summaries = {
        policy: _summary_for_responses(
            selected_by_dataset,
            responses,
        )
        for policy, responses in responses_by_policy.items()
    }
    incumbent = summaries["published_official"]
    admissibility = {
        policy: candidate_admissibility(
            summary,
            incumbent,
            datasets,
            capability_tolerance,
            minimum_coverage,
        )
        for policy, summary in summaries.items()
    }
    admissible = [
        policy
        for policy, decision in admissibility.items()
        if decision["admissible"]
    ]
    if not admissible:
        raise RuntimeError("witness search lost its incumbent")
    selected_policy = max(
        admissible,
        key=lambda policy: _candidate_selection_key(
            summaries[policy],
            datasets,
        ),
    )

    records = []
    for dataset in datasets:
        for index, (row, official, witness) in enumerate(
            zip(
                selected_by_dataset[dataset],
                official_by_dataset[dataset],
                witness_by_dataset[dataset],
            )
        ):
            records.append(
                {
                    "dataset": dataset,
                    "id": cub_row_id(row),
                    "context_type": row["context_type"],
                    "answer_bearing_irrelevant": (
                        str(row["context_type"]) == "irrelevant"
                        and target_literal_in_context(row, dataset)
                    ),
                    "official_response": official,
                    "witness_response": witness,
                    "witness_grounded": witness_is_grounded(
                        witness,
                        row,
                        dataset,
                    ),
                    "policy_responses": {
                        policy: responses_by_policy[policy][dataset][
                            index
                        ]
                        for policy in responses_by_policy
                    },
                }
            )

    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        CUB_WITNESS_ROUTER_VERSION
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    predictions_digest = store.put(
        "cub_witness_router_predictions",
        records,
    )
    payload = {
        "witness_version": CUB_WITNESS_ROUTER_VERSION,
        "evaluation_mode": "validation_grounded_witness_policy_search",
        "datasets": list(datasets),
        "config": config,
        "split": split,
        "selection": {
            "method": "first_n_per_context_in_published_order",
            "per_context": per_context,
            "total": len(records),
        },
        "dataset_sources": dataset_sources,
        "model": model_name,
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "policies": list(responses_by_policy),
        "candidate_summaries": summaries,
        "capability_tolerance": capability_tolerance,
        "minimum_coverage": minimum_coverage,
        "admissibility": admissibility,
        "selection_keys": {
            policy: list(
                _candidate_selection_key(summary, datasets)
            )
            for policy, summary in summaries.items()
        },
        "selected_policy": selected_policy,
        "selected_summary": summaries[selected_policy],
        "source_official_predictions_digest": (
            official_predictions_digest
        ),
        "predictions_digest": predictions_digest,
        "execution": {
            "batch_size_cap": batch_size,
            "max_generation_tokens": max_tokens,
            "max_batch_tokens": max_batch_tokens,
            "max_prompt_tokens": max_prompt_tokens,
            "batching": "length_sorted_token_budgeted",
        },
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "Validation-only search over three fixed compositions of an "
            "established extractive-answerability idea and the published "
            "relevance expert. Generated text is accepted only when its "
            "complete token sequence occurs in the evidence. This is not "
            "a novelty or held-out-performance claim."
        ),
        "next_action": (
            "If a non-incumbent policy is admissible and materially "
            "improves audited distractor rejection, freeze the prompt and "
            "policy for held-out evaluation. Otherwise reject grounded "
            "witness extraction at this model scale and train a router "
            "from separately supervised subject and relation targets."
        ),
    }
    search_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "search_id": search_id,
    }
    store.write_manifest(
        "cognitive-core-cub-witness-router-" + search_id,
        manifest,
    )
    return manifest


def _hybrid_veto_responses(
    official_responses: Sequence[str],
    margins: Sequence[float],
    threshold: float,
) -> Tuple[str, ...]:
    if len(official_responses) != len(margins):
        raise ValueError("official responses and margins do not align")
    routed = []
    for response, margin in zip(official_responses, margins):
        official = parse_relevance(response)
        if official is True and margin > threshold:
            routed.append("Ir")
        else:
            routed.append(response)
    return tuple(routed)


def _summary_for_responses(
    selected_by_dataset: Mapping[
        str,
        Sequence[Mapping[str, Any]],
    ],
    responses_by_dataset: Mapping[str, Sequence[str]],
) -> Mapping[str, Any]:
    raw_metrics = {}
    audited_metrics = {}
    for dataset, rows in selected_by_dataset.items():
        responses = tuple(responses_by_dataset[dataset])
        raw_metrics[dataset] = evaluate_relevance(
            rows,
            responses,
        ).as_dict()
        retained = [
            not (
                str(row["context_type"]) == "irrelevant"
                and target_literal_in_context(row, dataset)
            )
            for row in rows
        ]
        audited_rows = tuple(
            row
            for row, keep in zip(rows, retained)
            if keep
        )
        audited_responses = tuple(
            response
            for response, keep in zip(responses, retained)
            if keep
        )
        audited_metrics[dataset] = evaluate_relevance(
            audited_rows,
            audited_responses,
        ).as_dict()
    return {
        "raw_metrics_by_dataset": raw_metrics,
        "audited_metrics_by_dataset": audited_metrics,
    }


def run_selective_veto_search(
    output_root: Path,
    official_predictions_root: Path = DEFAULT_OFFICIAL_RELEVANCE_ROOT,
    official_predictions_digest: str = (
        DEFAULT_OFFICIAL_RELEVANCE_DIGEST
    ),
    model_name: str = DEFAULT_MODEL,
    datasets: Sequence[str] = (NQ_DATASET, DRUID_DATASET),
    config: str = CUB_CONFIG,
    split: str = "validation",
    per_context: int = 66,
    batch_size: int = 12,
    max_batch_tokens: int = 12000,
    max_prompt_tokens: int = 4096,
    capability_tolerance: float = 0.05,
    minimum_coverage: float = 0.95,
) -> Mapping[str, Any]:
    from mlx_lm import load

    started = time.monotonic()
    selected_by_dataset = {
        dataset: balanced_slice(
            fetch_cub_rows(dataset, config, split),
            per_context,
        )
        for dataset in datasets
    }
    source_store = ArtifactStore(official_predictions_root)
    official_envelope = source_store.get(
        official_predictions_digest
    )
    if (
        official_envelope["kind"]
        != "cub_semantic_relevance_predictions"
    ):
        raise ValueError(
            "official source is not a semantic relevance artifact"
        )
    official_by_key = {
        (str(record["dataset"]), str(record["id"])): str(
            record["semantic_response"]
        )
        for record in official_envelope["value"]
    }
    official_by_dataset = {
        dataset: tuple(
            official_by_key[(dataset, cub_row_id(row))]
            for row in selected_by_dataset[dataset]
        )
        for dataset in datasets
    }
    incumbent = _summary_for_responses(
        selected_by_dataset,
        official_by_dataset,
    )

    model, tokenizer, model_config = load(
        model_name,
        return_config=True,
    )
    prompts = []
    ordered_keys = []
    for dataset in datasets:
        for row in selected_by_dataset[dataset]:
            prompts.append(
                _chat_prompt(
                    tokenizer,
                    candidate_relevance_prompt(
                        row,
                        dataset,
                        "strict_relation",
                    ),
                )
            )
            ordered_keys.append((dataset, cub_row_id(row)))
    margin_results = _generate_relevance_margins(
        model,
        tokenizer,
        prompts,
        batch_size,
        max_batch_tokens,
        max_prompt_tokens,
    )
    margins_by_dataset: Dict[str, Tuple[float, ...]] = {}
    cursor = 0
    for dataset in datasets:
        count = len(selected_by_dataset[dataset])
        margins_by_dataset[dataset] = tuple(
            float(record["margin_ir_minus_re"])
            for record in margin_results[cursor : cursor + count]
        )
        cursor += count

    unique_margins = sorted(
        {
            margin
            for margins in margins_by_dataset.values()
            for margin in margins
        }
    )
    thresholds = [unique_margins[0] - 1.0]
    thresholds.extend(
        (left + right) / 2.0
        for left, right in zip(
            unique_margins,
            unique_margins[1:],
        )
    )
    thresholds.append(unique_margins[-1] + 1.0)

    curve = []
    for threshold in thresholds:
        responses_by_dataset = {
            dataset: _hybrid_veto_responses(
                official_by_dataset[dataset],
                margins_by_dataset[dataset],
                threshold,
            )
            for dataset in datasets
        }
        summary = _summary_for_responses(
            selected_by_dataset,
            responses_by_dataset,
        )
        decision = candidate_admissibility(
            summary,
            incumbent,
            datasets,
            capability_tolerance,
            minimum_coverage,
        )
        vetoed = sum(
            response_before != response_after
            for dataset in datasets
            for response_before, response_after in zip(
                official_by_dataset[dataset],
                responses_by_dataset[dataset],
            )
        )
        curve.append(
            {
                "threshold": threshold,
                "veto_count": vetoed,
                "veto_fraction": vetoed
                / sum(
                    len(rows)
                    for rows in selected_by_dataset.values()
                ),
                "summary": summary,
                "admissibility": decision,
            }
        )
    admissible = [
        candidate
        for candidate in curve
        if candidate["admissibility"]["admissible"]
    ]
    if not admissible:
        raise RuntimeError("selective-veto search lost its incumbent")
    selected = max(
        admissible,
        key=lambda candidate: _candidate_selection_key(
            candidate["summary"],
            datasets,
        ),
    )

    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-selective-veto-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    curve_digest = store.put(
        "cub_selective_veto_validation_curve",
        curve,
    )
    margin_records = [
        {
            "dataset": dataset,
            "id": row_id,
            **dict(result),
        }
        for (dataset, row_id), result in zip(
            ordered_keys,
            margin_results,
        )
    ]
    margins_digest = store.put(
        "cub_selective_veto_margins",
        margin_records,
    )
    selected_threshold = float(selected["threshold"])
    selected_records = []
    for dataset in datasets:
        routed = _hybrid_veto_responses(
            official_by_dataset[dataset],
            margins_by_dataset[dataset],
            selected_threshold,
        )
        for row, official, margin, response in zip(
            selected_by_dataset[dataset],
            official_by_dataset[dataset],
            margins_by_dataset[dataset],
            routed,
        ):
            selected_records.append(
                {
                    "dataset": dataset,
                    "id": cub_row_id(row),
                    "context_type": row["context_type"],
                    "official_response": official,
                    "strict_margin_ir_minus_re": margin,
                    "routed_response": response,
                    "vetoed": response != official,
                }
            )
    selected_records_digest = store.put(
        "cub_selective_veto_predictions",
        selected_records,
    )
    payload = {
        "veto_version": CUB_SELECTIVE_VETO_VERSION,
        "evaluation_mode": "validation_confidence_veto_search",
        "datasets": list(datasets),
        "config": config,
        "split": split,
        "model": model_name,
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "source_official_predictions_digest": (
            official_predictions_digest
        ),
        "score_prompt": "strict_relation",
        "score_definition": (
            "first-token log P(Ir) minus log P(Re)"
        ),
        "routing_rule": (
            "preserve the published expert decision except veto Relevant "
            "when the strict-relation irrelevance margin exceeds the "
            "frozen threshold"
        ),
        "capability_tolerance": capability_tolerance,
        "minimum_coverage": minimum_coverage,
        "candidate_count": len(curve),
        "selected": selected,
        "curve_digest": curve_digest,
        "margins_digest": margins_digest,
        "selected_predictions_digest": selected_records_digest,
        "execution": {
            "batch_size_cap": batch_size,
            "max_batch_tokens": max_batch_tokens,
            "max_prompt_tokens": max_prompt_tokens,
            "batching": "length_sorted_token_budgeted",
        },
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "Validation-tuned confidence veto combining two prompting "
            "signals in an established relevance-routing family. Any "
            "surviving threshold must be frozen before held-out use and "
            "does not establish novelty."
        ),
        "next_action": (
            "If an admissible nontrivial veto survives, freeze its "
            "threshold and test semantic classification plus downstream "
            "answer routing on held-out NQ and DRUID; otherwise refute "
            "prompt-only semantic gating at this model scale."
        ),
    }
    veto_id = content_digest(payload)[:20]
    manifest = {**payload, "schema": 1, "veto_id": veto_id}
    store.write_manifest(
        "cognitive-core-cub-selective-veto-" + veto_id,
        manifest,
    )
    return manifest


def paired_relevance_changes(
    rows: Sequence[Mapping[str, Any]],
    incumbent_responses: Sequence[str],
    candidate_responses: Sequence[str],
) -> Mapping[str, Any]:
    if not (
        len(rows)
        == len(incumbent_responses)
        == len(candidate_responses)
    ):
        raise ValueError("paired relevance inputs do not align")
    changes = {
        context_type: {
            "corrected": 0,
            "harmed": 0,
            "unchanged": 0,
        }
        for context_type in ("gold", "edited", "irrelevant")
    }
    for row, incumbent, candidate in zip(
        rows,
        incumbent_responses,
        candidate_responses,
    ):
        context_type = str(row["context_type"])
        expected = expected_relevant(row)
        before_correct = parse_relevance(incumbent) == expected
        after_correct = parse_relevance(candidate) == expected
        if after_correct and not before_correct:
            changes[context_type]["corrected"] += 1
        elif before_correct and not after_correct:
            changes[context_type]["harmed"] += 1
        else:
            changes[context_type]["unchanged"] += 1
    totals = {
        key: sum(changes[context_type][key] for context_type in changes)
        for key in ("corrected", "harmed", "unchanged")
    }
    return {
        "by_context": changes,
        "total": totals,
        "net_corrections": totals["corrected"] - totals["harmed"],
    }


def run_frozen_veto_evaluation(
    output_root: Path,
    validation_manifest_path: Path,
    model_name: str = DEFAULT_MODEL,
    datasets: Sequence[str] = (NQ_DATASET, DRUID_DATASET),
    config: str = CUB_CONFIG,
    split: str = "test",
    per_context: int = 20,
    batch_size: int = 12,
    max_tokens: int = 1,
    max_batch_tokens: int = 12000,
    max_prompt_tokens: int = 4096,
    local_jsonl_by_dataset: Optional[Mapping[str, Path]] = None,
) -> Mapping[str, Any]:
    """Evaluate a validation-selected veto without searching the test set."""

    from mlx_lm import load

    started = time.monotonic()
    validation = json.loads(
        validation_manifest_path.read_text(encoding="utf-8")
    )
    if validation.get("veto_version") != CUB_SELECTIVE_VETO_VERSION:
        raise ValueError("source manifest is not a selective-veto search")
    if validation.get("split") != "validation":
        raise ValueError("frozen veto must come from validation")
    if model_name != validation.get("model"):
        raise ValueError("evaluation model differs from frozen model")
    if config != validation.get("config"):
        raise ValueError("evaluation config differs from frozen config")
    unsupported = set(datasets).difference(validation.get("datasets", ()))
    if unsupported:
        raise ValueError(
            "evaluation datasets absent from frozen search: %s"
            % ", ".join(sorted(unsupported))
        )
    if split == validation.get("split"):
        raise ValueError("frozen evaluation split must be held out")
    threshold = float(validation["selected"]["threshold"])

    local_jsonl_by_dataset = dict(local_jsonl_by_dataset or {})
    selected_by_dataset = {}
    dataset_sources = {}
    for dataset in datasets:
        local_path = local_jsonl_by_dataset.get(dataset)
        if local_path is None:
            all_rows = fetch_cub_rows(dataset, config, split)
            dataset_sources[dataset] = {
                "kind": "huggingface_rows_api",
                "dataset": dataset,
                "config": config,
                "split": split,
            }
        else:
            all_rows = load_cub_jsonl(local_path)
            dataset_sources[dataset] = {
                "kind": "official_jsonl_snapshot",
                "path": str(local_path),
                "sha256": hashlib.sha256(
                    local_path.read_bytes()
                ).hexdigest(),
                "row_count": len(all_rows),
            }
        selected_by_dataset[dataset] = balanced_slice(
            all_rows,
            per_context,
        )
    model, tokenizer, model_config = load(
        model_name,
        return_config=True,
    )
    official_prompts = []
    strict_prompts = []
    for dataset in datasets:
        for row in selected_by_dataset[dataset]:
            official_prompts.append(
                _chat_prompt(tokenizer, relevance_prompt(row, dataset))
            )
            strict_prompts.append(
                _chat_prompt(
                    tokenizer,
                    candidate_relevance_prompt(
                        row,
                        dataset,
                        "strict_relation",
                    ),
                )
            )
    official_responses = _generate_relevance_labels(
        model,
        tokenizer,
        official_prompts,
        batch_size,
        max_tokens,
        max_batch_tokens,
        max_prompt_tokens,
    )
    margin_results = _generate_relevance_margins(
        model,
        tokenizer,
        strict_prompts,
        batch_size,
        max_batch_tokens,
        max_prompt_tokens,
    )

    official_by_dataset: Dict[str, Tuple[str, ...]] = {}
    candidate_by_dataset: Dict[str, Tuple[str, ...]] = {}
    margins_by_dataset: Dict[str, Tuple[float, ...]] = {}
    cursor = 0
    for dataset in datasets:
        count = len(selected_by_dataset[dataset])
        official = official_responses[cursor : cursor + count]
        margins = tuple(
            float(record["margin_ir_minus_re"])
            for record in margin_results[cursor : cursor + count]
        )
        official_by_dataset[dataset] = official
        margins_by_dataset[dataset] = margins
        candidate_by_dataset[dataset] = _hybrid_veto_responses(
            official,
            margins,
            threshold,
        )
        cursor += count
    if cursor != len(official_responses):
        raise RuntimeError("frozen evaluation result cursor mismatch")

    incumbent = _summary_for_responses(
        selected_by_dataset,
        official_by_dataset,
    )
    candidate = _summary_for_responses(
        selected_by_dataset,
        candidate_by_dataset,
    )
    paired_changes = {
        dataset: paired_relevance_changes(
            selected_by_dataset[dataset],
            official_by_dataset[dataset],
            candidate_by_dataset[dataset],
        )
        for dataset in datasets
    }
    safety = candidate_admissibility(
        candidate,
        incumbent,
        datasets,
        float(validation["capability_tolerance"]),
        float(validation["minimum_coverage"]),
    )
    audited_balanced_delta = {
        dataset: (
            candidate["audited_metrics_by_dataset"][dataset][
                "balanced_accuracy"
            ]
            - incumbent["audited_metrics_by_dataset"][dataset][
                "balanced_accuracy"
            ]
        )
        for dataset in datasets
    }
    mean_audited_balanced_delta = sum(
        audited_balanced_delta.values()
    ) / len(audited_balanced_delta)
    net_corrections = sum(
        change["net_corrections"]
        for change in paired_changes.values()
    )
    survived = bool(
        safety["admissible"]
        and mean_audited_balanced_delta > 0.0
        and net_corrections > 0
    )

    records = []
    for dataset in datasets:
        for row, official, margin, routed in zip(
            selected_by_dataset[dataset],
            official_by_dataset[dataset],
            margins_by_dataset[dataset],
            candidate_by_dataset[dataset],
        ):
            records.append(
                {
                    "dataset": dataset,
                    "id": cub_row_id(row),
                    "context_type": row["context_type"],
                    "answer_bearing_irrelevant": (
                        str(row["context_type"]) == "irrelevant"
                        and target_literal_in_context(row, dataset)
                    ),
                    "official_response": official,
                    "strict_margin_ir_minus_re": margin,
                    "routed_response": routed,
                    "vetoed": routed != official,
                    "official_correct": (
                        parse_relevance(official)
                        == expected_relevant(row)
                    ),
                    "routed_correct": (
                        parse_relevance(routed)
                        == expected_relevant(row)
                    ),
                }
            )

    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-cub-frozen-veto-evaluation-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    predictions_digest = store.put(
        "cub_frozen_veto_predictions",
        records,
    )
    payload = {
        "evaluation_version": CUB_FROZEN_VETO_EVALUATION_VERSION,
        "evaluation_mode": "heldout_frozen_confidence_veto",
        "source_validation_manifest": str(validation_manifest_path),
        "source_veto_id": validation["veto_id"],
        "frozen_threshold": threshold,
        "datasets": list(datasets),
        "config": config,
        "split": split,
        "selection": {
            "method": "first_n_per_context_in_published_order",
            "per_context": per_context,
            "total": len(records),
        },
        "dataset_sources": dataset_sources,
        "model": model_name,
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "incumbent_summary": incumbent,
        "candidate_summary": candidate,
        "paired_changes": paired_changes,
        "audited_balanced_delta_by_dataset": audited_balanced_delta,
        "mean_audited_balanced_delta": mean_audited_balanced_delta,
        "heldout_safety": safety,
        "survived_predeclared_test": survived,
        "predictions_digest": predictions_digest,
        "execution": {
            "batch_size_cap": batch_size,
            "max_batch_tokens": max_batch_tokens,
            "max_prompt_tokens": max_prompt_tokens,
            "batching": "length_sorted_token_budgeted",
        },
        "benchmark_repository": CUB_REPOSITORY,
        "benchmark_commit": CUB_COMMIT,
        "prior_art_assessment_id": assessment.assessment_id,
        "prior_art_object_digest": assessment_digest,
        "elapsed_seconds": time.monotonic() - started,
        "claim_boundary": (
            "The threshold was selected once on validation and applied "
            "unchanged to a deterministic held-out slice. This is a "
            "component test of relevance classification, not evidence "
            "of a downstream cognitive-core solution or novelty."
        ),
        "next_action": (
            "Only if the frozen veto yields positive net corrections "
            "and positive audited balanced accuracy without violating "
            "the safety constraint, test its downstream answer routing. "
            "Otherwise reject this prompt-confidence mechanism and "
            "advance to a learned or decomposed semantic router."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {
        **payload,
        "schema": 1,
        "evaluation_id": evaluation_id,
    }
    store.write_manifest(
        "cognitive-core-cub-frozen-veto-" + evaluation_id,
        manifest,
    )
    return manifest


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/cub_semantic_relevance_v1",
    )
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument(
        "--datasets",
        default=NQ_DATASET + "," + DRUID_DATASET,
    )
    parser.add_argument("--config", default=CUB_CONFIG)
    parser.add_argument("--split", default="validation")
    parser.add_argument("--per-context", type=int, default=66)
    parser.add_argument("--batch-size", type=int, default=12)
    parser.add_argument("--max-tokens", type=int, default=1)
    parser.add_argument("--max-batch-tokens", type=int, default=12000)
    parser.add_argument("--max-prompt-tokens", type=int, default=4096)
    parser.add_argument(
        "--search",
        action="store_true",
        help="search frozen semantic relevance prompt variants",
    )
    parser.add_argument(
        "--candidates",
        default="strict_relation,contrastive_relation",
    )
    parser.add_argument(
        "--official-root",
        default=str(DEFAULT_OFFICIAL_RELEVANCE_ROOT),
    )
    parser.add_argument(
        "--official-digest",
        default=DEFAULT_OFFICIAL_RELEVANCE_DIGEST,
    )
    parser.add_argument(
        "--rescore-manifest",
        default=None,
        help="rescore an existing prompt-search manifest without inference",
    )
    parser.add_argument(
        "--selective-veto",
        action="store_true",
        help="tune a confidence veto over the published relevance expert",
    )
    parser.add_argument(
        "--evaluate-frozen-veto",
        action="store_true",
        help="evaluate a validation-selected veto on a held-out split",
    )
    parser.add_argument(
        "--witness-search",
        action="store_true",
        help="search grounded extractive-witness routing policies",
    )
    parser.add_argument(
        "--veto-manifest",
        default=None,
        help="validation selective-veto manifest to freeze",
    )
    parser.add_argument(
        "--local-jsonl",
        default="",
        help="comma-separated dataset=official_jsonl_path mappings",
    )
    arguments = parser.parse_args(list(argv) or None)
    datasets = tuple(
        item.strip()
        for item in arguments.datasets.split(",")
        if item.strip()
    )
    local_jsonl_by_dataset = {}
    for item in arguments.local_jsonl.split(","):
        if not item.strip():
            continue
        if "=" not in item:
            parser.error("--local-jsonl entries must be dataset=path")
        dataset, path = item.split("=", 1)
        local_jsonl_by_dataset[dataset.strip()] = Path(path.strip())
    if arguments.witness_search:
        manifest = run_witness_router_search(
            Path(arguments.output),
            Path(arguments.official_root),
            arguments.official_digest,
            arguments.model,
            datasets,
            arguments.config,
            arguments.split,
            arguments.per_context,
            arguments.batch_size,
            arguments.max_tokens,
            arguments.max_batch_tokens,
            arguments.max_prompt_tokens,
            local_jsonl_by_dataset=local_jsonl_by_dataset,
        )
    elif arguments.evaluate_frozen_veto:
        if not arguments.veto_manifest:
            parser.error("--evaluate-frozen-veto requires --veto-manifest")
        manifest = run_frozen_veto_evaluation(
            Path(arguments.output),
            Path(arguments.veto_manifest),
            arguments.model,
            datasets,
            arguments.config,
            arguments.split,
            arguments.per_context,
            arguments.batch_size,
            arguments.max_tokens,
            arguments.max_batch_tokens,
            arguments.max_prompt_tokens,
            local_jsonl_by_dataset,
        )
    elif arguments.selective_veto:
        manifest = run_selective_veto_search(
            Path(arguments.output),
            Path(arguments.official_root),
            arguments.official_digest,
            arguments.model,
            datasets,
            arguments.config,
            arguments.split,
            arguments.per_context,
            arguments.batch_size,
            arguments.max_batch_tokens,
            arguments.max_prompt_tokens,
        )
    elif arguments.rescore_manifest:
        manifest = rescore_relevance_prompt_search(
            Path(arguments.rescore_manifest),
            Path(arguments.output),
        )
    elif arguments.search:
        manifest = run_relevance_prompt_search(
            Path(arguments.output),
            Path(arguments.official_root),
            arguments.official_digest,
            arguments.model,
            tuple(
                item.strip()
                for item in arguments.candidates.split(",")
                if item.strip()
            ),
            datasets,
            arguments.config,
            arguments.split,
            arguments.per_context,
            arguments.batch_size,
            arguments.max_tokens,
            arguments.max_batch_tokens,
            arguments.max_prompt_tokens,
        )
    else:
        manifest = run_relevance_qualification(
            Path(arguments.output),
            arguments.model,
            datasets,
            arguments.config,
            arguments.split,
            arguments.per_context,
            arguments.batch_size,
            arguments.max_tokens,
            arguments.max_batch_tokens,
            arguments.max_prompt_tokens,
            local_jsonl_by_dataset,
        )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
