from __future__ import annotations

import re
from typing import Any, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.joint_relational_comparator_v52l import (
    comparator_metrics,
)


DECOMPOSED_RELATION_POLICY_VERSION = (
    "general-cognitive-decomposed-relation-policy-v52p"
)
M52P_SEED = 52971
M52P_M52O_AUDIT_ID = (
    "95360274b421335510197322d594380cf61d2b27d7df518f0b7f7e1f711ebe0b"
)
M52P_GRAMMAR = "A_REL <YES|NO> | B_REL <YES|NO> | ANSWER <A|B>"
_RESPONSE = re.compile(
    r"^\s*A_REL\s+(YES|NO)\s*\|\s*B_REL\s+(YES|NO)\s*\|\s*ANSWER\s+([AB])\s*$",
    re.IGNORECASE,
)


def decomposed_relation_prompt(basis: str, candidate_a: str, candidate_b: str) -> str:
    return (
        "A research conclusion assumes this operating condition:\n"
        f"{basis}\n\n"
        "Current candidate A:\n"
        f"{candidate_a}\n\n"
        "Current candidate B:\n"
        f"{candidate_b}\n\n"
        "First decide independently whether candidate A preserves the causal operating "
        "condition and whether candidate B preserves it. Then choose the preserving "
        "candidate. Use exactly this format and no other text:\n"
        "A_REL YES|NO | B_REL YES|NO | ANSWER A|B"
    )


def decomposed_completion(target: str) -> str:
    if target == "A":
        return "A_REL YES | B_REL NO | ANSWER A"
    if target == "B":
        return "A_REL NO | B_REL YES | ANSWER B"
    raise ValueError("M52p target must be A or B")


def parse_decomposed_response(response: str) -> Mapping[str, str] | None:
    match = _RESPONSE.match(str(response))
    if match is None:
        return None
    return {
        "a_relation": match.group(1).upper(),
        "b_relation": match.group(2).upper(),
        "answer": match.group(3).upper(),
    }


def decomposed_records(
    rows: Sequence[Mapping[str, Any]], responses: Sequence[str]
) -> Tuple[Mapping[str, Any], ...]:
    if len(rows) != len(responses):
        raise ValueError("M52p rows and responses must align")
    records = []
    for row, response in zip(rows, responses):
        metadata = row["metadata"]
        target = str(metadata["target"])
        a_target = "YES" if target == "A" else "NO"
        b_target = "YES" if target == "B" else "NO"
        parsed = parse_decomposed_response(str(response))
        prediction = None if parsed is None else parsed["answer"]
        a_prediction = None if parsed is None else parsed["a_relation"]
        b_prediction = None if parsed is None else parsed["b_relation"]
        answer_correct = prediction == target
        a_correct = a_prediction == a_target
        b_correct = b_prediction == b_target
        records.append(
            {
                "record_id": metadata["record_id"],
                "semantic_group_id": metadata["semantic_group_id"],
                "contrast_id": metadata["contrast_id"],
                "family": metadata["family"],
                "variant": metadata["variant"],
                "orientation": metadata["orientation"],
                "target": target,
                "prediction": prediction,
                "correct": answer_correct,
                "a_relation_target": a_target,
                "a_relation_prediction": a_prediction,
                "a_relation_correct": a_correct,
                "b_relation_target": b_target,
                "b_relation_prediction": b_prediction,
                "b_relation_correct": b_correct,
                "relation_pair_correct": a_correct and b_correct,
                "structured_exact_correct": a_correct and b_correct and answer_correct,
                "grammar_valid": parsed is not None,
                "response": str(response),
            }
        )
    return tuple(records)


def decomposed_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    final_metrics = comparator_metrics(records)

    def relation_summary(selected: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        judgments = []
        for row in selected:
            judgments.extend(
                (
                    (row["a_relation_target"], row["a_relation_correct"]),
                    (row["b_relation_target"], row["b_relation_correct"]),
                )
            )
        yes = [correct for target, correct in judgments if target == "YES"]
        no = [correct for target, correct in judgments if target == "NO"]
        yes_recall = sum(bool(value) for value in yes) / max(len(yes), 1)
        no_recall = sum(bool(value) for value in no) / max(len(no), 1)
        return {
            "relation_balanced_accuracy": (yes_recall + no_recall) / 2.0,
            "relation_yes_recall": yes_recall,
            "relation_no_recall": no_recall,
            "relation_pair_accuracy": sum(
                bool(row["relation_pair_correct"]) for row in selected
            )
            / max(len(selected), 1),
            "structured_exact_accuracy": sum(
                bool(row["structured_exact_correct"]) for row in selected
            )
            / max(len(selected), 1),
            "grammar_valid_rate": sum(bool(row["grammar_valid"]) for row in selected)
            / max(len(selected), 1),
        }

    relation = relation_summary(records)
    return {
        **final_metrics,
        **relation,
        "by_family_decomposed": {
            family: {
                **relation_summary([row for row in records if row["family"] == family]),
                "final_balanced_accuracy": final_metrics["by_family"][family][
                    "balanced_accuracy"
                ],
            }
            for family in sorted({str(row["family"]) for row in records})
        },
        "by_variant_decomposed": {
            variant: {
                **relation_summary([row for row in records if row["variant"] == variant]),
                "final_balanced_accuracy": final_metrics["by_variant"][variant][
                    "balanced_accuracy"
                ],
            }
            for variant in sorted({str(row["variant"]) for row in records})
        },
    }


def decomposed_condition_passed(
    metrics: Mapping[str, Any],
    independent_metrics: Mapping[str, Any],
    contract: Mapping[str, Any],
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_grammar_valid_rate": float(metrics["grammar_valid_rate"])
        >= float(contract["minimum_grammar_valid_rate"]),
        "minimum_relation_balanced_accuracy": float(
            metrics["relation_balanced_accuracy"]
        )
        >= float(contract["minimum_relation_balanced_accuracy"]),
        "minimum_relation_pair_accuracy": float(metrics["relation_pair_accuracy"])
        >= float(contract["minimum_relation_pair_accuracy"]),
        "minimum_structured_exact_accuracy": float(
            metrics["structured_exact_accuracy"]
        )
        >= float(contract["minimum_structured_exact_accuracy"]),
        "minimum_final_balanced_accuracy": float(metrics["balanced_accuracy"])
        >= float(contract["minimum_final_balanced_accuracy"]),
        "minimum_final_swap_pair_accuracy": float(metrics["swap_pair_accuracy"])
        >= float(contract["minimum_final_swap_pair_accuracy"]),
        "minimum_final_paraphrase_accuracy": float(
            metrics["paraphrase_balanced_accuracy"]
        )
        >= float(contract["minimum_final_paraphrase_accuracy"]),
        "minimum_each_family_final_accuracy": min(
            float(row["final_balanced_accuracy"])
            for row in metrics["by_family_decomposed"].values()
        )
        >= float(contract["minimum_each_family_final_accuracy"]),
        "maximum_candidate_order_bias": float(metrics["candidate_order_bias"])
        <= float(contract["maximum_candidate_order_bias"]),
        "minimum_delta_from_independent": float(metrics["balanced_accuracy"])
        - float(independent_metrics["balanced_accuracy"])
        >= float(contract["minimum_delta_from_independent"]),
    }
    return all(checks.values()), checks
