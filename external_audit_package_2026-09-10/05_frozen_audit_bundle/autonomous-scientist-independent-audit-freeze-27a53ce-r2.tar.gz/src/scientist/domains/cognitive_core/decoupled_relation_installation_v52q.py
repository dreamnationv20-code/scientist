from __future__ import annotations

import re
from functools import lru_cache
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.joint_relational_comparator_v52l import (
    M52L_FAMILIES_BY_SPLIT,
    _family,
    comparator_metrics,
)
from scientist.domains.cognitive_core.semantic_relation_competence_v52i import (
    M52I_VARIANTS,
)


DECOUPLED_RELATION_INSTALLATION_VERSION = (
    "general-cognitive-decoupled-relation-installation-v52q"
)
M52Q_SEED = 52981
M52Q_M52P_AUDIT_ID = (
    "eb6c8f5c7025c93a4683732611d3c35ab3a0c7ef893860c8e096c0dbfd81c53c"
)
M52Q_GRAMMAR = "A_REL <YES|NO> | B_REL <YES|NO>"
M52Q_CONFIGURATIONS = ("yes_no", "no_yes", "yes_yes", "no_no")
_RESPONSE = re.compile(
    r"^\s*A_REL\s+(YES|NO)\s*\|\s*B_REL\s+(YES|NO)\s*$",
    re.IGNORECASE,
)


def decoupled_relation_prompt(basis: str, candidate_a: str, candidate_b: str) -> str:
    return (
        "A research conclusion assumes this operating condition:\n"
        f"{basis}\n\n"
        "Current candidate A:\n"
        f"{candidate_a}\n\n"
        "Current candidate B:\n"
        f"{candidate_b}\n\n"
        "Judge each candidate independently. More than one candidate, or neither candidate, "
        "may preserve the required causal operating condition. Use exactly this format and "
        "no other text:\n"
        "A_REL YES|NO | B_REL YES|NO"
    )


def decoupled_completion(a_relation: str, b_relation: str) -> str:
    values = (str(a_relation).upper(), str(b_relation).upper())
    if any(value not in ("YES", "NO") for value in values):
        raise ValueError("M52q relation targets must be YES or NO")
    return f"A_REL {values[0]} | B_REL {values[1]}"


def parse_decoupled_response(response: str) -> Mapping[str, str] | None:
    match = _RESPONSE.match(str(response))
    if match is None:
        return None
    return {
        "a_relation": match.group(1).upper(),
        "b_relation": match.group(2).upper(),
    }


def _basis_text(state: Mapping[str, str], variant: str) -> str:
    return str(
        state["basis_paraphrase"]
        if variant in ("basis_paraphrase", "dual_paraphrase")
        else state["basis"]
    )


def _candidate_text(state: Mapping[str, str], variant: str) -> str:
    return str(
        state["current_paraphrase"]
        if variant in ("current_paraphrase", "dual_paraphrase")
        else state["current"]
    )


@lru_cache(maxsize=1)
def build_m52q_installation_rows() -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for family_name in M52L_FAMILIES_BY_SPLIT["train"]:
        states = _family(family_name)
        for state_index, positive_state in enumerate(states):
            negative_a = states[(state_index + 1) % len(states)]
            negative_b = states[(state_index + 2) % len(states)]
            for variant in M52I_VARIANTS:
                basis = _basis_text(positive_state, variant)
                positive = _candidate_text(positive_state, variant)
                negative_a_text = _candidate_text(negative_a, variant)
                negative_b_text = _candidate_text(negative_b, variant)
                configurations = (
                    ("yes_no", positive, negative_b_text, "YES", "NO"),
                    ("no_yes", negative_a_text, positive, "NO", "YES"),
                    ("yes_yes", positive, positive, "YES", "YES"),
                    ("no_no", negative_a_text, negative_b_text, "NO", "NO"),
                )
                for configuration, candidate_a, candidate_b, a_target, b_target in configurations:
                    record_id = "m52q-install-" + content_digest(
                        {
                            "version": DECOUPLED_RELATION_INSTALLATION_VERSION,
                            "family": family_name,
                            "basis": positive_state["key"],
                            "variant": variant,
                            "configuration": configuration,
                        }
                    )[:24]
                    rows.append(
                        {
                            "prompt": decoupled_relation_prompt(
                                basis, candidate_a, candidate_b
                            ),
                            "completion": decoupled_completion(a_target, b_target),
                            "metadata": {
                                "record_id": record_id,
                                "family": family_name,
                                "variant": variant,
                                "configuration": configuration,
                                "basis_state_key": positive_state["key"],
                                "candidate_a_state_key": (
                                    positive_state["key"]
                                    if a_target == "YES"
                                    else negative_a["key"]
                                ),
                                "candidate_b_state_key": (
                                    positive_state["key"]
                                    if b_target == "YES"
                                    else negative_b["key"]
                                ),
                                "basis_text": basis,
                                "candidate_a_text": candidate_a,
                                "candidate_b_text": candidate_b,
                                "a_relation_target": a_target,
                                "b_relation_target": b_target,
                            },
                        }
                    )
    return tuple(rows)


def relation_records(
    rows: Sequence[Mapping[str, Any]], responses: Sequence[str]
) -> Tuple[Mapping[str, Any], ...]:
    if len(rows) != len(responses):
        raise ValueError("M52q rows and responses must align")
    records = []
    for row, response in zip(rows, responses):
        metadata = row["metadata"]
        target = metadata.get("target")
        a_target = str(
            metadata.get("a_relation_target", "YES" if target == "A" else "NO")
        )
        b_target = str(
            metadata.get("b_relation_target", "YES" if target == "B" else "NO")
        )
        parsed = parse_decoupled_response(str(response))
        a_prediction = None if parsed is None else parsed["a_relation"]
        b_prediction = None if parsed is None else parsed["b_relation"]
        a_correct = a_prediction == a_target
        b_correct = b_prediction == b_target
        prediction = None
        if a_prediction == "YES" and b_prediction == "NO":
            prediction = "A"
        elif a_prediction == "NO" and b_prediction == "YES":
            prediction = "B"
        records.append(
            {
                "record_id": metadata["record_id"],
                "semantic_group_id": metadata.get("semantic_group_id"),
                "contrast_id": metadata.get("contrast_id"),
                "family": metadata["family"],
                "variant": metadata["variant"],
                "configuration": metadata.get("configuration"),
                "orientation": metadata.get("orientation"),
                "target": target,
                "prediction": prediction,
                "correct": target is not None and prediction == target,
                "a_relation_target": a_target,
                "a_relation_prediction": a_prediction,
                "a_relation_correct": a_correct,
                "b_relation_target": b_target,
                "b_relation_prediction": b_prediction,
                "b_relation_correct": b_correct,
                "relation_pair_correct": a_correct and b_correct,
                "grammar_valid": parsed is not None,
                "response": str(response),
            }
        )
    return tuple(records)


def _balanced_relation_accuracy(
    records: Sequence[Mapping[str, Any]], slot: str | None = None
) -> float:
    judgments = []
    for row in records:
        if slot in (None, "a"):
            judgments.append(
                (row["a_relation_target"], row["a_relation_correct"])
            )
        if slot in (None, "b"):
            judgments.append(
                (row["b_relation_target"], row["b_relation_correct"])
            )
    recalls = []
    for target in ("YES", "NO"):
        selected = [bool(correct) for value, correct in judgments if value == target]
        recalls.append(sum(selected) / max(len(selected), 1))
    return sum(recalls) / 2.0


def installation_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    configurations = sorted({str(row["configuration"]) for row in records})

    def summary(selected: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        return {
            "record_count": len(selected),
            "grammar_valid_rate": sum(bool(row["grammar_valid"]) for row in selected)
            / max(len(selected), 1),
            "relation_balanced_accuracy": _balanced_relation_accuracy(selected),
            "a_relation_balanced_accuracy": _balanced_relation_accuracy(selected, "a"),
            "b_relation_balanced_accuracy": _balanced_relation_accuracy(selected, "b"),
            "relation_pair_accuracy": sum(
                bool(row["relation_pair_correct"]) for row in selected
            )
            / max(len(selected), 1),
        }

    overall = summary(records)
    return {
        **overall,
        "slot_accuracy_gap": abs(
            overall["a_relation_balanced_accuracy"]
            - overall["b_relation_balanced_accuracy"]
        ),
        "by_configuration": {
            configuration: summary(
                [row for row in records if row["configuration"] == configuration]
            )
            for configuration in configurations
        },
        "by_family": {
            family: summary([row for row in records if row["family"] == family])
            for family in sorted({str(row["family"]) for row in records})
        },
    }


def evaluation_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    final = comparator_metrics(records)
    return {
        **final,
        "grammar_valid_rate": sum(bool(row["grammar_valid"]) for row in records)
        / max(len(records), 1),
        "relation_balanced_accuracy": _balanced_relation_accuracy(records),
        "a_relation_balanced_accuracy": _balanced_relation_accuracy(records, "a"),
        "b_relation_balanced_accuracy": _balanced_relation_accuracy(records, "b"),
        "relation_pair_accuracy": sum(
            bool(row["relation_pair_correct"]) for row in records
        )
        / max(len(records), 1),
        "by_family_relation": {
            family: {
                "relation_balanced_accuracy": _balanced_relation_accuracy(
                    [row for row in records if row["family"] == family]
                ),
                "final_balanced_accuracy": final["by_family"][family][
                    "balanced_accuracy"
                ],
            }
            for family in sorted({str(row["family"]) for row in records})
        },
    }


def installation_gate_passed(
    metrics: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_grammar_valid_rate": float(metrics["grammar_valid_rate"])
        >= float(contract["minimum_grammar_valid_rate"]),
        "minimum_relation_balanced_accuracy": float(
            metrics["relation_balanced_accuracy"]
        )
        >= float(contract["minimum_relation_balanced_accuracy"]),
        "minimum_a_relation_balanced_accuracy": float(
            metrics["a_relation_balanced_accuracy"]
        )
        >= float(contract["minimum_each_slot_balanced_accuracy"]),
        "minimum_b_relation_balanced_accuracy": float(
            metrics["b_relation_balanced_accuracy"]
        )
        >= float(contract["minimum_each_slot_balanced_accuracy"]),
        "minimum_relation_pair_accuracy": float(metrics["relation_pair_accuracy"])
        >= float(contract["minimum_relation_pair_accuracy"]),
        "minimum_each_configuration_pair_accuracy": min(
            float(row["relation_pair_accuracy"])
            for row in metrics["by_configuration"].values()
        )
        >= float(contract["minimum_each_configuration_pair_accuracy"]),
        "maximum_slot_accuracy_gap": float(metrics["slot_accuracy_gap"])
        <= float(contract["maximum_slot_accuracy_gap"]),
    }
    return all(checks.values()), checks


def support_gate_passed(
    metrics: Mapping[str, Any],
    independent_metrics: Mapping[str, Any],
    contract: Mapping[str, Any],
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_grammar_valid_rate": float(metrics["grammar_valid_rate"])
        >= float(contract["minimum_grammar_valid_rate"]),
        "minimum_relation_balanced_accuracy": float(
            metrics["relation_balanced_accuracy"]
        )
        >= float(contract["minimum_relation_balanced_accuracy"]),
        "minimum_relation_pair_accuracy": float(metrics["relation_pair_accuracy"])
        >= float(contract["minimum_relation_pair_accuracy"]),
        "minimum_final_balanced_accuracy": float(metrics["balanced_accuracy"])
        >= float(contract["minimum_final_balanced_accuracy"]),
        "minimum_final_swap_pair_accuracy": float(metrics["swap_pair_accuracy"])
        >= float(contract["minimum_final_swap_pair_accuracy"]),
        "minimum_final_paraphrase_accuracy": float(
            metrics["paraphrase_balanced_accuracy"]
        )
        >= float(contract["minimum_final_paraphrase_accuracy"]),
        "minimum_each_family_final_accuracy": min(
            float(row["final_balanced_accuracy"])
            for row in metrics["by_family_relation"].values()
        )
        >= float(contract["minimum_each_family_final_accuracy"]),
        "maximum_candidate_order_bias": float(metrics["candidate_order_bias"])
        <= float(contract["maximum_candidate_order_bias"]),
        "minimum_delta_from_independent": float(metrics["balanced_accuracy"])
        - float(independent_metrics["balanced_accuracy"])
        >= float(contract["minimum_delta_from_independent"]),
    }
    return all(checks.values()), checks
