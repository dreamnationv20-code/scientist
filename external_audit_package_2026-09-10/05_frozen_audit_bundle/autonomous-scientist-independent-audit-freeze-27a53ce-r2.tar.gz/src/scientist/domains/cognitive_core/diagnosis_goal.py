from __future__ import annotations

from scientist.kernel.contracts import MetricDirection, MetricSpec
from scientist.program.goal_graph import (
    CompositionOperator,
    DependencyEdge,
    DependencyKind,
    ExecutableLeafContract,
    GoalGraphDecompositionProposal,
    GoalNodeKind,
    GoalNodeSpec,
    ParentCompositionRule,
)

from scientist.domains.cognitive_core.goal_program import (
    COGNITIVE_GOAL_PROGRAM_VERSION,
    fresh_goal_graph_spec,
)


DIAGNOSIS_PROGRAM_VERSION = "cognitive-core-causal-diagnosis-v3"


def _diagnostic_leaf(
    *,
    parent: GoalNodeSpec,
    title: str,
    question: str,
    hypothesis: str,
    parent_decision: str,
    success: tuple[str, ...],
    falsification: tuple[str, ...],
    artifact: str,
    testbed: str,
    budget: float,
    tags: tuple[str, ...],
) -> GoalNodeSpec:
    metric = MetricSpec(
        name="diagnostic_resolution",
        direction=MetricDirection.TARGET,
        unit="binary resolution gate",
        aggregation="all validity checks plus non-inconclusive disposition",
        primary=True,
        target=1.0,
    )
    contract = ExecutableLeafContract(
        hypothesis=hypothesis,
        parent_decision=parent_decision,
        root_metric_link=(
            "A resolved bottleneck or transport diagnosis determines which "
            "architectural representations may enter solution search."
        ),
        metric=metric,
        success_conditions=success,
        falsification_conditions=falsification,
        testbed_ref=testbed,
        parent_integration_test=(
            "The diagnostic disposition must change the parent causal model, "
            "horizon map, or representation decision on sequestered evidence."
        ),
        experiment_budget=budget,
        preregistration_ref=DIAGNOSIS_PROGRAM_VERSION,
    )
    return GoalNodeSpec(
        goal_id=parent.goal_id,
        title=title,
        question=question,
        kind=GoalNodeKind.EXECUTABLE_LEAF,
        rationale=(
            "This experiment resolves a causal question; it does not propose "
            "or optimize a cognitive architecture."
        ),
        success_conditions=success,
        falsification_conditions=falsification,
        expected_artifact=artifact,
        critical=True,
        leaf_contract=contract,
        tags=("cognitive-core-v3", "diagnostic", *tags),
    )


def diagnosis_decompositions() -> tuple[
    tuple[GoalGraphDecompositionProposal, ...],
    tuple[DependencyEdge, ...],
]:
    spec = fresh_goal_graph_spec()
    causal_parent = spec.nodes["causal_models"]
    horizon_parent = spec.nodes["horizon_transfer"]
    representation_parent = spec.nodes["representation"]

    intervention_matrix = _diagnostic_leaf(
        parent=causal_parent,
        title="Matched causal intervention matrix",
        question=(
            "What capability changes follow independent and paired do-style "
            "interventions on capacity, optimization, representation, and routing?"
        ),
        hypothesis=(
            "Cost-matched capacity, optimization-kinetics, representation, and "
            "routing interventions produce stable mechanism-specific capability "
            "effect signatures."
        ),
        parent_decision="which causal explanations remain observationally possible",
        success=(
            "capacity, optimization, representation, and routing are varied independently",
            "sham, positive, and randomized-seed controls are included",
            "case, training, parameter, and total-system budgets remain matched",
            "an independent verifier reconstructs every intervention contrast",
        ),
        falsification=(
            "an intervention changes more than its preregistered factor",
            "effect signatures are dominated by seed or cost imbalance",
        ),
        artifact="factorial causal intervention atlas",
        testbed="cognitive-core-matched-interventions-v3",
        budget=24.0,
        tags=("causal-intervention", "factorial", "null-control"),
    )
    model_selection = _diagnostic_leaf(
        parent=causal_parent,
        title="Held-out competing-model discrimination",
        question=(
            "Which frozen capacity, kinetics, entanglement, routing, interaction, "
            "or null model predicts unseen intervention outcomes?"
        ),
        hypothesis=(
            "The intervention atlas contains enough independent variation to "
            "separate at least one causal model or tightly support the null."
        ),
        parent_decision="which bottleneck model constrains architecture generation",
        success=(
            "every model makes quantitative predictions before held-out outcomes",
            "the null and mixed-mechanism models are scored alongside pure mechanisms",
            "selection uses held-out likelihood and uncertainty rather than narrative fit",
            "the protocol returns inconclusive when models are not distinguishable",
        ),
        falsification=(
            "model predictions are written after outcomes are inspected",
            "multiple mechanisms remain indistinguishable at the available precision",
        ),
        artifact="competing causal model comparison and uncertainty certificate",
        testbed="cognitive-core-causal-model-selection-v3",
        budget=16.0,
        tags=("causal-model-selection", "heldout", "null-model"),
    )
    causal_rule = ParentCompositionRule(
        parent_id=causal_parent.node_id,
        child_ids=(intervention_matrix.node_id, model_selection.node_id),
        operator=CompositionOperator.ALL,
        integration_test=(
            "The matched atlas is valid and held-out model discrimination yields "
            "a supported, refuted, or mixed result rather than forced certainty."
        ),
        rationale="Causal claims require both intervention and prospective prediction.",
        decomposer_ref=DIAGNOSIS_PROGRAM_VERSION,
    )

    horizon_registry = _diagnostic_leaf(
        parent=horizon_parent,
        title="Frozen multi-horizon prediction ladder",
        question=(
            "Can the same interventions and capability metrics be bound to "
            "ordered horizons before higher-horizon evidence is exposed?"
        ),
        hypothesis=(
            "A shared identity and prediction registry prevents local evidence "
            "from being relabeled as transfer or terminal success."
        ),
        parent_decision="whether local-to-terminal effects are comparable",
        success=(
            "intervention, task-family, model-family, and metric identities persist across horizons",
            "higher-horizon predictions are frozen before their outcomes are visible",
            "seed distributions and continuous metrics are retained rather than thresholded",
        ),
        falsification=(
            "a later horizon changes the intervention or target construct",
            "adaptive exposure contaminates a prediction partition",
        ),
        artifact="sealed horizon and prediction registry",
        testbed="cognitive-core-horizon-registry-v3",
        budget=8.0,
        tags=("horizon-registry", "prediction-freeze", "identity"),
    )
    transport_map = _diagnostic_leaf(
        parent=horizon_parent,
        title="Calibrated transport and reversal dossier",
        question=(
            "Which local effects persist, attenuate, emerge, reverse, or vanish "
            "across model scale, task family, and naturality?"
        ),
        hypothesis=(
            "Transport outcomes are conditionally predictable from scale, loss, "
            "seed distribution, intervention class, task diversity, and cost."
        ),
        parent_decision="which cheap horizons may screen future hypotheses",
        success=(
            "matched successes and failures are both represented",
            "transport probabilities are calibrated on held-out intervention families",
            "rank reversals and multimodal seed outcomes are reported explicitly",
            "unreliable horizons are blocked rather than averaged into a positive score",
        ),
        falsification=(
            "local effect size alone is treated as a terminal predictor",
            "the transport rule fails held-out calibration",
        ),
        artifact="local-to-terminal transport atlas and reliability bounds",
        testbed="cognitive-core-horizon-transport-v3",
        budget=20.0,
        tags=("horizon-transport-map", "calibration", "reversal"),
    )
    horizon_rule = ParentCompositionRule(
        parent_id=horizon_parent.node_id,
        child_ids=(horizon_registry.node_id, transport_map.node_id),
        operator=CompositionOperator.ALL,
        integration_test=(
            "A sealed registry and held-out calibrated transport map jointly "
            "bound every allowed cheap-to-expensive inference."
        ),
        rationale="Transport claims require frozen identities before outcome modeling.",
        decomposer_ref=DIAGNOSIS_PROGRAM_VERSION,
    )

    adequacy = _diagnostic_leaf(
        parent=representation_parent,
        title="Held-out representation sufficiency test",
        question=(
            "Do current descriptors predict opposing horizon outcomes, or does "
            "the residual evidence require a missing latent concept?"
        ),
        hypothesis=(
            "Scale, loss, seed variance, load, intervention class, task diversity, "
            "provenance, and total cost suffice to predict transport disposition."
        ),
        parent_decision=(
            "retain the current hypothesis language or revise the graph to latent-concept invention"
        ),
        success=(
            "descriptor sufficiency is evaluated on held-out matched contrasts",
            "a null predictor and flexible interaction model are included",
            "both sufficiency and insufficiency have preregistered decision thresholds",
            "insufficiency triggers graph revision rather than an ad hoc selector",
        ),
        falsification=(
            "representation adequacy is judged on training contrasts",
            "an unexplained residual is renamed rather than prospectively tested",
        ),
        artifact="representation adequacy or insufficiency certificate",
        testbed="cognitive-core-representation-adequacy-v3",
        budget=14.0,
        tags=("representation-adequacy", "heldout-contrast", "latent-trigger"),
    )
    adequacy_rule = ParentCompositionRule(
        parent_id=representation_parent.node_id,
        child_ids=(adequacy.node_id,),
        operator=CompositionOperator.ALL,
        integration_test=(
            "If descriptors are sufficient, their held-out rule must transfer; "
            "if insufficient, parent integration fails and the graph must add a "
            "prospective latent-concept branch."
        ),
        rationale="Concept invention is evidence-triggered, not mandatory theater.",
        decomposer_ref=DIAGNOSIS_PROGRAM_VERSION,
    )

    proposals = (
        GoalGraphDecompositionProposal(
            parent_id=causal_parent.node_id,
            nodes=(intervention_matrix, model_selection),
            rule=causal_rule,
            assumptions=(
                "intervention factors can be manipulated at matched total cost",
                "pure, mixed, and null models remain live until held-out scoring",
            ),
            distinguishing_predictions=(
                "capacity changes respond selectively to headroom",
                "kinetics changes respond to training trajectory at fixed capacity",
                "representation changes respond to factorization at fixed resources",
                "routing changes respond to information availability and control",
            ),
            reasoning="Separate observational fit from causal intervention and prediction.",
        ),
        GoalGraphDecompositionProposal(
            parent_id=horizon_parent.node_id,
            nodes=(horizon_registry, transport_map),
            rule=horizon_rule,
            assumptions=(
                "the same intervention identity can be followed across horizons",
                "terminal partitions remain sealed during transport fitting",
            ),
            distinguishing_predictions=(
                "persistent, attenuating, emerging, reversing, and null effects remain distinct",
            ),
            reasoning="A transport rule is credible only after identities and predictions freeze.",
        ),
        GoalGraphDecompositionProposal(
            parent_id=representation_parent.node_id,
            nodes=(adequacy,),
            rule=adequacy_rule,
            assumptions=(
                "current descriptors are frozen before the sufficiency test",
            ),
            distinguishing_predictions=(
                "sufficiency predicts held-out disposition; insufficiency leaves structured residuals",
            ),
            reasoning="Test the existing language before asking a generator to invent another one.",
        ),
    )
    dependencies = (
        DependencyEdge(
            source_id=model_selection.node_id,
            target_id=intervention_matrix.node_id,
            kind=DependencyKind.REQUIRES,
            rationale="Model selection requires the frozen intervention atlas.",
        ),
        DependencyEdge(
            source_id=transport_map.node_id,
            target_id=horizon_registry.node_id,
            kind=DependencyKind.REQUIRES,
            rationale="Transport fitting requires sealed horizon predictions.",
        ),
    )
    return proposals, dependencies


def diagnosis_parent_decomposition() -> GoalGraphDecompositionProposal:
    return fresh_goal_graph_spec().decompositions[1]


DIAGNOSIS_DECOMPOSER_REF = (
    COGNITIVE_GOAL_PROGRAM_VERSION + "+" + DIAGNOSIS_PROGRAM_VERSION
)
