from __future__ import annotations

from scientist.domains.cognitive_core.diagnosis_goal import (
    diagnosis_decompositions,
)
from scientist.domains.cognitive_core.goal_program import fresh_goal_graph_spec
from scientist.program.goal_graph import GoalNodeSpec
from scientist.program.literature import (
    ClaimClassification,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)


DIAGNOSIS_LITERATURE_VERSION = "cognitive-core-diagnosis-literature-v3-2026-08-06"


WORKS = {
    "memory_layers": PriorWork(
        work_id="memory-layers-icml-2025-diagnosis",
        title="Memory Layers at Scale",
        year=2025,
        locator="https://proceedings.mlr.press/v267/berges25a.html",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "associative storage capacity",
            "compute-matched scaling",
            "factual memory versus dense parameters",
        ),
        abstract="Separates sparse associative memory capacity from dense compute.",
    ),
    "icl_ood": PriorWork(
        work_id="icl-ood-icml-2025-diagnosis",
        title="When can in-context learning generalize out of task distribution?",
        year=2025,
        locator="https://proceedings.mlr.press/v267/goddard25a.html",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "task-diversity phase diagram",
            "specialization-to-generalization transition",
            "out-of-task-distribution transfer",
        ),
        abstract="Shows a diversity-dependent transition from specialized to OOD task learning.",
    ),
    "adacad": PriorWork(
        work_id="adacad-naacl-2025-diagnosis",
        title="AdaCAD: Adaptively Decoding to Balance Conflicts between Contextual and Parametric Knowledge",
        year=2025,
        locator="https://aclanthology.org/2025.naacl-long.581/",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "parametric-context conflict",
            "instance-level routing signal",
            "static intervention negative control",
        ),
        abstract="Finds that static context adjustment harms no-conflict cases and adapts by conflict degree.",
    ),
    "wise": PriorWork(
        work_id="wise-neurips-2024-diagnosis",
        title="WISE: Rethinking the Knowledge Memory for Lifelong Model Editing of Large Language Models",
        year=2024,
        locator="https://openreview.net/forum?id=NpoDbZBPZH",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "parametric versus working memory",
            "update reliability",
            "generalization-locality trade-off",
        ),
        abstract="Separates reliability, generalization, and locality in lifelong editing.",
    ),
    "grokking": PriorWork(
        work_id="slingshot-neurips-2022-diagnosis",
        title="The Slingshot Mechanism: An Empirical Study of Adaptive Optimizers and the Grokking Phenomenon",
        year=2022,
        locator="https://openreview.net/forum?id=dJgYhYKvr1",
        relation=PriorArtRelation.ADJACENT,
        matched_components=(
            "delayed generalization",
            "optimizer-dependent training dynamics",
            "memorization before generalization",
        ),
        abstract="Demonstrates that checkpoint timing and optimizer dynamics can masquerade as capacity limits.",
    ),
    "causal_rep": PriorWork(
        work_id="interventional-causal-representation-icml-2023-diagnosis",
        title="Interventional Causal Representation Learning",
        year=2023,
        locator="https://proceedings.mlr.press/v202/ahuja23a.html",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "do-style interventions",
            "latent-factor identification",
            "observational non-identifiability",
        ),
        abstract="Formalizes how interventions can identify latent causal factors.",
    ),
    "mib": PriorWork(
        work_id="mib-blackboxnlp-2025-diagnosis",
        title="Findings of the BlackboxNLP 2025 Shared Task: Localizing Circuits and Causal Variables in Language Models",
        year=2025,
        locator="https://aclanthology.org/2025.blackboxnlp-1.32/",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "causal component localization",
            "causal variable localization",
            "reproducible method comparison",
        ),
        abstract="Benchmarks circuit and causal-variable localization rather than probe fit alone.",
    ),
    "scaling": PriorWork(
        work_id="observational-scaling-neurips-2024-diagnosis",
        title="Observational Scaling Laws and the Predictability of Language Model Performance",
        year=2024,
        locator="https://openreview.net/forum?id=On5WIN7xyD",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "cross-family capability space",
            "small-to-large prediction",
            "post-training intervention scaling",
        ),
        abstract="Models family efficiency separately from a low-dimensional capability trajectory.",
    ),
    "mirage": PriorWork(
        work_id="emergence-mirage-neurips-2023-diagnosis",
        title="Are Emergent Abilities of Large Language Models a Mirage?",
        year=2023,
        locator="https://openreview.net/forum?id=ITw9edRDlD",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "metric-induced discontinuity",
            "continuous versus threshold metrics",
            "scaling interpretation controls",
        ),
        abstract="Shows that metric choice can create apparent abrupt emergence.",
    ),
    "distributional_scaling": PriorWork(
        work_id="distributional-scaling-2024-diagnosis",
        title="Distributional Scaling Laws for Emergent Capabilities",
        year=2024,
        locator="https://openreview.net/forum?id=e8eo9iEFaO",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "seed-dependent multimodality",
            "width-depth asymmetry",
            "breakthrough probability across scale",
        ),
        abstract="Shows that seed distributions and scaling direction can alter apparent emergence.",
    ),
    "probe_failure": PriorWork(
        work_id="mechanisms-outcomes-emnlp-2025-diagnosis",
        title="Mechanisms vs. Outcomes: Probing for Syntax Fails to Explain Performance on Targeted Syntactic Evaluations",
        year=2025,
        locator="https://aclanthology.org/2025.emnlp-main.1712/",
        relation=PriorArtRelation.ADJACENT,
        matched_components=(
            "representation probe insufficiency",
            "mechanism-outcome disconnect",
            "held-out behavioral explanation",
        ),
        abstract="Warns that decodable representations need not explain downstream behavior.",
    ),
}


def _assessment(
    node: GoalNodeSpec,
    closest: tuple[PriorWork, ...],
    *,
    phenomenon: str,
    intervention: str,
    mechanism: str,
    rationale: str,
) -> PriorArtAssessment:
    return PriorArtAssessment(
        signature=ClaimSignature(
            subject_id=node.node_id,
            statement=node.question,
            problem="identify why candidate cognitive systems fail before solution search",
            phenomenon=phenomenon,
            intervention=intervention,
            mechanism=mechanism,
            evaluation=node.expected_artifact,
        ),
        trigger=LiteratureTrigger.INITIAL_SCOPE,
        queries=(
            LiteratureQuery(
                query=node.question,
                facet=SearchFacet.PROBLEM,
                provider="PMLR and ACL Anthology",
            ),
            LiteratureQuery(
                query=intervention,
                facet=SearchFacet.INTERVENTION,
                provider="PMLR and OpenReview",
            ),
            LiteratureQuery(
                query=mechanism,
                facet=SearchFacet.MECHANISM,
                provider="ACL Anthology and OpenReview",
            ),
            LiteratureQuery(
                query="evaluation " + node.expected_artifact,
                facet=SearchFacet.EVALUATION,
                provider="PMLR and ACL Anthology",
            ),
            LiteratureQuery(
                query="citation neighborhood "
                + " ".join(work.title for work in closest),
                facet=SearchFacet.CITATION_NEIGHBORHOOD,
                provider="primary-source indexes",
            ),
        ),
        closest_works=closest,
        classification=ClaimClassification.NOT_APPLICABLE,
        rationale=rationale + " This survey scopes a diagnostic; no novelty claim is authorized.",
        novel_delta=(),
        citation_snowball_complete=True,
        searched_at="2026-08-06",
        reviewer_ref=DIAGNOSIS_LITERATURE_VERSION,
    )


def diagnosis_prior_art_assessment() -> PriorArtAssessment:
    node = fresh_goal_graph_spec().nodes["diagnosis"]
    return _assessment(
        node,
        (
            WORKS["memory_layers"],
            WORKS["icl_ood"],
            WORKS["adacad"],
            WORKS["wise"],
            WORKS["grokking"],
            WORKS["causal_rep"],
            WORKS["scaling"],
            WORKS["mirage"],
        ),
        phenomenon=(
            "the same capability failure can arise from capacity, learning dynamics, "
            "representation, routing, interaction, or measurement thresholding"
        ),
        intervention=(
            "matched factorial perturbations followed across sealed evaluation horizons"
        ),
        mechanism=(
            "competing pure, mixed, and null causal models with held-out predictions"
        ),
        rationale=(
            "Prior work rules out reading a bottleneck directly from aggregate accuracy "
            "or a single scale. Intervention, checkpoint, source-conflict, seed, and "
            "metric controls are all required."
        ),
    )


def diagnosis_child_prior_art_assessments() -> tuple[PriorArtAssessment, ...]:
    nodes = fresh_goal_graph_spec().nodes
    return (
        _assessment(
            nodes["causal_models"],
            (
                WORKS["causal_rep"],
                WORKS["mib"],
                WORKS["grokking"],
                WORKS["adacad"],
                WORKS["memory_layers"],
            ),
            phenomenon="observationally similar failures with different causal responses",
            intervention="independent capacity, kinetics, factorization, and routing perturbations",
            mechanism="held-out discrimination among pure, interaction, and null models",
            rationale="Interventions are needed because probes and correlations do not identify mechanism.",
        ),
        _assessment(
            nodes["horizon_transfer"],
            (
                WORKS["scaling"],
                WORKS["mirage"],
                WORKS["distributional_scaling"],
                WORKS["icl_ood"],
            ),
            phenomenon="local gains may persist, attenuate, emerge, reverse, or vanish",
            intervention="freeze predictions before increasing scale, naturality, or task distance",
            mechanism="calibrated transport conditional on loss, family, seed, metric, and intervention",
            rationale="Small-scale transfer is sometimes predictable but not from raw local accuracy alone.",
        ),
        _assessment(
            nodes["representation"],
            (
                WORKS["causal_rep"],
                WORKS["mib"],
                WORKS["probe_failure"],
                WORKS["distributional_scaling"],
            ),
            phenomenon="available descriptors may fail to explain opposing transport outcomes",
            intervention="cross-fit descriptor sufficiency before latent-concept invention",
            mechanism="predictive residual structure under held-out interventions and environments",
            rationale="Decodability and narrative labels are insufficient; a representation must predict interventions.",
        ),
    )


def diagnosis_leaf_prior_art_assessments() -> tuple[PriorArtAssessment, ...]:
    proposals, _ = diagnosis_decompositions()
    assessments = []
    for proposal in proposals:
        for leaf in proposal.nodes:
            tags = set(leaf.tags)
            if "causal-intervention" in tags or "causal-model-selection" in tags:
                closest = (
                    WORKS["causal_rep"],
                    WORKS["mib"],
                    WORKS["grokking"],
                    WORKS["adacad"],
                )
                mechanism = "factorial intervention signatures and prospective model scoring"
            elif "horizon-registry" in tags or "horizon-transport-map" in tags:
                closest = (
                    WORKS["scaling"],
                    WORKS["mirage"],
                    WORKS["distributional_scaling"],
                )
                mechanism = "sealed predictions and distributional transport calibration"
            else:
                closest = (
                    WORKS["causal_rep"],
                    WORKS["mib"],
                    WORKS["probe_failure"],
                )
                mechanism = "held-out descriptor sufficiency and structured residuals"
            assessments.append(
                _assessment(
                    leaf,
                    closest,
                    phenomenon="a causal diagnostic can look resolved while remaining confounded",
                    intervention=leaf.leaf_contract.hypothesis,
                    mechanism=mechanism,
                    rationale=(
                        "The leaf adopts established diagnostic controls and is an "
                        "internal protocol rather than a new scientific claim."
                    ),
                )
            )
    return tuple(assessments)
