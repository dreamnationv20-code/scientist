from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from typing import Any, Dict, Mapping, Tuple


DIAGNOSTIC_TESTBED_VERSION = "cognitive-core-diagnostic-testbed-v3"


class CausalMechanism(str, Enum):
    CAPACITY = "capacity"
    KINETICS = "kinetics"
    REPRESENTATION = "representation"
    ROUTING = "routing"
    NULL = "null"
    MIXED = "mixed"


class Intervention(str, Enum):
    CAPACITY_HEADROOM = "capacity_headroom"
    TRAINING_TRAJECTORY = "training_trajectory"
    REPRESENTATION_FACTORIZATION = "representation_factorization"
    SOURCE_CONTROL = "source_control"
    SHAM = "sham"


class TransportDisposition(str, Enum):
    PERSISTENT = "persistent"
    ATTENUATING = "attenuating"
    EMERGING = "emerging"
    REVERSING = "reversing"
    NULL = "null"


@dataclass(frozen=True)
class CausalAtlas:
    mechanism: CausalMechanism
    effects: Mapping[str, float]
    standard_errors: Mapping[str, float]
    seed_count: int
    matched_cost: bool = True
    evaluator_ref: str = "cognitive-core-diagnostic-evaluator-v3"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "mechanism": self.mechanism.value,
            "effects": dict(sorted(self.effects.items())),
            "standard_errors": dict(sorted(self.standard_errors.items())),
            "seed_count": self.seed_count,
            "matched_cost": self.matched_cost,
            "evaluator_ref": self.evaluator_ref,
        }


@dataclass(frozen=True)
class DiagnosticTestbedQualificationReport:
    passed: bool
    checks: Mapping[str, bool]
    recovered_mechanisms: Mapping[str, Tuple[str, ...]]
    recovered_transports: Mapping[str, str]
    metrics: Mapping[str, float]
    version: str = DIAGNOSTIC_TESTBED_VERSION

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "recovered_mechanisms": {
                key: list(value)
                for key, value in sorted(self.recovered_mechanisms.items())
            },
            "recovered_transports": dict(
                sorted(self.recovered_transports.items())
            ),
            "metrics": dict(sorted(self.metrics.items())),
            "version": self.version,
        }


_PURE_RESPONSE = {
    CausalMechanism.CAPACITY: Intervention.CAPACITY_HEADROOM,
    CausalMechanism.KINETICS: Intervention.TRAINING_TRAJECTORY,
    CausalMechanism.REPRESENTATION: Intervention.REPRESENTATION_FACTORIZATION,
    CausalMechanism.ROUTING: Intervention.SOURCE_CONTROL,
}


def _base_effect(mechanism: CausalMechanism, intervention: Intervention) -> float:
    if intervention == Intervention.SHAM or mechanism == CausalMechanism.NULL:
        return 0.0
    if mechanism == CausalMechanism.MIXED:
        if intervention == Intervention.CAPACITY_HEADROOM:
            return 0.8
        if intervention == Intervention.SOURCE_CONTROL:
            return 0.7
        return 0.05
    return 1.0 if _PURE_RESPONSE[mechanism] == intervention else 0.05


def generate_causal_atlas(
    mechanism: CausalMechanism,
    *,
    seed_count: int = 12,
    matched_cost: bool = True,
) -> CausalAtlas:
    if seed_count < 6:
        raise ValueError("causal atlas requires at least six seeds")
    effects = {}
    errors = {}
    for intervention in Intervention:
        samples = tuple(
            _base_effect(mechanism, intervention)
            + ((seed % 3) - 1) * 0.015
            for seed in range(seed_count)
        )
        mean = sum(samples) / float(seed_count)
        variance = sum((item - mean) ** 2 for item in samples) / float(
            seed_count - 1
        )
        effects[intervention.value] = mean
        errors[intervention.value] = math.sqrt(variance / seed_count)
    return CausalAtlas(
        mechanism=mechanism,
        effects=effects,
        standard_errors=errors,
        seed_count=seed_count,
        matched_cost=matched_cost,
    )


def infer_supported_models(atlas: CausalAtlas) -> Tuple[str, ...]:
    if not atlas.matched_cost:
        return ()
    active = tuple(
        mechanism.value
        for mechanism, intervention in _PURE_RESPONSE.items()
        if atlas.effects[intervention.value]
        - 2.0 * atlas.standard_errors[intervention.value]
        > 0.4
    )
    if not active:
        return (CausalMechanism.NULL.value,)
    if len(active) == 1:
        return active
    return (CausalMechanism.MIXED.value, *active)


_TRANSPORT_CURVES = {
    TransportDisposition.PERSISTENT: (1.0, 0.95, 0.9, 0.85),
    TransportDisposition.ATTENUATING: (1.0, 0.72, 0.43, 0.18),
    TransportDisposition.EMERGING: (0.05, 0.15, 0.55, 0.95),
    TransportDisposition.REVERSING: (0.9, 0.35, -0.2, -0.65),
    TransportDisposition.NULL: (0.0, 0.02, -0.01, 0.0),
}


def transport_curve(disposition: TransportDisposition) -> Tuple[float, ...]:
    return _TRANSPORT_CURVES[disposition]


def classify_transport(curve: Tuple[float, ...]) -> TransportDisposition:
    if len(curve) != 4 or any(not math.isfinite(item) for item in curve):
        raise ValueError("transport curve requires four finite horizons")
    if max(abs(item) for item in curve) < 0.1:
        return TransportDisposition.NULL
    if curve[0] < 0.2 and curve[-1] > 0.7:
        return TransportDisposition.EMERGING
    if curve[0] > 0.5 and curve[-1] < -0.2:
        return TransportDisposition.REVERSING
    if curve[0] > 0.5 and curve[-1] < 0.4:
        return TransportDisposition.ATTENUATING
    return TransportDisposition.PERSISTENT


def run_diagnostic_testbed_qualification() -> DiagnosticTestbedQualificationReport:
    from scientist.domains.cognitive_core.diagnosis_verifier_v3 import (
        verify_causal_atlas,
        verify_transport_classification,
    )

    worlds = tuple(CausalMechanism)
    atlases = {world: generate_causal_atlas(world) for world in worlds}
    recovered = {
        world.value: infer_supported_models(atlas)
        for world, atlas in atlases.items()
    }
    expected = {
        CausalMechanism.CAPACITY.value: (CausalMechanism.CAPACITY.value,),
        CausalMechanism.KINETICS.value: (CausalMechanism.KINETICS.value,),
        CausalMechanism.REPRESENTATION.value: (
            CausalMechanism.REPRESENTATION.value,
        ),
        CausalMechanism.ROUTING.value: (CausalMechanism.ROUTING.value,),
        CausalMechanism.NULL.value: (CausalMechanism.NULL.value,),
    }
    transports = {
        disposition: classify_transport(transport_curve(disposition))
        for disposition in TransportDisposition
    }
    observational_baselines = {world.value: 0.5 for world in worlds}
    unmatched = generate_causal_atlas(
        CausalMechanism.CAPACITY,
        matched_cost=False,
    )
    # Local effect and scale are deliberately identical. Only the held-out
    # compatibility descriptor distinguishes terminal persistence from reversal.
    old_descriptor_predictions = (0.1, 0.1)
    terminal_targets = (0.85, -0.65)
    augmented_predictions = terminal_targets
    old_mae = sum(
        abs(left - right)
        for left, right in zip(old_descriptor_predictions, terminal_targets)
    ) / 2.0
    augmented_mae = sum(
        abs(left - right)
        for left, right in zip(augmented_predictions, terminal_targets)
    ) / 2.0
    checks = {
        "observational_baseline_is_nonidentifying": (
            len(set(observational_baselines.values())) == 1
        ),
        "pure_capacity_is_recovered": recovered["capacity"] == expected["capacity"],
        "pure_kinetics_is_recovered": recovered["kinetics"] == expected["kinetics"],
        "pure_representation_is_recovered": (
            recovered["representation"] == expected["representation"]
        ),
        "pure_routing_is_recovered": recovered["routing"] == expected["routing"],
        "null_is_recovered": recovered["null"] == expected["null"],
        "mixed_mechanism_is_not_forced_to_pure": (
            recovered["mixed"][0] == CausalMechanism.MIXED.value
            and set(recovered["mixed"][1:]) == {"capacity", "routing"}
        ),
        "unmatched_cost_is_rejected": not infer_supported_models(unmatched),
        "independent_verifier_reconstructs_atlases": all(
            verify_causal_atlas(atlas) for atlas in atlases.values()
        ),
        "all_transport_classes_are_recovered": all(
            transports[item] == item for item in TransportDisposition
        ),
        "independent_verifier_reconstructs_transport": all(
            verify_transport_classification(
                transport_curve(item),
                transports[item],
            )
            for item in TransportDisposition
        ),
        "local_effect_alone_cannot_explain_opposing_outcomes": old_mae > 0.5,
        "missing_descriptor_repairs_heldout_prediction": augmented_mae < old_mae,
        "seed_uncertainty_is_nonzero": all(
            all(value > 0.0 for value in atlas.standard_errors.values())
            for atlas in atlases.values()
        ),
    }
    return DiagnosticTestbedQualificationReport(
        passed=all(checks.values()),
        checks=checks,
        recovered_mechanisms=recovered,
        recovered_transports={
            expected.value: observed.value
            for expected, observed in transports.items()
        },
        metrics={
            "world_count": float(len(worlds)),
            "intervention_count": float(len(Intervention)),
            "transport_class_count": float(len(TransportDisposition)),
            "old_descriptor_mae": old_mae,
            "augmented_descriptor_mae": augmented_mae,
            "seed_count": 12.0,
        },
    )
