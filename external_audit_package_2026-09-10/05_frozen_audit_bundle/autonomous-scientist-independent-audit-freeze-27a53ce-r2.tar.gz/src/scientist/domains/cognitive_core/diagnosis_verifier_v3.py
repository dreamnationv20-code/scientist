from __future__ import annotations

import math

from scientist.domains.cognitive_core.diagnosis_v3 import (
    CausalAtlas,
    CausalMechanism,
    Intervention,
    TransportDisposition,
)


DIAGNOSTIC_VERIFIER_VERSION = "cognitive-core-diagnostic-verifier-v3"


def _independent_expected_effect(
    mechanism: CausalMechanism,
    intervention: Intervention,
) -> float:
    if intervention == Intervention.SHAM or mechanism == CausalMechanism.NULL:
        return 0.0
    if mechanism == CausalMechanism.MIXED:
        if intervention == Intervention.CAPACITY_HEADROOM:
            return 0.8
        if intervention == Intervention.SOURCE_CONTROL:
            return 0.7
        return 0.05
    target = {
        CausalMechanism.CAPACITY: Intervention.CAPACITY_HEADROOM,
        CausalMechanism.KINETICS: Intervention.TRAINING_TRAJECTORY,
        CausalMechanism.REPRESENTATION: Intervention.REPRESENTATION_FACTORIZATION,
        CausalMechanism.ROUTING: Intervention.SOURCE_CONTROL,
    }[mechanism]
    return 1.0 if intervention == target else 0.05


def verify_causal_atlas(atlas: CausalAtlas) -> bool:
    if atlas.evaluator_ref == DIAGNOSTIC_VERIFIER_VERSION:
        return False
    if set(atlas.effects) != {item.value for item in Intervention}:
        return False
    if set(atlas.standard_errors) != set(atlas.effects):
        return False
    return all(
        math.isclose(
            atlas.effects[intervention.value],
            _independent_expected_effect(atlas.mechanism, intervention),
            abs_tol=1e-12,
        )
        and atlas.standard_errors[intervention.value] > 0.0
        for intervention in Intervention
    )


def _independent_transport_classification(
    curve: tuple[float, ...],
) -> TransportDisposition:
    if len(curve) != 4:
        raise ValueError("verifier expected four horizons")
    first, _, _, last = curve
    if max(abs(item) for item in curve) < 0.1:
        return TransportDisposition.NULL
    if first < 0.2 and last > 0.7:
        return TransportDisposition.EMERGING
    if first > 0.5 and last < -0.2:
        return TransportDisposition.REVERSING
    if first > 0.5 and last < 0.4:
        return TransportDisposition.ATTENUATING
    return TransportDisposition.PERSISTENT


def verify_transport_classification(
    curve: tuple[float, ...],
    reported: TransportDisposition,
) -> bool:
    return _independent_transport_classification(curve) == reported
