from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.domains.cognitive_core.learning import (
    LearningConfig,
    TrainingCondition,
)


DIAGNOSTIC_ASSET_AUDIT_VERSION = "cognitive-core-diagnostic-asset-audit-v3"


@dataclass(frozen=True)
class DiagnosticAssetAudit:
    asset_ref: str
    factorial_ready: bool
    factor_status: Mapping[str, str]
    confounds: Mapping[str, Tuple[str, ...]]
    reusable_evidence: Tuple[str, ...]
    required_repairs: Tuple[str, ...]
    claim_boundary: str
    version: str = DIAGNOSTIC_ASSET_AUDIT_VERSION

    def as_dict(self) -> Dict[str, Any]:
        return {
            "asset_ref": self.asset_ref,
            "factorial_ready": self.factorial_ready,
            "factor_status": dict(sorted(self.factor_status.items())),
            "confounds": {
                key: list(values)
                for key, values in sorted(self.confounds.items())
            },
            "reusable_evidence": list(self.reusable_evidence),
            "required_repairs": list(self.required_repairs),
            "claim_boundary": self.claim_boundary,
            "version": self.version,
        }


def audit_legacy_mlx_lab() -> DiagnosticAssetAudit:
    # Instantiate the historical contract so future changes cannot silently
    # make this audit describe a configuration that the code no longer accepts.
    LearningConfig(
        condition=TrainingCondition.RANDOM_FACTS,
        fact_count=64,
        width=32,
        steps=800,
        evidence_schedule="balanced",
        relevance_annotation=False,
    )
    return DiagnosticAssetAudit(
        asset_ref="cognitive-core-mlx-lab-v6",
        factorial_ready=False,
        factor_status={
            "capacity": "partially observable but not independently manipulable",
            "kinetics": "checkpoint trajectories are reusable with explicit cost horizons",
            "representation": "annotation intervention is entangled with routing observability",
            "routing": "evidence schedule changes curriculum exposure rather than routing alone",
            "null": "same-seed structured-fact controls are reusable but insufficient",
        },
        confounds={
            "fact_count": (
                "changes memory load, not architectural capacity",
            ),
            "width": (
                "changes parameter count",
                "changes inference FLOPs",
                "changes all representational pathways simultaneously",
            ),
            "steps": (
                "changes optimization horizon",
                "changes training compute",
            ),
            "relevance_annotation": (
                "changes input representation",
                "changes evidence observability",
                "changes the available routing rule",
            ),
            "evidence_schedule": (
                "changes curriculum",
                "changes evidence frequency",
                "changes optimization kinetics and routing opportunity together",
            ),
        },
        reusable_evidence=(
            "same-run checkpoint curves for kinetics hypotheses",
            "random-versus-structured fact load controls",
            "evidence corruption and abstention stress suites",
            "historical local-to-natural routing failures as horizon contrasts",
        ),
        required_repairs=(
            "hold total parameters, tokens, FLOPs, and wall-time budgets explicit per arm",
            "allocate fixed resources between memory and reusable computation without changing total width",
            "separate representational factorization from the decision policy that routes evidence",
            "change curriculum order at fixed examples, steps, and source availability",
            "add sham interventions and pairwise interaction arms",
            "freeze continuous per-seed predictions before evaluating later horizons",
        ),
        claim_boundary=(
            "The historical lab is admissible as micro-horizon evidence and a "
            "source of contrasts. It cannot by itself identify the binding "
            "capacity, kinetics, representation, or routing mechanism."
        ),
    )
