from __future__ import annotations

import hashlib
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    Intervention,
    enumerate_interventions,
    score_on_cases,
)
from scientist.domains.cognitive_core.proposal_verification_v36 import (
    PROPOSAL_BUDGET,
    aggregate_proposal_sets,
    fixed_case_partition,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
    REPRESENTATIONS,
    RepairTask,
    _build_task,
    execute,
)


EVIDENCE_ALGEBRA_VERSION = "general-cognitive-evidence-algebra-v39"
M39_SPLIT_SEEDS = {"development": 39061, "test": 39109}
EVIDENCE_MODES = ("passive", "active")


@dataclass(frozen=True)
class EvidenceCase:
    case_id: str
    required: Any


@dataclass(frozen=True)
class CandidateTrace:
    candidate_id: str
    group_id: str
    ordinal: int
    predictions: Tuple[Any, ...]


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _classes(
    candidates: Sequence[CandidateTrace], signatures: Mapping[str, Tuple[str, ...]]
) -> Tuple[Tuple[str, ...], ...]:
    grouped: Dict[Tuple[str, ...], list[CandidateTrace]] = {}
    for candidate in candidates:
        grouped.setdefault(signatures[candidate.candidate_id], []).append(candidate)
    groups = [
        tuple(item.candidate_id for item in sorted(items, key=lambda item: item.ordinal))
        for items in grouped.values()
    ]
    return tuple(sorted(groups, key=lambda group: min(
        candidate.ordinal
        for candidate in candidates
        if candidate.candidate_id in set(group)
    )))


def analyze_evidence(
    cases: Sequence[EvidenceCase], candidates: Sequence[CandidateTrace]
) -> Mapping[str, Any]:
    """Analyze an executable candidate-by-case matrix without semantic labels.

    Resolution is deliberately conservative: exactly one candidate must agree with
    every observation. Multiple perfect candidates produce an explicit ambiguity;
    no perfect candidate means the supplied representation is inadequate.
    """

    cases = tuple(cases)
    candidates = tuple(candidates)
    if not cases:
        raise ValueError("at least one evidence case is required")
    if not candidates:
        raise ValueError("at least one candidate trace is required")
    if len({case.case_id for case in cases}) != len(cases):
        raise ValueError("evidence case ids must be unique")
    if len({candidate.candidate_id for candidate in candidates}) != len(candidates):
        raise ValueError("candidate ids must be unique")
    if len({candidate.ordinal for candidate in candidates}) != len(candidates):
        raise ValueError("candidate ordinals must be unique")
    if any(len(candidate.predictions) != len(cases) for candidate in candidates):
        raise ValueError("every candidate must have one prediction per case")

    required = tuple(_canonical(case.required) for case in cases)
    match_vectors: Dict[str, Tuple[bool, ...]] = {}
    prediction_vectors: Dict[str, Tuple[str, ...]] = {}
    for candidate in candidates:
        predictions = tuple(_canonical(value) for value in candidate.predictions)
        prediction_vectors[candidate.candidate_id] = predictions
        match_vectors[candidate.candidate_id] = tuple(
            prediction == expected for prediction, expected in zip(predictions, required)
        )

    dominates: Dict[str, list[str]] = {candidate.candidate_id: [] for candidate in candidates}
    dominated_by: Dict[str, list[str]] = {candidate.candidate_id: [] for candidate in candidates}
    for left in candidates:
        left_vector = match_vectors[left.candidate_id]
        for right in candidates:
            if left.candidate_id == right.candidate_id:
                continue
            right_vector = match_vectors[right.candidate_id]
            if all(a >= b for a, b in zip(left_vector, right_vector)) and any(
                a > b for a, b in zip(left_vector, right_vector)
            ):
                dominates[left.candidate_id].append(right.candidate_id)
                dominated_by[right.candidate_id].append(left.candidate_id)

    by_id = {candidate.candidate_id: candidate for candidate in candidates}
    agreement = {
        candidate.candidate_id: sum(match_vectors[candidate.candidate_id])
        for candidate in candidates
    }
    perfect = tuple(
        candidate.candidate_id
        for candidate in sorted(candidates, key=lambda item: item.ordinal)
        if agreement[candidate.candidate_id] == len(cases)
    )
    if len(perfect) == 1:
        status = "resolved"
        frontier = perfect
    elif perfect:
        status = "ambiguous"
        frontier = perfect
    else:
        status = "representation_inadequate"
        maximum = max(agreement.values())
        frontier = tuple(
            candidate.candidate_id
            for candidate in sorted(candidates, key=lambda item: item.ordinal)
            if agreement[candidate.candidate_id] == maximum
            and not dominated_by[candidate.candidate_id]
        )
        if not frontier:
            frontier = tuple(
                candidate.candidate_id
                for candidate in sorted(candidates, key=lambda item: item.ordinal)
                if agreement[candidate.candidate_id] == maximum
            )

    ranked = tuple(
        candidate.candidate_id
        for candidate in sorted(
            candidates,
            key=lambda item: (
                -agreement[item.candidate_id],
                len(dominated_by[item.candidate_id]),
                item.ordinal,
            ),
        )
    )
    groups: Dict[str, list[CandidateTrace]] = {}
    for candidate in candidates:
        groups.setdefault(candidate.group_id, []).append(candidate)
    group_rows = {}
    for group_id, members in sorted(
        groups.items(), key=lambda item: min(member.ordinal for member in item[1])
    ):
        member_ids = tuple(
            member.candidate_id for member in sorted(members, key=lambda item: item.ordinal)
        )
        best = max(agreement[member_id] for member_id in member_ids)
        group_rows[group_id] = {
            "member_candidate_ids": list(member_ids),
            "best_agreement_count": best,
            "best_agreement_rate": best / len(cases),
            "perfect_candidate_ids": [member_id for member_id in member_ids if member_id in perfect],
            "frontier_candidate_ids": [member_id for member_id in member_ids if member_id in frontier],
        }
    responsible_groups = tuple(
        group_id
        for group_id, row in group_rows.items()
        if row["frontier_candidate_ids"]
    )
    candidate_rows = {}
    for candidate in sorted(candidates, key=lambda item: item.ordinal):
        candidate_id = candidate.candidate_id
        vector = match_vectors[candidate_id]
        candidate_rows[candidate_id] = {
            "group_id": candidate.group_id,
            "ordinal": candidate.ordinal,
            "match_vector": [int(value) for value in vector],
            "agreement_count": agreement[candidate_id],
            "agreement_rate": agreement[candidate_id] / len(cases),
            "contradiction_case_ids": [
                case.case_id for case, matches in zip(cases, vector) if not matches
            ],
            "dominates": sorted(dominates[candidate_id], key=lambda key: by_id[key].ordinal),
            "dominated_by": sorted(
                dominated_by[candidate_id], key=lambda key: by_id[key].ordinal
            ),
            "prediction_fingerprint": hashlib.sha256(
                _canonical(prediction_vectors[candidate_id]).encode("utf-8")
            ).hexdigest(),
        }
    payload = {
        "version": EVIDENCE_ALGEBRA_VERSION,
        "status": status,
        "case_ids": [case.case_id for case in cases],
        "case_count": len(cases),
        "candidate_count": len(candidates),
        "perfect_candidate_ids": list(perfect),
        "frontier_candidate_ids": list(frontier),
        "resolved_candidate_id": perfect[0] if status == "resolved" else None,
        "ranked_candidate_ids": list(ranked),
        "evidence_equivalence_classes": [
            list(group)
            for group in _classes(
                candidates,
                {
                    key: tuple(str(int(value)) for value in vector)
                    for key, vector in match_vectors.items()
                },
            )
        ],
        "behavioral_equivalence_classes": [
            list(group) for group in _classes(candidates, prediction_vectors)
        ],
        "responsible_group_ids": list(responsible_groups),
        "resolved_group_id": responsible_groups[0]
        if status == "resolved" and len(responsible_groups) == 1
        else None,
        "groups": group_rows,
        "candidates": candidate_rows,
        "calibrated_abstention": status != "resolved",
    }
    return {**payload, "analysis_id": content_digest(payload)}


def build_m39_suite(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[RepairTask, ...]:
    if split not in M39_SPLIT_SEEDS:
        raise ValueError("unknown M39 split")
    rng = random.Random(M39_SPLIT_SEEDS[split])
    tasks = tuple(
        _build_task(f"m39_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("M39 task ids are not unique")
    return tasks


def evidence_cases(task: RepairTask, mode: str) -> Tuple[Mapping[str, Any], ...]:
    if mode not in EVIDENCE_MODES:
        raise ValueError("unknown evidence mode")
    passive = tuple(task.visible_correct) + (task.counterexample,)
    if mode == "passive":
        return passive
    diagnostic, _ = fixed_case_partition(task)
    return passive + diagnostic


def task_evidence_matrix(
    task: RepairTask,
    mode: str,
    *,
    selected_cases: Sequence[Mapping[str, Any]] | None = None,
    opaque_labels: bool = False,
) -> Tuple[Tuple[EvidenceCase, ...], Tuple[CandidateTrace, ...], Mapping[str, str]]:
    raw_cases = tuple(selected_cases) if selected_cases is not None else evidence_cases(task, mode)
    interventions = tuple(enumerate_interventions(task))
    case_rows = tuple(
        EvidenceCase(f"case_{index + 1}", case["expected"])
        for index, case in enumerate(raw_cases)
    )
    group_names = {
        node: (f"opaque_group_{index + 1}" if opaque_labels else node)
        for index, node in enumerate(sorted(task.candidate))
    }
    forward = {
        intervention.key: (
            f"opaque_candidate_{len(interventions) - index:03d}"
            if opaque_labels
            else intervention.key
        )
        for index, intervention in enumerate(interventions)
    }
    traces = []
    for ordinal, intervention in enumerate(interventions):
        predictions = []
        for case in raw_cases:
            try:
                prediction = execute(task.representation, intervention.program, case["input"])
            except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
                prediction = {"execution_error": True}
            predictions.append(prediction)
        traces.append(
            CandidateTrace(
                candidate_id=forward[intervention.key],
                group_id=group_names[intervention.node],
                ordinal=ordinal,
                predictions=tuple(predictions),
            )
        )
    if opaque_labels:
        traces.reverse()
    return case_rows, tuple(traces), forward


def analyze_task(task: RepairTask, mode: str) -> Mapping[str, Any]:
    cases, traces, _ = task_evidence_matrix(task, mode)
    return analyze_evidence(cases, traces)


def _invariance_check(task: RepairTask, mode: str) -> bool:
    cases, traces, _ = task_evidence_matrix(task, mode)
    opaque_cases, opaque_traces, forward = task_evidence_matrix(
        task, mode, opaque_labels=True
    )
    original = analyze_evidence(cases, traces)
    opaque = analyze_evidence(opaque_cases, opaque_traces)
    reverse = {opaque_id: source_id for source_id, opaque_id in forward.items()}

    def remap(values: Sequence[str]) -> Tuple[str, ...]:
        return tuple(reverse.get(value, value) for value in values)

    original_classes = {
        frozenset(group) for group in original["evidence_equivalence_classes"]
    }
    opaque_classes = {
        frozenset(remap(group)) for group in opaque["evidence_equivalence_classes"]
    }
    return bool(
        original["status"] == opaque["status"]
        and tuple(original["ranked_candidate_ids"])
        == remap(opaque["ranked_candidate_ids"])
        and set(original["perfect_candidate_ids"])
        == set(remap(opaque["perfect_candidate_ids"]))
        and original_classes == opaque_classes
    )


def _ambiguous_single_case(task: RepairTask) -> Mapping[str, Any] | None:
    best = None
    for case in evidence_cases(task, "active"):
        cases, traces, _ = task_evidence_matrix(
            task, "active", selected_cases=(case,)
        )
        analysis = analyze_evidence(cases, traces)
        size = len(analysis["perfect_candidate_ids"])
        if size >= 2 and (best is None or size > best[0]):
            best = (size, case, analysis)
    if best is None:
        return None
    return {"case": best[1], "analysis": best[2]}


def _condition_metrics(
    tasks: Sequence[RepairTask], mode: str
) -> Tuple[Mapping[str, Any], Sequence[Mapping[str, Any]]]:
    proposal_sets = []
    analyses = []
    interventions_by_task = {}
    for task in tasks:
        interventions = tuple(enumerate_interventions(task))
        interventions_by_task[task.task_id] = {item.key: item for item in interventions}
        analysis = analyze_task(task, mode)
        analyses.append(analysis)
        proposal_sets.append(
            tuple(
                interventions_by_task[task.task_id][candidate_id]
                for candidate_id in analysis["ranked_candidate_ids"][:PROPOSAL_BUDGET]
            )
        )
    aggregate = aggregate_proposal_sets(
        f"evidence_algebra_{mode}", tasks, proposal_sets
    )
    records = []
    resolved = 0
    resolved_correct = 0
    correct_retained = 0
    target_group_retained = 0
    invariant = 0
    ambiguity_sizes = []
    by_representation: Dict[str, list[Mapping[str, float]]] = {}
    for task, analysis, controller in zip(tasks, analyses, aggregate["records"]):
        correct_key = f"{task.target_node}={json.dumps(task.correct_edit_value, sort_keys=True)}"
        is_resolved = analysis["status"] == "resolved"
        is_correct = analysis["resolved_candidate_id"] == correct_key
        frontier = set(analysis["frontier_candidate_ids"])
        item = {
            "resolved": float(is_resolved),
            "resolved_correct": float(is_resolved and is_correct),
            "correct_retained": float(correct_key in frontier),
            "target_group_retained": float(task.target_node in analysis["responsible_group_ids"]),
            "invariant": float(_invariance_check(task, mode)),
        }
        resolved += int(is_resolved)
        resolved_correct += int(is_resolved and is_correct)
        correct_retained += int(correct_key in frontier)
        target_group_retained += int(task.target_node in analysis["responsible_group_ids"])
        invariant += int(item["invariant"])
        ambiguity_sizes.append(len(analysis["frontier_candidate_ids"]))
        by_representation.setdefault(task.representation, []).append(item)
        records.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "analysis": analysis,
                "controller": controller,
            }
        )

    def mean(items: Sequence[Mapping[str, float]], key: str) -> float:
        return sum(item[key] for item in items) / len(items)

    metrics = {
        **aggregate["metrics"],
        "resolved_rate": resolved / len(tasks),
        "resolution_precision": resolved_correct / resolved if resolved else 1.0,
        "correct_frontier_retention_rate": correct_retained / len(tasks),
        "target_group_retention_rate": target_group_retained / len(tasks),
        "mean_frontier_size": sum(ambiguity_sizes) / len(ambiguity_sizes),
        "representation_label_invariance_rate": invariant / len(tasks),
        "analysis_completeness": len(records) / len(tasks),
        "algebra_by_representation": {
            representation: {
                "resolved_rate": mean(items, "resolved"),
                "resolution_precision": (
                    sum(item["resolved_correct"] for item in items)
                    / sum(item["resolved"] for item in items)
                    if sum(item["resolved"] for item in items)
                    else 1.0
                ),
                "correct_frontier_retention_rate": mean(items, "correct_retained"),
                "target_group_retention_rate": mean(items, "target_group_retained"),
                "representation_label_invariance_rate": mean(items, "invariant"),
            }
            for representation, items in sorted(by_representation.items())
        },
    }
    heldout_records = [
        record
        for record in aggregate["records"]
        if record["representation"] in HELDOUT_LOCALIZATION_REPRESENTATIONS
    ]
    metrics["heldout_exact_repair_coverage_at_k"] = sum(
        float(record["assessment"]["exact_repair_coverage"])
        for record in heldout_records
    ) / len(heldout_records)
    return metrics, records


def _ambiguity_metrics(
    tasks: Sequence[RepairTask],
) -> Tuple[Mapping[str, Any], Sequence[Mapping[str, Any]]]:
    rows = []
    by_representation: Dict[str, list[Mapping[str, float]]] = {}
    for task in tasks:
        control = _ambiguous_single_case(task)
        if control is None:
            continue
        analysis = control["analysis"]
        correct_key = f"{task.target_node}={json.dumps(task.correct_edit_value, sort_keys=True)}"
        row = {
            "task_id": task.task_id,
            "representation": task.representation,
            "status": analysis["status"],
            "frontier_size": len(analysis["frontier_candidate_ids"]),
            "false_confident_resolution": analysis["status"] == "resolved",
            "correct_retained": correct_key in set(analysis["frontier_candidate_ids"]),
            "analysis": analysis,
        }
        rows.append(row)
        by_representation.setdefault(task.representation, []).append(
            {
                "recognized": float(analysis["status"] == "ambiguous"),
                "false_confident": float(analysis["status"] == "resolved"),
                "retained": float(row["correct_retained"]),
            }
        )

    def summarize(items: Sequence[Mapping[str, float]]) -> Mapping[str, float]:
        return {
            "ambiguity_recognition_rate": sum(item["recognized"] for item in items) / len(items),
            "false_confident_resolution_rate": sum(item["false_confident"] for item in items)
            / len(items),
            "correct_candidate_retention_rate": sum(item["retained"] for item in items) / len(items),
        }

    summary = summarize(
        [
            {
                "recognized": float(row["status"] == "ambiguous"),
                "false_confident": float(row["false_confident_resolution"]),
                "retained": float(row["correct_retained"]),
            }
            for row in rows
        ]
    )
    return {
        "task_count": len(rows),
        **summary,
        "mean_frontier_size": sum(row["frontier_size"] for row in rows) / len(rows),
        "by_representation": {
            representation: {"task_count": len(items), **summarize(items)}
            for representation, items in sorted(by_representation.items())
        },
    }, rows


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def prepare_m39_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    test = build_m39_suite("test", 30)
    public_hash = _write_jsonl(
        output / "test-public.jsonl",
        (
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "candidate_count": len(enumerate_interventions(task)),
                "passive_case_count": len(evidence_cases(task, "passive")),
                "active_case_count": len(evidence_cases(task, "active")),
            }
            for task in test
        ),
    )
    authority_hash = _write_jsonl(
        output / "test-authority.jsonl",
        (
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "target_node": task.target_node,
                "correct_edit_value": task.correct_edit_value,
                "diagnostic_cases": list(fixed_case_partition(task)[0]),
                "final_cases": list(fixed_case_partition(task)[1]),
            }
            for task in test
        ),
    )
    ambiguity_counts = {
        representation: sum(
            int(_ambiguous_single_case(task) is not None)
            for task in test
            if task.representation == representation
        )
        for representation in REPRESENTATIONS
    }
    payload = {
        "version": EVIDENCE_ALGEBRA_VERSION,
        "split_seeds": M39_SPLIT_SEEDS,
        "representations": list(REPRESENTATIONS),
        "evidence_modes": list(EVIDENCE_MODES),
        "proposal_budget": PROPOSAL_BUDGET,
        "counts": {
            "test_tasks": len(test),
            "tasks_per_representation": 30,
            "ambiguity_controls_by_representation": ambiguity_counts,
        },
        "hashes": {"test_public": public_hash, "test_authority": authority_hash},
        "operator_contract": {
            "resolved": "exactly_one_candidate_matches_every_observation",
            "ambiguous": "multiple_candidates_match_every_observation",
            "representation_inadequate": "no_candidate_matches_every_observation",
            "ranking": "agreement_then_dominance_then_stable_ordinal",
            "semantic_label_use": False,
            "model_use": False,
        },
        "gates": {
            "minimum_active_exact_coverage_at_k": 0.99,
            "minimum_active_semantic_accuracy": 0.98,
            "minimum_active_preservation": 1.0,
            "minimum_passive_exact_coverage_at_k": 0.98,
            "minimum_active_heldout_exact_coverage_at_k": 0.98,
            "minimum_active_heldout_semantic_accuracy": 0.98,
            "minimum_resolution_precision": 1.0,
            "minimum_correct_frontier_retention": 1.0,
            "minimum_target_group_retention": 1.0,
            "minimum_representation_label_invariance": 1.0,
            "minimum_analysis_completeness": 1.0,
            "minimum_ambiguity_control_count": 100,
            "minimum_ambiguity_recognition": 1.0,
            "maximum_false_confident_resolution": 0.0,
            "minimum_ambiguity_correct_retention": 1.0,
        },
        "claim_boundary": (
            "M39 tests a deterministic evidence algebra on fresh finite typed single-fault mechanisms. "
            "It tests structured consequence comparison, calibrated abstention, and representation-label "
            "invariance. It does not test active experiment invention, open-vocabulary concepts, multifault "
            "repair, or model-size parity."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m39_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": content_digest(payload) == freeze["freeze_id"],
        "gates_frozen": "gates" in freeze,
        "operator_contract_frozen": "operator_contract" in freeze,
        "no_model_or_training_data": not (output / "train.jsonl").exists(),
        "diagnostic_and_final_cases_disjoint": all(
            {
                _canonical(case["input"])
                for case in fixed_case_partition(task)[0]
            }.isdisjoint(
                {_canonical(case["input"]) for case in fixed_case_partition(task)[1]}
            )
            for task in build_m39_suite("test", 30)
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}


def evaluate_m39(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m39_suite("test", 30)
    mode_results = {}
    prediction_payload = {}
    for mode in EVIDENCE_MODES:
        metrics, records = _condition_metrics(tasks, mode)
        mode_results[mode] = metrics
        prediction_payload[mode] = records
    ambiguity_metrics, ambiguity_records = _ambiguity_metrics(tasks)
    prediction_payload["ambiguity_controls"] = ambiguity_records
    store = ArtifactStore(output_root)
    predictions_digest = store.put("evidence_algebra_predictions", prediction_payload)
    payload = {
        "version": EVIDENCE_ALGEBRA_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "operator_contract": freeze["operator_contract"],
        "metrics_by_evidence_mode": mode_results,
        "ambiguity_controls": ambiguity_metrics,
        "predictions_digest": predictions_digest,
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"evidence-algebra-{manifest['evaluation_id']}", manifest)
    return manifest


def assess_m39(
    evaluation: Mapping[str, Any], benchmark_root: Path
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["gates"]
    active = evaluation["metrics_by_evidence_mode"]["active"]
    passive = evaluation["metrics_by_evidence_mode"]["passive"]
    ambiguity = evaluation["ambiguity_controls"]
    checks = {
        "same_benchmark_freeze": evaluation["benchmark_freeze_id"] == freeze["freeze_id"],
        "active_exact_coverage": active["exact_repair_coverage_at_k"]
        >= gates["minimum_active_exact_coverage_at_k"],
        "active_semantic_accuracy": active["selected_semantic_accuracy"]
        >= gates["minimum_active_semantic_accuracy"],
        "active_preservation": active["selected_preserved_correct_accuracy"]
        >= gates["minimum_active_preservation"],
        "passive_exact_coverage": passive["exact_repair_coverage_at_k"]
        >= gates["minimum_passive_exact_coverage_at_k"],
        "active_heldout_exact_coverage": active["heldout_exact_repair_coverage_at_k"]
        >= gates["minimum_active_heldout_exact_coverage_at_k"],
        "active_heldout_semantic_accuracy": active["heldout_selected_semantic_accuracy"]
        >= gates["minimum_active_heldout_semantic_accuracy"],
        "resolution_precision": active["resolution_precision"]
        >= gates["minimum_resolution_precision"],
        "correct_frontier_retention": active["correct_frontier_retention_rate"]
        >= gates["minimum_correct_frontier_retention"],
        "target_group_retention": active["target_group_retention_rate"]
        >= gates["minimum_target_group_retention"],
        "representation_label_invariance": active["representation_label_invariance_rate"]
        >= gates["minimum_representation_label_invariance"],
        "analysis_completeness": active["analysis_completeness"]
        >= gates["minimum_analysis_completeness"],
        "ambiguity_control_count": ambiguity["task_count"]
        >= gates["minimum_ambiguity_control_count"],
        "ambiguity_recognition": ambiguity["ambiguity_recognition_rate"]
        >= gates["minimum_ambiguity_recognition"],
        "zero_false_confident_resolution": ambiguity["false_confident_resolution_rate"]
        <= gates["maximum_false_confident_resolution"],
        "ambiguity_correct_retention": ambiguity["correct_candidate_retention_rate"]
        >= gates["minimum_ambiguity_correct_retention"],
    }
    payload = {
        "version": EVIDENCE_ALGEBRA_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "evaluation_id": evaluation["evaluation_id"],
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
    }
    return {**payload, "assessment_id": content_digest(payload)}
