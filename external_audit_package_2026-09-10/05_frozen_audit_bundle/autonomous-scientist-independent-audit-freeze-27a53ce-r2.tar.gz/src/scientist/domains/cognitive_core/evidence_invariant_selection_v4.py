from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.heldout_model_selection_v3 import (
    MAX_SELECTED_RMSE,
    MIN_SEED_STABILITY,
    PREDICTION_RESIDUAL_FLOOR,
    CompetingModelSpec,
    FrozenModelPredictionRegistry,
    HeldoutOutcome,
    QuantitativePrediction,
    _outcome,
)
from scientist.program.diagnostics import DiagnosticDisposition


EVIDENCE_INVARIANT_SELECTION_VERSION = (
    "cognitive-core-evidence-invariant-model-selection-v4"
)

# These six endpoints are measured on distinct evaluation families.  The
# geometric cognitive-core score and known-answer destruction are derived from
# these family outcomes, so treating them as additional independent likelihood
# terms would count some observations twice.
INDEPENDENT_SELECTION_METRICS = (
    "procedure_accuracy",
    "closed_book_accuracy",
    "oracle_evidence_accuracy",
    "irrelevant_evidence_accuracy",
    "conflicting_evidence_accuracy",
    "unknown_accuracy",
)

COMPLEXITY_PENALTY_PER_TERM = 0.01
MIN_TOTAL_LOG_SCORE_MARGIN = 2.0
MIN_SELECTED_PROBABILITY = 0.80


@dataclass(frozen=True)
class EvidenceInvariantModelFit:
    model_id: str
    total_predictive_log_score: float
    mean_predictive_log_score: float
    rmse: float
    posterior_probability: float
    leave_one_seed_out_win_fraction: float
    complexity: int
    scored_observation_count: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "total_predictive_log_score": self.total_predictive_log_score,
            "mean_predictive_log_score": self.mean_predictive_log_score,
            "rmse": self.rmse,
            "posterior_probability": self.posterior_probability,
            "leave_one_seed_out_win_fraction": (
                self.leave_one_seed_out_win_fraction
            ),
            "complexity": self.complexity,
            "scored_observation_count": self.scored_observation_count,
        }


@dataclass(frozen=True)
class EvidenceInvariantSelection:
    fits: Mapping[str, EvidenceInvariantModelFit]
    supported_model_ids: Tuple[str, ...]
    disposition: DiagnosticDisposition
    checks: Mapping[str, bool]
    total_score_margin: float
    seed_count: int
    scored_metrics: Tuple[str, ...]
    registry_id: str
    version: str = EVIDENCE_INVARIANT_SELECTION_VERSION

    @property
    def resolved(self) -> bool:
        return (
            all(self.checks.values())
            and self.disposition != DiagnosticDisposition.INCONCLUSIVE
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "registry_id": self.registry_id,
            "fits": {
                key: value.as_dict() for key, value in sorted(self.fits.items())
            },
            "supported_model_ids": list(self.supported_model_ids),
            "disposition": self.disposition.value,
            "checks": dict(sorted(self.checks.items())),
            "total_score_margin": self.total_score_margin,
            "seed_count": self.seed_count,
            "scored_metrics": list(self.scored_metrics),
            "resolved": self.resolved,
        }


def _score_one_model(
    model: CompetingModelSpec,
    predictions: Mapping[str, Mapping[str, QuantitativePrediction]],
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
    metrics: Sequence[str],
    *,
    leave_out_seed: int | None = None,
) -> Tuple[float, float, int]:
    total_log_score = 0.0
    squared_errors = []
    for arm_id, arm_outcomes in outcomes.items():
        if arm_id == "sham":
            continue
        for metric in metrics:
            observed = arm_outcomes[metric]
            prediction = predictions[arm_id][metric]
            if leave_out_seed is None:
                observed_mean = observed.mean
                observed_se = observed.standard_error
            else:
                retained = tuple(
                    sample
                    for index, sample in enumerate(observed.samples)
                    if index != leave_out_seed
                )
                reduced = _outcome(retained)
                observed_mean = reduced.mean
                observed_se = reduced.standard_error
            variance = (
                observed_se**2
                + prediction.standard_error**2
                + PREDICTION_RESIDUAL_FLOOR[metric] ** 2
            )
            residual = observed_mean - prediction.mean
            total_log_score += -0.5 * (
                residual**2 / variance + math.log(2.0 * math.pi * variance)
            )
            squared_errors.append(residual**2)
    # This penalty is deliberately applied once.  Therefore adding an outcome
    # on which every model has the same predictive distribution adds the same
    # value to every total score and cannot alter any pairwise margin.
    total_log_score -= COMPLEXITY_PENALTY_PER_TERM * model.complexity
    count = len(squared_errors)
    if count == 0:
        raise ValueError("evidence-invariant selection has no scored outcomes")
    rmse = math.sqrt(sum(squared_errors) / float(count))
    return total_log_score, rmse, count


def score_evidence_invariant_models(
    registry: FrozenModelPredictionRegistry,
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
    *,
    model_ids: Sequence[str] | None = None,
    metrics: Sequence[str] = INDEPENDENT_SELECTION_METRICS,
) -> EvidenceInvariantSelection:
    metrics = tuple(metrics)
    if not metrics or len(set(metrics)) != len(metrics):
        raise ValueError("selection metrics must be a unique non-empty sequence")
    if any(metric not in PREDICTION_RESIDUAL_FLOOR for metric in metrics):
        raise ValueError("selection contains an unknown metric")
    if any(
        metric in ("cognitive_core_score", "known_answer_destruction")
        for metric in metrics
    ):
        raise ValueError("derived outcomes cannot be independent score terms")

    available = {model.model_id: model for model in registry.models}
    selected_ids = tuple(model_ids or available)
    if not selected_ids or len(set(selected_ids)) != len(selected_ids):
        raise ValueError("candidate model identities must be unique and non-empty")
    if not set(selected_ids).issubset(available):
        raise ValueError("selection requested a model outside the registry")
    models = tuple(available[model_id] for model_id in selected_ids)
    expected_arms = set(outcomes)
    if not all(
        expected_arms.issubset(registry.predictions[model.model_id])
        for model in models
    ):
        raise ValueError("candidate predictions do not cover the outcomes")
    if not all(
        set(metrics).issubset(arm_outcomes)
        for arm_outcomes in outcomes.values()
    ):
        raise ValueError("outcomes do not contain every independent metric")

    raw = {
        model.model_id: _score_one_model(
            model,
            registry.predictions[model.model_id],
            outcomes,
            metrics,
        )
        for model in models
    }
    maximum = max(total for total, _, _ in raw.values())
    weights = {
        model_id: math.exp(max(-700.0, min(0.0, total - maximum)))
        for model_id, (total, _, _) in raw.items()
    }
    total_weight = sum(weights.values())
    first_outcome = next(iter(next(iter(outcomes.values())).values()))
    seed_count = len(first_outcome.samples)
    leave_one_winners = []
    for seed_index in range(seed_count):
        leave_one_scores = {
            model.model_id: _score_one_model(
                model,
                registry.predictions[model.model_id],
                outcomes,
                metrics,
                leave_out_seed=seed_index,
            )[0]
            for model in models
        }
        leave_one_winners.append(max(leave_one_scores, key=leave_one_scores.get))

    fits = {
        model_id: EvidenceInvariantModelFit(
            model_id=model_id,
            total_predictive_log_score=total,
            mean_predictive_log_score=total / float(count),
            rmse=rmse,
            posterior_probability=weights[model_id] / total_weight,
            leave_one_seed_out_win_fraction=(
                leave_one_winners.count(model_id) / float(seed_count)
            ),
            complexity=available[model_id].complexity,
            scored_observation_count=count,
        )
        for model_id, (total, rmse, count) in raw.items()
    }
    ordered = sorted(
        fits.values(),
        key=lambda item: item.total_predictive_log_score,
        reverse=True,
    )
    top = ordered[0]
    margin = (
        math.inf
        if len(ordered) == 1
        else top.total_predictive_log_score
        - ordered[1].total_predictive_log_score
    )
    distinguishable = (
        margin >= MIN_TOTAL_LOG_SCORE_MARGIN
        and top.rmse <= MAX_SELECTED_RMSE
        and top.posterior_probability >= MIN_SELECTED_PROBABILITY
        and top.leave_one_seed_out_win_fraction >= MIN_SEED_STABILITY
    )
    supported = (top.model_id,) if distinguishable else ()
    disposition = (
        available[top.model_id].disposition
        if distinguishable
        else DiagnosticDisposition.INCONCLUSIVE
    )
    checks = {
        "at_least_six_heldout_seeds": seed_count >= 6,
        "candidate_predictions_cover_outcomes": all(
            expected_arms.issubset(registry.predictions[model.model_id])
            for model in models
        ),
        "complexity_penalty_is_applied_once": True,
        "derived_metrics_are_not_independent_terms": set(metrics).isdisjoint(
            {"cognitive_core_score", "known_answer_destruction"}
        ),
        "uncertainty_is_finite": all(
            math.isfinite(outcome.mean)
            and math.isfinite(outcome.standard_error)
            and outcome.standard_error >= 0.0
            for arm in outcomes.values()
            for outcome in arm.values()
        ),
        "ambiguity_rule_was_respected": distinguishable or not supported,
    }
    return EvidenceInvariantSelection(
        fits=fits,
        supported_model_ids=supported,
        disposition=disposition,
        checks=checks,
        total_score_margin=margin,
        seed_count=seed_count,
        scored_metrics=metrics,
        registry_id=registry.registry_id,
    )

