from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Mapping,
    Sequence,
    Tuple,
)

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.learning import (
    ABSTAIN_CLASS,
    EncodedExample,
    LearningConfig,
    TrainingCondition,
    encode_evidence,
    fact_keys,
    fact_label,
    unknown_keys,
    update_label,
)
from scientist.domains.cognitive_core.prior_art import (
    evidence_utilization_scope_assessment,
)

if TYPE_CHECKING:
    from scientist.domains.cognitive_core.mlx_lab import LearnedRunResult


EVIDENCE_STRESS_VERSION = "cognitive-core-evidence-stress-v1"
DEFAULT_NOISE_RATES = (0, 10, 25, 50, 100)


def _corrupted(index: int, total: int, percent: int) -> bool:
    """Choose an exactly sized, deterministic subset without prefix bias."""

    if not 0 <= percent <= 100:
        raise ValueError("noise percent must be in [0, 100]")
    rank = (index * 7919 + 104729) % total
    return rank < round(total * percent / 100.0)


def evidence_stress_suite(
    config: LearningConfig,
    noise_rates: Sequence[int] = DEFAULT_NOISE_RATES,
) -> Tuple[EncodedExample, ...]:
    """Counterfactually corrupt explicit relevance labels at test time.

    Values, keys, queries, and target answers remain fixed across noise
    levels.  Only the relevance markers change.  This isolates dependence
    on the exact annotation token from evidence-key matching.
    """

    if not config.relevance_annotation:
        raise ValueError(
            "the counterfactual stress suite requires an annotated model"
        )
    examples = []
    known = fact_keys(config)
    total_known = len(known)

    for percent in noise_rates:
        suffix = "%03d" % percent
        for index, key in enumerate(known):
            corrupt = _corrupted(index, total_known, percent)
            distractor_key = (key + config.fact_count + 17) % 256
            if distractor_key == key:
                distractor_key = (distractor_key + 1) % 256
            examples.append(
                encode_evidence(
                    key,
                    ((distractor_key, (7 * key + 3) % 16),),
                    fact_label(config, key),
                    "irrelevant_false_positive_" + suffix,
                    "known-%03d" % key,
                    annotate_relevance=True,
                    relevance_labels=(corrupt,),
                )
            )
            examples.append(
                encode_evidence(
                    key,
                    ((key, update_label(config, key)),),
                    update_label(config, key),
                    "update_false_negative_" + suffix,
                    "known-%03d" % key,
                    annotate_relevance=True,
                    relevance_labels=(not corrupt,),
                )
            )

        rng = random.Random(config.data_seed + 880301)
        oracle_total = 192
        for index in range(oracle_total):
            query = rng.randrange(256)
            answer = rng.randrange(16)
            distractor_key = (
                query + 1 + rng.randrange(254)
            ) % 256
            evidence = (
                (query, answer),
                (distractor_key, rng.randrange(16)),
            )
            labels = (True, False)
            if index % 2:
                evidence = tuple(reversed(evidence))
                labels = tuple(reversed(labels))
            if _corrupted(index, oracle_total, percent):
                labels = tuple(not value for value in labels)
            examples.append(
                encode_evidence(
                    query,
                    evidence,
                    answer,
                    "oracle_label_swap_" + suffix,
                    "oracle-%03d" % index,
                    annotate_relevance=True,
                    relevance_labels=labels,
                )
            )

        unavailable = unknown_keys(config)
        unknown_total = 96
        for index in range(unknown_total):
            query = unavailable[index % len(unavailable)]
            distractor_key = (query + 37) % 256
            if distractor_key == query:
                distractor_key = (distractor_key + 1) % 256
            corrupt = _corrupted(index, unknown_total, percent)
            examples.append(
                encode_evidence(
                    query,
                    ((distractor_key, (5 * query + 1) % 16),),
                    ABSTAIN_CLASS,
                    "unknown_false_positive_" + suffix,
                    "unknown-%03d" % index,
                    annotate_relevance=True,
                    relevance_labels=(corrupt,),
                )
            )
    return tuple(examples)


@dataclass(frozen=True)
class EvidenceStressSummary:
    summary_id: str
    prior_art_assessment_id: str
    run_id: str
    robustness_curves: Mapping[str, Mapping[str, float]]
    clean_gate_passed: bool
    noisy_gate_passed: bool
    decision: str
    claim_boundary: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "summary_id": self.summary_id,
            "prior_art_assessment_id": self.prior_art_assessment_id,
            "run_id": self.run_id,
            "robustness_curves": {
                family: dict(sorted(values.items()))
                for family, values in sorted(
                    self.robustness_curves.items()
                )
            },
            "clean_gate_passed": self.clean_gate_passed,
            "noisy_gate_passed": self.noisy_gate_passed,
            "decision": self.decision,
            "claim_boundary": self.claim_boundary,
        }


def summarize_stress(
    result: LearnedRunResult,
    prior_art_assessment_id: str,
    noise_rates: Sequence[int] = DEFAULT_NOISE_RATES,
) -> EvidenceStressSummary:
    families = (
        "irrelevant_false_positive",
        "update_false_negative",
        "oracle_label_swap",
        "unknown_false_positive",
    )
    curves = {
        family: {
            "%03d" % percent: result.metrics[
                "relevance_noise.%s_%03d_accuracy"
                % (family, percent)
            ]
            for percent in noise_rates
        }
        for family in families
    }
    clean_gate = (
        result.metrics["closed_book_accuracy"] >= 0.95
        and result.metrics["oracle_evidence_accuracy"] >= 0.90
        and result.metrics["irrelevant_evidence_accuracy"] >= 0.90
        and result.metrics["unknown_accuracy"] >= 0.90
    )
    noisy_gate = all(
        curves[family]["025"] >= 0.75
        for family in families
    )
    if not clean_gate:
        decision = (
            "kill: the candidate failed its original clean-evidence gates"
        )
    elif not noisy_gate:
        decision = (
            "revise: exact relevance annotations are too brittle for "
            "external transfer; learn or marginalize relevance confidence"
        )
    else:
        decision = (
            "ascend: freeze a multi-seed replication and then evaluate the "
            "same decision rule on the CUB natural-data development split"
        )
    claim_boundary = (
        "Development diagnostic only. The prior-art classification is "
        "reproduction; no novelty, frontier-advance, scaled-model, or "
        "breakthrough claim is authorized."
    )
    payload = {
        "stress_version": EVIDENCE_STRESS_VERSION,
        "assessment_id": prior_art_assessment_id,
        "run_id": result.run_id,
        "curves": curves,
        "clean_gate": clean_gate,
        "noisy_gate": noisy_gate,
        "decision": decision,
        "claim_boundary": claim_boundary,
    }
    return EvidenceStressSummary(
        summary_id=content_digest(payload)[:20],
        prior_art_assessment_id=prior_art_assessment_id,
        run_id=result.run_id,
        robustness_curves=curves,
        clean_gate_passed=clean_gate,
        noisy_gate_passed=noisy_gate,
        decision=decision,
        claim_boundary=claim_boundary,
    )


def run_stress(
    output_root: Path,
    config: LearningConfig,
) -> EvidenceStressSummary:
    from scientist.domains.cognitive_core.mlx_lab import train_and_evaluate

    store = ArtifactStore(output_root)
    assessment = evidence_utilization_scope_assessment(
        "cognitive-core-evidence-stress-v1"
    )
    assessment_digest = store.put(
        "prior_art_assessment",
        assessment.as_dict(),
    )
    suite = evidence_stress_suite(config)
    result = train_and_evaluate(
        config,
        extra_suites={"relevance_noise": suite},
    )
    run_digest = store.put(
        "cognitive_core_evidence_stress_run",
        result.as_dict(),
    )
    summary = summarize_stress(result, assessment.assessment_id)
    manifest = {
        **summary.as_dict(),
        "schema": 1,
        "stress_version": EVIDENCE_STRESS_VERSION,
        "development_status": "diagnostic_not_replication",
        "prior_art_object_digest": assessment_digest,
        "run_object_digest": run_digest,
        "config": config.as_dict(),
        "preregistered_noisy_gate": (
            "all four evidence behaviors retain >=0.75 accuracy at "
            "25% counterfactual relevance-label noise"
        ),
        "next_external_incumbent": "chen-et-al-cub-2026",
    }
    store.write_manifest(
        "cognitive-core-evidence-stress-" + summary.summary_id,
        manifest,
    )
    return summary


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/evidence_stress_v1",
    )
    parser.add_argument("--steps", type=int, default=1600)
    parser.add_argument("--seed", type=int, default=21)
    parser.add_argument("--data-seed", type=int, default=20260810)
    parser.add_argument(
        "--training-label-noise",
        type=float,
        default=0.0,
    )
    parser.add_argument(
        "--unknown-evidence-fraction",
        type=float,
        default=0.0,
    )
    parser.add_argument(
        "--evidence-schedule",
        choices=(
            "balanced",
            "routing_6",
            "routing_8",
            "routing_10",
            "routing_heavy",
        ),
        default="routing_10",
    )
    parser.add_argument(
        "--device",
        choices=("cpu", "gpu"),
        default="cpu",
    )
    arguments = parser.parse_args(list(argv) or None)
    config = LearningConfig(
        condition=TrainingCondition.RANDOM_FACTS,
        fact_count=192,
        width=32,
        steps=arguments.steps,
        model_seed=arguments.seed,
        data_seed=arguments.data_seed,
        compute_device=arguments.device,
        evidence_schedule=arguments.evidence_schedule,
        relevance_annotation=True,
        relevance_label_noise=arguments.training_label_noise,
        unknown_evidence_fraction=(
            arguments.unknown_evidence_fraction
        ),
    )
    summary = run_stress(Path(arguments.output), config)
    print(json.dumps(summary.as_dict(), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
