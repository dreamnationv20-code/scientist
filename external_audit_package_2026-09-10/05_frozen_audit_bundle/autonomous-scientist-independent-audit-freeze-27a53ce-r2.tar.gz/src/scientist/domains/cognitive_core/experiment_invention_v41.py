from __future__ import annotations

import hashlib
import itertools
import json
import math
import random
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.ambiguity_stress_v40 import (
    AmbiguityScenario,
    _short_horizon_scenario,
    robust_evidence_policy,
)
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    Intervention,
    enumerate_interventions,
)
from scientist.domains.cognitive_core.evidence_algebra_v39 import (
    CandidateTrace,
    EvidenceCase,
    _canonical,
    evidence_cases,
)
from scientist.domains.cognitive_core.internal_core_v28 import _batch_responses, _chat_prompt
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
    LOCALIZATION_TRAIN_REPRESENTATIONS,
    REPRESENTATIONS,
    RepairTask,
    _build_task,
    execute,
)


EXPERIMENT_INVENTION_VERSION = "general-cognitive-experiment-invention-v41"
M41_SPLIT_SEEDS = {"train": 41037, "valid": 41061, "test": 41109}
SEARCH_BUDGET = 8


@dataclass(frozen=True)
class ExperimentTask:
    task_id: str
    source: RepairTask
    scenario: AmbiguityScenario
    observed_inputs: Tuple[Any, ...]
    frontier: Tuple[Intervention, ...]

    @property
    def representation(self) -> str:
        return self.source.representation


def build_m41_source_suite(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[RepairTask, ...]:
    if split not in M41_SPLIT_SEEDS:
        raise ValueError("unknown M41 split")
    rng = random.Random(M41_SPLIT_SEEDS[split])
    return tuple(
        _build_task(f"m41_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )


def build_m41_tasks(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[ExperimentTask, ...]:
    tasks = []
    for source in build_m41_source_suite(split, per_representation, representations):
        scenario = _short_horizon_scenario(source)
        if scenario is None:
            continue
        raw_cases = evidence_cases(source, "active")[: len(scenario.cases)]
        policy = robust_evidence_policy(scenario.cases, scenario.candidates)
        frontier_ids = set(policy["robust_frontier_ids"])
        interventions = {
            intervention.key: intervention for intervention in enumerate_interventions(source)
        }
        frontier = tuple(
            interventions[candidate.candidate_id]
            for candidate in sorted(scenario.candidates, key=lambda item: item.ordinal)
            if candidate.candidate_id in frontier_ids
        )
        correct = f"{source.target_node}={json.dumps(source.correct_edit_value, sort_keys=True)}"
        if correct not in {item.key for item in frontier} or len(frontier) < 2:
            continue
        task_id = "m41-exp-" + content_digest(
            {
                "source": source.task_id,
                "scenario": scenario.scenario_id,
                "version": EXPERIMENT_INVENTION_VERSION,
            }
        )[:20]
        tasks.append(
            ExperimentTask(
                task_id,
                source,
                scenario,
                tuple(case["input"] for case in raw_cases),
                frontier,
            )
        )
    return tuple(tasks)


def input_universe(representation: str) -> Tuple[Any, ...]:
    if representation in ("predicate", "program"):
        return tuple(list(value) for value in itertools.product(range(10), repeat=3))
    if representation == "temporal":
        return tuple(list(value) for value in itertools.product(range(5), repeat=5))
    if representation == "causal":
        return tuple([index, value] for index in range(3) for value in range(1, 5))
    if representation == "planning":
        return tuple([stage, blocked] for stage in range(6) for blocked in (False, True))
    raise ValueError("unknown representation")


def input_schema(representation: str) -> str:
    if representation in ("predicate", "program"):
        return "JSON list of exactly three integers; each integer is between 0 and 9 inclusive"
    if representation == "temporal":
        return "JSON list of exactly five integers; each integer is between 0 and 4 inclusive"
    if representation == "causal":
        return "JSON list [intervention_index, value], index 0..2 and value 1..4"
    if representation == "planning":
        return "JSON list [stage, blocked], stage 0..5 and blocked is true or false"
    raise ValueError("unknown representation")


def valid_input(representation: str, value: Any) -> bool:
    if not isinstance(value, list):
        return False
    if representation in ("predicate", "program"):
        return len(value) == 3 and all(type(item) is int and 0 <= item <= 9 for item in value)
    if representation == "temporal":
        return len(value) == 5 and all(type(item) is int and 0 <= item <= 4 for item in value)
    if representation == "causal":
        return (
            len(value) == 2
            and type(value[0]) is int
            and 0 <= value[0] <= 2
            and type(value[1]) is int
            and 1 <= value[1] <= 4
        )
    if representation == "planning":
        return (
            len(value) == 2
            and type(value[0]) is int
            and 0 <= value[0] <= 5
            and type(value[1]) is bool
        )
    return False


def _candidate_predictions(task: ExperimentTask, value: Any) -> Tuple[str, ...]:
    predictions = []
    for intervention in task.frontier:
        try:
            output = execute(task.representation, intervention.program, value)
        except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
            output = {"execution_error": True}
        predictions.append(_canonical(output))
    return tuple(predictions)


def partition_metrics(task: ExperimentTask, value: Any) -> Mapping[str, float]:
    predictions = _candidate_predictions(task, value)
    counts: Dict[str, int] = {}
    for prediction in predictions:
        counts[prediction] = counts.get(prediction, 0) + 1
    total = len(predictions)
    entropy = -sum(
        (count / total) * math.log2(count / total) for count in counts.values()
    )
    maximum = math.log2(total) if total > 1 else 1.0
    return {
        "partition_count": float(len(counts)),
        "partition_entropy": entropy,
        "normalized_information_gain": entropy / maximum if maximum else 0.0,
        "largest_partition_fraction": max(counts.values()) / total,
    }


def _available_inputs(task: ExperimentTask) -> Tuple[Any, ...]:
    observed = {_canonical(value) for value in task.observed_inputs}
    return tuple(
        value for value in input_universe(task.representation) if _canonical(value) not in observed
    )


def _experiment_key(task: ExperimentTask, value: Any) -> Tuple[float, float, str]:
    metrics = partition_metrics(task, value)
    return (
        metrics["partition_entropy"],
        -metrics["largest_partition_fraction"],
        _canonical(value),
    )


def oracle_experiment(task: ExperimentTask) -> Any:
    return max(_available_inputs(task), key=lambda value: _experiment_key(task, value))


def random_experiment(task: ExperimentTask) -> Any:
    values = list(_available_inputs(task))
    seed = int(hashlib.sha256(("random-m41-" + task.task_id).encode("utf-8")).hexdigest()[:16], 16)
    return random.Random(seed).choice(values)


def search_experiment(task: ExperimentTask, budget: int = SEARCH_BUDGET) -> Any:
    values = list(_available_inputs(task))
    seed = int(hashlib.sha256(("search-m41-" + task.task_id).encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(values)
    return max(values[:budget], key=lambda value: _experiment_key(task, value))


def _program_text(program: Mapping[str, Any]) -> str:
    return "; ".join(
        f"{node}={json.dumps(value, sort_keys=True)}"
        for node, value in sorted(program.items())
    )


def experiment_prompt(task: ExperimentTask, *, dossier: bool = True) -> str:
    observed = {_canonical(value) for value in task.observed_inputs}
    lines = [
        f"Representation: {task.representation}",
        f"Valid experiment input: {input_schema(task.representation)}.",
        "Invent one new input whose execution should distinguish the remaining candidate mechanisms.",
        "The input must not repeat an observed input. Do not explain your answer.",
        "Observed inputs: " + json.dumps(sorted(observed)),
    ]
    if dossier:
        lines.append("Unresolved executable candidate mechanisms:")
        for index, intervention in enumerate(task.frontier, 1):
            lines.append(f"  c{index}: {_program_text(intervention.program)}")
        lines.append(
            "Choose values that activate a behavioral difference between these mechanisms; do not name a candidate."
        )
    lines.append("Return exactly: EXPERIMENT: <JSON list>")
    return "\n".join(lines)


_EXPERIMENT_RE = re.compile(r"EXPERIMENT\s*:\s*([^\n\r]+)", re.IGNORECASE)


def parse_experiment(response: str) -> Any | None:
    matches = _EXPERIMENT_RE.findall(response)
    if not matches:
        return None
    raw = matches[-1].strip().rstrip(".;")
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


def _augmented_policy(task: ExperimentTask, value: Any) -> Mapping[str, Any]:
    authority_output = execute(task.representation, task.source.authority, value)
    new_case = EvidenceCase(f"invented_{len(task.scenario.cases) + 1}", authority_output)
    candidates = tuple(
        CandidateTrace(
            intervention.key,
            intervention.node,
            index,
            tuple(task.scenario.candidates[
                next(
                    position
                    for position, candidate in enumerate(task.scenario.candidates)
                    if candidate.candidate_id == intervention.key
                )
            ].predictions)
            + (execute(task.representation, intervention.program, value),),
        )
        for index, intervention in enumerate(task.frontier)
    )
    return robust_evidence_policy(task.scenario.cases + (new_case,), candidates)


def score_experiment(task: ExperimentTask, value: Any | None) -> Mapping[str, Any]:
    parsed = value is not None
    valid = bool(parsed and valid_input(task.representation, value))
    novel = bool(valid and _canonical(value) not in {_canonical(item) for item in task.observed_inputs})
    if not novel:
        return {
            "parsed": parsed,
            "valid": valid,
            "novel": novel,
            "partition_count": 1.0,
            "partition_entropy": 0.0,
            "normalized_information_gain": 0.0,
            "positive_information_gain": False,
            "frontier_reduction": 0.0,
            "normalized_frontier_reduction": 0.0,
            "resolved_after_query": False,
        }
    partition = partition_metrics(task, value)
    policy = _augmented_policy(task, value)
    reduction = len(task.frontier) - len(policy["robust_frontier_ids"])
    return {
        "parsed": parsed,
        "valid": valid,
        "novel": novel,
        **partition,
        "positive_information_gain": partition["partition_count"] > 1,
        "frontier_reduction": float(reduction),
        "normalized_frontier_reduction": reduction / (len(task.frontier) - 1),
        "resolved_after_query": policy["status"] == "resolved",
    }


def aggregate_experiments(
    condition: str,
    tasks: Sequence[ExperimentTask],
    values: Sequence[Any | None],
    responses: Sequence[str] | None = None,
) -> Mapping[str, Any]:
    if len(tasks) != len(values):
        raise ValueError("tasks and values do not align")
    if responses is None:
        responses = [""] * len(tasks)
    records = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    for task, value, response in zip(tasks, values, responses):
        score = score_experiment(task, value)
        record = {
            "task_id": task.task_id,
            "representation": task.representation,
            "experiment": value,
            "response": response,
            "frontier_size": len(task.frontier),
            "assessment": score,
        }
        records.append(record)
        by_representation.setdefault(task.representation, []).append(score)

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        def mean(key: str) -> float:
            return sum(float(item[key]) for item in items) / len(items)

        return {
            "parse_coverage": mean("parsed"),
            "valid_experiment_rate": mean("valid"),
            "novel_experiment_rate": mean("novel"),
            "positive_information_gain_rate": mean("positive_information_gain"),
            "mean_normalized_information_gain": mean("normalized_information_gain"),
            "mean_frontier_reduction": mean("frontier_reduction"),
            "mean_normalized_frontier_reduction": mean("normalized_frontier_reduction"),
            "resolution_rate": mean("resolved_after_query"),
        }

    all_scores = [record["assessment"] for record in records]
    heldout = [
        record["assessment"]
        for record in records
        if record["representation"] in HELDOUT_LOCALIZATION_REPRESENTATIONS
    ]
    return {
        "metrics": {
            "condition": condition,
            "task_count": len(tasks),
            **summarize(all_scores),
            "heldout_mean_normalized_information_gain": summarize(heldout)[
                "mean_normalized_information_gain"
            ],
            "heldout_resolution_rate": summarize(heldout)["resolution_rate"],
            "by_representation": {
                representation: summarize(items)
                for representation, items in sorted(by_representation.items())
            },
        },
        "records": records,
    }


def experiment_training_record(task: ExperimentTask) -> Mapping[str, Any]:
    value = oracle_experiment(task)
    return {
        "messages": [
            {"role": "user", "content": experiment_prompt(task, dossier=True)},
            {"role": "assistant", "content": "EXPERIMENT: " + json.dumps(value)},
        ],
        "metadata": {
            "task_id": task.task_id,
            "representation": task.representation,
            "mode": "open_world_experiment_invention",
        },
    }


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def prepare_m41_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    data = output / "invention"
    data.mkdir(parents=True, exist_ok=True)
    train = build_m41_tasks("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)
    valid = build_m41_tasks("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)
    test = build_m41_tasks("test", 30)
    train_hash, train_count = _write_jsonl(
        data / "train.jsonl", (experiment_training_record(task) for task in train)
    )
    valid_hash, valid_count = _write_jsonl(
        data / "valid.jsonl", (experiment_training_record(task) for task in valid)
    )
    public_hash, _ = _write_jsonl(
        output / "test-public.jsonl",
        (
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "dossier_prompt_hash": hashlib.sha256(
                    experiment_prompt(task, dossier=True).encode("utf-8")
                ).hexdigest(),
                "blind_prompt_hash": hashlib.sha256(
                    experiment_prompt(task, dossier=False).encode("utf-8")
                ).hexdigest(),
                "frontier_size": len(task.frontier),
            }
            for task in test
        ),
    )
    authority_hash, _ = _write_jsonl(
        output / "test-authority.jsonl",
        (
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "oracle_experiment": oracle_experiment(task),
                "authority_program": dict(task.source.authority),
            }
            for task in test
        ),
    )
    payload = {
        "version": EXPERIMENT_INVENTION_VERSION,
        "split_seeds": M41_SPLIT_SEEDS,
        "representations": list(REPRESENTATIONS),
        "training_representations": list(LOCALIZATION_TRAIN_REPRESENTATIONS),
        "heldout_representations": list(HELDOUT_LOCALIZATION_REPRESENTATIONS),
        "search_budget": SEARCH_BUDGET,
        "counts": {
            "train_tasks": len(train),
            "valid_tasks": len(valid),
            "test_tasks": len(test),
            "train_records": train_count,
            "valid_records": valid_count,
        },
        "hashes": {
            "invention_train": train_hash,
            "invention_valid": valid_hash,
            "test_public": public_hash,
            "test_authority": authority_hash,
        },
        "training_recipe": {
            "objective": "oracle_information_gain_experiment_generation",
            "lora_layers": 8,
            "iterations": 200,
            "learning_rate": 2e-5,
            "gradient_accumulation_steps": 4,
            "checkpoint_interval": 50,
            "max_sequence_length": 1024,
            "seed": 41,
        },
        "feasibility_gates": {
            "minimum_oracle_positive_information_gain_rate": 0.98,
            "minimum_oracle_normalized_information_gain": 0.75,
            "minimum_oracle_frontier_reduction": 1.0,
        },
        "model_gates": {
            "minimum_valid_experiment_rate": 0.90,
            "minimum_novel_experiment_rate": 0.90,
            "minimum_positive_information_gain_rate": 0.80,
            "minimum_normalized_information_gain": 0.65,
            "minimum_frontier_reduction": 1.0,
            "minimum_resolution_rate": 0.25,
            "minimum_heldout_normalized_information_gain": 0.55,
            "minimum_information_gain_over_base_dossier": 0.10,
            "minimum_information_gain_over_adapted_blind": 0.10,
            "minimum_information_gain_over_random": 0.10,
            "minimum_information_gain_ratio_to_search8": 0.90,
            "minimum_information_gain_ratio_to_oracle": 0.75,
            "minimum_resolution_ratio_to_oracle": 0.80,
        },
        "claim_boundary": (
            "M41 tests one-shot executable input invention for fresh synthetic ambiguity frontiers. The "
            "model receives candidate programs and an input schema but no prepared diagnostic pool. Full "
            "enumeration remains feasible in these toy domains and is reported as an oracle; M41 does not "
            "establish experiment invention in natural or unbounded domains."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m41_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "invention_train": output / "invention/train.jsonl",
        "invention_valid": output / "invention/valid.jsonl",
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    train_text = paths["invention_train"].read_text(encoding="utf-8")
    train_ids = {task.task_id for task in build_m41_tasks("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    valid_ids = {task.task_id for task in build_m41_tasks("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    test_ids = {task.task_id for task in build_m41_tasks("test", 30)}
    payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": content_digest(payload) == freeze["freeze_id"],
        "heldout_representations_absent_from_training": (
            '"representation": "program"' not in train_text
            and '"representation": "planning"' not in train_text
        ),
        "splits_are_disjoint": not (train_ids & valid_ids or train_ids & test_ids or valid_ids & test_ids),
        "test_not_available_to_mlx": not (output / "invention/test.jsonl").exists(),
        "gates_and_recipe_frozen": (
            "feasibility_gates" in freeze
            and "model_gates" in freeze
            and "training_recipe" in freeze
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}


def run_m41_baselines(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m41_tasks("test", 30)
    values = {
        "random": tuple(random_experiment(task) for task in tasks),
        "search8": tuple(search_experiment(task) for task in tasks),
        "oracle": tuple(oracle_experiment(task) for task in tasks),
    }
    results = {
        condition: aggregate_experiments(condition, tasks, experiments)
        for condition, experiments in values.items()
    }
    oracle = results["oracle"]["metrics"]
    gates = freeze["feasibility_gates"]
    checks = {
        "oracle_positive_information_gain": oracle["positive_information_gain_rate"]
        >= gates["minimum_oracle_positive_information_gain_rate"],
        "oracle_normalized_information_gain": oracle["mean_normalized_information_gain"]
        >= gates["minimum_oracle_normalized_information_gain"],
        "oracle_frontier_reduction": oracle["mean_frontier_reduction"]
        >= gates["minimum_oracle_frontier_reduction"],
    }
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "experiment_invention_baselines",
        {condition: result["records"] for condition, result in results.items()},
    )
    payload = {
        "version": EXPERIMENT_INVENTION_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "metrics": {condition: result["metrics"] for condition, result in results.items()},
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
        "predictions_digest": predictions_digest,
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"experiment-invention-baselines-{manifest['evaluation_id']}", manifest)
    return manifest


def evaluate_experiment_model(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    condition: str,
    *,
    dossier: bool,
    adapter_path: Optional[Path] = None,
    batch_size: int = 8,
    max_tokens: int = 40,
) -> Mapping[str, Any]:
    from mlx_lm import load

    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m41_tasks("test", 30)
    started = time.monotonic()
    load_args: Dict[str, Any] = {"return_config": True}
    if adapter_path is not None:
        load_args["adapter_path"] = str(adapter_path)
    model, tokenizer, config = load(model_path, **load_args)
    prompts = tuple(
        _chat_prompt(tokenizer, experiment_prompt(task, dossier=dossier)) for task in tasks
    )
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        prompts,
        batch_size=batch_size,
        max_tokens=max_tokens,
        max_batch_tokens=12000,
    )
    values = tuple(parse_experiment(response) for response in responses)
    aggregate = aggregate_experiments(condition, tasks, values, responses)
    store = ArtifactStore(output_root)
    predictions_digest = store.put("experiment_invention_model_predictions", aggregate["records"])
    payload = {
        "version": EXPERIMENT_INVENTION_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "condition": condition,
        "dossier": dossier,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path) if adapter_path else None,
        "adapter_config_sha256": hashlib.sha256(
            (adapter_path / "adapter_config.json").read_bytes()
        ).hexdigest()
        if adapter_path
        else None,
        "adapter_weights_sha256": hashlib.sha256(
            (adapter_path / "adapters.safetensors").read_bytes()
        ).hexdigest()
        if adapter_path
        else None,
        "metrics": aggregate["metrics"],
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "generation": {"batch_size": batch_size, "max_tokens": max_tokens},
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"experiment-invention-model-{condition}-{manifest['evaluation_id']}", manifest)
    return manifest


def assess_m41(
    candidate: Mapping[str, Any],
    base_dossier: Mapping[str, Any],
    adapted_blind: Mapping[str, Any],
    baselines: Mapping[str, Any],
    benchmark_root: Path,
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["model_gates"]
    metrics = candidate["metrics"]
    base = base_dossier["metrics"]
    blind = adapted_blind["metrics"]
    random_metrics = baselines["metrics"]["random"]
    search = baselines["metrics"]["search8"]
    oracle = baselines["metrics"]["oracle"]
    info = metrics["mean_normalized_information_gain"]
    checks = {
        "feasibility_passed": baselines["passed"],
        "same_benchmark_freeze": (
            candidate["benchmark_freeze_id"]
            == base_dossier["benchmark_freeze_id"]
            == adapted_blind["benchmark_freeze_id"]
            == baselines["benchmark_freeze_id"]
            == freeze["freeze_id"]
        ),
        "same_exact_model": (
            candidate["model_path"] == base_dossier["model_path"] == adapted_blind["model_path"]
        ),
        "adapter_present": candidate["adapter_path"] is not None,
        "valid_experiment_rate": metrics["valid_experiment_rate"]
        >= gates["minimum_valid_experiment_rate"],
        "novel_experiment_rate": metrics["novel_experiment_rate"]
        >= gates["minimum_novel_experiment_rate"],
        "positive_information_gain_rate": metrics["positive_information_gain_rate"]
        >= gates["minimum_positive_information_gain_rate"],
        "normalized_information_gain": info >= gates["minimum_normalized_information_gain"],
        "frontier_reduction": metrics["mean_frontier_reduction"]
        >= gates["minimum_frontier_reduction"],
        "resolution_rate": metrics["resolution_rate"] >= gates["minimum_resolution_rate"],
        "heldout_information_gain": metrics["heldout_mean_normalized_information_gain"]
        >= gates["minimum_heldout_normalized_information_gain"],
        "gain_over_base_dossier": info - base["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_base_dossier"],
        "gain_over_adapted_blind": info - blind["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_adapted_blind"],
        "information_gain_over_random": info - random_metrics["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_random"],
        "ratio_to_search8": info / search["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_ratio_to_search8"],
        "ratio_to_oracle": info / oracle["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_ratio_to_oracle"],
        "resolution_ratio_to_oracle": metrics["resolution_rate"] / oracle["resolution_rate"]
        >= gates["minimum_resolution_ratio_to_oracle"],
    }
    payload = {
        "version": EXPERIMENT_INVENTION_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "candidate_evaluation_id": candidate["evaluation_id"],
        "base_dossier_evaluation_id": base_dossier["evaluation_id"],
        "adapted_blind_evaluation_id": adapted_blind["evaluation_id"],
        "baseline_evaluation_id": baselines["evaluation_id"],
        "metrics": metrics,
        "controls": {
            "base_dossier": base,
            "adapted_blind": blind,
            "random": random_metrics,
            "search8": search,
            "oracle": oracle,
        },
        "deltas": {
            "information_gain_over_base_dossier": info
            - base["mean_normalized_information_gain"],
            "information_gain_over_adapted_blind": info
            - blind["mean_normalized_information_gain"],
            "information_gain_over_random": info
            - random_metrics["mean_normalized_information_gain"],
            "information_gain_ratio_to_search8": info
            / search["mean_normalized_information_gain"],
            "information_gain_ratio_to_oracle": info
            / oracle["mean_normalized_information_gain"],
            "resolution_ratio_to_oracle": metrics["resolution_rate"]
            / oracle["resolution_rate"],
        },
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
    }
    return {**payload, "assessment_id": content_digest(payload)}
