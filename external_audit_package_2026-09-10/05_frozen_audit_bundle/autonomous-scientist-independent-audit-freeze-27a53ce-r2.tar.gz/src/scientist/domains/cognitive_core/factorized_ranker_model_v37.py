from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import enumerate_interventions
from scientist.domains.cognitive_core.factorized_ranking_v37 import (
    FACTORIZED_RANKING_VERSION,
    NEGATIVE_TOKEN,
    POSITIVE_TOKEN,
    build_m37_suite,
    factorized_ranking,
    node_scoring_prompt,
    value_scoring_prompt,
)
from scientist.domains.cognitive_core.internal_core_v28 import _chat_prompt
from scientist.domains.cognitive_core.proposal_verification_v36 import (
    PROPOSAL_BUDGET,
    aggregate_proposal_sets,
)


FACTORIZED_RANKER_MODEL_VERSION = "general-cognitive-factorized-ranker-model-v37"


def _single_token_id(tokenizer, text: str) -> int:
    tokens = tokenizer.encode(text, add_special_tokens=False)
    if len(tokens) != 1:
        raise ValueError(f"expected {text!r} to be one token, received {tokens!r}")
    return int(tokens[0])


def _binary_margins(
    model,
    tokenizer,
    prompts: Sequence[str],
    *,
    batch_size: int,
    max_batch_tokens: int,
    max_prompt_tokens: int,
) -> Tuple[Tuple[float, ...], float]:
    import mlx.core as mx
    from mlx_lm.generate import BatchGenerator

    positive_token = _single_token_id(tokenizer, POSITIVE_TOKEN)
    negative_token = _single_token_id(tokenizer, NEGATIVE_TOKEN)
    encoded = [
        (index, tokenizer.encode(prompt)[-max_prompt_tokens:])
        for index, prompt in enumerate(prompts)
    ]
    encoded.sort(key=lambda item: len(item[1]))
    results: list[Optional[float]] = [None] * len(prompts)
    peak_memory = 0.0
    completed = 0
    cursor = 0
    while cursor < len(encoded):
        end = min(cursor + batch_size, len(encoded))
        while end > cursor + 1:
            padded_tokens = (end - cursor) * len(encoded[end - 1][1])
            if padded_tokens <= max_batch_tokens:
                break
            end -= 1
        batch_records = encoded[cursor:end]
        generator = BatchGenerator(
            model,
            stop_tokens=[[token] for token in tokenizer.eos_token_ids],
            prefill_batch_size=len(batch_records),
            completion_batch_size=len(batch_records),
        )
        batch_peak = 0.0
        try:
            uids = generator.insert([tokens for _, tokens in batch_records], [1] * len(batch_records))
            index_by_uid = {uid: index for uid, (index, _) in zip(uids, batch_records)}
            with generator.stats() as stats:
                while responses := generator.next_generated():
                    for response in responses:
                        logprobs = response.logprobs
                        mx.eval(logprobs)
                        results[index_by_uid[response.uid]] = float(
                            (logprobs[positive_token] - logprobs[negative_token]).item()
                        )
                batch_peak = float(stats.peak_memory)
        finally:
            generator.close()
        peak_memory = max(peak_memory, batch_peak)
        completed += len(batch_records)
        if completed % 128 == 0 or end == len(encoded):
            print(
                json.dumps(
                    {
                        "stage": "v37_factorized_margin_scoring",
                        "completed": completed,
                        "total": len(prompts),
                        "peak_memory_gb": round(peak_memory, 3),
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
        cursor = end
    if any(value is None for value in results):
        raise RuntimeError("missing binary margin")
    return tuple(float(value) for value in results if value is not None), peak_memory


def evaluate_factorized_ranker(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    condition: str,
    *,
    adapter_path: Optional[Path] = None,
    batch_size: int = 16,
    max_batch_tokens: int = 14000,
    max_prompt_tokens: int = 1024,
    suite_split: str = "test",
    per_representation: int = 30,
) -> Mapping[str, Any]:
    from mlx_lm import load

    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m37_suite(suite_split, per_representation)
    started = time.monotonic()
    load_arguments: Dict[str, Any] = {"return_config": True}
    if adapter_path is not None:
        load_arguments["adapter_path"] = str(adapter_path)
    model, tokenizer, config = load(model_path, **load_arguments)

    prompts = []
    prompt_keys = []
    for task in tasks:
        for node in sorted(task.candidate):
            prompts.append(_chat_prompt(tokenizer, node_scoring_prompt(task, node)))
            prompt_keys.append((task.task_id, "node", node))
        for intervention in enumerate_interventions(task):
            prompts.append(_chat_prompt(tokenizer, value_scoring_prompt(task, intervention)))
            prompt_keys.append((task.task_id, "value", intervention.key))
    margins, peak_memory = _binary_margins(
        model,
        tokenizer,
        prompts,
        batch_size=batch_size,
        max_batch_tokens=max_batch_tokens,
        max_prompt_tokens=max_prompt_tokens,
    )
    node_by_task: Dict[str, Dict[str, float]] = {task.task_id: {} for task in tasks}
    value_by_task: Dict[str, Dict[str, float]] = {task.task_id: {} for task in tasks}
    for (task_id, stage, key), margin in zip(prompt_keys, margins):
        destination = node_by_task if stage == "node" else value_by_task
        destination[task_id][key] = margin

    proposal_sets = []
    ranking_records = []
    exact_ranks = []
    node_top1 = []
    value_top1 = []
    ranking_by_representation: Dict[str, list[Mapping[str, float]]] = {}
    for task in tasks:
        ranked, score_rows = factorized_ranking(
            task, node_by_task[task.task_id], value_by_task[task.task_id]
        )
        proposal_sets.append(ranked[:PROPOSAL_BUDGET])
        correct_key = (
            f"{task.target_node}={json.dumps(task.correct_edit_value, sort_keys=True)}"
        )
        exact_rank = next(index for index, item in enumerate(ranked, 1) if item.key == correct_key)
        predicted_node = max(
            node_by_task[task.task_id],
            key=lambda node: (node_by_task[task.task_id][node], node),
        )
        target_node_interventions = [
            item for item in enumerate_interventions(task) if item.node == task.target_node
        ]
        predicted_value_key = max(
            (item.key for item in target_node_interventions),
            key=lambda key: (value_by_task[task.task_id][key], key),
        )
        item_metrics = {
            "exact_rank": float(exact_rank),
            "exact_top1": float(exact_rank == 1),
            "target_node_top1": float(predicted_node == task.target_node),
            "target_value_top1_given_node": float(predicted_value_key == correct_key),
        }
        exact_ranks.append(float(exact_rank))
        node_top1.append(item_metrics["target_node_top1"])
        value_top1.append(item_metrics["target_value_top1_given_node"])
        ranking_by_representation.setdefault(task.representation, []).append(item_metrics)
        ranking_records.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "correct_key": correct_key,
                "node_margins": node_by_task[task.task_id],
                "ranked_edits": list(score_rows),
                "ranking_metrics": item_metrics,
            }
        )

    aggregate = aggregate_proposal_sets(condition, tasks, proposal_sets)

    def mean(items: Sequence[Mapping[str, float]], key: str) -> float:
        return sum(item[key] for item in items) / len(items)

    rank_metrics = {
        "scoring_completeness": float(
            len(margins)
            == sum(len(task.candidate) + len(enumerate_interventions(task)) for task in tasks)
        ),
        "mean_exact_rank": sum(exact_ranks) / len(exact_ranks),
        "exact_top1_accuracy": sum(float(rank == 1) for rank in exact_ranks) / len(exact_ranks),
        "target_node_top1_accuracy": sum(node_top1) / len(node_top1),
        "target_value_top1_given_node_accuracy": sum(value_top1) / len(value_top1),
        "ranking_by_representation": {
            representation: {
                "mean_exact_rank": mean(items, "exact_rank"),
                "exact_top1_accuracy": mean(items, "exact_top1"),
                "target_node_top1_accuracy": mean(items, "target_node_top1"),
                "target_value_top1_given_node_accuracy": mean(
                    items, "target_value_top1_given_node"
                ),
            }
            for representation, items in sorted(ranking_by_representation.items())
        },
    }
    metrics = {**aggregate["metrics"], **rank_metrics}
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "factorized_ranker_predictions",
        {"rankings": ranking_records, "controller_records": aggregate["records"]},
    )
    payload = {
        "version": FACTORIZED_RANKER_MODEL_VERSION,
        "benchmark_version": FACTORIZED_RANKING_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "condition": condition,
        "evaluation_suite": {
            "split": suite_split,
            "per_representation": per_representation,
            "post_sealed_diagnostic": suite_split != "test",
        },
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path) if adapter_path else None,
        "adapter_config_sha256": (
            hashlib.sha256((adapter_path / "adapter_config.json").read_bytes()).hexdigest()
            if adapter_path
            else None
        ),
        "adapter_weights_sha256": (
            hashlib.sha256((adapter_path / "adapters.safetensors").read_bytes()).hexdigest()
            if adapter_path
            else None
        ),
        "metrics": metrics,
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "scoring": {
            "positive_token": POSITIVE_TOKEN,
            "negative_token": NEGATIVE_TOKEN,
            "batch_size": batch_size,
            "max_prompt_tokens": max_prompt_tokens,
            "factorization": "softmax(node_margin)*softmax(value_margin_within_node)",
        },
        "claim_boundary": (
            "The 1.5B model supplies binary node and value support margins. Legal edit enumeration, "
            "factorization, execution, verification, query selection, and conservative fallback are external."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest(f"factorized-ranker-{condition}-{evaluation_id}", manifest)
    return manifest


def assess_factorized_ranker(
    candidate: Mapping[str, Any],
    base: Mapping[str, Any],
    benchmark_root: Path,
    baselines: Mapping[str, Any],
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["ranker_gates"]
    metrics = candidate["metrics"]
    base_metrics = base["metrics"]
    random_metrics = baselines["random_k4_metrics"]
    gain_random = (
        metrics["exact_repair_coverage_at_k"] - random_metrics["exact_repair_coverage_at_k"]
    )
    gain_base = metrics["exact_repair_coverage_at_k"] - base_metrics["exact_repair_coverage_at_k"]
    checks = {
        "feasibility_prerequisite_passed": bool(baselines["passed"]),
        "same_benchmark_freeze": (
            candidate["benchmark_freeze_id"]
            == base["benchmark_freeze_id"]
            == baselines["benchmark_freeze_id"]
            == freeze["freeze_id"]
        ),
        "same_exact_model": candidate["model_path"] == base["model_path"],
        "adapter_present_only_for_candidate": (
            candidate.get("adapter_path") is not None and base.get("adapter_path") is None
        ),
        "scoring_completeness": (
            metrics["scoring_completeness"] >= gates["minimum_scoring_completeness"]
        ),
        "exact_repair_coverage_at_k": (
            metrics["exact_repair_coverage_at_k"] >= gates["minimum_exact_repair_coverage_at_k"]
        ),
        "exact_coverage_gain_over_random": (
            gain_random >= gates["minimum_exact_coverage_gain_over_random"]
        ),
        "exact_coverage_gain_over_base": (
            gain_base >= gates["minimum_exact_coverage_gain_over_base"]
        ),
        "selected_semantic_accuracy": (
            metrics["selected_semantic_accuracy"] >= gates["minimum_selected_semantic_accuracy"]
        ),
        "selected_preservation": (
            metrics["selected_preserved_correct_accuracy"] >= gates["minimum_selected_preservation"]
        ),
        "selected_exact_rate": (
            metrics["selected_exact_rate"] >= gates["minimum_selected_exact_rate"]
        ),
        "heldout_selected_semantic_accuracy": (
            metrics["heldout_selected_semantic_accuracy"]
            >= gates["minimum_heldout_selected_semantic_accuracy"]
        ),
        "target_node_top1_accuracy": (
            metrics["target_node_top1_accuracy"] >= gates["minimum_target_node_top1_accuracy"]
        ),
        "target_value_top1_given_node_accuracy": (
            metrics["target_value_top1_given_node_accuracy"]
            >= gates["minimum_target_value_top1_given_node_accuracy"]
        ),
    }
    payload = {
        "version": FACTORIZED_RANKER_MODEL_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "candidate_evaluation_id": candidate["evaluation_id"],
        "base_evaluation_id": base["evaluation_id"],
        "baseline_evaluation_id": baselines["evaluation_id"],
        "metrics": metrics,
        "base_metrics": base_metrics,
        "random_k4_metrics": random_metrics,
        "exact_coverage_gain_over_random": gain_random,
        "exact_coverage_gain_over_base": gain_base,
        "checks": checks,
        "gates": gates,
        "passed": all(checks.values()),
    }
    return {**payload, "assessment_id": content_digest(payload)}
