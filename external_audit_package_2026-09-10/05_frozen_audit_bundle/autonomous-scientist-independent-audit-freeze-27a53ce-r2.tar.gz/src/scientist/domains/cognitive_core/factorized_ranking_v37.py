from __future__ import annotations

import hashlib
import json
import math
import random
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    Intervention,
    enumerate_interventions,
    legal_values,
)
from scientist.domains.cognitive_core.proposal_verification_v36 import (
    PROPOSAL_BUDGET,
    aggregate_proposal_sets,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
    LOCALIZATION_TRAIN_REPRESENTATIONS,
    REPRESENTATIONS,
    RepairTask,
    _build_task,
)


FACTORIZED_RANKING_VERSION = "general-cognitive-factorized-ranking-v37"
M37_SPLIT_SEEDS = {"train": 37037, "valid": 37061, "test": 37109}
POSITIVE_TOKEN = "Y"
NEGATIVE_TOKEN = "N"


def build_m37_suite(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[RepairTask, ...]:
    if split not in M37_SPLIT_SEEDS:
        raise ValueError("unknown M37 split")
    rng = random.Random(M37_SPLIT_SEEDS[split])
    tasks = tuple(
        _build_task(f"m37_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("M37 task ids are not unique")
    return tasks


def _evidence(task: RepairTask) -> str:
    nodes = "\n".join(
        f"  {node}={json.dumps(value, sort_keys=True)}"
        for node, value in sorted(task.candidate.items())
    )
    correct = "\n".join(
        f"  input={json.dumps(case['input'])} -> required={json.dumps(case['expected'])}"
        for case in task.visible_correct
    )
    bad = task.counterexample
    return (
        f"Representation: {task.representation}\n"
        "A typed mechanism contains exactly one faulty node. Infer causal support from the observed behavior; "
        "do not reward a change merely because it looks unusual.\n"
        f"Candidate mechanism:\n{nodes}\n"
        f"Preserved cases:\n{correct}\n"
        f"Failure: input={json.dumps(bad['input'])}; candidate_output={json.dumps(bad['candidate'])}; "
        f"required={json.dumps(bad['expected'])}"
    )


def node_scoring_prompt(task: RepairTask, node: str) -> str:
    if node not in task.candidate:
        raise ValueError("unknown node")
    alternatives = list(legal_values(task, node))
    return (
        _evidence(task)
        + "\n\nNODE LOCALIZATION STAGE\n"
        + f"Node under evaluation: {node}\n"
        + f"Current value: {json.dumps(task.candidate[node], sort_keys=True)}\n"
        + f"Typed alternatives: {json.dumps(alternatives, sort_keys=True)}\n"
        + "Is this the faulty node? Answer exactly one token: Y or N."
    )


def value_scoring_prompt(task: RepairTask, intervention: Intervention) -> str:
    return (
        _evidence(task)
        + "\n\nCONDITIONAL VALUE STAGE\n"
        + f"Assume node under evaluation: {intervention.node}\n"
        + f"Proposed replacement: {json.dumps(intervention.value, sort_keys=True)}\n"
        + "Would this exact typed replacement restore the intended mechanism, rather than merely fit the "
        + "displayed examples? Answer exactly one token: Y or N."
    )


def _record(
    task: RepairTask,
    stage: str,
    prompt: str,
    positive: bool,
    *,
    node: str,
    value: Any = None,
    hard_negative: bool = False,
) -> Mapping[str, Any]:
    return {
        "messages": [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": POSITIVE_TOKEN if positive else NEGATIVE_TOKEN},
        ],
        "metadata": {
            "task_id": task.task_id,
            "representation": task.representation,
            "stage": stage,
            "node": node,
            "value": value,
            "positive": positive,
            "hard_negative": hard_negative,
        },
    }


def factorized_training_records(task: RepairTask) -> Tuple[Mapping[str, Any], ...]:
    """Balanced pointwise contrasts covering every legal wrong node and edit."""

    records = []
    nodes = sorted(task.candidate)
    node_negatives = [node for node in nodes if node != task.target_node]
    positive_node = _record(
        task,
        "node",
        node_scoring_prompt(task, task.target_node),
        True,
        node=task.target_node,
    )
    records.extend([positive_node] * len(node_negatives))
    records.extend(
        _record(
            task,
            "node",
            node_scoring_prompt(task, node),
            False,
            node=node,
        )
        for node in node_negatives
    )

    interventions = tuple(enumerate_interventions(task))
    correct_key = f"{task.target_node}={json.dumps(task.correct_edit_value, sort_keys=True)}"
    positive_edit = next(item for item in interventions if item.key == correct_key)
    wrong_edits = [item for item in interventions if item.key != correct_key]
    positive_value = _record(
        task,
        "value",
        value_scoring_prompt(task, positive_edit),
        True,
        node=positive_edit.node,
        value=positive_edit.value,
    )
    records.extend([positive_value] * len(wrong_edits))
    records.extend(
        _record(
            task,
            "value",
            value_scoring_prompt(task, item),
            False,
            node=item.node,
            value=item.value,
            hard_negative=bool(item.viable),
        )
        for item in wrong_edits
    )
    seed = int(hashlib.sha256(("records-" + task.task_id).encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(records)
    return tuple(records)


def _softmax(values: Mapping[str, float]) -> Mapping[str, float]:
    if not values:
        raise ValueError("cannot normalize empty score table")
    maximum = max(values.values())
    weights = {key: math.exp(float(value) - maximum) for key, value in values.items()}
    total = sum(weights.values())
    return {key: value / total for key, value in weights.items()}


def factorized_ranking(
    task: RepairTask,
    node_margins: Mapping[str, float],
    value_margins: Mapping[str, float],
) -> Tuple[Tuple[Intervention, ...], Tuple[Mapping[str, Any], ...]]:
    nodes = sorted(task.candidate)
    if set(node_margins) != set(nodes):
        raise ValueError("node margin table is incomplete")
    interventions = tuple(enumerate_interventions(task))
    if set(value_margins) != {item.key for item in interventions}:
        raise ValueError("value margin table is incomplete")
    node_probabilities = _softmax(node_margins)
    conditional_probabilities: Dict[str, Mapping[str, float]] = {}
    for node in nodes:
        conditional_probabilities[node] = _softmax(
            {item.key: value_margins[item.key] for item in interventions if item.node == node}
        )
    scored = []
    for item in interventions:
        node_probability = node_probabilities[item.node]
        value_probability = conditional_probabilities[item.node][item.key]
        scored.append(
            (
                math.log(node_probability) + math.log(value_probability),
                item.key,
                item,
                {
                    "key": item.key,
                    "node": item.node,
                    "value": item.value,
                    "node_margin": float(node_margins[item.node]),
                    "value_margin": float(value_margins[item.key]),
                    "node_probability": node_probability,
                    "conditional_value_probability": value_probability,
                    "joint_probability": node_probability * value_probability,
                },
            )
        )
    scored.sort(key=lambda row: (-row[0], row[1]))
    return (
        tuple(row[2] for row in scored),
        tuple({**row[3], "rank": index} for index, row in enumerate(scored, 1)),
    )


def random_m37_proposals(task: RepairTask) -> Tuple[Intervention, ...]:
    interventions = list(enumerate_interventions(task))
    seed = int(hashlib.sha256(("random-v37-" + task.task_id).encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(interventions)
    return tuple(interventions[:PROPOSAL_BUDGET])


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def prepare_m37_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    factorized = output / "factorized"
    factorized.mkdir(parents=True, exist_ok=True)
    train = build_m37_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)
    valid = build_m37_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)
    test = build_m37_suite("test", 30)
    train_hash, train_records = _write_jsonl(
        factorized / "train.jsonl",
        (record for task in train for record in factorized_training_records(task)),
    )
    valid_hash, valid_records = _write_jsonl(
        factorized / "valid.jsonl",
        (record for task in valid for record in factorized_training_records(task)),
    )
    public_hash, _ = _write_jsonl(
        output / "test-public.jsonl",
        (
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "node_prompts": {
                    node: node_scoring_prompt(task, node) for node in sorted(task.candidate)
                },
                "value_prompts": {
                    item.key: value_scoring_prompt(task, item)
                    for item in enumerate_interventions(task)
                },
            }
            for task in test
        ),
    )
    authority_hash, _ = _write_jsonl(
        output / "test-authority.jsonl",
        (
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "target_node": task.target_node,
                "correct_edit_value": task.correct_edit_value,
            }
            for task in test
        ),
    )
    payload = {
        "version": FACTORIZED_RANKING_VERSION,
        "split_seeds": M37_SPLIT_SEEDS,
        "representations": list(REPRESENTATIONS),
        "training_representations": list(LOCALIZATION_TRAIN_REPRESENTATIONS),
        "heldout_representations": list(HELDOUT_LOCALIZATION_REPRESENTATIONS),
        "proposal_budget": PROPOSAL_BUDGET,
        "counts": {
            "train_tasks": len(train),
            "valid_tasks": len(valid),
            "test_tasks": len(test),
            "train_contrast_records": train_records,
            "valid_contrast_records": valid_records,
        },
        "hashes": {
            "factorized_train": train_hash,
            "factorized_valid": valid_hash,
            "test_public": public_hash,
            "test_authority": authority_hash,
        },
        "training_recipe": {
            "objective": "balanced_pointwise_contrast_over_all_legal_nodes_and_values",
            "factorization": "P(node|evidence)*P(value|node,evidence)",
            "positive_token": POSITIVE_TOKEN,
            "negative_token": NEGATIVE_TOKEN,
            "lora_layers": 8,
            "iterations": 200,
            "learning_rate": 2e-5,
            "gradient_accumulation_steps": 4,
            "checkpoint_interval": 50,
            "seed": 37,
        },
        "feasibility_gates": {
            "minimum_full_enumeration_semantic_accuracy": 0.98,
            "minimum_full_enumeration_preservation": 1.0,
            "minimum_full_enumeration_exact_rate": 0.90,
        },
        "ranker_gates": {
            "minimum_scoring_completeness": 1.0,
            "minimum_exact_repair_coverage_at_k": 0.70,
            "minimum_exact_coverage_gain_over_random": 0.20,
            "minimum_exact_coverage_gain_over_base": 0.10,
            "minimum_selected_semantic_accuracy": 0.85,
            "minimum_selected_preservation": 1.0,
            "minimum_selected_exact_rate": 0.60,
            "minimum_heldout_selected_semantic_accuracy": 0.80,
            "minimum_target_node_top1_accuracy": 0.60,
            "minimum_target_value_top1_given_node_accuracy": 0.60,
        },
        "claim_boundary": (
            "M37 tests evidence-conditioned ranking over an externally enumerated finite typed repair space "
            "on fresh synthetic single-fault mechanisms. It does not test open-vocabulary concept invention."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m37_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "factorized_train": output / "factorized/train.jsonl",
        "factorized_valid": output / "factorized/valid.jsonl",
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    train_text = paths["factorized_train"].read_text(encoding="utf-8")
    train_ids = {task.task_id for task in build_m37_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    valid_ids = {task.task_id for task in build_m37_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    test_ids = {task.task_id for task in build_m37_suite("test", 30)}
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": (
            content_digest({key: value for key, value in freeze.items() if key != "freeze_id"})
            == freeze["freeze_id"]
        ),
        "heldout_representations_absent_from_training": (
            '\"representation\": \"program\"' not in train_text
            and '\"representation\": \"planning\"' not in train_text
        ),
        "splits_are_disjoint": not (train_ids & valid_ids or train_ids & test_ids or valid_ids & test_ids),
        "test_not_exposed_to_mlx": not (output / "factorized/test.jsonl").exists(),
        "gates_and_training_recipe_frozen": (
            "feasibility_gates" in freeze
            and "ranker_gates" in freeze
            and "training_recipe" in freeze
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}


def run_m37_baselines(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m37_suite("test", 30)
    full = aggregate_proposal_sets(
        "full_enumeration",
        tasks,
        [enumerate_interventions(task) for task in tasks],
        proposal_budget=None,
    )
    random_result = aggregate_proposal_sets(
        "random_k4", tasks, [random_m37_proposals(task) for task in tasks]
    )
    gates = freeze["feasibility_gates"]
    checks = {
        "semantic_accuracy": (
            full["metrics"]["selected_semantic_accuracy"]
            >= gates["minimum_full_enumeration_semantic_accuracy"]
        ),
        "preservation": (
            full["metrics"]["selected_preserved_correct_accuracy"]
            >= gates["minimum_full_enumeration_preservation"]
        ),
        "exact_rate": (
            full["metrics"]["selected_exact_rate"]
            >= gates["minimum_full_enumeration_exact_rate"]
        ),
    }
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "factorized_ranking_baselines",
        {"full_enumeration": full["records"], "random_k4": random_result["records"]},
    )
    payload = {
        "version": FACTORIZED_RANKING_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "full_enumeration_metrics": full["metrics"],
        "random_k4_metrics": random_result["metrics"],
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
        "predictions_digest": predictions_digest,
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"factorized-ranking-baselines-{manifest['evaluation_id']}", manifest)
    return manifest
