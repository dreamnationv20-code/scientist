from __future__ import annotations

import hashlib
import json
import random
import time
from dataclasses import replace
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.contrast_experiment_v42 import (
    ContrastPair,
    _best_contrast_pair,
    aggregate_contrasts,
    contrast_prompt,
    pair_members,
)
from scientist.domains.cognitive_core.experiment_invention_v41 import (
    ExperimentTask,
    parse_experiment,
)
from scientist.domains.cognitive_core.internal_core_v28 import (
    _batch_responses,
    _chat_prompt,
)
from scientist.domains.cognitive_core.model_controlled_tool_loop_v46 import (
    _interaction_metrics,
    _run_condition,
    interaction_prompt,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
    experiment_classes,
)


FEEDBACK_COUNTERFACTUAL_VERSION = "general-cognitive-feedback-counterfactual-v48"
M48_SPLIT_SEEDS = {
    "train": 48037,
    "valid": 48061,
    "calibration": 48079,
    "test": 48109,
}
M48_REPRESENTATIONS = ("predicate", "causal")
M48_PER_REPRESENTATION = {
    "train": 60,
    "valid": 12,
    "calibration": 6,
    "test": 30,
}
M48_MINIMUM_EXCLUSIVE_FRACTION = 0.10
M48_PARENT_ADAPTER_SHA256 = (
    "001db1f2a4e10a8a118f0b9ebe929ef9c6faa93959aa148997376e600e11ce79"
)
M48_MODEL_SNAPSHOT = "8b403126fc14f14cfc99bb4cfa72ecbc129ea677"


def _source_tasks(
    split: str, per_representation: int, representations: Sequence[str]
) -> Tuple[Any, ...]:
    if split not in M48_SPLIT_SEEDS:
        raise ValueError("unknown M48 split")
    rng = random.Random(M48_SPLIT_SEEDS[split])
    return tuple(
        _build_task(f"m48_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )


def _experiment_task(source: Any) -> ExperimentTask | None:
    task = _m43_experiment_task(source)
    if task is None:
        return None
    return replace(
        task,
        task_id="m48-exp-"
        + content_digest(
            {
                "source": source.task_id,
                "scenario": task.scenario.scenario_id,
                "version": FEEDBACK_COUNTERFACTUAL_VERSION,
            }
        )[:20],
    )


def build_m48_pairs(
    split: str,
    per_representation: int | None = None,
    representations: Sequence[str] = M48_REPRESENTATIONS,
) -> Tuple[ContrastPair, ...]:
    if split not in M48_PER_REPRESENTATION:
        raise ValueError("unknown M48 split")
    if per_representation is None:
        per_representation = M48_PER_REPRESENTATION[split]
    bases = tuple(
        task
        for source in _source_tasks(split, per_representation, representations)
        for task in (_experiment_task(source),)
        if task is not None
    )
    return tuple(
        pair
        for base in bases
        for pair in (
            _best_contrast_pair(
                base,
                version=FEEDBACK_COUNTERFACTUAL_VERSION,
                pair_prefix="m48-pair",
                minimum_exclusive_fraction=M48_MINIMUM_EXCLUSIVE_FRACTION,
            ),
        )
        if pair is not None
    )


def _ordered(values: Sequence[Any], salt: str) -> Tuple[Any, ...]:
    result = list(values)
    random.Random(
        int(hashlib.sha256(salt.encode("utf-8")).hexdigest()[:16], 16)
    ).shuffle(result)
    return tuple(result)


def _history_row(
    experiment: Any, outputs: Sequence[Any], slot: int, turn: int
) -> Mapping[str, Any]:
    return {
        "slot": slot,
        "turn": turn,
        "experiment": experiment,
        "outputs": list(outputs),
        "response": "EXPERIMENT: " + json.dumps(experiment),
    }


def _preference(
    pair: ContrastPair,
    own: ExperimentTask,
    sibling: ExperimentTask,
    *,
    pair_kind: str,
    variant: str,
    history: Sequence[Mapping[str, Any]],
    chosen: str,
    rejected: str,
    turn: int,
) -> Mapping[str, Any]:
    prompt = interaction_prompt(
        own,
        own,
        history,
        (),
        feedback=True,
        turn=turn,
    )
    return {
        "prompt": prompt,
        "chosen": chosen,
        "rejected": rejected,
        "metadata": {
            "pair_id": pair.pair_id,
            "task_id": own.task_id,
            "sibling_task_id": sibling.task_id,
            "representation": own.representation,
            "counterfactual_pair_id": content_digest(
                {"task": own.task_id, "kind": pair_kind}
            )[:20],
            "pair_kind": pair_kind,
            "variant": variant,
            "history": list(history),
            "turn": turn,
            "teacher_source": "counterfactual_executable_partition_training_only",
        },
    }


def counterfactual_preferences(
    pair: ContrastPair, own: ExperimentTask, sibling: ExperimentTask
) -> Tuple[Mapping[str, Any], ...]:
    classes = experiment_classes(own, sibling)
    targets = _ordered(
        classes["frontier_specific"], f"m48:{own.task_id}:target"
    )
    failures = _ordered(
        classes["sibling_specific"] + classes["uninformative"],
        f"m48:{own.task_id}:failure",
    )
    if not targets or not failures:
        raise ValueError("M48 task lacks target or uninformative support")
    target0 = targets[0]
    target1 = targets[1 % len(targets)]
    failure0 = failures[0]
    failure1 = failures[1 % len(failures)]
    equal0 = raw_candidate_outputs(own, failure0)
    equal1 = raw_candidate_outputs(own, failure1)
    unequal0 = raw_candidate_outputs(own, target0)
    unequal1 = raw_candidate_outputs(own, target1)
    if equal0[0] != equal0[1] or equal1[0] != equal1[1]:
        raise ValueError("M48 equal-output counterfactual is not equal")
    if unequal0[0] == unequal0[1] or unequal1[0] == unequal1[1]:
        raise ValueError("M48 unequal-output counterfactual is not unequal")
    propose0 = "EXPERIMENT: " + json.dumps(target0)
    propose1 = "EXPERIMENT: " + json.dumps(target1)
    single_equal = (_history_row(failure0, equal0, 1, 1),)
    single_unequal = (_history_row(failure0, unequal0, 1, 1),)
    two_equal = (
        _history_row(failure0, equal0, 1, 1),
        _history_row(failure1, equal1, 2, 2),
    )
    earlier_unequal = (
        _history_row(failure0, unequal1, 1, 1),
        _history_row(failure1, equal1, 2, 2),
    )
    return (
        _preference(
            pair,
            own,
            sibling,
            pair_kind="single_slot_output_agreement",
            variant="equal_requires_revision",
            history=single_equal,
            chosen=propose0,
            rejected="SELECT: 1",
            turn=2,
        ),
        _preference(
            pair,
            own,
            sibling,
            pair_kind="single_slot_output_agreement",
            variant="unequal_requires_selection",
            history=single_unequal,
            chosen="SELECT: 1",
            rejected=propose0,
            turn=2,
        ),
        _preference(
            pair,
            own,
            sibling,
            pair_kind="two_slot_output_location",
            variant="all_equal_requires_revision",
            history=two_equal,
            chosen=propose1,
            rejected="SELECT: 1",
            turn=3,
        ),
        _preference(
            pair,
            own,
            sibling,
            pair_kind="two_slot_output_location",
            variant="earlier_unequal_requires_earlier_selection",
            history=earlier_unequal,
            chosen="SELECT: 1",
            rejected="SELECT: 2",
            turn=3,
        ),
    )


def _all_preferences(pairs: Sequence[ContrastPair]) -> Iterable[Mapping[str, Any]]:
    for pair in pairs:
        yield from counterfactual_preferences(pair, pair.left, pair.right)
        yield from counterfactual_preferences(pair, pair.right, pair.left)


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def _row_summary(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    variants: Dict[str, int] = {}
    representations: Dict[str, int] = {}
    for row in rows:
        metadata = row["metadata"]
        variants[metadata["variant"]] = variants.get(metadata["variant"], 0) + 1
        representation = metadata["representation"]
        representations[representation] = representations.get(representation, 0) + 1
    return {
        "records": len(rows),
        "by_variant": dict(sorted(variants.items())),
        "by_representation": dict(sorted(representations.items())),
    }


def _gates() -> Mapping[str, float]:
    return {
        "minimum_action_parse_rate": 0.95,
        "minimum_valid_action_rate": 0.85,
        "minimum_selection_completion_rate": 0.90,
        "minimum_selected_evidence_rate": 0.80,
        "minimum_available_evidence_selection_rate": 0.90,
        "minimum_predicate_information": 0.70,
        "minimum_causal_information": 0.90,
        "minimum_overall_correct_assignment": 0.65,
        "minimum_information_gain_over_direct": 0.15,
        "minimum_assignment_gain_over_direct": 0.15,
        "minimum_information_gain_over_no_feedback": 0.15,
        "minimum_assignment_gain_over_no_feedback": 0.15,
        "minimum_advantage_gap_over_mismatched": 0.60,
    }


def prepare_m48_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    data = output / "preference"
    data.mkdir(parents=True, exist_ok=True)
    pairs = {split: build_m48_pairs(split) for split in M48_SPLIT_SEEDS}
    rows = {
        split: tuple(_all_preferences(pairs[split])) for split in ("train", "valid")
    }
    hashes: Dict[str, str] = {}
    counts: Dict[str, Any] = {}
    for split in ("train", "valid"):
        digest, count = _write_jsonl(data / f"{split}.jsonl", rows[split])
        hashes[f"preference_{split}"] = digest
        counts[f"{split}_preference_records"] = count
    for split in ("calibration", "test"):
        public_hash, _ = _write_jsonl(
            output / f"{split}-public.jsonl",
            (
                {
                    "pair_id": pair.pair_id,
                    "representation": pair.representation,
                    "left_task_id": pair.left.task_id,
                    "right_task_id": pair.right.task_id,
                }
                for pair in pairs[split]
            ),
        )
        authority_hash, _ = _write_jsonl(
            output / f"{split}-authority.jsonl",
            (
                {
                    "pair_id": pair.pair_id,
                    "authority_program": dict(pair.left.source.authority),
                    "left_frontier": [item.key for item in pair.left.frontier],
                    "right_frontier": [item.key for item in pair.right.frontier],
                }
                for pair in pairs[split]
            ),
        )
        hashes[f"{split}_public"] = public_hash
        hashes[f"{split}_authority"] = authority_hash
    counts.update(
        {
            split: {
                "pairs": len(split_pairs),
                "tasks": len(split_pairs) * 2,
                "by_representation": {
                    representation: sum(
                        int(pair.representation == representation)
                        for pair in split_pairs
                    )
                    for representation in M48_REPRESENTATIONS
                },
            }
            for split, split_pairs in pairs.items()
        }
    )
    gates = _gates()
    interaction_contract = {
        "proposal_turn_budget": 8,
        "action_max_tokens": 24,
        "forced_final_selection_max_tokens": 8,
        "maximum_total_output_tokens_per_task": 200,
        "batch_size": 8,
        "tool_returns": "raw_c1_and_c2_outputs_only",
        "tool_does_not_return": [
            "information_gain",
            "ranking",
            "recommended_action",
            "stop_decision",
        ],
        "selection_policy": "model_selects_a_previously_executed_slot",
        "external_fallback_selection": False,
        "no_test_time_parameter_updates": True,
    }
    payload = {
        "version": FEEDBACK_COUNTERFACTUAL_VERSION,
        "parent_version": "general-cognitive-sequential-policy-learning-v47",
        "split_seeds": M48_SPLIT_SEEDS,
        "representations": list(M48_REPRESENTATIONS),
        "per_representation_source_count": M48_PER_REPRESENTATION,
        "counts": counts,
        "preference_summary": {
            split: _row_summary(split_rows) for split, split_rows in rows.items()
        },
        "hashes": hashes,
        "frozen_model": {
            "snapshot": M48_MODEL_SNAPSHOT,
            "parent_adapter_sha256": M48_PARENT_ADAPTER_SHA256,
            "parent_adapter_source": "m47_validation_selected_checkpoint_160",
        },
        "counterfactual_contract": {
            "records_per_task": 4,
            "paired_prompt_fields_held_constant": [
                "task",
                "candidate_programs",
                "observed_inputs",
                "tested_experiment",
                "slot",
            ],
            "paired_prompt_field_varied": "raw_c1_c2_outputs",
            "equal_outputs_prefer": "EXPERIMENT",
            "unequal_outputs_prefer": "SELECT",
            "includes_nonlatest_informative_slot": True,
            "teacher_available_only_during_training": True,
            "metrics_or_ranks_in_prompt": False,
        },
        "training_recipe": {
            "objective": "simpo_counterfactual_feedback_dependence",
            "initialization": "m47_selected_checkpoint_160",
            "lora_layers": 8,
            "lora_rank": 8,
            "lora_scale": 20.0,
            "iterations": 180,
            "learning_rate": 1e-5,
            "gradient_accumulation_steps": 4,
            "preference_beta": 2.0,
            "chosen_sft_weight": 0.25,
            "checkpoint_interval": 60,
            "max_sequence_length": 1024,
            "seed": 48,
            "checkpoint_selection": "maximum_frozen_autonomous_causal_score",
        },
        "validation_selection_contract": {
            "candidates": [0, 60, 120, 180],
            "split": "valid",
            "conditions": [
                "correct_feedback",
                "correct_no_feedback",
                "mismatched_feedback",
            ],
            "minimum_action_parse_rate": 0.95,
            "minimum_selection_completion_rate": 0.80,
            "score_formula": (
                "selected_evidence_rate + information_gain_over_no_feedback + "
                "advantage_gap_over_mismatched + 0.25*valid_action_rate + "
                "0.25*selection_completion_rate"
            ),
            "tie_break": "higher_selected_evidence_then_earlier_checkpoint",
            "calibration_or_test_unavailable_to_selector": True,
        },
        "interaction_contract": interaction_contract,
        "conditions": [
            "direct_correct",
            "correct_feedback",
            "correct_no_feedback",
            "mismatched_feedback",
        ],
        "calibration_readiness_gates": gates,
        "sealed_test_gates": gates,
        "sealed_test_policy": "test_is_opened_only_if_all_calibration_readiness_gates_pass",
        "claim_boundary": (
            "M48 tests whether counterfactually paired preference learning makes the frozen 1.5B policy "
            "condition revise/select decisions on raw execution feedback. Checkpoints are selected only on "
            "fresh autonomous validation rollouts. At calibration and test, the tool returns raw outputs only "
            "and the model owns proposals, revisions, stopping, and selection. M48 does not establish transfer "
            "to unseen representation grammars, natural scientific experiments, or 70B parity."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def _load_json(path: Path) -> Mapping[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def verify_m48_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = _load_json(output / "benchmark-freeze.json")
    paths = {
        "preference_train": output / "preference/train.jsonl",
        "preference_valid": output / "preference/valid.jsonl",
        **{
            f"{split}_{kind}": output / f"{split}-{kind}.jsonl"
            for split in ("calibration", "test")
            for kind in ("public", "authority")
        },
    }
    hashes = {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in paths.items()
    }
    payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    split_ids = {
        split: {pair.pair_id for pair in build_m48_pairs(split)}
        for split in M48_SPLIT_SEEDS
    }
    rows = tuple(
        json.loads(line)
        for line in paths["preference_train"].read_text(encoding="utf-8").splitlines()
        if line
    )
    by_counterfactual: Dict[str, list[Mapping[str, Any]]] = {}
    for row in rows:
        by_counterfactual.setdefault(
            row["metadata"]["counterfactual_pair_id"], []
        ).append(row)
    single_pairs = [
        group
        for group in by_counterfactual.values()
        if group[0]["metadata"]["pair_kind"] == "single_slot_output_agreement"
    ]
    exact_pairs = all(
        len(group) == 2
        and {row["metadata"]["variant"] for row in group}
        == {"equal_requires_revision", "unequal_requires_selection"}
        and group[0]["metadata"]["history"][0]["experiment"]
        == group[1]["metadata"]["history"][0]["experiment"]
        for group in single_pairs
    )
    all_disjoint = all(
        not (split_ids[left] & split_ids[right])
        for index, left in enumerate(M48_SPLIT_SEEDS)
        for right in tuple(M48_SPLIT_SEEDS)[index + 1 :]
    )
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": content_digest(payload) == freeze["freeze_id"],
        "all_splits_are_disjoint": all_disjoint,
        "calibration_and_test_absent_from_training": not (
            output / "preference/calibration.jsonl"
        ).exists()
        and not (output / "preference/test.jsonl").exists(),
        "single_slot_counterfactual_pairs_are_exact": bool(single_pairs) and exact_pairs,
        "balanced_equal_and_unequal_targets": sum(
            row["metadata"]["variant"] == "equal_requires_revision" for row in rows
        )
        == sum(
            row["metadata"]["variant"] == "unequal_requires_selection" for row in rows
        ),
        "parent_adapter_hash_is_frozen": freeze["frozen_model"][
            "parent_adapter_sha256"
        ]
        == M48_PARENT_ADAPTER_SHA256,
        "autonomous_validation_selector_is_frozen": freeze[
            "validation_selection_contract"
        ]["calibration_or_test_unavailable_to_selector"],
        "teacher_is_training_only": freeze["counterfactual_contract"][
            "teacher_available_only_during_training"
        ]
        and freeze["interaction_contract"]["external_fallback_selection"] is False,
        "gates_are_identical_across_splits": freeze["calibration_readiness_gates"]
        == freeze["sealed_test_gates"],
    }
    return {
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def autonomous_metrics(
    pairs: Sequence[ContrastPair], states: Mapping[str, Sequence[Mapping[str, Any]]]
) -> Mapping[str, Any]:
    results = {}
    interactions = {}
    for mode, condition_states in states.items():
        results[mode] = aggregate_contrasts(
            mode,
            pairs,
            [state["selected_experiment"] for state in condition_states],
            [state["final_response"] for state in condition_states],
        )
        interactions[mode] = _interaction_metrics(
            pairs, condition_states, mode=mode
        )
    candidate = results["correct_feedback"]["metrics"]
    no_feedback = results["correct_no_feedback"]["metrics"]
    mismatch = results["mismatched_feedback"]["metrics"]
    loop = interactions["correct_feedback"]
    info_gap = candidate["mean_normalized_information_gain"] - no_feedback[
        "mean_normalized_information_gain"
    ]
    advantage_gap = candidate["mean_assignment_advantage"] - mismatch[
        "mean_assignment_advantage"
    ]
    causal_score = (
        loop["selected_evidence_rate"]
        + info_gap
        + advantage_gap
        + 0.25 * loop["valid_action_rate"]
        + 0.25 * loop["selection_completion_rate"]
    )
    return {
        "metrics": {name: result["metrics"] for name, result in results.items()},
        "interaction_metrics": {
            name: {key: value for key, value in result.items() if key != "records"}
            for name, result in interactions.items()
        },
        "information_gain_over_no_feedback": info_gap,
        "advantage_gap_over_mismatched": advantage_gap,
        "autonomous_causal_score": causal_score,
    }


def evaluate_m48_split(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    adapter_path: Path,
    *,
    split: str,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if split not in ("calibration", "test"):
        raise ValueError("M48 split must be calibration or test")
    freeze = _load_json(benchmark_root / "benchmark-freeze.json")
    selection = _load_json(output_root / "checkpoint-selection.json")
    if split == "test":
        calibration = output_root / "m48-calibration-assessment.json"
        if not calibration.exists() or not _load_json(calibration)["passed"]:
            raise RuntimeError("sealed M48 test cannot open before calibration passes")
    if not model_path.rstrip("/").endswith(freeze["frozen_model"]["snapshot"]):
        raise ValueError("model path does not match frozen M48 snapshot")
    adapter_hash = hashlib.sha256(
        (adapter_path / "adapters.safetensors").read_bytes()
    ).hexdigest()
    if (
        adapter_hash != selection["selected_adapter_sha256"]
        or selection["benchmark_freeze_id"] != freeze["freeze_id"]
        or selection["criterion"]
        != freeze["training_recipe"]["checkpoint_selection"]
    ):
        raise ValueError("adapter does not match frozen M48 validation selection")
    pairs = build_m48_pairs(split)
    tasks = pair_members(pairs)
    started = time.monotonic()
    model, tokenizer, config = load(
        model_path, adapter_path=str(adapter_path), return_config=True
    )
    states = {}
    peak_memory = 0.0
    for mode in ("correct_feedback", "correct_no_feedback", "mismatched_feedback"):
        condition_states, peak = _run_condition(
            pairs,
            model,
            tokenizer,
            mode=mode,
            contract=freeze["interaction_contract"],
        )
        states[mode] = condition_states
        peak_memory = max(peak_memory, peak)
    autonomous = autonomous_metrics(pairs, states)
    direct_responses, direct_peak = _batch_responses(
        model,
        tokenizer,
        tuple(
            _chat_prompt(tokenizer, contrast_prompt(task, dossier=True))
            for task in tasks
        ),
        batch_size=int(freeze["interaction_contract"]["batch_size"]),
        max_tokens=40,
        max_batch_tokens=12000,
    )
    peak_memory = max(peak_memory, direct_peak)
    direct = aggregate_contrasts(
        "direct_correct",
        pairs,
        [parse_experiment(response) for response in direct_responses],
        direct_responses,
    )
    metrics = {"direct_correct": direct["metrics"], **autonomous["metrics"]}
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "feedback_counterfactual_predictions",
        {
            "states": states,
            "direct": {
                "records": direct["records"],
                "pair_records": direct["pair_records"],
                "responses": list(direct_responses),
            },
        },
    )
    payload = {
        "version": FEEDBACK_COUNTERFACTUAL_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "split": split,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path),
        "adapter_weights_sha256": adapter_hash,
        "checkpoint_selection_id": selection["selection_id"],
        "metrics": metrics,
        "interaction_metrics": autonomous["interaction_metrics"],
        "autonomous_causal_score": autonomous["autonomous_causal_score"],
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "interaction_contract": freeze["interaction_contract"],
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(
        f"feedback-counterfactual-{split}-{manifest['evaluation_id']}", manifest
    )
    return manifest


def assess_m48_split(
    evaluation: Mapping[str, Any], benchmark_root: Path
) -> Mapping[str, Any]:
    freeze = _load_json(benchmark_root / "benchmark-freeze.json")
    split = str(evaluation["split"])
    gates = (
        freeze["calibration_readiness_gates"]
        if split == "calibration"
        else freeze["sealed_test_gates"]
    )
    metrics = evaluation["metrics"]
    interactions = evaluation["interaction_metrics"]
    candidate = metrics["correct_feedback"]
    direct = metrics["direct_correct"]
    no_feedback = metrics["correct_no_feedback"]
    mismatch = metrics["mismatched_feedback"]
    loop = interactions["correct_feedback"]
    predicate = candidate["by_representation"]["predicate"]
    causal = candidate["by_representation"]["causal"]
    checks = {
        "same_benchmark_freeze": evaluation["benchmark_freeze_id"] == freeze["freeze_id"],
        "fixed_raw_tool_contract": evaluation["interaction_contract"] == freeze["interaction_contract"],
        "action_parse_rate": loop["action_parse_rate"] >= gates["minimum_action_parse_rate"],
        "valid_action_rate": loop["valid_action_rate"] >= gates["minimum_valid_action_rate"],
        "selection_completion_rate": loop["selection_completion_rate"] >= gates["minimum_selection_completion_rate"],
        "selected_evidence_rate": loop["selected_evidence_rate"] >= gates["minimum_selected_evidence_rate"],
        "available_evidence_selection_rate": loop["available_evidence_selection_rate"] >= gates["minimum_available_evidence_selection_rate"],
        "predicate_information": predicate["mean_normalized_information_gain"] >= gates["minimum_predicate_information"],
        "causal_information": causal["mean_normalized_information_gain"] >= gates["minimum_causal_information"],
        "overall_correct_assignment": candidate["correct_assignment_rate"] >= gates["minimum_overall_correct_assignment"],
        "information_gain_over_direct": candidate["mean_normalized_information_gain"] - direct["mean_normalized_information_gain"] >= gates["minimum_information_gain_over_direct"],
        "assignment_gain_over_direct": candidate["correct_assignment_rate"] - direct["correct_assignment_rate"] >= gates["minimum_assignment_gain_over_direct"],
        "information_gain_over_no_feedback": candidate["mean_normalized_information_gain"] - no_feedback["mean_normalized_information_gain"] >= gates["minimum_information_gain_over_no_feedback"],
        "assignment_gain_over_no_feedback": candidate["correct_assignment_rate"] - no_feedback["correct_assignment_rate"] >= gates["minimum_assignment_gain_over_no_feedback"],
        "advantage_gap_over_mismatched": candidate["mean_assignment_advantage"] - mismatch["mean_assignment_advantage"] >= gates["minimum_advantage_gap_over_mismatched"],
    }
    deltas = {
        "information_gain_over_direct": candidate["mean_normalized_information_gain"] - direct["mean_normalized_information_gain"],
        "assignment_gain_over_direct": candidate["correct_assignment_rate"] - direct["correct_assignment_rate"],
        "information_gain_over_no_feedback": candidate["mean_normalized_information_gain"] - no_feedback["mean_normalized_information_gain"],
        "assignment_gain_over_no_feedback": candidate["correct_assignment_rate"] - no_feedback["correct_assignment_rate"],
        "advantage_gap_over_mismatched": candidate["mean_assignment_advantage"] - mismatch["mean_assignment_advantage"],
    }
    payload = {
        "version": FEEDBACK_COUNTERFACTUAL_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "split": split,
        "evaluation_id": evaluation["evaluation_id"],
        "metrics": metrics,
        "interaction_metrics": interactions,
        "autonomous_causal_score": evaluation["autonomous_causal_score"],
        "deltas": deltas,
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
        "sealed_test_authorized": split == "calibration" and all(checks.values()),
        "claim_boundary": freeze["claim_boundary"],
    }
    return {**payload, "assessment_id": content_digest(payload)}
