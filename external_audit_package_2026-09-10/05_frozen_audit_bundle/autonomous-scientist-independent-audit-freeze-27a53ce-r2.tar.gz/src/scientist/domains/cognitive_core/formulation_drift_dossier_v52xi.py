from __future__ import annotations

from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.cross_channel_binding_v52x import (
    M52X_DESCRIPTOR_CHANNEL,
    descriptor_direction,
)
from scientist.domains.cognitive_core.reciprocal_invariant_normalization_v52xh import (
    reciprocal_key,
    reciprocal_mean_records,
)
from scientist.domains.cognitive_core.robust_calibration_transport_v52xg import (
    fit_minimax_threshold,
    threshold_metrics,
)


FORMULATION_DRIFT_DOSSIER_VERSION = (
    "general-cognitive-formulation-drift-dossier-v52xi"
)
M52XI_SEED = 53233
M52XI_M52XH_AUDIT_ID = (
    "cf918ccd399a83547630c6de8533e3de76b5d1334b2898036d0458bc05062712"
)
M52XI_NULL_STATE = "__semantic_null__"
M52XI_NULL_TEXT = {
    "name": {
        "basis": "No particular method designation is supplied.",
        "candidate": "This candidate has no specified method designation.",
    },
    "principle": {
        "basis": "No particular governing principle is supplied.",
        "candidate": "This candidate has no specified governing principle.",
    },
    "action": {
        "basis": "No particular runtime operation is supplied.",
        "candidate": "This candidate has no specified runtime operation.",
    },
}


def _anchor_metadata(
    metadata: Mapping[str, Any], null_side: str
) -> Mapping[str, Any]:
    if null_side not in ("basis", "candidate"):
        raise ValueError("M52xi null side must be basis or candidate")
    basis_transformation = str(metadata["basis_transformation"])
    candidate_transformation = str(metadata["candidate_transformation"])
    basis_channel = M52X_DESCRIPTOR_CHANNEL[basis_transformation]
    candidate_channel = M52X_DESCRIPTOR_CHANNEL[candidate_transformation]
    basis_null = null_side == "basis"
    candidate_null = null_side == "candidate"
    key = {
        "family": str(metadata["family"]),
        "basis_state_key": (
            M52XI_NULL_STATE if basis_null else str(metadata["basis_state_key"])
        ),
        "candidate_state_key": (
            M52XI_NULL_STATE
            if candidate_null
            else str(metadata["candidate_state_key"])
        ),
        "basis_transformation": basis_transformation,
        "candidate_transformation": candidate_transformation,
    }
    record_id = content_digest({"milestone": "M52xi", "anchor": key})
    return {
        "record_id": record_id,
        "orbit_id": content_digest(
            {"milestone": "M52xi", "anchor_orbit": key}
        ),
        "family": key["family"],
        "semantic_split": str(metadata["semantic_split"]),
        "formulation_split": str(metadata["formulation_split"]),
        "basis_style": int(metadata["basis_style"]),
        "candidate_style": int(metadata["candidate_style"]),
        "basis_state_key": key["basis_state_key"],
        "candidate_state_key": key["candidate_state_key"],
        "basis_transformation": basis_transformation,
        "basis_transformation_split": "m52xi_fixed_semantic_null",
        "candidate_transformation": candidate_transformation,
        "candidate_transformation_split": "m52xi_fixed_semantic_null",
        "basis_text": (
            M52XI_NULL_TEXT[basis_channel]["basis"]
            if basis_null
            else str(metadata["basis_text"])
        ),
        "candidate_text": (
            M52XI_NULL_TEXT[candidate_channel]["candidate"]
            if candidate_null
            else str(metadata["candidate_text"])
        ),
        "relation_target": "NO",
        "anchor_null_side": null_side,
    }


def build_semantic_null_anchor_rows(
    source_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    unique: dict[tuple[str, ...], Mapping[str, Any]] = {}
    for source in source_rows:
        for null_side in ("basis", "candidate"):
            metadata = _anchor_metadata(source["metadata"], null_side)
            row = {
                "prompt": (
                    "Determine whether the two descriptions refer to the same underlying "
                    "algorithmic state. Answer YES or NO.\n\nDescription A:\n"
                    f"{metadata['basis_text']}\n\nDescription B:\n"
                    f"{metadata['candidate_text']}\n\nAnswer:"
                ),
                "metadata": metadata,
            }
            direction = descriptor_direction(row)
            key = (
                str(metadata["family"]),
                str(metadata["basis_state_key"]),
                str(metadata["candidate_state_key"]),
                str(metadata["basis_transformation"]),
                str(metadata["candidate_transformation"]),
                direction,
            )
            unique.setdefault(key, row)
    return tuple(unique.values())


def anchor_centered_records(
    actual_raw_records: Sequence[Mapping[str, Any]],
    anchor_raw_records: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    actual = reciprocal_mean_records(actual_raw_records)
    anchors = reciprocal_mean_records(anchor_raw_records)
    anchor_index = {reciprocal_key(row): row for row in anchors}
    centered = []
    for row in actual:
        fields = list(reciprocal_key(row))
        left_null_key = tuple(
            fields[:2] + [M52XI_NULL_STATE] + fields[3:]
        )
        right_null_key = tuple(
            [fields[0], M52XI_NULL_STATE, fields[2], *fields[3:]]
        )
        if left_null_key not in anchor_index or right_null_key not in anchor_index:
            raise ValueError("M52xi semantic-null reference is incomplete")
        reference = 0.5 * (
            float(anchor_index[left_null_key]["margin"])
            + float(anchor_index[right_null_key]["margin"])
        )
        margin = float(row["margin"]) - reference
        centered.append(
            {
                **row,
                "margin": margin,
                "prediction": "YES" if margin > 0.0 else "NO",
                "raw_reciprocal_margin": float(row["margin"]),
                "semantic_null_reference": reference,
            }
        )
    return tuple(centered)


def _by_family(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[str, Tuple[Mapping[str, Any], ...]]:
    return {
        family: tuple(row for row in records if str(row["family"]) == family)
        for family in sorted({str(row["family"]) for row in records})
    }


def _apply_threshold(
    records: Sequence[Mapping[str, Any]], threshold: float
) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        {
            **row,
            "margin": float(row["margin"]) - float(threshold),
            "prediction": (
                "YES" if float(row["margin"]) > float(threshold) else "NO"
            ),
        }
        for row in records
    )


def score_at_threshold(
    records: Sequence[Mapping[str, Any]], threshold: float
) -> Mapping[str, Any]:
    overall = threshold_metrics(records, threshold)
    family = {
        key: threshold_metrics(values, threshold)
        for key, values in _by_family(records).items()
    }
    return {
        "threshold": float(threshold),
        "overall": overall,
        "by_family": family,
        "minimum_family_balanced_accuracy": min(
            float(value["balanced_accuracy"]) for value in family.values()
        ),
    }


def formulation_transfer(
    train_records: Sequence[Mapping[str, Any]],
    test_records: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    fit = fit_minimax_threshold(_by_family(train_records))
    return {
        "training_fit": fit,
        "test_metrics": score_at_threshold(test_records, float(fit["threshold"])),
    }


def joint_formulation_family_holdout(
    selection: Sequence[Mapping[str, Any]],
    confirmation: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    formulations = {"selection": tuple(selection), "confirmation": tuple(confirmation)}
    values = {}
    for test_name, test_records in formulations.items():
        train_name = "confirmation" if test_name == "selection" else "selection"
        train_records = formulations[train_name]
        for family, held in _by_family(test_records).items():
            fit = fit_minimax_threshold(
                {
                    key: rows
                    for key, rows in _by_family(train_records).items()
                    if key != family
                }
            )
            values[f"{test_name}|{family}"] = {
                "training_formulation": train_name,
                "training_threshold": fit["threshold"],
                "heldout_metrics": threshold_metrics(held, float(fit["threshold"])),
            }
    return values


def diagnose_normalization(
    selection: Sequence[Mapping[str, Any]],
    confirmation: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    selection_to_confirmation = formulation_transfer(selection, confirmation)
    confirmation_to_selection = formulation_transfer(confirmation, selection)
    joint = joint_formulation_family_holdout(selection, confirmation)
    opened_cells = {
        f"selection|{key}": value for key, value in _by_family(selection).items()
    }
    opened_cells.update(
        {
            f"confirmation|{key}": value
            for key, value in _by_family(confirmation).items()
        }
    )
    combined = fit_minimax_threshold(opened_cells)
    checks = {
        "selection_to_confirmation_overall": float(
            selection_to_confirmation["test_metrics"]["overall"][
                "balanced_accuracy"
            ]
        )
        >= 0.88,
        "selection_to_confirmation_each_family": float(
            selection_to_confirmation["test_metrics"][
                "minimum_family_balanced_accuracy"
            ]
        )
        >= 0.82,
        "confirmation_to_selection_overall": float(
            confirmation_to_selection["test_metrics"]["overall"][
                "balanced_accuracy"
            ]
        )
        >= 0.90,
        "confirmation_to_selection_each_family": float(
            confirmation_to_selection["test_metrics"][
                "minimum_family_balanced_accuracy"
            ]
        )
        >= 0.85,
        "joint_unseen_formulation_and_family_floor": min(
            float(value["heldout_metrics"]["balanced_accuracy"])
            for value in joint.values()
        )
        >= 0.82,
        "combined_opened_cell_floor": float(
            combined["minimum_distribution_balanced_accuracy"]
        )
        >= 0.85,
    }
    return {
        "selection_to_confirmation": selection_to_confirmation,
        "confirmation_to_selection": confirmation_to_selection,
        "joint_formulation_family_holdout": joint,
        "combined_opened_minimax": combined,
        "checks": checks,
        "predictor_supported": all(checks.values()),
    }


__all__ = (
    "FORMULATION_DRIFT_DOSSIER_VERSION",
    "M52XI_M52XH_AUDIT_ID",
    "M52XI_NULL_STATE",
    "M52XI_NULL_TEXT",
    "M52XI_SEED",
    "anchor_centered_records",
    "build_semantic_null_anchor_rows",
    "diagnose_normalization",
    "formulation_transfer",
    "joint_formulation_family_holdout",
    "score_at_threshold",
)
