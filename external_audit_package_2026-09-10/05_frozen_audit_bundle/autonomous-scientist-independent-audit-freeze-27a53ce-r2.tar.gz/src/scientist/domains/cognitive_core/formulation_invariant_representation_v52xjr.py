from __future__ import annotations

from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.cross_channel_binding_v52x import binding_metrics
from scientist.domains.cognitive_core.multiformulation_population_validation_v52xe import (
    evaluate_geometry_records,
    population_geometry_gate_passed,
)
from scientist.domains.cognitive_core.reciprocal_invariant_normalization_v52xh import (
    readout_gate_passed,
    reciprocal_readout_records,
)
from scientist.domains.cognitive_core.robust_calibration_transport_v52xg import (
    fit_minimax_threshold,
)


FORMULATION_INVARIANT_REPRESENTATION_VERSION = (
    "general-cognitive-formulation-invariant-representation-v52xjr"
)
M52XJR_SEED = 53251
M52XJR_M52XI_AUDIT_ID = (
    "21ecd899d4dbc33dfd90fdebb0d529d37857ce13d3c4635dce5cef36437b0a6a"
)


def evaluate_fixed_boundary_ensemble(
    rows: Sequence[Mapping[str, Any]],
    raw_hidden_records: Sequence[Mapping[str, Any]],
    threshold: float,
    hidden_gate: Mapping[str, float],
    readout_gate: Mapping[str, float],
) -> Mapping[str, Any]:
    fused, readout = reciprocal_readout_records(rows, raw_hidden_records, threshold)
    geometry = evaluate_geometry_records(fused)
    hidden_passed, hidden_checks, population = population_geometry_gate_passed(
        geometry, hidden_gate
    )
    metrics = binding_metrics(readout)
    readout_passed, readout_checks = readout_gate_passed(metrics, readout_gate)
    oracle = fit_minimax_threshold({"primary": fused, "duplicate": fused})
    return {
        "reciprocal_hidden_records": list(fused),
        "readout_records": list(readout),
        "hidden_geometry": geometry,
        "hidden_population_risk": population,
        "hidden_checks": hidden_checks,
        "hidden_passed": hidden_passed,
        "readout_metrics": metrics,
        "readout_checks": readout_checks,
        "readout_passed": readout_passed,
        "oracle_threshold_diagnostic_only": oracle["threshold"],
        "oracle_balanced_accuracy_diagnostic_only": oracle[
            "minimum_distribution_balanced_accuracy"
        ],
        "minimum_family_balanced_accuracy": min(
            float(value["absolute"]["balanced_accuracy"])
            for value in metrics["by_family"].values()
        ),
        "passed": hidden_passed and readout_passed,
    }


def summarize_development_panel(
    ensembles: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    if len(ensembles) < 2:
        raise ValueError("M52xj-R development requires multiple heldout formulations")
    thresholds = [
        float(value["oracle_threshold_diagnostic_only"])
        for value in ensembles.values()
    ]
    return {
        "ensemble_names": list(ensembles),
        "all_ensembles_passed": all(
            bool(value["passed"]) for value in ensembles.values()
        ),
        "minimum_family_balanced_accuracy": min(
            float(value["minimum_family_balanced_accuracy"])
            for value in ensembles.values()
        ),
        "minimum_overall_balanced_accuracy": min(
            float(value["readout_metrics"]["absolute"]["balanced_accuracy"])
            for value in ensembles.values()
        ),
        "minimum_ranking_accuracy": min(
            float(value["readout_metrics"]["ranking"]["ranking_accuracy"])
            for value in ensembles.values()
        ),
        "minimum_top1_accuracy": min(
            float(value["readout_metrics"]["ranking"]["top1_accuracy"])
            for value in ensembles.values()
        ),
        "minimum_weakest_reciprocity": min(
            float(
                value["hidden_geometry"]["reciprocity"][
                    "weakest_pair_mean_reciprocal_correlation"
                ]
            )
            for value in ensembles.values()
        ),
        "oracle_threshold_minimum": min(thresholds),
        "oracle_threshold_maximum": max(thresholds),
        "oracle_threshold_range": max(thresholds) - min(thresholds),
    }


def development_candidate_gate_passed(
    candidate: Mapping[str, Any],
    baseline: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "all_heldout_formulations_pass": bool(candidate["all_ensembles_passed"]),
        "minimum_worst_family_improvement": float(
            candidate["minimum_family_balanced_accuracy"]
        )
        - float(baseline["minimum_family_balanced_accuracy"])
        >= float(contract["minimum_worst_family_improvement"]),
        "maximum_oracle_threshold_range": float(
            candidate["oracle_threshold_range"]
        )
        <= float(contract["maximum_oracle_threshold_range"]),
        "minimum_ranking_accuracy": float(candidate["minimum_ranking_accuracy"])
        >= float(contract["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(candidate["minimum_top1_accuracy"])
        >= float(contract["minimum_top1_accuracy"]),
        "minimum_weakest_reciprocity": float(
            candidate["minimum_weakest_reciprocity"]
        )
        >= float(contract["minimum_weakest_reciprocity"]),
        "output_preservation": bool(candidate["output_preservation_passed"]),
    }
    return all(checks.values()), checks


def confirmation_candidate_gate_passed(
    confirmation: Mapping[str, Any],
    baseline: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "confirmation_ensemble_passes": bool(confirmation["passed"]),
        "minimum_family_nonregression": float(
            confirmation["minimum_family_balanced_accuracy"]
        )
        - float(baseline["minimum_family_balanced_accuracy"])
        >= -float(contract["maximum_worst_family_regression"]),
        "minimum_ranking_accuracy": float(
            confirmation["readout_metrics"]["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(
            confirmation["readout_metrics"]["ranking"]["top1_accuracy"]
        )
        >= float(contract["minimum_top1_accuracy"]),
    }
    return all(checks.values()), checks


def select_earliest_development_pass(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    passing = [row for row in candidates if bool(row["passed"])]
    if not passing:
        return None
    return min(passing, key=lambda row: int(row["iteration"]))


__all__ = (
    "FORMULATION_INVARIANT_REPRESENTATION_VERSION",
    "M52XJR_M52XI_AUDIT_ID",
    "M52XJR_SEED",
    "confirmation_candidate_gate_passed",
    "development_candidate_gate_passed",
    "evaluate_fixed_boundary_ensemble",
    "select_earliest_development_pass",
    "summarize_development_panel",
)
