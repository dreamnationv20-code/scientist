from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.objective_evidence_architecture_v8 import (
    ObjectiveEvidenceArchitecture,
)
from scientist.kernel.contracts import MetricDirection, MetricSpec
from scientist.program.goal_graph import (
    CompositionOperator,
    DependencyEdge,
    DependencyKind,
    ExecutableLeafContract,
    GoalGraphDecompositionProposal,
    GoalNodeKind,
    GoalNodeRole,
    GoalNodeSpec,
    ParentCompositionRule,
)


FUNCTIONAL_CONTRACTS_VERSION = "cognitive-core-functional-contracts-v9"


@dataclass(frozen=True)
class FunctionalContractDefinition:
    capability_key: str
    wave: int
    required_inputs: Tuple[str, ...]
    observable_outputs: Tuple[str, ...]
    functional_pass_condition: str
    protected_work_packages: Tuple[str, ...]
    disallowed_shortcuts: Tuple[str, ...]
    prerequisite_keys: Tuple[str, ...] = ()


@dataclass(frozen=True)
class FunctionalWorkPackageContract:
    work_package_key: str
    capability_key: str
    wave: int
    parent_node_id: str
    leaf: GoalNodeSpec
    required_inputs: Tuple[str, ...]
    observable_outputs: Tuple[str, ...]
    protected_work_packages: Tuple[str, ...]
    disallowed_shortcuts: Tuple[str, ...]
    prerequisite_keys: Tuple[str, ...]
    shared_candidate_required: bool = True
    mechanism_commitment: str = "none"

    @property
    def contract_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": FUNCTIONAL_CONTRACTS_VERSION,
            "work_package_key": self.work_package_key,
            "capability_key": self.capability_key,
            "wave": self.wave,
            "parent_node_id": self.parent_node_id,
            "leaf": self.leaf.as_dict(),
            "required_inputs": list(self.required_inputs),
            "observable_outputs": list(self.observable_outputs),
            "protected_work_packages": list(self.protected_work_packages),
            "disallowed_shortcuts": list(self.disallowed_shortcuts),
            "prerequisite_keys": list(self.prerequisite_keys),
            "shared_candidate_required": self.shared_candidate_required,
            "mechanism_commitment": self.mechanism_commitment,
        }
        if include_id:
            value["contract_id"] = self.contract_id
        return value


@dataclass(frozen=True)
class FunctionalContractBundle:
    contracts: Mapping[str, FunctionalWorkPackageContract]
    decompositions: Tuple[GoalGraphDecompositionProposal, ...]
    dependencies: Tuple[DependencyEdge, ...]
    wave_keys: Mapping[int, Tuple[str, ...]]

    @property
    def bundle_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def total_experiment_budget(self) -> float:
        return sum(
            item.leaf.leaf_contract.experiment_budget
            for item in self.contracts.values()
            if item.leaf.leaf_contract is not None
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": FUNCTIONAL_CONTRACTS_VERSION,
            "contracts": {
                key: item.as_dict()
                for key, item in sorted(self.contracts.items())
            },
            "decompositions": [item.as_dict() for item in self.decompositions],
            "dependencies": [item.as_dict() for item in self.dependencies],
            "wave_keys": {
                str(wave): list(keys)
                for wave, keys in sorted(self.wave_keys.items())
            },
            "total_experiment_budget": self.total_experiment_budget,
        }
        if include_id:
            value["bundle_id"] = self.bundle_id
        return value


DEFINITIONS: Mapping[str, FunctionalContractDefinition] = {
    "procedure_representation": FunctionalContractDefinition(
        capability_key="procedures",
        wave=1,
        required_inputs=(
            "operation specification",
            "operands or task state",
            "unseen surface realization",
        ),
        observable_outputs=(
            "operation identity independent of incidental template",
            "correct execution on unseen operands and renderings",
        ),
        functional_pass_condition=(
            "A reusable operation transfers across unseen operands, symbols, and "
            "surface forms without memorizing the evaluation templates."
        ),
        protected_work_packages=("knowledge_retention", "system_cost"),
        disallowed_shortcuts=(
            "template lookup",
            "evaluation-case memorization",
            "a separate specialist unavailable to the shared candidate",
        ),
    ),
    "procedure_composition": FunctionalContractDefinition(
        capability_key="procedures",
        wave=3,
        required_inputs=(
            "two or more represented operations",
            "unseen composition order",
            "intermediate task state",
        ),
        observable_outputs=(
            "correct unseen operation composition",
            "stable intermediate-state semantics",
        ),
        functional_pass_condition=(
            "The shared candidate composes learned operations at unseen orders "
            "and lengths while retaining each component operation."
        ),
        protected_work_packages=(
            "procedure_representation",
            "procedure_retention",
            "system_cost",
        ),
        disallowed_shortcuts=(
            "enumeration of tested compositions",
            "composition-specific retraining",
        ),
        prerequisite_keys=("procedure_representation", "fast_adaptation"),
    ),
    "task_inference": FunctionalContractDefinition(
        capability_key="rapid_learning",
        wave=1,
        required_inputs=(
            "sparse demonstrations",
            "candidate task context",
            "unseen query",
        ),
        observable_outputs=(
            "inferred task identity or uncertainty",
            "correct action under the inferred task",
        ),
        functional_pass_condition=(
            "The latent task is inferred from few demonstrations on unseen task "
            "families without access to hidden task labels."
        ),
        protected_work_packages=("procedure_retention", "system_cost"),
        disallowed_shortcuts=(
            "hidden task-label access",
            "task-family-specific prompt templates",
        ),
    ),
    "fast_adaptation": FunctionalContractDefinition(
        capability_key="rapid_learning",
        wave=2,
        required_inputs=(
            "inferred task representation",
            "few demonstrations",
            "frozen shared candidate",
        ),
        observable_outputs=(
            "post-demonstration task competence",
            "measured marginal adaptation cost",
        ),
        functional_pass_condition=(
            "The inferred task is acquired at fixed marginal cost without full "
            "system retraining or loss of previous procedures."
        ),
        protected_work_packages=(
            "procedure_representation",
            "knowledge_retention",
            "system_cost",
        ),
        disallowed_shortcuts=(
            "unreported full-model retraining",
            "unbounded context growth",
            "per-task specialist substitution",
        ),
        prerequisite_keys=("task_inference", "procedure_representation"),
    ),
    "relevance_representation": FunctionalContractDefinition(
        capability_key="routing",
        wave=1,
        required_inputs=(
            "query or requested change",
            "candidate evidence and state",
            "protected-state declarations",
        ),
        observable_outputs=(
            "target, protected, irrelevant, and uncertain relations",
            "relation predictions on unseen compositions",
        ),
        functional_pass_condition=(
            "Relational relevance generalizes to unseen target/evidence/state "
            "combinations and separates targets from protected state."
        ),
        protected_work_packages=("knowledge_retention", "system_cost"),
        disallowed_shortcuts=(
            "position-only relevance",
            "identifier memorization",
            "oracle relevance labels at evaluation time",
        ),
    ),
    "selector_inference": FunctionalContractDefinition(
        capability_key="routing",
        wave=2,
        required_inputs=(
            "represented relevance relations",
            "task belief",
            "available information channels",
        ),
        observable_outputs=(
            "selected influence path",
            "explicit protected and ignored channels",
        ),
        functional_pass_condition=(
            "The correct influence path is selected on unseen relational "
            "compositions without routing irrelevant state into the decision."
        ),
        protected_work_packages=(
            "evidence_discrimination",
            "update_locality",
            "system_cost",
        ),
        disallowed_shortcuts=(
            "always-use-all-information policy",
            "hard-coded task identifiers",
        ),
        prerequisite_keys=("relevance_representation", "task_inference"),
    ),
    "uncertainty_routing": FunctionalContractDefinition(
        capability_key="routing",
        wave=2,
        required_inputs=(
            "task belief",
            "selected evidence",
            "calibrated uncertainty and action costs",
        ),
        observable_outputs=(
            "answer, retrieve, clarify, update, or abstain action",
            "action probability or confidence",
        ),
        functional_pass_condition=(
            "The system chooses the utility-correct action under uncertainty and "
            "remains calibrated across unseen task families."
        ),
        protected_work_packages=("selector_inference", "system_cost"),
        disallowed_shortcuts=(
            "always-answer policy",
            "always-abstain policy",
            "access to hidden correctness labels",
        ),
        prerequisite_keys=("task_inference", "selector_inference"),
    ),
    "evidence_discrimination": FunctionalContractDefinition(
        capability_key="evidence",
        wave=2,
        required_inputs=(
            "query and prior state",
            "relevant, irrelevant, conflicting, or adversarial evidence",
        ),
        observable_outputs=(
            "evidence-role classification",
            "provenance-preserving relevance decision",
        ),
        functional_pass_condition=(
            "Evidence roles are discriminated on unseen sources and relations, "
            "including conflicts and adversarial distractors."
        ),
        protected_work_packages=("relevance_representation", "system_cost"),
        disallowed_shortcuts=(
            "source-position heuristics",
            "evaluation-source whitelist",
        ),
        prerequisite_keys=("relevance_representation",),
    ),
    "evidence_integration": FunctionalContractDefinition(
        capability_key="evidence",
        wave=2,
        required_inputs=(
            "discriminated evidence",
            "current knowledge state",
            "query and provenance",
        ),
        observable_outputs=(
            "evidence-grounded answer",
            "preserved correct prior knowledge when evidence is irrelevant",
        ),
        functional_pass_condition=(
            "Helpful evidence changes the answer when warranted while irrelevant, "
            "conflicting, and adversarial evidence cannot destructively override it."
        ),
        protected_work_packages=(
            "knowledge_retention",
            "selector_inference",
            "system_cost",
        ),
        disallowed_shortcuts=(
            "blind last-context override",
            "discarding all external evidence",
        ),
        prerequisite_keys=("evidence_discrimination", "selector_inference"),
    ),
    "requested_change": FunctionalContractDefinition(
        capability_key="updating",
        wave=1,
        required_inputs=(
            "explicit update request",
            "current target value or rule",
            "new value or rule",
        ),
        observable_outputs=(
            "correct updated target behavior",
            "auditable update acknowledgement",
        ),
        functional_pass_condition=(
            "A warranted requested change is installed accurately and is available "
            "to subsequent decisions without full-system retraining."
        ),
        protected_work_packages=("knowledge_retention", "procedure_retention"),
        disallowed_shortcuts=(
            "answer-time access to the update target",
            "rebuilding an independent model per update",
        ),
    ),
    "update_locality": FunctionalContractDefinition(
        capability_key="updating",
        wave=2,
        required_inputs=(
            "requested change",
            "target and protected relevance relations",
            "pre-update shared state",
        ),
        observable_outputs=(
            "target-state change",
            "zero or bounded protected-state change",
        ),
        functional_pass_condition=(
            "The requested target changes while causally unrelated knowledge, "
            "procedures, and routing behavior remain within frozen floors."
        ),
        protected_work_packages=(
            "knowledge_retention",
            "procedure_retention",
            "selector_inference",
        ),
        disallowed_shortcuts=(
            "global overwrite followed by selective evaluation",
            "excluding affected protected cases after the update",
        ),
        prerequisite_keys=("requested_change", "relevance_representation"),
    ),
    "sequential_update_consistency": FunctionalContractDefinition(
        capability_key="updating",
        wave=3,
        required_inputs=(
            "ordered updates to overlapping and disjoint targets",
            "interleaved queries",
            "persistent shared state",
        ),
        observable_outputs=(
            "latest correct target state",
            "order-consistent answers after delays",
        ),
        functional_pass_condition=(
            "Repeated updates preserve the latest warranted state and commute when "
            "causally independent across interleaved trajectories."
        ),
        protected_work_packages=(
            "update_locality",
            "knowledge_retention",
            "procedure_retention",
        ),
        disallowed_shortcuts=(
            "replaying the full update transcript at every query",
            "resetting between trajectory steps",
        ),
        prerequisite_keys=("requested_change", "update_locality"),
    ),
    "knowledge_retention": FunctionalContractDefinition(
        capability_key="retention",
        wave=3,
        required_inputs=(
            "pre-intervention knowledge probes",
            "targeted intervention",
            "unrelated post-intervention probes",
        ),
        observable_outputs=(
            "retained unrelated answers",
            "case-level retention deltas",
        ),
        functional_pass_condition=(
            "Knowledge outside the causal intervention scope remains correct over "
            "unseen probes and delayed trajectories."
        ),
        protected_work_packages=("requested_change", "system_cost"),
        disallowed_shortcuts=(
            "omitting difficult pre-update knowledge from retention scoring",
            "restoring from an evaluation-only snapshot",
        ),
        prerequisite_keys=("update_locality",),
    ),
    "procedure_retention": FunctionalContractDefinition(
        capability_key="retention",
        wave=3,
        required_inputs=(
            "pre-intervention procedure probes",
            "knowledge or task intervention",
            "unseen post-intervention procedure probes",
        ),
        observable_outputs=(
            "retained operation and composition accuracy",
            "procedure-specific retention deltas",
        ),
        functional_pass_condition=(
            "Reusable procedures remain executable after knowledge updates and new "
            "task acquisition without restoring a separate procedure model."
        ),
        protected_work_packages=(
            "procedure_representation",
            "fast_adaptation",
            "system_cost",
        ),
        disallowed_shortcuts=(
            "frozen evaluation-only procedure expert",
            "excluding changed-context procedure cases",
        ),
        prerequisite_keys=("procedure_representation", "update_locality"),
    ),
    "delayed_interference": FunctionalContractDefinition(
        capability_key="retention",
        wave=3,
        required_inputs=(
            "locally passing intervention",
            "long interleaved trajectory",
            "target and protected-state probes",
        ),
        observable_outputs=(
            "horizon-indexed target utility",
            "horizon-indexed protected-state retention",
        ),
        functional_pass_condition=(
            "A locally non-regressive intervention remains non-regressive through "
            "the frozen 1, 4, 16, and 32-step horizon ladder."
        ),
        protected_work_packages=(
            "sequential_update_consistency",
            "knowledge_retention",
            "procedure_retention",
        ),
        disallowed_shortcuts=(
            "terminal-only state restoration",
            "changing the intervention across horizons",
        ),
        prerequisite_keys=(
            "sequential_update_consistency",
            "knowledge_retention",
            "procedure_retention",
        ),
    ),
    "shared_architecture": FunctionalContractDefinition(
        capability_key="integration",
        wave=4,
        required_inputs=(
            "one frozen candidate identity",
            "all capability interfaces",
            "one shared state and cost ledger",
        ),
        observable_outputs=(
            "joint capability predictions",
            "reconstructable shared-candidate artifact",
        ),
        functional_pass_condition=(
            "One reconstructable candidate executes all required capabilities; no "
            "capability is supplied by an independently selected specialist."
        ),
        protected_work_packages=(
            "procedure_composition",
            "fast_adaptation",
            "uncertainty_routing",
            "evidence_integration",
            "delayed_interference",
            "system_cost",
        ),
        disallowed_shortcuts=(
            "per-benchmark model selection",
            "unreported specialist ensembles",
            "different candidate states across capability tests",
        ),
        prerequisite_keys=(
            "procedure_composition",
            "fast_adaptation",
            "uncertainty_routing",
            "evidence_integration",
            "delayed_interference",
            "system_cost",
        ),
    ),
    "system_cost": FunctionalContractDefinition(
        capability_key="integration",
        wave=1,
        required_inputs=(
            "candidate reconstruction manifest",
            "training and inference ledger",
            "context, memory, retrieval, and adaptation usage",
        ),
        observable_outputs=(
            "end-to-end comparable cost vector",
            "matched-budget admissibility decision",
        ),
        functional_pass_condition=(
            "Parameters, training, inference, context, memory, retrieval, and "
            "adaptation are all measured and remain inside the frozen envelope."
        ),
        protected_work_packages=("shared_architecture", "pareto_floors"),
        disallowed_shortcuts=(
            "excluding retrieval or memory cost",
            "amortizing candidate-only training away",
            "using an unmatched external service",
        ),
    ),
    "pareto_floors": FunctionalContractDefinition(
        capability_key="integration",
        wave=4,
        required_inputs=(
            "frozen shared candidate",
            "matched incumbent",
            "all capability and cost reports",
        ),
        observable_outputs=(
            "capability-by-capability paired deltas",
            "joint Pareto admissibility decision",
        ),
        functional_pass_condition=(
            "The shared candidate improves at least one declared objective while "
            "every other capability and system-cost floor remains satisfied."
        ),
        protected_work_packages=(
            "procedure_composition",
            "fast_adaptation",
            "uncertainty_routing",
            "evidence_integration",
            "delayed_interference",
            "system_cost",
        ),
        disallowed_shortcuts=(
            "compensating a failed floor with an aggregate mean",
            "post-hoc metric removal",
            "different incumbents for favorable capability comparisons",
        ),
        prerequisite_keys=("shared_architecture", "system_cost"),
    ),
}


WAVE_BUDGETS = {1: 10.0, 2: 12.0, 3: 12.0, 4: 20.0}


def functional_contract_bundle(
    architecture: ObjectiveEvidenceArchitecture,
) -> FunctionalContractBundle:
    if set(architecture.work_packages) != set(DEFINITIONS):
        raise ValueError("functional definitions do not cover the objective graph")

    contracts: Dict[str, FunctionalWorkPackageContract] = {}
    decompositions = []
    for key, parent in architecture.work_packages.items():
        definition = DEFINITIONS[key]
        success_conditions = (
            definition.functional_pass_condition,
            "The result holds on frozen unseen task and composition families.",
            "The same candidate identity and persistent state are used throughout.",
            "Every declared protected work package remains above its frozen floor.",
            "End-to-end cost remains within the registered shared-candidate envelope.",
        )
        falsification_conditions = (
            "The functional pass condition fails on the audit partition.",
            "A declared disallowed shortcut is necessary for the result.",
            "A protected work package falls below its frozen floor.",
            "The result requires a separately selected specialist or hidden cost.",
        )
        metric = MetricSpec(
            name="%s_functional_gate" % key,
            direction=MetricDirection.TARGET,
            unit="binary preregistered functional gate",
            aggregation="all functional, protection, identity, and cost checks",
            primary=True,
            target=1.0,
        )
        executable = ExecutableLeafContract(
            hypothesis=(
                "Within the frozen shared-candidate interface and cost envelope, "
                "at least one candidate can satisfy the %s functional behavior; "
                "this contract does not select its implementation mechanism."
                % key
            ),
            parent_decision=(
                "whether the shared candidate satisfies %s and may integrate "
                "into the %s capability" % (parent.title, definition.capability_key)
            ),
            root_metric_link=(
                "%s is a necessary non-substitutable edge of the functional "
                "cognitive-core objective" % parent.title
            ),
            metric=metric,
            success_conditions=success_conditions,
            falsification_conditions=falsification_conditions,
            testbed_ref="%s:%s" % (FUNCTIONAL_CONTRACTS_VERSION, key),
            parent_integration_test=(
                "Run this exact candidate and state through the parent work "
                "package and capability suite; an isolated substitute cannot pass."
            ),
            experiment_budget=WAVE_BUDGETS[definition.wave],
            preregistration_ref="%s:%s" % (FUNCTIONAL_CONTRACTS_VERSION, key),
        )
        leaf = GoalNodeSpec(
            goal_id=parent.goal_id,
            title="Functional contract: %s" % parent.title,
            question=parent.question,
            kind=GoalNodeKind.EXECUTABLE_LEAF,
            rationale=(
                "This leaf freezes observable behavior, protection, identity, and "
                "cost requirements before any implementation mechanism is proposed."
            ),
            success_conditions=success_conditions,
            falsification_conditions=falsification_conditions,
            expected_artifact=(
                "%s shared-candidate functional result" % key
            ),
            critical=True,
            leaf_contract=executable,
            tags=(
                "objective",
                "functional-contract",
                "shared-candidate",
                "wave-%d" % definition.wave,
                key.replace("_", "-"),
            ),
            role=GoalNodeRole.OBJECTIVE,
        )
        contract = FunctionalWorkPackageContract(
            work_package_key=key,
            capability_key=definition.capability_key,
            wave=definition.wave,
            parent_node_id=parent.node_id,
            leaf=leaf,
            required_inputs=definition.required_inputs,
            observable_outputs=definition.observable_outputs,
            protected_work_packages=definition.protected_work_packages,
            disallowed_shortcuts=definition.disallowed_shortcuts,
            prerequisite_keys=definition.prerequisite_keys,
        )
        contracts[key] = contract
        rule = ParentCompositionRule(
            parent_id=parent.node_id,
            child_ids=(leaf.node_id,),
            operator=CompositionOperator.ALL,
            integration_test=executable.parent_integration_test,
            rationale=(
                "The mechanism-neutral functional contract is the executable "
                "completion criterion for this objective work package."
            ),
            decomposer_ref=FUNCTIONAL_CONTRACTS_VERSION,
        )
        decompositions.append(
            GoalGraphDecompositionProposal(
                parent_id=parent.node_id,
                nodes=(leaf,),
                rule=rule,
                assumptions=(
                    "the required behavior can be tested without selecting a mechanism",
                    "one candidate identity will be shared across capability tests",
                    "protected floors and all system costs are independently reconstructable",
                ),
                distinguishing_predictions=(
                    "the work package can fail while another package passes",
                    "shortcut controls can pass an apparent task score but fail this contract",
                ),
                reasoning=(
                    "Freeze the functional completion criterion before baseline "
                    "reconstruction or mechanism search."
                ),
            )
        )

    dependencies = []
    for key, contract in contracts.items():
        for prerequisite_key in contract.prerequisite_keys:
            prerequisite_parent = architecture.work_packages[prerequisite_key]
            dependencies.append(
                DependencyEdge(
                    source_id=contract.leaf.node_id,
                    target_id=prerequisite_parent.node_id,
                    kind=DependencyKind.REQUIRES,
                    rationale=(
                        "%s becomes executable only after the %s functional "
                        "work package integrates in the shared candidate."
                        % (key, prerequisite_key)
                    ),
                )
            )

    wave_keys: Dict[int, Tuple[str, ...]] = {}
    for wave in sorted({item.wave for item in contracts.values()}):
        wave_keys[wave] = tuple(
            sorted(
                key for key, item in contracts.items() if item.wave == wave
            )
        )
    return FunctionalContractBundle(
        contracts=contracts,
        decompositions=tuple(decompositions),
        dependencies=tuple(dependencies),
        wave_keys=wave_keys,
    )
