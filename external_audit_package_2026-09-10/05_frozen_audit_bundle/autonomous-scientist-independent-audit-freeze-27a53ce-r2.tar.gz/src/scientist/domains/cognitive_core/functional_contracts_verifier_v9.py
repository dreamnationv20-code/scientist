from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.functional_contracts_v9 import (
    FunctionalContractBundle,
)
from scientist.domains.cognitive_core.objective_evidence_architecture_v8 import (
    ObjectiveEvidenceArchitecture,
)
from scientist.program.control_plane import (
    AutonomousScientistControlPlane,
    ControlActionKind,
)
from scientist.program.goal_graph import (
    DEFAULT_MAX_META_COMPUTE_FRACTION,
    DependencyKind,
    GoalNodeKind,
    GoalNodeRole,
    GoalNodeStatus,
)


FUNCTIONAL_CONTRACTS_VERIFIER_REF = (
    "cognitive-core-functional-contracts-independent-verifier-v9"
)


@dataclass(frozen=True)
class FunctionalContractsVerification:
    check_results: Mapping[str, bool]
    pre_progress: Mapping[str, Mapping[str, float | int]]
    post_progress: Mapping[str, Mapping[str, float | int]]
    ready_work_package_keys: Tuple[str, ...]
    blocked_work_package_keys: Tuple[str, ...]
    first_action_kinds: Mapping[str, str]
    total_experiment_budget: float
    objective_compute_envelope: float
    limitations: Tuple[str, ...]
    verifier_ref: str = FUNCTIONAL_CONTRACTS_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "pre_progress": self.pre_progress,
            "post_progress": self.post_progress,
            "ready_work_package_keys": list(self.ready_work_package_keys),
            "blocked_work_package_keys": list(self.blocked_work_package_keys),
            "first_action_kinds": dict(sorted(self.first_action_kinds.items())),
            "total_experiment_budget": self.total_experiment_budget,
            "objective_compute_envelope": self.objective_compute_envelope,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_functional_contract_registration(
    *,
    control: AutonomousScientistControlPlane,
    architecture: ObjectiveEvidenceArchitecture,
    bundle: FunctionalContractBundle,
    pre_statuses: Mapping[str, GoalNodeStatus],
    pre_progress: Mapping[str, Mapping[str, float | int]],
    pre_compute_spent: float,
    pre_support_edge_ids: Tuple[str, ...],
) -> FunctionalContractsVerification:
    graph = control.graph
    contract_keys = set(bundle.contracts)
    expected_keys = set(architecture.work_packages)
    leaf_ids = {
        key: item.leaf.node_id for key, item in bundle.contracts.items()
    }
    ready_keys = tuple(
        sorted(
            key
            for key, leaf_id in leaf_ids.items()
            if graph.status(leaf_id) == GoalNodeStatus.READY
        )
    )
    blocked_keys = tuple(
        sorted(
            key
            for key, leaf_id in leaf_ids.items()
            if graph.status(leaf_id) == GoalNodeStatus.PROPOSED
            and not graph.requirements_met(leaf_id)
        )
    )
    actions = control.next_actions()
    action_by_node = {item.node_id: item for item in actions}
    first_action_kinds = {
        key: action_by_node[leaf_ids[key]].kind.value
        for key in ready_keys
        if leaf_ids[key] in action_by_node
    }
    support_edge_ids = tuple(
        sorted(
            edge.edge_id
            for edge in graph.dependencies.values()
            if edge.kind == DependencyKind.SUPPORTS
        )
    )
    required_edges = {
        edge.edge_id for edge in bundle.dependencies
    }
    live_required_edges = {
        edge.edge_id
        for edge in graph.dependencies.values()
        if edge.kind == DependencyKind.REQUIRES
        and edge.edge_id in required_edges
    }
    post_progress = graph.progress_by_role()
    objective_envelope = control.goal.total_compute_budget * (
        1.0 - DEFAULT_MAX_META_COMPUTE_FRACTION
    )
    evidence_status_preserved = all(
        graph.status(node_id) == status
        for node_id, status in pre_statuses.items()
        if graph.nodes[node_id].effective_role == GoalNodeRole.EVIDENCE
    )
    active_rules_exact = all(
        graph.active_rule(item.parent_node_id) is not None
        and graph.active_rule(item.parent_node_id).child_ids
        == (item.leaf.node_id,)
        for item in bundle.contracts.values()
    )
    capabilities_covered = {
        item.capability_key for item in bundle.contracts.values()
    } == set(architecture.capabilities)
    checks = {
        "all_eighteen_objective_work_packages_are_covered": (
            contract_keys == expected_keys and len(contract_keys) == 18
        ),
        "all_seven_capabilities_are_covered": capabilities_covered,
        "every_work_package_has_one_active_executable_contract": (
            active_rules_exact
            and all(
                item.leaf.kind == GoalNodeKind.EXECUTABLE_LEAF
                and item.leaf.leaf_contract is not None
                for item in bundle.contracts.values()
            )
        ),
        "contracts_are_explicit_objectives": all(
            item.leaf.role == GoalNodeRole.OBJECTIVE
            and item.leaf.effective_role == GoalNodeRole.OBJECTIVE
            for item in bundle.contracts.values()
        ),
        "contracts_are_mechanism_neutral": all(
            item.mechanism_commitment == "none"
            and item.shared_candidate_required
            for item in bundle.contracts.values()
        ),
        "contracts_freeze_inputs_outputs_protections_and_shortcuts": all(
            item.required_inputs
            and item.observable_outputs
            and item.protected_work_packages
            and item.disallowed_shortcuts
            for item in bundle.contracts.values()
        ),
        "contract_identities_and_metrics_are_unique": (
            len({item.contract_id for item in bundle.contracts.values()}) == 18
            and len(
                {
                    item.leaf.leaf_contract.metric.name
                    for item in bundle.contracts.values()
                    if item.leaf.leaf_contract is not None
                }
            )
            == 18
        ),
        "declared_dependency_dag_is_registered_exactly": (
            live_required_edges == required_edges
            and len(required_edges) == len(bundle.dependencies)
        ),
        "only_wave_one_is_initially_ready": (
            set(ready_keys) == set(bundle.wave_keys[1])
            and set(blocked_keys)
            == contract_keys.difference(bundle.wave_keys[1])
        ),
        "ready_objectives_require_baseline_review_before_search": (
            set(first_action_kinds) == set(ready_keys)
            and all(
                kind == ControlActionKind.SURVEY_LITERATURE.value
                for kind in first_action_kinds.values()
            )
        ),
        "blocked_waves_do_not_consume_actions": all(
            leaf_ids[key] not in action_by_node for key in blocked_keys
        ),
        "contract_budget_fits_reserved_objective_envelope": (
            bundle.total_experiment_budget <= objective_envelope
        ),
        "registration_spent_no_compute": math.isclose(
            control.compute_spent,
            pre_compute_spent,
            rel_tol=0.0,
            abs_tol=1e-12,
        ),
        "historical_evidence_status_and_progress_are_preserved": (
            evidence_status_preserved
            and post_progress["evidence"] == pre_progress["evidence"]
        ),
        "historical_support_edges_are_preserved": (
            support_edge_ids == tuple(sorted(pre_support_edge_ids))
        ),
        "objective_progress_is_not_artificially_advanced": (
            post_progress["objective"]["integrated"]
            == pre_progress["objective"]["integrated"]
            and post_progress["objective"]["total"]
            == pre_progress["objective"]["total"] + 18
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    return FunctionalContractsVerification(
        check_results=checks,
        pre_progress=pre_progress,
        post_progress=post_progress,
        ready_work_package_keys=ready_keys,
        blocked_work_package_keys=blocked_keys,
        first_action_kinds=first_action_kinds,
        total_experiment_budget=bundle.total_experiment_budget,
        objective_compute_envelope=objective_envelope,
        limitations=(
            "These contracts freeze functional completion criteria; they do not implement the shared candidate.",
            "Experiment budgets are ceilings and are not compute reservations or expenditures.",
            "Literature closure and incumbent reconstruction remain Phase 2 work for initially ready leaves.",
        ),
    )
