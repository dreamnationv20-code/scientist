from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.concept_invention_v29 import (
    _diagnostic_counterexample,
    _evaluation_view,
)
from scientist.domains.cognitive_core.general_contract_v27 import (
    CognitiveOperation,
    CognitiveTask,
    EvaluationGates,
    OPERATION_CONTRACTS,
    build_suite,
    compile_predicate,
    parse_answer,
    score_response,
)
from scientist.domains.cognitive_core.internal_core_v28 import (
    _batch_responses,
    aggregate_metrics,
)


FUNCTIONAL_RESIDENCY_VERSION = "general-cognitive-core-functional-residency-v30"
CORE_PROTOCOL = (
    "Use a compact cognitive protocol internally: identify the goal, separate observations from "
    "interventions, choose the minimal sufficient representation, check uncertainty, and route exact "
    "operations to the appropriate tool. Obey the requested ANSWER format."
)


def _records(root: Path, manifest: Mapping[str, Any]) -> Mapping[str, Mapping[str, Any]]:
    envelope = ArtifactStore(root).get(str(manifest["predictions_digest"]))
    return {str(record["task_id"]): record for record in envelope["value"]}


def _feedback(task: CognitiveTask, first_response: str) -> str:
    if task.operation == CognitiveOperation.LATENT_CONCEPT_INVENTION:
        view = _evaluation_view(task)
        counterexample = _diagnostic_counterexample(task, first_response, view.hidden_cases)
        if counterexample is not None:
            row, label = counterexample
            return (
                f"Execution produced a counterexample: x0={row[0]}, x1={row[1]}, x2={row[2]} "
                f"must be {'YES' if label else 'NO'}. Repair the executable predicate."
            )
        return "The predicate is not executable or not uniquely supported. Reconstruct the smallest valid predicate."
    return {
        CognitiveOperation.GOAL_DECOMPOSITION: (
            "The proposed action fails the dependency/recovery validator. Select the permitted next executable action."
        ),
        CognitiveOperation.CAUSAL_DIAGNOSIS: (
            "The selected variable fails the intervention-effect validator. Compare outcome changes under each do-operation."
        ),
        CognitiveOperation.REPRESENTATION_REVISION: (
            "Replay shows that the selected representation class does not explain every visible trajectory. Choose the minimal class that does."
        ),
        CognitiveOperation.TOOL_ROUTING: (
            "The route fails the functional contract. Recheck whether the request needs exact calculation, current retrieval, execution, persistent recall, or no tool."
        ),
        CognitiveOperation.UNCERTAINTY_CONTROL: (
            "The decision violates the unique-best/abstain rule. Recheck the evidence for a tie or a unique maximum."
        ),
    }[task.operation]


def _concept_verifier_failure(task: CognitiveTask, response: str) -> bool:
    """Validate away from every final evaluation case."""
    answer = parse_answer(response)
    if answer is None:
        return True
    try:
        candidate = compile_predicate(answer)
        authority = compile_predicate(task.expected_answer)
    except (SyntaxError, TypeError, ValueError):
        return True
    reserved = set(_evaluation_view(task).hidden_cases)
    for x0 in range(10):
        for x1 in range(10):
            for x2 in range(13):
                row = (x0, x1, x2)
                if row in reserved:
                    continue
                try:
                    if candidate(row) != authority(row):
                        return True
                except (ArithmeticError, OverflowError, ValueError):
                    return True
    return False


def _repair_prompt(
    tokenizer: Any,
    task: CognitiveTask,
    first_response: str,
    feedback: str,
    system_instruction: str,
) -> str:
    messages = []
    if system_instruction:
        messages.append({"role": "system", "content": system_instruction})
    messages.extend(
        (
            {"role": "user", "content": task.prompt},
            {"role": "assistant", "content": first_response},
            {
                "role": "user",
                "content": feedback + " Return exactly one line in the requested ANSWER format.",
            },
        )
    )
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


def run_repair_condition(
    output_root: Path,
    model_path: str,
    first_manifest_path: Path,
    condition: str,
    *,
    adapter_path: Optional[Path] = None,
    system_instruction: str = CORE_PROTOCOL,
    batch_size: int = 6,
    max_tokens: int = 32,
    max_batch_tokens: int = 12000,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if condition not in ("external_runtime", "hybrid"):
        raise ValueError("unsupported repair condition")
    started = time.monotonic()
    first_manifest = json.loads(first_manifest_path.read_text(encoding="utf-8"))
    first_records = _records(output_root, first_manifest)
    tasks = build_suite("test", 24)
    wrong_tasks = []
    for task in tasks:
        response = str(first_records[task.task_id]["response"])
        verifier_failure = (
            _concept_verifier_failure(task, response)
            if task.operation == CognitiveOperation.LATENT_CONCEPT_INVENTION
            else float(score_response(task, response)["score"]) < 1.0
        )
        if verifier_failure:
            wrong_tasks.append(task)
    load_arguments: Dict[str, Any] = {"return_config": True}
    if adapter_path is not None:
        load_arguments["adapter_path"] = str(adapter_path)
    model, tokenizer, model_config = load(model_path, **load_arguments)
    prompts = [
        _repair_prompt(
            tokenizer,
            task,
            str(first_records[task.task_id]["response"]),
            _feedback(task, str(first_records[task.task_id]["response"])),
            system_instruction,
        )
        for task in wrong_tasks
    ]
    repaired_responses, peak_memory = (
        _batch_responses(
            model,
            tokenizer,
            prompts,
            batch_size=batch_size,
            max_tokens=max_tokens,
            max_batch_tokens=max_batch_tokens,
        )
        if prompts
        else ((), 0.0)
    )
    repaired_by_id = {task.task_id: response for task, response in zip(wrong_tasks, repaired_responses)}
    records = []
    for task in tasks:
        first = str(first_records[task.task_id]["response"])
        final = repaired_by_id.get(task.task_id, first)
        records.append(
            {
                "task_id": task.task_id,
                "track": task.track.value,
                "operation": task.operation.value,
                "first_response": first,
                "response": final,
                "feedback": _feedback(task, first) if task.task_id in repaired_by_id else None,
                "tool_calls": int(task.task_id in repaired_by_id),
                "assessment": dict(score_response(task, final)),
            }
        )
    elapsed = time.monotonic() - started
    metrics = aggregate_metrics(condition, tasks, records, elapsed, peak_memory)
    store = ArtifactStore(output_root)
    predictions_digest = store.put("general_cognitive_core_predictions", records)
    payload: Dict[str, Any] = {
        "version": FUNCTIONAL_RESIDENCY_VERSION,
        "condition": condition,
        "model_path": model_path,
        "model_type": str(model_config.get("model_type", "")),
        "adapter_path": str(adapter_path) if adapter_path is not None else None,
        "first_condition": first_manifest["condition"],
        "first_evaluation_id": first_manifest["evaluation_id"],
        "metrics": metrics.as_dict(),
        "verifier_calls": len(wrong_tasks),
        "mean_verifier_calls_per_task": len(wrong_tasks) / len(tasks),
        "maximum_model_calls_per_task": 2,
        "predictions_digest": predictions_digest,
        "feedback_policy": (
            "One objective verifier failure signal and, for executable concepts, one disjoint "
            "counterexample. Concept repair eligibility is determined on an exhaustive diagnostic "
            "grid excluding all final cases. The repair is adopted prospectively without inspecting "
            "final score."
        ),
        "claim_boundary": (
            "Verifier feedback is valid evidence about functional residency, but the benchmark-specific "
            "validators do not constitute a general external cognitive system."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest("general-cognitive-core-" + condition + "-" + evaluation_id, manifest)
    return manifest


def _residence_for_scores(scores: Mapping[str, float]) -> str:
    internal = scores["internal"]
    external = scores["external_runtime"]
    hybrid = scores["hybrid"]
    if hybrid >= max(internal, external) + 0.02:
        return "hybrid"
    if internal >= external + 0.02 and internal >= hybrid - 0.02:
        return "internal"
    if external >= internal + 0.02 and external >= hybrid - 0.02:
        return "external"
    return "ambiguous"


def finalize_residency(
    output_root: Path,
    manifest_paths: Mapping[str, Path],
    gates: EvaluationGates = EvaluationGates(),
) -> Mapping[str, Any]:
    manifests = {
        condition: json.loads(path.read_text(encoding="utf-8"))
        for condition, path in manifest_paths.items()
    }
    required = {"base", "prompted", "external_runtime", "internal", "hybrid"}
    if set(manifests) != required:
        raise ValueError("residency factorial is incomplete")
    scores_by_condition = {
        condition: float(manifest["metrics"]["overall_score"])
        for condition, manifest in manifests.items()
    }
    operation_scores = {
        operation.value: {
            condition: float(manifest["metrics"]["score_by_operation"][operation.value])
            for condition, manifest in manifests.items()
        }
        for operation in CognitiveOperation
    }
    residency_map = {
        operation: _residence_for_scores(scores)
        for operation, scores in operation_scores.items()
    }
    preregistered = {
        contract.operation.value: contract.primary_residence_hypothesis.value
        for contract in OPERATION_CONTRACTS
    }
    checks = {
        "factorial_complete": set(manifests) == required,
        "same_base_model": len({manifest["model_path"] for manifest in manifests.values()}) == 1,
        "external_feedback_improves_prompted": scores_by_condition["external_runtime"] > scores_by_condition["prompted"],
        "hybrid_gain_over_internal": (
            scores_by_condition["hybrid"] - scores_by_condition["internal"]
            >= gates.minimum_hybrid_gain_over_internal
        ),
        "bounded_model_calls": all(
            int(manifests[name]["maximum_model_calls_per_task"]) <= 2
            for name in ("external_runtime", "hybrid")
        ),
    }
    payload: Dict[str, Any] = {
        "version": FUNCTIONAL_RESIDENCY_VERSION,
        "conditions": {key: value["evaluation_id"] for key, value in manifests.items()},
        "scores_by_condition": scores_by_condition,
        "operation_scores": operation_scores,
        "inferred_residency_map": residency_map,
        "preregistered_residency_hypotheses": preregistered,
        "residency_hypothesis_matches": {
            operation: residence == preregistered[operation]
            for operation, residence in residency_map.items()
        },
        "checks": checks,
        "passed": all(checks.values()),
        "claim_boundary": (
            "This is a local functional-residency pilot. A stable residency claim requires naturalistic "
            "tasks, compute-matched tools, other model families, and external replication."
        ),
    }
    trial_id = content_digest(payload)[:20]
    manifest = {**payload, "trial_id": trial_id, "schema": 1}
    ArtifactStore(output_root).write_manifest("general-cognitive-core-residency-v30-" + trial_id, manifest)
    return manifest
