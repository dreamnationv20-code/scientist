from __future__ import annotations

import random
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any, Dict, Mapping, Protocol, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.shared_substrate_v10 import (
    CandidateAction,
    CandidateActionKind,
    CandidateCostLedger,
    CandidateEvent,
    CandidateEventKind,
    CandidateStep,
    ReferenceSharedBaseline,
    SharedCandidateInterfaceContract,
    WAVE_ONE_KEYS,
    reference_shared_baseline,
)


FUNCTIONAL_VERTICAL_SLICE_VERSION = "cognitive-core-functional-vertical-slice-v11"


class SlicePartition(str, Enum):
    DEVELOPMENT = "development"
    CALIBRATION = "calibration"
    AUDIT = "audit"


@dataclass(frozen=True)
class VerticalProbe:
    probe_id: str
    partition: SlicePartition
    episode_id: str
    work_package_key: str
    event_id: str
    expected_kind: CandidateActionKind
    expected_payload: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe_id": self.probe_id,
            "partition": self.partition.value,
            "episode_id": self.episode_id,
            "work_package_key": self.work_package_key,
            "event_id": self.event_id,
            "expected_kind": self.expected_kind.value,
            "expected_payload": dict(self.expected_payload),
        }


@dataclass(frozen=True)
class VerticalEpisode:
    episode_id: str
    partition: SlicePartition
    task_token: str
    surface_token: str
    events: Tuple[CandidateEvent, ...]
    probes: Tuple[VerticalProbe, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "episode_id": self.episode_id,
            "partition": self.partition.value,
            "task_token": self.task_token,
            "surface_token": self.surface_token,
            "events": [item.as_dict() for item in self.events],
            "probes": [item.as_dict() for item in self.probes],
        }


@dataclass(frozen=True)
class VerticalSliceRegistry:
    interface_id: str
    episodes: Tuple[VerticalEpisode, ...]
    cost_envelope: Mapping[str, float]
    frozen_partitions: Tuple[str, ...]
    shortcut_controls: Tuple[str, ...]

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": FUNCTIONAL_VERTICAL_SLICE_VERSION,
            "interface_id": self.interface_id,
            "episodes": [item.as_dict() for item in self.episodes],
            "cost_envelope": dict(sorted(self.cost_envelope.items())),
            "frozen_partitions": list(self.frozen_partitions),
            "shortcut_controls": list(self.shortcut_controls),
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


@dataclass(frozen=True)
class SliceCandidateDescriptor:
    candidate_id: str
    name: str
    executable_digest: str
    role: str
    admissible_for_search: bool
    inadmissibility_reason: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "name": self.name,
            "executable_digest": self.executable_digest,
            "role": self.role,
            "admissible_for_search": self.admissible_for_search,
            "inadmissibility_reason": self.inadmissibility_reason,
        }


@dataclass(frozen=True)
class SliceProbeOutcome:
    probe: VerticalProbe
    observed: CandidateAction
    passed: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe": self.probe.as_dict(),
            "observed": self.observed.as_dict(),
            "passed": self.passed,
        }


@dataclass(frozen=True)
class VerticalCandidateEvaluation:
    candidate: SliceCandidateDescriptor
    registry_id: str
    event_stream_digest: str
    steps: Tuple[CandidateStep, ...]
    outcomes: Tuple[SliceProbeOutcome, ...]
    partition_scores: Mapping[str, Mapping[str, float]]
    functional_gates: Mapping[str, float]
    final_cost: CandidateCostLedger

    @property
    def evaluation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": FUNCTIONAL_VERTICAL_SLICE_VERSION,
            "candidate": self.candidate.as_dict(),
            "registry_id": self.registry_id,
            "event_stream_digest": self.event_stream_digest,
            "steps": [item.as_dict() for item in self.steps],
            "outcomes": [item.as_dict() for item in self.outcomes],
            "partition_scores": {
                partition: dict(sorted(scores.items()))
                for partition, scores in sorted(self.partition_scores.items())
            },
            "functional_gates": dict(sorted(self.functional_gates.items())),
            "joint_gate": float(all(self.functional_gates.values())),
            "final_cost": self.final_cost.as_dict(),
        }
        if include_id:
            value["evaluation_id"] = self.evaluation_id
        return value


@dataclass(frozen=True)
class VerticalSliceExperiment:
    registry: VerticalSliceRegistry
    evaluations: Mapping[str, VerticalCandidateEvaluation]
    baseline_candidate_id: str
    positive_control_candidate_id: str
    memorizer_control_candidate_id: str
    limitations: Tuple[str, ...]

    @property
    def experiment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": FUNCTIONAL_VERTICAL_SLICE_VERSION,
            "registry": self.registry.as_dict(),
            "evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.evaluations.items())
            },
            "baseline_candidate_id": self.baseline_candidate_id,
            "positive_control_candidate_id": self.positive_control_candidate_id,
            "memorizer_control_candidate_id": self.memorizer_control_candidate_id,
            "limitations": list(self.limitations),
        }
        if include_id:
            value["experiment_id"] = self.experiment_id
        return value


class _CandidateRuntime(Protocol):
    cost: CandidateCostLedger

    def act(self, event: CandidateEvent) -> CandidateStep: ...


def make_vertical_episode(
    partition: SlicePartition,
    index: int,
    *,
    modulus: int,
    scale: int,
    shift: int,
) -> VerticalEpisode:
    prefix = "%s-%02d" % (partition.value, index)
    task_token = "task-%s-%x" % (prefix, scale * 31 + shift)
    surface_token = "surface-%s-%x" % (prefix, scale * 17 + shift)
    rule_token = "rule-%s" % prefix
    other_task = "distractor-task-%s" % prefix
    other_rule = "distractor-rule-%s" % prefix
    demos_x = (2, 5, 7)
    demonstrations = [
        {"operands": [x], "output": (scale * x + shift) % modulus}
        for x in demos_x
    ]
    explicit_x = 4
    query_x = 9
    post_update_x = 6
    new_shift = (shift + 3) % modulus
    evidence = [
        {
            "evidence_id": "%s-link" % prefix,
            "subject": task_token,
            "relation": "governed_by",
            "object": rule_token,
        },
        {
            "evidence_id": "%s-scale" % prefix,
            "subject": rule_token,
            "relation": "scale",
            "object": scale,
        },
        {
            "evidence_id": "%s-shift" % prefix,
            "subject": rule_token,
            "relation": "shift",
            "object": shift,
        },
        {
            "evidence_id": "%s-distractor-link" % prefix,
            "subject": other_task,
            "relation": "governed_by",
            "object": other_rule,
        },
        {
            "evidence_id": "%s-distractor-scale" % prefix,
            "subject": other_rule,
            "relation": "scale",
            "object": (scale + 1) % modulus,
        },
        {
            "evidence_id": "%s-protected" % prefix,
            "subject": "protected-state-%s" % prefix,
            "relation": "must_preserve",
            "object": "stable",
        },
    ]
    events = (
        CandidateEvent(
            "%s-procedure" % prefix,
            CandidateEventKind.EXECUTE_PROCEDURE,
            {
                "operation": "affine::%s" % surface_token,
                "operands": [explicit_x],
                "procedure_spec": {
                    "operator": "affine_mod",
                    "modulus": modulus,
                    "scale": scale,
                    "shift": shift,
                    "surface_token": surface_token,
                },
            },
        ),
        CandidateEvent(
            "%s-demonstrations" % prefix,
            CandidateEventKind.OBSERVE_DEMONSTRATIONS,
            {
                "task_token": task_token,
                "modulus": modulus,
                "demonstrations": demonstrations,
            },
        ),
        CandidateEvent(
            "%s-task-query" % prefix,
            CandidateEventKind.ANSWER_TASK,
            {"task_token": task_token, "operands": [query_x]},
        ),
        CandidateEvent(
            "%s-relevance" % prefix,
            CandidateEventKind.SELECT_RELEVANCE,
            {
                "query_target": task_token,
                "relation_path": ["governed_by", "scale|shift"],
                "evidence": evidence,
            },
        ),
        CandidateEvent(
            "%s-update" % prefix,
            CandidateEventKind.REQUEST_UPDATE,
            {
                "key": "task::%s::shift" % task_token,
                "value": str(new_shift),
                "task_token": task_token,
                "field": "shift",
            },
        ),
        CandidateEvent(
            "%s-post-update-query" % prefix,
            CandidateEventKind.ANSWER_TASK,
            {"task_token": task_token, "operands": [post_update_x]},
        ),
    )
    probe_specs = (
        (
            "procedure_representation",
            events[0],
            CandidateActionKind.PROCEDURE_RESULT,
            {"value": (scale * explicit_x + shift) % modulus},
        ),
        (
            "task_inference",
            events[2],
            CandidateActionKind.TASK_RESULT,
            {"value": (scale * query_x + shift) % modulus},
        ),
        (
            "relevance_representation",
            events[3],
            CandidateActionKind.RELEVANCE_SELECTION,
            {
                "evidence_ids": [
                    "%s-link" % prefix,
                    "%s-scale" % prefix,
                    "%s-shift" % prefix,
                ]
            },
        ),
        (
            "requested_change",
            events[4],
            CandidateActionKind.UPDATE_ACKNOWLEDGEMENT,
            {
                "key": "task::%s::shift" % task_token,
                "stored": str(new_shift),
            },
        ),
        (
            "requested_change",
            events[5],
            CandidateActionKind.TASK_RESULT,
            {"value": (scale * post_update_x + new_shift) % modulus},
        ),
    )
    probes = tuple(
        VerticalProbe(
            probe_id="%s-probe-%s-%d" % (prefix, key, order),
            partition=partition,
            episode_id=prefix,
            work_package_key=key,
            event_id=event.event_id,
            expected_kind=kind,
            expected_payload=payload,
        )
        for order, (key, event, kind, payload) in enumerate(probe_specs)
    )
    return VerticalEpisode(
        episode_id=prefix,
        partition=partition,
        task_token=task_token,
        surface_token=surface_token,
        events=events,
        probes=probes,
    )


def build_vertical_slice_registry(
    interface: SharedCandidateInterfaceContract,
) -> VerticalSliceRegistry:
    partition_specs = {
        SlicePartition.DEVELOPMENT: (11, 1103),
        SlicePartition.CALIBRATION: (13, 1307),
        SlicePartition.AUDIT: (17, 1709),
    }
    episodes = []
    for partition, (modulus, seed) in partition_specs.items():
        randomizer = random.Random(seed)
        pairs = []
        while len(pairs) < 4:
            pair = (
                randomizer.randrange(1, modulus),
                randomizer.randrange(0, modulus),
            )
            if pair not in pairs:
                pairs.append(pair)
        episodes.extend(
            make_vertical_episode(
                partition,
                index,
                modulus=modulus,
                scale=scale,
                shift=shift,
            )
            for index, (scale, shift) in enumerate(pairs)
        )
    return VerticalSliceRegistry(
        interface_id=interface.interface_id,
        episodes=tuple(episodes),
        cost_envelope={
            "parameter_count": 0.0,
            "training_compute_flops": 0.0,
            "training_examples": 0.0,
            "inference_events": 72.0,
            "primitive_operations": 50000.0,
            "context_tokens": 10000.0,
            "persistent_memory_slots": 100.0,
            "retrieval_calls": 24.0,
            "adaptation_writes": 100.0,
            "external_service_calls": 0.0,
        },
        frozen_partitions=tuple(item.value for item in SlicePartition),
        shortcut_controls=(
            "task, surface, evidence, episode, and modulus families are disjoint across partitions",
            "expected actions are evaluator-side and absent from candidate event payloads",
            "one runtime persists through all episodes without per-probe reset",
            "a development-event memorizer must fail calibration and audit",
            "a generator-aware solver is a positive control and is ineligible for search adoption",
        ),
    )


class GeneratorAwarePositiveControl:
    def __init__(self, interface_id: str) -> None:
        self.descriptor = SliceCandidateDescriptor(
            candidate_id=content_digest(
                {"version": FUNCTIONAL_VERTICAL_SLICE_VERSION, "control": "oracle"}
            ),
            name="Generator-aware algebraic positive control",
            executable_digest=content_digest(
                {"runtime": "GeneratorAwarePositiveControl", "interface_id": interface_id}
            ),
            role="positive_control",
            admissible_for_search=False,
            inadmissibility_reason=(
                "hard-coded knowledge of the evaluator's affine generator and evidence schema"
            ),
        )
        self.models: Dict[str, Tuple[int, int, int]] = {}
        self.updates: Dict[Tuple[str, str], int] = {}
        self.cost = CandidateCostLedger()

    def _state_id(self) -> str:
        return content_digest(
            {
                "models": {key: list(value) for key, value in sorted(self.models.items())},
                "updates": {
                    "%s:%s" % key: value for key, value in sorted(self.updates.items())
                },
            }
        )

    def act(self, event: CandidateEvent) -> CandidateStep:
        before_id = self._state_id()
        before_cost = self.cost
        payload = event.payload
        operations = 1
        retrievals = 0
        writes = 0
        if event.kind == CandidateEventKind.EXECUTE_PROCEDURE:
            spec = payload["procedure_spec"]
            x = int(payload["operands"][0])
            value = (
                int(spec["scale"]) * x + int(spec["shift"])
            ) % int(spec["modulus"])
            action = CandidateAction(
                CandidateActionKind.PROCEDURE_RESULT, {"value": value}
            )
            operations = 3
        elif event.kind == CandidateEventKind.OBSERVE_DEMONSTRATIONS:
            target = str(payload["task_token"])
            modulus = int(payload["modulus"])
            demos = payload["demonstrations"]
            matches = []
            for scale in range(modulus):
                for shift in range(modulus):
                    if all(
                        (scale * int(row["operands"][0]) + shift) % modulus
                        == int(row["output"])
                        for row in demos
                    ):
                        matches.append((modulus, scale, shift))
            if len(matches) != 1:
                action = CandidateAction(
                    CandidateActionKind.ABSTAIN,
                    {"reason": "task is not uniquely identifiable"},
                )
            else:
                self.models[target] = matches[0]
                writes = 1
                action = CandidateAction(
                    CandidateActionKind.DEMONSTRATIONS_STORED,
                    {"count": len(demos)},
                )
            operations = modulus * modulus * len(demos)
        elif event.kind == CandidateEventKind.ANSWER_TASK:
            target = str(payload["task_token"])
            if target not in self.models:
                action = CandidateAction(
                    CandidateActionKind.ABSTAIN,
                    {"reason": "task not inferred"},
                )
            else:
                modulus, scale, shift = self.models[target]
                shift = self.updates.get((target, "shift"), shift)
                x = int(payload["operands"][0])
                action = CandidateAction(
                    CandidateActionKind.TASK_RESULT,
                    {"value": (scale * x + shift) % modulus},
                )
                operations = 3
        elif event.kind == CandidateEventKind.SELECT_RELEVANCE:
            target = str(payload["query_target"])
            evidence = payload["evidence"]
            rule_ids = {
                str(row["object"])
                for row in evidence
                if row["subject"] == target and row["relation"] == "governed_by"
            }
            selected = [
                str(row["evidence_id"])
                for row in evidence
                if (
                    row["subject"] == target
                    and row["relation"] == "governed_by"
                )
                or (
                    row["subject"] in rule_ids
                    and row["relation"] in ("scale", "shift")
                )
            ]
            action = CandidateAction(
                CandidateActionKind.RELEVANCE_SELECTION,
                {"evidence_ids": selected},
            )
            retrievals = 1
            operations = len(evidence) * 2
        elif event.kind == CandidateEventKind.REQUEST_UPDATE:
            target = str(payload["task_token"])
            field = str(payload["field"])
            value = int(payload["value"])
            self.updates[(target, field)] = value
            writes = 1
            action = CandidateAction(
                CandidateActionKind.UPDATE_ACKNOWLEDGEMENT,
                {"key": str(payload["key"]), "stored": str(value)},
            )
        else:  # pragma: no cover - the registry uses no other event kind
            action = CandidateAction(
                CandidateActionKind.ABSTAIN,
                {"reason": "unsupported event"},
            )
        self.cost = replace(
            self.cost,
            inference_events=self.cost.inference_events + 1,
            primitive_operations=self.cost.primitive_operations + operations,
            context_tokens=self.cost.context_tokens + len(str(dict(payload)).split()),
            persistent_memory_slots=len(self.models) + len(self.updates),
            retrieval_calls=self.cost.retrieval_calls + retrievals,
            adaptation_writes=self.cost.adaptation_writes + writes,
        )
        return CandidateStep(
            event=event,
            action=action,
            state_before_id=before_id,
            state_after_id=self._state_id(),
            cost_before=before_cost,
            cost_after=self.cost,
        )


class DevelopmentEventMemorizer:
    def __init__(
        self,
        registry: VerticalSliceRegistry,
    ) -> None:
        self.descriptor = SliceCandidateDescriptor(
            candidate_id=content_digest(
                {"version": FUNCTIONAL_VERTICAL_SLICE_VERSION, "control": "memorizer"}
            ),
            name="Development event-ID memorizer control",
            executable_digest=content_digest(
                {"runtime": "DevelopmentEventMemorizer", "registry_id": registry.registry_id}
            ),
            role="shortcut_control",
            admissible_for_search=False,
            inadmissibility_reason="looks up evaluator event IDs and has no transferable mechanism",
        )
        self.lookup = {
            probe.event_id: CandidateAction(probe.expected_kind, probe.expected_payload)
            for episode in registry.episodes
            if episode.partition == SlicePartition.DEVELOPMENT
            for probe in episode.probes
        }
        self.counter = 0
        self.cost = CandidateCostLedger()

    def _state_id(self) -> str:
        return content_digest({"counter": self.counter})

    def act(self, event: CandidateEvent) -> CandidateStep:
        before_id = self._state_id()
        before_cost = self.cost
        if event.event_id in self.lookup:
            action = self.lookup[event.event_id]
        elif event.kind == CandidateEventKind.OBSERVE_DEMONSTRATIONS:
            action = CandidateAction(
                CandidateActionKind.DEMONSTRATIONS_STORED,
                {"count": len(event.payload["demonstrations"])},
            )
        else:
            action = CandidateAction(
                CandidateActionKind.ABSTAIN,
                {"reason": "unmemorized event ID"},
            )
        self.counter += 1
        self.cost = replace(
            self.cost,
            inference_events=self.cost.inference_events + 1,
            primitive_operations=self.cost.primitive_operations + 1,
            context_tokens=self.cost.context_tokens + len(str(dict(event.payload)).split()),
            persistent_memory_slots=len(self.lookup),
        )
        return CandidateStep(
            event=event,
            action=action,
            state_before_id=before_id,
            state_after_id=self._state_id(),
            cost_before=before_cost,
            cost_after=self.cost,
        )


def evaluate_vertical_candidate(
    runtime: _CandidateRuntime,
    descriptor: SliceCandidateDescriptor,
    registry: VerticalSliceRegistry,
) -> VerticalCandidateEvaluation:
    events = tuple(event for episode in registry.episodes for event in episode.events)
    probes = tuple(probe for episode in registry.episodes for probe in episode.probes)
    steps = tuple(runtime.act(event) for event in events)
    action_by_event = {step.event.event_id: step.action for step in steps}
    outcomes = tuple(
        SliceProbeOutcome(
            probe=probe,
            observed=action_by_event[probe.event_id],
            passed=(
                action_by_event[probe.event_id].kind == probe.expected_kind
                and action_by_event[probe.event_id].payload == probe.expected_payload
            ),
        )
        for probe in probes
    )
    partition_scores: Dict[str, Dict[str, float]] = {}
    for partition in SlicePartition:
        partition_scores[partition.value] = {}
        for key in WAVE_ONE_KEYS:
            if key == "system_cost":
                continue
            rows = tuple(
                item
                for item in outcomes
                if item.probe.partition == partition
                and item.probe.work_package_key == key
            )
            partition_scores[partition.value][key] = (
                sum(item.passed for item in rows) / len(rows)
            )
    cost_passed = all(
        runtime.cost.as_dict()[key] <= limit
        for key, limit in registry.cost_envelope.items()
    ) and all(value >= 0 for value in runtime.cost.as_dict().values())
    for partition in SlicePartition:
        partition_scores[partition.value]["system_cost"] = float(cost_passed)
    gates = {
        key: float(
            partition_scores[SlicePartition.CALIBRATION.value][key] == 1.0
            and partition_scores[SlicePartition.AUDIT.value][key] == 1.0
        )
        for key in WAVE_ONE_KEYS
    }
    return VerticalCandidateEvaluation(
        candidate=descriptor,
        registry_id=registry.registry_id,
        event_stream_digest=content_digest([event.as_dict() for event in events]),
        steps=steps,
        outcomes=outcomes,
        partition_scores=partition_scores,
        functional_gates=gates,
        final_cost=runtime.cost,
    )


def run_vertical_slice_experiment(
    interface: SharedCandidateInterfaceContract,
) -> VerticalSliceExperiment:
    registry = build_vertical_slice_registry(interface)
    baseline_spec = reference_shared_baseline(interface)
    baseline_descriptor = SliceCandidateDescriptor(
        candidate_id=baseline_spec.candidate_id,
        name=baseline_spec.name,
        executable_digest=baseline_spec.executable_digest,
        role="registered_incumbent",
        admissible_for_search=True,
    )
    positive_runtime = GeneratorAwarePositiveControl(interface.interface_id)
    memorizer_runtime = DevelopmentEventMemorizer(registry)
    evaluations = {
        "baseline": evaluate_vertical_candidate(
            ReferenceSharedBaseline(baseline_spec),
            baseline_descriptor,
            registry,
        ),
        "positive_control": evaluate_vertical_candidate(
            positive_runtime,
            positive_runtime.descriptor,
            registry,
        ),
        "memorizer_control": evaluate_vertical_candidate(
            memorizer_runtime,
            memorizer_runtime.descriptor,
            registry,
        ),
    }
    return VerticalSliceExperiment(
        registry=registry,
        evaluations=evaluations,
        baseline_candidate_id=baseline_descriptor.candidate_id,
        positive_control_candidate_id=positive_runtime.descriptor.candidate_id,
        memorizer_control_candidate_id=memorizer_runtime.descriptor.candidate_id,
        limitations=(
            "The slice is a controlled symbolic microdomain, not evidence of broad cognitive competence.",
            "The positive control proves evaluator solvability but is generator-aware and cannot be adopted as a scientific candidate.",
            "Phase 3 diagnoses the registered baseline; mechanism invention and candidate improvement begin only in Phase 4.",
        ),
    )
