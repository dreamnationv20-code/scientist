from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.functional_vertical_slice_v11 import (
    SlicePartition,
    VerticalSliceExperiment,
)
from scientist.domains.cognitive_core.shared_substrate_v10 import (
    CandidateCostLedger,
    WAVE_ONE_KEYS,
)
from scientist.program.control_plane import (
    AutonomousScientistControlPlane,
    ControlActionKind,
)


FUNCTIONAL_VERTICAL_SLICE_VERIFIER_REF = (
    "cognitive-core-functional-vertical-slice-independent-verifier-v11"
)


@dataclass(frozen=True)
class FunctionalVerticalSliceVerification:
    check_results: Mapping[str, bool]
    registry_id: str
    experiment_id: str
    baseline_functional_gates: Mapping[str, float]
    positive_control_functional_gates: Mapping[str, float]
    memorizer_control_functional_gates: Mapping[str, float]
    baseline_audit_scores: Mapping[str, float]
    limitations: Tuple[str, ...]
    verifier_ref: str = FUNCTIONAL_VERTICAL_SLICE_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "registry_id": self.registry_id,
            "experiment_id": self.experiment_id,
            "baseline_functional_gates": dict(
                sorted(self.baseline_functional_gates.items())
            ),
            "positive_control_functional_gates": dict(
                sorted(self.positive_control_functional_gates.items())
            ),
            "memorizer_control_functional_gates": dict(
                sorted(self.memorizer_control_functional_gates.items())
            ),
            "baseline_audit_scores": dict(
                sorted(self.baseline_audit_scores.items())
            ),
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _contains_forbidden_answer_key(value: Any) -> bool:
    forbidden = {"expected", "expected_answer", "correct", "oracle_answer"}
    if isinstance(value, Mapping):
        return bool(forbidden.intersection(value)) or any(
            _contains_forbidden_answer_key(item) for item in value.values()
        )
    if isinstance(value, (list, tuple)):
        return any(_contains_forbidden_answer_key(item) for item in value)
    return False


def verify_functional_vertical_slice(
    *,
    control: AutonomousScientistControlPlane,
    experiment: VerticalSliceExperiment,
    replay: VerticalSliceExperiment,
    phase_two_manifest: Mapping[str, Any],
) -> FunctionalVerticalSliceVerification:
    registry = experiment.registry
    baseline = experiment.evaluations["baseline"]
    positive = experiment.evaluations["positive_control"]
    memorizer = experiment.evaluations["memorizer_control"]
    partition_episode_ids = {
        partition.value: {
            episode.episode_id
            for episode in registry.episodes
            if episode.partition == partition
        }
        for partition in SlicePartition
    }
    partition_task_ids = {
        partition.value: {
            episode.task_token
            for episode in registry.episodes
            if episode.partition == partition
        }
        for partition in SlicePartition
    }
    partition_event_ids = {
        partition.value: {
            event.event_id
            for episode in registry.episodes
            if episode.partition == partition
            for event in episode.events
        }
        for partition in SlicePartition
    }
    pairwise_disjoint = all(
        not values.intersection(other)
        for index, values in enumerate(partition_event_ids.values())
        for other in tuple(partition_event_ids.values())[index + 1 :]
    ) and all(
        not values.intersection(other)
        for index, values in enumerate(partition_task_ids.values())
        for other in tuple(partition_task_ids.values())[index + 1 :]
    )
    stream_digests = {
        item.event_stream_digest for item in experiment.evaluations.values()
    }
    state_chains = {
        key: all(
            left.state_after_id == right.state_before_id
            and left.cost_after == right.cost_before
            for left, right in zip(item.steps, item.steps[1:])
        )
        for key, item in experiment.evaluations.items()
    }
    expected_cost_dimensions = set(CandidateCostLedger().as_dict())
    cost_ledgers_valid = all(
        set(item.final_cost.as_dict()) == expected_cost_dimensions
        and all(value >= 0 for value in item.final_cost.as_dict().values())
        and all(
            item.final_cost.as_dict()[name] <= limit
            for name, limit in registry.cost_envelope.items()
        )
        for item in experiment.evaluations.values()
    )
    action_by_node = {
        item.node_id: item.kind for item in control.next_actions()
    }
    # The manifest maps work package to assessment ID, so recover leaf IDs from
    # the registered portfolio rows instead of treating those IDs as nodes.
    control_value = control.as_dict()
    current_portfolio_ids = control_value["current_portfolio_ids"]
    registered_primary_ids = set()
    registered_leaf_ids = set()
    portfolio_by_id = {
        item["portfolio_id"]: item
        for item in control_value["incumbent_portfolios"]
    }
    for leaf_id, portfolio_id in current_portfolio_ids.items():
        portfolio = portfolio_by_id[portfolio_id]
        if portfolio["primary_incumbent_id"] == experiment.baseline_candidate_id:
            registered_leaf_ids.add(leaf_id)
            registered_primary_ids.add(portfolio["primary_incumbent_id"])
    wave_one_leaf_ids = registered_leaf_ids
    progress = control.graph.progress_by_role()
    baseline_expected_gates = {
        "procedure_representation": 0.0,
        "relevance_representation": 0.0,
        "requested_change": 0.0,
        "system_cost": 1.0,
        "task_inference": 0.0,
    }
    checks = {
        "phase_two_source_manifest_passed": bool(phase_two_manifest.get("passed")),
        "registry_has_four_episodes_in_each_disjoint_partition": (
            len(registry.episodes) == 12
            and all(len(ids) == 4 for ids in partition_episode_ids.values())
            and pairwise_disjoint
        ),
        "all_five_wave_one_work_packages_are_scored": all(
            set(item.functional_gates) == set(WAVE_ONE_KEYS)
            for item in experiment.evaluations.values()
        ),
        "candidate_inputs_exclude_evaluator_answers": all(
            not _contains_forbidden_answer_key(event.payload)
            for episode in registry.episodes
            for event in episode.events
        ),
        "all_candidates_receive_the_identical_event_stream": (
            len(stream_digests) == 1
            and all(len(item.steps) == 72 for item in experiment.evaluations.values())
        ),
        "every_candidate_uses_one_continuous_state_and_cost_chain": all(
            state_chains.values()
        ),
        "cost_ledgers_are_complete_nonnegative_and_within_envelope": (
            cost_ledgers_valid
        ),
        "registered_baseline_identity_matches_phase_two_everywhere": (
            experiment.baseline_candidate_id == phase_two_manifest["candidate_id"]
            and baseline.candidate.executable_digest
            == phase_two_manifest["candidate_executable_digest"]
            and registered_primary_ids == {experiment.baseline_candidate_id}
            and len(wave_one_leaf_ids) == 5
        ),
        "baseline_residual_profile_is_reconstructed_without_false_progress": (
            baseline.functional_gates == baseline_expected_gates
            and all(
                baseline.partition_scores[partition.value]["requested_change"]
                == 0.5
                for partition in SlicePartition
            )
            and all(
                baseline.partition_scores[SlicePartition.AUDIT.value][key] == 0.0
                for key in (
                    "procedure_representation",
                    "relevance_representation",
                    "task_inference",
                )
            )
        ),
        "generator_aware_positive_control_proves_slice_is_solvable": (
            all(value == 1.0 for value in positive.functional_gates.values())
            and not positive.candidate.admissible_for_search
            and bool(positive.candidate.inadmissibility_reason)
        ),
        "development_memorizer_is_rejected_by_heldout_partitions": (
            all(
                memorizer.partition_scores[SlicePartition.DEVELOPMENT.value][key]
                == 1.0
                for key in WAVE_ONE_KEYS
            )
            and all(
                memorizer.partition_scores[SlicePartition.CALIBRATION.value][key]
                == 0.0
                for key in WAVE_ONE_KEYS
                if key != "system_cost"
            )
            and all(
                memorizer.partition_scores[SlicePartition.AUDIT.value][key] == 0.0
                for key in WAVE_ONE_KEYS
                if key != "system_cost"
            )
            and not memorizer.candidate.admissible_for_search
        ),
        "experiment_replay_is_content_identical": (
            experiment.experiment_id == replay.experiment_id
        ),
        "control_plane_remains_ready_without_campaign_or_objective_claim": (
            len(wave_one_leaf_ids) == 5
            and all(
                action_by_node.get(leaf_id) == ControlActionKind.START_CAMPAIGN
                for leaf_id in wave_one_leaf_ids
            )
            and not control_value["campaigns"]
            and progress == phase_two_manifest["post_progress"]
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    return FunctionalVerticalSliceVerification(
        check_results=checks,
        registry_id=registry.registry_id,
        experiment_id=experiment.experiment_id,
        baseline_functional_gates=baseline.functional_gates,
        positive_control_functional_gates=positive.functional_gates,
        memorizer_control_functional_gates=memorizer.functional_gates,
        baseline_audit_scores=baseline.partition_scores[
            SlicePartition.AUDIT.value
        ],
        limitations=(
            "Passing controls validate the evaluator, not the cognitive-core objective.",
            "The incumbent passes only the cost gate and remains scientifically unimproved.",
            "The first causal contrasts are now available, but no latent mechanism has yet been invented or tested.",
        ),
    )
