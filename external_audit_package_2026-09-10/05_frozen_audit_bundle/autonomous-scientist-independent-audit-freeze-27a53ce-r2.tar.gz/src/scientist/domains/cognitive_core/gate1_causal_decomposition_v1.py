from __future__ import annotations

import hashlib
import json
import math
import random
import re
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from scientist.core.artifacts import content_digest


# Protocols v1/v2 were response-channel preflights and are excluded from
# scientific analysis. V3 preserves scratch work, tolerates Markdown around the
# terminal marker, and stops as soon as the completed answer line is emitted.
# Task seeds, labels, interventions, gates, and model contracts never changed.
VERSION = "cognitive-core-gate1-causal-decomposition-v3"
SEED = 551_001
FAMILIES = (
    "obfuscated_planning",
    "novel_rule_induction",
    "counterfactual_causal",
    "stateful_tool_workflow",
    "evidence_grounding",
)
INTERVENTIONS = ("raw", "state", "dynamics", "actions", "verifier", "evidence")
ITEMS_PER_FAMILY = 8
TASK_COUNT = ITEMS_PER_FAMILY * len(FAMILIES)
MAXIMUM_NEW_TOKENS = 768

MODEL_CONTRACT = (
    {
        "key": "qwen3_1p7b",
        "repository": "Qwen/Qwen3-1.7B-MLX-4bit",
        "revision": "21457c6f51ed54a7c16e988c0844db973815c137",
        "parameters_billions": 1.7,
        "execution": "local",
    },
    {
        "key": "qwen3_4b",
        "repository": "Qwen/Qwen3-4B-MLX-4bit",
        "revision": "52a5ab34fa604bc8af6d3ce0cac0cab10b7eb495",
        "parameters_billions": 4.0,
        "execution": "local",
    },
    {
        "key": "qwen3_8b",
        "repository": "Qwen/Qwen3-8B-MLX-4bit",
        "revision": "383413e909f3bc5303ce195ebbdf0339c5a1a2a3",
        "parameters_billions": 8.2,
        "execution": "local",
    },
    {
        "key": "ouro_1p4b",
        "repository": "ByteDance/Ouro-1.4B",
        "revision": "external-freeze-required",
        "parameters_billions": 1.4,
        "execution": "external_recurrent_baseline",
    },
    {
        "key": "qwen_72b_reference",
        "repository": "mlx-community/Qwen2.5-72B-Instruct-4bit",
        "revision": "36a74b07390031bb18c9f12fb7c06699bc6273c4",
        "parameters_billions": 72.0,
        "execution": "external_required",
    },
)


@dataclass(frozen=True)
class GateTask:
    task_id: str
    family: str
    raw_prompt: str
    interventions: Mapping[str, str]
    authority: Mapping[str, Any]

    def public_dict(self) -> Mapping[str, Any]:
        prompts = {"raw": self.raw_prompt}
        prompts.update(
            {
                name: self.raw_prompt + "\n\nORACLE INTERVENTION (not the answer):\n" + text
                for name, text in self.interventions.items()
            }
        )
        return {
            "task_id": self.task_id,
            "family": self.family,
            "prompts": prompts,
            "maximum_new_tokens": MAXIMUM_NEW_TOKENS,
        }

    def authority_dict(self) -> Mapping[str, Any]:
        return {**self.public_dict(), "authority": dict(self.authority)}


def _jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _read_jsonl(path: Path) -> list[Mapping[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _write_immutable(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite frozen Gate 1 artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")


def _finish(instruction: str) -> str:
    return (
        instruction
        + "\nReason briefly (at most 12 short lines). Your last output line must be exactly "
        "`FINAL: <answer>`. Do not write anything after the FINAL line."
    )


def _choice_aliases(rng: random.Random, count: int, prefix: str) -> list[str]:
    values = list(range(100, 999))
    rng.shuffle(values)
    return [f"{prefix}{value}" for value in values[:count]]


def _shortest_path(
    start: str, goal: str, edges: Sequence[tuple[str, str, str]]
) -> tuple[str, ...]:
    queue: deque[tuple[str, tuple[str, ...]]] = deque([(start, ())])
    seen = {start}
    by_source: dict[str, list[tuple[str, str]]] = {}
    for source, target, action in edges:
        by_source.setdefault(source, []).append((target, action))
    while queue:
        node, actions = queue.popleft()
        if node == goal:
            return actions
        for target, action in by_source.get(node, ()):
            if target not in seen:
                seen.add(target)
                queue.append((target, (*actions, action)))
    raise ValueError("unreachable planning goal")


def _planning_task(index: int, rng: random.Random) -> GateTask:
    nodes = _choice_aliases(rng, 7, "sector-")
    actions = _choice_aliases(rng, 10, "op-")
    start, goal = nodes[0], nodes[4]
    # The first chain is uniquely shortest. Later edges are legal distractors.
    edges = [
        (nodes[0], nodes[1], actions[0]),
        (nodes[1], nodes[4], actions[1]),
        (nodes[0], nodes[2], actions[2]),
        (nodes[2], nodes[3], actions[3]),
        (nodes[3], nodes[4], actions[4]),
        (nodes[1], nodes[5], actions[5]),
        (nodes[5], nodes[6], actions[6]),
        (nodes[6], nodes[4], actions[7]),
        (nodes[2], nodes[6], actions[8]),
    ]
    rng.shuffle(edges)
    path = _shortest_path(start, goal, edges)
    decoy = _shortest_path(nodes[2], goal, edges)
    prose = [
        f"Operation {action} can be used only in {source}; it leaves the agent in {target}."
        for source, target, action in edges
    ]
    raw = _finish(
        "An agent is in an unfamiliar transition system. "
        f"It starts in {start} and must reach {goal} in the fewest operations.\n"
        + "\n".join(prose)
        + "\nWhich operation must it execute first? Return only the operation label."
    )
    legal = sorted(action for source, _, action in edges if source == start)
    relevant_nodes = {start, goal, nodes[1], nodes[2], nodes[3]}
    relevant = [edge for edge in edges if edge[0] in relevant_nodes and edge[1] in relevant_nodes]
    return GateTask(
        f"g1-plan-{index:02d}",
        "obfuscated_planning",
        raw,
        {
            "state": f"Canonical parsed state: current={start}; goal={goal}.",
            "dynamics": "Canonical transition triples (source, operation, destination): "
            + json.dumps(edges),
            "actions": "The legal first operations are " + json.dumps(legal) + ".",
            "verifier": (
                "A proposed route beginning "
                + json.dumps(list(decoy))
                + f" is invalid from {start}: its first operation is not enabled there."
            ),
            "evidence": "Only transitions on potentially competitive routes: "
            + json.dumps(relevant),
        },
        {"answer": path[0], "shortest_path": list(path), "legal_first": legal},
    )


def _apply_rule(sequence: Sequence[str], rule: str, amount: int) -> list[str]:
    values = list(sequence)
    if rule == "rotate_left":
        return values[amount:] + values[:amount]
    if rule == "rotate_right":
        return values[-amount:] + values[:-amount]
    if rule == "reverse_then_rotate":
        values.reverse()
        return values[amount:] + values[:amount]
    if rule == "odd_then_even":
        return values[::2] + values[1::2]
    if rule == "swap_pairs":
        result = values[:]
        for i in range(0, len(result) - 1, 2):
            result[i], result[i + 1] = result[i + 1], result[i]
        return result
    raise ValueError(rule)


def _rule_task(index: int, rng: random.Random) -> GateTask:
    alphabet = _choice_aliases(rng, 8, "glyph-")
    rule = rng.choice(
        ["rotate_left", "rotate_right", "reverse_then_rotate", "odd_then_even", "swap_pairs"]
    )
    amount = rng.choice((1, 2))
    demos = []
    for length in (4, 5, 6, 7):
        source = rng.sample(alphabet, length)
        demos.append((source, _apply_rule(source, rule, amount)))
    query = rng.sample(alphabet, 7)
    answer = _apply_rule(query, rule, amount)
    raw = _finish(
        "Infer the single deterministic sequence rule called VESPER from demonstrations, "
        "then apply it to the query. Return the output as a comma-separated glyph sequence.\n"
        + "\n".join(
            f"VESPER({','.join(source)}) -> {','.join(target)}" for source, target in demos
        )
        + f"\nQuery: VESPER({','.join(query)})"
    )
    candidates = [answer]
    for alternative, alternate_amount in (
        ("rotate_left", 1),
        ("rotate_right", 1),
        ("odd_then_even", 1),
        ("swap_pairs", 1),
    ):
        value = _apply_rule(query, alternative, alternate_amount)
        if value not in candidates:
            candidates.append(value)
    rng.shuffle(candidates)
    decoy = list(reversed(query))
    return GateTask(
        f"g1-rule-{index:02d}",
        "novel_rule_induction",
        raw,
        {
            "state": "Parsed query sequence with positions: "
            + json.dumps(list(enumerate(query))),
            "dynamics": f"Induced operator schema: {rule}(amount={amount}). Apply it; no output is supplied.",
            "actions": "Type-correct candidate outputs: "
            + json.dumps([",".join(value) for value in candidates]),
            "verifier": (
                "The candidate "
                + ",".join(decoy)
                + " fails at least one demonstration under a single position-preserving permutation."
            ),
            "evidence": "The two most length-diverse demonstrations are: "
            + json.dumps([demos[0], demos[-1]]),
        },
        {"answer": ",".join(answer), "rule": rule, "amount": amount},
    )


def _bool_eval(op: str, parents: Sequence[bool]) -> bool:
    if op == "NOT":
        return not parents[0]
    if op == "AND":
        return parents[0] and parents[1]
    if op == "OR":
        return parents[0] or parents[1]
    if op == "XOR":
        return parents[0] != parents[1]
    raise ValueError(op)


def _causal_task(index: int, rng: random.Random) -> GateTask:
    variables = _choice_aliases(rng, 6, "unit-")
    a, b, c, d, e, irrelevant = variables
    exogenous = {a: rng.choice((False, True)), b: rng.choice((False, True))}
    operations = [
        (c, rng.choice(("AND", "OR", "XOR")), (a, b)),
        (d, rng.choice(("NOT",)), (c,)),
        (e, rng.choice(("AND", "OR", "XOR")), (d, b)),
        (irrelevant, "NOT", (a,)),
    ]
    desired = bool(index % 2)
    possible = []
    for candidate_target in (a, b, c):
        for candidate_value in (False, True):
            candidate_values = dict(exogenous)
            candidate_values[candidate_target] = candidate_value
            for target, op, parents in operations:
                if target not in candidate_values:
                    candidate_values[target] = _bool_eval(
                        op, [candidate_values[parent] for parent in parents]
                    )
            if candidate_values[e] == desired:
                possible.append((candidate_target, candidate_value, candidate_values))
    if not possible:
        # A constant outcome is possible for some Boolean equations. Make the final
        # mechanism sensitive to d while retaining a nontrivial dependency on b.
        operations[2] = (e, "XOR", (d, b))
        for candidate_target in (a, b, c):
            for candidate_value in (False, True):
                candidate_values = dict(exogenous)
                candidate_values[candidate_target] = candidate_value
                for target, op, parents in operations:
                    if target not in candidate_values:
                        candidate_values[target] = _bool_eval(
                            op, [candidate_values[parent] for parent in parents]
                        )
                if candidate_values[e] == desired:
                    possible.append((candidate_target, candidate_value, candidate_values))
    if not possible:
        raise RuntimeError("failed to construct balanced causal intervention")
    intervention_target, intervention_value, values = rng.choice(possible)
    equations = []
    for target, op, parents in operations:
        if op == "NOT":
            equations.append(f"{target} is active exactly when {parents[0]} is inactive.")
        else:
            phrase = {"AND": "both", "OR": "at least one", "XOR": "exactly one"}[op]
            equations.append(
                f"{target} is active exactly when {phrase} of {parents[0]} and {parents[1]} are active."
            )
    raw = _finish(
        "Evaluate this deterministic causal system under an intervention. Intervening fixes "
        "that unit and replaces its normal equation. Return `yes` if the queried unit is active, "
        "otherwise `no`.\n"
        f"Initially {a} is {'active' if exogenous[a] else 'inactive'} and {b} is "
        f"{'active' if exogenous[b] else 'inactive'}.\n"
        + "\n".join(equations)
        + f"\nIntervention: force {intervention_target} {'active' if intervention_value else 'inactive'}."
        + f"\nQuery: is {e} active?"
    )
    canonical_equations = [
        {"target": target, "operator": op, "parents": list(parents)}
        for target, op, parents in operations
    ]
    return GateTask(
        f"g1-causal-{index:02d}",
        "counterfactual_causal",
        raw,
        {
            "state": "Canonical exogenous assignment and intervention: "
            + json.dumps(
                {
                    "exogenous": exogenous,
                    "do": {intervention_target: intervention_value},
                    "query": e,
                },
                sort_keys=True,
            ),
            "dynamics": "Canonical structural equations: " + json.dumps(canonical_equations),
            "actions": "The complete answer domain is [yes, no].",
            "verifier": (
                f"A draft trace assigns {c}={'active' if not values[c] else 'inactive'}, but the "
                f"equation for {c} rejects that intermediate value; recompute forward from the intervention."
            ),
            "evidence": "The irrelevant unit and its equation can be discarded. Relevant equations: "
            + json.dumps(canonical_equations[:3]),
        },
        {
            "answer": "yes" if values[e] else "no",
            "values": values,
            "intervention": {intervention_target: intervention_value},
        },
    )


def _tool_task(index: int, rng: random.Random) -> GateTask:
    names = _choice_aliases(rng, 6, "api_")
    lookup, authorize, transform, notify, distract_a, distract_b = names
    entity = f"record-{rng.randrange(1000, 9999)}"
    pin = f"P{rng.randrange(100, 999)}"
    mode = rng.choice(("archive", "convert", "validate"))
    channel = rng.choice(("audit", "email", "queue"))
    schemas = [
        {"name": lookup, "inputs": {"name": "string"}, "returns": {"record_key": "key"}},
        {
            "name": authorize,
            "inputs": {"record_key": "key", "pin": "string"},
            "returns": {"permit": "permit"},
        },
        {
            "name": transform,
            "inputs": {"record_key": "key", "permit": "permit", "mode": "string"},
            "returns": {"receipt": "receipt"},
        },
        {
            "name": notify,
            "inputs": {"receipt": "receipt", "channel": "string"},
            "returns": {"done": "boolean"},
        },
        {"name": distract_a, "inputs": {"receipt": "receipt"}, "returns": {"record_key": "key"}},
        {"name": distract_b, "inputs": {"name": "string"}, "returns": {"permit": "permit"}},
    ]
    rng.shuffle(schemas)
    expected = [
        {"name": lookup, "arguments": {"name": entity}},
        {"name": authorize, "arguments": {"record_key": "$1.record_key", "pin": pin}},
        {
            "name": transform,
            "arguments": {
                "record_key": "$1.record_key",
                "permit": "$2.permit",
                "mode": mode,
            },
        },
        {"name": notify, "arguments": {"receipt": "$3.receipt", "channel": channel}},
    ]
    raw = _finish(
        "Construct a stateful workflow. Later calls may reference earlier returned fields as "
        "`$<call-number>.<field>`. Return a compact JSON array of calls, each with `name` and "
        "`arguments`; do not call unnecessary APIs.\n"
        f"Goal: process {entity} using PIN {pin} in mode {mode}, then notify channel {channel}.\n"
        "API schemas: "
        + json.dumps(schemas, sort_keys=True)
    )
    required = [schema for schema in schemas if schema["name"] in {lookup, authorize, transform, notify}]
    decoy = [expected[0], expected[2], expected[1], expected[3]]
    return GateTask(
        f"g1-tool-{index:02d}",
        "stateful_tool_workflow",
        raw,
        {
            "state": "Canonical initial known values and unresolved types: "
            + json.dumps(
                {
                    "known": {"name": entity, "pin": pin, "mode": mode, "channel": channel},
                    "needed": ["key", "permit", "receipt", "done"],
                }
            ),
            "dynamics": (
                "Required dataflow is key -> permit -> receipt -> done. Every reference must point "
                "to an earlier call returning the required type."
            ),
            "actions": "At each step select a type-enabled API; the available names are "
            + json.dumps(sorted(schema["name"] for schema in schemas)),
            "verifier": (
                "The draft workflow "
                + json.dumps(decoy, separators=(",", ":"))
                + " first fails at call 2 because its permit reference has not been produced yet."
            ),
            "evidence": "Only these schemas are relevant: " + json.dumps(required, sort_keys=True),
        },
        {"answer": expected, "required_tools": [lookup, authorize, transform, notify]},
    )


def _evidence_task(index: int, rng: random.Random) -> GateTask:
    entities = _choice_aliases(rng, 9, "entity-")
    relations = _choice_aliases(rng, 5, "rel-")
    a, b, c, answer, x, y, z, u, v = entities
    r1, r2, r3, noise_r1, noise_r2 = relations
    facts = [
        (a, r1, b),
        (b, r2, c),
        (c, r3, answer),
        (a, noise_r1, x),
        (x, r2, y),
        (y, noise_r2, z),
        (u, r1, v),
        (v, r3, x),
    ]
    rng.shuffle(facts)
    raw = _finish(
        "Use only the dossier and the ordered relation chain in the query. A fact `(x, r, y)` "
        "means following relation r from x reaches y. Return the final entity label.\nDossier:\n"
        + "\n".join(f"({left}, {relation}, {right})" for left, relation, right in facts)
        + f"\nQuery: start at {a}, then follow {r1}, then {r2}, then {r3}."
    )
    candidates = sorted({right for _, _, right in facts})
    proof = [(a, r1, b), (b, r2, c), (c, r3, answer)]
    return GateTask(
        f"g1-evidence-{index:02d}",
        "evidence_grounding",
        raw,
        {
            "state": f"Canonical query state: current={a}; remaining_relations={json.dumps([r1, r2, r3])}.",
            "dynamics": "At each step, match both the current entity and the next relation exactly, "
            "then replace current with the fact's right-hand entity.",
            "actions": "Entities that appear as possible destinations are " + json.dumps(candidates),
            "verifier": (
                f"The candidate {z} has no valid proof: after the first step the current entity is {b}, "
                f"so a second-step fact must begin with {b}."
            ),
            "evidence": "Minimal sufficient evidence, in dossier order: " + json.dumps(proof),
        },
        {"answer": answer, "proof": proof},
    )


def build_tasks(
    seed: int = SEED, items_per_family: int = ITEMS_PER_FAMILY
) -> tuple[GateTask, ...]:
    rng = random.Random(seed)
    builders = (
        _planning_task,
        _rule_task,
        _causal_task,
        _tool_task,
        _evidence_task,
    )
    tasks = tuple(
        builder(index, rng) for builder in builders for index in range(items_per_family)
    )
    expected = items_per_family * len(FAMILIES)
    if len(tasks) != expected or len({task.task_id for task in tasks}) != expected:
        raise RuntimeError("Gate 1 task construction is not balanced and unique")
    return tasks


def _extract_final(response: str) -> str | None:
    matches = re.findall(
        r"(?im)^\s*(?:\*\*)?FINAL\s*:\s*(.+?)(?:\*\*)?\s*$", response
    )
    return matches[0].strip() if matches else None


def _normalized_text(value: str) -> str:
    return re.sub(r"\s+", "", value).casefold()


def _parse_json(value: str) -> Any:
    value = value.strip()
    if value.startswith("```"):
        value = re.sub(r"^```(?:json)?\s*|\s*```$", "", value, flags=re.I | re.S)
    return json.loads(value)


def validate_tool_workflow(candidate: Any, authority: Mapping[str, Any]) -> Mapping[str, Any]:
    expected = authority["answer"]
    if not isinstance(candidate, list):
        return {"valid": False, "reason": "not_a_call_array"}
    if len(candidate) != len(expected):
        return {"valid": False, "reason": "wrong_call_count"}
    for index, (actual, required) in enumerate(zip(candidate, expected), start=1):
        if not isinstance(actual, dict) or set(actual) != {"name", "arguments"}:
            return {"valid": False, "reason": f"malformed_call_{index}"}
        if actual["name"] != required["name"] or actual["arguments"] != required["arguments"]:
            return {"valid": False, "reason": f"incorrect_call_{index}"}
    return {"valid": True, "reason": "workflow_executes"}


def score_response(family: str, authority: Mapping[str, Any], response: str) -> Mapping[str, Any]:
    final = _extract_final(response)
    if final is None:
        return {"parsed": False, "correct": False, "answer": None, "reason": "missing_final"}
    if family == "stateful_tool_workflow":
        try:
            candidate = _parse_json(final)
        except (json.JSONDecodeError, TypeError):
            return {"parsed": False, "correct": False, "answer": final, "reason": "invalid_json"}
        validation = validate_tool_workflow(candidate, authority)
        return {
            "parsed": True,
            "correct": bool(validation["valid"]),
            "answer": candidate,
            "validation": validation,
        }
    expected = str(authority["answer"])
    return {
        "parsed": True,
        "correct": _normalized_text(final) == _normalized_text(expected),
        "answer": final,
        "expected_sha256": hashlib.sha256(expected.encode()).hexdigest(),
    }


def prepare_benchmark(output: Path) -> Mapping[str, Any]:
    tasks = build_tasks()
    public_payload = _jsonl(task.public_dict() for task in tasks)
    authority_payload = _jsonl(task.authority_dict() for task in tasks)
    body = {
        "version": VERSION,
        "gate": "Gate 1: causal scaling-gap decomposition",
        "research_question": (
            "Which oracle-supplied computational object—state, dynamics, candidate actions, "
            "verifier feedback, or relevant evidence—causally closes the small/large-model gap?"
        ),
        "seed": SEED,
        "families": list(FAMILIES),
        "interventions": list(INTERVENTIONS),
        "items_per_family": ITEMS_PER_FAMILY,
        "task_count": TASK_COUNT,
        "model_contract": list(MODEL_CONTRACT),
        "inference_contract": {
            "temperature": 0.0,
            "top_p": 1.0,
            "top_k": 0,
            "enable_thinking": False,
            "maximum_new_tokens": MAXIMUM_NEW_TOKENS,
            "same_prompt_template_and_decoding_for_all_qwen_scales": True,
            "single_deterministic_response_per_task_condition": True,
            "answer_channel": (
                "brief scratch work followed by terminal FINAL line; Markdown around FINAL is tolerated; "
                "generation stops immediately after the completed line"
            ),
        },
        "design_contract": {
            "training": False,
            "model_specific_prompting": False,
            "labels_absent_from_public_authority": True,
            "interventions_are_single_factor_not_cumulative": True,
            "synthetic_aliases_are_seeded_and_semantically_opaque": True,
            "all_labels_and_intermediates_are_programmatically_verified": True,
            "raw_all_scales": ["qwen3_1p7b", "qwen3_4b", "qwen3_8b", "ouro_1p4b", "qwen_72b_reference"],
            "oracle_interventions_primary_model": "qwen3_1p7b",
        },
        "decision_rule": {
            "gap_reference": "frozen 72B raw accuracy minus frozen 1.7B raw accuracy",
            "provisional_local_reference": "8B raw, reported as provisional only",
            "shared_bottleneck_minimum_families": 3,
            "minimum_fraction_of_positive_gap_closed": 0.5,
            "minimum_family_raw_gap": 0.125,
            "family_effect": "1.7B intervention accuracy minus 1.7B raw accuracy",
            "continue_to_mechanism_gate_only_if_shared_bottleneck_passes": True,
        },
        "stop_rules": [
            "No Gate 2 architecture change before the external 72B condition is imported.",
            "If no single factor closes >=50% of the positive gap in >=3 families, stop the one-mechanism program.",
            "If oracle state does not materially close the gap, do not build a state-representation module.",
            "Ouro is a prior-art recurrent baseline, not a novel contribution.",
            "An external task planner is scaffolding and cannot establish an internal cognitive-core claim.",
        ],
        "claim_boundary": (
            "This seeded 40-task panel is a causal diagnostic pre-registered before model outputs. "
            "It is not a capability benchmark, publication result, or 1.7B/72B parity claim. Gate 1 "
            "is formally incomplete until frozen Ouro and 72B raw records are imported."
        ),
        "supersedes": {
            "versions": [
                "cognitive-core-gate1-causal-decomposition-v1",
                "cognitive-core-gate1-causal-decomposition-v2",
            ],
            "reason": (
                "Retired during 1.7B instrumentation preflights: v1's 384-token answer-last channel "
                "created ceiling/Markdown false negatives; v2's answer-first channel suppressed "
                "scratch work. Neither produced a complete intervention panel."
            ),
            "unchanged_scientific_content": [
                "task seed and generated instances",
                "authority labels and deterministic solvers",
                "oracle intervention content",
                "models, decoding temperature, and decision thresholds",
            ],
        },
        "public_tasks_sha256": hashlib.sha256(public_payload.encode()).hexdigest(),
        "authority_tasks_sha256": hashlib.sha256(authority_payload.encode()).hexdigest(),
    }
    freeze = {**body, "freeze_id": content_digest(body)}
    _write_immutable(output / "tasks-public.jsonl", public_payload)
    _write_immutable(output / "tasks-authority.jsonl", authority_payload)
    _write_immutable(
        output / "protocol-freeze.json", json.dumps(freeze, indent=2, sort_keys=True) + "\n"
    )
    verification = verify_benchmark(output)
    _write_immutable(
        output / "protocol-verification.json",
        json.dumps(verification, indent=2, sort_keys=True) + "\n",
    )
    return freeze


def verify_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "protocol-freeze.json").read_text(encoding="utf-8"))
    public_path = output / "tasks-public.jsonl"
    authority_path = output / "tasks-authority.jsonl"
    public = _read_jsonl(public_path)
    authority = _read_jsonl(authority_path)
    regenerated = build_tasks()
    checks = {
        "freeze_id_content_derived": content_digest(
            {key: value for key, value in freeze.items() if key != "freeze_id"}
        )
        == freeze["freeze_id"],
        "public_hash_matches": hashlib.sha256(public_path.read_bytes()).hexdigest()
        == freeze["public_tasks_sha256"],
        "authority_hash_matches": hashlib.sha256(authority_path.read_bytes()).hexdigest()
        == freeze["authority_tasks_sha256"],
        "balanced_panel": len(public) == TASK_COUNT
        and all(sum(row["family"] == family for row in public) == ITEMS_PER_FAMILY for family in FAMILIES),
        "all_interventions_present": all(
            set(row["prompts"]) == set(INTERVENTIONS) for row in public
        ),
        "authority_not_public": all("authority" not in row for row in public),
        "order_matches": [row["task_id"] for row in public]
        == [row["task_id"] for row in authority],
        "deterministic_regeneration": _jsonl(task.public_dict() for task in regenerated)
        == public_path.read_text(encoding="utf-8"),
        "all_authority_answers_self_score": all(
            score_response(
                row["family"],
                row["authority"],
                "FINAL: "
                + (
                    json.dumps(row["authority"]["answer"], separators=(",", ":"))
                    if row["family"] == "stateful_tool_workflow"
                    else str(row["authority"]["answer"])
                ),
            )["correct"]
            for row in authority
        ),
        "single_factor_interventions": freeze["design_contract"][
            "interventions_are_single_factor_not_cumulative"
        ],
        "external_slots_frozen": {"ouro_1p4b", "qwen_72b_reference"}.issubset(
            {row["key"] for row in freeze["model_contract"]}
        ),
    }
    return {"version": VERSION, "freeze_id": freeze["freeze_id"], "checks": checks, "passed": all(checks.values())}


def wilson_interval(correct: int, count: int) -> list[float]:
    if count <= 0:
        return [0.0, 0.0]
    z = 1.959963984540054
    p = correct / count
    denominator = 1 + z * z / count
    center = (p + z * z / (2 * count)) / denominator
    radius = z * math.sqrt(p * (1 - p) / count + z * z / (4 * count * count)) / denominator
    return [max(0.0, center - radius), min(1.0, center + radius)]


def summarize_records(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    by_family: dict[str, Any] = {}
    for family in FAMILIES:
        local = [row for row in records if row["family"] == family]
        correct = sum(bool(row["score"]["correct"]) for row in local)
        by_family[family] = {
            "count": len(local),
            "correct": correct,
            "accuracy": correct / len(local) if local else None,
            "wilson_95": wilson_interval(correct, len(local)),
            "parse_rate": (
                sum(bool(row["score"]["parsed"]) for row in local) / len(local) if local else None
            ),
        }
    correct = sum(bool(row["score"]["correct"]) for row in records)
    return {
        "count": len(records),
        "correct": correct,
        "macro_accuracy": (
            sum(value["accuracy"] for value in by_family.values() if value["accuracy"] is not None)
            / sum(value["accuracy"] is not None for value in by_family.values())
            if records
            else None
        ),
        "micro_accuracy": correct / len(records) if records else None,
        "by_family": by_family,
    }


def analyze_conditions(
    records_by_condition: Mapping[str, Sequence[Mapping[str, Any]]],
    reference_model: str = "qwen3_8b",
) -> Mapping[str, Any]:
    raw_small = records_by_condition.get("qwen3_1p7b:raw", ())
    raw_reference = records_by_condition.get(f"{reference_model}:raw", ())
    summaries = {key: summarize_records(rows) for key, rows in records_by_condition.items()}
    effects: dict[str, Any] = {}
    passing_families: dict[str, list[str]] = {name: [] for name in INTERVENTIONS[1:]}
    positive_effect_families: dict[str, list[str]] = {name: [] for name in INTERVENTIONS[1:]}
    for family in FAMILIES:
        small = [row for row in raw_small if row["family"] == family]
        reference = [row for row in raw_reference if row["family"] == family]
        small_accuracy = sum(row["score"]["correct"] for row in small) / len(small) if small else None
        reference_accuracy = (
            sum(row["score"]["correct"] for row in reference) / len(reference) if reference else None
        )
        raw_gap = (
            reference_accuracy - small_accuracy
            if small_accuracy is not None and reference_accuracy is not None
            else None
        )
        family_effects = {}
        for intervention in INTERVENTIONS[1:]:
            local = records_by_condition.get(f"qwen3_1p7b:{intervention}", ())
            rows = [row for row in local if row["family"] == family]
            accuracy = sum(row["score"]["correct"] for row in rows) / len(rows) if rows else None
            effect = accuracy - small_accuracy if accuracy is not None and small_accuracy is not None else None
            if effect is not None and effect > 0:
                positive_effect_families[intervention].append(family)
            fraction = effect / raw_gap if effect is not None and raw_gap is not None and raw_gap > 0 else None
            passed = bool(raw_gap is not None and raw_gap >= 0.125 and fraction is not None and fraction >= 0.5)
            if passed:
                passing_families[intervention].append(family)
            family_effects[intervention] = {
                "accuracy": accuracy,
                "absolute_effect": effect,
                "positive_gap_fraction_closed": fraction,
                "passes_family_rule": passed,
            }
        effects[family] = {
            "small_raw_accuracy": small_accuracy,
            "reference_raw_accuracy": reference_accuracy,
            "raw_gap": raw_gap,
            "interventions": family_effects,
        }
    candidates = [name for name, families in passing_families.items() if len(families) >= 3]
    has_complete_ouro = len(records_by_condition.get("ouro_1p4b:raw", ())) == TASK_COUNT
    has_complete_72b = len(records_by_condition.get("qwen_72b_reference:raw", ())) == TASK_COUNT
    formal_complete = has_complete_ouro and has_complete_72b
    locally_decisive_rejection = (
        len(raw_small) == TASK_COUNT
        and all(
            len(records_by_condition.get(f"qwen3_1p7b:{name}", ())) == TASK_COUNT
            for name in INTERVENTIONS[1:]
        )
        and all(len(families) < 3 for families in positive_effect_families.values())
    )
    recurrence = None
    ouro = records_by_condition.get("ouro_1p4b:raw", ())
    if len(raw_small) == TASK_COUNT and len(ouro) == TASK_COUNT:
        small_by_id = {str(row["task_id"]): row for row in raw_small}
        ouro_by_id = {str(row["task_id"]): row for row in ouro}
        shared_ids = sorted(set(small_by_id) & set(ouro_by_id))
        recurrence = {
            "qwen3_1p7b_accuracy": sum(
                bool(small_by_id[task_id]["score"]["correct"]) for task_id in shared_ids
            )
            / len(shared_ids),
            "ouro_1p4b_accuracy": sum(
                bool(ouro_by_id[task_id]["score"]["correct"]) for task_id in shared_ids
            )
            / len(shared_ids),
            "absolute_gain": (
                sum(bool(ouro_by_id[task_id]["score"]["correct"]) for task_id in shared_ids)
                - sum(bool(small_by_id[task_id]["score"]["correct"]) for task_id in shared_ids)
            )
            / len(shared_ids),
            "correctness_agreement": sum(
                bool(ouro_by_id[task_id]["score"]["correct"])
                == bool(small_by_id[task_id]["score"]["correct"])
                for task_id in shared_ids
            )
            / len(shared_ids),
            "ouro_unique_successes": sum(
                bool(ouro_by_id[task_id]["score"]["correct"])
                and not bool(small_by_id[task_id]["score"]["correct"])
                for task_id in shared_ids
            ),
            "qwen_unique_successes": sum(
                bool(small_by_id[task_id]["score"]["correct"])
                and not bool(ouro_by_id[task_id]["score"]["correct"])
                for task_id in shared_ids
            ),
        }
    if locally_decisive_rejection:
        decision = "stop_one_mechanism_program_local_causal_rejection"
    elif not has_complete_72b:
        decision = "await_external_72b"
    elif not has_complete_ouro:
        decision = "await_ouro"
    else:
        decision = "continue_to_gate2" if candidates else "stop_one_mechanism_program"
    return {
        "summaries": summaries,
        "reference_model": reference_model,
        "formal_gate_complete": formal_complete,
        "family_effects": effects,
        "passing_families_by_intervention": passing_families,
        "positive_effect_families_by_intervention": positive_effect_families,
        "provisional_shared_bottlenecks": candidates,
        "provisional_gate_passed": bool(candidates),
        "local_causal_rejection_is_logically_decisive": locally_decisive_rejection,
        "why_72b_cannot_reverse_local_rejection": (
            "The external reference changes gap size but cannot create a positive intervention "
            "effect in a third family; every factor has positive local effect in fewer than three."
            if locally_decisive_rejection
            else None
        ),
        "recurrence_control": recurrence,
        "decision": decision,
    }
