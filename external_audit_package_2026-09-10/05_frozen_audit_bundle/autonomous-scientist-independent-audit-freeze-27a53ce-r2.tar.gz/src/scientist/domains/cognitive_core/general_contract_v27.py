from __future__ import annotations

import ast
import hashlib
import json
import random
import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


GENERAL_CORE_CONTRACT_VERSION = "general-cognitive-core-contract-v27"


class CognitiveOperation(str, Enum):
    GOAL_DECOMPOSITION = "goal_decomposition"
    CAUSAL_DIAGNOSIS = "causal_diagnosis"
    LATENT_CONCEPT_INVENTION = "latent_concept_invention"
    REPRESENTATION_REVISION = "representation_revision"
    TOOL_ROUTING = "tool_routing"
    UNCERTAINTY_CONTROL = "uncertainty_control"


class CognitiveTrack(str, Enum):
    GENERAL = "general"
    SCIENTIFIC = "scientific"


class FunctionalResidence(str, Enum):
    INTERNAL = "internal"
    EXTERNAL = "external"
    HYBRID = "hybrid"


@dataclass(frozen=True)
class OperationContract:
    operation: CognitiveOperation
    definition: str
    primary_residence_hypothesis: FunctionalResidence
    behavioral_test: str
    intervention_test: str
    downstream_measure: str

    def as_dict(self) -> Dict[str, str]:
        return {
            "operation": self.operation.value,
            "definition": self.definition,
            "primary_residence_hypothesis": self.primary_residence_hypothesis.value,
            "behavioral_test": self.behavioral_test,
            "intervention_test": self.intervention_test,
            "downstream_measure": self.downstream_measure,
        }


OPERATION_CONTRACTS: Tuple[OperationContract, ...] = (
    OperationContract(
        CognitiveOperation.GOAL_DECOMPOSITION,
        "Construct an executable dependency order and revise it after a blocked subgoal.",
        FunctionalResidence.HYBRID,
        "Produce a valid order on unseen dependency graphs.",
        "Remove persistent graph state or corrupt one prerequisite edge.",
        "Fraction of targets reached without illegal actions.",
    ),
    OperationContract(
        CognitiveOperation.CAUSAL_DIAGNOSIS,
        "Distinguish an intervening cause from observational correlates.",
        FunctionalResidence.INTERNAL,
        "Identify the manipulated variable with an invariant effect.",
        "Delete intervention rows while preserving correlations.",
        "Accuracy of a downstream intervention choice.",
    ),
    OperationContract(
        CognitiveOperation.LATENT_CONCEPT_INVENTION,
        "Invent an executable predicate that explains contrasts and predicts unseen cases.",
        FunctionalResidence.INTERNAL,
        "Synthesize a predicate from labeled contrasts.",
        "Apply the predicate to hidden cases and feature-flip interventions.",
        "Held-out and interventional prediction accuracy.",
    ),
    OperationContract(
        CognitiveOperation.REPRESENTATION_REVISION,
        "Replace a failing stateless representation with the minimal stateful alternative.",
        FunctionalResidence.HYBRID,
        "Choose the representation class required by unseen trajectories.",
        "Ablate history or cumulative state from the evidence.",
        "Future-step prediction accuracy after revision.",
    ),
    OperationContract(
        CognitiveOperation.TOOL_ROUTING,
        "Select exact external machinery only when its functional advantage is relevant.",
        FunctionalResidence.HYBRID,
        "Route novel requests to calculation, retrieval, execution, memory, or no tool.",
        "Disable the selected tool or substitute a semantically adjacent tool.",
        "Task accuracy net of tool calls and invalid calls.",
    ),
    OperationContract(
        CognitiveOperation.UNCERTAINTY_CONTROL,
        "Abstain when evidence underdetermines the answer and commit when it is identified.",
        FunctionalResidence.INTERNAL,
        "Separate identifiable from ambiguous cases.",
        "Add or remove the single disambiguating observation.",
        "Selective accuracy and false-commit rate.",
    ),
)


@dataclass(frozen=True)
class CognitiveTask:
    task_id: str
    split: str
    track: CognitiveTrack
    operation: CognitiveOperation
    prompt: str
    expected_answer: str
    hidden_cases: Tuple[Tuple[int, int, int], ...] = ()
    hidden_labels: Tuple[bool, ...] = ()
    metadata: Mapping[str, Any] | None = None

    def public_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "split": self.split,
            "track": self.track.value,
            "operation": self.operation.value,
            "prompt": self.prompt,
        }

    def authority_dict(self) -> Dict[str, Any]:
        return {
            **self.public_dict(),
            "expected_answer": self.expected_answer,
            "hidden_cases": [list(case) for case in self.hidden_cases],
            "hidden_labels": list(self.hidden_labels),
            "metadata": dict(self.metadata or {}),
        }

    def chat_record(self) -> Dict[str, Any]:
        return {
            "messages": [
                {"role": "user", "content": self.prompt},
                {"role": "assistant", "content": "ANSWER: " + self.expected_answer},
            ],
            "metadata": {
                "task_id": self.task_id,
                "track": self.track.value,
                "operation": self.operation.value,
            },
        }


@dataclass(frozen=True)
class EvaluationGates:
    minimum_parse_coverage: float = 0.95
    minimum_internal_gain: float = 0.08
    maximum_family_regression: float = 0.05
    minimum_concept_semantic_accuracy: float = 0.60
    minimum_concept_gain: float = 0.15
    minimum_hybrid_gain_over_internal: float = 0.03
    minimum_selective_ablation_drop: float = 0.10
    maximum_off_target_ablation_drop: float = 0.05
    recovery_tolerance: float = 0.01

    def as_dict(self) -> Dict[str, float]:
        return {
            "minimum_parse_coverage": self.minimum_parse_coverage,
            "minimum_internal_gain": self.minimum_internal_gain,
            "maximum_family_regression": self.maximum_family_regression,
            "minimum_concept_semantic_accuracy": self.minimum_concept_semantic_accuracy,
            "minimum_concept_gain": self.minimum_concept_gain,
            "minimum_hybrid_gain_over_internal": self.minimum_hybrid_gain_over_internal,
            "minimum_selective_ablation_drop": self.minimum_selective_ablation_drop,
            "maximum_off_target_ablation_drop": self.maximum_off_target_ablation_drop,
            "recovery_tolerance": self.recovery_tolerance,
        }


@dataclass(frozen=True)
class BenchmarkFreeze:
    contract_version: str
    model_primary: str
    model_scale_control: str
    train_count: int
    validation_count: int
    test_count: int
    public_test_sha256: str
    authority_test_sha256: str
    training_sha256: str
    validation_sha256: str
    gates: EvaluationGates
    split_seeds: Mapping[str, int]
    claim_boundary: str

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "contract_version": self.contract_version,
            "model_primary": self.model_primary,
            "model_scale_control": self.model_scale_control,
            "train_count": self.train_count,
            "validation_count": self.validation_count,
            "test_count": self.test_count,
            "public_test_sha256": self.public_test_sha256,
            "authority_test_sha256": self.authority_test_sha256,
            "training_sha256": self.training_sha256,
            "validation_sha256": self.validation_sha256,
            "gates": self.gates.as_dict(),
            "split_seeds": dict(self.split_seeds),
            "operation_contracts": [item.as_dict() for item in OPERATION_CONTRACTS],
            "claim_boundary": self.claim_boundary,
        }
        if include_id:
            payload["freeze_id"] = self.freeze_id
        return payload


PRIMARY_MODEL = "mlx-community/Qwen2.5-1.5B-Instruct-4bit"
SCALE_CONTROL_MODEL = "mlx-community/Qwen2.5-3B-Instruct-4bit"
SPLIT_SEEDS = {"train": 27101, "valid": 27161, "test": 27241}


def _answer_instruction(body: str) -> str:
    return (
        body.strip()
        + "\nReturn exactly one line in the form ANSWER: <value>. Do not explain."
    )


def _task_id(split: str, operation: CognitiveOperation, index: int, body: str) -> str:
    digest = hashlib.sha256(body.encode("utf-8")).hexdigest()[:12]
    return f"v27-{split}-{operation.value}-{index:04d}-{digest}"


def _latent_rule(split: str, rng: random.Random) -> Tuple[str, Any]:
    if split == "test":
        choice = rng.randrange(3)
        if choice == 0:
            modulus = rng.choice((3, 4))
            residue = rng.randrange(modulus)
            expression = f"(x0+2*x1)%{modulus}=={residue}"
            return expression, lambda row: (row[0] + 2 * row[1]) % modulus == residue
        if choice == 1:
            width = rng.choice((1, 2, 3))
            expression = f"abs(x0-x1)<={width}"
            return expression, lambda row: abs(row[0] - row[1]) <= width
        threshold = rng.choice((5, 7, 9))
        expression = f"x0*x1>x2+{threshold}"
        return expression, lambda row: row[0] * row[1] > row[2] + threshold
    choice = rng.randrange(5)
    if choice == 0:
        return "x0>x1", lambda row: row[0] > row[1]
    if choice == 1:
        residue = rng.randrange(2)
        return f"(x0+x1)%2=={residue}", lambda row: (row[0] + row[1]) % 2 == residue
    if choice == 2:
        offset = rng.choice((0, 1, 2))
        return f"x0+x1>x2+{offset}", lambda row: row[0] + row[1] > row[2] + offset
    if choice == 3:
        width = rng.choice((1, 2))
        return f"abs(x0-x1)<={width}", lambda row: abs(row[0] - row[1]) <= width
    threshold = rng.choice((3, 5))
    return f"x0*x1>x2+{threshold}", lambda row: row[0] * row[1] > row[2] + threshold


def _balanced_rows(rng: random.Random, predicate: Any, count: int) -> Tuple[Tuple[int, int, int], ...]:
    positive = []
    negative = []
    attempts = 0
    while len(positive) < count // 2 or len(negative) < count // 2:
        row = (rng.randrange(0, 10), rng.randrange(0, 10), rng.randrange(0, 13))
        bucket = positive if predicate(row) else negative
        if row not in bucket and len(bucket) < count // 2:
            bucket.append(row)
        attempts += 1
        if attempts > 10000:
            raise RuntimeError("could not balance latent concept rows")
    rows = positive + negative
    rng.shuffle(rows)
    return tuple(rows)


def _latent_task(split: str, index: int, rng: random.Random) -> CognitiveTask:
    expression, predicate = _latent_rule(split, rng)
    demonstrations = _balanced_rows(rng, predicate, 10)
    hidden = _balanced_rows(rng, predicate, 20)
    track = CognitiveTrack.SCIENTIFIC if index % 2 else CognitiveTrack.GENERAL
    framing = (
        "A system shows a beneficial terminal response"
        if track == CognitiveTrack.SCIENTIFIC
        else "A controller accepts some states"
    )
    examples = "\n".join(
        f"x0={row[0]}, x1={row[1]}, x2={row[2]} -> {'YES' if predicate(row) else 'NO'}"
        for row in demonstrations
    )
    body = _answer_instruction(
        f"{framing}. Invent the smallest predicate that explains these contrasts.\n"
        "Allowed syntax: x0,x1,x2, integer constants, +, -, *, %, abs(), >, <=, ==, and parentheses.\n"
        f"{examples}\nReturn the executable predicate as the value."
    )
    return CognitiveTask(
        _task_id(split, CognitiveOperation.LATENT_CONCEPT_INVENTION, index, body),
        split,
        track,
        CognitiveOperation.LATENT_CONCEPT_INVENTION,
        body,
        expression,
        hidden,
        tuple(bool(predicate(row)) for row in hidden),
        {"rule_family": _expression_family(expression)},
    )


def _causal_task(split: str, index: int, rng: random.Random) -> CognitiveTask:
    cause = rng.randrange(3)
    names = (
        ("temperature", "pressure", "humidity")
        if index % 2
        else ("cache", "queue", "worker")
    )
    coefficient = rng.choice((2, 3, 4))
    baseline = rng.randrange(1, 5)
    rows = []
    for variable in range(3):
        low = baseline + (coefficient if variable == cause else 0)
        high = baseline + (2 * coefficient if variable == cause else 0)
        rows.append(f"do({names[variable]}=1) -> outcome={low}")
        rows.append(f"do({names[variable]}=2) -> outcome={high}")
    rng.shuffle(rows)
    body = _answer_instruction(
        "Observationally all three variables move together. The following controlled interventions were then run:\n"
        + "\n".join(rows)
        + "\nWhich variable has the direct invariant effect on outcome?"
    )
    return CognitiveTask(
        _task_id(split, CognitiveOperation.CAUSAL_DIAGNOSIS, index, body),
        split,
        CognitiveTrack.SCIENTIFIC if index % 2 else CognitiveTrack.GENERAL,
        CognitiveOperation.CAUSAL_DIAGNOSIS,
        body,
        names[cause],
        metadata={"cause_index": cause},
    )


def _goal_task(split: str, index: int, rng: random.Random) -> CognitiveTask:
    prefixes = ("collect", "clean", "build", "verify", "release")
    suffix = rng.choice(("artifact", "dataset", "module", "report"))
    actions = tuple(f"{name}_{suffix}" for name in prefixes)
    completed = rng.randrange(0, 3)
    blocked = completed + 1
    dependencies = {
        actions[0]: (),
        actions[1]: (actions[0],),
        actions[2]: (actions[1],),
        actions[3]: (actions[2],),
        actions[4]: (actions[3],),
    }
    completed_actions = actions[: completed + 1]
    alternative = f"repair_{suffix}"
    body = _answer_instruction(
        "Goal: " + actions[-1] + "\nDependencies:\n"
        + "\n".join(
            f"{action} requires {', '.join(reqs) if reqs else 'nothing'}"
            for action, reqs in dependencies.items()
        )
        + f"\nCompleted: {', '.join(completed_actions)}"
        + f"\nBlocked action: {actions[blocked]}. Its permitted recovery action is {alternative}."
        + "\nWhat is the next executable action that preserves progress toward the goal?"
    )
    return CognitiveTask(
        _task_id(split, CognitiveOperation.GOAL_DECOMPOSITION, index, body),
        split,
        CognitiveTrack.GENERAL,
        CognitiveOperation.GOAL_DECOMPOSITION,
        body,
        alternative,
        metadata={"blocked": actions[blocked]},
    )


def _representation_task(split: str, index: int, rng: random.Random) -> CognitiveTask:
    family = rng.choice(("stateless", "previous_state", "cumulative_state"))
    sequences = []
    for _ in range(4):
        inputs = [rng.randrange(0, 5) for _ in range(5)]
        if family == "stateless":
            outputs = [(2 * value + 1) % 7 for value in inputs]
        elif family == "previous_state":
            outputs = [inputs[0]] + [(inputs[t] + inputs[t - 1]) % 7 for t in range(1, 5)]
        else:
            total = 0
            outputs = []
            for value in inputs:
                total = (total + value) % 7
                outputs.append(total)
        sequences.append(f"inputs={inputs}; outputs={outputs}")
    body = _answer_instruction(
        "A stateless predictor is failing. Choose the minimal representation class that exactly explains all trajectories: stateless, previous_state, or cumulative_state.\n"
        + "\n".join(sequences)
    )
    return CognitiveTask(
        _task_id(split, CognitiveOperation.REPRESENTATION_REVISION, index, body),
        split,
        CognitiveTrack.SCIENTIFIC if index % 2 else CognitiveTrack.GENERAL,
        CognitiveOperation.REPRESENTATION_REVISION,
        body,
        family,
    )


def _tool_task(split: str, index: int, rng: random.Random) -> CognitiveTask:
    scenarios = (
        ("Compute the exact value of 98317 multiplied by 7729.", "calculator"),
        ("Find today's current policy rate from an authoritative source.", "retriever"),
        ("Run the supplied program and report whether its tests pass.", "code"),
        ("Recall the experiment result stored in this project's persistent notebook yesterday.", "memory"),
        ("Explain in your own words why controlled interventions distinguish causes.", "none"),
    )
    scenario, answer = scenarios[(index + rng.randrange(len(scenarios))) % len(scenarios)]
    body = _answer_instruction(
        scenario
        + "\nChoose exactly one route: calculator, retriever, code, memory, or none."
    )
    return CognitiveTask(
        _task_id(split, CognitiveOperation.TOOL_ROUTING, index, body),
        split,
        CognitiveTrack.GENERAL,
        CognitiveOperation.TOOL_ROUTING,
        body,
        answer,
    )


def _uncertainty_task(split: str, index: int, rng: random.Random) -> CognitiveTask:
    candidates = ("alpha", "beta", "gamma")
    answer_index = rng.randrange(3)
    identified = (index + rng.randrange(2)) % 2 == 0
    scores = [rng.randrange(1, 5) for _ in candidates]
    if identified:
        scores[answer_index] = max(scores) + 4
        answer = candidates[answer_index]
        evidence = "; ".join(f"{name} has independent score {score}" for name, score in zip(candidates, scores))
    else:
        tied = rng.sample(range(3), 2)
        scores[tied[0]] = scores[tied[1]] = 7
        answer = "ABSTAIN"
        evidence = "; ".join(f"{name} has independent score {score}" for name, score in zip(candidates, scores))
    body = _answer_instruction(
        "Select the uniquely best-supported hypothesis. If the evidence does not identify a unique best hypothesis, answer ABSTAIN.\n"
        + evidence
    )
    return CognitiveTask(
        _task_id(split, CognitiveOperation.UNCERTAINTY_CONTROL, index, body),
        split,
        CognitiveTrack.SCIENTIFIC if index % 2 else CognitiveTrack.GENERAL,
        CognitiveOperation.UNCERTAINTY_CONTROL,
        body,
        answer,
        metadata={"identified": identified},
    )


TASK_BUILDERS = {
    CognitiveOperation.GOAL_DECOMPOSITION: _goal_task,
    CognitiveOperation.CAUSAL_DIAGNOSIS: _causal_task,
    CognitiveOperation.LATENT_CONCEPT_INVENTION: _latent_task,
    CognitiveOperation.REPRESENTATION_REVISION: _representation_task,
    CognitiveOperation.TOOL_ROUTING: _tool_task,
    CognitiveOperation.UNCERTAINTY_CONTROL: _uncertainty_task,
}


def build_suite(split: str, per_operation: int) -> Tuple[CognitiveTask, ...]:
    if split not in SPLIT_SEEDS:
        raise ValueError("unknown split")
    if per_operation <= 0:
        raise ValueError("per_operation must be positive")
    rng = random.Random(SPLIT_SEEDS[split])
    tasks = []
    for operation in CognitiveOperation:
        builder = TASK_BUILDERS[operation]
        tasks.extend(builder(split, index, rng) for index in range(per_operation))
    ids = [task.task_id for task in tasks]
    if len(ids) != len(set(ids)):
        raise RuntimeError("task ids are not unique")
    return tuple(tasks)


_ANSWER_RE = re.compile(r"ANSWER\s*:\s*([^\n\r]+)", re.IGNORECASE)


def parse_answer(response: str) -> str | None:
    matches = _ANSWER_RE.findall(response)
    if not matches:
        return None
    return matches[-1].strip().strip("`\"'").strip()


_ALLOWED_NODES = (
    ast.Expression,
    ast.Compare,
    ast.Name,
    ast.Load,
    ast.Constant,
    ast.BinOp,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Mod,
    ast.Gt,
    ast.LtE,
    ast.Eq,
    ast.Call,
    ast.USub,
    ast.UnaryOp,
)


def compile_predicate(expression: str):
    tree = ast.parse(expression.replace(" ", ""), mode="eval")
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise ValueError("unsupported predicate syntax")
        if isinstance(node, ast.Name) and node.id not in {"x0", "x1", "x2", "abs"}:
            raise ValueError("unsupported predicate name")
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id != "abs" or len(node.args) != 1:
                raise ValueError("unsupported predicate call")
    code = compile(tree, "<latent-predicate>", "eval")

    def predicate(row: Sequence[int]) -> bool:
        value = eval(
            code,
            {"__builtins__": {}, "abs": abs},
            {"x0": int(row[0]), "x1": int(row[1]), "x2": int(row[2])},
        )
        return bool(value)

    return predicate


def _expression_family(expression: str) -> str:
    if "%" in expression and "2*x1" in expression:
        return "weighted_modular"
    if "%" in expression:
        return "modular"
    if "abs" in expression:
        return "difference_band"
    if "*" in expression:
        return "multiplicative_threshold"
    if "x0+x1" in expression:
        return "additive_threshold"
    return "order"


def score_response(task: CognitiveTask, response: str) -> Mapping[str, Any]:
    answer = parse_answer(response)
    if answer is None:
        return {"parsed": False, "score": 0.0, "answer": None}
    if task.operation != CognitiveOperation.LATENT_CONCEPT_INVENTION:
        correct = answer.casefold() == task.expected_answer.casefold()
        return {"parsed": True, "score": float(correct), "answer": answer}
    try:
        predicate = compile_predicate(answer)
        predictions = tuple(bool(predicate(row)) for row in task.hidden_cases)
    except (MemoryError, RecursionError, SyntaxError, TypeError, ValueError, ZeroDivisionError):
        return {"parsed": True, "score": 0.0, "answer": answer, "valid_program": False}
    accuracy = sum(
        prediction == label
        for prediction, label in zip(predictions, task.hidden_labels)
    ) / len(task.hidden_labels)
    return {
        "parsed": True,
        "score": accuracy,
        "answer": answer,
        "valid_program": True,
        "semantic_exact": accuracy == 1.0,
        "expression_family": _expression_family(answer),
    }


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def prepare_benchmark(
    output_directory: Path,
    train_per_operation: int = 80,
    validation_per_operation: int = 12,
    test_per_operation: int = 24,
) -> BenchmarkFreeze:
    output_directory.mkdir(parents=True, exist_ok=True)
    train = build_suite("train", train_per_operation)
    valid = build_suite("valid", validation_per_operation)
    test = build_suite("test", test_per_operation)
    training_sha = _write_jsonl(output_directory / "train.jsonl", (task.chat_record() for task in train))
    validation_sha = _write_jsonl(output_directory / "valid.jsonl", (task.chat_record() for task in valid))
    public_test_sha = _write_jsonl(output_directory / "test-public.jsonl", (task.public_dict() for task in test))
    authority_test_sha = _write_jsonl(
        output_directory / "test-authority.jsonl", (task.authority_dict() for task in test)
    )
    freeze = BenchmarkFreeze(
        GENERAL_CORE_CONTRACT_VERSION,
        PRIMARY_MODEL,
        SCALE_CONTROL_MODEL,
        len(train),
        len(valid),
        len(test),
        public_test_sha,
        authority_test_sha,
        training_sha,
        validation_sha,
        EvaluationGates(),
        SPLIT_SEEDS,
        (
            "A local synthetic-but-executable benchmark can qualify wiring and provide preliminary "
            "evidence. It cannot establish general intelligence, 70B parity, scientific novelty, or "
            "publication readiness without external naturalistic benchmarks and replication."
        ),
    )
    (output_directory / "benchmark-freeze.json").write_text(
        json.dumps(freeze.as_dict(), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_benchmark(output_directory: Path) -> Mapping[str, Any]:
    manifest = json.loads((output_directory / "benchmark-freeze.json").read_text(encoding="utf-8"))
    hashes = {
        name: hashlib.sha256((output_directory / filename).read_bytes()).hexdigest()
        for name, filename in {
            "training_sha256": "train.jsonl",
            "validation_sha256": "valid.jsonl",
            "public_test_sha256": "test-public.jsonl",
            "authority_test_sha256": "test-authority.jsonl",
        }.items()
    }
    checks = {
        "artifact_hashes_match": all(manifest[key] == value for key, value in hashes.items()),
        "both_tracks_present": {task.track for task in build_suite("test", 24)} == set(CognitiveTrack),
        "all_operations_present": {task.operation for task in build_suite("test", 24)} == set(CognitiveOperation),
        "heldout_latent_family_present": any(
            task.metadata and task.metadata.get("rule_family") == "weighted_modular"
            for task in build_suite("test", 24)
        ),
        "training_excludes_weighted_modular_family": all(
            not task.metadata or task.metadata.get("rule_family") != "weighted_modular"
            for task in build_suite("train", 80)
        ),
        "gates_frozen_before_model_evaluation": bool(manifest.get("gates")),
    }
    return {
        "version": GENERAL_CORE_CONTRACT_VERSION,
        "freeze_id": manifest["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
        "hashes": hashes,
    }

