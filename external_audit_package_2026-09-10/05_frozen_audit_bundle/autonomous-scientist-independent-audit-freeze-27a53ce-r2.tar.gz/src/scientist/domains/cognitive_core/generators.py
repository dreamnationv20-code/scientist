from __future__ import annotations

import random
from typing import Iterable, Sequence, Tuple

from scientist.domains.cognitive_core.models import (
    ABSTAIN,
    CognitiveProbe,
    EvidenceItem,
    ProbeInput,
    ProbeKind,
)
from scientist.domains.cognitive_core.semantics import (
    execute_procedure,
    knowledge_table,
)
from scientist.kernel.contracts import EvidencePartition
from scientist.kernel.interfaces import ExperimentRequest


def _different_value(value: int, modulus: int) -> int:
    return (value + 1) % modulus


def generate_probe(
    kind: ProbeKind,
    seed: int,
    partition: EvidencePartition,
    knowledge_seed: int = 1729,
    fact_count: int = 32,
    value_modulus: int = 16,
) -> CognitiveProbe:
    rng = random.Random(seed)
    table = knowledge_table(knowledge_seed, fact_count, value_modulus)
    known_keys = tuple(sorted(table))
    query_key = known_keys[rng.randrange(len(known_keys))]
    evidence = ()
    operation = ""
    operands = ()

    if kind == ProbeKind.PROCEDURE:
        operation = ("add_mod", "xor", "max")[seed % 3]
        operands = (
            rng.randrange(value_modulus),
            rng.randrange(value_modulus),
        )
        public_input = ProbeInput(
            kind=kind,
            operation=operation,
            operands=operands,
            value_modulus=value_modulus,
        )
        expected = execute_procedure(public_input)
    elif kind == ProbeKind.CLOSED_BOOK_FACT:
        public_input = ProbeInput(
            kind=kind,
            query_key=query_key,
            value_modulus=value_modulus,
        )
        expected = table[query_key]
    elif kind == ProbeKind.ORACLE_EVIDENCE:
        query_key = 100000 + seed
        expected = rng.randrange(value_modulus)
        evidence = (
            EvidenceItem(query_key + 1, rng.randrange(value_modulus)),
            EvidenceItem(query_key, expected),
            EvidenceItem(query_key + 2, rng.randrange(value_modulus)),
        )
        public_input = ProbeInput(
            kind=kind,
            query_key=query_key,
            evidence=evidence,
            value_modulus=value_modulus,
        )
    elif kind == ProbeKind.IRRELEVANT_EVIDENCE:
        expected = table[query_key]
        distractor_key = known_keys[
            (known_keys.index(query_key) + 1) % len(known_keys)
        ]
        evidence = (
            EvidenceItem(distractor_key, table[distractor_key]),
        )
        public_input = ProbeInput(
            kind=kind,
            query_key=query_key,
            evidence=evidence,
            value_modulus=value_modulus,
        )
    elif kind == ProbeKind.CONFLICTING_EVIDENCE:
        parametric_answer = table[query_key]
        expected = _different_value(parametric_answer, value_modulus)
        evidence = (EvidenceItem(query_key, expected),)
        public_input = ProbeInput(
            kind=kind,
            query_key=query_key,
            evidence=evidence,
            value_modulus=value_modulus,
        )
    elif kind == ProbeKind.UNKNOWN_FACT:
        query_key = 200000 + seed
        public_input = ProbeInput(
            kind=kind,
            query_key=query_key,
            value_modulus=value_modulus,
        )
        expected = ABSTAIN
    else:
        raise ValueError("unsupported probe kind")

    return CognitiveProbe(
        partition=partition,
        seed=seed,
        knowledge_seed=knowledge_seed,
        fact_count=fact_count,
        public_input=public_input,
        expected_answer=expected,
    )


def generate_suite(
    kinds: Iterable[ProbeKind],
    seeds: Iterable[int],
    partition: EvidencePartition,
    knowledge_seed: int = 1729,
    fact_count: int = 32,
    value_modulus: int = 16,
) -> Tuple[CognitiveProbe, ...]:
    return tuple(
        generate_probe(
            kind=kind,
            seed=seed,
            partition=partition,
            knowledge_seed=knowledge_seed,
            fact_count=fact_count,
            value_modulus=value_modulus,
        )
        for kind in kinds
        for seed in seeds
    )


class CognitiveProbeFactory:
    name = "cognitive-core-probe-factory"
    factory_version = "cognitive-probe-generator-v1"

    def __init__(
        self,
        knowledge_seed: int = 1729,
        fact_count: int = 32,
        value_modulus: int = 16,
    ) -> None:
        self.knowledge_seed = knowledge_seed
        self.fact_count = fact_count
        self.value_modulus = value_modulus

    def generate(
        self,
        request: ExperimentRequest,
    ) -> Sequence[CognitiveProbe]:
        kinds = tuple(ProbeKind)
        requested = tuple(
            ProbeKind(tag)
            for tag in request.mechanism_tags
            if tag in {kind.value for kind in ProbeKind}
        )
        active_kinds = requested or kinds
        return tuple(
            generate_probe(
                kind=active_kinds[index % len(active_kinds)],
                seed=request.seed_start + index,
                partition=request.partition,
                knowledge_seed=self.knowledge_seed,
                fact_count=self.fact_count,
                value_modulus=self.value_modulus,
            )
            for index in range(request.count)
        )
