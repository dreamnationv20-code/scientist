from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from scientist.core.artifacts import ArtifactStore
from scientist.program.control_plane import AutonomousScientistControlPlane
from scientist.program.goal_graph import (
    CompositionOperator,
    DependencyEdge,
    DependencyKind,
    GoalGraphDecompositionProposal,
    GoalNodeKind,
    GoalNodeSpec,
    ParentCompositionRule,
)
from scientist.research_programs.cognitive_core import high_level_goal


COGNITIVE_GOAL_PROGRAM_VERSION = "cognitive-core-goal-program-v3-diagnostic-first"


@dataclass(frozen=True)
class CognitiveCoreGoalGraphSpec:
    root: GoalNodeSpec
    nodes: Dict[str, GoalNodeSpec]
    decompositions: Tuple[GoalGraphDecompositionProposal, ...]
    dependencies: Tuple[DependencyEdge, ...]


def _node(
    goal_id: str,
    *,
    title: str,
    question: str,
    kind: GoalNodeKind,
    rationale: str,
    success: Tuple[str, ...],
    falsification: Tuple[str, ...],
    artifact: str,
    tags: Tuple[str, ...],
) -> GoalNodeSpec:
    return GoalNodeSpec(
        goal_id=goal_id,
        title=title,
        question=question,
        kind=kind,
        rationale=rationale,
        success_conditions=success,
        falsification_conditions=falsification,
        expected_artifact=artifact,
        critical=True,
        tags=tags,
    )


def fresh_goal_graph_spec() -> CognitiveCoreGoalGraphSpec:
    """Solution-neutral graph; prior results may populate it but not define it."""

    goal = high_level_goal()
    root = _node(
        goal.goal_id,
        title=goal.name,
        question=goal.outcome,
        kind=GoalNodeKind.ROOT,
        rationale=(
            "Resolve the cognitive-core claim through multi-horizon diagnosis, "
            "representation repair, capability integration, and independent "
            "terminal validation."
        ),
        success=(goal.success_definition,),
        falsification=goal.failure_conditions,
        artifact="root resolution certificate with frozen independent evidence",
        tags=("cognitive-core", "root-objective", "diagnostic-first"),
    )
    measurement = _node(
        goal.goal_id,
        title="Valid multi-capability measurement system",
        question=(
            "Can the test system independently measure procedures, rapid "
            "learning, knowledge boundaries, evidence use, updating, retention, "
            "and total system cost without shortcut leakage?"
        ),
        kind=GoalNodeKind.ENGINEERING_ENABLER,
        rationale="Every downstream mechanism is ambiguous if capabilities collapse into one score.",
        success=(
            "positive, negative, and oracle controls produce distinct signatures",
            "partitions and model/task identities are disjoint across horizons",
            "an independent verifier reconstructs every capability metric",
        ),
        falsification=(
            "a shortcut control passes as transferable cognition",
            "one metric improvement hides a frozen capability-floor violation",
        ),
        artifact="qualified multi-horizon cognitive-core laboratory",
        tags=("measurement", "horizon", "prerequisite"),
    )
    diagnosis = _node(
        goal.goal_id,
        title="Causal and horizon-transfer diagnosis",
        question=(
            "Which capacity, optimization, representation, routing, or null "
            "explanation accounts for current failures, and why do local wins "
            "fail or survive at later horizons?"
        ),
        kind=GoalNodeKind.SCIENTIFIC_QUESTION,
        rationale=(
            "Architecture search should begin only after local-to-terminal "
            "contradictions identify a binding bottleneck or missing concept."
        ),
        success=(
            "competing causal models make distinguishing predictions",
            "matched transfer successes and failures form a frozen dossier",
            "representation adequacy is tested on held-out contrasts",
        ),
        falsification=(
            "candidate mechanisms cannot be separated by intervention",
            "the horizon ladder does not predict the terminal claim",
        ),
        artifact="causal diagnosis and horizon-failure dossier",
        tags=("diagnosis", "contrast", "representation"),
    )
    integrated = _node(
        goal.goal_id,
        title="Integrated cognitive-core candidate",
        question=(
            "Can one cost-matched learner jointly preserve procedures, learn "
            "rapidly, recognize boundaries, use evidence, and update knowledge?"
        ),
        kind=GoalNodeKind.INTEGRATION,
        rationale="Isolated component wins do not establish a useful cognitive core.",
        success=goal.integration_requirements,
        falsification=goal.failure_conditions,
        artifact="frozen integrated candidate with capability-floor report",
        tags=("integration", "pareto", "matched-cost"),
    )
    validation = _node(
        goal.goal_id,
        title="Independent terminal validation",
        question=(
            "Does the frozen integrated candidate transfer across natural tasks, "
            "model configurations, distribution shifts, and total-cost accounting?"
        ),
        kind=GoalNodeKind.INTEGRATION,
        rationale="Synthetic or single-benchmark success is mechanism evidence, not the root claim.",
        success=(
            "all terminal capability floors pass on quarantined evidence",
            "the result replicates across task and model families",
            "the Pareto improvement survives total-system cost matching",
        ),
        falsification=(
            "the effect depends on a synthetic or benchmark-specific shortcut",
            "the effect disappears under model, task, or distribution transfer",
        ),
        artifact="terminal replication and claim-boundary certificate",
        tags=("terminal", "transfer", "replication"),
    )

    causal_models = _node(
        goal.goal_id,
        title="Competing bottleneck models",
        question=(
            "Do capacity, optimization kinetics, representation entanglement, "
            "knowledge-boundary routing, or the null model best predict failures?"
        ),
        kind=GoalNodeKind.SCIENTIFIC_QUESTION,
        rationale="The program must not assume that factual storage is the bottleneck.",
        success=("at least one matched intervention separates competing models",),
        falsification=("the proposed models make indistinguishable predictions",),
        artifact="frozen causal-model comparison",
        tags=("causal-models", "null-model", "factorial"),
    )
    horizon_transfer = _node(
        goal.goal_id,
        title="Local-to-terminal transfer map",
        question="Which cheap-horizon effects persist, reverse, or disappear later?",
        kind=GoalNodeKind.SCIENTIFIC_QUESTION,
        rationale="Small-scale wins are useful only when their terminal reliability is measured.",
        success=(
            "predictions are registered before every higher horizon",
            "the dossier contains matched transfers and transport failures",
        ),
        falsification=("higher-horizon evidence was adaptively reused for development",),
        artifact="multi-horizon prediction and contrast atlas",
        tags=("horizon-transport", "dossier", "quarantine"),
    )
    representation = _node(
        goal.goal_id,
        title="Representation adequacy and latent-concept discovery",
        question=(
            "Can current descriptors predict which local effects transfer, and "
            "if not, what new concept explains the opposing outcomes?"
        ),
        kind=GoalNodeKind.SCIENTIFIC_QUESTION,
        rationale=(
            "A new router or selector is unjustified when the available concepts "
            "cannot distinguish the required decisions."
        ),
        success=(
            "representation insufficiency is established on held-out contrasts",
            "a concept adds frozen predictive information",
            "the validated concept changes generated executable hypotheses",
        ),
        falsification=(
            "the old representation already explains the contrast",
            "the concept is only a post-hoc label or does not change generation",
        ),
        artifact="validated concept and generator-revision certificate",
        tags=("latent-concept", "representation-change", "generation"),
    )

    capabilities = {
        "procedures": (
            "Reusable procedural substrate",
            "Does the learner preserve compositional procedures under knowledge and context changes?",
            "procedure OOD and composition report",
        ),
        "rapid_learning": (
            "Rapid task learning",
            "Can unseen procedures be acquired from few demonstrations without damaging old skills?",
            "few-shot acquisition and retention report",
        ),
        "boundary": (
            "Knowledge-boundary control",
            "Can the learner choose among answer, retrieve, clarify, and abstain with calibrated utility?",
            "knowledge-boundary decision policy",
        ),
        "evidence": (
            "Reliable evidence use",
            "Can relevant, irrelevant, conflicting, and adversarial evidence be handled correctly?",
            "evidence integration and provenance report",
        ),
        "updating": (
            "Non-destructive knowledge updating",
            "Can targeted knowledge change without retraining or unrelated-skill destruction?",
            "update reversibility and retention report",
        ),
    }
    capability_nodes: Dict[str, GoalNodeSpec] = {}
    for key, (title, question, artifact) in capabilities.items():
        capability_nodes[key] = _node(
            goal.goal_id,
            title=title,
            question=question,
            kind=GoalNodeKind.CAPABILITY,
            rationale="This is a necessary, non-substitutable terminal capability.",
            success=("the frozen capability floor passes on unseen task families",),
            falsification=("a matched incumbent remains superior or another capability regresses",),
            artifact=artifact,
            tags=("capability", key.replace("_", "-")),
        )

    validations = {
        "synthetic": "Synthetic causal validation",
        "natural": "Natural-language validation",
        "scale": "Architecture and scale transfer",
        "shift": "Distribution-shift and adversarial validation",
        "cost": "End-to-end system-cost validation",
    }
    validation_nodes = {
        key: _node(
            goal.goal_id,
            title=title,
            question="Does the frozen candidate pass %s?" % title.lower(),
            kind=GoalNodeKind.SCIENTIFIC_QUESTION,
            rationale="Each terminal axis blocks a broader claim when unresolved.",
            success=("the preregistered independent gate passes",),
            falsification=("the frozen candidate fails or the partition was exposed adaptively",),
            artifact=title.lower() + " report",
            tags=("validation", key),
        )
        for key, title in validations.items()
    }

    nodes = {
        "measurement": measurement,
        "diagnosis": diagnosis,
        "integrated": integrated,
        "validation": validation,
        "causal_models": causal_models,
        "horizon_transfer": horizon_transfer,
        "representation": representation,
        **capability_nodes,
        **{"validation_" + key: value for key, value in validation_nodes.items()},
    }

    def proposal(
        parent: GoalNodeSpec,
        children: Tuple[GoalNodeSpec, ...],
        name: str,
    ) -> GoalGraphDecompositionProposal:
        rule = ParentCompositionRule(
            parent_id=parent.node_id,
            child_ids=tuple(child.node_id for child in children),
            operator=CompositionOperator.ALL,
            integration_test=(
                "Every child must pass its frozen parent-specific integration "
                "test without violating another capability floor."
            ),
            rationale=name,
            decomposer_ref=COGNITIVE_GOAL_PROGRAM_VERSION,
        )
        return GoalGraphDecompositionProposal(
            parent_id=parent.node_id,
            nodes=children,
            rule=rule,
            assumptions=(
                "capabilities are non-substitutable",
                "higher horizons remain quarantined until prediction freeze",
            ),
            distinguishing_predictions=(
                "local success without terminal transfer cannot satisfy the parent",
            ),
            reasoning=name,
        )

    decompositions = (
        proposal(
            root,
            (measurement, diagnosis, integrated, validation),
            "The root requires measurement, diagnosis, integration, and validation.",
        ),
        proposal(
            diagnosis,
            (causal_models, horizon_transfer, representation),
            "Diagnosis requires causal discrimination, transfer evidence, and representation tests.",
        ),
        proposal(
            integrated,
            tuple(capability_nodes.values()),
            "All five cognitive capabilities must coexist in one learner.",
        ),
        proposal(
            validation,
            tuple(validation_nodes.values()),
            "The terminal claim requires every independent validation axis.",
        ),
    )
    dependencies = (
        DependencyEdge(
            source_id=diagnosis.node_id,
            target_id=measurement.node_id,
            kind=DependencyKind.REQUIRES,
            rationale="Diagnosis is uninterpretable before measurement qualification.",
        ),
        DependencyEdge(
            source_id=integrated.node_id,
            target_id=diagnosis.node_id,
            kind=DependencyKind.REQUIRES,
            rationale="Architecture search follows causal and representation diagnosis.",
        ),
        DependencyEdge(
            source_id=validation.node_id,
            target_id=integrated.node_id,
            kind=DependencyKind.REQUIRES,
            rationale="Terminal evaluation requires a frozen integrated candidate.",
        ),
    )
    return CognitiveCoreGoalGraphSpec(
        root=root,
        nodes=nodes,
        decompositions=decompositions,
        dependencies=dependencies,
    )


def build_control_plane(
    *,
    artifact_store: Optional[ArtifactStore] = None,
) -> AutonomousScientistControlPlane:
    """Create the fresh durable root; literature closure precedes registration."""

    goal = high_level_goal()
    spec = fresh_goal_graph_spec()
    return AutonomousScientistControlPlane(
        goal,
        spec.root,
        artifact_store=artifact_store,
        controller_ref=COGNITIVE_GOAL_PROGRAM_VERSION,
    )
