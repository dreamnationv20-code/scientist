from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
import platform
import time
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_factorial_mlx_v3 import (
    FactorialCheckpoint,
    FactorialResourceLedger,
)
from scientist.domains.cognitive_core.learning import (
    ABSTAIN_CLASS,
    EVIDENCE_MATCH,
    LEARNING_CONTRACT_VERSION,
    NIBBLE_BASE,
    PAD,
    SEQUENCE_LENGTH,
    TASK_PROCEDURE,
    VOCAB_SIZE,
    EncodedExample,
    LearningConfig,
    evaluation_suite,
    family_counts,
    training_batch,
)


GRADED_CAUSAL_LAB_VERSION = "cognitive-core-graded-causal-mlx-v3"
GRADED_CAUSAL_PROTOCOL_REF = "cognitive-core-causal-model-selection-v3"
GRADED_CAUSAL_EVALUATOR_REF = "graded-causal-mlx-evaluator-v3"


@dataclass(frozen=True)
class GradedArmSpec:
    arm_id: str
    capacity_level: float = 0.0
    representation_level: float = 0.0
    routing_correct_fraction: float = 0.0
    routing_noise_fraction: float = 0.0
    curriculum_window_steps: int = 1
    sham: bool = False

    def __post_init__(self) -> None:
        if not self.arm_id:
            raise ValueError("graded arm identity must not be empty")
        for value in (
            self.capacity_level,
            self.representation_level,
            self.routing_correct_fraction,
            self.routing_noise_fraction,
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError("graded factor levels must lie in [0, 1]")
        if (
            self.routing_correct_fraction + self.routing_noise_fraction
            > 1.0
        ):
            raise ValueError("routing exposure fractions cannot exceed one")
        if self.curriculum_window_steps < 1:
            raise ValueError("curriculum window must be positive")
        if self.sham and any(
            (
                self.capacity_level,
                self.representation_level,
                self.routing_correct_fraction,
                self.routing_noise_fraction,
                self.curriculum_window_steps != 1,
            )
        ):
            raise ValueError("sham cannot activate a graded factor")

    @property
    def effective_routing_level(self) -> float:
        return self.routing_correct_fraction - self.routing_noise_fraction

    def kinetics_level(self, total_steps: int) -> float:
        if self.curriculum_window_steps <= 1:
            return 0.0
        return math.log(float(self.curriculum_window_steps)) / math.log(
            float(total_steps)
        )

    def factor_levels(self, total_steps: int) -> Dict[str, float]:
        return {
            "capacity_headroom": self.capacity_level,
            "training_trajectory": self.kinetics_level(total_steps),
            "representation_factorization": self.representation_level,
            "source_control": self.effective_routing_level,
        }

    def as_dict(self, *, total_steps: int | None = None) -> Dict[str, Any]:
        value = {
            "arm_id": self.arm_id,
            "capacity_level": self.capacity_level,
            "representation_level": self.representation_level,
            "routing_correct_fraction": self.routing_correct_fraction,
            "routing_noise_fraction": self.routing_noise_fraction,
            "effective_routing_level": self.effective_routing_level,
            "curriculum_window_steps": self.curriculum_window_steps,
            "sham": self.sham,
        }
        if total_steps is not None:
            value["factor_levels"] = self.factor_levels(total_steps)
        return value


GRADED_BASELINE = GradedArmSpec("baseline")
GRADED_SHAM = GradedArmSpec("sham", sham=True)


def graded_holdout_arm_catalog() -> Tuple[GradedArmSpec, ...]:
    return (
        GRADED_BASELINE,
        GRADED_SHAM,
        GradedArmSpec("routing_half", routing_correct_fraction=0.5),
        GradedArmSpec(
            "routing_noisy",
            routing_correct_fraction=0.75,
            routing_noise_fraction=0.25,
        ),
        GradedArmSpec("routing_full_anchor", routing_correct_fraction=1.0),
        GradedArmSpec("capacity_mid", capacity_level=0.5),
        GradedArmSpec(
            "representation_half",
            representation_level=0.5,
        ),
        GradedArmSpec(
            "capacity_mid+routing_half",
            capacity_level=0.5,
            routing_correct_fraction=0.5,
        ),
        GradedArmSpec(
            "representation_half+routing_half",
            representation_level=0.5,
            routing_correct_fraction=0.5,
        ),
        GradedArmSpec(
            "all_beneficial_mid",
            capacity_level=0.5,
            representation_level=0.5,
            routing_correct_fraction=0.5,
        ),
        GradedArmSpec(
            "capacity_full+routing_full",
            capacity_level=1.0,
            routing_correct_fraction=1.0,
        ),
        GradedArmSpec(
            "representation_full+routing_full",
            representation_level=1.0,
            routing_correct_fraction=1.0,
        ),
        GradedArmSpec(
            "all_beneficial_full",
            capacity_level=1.0,
            representation_level=1.0,
            routing_correct_fraction=1.0,
        ),
        GradedArmSpec(
            "local_curriculum_window_20",
            curriculum_window_steps=20,
        ),
    )


def _example_payload(example: EncodedExample) -> Dict[str, Any]:
    return {
        "tokens": list(example.tokens),
        "label": example.label,
        "family": example.family,
        "pair_id": example.pair_id,
    }


def _example_digest(example: EncodedExample) -> str:
    return content_digest(_example_payload(example))


_FAMILY_BLOCK_ORDER = {
    "procedure": 0,
    "memory": 1,
    "oracle_evidence": 2,
    "irrelevant_evidence": 3,
    "conflicting_evidence": 4,
    "unknown": 5,
}


@dataclass(frozen=True)
class GradedTrainingPlan:
    batches: Tuple[Tuple[EncodedExample, ...], ...]
    raw_multiset_digest: str
    ordered_examples_digest: str
    family_counts: Mapping[str, int]
    example_count: int
    batch_size: int
    curriculum_window_steps: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "raw_multiset_digest": self.raw_multiset_digest,
            "ordered_examples_digest": self.ordered_examples_digest,
            "family_counts": dict(sorted(self.family_counts.items())),
            "example_count": self.example_count,
            "batch_size": self.batch_size,
            "step_count": len(self.batches),
            "curriculum_window_steps": self.curriculum_window_steps,
        }


def build_graded_training_plan(
    config: LearningConfig,
    arm: GradedArmSpec,
) -> GradedTrainingPlan:
    if arm.curriculum_window_steps > config.steps:
        raise ValueError("curriculum window cannot exceed training steps")
    canonical = tuple(
        example
        for step in range(config.steps)
        for example in training_batch(config, step)
    )
    window_size = arm.curriculum_window_steps * config.batch_size
    ordered: List[EncodedExample] = []
    for start in range(0, len(canonical), window_size):
        window = canonical[start : start + window_size]
        if arm.curriculum_window_steps == 1:
            ordered.extend(window)
        else:
            ordered.extend(
                example
                for _, example in sorted(
                    enumerate(window),
                    key=lambda item: (
                        _FAMILY_BLOCK_ORDER[item[1].family],
                        item[0],
                    ),
                )
            )
    batches = tuple(
        tuple(ordered[start : start + config.batch_size])
        for start in range(0, len(ordered), config.batch_size)
    )
    if len(batches) != config.steps or any(
        len(batch) != config.batch_size for batch in batches
    ):
        raise AssertionError("graded plan changed the training budget")
    ordered_tuple = tuple(ordered)
    digests = tuple(_example_digest(example) for example in ordered_tuple)
    return GradedTrainingPlan(
        batches=batches,
        raw_multiset_digest=content_digest(sorted(digests)),
        ordered_examples_digest=content_digest(digests),
        family_counts=family_counts(ordered_tuple),
        example_count=len(ordered_tuple),
        batch_size=config.batch_size,
        curriculum_window_steps=arm.curriculum_window_steps,
    )


def _decoded_key(tokens: Sequence[int], offset: int) -> int | None:
    high, low = tokens[offset], tokens[offset + 1]
    if high < NIBBLE_BASE or low < NIBBLE_BASE:
        return None
    return (high - NIBBLE_BASE) * 16 + (low - NIBBLE_BASE)


def _routing_selector(tokens: Sequence[int], salt: str) -> float:
    payload = repr((tuple(tokens), salt)).encode("utf-8")
    integer = int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")
    return integer / float(2**64)


def _route_tokens(
    tokens: Sequence[int],
    *,
    invert: bool,
) -> Tuple[int, ...]:
    routed = list(tokens)
    query = _decoded_key(tokens, 5)
    if query is None:
        return tuple(routed)
    for key_offset, flag_offset in ((7, 10), (11, 14)):
        evidence_key = _decoded_key(tokens, key_offset)
        if evidence_key is None:
            routed[flag_offset] = PAD
            continue
        matches = evidence_key == query
        retain = (not matches) if invert else matches
        if retain:
            routed[flag_offset] = EVIDENCE_MATCH
        else:
            routed[key_offset : flag_offset + 1] = [PAD] * 4
    return tuple(routed)


def graded_model_facing_tokens(
    examples: Sequence[EncodedExample],
    arm: GradedArmSpec,
) -> Tuple[Tuple[int, ...], ...]:
    values: List[Tuple[int, ...]] = []
    correct_cutoff = arm.routing_correct_fraction
    noise_cutoff = correct_cutoff + arm.routing_noise_fraction
    for example in examples:
        selector = _routing_selector(example.tokens, "graded-routing-v3")
        if selector < correct_cutoff:
            selected = _route_tokens(example.tokens, invert=False)
        elif selector < noise_cutoff:
            selected = _route_tokens(example.tokens, invert=True)
        else:
            selected = example.tokens
        if arm.sham:
            selected = tuple(reversed(tuple(reversed(selected))))
        values.append(tuple(selected))
    return tuple(values)


def active_width(config: LearningConfig, arm: GradedArmSpec) -> int:
    base = config.width // 4
    headroom = config.width // 2
    value = round(base + arm.capacity_level * (headroom - base))
    return max(1, min(headroom, value))


def memory_window_start(config: LearningConfig, arm: GradedArmSpec) -> int:
    width = active_width(config, arm)
    maximum_start = min(width, config.width - width)
    return round(arm.representation_level * maximum_start)


class GradedCognitiveTransformer(nn.Module):
    def __init__(self, config: LearningConfig, arm: GradedArmSpec) -> None:
        super().__init__()
        if config.width % 4:
            raise ValueError("graded lab width must be divisible by four")
        self.width = config.width
        self.active_width = active_width(config, arm)
        self.memory_start = memory_window_start(config, arm)
        self.token_embedding = nn.Embedding(VOCAB_SIZE, config.width)
        self.position_embedding = nn.Embedding(SEQUENCE_LENGTH, config.width)
        self.layers = [
            nn.TransformerEncoderLayer(
                dims=config.width,
                num_heads=config.heads,
                mlp_dims=4 * config.width,
                dropout=0.0,
                norm_first=True,
            )
            for _ in range(config.layers)
        ]
        self.norm = nn.LayerNorm(config.width)
        self.output = nn.Linear(config.width, ABSTAIN_CLASS + 1)

    def _feature_mask(self, tokens: mx.array) -> mx.array:
        procedure = (
            [1.0] * self.active_width
            + [0.0] * (self.width - self.active_width)
        )
        memory = (
            [0.0] * self.memory_start
            + [1.0] * self.active_width
            + [0.0]
            * (self.width - self.memory_start - self.active_width)
        )
        procedure_mask = mx.array(procedure).reshape((1, 1, self.width))
        memory_mask = mx.array(memory).reshape((1, 1, self.width))
        is_procedure = (tokens[:, 1] == TASK_PROCEDURE).reshape(
            (tokens.shape[0], 1, 1)
        )
        return mx.where(is_procedure, procedure_mask, memory_mask)

    def __call__(self, tokens: mx.array) -> mx.array:
        positions = mx.arange(tokens.shape[1])
        mask = self._feature_mask(tokens)
        hidden = (
            self.token_embedding(tokens)
            + self.position_embedding(positions)
        ) * mask
        for layer in self.layers:
            hidden = layer(hidden, None) * mask
        pooled = self.norm(hidden[:, 0, :]) * mask[:, 0, :]
        return self.output(pooled)


def graded_mask_signature(
    config: LearningConfig,
    arm: GradedArmSpec,
) -> Dict[str, Any]:
    width = active_width(config, arm)
    memory_start = memory_window_start(config, arm)
    procedure = tuple(range(width))
    memory = tuple(range(memory_start, memory_start + width))
    return {
        "full_width": config.width,
        "active_width_per_task": width,
        "procedure_dimensions": list(procedure),
        "memory_dimensions": list(memory),
        "overlap_dimensions": len(set(procedure).intersection(memory)),
        "model_shape_changes": False,
    }


def _parameter_count(model: GradedCognitiveTransformer) -> int:
    return sum(
        math.prod(array.shape)
        for _, array in tree_flatten(model.parameters())
    )


def _parameter_digest(model: GradedCognitiveTransformer) -> str:
    digest = hashlib.sha256()
    for name, array in tree_flatten(model.parameters()):
        mx.eval(array)
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(array.shape)).encode("ascii"))
        digest.update(repr(array.tolist()).encode("utf-8"))
    return digest.hexdigest()


def _arrays(
    examples: Sequence[EncodedExample],
    arm: GradedArmSpec,
) -> Tuple[mx.array, mx.array]:
    return (
        mx.array(graded_model_facing_tokens(examples, arm), dtype=mx.int32),
        mx.array([example.label for example in examples], dtype=mx.int32),
    )


def _predict(
    model: GradedCognitiveTransformer,
    examples: Sequence[EncodedExample],
    arm: GradedArmSpec,
    batch_size: int = 256,
) -> Tuple[int, ...]:
    predictions: List[int] = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        tokens, _ = _arrays(examples[start : start + batch_size], arm)
        batch_predictions = mx.argmax(model(tokens), axis=-1)
        mx.eval(batch_predictions)
        predictions.extend(int(value) for value in batch_predictions.tolist())
    model.train()
    return tuple(predictions)


def _evaluation_metrics(
    model: GradedCognitiveTransformer,
    examples: Sequence[EncodedExample],
    arm: GradedArmSpec,
) -> Dict[str, float]:
    predictions = _predict(model, examples, arm)
    correct: Dict[str, int] = {}
    total: Dict[str, int] = {}
    closed_book: Dict[str, bool] = {}
    irrelevant: Dict[str, bool] = {}
    for example, prediction in zip(examples, predictions):
        item_correct = prediction == example.label
        correct[example.family] = correct.get(example.family, 0) + int(
            item_correct
        )
        total[example.family] = total.get(example.family, 0) + 1
        if example.family == "closed_book":
            closed_book[example.pair_id] = item_correct
        elif example.family == "irrelevant_evidence":
            irrelevant[example.pair_id] = item_correct
    metrics = {
        family + "_accuracy": correct[family] / float(total[family])
        for family in sorted(total)
    }
    eligible = [pair for pair, item_correct in closed_book.items() if item_correct]
    metrics["known_answer_destruction"] = (
        sum(not irrelevant.get(pair, False) for pair in eligible)
        / float(len(eligible))
        if eligible
        else 0.0
    )
    components = (
        metrics["procedure_accuracy"],
        metrics["oracle_evidence_accuracy"],
        metrics["unknown_accuracy"],
        1.0 - metrics["known_answer_destruction"],
    )
    metrics["cognitive_core_score"] = math.prod(
        max(1e-6, component) for component in components
    ) ** (1.0 / len(components))
    return metrics


def _evaluation_digest(examples: Iterable[EncodedExample]) -> str:
    return content_digest([_example_payload(example) for example in examples])


def _model_input_digest(
    plan: GradedTrainingPlan,
    arm: GradedArmSpec,
) -> str:
    return content_digest(
        [
            list(tokens)
            for batch in plan.batches
            for tokens in graded_model_facing_tokens(batch, arm)
        ]
    )


def _routing_counts(
    plan: GradedTrainingPlan,
    arm: GradedArmSpec,
) -> Dict[str, int]:
    counts = {"correctly_routed": 0, "noisily_routed": 0, "untouched": 0}
    correct_cutoff = arm.routing_correct_fraction
    noise_cutoff = correct_cutoff + arm.routing_noise_fraction
    for batch in plan.batches:
        for example in batch:
            selector = _routing_selector(example.tokens, "graded-routing-v3")
            if selector < correct_cutoff:
                counts["correctly_routed"] += 1
            elif selector < noise_cutoff:
                counts["noisily_routed"] += 1
            else:
                counts["untouched"] += 1
    return counts


def _resource_ledger(
    config: LearningConfig,
    parameter_count: int,
    evaluation_count: int,
) -> FactorialResourceLedger:
    checkpoint_passes = 1 + math.ceil(
        config.steps / float(config.checkpoint_interval)
    )
    evaluation_passes = checkpoint_passes + 1
    training_examples = config.steps * config.batch_size
    full_width_token_passes = SEQUENCE_LENGTH * (
        3 * training_examples + evaluation_passes * evaluation_count
    )
    per_token_flops = config.layers * 12 * config.width * config.width
    per_example_output_flops = 2 * config.width * (ABSTAIN_CLASS + 1)
    nominal_flops = (
        full_width_token_passes * per_token_flops
        + (
            3 * training_examples + evaluation_passes * evaluation_count
        )
        * per_example_output_flops
    )
    return FactorialResourceLedger(
        parameter_count=parameter_count,
        optimizer_steps=config.steps,
        training_examples=training_examples,
        raw_training_tokens=training_examples * SEQUENCE_LENGTH,
        evaluation_examples=evaluation_count,
        evaluation_passes=evaluation_passes,
        full_width_token_passes=full_width_token_passes,
        nominal_transformer_flops=nominal_flops,
    )


@dataclass(frozen=True)
class GradedRunResult:
    run_id: str
    arm: GradedArmSpec
    config: LearningConfig
    initial_parameter_digest: str
    parameter_count: int
    raw_multiset_digest: str
    ordered_examples_digest: str
    model_input_digest: str
    routing_counts: Mapping[str, int]
    evaluation_digest: str
    mask_signature: Mapping[str, Any]
    resource_ledger: FactorialResourceLedger
    metrics: Mapping[str, float]
    checkpoints: Tuple[FactorialCheckpoint, ...]
    elapsed_seconds: float
    framework: str = "mlx-0.32"
    lab_version: str = GRADED_CAUSAL_LAB_VERSION
    protocol_ref: str = GRADED_CAUSAL_PROTOCOL_REF
    evaluator_ref: str = GRADED_CAUSAL_EVALUATOR_REF

    def as_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "arm": self.arm.as_dict(total_steps=self.config.steps),
            "config": self.config.as_dict(),
            "initial_parameter_digest": self.initial_parameter_digest,
            "parameter_count": self.parameter_count,
            "raw_multiset_digest": self.raw_multiset_digest,
            "ordered_examples_digest": self.ordered_examples_digest,
            "model_input_digest": self.model_input_digest,
            "routing_counts": dict(sorted(self.routing_counts.items())),
            "evaluation_digest": self.evaluation_digest,
            "mask_signature": dict(self.mask_signature),
            "resource_ledger": {
                **self.resource_ledger.as_dict(),
                "match_signature": self.resource_ledger.match_signature,
            },
            "metrics": dict(sorted(self.metrics.items())),
            "checkpoints": [item.as_dict() for item in self.checkpoints],
            "elapsed_seconds": self.elapsed_seconds,
            "framework": self.framework,
            "hardware": platform.machine() + ":" + self.config.compute_device,
            "lab_version": self.lab_version,
            "learning_contract_version": LEARNING_CONTRACT_VERSION,
            "protocol_ref": self.protocol_ref,
            "evaluator_ref": self.evaluator_ref,
        }


def train_graded_arm(
    config: LearningConfig,
    arm: GradedArmSpec,
) -> GradedRunResult:
    started = time.monotonic()
    if config.relevance_annotation:
        raise ValueError("graded routing requires unannotated frozen inputs")
    mx.set_default_device(mx.cpu if config.compute_device == "cpu" else mx.gpu)
    plan = build_graded_training_plan(config, arm)
    evaluation = evaluation_suite(config)
    mx.random.seed(config.model_seed)
    model = GradedCognitiveTransformer(config, arm)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    parameter_count = _parameter_count(model)
    optimizer = optim.AdamW(
        learning_rate=config.learning_rate,
        weight_decay=0.0001,
    )

    def loss_fn(
        active_model: GradedCognitiveTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens),
            labels,
            reduction="mean",
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints: List[FactorialCheckpoint] = [
        FactorialCheckpoint(
            step=0,
            loss=-1.0,
            metrics=_evaluation_metrics(model, evaluation, arm),
        )
    ]
    last_loss = float("nan")
    model.train()
    for step, batch in enumerate(plan.batches, start=1):
        tokens, labels = _arrays(batch, arm)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
        if step % config.checkpoint_interval == 0 or step == config.steps:
            checkpoints.append(
                FactorialCheckpoint(
                    step=step,
                    loss=last_loss,
                    metrics=_evaluation_metrics(model, evaluation, arm),
                )
            )
            model.train()
    metrics = _evaluation_metrics(model, evaluation, arm)
    metrics["final_training_loss"] = last_loss
    ledger = _resource_ledger(config, parameter_count, len(evaluation))
    payload = {
        "lab_version": GRADED_CAUSAL_LAB_VERSION,
        "protocol_ref": GRADED_CAUSAL_PROTOCOL_REF,
        "config": config.as_dict(),
        "arm": arm.as_dict(total_steps=config.steps),
        "initial_parameter_digest": initial_parameter_digest,
        "raw_multiset_digest": plan.raw_multiset_digest,
        "ordered_examples_digest": plan.ordered_examples_digest,
        "evaluation_digest": _evaluation_digest(evaluation),
        "resource_signature": ledger.match_signature,
    }
    return GradedRunResult(
        run_id=content_digest(payload)[:20],
        arm=arm,
        config=config,
        initial_parameter_digest=initial_parameter_digest,
        parameter_count=parameter_count,
        raw_multiset_digest=plan.raw_multiset_digest,
        ordered_examples_digest=plan.ordered_examples_digest,
        model_input_digest=_model_input_digest(plan, arm),
        routing_counts=_routing_counts(plan, arm),
        evaluation_digest=_evaluation_digest(evaluation),
        mask_signature=graded_mask_signature(config, arm),
        resource_ledger=ledger,
        metrics=metrics,
        checkpoints=tuple(checkpoints),
        elapsed_seconds=time.monotonic() - started,
    )
