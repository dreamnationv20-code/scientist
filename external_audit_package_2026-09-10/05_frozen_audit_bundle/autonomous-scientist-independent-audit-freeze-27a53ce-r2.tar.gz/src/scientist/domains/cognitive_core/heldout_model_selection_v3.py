from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_atlas_analysis_v3 import (
    FINAL_DIAGNOSTIC_METRICS,
    EmpiricalCausalAtlas,
    PairedEffect,
)
from scientist.domains.cognitive_core.graded_causal_mlx_v3 import (
    GRADED_CAUSAL_PROTOCOL_REF,
    GradedArmSpec,
    GradedRunResult,
    graded_holdout_arm_catalog,
)
from scientist.program.diagnostics import DiagnosticDisposition


HELDOUT_MODEL_SELECTION_VERSION = "cognitive-core-heldout-model-selection-v3"
HELDOUT_MODEL_SELECTION_EVALUATOR_REF = "heldout-model-selection-evaluator-v3"
PREDICTION_RESIDUAL_FLOOR = {
    metric: (0.05 if metric == "cognitive_core_score" else 0.08)
    for metric in FINAL_DIAGNOSTIC_METRICS
}
MIN_SCORE_MARGIN = 0.025
MAX_SELECTED_RMSE = 0.12
MIN_SELECTED_PROBABILITY = 0.80
MIN_SEED_STABILITY = 2.0 / 3.0


FACTOR_ORDER = (
    "capacity_headroom",
    "training_trajectory",
    "representation_factorization",
    "source_control",
)


@dataclass(frozen=True)
class CompetingModelSpec:
    model_id: str
    main_factors: Tuple[str, ...]
    interaction_pairs: Tuple[Tuple[str, str], ...] = ()
    disposition: DiagnosticDisposition = DiagnosticDisposition.SUPPORTED

    def __post_init__(self) -> None:
        if not self.model_id:
            raise ValueError("competing model identity must not be empty")
        if len(set(self.main_factors)) != len(self.main_factors):
            raise ValueError("competing model factors must be unique")
        if any(item not in FACTOR_ORDER for item in self.main_factors):
            raise ValueError("competing model contains an unknown factor")
        if any(
            left not in self.main_factors or right not in self.main_factors
            for left, right in self.interaction_pairs
        ):
            raise ValueError("interactions require both main effects")

    @property
    def complexity(self) -> int:
        return len(self.main_factors) + len(self.interaction_pairs)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "main_factors": list(self.main_factors),
            "interaction_pairs": [list(item) for item in self.interaction_pairs],
            "complexity": self.complexity,
            "disposition": self.disposition.value,
        }


def _pairs(factors: Sequence[str]) -> Tuple[Tuple[str, str], ...]:
    return tuple(
        (factors[left], factors[right])
        for left in range(len(factors))
        for right in range(left + 1, len(factors))
    )


def competing_model_catalog() -> Tuple[CompetingModelSpec, ...]:
    beneficial = (
        "capacity_headroom",
        "representation_factorization",
        "source_control",
    )
    return (
        CompetingModelSpec(
            "null",
            (),
            disposition=DiagnosticDisposition.REFUTED,
        ),
        CompetingModelSpec("capacity", ("capacity_headroom",)),
        CompetingModelSpec("kinetics", ("training_trajectory",)),
        CompetingModelSpec(
            "representation",
            ("representation_factorization",),
        ),
        CompetingModelSpec("routing", ("source_control",)),
        CompetingModelSpec(
            "capacity+routing_additive",
            ("capacity_headroom", "source_control"),
            disposition=DiagnosticDisposition.MIXED,
        ),
        CompetingModelSpec(
            "capacity+routing_interaction",
            ("capacity_headroom", "source_control"),
            (("capacity_headroom", "source_control"),),
            DiagnosticDisposition.MIXED,
        ),
        CompetingModelSpec(
            "representation+routing_additive",
            ("representation_factorization", "source_control"),
            disposition=DiagnosticDisposition.MIXED,
        ),
        CompetingModelSpec(
            "representation+routing_interaction",
            ("representation_factorization", "source_control"),
            (("representation_factorization", "source_control"),),
            DiagnosticDisposition.MIXED,
        ),
        CompetingModelSpec(
            "beneficial_additive",
            beneficial,
            disposition=DiagnosticDisposition.MIXED,
        ),
        CompetingModelSpec(
            "beneficial_factorial",
            beneficial,
            _pairs(beneficial),
            DiagnosticDisposition.MIXED,
        ),
        CompetingModelSpec(
            "full_additive",
            FACTOR_ORDER,
            disposition=DiagnosticDisposition.MIXED,
        ),
        CompetingModelSpec(
            "full_factorial",
            FACTOR_ORDER,
            _pairs(FACTOR_ORDER),
            DiagnosticDisposition.MIXED,
        ),
    )


def _pair_arm_id(left: str, right: str) -> str:
    ordered = tuple(item for item in FACTOR_ORDER if item in (left, right))
    if len(ordered) != 2:
        raise ValueError("interaction pair must contain distinct known factors")
    return "+".join(ordered)


@dataclass(frozen=True)
class QuantitativePrediction:
    mean: float
    standard_error: float

    def as_dict(self) -> Dict[str, float]:
        return {
            "mean": self.mean,
            "standard_error": self.standard_error,
        }


@dataclass(frozen=True)
class FrozenModelPredictionRegistry:
    source_atlas_id: str
    source_atlas_version: str
    data_seed: int
    model_seeds: Tuple[int, ...]
    total_steps: int
    arms: Tuple[GradedArmSpec, ...]
    models: Tuple[CompetingModelSpec, ...]
    predictions: Mapping[
        str,
        Mapping[str, Mapping[str, QuantitativePrediction]],
    ]
    protocol_ref: str = GRADED_CAUSAL_PROTOCOL_REF
    version: str = HELDOUT_MODEL_SELECTION_VERSION

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, *, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": self.version,
            "protocol_ref": self.protocol_ref,
            "source_atlas_id": self.source_atlas_id,
            "source_atlas_version": self.source_atlas_version,
            "data_seed": self.data_seed,
            "model_seeds": list(self.model_seeds),
            "total_steps": self.total_steps,
            "arms": [arm.as_dict(total_steps=self.total_steps) for arm in self.arms],
            "models": [model.as_dict() for model in self.models],
            "predictions": {
                model_id: {
                    arm_id: {
                        metric: prediction.as_dict()
                        for metric, prediction in sorted(metrics.items())
                    }
                    for arm_id, metrics in sorted(arms.items())
                }
                for model_id, arms in sorted(self.predictions.items())
            },
            "scoring_rule": {
                "kind": "heldout Gaussian predictive likelihood",
                "residual_floor": dict(PREDICTION_RESIDUAL_FLOOR),
                "complexity_penalty_per_term": 0.01,
                "minimum_score_margin": MIN_SCORE_MARGIN,
                "maximum_selected_rmse": MAX_SELECTED_RMSE,
                "minimum_selected_probability": MIN_SELECTED_PROBABILITY,
                "minimum_leave_one_seed_stability": MIN_SEED_STABILITY,
                "ambiguity_disposition": "inconclusive",
            },
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


def _scaled_effect(
    effect: PairedEffect,
    coefficient: float,
) -> QuantitativePrediction:
    return QuantitativePrediction(
        mean=coefficient * effect.mean,
        standard_error=abs(coefficient) * effect.standard_error,
    )


def freeze_model_predictions(
    source_atlas: EmpiricalCausalAtlas,
    *,
    source_atlas_id: str,
    data_seed: int,
    model_seeds: Sequence[int],
    total_steps: int,
    arms: Sequence[GradedArmSpec] | None = None,
    models: Sequence[CompetingModelSpec] | None = None,
) -> FrozenModelPredictionRegistry:
    arms = tuple(arms or graded_holdout_arm_catalog())
    models = tuple(models or competing_model_catalog())
    if not source_atlas.verification_passed:
        raise ValueError("prediction source atlas failed verification")
    if len(set(model_seeds)) != len(tuple(model_seeds)) or len(model_seeds) < 6:
        raise ValueError("heldout registry requires six unique model seeds")
    predictions: Dict[
        str,
        Dict[str, Dict[str, QuantitativePrediction]],
    ] = {}
    for model in models:
        predictions[model.model_id] = {}
        for arm in arms:
            levels = arm.factor_levels(total_steps)
            predictions[model.model_id][arm.arm_id] = {}
            for metric in FINAL_DIAGNOSTIC_METRICS:
                mean = 0.0
                variance = 0.0
                for factor in model.main_factors:
                    scaled = _scaled_effect(
                        source_atlas.effects[factor][metric],
                        levels[factor],
                    )
                    mean += scaled.mean
                    variance += scaled.standard_error**2
                for left, right in model.interaction_pairs:
                    coefficient = levels[left] * levels[right]
                    scaled = _scaled_effect(
                        source_atlas.interaction_residuals[
                            _pair_arm_id(left, right)
                        ][metric],
                        coefficient,
                    )
                    mean += scaled.mean
                    variance += scaled.standard_error**2
                predictions[model.model_id][arm.arm_id][metric] = (
                    QuantitativePrediction(
                        mean=mean,
                        standard_error=math.sqrt(variance),
                    )
                )
    return FrozenModelPredictionRegistry(
        source_atlas_id=source_atlas_id,
        source_atlas_version=source_atlas.analysis_version,
        data_seed=data_seed,
        model_seeds=tuple(model_seeds),
        total_steps=total_steps,
        arms=tuple(arms),
        models=tuple(models),
        predictions=predictions,
    )


@dataclass(frozen=True)
class HeldoutOutcome:
    mean: float
    standard_error: float
    samples: Tuple[float, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "mean": self.mean,
            "standard_error": self.standard_error,
            "samples": list(self.samples),
        }


def _outcome(samples: Sequence[float]) -> HeldoutOutcome:
    if len(samples) < 2:
        raise ValueError("heldout outcome requires at least two seeds")
    mean = sum(samples) / float(len(samples))
    variance = sum((item - mean) ** 2 for item in samples) / float(
        len(samples) - 1
    )
    return HeldoutOutcome(
        mean=mean,
        standard_error=math.sqrt(variance / len(samples)),
        samples=tuple(samples),
    )


def build_heldout_outcomes(
    runs: Sequence[GradedRunResult],
) -> Dict[str, Dict[str, HeldoutOutcome]]:
    if not runs:
        raise ValueError("heldout outcome construction requires runs")
    seeds = tuple(sorted({run.config.model_seed for run in runs}))
    arms = {run.arm.arm_id for run in runs}
    cells = {(run.config.model_seed, run.arm.arm_id): run for run in runs}
    if "baseline" not in arms or len(cells) != len(seeds) * len(arms):
        raise ValueError("heldout outcomes require a complete seed-by-arm matrix")
    values: Dict[str, Dict[str, HeldoutOutcome]] = {}
    for arm_id in sorted(arms):
        if arm_id == "baseline":
            continue
        values[arm_id] = {}
        for metric in FINAL_DIAGNOSTIC_METRICS:
            values[arm_id][metric] = _outcome(
                tuple(
                    float(cells[(seed, arm_id)].metrics[metric])
                    - float(cells[(seed, "baseline")].metrics[metric])
                    for seed in seeds
                )
            )
    return values


@dataclass(frozen=True)
class ModelFit:
    model_id: str
    predictive_log_score: float
    rmse: float
    posterior_probability: float
    leave_one_seed_out_win_fraction: float
    complexity: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "predictive_log_score": self.predictive_log_score,
            "rmse": self.rmse,
            "posterior_probability": self.posterior_probability,
            "leave_one_seed_out_win_fraction": (
                self.leave_one_seed_out_win_fraction
            ),
            "complexity": self.complexity,
        }


@dataclass(frozen=True)
class HeldoutModelSelection:
    fits: Mapping[str, ModelFit]
    supported_model_ids: Tuple[str, ...]
    disposition: DiagnosticDisposition
    checks: Mapping[str, bool]
    score_margin: float
    outcome_count: int
    seed_count: int
    registry_id: str
    version: str = HELDOUT_MODEL_SELECTION_VERSION

    @property
    def resolved(self) -> bool:
        return (
            all(self.checks.values())
            and self.disposition != DiagnosticDisposition.INCONCLUSIVE
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "registry_id": self.registry_id,
            "fits": {
                key: value.as_dict() for key, value in sorted(self.fits.items())
            },
            "supported_model_ids": list(self.supported_model_ids),
            "disposition": self.disposition.value,
            "checks": dict(sorted(self.checks.items())),
            "score_margin": self.score_margin,
            "outcome_count": self.outcome_count,
            "seed_count": self.seed_count,
            "resolved": self.resolved,
        }


def _score_one_model(
    model: CompetingModelSpec,
    predictions: Mapping[str, Mapping[str, QuantitativePrediction]],
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
    *,
    leave_out_seed: int | None = None,
) -> Tuple[float, float]:
    log_scores = []
    squared_errors = []
    for arm_id, metrics in outcomes.items():
        if arm_id == "sham":
            # Sham is a validity control rather than a mechanism discriminator.
            continue
        for metric, observed in metrics.items():
            prediction = predictions[arm_id][metric]
            if leave_out_seed is None:
                observed_mean = observed.mean
                observed_se = observed.standard_error
            else:
                retained = tuple(
                    sample
                    for index, sample in enumerate(observed.samples)
                    if index != leave_out_seed
                )
                reduced = _outcome(retained)
                observed_mean = reduced.mean
                observed_se = reduced.standard_error
            variance = (
                observed_se**2
                + prediction.standard_error**2
                + PREDICTION_RESIDUAL_FLOOR[metric] ** 2
            )
            residual = observed_mean - prediction.mean
            log_scores.append(
                -0.5
                * (
                    residual**2 / variance
                    + math.log(2.0 * math.pi * variance)
                )
            )
            squared_errors.append(residual**2)
    mean_log_score = sum(log_scores) / float(len(log_scores))
    mean_log_score -= 0.01 * model.complexity
    rmse = math.sqrt(sum(squared_errors) / float(len(squared_errors)))
    return mean_log_score, rmse


def score_competing_models(
    registry: FrozenModelPredictionRegistry,
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
) -> HeldoutModelSelection:
    expected_arms = {arm.arm_id for arm in registry.arms} - {"baseline"}
    if set(outcomes) != expected_arms:
        raise ValueError("heldout outcomes do not match the frozen arm registry")
    model_by_id = {model.model_id: model for model in registry.models}
    raw: Dict[str, Tuple[float, float]] = {}
    for model in registry.models:
        raw[model.model_id] = _score_one_model(
            model,
            registry.predictions[model.model_id],
            outcomes,
        )
    maximum = max(score for score, _ in raw.values())
    outcome_count = sum(
        len(metrics) for arm, metrics in outcomes.items() if arm != "sham"
    )
    weights = {
        model_id: math.exp(
            max(-700.0, min(0.0, (score - maximum) * outcome_count))
        )
        for model_id, (score, _) in raw.items()
    }
    total_weight = sum(weights.values())
    seed_count = len(next(iter(next(iter(outcomes.values())).values())).samples)
    leave_one_winners = []
    for seed_index in range(seed_count):
        scores = {
            model.model_id: _score_one_model(
                model,
                registry.predictions[model.model_id],
                outcomes,
                leave_out_seed=seed_index,
            )[0]
            for model in registry.models
        }
        leave_one_winners.append(max(scores, key=scores.get))
    fits = {
        model_id: ModelFit(
            model_id=model_id,
            predictive_log_score=score,
            rmse=rmse,
            posterior_probability=weights[model_id] / total_weight,
            leave_one_seed_out_win_fraction=(
                leave_one_winners.count(model_id) / float(seed_count)
            ),
            complexity=model_by_id[model_id].complexity,
        )
        for model_id, (score, rmse) in raw.items()
    }
    ordered = sorted(
        fits.values(),
        key=lambda item: item.predictive_log_score,
        reverse=True,
    )
    top = ordered[0]
    margin = top.predictive_log_score - ordered[1].predictive_log_score
    distinguishable = (
        margin >= MIN_SCORE_MARGIN
        and top.rmse <= MAX_SELECTED_RMSE
        and top.posterior_probability >= MIN_SELECTED_PROBABILITY
        and top.leave_one_seed_out_win_fraction >= MIN_SEED_STABILITY
    )
    if distinguishable:
        supported = (top.model_id,)
        disposition = model_by_id[top.model_id].disposition
    else:
        supported = ()
        disposition = DiagnosticDisposition.INCONCLUSIVE
    checks = {
        "null_model_was_scored": "null" in fits,
        "all_pure_models_were_scored": all(
            item in fits
            for item in ("capacity", "kinetics", "representation", "routing")
        ),
        "mixed_models_were_scored": any(
            model.complexity > 1 for model in registry.models
        ),
        "predictions_cover_every_outcome": all(
            set(registry.predictions[model.model_id])
            >= set(outcomes)
            and all(
                set(registry.predictions[model.model_id][arm_id])
                == set(FINAL_DIAGNOSTIC_METRICS)
                for arm_id in outcomes
            )
            for model in registry.models
        ),
        "uncertainty_is_finite": all(
            math.isfinite(outcome.mean)
            and math.isfinite(outcome.standard_error)
            and outcome.standard_error >= 0.0
            for metrics in outcomes.values()
            for outcome in metrics.values()
        ),
        "at_least_six_heldout_seeds": seed_count >= 6,
        "ambiguity_rule_was_respected": (
            distinguishable
            or (
                disposition == DiagnosticDisposition.INCONCLUSIVE
                and not supported
            )
        ),
    }
    return HeldoutModelSelection(
        fits=fits,
        supported_model_ids=supported,
        disposition=disposition,
        checks=checks,
        score_margin=margin,
        outcome_count=sum(len(metrics) for metrics in outcomes.values()),
        seed_count=seed_count,
        registry_id=registry.registry_id,
    )


def run_model_selection_synthetic_qualification() -> Dict[str, Any]:
    """Recover representative pure, mixed, null, and ambiguous controls."""

    models = competing_model_catalog()
    arms = graded_holdout_arm_catalog()
    metrics = FINAL_DIAGNOSTIC_METRICS
    predictions = {
        model.model_id: {
            arm.arm_id: {
                metric: QuantitativePrediction(
                    mean=(
                        0.18
                        * sum(
                            arm.factor_levels(800)[factor]
                            for factor in model.main_factors
                        )
                        + 0.12
                        * sum(
                            arm.factor_levels(800)[left]
                            * arm.factor_levels(800)[right]
                            for left, right in model.interaction_pairs
                        )
                    ),
                    standard_error=0.01,
                )
                for metric in metrics
            }
            for arm in arms
        }
        for model in models
    }
    registry = FrozenModelPredictionRegistry(
        source_atlas_id="synthetic-source-atlas",
        source_atlas_version="synthetic",
        data_seed=1,
        model_seeds=tuple(range(6)),
        total_steps=800,
        arms=arms,
        models=models,
        predictions=predictions,
    )

    def outcomes_for(model_id: str) -> Dict[str, Dict[str, HeldoutOutcome]]:
        return {
            arm.arm_id: {
                metric: HeldoutOutcome(
                    mean=predictions[model_id][arm.arm_id][metric].mean,
                    standard_error=0.005,
                    samples=tuple(
                        predictions[model_id][arm.arm_id][metric].mean
                        + ((seed % 3) - 1) * 0.005
                        for seed in range(6)
                    ),
                )
                for metric in metrics
            }
            for arm in arms
            if arm.arm_id != "baseline"
        }

    recovered = {}
    for model_id in (
        "null",
        "capacity",
        "routing",
        "capacity+routing_additive",
        "capacity+routing_interaction",
        "beneficial_additive",
        "beneficial_factorial",
    ):
        selection = score_competing_models(registry, outcomes_for(model_id))
        recovered[model_id] = selection.supported_model_ids
    routing_outcomes = outcomes_for("routing")
    ambiguous = {
        arm: {
            metric: HeldoutOutcome(
                mean=outcome.mean * 0.5,
                standard_error=0.2,
                samples=tuple(outcome.mean * 0.5 for _ in range(6)),
            )
            for metric, outcome in values.items()
        }
        for arm, values in routing_outcomes.items()
    }
    ambiguous_result = score_competing_models(registry, ambiguous)
    checks = {
        "null_recovered": recovered["null"] == ("null",),
        "capacity_recovered": recovered["capacity"] == ("capacity",),
        "routing_recovered": recovered["routing"] == ("routing",),
        "capacity_routing_mixed_recovered": (
            recovered["capacity+routing_additive"]
            == ("capacity+routing_additive",)
        ),
        "capacity_routing_interaction_recovered": (
            recovered["capacity+routing_interaction"]
            == ("capacity+routing_interaction",)
        ),
        "three_factor_mixed_recovered": (
            recovered["beneficial_additive"] == ("beneficial_additive",)
        ),
        "three_factor_interaction_recovered": (
            recovered["beneficial_factorial"] == ("beneficial_factorial",)
        ),
        "ambiguous_world_is_inconclusive": (
            ambiguous_result.disposition == DiagnosticDisposition.INCONCLUSIVE
            and not ambiguous_result.supported_model_ids
        ),
    }
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "recovered": {
            key: list(value) for key, value in sorted(recovered.items())
        },
        "ambiguous_disposition": ambiguous_result.disposition.value,
        "version": HELDOUT_MODEL_SELECTION_VERSION,
    }
