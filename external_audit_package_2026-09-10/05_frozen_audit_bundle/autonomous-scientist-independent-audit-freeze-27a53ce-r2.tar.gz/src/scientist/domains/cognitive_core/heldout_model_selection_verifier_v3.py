from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.graded_causal_mlx_v3 import (
    GRADED_CAUSAL_EVALUATOR_REF,
    GradedRunResult,
    active_width,
    memory_window_start,
)
from scientist.domains.cognitive_core.heldout_model_selection_v3 import (
    FrozenModelPredictionRegistry,
    HeldoutModelSelection,
    build_heldout_outcomes,
    score_competing_models,
)


HELDOUT_MODEL_SELECTION_VERIFIER_REF = (
    "heldout-model-selection-independent-verifier-v3"
)


@dataclass(frozen=True)
class HeldoutModelSelectionVerification:
    passed: bool
    checks: Mapping[str, bool]
    seed_count: int
    arm_count: int
    cell_count: int
    reconstructed_selection: Mapping[str, Any]
    limitations: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "seed_count": self.seed_count,
            "arm_count": self.arm_count,
            "cell_count": self.cell_count,
            "reconstructed_selection": dict(self.reconstructed_selection),
            "limitations": list(self.limitations),
            "verifier_ref": HELDOUT_MODEL_SELECTION_VERIFIER_REF,
        }


def _metrics_identical(
    left: GradedRunResult,
    right: GradedRunResult,
) -> bool:
    return dict(left.metrics) == dict(right.metrics) and tuple(
        item.as_dict() for item in left.checkpoints
    ) == tuple(item.as_dict() for item in right.checkpoints)


def _mask_is_exact(run: GradedRunResult) -> bool:
    signature = run.mask_signature
    width = active_width(run.config, run.arm)
    start = memory_window_start(run.config, run.arm)
    procedure = tuple(range(width))
    memory = tuple(range(start, start + width))
    return (
        int(signature["full_width"]) == run.config.width
        and int(signature["active_width_per_task"]) == width
        and tuple(signature["procedure_dimensions"]) == procedure
        and tuple(signature["memory_dimensions"]) == memory
        and int(signature["overlap_dimensions"])
        == len(set(procedure).intersection(memory))
        and not bool(signature["model_shape_changes"])
    )


def verify_heldout_model_selection(
    runs: Sequence[GradedRunResult],
    registry: FrozenModelPredictionRegistry,
    reported: HeldoutModelSelection,
) -> HeldoutModelSelectionVerification:
    if not runs:
        raise ValueError("heldout verifier requires run evidence")
    seeds = {run.config.model_seed for run in runs}
    arms = {run.arm.arm_id: run.arm for run in runs}
    cells = {(run.config.model_seed, run.arm.arm_id): run for run in runs}
    complete = len(cells) == len(runs) == len(seeds) * len(arms)
    baseline = {seed: cells.get((seed, "baseline")) for seed in seeds}
    sham = {seed: cells.get((seed, "sham")) for seed in seeds}
    paired_initialization = complete and all(
        len(
            {
                cells[(seed, arm_id)].initial_parameter_digest
                for arm_id in arms
            }
        )
        == 1
        for seed in seeds
    )
    baseline_input = {
        seed: baseline[seed].model_input_digest
        for seed in seeds
        if baseline[seed] is not None
    }
    baseline_order = {
        seed: baseline[seed].ordered_examples_digest
        for seed in seeds
        if baseline[seed] is not None
    }
    routing_counts_are_exact = all(
        (
            (run.routing_counts["correctly_routed"] > 0)
            == (run.arm.routing_correct_fraction > 0.0)
        )
        and (
            (run.routing_counts["noisily_routed"] > 0)
            == (run.arm.routing_noise_fraction > 0.0)
        )
        and sum(run.routing_counts.values())
        == run.config.steps * run.config.batch_size
        for run in runs
    )
    input_changes_are_declared = complete and all(
        (
            run.model_input_digest
            != baseline_input[run.config.model_seed]
        )
        == (
            run.arm.routing_correct_fraction > 0.0
            or run.arm.routing_noise_fraction > 0.0
            or run.arm.curriculum_window_steps > 1
        )
        for run in runs
    )
    order_changes_are_declared = complete and all(
        (
            run.ordered_examples_digest
            != baseline_order[run.config.model_seed]
        )
        == (run.arm.curriculum_window_steps > 1)
        for run in runs
    )
    sham_exact = complete and all(
        baseline[seed] is not None
        and sham[seed] is not None
        and baseline[seed].ordered_examples_digest
        == sham[seed].ordered_examples_digest
        and baseline[seed].model_input_digest == sham[seed].model_input_digest
        and baseline[seed].mask_signature == sham[seed].mask_signature
        and _metrics_identical(baseline[seed], sham[seed])
        for seed in seeds
    )
    reconstructed = score_competing_models(
        registry,
        build_heldout_outcomes(runs),
    )
    checks = {
        "complete_seed_by_arm_matrix": complete,
        "registry_seeds_match_runs": seeds == set(registry.model_seeds),
        "registry_arms_match_runs": (
            arms == {arm.arm_id: arm for arm in registry.arms}
        ),
        "heldout_data_seed_matches_registry": all(
            run.config.data_seed == registry.data_seed for run in runs
        ),
        "at_least_six_new_seeds": len(seeds) >= 6,
        "evaluator_and_verifier_are_independent": all(
            run.evaluator_ref == GRADED_CAUSAL_EVALUATOR_REF
            and run.evaluator_ref != HELDOUT_MODEL_SELECTION_VERIFIER_REF
            for run in runs
        ),
        "raw_training_multiset_is_shared": (
            len({run.raw_multiset_digest for run in runs}) == 1
        ),
        "evaluation_cases_are_shared": (
            len({run.evaluation_digest for run in runs}) == 1
        ),
        "parameter_count_is_shared": (
            len({run.parameter_count for run in runs}) == 1
        ),
        "resource_ledger_is_shared": (
            len({run.resource_ledger.match_signature for run in runs}) == 1
        ),
        "initial_parameters_are_paired_within_seed": paired_initialization,
        "randomized_seeds_have_distinct_initializations": (
            len(
                {
                    run.initial_parameter_digest
                    for run in runs
                    if run.arm.arm_id == "baseline"
                }
            )
            == len(seeds)
        ),
        "sham_is_exact_negative_control": sham_exact,
        "routing_exposure_counts_match_declared_levels": (
            routing_counts_are_exact
        ),
        "model_input_changes_are_declared": input_changes_are_declared,
        "training_order_changes_only_for_curriculum": (
            order_changes_are_declared
        ),
        "feature_masks_match_capacity_and_representation_levels": all(
            _mask_is_exact(run) for run in runs
        ),
        "reported_selection_is_reconstructed": (
            reconstructed.as_dict() == reported.as_dict()
        ),
        "selection_validity_checks_pass": all(reported.checks.values()),
    }
    limitations = (
        "Predictions are transported from one earlier micro-horizon atlas to new seeds and a new synthetic data seed; this is not cross-scale evidence.",
        "Partial and noisy routing remain externally imposed key-based interventions, not learned relevance inference.",
        "Representation separation is operationalized as subspace overlap, so conclusions are limited to this representation family.",
        "An inconclusive likelihood comparison must trigger representation review rather than forced architecture selection.",
    )
    return HeldoutModelSelectionVerification(
        passed=all(checks.values()),
        checks=checks,
        seed_count=len(seeds),
        arm_count=len(arms),
        cell_count=len(runs),
        reconstructed_selection=reconstructed.as_dict(),
        limitations=limitations,
    )
