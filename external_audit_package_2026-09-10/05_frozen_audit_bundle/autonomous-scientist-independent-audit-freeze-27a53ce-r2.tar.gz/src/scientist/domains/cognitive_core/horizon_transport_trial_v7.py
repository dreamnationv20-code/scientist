from __future__ import annotations

from dataclasses import dataclass
import math
import platform
from typing import Any, Dict, List, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.learned_locality_trial_v6 import (
    _predict,
    _train_model,
    build_learned_training_plan,
)
from scientist.domains.cognitive_core.learning import (
    LearningConfig,
    TrainingCondition,
    encode_memory,
    fact_keys,
    fact_label,
    update_label,
)
from scientist.kernel.contracts import EvidencePartition
from scientist.program.horizon_diagnostics import (
    EvaluationHorizon,
    HorizonKind,
    HorizonPrediction,
)


HORIZON_TRANSPORT_TRIAL_VERSION = "cognitive-core-horizon-transport-trial-v7"
HORIZON_TRANSPORT_EVALUATOR_REF = "learned-horizon-transport-evaluator-v7"
HORIZON_REGISTRAR_REF = "cognitive-core-sealed-horizon-registrar-v7"

TRANSPORT_METRICS = (
    "target_accuracy",
    "retention_accuracy",
    "target_delta",
    "retention_delta",
    "net_update_retention_delta",
    "normalized_external_memory_cost",
)


@dataclass(frozen=True)
class TransportPartition:
    partition: EvidencePartition
    data_seed: int

    def __post_init__(self) -> None:
        if self.partition not in (
            EvidencePartition.AUDIT,
            EvidencePartition.REPLICATION,
        ):
            raise ValueError("transport requires audit or replication")
        if self.data_seed <= 0:
            raise ValueError("transport data seed must be positive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "partition": self.partition.value,
            "data_seed": self.data_seed,
        }


@dataclass(frozen=True)
class TransportHorizonSpec:
    name: str
    rank: int
    update_count: int
    kind: HorizonKind
    partitions: Tuple[TransportPartition, ...]
    compute_budget: float = 2.0

    def __post_init__(self) -> None:
        if not self.name or self.rank < 0 or self.update_count <= 0:
            raise ValueError("transport horizon identity is invalid")
        if len(self.partitions) != 2 or {
            item.partition for item in self.partitions
        } != {EvidencePartition.AUDIT, EvidencePartition.REPLICATION}:
            raise ValueError("every transport horizon needs audit and replication")
        if len({item.data_seed for item in self.partitions}) != 2:
            raise ValueError("transport horizon partitions must be disjoint")
        if self.compute_budget <= 0.0:
            raise ValueError("transport compute budget must be positive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "rank": self.rank,
            "update_count": self.update_count,
            "kind": self.kind.value,
            "partitions": [item.as_dict() for item in self.partitions],
            "compute_budget": self.compute_budget,
        }


@dataclass(frozen=True)
class TransportCandidate:
    name: str
    family: str
    split: str
    controller: str
    capacity: int
    ttl: int = 0
    noise_period: int = 0

    def __post_init__(self) -> None:
        if not all((self.name, self.family, self.split, self.controller)):
            raise ValueError("transport candidate identity is incomplete")
        if self.split not in ("development", "validation"):
            raise ValueError("transport candidate split is invalid")
        if self.controller not in (
            "scoped_fifo",
            "scoped_ttl",
            "scoped_noisy",
            "unscoped_global",
            "overflow_spill",
            "scoped_reservoir",
        ):
            raise ValueError("unsupported transport controller")
        if self.capacity <= 0 or self.ttl < 0 or self.noise_period < 0:
            raise ValueError("transport controller dimensions are invalid")
        if self.controller == "scoped_ttl" and self.ttl <= 0:
            raise ValueError("TTL controller requires a positive lifetime")
        if self.controller == "scoped_noisy" and self.noise_period <= 1:
            raise ValueError("noisy controller requires a nontrivial period")

    @property
    def candidate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "name": self.name,
            "family": self.family,
            "split": self.split,
            "controller": self.controller,
            "capacity": self.capacity,
            "ttl": self.ttl,
            "noise_period": self.noise_period,
        }
        if include_id:
            value["candidate_id"] = self.candidate_id
        return value


@dataclass(frozen=True)
class FrozenHorizonTransportRegistry:
    node_id: str
    source_trial_verification_id: str
    hypothesis_id: str
    horizons: Tuple[TransportHorizonSpec, ...]
    candidates: Tuple[TransportCandidate, ...]
    model_seeds: Tuple[int, ...]
    fact_count: int
    width: int
    layers: int
    heads: int
    steps: int
    batch_size: int
    learning_rate: float
    checkpoint_interval: int
    prediction_tolerance: float
    minimum_validation_class_accuracy: float
    minimum_validation_metric_accuracy: float
    required_registry_checks: Tuple[str, ...]
    required_transport_checks: Tuple[str, ...]
    registrar_ref: str = HORIZON_REGISTRAR_REF

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.source_trial_verification_id,
                self.hypothesis_id,
                self.horizons,
                self.candidates,
                self.model_seeds,
                self.required_registry_checks,
                self.required_transport_checks,
                self.registrar_ref,
            )
        ):
            raise ValueError("horizon registry is incomplete")
        ranks = tuple(item.rank for item in self.horizons)
        if ranks != tuple(range(len(self.horizons))):
            raise ValueError("horizon ranks must be consecutive and ordered")
        update_counts = tuple(item.update_count for item in self.horizons)
        if tuple(sorted(update_counts)) != update_counts or len(
            set(update_counts)
        ) != len(update_counts):
            raise ValueError("horizon update counts must strictly increase")
        data_seeds = tuple(
            partition.data_seed
            for horizon in self.horizons
            for partition in horizon.partitions
        )
        if len(set(data_seeds)) != len(data_seeds):
            raise ValueError("all horizon partitions must be disjoint")
        if len(self.model_seeds) < 8 or len(set(self.model_seeds)) != len(
            self.model_seeds
        ):
            raise ValueError("transport requires eight unique model seeds")
        if len(self.candidates) < 6 or len(
            {item.candidate_id for item in self.candidates}
        ) != len(self.candidates):
            raise ValueError("transport needs distinct controller families")
        if not any(item.split == "validation" for item in self.candidates):
            raise ValueError("transport needs held-out controller families")
        if min(
            self.fact_count,
            self.width,
            self.layers,
            self.heads,
            self.steps,
            self.batch_size,
            self.checkpoint_interval,
        ) <= 0:
            raise ValueError("transport training dimensions are invalid")
        if self.fact_count % 2 or max(update_counts) > self.fact_count // 2:
            raise ValueError("transport requires enough target/protected key pairs")
        for value in (
            self.prediction_tolerance,
            self.minimum_validation_class_accuracy,
            self.minimum_validation_metric_accuracy,
        ):
            if not 0.0 < value <= 1.0:
                raise ValueError("transport decision threshold is invalid")

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def config(
        self,
        partition: TransportPartition,
        model_seed: int,
    ) -> LearningConfig:
        if model_seed not in self.model_seeds or partition not in tuple(
            item for horizon in self.horizons for item in horizon.partitions
        ):
            raise ValueError("training configuration is outside the registry")
        return LearningConfig(
            condition=TrainingCondition.RANDOM_FACTS,
            fact_count=self.fact_count,
            width=self.width,
            layers=self.layers,
            heads=self.heads,
            steps=self.steps,
            batch_size=self.batch_size,
            learning_rate=self.learning_rate,
            model_seed=model_seed,
            data_seed=partition.data_seed,
            checkpoint_interval=self.checkpoint_interval,
            compute_device="cpu",
            evidence_schedule="balanced",
            relevance_annotation=False,
        )

    def evaluation_horizon(self, spec: TransportHorizonSpec) -> EvaluationHorizon:
        if spec not in self.horizons:
            raise ValueError("unknown horizon specification")
        return EvaluationHorizon(
            node_id=self.node_id,
            name=spec.name,
            rank=spec.rank,
            kind=spec.kind,
            partition_ref="sealed:%s" % content_digest(
                [item.as_dict() for item in spec.partitions]
            ),
            task_family_ref="synthetic-keyed-persistent-update-v7",
            model_family_ref="mlx-tiny-transformer-w48-l2-h4-v7",
            metric_names=TRANSPORT_METRICS,
            compute_budget=spec.compute_budget,
            sealed=True,
            registrar_ref=self.registrar_ref,
        )

    def expected_metrics(
        self,
        candidate: TransportCandidate,
        horizon: TransportHorizonSpec,
    ) -> Mapping[str, float]:
        count = horizon.update_count
        retention = 0.99
        baseline_target = 0.0
        if candidate.controller == "scoped_fifo":
            target = min(1.0, candidate.capacity / float(count))
        elif candidate.controller == "scoped_reservoir":
            target = min(1.0, candidate.capacity / float(count))
        elif candidate.controller == "scoped_ttl":
            target = min(1.0, candidate.ttl / float(count))
        elif candidate.controller == "scoped_noisy":
            missed = count // candidate.noise_period
            target = 1.0 - missed / float(count)
        elif candidate.controller == "unscoped_global":
            target = (1.0 + (count - 1.0) / 16.0) / float(count)
            retention = 1.0 / 16.0
        elif candidate.controller == "overflow_spill":
            target = min(1.0, candidate.capacity / float(count))
            if count > candidate.capacity:
                retention = 1.0 / 16.0
        else:
            raise AssertionError("unreachable controller")
        target_delta = target - baseline_target
        retention_delta = retention - 0.99
        return {
            "target_accuracy": target,
            "retention_accuracy": retention,
            "target_delta": target_delta,
            "retention_delta": retention_delta,
            "net_update_retention_delta": target_delta + retention_delta,
            "normalized_external_memory_cost": candidate.capacity / 64.0,
        }

    def prediction(
        self,
        candidate: TransportCandidate,
        horizon: TransportHorizonSpec,
    ) -> HorizonPrediction:
        registered_horizon = self.evaluation_horizon(horizon)
        return HorizonPrediction(
            node_id=self.node_id,
            hypothesis_id=self.hypothesis_id,
            candidate_id=candidate.candidate_id,
            horizon_id=registered_horizon.horizon_id,
            expected_metrics=self.expected_metrics(candidate, horizon),
            qualitative_predictions=(
                "scoped state preserves never-updated keys unless its declared overflow semantics spill",
                "bounded state attenuates delayed update recall when update count exceeds effective capacity",
                "controller identity and metric semantics remain fixed at every horizon",
            ),
            boundary_conditions=(
                "synthetic keyed facts with an exact externally supplied selector",
                "at most thirty-two distinct targets and thirty-two protected keys",
                "fixed width, training budget, and controller resource declaration",
            ),
            predictor_ref="mechanism-conditional-horizon-predictor-v7",
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": HORIZON_TRANSPORT_TRIAL_VERSION,
            "node_id": self.node_id,
            "source_trial_verification_id": self.source_trial_verification_id,
            "hypothesis_id": self.hypothesis_id,
            "horizons": [item.as_dict() for item in self.horizons],
            "candidates": [item.as_dict() for item in self.candidates],
            "model_seeds": list(self.model_seeds),
            "fact_count": self.fact_count,
            "width": self.width,
            "layers": self.layers,
            "heads": self.heads,
            "steps": self.steps,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "checkpoint_interval": self.checkpoint_interval,
            "prediction_tolerance": self.prediction_tolerance,
            "minimum_validation_class_accuracy": self.minimum_validation_class_accuracy,
            "minimum_validation_metric_accuracy": self.minimum_validation_metric_accuracy,
            "required_registry_checks": list(self.required_registry_checks),
            "required_transport_checks": list(self.required_transport_checks),
            "registrar_ref": self.registrar_ref,
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


def frozen_horizon_transport_registry(
    *,
    node_id: str,
    source_trial_verification_id: str,
    hypothesis_id: str,
) -> FrozenHorizonTransportRegistry:
    return FrozenHorizonTransportRegistry(
        node_id=node_id,
        source_trial_verification_id=source_trial_verification_id,
        hypothesis_id=hypothesis_id,
        horizons=(
            TransportHorizonSpec(
                "one_update", 0, 1, HorizonKind.LOCAL_VALIDATION,
                (
                    TransportPartition(EvidencePartition.AUDIT, 20260820),
                    TransportPartition(EvidencePartition.REPLICATION, 20260821),
                ),
            ),
            TransportHorizonSpec(
                "four_updates", 1, 4, HorizonKind.TRANSFER,
                (
                    TransportPartition(EvidencePartition.AUDIT, 20260822),
                    TransportPartition(EvidencePartition.REPLICATION, 20260823),
                ),
            ),
            TransportHorizonSpec(
                "sixteen_updates", 2, 16, HorizonKind.TRANSFER,
                (
                    TransportPartition(EvidencePartition.AUDIT, 20260824),
                    TransportPartition(EvidencePartition.REPLICATION, 20260825),
                ),
            ),
            TransportHorizonSpec(
                "thirty_two_updates", 3, 32, HorizonKind.TRANSFER,
                (
                    TransportPartition(EvidencePartition.AUDIT, 20260826),
                    TransportPartition(EvidencePartition.REPLICATION, 20260827),
                ),
            ),
        ),
        candidates=(
            TransportCandidate(
                "full_capacity_locality", "exact_scope", "development",
                "scoped_fifo", 64,
            ),
            TransportCandidate(
                "bounded_fifo_locality", "bounded_fifo", "development",
                "scoped_fifo", 4,
            ),
            TransportCandidate(
                "temporal_locality", "temporal_ttl", "development",
                "scoped_ttl", 64, ttl=4,
            ),
            TransportCandidate(
                "noisy_locality", "selector_noise", "development",
                "scoped_noisy", 64, noise_period=4,
            ),
            TransportCandidate(
                "global_update", "unscoped_global", "development",
                "unscoped_global", 64,
            ),
            TransportCandidate(
                "overflow_spill_locality", "overflow_spill", "validation",
                "overflow_spill", 8,
            ),
            TransportCandidate(
                "reservoir_locality", "reservoir_bounded", "validation",
                "scoped_reservoir", 8,
            ),
        ),
        model_seeds=tuple(range(30, 38)),
        fact_count=64,
        width=48,
        layers=2,
        heads=4,
        steps=800,
        batch_size=80,
        learning_rate=0.001,
        checkpoint_interval=200,
        prediction_tolerance=0.10,
        minimum_validation_class_accuracy=1.0,
        minimum_validation_metric_accuracy=0.90,
        required_registry_checks=(
            "source_learned_trial_is_bound",
            "ordered_horizons_are_complete",
            "horizon_partitions_are_disjoint",
            "task_model_and_metric_identities_persist",
            "audit_and_replication_are_predeclared",
            "candidate_identities_persist_across_horizons",
            "development_and_validation_families_are_frozen",
            "predictions_cover_every_candidate_horizon_cell",
            "predictions_cover_every_metric",
            "predictions_are_finite",
            "higher_horizon_outcomes_are_absent_at_freeze",
            "tampered_intervention_identity_is_detected",
            "tampered_metric_identity_is_detected",
            "duplicate_partition_is_detected",
        ),
        required_transport_checks=(
            "registry_identity_is_reconstructed",
            "all_outcomes_follow_frozen_predictions",
            "complete_horizon_partition_seed_candidate_matrix",
            "fresh_training_seeds_are_used",
            "training_is_shared_within_partition_seed",
            "initializations_are_distinct",
            "all_trajectory_metrics_are_reconstructed",
            "audit_and_replication_curves_agree",
            "persistent_attenuating_and_reversing_cases_exist",
            "validation_family_metric_predictions_are_calibrated",
            "validation_family_transport_classes_are_correct",
            "unreliable_local_only_inference_is_rejected",
            "resource_and_cost_descriptors_are_retained",
            "independent_retraining_spot_checks_pass",
        ),
    )


@dataclass(frozen=True)
class CandidateTrajectoryTrace:
    registry_id: str
    horizon_id: str
    horizon_rank: int
    update_count: int
    partition: EvidencePartition
    data_seed: int
    model_seed: int
    candidate_id: str
    target_keys: Tuple[int, ...]
    retention_keys: Tuple[int, ...]
    update_values: Tuple[int, ...]
    base_target_predictions: Tuple[int, ...]
    base_retention_predictions: Tuple[int, ...]
    target_predictions: Tuple[int, ...]
    retention_predictions: Tuple[int, ...]
    metrics: Mapping[str, float]
    evaluator_ref: str = HORIZON_TRANSPORT_EVALUATOR_REF

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": HORIZON_TRANSPORT_TRIAL_VERSION,
            "registry_id": self.registry_id,
            "horizon_id": self.horizon_id,
            "horizon_rank": self.horizon_rank,
            "update_count": self.update_count,
            "partition": self.partition.value,
            "data_seed": self.data_seed,
            "model_seed": self.model_seed,
            "candidate_id": self.candidate_id,
            "target_keys": list(self.target_keys),
            "retention_keys": list(self.retention_keys),
            "update_values": list(self.update_values),
            "base_target_predictions": list(self.base_target_predictions),
            "base_retention_predictions": list(self.base_retention_predictions),
            "target_predictions": list(self.target_predictions),
            "retention_predictions": list(self.retention_predictions),
            "metrics": dict(sorted(self.metrics.items())),
            "evaluator_ref": self.evaluator_ref,
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


@dataclass(frozen=True)
class HorizonTrainingRun:
    registry_id: str
    horizon_id: str
    horizon_rank: int
    update_count: int
    partition: EvidencePartition
    config: LearningConfig
    initial_parameter_digest: str
    final_parameter_digest: str
    parameter_count: int
    training_order_digest: str
    training_multiset_digest: str
    training_example_count: int
    final_training_loss: float
    traces: Tuple[CandidateTrajectoryTrace, ...]
    elapsed_seconds: float
    hardware: str = platform.machine() + ":cpu"

    @property
    def run_id(self) -> str:
        return content_digest(
            {
                "version": HORIZON_TRANSPORT_TRIAL_VERSION,
                "registry_id": self.registry_id,
                "horizon_id": self.horizon_id,
                "partition": self.partition.value,
                "config": self.config.as_dict(),
                "initial_parameter_digest": self.initial_parameter_digest,
                "final_parameter_digest": self.final_parameter_digest,
                "training_order_digest": self.training_order_digest,
                "training_multiset_digest": self.training_multiset_digest,
                "traces": [item.trace_id for item in self.traces],
            }
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": HORIZON_TRANSPORT_TRIAL_VERSION,
            "registry_id": self.registry_id,
            "horizon_id": self.horizon_id,
            "horizon_rank": self.horizon_rank,
            "update_count": self.update_count,
            "partition": self.partition.value,
            "config": self.config.as_dict(),
            "initial_parameter_digest": self.initial_parameter_digest,
            "final_parameter_digest": self.final_parameter_digest,
            "parameter_count": self.parameter_count,
            "training_order_digest": self.training_order_digest,
            "training_multiset_digest": self.training_multiset_digest,
            "training_example_count": self.training_example_count,
            "final_training_loss": self.final_training_loss,
            "traces": [item.as_dict() for item in self.traces],
            "elapsed_seconds": self.elapsed_seconds,
            "hardware": self.hardware,
        }
        if include_id:
            value["run_id"] = self.run_id
        return value


def _controller_predictions(
    candidate: TransportCandidate,
    *,
    target_keys: Tuple[int, ...],
    retention_keys: Tuple[int, ...],
    update_values: Tuple[int, ...],
    base_target: Tuple[int, ...],
    base_retention: Tuple[int, ...],
) -> Tuple[Tuple[int, ...], Tuple[int, ...]]:
    memory: Dict[int, Tuple[int, int]] = {}
    overflowed = False
    latest = update_values[-1]
    for step, (key, value) in enumerate(zip(target_keys, update_values)):
        if candidate.controller == "unscoped_global":
            continue
        if candidate.controller == "scoped_noisy" and (
            (step + 1) % candidate.noise_period == 0
        ):
            continue
        if candidate.controller == "scoped_reservoir":
            if len(memory) < candidate.capacity:
                memory[key] = (value, step)
            continue
        memory[key] = (value, step)
        if candidate.controller == "scoped_ttl":
            expired = tuple(
                stored_key
                for stored_key, (_, inserted) in memory.items()
                if step - inserted >= candidate.ttl
            )
            for stored_key in expired:
                memory.pop(stored_key)
        elif len(memory) > candidate.capacity:
            oldest = min(memory, key=lambda item: memory[item][1])
            memory.pop(oldest)
            overflowed = True

    if candidate.controller == "unscoped_global":
        return (
            tuple(latest for _ in target_keys),
            tuple(latest for _ in retention_keys),
        )
    target_predictions = tuple(
        memory.get(key, (fallback, -1))[0]
        for key, fallback in zip(target_keys, base_target)
    )
    if candidate.controller == "overflow_spill" and overflowed:
        retention_predictions = tuple(latest for _ in retention_keys)
    else:
        retention_predictions = tuple(
            memory.get(key, (fallback, -1))[0]
            for key, fallback in zip(retention_keys, base_retention)
        )
    return target_predictions, retention_predictions


def _trajectory_metrics(
    candidate: TransportCandidate,
    *,
    update_values: Tuple[int, ...],
    retention_labels: Tuple[int, ...],
    base_target: Tuple[int, ...],
    base_retention: Tuple[int, ...],
    target_predictions: Tuple[int, ...],
    retention_predictions: Tuple[int, ...],
) -> Mapping[str, float]:
    count = float(len(update_values))
    protected_count = float(len(retention_labels))
    target_accuracy = sum(
        left == right for left, right in zip(target_predictions, update_values)
    ) / count
    retention_accuracy = sum(
        left == right
        for left, right in zip(retention_predictions, retention_labels)
    ) / protected_count
    baseline_target = sum(
        left == right for left, right in zip(base_target, update_values)
    ) / count
    baseline_retention = sum(
        left == right for left, right in zip(base_retention, retention_labels)
    ) / protected_count
    target_delta = target_accuracy - baseline_target
    retention_delta = retention_accuracy - baseline_retention
    return {
        "target_accuracy": target_accuracy,
        "retention_accuracy": retention_accuracy,
        "target_delta": target_delta,
        "retention_delta": retention_delta,
        "net_update_retention_delta": target_delta + retention_delta,
        "normalized_external_memory_cost": candidate.capacity / 64.0,
    }


def run_horizon_partition(
    registry: FrozenHorizonTransportRegistry,
    horizon: TransportHorizonSpec,
    partition: TransportPartition,
) -> Tuple[HorizonTrainingRun, ...]:
    if horizon not in registry.horizons or partition not in horizon.partitions:
        raise ValueError("horizon partition is outside the registry")
    registered_horizon = registry.evaluation_horizon(horizon)
    template = registry.config(partition, registry.model_seeds[0])
    plan = build_learned_training_plan(template)
    keys = fact_keys(template)
    target_bank = keys[::2]
    retention_keys = keys[1::2]
    target_keys = target_bank[: horizon.update_count]
    evaluation_keys = target_keys + retention_keys
    examples = tuple(
        encode_memory(key, fact_label(template, key)) for key in evaluation_keys
    )
    update_values = tuple(update_label(template, key) for key in target_keys)
    retention_labels = tuple(fact_label(template, key) for key in retention_keys)
    runs: List[HorizonTrainingRun] = []
    for model_seed in registry.model_seeds:
        config = registry.config(partition, model_seed)
        (
            model,
            initial_digest,
            final_digest,
            parameter_count,
            final_loss,
            elapsed,
        ) = _train_model(config, plan)
        predictions = _predict(model, examples)
        base_target = predictions[: len(target_keys)]
        base_retention = predictions[len(target_keys) :]
        traces = []
        for candidate in registry.candidates:
            target_predictions, retention_predictions = _controller_predictions(
                candidate,
                target_keys=target_keys,
                retention_keys=retention_keys,
                update_values=update_values,
                base_target=base_target,
                base_retention=base_retention,
            )
            metrics = _trajectory_metrics(
                candidate,
                update_values=update_values,
                retention_labels=retention_labels,
                base_target=base_target,
                base_retention=base_retention,
                target_predictions=target_predictions,
                retention_predictions=retention_predictions,
            )
            traces.append(
                CandidateTrajectoryTrace(
                    registry_id=registry.registry_id,
                    horizon_id=registered_horizon.horizon_id,
                    horizon_rank=horizon.rank,
                    update_count=horizon.update_count,
                    partition=partition.partition,
                    data_seed=partition.data_seed,
                    model_seed=model_seed,
                    candidate_id=candidate.candidate_id,
                    target_keys=target_keys,
                    retention_keys=retention_keys,
                    update_values=update_values,
                    base_target_predictions=base_target,
                    base_retention_predictions=base_retention,
                    target_predictions=target_predictions,
                    retention_predictions=retention_predictions,
                    metrics=metrics,
                )
            )
        runs.append(
            HorizonTrainingRun(
                registry_id=registry.registry_id,
                horizon_id=registered_horizon.horizon_id,
                horizon_rank=horizon.rank,
                update_count=horizon.update_count,
                partition=partition.partition,
                config=config,
                initial_parameter_digest=initial_digest,
                final_parameter_digest=final_digest,
                parameter_count=parameter_count,
                training_order_digest=plan.ordered_digest,
                training_multiset_digest=plan.multiset_digest,
                training_example_count=plan.example_count,
                final_training_loss=final_loss,
                traces=tuple(traces),
                elapsed_seconds=elapsed,
            )
        )
    return tuple(runs)


def aggregate_transport_metrics(
    runs: Tuple[HorizonTrainingRun, ...],
) -> Mapping[Tuple[str, str], Mapping[str, float]]:
    grouped: Dict[Tuple[str, str], List[Mapping[str, float]]] = {}
    for run in runs:
        for trace in run.traces:
            grouped.setdefault(
                (trace.candidate_id, trace.horizon_id), []
            ).append(trace.metrics)
    result: Dict[Tuple[str, str], Mapping[str, float]] = {}
    for identity, rows in grouped.items():
        result[identity] = {
            metric: sum(row[metric] for row in rows) / float(len(rows))
            for metric in TRANSPORT_METRICS
        }
    return result


def standard_errors(
    rows: Tuple[Mapping[str, float], ...],
) -> Mapping[str, float]:
    result = {}
    for metric in TRANSPORT_METRICS:
        values = tuple(row[metric] for row in rows)
        mean = sum(values) / float(len(values))
        variance = sum((item - mean) ** 2 for item in values) / max(
            1.0, float(len(values) - 1)
        )
        result[metric] = math.sqrt(variance / float(len(values)))
    return result
