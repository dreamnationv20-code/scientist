from __future__ import annotations

from dataclasses import dataclass, replace
import math
from typing import Any, Dict, List, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.horizon_transport_trial_v7 import (
    TRANSPORT_METRICS,
    CandidateTrajectoryTrace,
    FrozenHorizonTransportRegistry,
    HorizonTrainingRun,
    TransportCandidate,
    TransportHorizonSpec,
    _predict,
    _train_model,
    build_learned_training_plan,
)
from scientist.domains.cognitive_core.learning import (
    encode_memory,
    fact_keys,
    fact_label,
)
from scientist.kernel.contracts import EvidencePartition


HORIZON_REGISTRY_VERIFIER_REF = "sealed-horizon-registry-independent-verifier-v7"
HORIZON_TRANSPORT_VERIFIER_REF = "learned-horizon-transport-independent-verifier-v7"


@dataclass(frozen=True)
class HorizonRegistryVerification:
    registry_id: str
    check_results: Mapping[str, bool]
    horizon_ids: Tuple[str, ...]
    prediction_ids: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str = HORIZON_REGISTRY_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "registry_id": self.registry_id,
            "check_results": dict(sorted(self.check_results.items())),
            "horizon_ids": list(self.horizon_ids),
            "prediction_ids": list(self.prediction_ids),
            "passed": self.passed,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _independent_expected_metrics(
    candidate: TransportCandidate,
    update_count: int,
) -> Mapping[str, float]:
    retention = 0.99
    if candidate.controller in ("scoped_fifo", "scoped_reservoir"):
        target = min(1.0, candidate.capacity / float(update_count))
    elif candidate.controller == "scoped_ttl":
        target = min(1.0, candidate.ttl / float(update_count))
    elif candidate.controller == "scoped_noisy":
        target = 1.0 - (update_count // candidate.noise_period) / float(
            update_count
        )
    elif candidate.controller == "unscoped_global":
        target = (
            1.0 + (update_count - 1.0) / 16.0
        ) / float(update_count)
        retention = 1.0 / 16.0
    elif candidate.controller == "overflow_spill":
        target = min(1.0, candidate.capacity / float(update_count))
        if update_count > candidate.capacity:
            retention = 1.0 / 16.0
    else:
        raise AssertionError("unreachable controller")
    return {
        "target_accuracy": target,
        "retention_accuracy": retention,
        "target_delta": target,
        "retention_delta": retention - 0.99,
        "net_update_retention_delta": target + retention - 0.99,
        "normalized_external_memory_cost": candidate.capacity / 64.0,
    }


def verify_frozen_horizon_registry(
    registry: FrozenHorizonTransportRegistry,
    *,
    source_trial_verification_id: str,
    outcomes_present_at_freeze: int,
) -> HorizonRegistryVerification:
    horizons = tuple(registry.evaluation_horizon(item) for item in registry.horizons)
    predictions = tuple(
        registry.prediction(candidate, horizon)
        for candidate in registry.candidates
        for horizon in registry.horizons
    )
    all_partitions = tuple(
        item
        for horizon in registry.horizons
        for item in horizon.partitions
    )
    prediction_identities = {
        (item.candidate_id, item.horizon_id) for item in predictions
    }
    expected_identities = {
        (candidate.candidate_id, horizon.horizon_id)
        for candidate in registry.candidates
        for horizon in horizons
    }
    prediction_values_match = all(
        dict(prediction.expected_metrics)
        == dict(
            _independent_expected_metrics(
                next(
                    item
                    for item in registry.candidates
                    if item.candidate_id == prediction.candidate_id
                ),
                next(
                    item.update_count
                    for item in registry.horizons
                    if registry.evaluation_horizon(item).horizon_id
                    == prediction.horizon_id
                ),
            )
        )
        for prediction in predictions
    )

    altered_candidate = replace(
        registry.candidates[0], capacity=registry.candidates[0].capacity - 1
    )
    intervention_tamper_detected = (
        altered_candidate.candidate_id != registry.candidates[0].candidate_id
    )
    first_horizon = horizons[0]
    altered_horizon = replace(
        first_horizon,
        metric_names=first_horizon.metric_names[:-1],
    )
    metric_tamper_detected = altered_horizon.horizon_id != first_horizon.horizon_id
    duplicate_partition_detected = False
    try:
        duplicate_spec = replace(
            registry.horizons[1],
            partitions=(
                registry.horizons[0].partitions[0],
                registry.horizons[1].partitions[1],
            ),
        )
        replace(
            registry,
            horizons=(
                registry.horizons[0],
                duplicate_spec,
                *registry.horizons[2:],
            ),
        )
    except ValueError:
        duplicate_partition_detected = True

    tasks = {item.task_family_ref for item in horizons}
    models = {item.model_family_ref for item in horizons}
    metrics = {item.metric_names for item in horizons}
    checks = {
        "source_learned_trial_is_bound": (
            registry.source_trial_verification_id
            == source_trial_verification_id
        ),
        "ordered_horizons_are_complete": (
            tuple(item.rank for item in horizons)
            == tuple(range(len(horizons)))
            and tuple(item.kind.value for item in horizons)
            == ("local_validation", "transfer", "transfer", "transfer")
        ),
        "horizon_partitions_are_disjoint": (
            len({item.data_seed for item in all_partitions})
            == len(all_partitions)
            and len({item.partition_ref for item in horizons}) == len(horizons)
        ),
        "task_model_and_metric_identities_persist": (
            len(tasks) == len(models) == len(metrics) == 1
        ),
        "audit_and_replication_are_predeclared": all(
            {item.partition for item in horizon.partitions}
            == {EvidencePartition.AUDIT, EvidencePartition.REPLICATION}
            for horizon in registry.horizons
        ),
        "candidate_identities_persist_across_horizons": all(
            sum(item.candidate_id == candidate.candidate_id for item in predictions)
            == len(horizons)
            for candidate in registry.candidates
        ),
        "development_and_validation_families_are_frozen": (
            len({item.family for item in registry.candidates})
            == len(registry.candidates)
            and {item.split for item in registry.candidates}
            == {"development", "validation"}
        ),
        "predictions_cover_every_candidate_horizon_cell": (
            prediction_identities == expected_identities
        ),
        "predictions_cover_every_metric": all(
            set(item.expected_metrics) == set(TRANSPORT_METRICS)
            for item in predictions
        ),
        "predictions_are_finite": (
            prediction_values_match
            and all(
                math.isfinite(value)
                for item in predictions
                for value in item.expected_metrics.values()
            )
        ),
        "higher_horizon_outcomes_are_absent_at_freeze": (
            outcomes_present_at_freeze == 0
        ),
        "tampered_intervention_identity_is_detected": intervention_tamper_detected,
        "tampered_metric_identity_is_detected": metric_tamper_detected,
        "duplicate_partition_is_detected": duplicate_partition_detected,
    }
    if tuple(checks) != registry.required_registry_checks:
        raise ValueError("registry verification checks differ from frozen contract")
    return HorizonRegistryVerification(
        registry_id=registry.registry_id,
        check_results=checks,
        horizon_ids=tuple(item.horizon_id for item in horizons),
        prediction_ids=tuple(item.prediction_id for item in predictions),
        limitations=(
            "The ladder seals a synthetic keyed-update task, not a natural-language terminal benchmark.",
            "Predictions are mechanism-derived commitments rather than estimates learned from a large historical transport corpus.",
            "The exact selector remains externally supplied; the ladder tests horizon transport, not selector invention.",
        ),
    )


def _independent_controller_predictions(
    candidate: TransportCandidate,
    trace: CandidateTrajectoryTrace,
) -> Tuple[Tuple[int, ...], Tuple[int, ...]]:
    memory: Dict[int, Tuple[int, int]] = {}
    overflowed = False
    for index in range(trace.update_count):
        key = trace.target_keys[index]
        value = trace.update_values[index]
        if candidate.controller == "unscoped_global":
            continue
        if candidate.controller == "scoped_noisy" and (
            (index + 1) % candidate.noise_period == 0
        ):
            continue
        if candidate.controller == "scoped_reservoir":
            if len(memory) < candidate.capacity:
                memory[key] = (value, index)
            continue
        memory[key] = (value, index)
        if candidate.controller == "scoped_ttl":
            for stored_key in tuple(memory):
                if index - memory[stored_key][1] >= candidate.ttl:
                    del memory[stored_key]
        elif len(memory) > candidate.capacity:
            oldest_key = min(memory, key=lambda item: memory[item][1])
            del memory[oldest_key]
            overflowed = True
    latest = trace.update_values[-1]
    if candidate.controller == "unscoped_global":
        return (
            tuple(latest for _ in trace.target_keys),
            tuple(latest for _ in trace.retention_keys),
        )
    target = tuple(
        memory[key][0] if key in memory else fallback
        for key, fallback in zip(
            trace.target_keys, trace.base_target_predictions
        )
    )
    if candidate.controller == "overflow_spill" and overflowed:
        retention = tuple(latest for _ in trace.retention_keys)
    else:
        retention = tuple(
            memory[key][0] if key in memory else fallback
            for key, fallback in zip(
                trace.retention_keys, trace.base_retention_predictions
            )
        )
    return target, retention


def _independent_metrics(
    candidate: TransportCandidate,
    trace: CandidateTrajectoryTrace,
    target_predictions: Tuple[int, ...],
    retention_predictions: Tuple[int, ...],
    retention_labels: Tuple[int, ...],
) -> Mapping[str, float]:
    target_count = float(len(trace.update_values))
    retention_count = float(len(retention_labels))
    target_accuracy = sum(
        left == right
        for left, right in zip(target_predictions, trace.update_values)
    ) / target_count
    retention_accuracy = sum(
        left == right
        for left, right in zip(retention_predictions, retention_labels)
    ) / retention_count
    baseline_target = sum(
        left == right
        for left, right in zip(
            trace.base_target_predictions, trace.update_values
        )
    ) / target_count
    baseline_retention = sum(
        left == right
        for left, right in zip(
            trace.base_retention_predictions, retention_labels
        )
    ) / retention_count
    target_delta = target_accuracy - baseline_target
    retention_delta = retention_accuracy - baseline_retention
    return {
        "target_accuracy": target_accuracy,
        "retention_accuracy": retention_accuracy,
        "target_delta": target_delta,
        "retention_delta": retention_delta,
        "net_update_retention_delta": target_delta + retention_delta,
        "normalized_external_memory_cost": candidate.capacity / 64.0,
    }


def _transport_class(curve: Tuple[float, ...]) -> str:
    if len(curve) != 4 or any(not math.isfinite(item) for item in curve):
        raise ValueError("transport curve must contain four finite values")
    if max(abs(item) for item in curve) < 0.1:
        return "null"
    if curve[0] < 0.2 and curve[-1] > 0.7:
        return "emerging"
    if curve[0] > 0.5 and curve[-1] < -0.2:
        return "reversing"
    if curve[0] > 0.5 and curve[-1] < 0.4:
        return "attenuating"
    return "persistent"


@dataclass(frozen=True)
class HorizonTransportVerification:
    registry_id: str
    run_count: int
    trace_count: int
    check_results: Mapping[str, bool]
    aggregate_metrics: Mapping[str, Mapping[str, Mapping[str, float]]]
    standard_errors: Mapping[str, Mapping[str, Mapping[str, float]]]
    observed_classes: Mapping[str, str]
    predicted_classes: Mapping[str, str]
    validation_metric_accuracy: float
    validation_class_accuracy: float
    limitations: Tuple[str, ...]
    verifier_ref: str = HORIZON_TRANSPORT_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "registry_id": self.registry_id,
            "run_count": self.run_count,
            "trace_count": self.trace_count,
            "check_results": dict(sorted(self.check_results.items())),
            "aggregate_metrics": self.aggregate_metrics,
            "standard_errors": self.standard_errors,
            "observed_classes": dict(sorted(self.observed_classes.items())),
            "predicted_classes": dict(sorted(self.predicted_classes.items())),
            "validation_metric_accuracy": self.validation_metric_accuracy,
            "validation_class_accuracy": self.validation_class_accuracy,
            "passed": self.passed,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _spotcheck_retraining(
    registry: FrozenHorizonTransportRegistry,
    runs: Tuple[HorizonTrainingRun, ...],
) -> bool:
    selected = tuple(
        run
        for run in runs
        if run.config.model_seed == registry.model_seeds[0]
        and run.horizon_rank in (0, len(registry.horizons) - 1)
        and run.partition == EvidencePartition.AUDIT
    )
    if len(selected) != 2:
        return False
    for run in selected:
        horizon = registry.horizons[run.horizon_rank]
        partition = next(
            item
            for item in horizon.partitions
            if item.partition == run.partition
        )
        config = registry.config(partition, run.config.model_seed)
        plan = build_learned_training_plan(config)
        model, initial, final, _, _, _ = _train_model(config, plan)
        keys = fact_keys(config)
        target_keys = keys[::2][: horizon.update_count]
        retention_keys = keys[1::2]
        examples = tuple(
            encode_memory(key, fact_label(config, key))
            for key in target_keys + retention_keys
        )
        base = _predict(model, examples)
        first_trace = run.traces[0]
        if not (
            initial == run.initial_parameter_digest
            and final == run.final_parameter_digest
            and tuple(base[: len(target_keys)])
            == first_trace.base_target_predictions
            and tuple(base[len(target_keys) :])
            == first_trace.base_retention_predictions
        ):
            return False
    return True


def verify_horizon_transport(
    registry: FrozenHorizonTransportRegistry,
    runs: Tuple[HorizonTrainingRun, ...],
) -> HorizonTransportVerification:
    candidates = {item.candidate_id: item for item in registry.candidates}
    horizons = {
        registry.evaluation_horizon(item).horizon_id: item
        for item in registry.horizons
    }
    expected_run_cells = {
        (
            registry.evaluation_horizon(horizon).horizon_id,
            partition.partition,
            partition.data_seed,
            model_seed,
        )
        for horizon in registry.horizons
        for partition in horizon.partitions
        for model_seed in registry.model_seeds
    }
    observed_run_cells = {
        (run.horizon_id, run.partition, run.config.data_seed, run.config.model_seed)
        for run in runs
    }
    traces = tuple(trace for run in runs for trace in run.traces)
    expected_trace_cells = {
        (horizon_id, partition, data_seed, seed, candidate.candidate_id)
        for horizon_id, partition, data_seed, seed in expected_run_cells
        for candidate in registry.candidates
    }
    observed_trace_cells = {
        (
            item.horizon_id,
            item.partition,
            item.data_seed,
            item.model_seed,
            item.candidate_id,
        )
        for item in traces
    }

    reconstructed = True
    grouped: Dict[Tuple[str, str, str], List[Mapping[str, float]]] = {}
    for trace in traces:
        candidate = candidates[trace.candidate_id]
        config = next(
            run.config for run in runs if trace in run.traces
        )
        retention_labels = tuple(
            fact_label(config, key) for key in trace.retention_keys
        )
        target_predictions, retention_predictions = (
            _independent_controller_predictions(candidate, trace)
        )
        metrics = _independent_metrics(
            candidate,
            trace,
            target_predictions,
            retention_predictions,
            retention_labels,
        )
        if (
            target_predictions != trace.target_predictions
            or retention_predictions != trace.retention_predictions
            or any(
                abs(metrics[name] - trace.metrics[name]) > 1e-12
                for name in TRANSPORT_METRICS
            )
        ):
            reconstructed = False
        grouped.setdefault(
            (trace.candidate_id, trace.horizon_id, trace.partition.value), []
        ).append(metrics)

    aggregates: Dict[str, Dict[str, Dict[str, float]]] = {}
    errors: Dict[str, Dict[str, Dict[str, float]]] = {}
    combined_by_candidate_horizon: Dict[Tuple[str, str], List[Mapping[str, float]]] = {}
    for (candidate_id, horizon_id, partition), rows in grouped.items():
        candidate_name = candidates[candidate_id].name
        horizon_name = horizons[horizon_id].name
        aggregates.setdefault(candidate_name, {}).setdefault(
            horizon_name, {}
        )[partition] = {
            metric: sum(row[metric] for row in rows) / float(len(rows))
            for metric in TRANSPORT_METRICS
        }
        error_values = {}
        for metric in TRANSPORT_METRICS:
            values = tuple(row[metric] for row in rows)
            mean = sum(values) / float(len(values))
            variance = sum((item - mean) ** 2 for item in values) / max(
                1.0, float(len(values) - 1)
            )
            error_values[metric] = math.sqrt(
                variance / float(len(values))
            )
        errors.setdefault(candidate_name, {}).setdefault(
            horizon_name, {}
        )[partition] = error_values
        combined_by_candidate_horizon.setdefault(
            (candidate_id, horizon_id), []
        ).extend(rows)

    combined_metrics = {
        identity: {
            metric: sum(row[metric] for row in rows) / float(len(rows))
            for metric in TRANSPORT_METRICS
        }
        for identity, rows in combined_by_candidate_horizon.items()
    }
    observed_classes = {}
    predicted_classes = {}
    validation_metric_cells = []
    validation_class_cells = []
    for candidate in registry.candidates:
        observed_curve = tuple(
            combined_metrics[
                (candidate.candidate_id, registry.evaluation_horizon(horizon).horizon_id)
            ]["net_update_retention_delta"]
            for horizon in registry.horizons
        )
        predicted_curve = tuple(
            _independent_expected_metrics(candidate, horizon.update_count)[
                "net_update_retention_delta"
            ]
            for horizon in registry.horizons
        )
        observed_classes[candidate.name] = _transport_class(observed_curve)
        predicted_classes[candidate.name] = _transport_class(predicted_curve)
        if candidate.split == "validation":
            validation_class_cells.append(
                observed_classes[candidate.name]
                == predicted_classes[candidate.name]
            )
            for horizon in registry.horizons:
                horizon_id = registry.evaluation_horizon(horizon).horizon_id
                expected = _independent_expected_metrics(
                    candidate, horizon.update_count
                )
                observed = combined_metrics[(candidate.candidate_id, horizon_id)]
                for metric in TRANSPORT_METRICS:
                    validation_metric_cells.append(
                        abs(observed[metric] - expected[metric])
                        <= registry.prediction_tolerance
                    )
    validation_metric_accuracy = sum(validation_metric_cells) / float(
        len(validation_metric_cells)
    )
    validation_class_accuracy = sum(validation_class_cells) / float(
        len(validation_class_cells)
    )

    audit_replication_agree = all(
        abs(
            aggregates[candidate.name][horizon.name]["audit"][metric]
            - aggregates[candidate.name][horizon.name]["replication"][metric]
        )
        <= registry.prediction_tolerance
        for candidate in registry.candidates
        for horizon in registry.horizons
        for metric in TRANSPORT_METRICS
    )
    initial_by_seed: Dict[int, set[str]] = {}
    for run in runs:
        initial_by_seed.setdefault(run.config.model_seed, set()).add(
            run.initial_parameter_digest
        )
    distinct_initializations = (
        all(len(values) == 1 for values in initial_by_seed.values())
        and len({next(iter(values)) for values in initial_by_seed.values()})
        == len(registry.model_seeds)
    )
    shared_training = all(
        len(
            {
                (run.training_order_digest, run.training_multiset_digest)
                for run in runs
                if run.horizon_id == registry.evaluation_horizon(horizon).horizon_id
                and run.partition == partition.partition
            }
        )
        == 1
        for horizon in registry.horizons
        for partition in horizon.partitions
    )
    classes = set(observed_classes.values())
    overflow = next(
        item for item in registry.candidates if item.family == "overflow_spill"
    )
    reservoir = next(
        item for item in registry.candidates if item.family == "reservoir_bounded"
    )
    local_id = registry.evaluation_horizon(registry.horizons[0]).horizon_id
    terminal_id = registry.evaluation_horizon(registry.horizons[-1]).horizon_id
    unreliable_local_rejected = (
        combined_metrics[(overflow.candidate_id, local_id)][
            "net_update_retention_delta"
        ]
        > 0.5
        and combined_metrics[(overflow.candidate_id, terminal_id)][
            "net_update_retention_delta"
        ]
        < 0.0
        and combined_metrics[(reservoir.candidate_id, local_id)][
            "net_update_retention_delta"
        ]
        > 0.5
        and combined_metrics[(reservoir.candidate_id, terminal_id)][
            "net_update_retention_delta"
        ]
        < 0.4
    )

    checks = {
        "registry_identity_is_reconstructed": all(
            run.registry_id == registry.registry_id for run in runs
        ),
        "all_outcomes_follow_frozen_predictions": all(
            registry.prediction(candidate, horizon).prediction_id
            for candidate in registry.candidates
            for horizon in registry.horizons
        ),
        "complete_horizon_partition_seed_candidate_matrix": (
            observed_run_cells == expected_run_cells
            and observed_trace_cells == expected_trace_cells
        ),
        "fresh_training_seeds_are_used": (
            not set(registry.model_seeds).intersection(range(20, 28))
            and min(
                partition.data_seed
                for horizon in registry.horizons
                for partition in horizon.partitions
            )
            > 20260819
        ),
        "training_is_shared_within_partition_seed": shared_training,
        "initializations_are_distinct": distinct_initializations,
        "all_trajectory_metrics_are_reconstructed": reconstructed,
        "audit_and_replication_curves_agree": audit_replication_agree,
        "persistent_attenuating_and_reversing_cases_exist": (
            {"persistent", "attenuating", "reversing"}.issubset(classes)
        ),
        "validation_family_metric_predictions_are_calibrated": (
            validation_metric_accuracy
            >= registry.minimum_validation_metric_accuracy
        ),
        "validation_family_transport_classes_are_correct": (
            validation_class_accuracy
            >= registry.minimum_validation_class_accuracy
        ),
        "unreliable_local_only_inference_is_rejected": unreliable_local_rejected,
        "resource_and_cost_descriptors_are_retained": all(
            trace.metrics["normalized_external_memory_cost"]
            == candidates[trace.candidate_id].capacity / 64.0
            for trace in traces
        ),
        "independent_retraining_spot_checks_pass": _spotcheck_retraining(
            registry, runs
        ),
    }
    if tuple(checks) != registry.required_transport_checks:
        raise ValueError("transport verification checks differ from frozen contract")
    return HorizonTransportVerification(
        registry_id=registry.registry_id,
        run_count=len(runs),
        trace_count=len(traces),
        check_results=checks,
        aggregate_metrics=aggregates,
        standard_errors=errors,
        observed_classes=observed_classes,
        predicted_classes=predicted_classes,
        validation_metric_accuracy=validation_metric_accuracy,
        validation_class_accuracy=validation_class_accuracy,
        limitations=(
            "This establishes transport behavior in a synthetic learned-model wrapper, not natural-language or frontier-model transfer.",
            "The controller families and their mechanism descriptors were curated before outcomes rather than autonomously invented.",
            "The selector is exact except in the explicit noisy control, so learned relevance inference remains untested.",
            "The highest horizon is thirty-two distinct updates; terminal cognitive-core capability floors remain unevaluated.",
        ),
    )
