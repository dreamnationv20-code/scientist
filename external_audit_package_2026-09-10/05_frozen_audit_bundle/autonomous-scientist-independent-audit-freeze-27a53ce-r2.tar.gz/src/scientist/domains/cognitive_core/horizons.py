from __future__ import annotations

from typing import Tuple

from scientist.program.horizon_diagnostics import (
    EvaluationHorizon,
    HorizonKind,
)


COGNITIVE_HORIZON_VERSION = "cognitive-core-horizons-v1-20260805"

COGNITIVE_HORIZON_METRICS = (
    "procedure_delta",
    "rapid_learning_delta",
    "boundary_utility_delta",
    "evidence_utility_delta",
    "update_retention_delta",
    "system_cost_delta",
    "pareto_gate_margin",
)


def cognitive_core_horizon_ladder(
    node_id: str,
) -> Tuple[EvaluationHorizon, ...]:
    """Freeze historical-development and fresh terminal horizons separately."""

    declarations = (
        (
            "historical_synthetic_development",
            HorizonKind.DEVELOPMENT,
            "historical://cognitive-core/minilab-through-20260804",
            "historical_minilab_tasks",
            "historical_micro_models",
            100.0,
        ),
        (
            "historical_natural_transfer",
            HorizonKind.LOCAL_VALIDATION,
            "historical://cognitive-core/cub-through-20260804",
            "historical_cub_tasks",
            "historical_qwen_mlx_models",
            100.0,
        ),
        (
            "fresh_causal_development",
            HorizonKind.DEVELOPMENT,
            "sealed://cognitive-core-v3/causal-development",
            "fresh_factorial_causal_tasks",
            "fresh_compact_models",
            25.0,
        ),
        (
            "fresh_synthetic_replication",
            HorizonKind.LOCAL_VALIDATION,
            "sealed://cognitive-core-v3/synthetic-replication",
            "unseen_synthetic_task_families",
            "fresh_compact_model_seeds",
            50.0,
        ),
        (
            "fresh_semantic_transfer",
            HorizonKind.TRANSFER,
            "sealed://cognitive-core-v3/semantic-transfer",
            "unseen_natural_language_task_families",
            "frozen_open_weight_development_models",
            100.0,
        ),
        (
            "fresh_terminal_system",
            HorizonKind.TERMINAL,
            "sealed://cognitive-core-v3/terminal-system",
            "quarantined_cross_domain_task_families",
            "quarantined_model_configurations",
            200.0,
        ),
    )
    return tuple(
        EvaluationHorizon(
            node_id=node_id,
            name=name,
            rank=rank,
            kind=kind,
            partition_ref=partition,
            task_family_ref=tasks,
            model_family_ref=models,
            metric_names=COGNITIVE_HORIZON_METRICS,
            compute_budget=budget,
            sealed=True,
            registrar_ref=COGNITIVE_HORIZON_VERSION,
        )
        for rank, (name, kind, partition, tasks, models, budget) in enumerate(
            declarations
        )
    )
