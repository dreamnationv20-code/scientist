from __future__ import annotations

from itertools import combinations, product
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.alignment_failure_diagnostic_v52xb import (
    hubness_metrics,
    reciprocity_metrics,
)
from scientist.domains.cognitive_core.cross_channel_binding_v52x import (
    binding_metrics,
)


HUBNESS_CORRECTED_ALIGNMENT_VERSION = (
    "general-cognitive-hubness-corrected-alignment-v52xc"
)
M52XC_SEED = 53131
M52XC_M52XB_AUDIT_ID = (
    "ce367c0dd52c23689f07157098ee9717939d8d835551227ac796e7a8e2ef3ec4"
)
M52XC_CHANNELS = ("name", "principle", "action")
M52XC_ROLES = ("neutral", "requirement", "observation")
M52XC_TRAINED_UNDIRECTED_EDGES = (
    ("name", "principle"),
    ("principle", "action"),
)
M52XC_TRAINED_DIRECTIONS = (
    "name->principle",
    "principle->name",
    "principle->action",
    "action->principle",
)
M52XC_HELDOUT_DIRECTIONS = ("name->action", "action->name")

M52XC_SELECTION_TRANSFORM = {
    "name": "canonical",
    "principle": "terse_constraint",
    "action": "mechanistic_expansion",
}
M52XC_CONFIRMATION_TRANSFORM = {
    "name": "canonical",
    "principle": "invariant_abstraction",
    "action": "operational_trace",
}


def training_role_text(
    state: Mapping[str, str], channel: str, role: str
) -> str:
    value = str(state[channel])
    if role == "neutral":
        return value
    templates = {
        ("name", "requirement"): "The required method is identified as {value}.",
        ("name", "observation"): "The operating method is identified as {value}.",
        ("principle", "requirement"): (
            "The required governing rule states that {value}."
        ),
        ("principle", "observation"): (
            "The observed behavior follows the rule that {value}."
        ),
        ("action", "requirement"): "The required operation is to {value}.",
        ("action", "observation"): (
            "The system carries out this operation: {value}."
        ),
    }
    try:
        return templates[(channel, role)].format(value=value)
    except KeyError as error:
        raise ValueError(f"unknown M52xc channel/role: {channel}/{role}") from error


def build_training_view_groups(
    ledger: Mapping[str, Any],
) -> Tuple[Mapping[str, Any], ...]:
    view_pairs = []
    for channel in M52XC_CHANNELS:
        for left_role, right_role in combinations(M52XC_ROLES, 2):
            view_pairs.append((channel, left_role, channel, right_role, "role"))
    for left_channel, right_channel in M52XC_TRAINED_UNDIRECTED_EDGES:
        for left_role, right_role in product(M52XC_ROLES, repeat=2):
            view_pairs.append(
                (
                    left_channel,
                    left_role,
                    right_channel,
                    right_role,
                    "cross_channel",
                )
            )
    groups = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != "discovery":
            continue
        states = tuple(family_value["states"])
        if len(states) != 4:
            raise ValueError("M52xc requires four states in every training family")
        for left_channel, left_role, right_channel, right_role, kind in view_pairs:
            groups.append(
                {
                    "group_id": (
                        f"{family}::{left_channel}.{left_role}::"
                        f"{right_channel}.{right_role}"
                    ),
                    "family": str(family),
                    "semantic_split": "discovery",
                    "pair_kind": kind,
                    "left_channel": left_channel,
                    "left_role": left_role,
                    "right_channel": right_channel,
                    "right_role": right_role,
                    "states": [
                        {
                            "state_key": str(state["key"]),
                            "left_text": training_role_text(
                                state, left_channel, left_role
                            ),
                            "right_text": training_role_text(
                                state, right_channel, right_role
                            ),
                        }
                        for state in states
                    ],
                }
            )
    return tuple(groups)


def _fresh_text(
    state: Mapping[str, str], channel: str, role: str, formulation: str
) -> str:
    value = str(state[channel])
    templates = {
        ("selection", "name", "basis"): (
            "Success presupposes the method called {value}."
        ),
        ("selection", "name", "candidate"): (
            "The method presently in operation is {value}."
        ),
        ("selection", "principle", "basis"): (
            "Success presupposes this decision rule: {value}."
        ),
        ("selection", "principle", "candidate"): (
            "The observed decision rule is: {value}."
        ),
        ("selection", "action", "basis"): (
            "Success presupposes performing this operation: {value}."
        ),
        ("selection", "action", "candidate"): (
            "The mechanism actually performs this operation: {value}."
        ),
        ("confirmation", "name", "basis"): (
            "The target design is the technique known as {value}."
        ),
        ("confirmation", "name", "candidate"): (
            "Inspection identifies the technique as {value}."
        ),
        ("confirmation", "principle", "basis"): (
            "The target behavior is governed by the following invariant: {value}."
        ),
        ("confirmation", "principle", "candidate"): (
            "Inspection reveals the governing invariant: {value}."
        ),
        ("confirmation", "action", "basis"): (
            "The target response carries out the following step: {value}."
        ),
        ("confirmation", "action", "candidate"): (
            "Inspection shows the following step being carried out: {value}."
        ),
    }
    try:
        return templates[(formulation, channel, role)].format(value=value)
    except KeyError as error:
        raise ValueError(
            f"unknown M52xc formulation/channel/role: {formulation}/{channel}/{role}"
        ) from error


def build_fresh_evaluation_rows(
    ledger: Mapping[str, Any], formulation: str
) -> Tuple[Mapping[str, Any], ...]:
    if formulation not in {"selection", "confirmation"}:
        raise ValueError("M52xc formulation must be selection or confirmation")
    transform = (
        M52XC_SELECTION_TRANSFORM
        if formulation == "selection"
        else M52XC_CONFIRMATION_TRANSFORM
    )
    rows = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != "discovery":
            continue
        states = tuple(family_value["states"])
        state_index = {str(state["key"]): state for state in states}
        for direction in M52XC_TRAINED_DIRECTIONS:
            basis_channel, candidate_channel = direction.split("->")
            for basis_state in states:
                orbit = content_digest(
                    {
                        "milestone": "M52xc",
                        "formulation": formulation,
                        "family": family,
                        "direction": direction,
                        "basis_state": basis_state["key"],
                    }
                )
                for candidate_key, candidate_state in state_index.items():
                    metadata = {
                        "record_id": content_digest(
                            {
                                "orbit": orbit,
                                "candidate_state": candidate_key,
                            }
                        ),
                        "orbit_id": orbit,
                        "family": str(family),
                        "semantic_split": "discovery",
                        "formulation_split": formulation,
                        "basis_state_key": str(basis_state["key"]),
                        "candidate_state_key": candidate_key,
                        "basis_transformation": transform[basis_channel],
                        "basis_transformation_split": "m52xc_fresh",
                        "candidate_transformation": transform[candidate_channel],
                        "candidate_transformation_split": "m52xc_fresh",
                        "basis_text": _fresh_text(
                            basis_state, basis_channel, "basis", formulation
                        ),
                        "candidate_text": _fresh_text(
                            candidate_state,
                            candidate_channel,
                            "candidate",
                            formulation,
                        ),
                        "relation_target": (
                            "YES"
                            if str(basis_state["key"]) == candidate_key
                            else "NO"
                        ),
                    }
                    rows.append({"metadata": metadata})
    return tuple(rows)


def geometry_gate_passed(
    retrieval: Mapping[str, Any],
    hubness: Mapping[str, Any],
    reciprocity: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_hidden_ranking_accuracy": float(
            retrieval["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_hidden_ranking_accuracy"]),
        "minimum_hidden_top1_accuracy": float(retrieval["ranking"]["top1_accuracy"])
        >= float(contract["minimum_hidden_top1_accuracy"]),
        "minimum_each_direction_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in retrieval["by_direction"].values()
        )
        >= float(contract["minimum_each_direction_ranking_accuracy"]),
        "minimum_each_family_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in retrieval["by_family"].values()
        )
        >= float(contract["minimum_each_family_ranking_accuracy"]),
        "maximum_highest_column_error_rate": float(
            hubness["errors_to_highest_mean_similarity_column_rate"]
        )
        <= float(contract["maximum_highest_column_error_rate"]),
        "maximum_recurrent_attractor_error_rate": float(
            hubness["errors_to_recurrent_family_attractor_rate"]
        )
        <= float(contract["maximum_recurrent_attractor_error_rate"]),
        "maximum_candidate_indegree_ratio_to_ideal": float(
            hubness["maximum_candidate_selection_indegree_ratio_to_ideal"]
        )
        <= float(contract["maximum_candidate_indegree_ratio_to_ideal"]),
        "minimum_weakest_pair_reciprocity": float(
            reciprocity["weakest_pair_mean_reciprocal_correlation"]
        )
        >= float(contract["minimum_weakest_pair_reciprocity"]),
        "maximum_direction_ranking_gap": float(
            reciprocity["maximum_direction_ranking_gap"]
        )
        <= float(contract["maximum_direction_ranking_gap"]),
    }
    return all(checks.values()), checks


def calibration_gate_passed(
    calibration: Mapping[str, Any],
    parent_calibration: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    aligned = calibration["by_stratum"]["aligned"]
    negative = calibration["by_stratum"]["trained_cross_negative"]
    parent_aligned = parent_calibration["by_stratum"]["aligned"]
    parent_negative = parent_calibration["by_stratum"]["trained_cross_negative"]
    checks = {
        "maximum_parent_margin_mae": float(
            calibration["mean_absolute_parent_margin_drift"]
        )
        <= float(contract["maximum_parent_margin_mae"]),
        "minimum_parent_prediction_agreement": float(
            calibration["parent_prediction_agreement"]
        )
        >= float(contract["minimum_parent_prediction_agreement"]),
        "maximum_aligned_balanced_accuracy_decline": float(
            aligned["absolute"]["balanced_accuracy"]
        )
        - float(parent_aligned["absolute"]["balanced_accuracy"])
        >= -float(contract["maximum_aligned_balanced_accuracy_decline"]),
        "maximum_cross_negative_specificity_decline": float(
            negative["absolute"]["specificity"]
        )
        - float(parent_negative["absolute"]["specificity"])
        >= -float(contract["maximum_cross_negative_specificity_decline"]),
    }
    return all(checks.values()), checks


def output_installation_gate_passed(
    metrics: Mapping[str, Any], contract: Mapping[str, float]
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_output_ranking_accuracy": float(
            metrics["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_output_ranking_accuracy"]),
        "minimum_output_top1_accuracy": float(metrics["ranking"]["top1_accuracy"])
        >= float(contract["minimum_output_top1_accuracy"]),
        "minimum_each_output_direction_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in metrics["by_direction"].values()
        )
        >= float(contract["minimum_each_output_direction_ranking_accuracy"]),
        "minimum_each_output_family_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in metrics["by_family"].values()
        )
        >= float(contract["minimum_each_output_family_ranking_accuracy"]),
    }
    return all(checks.values()), checks


def evaluate_geometry_records(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[str, Mapping[str, Any]]:
    return {
        "retrieval": binding_metrics(records),
        "hubness": hubness_metrics(records),
        "reciprocity": reciprocity_metrics(records),
    }


def select_earliest_pass(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    passing = [candidate for candidate in candidates if bool(candidate["passed"])]
    return min(passing, key=lambda candidate: int(candidate["iteration"])) if passing else None
