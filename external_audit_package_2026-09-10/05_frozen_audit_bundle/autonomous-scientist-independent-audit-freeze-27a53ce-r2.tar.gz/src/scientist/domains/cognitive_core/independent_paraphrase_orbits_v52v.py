from __future__ import annotations

from functools import lru_cache
from typing import Any, Callable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.semantic_relation_competence_v52i import (
    semantic_relation_prompt,
)


INDEPENDENT_PARAPHRASE_ORBITS_VERSION = (
    "general-cognitive-independent-paraphrase-orbits-v52v"
)
M52V_SEED = 53041
M52V_M52U_AUDIT_ID = (
    "417a52b28741843033218051633499b582c71b201ce5119a67245663542f1fa1"
)


def _state(
    key: str,
    name: str,
    principle: str,
    action: str,
    distinction: str,
    trigger: str,
) -> Mapping[str, str]:
    return {
        "key": key,
        "name": name,
        "principle": principle,
        "action": action,
        "distinction": distinction,
        "trigger": trigger,
    }


M52V_FAMILIES: Mapping[str, Tuple[Mapping[str, str], ...]] = {
    "cache_eviction_policy": (
        _state(
            "least_recently_used",
            "least-recently-used eviction",
            "time since the latest access determines the victim",
            "remove the entry whose most recent access is oldest",
            "access count and insertion age do not select the victim",
            "the cache has no free slot",
        ),
        _state(
            "least_frequently_used",
            "least-frequently-used eviction",
            "the smallest accumulated access count determines the victim",
            "remove the entry with the fewest recorded accesses",
            "recency and insertion age do not select the victim",
            "the cache has no free slot",
        ),
        _state(
            "first_in_first_out",
            "first-in-first-out eviction",
            "residence age since insertion determines the victim",
            "remove the entry that entered the cache earliest",
            "recent use and access count do not alter the insertion queue",
            "the cache has no free slot",
        ),
        _state(
            "random_eviction",
            "uniform random eviction",
            "a random draw independent of history determines the victim",
            "sample one resident entry uniformly for removal",
            "neither recency, frequency, nor insertion age receives priority",
            "the cache has no free slot",
        ),
    ),
    "database_index_organization": (
        _state(
            "btree_index",
            "balanced-tree indexing",
            "ordered separator keys route lookups through a balanced search tree",
            "descend tree pages by comparing the key with ordered separators",
            "the structure preserves key order rather than hashing keys into buckets",
            "a record lookup or ordered range scan is requested",
        ),
        _state(
            "hash_index",
            "hash-table indexing",
            "a key hash selects an unordered bucket containing matching entries",
            "hash the lookup key and inspect its assigned bucket",
            "ordered ranges are not represented by the bucket placement",
            "an equality lookup is requested",
        ),
        _state(
            "bitmap_index",
            "bitmap indexing",
            "one bit vector per value records which rows contain that value",
            "combine value-specific bit vectors to locate matching row positions",
            "row membership bits replace per-key search paths",
            "a low-cardinality predicate is evaluated",
        ),
        _state(
            "lsm_index",
            "log-structured merge indexing",
            "writes accumulate in sorted runs that are merged across storage levels",
            "buffer updates in memory and flush them into immutable sorted runs",
            "background compaction replaces in-place page updates",
            "new indexed records are written",
        ),
    ),
    "graph_frontier_policy": (
        _state(
            "breadth_first",
            "breadth-first traversal",
            "vertices with smaller hop distance are expanded before deeper vertices",
            "remove the oldest discovered vertex from a FIFO frontier",
            "discovery depth outranks path cost estimates and heuristic scores",
            "the next frontier vertex is selected",
        ),
        _state(
            "depth_first",
            "depth-first traversal",
            "the most recently discovered unfinished branch is expanded first",
            "remove the newest discovered vertex from a LIFO frontier",
            "branch recency outranks breadth level and path cost",
            "the next frontier vertex is selected",
        ),
        _state(
            "dijkstra_frontier",
            "lowest-path-cost traversal",
            "the smallest accumulated path cost determines the next expansion",
            "remove the vertex with minimum distance-so-far from a priority queue",
            "heuristic estimates and discovery order do not outrank known path cost",
            "the next frontier vertex is selected",
        ),
        _state(
            "astar_frontier",
            "A-star traversal",
            "accumulated path cost plus estimated remaining cost determines expansion",
            "remove the vertex minimizing the sum of known cost and heuristic estimate",
            "neither path cost alone nor discovery order determines expansion",
            "the next frontier vertex is selected",
        ),
    ),
    "parallel_task_distribution": (
        _state(
            "static_blocks",
            "static block assignment",
            "each worker receives a fixed task block before execution begins",
            "partition the task list once and bind each block to one worker",
            "runtime queue length does not change ownership",
            "parallel work is initialized",
        ),
        _state(
            "central_dynamic_queue",
            "central dynamic queue assignment",
            "idle workers repeatedly draw the next task from one shared queue",
            "place unassigned tasks in a central queue consumed on demand",
            "tasks are not permanently bound to workers in advance",
            "a worker becomes available",
        ),
        _state(
            "work_stealing",
            "decentralized work stealing",
            "an idle worker takes tasks from another worker's private deque",
            "let workers own local deques and steal from peers after becoming idle",
            "no single central queue supplies every task",
            "a worker exhausts its local deque",
        ),
        _state(
            "cyclic_assignment",
            "cyclic task assignment",
            "successive tasks rotate deterministically across worker identifiers",
            "assign task number i to worker i modulo the worker count",
            "task cost and runtime idleness do not affect ownership",
            "the next task is enumerated",
        ),
    ),
    "compression_coding": (
        _state(
            "run_length",
            "run-length encoding",
            "a repeated symbol run is represented by the symbol and its repetition count",
            "replace each maximal repeated run with one value-count pair",
            "the method exploits consecutive repetition rather than symbol probability",
            "a maximal run of identical symbols is encountered",
        ),
        _state(
            "huffman",
            "Huffman coding",
            "frequent symbols receive shorter prefix-free codewords",
            "build a probability-weighted prefix tree and emit its leaf codes",
            "dictionary phrase reuse and numeric differences do not define codes",
            "symbol frequencies have been estimated",
        ),
        _state(
            "dictionary_coding",
            "dictionary phrase coding",
            "repeated symbol sequences are replaced by references to dictionary entries",
            "insert recurring phrases into a dictionary and emit their identifiers",
            "single-symbol frequencies alone do not determine phrase identifiers",
            "a previously represented phrase appears again",
        ),
        _state(
            "delta_coding",
            "delta coding",
            "each numeric value is represented by its difference from a reference value",
            "emit the change from the previous value instead of the full value",
            "repeated phrases and symbol probabilities do not define the representation",
            "the next numeric value in an ordered series is encoded",
        ),
    ),
    "model_aggregation_rule": (
        _state(
            "majority_vote",
            "hard majority voting",
            "the class receiving the most discrete model votes becomes the output",
            "convert every model prediction to a class vote and count the votes",
            "probability magnitude and a learned meta-model do not affect the tally",
            "component classifiers have returned class labels",
        ),
        _state(
            "probability_average",
            "probability averaging",
            "the class with the largest mean predicted probability becomes the output",
            "average each class probability across models before taking the argmax",
            "models contribute confidence values rather than only hard votes",
            "component classifiers have returned probability vectors",
        ),
        _state(
            "weighted_blend",
            "fixed weighted blending",
            "a predetermined weight controls each model's contribution to the combined score",
            "multiply each model score by its fixed weight and sum the results",
            "the combination weights are not learned anew for each example",
            "component models have returned numeric scores",
        ),
        _state(
            "stacked_meta_model",
            "stacked meta-model aggregation",
            "a learned second-level model maps component predictions to the final output",
            "feed the component outputs into a trained meta-learner",
            "a fixed vote or arithmetic average does not determine the result",
            "all component predictions for an example are available",
        ),
    ),
    "stream_window_semantics": (
        _state(
            "tumbling_window",
            "tumbling event-time windows",
            "each event belongs to one nonoverlapping fixed-duration interval",
            "partition event time into adjacent fixed windows with no overlap",
            "an event cannot contribute to two neighboring windows",
            "an event timestamp is assigned to a window",
        ),
        _state(
            "sliding_window",
            "sliding event-time windows",
            "overlapping fixed-duration intervals advance by a shorter slide step",
            "place an event into every active interval covering its timestamp",
            "one event may contribute to multiple overlapping windows",
            "an event timestamp is assigned to windows",
        ),
        _state(
            "session_window",
            "gap-delimited session windows",
            "a sufficiently long inactivity gap closes the current variable-length session",
            "group nearby events until the inactivity timeout is exceeded",
            "calendar-aligned fixed boundaries do not close the session",
            "the time gap since the preceding event is measured",
        ),
        _state(
            "landmark_window",
            "landmark windows",
            "all events since a designated landmark remain in one growing window",
            "retain events from a fixed starting point through the present",
            "old events do not expire by a rolling duration",
            "a new event arrives after the landmark",
        ),
    ),
    "storage_compaction_strategy": (
        _state(
            "size_tiered",
            "size-tiered compaction",
            "similarly sized sorted runs are merged after enough peers accumulate",
            "collect runs of comparable size and merge them into a larger run",
            "overlapping key ranges may coexist across a tier",
            "a tier accumulates its merge threshold of similar runs",
        ),
        _state(
            "leveled",
            "leveled compaction",
            "each level maintains bounded size and mostly nonoverlapping key ranges",
            "merge an overflowing run into overlapping ranges of the next level",
            "range organization rather than run-size similarity controls selection",
            "a level exceeds its size budget",
        ),
        _state(
            "fifo_compaction",
            "FIFO file expiration",
            "the oldest complete files are discarded when storage exceeds its limit",
            "delete files in creation order without merging their records",
            "key overlap and run size do not select merge inputs",
            "the configured storage budget is exceeded",
        ),
        _state(
            "time_window_compaction",
            "time-window compaction",
            "files whose records occupy the same time bucket are compacted together",
            "group files by event-time interval and merge within each interval",
            "files from unrelated time buckets are not merged merely due to size",
            "a time bucket accumulates enough files",
        ),
    ),
    "concurrency_progress_guarantee": (
        _state(
            "wait_free",
            "wait-free progress",
            "every operation completes within a bounded number of its own steps",
            "ensure each thread finishes regardless of delays or actions by peers",
            "system-wide progress alone is insufficient because every caller must progress",
            "a thread invokes the concurrent operation",
        ),
        _state(
            "lock_free",
            "lock-free progress",
            "some operation always completes even though an individual thread may starve",
            "use retries so contention still permits system-wide completion",
            "per-thread bounded completion is not guaranteed",
            "concurrent operations contend",
        ),
        _state(
            "obstruction_free",
            "obstruction-free progress",
            "an operation completes if it eventually runs without interference",
            "allow a thread to finish after it executes alone for long enough",
            "continued contention need not guarantee any completion",
            "a thread obtains a sufficiently long interference-free interval",
        ),
        _state(
            "blocking_progress",
            "blocking lock-based progress",
            "a thread may wait for another thread to release exclusive ownership",
            "acquire a mutual-exclusion lock before entering the protected operation",
            "a stalled lock owner can prevent all waiting callers from progressing",
            "the protected operation is invoked",
        ),
    ),
    "query_join_strategy": (
        _state(
            "nested_loop",
            "nested-loop joining",
            "every outer row probes candidate rows of the inner input directly",
            "scan the inner relation for each row of the outer relation",
            "neither a hash table nor sorted merge order organizes matching",
            "an outer row needs matching inner rows",
        ),
        _state(
            "hash_join",
            "hash joining",
            "equality keys map rows from both inputs into corresponding hash buckets",
            "build a hash table on one input and probe it with the other",
            "input ordering is unnecessary and nonequality predicates are unsupported",
            "an equality join key is evaluated",
        ),
        _state(
            "sort_merge_join",
            "sort-merge joining",
            "two key-ordered inputs advance together to find equal key ranges",
            "sort both inputs by join key and merge their matching runs",
            "hash buckets and repeated full inner scans are not used",
            "the next ordered key from either input is examined",
        ),
        _state(
            "index_nested_loop",
            "index nested-loop joining",
            "each outer key performs an indexed lookup into the inner relation",
            "probe an inner index separately for every outer row",
            "the inner relation is not scanned completely for each outer row",
            "an outer row supplies its join key",
        ),
    ),
    "neural_normalization_method": (
        _state(
            "batch_normalization",
            "batch normalization",
            "statistics are computed per feature across examples in the mini-batch",
            "normalize each activation channel using its batch mean and variance",
            "different features are not pooled into one per-example statistic",
            "a training mini-batch is processed",
        ),
        _state(
            "layer_normalization",
            "layer normalization",
            "statistics are computed across features separately for each example",
            "normalize one example using the mean and variance of its layer features",
            "other examples in the mini-batch do not supply the statistics",
            "one example reaches the normalized layer",
        ),
        _state(
            "instance_normalization",
            "instance normalization",
            "each example and channel uses statistics across its spatial positions",
            "normalize every channel of one example over that channel's spatial map",
            "channels are not pooled together and batch peers do not contribute",
            "one feature map is normalized",
        ),
        _state(
            "group_normalization",
            "group normalization",
            "channels are partitioned into groups normalized within each example",
            "compute statistics over spatial positions and channels inside each group",
            "the complete channel set and other batch examples are not pooled together",
            "one example's grouped feature maps are normalized",
        ),
    ),
    "privacy_protection_mechanism": (
        _state(
            "differential_privacy",
            "differential privacy",
            "randomized noise bounds how much one person's data changes output probabilities",
            "calibrate random noise to the sensitivity of the released computation",
            "the guarantee does not rely on grouping people into identical records",
            "a statistic derived from private records is released",
        ),
        _state(
            "k_anonymity",
            "k-anonymity",
            "each released quasi-identifier pattern is shared by at least k records",
            "generalize or suppress attributes until every equivalence class has size k",
            "no probabilistic output-stability guarantee is provided",
            "a table containing quasi-identifiers is published",
        ),
        _state(
            "homomorphic_encryption",
            "homomorphic encrypted computation",
            "selected computations operate directly on ciphertext and decrypt to the correct result",
            "evaluate supported arithmetic without first decrypting the private operands",
            "participants need not reveal plaintext inputs to the compute service",
            "a computation over encrypted values is requested",
        ),
        _state(
            "secure_multiparty_computation",
            "secure multiparty computation",
            "several parties jointly compute a function without revealing their private inputs",
            "exchange protocol messages that reveal only the agreed function output",
            "no single party receives every plaintext input",
            "multiple data owners invoke a joint function",
        ),
    ),
}


M52V_FAMILIES_BY_SPLIT = {
    "discovery": (
        "cache_eviction_policy",
        "database_index_organization",
        "graph_frontier_policy",
        "parallel_task_distribution",
        "compression_coding",
        "model_aggregation_rule",
    ),
    "development": (
        "stream_window_semantics",
        "storage_compaction_strategy",
    ),
    "sealed": (
        "concurrency_progress_guarantee",
        "query_join_strategy",
        "neural_normalization_method",
        "privacy_protection_mechanism",
    ),
}


M52V_TRANSFORMATIONS_BY_SPLIT = {
    "discovery": (
        "canonical",
        "terse_constraint",
        "mechanistic_expansion",
        "invariant_abstraction",
    ),
    "development": ("operational_trace", "contrastive_boundary"),
    "sealed": ("passive_reframe", "causal_conditional"),
}


def _basis_canonical(state: Mapping[str, str]) -> str:
    return f"The conclusion requires {state['name']}."


def _basis_terse(state: Mapping[str, str]) -> str:
    return f"Required decision rule: {state['principle']}."


def _basis_mechanistic(state: Mapping[str, str]) -> str:
    return f"The evidence depends on this mechanism: {state['action']}."


def _basis_invariant(state: Mapping[str, str]) -> str:
    return f"Validity requires the invariant that {state['principle']}."


def _basis_operational(state: Mapping[str, str]) -> str:
    return f"The evidence applies only if the required operation is to {state['action']}."


def _basis_contrastive(state: Mapping[str, str]) -> str:
    return f"The assumed regime follows this rule: {state['principle']}; {state['distinction']}."


def _basis_passive(state: Mapping[str, str]) -> str:
    return f"Under the argument, the mandated behavior is to {state['action']}."


def _basis_causal(state: Mapping[str, str]) -> str:
    return f"When {state['trigger']}, the assumed response is to {state['action']}."


def _candidate_canonical(state: Mapping[str, str]) -> str:
    return f"The current system uses {state['name']}."


def _candidate_terse(state: Mapping[str, str]) -> str:
    return f"Observed rule: {state['principle']}."


def _candidate_mechanistic(state: Mapping[str, str]) -> str:
    return f"Its active mechanism is to {state['action']}."


def _candidate_invariant(state: Mapping[str, str]) -> str:
    return f"Current behavior maintains this invariant: {state['principle']}."


def _candidate_operational(state: Mapping[str, str]) -> str:
    return f"A runtime trace exhibits this operation: {state['action']}."


def _candidate_contrastive(state: Mapping[str, str]) -> str:
    return f"The implementation follows {state['principle']}; {state['distinction']}."


def _candidate_passive(state: Mapping[str, str]) -> str:
    return f"In the current deployment, the selected behavior is to {state['action']}."


def _candidate_causal(state: Mapping[str, str]) -> str:
    return f"Whenever {state['trigger']}, the system responds by choosing to {state['action']}."


M52V_BASIS_RENDERERS: Mapping[str, Callable[[Mapping[str, str]], str]] = {
    "canonical": _basis_canonical,
    "terse_constraint": _basis_terse,
    "mechanistic_expansion": _basis_mechanistic,
    "invariant_abstraction": _basis_invariant,
    "operational_trace": _basis_operational,
    "contrastive_boundary": _basis_contrastive,
    "passive_reframe": _basis_passive,
    "causal_conditional": _basis_causal,
}


M52V_CANDIDATE_RENDERERS: Mapping[str, Callable[[Mapping[str, str]], str]] = {
    "canonical": _candidate_canonical,
    "terse_constraint": _candidate_terse,
    "mechanistic_expansion": _candidate_mechanistic,
    "invariant_abstraction": _candidate_invariant,
    "operational_trace": _candidate_operational,
    "contrastive_boundary": _candidate_contrastive,
    "passive_reframe": _candidate_passive,
    "causal_conditional": _candidate_causal,
}


def _split_for(value: str, mapping: Mapping[str, Sequence[str]]) -> str:
    selected = [split for split, values in mapping.items() if value in values]
    if len(selected) != 1:
        raise ValueError(f"M52v value must belong to exactly one split: {value}")
    return selected[0]


def render_basis(state: Mapping[str, str], transformation: str) -> str:
    return M52V_BASIS_RENDERERS[transformation](state)


def render_candidate(state: Mapping[str, str], transformation: str) -> str:
    return M52V_CANDIDATE_RENDERERS[transformation](state)


@lru_cache(maxsize=1)
def build_m52v_relation_rows() -> Tuple[Mapping[str, Any], ...]:
    rows = []
    transformations = tuple(M52V_BASIS_RENDERERS)
    for family, states in M52V_FAMILIES.items():
        semantic_split = _split_for(family, M52V_FAMILIES_BY_SPLIT)
        for basis_state in states:
            orbit_id = "m52v-orbit-" + content_digest(
                {
                    "version": INDEPENDENT_PARAPHRASE_ORBITS_VERSION,
                    "family": family,
                    "basis_state": basis_state["key"],
                }
            )[:24]
            for basis_transformation in transformations:
                basis = render_basis(basis_state, basis_transformation)
                basis_split = _split_for(
                    basis_transformation, M52V_TRANSFORMATIONS_BY_SPLIT
                )
                for candidate_state in states:
                    target = "YES" if candidate_state["key"] == basis_state["key"] else "NO"
                    for candidate_transformation in transformations:
                        candidate = render_candidate(
                            candidate_state, candidate_transformation
                        )
                        candidate_split = _split_for(
                            candidate_transformation,
                            M52V_TRANSFORMATIONS_BY_SPLIT,
                        )
                        relation_id = "m52v-relation-" + content_digest(
                            {
                                "version": INDEPENDENT_PARAPHRASE_ORBITS_VERSION,
                                "family": family,
                                "basis_state": basis_state["key"],
                                "candidate_state": candidate_state["key"],
                                "basis_transformation": basis_transformation,
                                "candidate_transformation": candidate_transformation,
                            }
                        )[:24]
                        rows.append(
                            {
                                "prompt": semantic_relation_prompt(basis, candidate),
                                "metadata": {
                                    "record_id": relation_id,
                                    "orbit_id": orbit_id,
                                    "family": family,
                                    "semantic_split": semantic_split,
                                    "basis_state_key": basis_state["key"],
                                    "candidate_state_key": candidate_state["key"],
                                    "basis_transformation": basis_transformation,
                                    "basis_transformation_split": basis_split,
                                    "candidate_transformation": candidate_transformation,
                                    "candidate_transformation_split": candidate_split,
                                    "basis_generator_id": (
                                        f"basis::{basis_transformation}::deterministic-v1"
                                    ),
                                    "candidate_generator_id": (
                                        f"candidate::{candidate_transformation}::deterministic-v1"
                                    ),
                                    "basis_text": basis,
                                    "candidate_text": candidate,
                                    "relation_target": target,
                                },
                            }
                        )
    return tuple(rows)


def orbit_ledger() -> Mapping[str, Any]:
    return {
        "version": INDEPENDENT_PARAPHRASE_ORBITS_VERSION,
        "semantic_families": {
            family: {
                "split": _split_for(family, M52V_FAMILIES_BY_SPLIT),
                "states": [dict(state) for state in states],
            }
            for family, states in M52V_FAMILIES.items()
        },
        "transformations": {
            transformation: {
                "split": _split_for(
                    transformation, M52V_TRANSFORMATIONS_BY_SPLIT
                ),
                "basis_generator_id": f"basis::{transformation}::deterministic-v1",
                "candidate_generator_id": f"candidate::{transformation}::deterministic-v1",
                "role_independent": True,
            }
            for transformation in M52V_BASIS_RENDERERS
        },
        "construction": {
            "basis_renderer_inputs": ["one semantic state", "one basis transformation"],
            "candidate_renderer_inputs": [
                "one semantic state",
                "one candidate transformation",
            ],
            "renderer_can_observe_other_role_text": False,
            "relation_builder_changes_rendered_text": False,
            "external_semantic_validation_complete": False,
        },
    }
