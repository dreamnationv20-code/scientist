from __future__ import annotations

from itertools import product
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.cross_channel_binding_v52x import (
    binding_metrics,
    descriptor_direction,
)
from scientist.domains.cognitive_core.independent_paraphrase_orbits_v52v import (
    semantic_relation_prompt,
)
from scientist.domains.cognitive_core.joint_pair_relation_operator_v52xjv import (
    pair_relation_confirmation_gate_passed,
    pair_relation_development_gate_passed,
    pair_relation_fold_gate_passed,
    select_earliest_pair_relation_pass,
    summarize_joint_output_panel,
    summarize_pair_relation_lofo,
)
from scientist.domains.cognitive_core.reciprocal_role_alignment_v52xd import (
    M52XD_TRAINED_DIRECTIONS,
)
from scientist.domains.cognitive_core.representation_atlas_v52w import (
    relation_margin_records,
)


INTERACTION_FACTORIZED_RELATION_VERSION = (
    "general-cognitive-interaction-factorized-relation-v52xjx"
)
M52XJX_SEED = 53521
M52XJX_M52XJW_AUDIT_ID = (
    "75bda67e9738230ff640253c56739b7d8f278f0cdc996a966ad921ae402fd14b"
)
M52XJX_STYLE_COUNT = 2
M52XJX_CHANNELS = ("name", "principle", "action")
M52XJX_DIRECTIONS = tuple(M52XD_TRAINED_DIRECTIONS)
M52XJX_FORMULATION_SPLIT = {
    "internal_a": "discovery",
    "internal_b": "discovery",
    "development_a": "development",
    "development_b": "development",
    "sealed_a": "sealed",
    "sealed_b": "sealed",
}


REFERENCE_QUERY_OPEN = "<REFERENCE_SUMMARY_QUERY>"
REFERENCE_QUERY_CLOSE = "</REFERENCE_SUMMARY_QUERY>"
CANDIDATE_QUERY_OPEN = "<CANDIDATE_SUMMARY_QUERY>"
CANDIDATE_QUERY_CLOSE = "</CANDIDATE_SUMMARY_QUERY>"
REFERENCE_QUERY_TEXT = (
    "Encode the reference meaning after considering the candidate context."
)
CANDIDATE_QUERY_TEXT = (
    "Encode the candidate meaning after considering the reference context."
)


_FRAME = {
    "internal_a": "interaction-preserving correspondence test",
    "internal_b": "joint role-factor audit",
    "development_a": "unseen interaction transfer",
    "development_b": "novel joint-factor review",
    "sealed_a": "quarantined interaction check",
    "sealed_b": "independent interaction confirmation",
}
_NOUN = {
    "name": "method identity",
    "principle": "governing rule",
    "action": "operational behavior",
}
_PREFIX = {
    "internal_a": "interaction_correspondence",
    "internal_b": "joint_role_factor",
    "development_a": "unseen_interaction",
    "development_b": "novel_joint_factor",
    "sealed_a": "quarantined_interaction",
    "sealed_b": "independent_interaction",
}


def interaction_pair_text(
    state: Mapping[str, str],
    channel: str,
    role: str,
    formulation: str,
    style: int,
) -> str:
    if formulation not in M52XJX_FORMULATION_SPLIT:
        raise ValueError(f"unknown M52xj-X formulation: {formulation}")
    if channel not in M52XJX_CHANNELS or role not in {"basis", "candidate"}:
        raise ValueError(f"unknown M52xj-X channel/role: {channel}/{role}")
    if not 0 <= int(style) < M52XJX_STYLE_COUNT:
        raise ValueError(f"unknown M52xj-X style: {style}")
    frame = _FRAME[formulation]
    noun = _NOUN[channel]
    value = str(state[channel])
    basis = (
        "Reference evidence for the {frame}; {noun}: {value}",
        "The {frame} receives this reference-side {noun}: {value}",
    )
    candidate = (
        "Candidate evidence for the {frame}; {noun}: {value}",
        "The {frame} receives this candidate-side {noun}: {value}",
    )
    return (basis if role == "basis" else candidate)[int(style)].format(
        frame=frame, noun=noun, value=value
    )


def interaction_cross_encoder_prompt(
    basis_text: str,
    candidate_text: str,
    basis_channel: str,
    candidate_channel: str,
) -> str:
    if basis_channel not in M52XJX_CHANNELS or candidate_channel not in M52XJX_CHANNELS:
        raise ValueError("unknown M52xj-X channel route")
    return (
        "Construct two role-conditioned semantic summaries for a later relation "
        "decision. Both summaries must consider both pieces of evidence.\n"
        f"<REFERENCE channel=\"{basis_channel}\">{basis_text}</REFERENCE>\n"
        f"<CANDIDATE channel=\"{candidate_channel}\">{candidate_text}</CANDIDATE>\n"
        f"{REFERENCE_QUERY_OPEN}{REFERENCE_QUERY_TEXT}{REFERENCE_QUERY_CLOSE}\n"
        f"{CANDIDATE_QUERY_OPEN}{CANDIDATE_QUERY_TEXT}{CANDIDATE_QUERY_CLOSE}\n"
        "Do not answer YES or NO; expose the two internal summaries only."
    )


def _tagged_character_span(
    rendered: str, open_tag: str, close_tag: str
) -> tuple[int, int]:
    open_index = rendered.index(open_tag) + len(open_tag)
    close_index = rendered.index(close_tag, open_index)
    if close_index <= open_index:
        raise ValueError("M52xj-X tagged span is empty")
    return open_index, close_index


def joint_role_tokenization(
    tokenizer: Any, prompt: str
) -> tuple[tuple[int, ...], tuple[int, ...], tuple[int, ...]]:
    messages = [{"role": "user", "content": prompt}]
    rendered = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    underlying = getattr(tokenizer, "_tokenizer", tokenizer)
    encoded = underlying(
        rendered, add_special_tokens=False, return_offsets_mapping=True
    )
    token_ids = tuple(int(value) for value in encoded["input_ids"])
    wrapper_ids = tuple(
        int(value)
        for value in tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=False,
        )
    )
    if token_ids != wrapper_ids:
        raise ValueError("M52xj-X rendered and wrapper tokenizations disagree")
    offsets = tuple(tuple(int(part) for part in value) for value in encoded["offset_mapping"])

    def indices(open_tag: str, close_tag: str) -> tuple[int, ...]:
        start, end = _tagged_character_span(rendered, open_tag, close_tag)
        selected = tuple(
            index
            for index, (left, right) in enumerate(offsets)
            if right > start and left < end
        )
        if not selected or any(offsets[index] == (0, 0) for index in selected):
            raise ValueError("M52xj-X could not isolate a query-token span")
        return selected

    return (
        token_ids,
        indices(REFERENCE_QUERY_OPEN, REFERENCE_QUERY_CLOSE),
        indices(CANDIDATE_QUERY_OPEN, CANDIDATE_QUERY_CLOSE),
    )


def build_interaction_pair_rows(
    ledger: Mapping[str, Any], formulation: str
) -> Tuple[Mapping[str, Any], ...]:
    if formulation not in M52XJX_FORMULATION_SPLIT:
        raise ValueError("unknown M52xj-X formulation")
    semantic_split = M52XJX_FORMULATION_SPLIT[formulation]
    rows = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != semantic_split:
            continue
        states = tuple(family_value["states"])
        if len(states) != 4:
            raise ValueError("M52xj-X requires four states per family")
        for direction in M52XJX_DIRECTIONS:
            basis_channel, candidate_channel = direction.split("->")
            for basis_style, candidate_style in product(
                range(M52XJX_STYLE_COUNT), repeat=2
            ):
                for basis_state in states:
                    orbit = content_digest(
                        {
                            "milestone": "M52xj-X",
                            "formulation": formulation,
                            "family": family,
                            "direction": direction,
                            "basis_style": basis_style,
                            "candidate_style": candidate_style,
                            "basis_state": basis_state["key"],
                        }
                    )
                    basis_text = interaction_pair_text(
                        basis_state,
                        basis_channel,
                        "basis",
                        formulation,
                        basis_style,
                    )
                    for candidate_state in states:
                        candidate_text = interaction_pair_text(
                            candidate_state,
                            candidate_channel,
                            "candidate",
                            formulation,
                            candidate_style,
                        )
                        prefix = _PREFIX[formulation]
                        metadata = {
                            "record_id": content_digest(
                                {
                                    "orbit": orbit,
                                    "candidate_state": candidate_state["key"],
                                }
                            ),
                            "orbit_id": orbit,
                            "family": str(family),
                            "semantic_split": semantic_split,
                            "formulation_split": formulation,
                            "basis_style": int(basis_style),
                            "candidate_style": int(candidate_style),
                            "basis_channel": basis_channel,
                            "candidate_channel": candidate_channel,
                            "basis_state_key": str(basis_state["key"]),
                            "candidate_state_key": str(candidate_state["key"]),
                            "basis_transformation": (
                                f"{prefix}_{basis_channel}_{basis_style}"
                            ),
                            "basis_transformation_split": "m52xjx_interaction_pair",
                            "candidate_transformation": (
                                f"{prefix}_{candidate_channel}_{candidate_style}"
                            ),
                            "candidate_transformation_split": (
                                "m52xjx_interaction_pair"
                            ),
                            "basis_text": basis_text,
                            "candidate_text": candidate_text,
                            "cross_encoder_prompt": interaction_cross_encoder_prompt(
                                basis_text,
                                candidate_text,
                                basis_channel,
                                candidate_channel,
                            ),
                            "relation_target": (
                                "YES"
                                if str(basis_state["key"])
                                == str(candidate_state["key"])
                                else "NO"
                            ),
                        }
                        row = {
                            "prompt": semantic_relation_prompt(
                                basis_text, candidate_text
                            ),
                            "metadata": metadata,
                        }
                        if descriptor_direction(row) != direction:
                            raise ValueError(
                                "M52xj-X direction routing is inconsistent"
                            )
                        rows.append(row)
    return tuple(rows)


def build_interaction_relation_episodes(
    family_episodes: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    episodes = []
    for source in family_episodes:
        left_channel, right_channel = str(source["edge"]).split("<->")
        directions = (
            (
                f"{left_channel}->{right_channel}",
                left_channel,
                right_channel,
                "left_basis_text",
                "right_candidate_text",
            ),
            (
                f"{right_channel}->{left_channel}",
                right_channel,
                left_channel,
                "right_basis_text",
                "left_candidate_text",
            ),
        )
        views = []
        for view in source["views"]:
            groups = []
            states = tuple(view["states"])
            for direction, basis_channel, candidate_channel, basis_key, candidate_key in directions:
                for basis_index, basis_state in enumerate(states):
                    examples = []
                    for candidate_index, candidate_state in enumerate(states):
                        basis_text = str(basis_state[basis_key])
                        candidate_text = str(candidate_state[candidate_key])
                        examples.append(
                            {
                                "example_id": content_digest(
                                    {
                                        "episode": source["episode_id"],
                                        "family": view["family"],
                                        "direction": direction,
                                        "basis": basis_state["state_key"],
                                        "candidate": candidate_state["state_key"],
                                    }
                                ),
                                "family": str(view["family"]),
                                "direction": direction,
                                "basis_channel": basis_channel,
                                "candidate_channel": candidate_channel,
                                "basis_state_key": str(basis_state["state_key"]),
                                "candidate_state_key": str(candidate_state["state_key"]),
                                "basis_text": basis_text,
                                "candidate_text": candidate_text,
                                "cross_encoder_prompt": interaction_cross_encoder_prompt(
                                    basis_text,
                                    candidate_text,
                                    basis_channel,
                                    candidate_channel,
                                ),
                                "relation_target": (
                                    "YES" if basis_index == candidate_index else "NO"
                                ),
                            }
                        )
                    groups.append(
                        {
                            "group_id": content_digest(
                                {
                                    "episode": source["episode_id"],
                                    "family": view["family"],
                                    "direction": direction,
                                    "basis": basis_state["state_key"],
                                }
                            ),
                            "family": str(view["family"]),
                            "direction": direction,
                            "basis_channel": basis_channel,
                            "candidate_channel": candidate_channel,
                            "basis_state_key": str(basis_state["state_key"]),
                            "examples": examples,
                        }
                    )
            if len(groups) != 8 or not all(
                len(group["examples"]) == 4
                and sum(row["relation_target"] == "YES" for row in group["examples"])
                == 1
                for group in groups
            ):
                raise ValueError("each M52xj-X view requires eight complete groups")
            views.append(
                {
                    "family": str(view["family"]),
                    "context": str(view["context"]),
                    "groups": groups,
                }
            )
        episodes.append(
            {
                "episode_id": str(source["episode_id"]),
                "families": list(source["families"]),
                "edge": str(source["edge"]),
                "semantic_split": "discovery",
                "views": views,
            }
        )
    if len(episodes) != 90 or not all(len(row["views"]) == 2 for row in episodes):
        raise ValueError("M52xj-X requires 90 two-family interaction episodes")
    return tuple(episodes)


def leave_one_family_out_interaction_episodes(
    episodes: Sequence[Mapping[str, Any]], held_family: str
) -> Tuple[Mapping[str, Any], ...]:
    selected = tuple(
        episode
        for episode in episodes
        if str(held_family) not in {str(value) for value in episode["families"]}
    )
    if len(selected) != 60:
        raise ValueError("each M52xj-X fold requires 60 five-family episodes")
    return selected


def evaluate_interaction_output_ensemble(
    rows: Sequence[Mapping[str, Any]],
    margins: Sequence[float],
    gate: Mapping[str, float],
) -> Mapping[str, Any]:
    records = relation_margin_records(rows, margins)
    metrics = binding_metrics(records)
    checks = {
        "minimum_absolute_balanced_accuracy": float(
            metrics["absolute"]["balanced_accuracy"]
        )
        >= float(gate["minimum_absolute_balanced_accuracy"]),
        "minimum_ranking_accuracy": float(metrics["ranking"]["ranking_accuracy"])
        >= float(gate["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(metrics["ranking"]["top1_accuracy"])
        >= float(gate["minimum_top1_accuracy"]),
        "minimum_each_direction_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in metrics["by_direction"].values()
        )
        >= float(gate["minimum_each_direction_ranking_accuracy"]),
        "minimum_each_family_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in metrics["by_family"].values()
        )
        >= float(gate["minimum_each_family_ranking_accuracy"]),
        "minimum_each_family_balanced_accuracy": min(
            float(value["absolute"]["balanced_accuracy"])
            for value in metrics["by_family"].values()
        )
        >= float(gate["minimum_each_family_balanced_accuracy"]),
    }
    return {
        "relation_records": list(records),
        "metrics": metrics,
        "checks": checks,
        "passed": all(checks.values()),
    }


__all__ = (
    "CANDIDATE_QUERY_CLOSE",
    "CANDIDATE_QUERY_OPEN",
    "CANDIDATE_QUERY_TEXT",
    "INTERACTION_FACTORIZED_RELATION_VERSION",
    "M52XJX_CHANNELS",
    "M52XJX_DIRECTIONS",
    "M52XJX_FORMULATION_SPLIT",
    "M52XJX_M52XJW_AUDIT_ID",
    "M52XJX_SEED",
    "REFERENCE_QUERY_CLOSE",
    "REFERENCE_QUERY_OPEN",
    "REFERENCE_QUERY_TEXT",
    "build_interaction_pair_rows",
    "build_interaction_relation_episodes",
    "evaluate_interaction_output_ensemble",
    "interaction_cross_encoder_prompt",
    "interaction_pair_text",
    "joint_role_tokenization",
    "leave_one_family_out_interaction_episodes",
    "pair_relation_confirmation_gate_passed",
    "pair_relation_development_gate_passed",
    "pair_relation_fold_gate_passed",
    "select_earliest_pair_relation_pass",
    "summarize_joint_output_panel",
    "summarize_pair_relation_lofo",
)
