from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.general_contract_v27 import (
    CognitiveOperation,
    CognitiveTask,
    EvaluationGates,
    GENERAL_CORE_CONTRACT_VERSION,
    build_suite,
    score_response,
)


INTERNAL_CORE_VERSION = "general-cognitive-core-internalization-v28"


@dataclass(frozen=True)
class ConditionMetrics:
    condition: str
    task_count: int
    parse_coverage: float
    overall_score: float
    score_by_operation: Mapping[str, float]
    score_by_track: Mapping[str, float]
    exact_rate: float
    elapsed_seconds: float
    peak_memory_gb: float

    def as_dict(self) -> Dict[str, Any]:
        return {
            "condition": self.condition,
            "task_count": self.task_count,
            "parse_coverage": self.parse_coverage,
            "overall_score": self.overall_score,
            "score_by_operation": dict(sorted(self.score_by_operation.items())),
            "score_by_track": dict(sorted(self.score_by_track.items())),
            "exact_rate": self.exact_rate,
            "elapsed_seconds": self.elapsed_seconds,
            "peak_memory_gb": self.peak_memory_gb,
        }


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _chat_prompt(tokenizer: Any, task_prompt: str, system_instruction: str = "") -> str:
    messages = []
    if system_instruction:
        messages.append({"role": "system", "content": system_instruction})
    messages.append({"role": "user", "content": task_prompt})
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


def _batch_responses(
    model: Any,
    tokenizer: Any,
    prompts: Sequence[str],
    *,
    batch_size: int,
    max_tokens: int,
    max_batch_tokens: int,
) -> Tuple[Tuple[str, ...], float]:
    from mlx_lm import batch_generate

    encoded = [(index, tokenizer.encode(prompt)) for index, prompt in enumerate(prompts)]
    encoded.sort(key=lambda item: len(item[1]))
    responses: list[Optional[str]] = [None] * len(prompts)
    peak_memory = 0.0
    cursor = 0
    while cursor < len(encoded):
        end = min(cursor + batch_size, len(encoded))
        while end > cursor + 1:
            padded = (end - cursor) * len(encoded[end - 1][1])
            if padded <= max_batch_tokens:
                break
            end -= 1
        records = encoded[cursor:end]
        generated = batch_generate(
            model,
            tokenizer,
            [tokens for _, tokens in records],
            max_tokens=max_tokens,
            verbose=False,
        )
        for (index, _), response in zip(records, generated.texts):
            responses[index] = response.strip()
        peak_memory = max(peak_memory, float(generated.stats.peak_memory))
        cursor = end
        print(
            json.dumps(
                {
                    "stage": "v28_evaluation",
                    "completed": cursor,
                    "total": len(encoded),
                    "peak_memory_gb": round(peak_memory, 3),
                },
                sort_keys=True,
            ),
            flush=True,
        )
    if any(response is None for response in responses):
        raise RuntimeError("missing model response")
    return tuple(str(response) for response in responses), peak_memory


def aggregate_metrics(
    condition: str,
    tasks: Sequence[CognitiveTask],
    records: Sequence[Mapping[str, Any]],
    elapsed_seconds: float,
    peak_memory_gb: float,
) -> ConditionMetrics:
    if len(tasks) != len(records):
        raise ValueError("tasks and records do not align")
    by_operation: Dict[str, list[float]] = {}
    by_track: Dict[str, list[float]] = {}
    parsed = 0
    exact = 0
    scores = []
    for task, record in zip(tasks, records):
        score = float(record["assessment"]["score"])
        scores.append(score)
        parsed += int(bool(record["assessment"]["parsed"]))
        exact += int(score == 1.0)
        by_operation.setdefault(task.operation.value, []).append(score)
        by_track.setdefault(task.track.value, []).append(score)
    return ConditionMetrics(
        condition=condition,
        task_count=len(tasks),
        parse_coverage=parsed / len(tasks),
        overall_score=sum(scores) / len(scores),
        score_by_operation={key: sum(values) / len(values) for key, values in by_operation.items()},
        score_by_track={key: sum(values) / len(values) for key, values in by_track.items()},
        exact_rate=exact / len(tasks),
        elapsed_seconds=elapsed_seconds,
        peak_memory_gb=peak_memory_gb,
    )


def evaluate_model_condition(
    output_root: Path,
    model_path: str,
    condition: str,
    *,
    adapter_path: Optional[Path] = None,
    system_instruction: str = "",
    test_per_operation: int = 24,
    batch_size: int = 8,
    max_tokens: int = 32,
    max_batch_tokens: int = 12000,
) -> Mapping[str, Any]:
    from mlx_lm import load

    started = time.monotonic()
    tasks = build_suite("test", test_per_operation)
    load_arguments: Dict[str, Any] = {"return_config": True}
    if adapter_path is not None:
        load_arguments["adapter_path"] = str(adapter_path)
    model, tokenizer, model_config = load(model_path, **load_arguments)
    prompts = tuple(_chat_prompt(tokenizer, task.prompt, system_instruction) for task in tasks)
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        prompts,
        batch_size=batch_size,
        max_tokens=max_tokens,
        max_batch_tokens=max_batch_tokens,
    )
    records = []
    for task, response in zip(tasks, responses):
        records.append(
            {
                "task_id": task.task_id,
                "track": task.track.value,
                "operation": task.operation.value,
                "response": response,
                "assessment": dict(score_response(task, response)),
            }
        )
    elapsed = time.monotonic() - started
    metrics = aggregate_metrics(condition, tasks, records, elapsed, peak_memory)
    store = ArtifactStore(output_root)
    predictions_digest = store.put("general_cognitive_core_predictions", records)
    payload: Dict[str, Any] = {
        "version": INTERNAL_CORE_VERSION,
        "contract_version": GENERAL_CORE_CONTRACT_VERSION,
        "condition": condition,
        "model_path": model_path,
        "model_type": str(model_config.get("model_type", "")),
        "quantization": dict(model_config.get("quantization", {})),
        "adapter_path": str(adapter_path) if adapter_path is not None else None,
        "adapter_config_sha256": (
            _sha256(adapter_path / "adapter_config.json") if adapter_path is not None else None
        ),
        "adapter_weights_sha256": (
            _sha256(adapter_path / "adapters.safetensors") if adapter_path is not None else None
        ),
        "system_instruction": system_instruction,
        "metrics": metrics.as_dict(),
        "predictions_digest": predictions_digest,
        "generation": {
            "batch_size": batch_size,
            "max_tokens": max_tokens,
            "max_batch_tokens": max_batch_tokens,
        },
        "claim_boundary": (
            "This is a frozen local executable benchmark. It measures transfer within its declared "
            "task grammar and is not evidence of broad naturalistic general intelligence."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest(f"general-cognitive-core-{condition}-{evaluation_id}", manifest)
    return manifest


def compare_internalization(
    baseline: Mapping[str, Any],
    internal: Mapping[str, Any],
    gates: EvaluationGates = EvaluationGates(),
) -> Mapping[str, Any]:
    base = baseline["metrics"]
    candidate = internal["metrics"]
    operation_deltas = {
        operation: candidate["score_by_operation"][operation] - base["score_by_operation"][operation]
        for operation in base["score_by_operation"]
    }
    checks = {
        "candidate_parse_coverage": candidate["parse_coverage"] >= gates.minimum_parse_coverage,
        "minimum_overall_gain": candidate["overall_score"] - base["overall_score"] >= gates.minimum_internal_gain,
        "no_operation_regresses_beyond_tolerance": min(operation_deltas.values()) >= -gates.maximum_family_regression,
        "same_model": baseline["model_path"] == internal["model_path"],
        "adapter_present_only_in_candidate": baseline.get("adapter_path") is None and internal.get("adapter_path") is not None,
    }
    payload = {
        "version": INTERNAL_CORE_VERSION,
        "baseline_evaluation_id": baseline["evaluation_id"],
        "internal_evaluation_id": internal["evaluation_id"],
        "overall_gain": candidate["overall_score"] - base["overall_score"],
        "parse_coverage_gain": candidate["parse_coverage"] - base["parse_coverage"],
        "operation_deltas": operation_deltas,
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates.as_dict(),
    }
    return {**payload, "comparison_id": content_digest(payload)}

