from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest


INVENTION_EVIDENCE_AUDIT_VERSION = (
    "cognitive-core-invention-evidence-audit-v15"
)


class ClaimVerdict(str, Enum):
    SUPPORTED = "supported"
    SUPPORTED_WITH_LIMITS = "supported_with_limits"
    NOT_SUPPORTED = "not_supported"
    NOT_ASSESSED = "not_assessed"


@dataclass(frozen=True)
class EvidenceChainLink:
    phase: int
    name: str
    manifest_version: str
    verification_id: str
    consumes: Tuple[str, ...]
    produces: Tuple[str, ...]
    provenance_class: str
    passed: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "phase": self.phase,
            "name": self.name,
            "manifest_version": self.manifest_version,
            "verification_id": self.verification_id,
            "consumes": list(self.consumes),
            "produces": list(self.produces),
            "provenance_class": self.provenance_class,
            "passed": self.passed,
        }


@dataclass(frozen=True)
class ClaimAssessment:
    claim_key: str
    statement: str
    verdict: ClaimVerdict
    supporting_phase_ids: Tuple[str, ...]
    reasons: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "claim_key": self.claim_key,
            "statement": self.statement,
            "verdict": self.verdict.value,
            "supporting_phase_ids": list(self.supporting_phase_ids),
            "reasons": list(self.reasons),
        }


@dataclass(frozen=True)
class InventionEvidenceAudit:
    chain: Tuple[EvidenceChainLink, ...]
    autonomy_criteria: Mapping[str, bool]
    stage_provenance: Mapping[str, str]
    claims: Tuple[ClaimAssessment, ...]
    integrity_checks: Mapping[str, bool]
    demonstrated_milestone: str
    unresolved_core: str
    required_next_architecture: Tuple[str, ...]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.integrity_checks.values())

    @property
    def audit_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": INVENTION_EVIDENCE_AUDIT_VERSION,
            "chain": [item.as_dict() for item in self.chain],
            "autonomy_criteria": dict(sorted(self.autonomy_criteria.items())),
            "autonomous_invention_demonstrated": all(
                self.autonomy_criteria.values()
            ),
            "stage_provenance": dict(sorted(self.stage_provenance.items())),
            "claims": [item.as_dict() for item in self.claims],
            "integrity_checks": dict(sorted(self.integrity_checks.items())),
            "demonstrated_milestone": self.demonstrated_milestone,
            "unresolved_core": self.unresolved_core,
            "required_next_architecture": list(self.required_next_architecture),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["audit_id"] = self.audit_id
        return value


def build_invention_evidence_audit(
    *,
    manifests: Mapping[int, Mapping[str, Any]],
    artifact_integrity: Mapping[str, bool],
    memory_chain_valid: bool,
    objective_progress: Mapping[str, float | int],
    evidence_progress: Mapping[str, float | int],
    active_campaign_count: int,
    current_candidate_source_digest: str,
) -> InventionEvidenceAudit:
    if set(manifests) != set(range(1, 7)):
        raise ValueError("audit requires exactly Phase 1 through Phase 6 manifests")
    p1, p2, p3, p4, p5, p6 = (manifests[index] for index in range(1, 7))
    chain = (
        EvidenceChainLink(
            1,
            "mechanism-neutral functional contracts",
            p1["manifest_version"],
            p1["verification_id"],
            (p1["architecture_guard_verification_id"],),
            (p1["bundle_id"],),
            "agent_engineered_contracts_control_plane_verified",
            bool(p1["passed"]),
        ),
        EvidenceChainLink(
            2,
            "shared matched baseline",
            p2["manifest_version"],
            p2["verification_id"],
            (p2["functional_contract_verification_id"],),
            (p2["candidate_id"], p2["reconstruction_id"]),
            "agent_engineered_baseline_deterministically_reconstructed",
            bool(p2["passed"]),
        ),
        EvidenceChainLink(
            3,
            "joint functional vertical slice",
            p3["manifest_version"],
            p3["verification_id"],
            (p3["source_phase_two_verification_id"],),
            (p3["registry_id"], p3["experiment_id"]),
            "agent_engineered_evaluator_automatically_executed",
            bool(p3["passed"]),
        ),
        EvidenceChainLink(
            4,
            "contrast-bound causal schema mechanism",
            p4["manifest_version"],
            p4["verification_id"],
            (p4["source_phase_three_verification_id"], p4["dossier_id"]),
            (
                p4["hypothesis_id"],
                p4["preregistration_id"],
                p4["combined_candidate_id"],
            ),
            "agent_invented_domain_specific_mechanism_automatically_ablated",
            bool(p4["passed"]),
        ),
        EvidenceChainLink(
            5,
            "expanded-family conservative adoption",
            p5["manifest_version"],
            p5["verification_id"],
            (p5["source_phase_four_verification_id"],),
            (p5["trial_id"], p5["candidate_freeze"]["freeze_id"]),
            "automatic_evaluation_and_local_independent_verification",
            bool(p5["passed"]),
        ),
        EvidenceChainLink(
            6,
            "long-horizon local replication",
            p6["manifest_version"],
            p6["verification_id"],
            (p6["source_phase_five_verification_id"],),
            (p6["trial_id"], p6["replication_reconstruction_id"]),
            "automatic_execution_disjoint_seed_local_reconstruction",
            bool(p6["passed"]),
        ),
    )
    autonomy = {
        "goal_graph_and_contract_registration_are_automatic_after_definition": True,
        "candidate_outcomes_are_automatically_executed_and_replayed": True,
        "preregistration_and_identity_guards_are_automatically_enforced": True,
        "replication_expectations_are_independently_reconstructed": True,
        "semantic_missing_factor_is_invented_without_a_prewritten_domain_mapping": False,
        "executable_candidate_is_synthesized_by_the_scientist_runtime": False,
        "audit_generator_is_hidden_from_the_architecture_and_candidate_author": False,
        "external_replication_or_confirmation_is_present": False,
    }
    stage_provenance = {
        "research_goal": "user-defined and refined through user observations",
        "goal_graph": "engineered by Codex, then deterministically registered and guarded",
        "shared_baseline": "engineered by Codex and deterministically reconstructed",
        "vertical_slice_generator": "engineered by Codex with a synthetic affine finite-field family",
        "contrast_dossier": "automatically populated, but its semantic contrast descriptions are domain-specific code written by Codex",
        "latent_concept": "invented by Codex diagnostic reasoning and returned by a fixed domain-specific synthesis function",
        "candidate_program": "written by Codex; not synthesized by the autonomous scientist runtime",
        "preregistration_and_evaluation": "automatic and content-addressed",
        "verification": "separate local verifier code, also authored in the same session and codebase",
        "replication": "disjoint seeds and independent expected-action reconstruction, but not external",
    }
    phase_ids = tuple(item.verification_id for item in chain)
    claims = (
        ClaimAssessment(
            "workflow_integrity",
            "The objective-first diagnostic workflow is wired and reproducible end to end.",
            ClaimVerdict.SUPPORTED,
            phase_ids,
            (
                "all six phase manifests passed",
                "content identities form an exact dependency chain",
                "referenced artifacts and the scientific-memory chain verify",
            ),
        ),
        ClaimAssessment(
            "diagnostic_concept_utility",
            "A contrast-derived causal concept produced a selectively validated and replicated improvement in the frozen microdomain.",
            ClaimVerdict.SUPPORTED_WITH_LIMITS,
            (p4["verification_id"], p5["verification_id"], p6["verification_id"]),
            (
                "the two-factor ablation matched every preregistered prediction",
                "the combined candidate survived expanded, reordered, and 32-lag local replication",
                "the concept and candidate were nevertheless authored by Codex in a synthetic domain",
            ),
        ),
        ClaimAssessment(
            "wave_one_microdomain_advance",
            "The frozen candidate beats the registered reference baseline on all four behavioral Wave-1 metrics without violating the cost envelope.",
            ClaimVerdict.SUPPORTED_WITH_LIMITS,
            (p5["verification_id"], p6["verification_id"]),
            (
                "paired audit deltas are positive for procedure, task, relevance, and updating",
                "cost and zero-external-service gates hold",
                "coverage is restricted to symbolic finite-field and directed-graph tasks",
            ),
        ),
        ClaimAssessment(
            "autonomous_hypothesis_invention",
            "The AI-scientist runtime autonomously invented the useful latent concept and executable mechanism.",
            ClaimVerdict.NOT_SUPPORTED,
            (),
            (
                "the semantic dossier mapping and concept synthesis function are fixed domain-specific code",
                "the executable candidate was written by Codex rather than synthesized by the runtime",
                "the implementer had access to the evaluator family and audit-generating code",
            ),
        ),
        ClaimAssessment(
            "general_cognitive_core",
            "The candidate solves the general cognitive-core objective across CS and AI/ML problems.",
            ClaimVerdict.NOT_SUPPORTED,
            (),
            (
                "only five of eighteen work packages were exercised",
                "the objective graph remains at zero integrated objective nodes",
                "no neural, natural-language, software, theorem, or cross-domain transfer task was tested",
            ),
        ),
        ClaimAssessment(
            "scientific_novelty",
            "The causally addressable executable schema is novel relative to the literature.",
            ClaimVerdict.NOT_ASSESSED,
            (),
            (
                "Phase-2 literature established component neighbors before the concept existed",
                "no post-invention novelty or citation-neighborhood review was completed for this exact concept",
            ),
        ),
        ClaimAssessment(
            "breakthrough",
            "This run constitutes a general AI-scientist or cognitive-core breakthrough.",
            ClaimVerdict.NOT_SUPPORTED,
            (),
            (
                "the demonstrated result is a local synthetic mechanism pilot",
                "autonomous invention, external confirmation, and broad task transfer are absent",
            ),
        ),
    )
    integrity_checks = {
        "all_phase_manifests_pass": all(item.passed for item in chain),
        "phase_one_to_two_identity_link_is_exact": (
            p2["functional_contract_verification_id"] == p1["verification_id"]
        ),
        "phase_two_to_three_identity_link_is_exact": (
            p3["source_phase_two_verification_id"] == p2["verification_id"]
        ),
        "phase_three_to_four_identity_link_is_exact": (
            p4["source_phase_three_verification_id"] == p3["verification_id"]
        ),
        "phase_four_to_five_identity_link_is_exact": (
            p5["source_phase_four_verification_id"] == p4["verification_id"]
        ),
        "phase_five_to_six_identity_link_is_exact": (
            p6["source_phase_five_verification_id"] == p5["verification_id"]
        ),
        "candidate_identity_is_stable_from_mechanism_through_replication": (
            p4["combined_candidate_id"]
            == p5["candidate_freeze"]["candidate_id"]
            == p6["candidate_freeze"]["candidate_id"]
            and p4["combined_candidate_executable_digest"]
            == p5["candidate_freeze"]["executable_digest"]
            == p6["candidate_freeze"]["executable_digest"]
        ),
        "current_candidate_source_matches_adoption_and_replication_freeze": (
            current_candidate_source_digest
            == p5["candidate_freeze"]["implementation_source_digest"]
            == p6["candidate_freeze"]["implementation_source_digest"]
        ),
        "every_referenced_content_artifact_passes_integrity": (
            bool(artifact_integrity) and all(artifact_integrity.values())
        ),
        "scientific_memory_chain_is_valid": memory_chain_valid,
        "objective_progress_is_not_inflated": (
            objective_progress["integrated"] == 0
            and objective_progress["total"] == 44
        ),
        "historical_evidence_progress_is_preserved": (
            evidence_progress["integrated"] == 12
            and evidence_progress["total"] == 16
        ),
        "no_unrecorded_campaign_is_active": active_campaign_count == 0,
        "autonomous_invention_claim_is_explicitly_rejected": next(
            item
            for item in claims
            if item.claim_key == "autonomous_hypothesis_invention"
        ).verdict
        == ClaimVerdict.NOT_SUPPORTED,
        "general_breakthrough_claim_is_explicitly_rejected": next(
            item for item in claims if item.claim_key == "breakthrough"
        ).verdict
        == ClaimVerdict.NOT_SUPPORTED,
    }
    return InventionEvidenceAudit(
        chain=chain,
        autonomy_criteria=autonomy,
        stage_provenance=stage_provenance,
        claims=claims,
        integrity_checks=integrity_checks,
        demonstrated_milestone=(
            "A reproducible diagnostic workflow turned a multi-symptom baseline "
            "failure into a causally ablated mechanism that transferred across "
            "expanded synthetic families and 32-step local replication."
        ),
        unresolved_core=(
            "The runtime still does not autonomously invent semantic latent concepts "
            "or synthesize their executable mechanisms from ontology-neutral evidence."
        ),
        required_next_architecture=(
            "replace fixed semantic contrast descriptions with ontology-neutral state/action/outcome contrast records",
            "introduce a pluggable concept proposer that receives only those records and emits multiple falsifiable latent variables",
            "introduce typed program synthesis or learned mechanism compilation from a frozen concept contract",
            "generate the prospective audit family behind a separate post-freeze authority unavailable to proposer and implementer",
            "require transfer to at least two structurally different task domains before any general invention claim",
            "append future proposal, synthesis, exposure, and verification events to the live scientific-memory ledger",
        ),
        limitations=(
            "This audit verifies local artifacts and code paths, not institutional independence.",
            "The absence of external API use made the run cheap and reproducible but did not test frontier-model invention quality.",
            "A passing audit means the evidence boundaries are honest; it does not mean the root cognitive-core goal passed.",
        ),
    )
