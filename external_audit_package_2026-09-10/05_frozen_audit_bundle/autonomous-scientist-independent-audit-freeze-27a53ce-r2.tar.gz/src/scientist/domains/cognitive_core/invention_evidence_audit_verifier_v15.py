from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.invention_evidence_audit_v15 import (
    ClaimVerdict,
    InventionEvidenceAudit,
)
from scientist.program.control_plane import AutonomousScientistControlPlane


INVENTION_EVIDENCE_AUDIT_VERIFIER_REF = (
    "cognitive-core-invention-evidence-independent-verifier-v15"
)


@dataclass(frozen=True)
class InventionEvidenceAuditVerification:
    check_results: Mapping[str, bool]
    audit_id: str
    supported_claim_keys: Tuple[str, ...]
    limited_claim_keys: Tuple[str, ...]
    rejected_claim_keys: Tuple[str, ...]
    unassessed_claim_keys: Tuple[str, ...]
    autonomous_invention_demonstrated: bool
    root_objective_complete: bool
    limitations: Tuple[str, ...]
    verifier_ref: str = INVENTION_EVIDENCE_AUDIT_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "audit_id": self.audit_id,
            "supported_claim_keys": list(self.supported_claim_keys),
            "limited_claim_keys": list(self.limited_claim_keys),
            "rejected_claim_keys": list(self.rejected_claim_keys),
            "unassessed_claim_keys": list(self.unassessed_claim_keys),
            "autonomous_invention_demonstrated": (
                self.autonomous_invention_demonstrated
            ),
            "root_objective_complete": self.root_objective_complete,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_invention_evidence_audit(
    *,
    control: AutonomousScientistControlPlane,
    audit: InventionEvidenceAudit,
    reloaded_audit_value: Mapping[str, Any],
) -> InventionEvidenceAuditVerification:
    by_verdict = {
        verdict: tuple(
            sorted(
                item.claim_key
                for item in audit.claims
                if item.verdict == verdict
            )
        )
        for verdict in ClaimVerdict
    }
    autonomy_false = {
        key for key, value in audit.autonomy_criteria.items() if not value
    }
    progress = control.graph.progress_by_role()
    claim_by_key = {item.claim_key: item for item in audit.claims}
    root_complete = progress["objective"]["integrated"] == progress["objective"]["total"]
    checks = {
        "audit_artifact_round_trip_is_content_exact": (
            reloaded_audit_value == audit.as_dict()
        ),
        "all_six_phases_form_a_passing_ordered_chain": (
            len(audit.chain) == 6
            and tuple(item.phase for item in audit.chain) == (1, 2, 3, 4, 5, 6)
            and all(item.passed for item in audit.chain)
        ),
        "all_audit_integrity_checks_pass": (
            audit.passed and all(audit.integrity_checks.values())
        ),
        "autonomy_failures_cover_semantics_synthesis_blinding_and_externality": (
            autonomy_false
            == {
                "semantic_missing_factor_is_invented_without_a_prewritten_domain_mapping",
                "executable_candidate_is_synthesized_by_the_scientist_runtime",
                "audit_generator_is_hidden_from_the_architecture_and_candidate_author",
                "external_replication_or_confirmation_is_present",
            }
        ),
        "autonomous_invention_is_not_claimed": (
            not all(audit.autonomy_criteria.values())
            and claim_by_key["autonomous_hypothesis_invention"].verdict
            == ClaimVerdict.NOT_SUPPORTED
        ),
        "general_cognitive_core_and_breakthrough_are_not_claimed": (
            claim_by_key["general_cognitive_core"].verdict
            == ClaimVerdict.NOT_SUPPORTED
            and claim_by_key["breakthrough"].verdict
            == ClaimVerdict.NOT_SUPPORTED
        ),
        "literature_novelty_is_left_unassessed": (
            claim_by_key["scientific_novelty"].verdict
            == ClaimVerdict.NOT_ASSESSED
        ),
        "demonstrated_claims_are_bounded_to_workflow_and_microdomain": (
            by_verdict[ClaimVerdict.SUPPORTED] == ("workflow_integrity",)
            and set(by_verdict[ClaimVerdict.SUPPORTED_WITH_LIMITS])
            == {"diagnostic_concept_utility", "wave_one_microdomain_advance"}
        ),
        "next_architecture_targets_actual_autonomy_gap": (
            len(audit.required_next_architecture) >= 6
            and any("ontology-neutral" in item for item in audit.required_next_architecture)
            and any("program synthesis" in item for item in audit.required_next_architecture)
            and any("separate post-freeze authority" in item for item in audit.required_next_architecture)
        ),
        "root_objective_remains_explicitly_unresolved": (
            not root_complete
            and progress["objective"]["integrated"] == 0
            and "still does not autonomously invent" in audit.unresolved_core
        ),
        "live_scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    return InventionEvidenceAuditVerification(
        check_results=checks,
        audit_id=audit.audit_id,
        supported_claim_keys=by_verdict[ClaimVerdict.SUPPORTED],
        limited_claim_keys=by_verdict[ClaimVerdict.SUPPORTED_WITH_LIMITS],
        rejected_claim_keys=by_verdict[ClaimVerdict.NOT_SUPPORTED],
        unassessed_claim_keys=by_verdict[ClaimVerdict.NOT_ASSESSED],
        autonomous_invention_demonstrated=all(audit.autonomy_criteria.values()),
        root_objective_complete=root_complete,
        limitations=(
            "This verification certifies honesty and traceability of the evidence chain, not success of the root scientific objective.",
            "Agent authorship and evaluator visibility prevent an autonomous-invention claim even though automated experimental safeguards passed.",
        ),
    )
