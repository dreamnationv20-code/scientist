from __future__ import annotations

import math
import re
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


ISOLATED_MARGIN_FAILURE_DOSSIER_VERSION = (
    "general-cognitive-isolated-margin-failure-dossier-v52t"
)
M52T_SEED = 53021
M52T_M52S_AUDIT_ID = (
    "ba9b7e46057c9212575c993ff6d738db596740b3bfcae2cc1b4d87e5f9cffdca"
)
M52T_VARIANTS = (
    "canonical",
    "basis_paraphrase",
    "current_paraphrase",
    "dual_paraphrase",
)


def build_factorial_comparisons(
    source_rows: Sequence[Mapping[str, Any]],
    margin_records: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    source = {
        str(row["metadata"]["record_id"]): row for row in source_rows
    }
    if set(source) != {str(row["record_id"]) for row in margin_records}:
        raise ValueError("M52t source and margin-record identities must match")
    relations: dict[
        tuple[str, str, str], dict[str, Mapping[str, Any]]
    ] = {}
    for record in margin_records:
        row = source[str(record["record_id"])]
        metadata = row["metadata"]
        key = (
            str(metadata["family"]),
            str(metadata["basis_state_key"]),
            str(metadata["candidate_state_key"]),
        )
        relations.setdefault(key, {})[str(metadata["variant"])] = {
            "margin": float(record["margin"]),
            "target": str(record["target"]),
            "basis_text": str(metadata["basis_text"]),
            "candidate_text": str(metadata["candidate_text"]),
        }
    groups: dict[tuple[str, str], list[str]] = {}
    for family, basis, candidate in relations:
        groups.setdefault((family, basis), []).append(candidate)
    comparisons = []
    for (family, basis), candidates in sorted(groups.items()):
        candidates = sorted(set(candidates))
        positive = [
            candidate
            for candidate in candidates
            if relations[(family, basis, candidate)]["canonical"]["target"]
            == "YES"
        ]
        negatives = [candidate for candidate in candidates if candidate not in positive]
        if len(positive) != 1 or len(negatives) != 2:
            raise ValueError("M52t requires one positive and two negatives per basis")
        positive_key = positive[0]
        for negative_key in negatives:
            gaps = {}
            texts = {}
            for variant in M52T_VARIANTS:
                positive_relation = relations[(family, basis, positive_key)][variant]
                negative_relation = relations[(family, basis, negative_key)][variant]
                if (
                    positive_relation["basis_text"]
                    != negative_relation["basis_text"]
                ):
                    raise ValueError("M52t comparison basis texts must match")
                gaps[variant] = float(positive_relation["margin"]) - float(
                    negative_relation["margin"]
                )
                texts[variant] = {
                    "basis": positive_relation["basis_text"],
                    "positive": positive_relation["candidate_text"],
                    "negative": negative_relation["candidate_text"],
                }
            comparison_id = "m52t-comparison-" + content_digest(
                {
                    "version": ISOLATED_MARGIN_FAILURE_DOSSIER_VERSION,
                    "family": family,
                    "basis": basis,
                    "positive": positive_key,
                    "negative": negative_key,
                }
            )[:24]
            comparisons.append(
                {
                    "comparison_id": comparison_id,
                    "family": family,
                    "basis_state_key": basis,
                    "positive_candidate_state_key": positive_key,
                    "negative_candidate_state_key": negative_key,
                    "gaps": gaps,
                    "correct": {
                        variant: float(gaps[variant]) > 0.0
                        for variant in M52T_VARIANTS
                    },
                    "texts": texts,
                }
            )
    return tuple(comparisons)


def _transition_metrics(
    comparisons: Sequence[Mapping[str, Any]],
    transitions: Sequence[tuple[str, str]],
) -> Mapping[str, Any]:
    repaired = []
    harmed = []
    unchanged_correct = 0
    unchanged_wrong = 0
    gap_changes = []
    for row in comparisons:
        for source, target in transitions:
            before = bool(row["correct"][source])
            after = bool(row["correct"][target])
            gap_changes.append(float(row["gaps"][target]) - float(row["gaps"][source]))
            transition = {
                "comparison_id": row["comparison_id"],
                "family": row["family"],
                "basis_state_key": row["basis_state_key"],
                "negative_candidate_state_key": row[
                    "negative_candidate_state_key"
                ],
                "source_variant": source,
                "target_variant": target,
                "source_gap": float(row["gaps"][source]),
                "target_gap": float(row["gaps"][target]),
            }
            if not before and after:
                repaired.append(transition)
            elif before and not after:
                harmed.append(transition)
            elif before:
                unchanged_correct += 1
            else:
                unchanged_wrong += 1
    discordant = len(repaired) + len(harmed)
    smaller = min(len(repaired), len(harmed))
    exact_probability = min(
        1.0,
        2.0
        * sum(math.comb(discordant, index) for index in range(smaller + 1))
        / max(2**discordant, 1),
    )
    return {
        "transition_count": len(gap_changes),
        "repaired_count": len(repaired),
        "harmed_count": len(harmed),
        "unchanged_correct_count": unchanged_correct,
        "unchanged_wrong_count": unchanged_wrong,
        "error_repair_rate": len(repaired)
        / max(len(repaired) + unchanged_wrong, 1),
        "mean_gap_change": sum(gap_changes) / max(len(gap_changes), 1),
        "discordant_exact_two_sided_probability": exact_probability,
        "repaired": repaired,
        "harmed": harmed,
    }


_STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "conclusion",
    "current",
    "evidence",
    "for",
    "from",
    "in",
    "is",
    "now",
    "of",
    "on",
    "or",
    "presupposes",
    "state",
    "that",
    "the",
    "this",
    "to",
    "with",
}


def _words(text: str) -> set[str]:
    return {
        word
        for word in re.findall(r"[a-z]+", str(text).lower())
        if word not in _STOPWORDS
    }


def _jaccard(left: str, right: str) -> float:
    left_words = _words(left)
    right_words = _words(right)
    return len(left_words & right_words) / max(len(left_words | right_words), 1)


def lexical_overlap_diagnostic(
    comparisons: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    by_variant = {}
    for variant in M52T_VARIANTS:
        advantages = []
        for row in comparisons:
            texts = row["texts"][variant]
            advantages.append(
                _jaccard(texts["basis"], texts["positive"])
                - _jaccard(texts["basis"], texts["negative"])
            )
        by_variant[variant] = {
            "strict_ranking_accuracy": sum(value > 0.0 for value in advantages)
            / max(len(advantages), 1),
            "tie_rate": sum(value == 0.0 for value in advantages)
            / max(len(advantages), 1),
            "mean_overlap_advantage": sum(advantages)
            / max(len(advantages), 1),
        }
    return {
        "by_variant": by_variant,
        "maximum_strict_ranking_accuracy": max(
            row["strict_ranking_accuracy"] for row in by_variant.values()
        ),
    }


def factorial_dossier(
    comparisons: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    variants = {}
    failures = []
    for variant in M52T_VARIANTS:
        gaps = [float(row["gaps"][variant]) for row in comparisons]
        selected_failures = [
            {
                "comparison_id": row["comparison_id"],
                "family": row["family"],
                "basis_state_key": row["basis_state_key"],
                "negative_candidate_state_key": row[
                    "negative_candidate_state_key"
                ],
                "variant": variant,
                "gap": float(row["gaps"][variant]),
            }
            for row in comparisons
            if not row["correct"][variant]
        ]
        failures.extend(selected_failures)
        variants[variant] = {
            "comparison_count": len(gaps),
            "ranking_accuracy": sum(value > 0.0 for value in gaps)
            / max(len(gaps), 1),
            "mean_gap": sum(gaps) / max(len(gaps), 1),
            "minimum_gap": min(gaps, default=0.0),
            "failure_count": len(selected_failures),
        }
    interactions = [
        float(row["gaps"]["dual_paraphrase"])
        - float(row["gaps"]["basis_paraphrase"])
        - float(row["gaps"]["current_paraphrase"])
        + float(row["gaps"]["canonical"])
        for row in comparisons
    ]
    basis_reexpression = _transition_metrics(
        comparisons,
        (
            ("canonical", "basis_paraphrase"),
            ("current_paraphrase", "dual_paraphrase"),
        ),
    )
    candidate_reexpression = _transition_metrics(
        comparisons,
        (
            ("canonical", "current_paraphrase"),
            ("basis_paraphrase", "dual_paraphrase"),
        ),
    )
    return {
        "comparison_count": len(comparisons),
        "variant_observation_count": len(comparisons) * len(M52T_VARIANTS),
        "variants": variants,
        "failure_count": len(failures),
        "failure_family_count": len({row["family"] for row in failures}),
        "failures": failures,
        "basis_reexpression": basis_reexpression,
        "candidate_reexpression": candidate_reexpression,
        "factorial_interaction": {
            "mean_gap_interaction": sum(interactions)
            / max(len(interactions), 1),
            "positive_interaction_rate": sum(value > 0.0 for value in interactions)
            / max(len(interactions), 1),
            "negative_interaction_rate": sum(value < 0.0 for value in interactions)
            / max(len(interactions), 1),
        },
        "lexical_overlap": lexical_overlap_diagnostic(comparisons),
    }


def diagnosis_gate_passed(
    dossier: Mapping[str, Any], contract: Mapping[str, Any]
) -> tuple[bool, Mapping[str, bool]]:
    basis = dossier["basis_reexpression"]
    lexical = dossier["lexical_overlap"]
    checks = {
        "expected_comparison_count": dossier["comparison_count"]
        == contract["expected_comparison_count"],
        "expected_failure_count": dossier["failure_count"]
        == contract["expected_failure_count"],
        "minimum_failure_family_count": dossier["failure_family_count"]
        >= contract["minimum_failure_family_count"],
        "minimum_basis_reexpression_repair_rate": basis["error_repair_rate"]
        >= contract["minimum_basis_reexpression_repair_rate"],
        "maximum_basis_reexpression_harmed_count": basis["harmed_count"]
        <= contract["maximum_basis_reexpression_harmed_count"],
        "maximum_discordant_exact_probability": basis[
            "discordant_exact_two_sided_probability"
        ]
        <= contract["maximum_discordant_exact_probability"],
        "surface_overlap_is_insufficient": lexical[
            "maximum_strict_ranking_accuracy"
        ]
        <= contract["maximum_surface_overlap_accuracy"],
    }
    return all(checks.values()), checks
