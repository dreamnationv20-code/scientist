from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.gate1_causal_decomposition_v1 import (
    FAMILIES,
    MODEL_CONTRACT,
    GateTask,
    build_tasks,
    score_response,
)


VERSION = "cognitive-core-joint-oracle-gate-v1"
SEED = 552_017
ITEMS_PER_FAMILY = 12
TASK_COUNT = ITEMS_PER_FAMILY * len(FAMILIES)
MAXIMUM_NEW_TOKENS = 768
CONDITIONS = ("qwen3_1p7b:raw", "qwen3_1p7b:joint", "qwen3_8b:raw")


def _after(text: str, marker: str) -> str:
    if marker not in text:
        raise ValueError(f"missing marker {marker!r}")
    return text.split(marker, 1)[1]


def _planning_interface(task: GateTask) -> str:
    state = task.interventions["state"]
    dynamics = task.interventions["dynamics"]
    actions = task.interventions["actions"]
    edges = json.loads(_after(dynamics, ": "))
    answer = str(task.authority["answer"])
    edge = next(edge for edge in edges if edge[2] == answer)
    remaining = len(task.authority["shortest_path"]) - 1
    trace = (
        f"The optimal first successor state is {edge[1]}, and its remaining shortest distance "
        f"to the goal is {remaining}. Recover the enabled operation that maps the current state "
        "to that successor; do not substitute a later operation."
    )
    return "\n".join((state, dynamics, actions, "ORACLE TRACE INTERFACE: " + trace))


def _rule_interface(task: GateTask) -> str:
    positions = json.loads(_after(task.interventions["state"], ": "))
    query = [value for _, value in positions]
    answer = str(task.authority["answer"]).split(",")
    permutation = [query.index(value) for value in answer]
    trace = (
        "The compiled output-to-input position map is "
        + json.dumps(permutation)
        + ". Fill each output slot by copying the glyph at that zero-based input position."
    )
    return "\n".join(
        (
            task.interventions["state"],
            task.interventions["dynamics"],
            task.interventions["actions"],
            "ORACLE TRACE INTERFACE: " + trace,
        )
    )


def _causal_interface(task: GateTask) -> str:
    state_payload = json.loads(_after(task.interventions["state"], ": "))
    query = str(state_payload["query"])
    intermediate = {
        key: value for key, value in task.authority["values"].items() if key != query
    }
    trace = (
        "Correct evaluated non-query registers under the intervention are "
        + json.dumps(intermediate, sort_keys=True)
        + f". Evaluate only {query}'s structural equation from these registers, then map active/inactive to yes/no."
    )
    return "\n".join(
        (
            task.interventions["state"],
            task.interventions["dynamics"],
            task.interventions["actions"],
            "ORACLE TRACE INTERFACE: " + trace,
        )
    )


def _tool_interface(task: GateTask) -> str:
    expected = task.authority["answer"]
    steps = []
    return_types = ("record_key", "permit", "receipt", "done")
    for index, (call, returned) in enumerate(zip(expected, return_types), start=1):
        steps.append(
            {
                "call": index,
                "select_api_by_contract": {
                    "required_return_field": returned,
                    "required_argument_fields": sorted(call["arguments"]),
                },
                "arguments": call["arguments"],
                "api_name": "FILL_FROM_SCHEMA",
            }
        )
    trace = (
        "Instantiate this verified dependency trace by replacing only each API-name slot with the "
        "unique matching schema name; preserve the supplied arguments and references: "
        + json.dumps(steps, sort_keys=True)
    )
    return "\n".join(
        (
            task.interventions["state"],
            task.interventions["dynamics"],
            task.interventions["actions"],
            "ORACLE TRACE INTERFACE: " + trace,
        )
    )


def _evidence_interface(task: GateTask) -> str:
    proof = task.authority["proof"]
    first, second, final = proof
    trace = (
        f"Verified trace prefix: {first[0]} --{first[1]}--> {first[2]} --{second[1]}--> {second[2]}. "
        f"One unresolved step remains: {second[2]} --{final[1]}--> [FILL_FROM_DOSSIER]."
    )
    return "\n".join(
        (
            task.interventions["state"],
            task.interventions["dynamics"],
            task.interventions["actions"],
            "ORACLE TRACE INTERFACE: " + trace,
        )
    )


_INTERFACE_BUILDERS = {
    "obfuscated_planning": _planning_interface,
    "novel_rule_induction": _rule_interface,
    "counterfactual_causal": _causal_interface,
    "stateful_tool_workflow": _tool_interface,
    "evidence_grounding": _evidence_interface,
}


def joint_prompt(task: GateTask) -> str:
    interface = _INTERFACE_BUILDERS[task.family](task)
    return (
        task.raw_prompt
        + "\n\nJOINT ORACLE COMPUTATION INTERFACE (contains no final answer):\n"
        + interface
        + "\nUse the interface as authoritative. Execute its remaining FILL/lookup step and return the requested answer."
    )


def build_joint_rows() -> tuple[tuple[Mapping[str, Any], ...], tuple[Mapping[str, Any], ...]]:
    tasks = build_tasks(seed=SEED, items_per_family=ITEMS_PER_FAMILY)
    public = []
    authority = []
    for task in tasks:
        prompts = {"raw": task.raw_prompt, "joint": joint_prompt(task)}
        row = {
            "task_id": task.task_id,
            "family": task.family,
            "prompts": prompts,
            "maximum_new_tokens": MAXIMUM_NEW_TOKENS,
        }
        public.append(row)
        authority.append({**row, "authority": dict(task.authority)})
    return tuple(public), tuple(authority)


def _jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _read_rows(path: Path) -> list[Mapping[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _write_immutable(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite frozen joint-oracle artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")


def prepare_benchmark(project: Path, output: Path) -> Mapping[str, Any]:
    public, authority = build_joint_rows()
    public_payload = _jsonl(public)
    authority_payload = _jsonl(authority)
    prior_path = project / "data/cognitive_core/gate1_causal_decomposition_v3/tasks-public.jsonl"
    prior_raw_hashes = {
        hashlib.sha256(str(row["prompts"]["raw"]).encode()).hexdigest()
        for row in _read_rows(prior_path)
    }
    new_raw_hashes = {
        hashlib.sha256(str(row["prompts"]["raw"]).encode()).hexdigest() for row in public
    }
    body = {
        "version": VERSION,
        "question": (
            "Can a complete typed computation interface with correct intermediate structure, but "
            "without the final answer, make Qwen3-1.7B approach Qwen3-8B across held-out families?"
        ),
        "seed": SEED,
        "families": list(FAMILIES),
        "items_per_family": ITEMS_PER_FAMILY,
        "task_count": TASK_COUNT,
        "conditions": list(CONDITIONS),
        "model_contract": [
            row for row in MODEL_CONTRACT if row["key"] in {"qwen3_1p7b", "qwen3_8b"}
        ],
        "inference_contract": {
            "temperature": 0.0,
            "enable_thinking": False,
            "maximum_new_tokens": MAXIMUM_NEW_TOKENS,
            "same_decoding_for_all_conditions": True,
            "terminal_final_line_stop": True,
        },
        "oracle_contract": {
            "joint_components": [
                "typed parsed state",
                "executable dynamics/operator rule",
                "legal action/output structure",
                "correct intermediate trace with final lookup or fill withheld",
            ],
            "final_answer_explicitly_withheld": True,
            "diagnostic_only_not_deployable_scaffolding": True,
            "no_training": True,
        },
        "gates_all_required": {
            "minimum_families_closing_half_gap": 3,
            "minimum_absolute_family_gain": 0.15,
            "stateful_tool_minimum_accuracy": 0.50,
            "stateful_tool_minimum_gain": 0.25,
            "maximum_joint_macro_gap_to_8b": 0.10,
        },
        "decision_rule": (
            "Continue only if all gates pass, including dependent tool use. On failure, stop the "
            "current 1.7B-plus-cognitive-core approximately 70B thesis; do not create another mechanism milestone."
        ),
        "claim_boundary": (
            "This 60-task synthetic held-out gate is a terminal causal feasibility test, not a "
            "publication result or evidence of 70B parity. Passing only licenses one learned internal "
            "task-compiler/executor experiment; failing terminates the current thesis."
        ),
        "zero_raw_prompt_overlap_with_gate1_v3": not bool(prior_raw_hashes & new_raw_hashes),
        "public_tasks_sha256": hashlib.sha256(public_payload.encode()).hexdigest(),
        "authority_tasks_sha256": hashlib.sha256(authority_payload.encode()).hexdigest(),
    }
    freeze = {**body, "freeze_id": content_digest(body)}
    _write_immutable(output / "tasks-public.jsonl", public_payload)
    _write_immutable(output / "tasks-authority.jsonl", authority_payload)
    _write_immutable(output / "protocol-freeze.json", json.dumps(freeze, indent=2, sort_keys=True) + "\n")
    verification = verify_benchmark(project, output)
    _write_immutable(
        output / "protocol-verification.json",
        json.dumps(verification, indent=2, sort_keys=True) + "\n",
    )
    return freeze


def verify_benchmark(project: Path, output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "protocol-freeze.json").read_text(encoding="utf-8"))
    public_path = output / "tasks-public.jsonl"
    authority_path = output / "tasks-authority.jsonl"
    public = _read_rows(public_path)
    authority = _read_rows(authority_path)
    regenerated_public, regenerated_authority = build_joint_rows()
    checks = {
        "freeze_content_derived": content_digest(
            {key: value for key, value in freeze.items() if key != "freeze_id"}
        )
        == freeze["freeze_id"],
        "public_hash_matches": hashlib.sha256(public_path.read_bytes()).hexdigest()
        == freeze["public_tasks_sha256"],
        "authority_hash_matches": hashlib.sha256(authority_path.read_bytes()).hexdigest()
        == freeze["authority_tasks_sha256"],
        "deterministic_regeneration": _jsonl(regenerated_public)
        == public_path.read_text(encoding="utf-8")
        and _jsonl(regenerated_authority) == authority_path.read_text(encoding="utf-8"),
        "balanced_fresh_panel": len(public) == TASK_COUNT
        and all(sum(row["family"] == family for row in public) == ITEMS_PER_FAMILY for family in FAMILIES)
        and freeze["zero_raw_prompt_overlap_with_gate1_v3"],
        "joint_interface_present": all(
            "ORACLE TRACE INTERFACE:" in row["prompts"]["joint"] for row in public
        ),
        "no_explicit_final_answer_in_joint_addition": all(
            f"FINAL: {row['authority']['answer']}" not in row["prompts"]["joint"]
            for row in authority
        ),
        "authority_absent_from_public": all("authority" not in row for row in public),
        "all_authority_answers_self_score": all(
            score_response(
                row["family"],
                row["authority"],
                "FINAL: "
                + (
                    json.dumps(row["authority"]["answer"], separators=(",", ":"))
                    if row["family"] == "stateful_tool_workflow"
                    else str(row["authority"]["answer"])
                ),
            )["correct"]
            for row in authority
        ),
        "hard_stop_rule_frozen": "stop the current" in freeze["decision_rule"],
    }
    return {"version": VERSION, "freeze_id": freeze["freeze_id"], "checks": checks, "passed": all(checks.values())}


def _wilson(correct: int, count: int) -> list[float]:
    if not count:
        return [0.0, 0.0]
    z = 1.959963984540054
    p = correct / count
    denominator = 1 + z * z / count
    center = (p + z * z / (2 * count)) / denominator
    radius = z * math.sqrt(p * (1 - p) / count + z * z / (4 * count * count)) / denominator
    return [max(0.0, center - radius), min(1.0, center + radius)]


def summarize(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    by_family = {}
    for family in FAMILIES:
        rows = [row for row in records if row["family"] == family]
        correct = sum(bool(row["score"]["correct"]) for row in rows)
        by_family[family] = {
            "count": len(rows),
            "correct": correct,
            "accuracy": correct / len(rows) if rows else None,
            "wilson_95": _wilson(correct, len(rows)),
            "parse_rate": sum(bool(row["score"]["parsed"]) for row in rows) / len(rows) if rows else None,
        }
    correct = sum(bool(row["score"]["correct"]) for row in records)
    return {
        "count": len(records),
        "correct": correct,
        "macro_accuracy": sum(row["accuracy"] for row in by_family.values() if row["accuracy"] is not None)
        / sum(row["accuracy"] is not None for row in by_family.values())
        if records
        else None,
        "by_family": by_family,
    }


def analyze(records_by_condition: Mapping[str, Sequence[Mapping[str, Any]]]) -> Mapping[str, Any]:
    summaries = {key: summarize(rows) for key, rows in records_by_condition.items()}
    complete = all(len(records_by_condition.get(key, ())) == TASK_COUNT for key in CONDITIONS)
    if not complete:
        return {
            "complete": False,
            "completed_conditions": sorted(
                key for key in CONDITIONS if len(records_by_condition.get(key, ())) == TASK_COUNT
            ),
            "summaries": summaries,
            "decision": "await_complete_frozen_conditions",
        }
    raw = summaries["qwen3_1p7b:raw"]
    joint = summaries["qwen3_1p7b:joint"]
    reference = summaries["qwen3_8b:raw"]
    family_effects = {}
    passing = []
    for family in FAMILIES:
        raw_accuracy = raw["by_family"][family]["accuracy"]
        joint_accuracy = joint["by_family"][family]["accuracy"]
        reference_accuracy = reference["by_family"][family]["accuracy"]
        gap = max(0.0, reference_accuracy - raw_accuracy)
        gain = joint_accuracy - raw_accuracy
        fraction = gain / gap if gap > 0 else (1.0 if gain >= 0 else None)
        passed = gain >= 0.15 and fraction is not None and fraction >= 0.5
        if passed:
            passing.append(family)
        family_effects[family] = {
            "raw_1p7b": raw_accuracy,
            "joint_1p7b": joint_accuracy,
            "raw_8b": reference_accuracy,
            "absolute_gain": gain,
            "scaling_gap": gap,
            "gap_fraction_closed": fraction,
            "family_gate_passed": passed,
        }
    tool = family_effects["stateful_tool_workflow"]
    gates = {
        "three_families_close_half_gap": len(passing) >= 3,
        "stateful_tool_repair": tool["joint_1p7b"] >= 0.50 and tool["absolute_gain"] >= 0.25,
        # Scores are rational task counts, but their Python float encodings need
        # not preserve an equality exactly (for example, 0.4666... - 0.3666...
        # can be infinitesimally greater than 0.10).  Equality is explicitly
        # admitted by the frozen "maximum gap" contract.
        "joint_macro_within_ten_points_of_8b": joint["macro_accuracy"] + 1e-12
        >= reference["macro_accuracy"] - 0.10,
    }
    passed = all(gates.values())
    return {
        "complete": True,
        "summaries": summaries,
        "family_effects": family_effects,
        "passing_families": passing,
        "gates": gates,
        "passed": passed,
        "decision": (
            "license_one_internal_task_compiler_executor_experiment"
            if passed
            else "stop_current_cognitive_core_thesis"
        ),
    }
