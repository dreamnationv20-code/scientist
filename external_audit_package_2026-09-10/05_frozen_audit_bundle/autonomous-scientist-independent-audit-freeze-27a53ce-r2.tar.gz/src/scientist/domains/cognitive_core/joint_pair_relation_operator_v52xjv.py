from __future__ import annotations

from itertools import product
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.cross_channel_binding_v52x import (
    binding_metrics,
    descriptor_direction,
)
from scientist.domains.cognitive_core.independent_paraphrase_orbits_v52v import (
    semantic_relation_prompt,
)
from scientist.domains.cognitive_core.reciprocal_role_alignment_v52xd import (
    M52XD_TRAINED_DIRECTIONS,
)
from scientist.domains.cognitive_core.representation_atlas_v52w import (
    relation_margin_records,
)


JOINT_PAIR_RELATION_OPERATOR_VERSION = (
    "general-cognitive-joint-pair-relation-operator-v52xjv"
)
M52XJV_SEED = 53321
M52XJV_M52XJU_AUDIT_ID = (
    "cdefa12732e2e0df1649b5b172a005d046f4805a5ccbe33d6201b0342843a862"
)
M52XJV_STYLE_COUNT = 2
M52XJV_FORMULATION_SPLIT = {
    "internal_a": "discovery",
    "internal_b": "discovery",
    "development_a": "development",
    "development_b": "development",
    "sealed_a": "sealed",
    "sealed_b": "sealed",
}


_FRAME = {
    "internal_a": "joint relation trial",
    "internal_b": "pairwise equivalence audit",
    "development_a": "unseen concept comparison",
    "development_b": "novel family equivalence review",
    "sealed_a": "quarantined pair judgment",
    "sealed_b": "independent equivalence confirmation",
}
_NOUN = {
    "name": "algorithm designation",
    "principle": "decision semantics",
    "action": "runtime effect",
}
_PREFIX = {
    "internal_a": "joint_relation",
    "internal_b": "pair_equivalence",
    "development_a": "unseen_concept",
    "development_b": "novel_equivalence",
    "sealed_a": "quarantined_pair",
    "sealed_b": "independent_equivalence",
}


def joint_pair_text(
    state: Mapping[str, str],
    channel: str,
    role: str,
    formulation: str,
    style: int,
) -> str:
    if formulation not in M52XJV_FORMULATION_SPLIT:
        raise ValueError(f"unknown M52xj-V formulation: {formulation}")
    if channel not in _NOUN or role not in {"basis", "candidate"}:
        raise ValueError(f"unknown M52xj-V channel/role: {channel}/{role}")
    if not 0 <= int(style) < M52XJV_STYLE_COUNT:
        raise ValueError(f"unknown M52xj-V style: {style}")
    frame = _FRAME[formulation]
    noun = _NOUN[channel]
    value = str(state[channel])
    basis = (
        "In the {frame}, the reference supplies this {noun}: {value}",
        "Judge the {frame} from the following reference {noun}: {value}",
    )
    candidate = (
        "In the {frame}, the candidate supplies this {noun}: {value}",
        "Judge the {frame} against the following candidate {noun}: {value}",
    )
    return (basis if role == "basis" else candidate)[int(style)].format(
        frame=frame, noun=noun, value=value
    )


def build_joint_pair_rows(
    ledger: Mapping[str, Any], formulation: str
) -> Tuple[Mapping[str, Any], ...]:
    if formulation not in M52XJV_FORMULATION_SPLIT:
        raise ValueError("unknown M52xj-V formulation")
    semantic_split = M52XJV_FORMULATION_SPLIT[formulation]
    rows = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != semantic_split:
            continue
        states = tuple(family_value["states"])
        if len(states) != 4:
            raise ValueError("M52xj-V requires four states per family")
        for direction in M52XD_TRAINED_DIRECTIONS:
            basis_channel, candidate_channel = direction.split("->")
            for basis_style, candidate_style in product(
                range(M52XJV_STYLE_COUNT), repeat=2
            ):
                for basis_state in states:
                    orbit = content_digest(
                        {
                            "milestone": "M52xj-V",
                            "formulation": formulation,
                            "family": family,
                            "direction": direction,
                            "basis_style": basis_style,
                            "candidate_style": candidate_style,
                            "basis_state": basis_state["key"],
                        }
                    )
                    basis_text = joint_pair_text(
                        basis_state,
                        basis_channel,
                        "basis",
                        formulation,
                        basis_style,
                    )
                    for candidate_state in states:
                        candidate_text = joint_pair_text(
                            candidate_state,
                            candidate_channel,
                            "candidate",
                            formulation,
                            candidate_style,
                        )
                        prefix = _PREFIX[formulation]
                        metadata = {
                            "record_id": content_digest(
                                {
                                    "orbit": orbit,
                                    "candidate_state": candidate_state["key"],
                                }
                            ),
                            "orbit_id": orbit,
                            "family": str(family),
                            "semantic_split": semantic_split,
                            "formulation_split": formulation,
                            "basis_style": int(basis_style),
                            "candidate_style": int(candidate_style),
                            "basis_state_key": str(basis_state["key"]),
                            "candidate_state_key": str(candidate_state["key"]),
                            "basis_transformation": (
                                f"{prefix}_{basis_channel}_{basis_style}"
                            ),
                            "basis_transformation_split": "m52xjv_joint_pair",
                            "candidate_transformation": (
                                f"{prefix}_{candidate_channel}_{candidate_style}"
                            ),
                            "candidate_transformation_split": "m52xjv_joint_pair",
                            "basis_text": basis_text,
                            "candidate_text": candidate_text,
                            "relation_target": (
                                "YES"
                                if str(basis_state["key"])
                                == str(candidate_state["key"])
                                else "NO"
                            ),
                        }
                        row = {
                            "prompt": semantic_relation_prompt(
                                basis_text, candidate_text
                            ),
                            "metadata": metadata,
                        }
                        if descriptor_direction(row) != direction:
                            raise ValueError("M52xj-V direction routing is inconsistent")
                        rows.append(row)
    return tuple(rows)


def build_pair_relation_episodes(
    family_episodes: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    """Turn item views into labelled joint-pair examples.

    Cross-family supervision compares relation labels only. It never asserts that a
    state or item in one family corresponds to any state or item in another family.
    """
    episodes = []
    for source in family_episodes:
        left_channel, right_channel = str(source["edge"]).split("<->")
        direction_fields = (
            (
                f"{left_channel}->{right_channel}",
                "left_basis_text",
                "right_candidate_text",
            ),
            (
                f"{right_channel}->{left_channel}",
                "right_basis_text",
                "left_candidate_text",
            ),
            (
                f"{left_channel}->{left_channel}",
                "left_basis_text",
                "left_candidate_text",
            ),
            (
                f"{right_channel}->{right_channel}",
                "right_basis_text",
                "right_candidate_text",
            ),
        )
        views = []
        for view in source["views"]:
            examples = []
            states = tuple(view["states"])
            for direction, basis_key, candidate_key in direction_fields:
                for basis_index, basis_state in enumerate(states):
                    basis_text = str(basis_state[basis_key])
                    for candidate_index, candidate_state in enumerate(states):
                        candidate_text = str(candidate_state[candidate_key])
                        target = "YES" if basis_index == candidate_index else "NO"
                        examples.append(
                            {
                                "example_id": content_digest(
                                    {
                                        "episode": source["episode_id"],
                                        "family": view["family"],
                                        "direction": direction,
                                        "basis": basis_state["state_key"],
                                        "candidate": candidate_state["state_key"],
                                    }
                                ),
                                "family": str(view["family"]),
                                "direction": direction,
                                "basis_state_key": str(basis_state["state_key"]),
                                "candidate_state_key": str(
                                    candidate_state["state_key"]
                                ),
                                "relation_target": target,
                                "prompt": semantic_relation_prompt(
                                    basis_text, candidate_text
                                ),
                            }
                        )
            if len(examples) != 64:
                raise ValueError("each M52xj-V family view requires 64 joint pairs")
            views.append(
                {
                    "family": str(view["family"]),
                    "context": str(view["context"]),
                    "examples": examples,
                }
            )
        episodes.append(
            {
                "episode_id": str(source["episode_id"]),
                "families": list(source["families"]),
                "semantic_split": "discovery",
                "views": views,
            }
        )
    if len(episodes) != 90 or not all(len(row["views"]) == 2 for row in episodes):
        raise ValueError("M52xj-V requires 90 two-family joint-pair episodes")
    return tuple(episodes)


def leave_one_family_out_pair_episodes(
    episodes: Sequence[Mapping[str, Any]], held_family: str
) -> Tuple[Mapping[str, Any], ...]:
    selected = tuple(
        episode
        for episode in episodes
        if str(held_family) not in {str(value) for value in episode["families"]}
    )
    if len(selected) != 60:
        raise ValueError("each M52xj-V fold requires 60 five-family episodes")
    return selected


def evaluate_joint_output_ensemble(
    rows: Sequence[Mapping[str, Any]],
    margins: Sequence[float],
    gate: Mapping[str, float],
) -> Mapping[str, Any]:
    records = relation_margin_records(rows, margins)
    metrics = binding_metrics(records)
    checks = {
        "minimum_absolute_balanced_accuracy": float(
            metrics["absolute"]["balanced_accuracy"]
        )
        >= float(gate["minimum_absolute_balanced_accuracy"]),
        "minimum_ranking_accuracy": float(metrics["ranking"]["ranking_accuracy"])
        >= float(gate["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(metrics["ranking"]["top1_accuracy"])
        >= float(gate["minimum_top1_accuracy"]),
        "minimum_each_direction_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in metrics["by_direction"].values()
        )
        >= float(gate["minimum_each_direction_ranking_accuracy"]),
        "minimum_each_family_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in metrics["by_family"].values()
        )
        >= float(gate["minimum_each_family_ranking_accuracy"]),
        "minimum_each_family_balanced_accuracy": min(
            float(value["absolute"]["balanced_accuracy"])
            for value in metrics["by_family"].values()
        )
        >= float(gate["minimum_each_family_balanced_accuracy"]),
    }
    return {
        "relation_records": list(records),
        "metrics": metrics,
        "checks": checks,
        "passed": all(checks.values()),
    }


def summarize_joint_output_panel(
    ensembles: Mapping[str, Mapping[str, Any]],
) -> Mapping[str, Any]:
    if len(ensembles) < 2:
        raise ValueError("M52xj-V panels require two formulations")
    return {
        "ensemble_names": list(ensembles),
        "all_ensembles_passed": all(bool(value["passed"]) for value in ensembles.values()),
        "minimum_family_balanced_accuracy": min(
            float(family["absolute"]["balanced_accuracy"])
            for value in ensembles.values()
            for family in value["metrics"]["by_family"].values()
        ),
        "minimum_overall_balanced_accuracy": min(
            float(value["metrics"]["absolute"]["balanced_accuracy"])
            for value in ensembles.values()
        ),
        "minimum_ranking_accuracy": min(
            float(value["metrics"]["ranking"]["ranking_accuracy"])
            for value in ensembles.values()
        ),
        "minimum_top1_accuracy": min(
            float(value["metrics"]["ranking"]["top1_accuracy"])
            for value in ensembles.values()
        ),
        "minimum_each_direction_ranking_accuracy": min(
            float(direction["ranking"]["ranking_accuracy"])
            for value in ensembles.values()
            for direction in value["metrics"]["by_direction"].values()
        ),
    }


def pair_relation_fold_gate_passed(
    candidate: Mapping[str, Any],
    baseline: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "all_internal_formulations_pass": bool(candidate["all_ensembles_passed"]),
        "minimum_worst_family_improvement": float(
            candidate["minimum_family_balanced_accuracy"]
        )
        - float(baseline["minimum_family_balanced_accuracy"])
        >= float(contract["minimum_worst_family_improvement"]),
        "maximum_overall_regression": float(
            candidate["minimum_overall_balanced_accuracy"]
        )
        - float(baseline["minimum_overall_balanced_accuracy"])
        >= -float(contract["maximum_overall_regression"]),
        "minimum_ranking_accuracy": float(candidate["minimum_ranking_accuracy"])
        >= float(contract["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(candidate["minimum_top1_accuracy"])
        >= float(contract["minimum_top1_accuracy"]),
        "minimum_each_direction_ranking_accuracy": float(
            candidate["minimum_each_direction_ranking_accuracy"]
        )
        >= float(contract["minimum_each_direction_ranking_accuracy"]),
        "output_preservation": bool(candidate["output_preservation_passed"]),
    }
    return all(checks.values()), checks


def summarize_pair_relation_lofo(
    folds: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    if len(folds) != 6 or len({row["held_family"] for row in folds}) != 6:
        raise ValueError("M52xj-V requires all six independent folds")
    return {
        "fold_count": 6,
        "passed_fold_count": sum(bool(row["passed"]) for row in folds),
        "minimum_family_balanced_accuracy": min(
            float(row["panel_summary"]["minimum_family_balanced_accuracy"])
            for row in folds
        ),
        "minimum_ranking_accuracy": min(
            float(row["panel_summary"]["minimum_ranking_accuracy"])
            for row in folds
        ),
        "minimum_top1_accuracy": min(
            float(row["panel_summary"]["minimum_top1_accuracy"])
            for row in folds
        ),
        "passed": all(bool(row["passed"]) for row in folds),
    }


def select_earliest_pair_relation_pass(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    passing = [row for row in candidates if bool(row["passed"])]
    return min(passing, key=lambda row: int(row["iteration"])) if passing else None


def pair_relation_development_gate_passed(
    candidate: Mapping[str, Any],
    incumbent: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "all_development_formulations_pass": bool(candidate["all_ensembles_passed"]),
        "minimum_worst_family_improvement": float(
            candidate["minimum_family_balanced_accuracy"]
        )
        - float(incumbent["minimum_family_balanced_accuracy"])
        >= float(contract["minimum_worst_family_improvement"]),
        "maximum_overall_regression": float(
            candidate["minimum_overall_balanced_accuracy"]
        )
        - float(incumbent["minimum_overall_balanced_accuracy"])
        >= -float(contract["maximum_overall_regression"]),
        "minimum_ranking_accuracy": float(candidate["minimum_ranking_accuracy"])
        >= float(contract["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(candidate["minimum_top1_accuracy"])
        >= float(contract["minimum_top1_accuracy"]),
        "minimum_each_direction_ranking_accuracy": float(
            candidate["minimum_each_direction_ranking_accuracy"]
        )
        >= float(contract["minimum_each_direction_ranking_accuracy"]),
        "output_preservation": bool(candidate["output_preservation_passed"]),
    }
    return all(checks.values()), checks


def pair_relation_confirmation_gate_passed(
    candidate: Mapping[str, Any],
    incumbent: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "all_sealed_formulations_pass": bool(candidate["all_ensembles_passed"]),
        "maximum_worst_family_regression": float(
            candidate["minimum_family_balanced_accuracy"]
        )
        - float(incumbent["minimum_family_balanced_accuracy"])
        >= -float(contract["maximum_worst_family_regression"]),
        "maximum_overall_regression": float(
            candidate["minimum_overall_balanced_accuracy"]
        )
        - float(incumbent["minimum_overall_balanced_accuracy"])
        >= -float(contract["maximum_overall_regression"]),
        "minimum_ranking_accuracy": float(candidate["minimum_ranking_accuracy"])
        >= float(contract["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(candidate["minimum_top1_accuracy"])
        >= float(contract["minimum_top1_accuracy"]),
    }
    return all(checks.values()), checks


__all__ = (
    "JOINT_PAIR_RELATION_OPERATOR_VERSION",
    "M52XJV_FORMULATION_SPLIT",
    "M52XJV_M52XJU_AUDIT_ID",
    "M52XJV_SEED",
    "M52XJV_STYLE_COUNT",
    "build_joint_pair_rows",
    "build_pair_relation_episodes",
    "evaluate_joint_output_ensemble",
    "joint_pair_text",
    "leave_one_family_out_pair_episodes",
    "pair_relation_confirmation_gate_passed",
    "pair_relation_development_gate_passed",
    "pair_relation_fold_gate_passed",
    "select_earliest_pair_relation_pass",
    "summarize_joint_output_panel",
    "summarize_pair_relation_lofo",
)
