from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_MODEL_SNAPSHOT,
)
from scientist.domains.cognitive_core.latent_state_validity_v52g import _state
from scientist.domains.cognitive_core.reference_normalization_v52k import (
    M52K_FAMILIES_BY_SPLIT,
    _family as _m52k_family,
)
from scientist.domains.cognitive_core.semantic_relation_competence_v52i import (
    M52I_VARIANTS,
)


JOINT_RELATIONAL_COMPARATOR_VERSION = (
    "general-cognitive-joint-relational-comparator-v52l"
)
M52L_SEED = 52931
M52L_SPLITS = ("train", "development", "validation", "confirmation")
M52L_M52K_AUDIT_ID = (
    "f486a4c60389a3f540f4a7eb4234d66194c7c4e560350af3cdcb37044c8e6057"
)


M52L_NEW_FAMILIES: Mapping[str, Tuple[Mapping[str, str], ...]] = {
    "synchronization_mechanism": (
        _state(
            "mutex",
            "Concurrent access must now be serialized by one mutually exclusive lock.",
            "Only one thread can own the lock and enter the protected critical section.",
            "The conclusion presupposes mutex-based mutual exclusion.",
            "This evidence assumes a single-owner lock serializes the critical section.",
        ),
        _state(
            "counting_semaphore",
            "Concurrency must now be bounded by a counter of available permits.",
            "Several threads may proceed until all semaphore permits are consumed.",
            "The conclusion presupposes counting-semaphore synchronization.",
            "This evidence assumes a permit counter bounds simultaneous access.",
        ),
        _state(
            "reader_writer_lock",
            "Concurrent readers may now share access while writers require exclusivity.",
            "The lock admits multiple readers or one writer, but never both together.",
            "The conclusion presupposes reader-writer locking.",
            "This evidence assumes shared read ownership and exclusive write ownership.",
        ),
        _state(
            "lock_free_cas",
            "Coordination must now make progress through atomic compare-and-swap retries.",
            "Threads update shared state without mutual-exclusion ownership by retrying failed CAS operations.",
            "The conclusion presupposes lock-free compare-and-swap synchronization.",
            "This evidence assumes atomic CAS retries replace lock ownership.",
        ),
    ),
    "partition_placement": (
        _state(
            "hash_partitioning",
            "Records must now be assigned to partitions by hashing their partition key.",
            "A deterministic hash maps each key into one shard bucket.",
            "The conclusion presupposes hash-based data partitioning.",
            "This evidence assumes a key hash selects the destination shard.",
        ),
        _state(
            "range_partitioning",
            "Records must now be assigned according to ordered key intervals.",
            "Each shard owns a contiguous range of the partition-key space.",
            "The conclusion presupposes range-based data partitioning.",
            "This evidence assumes contiguous key intervals determine shard placement.",
        ),
        _state(
            "round_robin_partitioning",
            "Records must now be distributed cyclically across partitions independent of key value.",
            "Successive records rotate through the available shard identifiers.",
            "The conclusion presupposes round-robin data partitioning.",
            "This evidence assumes cyclic arrival order, rather than record keys, selects shards.",
        ),
        _state(
            "directory_partitioning",
            "Record placement must now be resolved through an explicit lookup directory.",
            "A maintained mapping table identifies the shard responsible for each key or group.",
            "The conclusion presupposes directory-based data partitioning.",
            "This evidence assumes an explicit placement directory selects each shard.",
        ),
    ),
    "replication_topology": (
        _state(
            "single_leader",
            "All writes must now pass through one leader and then replicate to followers.",
            "One primary orders updates before replicas apply its log.",
            "The conclusion presupposes single-leader replication.",
            "This evidence assumes one primary orders writes for follower replicas.",
        ),
        _state(
            "multi_leader",
            "Several leaders may now accept writes and reconcile their replicated updates.",
            "Independent primaries ingest updates that are later exchanged and conflict-resolved.",
            "The conclusion presupposes multi-leader replication.",
            "This evidence assumes multiple writable primaries reconcile concurrent updates.",
        ),
        _state(
            "leaderless_quorum",
            "Clients must now read and write replica quorums without a distinguished leader.",
            "Operations contact multiple equivalent replicas and use quorum overlap for consistency.",
            "The conclusion presupposes leaderless quorum replication.",
            "This evidence assumes clients coordinate overlapping replica quorums directly.",
        ),
        _state(
            "chain_replication",
            "Writes must now traverse an ordered replica chain while reads are served from its tail.",
            "Updates flow from chain head through intermediate replicas to the committed tail.",
            "The conclusion presupposes chain replication.",
            "This evidence assumes ordered head-to-tail update propagation.",
        ),
    ),
    "execution_engine": (
        _state(
            "direct_interpretation",
            "Programs must now execute by directly interpreting source-level operations at runtime.",
            "The engine repeatedly decodes and performs program constructs without prior native compilation.",
            "The conclusion presupposes direct interpretation.",
            "This evidence assumes runtime interpretation executes source-level constructs directly.",
        ),
        _state(
            "bytecode_vm",
            "Programs must now compile to portable bytecode executed by a virtual machine.",
            "A VM dispatch loop interprets intermediate bytecode instructions.",
            "The conclusion presupposes bytecode virtual-machine execution.",
            "This evidence assumes portable intermediate instructions run inside a VM.",
        ),
        _state(
            "ahead_of_time",
            "Programs must now compile to native code before deployment and execution.",
            "The complete executable is generated in advance rather than during its workload.",
            "The conclusion presupposes ahead-of-time native compilation.",
            "This evidence assumes native machine code is produced before runtime.",
        ),
        _state(
            "just_in_time",
            "Programs must now compile hot operations to native code during execution.",
            "Runtime profiling triggers dynamic compilation and optimization of frequently used paths.",
            "The conclusion presupposes just-in-time compilation.",
            "This evidence assumes runtime profiles guide dynamic native compilation.",
        ),
    ),
}


M52L_FAMILIES_BY_SPLIT = {
    "train": tuple(M52K_FAMILIES_BY_SPLIT["development"]),
    "development": tuple(M52K_FAMILIES_BY_SPLIT["validation"]),
    "validation": ("synchronization_mechanism", "partition_placement"),
    "confirmation": ("replication_topology", "execution_engine"),
}


def _family(name: str) -> Tuple[Mapping[str, str], ...]:
    if name in M52L_NEW_FAMILIES:
        return M52L_NEW_FAMILIES[name]
    return _m52k_family(name)


def joint_comparator_prompt(basis: str, candidate_a: str, candidate_b: str) -> str:
    return (
        "A research conclusion assumes this operating condition:\n"
        f"{basis}\n\n"
        "Current candidate A:\n"
        f"{candidate_a}\n\n"
        "Current candidate B:\n"
        f"{candidate_b}\n\n"
        "Which current candidate preserves the causal operating condition required by the "
        "conclusion? Answer with exactly A or B."
    )


@lru_cache(maxsize=None)
def build_m52l_rows(split: str) -> Tuple[Mapping[str, Any], ...]:
    if split not in M52L_SPLITS:
        raise ValueError(f"unknown M52l split: {split}")
    rows = []
    for family_name in M52L_FAMILIES_BY_SPLIT[split]:
        states = _family(family_name)
        for state_index, state in enumerate(states):
            negative_state = states[(state_index + 1) % len(states)]
            semantic_group_id = "m52l-semantic-" + content_digest(
                {
                    "split": split,
                    "family": family_name,
                    "positive": state["key"],
                    "negative": negative_state["key"],
                    "version": JOINT_RELATIONAL_COMPARATOR_VERSION,
                }
            )[:24]
            for variant in M52I_VARIANTS:
                basis = (
                    str(state["basis_paraphrase"])
                    if variant in ("basis_paraphrase", "dual_paraphrase")
                    else str(state["basis"])
                )
                positive = (
                    str(state["current_paraphrase"])
                    if variant in ("current_paraphrase", "dual_paraphrase")
                    else str(state["current"])
                )
                negative = (
                    str(negative_state["current_paraphrase"])
                    if variant in ("current_paraphrase", "dual_paraphrase")
                    else str(negative_state["current"])
                )
                contrast_id = "m52l-contrast-" + content_digest(
                    {
                        "semantic_group_id": semantic_group_id,
                        "variant": variant,
                        "version": JOINT_RELATIONAL_COMPARATOR_VERSION,
                    }
                )[:24]
                for orientation, candidate_a, candidate_b, target in (
                    ("positive_first", positive, negative, "A"),
                    ("positive_second", negative, positive, "B"),
                ):
                    rows.append(
                        {
                            "prompt": joint_comparator_prompt(
                                basis, candidate_a, candidate_b
                            ),
                            "metadata": {
                                "record_id": "m52l-record-"
                                + content_digest(
                                    {
                                        "contrast_id": contrast_id,
                                        "orientation": orientation,
                                        "version": JOINT_RELATIONAL_COMPARATOR_VERSION,
                                    }
                                )[:24],
                                "semantic_group_id": semantic_group_id,
                                "contrast_id": contrast_id,
                                "split": split,
                                "family": family_name,
                                "variant": variant,
                                "orientation": orientation,
                                "basis_state_key": state["key"],
                                "positive_state_key": state["key"],
                                "negative_state_key": negative_state["key"],
                                "basis_text": basis,
                                "positive_text": positive,
                                "negative_text": negative,
                                "candidate_a_text": candidate_a,
                                "candidate_b_text": candidate_b,
                                "target": target,
                            },
                        }
                    )
    return tuple(rows)


def comparator_records(
    rows: Sequence[Mapping[str, Any]], scores: Sequence[float]
) -> Tuple[Mapping[str, Any], ...]:
    if len(rows) != len(scores):
        raise ValueError("M52l rows and scores must align")
    records = []
    for row, score in zip(rows, scores):
        metadata = row["metadata"]
        prediction = "A" if float(score) > 0.0 else "B"
        target = str(metadata["target"])
        records.append(
            {
                "record_id": metadata["record_id"],
                "semantic_group_id": metadata["semantic_group_id"],
                "contrast_id": metadata["contrast_id"],
                "family": metadata["family"],
                "variant": metadata["variant"],
                "orientation": metadata["orientation"],
                "target": target,
                "prediction": prediction,
                "score": float(score),
                "correct": prediction == target,
            }
        )
    return tuple(records)


def comparator_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    def summarize(selected: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
        target_a = [row for row in selected if row["target"] == "A"]
        target_b = [row for row in selected if row["target"] == "B"]
        recall_a = sum(bool(row["correct"]) for row in target_a) / max(
            len(target_a), 1
        )
        recall_b = sum(bool(row["correct"]) for row in target_b) / max(
            len(target_b), 1
        )
        return {
            "record_count": len(selected),
            "accuracy": sum(bool(row["correct"]) for row in selected)
            / max(len(selected), 1),
            "balanced_accuracy": (recall_a + recall_b) / 2.0,
            "target_a_recall": recall_a,
            "target_b_recall": recall_b,
            "candidate_order_bias": abs(recall_a - recall_b),
        }

    contrasts: dict[str, list[Mapping[str, Any]]] = {}
    semantic_groups: dict[str, list[Mapping[str, Any]]] = {}
    for row in records:
        contrasts.setdefault(str(row["contrast_id"]), []).append(row)
        semantic_groups.setdefault(str(row["semantic_group_id"]), []).append(row)
    swap_pair_accuracy = sum(
        len(group) == 2 and all(bool(row["correct"]) for row in group)
        for group in contrasts.values()
    ) / max(len(contrasts), 1)
    paraphrase_group_accuracy = sum(
        len(group) == 8 and all(bool(row["correct"]) for row in group)
        for group in semantic_groups.values()
    ) / max(len(semantic_groups), 1)
    paraphrase = [row for row in records if row["variant"] != "canonical"]
    return {
        **summarize(records),
        "swap_pair_accuracy": swap_pair_accuracy,
        "paraphrase_balanced_accuracy": summarize(paraphrase)["balanced_accuracy"],
        "paraphrase_group_accuracy": paraphrase_group_accuracy,
        "by_variant": {
            variant: summarize([row for row in records if row["variant"] == variant])
            for variant in M52I_VARIANTS
        },
        "by_family": {
            family: summarize([row for row in records if row["family"] == family])
            for family in sorted({str(row["family"]) for row in records})
        },
    }


def comparator_condition_passed(
    metrics: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "balanced_accuracy": metrics["balanced_accuracy"]
        >= contract["minimum_balanced_accuracy"],
        "paraphrase_balanced_accuracy": metrics["paraphrase_balanced_accuracy"]
        >= contract["minimum_paraphrase_balanced_accuracy"],
        "swap_pair_accuracy": metrics["swap_pair_accuracy"]
        >= contract["minimum_swap_pair_accuracy"],
        "paraphrase_group_accuracy": metrics["paraphrase_group_accuracy"]
        >= contract["minimum_paraphrase_group_accuracy"],
        "each_family_balanced_accuracy": min(
            row["balanced_accuracy"] for row in metrics["by_family"].values()
        )
        >= contract["minimum_each_family_balanced_accuracy"],
        "candidate_order_bias": metrics["candidate_order_bias"]
        <= contract["maximum_candidate_order_bias"],
    }
    return all(checks.values()), checks


def comparator_improvement_passed(
    metrics: Mapping[str, Any],
    control: Mapping[str, Any],
    contract: Mapping[str, Any],
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "balanced_accuracy_delta": float(metrics["balanced_accuracy"])
        - float(control["balanced_accuracy"])
        >= contract["minimum_balanced_accuracy_delta"],
        "swap_pair_accuracy_delta": float(metrics["swap_pair_accuracy"])
        - float(control["swap_pair_accuracy"])
        >= contract["minimum_swap_pair_accuracy_delta"],
    }
    return all(checks.values()), checks


def select_m52l_condition(
    frozen_joint: Mapping[str, Any],
    trained_candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    if frozen_joint["passed"]:
        return frozen_joint
    passing = [row for row in trained_candidates if row["passed"]]
    if not passing:
        return None
    return sorted(
        passing,
        key=lambda row: (
            -float(row["metrics"]["swap_pair_accuracy"]),
            -float(row["metrics"]["balanced_accuracy"]),
            -float(row["metrics"]["paraphrase_group_accuracy"]),
            float(row["metrics"]["candidate_order_bias"]),
            int(row["iteration"]),
        ),
    )[0]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _jsonl(rows: Sequence[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52l artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode()).hexdigest()


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    parent = (
        project
        / "runs/cognitive_core/sequential_policy_learning_v47/selected_adapter/"
        "adapters.safetensors"
    )
    m52k = json.loads(
        (
            project
            / "runs/cognitive_core/reference_normalization_v52k/local-audit.json"
        ).read_text()
    )
    return {
        "version": JOINT_RELATIONAL_COMPARATOR_VERSION,
        "parent_version": "general-cognitive-reference-normalization-v52k",
        "scientific_question": (
            "Can a small model jointly compare a conclusion basis and two candidate states, "
            "generalizing the latent relation across candidate-order swaps, paraphrases, and "
            "unseen CS semantic families?"
        ),
        "seed": M52L_SEED,
        "families_by_split": {
            split: list(value) for split, value in M52L_FAMILIES_BY_SPLIT.items()
        },
        "variants": list(M52I_VARIANTS),
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "parent_adapter_source": (
                "runs/cognitive_core/sequential_policy_learning_v47/selected_adapter/"
                "adapters.safetensors"
            ),
            "parent_adapter_sha256": _sha256(parent),
            "m52k_audit_id": m52k["audit_id"],
            "failed_m52k_has_no_adapter": True,
        },
        "representation_contract": {
            "input": "basis plus candidate A plus candidate B in one model context",
            "output": "single next token A or B",
            "candidate_order_swaps": "every semantic contrast appears in both orientations",
            "paraphrase_invariance": (
                "canonical is paired during training with basis, current, and dual paraphrases"
            ),
            "negative_state_constant_across_paraphrase_variants": True,
        },
        "training_recipe": {
            "trainable_component": "top_8_existing_M47_LoRA_blocks_only",
            "iterations": 200,
            "learning_rate": 0.000005,
            "gradient_accumulation_steps": 4,
            "max_sequence_length": 320,
            "checkpoint_candidates": [20, 40, 80, 120, 160, 200],
            "microbatch": (
                "four prompts: canonical swap pair plus one paraphrase swap pair"
            ),
            "loss": (
                "A/B next-token cross entropy plus 0.1 swap-antisymmetry penalty and "
                "0.1 paraphrase signed-margin consistency penalty"
            ),
            "confirmation_access_during_selection": False,
        },
        "development_contract": {
            "minimum_balanced_accuracy": 0.88,
            "minimum_paraphrase_balanced_accuracy": 0.85,
            "minimum_swap_pair_accuracy": 0.80,
            "minimum_paraphrase_group_accuracy": 0.60,
            "minimum_each_family_balanced_accuracy": 0.80,
            "maximum_candidate_order_bias": 0.10,
        },
        "improvement_contract": {
            "minimum_balanced_accuracy_delta": 0.03,
            "minimum_swap_pair_accuracy_delta": 0.05,
        },
        "conditions": {
            "independent_pair_midpoint": "M52k-style independent scoring control",
            "frozen_joint_decoder": "joint prompt without new training",
            "trained_joint_comparator": "swap- and paraphrase-invariant LoRA intervention",
        },
        "selection_rule": (
            "Use development only. Prefer a passing frozen joint decoder; otherwise select "
            "the passing trained checkpoint by swap-pair accuracy, balanced accuracy, "
            "paraphrase-group accuracy, order bias, then earliest iteration. Joint conditions "
            "must also improve over the appropriate frozen control."
        ),
        "staged_access": {
            "validation_opened_only_after_development_condition_pass": True,
            "confirmation_opened_only_after_selected_condition_passes_validation": True,
            "m52k_sealed_confirmation_reused": False,
        },
        "claim_boundary": (
            "M52l tests a closed-world joint two-candidate semantic comparator on synthetic "
            "CS state descriptions with exactly one applicable candidate. Passing would not "
            "establish single-candidate applicability, trajectory control, autonomous concept "
            "invention, general reasoning parity, or transfer outside this relation class."
        ),
    }


def _groups(
    rows: Sequence[Mapping[str, Any]], key: str
) -> Mapping[str, list[Mapping[str, Any]]]:
    groups: dict[str, list[Mapping[str, Any]]] = {}
    for row in rows:
        groups.setdefault(str(row["metadata"][key]), []).append(row)
    return groups


def verify_m52l_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol = _protocol_payload(project)
    reproduced = {split: build_m52l_rows(split) for split in M52L_SPLITS}
    all_previous = set(
        M52K_FAMILIES_BY_SPLIT["development"]
        + M52K_FAMILIES_BY_SPLIT["validation"]
        + M52K_FAMILIES_BY_SPLIT["confirmation"]
    )
    checks = {
        "protocol_id_content_derived": content_digest(protocol)
        == freeze["protocol_freeze_id"],
        "freeze_id_content_derived": content_digest(
            {key: value for key, value in freeze.items() if key != "freeze_id"}
        )
        == freeze["freeze_id"],
        "counts_match": all(
            len(reproduced[split]) == int(freeze["counts"][split])
            for split in M52L_SPLITS
        ),
        "hashes_match": all(
            hashlib.sha256((output / f"{split}.jsonl").read_bytes()).hexdigest()
            == freeze["hashes"][split]
            for split in M52L_SPLITS
        ),
        "stored_rows_reproduce": all(
            (output / f"{split}.jsonl").read_text() == _jsonl(reproduced[split])
            for split in M52L_SPLITS
        ),
        "families_disjoint": all(
            not (
                set(M52L_FAMILIES_BY_SPLIT[left])
                & set(M52L_FAMILIES_BY_SPLIT[right])
            )
            for index, left in enumerate(M52L_SPLITS)
            for right in M52L_SPLITS[index + 1 :]
        ),
        "validation_and_confirmation_families_are_fresh": not (
            set(M52L_FAMILIES_BY_SPLIT["validation"])
            | set(M52L_FAMILIES_BY_SPLIT["confirmation"])
        )
        & all_previous,
        "exact_candidate_order_swaps": all(
            len(group) == 2
            and {row["metadata"]["target"] for row in group} == {"A", "B"}
            and group[0]["metadata"]["candidate_a_text"]
            == group[1]["metadata"]["candidate_b_text"]
            and group[0]["metadata"]["candidate_b_text"]
            == group[1]["metadata"]["candidate_a_text"]
            for split in M52L_SPLITS
            for group in _groups(reproduced[split], "contrast_id").values()
        ),
        "paraphrase_groups_hold_semantic_states_fixed": all(
            len(group) == 8
            and len({row["metadata"]["positive_state_key"] for row in group}) == 1
            and len({row["metadata"]["negative_state_key"] for row in group}) == 1
            and {row["metadata"]["variant"] for row in group} == set(M52I_VARIANTS)
            for split in M52L_SPLITS
            for group in _groups(reproduced[split], "semantic_group_id").values()
        ),
        "shortcut_identifiers_absent": all(
            "m52l-record" not in row["prompt"].lower()
            and "m52l-contrast" not in row["prompt"].lower()
            and "positive_first" not in row["prompt"].lower()
            and "positive_second" not in row["prompt"].lower()
            for split in M52L_SPLITS
            for row in reproduced[split]
        ),
        "parent_adapter_matches": _sha256(
            project / freeze["frozen_model"]["parent_adapter_source"]
        )
        == freeze["frozen_model"]["parent_adapter_sha256"],
        "m52k_audit_matches": json.loads(
            (
                project
                / "runs/cognitive_core/reference_normalization_v52k/local-audit.json"
            ).read_text()
        )["audit_id"]
        == freeze["frozen_model"]["m52k_audit_id"]
        == M52L_M52K_AUDIT_ID,
    }
    result = {
        "freeze_id": freeze["freeze_id"],
        "protocol_freeze_id": freeze["protocol_freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }
    (output / "benchmark-verification.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    return result


def prepare_m52l_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol = _protocol_payload(project)
    hashes = {}
    counts = {}
    for split in M52L_SPLITS:
        rows = build_m52l_rows(split)
        payload = _jsonl(rows)
        hashes[split] = _write_immutable(output / f"{split}.jsonl", payload)
        counts[split] = len(rows)
    freeze_payload = {
        **protocol,
        "protocol_freeze_id": content_digest(protocol),
        "counts": counts,
        "hashes": hashes,
    }
    freeze = {**freeze_payload, "freeze_id": content_digest(freeze_payload)}
    _write_immutable(
        output / "benchmark-freeze.json",
        json.dumps(freeze, indent=2, sort_keys=True) + "\n",
    )
    return verify_m52l_benchmark(output, project)
