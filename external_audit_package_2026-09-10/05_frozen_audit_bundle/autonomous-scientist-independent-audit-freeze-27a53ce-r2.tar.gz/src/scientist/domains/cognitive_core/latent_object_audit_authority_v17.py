from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import (
    MetaTaskSpec,
    make_numeric_task,
    make_relational_task,
)
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    LATENT_OBJECT_FORMATION_VERSION,
    LatentCoreFreeze,
    LatentRegistry,
    build_latent_registry,
)


LATENT_AUDIT_AUTHORITY_REF = "sealed-latent-object-audit-authority-v17"


@dataclass(frozen=True)
class LatentAuditCommitment:
    sealed_spec_digest: str
    seeds: Tuple[int, ...]
    families: Tuple[str, ...]
    tasks_per_family: int
    materialization_rule: str
    authority_ref: str = LATENT_AUDIT_AUTHORITY_REF

    @property
    def commitment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "sealed_spec_digest": self.sealed_spec_digest,
            "seeds": list(self.seeds),
            "families": list(self.families),
            "tasks_per_family": self.tasks_per_family,
            "materialization_rule": self.materialization_rule,
            "authority_ref": self.authority_ref,
        }
        if include_id:
            value["commitment_id"] = self.commitment_id
        return value


@dataclass(frozen=True)
class LatentAuditMaterialization:
    commitment: LatentAuditCommitment
    candidate_freeze_id: str
    registries: Mapping[str, LatentRegistry]
    causal_registry: LatentRegistry
    materialization_stage: int

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "commitment": self.commitment.as_dict(),
            "candidate_freeze_id": self.candidate_freeze_id,
            "registries": {
                key: item.as_dict()
                for key, item in sorted(self.registries.items())
            },
            "causal_registry": self.causal_registry.as_dict(),
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


class LatentObjectAuditAuthority:
    def __init__(
        self,
        *,
        seeds: Tuple[int, ...] = (1721, 1741, 1753, 1777, 1789),
        tasks_per_family: int = 24,
    ) -> None:
        if len(seeds) < 5:
            raise ValueError("latent-object audit requires at least five seeds")
        if tasks_per_family < 24:
            raise ValueError("latent-object audit requires 24 tasks for lag-64 coverage")
        self._seeds = tuple(int(item) for item in seeds)
        self._tasks_per_family = int(tasks_per_family)
        self._sealed_spec = {
            "seeds": self._seeds,
            "tasks_per_family": self._tasks_per_family,
            "numeric_moduli": (17, 19, 23),
            "relational_path_lengths": (2, 3),
            "aliases": "unique opaque per event",
            "authority_ref": LATENT_AUDIT_AUTHORITY_REF,
        }
        self.commitment = LatentAuditCommitment(
            sealed_spec_digest=content_digest(self._sealed_spec),
            seeds=self._seeds,
            families=(
                "hidden_numeric_objects",
                "hidden_relational_objects",
            ),
            tasks_per_family=self._tasks_per_family,
            materialization_rule=(
                "all aliases, events, evaluator identities, and desired outcomes "
                "remain unavailable until the address model and interpreter freeze"
            ),
        )
        self._materialized = False

    @staticmethod
    def _numeric_tasks(seed: int, count: int) -> Tuple[MetaTaskSpec, ...]:
        randomizer = random.Random(seed)
        tasks = []
        signatures = set()
        for index in range(count):
            modulus = (17, 19, 23)[index % 3]
            degree = 1 + index % 2
            while True:
                coefficients = tuple(
                    randomizer.randrange(modulus)
                    for _ in range(degree + 1)
                )
                signature = (modulus, coefficients)
                if signature not in signatures:
                    signatures.add(signature)
                    break
            tasks.append(
                make_numeric_task(
                    task_ref="hidden-n-%08x" % randomizer.getrandbits(32),
                    modulus=modulus,
                    coefficients=coefficients,
                    query=7 + index,
                    revised_constant=(
                        coefficients[0]
                        + ((3 + index) % modulus or 1)
                    )
                    % modulus,
                    family="hidden_numeric_objects",
                )
            )
        return tuple(tasks)

    @staticmethod
    def _relational_tasks(seed: int, count: int) -> Tuple[MetaTaskSpec, ...]:
        randomizer = random.Random(seed)
        tasks = []
        for index in range(count):
            path_length = 2 + index % 2
            relations = tuple(
                "hidden-rel-%08x" % randomizer.getrandbits(32)
                for _ in range(path_length)
            )
            tasks.append(
                make_relational_task(
                    task_ref="hidden-r-%08x" % randomizer.getrandbits(32),
                    relations=relations,
                    chain_count=6,
                    revised_terminal=(
                        "hidden-terminal-%08x" % randomizer.getrandbits(32)
                    ),
                    family="hidden_relational_objects",
                )
            )
        return tuple(tasks)

    def materialize(
        self,
        candidate_freeze: LatentCoreFreeze,
        *,
        materialization_stage: int = 5,
    ) -> LatentAuditMaterialization:
        if self._materialized:
            raise ValueError("latent-object audit may be materialized only once")
        if candidate_freeze.freeze_stage >= materialization_stage:
            raise ValueError("candidate did not freeze before hidden materialization")
        registries = {}
        for seed in self._seeds:
            registries["numeric-%d" % seed] = build_latent_registry(
                partition="audit",
                tasks=self._numeric_tasks(seed, self._tasks_per_family),
                authority_ref=LATENT_AUDIT_AUTHORITY_REF,
                exposure_stage=materialization_stage,
                seed=seed + 10000,
            )
            registries["relational-%d" % seed] = build_latent_registry(
                partition="audit",
                tasks=self._relational_tasks(seed + 5000, self._tasks_per_family),
                authority_ref=LATENT_AUDIT_AUTHORITY_REF,
                exposure_stage=materialization_stage,
                seed=seed + 20000,
            )
        mixed_seed = self._seeds[0] + 30000
        mixed_tasks = (
            *self._numeric_tasks(mixed_seed, 8),
            *self._relational_tasks(mixed_seed + 1, 8),
        )
        random.Random(mixed_seed + 2).shuffle(mixed_tasks := list(mixed_tasks))
        causal_registry = build_latent_registry(
            partition="causal_audit",
            tasks=tuple(mixed_tasks),
            authority_ref=LATENT_AUDIT_AUTHORITY_REF,
            exposure_stage=materialization_stage,
            seed=mixed_seed + 3,
        )
        self._materialized = True
        return LatentAuditMaterialization(
            commitment=self.commitment,
            candidate_freeze_id=candidate_freeze.freeze_id,
            registries=registries,
            causal_registry=causal_registry,
            materialization_stage=materialization_stage,
        )

    def verify_commitment(
        self, materialization: LatentAuditMaterialization
    ) -> bool:
        return (
            materialization.commitment == self.commitment
            and self.commitment.sealed_spec_digest
            == content_digest(self._sealed_spec)
        )
