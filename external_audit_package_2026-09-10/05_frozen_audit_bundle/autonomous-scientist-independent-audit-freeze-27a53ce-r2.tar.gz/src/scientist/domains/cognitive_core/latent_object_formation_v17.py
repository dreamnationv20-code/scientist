from __future__ import annotations

import math
import random
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import (
    KnowledgeRow,
    MetaExample,
    MetaTaskSpec,
    TypedExpression,
    execute_expression,
    infer_typed_expression,
    make_numeric_task,
    make_relational_task,
)


LATENT_OBJECT_FORMATION_VERSION = "cognitive-core-latent-object-formation-v17"
ADDRESS_FEATURE_NAMES = (
    "bias",
    "surface_overlap",
    "locator_fit",
    "locator_coverage",
    "type_compatibility",
    "mutation_feasible",
    "query_executable",
    "recency",
)


class LatentEventKind(str, Enum):
    DISCOVER = "discover"
    ATTACH = "attach"
    QUERY = "query"
    SELECT = "select"
    UPDATE = "update"


class LatentActionKind(str, Enum):
    DISCOVERED = "discovered"
    ATTACHED = "attached"
    ANSWER = "answer"
    SELECTION = "selection"
    UPDATED = "updated"
    ABSTAIN = "abstain"


@dataclass(frozen=True)
class LatentEvent:
    event_id: str
    kind: LatentEventKind
    alias: str
    payload: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "kind": self.kind.value,
            "alias": self.alias,
            "payload": dict(self.payload),
        }


@dataclass(frozen=True)
class LatentProbe:
    probe_id: str
    event_id: str
    evaluator_object_ref: str
    evaluator_family: str
    expected_kind: LatentActionKind
    expected_payload: Mapping[str, Any]
    horizon: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe_id": self.probe_id,
            "event_id": self.event_id,
            "evaluator_object_ref": self.evaluator_object_ref,
            "evaluator_family": self.evaluator_family,
            "expected_kind": self.expected_kind.value,
            "expected_payload": dict(self.expected_payload),
            "horizon": self.horizon,
        }


@dataclass(frozen=True)
class LatentRegistry:
    partition: str
    tasks: Tuple[MetaTaskSpec, ...]
    events: Tuple[LatentEvent, ...]
    probes: Tuple[LatentProbe, ...]
    event_object_refs: Mapping[str, str]
    discovery_object_refs: Mapping[str, str]
    authority_ref: str
    exposure_stage: int
    seed: int

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "partition": self.partition,
            "tasks": [item.as_dict() for item in self.tasks],
            "events": [item.as_dict() for item in self.events],
            "probes": [item.as_dict() for item in self.probes],
            "event_object_refs": dict(sorted(self.event_object_refs.items())),
            "discovery_object_refs": dict(
                sorted(self.discovery_object_refs.items())
            ),
            "authority_ref": self.authority_ref,
            "exposure_stage": self.exposure_stage,
            "seed": self.seed,
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


def _example_dicts(examples: Sequence[MetaExample]) -> list[Dict[str, Any]]:
    return [item.as_dict() for item in examples]


def _row_dicts(rows: Sequence[KnowledgeRow]) -> list[Dict[str, Any]]:
    return [item.as_dict() for item in rows]


def _decode_examples(rows: Sequence[Mapping[str, Any]]) -> Tuple[MetaExample, ...]:
    return tuple(
        MetaExample(tuple(item["inputs"]), item["output"]) for item in rows
    )


def _decode_rows(rows: Sequence[Mapping[str, Any]]) -> Tuple[KnowledgeRow, ...]:
    return tuple(
        KnowledgeRow(str(item["row_id"]), tuple(item["cells"]))
        for item in rows
    )


def _safe_execute(
    expression: TypedExpression,
    inputs: Sequence[Any],
    context: Sequence[KnowledgeRow],
) -> Tuple[Any | None, Tuple[str, ...]]:
    try:
        return execute_expression(expression, inputs, context)
    except (KeyError, TypeError, ValueError):
        return None, ()


def _split_context(
    task: MetaTaskSpec,
) -> Tuple[Tuple[KnowledgeRow, ...], Tuple[KnowledgeRow, ...]]:
    attach_ids = set(task.expected_relevant_row_ids)
    if not attach_ids:
        return task.context, ()
    supporting = tuple(
        row for row in task.context if row.row_id in attach_ids
    )
    distractors = tuple(
        row
        for row in task.context
        if row.row_id not in attach_ids
        and row.row_id.endswith(("d-0", "d-1"))
    )
    base = tuple(
        row
        for row in task.context
        if row.row_id not in attach_ids
        and row not in distractors
    )
    return base, (*supporting, *distractors)


def _updated_task_expression(
    task: MetaTaskSpec,
) -> Tuple[TypedExpression, Tuple[KnowledgeRow, ...]]:
    expression = infer_typed_expression(
        task.examples, task.context, task.metadata
    )
    if expression is None:
        raise ValueError("task lacks a unique typed expression")
    context = list(task.context)
    address = task.update_address
    if address[0] == "coefficient":
        coefficients = list(expression.arguments["coefficients"])
        coefficients[int(address[1])] = int(task.update_value)
        expression = TypedExpression(
            expression.kind,
            {**expression.arguments, "coefficients": coefficients},
        )
    elif address[0] == "row":
        row_id = str(address[1])
        cell_index = int(address[2])
        context = [
            KnowledgeRow(
                row.row_id,
                tuple(
                    task.update_value if index == cell_index else value
                    for index, value in enumerate(row.cells)
                ),
            )
            if row.row_id == row_id
            else row
            for row in context
        ]
    else:
        raise ValueError("unsupported evaluator-side task update")
    return expression, tuple(context)


def _current_locators(
    task: MetaTaskSpec, *, updated: bool
) -> Tuple[MetaExample, ...]:
    if not updated:
        return task.examples
    expression, context = _updated_task_expression(task)
    return tuple(
        MetaExample(
            item.inputs,
            execute_expression(expression, item.inputs, context)[0],
        )
        for item in task.examples
    )


def _desired_change_examples(task: MetaTaskSpec) -> Tuple[MetaExample, ...]:
    expression, context = _updated_task_expression(task)
    inputs = (
        tuple(item.inputs for item in task.examples)
        if isinstance(task.metadata.get("field_0"), int)
        else (task.query_inputs,)
    )
    return tuple(
        MetaExample(
            tuple(item),
            execute_expression(expression, item, context)[0],
        )
        for item in inputs
    )


def _horizon_bucket(lag: int) -> int:
    if lag >= 64:
        return 64
    if lag >= 32:
        return 32
    if lag >= 8:
        return 8
    return 1


def build_latent_registry(
    *,
    partition: str,
    tasks: Sequence[MetaTaskSpec],
    authority_ref: str,
    exposure_stage: int,
    seed: int,
) -> LatentRegistry:
    task_rows = tuple(tasks)
    randomizer = random.Random(seed)
    events = []
    probe_specs = []
    event_object_refs: Dict[str, str] = {}
    discovery_object_refs: Dict[str, str] = {}
    used_aliases = set()
    used_event_ids = set()

    def identity(prefix: str) -> Tuple[str, str]:
        while True:
            event_id = "ev-%08x" % randomizer.getrandbits(32)
            alias = "alias-%08x" % randomizer.getrandbits(32)
            if event_id not in used_event_ids and alias not in used_aliases:
                used_event_ids.add(event_id)
                used_aliases.add(alias)
                return event_id, alias

    def append_event(
        task: MetaTaskSpec,
        kind: LatentEventKind,
        payload: Mapping[str, Any],
        expected_kind: LatentActionKind,
        expected_payload: Mapping[str, Any],
        *,
        label: str,
        horizon: int = 1,
    ) -> None:
        event_id, alias = identity(label)
        event = LatentEvent(event_id, kind, alias, dict(payload))
        events.append(event)
        event_object_refs[event_id] = task.task_ref
        if kind == LatentEventKind.DISCOVER:
            discovery_object_refs[event_id] = task.task_ref
        probe_specs.append(
            (
                LatentProbe(
                    probe_id="probe-%s" % event_id,
                    event_id=event_id,
                    evaluator_object_ref=task.task_ref,
                    evaluator_family=task.evaluator_family,
                    expected_kind=expected_kind,
                    expected_payload=dict(expected_payload),
                    horizon=horizon,
                ),
                label,
            )
        )

    for task in task_rows:
        base, _ = _split_context(task)
        append_event(
            task,
            LatentEventKind.DISCOVER,
            {
                "examples": _example_dicts(task.examples),
                "context": _row_dicts(base),
                "metadata": dict(task.metadata),
            },
            LatentActionKind.DISCOVERED,
            {"accepted": True},
            label="discover",
        )
    for task in task_rows:
        _, attachment = _split_context(task)
        append_event(
            task,
            LatentEventKind.ATTACH,
            {
                "locators": _example_dicts(_current_locators(task, updated=False)),
                "rows": _row_dicts(attachment),
            },
            LatentActionKind.ATTACHED,
            {"count": len(attachment)},
            label="attach",
        )
    for task in task_rows:
        locators = _example_dicts(_current_locators(task, updated=False))
        append_event(
            task,
            LatentEventKind.QUERY,
            {"locators": locators, "inputs": list(task.query_inputs)},
            LatentActionKind.ANSWER,
            {"value": task.expected_before},
            label="query-before",
        )
        append_event(
            task,
            LatentEventKind.SELECT,
            {"locators": locators, "inputs": list(task.query_inputs)},
            LatentActionKind.SELECTION,
            {"row_ids": list(task.expected_relevant_row_ids)},
            label="select-before",
        )
    update_index_by_object: Dict[str, int] = {}
    for task in task_rows:
        append_event(
            task,
            LatentEventKind.UPDATE,
            {
                "locators": _example_dicts(_current_locators(task, updated=False)),
                "desired_examples": _example_dicts(
                    _desired_change_examples(task)
                ),
            },
            LatentActionKind.UPDATED,
            {"accepted": True},
            label="update",
        )
        update_index_by_object[task.task_ref] = len(events) - 1
    for task in reversed(task_rows):
        lag = len(events) - update_index_by_object[task.task_ref] - 1
        horizon = _horizon_bucket(lag)
        locators = _example_dicts(_current_locators(task, updated=True))
        append_event(
            task,
            LatentEventKind.QUERY,
            {"locators": locators, "inputs": list(task.query_inputs)},
            LatentActionKind.ANSWER,
            {"value": task.expected_after},
            label="query-after",
            horizon=horizon,
        )
        append_event(
            task,
            LatentEventKind.SELECT,
            {"locators": locators, "inputs": list(task.query_inputs)},
            LatentActionKind.SELECTION,
            {"row_ids": list(task.expected_relevant_row_ids)},
            label="select-after",
            horizon=horizon,
        )
    probes = tuple(item for item, _ in probe_specs)
    if len(used_aliases) != len(events):
        raise ValueError("every cross-channel alias must be unique")
    event_text = str([event.as_dict() for event in events])
    if any(
        forbidden in event_text
        for forbidden in ("task_ref", "object_ref", "update_address")
    ):
        raise ValueError("candidate-visible events contain an explicit address")
    return LatentRegistry(
        partition=partition,
        tasks=task_rows,
        events=tuple(events),
        probes=probes,
        event_object_refs=event_object_refs,
        discovery_object_refs=discovery_object_refs,
        authority_ref=authority_ref,
        exposure_stage=exposure_stage,
        seed=seed,
    )


@dataclass
class LatentObject:
    slot_id: str
    expression: TypedExpression
    examples: Tuple[MetaExample, ...]
    context: Tuple[KnowledgeRow, ...]
    metadata: Mapping[str, Any]
    aliases: Tuple[str, ...]
    created_at: int
    last_touched: int


def _clone_object(value: LatentObject) -> LatentObject:
    return LatentObject(
        slot_id=value.slot_id,
        expression=TypedExpression(
            value.expression.kind, dict(value.expression.arguments)
        ),
        examples=tuple(value.examples),
        context=tuple(value.context),
        metadata=dict(value.metadata),
        aliases=tuple(value.aliases),
        created_at=value.created_at,
        last_touched=value.last_touched,
    )


def _locator_statistics(
    event: LatentEvent, obj: LatentObject
) -> Tuple[float, float]:
    locators = _decode_examples(event.payload.get("locators", ()))
    if not locators:
        return 0.0, 0.0
    predictions = tuple(
        _safe_execute(obj.expression, item.inputs, obj.context)[0]
        for item in locators
    )
    coverage = sum(item is not None for item in predictions) / len(predictions)
    fit = sum(
        prediction == item.output
        for prediction, item in zip(predictions, locators)
    ) / len(locators)
    return fit, coverage


def _infer_mutation(
    obj: LatentObject,
    desired_examples: Sequence[MetaExample],
) -> LatentObject | None:
    matches = []
    if obj.expression.kind == "polynomial_mod":
        modulus = int(obj.expression.arguments["modulus"])
        coefficients = list(obj.expression.arguments["coefficients"])
        for index in range(len(coefficients)):
            for value in range(modulus):
                if value == coefficients[index]:
                    continue
                revised = list(coefficients)
                revised[index] = value
                expression = TypedExpression(
                    "polynomial_mod",
                    {"modulus": modulus, "coefficients": revised},
                )
                if all(
                    _safe_execute(
                        expression, item.inputs, obj.context
                    )[0]
                    == item.output
                    for item in desired_examples
                ):
                    candidate = _clone_object(obj)
                    candidate.expression = expression
                    matches.append(candidate)
    elif obj.expression.kind == "relation_path":
        desired_values = {item.output for item in desired_examples}
        for desired in desired_values:
            for row in obj.context:
                revised_context = tuple(
                    KnowledgeRow(
                        candidate.row_id,
                        (
                            candidate.cells[0],
                            candidate.cells[1],
                            desired,
                        ),
                    )
                    if candidate.row_id == row.row_id
                    and len(candidate.cells) == 3
                    else candidate
                    for candidate in obj.context
                )
                if all(
                    _safe_execute(
                        obj.expression, item.inputs, revised_context
                    )[0]
                    == item.output
                    for item in desired_examples
                ):
                    candidate = _clone_object(obj)
                    candidate.context = revised_context
                    matches.append(candidate)
    unique = {
        content_digest(
            {
                "expression": item.expression.as_dict(),
                "context": [row.as_dict() for row in item.context],
            }
        ): item
        for item in matches
    }
    return next(iter(unique.values())) if len(unique) == 1 else None


def address_features(
    event: LatentEvent,
    obj: LatentObject,
    sequence: int,
) -> Mapping[str, float]:
    alias_tokens = set(event.alias.split("-"))
    known_tokens = {
        token for alias in obj.aliases for token in alias.split("-")
    }
    overlap = (
        len(alias_tokens.intersection(known_tokens))
        / len(alias_tokens.union(known_tokens))
        if alias_tokens.union(known_tokens)
        else 0.0
    )
    fit, coverage = _locator_statistics(event, obj)
    locator_rows = _decode_examples(event.payload.get("locators", ()))
    if locator_rows and obj.examples:
        expected_types = tuple(type(item) for item in obj.examples[0].inputs)
        observed_types = tuple(type(item) for item in locator_rows[0].inputs)
        type_compatibility = float(expected_types == observed_types)
    else:
        type_compatibility = 0.0
    desired = _decode_examples(event.payload.get("desired_examples", ()))
    mutation_feasible = float(
        bool(desired) and _infer_mutation(obj, desired) is not None
    )
    inputs = tuple(event.payload.get("inputs", ()))
    executable = float(
        bool(inputs)
        and _safe_execute(obj.expression, inputs, obj.context)[0]
        is not None
    )
    return {
        "bias": 1.0,
        "surface_overlap": overlap,
        "locator_fit": fit,
        "locator_coverage": coverage,
        "type_compatibility": type_compatibility,
        "mutation_feasible": mutation_feasible,
        "query_executable": executable,
        "recency": 1.0 / (1.0 + max(0, sequence - obj.last_touched)),
    }


@dataclass(frozen=True)
class AddressTrainingExample:
    event_id: str
    positive_features: Mapping[str, float]
    negative_features: Tuple[Mapping[str, float], ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "positive_features": dict(sorted(self.positive_features.items())),
            "negative_features": [
                dict(sorted(item.items())) for item in self.negative_features
            ],
        }


@dataclass(frozen=True)
class AddressTrainingSet:
    development_registry_id: str
    examples: Tuple[AddressTrainingExample, ...]
    exposed_event_ids: Tuple[str, ...]
    feature_names: Tuple[str, ...]

    @property
    def training_set_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "development_registry_id": self.development_registry_id,
            "examples": [item.as_dict() for item in self.examples],
            "exposed_event_ids": list(self.exposed_event_ids),
            "feature_names": list(self.feature_names),
        }
        if include_id:
            value["training_set_id"] = self.training_set_id
        return value


@dataclass(frozen=True)
class LatentAddressModel:
    feature_names: Tuple[str, ...]
    weights: Tuple[float, ...]
    training_set_id: str
    training_steps: int
    learning_rate: float

    @property
    def model_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def score(self, features: Mapping[str, float]) -> float:
        return sum(
            weight * float(features[name])
            for name, weight in zip(self.feature_names, self.weights)
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "feature_names": list(self.feature_names),
            "weights": list(self.weights),
            "training_set_id": self.training_set_id,
            "training_steps": self.training_steps,
            "learning_rate": self.learning_rate,
            "parameter_count": len(self.weights),
        }
        if include_id:
            value["model_id"] = self.model_id
        return value


def train_latent_address_model(
    training_set: AddressTrainingSet,
    *,
    steps: int = 800,
    learning_rate: float = 0.15,
) -> LatentAddressModel:
    names = training_set.feature_names
    weights = [0.0 for _ in names]
    pairs = [
        (
            [
                example.positive_features[name]
                - negative[name]
                for name in names
            ]
        )
        for example in training_set.examples
        for negative in example.negative_features
    ]
    if not pairs:
        raise ValueError("address training requires positive-negative pairs")
    for _ in range(steps):
        gradient = [0.0 for _ in names]
        for delta in pairs:
            margin = sum(weight * value for weight, value in zip(weights, delta))
            scale = 1.0 / (1.0 + math.exp(min(40.0, max(-40.0, margin))))
            for index, value in enumerate(delta):
                gradient[index] -= scale * value
        for index in range(len(weights)):
            gradient[index] = gradient[index] / len(pairs) + 0.001 * weights[index]
            weights[index] -= learning_rate * gradient[index]
    return LatentAddressModel(
        feature_names=names,
        weights=tuple(round(item, 12) for item in weights),
        training_set_id=training_set.training_set_id,
        training_steps=steps,
        learning_rate=learning_rate,
    )


@dataclass(frozen=True)
class LatentAction:
    kind: LatentActionKind
    payload: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {"kind": self.kind.value, "payload": dict(self.payload)}


@dataclass(frozen=True)
class LatentStep:
    sequence: int
    event: LatentEvent
    action: LatentAction
    resolved_slot_id: str | None
    address_scores: Mapping[str, float]
    feature_evaluations: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "sequence": self.sequence,
            "event": self.event.as_dict(),
            "action": self.action.as_dict(),
            "resolved_slot_id": self.resolved_slot_id,
            "address_scores": dict(sorted(self.address_scores.items())),
            "feature_evaluations": self.feature_evaluations,
        }


class LatentObjectRuntime:
    """Forms persistent slots and resolves aliases without evaluator identities."""

    def __init__(
        self,
        *,
        address_mode: str,
        model: LatentAddressModel | None = None,
        oracle_object_refs: Mapping[str, str] | None = None,
        discovery_object_refs: Mapping[str, str] | None = None,
        forced_slots: Mapping[str, str] | None = None,
    ) -> None:
        if address_mode not in ("learned", "surface", "recency", "oracle"):
            raise ValueError("unsupported latent address mode")
        if address_mode == "learned" and model is None:
            raise ValueError("learned address mode requires a frozen model")
        if address_mode == "oracle" and (
            oracle_object_refs is None or discovery_object_refs is None
        ):
            raise ValueError("oracle control requires evaluator-side identities")
        self.address_mode = address_mode
        self.model = model
        self.oracle_object_refs = dict(oracle_object_refs or {})
        self.discovery_object_refs = dict(discovery_object_refs or {})
        self.forced_slots = dict(forced_slots or {})
        self.objects: Dict[str, LatentObject] = {}
        self.oracle_slot_by_object: Dict[str, str] = {}
        self.sequence = 0
        self.feature_evaluations = 0

    def feature_rows(
        self, event: LatentEvent
    ) -> Mapping[str, Mapping[str, float]]:
        return {
            slot_id: address_features(event, obj, self.sequence)
            for slot_id, obj in sorted(self.objects.items())
        }

    def _resolve(
        self, event: LatentEvent
    ) -> Tuple[LatentObject | None, Mapping[str, float]]:
        if event.event_id in self.forced_slots:
            slot_id = self.forced_slots[event.event_id]
            return self.objects.get(slot_id), {slot_id: float("inf")}
        if not self.objects:
            return None, {}
        features = self.feature_rows(event)
        self.feature_evaluations += len(features)
        if self.address_mode == "oracle":
            object_ref = self.oracle_object_refs[event.event_id]
            slot_id = self.oracle_slot_by_object[object_ref]
            return self.objects[slot_id], {slot_id: 1.0}
        if self.address_mode == "learned":
            assert self.model is not None
            scores = {
                slot_id: self.model.score(row)
                for slot_id, row in features.items()
            }
        elif self.address_mode == "surface":
            scores = {
                slot_id: row["surface_overlap"]
                for slot_id, row in features.items()
            }
        else:
            scores = {
                slot_id: row["recency"] for slot_id, row in features.items()
            }
        slot_id = max(
            scores,
            key=lambda item: (scores[item], self.objects[item].last_touched, item),
        )
        return self.objects[slot_id], scores

    def act(self, event: LatentEvent) -> LatentStep:
        sequence = self.sequence
        self.sequence += 1
        before_feature_count = self.feature_evaluations
        scores: Mapping[str, float] = {}
        resolved: LatentObject | None = None
        if event.kind == LatentEventKind.DISCOVER:
            examples = _decode_examples(event.payload["examples"])
            context = _decode_rows(event.payload["context"])
            metadata = dict(event.payload["metadata"])
            expression = infer_typed_expression(examples, context, metadata)
            if expression is None:
                action = LatentAction(
                    LatentActionKind.ABSTAIN,
                    {"reason": "no unique executable schema"},
                )
            else:
                slot_id = "slot-%04d" % len(self.objects)
                resolved = LatentObject(
                    slot_id=slot_id,
                    expression=expression,
                    examples=examples,
                    context=context,
                    metadata=metadata,
                    aliases=(event.alias,),
                    created_at=sequence,
                    last_touched=sequence,
                )
                self.objects[slot_id] = resolved
                if self.address_mode == "oracle":
                    object_ref = self.discovery_object_refs[event.event_id]
                    self.oracle_slot_by_object[object_ref] = slot_id
                action = LatentAction(
                    LatentActionKind.DISCOVERED, {"accepted": True}
                )
        else:
            resolved, scores = self._resolve(event)
            if resolved is None:
                action = LatentAction(
                    LatentActionKind.ABSTAIN,
                    {"reason": "no compatible latent object"},
                )
            elif event.kind == LatentEventKind.ATTACH:
                rows = _decode_rows(event.payload["rows"])
                existing = {row.row_id for row in resolved.context}
                resolved.context = (
                    *resolved.context,
                    *(row for row in rows if row.row_id not in existing),
                )
                resolved.aliases = (*resolved.aliases, event.alias)
                resolved.last_touched = sequence
                action = LatentAction(
                    LatentActionKind.ATTACHED, {"count": len(rows)}
                )
            elif event.kind in (LatentEventKind.QUERY, LatentEventKind.SELECT):
                value, used_rows = _safe_execute(
                    resolved.expression,
                    tuple(event.payload["inputs"]),
                    resolved.context,
                )
                resolved.aliases = (*resolved.aliases, event.alias)
                resolved.last_touched = sequence
                if value is None:
                    action = LatentAction(
                        LatentActionKind.ABSTAIN,
                        {"reason": "latent object cannot execute query"},
                    )
                elif event.kind == LatentEventKind.QUERY:
                    action = LatentAction(
                        LatentActionKind.ANSWER, {"value": value}
                    )
                else:
                    action = LatentAction(
                        LatentActionKind.SELECTION,
                        {"row_ids": list(used_rows)},
                    )
            elif event.kind == LatentEventKind.UPDATE:
                desired = _decode_examples(event.payload["desired_examples"])
                revised = _infer_mutation(resolved, desired)
                if revised is None:
                    action = LatentAction(
                        LatentActionKind.ABSTAIN,
                        {"reason": "no unique behaviorally grounded mutation"},
                    )
                else:
                    resolved.expression = revised.expression
                    resolved.context = revised.context
                    resolved.aliases = (*resolved.aliases, event.alias)
                    resolved.last_touched = sequence
                    action = LatentAction(
                        LatentActionKind.UPDATED, {"accepted": True}
                    )
            else:  # pragma: no cover - enum exhaustiveness
                action = LatentAction(
                    LatentActionKind.ABSTAIN,
                    {"reason": "unsupported event"},
                )
        return LatentStep(
            sequence=sequence,
            event=event,
            action=action,
            resolved_slot_id=None if resolved is None else resolved.slot_id,
            address_scores=scores,
            feature_evaluations=(
                self.feature_evaluations - before_feature_count
            ),
        )


def build_address_training_set(
    registry: LatentRegistry,
) -> AddressTrainingSet:
    runtime = LatentObjectRuntime(
        address_mode="oracle",
        oracle_object_refs=registry.event_object_refs,
        discovery_object_refs=registry.discovery_object_refs,
    )
    examples = []
    exposed = []
    for event in registry.events:
        if event.kind != LatentEventKind.DISCOVER:
            feature_rows = runtime.feature_rows(event)
            positive_slot = runtime.oracle_slot_by_object[
                registry.event_object_refs[event.event_id]
            ]
            examples.append(
                AddressTrainingExample(
                    event_id=event.event_id,
                    positive_features=feature_rows[positive_slot],
                    negative_features=tuple(
                        row
                        for slot_id, row in feature_rows.items()
                        if slot_id != positive_slot
                    ),
                )
            )
            exposed.append(event.event_id)
        runtime.act(event)
    return AddressTrainingSet(
        development_registry_id=registry.registry_id,
        examples=tuple(examples),
        exposed_event_ids=tuple(exposed),
        feature_names=ADDRESS_FEATURE_NAMES,
    )


@dataclass(frozen=True)
class LatentProbeOutcome:
    probe: LatentProbe
    observed: LatentAction
    resolved_slot_id: str | None
    expected_slot_id: str | None
    action_passed: bool
    address_passed: bool

    @property
    def passed(self) -> bool:
        return self.action_passed and self.address_passed

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe": self.probe.as_dict(),
            "observed": self.observed.as_dict(),
            "resolved_slot_id": self.resolved_slot_id,
            "expected_slot_id": self.expected_slot_id,
            "action_passed": self.action_passed,
            "address_passed": self.address_passed,
            "passed": self.passed,
        }


@dataclass(frozen=True)
class LatentEvaluation:
    address_mode: str
    model_id: str | None
    registry_id: str
    outcomes: Tuple[LatentProbeOutcome, ...]
    family_scores: Mapping[str, float]
    horizon_scores: Mapping[str, float]
    action_score: float
    address_score: float
    feature_evaluations: int
    parameter_count: int

    @property
    def joint_score(self) -> float:
        return sum(item.passed for item in self.outcomes) / len(self.outcomes)

    @property
    def evaluation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "address_mode": self.address_mode,
            "model_id": self.model_id,
            "registry_id": self.registry_id,
            "outcomes": [item.as_dict() for item in self.outcomes],
            "family_scores": dict(sorted(self.family_scores.items())),
            "horizon_scores": dict(sorted(self.horizon_scores.items())),
            "action_score": self.action_score,
            "address_score": self.address_score,
            "joint_score": self.joint_score,
            "feature_evaluations": self.feature_evaluations,
            "parameter_count": self.parameter_count,
        }
        if include_id:
            value["evaluation_id"] = self.evaluation_id
        return value


def evaluate_latent_runtime(
    registry: LatentRegistry,
    *,
    address_mode: str,
    model: LatentAddressModel | None = None,
    forced_slots: Mapping[str, str] | None = None,
) -> Tuple[LatentEvaluation, Tuple[LatentStep, ...]]:
    runtime = LatentObjectRuntime(
        address_mode=address_mode,
        model=model,
        oracle_object_refs=(
            registry.event_object_refs if address_mode == "oracle" else None
        ),
        discovery_object_refs=(
            registry.discovery_object_refs if address_mode == "oracle" else None
        ),
        forced_slots=forced_slots,
    )
    steps = tuple(runtime.act(event) for event in registry.events)
    by_event = {item.event.event_id: item for item in steps}
    expected_slot_by_object = {
        object_ref: by_event[event_id].resolved_slot_id
        for event_id, object_ref in registry.discovery_object_refs.items()
    }
    outcomes = tuple(
        LatentProbeOutcome(
            probe=probe,
            observed=by_event[probe.event_id].action,
            resolved_slot_id=by_event[probe.event_id].resolved_slot_id,
            expected_slot_id=expected_slot_by_object[probe.evaluator_object_ref],
            action_passed=(
                by_event[probe.event_id].action.kind == probe.expected_kind
                and by_event[probe.event_id].action.payload
                == probe.expected_payload
            ),
            address_passed=(
                by_event[probe.event_id].resolved_slot_id
                == expected_slot_by_object[probe.evaluator_object_ref]
            ),
        )
        for probe in registry.probes
    )
    families = sorted({item.probe.evaluator_family for item in outcomes})
    family_scores = {
        family: sum(
            item.passed
            for item in outcomes
            if item.probe.evaluator_family == family
        )
        / sum(item.probe.evaluator_family == family for item in outcomes)
        for family in families
    }
    horizons = sorted({item.probe.horizon for item in outcomes})
    horizon_scores = {
        str(horizon): sum(
            item.passed for item in outcomes if item.probe.horizon == horizon
        )
        / sum(item.probe.horizon == horizon for item in outcomes)
        for horizon in horizons
    }
    return (
        LatentEvaluation(
            address_mode=address_mode,
            model_id=None if model is None else model.model_id,
            registry_id=registry.registry_id,
            outcomes=outcomes,
            family_scores=family_scores,
            horizon_scores=horizon_scores,
            action_score=sum(item.action_passed for item in outcomes)
            / len(outcomes),
            address_score=sum(item.address_passed for item in outcomes)
            / len(outcomes),
            feature_evaluations=sum(item.feature_evaluations for item in steps),
            parameter_count=0 if model is None else len(model.weights),
        ),
        steps,
    )


@dataclass(frozen=True)
class LatentCoreFreeze:
    model: LatentAddressModel
    training_set_id: str
    development_registry_id: str
    development_evaluation_id: str
    interpreter_source_digest: str
    freeze_stage: int

    @property
    def executable_digest(self) -> str:
        return content_digest(
            {
                "model": self.model.as_dict(),
                "interpreter_source_digest": self.interpreter_source_digest,
            }
        )

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "model": self.model.as_dict(),
            "training_set_id": self.training_set_id,
            "development_registry_id": self.development_registry_id,
            "development_evaluation_id": self.development_evaluation_id,
            "interpreter_source_digest": self.interpreter_source_digest,
            "executable_digest": self.executable_digest,
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_latent_core(
    *,
    model: LatentAddressModel,
    training_set: AddressTrainingSet,
    development_evaluation: LatentEvaluation,
    interpreter_source_digest: str,
    freeze_stage: int = 4,
) -> LatentCoreFreeze:
    if model.training_set_id != training_set.training_set_id:
        raise ValueError("model and training set identities differ")
    if development_evaluation.model_id != model.model_id:
        raise ValueError("development evaluation used another model")
    if development_evaluation.joint_score < 0.95:
        raise ValueError("latent core did not clear the development floor")
    return LatentCoreFreeze(
        model=model,
        training_set_id=training_set.training_set_id,
        development_registry_id=training_set.development_registry_id,
        development_evaluation_id=development_evaluation.evaluation_id,
        interpreter_source_digest=interpreter_source_digest,
        freeze_stage=freeze_stage,
    )


def build_latent_development_registry() -> LatentRegistry:
    randomizer = random.Random(1703)
    tasks = []
    numeric_programs = set()
    for index in range(8):
        modulus = (7, 11, 13)[index % 3]
        degree = 1 + index % 2
        while True:
            coefficients = tuple(
                randomizer.randrange(modulus) for _ in range(degree + 1)
            )
            signature = (modulus, coefficients)
            if signature not in numeric_programs:
                numeric_programs.add(signature)
                break
        tasks.append(
            make_numeric_task(
                task_ref="dev-object-n-%02d" % index,
                modulus=modulus,
                coefficients=coefficients,
                query=4 + index,
                revised_constant=(coefficients[0] + index + 2) % modulus,
                family="development-numeric",
            )
        )
    for index in range(8):
        relations = (
            "dev-rel-%02d-a" % index,
            "dev-rel-%02d-b" % index,
        )
        tasks.append(
            make_relational_task(
                task_ref="dev-object-r-%02d" % index,
                relations=relations,
                chain_count=5,
                revised_terminal="dev-terminal-%02d" % index,
                family="development-relational",
            )
        )
    randomizer.shuffle(tasks)
    return build_latent_registry(
        partition="development",
        tasks=tasks,
        authority_ref="latent-object-development-authority-v17",
        exposure_stage=1,
        seed=1707,
    )


@dataclass(frozen=True)
class CausalAddressIntervention:
    registry_id: str
    target_probe_ids: Tuple[str, ...]
    normal_resolved_slots: Mapping[str, str]
    forced_slot_mapping: Mapping[str, str]
    changed_probe_ids: Tuple[str, ...]
    non_target_invariance: float
    targets_fail_under_swap: bool

    @property
    def passed(self) -> bool:
        return self.targets_fail_under_swap and self.non_target_invariance == 1.0

    @property
    def intervention_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "registry_id": self.registry_id,
            "target_probe_ids": list(self.target_probe_ids),
            "normal_resolved_slots": dict(sorted(self.normal_resolved_slots.items())),
            "forced_slot_mapping": dict(sorted(self.forced_slot_mapping.items())),
            "changed_probe_ids": list(self.changed_probe_ids),
            "non_target_invariance": self.non_target_invariance,
            "targets_fail_under_swap": self.targets_fail_under_swap,
            "passed": self.passed,
        }
        if include_id:
            value["intervention_id"] = self.intervention_id
        return value


def run_causal_address_swap(
    registry: LatentRegistry,
    model: LatentAddressModel,
) -> CausalAddressIntervention:
    normal, _ = evaluate_latent_runtime(
        registry, address_mode="learned", model=model
    )
    candidates = tuple(
        item
        for item in normal.outcomes
        if item.probe.expected_kind == LatentActionKind.ANSWER
        and item.probe.horizon == 1
        and item.passed
    )
    pair = next(
        (left, right)
        for left in candidates
        for right in candidates
        if left.probe.evaluator_family != right.probe.evaluator_family
        and left.observed.payload != right.observed.payload
    )
    left, right = pair
    forced = {
        left.probe.event_id: str(right.resolved_slot_id),
        right.probe.event_id: str(left.resolved_slot_id),
    }
    intervened, _ = evaluate_latent_runtime(
        registry,
        address_mode="learned",
        model=model,
        forced_slots=forced,
    )
    normal_by_probe = {item.probe.probe_id: item for item in normal.outcomes}
    changed = tuple(
        item.probe.probe_id
        for item in intervened.outcomes
        if item.observed != normal_by_probe[item.probe.probe_id].observed
        or item.resolved_slot_id
        != normal_by_probe[item.probe.probe_id].resolved_slot_id
    )
    targets = (left.probe.probe_id, right.probe.probe_id)
    non_targets = tuple(
        item
        for item in intervened.outcomes
        if item.probe.probe_id not in set(targets)
    )
    invariance = sum(
        item.observed == normal_by_probe[item.probe.probe_id].observed
        and item.resolved_slot_id
        == normal_by_probe[item.probe.probe_id].resolved_slot_id
        for item in non_targets
    ) / len(non_targets)
    by_probe = {item.probe.probe_id: item for item in intervened.outcomes}
    return CausalAddressIntervention(
        registry_id=registry.registry_id,
        target_probe_ids=targets,
        normal_resolved_slots={
            left.probe.probe_id: str(left.resolved_slot_id),
            right.probe.probe_id: str(right.resolved_slot_id),
        },
        forced_slot_mapping=forced,
        changed_probe_ids=changed,
        non_target_invariance=invariance,
        targets_fail_under_swap=all(not by_probe[item].passed for item in targets),
    )


@dataclass(frozen=True)
class LatentObjectAuditTrial:
    candidate_freeze: LatentCoreFreeze
    audit_commitment_id: str
    audit_materialization_id: str
    audit_registry_ids: Mapping[str, str]
    candidate_evaluations: Mapping[str, LatentEvaluation]
    surface_evaluations: Mapping[str, LatentEvaluation]
    recency_evaluations: Mapping[str, LatentEvaluation]
    oracle_evaluations: Mapping[str, LatentEvaluation]
    causal_intervention: CausalAddressIntervention
    aggregate_family_scores: Mapping[str, float]
    aggregate_horizon_scores: Mapping[str, float]
    check_results: Mapping[str, bool]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LATENT_OBJECT_FORMATION_VERSION,
            "candidate_freeze": self.candidate_freeze.as_dict(),
            "audit_commitment_id": self.audit_commitment_id,
            "audit_materialization_id": self.audit_materialization_id,
            "audit_registry_ids": dict(sorted(self.audit_registry_ids.items())),
            "candidate_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.candidate_evaluations.items())
            },
            "surface_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.surface_evaluations.items())
            },
            "recency_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.recency_evaluations.items())
            },
            "oracle_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.oracle_evaluations.items())
            },
            "causal_intervention": self.causal_intervention.as_dict(),
            "aggregate_family_scores": dict(
                sorted(self.aggregate_family_scores.items())
            ),
            "aggregate_horizon_scores": dict(
                sorted(self.aggregate_horizon_scores.items())
            ),
            "check_results": dict(sorted(self.check_results.items())),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def run_latent_object_audit(
    *,
    candidate_freeze: LatentCoreFreeze,
    audit_commitment_id: str,
    audit_materialization_id: str,
    registries: Mapping[str, LatentRegistry],
    causal_registry: LatentRegistry,
    materialization_stage: int,
) -> LatentObjectAuditTrial:
    if candidate_freeze.freeze_stage >= materialization_stage:
        raise ValueError("audit registries were exposed before candidate freeze")
    candidate = {}
    surface = {}
    recency = {}
    oracle = {}
    for key, registry in registries.items():
        candidate[key] = evaluate_latent_runtime(
            registry,
            address_mode="learned",
            model=candidate_freeze.model,
        )[0]
        surface[key] = evaluate_latent_runtime(
            registry, address_mode="surface"
        )[0]
        recency[key] = evaluate_latent_runtime(
            registry, address_mode="recency"
        )[0]
        oracle[key] = evaluate_latent_runtime(
            registry, address_mode="oracle"
        )[0]
    all_outcomes = tuple(
        outcome
        for evaluation in candidate.values()
        for outcome in evaluation.outcomes
    )
    families = sorted({item.probe.evaluator_family for item in all_outcomes})
    family_scores = {
        family: sum(
            item.passed
            for item in all_outcomes
            if item.probe.evaluator_family == family
        )
        / sum(
            item.probe.evaluator_family == family for item in all_outcomes
        )
        for family in families
    }
    horizons = (1, 8, 32, 64)
    horizon_scores = {
        str(horizon): sum(
            item.passed
            for item in all_outcomes
            if item.probe.horizon == horizon
        )
        / sum(item.probe.horizon == horizon for item in all_outcomes)
        for horizon in horizons
    }
    intervention = run_causal_address_swap(
        causal_registry, candidate_freeze.model
    )
    candidate_scores = tuple(item.joint_score for item in candidate.values())
    surface_scores = tuple(item.joint_score for item in surface.values())
    recency_scores = tuple(item.joint_score for item in recency.values())
    oracle_scores = tuple(item.joint_score for item in oracle.values())
    checks = {
        "candidate_frozen_before_all_hidden_registries": (
            candidate_freeze.freeze_stage < materialization_stage
        ),
        "five_disjoint_seeds_per_hidden_family": (
            len(registries) == 10
            and sum(key.startswith("numeric-") for key in registries) == 5
            and sum(key.startswith("relational-") for key in registries) == 5
        ),
        "learned_candidate_clears_every_seed_floor": min(candidate_scores) >= 0.95,
        "both_hidden_families_clear_floor": all(
            value >= 0.95 for value in family_scores.values()
        ),
        "all_long_horizon_buckets_clear_floor": all(
            value >= 0.95 for value in horizon_scores.values()
        ),
        "learned_addressing_beats_surface_and_recency_by_twenty_points": (
            sum(candidate_scores) / len(candidate_scores)
            - max(
                sum(surface_scores) / len(surface_scores),
                sum(recency_scores) / len(recency_scores),
            )
            >= 0.20
        ),
        "oracle_control_saturates_every_registry": min(oracle_scores) == 1.0,
        "causal_address_swap_is_selective": intervention.passed,
        "model_stays_inside_declared_cost_envelope": (
            len(candidate_freeze.model.weights) <= 16
            and max(
                item.feature_evaluations for item in candidate.values()
            )
            <= 50000
        ),
        "audit_registry_identities_are_disjoint_from_development": (
            candidate_freeze.development_registry_id
            not in {item.registry_id for item in registries.values()}
            and len({item.registry_id for item in registries.values()})
            == len(registries)
        ),
    }
    return LatentObjectAuditTrial(
        candidate_freeze=candidate_freeze,
        audit_commitment_id=audit_commitment_id,
        audit_materialization_id=audit_materialization_id,
        audit_registry_ids={
            key: item.registry_id for key, item in registries.items()
        },
        candidate_evaluations=candidate,
        surface_evaluations=surface,
        recency_evaluations=recency,
        oracle_evaluations=oracle,
        causal_intervention=intervention,
        aggregate_family_scores=family_scores,
        aggregate_horizon_scores=horizon_scores,
        check_results=checks,
        limitations=(
            "Address formation is learned from supervised development co-reference labels, not self-supervised from raw experience.",
            "Behavioral locator examples provide the information needed for co-reference even though they are not stable identifiers.",
            "The executable-expression interpreter and mutation search remain engineered and typed.",
            "Hidden audits are synthetic local generators, not external replication or natural-language tasks.",
        ),
    )
