from __future__ import annotations

import itertools
import json
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.latent_object_audit_authority_v17 import (
    LatentAuditMaterialization,
)
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    AddressTrainingSet,
    LatentAction,
    LatentActionKind,
    LatentCoreFreeze,
    LatentEventKind,
    LatentEvaluation,
    LatentObjectAuditTrial,
    LatentRegistry,
)
from scientist.program.control_plane import AutonomousScientistControlPlane


LATENT_OBJECT_VERIFIER_REF = (
    "cognitive-core-latent-object-independent-verifier-v17"
)


@dataclass(frozen=True)
class LatentObjectVerification:
    check_results: Mapping[str, bool]
    cognitive_core_criteria: Mapping[str, bool]
    independent_match_rates: Mapping[str, float]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str = LATENT_OBJECT_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def latent_object_milestone_demonstrated(self) -> bool:
        required = (
            "explicit_cross_channel_addresses_removed",
            "co_reference_policy_is_learned",
            "two_hidden_families_transfer_across_five_seeds",
            "persistent_objects_survive_lag_64",
            "addressing_has_selective_causal_effect",
        )
        return all(self.cognitive_core_criteria[item] for item in required)

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "cognitive_core_criteria": dict(
                sorted(self.cognitive_core_criteria.items())
            ),
            "independent_match_rates": dict(
                sorted(self.independent_match_rates.items())
            ),
            "latent_object_milestone_demonstrated": (
                self.latent_object_milestone_demonstrated
            ),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


@dataclass
class _IndependentObject:
    kind: str
    parameters: Dict[str, Any]
    context: Dict[str, list[Any]]


def _numeric_value(coefficients: Sequence[int], modulus: int, value: int) -> int:
    return sum(
        int(coefficient) * pow(value, index)
        for index, coefficient in enumerate(coefficients)
    ) % modulus


def _infer_numeric(task) -> _IndependentObject:
    modulus = int(task.metadata["field_0"])
    for degree in range(3):
        matches = []
        for coefficients in itertools.product(range(modulus), repeat=degree + 1):
            if all(
                _numeric_value(coefficients, modulus, int(item.inputs[0]))
                == int(item.output)
                for item in task.examples
            ):
                matches.append(coefficients)
        if len(matches) == 1:
            return _IndependentObject(
                "numeric",
                {"modulus": modulus, "coefficients": list(matches[0])},
                {},
            )
    raise ValueError("independent verifier found no unique numeric program")


def _follow(
    context: Mapping[str, Sequence[Any]],
    start: Any,
    path: Sequence[Any],
) -> Tuple[Any | None, Tuple[str, ...]]:
    current = start
    used = []
    for relation in path:
        matches = [
            (row_id, cells)
            for row_id, cells in context.items()
            if len(cells) == 3
            and cells[0] == current
            and cells[1] == relation
        ]
        if len(matches) != 1:
            return None, ()
        row_id, cells = matches[0]
        used.append(row_id)
        current = cells[2]
    return current, tuple(used)


def _infer_relational(task, base_context) -> _IndependentObject:
    context = {row.row_id: list(row.cells) for row in base_context}
    relations = sorted(
        {cells[1] for cells in context.values() if len(cells) == 3}, key=str
    )
    for length in range(1, 4):
        matches = []
        for path in itertools.product(relations, repeat=length):
            if all(
                _follow(context, item.inputs[0], path)[0] == item.output
                for item in task.examples
            ):
                matches.append(path)
        if len(matches) == 1:
            return _IndependentObject(
                "relational", {"path": list(matches[0])}, context
            )
    raise ValueError("independent verifier found no unique relational program")


def _independent_execute(
    obj: _IndependentObject, inputs: Sequence[Any]
) -> Tuple[Any | None, Tuple[str, ...]]:
    if len(inputs) != 1:
        return None, ()
    if obj.kind == "numeric":
        return (
            _numeric_value(
                obj.parameters["coefficients"],
                int(obj.parameters["modulus"]),
                int(inputs[0]),
            ),
            (),
        )
    return _follow(obj.context, inputs[0], obj.parameters["path"])


def _independent_actions(registry: LatentRegistry) -> Mapping[str, LatentAction]:
    task_by_ref = {item.task_ref: item for item in registry.tasks}
    objects: Dict[str, _IndependentObject] = {}
    actions = {}
    for event in registry.events:
        object_ref = registry.event_object_refs[event.event_id]
        task = task_by_ref[object_ref]
        if event.kind == LatentEventKind.DISCOVER:
            base_context = tuple(
                type(task.context[0])(
                    str(item["row_id"]), tuple(item["cells"])
                )
                for item in event.payload["context"]
            ) if event.payload["context"] else ()
            if isinstance(task.metadata.get("field_0"), int):
                objects[object_ref] = _infer_numeric(task)
            else:
                objects[object_ref] = _infer_relational(task, base_context)
            actions[event.event_id] = LatentAction(
                LatentActionKind.DISCOVERED, {"accepted": True}
            )
        elif event.kind == LatentEventKind.ATTACH:
            obj = objects[object_ref]
            rows = tuple(event.payload["rows"])
            for row in rows:
                obj.context[str(row["row_id"])] = list(row["cells"])
            actions[event.event_id] = LatentAction(
                LatentActionKind.ATTACHED, {"count": len(rows)}
            )
        elif event.kind in (LatentEventKind.QUERY, LatentEventKind.SELECT):
            value, used = _independent_execute(
                objects[object_ref], event.payload["inputs"]
            )
            actions[event.event_id] = (
                LatentAction(LatentActionKind.ANSWER, {"value": value})
                if event.kind == LatentEventKind.QUERY
                else LatentAction(
                    LatentActionKind.SELECTION, {"row_ids": list(used)}
                )
            )
        elif event.kind == LatentEventKind.UPDATE:
            obj = objects[object_ref]
            address = task.update_address
            if address[0] == "coefficient":
                obj.parameters["coefficients"][int(address[1])] = int(
                    task.update_value
                )
            else:
                obj.context[str(address[1])][int(address[2])] = task.update_value
            actions[event.event_id] = LatentAction(
                LatentActionKind.UPDATED, {"accepted": True}
            )
    return actions


def _match_rate(
    registry: LatentRegistry, evaluation: LatentEvaluation
) -> float:
    expected = _independent_actions(registry)
    return sum(
        item.observed == expected[item.probe.event_id]
        for item in evaluation.outcomes
    ) / len(evaluation.outcomes)


def verify_latent_object_formation(
    *,
    control: AutonomousScientistControlPlane,
    development_registry: LatentRegistry,
    training_set: AddressTrainingSet,
    candidate_freeze: LatentCoreFreeze,
    materialization: LatentAuditMaterialization,
    trial: LatentObjectAuditTrial,
    artifact_round_trip_checks: Mapping[str, bool],
) -> LatentObjectVerification:
    visible_event_text = json.dumps(
        [event.as_dict() for event in development_registry.events],
        sort_keys=True,
    ).lower()
    hidden_event_ids = {
        event.event_id
        for registry in materialization.registries.values()
        for event in registry.events
    }
    match_rates = {
        key: _match_rate(materialization.registries[key], evaluation)
        for key, evaluation in trial.candidate_evaluations.items()
    }
    aliases = [event.alias for event in development_registry.events]
    progress = control.graph.progress_by_role()["objective"]
    checks = {
        "all_artifacts_round_trip_exactly": (
            bool(artifact_round_trip_checks)
            and all(artifact_round_trip_checks.values())
        ),
        "candidate_visible_events_lack_explicit_addresses": (
            all(
                item not in visible_event_text
                for item in (
                    "task_ref",
                    "object_ref",
                    "update_address",
                    "evaluator_family",
                )
            )
            and len(aliases) == len(set(aliases))
        ),
        "learned_model_is_bound_to_development_training_only": (
            candidate_freeze.model.training_set_id
            == training_set.training_set_id
            and training_set.development_registry_id
            == development_registry.registry_id
            and not hidden_event_ids.intersection(training_set.exposed_event_ids)
        ),
        "audit_materialized_after_frozen_model": (
            candidate_freeze.freeze_stage < materialization.materialization_stage
            and materialization.candidate_freeze_id == candidate_freeze.freeze_id
            and trial.candidate_freeze.freeze_id == candidate_freeze.freeze_id
        ),
        "all_preregistered_audit_checks_pass": trial.passed,
        "independent_reconstruction_matches_every_hidden_action": all(
            value == 1.0 for value in match_rates.values()
        ),
        "causal_swap_changes_only_the_two_target_addresses": (
            trial.causal_intervention.passed
            and set(trial.causal_intervention.changed_probe_ids)
            == set(trial.causal_intervention.target_probe_ids)
        ),
        "surface_and_recency_controls_remain_below_candidate": (
            min(
                item.joint_score
                for item in trial.candidate_evaluations.values()
            )
            > max(
                max(item.joint_score for item in trial.surface_evaluations.values()),
                max(item.joint_score for item in trial.recency_evaluations.values()),
            )
        ),
        "objective_graph_is_not_advanced_by_microdomain_evidence": (
            progress["integrated"] == 0
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    criteria = {
        "explicit_cross_channel_addresses_removed": checks[
            "candidate_visible_events_lack_explicit_addresses"
        ],
        "co_reference_policy_is_learned": (
            len(candidate_freeze.model.weights) > 0
            and candidate_freeze.model.training_steps > 0
            and candidate_freeze.model.weights
            != tuple(0.0 for _ in candidate_freeze.model.weights)
        ),
        "two_hidden_families_transfer_across_five_seeds": (
            trial.check_results["five_disjoint_seeds_per_hidden_family"]
            and trial.check_results["both_hidden_families_clear_floor"]
        ),
        "persistent_objects_survive_lag_64": (
            trial.aggregate_horizon_scores.get("64") == 1.0
        ),
        "addressing_has_selective_causal_effect": checks[
            "causal_swap_changes_only_the_two_target_addresses"
        ],
        "executable_schema_induction_is_learned_end_to_end": False,
        "co_reference_is_self_supervised": False,
        "naturalistic_language_or_code_transfer_is_demonstrated": False,
        "general_cognitive_core_is_demonstrated": False,
    }
    return LatentObjectVerification(
        check_results=checks,
        cognitive_core_criteria=criteria,
        independent_match_rates=match_rates,
        supported_claim=(
            "A learned behavioral co-reference policy formed and maintained "
            "persistent latent task objects without shared cross-channel IDs, "
            "surviving disjoint aliases, updates, distractors, and lag-64 audits."
        ),
        rejected_claims=(
            "the full cognitive core is solved",
            "object formation emerged without supervised co-reference labels",
            "the executable representation itself was learned end to end",
            "the result transfers to natural language, code, or external tasks",
        ),
        limitations=(
            "Behavioral locator examples act as content-based evidence for identity.",
            "The address scorer is learned, but the feature vocabulary is engineered.",
            "Typed program induction and mutation search remain frozen symbolic infrastructure.",
            "All replication is local and procedurally generated.",
        ),
    )
