from __future__ import annotations

import hashlib
import itertools
import json
import random
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_MODEL_SNAPSHOT,
    M50_OUTPUT_ALGEBRAS,
    M50_REPRESENTATIONS,
    _support,
    _task_signature,
)
from scientist.domains.cognitive_core.causal_controller_installation_v52 import (
    _slot_difference_targets,
    build_m52_cases,
)
from scientist.domains.cognitive_core.output_only_controller_v49 import (
    _task_lines,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.sequential_controller_validation_v52e import (
    M52E_M52_CHECKPOINT_SHA256,
    M52E_REPRESENTATIONS,
    M52E_STAGES,
    sequential_metrics,
)
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
)
from scientist.domains.cognitive_core.state_validity_installation_v52f import (
    build_m52f_trajectories,
)


LATENT_STATE_VALIDITY_VERSION = "general-cognitive-latent-state-validity-v52g"
M52G_SEED = 52739
M52G_SPLITS = ("train", "valid", "confirmation")
M52G_TRAJECTORIES_PER_REPRESENTATION = {
    "train": 5,
    "valid": 2,
    "confirmation": 5,
}
M52G_CONTEXTS = {
    "train": ("persistent",),
    "valid": ("persistent",),
    "confirmation": (
        "persistent",
        "current_only",
        "basis_rotated",
        "paraphrase",
    ),
}
M52G_REPRESENTATIONS = M52E_REPRESENTATIONS
M52G_M52F_RESULT_ID = (
    "4871594913586e594a27521ec4232228af365fb36d2915d8242a9d4d28d921bd"
)
M52G_M52F_GATE_SHA256 = (
    "bafb7e80ad738b7d7c1945237e4bb0c98d34ff6d6028a641ac20f96527fbeaab"
)


def _state(
    key: str,
    current: str,
    current_paraphrase: str,
    basis: str,
    basis_paraphrase: str,
) -> Mapping[str, str]:
    return {
        "key": key,
        "current": current,
        "current_paraphrase": current_paraphrase,
        "basis": basis,
        "basis_paraphrase": basis_paraphrase,
    }


M52G_STATE_FAMILIES: Mapping[str, Tuple[Mapping[str, str], ...]] = {
    "execution_order": (
        _state(
            "fixed_order",
            "Requests now arrive in a fixed, deterministic sequence.",
            "The request ordering is stable and repeatable.",
            "The conclusion presupposes a deterministic arrival order.",
            "This evidence assumes that request sequencing never varies.",
        ),
        _state(
            "random_order",
            "Requests now arrive in an independently randomized sequence.",
            "The request ordering is unpredictable from one run to the next.",
            "The conclusion presupposes randomly permuted arrivals.",
            "This evidence assumes that request sequence is freshly shuffled.",
        ),
        _state(
            "batched_order",
            "Requests now arrive as synchronized batches.",
            "Inputs are grouped into lockstep cohorts before processing.",
            "The conclusion presupposes cohort-wise batched arrivals.",
            "This evidence assumes that requests enter in synchronized groups.",
        ),
        _state(
            "priority_order",
            "Requests now arrive sorted by descending priority.",
            "Higher-urgency inputs always precede lower-urgency inputs.",
            "The conclusion presupposes priority-sorted arrivals.",
            "This evidence assumes that urgency determines the request sequence.",
        ),
    ),
    "feedback_regime": (
        _state(
            "immediate_feedback",
            "Each action now receives feedback immediately.",
            "Outcome signals are returned without delay after every decision.",
            "The conclusion presupposes instant per-action feedback.",
            "This evidence assumes that every decision is observed at once.",
        ),
        _state(
            "delayed_feedback",
            "Each action now receives feedback after a long delay.",
            "Outcome signals arrive many decisions after the action that caused them.",
            "The conclusion presupposes substantially delayed feedback.",
            "This evidence assumes that consequences are observed only much later.",
        ),
        _state(
            "aggregate_feedback",
            "Feedback now reports only one aggregate score per episode.",
            "Individual actions receive no signal; a summary arrives at episode end.",
            "The conclusion presupposes episode-level aggregate feedback.",
            "This evidence assumes that only a terminal summary score is observed.",
        ),
        _state(
            "asynchronous_feedback",
            "Feedback now arrives asynchronously and out of action order.",
            "Outcome signals return at irregular times unrelated to decision order.",
            "The conclusion presupposes asynchronous out-of-order feedback.",
            "This evidence assumes that observations return irregularly and unordered.",
        ),
    ),
    "resource_bottleneck": (
        _state(
            "memory_limited",
            "The active deployment is now limited primarily by memory capacity.",
            "Storage pressure, rather than arithmetic, is the dominant constraint.",
            "The conclusion presupposes a memory-bound operating regime.",
            "This evidence assumes that storage capacity is the binding resource.",
        ),
        _state(
            "compute_limited",
            "The active deployment is now limited primarily by computation.",
            "Arithmetic throughput, rather than storage, is the dominant constraint.",
            "The conclusion presupposes a compute-bound operating regime.",
            "This evidence assumes that processor throughput is the binding resource.",
        ),
        _state(
            "network_limited",
            "The active deployment is now limited primarily by network bandwidth.",
            "Data transfer capacity is the dominant operating constraint.",
            "The conclusion presupposes a communication-bound operating regime.",
            "This evidence assumes that network throughput is the binding resource.",
        ),
        _state(
            "energy_limited",
            "The active deployment is now limited primarily by its energy budget.",
            "Power consumption is the dominant operating constraint.",
            "The conclusion presupposes an energy-bound operating regime.",
            "This evidence assumes that available power is the binding resource.",
        ),
    ),
    "label_availability": (
        _state(
            "dense_labels",
            "Every training example now has a trusted label.",
            "Supervision is complete and reliable across the full training set.",
            "The conclusion presupposes dense, trustworthy supervision.",
            "This evidence assumes that all examples carry reliable targets.",
        ),
        _state(
            "sparse_labels",
            "Only a small fraction of training examples now have labels.",
            "Trusted targets are available for a sparse subset of the data.",
            "The conclusion presupposes sparsely labeled training data.",
            "This evidence assumes that supervision covers only a few examples.",
        ),
        _state(
            "no_labels",
            "Training examples now have no labels at all.",
            "The learning signal contains inputs without any supplied targets.",
            "The conclusion presupposes completely unlabeled training data.",
            "This evidence assumes that no example has an external target.",
        ),
        _state(
            "noisy_labels",
            "Training labels are now present but frequently incorrect.",
            "Supervision covers the data while containing substantial target corruption.",
            "The conclusion presupposes densely available but noisy labels.",
            "This evidence assumes widespread errors in the supplied targets.",
        ),
    ),
    "distribution_dynamics": (
        _state(
            "stationary_distribution",
            "Incoming examples now follow a stable stationary distribution.",
            "The population statistics remain effectively constant over time.",
            "The conclusion presupposes a data-generating process that does not drift.",
            "This evidence assumes time-invariant sampling statistics.",
        ),
        _state(
            "gradual_drift",
            "Incoming examples now undergo slow continuous distribution drift.",
            "Population statistics move incrementally as time advances.",
            "The conclusion presupposes a gradually drifting data-generating process.",
            "This evidence assumes that sampling statistics change smoothly over time.",
        ),
        _state(
            "seasonal_distribution",
            "Incoming examples now follow a repeating seasonal distribution cycle.",
            "Population statistics recur in a predictable periodic pattern.",
            "The conclusion presupposes periodically recurring distribution shifts.",
            "This evidence assumes that sampling statistics repeat on a fixed cycle.",
        ),
        _state(
            "adversarial_distribution",
            "Incoming examples now shift adversarially in response to the system.",
            "Population statistics are deliberately changed to exploit current behavior.",
            "The conclusion presupposes an adaptively adversarial data source.",
            "This evidence assumes that sampling changes strategically against the model.",
        ),
    ),
    "interface_contract": (
        _state(
            "strict_schema",
            "Tool responses now obey one strict schema with every field required.",
            "Each tool result has a fixed shape and contains all declared fields.",
            "The conclusion presupposes complete responses under a rigid interface contract.",
            "This evidence assumes a fixed response structure with no omitted fields.",
        ),
        _state(
            "optional_fields",
            "Tool responses now use a compatible schema with optional fields.",
            "The core response shape is stable, but auxiliary fields may be absent.",
            "The conclusion presupposes an interface whose nonessential fields are optional.",
            "This evidence assumes a stable core schema with permitted omissions.",
        ),
        _state(
            "partial_responses",
            "Tool responses now return arbitrary partial records.",
            "Any subset of response fields may be missing on a call.",
            "The conclusion presupposes incompletely populated response records.",
            "This evidence assumes that tool calls can omit arbitrary information.",
        ),
        _state(
            "reordered_stream",
            "Tool responses now arrive as fields in a reordered stream.",
            "Response content is complete, but field order varies during delivery.",
            "The conclusion presupposes complete fields delivered in variable order.",
            "This evidence assumes that response order changes while content remains complete.",
        ),
    ),
}

M52G_FAMILIES_BY_SPLIT = {
    "train": ("execution_order", "feedback_regime", "resource_bottleneck"),
    "valid": ("label_availability",),
    "confirmation": ("distribution_dynamics", "interface_contract"),
}


def _stable_seed(split: str, representation: str, source_index: int) -> int:
    material = f"{M52G_SEED}:{split}:{representation}:{source_index}"
    return int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)


def _two_candidate_task(
    split: str, representation: str, source_index: int
) -> Tuple[Any, Tuple[Any, ...], Tuple[Any, ...]] | None:
    rng = random.Random(_stable_seed(split, representation, source_index))
    source = _build_task(f"m52g_{split}", representation, source_index, rng)
    base = _m43_experiment_task(source)
    if base is None:
        return None
    candidates = sorted(base.frontier, key=lambda item: item.key)
    for left, right in itertools.combinations(candidates, 2):
        provisional = replace(base, frontier=(left, right))
        equal, unequal = _support(provisional)
        if equal and unequal:
            task_id = "m52g-task-" + content_digest(
                {
                    "split": split,
                    "representation": representation,
                    "source_index": source_index,
                    "frontier": [left.key, right.key],
                    "version": LATENT_STATE_VALIDITY_VERSION,
                }
            )[:24]
            return replace(provisional, task_id=task_id), equal, unequal
    return None


def _display_history(
    history: Sequence[Mapping[str, Any]], material: str
) -> Tuple[Mapping[str, Any], ...]:
    ordered = list(history)
    seed = int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(ordered)
    return tuple({**row, "slot": slot} for slot, row in enumerate(ordered, 1))


def _current_only_history(
    history: Sequence[Mapping[str, Any]], current_state_key: str
) -> Tuple[Mapping[str, Any], ...]:
    selected = [
        row for row in history if str(row["semantic_state"]) == current_state_key
    ]
    return tuple({**row, "slot": index} for index, row in enumerate(selected, 1))


def _basis_rotated_history(
    history: Sequence[Mapping[str, Any]], stage: int
) -> Tuple[Mapping[str, Any], ...]:
    if len(history) <= 1:
        return tuple(dict(row) for row in history)
    bases = [str(row["applicability_basis"]) for row in history]
    shift = 1 + (stage * 2) % (len(bases) - 1)
    rotated = bases[-shift:] + bases[:-shift]
    return tuple(
        {**row, "applicability_basis": basis}
        for row, basis in zip(history, rotated)
    )


def _paraphrase_history(
    history: Sequence[Mapping[str, Any]], states: Mapping[str, Mapping[str, str]]
) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        {
            **row,
            "applicability_basis": states[str(row["semantic_state"])][
                "basis_paraphrase"
            ],
        }
        for row in history
    )


def semantic_informative_slots(
    history: Sequence[Mapping[str, Any]], current_state_key: str
) -> Tuple[int, ...]:
    result = []
    for row in history:
        if str(row["semantic_state"]) != str(current_state_key):
            continue
        left, right = row["outputs"]
        if json.dumps(left, sort_keys=True, separators=(",", ":")) != json.dumps(
            right, sort_keys=True, separators=(",", ":")
        ):
            result.append(int(row["slot"]))
    return tuple(result)


def execute_semantic_action(
    history: Sequence[Mapping[str, Any]],
    action: int,
    phase: str,
    current_state_key: str,
) -> Mapping[str, Any]:
    informative = semantic_informative_slots(history, current_state_key)
    action = int(action)
    if phase == "pre_evidence":
        correct = action == 0 and not informative
        return {
            "phase": phase,
            "action": action,
            "informative_slots": list(informative),
            "transitioned": bool(correct),
            "terminal": not bool(correct),
            "success": False,
        }
    if phase not in ("post_evidence", "state_swap"):
        raise ValueError("unknown M52g phase")
    selected = action if 1 <= action <= len(history) else None
    success = selected is not None and selected in informative
    return {
        "phase": phase,
        "action": action,
        "informative_slots": list(informative),
        "selected_slot": selected,
        "transitioned": False,
        "terminal": True,
        "success": bool(success),
    }


def latent_validity_prompt(
    task: Any,
    history: Sequence[Mapping[str, Any]],
    current_state_text: str,
) -> str:
    lines = _task_lines(task)
    lines.extend(
        (
            f"Current research state: {current_state_text}",
            "Evidence is shown in display-slot order, not collection order.",
            "Evidence history:",
        )
    )
    for row in history:
        lines.append("  slot %d" % int(row["slot"]))
        lines.append("    Applicability basis: " + str(row["applicability_basis"]))
        lines.append("    experiment=" + json.dumps(row["experiment"]))
        lines.append("    c1_output=" + json.dumps(row["outputs"][0], sort_keys=True))
        lines.append("    c2_output=" + json.dumps(row["outputs"][1], sort_keys=True))
    lines.extend(
        (
            "Decide whether the available evidence supports a control decision in the current research state.",
            "Do not invent an experiment in this response.",
            "If a supporting slot achieves the goal, return exactly: SELECT: <slot number>",
            "If the evidence does not yet support selection, return exactly: REVISE",
        )
    )
    return "\n".join(lines)


def _prior_signatures() -> set[str]:
    result = {
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52_cases(split)
    }
    result.update(
        stage["task_signature"]
        for split in ("train", "valid", "confirmation")
        for trajectory in build_m52f_trajectories(split)
        for stage in trajectory["stages"]
    )
    return result


@lru_cache(maxsize=None)
def build_m52g_trajectories(
    split: str,
    representations: Tuple[str, ...] = M52G_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    if split not in M52G_SPLITS:
        raise ValueError(f"unknown M52g split: {split}")
    used = _prior_signatures()
    split_index = M52G_SPLITS.index(split)
    for earlier in M52G_SPLITS[:split_index]:
        used.update(
            trajectory["task_signature"]
            for trajectory in build_m52g_trajectories(
                earlier, M52G_REPRESENTATIONS
            )
        )
    trajectories = []
    count = M52G_TRAJECTORIES_PER_REPRESENTATION[split]
    families = M52G_FAMILIES_BY_SPLIT[split]
    for representation in representations:
        source_index = 0
        for trajectory_index in range(count):
            while True:
                candidate = _two_candidate_task(split, representation, source_index)
                source_index += 1
                if candidate is None:
                    if source_index > 30_000:
                        raise RuntimeError(
                            f"could not build M52g {split} {representation} tasks"
                        )
                    continue
                task, equal_values, unequal_values = candidate
                signature = _task_signature(task)
                if signature in used:
                    continue
                used.add(signature)
                break
            family_name = families[trajectory_index % len(families)]
            family = M52G_STATE_FAMILIES[family_name]
            state_lookup = {str(item["key"]): item for item in family}
            chronological = []
            stages = []
            for stage, state in zip(M52E_STAGES, family):
                equal_value = equal_values[(trajectory_index + stage) % len(equal_values)]
                evidence_value = unequal_values[
                    (trajectory_index * 3 + stage) % len(unequal_values)
                ]
                chronological.append(
                    {
                        "slot": len(chronological) + 1,
                        "semantic_state": state["key"],
                        "applicability_basis": state["basis"],
                        "experiment": equal_value,
                        "outputs": list(raw_candidate_outputs(task, equal_value)),
                    }
                )
                pre = _display_history(
                    chronological,
                    f"{split}:{representation}:{trajectory_index}:{stage}:pre",
                )
                chronological.append(
                    {
                        "slot": len(chronological) + 1,
                        "semantic_state": state["key"],
                        "applicability_basis": state["basis"],
                        "experiment": evidence_value,
                        "outputs": list(raw_candidate_outputs(task, evidence_value)),
                    }
                )
                post = _display_history(
                    chronological,
                    f"{split}:{representation}:{trajectory_index}:{stage}:post",
                )
                stages.append(
                    {
                        "stage": stage,
                        "state": dict(state),
                        "pre_evidence_history": pre,
                        "post_evidence_history": post,
                    }
                )
            trajectory_id = "m52g-trajectory-" + content_digest(
                {
                    "split": split,
                    "representation": representation,
                    "trajectory_index": trajectory_index,
                    "task_signature": signature,
                    "family": family_name,
                    "version": LATENT_STATE_VALIDITY_VERSION,
                }
            )[:24]
            trajectories.append(
                {
                    "trajectory_id": trajectory_id,
                    "representation": representation,
                    "output_algebra": M50_OUTPUT_ALGEBRAS[representation],
                    "task": task,
                    "task_signature": signature,
                    "family": family_name,
                    "state_lookup": state_lookup,
                    "stages": tuple(stages),
                }
            )
    return tuple(trajectories)


def _row(
    *,
    split: str,
    trajectory: Mapping[str, Any],
    stage: int,
    phase: str,
    context: str,
    prompt_history: Sequence[Mapping[str, Any]],
    environment_history: Sequence[Mapping[str, Any]],
    current_state_key: str,
    current_state_text: str,
) -> Mapping[str, Any]:
    informative = semantic_informative_slots(environment_history, current_state_key)
    expected_action = 0 if phase == "pre_evidence" else informative[0]
    record_id = "m52g-record-" + content_digest(
        {
            "split": split,
            "trajectory_id": trajectory["trajectory_id"],
            "stage": stage,
            "phase": phase,
            "context": context,
            "current_state_key": current_state_key,
            "version": LATENT_STATE_VALIDITY_VERSION,
        }
    )[:24]
    return {
        "prompt": latent_validity_prompt(
            trajectory["task"], prompt_history, current_state_text
        ),
        "metadata": {
            "record_id": record_id,
            "split": split,
            "trajectory_id": trajectory["trajectory_id"],
            "stage": stage,
            "phase": phase,
            "context_variant": context,
            "current_state_key": current_state_key,
            "current_state_text": current_state_text,
            "family": trajectory["family"],
            "task_id": trajectory["task"].task_id,
            "task_signature": trajectory["task_signature"],
            "representation": trajectory["representation"],
            "output_algebra": trajectory["output_algebra"],
            "prefix_length": len(prompt_history),
            "prompt_history": list(prompt_history),
            "environment_history": list(environment_history),
            "slot_difference_targets": list(_slot_difference_targets(prompt_history)),
            "slot_validity_targets": [
                int(str(item["semantic_state"]) == current_state_key)
                for item in prompt_history
            ],
            "action_target": int(expected_action),
            "stale_informative_slots": [
                int(item["slot"])
                for item in environment_history
                if str(item["semantic_state"]) != current_state_key
                and json.dumps(item["outputs"][0], sort_keys=True, separators=(",", ":"))
                != json.dumps(item["outputs"][1], sort_keys=True, separators=(",", ":"))
            ],
        },
    }


def build_m52g_rows(
    split: str,
    representations: Tuple[str, ...] = M52G_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for trajectory in build_m52g_trajectories(split, representations):
        for stage_state in trajectory["stages"]:
            stage = int(stage_state["stage"])
            state = stage_state["state"]
            state_key = str(state["key"])
            for phase, persistent in (
                ("pre_evidence", stage_state["pre_evidence_history"]),
                ("post_evidence", stage_state["post_evidence_history"]),
            ):
                contexts = {
                    "persistent": (
                        persistent,
                        persistent,
                        state["current"],
                    ),
                    "current_only": (
                        _current_only_history(persistent, state_key),
                        _current_only_history(persistent, state_key),
                        state["current"],
                    ),
                    "basis_rotated": (
                        _basis_rotated_history(persistent, stage),
                        persistent,
                        state["current"],
                    ),
                    "paraphrase": (
                        _paraphrase_history(persistent, trajectory["state_lookup"]),
                        persistent,
                        state["current_paraphrase"],
                    ),
                }
                for context in M52G_CONTEXTS[split]:
                    prompt_history, environment_history, current_text = contexts[context]
                    rows.append(
                        _row(
                            split=split,
                            trajectory=trajectory,
                            stage=stage,
                            phase=phase,
                            context=context,
                            prompt_history=prompt_history,
                            environment_history=environment_history,
                            current_state_key=state_key,
                            current_state_text=current_text,
                        )
                    )
            if split == "confirmation" and stage > 1:
                prior_stage = 1 + ((stage + len(trajectory["trajectory_id"])) % (stage - 1))
                prior_state = trajectory["stages"][prior_stage - 1]["state"]
                persistent = stage_state["pre_evidence_history"]
                rows.append(
                    _row(
                        split=split,
                        trajectory=trajectory,
                        stage=stage,
                        phase="state_swap",
                        context="state_swapped",
                        prompt_history=persistent,
                        environment_history=persistent,
                        current_state_key=str(prior_state["key"]),
                        current_state_text=str(prior_state["current_paraphrase"]),
                    )
                )
    return tuple(rows)


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52g artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json_payload(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def _jsonl_payload(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    m52f_root = project / "runs/cognitive_core/state_validity_installation_v52f"
    m52f_result = json.loads((m52f_root / "state-validity-result.json").read_text())
    m52_checkpoint = (
        project
        / "runs/cognitive_core/causal_controller_installation_v52/adapter/"
        "0000160_adapters.safetensors"
    )
    m52f_gate = m52f_root / "gate/selected_gate.safetensors"
    return {
        "version": LATENT_STATE_VALIDITY_VERSION,
        "parent_version": "general-cognitive-state-validity-installation-v52f",
        "scientific_question": (
            "Can the internal validity controller infer applicability from semantic state "
            "changes without scope identifiers, recency labels, or an explicit validity rule?"
        ),
        "seed": M52G_SEED,
        "representations": list(M52G_REPRESENTATIONS),
        "stages": list(M52E_STAGES),
        "families_by_split": {
            key: list(value) for key, value in M52G_FAMILIES_BY_SPLIT.items()
        },
        "trajectories_per_representation": dict(M52G_TRAJECTORIES_PER_REPRESENTATION),
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "m52_checkpoint_source": (
                "runs/cognitive_core/causal_controller_installation_v52/adapter/"
                "0000160_adapters.safetensors"
            ),
            "m52_checkpoint_sha256": _sha256(m52_checkpoint),
            "m52f_gate_source": (
                "runs/cognitive_core/state_validity_installation_v52f/gate/"
                "selected_gate.safetensors"
            ),
            "m52f_gate_sha256": _sha256(m52f_gate),
            "m52f_result_id": m52f_result["result_id"],
            "m52f_passed": bool(m52f_result["milestone_passed"]),
        },
        "architecture_contract": {
            "causal_layer": 14,
            "frozen_components": [
                "Qwen2.5-1.5B backbone",
                "M47 LoRA policy",
                "M52 difference scorer and pointer",
                "M52f validity actuator",
                "language decoder",
            ],
            "trainable_component": (
                "the eight-tensor semantic validity head initialized from M52f"
            ),
            "semantic_inputs": (
                "layer-14 hidden states at natural-language evidence assumptions and the "
                "current research-state description"
            ),
            "explicit_scope_identifiers": False,
            "chronology_or_turn_labels": False,
            "explicit_validity_rule": False,
            "heldout_confirmation_transition_families": True,
            "language_decoder_calls": 0,
        },
        "training_recipe": {
            "seed": M52G_SEED,
            "initialization": "M52f selected validity gate",
            "gate_width": 32,
            "validity_penalty_scale": 4.0,
            "learning_rate": 0.001,
            "iterations": 1600,
            "checkpoint_candidates": [400, 800, 1200, 1600],
            "loss": (
                "semantic slot-validity binary cross entropy plus frozen-pointer action cross entropy"
            ),
            "checkpoint_selection": (
                "highest validation action accuracy, then validity accuracy, then earliest checkpoint"
            ),
            "confirmation_access_during_selection": False,
        },
        "confirmation_controls": {
            "current_only": "remove all semantically obsolete evidence",
            "paraphrase": "replace state and basis descriptions with unseen semantic paraphrases",
            "basis_rotated": "rotate only evidence applicability descriptions",
            "validity_rotated": "rotate only inferred validity logits",
            "state_swapped": (
                "replace only the current state with a paraphrase matching prior evidence"
            ),
            "m52_baseline": "remove semantic validity penalties",
            "oracle_validity": "use true semantic applicability with the same actuator",
        },
        "confirmation_contract": {
            "minimum_persistent_decision_accuracy": 0.88,
            "minimum_persistent_stage_success": 0.80,
            "minimum_persistent_trajectory_success": 0.60,
            "minimum_each_representation_stage_success": 0.70,
            "minimum_each_later_stage_recovery_accuracy": 0.85,
            "minimum_terminal_select_accuracy": 0.85,
            "minimum_current_only_stage_success": 0.95,
            "minimum_semantic_validity_accuracy": 0.85,
            "minimum_paraphrase_decision_accuracy": 0.85,
            "minimum_paraphrase_action_agreement": 0.85,
            "minimum_state_swap_target_accuracy": 0.80,
            "minimum_state_swap_flip_rate": 0.80,
            "minimum_gain_over_m52_baseline": 0.45,
            "minimum_gain_over_basis_rotated": 0.25,
            "minimum_gain_over_validity_rotated": 0.30,
            "minimum_oracle_stage_success": 0.92,
            "require_m52_checkpoint_unchanged": True,
            "require_zero_trainable_base_tensors": True,
        },
        "integrity_contract": {
            "mechanisms_disjoint_from_all_prior_milestones_and_across_splits": True,
            "transition_families_disjoint_across_splits": True,
            "confirmation_evaluated_once_after_validation_selection": True,
            "state_swap_preserves_task_evidence_and_display_positions": True,
            "paraphrase_preserves_semantic_targets": True,
            "basis_rotation_preserves_task_evidence_and_positions": True,
            "terminal_outcomes_recomputed_from_semantic_applicability": True,
        },
        "claim_boundary": (
            "M52g tests semantic applicability inference on held-out synthetic state-"
            "transition families. Passing would not establish endogenous state discovery, "
            "natural-task transfer, autonomous tool use, or general reasoning parity."
        ),
    }


def prepare_m52g_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol_payload = _protocol_payload(project)
    protocol = {**protocol_payload, "protocol_freeze_id": content_digest(protocol_payload)}
    _write_immutable(output / "protocol-freeze.json", _json_payload(protocol))
    hashes = {}
    counts = {}
    for split in M52G_SPLITS:
        rows = build_m52g_rows(split)
        hashes[split] = _write_immutable(
            output / f"controller/{split}.jsonl", _jsonl_payload(rows)
        )
        counts[split] = len(rows)
    payload = {**protocol, "hashes": hashes, "counts": counts}
    freeze = {**payload, "freeze_id": content_digest(payload)}
    _write_immutable(output / "benchmark-freeze.json", _json_payload(freeze))
    verification = verify_m52g_benchmark(output, project)
    _write_immutable(output / "benchmark-verification.json", _json_payload(verification))
    return freeze


def _rows(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(json.loads(line) for line in path.read_text().splitlines() if line)


def verify_m52g_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol_payload = {
        key: value for key, value in protocol.items() if key != "protocol_freeze_id"
    }
    freeze_payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    stored = {
        split: _rows(output / f"controller/{split}.jsonl") for split in M52G_SPLITS
    }
    signatures = {
        split: {row["metadata"]["task_signature"] for row in rows}
        for split, rows in stored.items()
    }
    prior = _prior_signatures()
    semantics_valid = True
    controls_valid = True
    forbidden_absent = True
    for rows in stored.values():
        for row in rows:
            metadata = row["metadata"]
            history = metadata["prompt_history"]
            expected_validity = [
                int(str(item["semantic_state"]) == metadata["current_state_key"])
                for item in history
            ]
            semantics_valid = semantics_valid and (
                expected_validity == metadata["slot_validity_targets"]
                and len(history) == metadata["prefix_length"]
            )
            replay = execute_semantic_action(
                metadata["environment_history"],
                int(metadata["action_target"]),
                metadata["phase"],
                metadata["current_state_key"],
            )
            semantics_valid = semantics_valid and bool(
                replay["transitioned"]
                if metadata["phase"] == "pre_evidence"
                else replay["success"]
            )
            forbidden_absent = forbidden_absent and all(
                marker not in row["prompt"]
                for marker in ("scope_id", "scope_stage", "turn=", "valid only when")
            )
            if metadata["context_variant"] in (
                "basis_rotated",
                "paraphrase",
                "state_swapped",
            ):
                controls_valid = controls_valid and [
                    (item["slot"], item["experiment"], item["outputs"])
                    for item in metadata["prompt_history"]
                ] == [
                    (item["slot"], item["experiment"], item["outputs"])
                    for item in metadata["environment_history"]
                ]
    m52_checkpoint = project / freeze["frozen_model"]["m52_checkpoint_source"]
    m52f_gate = project / freeze["frozen_model"]["m52f_gate_source"]
    m52f_result = json.loads(
        (
            project
            / "runs/cognitive_core/state_validity_installation_v52f/"
            "state-validity-result.json"
        ).read_text()
    )
    checks = {
        "protocol_id_is_content_derived": content_digest(protocol_payload)
        == protocol["protocol_freeze_id"],
        "freeze_id_is_content_derived": content_digest(freeze_payload)
        == freeze["freeze_id"],
        "stored_rows_reproduce": all(
            stored[split] == build_m52g_rows(split) for split in M52G_SPLITS
        ),
        "file_hashes_match": all(
            _sha256(output / f"controller/{split}.jsonl")
            == freeze["hashes"][split]
            for split in M52G_SPLITS
        ),
        "counts_match": all(
            len(stored[split]) == freeze["counts"][split] for split in M52G_SPLITS
        ),
        "prior_mechanisms_excluded": all(
            not bool(signatures[split] & prior) for split in M52G_SPLITS
        ),
        "mechanism_splits_disjoint": all(
            not bool(signatures[left] & signatures[right])
            for index, left in enumerate(M52G_SPLITS)
            for right in M52G_SPLITS[index + 1 :]
        ),
        "transition_families_disjoint": all(
            not bool(
                set(M52G_FAMILIES_BY_SPLIT[left])
                & set(M52G_FAMILIES_BY_SPLIT[right])
            )
            for index, left in enumerate(M52G_SPLITS)
            for right in M52G_SPLITS[index + 1 :]
        ),
        "semantic_targets_and_terminal_actions_replay": semantics_valid,
        "controls_preserve_task_evidence_and_positions": controls_valid,
        "explicit_scope_and_chronology_markers_absent": forbidden_absent,
        "m52_checkpoint_matches": _sha256(m52_checkpoint)
        == freeze["frozen_model"]["m52_checkpoint_sha256"]
        == M52E_M52_CHECKPOINT_SHA256,
        "m52f_parent_matches": (
            _sha256(m52f_gate)
            == freeze["frozen_model"]["m52f_gate_sha256"]
            == M52G_M52F_GATE_SHA256
            and m52f_result["result_id"]
            == freeze["frozen_model"]["m52f_result_id"]
            == M52G_M52F_RESULT_ID
            and m52f_result["milestone_passed"]
        ),
    }
    return {
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def semantic_validity_metrics(
    predictions: Sequence[Mapping[str, Any]], context: str = "persistent"
) -> Mapping[str, Any]:
    rows = [row for row in predictions if row["context_variant"] == context]

    def summarize(selected: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
        correct = sum(int(value) for row in selected for value in row["validity_correct"])
        total = sum(len(row["validity_correct"]) for row in selected)
        return {"slot_count": total, "accuracy": correct / max(total, 1)}

    return {
        **summarize(rows),
        "by_representation": {
            representation: summarize(
                [row for row in rows if row["representation"] == representation]
            )
            for representation in M52G_REPRESENTATIONS
        },
        "by_family": {
            family: summarize([row for row in rows if row["family"] == family])
            for family in M52G_FAMILIES_BY_SPLIT["confirmation"]
        },
    }


def state_swap_metrics(
    predictions: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    normal = {
        (row["trajectory_id"], int(row["stage"])): row
        for row in predictions
        if row["context_variant"] == "persistent" and row["phase"] == "pre_evidence"
    }
    swaps = [row for row in predictions if row["context_variant"] == "state_swapped"]
    correct = sum(bool(row["semantic_success"]) for row in swaps)
    flips = sum(
        int(row["learned_action"])
        != int(normal[(row["trajectory_id"], int(row["stage"]))]["learned_action"])
        for row in swaps
    )
    return {
        "record_count": len(swaps),
        "target_accuracy": correct / max(len(swaps), 1),
        "action_flip_rate": flips / max(len(swaps), 1),
        "records": swaps,
    }


def paraphrase_agreement(
    predictions: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    persistent = {
        (row["trajectory_id"], int(row["stage"]), row["phase"]): row
        for row in predictions
        if row["context_variant"] == "persistent"
    }
    paraphrases = [
        row for row in predictions if row["context_variant"] == "paraphrase"
    ]
    agreement = sum(
        int(row["learned_action"])
        == int(
            persistent[(row["trajectory_id"], int(row["stage"]), row["phase"])][
                "learned_action"
            ]
        )
        for row in paraphrases
    )
    return {
        "record_count": len(paraphrases),
        "action_agreement": agreement / max(len(paraphrases), 1),
    }


def select_m52g_checkpoint(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    if not candidates:
        raise ValueError("M52g checkpoint selection requires candidates")
    return sorted(
        candidates,
        key=lambda row: (
            -float(row["action_accuracy"]),
            -float(row["validity_accuracy"]),
            int(row["iteration"]),
        ),
    )[0]


def m52g_passed(
    learned: Mapping[str, Any],
    current_only: Mapping[str, Any],
    paraphrase: Mapping[str, Any],
    basis_rotated: Mapping[str, Any],
    validity_rotated: Mapping[str, Any],
    baseline: Mapping[str, Any],
    oracle: Mapping[str, Any],
    validity: Mapping[str, Any],
    swap: Mapping[str, Any],
    agreement: Mapping[str, Any],
    contract: Mapping[str, Any],
    *,
    base_trainable_tensor_count: int,
    m52_checkpoint_unchanged: bool,
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "persistent_decision_accuracy": learned["decision_accuracy"]
        >= contract["minimum_persistent_decision_accuracy"],
        "persistent_stage_success": learned["stage_success"]
        >= contract["minimum_persistent_stage_success"],
        "persistent_trajectory_success": learned["trajectory_success"]
        >= contract["minimum_persistent_trajectory_success"],
        "each_representation_stage_success": min(
            row["stage_success"] for row in learned["by_representation"].values()
        )
        >= contract["minimum_each_representation_stage_success"],
        "each_later_stage_recovery_accuracy": min(
            learned["by_stage"][str(stage)]["pre_evidence_revise_accuracy"]
            for stage in M52E_STAGES
            if stage > 1
        )
        >= contract["minimum_each_later_stage_recovery_accuracy"],
        "terminal_select_accuracy": learned["post_evidence_select_accuracy"]
        >= contract["minimum_terminal_select_accuracy"],
        "current_only_stage_success": current_only["stage_success"]
        >= contract["minimum_current_only_stage_success"],
        "semantic_validity_accuracy": validity["accuracy"]
        >= contract["minimum_semantic_validity_accuracy"],
        "paraphrase_decision_accuracy": paraphrase["decision_accuracy"]
        >= contract["minimum_paraphrase_decision_accuracy"],
        "paraphrase_action_agreement": agreement["action_agreement"]
        >= contract["minimum_paraphrase_action_agreement"],
        "state_swap_target_accuracy": swap["target_accuracy"]
        >= contract["minimum_state_swap_target_accuracy"],
        "state_swap_flip_rate": swap["action_flip_rate"]
        >= contract["minimum_state_swap_flip_rate"],
        "gain_over_m52_baseline": learned["stage_success"]
        - baseline["stage_success"]
        >= contract["minimum_gain_over_m52_baseline"],
        "gain_over_basis_rotated": learned["stage_success"]
        - basis_rotated["stage_success"]
        >= contract["minimum_gain_over_basis_rotated"],
        "gain_over_validity_rotated": learned["stage_success"]
        - validity_rotated["stage_success"]
        >= contract["minimum_gain_over_validity_rotated"],
        "oracle_stage_success": oracle["stage_success"]
        >= contract["minimum_oracle_stage_success"],
        "zero_trainable_base_tensors": (
            base_trainable_tensor_count == 0
            if contract["require_zero_trainable_base_tensors"]
            else True
        ),
        "m52_checkpoint_unchanged": (
            m52_checkpoint_unchanged
            if contract["require_m52_checkpoint_unchanged"]
            else True
        ),
    }
    return all(checks.values()), checks


def latent_metrics(
    records: Sequence[Mapping[str, Any]], condition: str
) -> Mapping[str, Any]:
    return sequential_metrics(records, condition)
