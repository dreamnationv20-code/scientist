from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
import platform
import time
from typing import Any, Dict, List, Mapping, Tuple

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.concept_architecture_trial_v5 import (
    TRIAL_ARMS,
    ConceptArchitectureArm,
)
from scientist.domains.cognitive_core.learning import (
    EncodedExample,
    LearningConfig,
    TrainingCondition,
    encode_memory,
    fact_keys,
    fact_label,
    training_batch,
    update_label,
)
from scientist.domains.cognitive_core.mlx_lab import TinyCognitiveTransformer
from scientist.kernel.contracts import EvidencePartition


LEARNED_LOCALITY_TRIAL_VERSION = "cognitive-core-learned-locality-trial-v6"
LEARNED_LOCALITY_EVALUATOR_REF = "learned-locality-mlx-evaluator-v6"


@dataclass(frozen=True)
class LearnedLocalityPartition:
    partition: EvidencePartition
    data_seed: int

    def __post_init__(self) -> None:
        if self.partition not in (
            EvidencePartition.AUDIT,
            EvidencePartition.REPLICATION,
        ):
            raise ValueError("learned locality requires audit or replication")
        if self.data_seed <= 0:
            raise ValueError("learned locality data seed must be positive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "partition": self.partition.value,
            "data_seed": self.data_seed,
        }


@dataclass(frozen=True)
class FrozenLearnedLocalityRegistry:
    source_generation_revision_id: str
    source_architecture_trial_id: str
    factor_hypothesis_id: str
    protection_hypothesis_id: str
    partitions: Tuple[LearnedLocalityPartition, ...]
    model_seeds: Tuple[int, ...]
    fact_count: int
    width: int
    layers: int
    heads: int
    steps: int
    batch_size: int
    learning_rate: float
    checkpoint_interval: int
    minimum_target_accuracy: float
    minimum_target_improvement: float
    minimum_retention_delta: float
    minimum_joint_improvement: float
    minimum_seed_consistency: float
    required_checks: Tuple[str, ...]
    registrar_ref: str

    def __post_init__(self) -> None:
        required = (
            self.source_generation_revision_id,
            self.source_architecture_trial_id,
            self.factor_hypothesis_id,
            self.protection_hypothesis_id,
            self.partitions,
            self.model_seeds,
            self.required_checks,
            self.registrar_ref,
        )
        if not all(required):
            raise ValueError("learned locality registry is incomplete")
        if len(self.partitions) != 2 or len(
            {item.partition for item in self.partitions}
        ) != 2:
            raise ValueError("learned locality requires two distinct partitions")
        if len({item.data_seed for item in self.partitions}) != 2:
            raise ValueError("learned locality partition data must be disjoint")
        if len(self.model_seeds) < 8 or len(set(self.model_seeds)) != len(
            self.model_seeds
        ):
            raise ValueError("learned locality requires eight unique model seeds")
        if min(
            self.fact_count,
            self.width,
            self.layers,
            self.heads,
            self.steps,
            self.batch_size,
            self.checkpoint_interval,
        ) <= 0:
            raise ValueError("learned locality training dimensions are invalid")
        if self.fact_count % 2:
            raise ValueError("learned locality requires paired fact keys")
        for value in (
            self.minimum_target_accuracy,
            self.minimum_target_improvement,
            self.minimum_seed_consistency,
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError("learned locality probability floor is invalid")
        for value in (
            self.minimum_retention_delta,
            self.minimum_joint_improvement,
        ):
            if not -1.0 <= value <= 1.0:
                raise ValueError("learned locality effect floor is invalid")

    def config(self, partition: LearnedLocalityPartition, seed: int) -> LearningConfig:
        if seed not in self.model_seeds or partition not in self.partitions:
            raise ValueError("configuration is outside the frozen registry")
        return LearningConfig(
            condition=TrainingCondition.RANDOM_FACTS,
            fact_count=self.fact_count,
            width=self.width,
            layers=self.layers,
            heads=self.heads,
            steps=self.steps,
            batch_size=self.batch_size,
            learning_rate=self.learning_rate,
            model_seed=seed,
            data_seed=partition.data_seed,
            checkpoint_interval=self.checkpoint_interval,
            compute_device="cpu",
            evidence_schedule="balanced",
            relevance_annotation=False,
        )

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LEARNED_LOCALITY_TRIAL_VERSION,
            "source_generation_revision_id": self.source_generation_revision_id,
            "source_architecture_trial_id": self.source_architecture_trial_id,
            "factor_hypothesis_id": self.factor_hypothesis_id,
            "protection_hypothesis_id": self.protection_hypothesis_id,
            "partitions": [item.as_dict() for item in self.partitions],
            "model_seeds": list(self.model_seeds),
            "fact_count": self.fact_count,
            "width": self.width,
            "layers": self.layers,
            "heads": self.heads,
            "steps": self.steps,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "checkpoint_interval": self.checkpoint_interval,
            "minimum_target_accuracy": self.minimum_target_accuracy,
            "minimum_target_improvement": self.minimum_target_improvement,
            "minimum_retention_delta": self.minimum_retention_delta,
            "minimum_joint_improvement": self.minimum_joint_improvement,
            "minimum_seed_consistency": self.minimum_seed_consistency,
            "required_checks": list(self.required_checks),
            "registrar_ref": self.registrar_ref,
        }
        if include_id:
            value["registry_id"] = self.registry_id
        return value


def frozen_learned_locality_registry(
    *,
    source_generation_revision_id: str,
    source_architecture_trial_id: str,
    factor_hypothesis_id: str,
    protection_hypothesis_id: str,
) -> FrozenLearnedLocalityRegistry:
    return FrozenLearnedLocalityRegistry(
        source_generation_revision_id=source_generation_revision_id,
        source_architecture_trial_id=source_architecture_trial_id,
        factor_hypothesis_id=factor_hypothesis_id,
        protection_hypothesis_id=protection_hypothesis_id,
        partitions=(
            LearnedLocalityPartition(EvidencePartition.AUDIT, 20260818),
            LearnedLocalityPartition(EvidencePartition.REPLICATION, 20260819),
        ),
        model_seeds=tuple(range(20, 28)),
        fact_count=64,
        width=48,
        layers=2,
        heads=4,
        steps=800,
        batch_size=80,
        learning_rate=0.001,
        checkpoint_interval=200,
        minimum_target_accuracy=0.95,
        minimum_target_improvement=0.50,
        minimum_retention_delta=-0.01,
        minimum_joint_improvement=0.25,
        minimum_seed_consistency=0.75,
        required_checks=(
            "source_factor_and_protection_hypotheses_are_bound",
            "fresh_model_and_data_seeds_are_used",
            "training_plan_is_shared_within_partition",
            "initializations_are_distinct_across_model_seeds",
            "one_trained_model_is_shared_by_all_arms_within_seed",
            "complete_partition_seed_episode_arm_matrix",
            "update_events_exclude_post_update_query_targets",
            "baseline_and_sham_predictions_are_exact",
            "resource_ledgers_are_matched_across_arms",
            "independent_retraining_spot_checks_pass",
            "all_case_outcomes_are_independently_reconstructed",
            "combined_target_accuracy_floor_passes",
            "combined_target_improvement_floor_passes",
            "combined_retention_non_regression_passes",
            "combined_joint_improvement_floor_passes",
            "unscoped_factor_harms_retention",
            "locality_gate_repairs_retention_without_losing_update",
            "target_and_retention_seed_consistency_passes",
            "audit_and_replication_dispositions_agree",
        ),
        registrar_ref="cognitive-core-learned-locality-registry-v6",
    )


@dataclass(frozen=True)
class LearnedTrainingPlan:
    batches: Tuple[Tuple[EncodedExample, ...], ...]
    ordered_digest: str
    multiset_digest: str
    example_count: int


def build_learned_training_plan(config: LearningConfig) -> LearnedTrainingPlan:
    batches = tuple(training_batch(config, step) for step in range(config.steps))
    digests = tuple(
        content_digest(
            {
                "tokens": list(example.tokens),
                "label": example.label,
                "family": example.family,
                "pair_id": example.pair_id,
            }
        )
        for batch in batches
        for example in batch
    )
    return LearnedTrainingPlan(
        batches=batches,
        ordered_digest=content_digest(digests),
        multiset_digest=content_digest(sorted(digests)),
        example_count=len(digests),
    )


def _parameter_digest(model: TinyCognitiveTransformer) -> str:
    digest = hashlib.sha256()
    for name, array in tree_flatten(model.parameters()):
        mx.eval(array)
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(array.shape)).encode("ascii"))
        digest.update(repr(array.tolist()).encode("utf-8"))
    return digest.hexdigest()


def _parameter_count(model: TinyCognitiveTransformer) -> int:
    return sum(
        math.prod(array.shape)
        for _, array in tree_flatten(model.parameters())
    )


def _arrays(examples: Tuple[EncodedExample, ...]) -> Tuple[mx.array, mx.array]:
    return (
        mx.array([item.tokens for item in examples], dtype=mx.int32),
        mx.array([item.label for item in examples], dtype=mx.int32),
    )


def _predict(
    model: TinyCognitiveTransformer,
    examples: Tuple[EncodedExample, ...],
) -> Tuple[int, ...]:
    model.eval()
    tokens, _ = _arrays(examples)
    values = mx.argmax(model(tokens), axis=-1)
    mx.eval(values)
    model.train()
    return tuple(int(item) for item in values.tolist())


def _train_model(
    config: LearningConfig,
    plan: LearnedTrainingPlan,
) -> Tuple[TinyCognitiveTransformer, str, str, int, float, float]:
    started = time.monotonic()
    mx.set_default_device(mx.cpu)
    mx.random.seed(config.model_seed)
    model = TinyCognitiveTransformer(config)
    mx.eval(model.parameters())
    initial_digest = _parameter_digest(model)
    parameter_count = _parameter_count(model)
    optimizer = optim.AdamW(
        learning_rate=config.learning_rate,
        weight_decay=0.0001,
    )

    def loss_fn(
        active_model: TinyCognitiveTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    model.train()
    for batch in plan.batches:
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
    final_digest = _parameter_digest(model)
    return (
        model,
        initial_digest,
        final_digest,
        parameter_count,
        last_loss,
        time.monotonic() - started,
    )


@dataclass(frozen=True)
class LearnedLocalityTrace:
    registry_id: str
    partition: EvidencePartition
    data_seed: int
    model_seed: int
    episode_index: int
    arm_id: str
    target_key: int
    retention_key: int
    update_value: int
    base_target_prediction: int
    base_retention_prediction: int
    target_prediction: int
    retention_prediction: int
    target_correct: bool
    retention_correct: bool
    event_input_digest: str
    resource_signature: str
    evaluator_ref: str = LEARNED_LOCALITY_EVALUATOR_REF

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LEARNED_LOCALITY_TRIAL_VERSION,
            "registry_id": self.registry_id,
            "partition": self.partition.value,
            "data_seed": self.data_seed,
            "model_seed": self.model_seed,
            "episode_index": self.episode_index,
            "arm_id": self.arm_id,
            "target_key": self.target_key,
            "retention_key": self.retention_key,
            "update_value": self.update_value,
            "base_target_prediction": self.base_target_prediction,
            "base_retention_prediction": self.base_retention_prediction,
            "target_prediction": self.target_prediction,
            "retention_prediction": self.retention_prediction,
            "target_correct": self.target_correct,
            "retention_correct": self.retention_correct,
            "joint_correct": self.target_correct and self.retention_correct,
            "event_input_digest": self.event_input_digest,
            "resource_signature": self.resource_signature,
            "evaluator_ref": self.evaluator_ref,
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


@dataclass(frozen=True)
class LearnedLocalityRun:
    registry_id: str
    partition: EvidencePartition
    config: LearningConfig
    initial_parameter_digest: str
    final_parameter_digest: str
    parameter_count: int
    training_order_digest: str
    training_multiset_digest: str
    training_example_count: int
    evaluation_digest: str
    resource_ledger: Mapping[str, float]
    traces: Tuple[LearnedLocalityTrace, ...]
    final_training_loss: float
    elapsed_seconds: float
    framework: str = "mlx-0.32"
    hardware: str = platform.machine() + ":cpu"

    @property
    def run_id(self) -> str:
        # Scientific identity must not depend on wall-clock timing.  The
        # parameter and evaluation digests already bind the learned outcome.
        return content_digest(
            {
                "version": LEARNED_LOCALITY_TRIAL_VERSION,
                "registry_id": self.registry_id,
                "partition": self.partition.value,
                "config": self.config.as_dict(),
                "initial_parameter_digest": self.initial_parameter_digest,
                "final_parameter_digest": self.final_parameter_digest,
                "training_order_digest": self.training_order_digest,
                "training_multiset_digest": self.training_multiset_digest,
                "evaluation_digest": self.evaluation_digest,
                "resource_ledger": dict(sorted(self.resource_ledger.items())),
                "final_training_loss": self.final_training_loss,
                "framework": self.framework,
                "hardware": self.hardware,
            }
        )[:20]

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LEARNED_LOCALITY_TRIAL_VERSION,
            "registry_id": self.registry_id,
            "partition": self.partition.value,
            "config": self.config.as_dict(),
            "initial_parameter_digest": self.initial_parameter_digest,
            "final_parameter_digest": self.final_parameter_digest,
            "parameter_count": self.parameter_count,
            "training_order_digest": self.training_order_digest,
            "training_multiset_digest": self.training_multiset_digest,
            "training_example_count": self.training_example_count,
            "evaluation_digest": self.evaluation_digest,
            "resource_ledger": dict(sorted(self.resource_ledger.items())),
            "traces": [trace.as_dict() for trace in self.traces],
            "final_training_loss": self.final_training_loss,
            "elapsed_seconds": self.elapsed_seconds,
            "framework": self.framework,
            "hardware": self.hardware,
        }
        if include_id:
            value["run_id"] = self.run_id
        return value


def _arm_predictions(
    arm: ConceptArchitectureArm,
    *,
    update_value: int,
    base_target: int,
    base_retention: int,
) -> Tuple[int, int]:
    # All candidate branches are materialized before the frozen arm gates select
    # one. This keeps module allocation and nominal post-training work matched.
    unscoped = (update_value, update_value)
    scoped = (update_value, base_retention)
    baseline = (base_target, base_retention)
    if not arm.factor_enabled:
        selected = baseline
    elif arm.protection_enabled:
        selected = scoped
    else:
        selected = unscoped
    if arm.sham:
        selected = tuple(int(str(value)) for value in selected)
    return selected


def run_learned_locality_partition(
    registry: FrozenLearnedLocalityRegistry,
    partition: LearnedLocalityPartition,
) -> Tuple[LearnedLocalityRun, ...]:
    template = registry.config(partition, registry.model_seeds[0])
    plan = build_learned_training_plan(template)
    keys = fact_keys(template)
    episodes = tuple(zip(keys[::2], keys[1::2]))
    evaluation_examples = tuple(
        encode_memory(key, fact_label(template, key))
        for pair in episodes
        for key in pair
    )
    evaluation_digest = content_digest(
        [
            {
                "tokens": list(item.tokens),
                "label": item.label,
                "pair_id": item.pair_id,
            }
            for item in evaluation_examples
        ]
    )
    runs: List[LearnedLocalityRun] = []
    for seed in registry.model_seeds:
        config = registry.config(partition, seed)
        (
            model,
            initial_digest,
            final_digest,
            parameter_count,
            last_loss,
            elapsed,
        ) = _train_model(config, plan)
        predictions = _predict(model, evaluation_examples)
        base_by_key = {
            key: prediction
            for pair, pair_predictions in zip(
                episodes,
                zip(predictions[::2], predictions[1::2]),
            )
            for key, prediction in zip(pair, pair_predictions)
        }
        resource_ledger = {
            "parameter_count": float(parameter_count),
            "optimizer_steps": float(config.steps),
            "training_examples": float(plan.example_count),
            "evaluation_examples": float(len(evaluation_examples)),
            "allocated_external_memory_slots": float(config.fact_count),
            "post_training_branches_evaluated_per_episode": 3.0,
        }
        resource_signature = content_digest(resource_ledger)
        traces = []
        for episode_index, (target_key, retention_key) in enumerate(episodes):
            updated = update_label(config, target_key)
            event_input = {
                "event": "targeted_update",
                "target_key": target_key,
                "update_value": updated,
                "post_update_queries": [target_key, retention_key],
            }
            event_input_digest = content_digest(event_input)
            for arm in TRIAL_ARMS:
                target_prediction, retention_prediction = _arm_predictions(
                    arm,
                    update_value=updated,
                    base_target=base_by_key[target_key],
                    base_retention=base_by_key[retention_key],
                )
                traces.append(
                    LearnedLocalityTrace(
                        registry_id=registry.registry_id,
                        partition=partition.partition,
                        data_seed=partition.data_seed,
                        model_seed=seed,
                        episode_index=episode_index,
                        arm_id=arm.arm_id,
                        target_key=target_key,
                        retention_key=retention_key,
                        update_value=updated,
                        base_target_prediction=base_by_key[target_key],
                        base_retention_prediction=base_by_key[retention_key],
                        target_prediction=target_prediction,
                        retention_prediction=retention_prediction,
                        target_correct=(target_prediction == updated),
                        retention_correct=(
                            retention_prediction
                            == fact_label(config, retention_key)
                        ),
                        event_input_digest=event_input_digest,
                        resource_signature=resource_signature,
                    )
                )
        runs.append(
            LearnedLocalityRun(
                registry_id=registry.registry_id,
                partition=partition.partition,
                config=config,
                initial_parameter_digest=initial_digest,
                final_parameter_digest=final_digest,
                parameter_count=parameter_count,
                training_order_digest=plan.ordered_digest,
                training_multiset_digest=plan.multiset_digest,
                training_example_count=plan.example_count,
                evaluation_digest=evaluation_digest,
                resource_ledger=resource_ledger,
                traces=tuple(traces),
                final_training_loss=last_loss,
                elapsed_seconds=elapsed,
            )
        )
    return tuple(runs)


def learned_run_metrics(
    run: LearnedLocalityRun,
) -> Mapping[str, Mapping[str, float]]:
    values: Dict[str, Dict[str, float]] = {}
    for trace in run.traces:
        arm = values.setdefault(
            trace.arm_id,
            {"target": 0.0, "retention": 0.0, "joint": 0.0, "count": 0.0},
        )
        arm["target"] += float(trace.target_correct)
        arm["retention"] += float(trace.retention_correct)
        arm["joint"] += float(trace.target_correct and trace.retention_correct)
        arm["count"] += 1.0
    for arm in values.values():
        count = arm.pop("count")
        for name in tuple(arm):
            arm[name] /= count
    return values
