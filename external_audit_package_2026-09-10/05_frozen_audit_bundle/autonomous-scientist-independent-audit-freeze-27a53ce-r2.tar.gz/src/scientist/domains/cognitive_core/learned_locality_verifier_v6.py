from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from statistics import mean, stdev
from typing import Any, Dict, Mapping, Tuple

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.concept_architecture_trial_v5 import (
    TRIAL_ARMS,
)
from scientist.domains.cognitive_core.learning import (
    EncodedExample,
    LearningConfig,
    encode_memory,
    fact_keys,
    fact_label,
    training_batch,
    update_label,
)
from scientist.domains.cognitive_core.learned_locality_trial_v6 import (
    LEARNED_LOCALITY_TRIAL_VERSION,
    FrozenLearnedLocalityRegistry,
    LearnedLocalityPartition,
    LearnedLocalityRun,
    learned_run_metrics,
)
from scientist.domains.cognitive_core.mlx_lab import TinyCognitiveTransformer


LEARNED_LOCALITY_VERIFIER_REF = "learned-locality-independent-verifier-v6"


def _parameter_digest(model: TinyCognitiveTransformer) -> str:
    digest = hashlib.sha256()
    for name, array in tree_flatten(model.parameters()):
        mx.eval(array)
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(array.shape)).encode("ascii"))
        digest.update(repr(array.tolist()).encode("utf-8"))
    return digest.hexdigest()


def _arrays(examples: Tuple[EncodedExample, ...]) -> Tuple[mx.array, mx.array]:
    return (
        mx.array([item.tokens for item in examples], dtype=mx.int32),
        mx.array([item.label for item in examples], dtype=mx.int32),
    )


def _independent_retraining_spot_check(
    registry: FrozenLearnedLocalityRegistry,
    partition: LearnedLocalityPartition,
    recorded: LearnedLocalityRun,
) -> bool:
    config = registry.config(partition, registry.model_seeds[0])
    if recorded.config != config:
        return False
    mx.set_default_device(mx.cpu)
    mx.random.seed(config.model_seed)
    model = TinyCognitiveTransformer(config)
    mx.eval(model.parameters())
    initial_digest = _parameter_digest(model)
    optimizer = optim.AdamW(
        learning_rate=config.learning_rate,
        weight_decay=0.0001,
    )

    def loss_fn(
        active_model: TinyCognitiveTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    value_and_grad = nn.value_and_grad(model, loss_fn)
    model.train()
    for step in range(config.steps):
        tokens, labels = _arrays(training_batch(config, step))
        loss, gradients = value_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
    final_digest = _parameter_digest(model)
    keys = fact_keys(config)
    examples = tuple(
        encode_memory(key, fact_label(config, key)) for key in keys
    )
    model.eval()
    tokens, _ = _arrays(examples)
    predicted = mx.argmax(model(tokens), axis=-1)
    mx.eval(predicted)
    predictions = tuple(int(item) for item in predicted.tolist())
    recorded_baseline = {
        trace.target_key: trace.base_target_prediction
        for trace in recorded.traces
        if trace.arm_id == "baseline"
    }
    recorded_baseline.update(
        {
            trace.retention_key: trace.base_retention_prediction
            for trace in recorded.traces
            if trace.arm_id == "baseline"
        }
    )
    return (
        initial_digest == recorded.initial_parameter_digest
        and final_digest == recorded.final_parameter_digest
        and tuple(recorded_baseline[key] for key in keys) == predictions
    )


@dataclass(frozen=True)
class LearnedLocalityVerification:
    registry_id: str
    run_count: int
    trace_count: int
    check_results: Mapping[str, bool]
    effects: Mapping[str, Mapping[str, float]]
    partition_dispositions: Mapping[str, bool]
    limitations: Tuple[str, ...]
    verifier_ref: str = LEARNED_LOCALITY_VERIFIER_REF

    def __post_init__(self) -> None:
        if (
            not self.registry_id
            or self.run_count <= 0
            or self.trace_count <= 0
            or not self.check_results
            or not self.effects
            or not self.limitations
        ):
            raise ValueError("learned locality verification is incomplete")

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LEARNED_LOCALITY_TRIAL_VERSION,
            "registry_id": self.registry_id,
            "run_count": self.run_count,
            "trace_count": self.trace_count,
            "check_results": dict(sorted(self.check_results.items())),
            "effects": {
                partition: dict(sorted(values.items()))
                for partition, values in sorted(self.effects.items())
            },
            "partition_dispositions": dict(
                sorted(self.partition_dispositions.items())
            ),
            "passed": self.passed,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _summary(samples: Tuple[float, ...]) -> Tuple[float, float]:
    return (
        mean(samples),
        stdev(samples) / math.sqrt(len(samples)) if len(samples) > 1 else 0.0,
    )


def verify_learned_locality_trial(
    *,
    registry: FrozenLearnedLocalityRegistry,
    runs: Tuple[LearnedLocalityRun, ...],
    source_generation_revision: Mapping[str, Any],
    source_architecture_manifest: Mapping[str, Any],
) -> LearnedLocalityVerification:
    run_by_key = {
        (run.partition.value, run.config.model_seed): run for run in runs
    }
    expected_run_keys = {
        (partition.partition.value, seed)
        for partition in registry.partitions
        for seed in registry.model_seeds
    }
    programs = {
        str(program["causal_factor"]): str(program["hypothesis_id"])
        for program in source_generation_revision.get("generated_programs", ())
    }
    source_bound = (
        str(source_generation_revision.get("revision_id"))
        == registry.source_generation_revision_id
        and str(source_architecture_manifest.get("verification_id"))
        == registry.source_architecture_trial_id
        and programs.get("key_scoped_mutable_memory")
        == registry.factor_hypothesis_id
        and programs.get("update_locality_gate")
        == registry.protection_hypothesis_id
    )
    fresh_seeds = (
        min(registry.model_seeds) >= 20
        and all(
            item.data_seed not in {20260729, 20260814}
            for item in registry.partitions
        )
    )
    plans_shared = all(
        len(
            {
                run.training_order_digest
                for run in runs
                if run.partition == partition.partition
            }
        )
        == 1
        and len(
            {
                run.training_multiset_digest
                for run in runs
                if run.partition == partition.partition
            }
        )
        == 1
        for partition in registry.partitions
    )
    initializations_distinct = all(
        len(
            {
                run.initial_parameter_digest
                for run in runs
                if run.partition == partition.partition
            }
        )
        == len(registry.model_seeds)
        for partition in registry.partitions
    )
    arm_ids = {arm.arm_id for arm in TRIAL_ARMS}
    shared_models = True
    complete_matrix = set(run_by_key) == expected_run_keys
    sham_exact = True
    resources_matched = True
    reconstructed = True
    event_inputs_safe = True
    expected_trace_count = 0
    for run in runs:
        config = run.config
        keys = fact_keys(config)
        episode_count = len(keys) // 2
        expected_trace_count += episode_count * len(TRIAL_ARMS)
        traces_by_episode: Dict[int, list] = {}
        for trace in run.traces:
            traces_by_episode.setdefault(trace.episode_index, []).append(trace)
        complete_matrix &= (
            len(traces_by_episode) == episode_count
            and all(
                {item.arm_id for item in values} == arm_ids
                for values in traces_by_episode.values()
            )
        )
        shared_models &= all(
            len({item.base_target_prediction for item in values}) == 1
            and len({item.base_retention_prediction for item in values}) == 1
            for values in traces_by_episode.values()
        )
        resources_matched &= all(
            len({item.resource_signature for item in values}) == 1
            and next(iter({item.resource_signature for item in values}))
            == content_digest(run.resource_ledger)
            for values in traces_by_episode.values()
        )
        for episode_index, values in traces_by_episode.items():
            target_key = keys[2 * episode_index]
            retention_key = keys[2 * episode_index + 1]
            updated = update_label(config, target_key)
            event_input_digest = content_digest(
                {
                    "event": "targeted_update",
                    "target_key": target_key,
                    "update_value": updated,
                    "post_update_queries": [target_key, retention_key],
                }
            )
            baseline = next(item for item in values if item.arm_id == "baseline")
            sham = next(item for item in values if item.arm_id == "sham")
            sham_exact &= (
                baseline.target_prediction == sham.target_prediction
                and baseline.retention_prediction == sham.retention_prediction
            )
            event_inputs_safe &= all(
                item.event_input_digest == event_input_digest for item in values
            )
            for item in values:
                arm = next(arm for arm in TRIAL_ARMS if arm.arm_id == item.arm_id)
                if not arm.factor_enabled:
                    expected = (
                        item.base_target_prediction,
                        item.base_retention_prediction,
                    )
                elif arm.protection_enabled:
                    expected = (updated, item.base_retention_prediction)
                else:
                    expected = (updated, updated)
                reconstructed &= (
                    item.registry_id == registry.registry_id
                    and item.partition == run.partition
                    and item.data_seed == config.data_seed
                    and item.model_seed == config.model_seed
                    and item.target_key == target_key
                    and item.retention_key == retention_key
                    and item.update_value == updated
                    and (item.target_prediction, item.retention_prediction)
                    == expected
                    and item.target_correct
                    == (item.target_prediction == updated)
                    and item.retention_correct
                    == (
                        item.retention_prediction
                        == fact_label(config, retention_key)
                    )
                )

    spotchecks = all(
        _independent_retraining_spot_check(
            registry,
            partition,
            run_by_key[(partition.partition.value, registry.model_seeds[0])],
        )
        for partition in registry.partitions
    )

    effects: Dict[str, Dict[str, float]] = {}
    dispositions: Dict[str, bool] = {}
    target_floor_checks = []
    target_improvement_checks = []
    retention_checks = []
    joint_checks = []
    harm_checks = []
    repair_checks = []
    consistency_checks = []
    for partition in registry.partitions:
        partition_runs = tuple(
            run
            for run in runs
            if run.partition == partition.partition
        )
        seed_metrics = tuple(learned_run_metrics(run) for run in partition_runs)
        baseline_target = tuple(item["baseline"]["target"] for item in seed_metrics)
        baseline_retention = tuple(
            item["baseline"]["retention"] for item in seed_metrics
        )
        baseline_joint = tuple(item["baseline"]["joint"] for item in seed_metrics)
        factor_target = tuple(item["factor_only"]["target"] for item in seed_metrics)
        factor_retention = tuple(
            item["factor_only"]["retention"] for item in seed_metrics
        )
        combined_target = tuple(item["combined"]["target"] for item in seed_metrics)
        combined_retention = tuple(
            item["combined"]["retention"] for item in seed_metrics
        )
        combined_joint = tuple(item["combined"]["joint"] for item in seed_metrics)
        target_delta = tuple(
            candidate - baseline
            for candidate, baseline in zip(combined_target, baseline_target)
        )
        retention_delta = tuple(
            candidate - baseline
            for candidate, baseline in zip(
                combined_retention, baseline_retention
            )
        )
        joint_delta = tuple(
            candidate - baseline
            for candidate, baseline in zip(combined_joint, baseline_joint)
        )
        factor_harm = tuple(
            factor - baseline
            for factor, baseline in zip(factor_retention, baseline_retention)
        )
        repair_delta = tuple(
            combined - factor
            for combined, factor in zip(combined_retention, factor_retention)
        )
        values = {
            "baseline_target_mean": mean(baseline_target),
            "baseline_retention_mean": mean(baseline_retention),
            "baseline_joint_mean": mean(baseline_joint),
            "factor_only_target_mean": mean(factor_target),
            "factor_only_retention_mean": mean(factor_retention),
            "combined_target_mean": mean(combined_target),
            "combined_retention_mean": mean(combined_retention),
            "combined_joint_mean": mean(combined_joint),
            "target_delta_mean": _summary(target_delta)[0],
            "target_delta_standard_error": _summary(target_delta)[1],
            "retention_delta_mean": _summary(retention_delta)[0],
            "retention_delta_standard_error": _summary(retention_delta)[1],
            "joint_delta_mean": _summary(joint_delta)[0],
            "joint_delta_standard_error": _summary(joint_delta)[1],
            "factor_retention_harm_mean": mean(factor_harm),
            "protection_repair_mean": mean(repair_delta),
            "target_positive_seed_fraction": sum(
                value > 0.0 for value in target_delta
            )
            / len(target_delta),
            "retention_nonnegative_seed_fraction": sum(
                value >= 0.0 for value in retention_delta
            )
            / len(retention_delta),
        }
        effects[partition.partition.value] = values
        target_floor = (
            values["combined_target_mean"]
            >= registry.minimum_target_accuracy
        )
        target_improvement = (
            values["target_delta_mean"]
            >= registry.minimum_target_improvement
        )
        retention_pass = (
            values["retention_delta_mean"]
            >= registry.minimum_retention_delta
        )
        joint_pass = (
            values["joint_delta_mean"]
            >= registry.minimum_joint_improvement
        )
        harm_pass = values["factor_retention_harm_mean"] <= -0.25
        repair_pass = (
            values["protection_repair_mean"] >= 0.25
            and values["combined_target_mean"]
            >= values["factor_only_target_mean"]
        )
        consistency_pass = (
            values["target_positive_seed_fraction"]
            >= registry.minimum_seed_consistency
            and values["retention_nonnegative_seed_fraction"]
            >= registry.minimum_seed_consistency
        )
        target_floor_checks.append(target_floor)
        target_improvement_checks.append(target_improvement)
        retention_checks.append(retention_pass)
        joint_checks.append(joint_pass)
        harm_checks.append(harm_pass)
        repair_checks.append(repair_pass)
        consistency_checks.append(consistency_pass)
        dispositions[partition.partition.value] = all(
            (
                target_floor,
                target_improvement,
                retention_pass,
                joint_pass,
                harm_pass,
                repair_pass,
                consistency_pass,
            )
        )

    checks = {
        "source_factor_and_protection_hypotheses_are_bound": source_bound,
        "fresh_model_and_data_seeds_are_used": fresh_seeds,
        "training_plan_is_shared_within_partition": plans_shared,
        "initializations_are_distinct_across_model_seeds": (
            initializations_distinct
        ),
        "one_trained_model_is_shared_by_all_arms_within_seed": shared_models,
        "complete_partition_seed_episode_arm_matrix": (
            complete_matrix
            and len(runs) == len(expected_run_keys)
            and sum(len(run.traces) for run in runs) == expected_trace_count
        ),
        "update_events_exclude_post_update_query_targets": event_inputs_safe,
        "baseline_and_sham_predictions_are_exact": sham_exact,
        "resource_ledgers_are_matched_across_arms": resources_matched,
        "independent_retraining_spot_checks_pass": spotchecks,
        "all_case_outcomes_are_independently_reconstructed": reconstructed,
        "combined_target_accuracy_floor_passes": all(target_floor_checks),
        "combined_target_improvement_floor_passes": all(
            target_improvement_checks
        ),
        "combined_retention_non_regression_passes": all(retention_checks),
        "combined_joint_improvement_floor_passes": all(joint_checks),
        "unscoped_factor_harms_retention": all(harm_checks),
        "locality_gate_repairs_retention_without_losing_update": all(
            repair_checks
        ),
        "target_and_retention_seed_consistency_passes": all(
            consistency_checks
        ),
        "audit_and_replication_dispositions_agree": (
            len(set(dispositions.values())) == 1
        ),
    }
    if tuple(checks) != registry.required_checks:
        raise ValueError("learned locality checks differ from frozen registry")
    return LearnedLocalityVerification(
        registry_id=registry.registry_id,
        run_count=len(runs),
        trace_count=sum(len(run.traces) for run in runs),
        check_results=checks,
        effects=effects,
        partition_dispositions=dispositions,
        limitations=(
            "The trained component is a small synthetic MLX transformer, not a frontier language model.",
            "The locality mechanism is an external typed memory wrapper; its selector is exact rather than learned.",
            "The update and retention tasks are synthetic keyed facts rather than natural-language editing benchmarks.",
            "The intervention tests one concept-derived pair and does not satisfy every cognitive-core capability floor.",
            "The factors originated in a curated vocabulary, so autonomous useful-factor invention remains unproven.",
        ),
    )

