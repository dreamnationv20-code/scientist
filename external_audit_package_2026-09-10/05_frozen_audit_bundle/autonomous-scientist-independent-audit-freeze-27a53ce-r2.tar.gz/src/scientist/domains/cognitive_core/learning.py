from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum
from functools import lru_cache
from typing import (
    Any,
    Dict,
    Iterable,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
)


PAD = 0
CLS = 1
TASK_PROCEDURE = 2
TASK_MEMORY = 3
TASK_EVIDENCE = 4
TASK_UNKNOWN = 5
OP_ADD = 6
OP_XOR = 7
OP_MAX = 8
EVIDENCE_MATCH = 9
EVIDENCE_NONMATCH = 10
NIBBLE_BASE = 16
ABSTAIN_CLASS = 16
VOCAB_SIZE = 32
SEQUENCE_LENGTH = 16
LEARNING_CONTRACT_VERSION = (
    "cognitive-core-learning-v6-relevance-annotation"
)


class TrainingCondition(str, Enum):
    RANDOM_FACTS = "random_facts"
    STRUCTURED_FACTS = "structured_facts"


@dataclass(frozen=True)
class LearningConfig:
    condition: TrainingCondition
    fact_count: int
    width: int
    layers: int = 2
    heads: int = 4
    steps: int = 800
    batch_size: int = 80
    learning_rate: float = 0.001
    model_seed: int = 0
    data_seed: int = 20260729
    value_modulus: int = 16
    checkpoint_interval: int = 200
    compute_device: str = "cpu"
    evidence_schedule: str = "balanced"
    relevance_annotation: bool = False
    relevance_label_noise: float = 0.0
    unknown_evidence_fraction: float = 0.0

    def __post_init__(self) -> None:
        if not 1 <= self.fact_count <= 192:
            raise ValueError("fact_count must be in [1, 192]")
        if self.width <= 0 or self.width % self.heads:
            raise ValueError("width must be positive and divisible by heads")
        if min(self.layers, self.steps, self.batch_size) <= 0:
            raise ValueError("training dimensions must be positive")
        if self.batch_size % 20:
            raise ValueError("batch_size must be divisible by 20")
        if self.value_modulus != 16:
            raise ValueError("v1 uses a 16-label nibble vocabulary")
        if self.checkpoint_interval <= 0:
            raise ValueError("checkpoint interval must be positive")
        if self.compute_device not in ("cpu", "gpu"):
            raise ValueError("compute_device must be cpu or gpu")
        if self.evidence_schedule not in (
            "balanced",
            "routing_6",
            "routing_8",
            "routing_10",
            "routing_heavy",
        ):
            raise ValueError("unsupported evidence schedule")
        if not 0.0 <= self.relevance_label_noise <= 1.0:
            raise ValueError("relevance_label_noise must be in [0, 1]")
        if not 0.0 <= self.unknown_evidence_fraction <= 1.0:
            raise ValueError("unknown_evidence_fraction must be in [0, 1]")
        if (
            self.relevance_label_noise
            and not self.relevance_annotation
        ):
            raise ValueError(
                "relevance-label noise requires relevance annotations"
            )

    def as_dict(self) -> Dict[str, Any]:
        value = {
            "condition": self.condition.value,
            "fact_count": self.fact_count,
            "width": self.width,
            "layers": self.layers,
            "heads": self.heads,
            "steps": self.steps,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "model_seed": self.model_seed,
            "data_seed": self.data_seed,
            "value_modulus": self.value_modulus,
            "checkpoint_interval": self.checkpoint_interval,
            "compute_device": self.compute_device,
            "evidence_schedule": self.evidence_schedule,
            "relevance_annotation": self.relevance_annotation,
        }
        # Preserve the frozen v6 payload for all historical configurations.
        # Experimental extensions are serialized only when activated.
        if self.relevance_label_noise:
            value["relevance_label_noise"] = self.relevance_label_noise
        if self.unknown_evidence_fraction:
            value["unknown_evidence_fraction"] = (
                self.unknown_evidence_fraction
            )
        return value


@dataclass(frozen=True)
class EncodedExample:
    tokens: Tuple[int, ...]
    label: int
    family: str
    pair_id: str = ""

    def __post_init__(self) -> None:
        if len(self.tokens) != SEQUENCE_LENGTH:
            raise ValueError("encoded sequences must have fixed length")
        if any(token < 0 or token >= VOCAB_SIZE for token in self.tokens):
            raise ValueError("token is outside the vocabulary")
        if not 0 <= self.label <= ABSTAIN_CLASS:
            raise ValueError("label is outside the output vocabulary")


def _digits(value: int) -> Tuple[int, int]:
    if not 0 <= value <= 255:
        raise ValueError("keys must fit in two nibbles")
    return (
        NIBBLE_BASE + value // 16,
        NIBBLE_BASE + value % 16,
    )


def _number(value: int) -> int:
    if not 0 <= value < 16:
        raise ValueError("numbers must fit in one nibble")
    return NIBBLE_BASE + value


def _blank(task: int) -> List[int]:
    tokens = [PAD] * SEQUENCE_LENGTH
    tokens[0] = CLS
    tokens[1] = task
    return tokens


def encode_procedure(operation: str, left: int, right: int) -> EncodedExample:
    op_token = {
        "add_mod": OP_ADD,
        "xor": OP_XOR,
        "max": OP_MAX,
    }[operation]
    tokens = _blank(TASK_PROCEDURE)
    tokens[2] = op_token
    tokens[3] = _number(left)
    tokens[4] = _number(right)
    label = {
        "add_mod": (left + right) % 16,
        "xor": left ^ right,
        "max": max(left, right),
    }[operation]
    return EncodedExample(tuple(tokens), label, "procedure")


def encode_memory(key: int, label: int) -> EncodedExample:
    tokens = _blank(TASK_MEMORY)
    tokens[5], tokens[6] = _digits(key)
    return EncodedExample(
        tuple(tokens),
        label,
        "memory",
        "key-%03d" % key,
    )


def encode_evidence(
    query_key: int,
    evidence: Sequence[Tuple[int, int]],
    label: int,
    family: str,
    pair_id: str = "",
    annotate_relevance: bool = False,
    relevance_labels: Optional[Sequence[bool]] = None,
) -> EncodedExample:
    if len(evidence) > 2:
        raise ValueError("v1 supports at most two evidence items")
    if (
        relevance_labels is not None
        and len(relevance_labels) != len(evidence)
    ):
        raise ValueError(
            "relevance labels must align one-to-one with evidence"
        )
    if relevance_labels is not None and not annotate_relevance:
        raise ValueError(
            "relevance labels require relevance annotation tokens"
        )
    # Fact queries deliberately share one task token. The model must infer
    # answerability and evidence relevance from the key and context itself.
    tokens = _blank(TASK_MEMORY)
    tokens[5], tokens[6] = _digits(query_key)
    for index, (key, value) in enumerate(evidence):
        offset = 7 + 4 * index
        tokens[offset], tokens[offset + 1] = _digits(key)
        tokens[offset + 2] = _number(value)
        if annotate_relevance:
            is_relevant = (
                key == query_key
                if relevance_labels is None
                else relevance_labels[index]
            )
            tokens[offset + 3] = (
                EVIDENCE_MATCH
                if is_relevant
                else EVIDENCE_NONMATCH
            )
    return EncodedExample(tuple(tokens), label, family, pair_id)


def encode_unknown(key: int) -> EncodedExample:
    tokens = _blank(TASK_MEMORY)
    tokens[5], tokens[6] = _digits(key)
    return EncodedExample(tuple(tokens), ABSTAIN_CLASS, "unknown")


def structured_fact_label(key: int) -> int:
    return (3 * key + 5) % 16


@lru_cache(maxsize=None)
def fact_keys(config: LearningConfig) -> Tuple[int, ...]:
    rng = random.Random(config.data_seed + 18013)
    keys = list(range(256))
    rng.shuffle(keys)
    return tuple(sorted(keys[: config.fact_count]))


@lru_cache(maxsize=None)
def unknown_keys(config: LearningConfig) -> Tuple[int, ...]:
    known = set(fact_keys(config))
    return tuple(key for key in range(256) if key not in known)


@lru_cache(maxsize=None)
def random_fact_table(config: LearningConfig) -> Mapping[int, int]:
    rng = random.Random(config.data_seed + 99173)
    all_values = {
        key: rng.randrange(16)
        for key in range(256)
    }
    return {
        key: all_values[key]
        for key in fact_keys(config)
    }


def fact_label(config: LearningConfig, key: int) -> int:
    if key not in random_fact_table(config):
        raise ValueError("key is outside the fact table")
    if config.condition == TrainingCondition.STRUCTURED_FACTS:
        return structured_fact_label(key)
    return random_fact_table(config)[key]


def update_label(config: LearningConfig, key: int) -> int:
    excluded = {
        random_fact_table(config)[key],
        structured_fact_label(key),
    }
    candidate = (11 * key + 9) % 16
    while candidate in excluded:
        candidate = (candidate + 1) % 16
    return candidate


def _is_procedure_holdout(operation_index: int, left: int, right: int) -> bool:
    return (31 * left + 17 * right + 13 * operation_index) % 5 == 0


def _training_procedure(rng: random.Random) -> EncodedExample:
    operations = ("add_mod", "xor", "max")
    while True:
        operation_index = rng.randrange(len(operations))
        left = rng.randrange(16)
        right = rng.randrange(16)
        if not _is_procedure_holdout(operation_index, left, right):
            return encode_procedure(
                operations[operation_index],
                left,
                right,
            )


def _noisy_relevance_labels(
    query_key: int,
    evidence: Sequence[Tuple[int, int]],
    config: LearningConfig,
    rng: random.Random,
) -> Optional[Tuple[bool, ...]]:
    if not config.relevance_annotation:
        return None
    if not config.relevance_label_noise:
        return None
    return tuple(
        (key == query_key)
        != (rng.random() < config.relevance_label_noise)
        for key, _ in evidence
    )


def training_batch(
    config: LearningConfig,
    step: int,
) -> Tuple[EncodedExample, ...]:
    procedure_count = config.batch_size // 2
    memory_count = config.batch_size // 4
    evidence_count = config.batch_size // 5
    unknown_count = config.batch_size - (
        procedure_count + memory_count + evidence_count
    )
    examples: List[EncodedExample] = []

    for row in range(config.batch_size):
        rng = random.Random(
            config.data_seed * 1000003
            + step * config.batch_size
            + row
        )
        if row < procedure_count:
            examples.append(_training_procedure(rng))
        elif row < procedure_count + memory_count:
            keys = fact_keys(config)
            key = keys[rng.randrange(len(keys))]
            examples.append(encode_memory(key, fact_label(config, key)))
        elif row < procedure_count + memory_count + evidence_count:
            evidence_row = (
                row - procedure_count - memory_count
            )
            schedule_counts = {
                "balanced": (8, 4, 4),
                "routing_6": (6, 6, 4),
                "routing_8": (4, 8, 4),
                "routing_10": (3, 10, 3),
                "routing_heavy": (2, 12, 2),
            }
            oracle_slots, irrelevant_slots, _ = schedule_counts[
                config.evidence_schedule
            ]
            schedule_index = evidence_row % 16
            subtype = (
                "oracle"
                if schedule_index < oracle_slots
                else (
                    "irrelevant"
                    if schedule_index
                    < oracle_slots + irrelevant_slots
                    else "conflicting"
                )
            )
            if subtype == "oracle":
                query = rng.randrange(256)
                answer = rng.randrange(16)
                distractor_key = (
                    query + 1 + rng.randrange(254)
                ) % 256
                distractor = (distractor_key, rng.randrange(16))
                correct = (query, answer)
                evidence = (
                    (correct, distractor)
                    if rng.randrange(2) == 0
                    else (distractor, correct)
                )
                examples.append(
                    encode_evidence(
                        query,
                        evidence,
                        answer,
                        "oracle_evidence",
                        annotate_relevance=config.relevance_annotation,
                        relevance_labels=_noisy_relevance_labels(
                            query,
                            evidence,
                            config,
                            rng,
                        ),
                    )
                )
            elif subtype == "irrelevant":
                keys = fact_keys(config)
                query = keys[rng.randrange(len(keys))]
                distractor_key = (
                    query + config.fact_count + 17
                ) % 256
                if distractor_key == query:
                    distractor_key = (distractor_key + 1) % 256
                evidence = (
                    (distractor_key, rng.randrange(16)),
                )
                examples.append(
                    encode_evidence(
                        query,
                        evidence,
                        fact_label(config, query),
                        "irrelevant_evidence",
                        annotate_relevance=config.relevance_annotation,
                        relevance_labels=_noisy_relevance_labels(
                            query,
                            evidence,
                            config,
                            rng,
                        ),
                    )
                )
            else:
                keys = fact_keys(config)
                query = keys[rng.randrange(len(keys))]
                answer = update_label(config, query)
                evidence = ((query, answer),)
                examples.append(
                    encode_evidence(
                        query,
                        evidence,
                        answer,
                        "conflicting_evidence",
                        annotate_relevance=config.relevance_annotation,
                        relevance_labels=_noisy_relevance_labels(
                            query,
                            evidence,
                            config,
                            rng,
                        ),
                    )
                )
        else:
            available = unknown_keys(config)
            unknown_key = available[rng.randrange(len(available))]
            if rng.random() < config.unknown_evidence_fraction:
                distractor_key = (
                    unknown_key + 1 + rng.randrange(254)
                ) % 256
                evidence = (
                    (distractor_key, rng.randrange(16)),
                )
                examples.append(
                    encode_evidence(
                        unknown_key,
                        evidence,
                        ABSTAIN_CLASS,
                        "unknown",
                        annotate_relevance=(
                            config.relevance_annotation
                        ),
                        relevance_labels=_noisy_relevance_labels(
                            unknown_key,
                            evidence,
                            config,
                            rng,
                        ),
                    )
                )
            else:
                examples.append(encode_unknown(unknown_key))
    if len(examples) != config.batch_size or unknown_count <= 0:
        raise AssertionError("invalid matched batch construction")
    return tuple(examples)


def evaluation_suite(config: LearningConfig) -> Tuple[EncodedExample, ...]:
    examples: List[EncodedExample] = []
    operations = ("add_mod", "xor", "max")
    for operation_index, operation in enumerate(operations):
        for left in range(16):
            for right in range(16):
                if _is_procedure_holdout(operation_index, left, right):
                    examples.append(
                        encode_procedure(operation, left, right)
                    )

    table = tuple(
        (key, fact_label(config, key))
        for key in fact_keys(config)
    )
    for key, label in table:
        pair_id = "known-%03d" % key
        memory = encode_memory(key, label)
        examples.append(
            EncodedExample(
                memory.tokens,
                memory.label,
                "closed_book",
                pair_id,
            )
        )
        distractor_key = (key + config.fact_count + 17) % 256
        if distractor_key == key:
            distractor_key = (distractor_key + 1) % 256
        examples.append(
            encode_evidence(
                key,
                ((distractor_key, (7 * key + 3) % 16),),
                label,
                "irrelevant_evidence",
                pair_id,
                config.relevance_annotation,
            )
        )
        updated = update_label(config, key)
        examples.append(
            encode_evidence(
                key,
                ((key, updated),),
                updated,
                "conflicting_evidence",
                pair_id,
                config.relevance_annotation,
            )
        )

    rng = random.Random(config.data_seed + 555019)
    for index in range(192):
        query = rng.randrange(256)
        answer = rng.randrange(16)
        distractor_key = (query + 1 + rng.randrange(254)) % 256
        evidence = (
            (query, answer),
            (distractor_key, rng.randrange(16)),
        )
        if index % 2:
            evidence = tuple(reversed(evidence))
        examples.append(
            encode_evidence(
                query,
                evidence,
                answer,
                "oracle_evidence",
                annotate_relevance=config.relevance_annotation,
            )
        )
    available_unknown = unknown_keys(config)
    for index in range(96):
        key = available_unknown[index % len(available_unknown)]
        examples.append(encode_unknown(key))
    return tuple(examples)


def family_counts(
    examples: Iterable[EncodedExample],
) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for example in examples:
        counts[example.family] = counts.get(example.family, 0) + 1
    return counts
