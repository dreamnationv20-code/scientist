from __future__ import annotations

from scientist.program.literature import (
    ClaimClassification,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)
from scientist.research_programs.cognitive_core import high_level_goal

from scientist.domains.cognitive_core.goal_program import fresh_goal_graph_spec
from scientist.domains.cognitive_core.measurement_goal import measurement_decomposition


ROOT_LITERATURE_REVIEW_VERSION = "cognitive-core-root-literature-v3-2026-08-05"


def root_prior_art_assessment() -> PriorArtAssessment:
    """Closed scoping review for decomposition, not a novelty authorization."""

    goal = high_level_goal()
    root = fresh_goal_graph_spec().root
    signature = ClaimSignature(
        subject_id=root.node_id,
        statement=goal.outcome,
        problem=(
            "jointly preserve reusable procedures, rapid adaptation, reliable "
            "knowledge-boundary decisions, evidence use, and safe updates"
        ),
        phenomenon=(
            "different storage and adaptation paths exhibit capability, "
            "interference, robustness, and cost trade-offs"
        ),
        intervention=(
            "allocate computation and information among model parameters, "
            "context, retrieved memory, and fast adaptation"
        ),
        mechanism=(
            "competing hypotheses include capacity allocation, optimization "
            "kinetics, representation entanglement, source routing, and null"
        ),
        evaluation=(
            "multi-horizon Pareto gate at matched end-to-end system cost"
        ),
    )
    queries = (
        LiteratureQuery(
            query=(
                "language-model parametric memory external memory continual "
                "learning and retrieval"
            ),
            facet=SearchFacet.PROBLEM,
            provider="PMLR",
        ),
        LiteratureQuery(
            query=(
                "knowledge boundaries retrieval conflicts abstention language "
                "models"
            ),
            facet=SearchFacet.PROBLEM,
            provider="ACL Anthology",
        ),
        LiteratureQuery(
            query=(
                "memory layers test-time learning external memory language "
                "model architecture"
            ),
            facet=SearchFacet.INTERVENTION,
            provider="arXiv and PMLR",
        ),
        LiteratureQuery(
            query="lifelong model editing parametric and working memory",
            facet=SearchFacet.INTERVENTION,
            provider="OpenReview",
        ),
        LiteratureQuery(
            query=(
                "adaptive semiparametric gating internal external knowledge "
                "and neural memory"
            ),
            facet=SearchFacet.MECHANISM,
            provider="TACL and Google Research",
        ),
        LiteratureQuery(
            query=(
                "compositional generalization rapid in-context task learning "
                "knowledge conflict and update locality"
            ),
            facet=SearchFacet.EVALUATION,
            provider="PMLR and ACL Anthology",
        ),
        LiteratureQuery(
            query=(
                "papers citing Adaptive Semiparametric Language Models, "
                "Memory Layers at Scale, Titans, and HippoRAG 2"
            ),
            facet=SearchFacet.CITATION_NEIGHBORHOOD,
            provider="web search over primary-source indexes",
        ),
    )
    closest_works = (
        PriorWork(
            work_id="adaptive-semiparametric-lm-tacl-2021",
            title="Adaptive Semiparametric Language Models",
            year=2021,
            locator=(
                "https://direct.mit.edu/tacl/article/doi/10.1162/"
                "tacl_a_00371/100688/Adaptive-Semiparametric-Language-Models"
            ),
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "parametric model plus episodic memory",
                "adaptive source gating",
                "short- and long-term context",
            ),
            abstract=(
                "Combines a transformer with local cache and global nearest-"
                "neighbor memory through an adaptive gate."
            ),
        ),
        PriorWork(
            work_id="memory-layers-at-scale-icml-2025",
            title="Memory Layers at Scale",
            year=2025,
            locator="https://proceedings.mlr.press/v267/berges25a.html",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "separate associative storage capacity",
                "matched compute and parameter comparisons",
                "factual-memory scaling",
            ),
            executable=True,
            abstract=(
                "Scales sparse trainable key-value memory and shows factual "
                "gains over denser compute-matched alternatives."
            ),
        ),
        PriorWork(
            work_id="hipporag2-icml-2025",
            title=(
                "From RAG to Memory: Non-Parametric Continual Learning for "
                "Large Language Models"
            ),
            year=2025,
            locator="https://proceedings.mlr.press/v267/gutierrez25a.html",
            relation=PriorArtRelation.EXECUTABLE_BASELINE,
            matched_components=(
                "external long-term memory",
                "factual, associative, and sense-making evaluation",
                "online memory use",
            ),
            executable=True,
            abstract=(
                "HippoRAG 2 combines dense and graph retrieval and reports a "
                "single non-parametric system across three memory regimes."
            ),
        ),
        PriorWork(
            work_id="titans-neurips-2025",
            title="Titans: Learning to Memorize at Test Time",
            year=2025,
            locator=(
                "https://research.google/pubs/"
                "titans-learning-to-memorize-at-test-time/"
            ),
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "test-time neural memory",
                "short- and long-term memory integration",
                "long-context transfer",
            ),
            abstract=(
                "Introduces a learned long-term memory updated at test time "
                "and three integrations with attention."
            ),
        ),
        PriorWork(
            work_id="ttt-layers-2024",
            title="Learning to (Learn at Test Time): RNNs with Expressive Hidden States",
            year=2024,
            locator="https://arxiv.org/abs/2407.04620",
            relation=PriorArtRelation.ADJACENT,
            matched_components=(
                "fast-weight adaptation",
                "self-supervised state updates",
                "long-context sequence modeling",
            ),
            abstract=(
                "Treats recurrent hidden state as a model updated by a "
                "self-supervised learning step at test time."
            ),
        ),
        PriorWork(
            work_id="astute-rag-acl-2025",
            title=(
                "Astute RAG: Overcoming Imperfect Retrieval Augmentation and "
                "Knowledge Conflicts for Large Language Models"
            ),
            year=2025,
            locator="https://aclanthology.org/2025.acl-long.1476/",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "internal/external knowledge conflict",
                "source-aware consolidation",
                "imperfect retrieval robustness",
            ),
            abstract=(
                "Analyzes imperfect retrieval and adaptively consolidates "
                "internal and external information using source reliability."
            ),
        ),
        PriorWork(
            work_id="knowledge-boundary-coling-2025",
            title=(
                "Investigating the Factual Knowledge Boundary of Large "
                "Language Models with Retrieval Augmentation"
            ),
            year=2025,
            locator="https://aclanthology.org/2025.coling-main.250/",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "knowledge-boundary recognition",
                "adaptive retrieval",
                "internal/external conflict",
            ),
            abstract=(
                "Finds overconfidence and conflict failures and evaluates "
                "prior and posterior knowledge-boundary judgments."
            ),
        ),
        PriorWork(
            work_id="wise-neurips-2024",
            title=(
                "WISE: Rethinking the Knowledge Memory for Lifelong Model "
                "Editing of Large Language Models"
            ),
            year=2024,
            locator="https://openreview.net/forum?id=NpoDbZBPZH",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "lifelong knowledge updating",
                "parametric versus working memory",
                "reliability, generalization, and locality trade-off",
            ),
            abstract=(
                "Studies lifelong editing and reports a trade-off among "
                "reliability, generalization, and locality."
            ),
        ),
        PriorWork(
            work_id="icl-ood-icml-2025",
            title="When can in-context learning generalize out of task distribution?",
            year=2025,
            locator="https://proceedings.mlr.press/v267/goddard25a.html",
            relation=PriorArtRelation.ADJACENT,
            matched_components=(
                "rapid learning from demonstrations",
                "out-of-task-distribution transfer",
                "task-diversity phase transition",
            ),
            abstract=(
                "Shows a transition from task-specialized in-context learning "
                "to out-of-distribution task generalization with diversity."
            ),
        ),
        PriorWork(
            work_id="belief-revision-tmlr-2024",
            title=(
                "Fundamental Problems With Model Editing: How Should Rational "
                "Belief Revision Work in LLMs?"
            ),
            year=2024,
            locator="https://openreview.net/forum?id=LRf19n5Ly3",
            relation=PriorArtRelation.ADJACENT,
            matched_components=(
                "belief-update semantics",
                "far-reaching edit consequences",
                "formal evaluation",
            ),
            abstract=(
                "Argues that standard edit benchmarks under-specify rational "
                "belief revision and proposes a formal testbed."
            ),
        ),
    )
    return PriorArtAssessment(
        signature=signature,
        trigger=LiteratureTrigger.INITIAL_SCOPE,
        queries=queries,
        closest_works=closest_works,
        classification=ClaimClassification.NOT_APPLICABLE,
        rationale=(
            "This is a solution-neutral objective charter, not an empirical "
            "novelty claim. Existing work establishes every major component "
            "family separately, but no reviewed system establishes the joint "
            "multi-capability Pareto claim at matched end-to-end cost. The "
            "review therefore authorizes decomposition only; it does not "
            "authorize novelty, frontier, or breakthrough language."
        ),
        novel_delta=(),
        citation_snowball_complete=True,
        searched_at="2026-08-05",
        reviewer_ref=ROOT_LITERATURE_REVIEW_VERSION,
        executable_incumbent_id="hipporag2-icml-2025",
    )


def measurement_prior_art_assessment() -> PriorArtAssessment:
    """Scoping review for the v3 multi-capability measurement system."""

    node = fresh_goal_graph_spec().nodes["measurement"]
    signature = ClaimSignature(
        subject_id=node.node_id,
        statement=node.question,
        problem=(
            "measure distinct language-model learning, memory, evidence, "
            "updating, calibration, transfer, and cost capabilities without "
            "contamination or shortcut leakage"
        ),
        phenomenon=(
            "aggregate benchmark scores can conceal contamination, construct "
            "confounding, capability regressions, and system-cost displacement"
        ),
        intervention=(
            "use generated sealed task families, positive and negative controls, "
            "independent reconstruction, capability floors, and cost ledgers"
        ),
        mechanism=(
            "measurement validity follows from identity separation, control "
            "discrimination, prospective task generation, and verifier autonomy"
        ),
        evaluation=(
            "qualification checks over partitions, control signatures, metric "
            "reconstruction, transfer horizons, and end-to-end cost"
        ),
    )
    return PriorArtAssessment(
        signature=signature,
        trigger=LiteratureTrigger.INITIAL_SCOPE,
        queries=(
            LiteratureQuery(
                signature.problem,
                SearchFacet.PROBLEM,
                "ACL Anthology",
            ),
            LiteratureQuery(
                "holistic multi-metric evaluation of language models",
                SearchFacet.INTERVENTION,
                "arXiv and Stanford CRFM",
            ),
            LiteratureQuery(
                "dynamic contamination-free language model benchmarks",
                SearchFacet.INTERVENTION,
                "ACL Anthology",
            ),
            LiteratureQuery(
                "construct validity positive negative oracle controls",
                SearchFacet.MECHANISM,
                "PMLR and ACL Anthology",
            ),
            LiteratureQuery(
                "abstention calibration model editing locality retention cost",
                SearchFacet.EVALUATION,
                "ACL Anthology and OpenReview",
            ),
            LiteratureQuery(
                "citation neighborhood HELM C2LEVA WISE Abstain-QA",
                SearchFacet.CITATION_NEIGHBORHOOD,
                "web search over primary-source indexes",
            ),
        ),
        closest_works=(
            PriorWork(
                work_id="helm-2022",
                title="Holistic Evaluation of Language Models",
                year=2022,
                locator="https://arxiv.org/abs/2211.09110",
                relation=PriorArtRelation.EXECUTABLE_BASELINE,
                matched_components=(
                    "multi-metric evaluation",
                    "scenario transparency",
                    "efficiency measurement",
                ),
                executable=True,
                abstract=(
                    "HELM evaluates multiple scenarios and metrics with a "
                    "modular, transparent evaluation toolkit."
                ),
            ),
            PriorWork(
                work_id="c2leva-acl-2025",
                title=(
                    "C2LEVA: Toward Comprehensive and Contamination-Free "
                    "Language Model Evaluation"
                ),
                year=2025,
                locator="https://aclanthology.org/2025.findings-acl.116/",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "automatic test renewal",
                    "contamination prevention",
                    "multi-capability evaluation",
                ),
                abstract=(
                    "Combines broad task coverage with automated test-data "
                    "renewal and protected benchmark release."
                ),
            ),
            PriorWork(
                work_id="contamination-dynamic-emnlp-2025",
                title=(
                    "Benchmarking Large Language Models Under Data "
                    "Contamination: A Survey from Static to Dynamic Evaluation"
                ),
                year=2025,
                locator="https://aclanthology.org/2025.emnlp-main.511/",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "dynamic benchmark design",
                    "contamination threats",
                    "benchmark qualification criteria",
                ),
                abstract=(
                    "Systematizes contamination failure modes and design "
                    "criteria for dynamic evaluation."
                ),
            ),
            PriorWork(
                work_id="icl-ood-icml-2025-measurement",
                title="When can in-context learning generalize out of task distribution?",
                year=2025,
                locator="https://proceedings.mlr.press/v267/goddard25a.html",
                relation=PriorArtRelation.ADJACENT,
                matched_components=(
                    "unseen task-family evaluation",
                    "rapid in-context learning",
                    "task-distribution transfer",
                ),
                abstract=(
                    "Demonstrates that rapid learning must be tested beyond the "
                    "pretraining task distribution."
                ),
            ),
            PriorWork(
                work_id="abstention-survey-tacl-2025",
                title="Know Your Limits: A Survey of Abstention in Large Language Models",
                year=2025,
                locator="https://aclanthology.org/2025.tacl-1.26/",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "abstention metrics",
                    "knowledge-boundary evaluation",
                    "cross-domain meta-capability",
                ),
                abstract=(
                    "Organizes abstention evaluation by query, model, and human "
                    "values and identifies cross-task abstention as unresolved."
                ),
            ),
            PriorWork(
                work_id="wise-measurement-neurips-2024",
                title=(
                    "WISE: Rethinking the Knowledge Memory for Lifelong Model "
                    "Editing of Large Language Models"
                ),
                year=2024,
                locator="https://openreview.net/forum?id=NpoDbZBPZH",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "update reliability",
                    "generalization",
                    "locality and retention",
                ),
                abstract=(
                    "Shows why update evaluation must jointly measure "
                    "reliability, generalization, and locality."
                ),
            ),
            PriorWork(
                work_id="tool-cost-benchmark-2026",
                title="When Do Tools and Planning Help LLMs Think? A Cost- and Latency-Aware Benchmark",
                year=2026,
                locator="https://arxiv.org/abs/2601.02663",
                relation=PriorArtRelation.ADJACENT,
                matched_components=(
                    "accuracy-cost trade-offs",
                    "tool and retrieval latency",
                    "system-level evaluation",
                ),
                abstract=(
                    "Evaluates external tools with accuracy, cost, and latency "
                    "rather than treating tool use as free."
                ),
            ),
        ),
        classification=ClaimClassification.NOT_APPLICABLE,
        rationale=(
            "The node constructs measurement infrastructure and makes no "
            "scientific novelty claim. Prior work requires a dynamic, "
            "multi-metric, independently reconstructable laboratory. The old "
            "routing MiniLab covers only a subset of the required constructs, "
            "so it is historical evidence rather than a sufficient v3 lab."
        ),
        novel_delta=(),
        citation_snowball_complete=True,
        searched_at="2026-08-06",
        reviewer_ref="cognitive-core-measurement-literature-v3-2026-08-06",
        executable_incumbent_id="helm-2022",
    )


def measurement_leaf_prior_art_assessments() -> tuple[PriorArtAssessment, ...]:
    """Leaf-level engineering closures for the frozen measurement protocol."""

    leaves = measurement_decomposition().nodes
    works = {
        "c2leva": PriorWork(
            work_id="c2leva-acl-2025-leaf",
            title="C2LEVA: Toward Comprehensive and Contamination-Free Language Model Evaluation",
            year=2025,
            locator="https://aclanthology.org/2025.findings-acl.116/",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "automated test-data renewal",
                "protected benchmark release",
                "contamination prevention",
            ),
            abstract="Uses renewed and protected test data for contamination-resistant evaluation.",
        ),
        "contamination": PriorWork(
            work_id="dynamic-contamination-emnlp-2025-leaf",
            title="Benchmarking Large Language Models Under Data Contamination: A Survey from Static to Dynamic Evaluation",
            year=2025,
            locator="https://aclanthology.org/2025.emnlp-main.511/",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "dynamic benchmark criteria",
                "partition contamination threats",
                "static benchmark limitations",
            ),
            abstract="Provides design principles and failure modes for dynamic evaluation.",
        ),
        "checklist": PriorWork(
            work_id="checklist-acl-2020-leaf",
            title="Beyond Accuracy: Behavioral Testing of NLP Models with CheckList",
            year=2020,
            locator="https://aclanthology.org/2020.acl-main.442/",
            relation=PriorArtRelation.EXECUTABLE_BASELINE,
            matched_components=(
                "behavioral capability matrix",
                "positive and negative test types",
                "dynamic test generation",
            ),
            executable=True,
            abstract="Introduces task-agnostic capability and behavior testing with generated cases.",
        ),
        "helm": PriorWork(
            work_id="helm-2022-leaf",
            title="Holistic Evaluation of Language Models",
            year=2022,
            locator="https://arxiv.org/abs/2211.09110",
            relation=PriorArtRelation.EXECUTABLE_BASELINE,
            matched_components=(
                "transparent scenario contracts",
                "multi-metric reconstruction",
                "efficiency reporting",
            ),
            executable=True,
            abstract="Provides a modular executable framework for scenario and metric evaluation.",
        ),
        "rl_metrics": PriorWork(
            work_id="rl-evaluation-icml-2020-leaf",
            title="Evaluating the Performance of Reinforcement Learning Algorithms",
            year=2020,
            locator="https://proceedings.mlr.press/v119/jordan20a.html",
            relation=PriorArtRelation.ADJACENT,
            matched_components=(
                "metric validity",
                "reconstructable evaluation",
                "reproducible comparison",
            ),
            abstract="Shows that flawed metrics can make algorithm comparisons inconsistent.",
        ),
        "wise": PriorWork(
            work_id="wise-neurips-2024-leaf",
            title="WISE: Rethinking the Knowledge Memory for Lifelong Model Editing of Large Language Models",
            year=2024,
            locator="https://openreview.net/forum?id=NpoDbZBPZH",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "update reliability",
                "generalization",
                "locality and unrelated retention",
            ),
            abstract="Separates editing reliability, generalization, and locality.",
        ),
        "cost": PriorWork(
            work_id="tool-cost-latency-2026-leaf",
            title="When Do Tools and Planning Help LLMs Think? A Cost- and Latency-Aware Benchmark",
            year=2026,
            locator="https://arxiv.org/abs/2601.02663",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "end-to-end latency",
                "token cost",
                "tool-use overhead",
            ),
            abstract="Measures quality together with workflow-level cost and latency.",
        ),
    }
    configurations = (
        (
            leaves[0],
            (works["c2leva"], works["contamination"]),
            "Dynamic renewal and protected partitions are established requirements; this leaf qualifies their concrete implementation.",
            "partition identities, provenance, target concealment, and deterministic regeneration",
        ),
        (
            leaves[1],
            (works["checklist"], works["wise"]),
            "Behavioral controls and separable update/retention metrics are established; this leaf tests whether the laboratory instantiates them.",
            "opposing reference-control signatures across non-substitutable capabilities",
        ),
        (
            leaves[2],
            (works["helm"], works["rl_metrics"]),
            "Transparent metric definitions and reproducible evaluation are established; this leaf requires a separately implemented verifier.",
            "independent reconstruction of targets, outcomes, and aggregate metrics",
        ),
        (
            leaves[3],
            (works["helm"], works["cost"]),
            "System-level efficiency reporting is established; this leaf closes omitted-resource and horizon-relabeling loopholes.",
            "total resource accounting and evidence-to-horizon binding",
        ),
    )
    assessments = []
    for leaf, closest, rationale, mechanism in configurations:
        assessments.append(
            PriorArtAssessment(
                signature=ClaimSignature(
                    subject_id=leaf.node_id,
                    statement=leaf.question,
                    problem="qualify trustworthy cognitive-core measurement infrastructure",
                    phenomenon="aggregate or contaminated benchmarks admit shortcut success",
                    intervention=leaf.leaf_contract.hypothesis,
                    mechanism=mechanism,
                    evaluation=leaf.leaf_contract.testbed_ref,
                ),
                trigger=LiteratureTrigger.INITIAL_SCOPE,
                queries=(
                    LiteratureQuery(
                        query=leaf.question,
                        facet=SearchFacet.PROBLEM,
                        provider="ACL Anthology and PMLR",
                    ),
                    LiteratureQuery(
                        query=leaf.leaf_contract.hypothesis,
                        facet=SearchFacet.INTERVENTION,
                        provider="ACL Anthology and arXiv",
                    ),
                    LiteratureQuery(
                        query=mechanism,
                        facet=SearchFacet.MECHANISM,
                        provider="PMLR and OpenReview",
                    ),
                    LiteratureQuery(
                        query="citation neighborhood "
                        + " ".join(work.title for work in closest),
                        facet=SearchFacet.CITATION_NEIGHBORHOOD,
                        provider="primary-source indexes",
                    ),
                ),
                closest_works=closest,
                classification=ClaimClassification.NOT_APPLICABLE,
                rationale=rationale + " No scientific novelty is claimed.",
                novel_delta=(),
                citation_snowball_complete=True,
                searched_at="2026-08-06",
                reviewer_ref="cognitive-core-measurement-leaf-literature-v3-2026-08-06",
                executable_incumbent_id=next(
                    (work.work_id for work in closest if work.executable),
                    None,
                ),
            )
        )
    return tuple(assessments)
