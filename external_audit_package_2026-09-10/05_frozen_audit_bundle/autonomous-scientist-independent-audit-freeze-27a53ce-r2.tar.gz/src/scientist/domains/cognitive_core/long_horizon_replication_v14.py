from __future__ import annotations

import random
from dataclasses import dataclass, replace
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_schema_mechanism_v12 import (
    CausalSchemaCandidate,
    CausalSchemaPreregistration,
)
from scientist.domains.cognitive_core.conservative_adoption_v13 import (
    FrozenCandidateIdentity,
    harden_vertical_episode,
)
from scientist.domains.cognitive_core.functional_vertical_slice_v11 import (
    SliceCandidateDescriptor,
    SlicePartition,
    VerticalCandidateEvaluation,
    VerticalEpisode,
    VerticalProbe,
    VerticalSliceRegistry,
    evaluate_vertical_candidate,
    make_vertical_episode,
)
from scientist.domains.cognitive_core.shared_substrate_v10 import (
    CandidateAction,
    CandidateActionKind,
    CandidateEvent,
    CandidateEventKind,
    ReferenceSharedBaseline,
    SharedCandidateInterfaceContract,
    WAVE_ONE_KEYS,
    reference_shared_baseline,
)


LONG_HORIZON_REPLICATION_VERSION = (
    "cognitive-core-long-horizon-replication-v14"
)
HORIZONS = (1, 4, 16, 32)


@dataclass(frozen=True)
class LongHorizonRegistry:
    registry: VerticalSliceRegistry
    horizon_by_probe_id: Mapping[str, int]
    task_order: Tuple[str, ...]
    family_ref: str

    @property
    def long_registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LONG_HORIZON_REPLICATION_VERSION,
            "registry": self.registry.as_dict(),
            "horizon_by_probe_id": dict(
                sorted(self.horizon_by_probe_id.items())
            ),
            "task_order": list(self.task_order),
            "family_ref": self.family_ref,
        }
        if include_id:
            value["long_registry_id"] = self.long_registry_id
        return value


@dataclass(frozen=True)
class IndependentReconstruction:
    evaluation_id: str
    reconstructed_probe_count: int
    expected_action_match_rate: float
    observed_action_match_rate: float
    horizon_match_rates: Mapping[str, float]

    @property
    def reconstruction_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "evaluation_id": self.evaluation_id,
            "reconstructed_probe_count": self.reconstructed_probe_count,
            "expected_action_match_rate": self.expected_action_match_rate,
            "observed_action_match_rate": self.observed_action_match_rate,
            "horizon_match_rates": dict(sorted(self.horizon_match_rates.items())),
        }
        if include_id:
            value["reconstruction_id"] = self.reconstruction_id
        return value


@dataclass(frozen=True)
class LongHorizonReplicationTrial:
    candidate_freeze: FrozenCandidateIdentity
    primary_registry: LongHorizonRegistry
    order_control_registry: LongHorizonRegistry
    replication_registry: LongHorizonRegistry
    primary_baseline: VerticalCandidateEvaluation
    primary_candidate: VerticalCandidateEvaluation
    order_control_candidate: VerticalCandidateEvaluation
    replication_candidate: VerticalCandidateEvaluation
    replication_reconstruction: IndependentReconstruction
    primary_horizon_scores: Mapping[str, float]
    order_control_horizon_scores: Mapping[str, float]
    replication_horizon_scores: Mapping[str, float]
    check_results: Mapping[str, bool]
    disposition: str
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.check_results.values()) and self.disposition == "replicated"

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": LONG_HORIZON_REPLICATION_VERSION,
            "candidate_freeze": self.candidate_freeze.as_dict(),
            "primary_registry": self.primary_registry.as_dict(),
            "order_control_registry": self.order_control_registry.as_dict(),
            "replication_registry": self.replication_registry.as_dict(),
            "primary_baseline": self.primary_baseline.as_dict(),
            "primary_candidate": self.primary_candidate.as_dict(),
            "order_control_candidate": self.order_control_candidate.as_dict(),
            "replication_candidate": self.replication_candidate.as_dict(),
            "replication_reconstruction": self.replication_reconstruction.as_dict(),
            "primary_horizon_scores": dict(sorted(self.primary_horizon_scores.items())),
            "order_control_horizon_scores": dict(
                sorted(self.order_control_horizon_scores.items())
            ),
            "replication_horizon_scores": dict(
                sorted(self.replication_horizon_scores.items())
            ),
            "check_results": dict(sorted(self.check_results.items())),
            "disposition": self.disposition,
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def _task_specs(
    *,
    seed_offset: int,
    index_offset: int,
) -> Tuple[Tuple[SlicePartition, int, int, int, int], ...]:
    definitions = (
        (SlicePartition.DEVELOPMENT, 19, 8, 1401 + seed_offset),
        (SlicePartition.CALIBRATION, 23, 16, 1409 + seed_offset),
        (SlicePartition.AUDIT, 29, 40, 1423 + seed_offset),
    )
    rows = []
    running_index = index_offset
    for partition, modulus, count, seed in definitions:
        randomizer = random.Random(seed)
        pairs = []
        while len(pairs) < count:
            pair = (
                randomizer.randrange(1, modulus),
                randomizer.randrange(0, modulus),
            )
            if pair not in pairs:
                pairs.append(pair)
        for scale, shift in pairs:
            rows.append((partition, running_index, modulus, scale, shift))
            running_index += 1
    return tuple(rows)


def build_long_horizon_registry(
    interface: SharedCandidateInterfaceContract,
    *,
    family_ref: str,
    seed_offset: int,
    index_offset: int,
    order_seed: int | None = None,
) -> LongHorizonRegistry:
    specifications = list(
        _task_specs(seed_offset=seed_offset, index_offset=index_offset)
    )
    if order_seed is not None:
        random.Random(order_seed).shuffle(specifications)
    episodes = []
    history: list[Tuple[str, int, int, int]] = []
    horizon_by_probe_id: Dict[str, int] = {}
    for partition, index, modulus, scale, shift in specifications:
        base = make_vertical_episode(
            partition,
            index,
            modulus=modulus,
            scale=scale,
            shift=shift,
        )
        hardened, current = harden_vertical_episode(base, None)
        events = list(hardened.events)
        probes = list(hardened.probes)
        for horizon in HORIZONS:
            if len(history) < horizon:
                continue
            target, old_modulus, old_scale, old_shift = history[-horizon]
            argument = 11 + horizon
            event = CandidateEvent(
                "%s-horizon-%d-query" % (hardened.episode_id, horizon),
                CandidateEventKind.ANSWER_TASK,
                {"task_token": target, "operands": [argument]},
            )
            probe_id = "%s-probe-horizon-%d" % (
                hardened.episode_id,
                horizon,
            )
            events.append(event)
            probes.append(
                VerticalProbe(
                    probe_id=probe_id,
                    partition=partition,
                    episode_id=hardened.episode_id,
                    work_package_key="requested_change",
                    event_id=event.event_id,
                    expected_kind=CandidateActionKind.TASK_RESULT,
                    expected_payload={
                        "value": (
                            old_scale * argument + old_shift
                        )
                        % old_modulus
                    },
                )
            )
            horizon_by_probe_id[probe_id] = horizon
        episodes.append(
            replace(hardened, events=tuple(events), probes=tuple(probes))
        )
        history.append(current)
    event_count = sum(len(item.events) for item in episodes)
    scale = event_count / 161.0
    registry = VerticalSliceRegistry(
        interface_id=interface.interface_id,
        episodes=tuple(episodes),
        cost_envelope={
            "parameter_count": 0.0,
            "training_compute_flops": 0.0,
            "training_examples": 0.0,
            "inference_events": float(event_count),
            "primitive_operations": 112000.0 * scale,
            "context_tokens": 24000.0 * scale,
            "persistent_memory_slots": 256.0,
            "retrieval_calls": 64.0 * scale,
            "adaptation_writes": 256.0 * scale,
            "external_service_calls": 0.0,
        },
        frozen_partitions=tuple(item.value for item in SlicePartition),
        shortcut_controls=(
            "64 persistent tasks are accumulated without reset",
            "every task receives two mutations before delayed probes",
            "updated tasks are re-queried after 1, 4, 16, and 32 intervening tasks",
            "task order is tested again under a frozen permutation",
            "replication uses disjoint seeds and identities with independent expected-action reconstruction",
        ),
    )
    return LongHorizonRegistry(
        registry=registry,
        horizon_by_probe_id=horizon_by_probe_id,
        task_order=tuple(item.task_token for item in episodes),
        family_ref=family_ref,
    )


def _horizon_scores(
    evaluation: VerticalCandidateEvaluation,
    registry: LongHorizonRegistry,
) -> Mapping[str, float]:
    outcome_by_probe = {
        item.probe.probe_id: item for item in evaluation.outcomes
    }
    return {
        str(horizon): (
            sum(
                outcome_by_probe[probe_id].passed
                for probe_id, value in registry.horizon_by_probe_id.items()
                if value == horizon
            )
            / sum(
                value == horizon
                for value in registry.horizon_by_probe_id.values()
            )
        )
        for horizon in HORIZONS
    }


def independently_reconstruct_replication(
    evaluation: VerticalCandidateEvaluation,
    long_registry: LongHorizonRegistry,
) -> IndependentReconstruction:
    probe_by_event = {
        probe.event_id: probe
        for episode in long_registry.registry.episodes
        for probe in episode.probes
    }
    models: Dict[str, Tuple[int, int, int]] = {}
    reconstructed = []
    for step in evaluation.steps:
        event = step.event
        payload = event.payload
        expected = None
        if event.kind == CandidateEventKind.EXECUTE_PROCEDURE:
            spec = payload["procedure_spec"]
            x = int(payload["operands"][0])
            expected = CandidateAction(
                CandidateActionKind.PROCEDURE_RESULT,
                {
                    "value": (
                        int(spec["scale"]) * x + int(spec["shift"])
                    )
                    % int(spec["modulus"])
                },
            )
        elif event.kind == CandidateEventKind.OBSERVE_DEMONSTRATIONS:
            modulus = int(payload["modulus"])
            matches = []
            for scale in range(modulus):
                for shift in range(modulus):
                    if all(
                        (
                            scale * int(row["operands"][0]) + shift
                        )
                        % modulus
                        == int(row["output"])
                        for row in payload["demonstrations"]
                    ):
                        matches.append((modulus, scale, shift))
            if len(matches) == 1:
                models[str(payload["task_token"])] = matches[0]
        elif event.kind == CandidateEventKind.ANSWER_TASK:
            target = str(payload["task_token"])
            if target in models:
                modulus, scale, shift = models[target]
                expected = CandidateAction(
                    CandidateActionKind.TASK_RESULT,
                    {
                        "value": (
                            scale * int(payload["operands"][0]) + shift
                        )
                        % modulus
                    },
                )
        elif event.kind == CandidateEventKind.SELECT_RELEVANCE:
            target = str(payload["query_target"])
            evidence = payload["evidence"]
            frontier = {target}
            selected = []
            for _ in range(2):
                next_frontier = set()
                for row in evidence:
                    if row["subject"] in frontier:
                        selected.append(str(row["evidence_id"]))
                        next_frontier.add(str(row["object"]))
                frontier = next_frontier
            expected = CandidateAction(
                CandidateActionKind.RELEVANCE_SELECTION,
                {"evidence_ids": selected},
            )
        elif event.kind == CandidateEventKind.REQUEST_UPDATE:
            target = str(payload["task_token"])
            if target in models and payload["field"] == "shift":
                modulus, scale, _ = models[target]
                models[target] = (
                    modulus,
                    scale,
                    int(payload["value"]) % modulus,
                )
            expected = CandidateAction(
                CandidateActionKind.UPDATE_ACKNOWLEDGEMENT,
                {"key": str(payload["key"]), "stored": str(payload["value"])},
            )
        probe = probe_by_event.get(event.event_id)
        if probe is not None:
            reconstructed.append(
                (
                    probe.probe_id,
                    expected == CandidateAction(
                        probe.expected_kind, probe.expected_payload
                    ),
                    expected == step.action,
                )
            )
    horizon_rates = {}
    for horizon in HORIZONS:
        rows = tuple(
            row
            for row in reconstructed
            if long_registry.horizon_by_probe_id.get(row[0]) == horizon
        )
        horizon_rates[str(horizon)] = sum(row[2] for row in rows) / len(rows)
    return IndependentReconstruction(
        evaluation_id=evaluation.evaluation_id,
        reconstructed_probe_count=len(reconstructed),
        expected_action_match_rate=(
            sum(row[1] for row in reconstructed) / len(reconstructed)
        ),
        observed_action_match_rate=(
            sum(row[2] for row in reconstructed) / len(reconstructed)
        ),
        horizon_match_rates=horizon_rates,
    )


def _candidate_evaluation(
    preregistration: CausalSchemaPreregistration,
    interface_id: str,
    registry: VerticalSliceRegistry,
) -> VerticalCandidateEvaluation:
    combined = next(
        item for item in preregistration.arms if item.arm_id == "combined"
    )
    runtime = CausalSchemaCandidate(
        hypothesis_id=preregistration.hypothesis.hypothesis_id,
        arm=combined,
        interface_id=interface_id,
    )
    return evaluate_vertical_candidate(runtime, runtime.descriptor, registry)


def run_long_horizon_replication(
    *,
    preregistration: CausalSchemaPreregistration,
    candidate_freeze: FrozenCandidateIdentity,
    interface: SharedCandidateInterfaceContract,
    primary_registry: LongHorizonRegistry,
    order_control_registry: LongHorizonRegistry,
    replication_registry: LongHorizonRegistry,
) -> LongHorizonReplicationTrial:
    baseline_spec = reference_shared_baseline(interface)
    baseline_descriptor = SliceCandidateDescriptor(
        candidate_id=baseline_spec.candidate_id,
        name=baseline_spec.name,
        executable_digest=baseline_spec.executable_digest,
        role="registered_incumbent",
        admissible_for_search=True,
    )
    primary_baseline = evaluate_vertical_candidate(
        ReferenceSharedBaseline(baseline_spec),
        baseline_descriptor,
        primary_registry.registry,
    )
    primary_candidate = _candidate_evaluation(
        preregistration, interface.interface_id, primary_registry.registry
    )
    order_candidate = _candidate_evaluation(
        preregistration, interface.interface_id, order_control_registry.registry
    )
    replication_candidate = _candidate_evaluation(
        preregistration, interface.interface_id, replication_registry.registry
    )
    reconstruction = independently_reconstruct_replication(
        replication_candidate, replication_registry
    )
    primary_scores = _horizon_scores(primary_candidate, primary_registry)
    order_scores = _horizon_scores(order_candidate, order_control_registry)
    replication_scores = _horizon_scores(
        replication_candidate, replication_registry
    )
    evaluations = (primary_candidate, order_candidate, replication_candidate)
    checks = {
        "candidate_identity_matches_adoption_freeze_in_all_runs": all(
            item.candidate.candidate_id == candidate_freeze.candidate_id
            and item.candidate.executable_digest
            == candidate_freeze.executable_digest
            for item in evaluations
        ),
        "all_candidate_runs_pass_every_wave_one_gate": all(
            all(item.functional_gates.values()) for item in evaluations
        ),
        "all_horizons_pass_in_primary_order_control_and_replication": all(
            score == 1.0
            for scores in (primary_scores, order_scores, replication_scores)
            for score in scores.values()
        ),
        "independent_replication_reconstructs_every_expected_and_observed_action": (
            reconstruction.expected_action_match_rate == 1.0
            and reconstruction.observed_action_match_rate == 1.0
            and all(value == 1.0 for value in reconstruction.horizon_match_rates.values())
        ),
        "replication_identifiers_are_disjoint_from_primary": (
            set(primary_registry.task_order).isdisjoint(
                replication_registry.task_order
            )
        ),
        "order_control_uses_same_tasks_in_a_different_order": (
            set(primary_registry.task_order) == set(order_control_registry.task_order)
            and primary_registry.task_order != order_control_registry.task_order
        ),
        "baseline_still_fails_every_behavioral_gate": all(
            primary_baseline.functional_gates[key] == 0.0
            for key in WAVE_ONE_KEYS
            if key != "system_cost"
        ),
        "cost_and_external_service_floors_hold_in_every_run": all(
            item.functional_gates["system_cost"] == 1.0
            and item.final_cost.external_service_calls == 0
            for item in evaluations
        ),
    }
    return LongHorizonReplicationTrial(
        candidate_freeze=candidate_freeze,
        primary_registry=primary_registry,
        order_control_registry=order_control_registry,
        replication_registry=replication_registry,
        primary_baseline=primary_baseline,
        primary_candidate=primary_candidate,
        order_control_candidate=order_candidate,
        replication_candidate=replication_candidate,
        replication_reconstruction=reconstruction,
        primary_horizon_scores=primary_scores,
        order_control_horizon_scores=order_scores,
        replication_horizon_scores=replication_scores,
        check_results=checks,
        disposition="replicated" if all(checks.values()) else "replication_failed",
        limitations=(
            "The 32-step result demonstrates state persistence in a symbolic finite-field task stream, not long-context neural memory.",
            "Replication is independently seeded and independently reconstructed but runs in the same codebase and hardware environment.",
            "The result covers the five Wave-1 contracts only; later-wave composition, uncertainty, evidence conflict, retention, and global Pareto contracts remain unresolved.",
        ),
    )
