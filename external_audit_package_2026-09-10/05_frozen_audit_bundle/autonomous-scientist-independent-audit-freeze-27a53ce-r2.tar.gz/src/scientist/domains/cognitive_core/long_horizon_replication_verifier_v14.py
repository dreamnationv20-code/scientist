from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.causal_schema_mechanism_v12 import (
    CausalSchemaCandidate,
)
from scientist.domains.cognitive_core.long_horizon_replication_v14 import (
    HORIZONS,
    LongHorizonReplicationTrial,
)
from scientist.program.control_plane import AutonomousScientistControlPlane


LONG_HORIZON_REPLICATION_VERIFIER_REF = (
    "cognitive-core-long-horizon-independent-verifier-v14"
)


@dataclass(frozen=True)
class LongHorizonReplicationVerification:
    check_results: Mapping[str, bool]
    trial_id: str
    candidate_id: str
    primary_registry_id: str
    replication_registry_id: str
    horizon_scores: Mapping[str, Mapping[str, float]]
    replication_reconstruction_id: str
    disposition: str
    limitations: Tuple[str, ...]
    verifier_ref: str = LONG_HORIZON_REPLICATION_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "trial_id": self.trial_id,
            "candidate_id": self.candidate_id,
            "primary_registry_id": self.primary_registry_id,
            "replication_registry_id": self.replication_registry_id,
            "horizon_scores": {
                key: dict(sorted(item.items()))
                for key, item in sorted(self.horizon_scores.items())
            },
            "replication_reconstruction_id": self.replication_reconstruction_id,
            "disposition": self.disposition,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_long_horizon_replication(
    *,
    control: AutonomousScientistControlPlane,
    trial: LongHorizonReplicationTrial,
    replay: LongHorizonReplicationTrial,
    phase_five_manifest: Mapping[str, Any],
) -> LongHorizonReplicationVerification:
    primary = trial.primary_registry
    order = trial.order_control_registry
    replication = trial.replication_registry
    expected_horizon_counts = {1: 63, 4: 60, 16: 48, 32: 32}
    observed_horizon_counts = {
        horizon: sum(
            value == horizon for value in primary.horizon_by_probe_id.values()
        )
        for horizon in HORIZONS
    }
    primary_event_count = sum(
        len(item.events) for item in primary.registry.episodes
    )
    primary_probe_count = sum(
        len(item.probes) for item in primary.registry.episodes
    )
    replication_event_count = sum(
        len(item.events) for item in replication.registry.episodes
    )
    replication_probe_count = sum(
        len(item.probes) for item in replication.registry.episodes
    )
    control_value = control.as_dict()
    progress = control.graph.progress_by_role()
    checks = {
        "phase_five_adoption_and_frozen_candidate_are_bound": (
            bool(phase_five_manifest.get("passed"))
            and phase_five_manifest["disposition"] == "adopt_for_replication"
            and trial.candidate_freeze.freeze_id
            == phase_five_manifest["candidate_freeze"]["freeze_id"]
            and trial.candidate_freeze.candidate_id
            == phase_five_manifest["candidate_freeze"]["candidate_id"]
        ),
        "candidate_source_remains_identical_to_adoption_freeze": (
            trial.candidate_freeze.implementation_source_digest
            == content_digest(inspect.getsource(CausalSchemaCandidate))
        ),
        "primary_and_replication_each_have_full_long_trajectory_scale": (
            len(primary.registry.episodes) == 64
            and len(replication.registry.episodes) == 64
            and primary_event_count == replication_event_count == 715
            and primary_probe_count == replication_probe_count == 651
        ),
        "horizon_ladder_has_exact_preregistered_coverage": (
            observed_horizon_counts == expected_horizon_counts
            and {
                horizon: sum(
                    value == horizon
                    for value in replication.horizon_by_probe_id.values()
                )
                for horizon in HORIZONS
            }
            == expected_horizon_counts
        ),
        "primary_order_control_and_replication_pass_all_horizons": all(
            value == 1.0
            for scores in (
                trial.primary_horizon_scores,
                trial.order_control_horizon_scores,
                trial.replication_horizon_scores,
            )
            for value in scores.values()
        ),
        "all_three_candidate_runs_pass_every_wave_one_gate": all(
            all(item.functional_gates.values())
            for item in (
                trial.primary_candidate,
                trial.order_control_candidate,
                trial.replication_candidate,
            )
        ),
        "order_control_uses_same_task_set_in_different_sequence": (
            set(primary.task_order) == set(order.task_order)
            and primary.task_order != order.task_order
        ),
        "replication_task_identities_are_fully_disjoint": set(
            primary.task_order
        ).isdisjoint(replication.task_order),
        "independent_reconstructor_covers_all_replication_probes": (
            trial.replication_reconstruction.reconstructed_probe_count == 651
            and trial.replication_reconstruction.expected_action_match_rate == 1.0
            and trial.replication_reconstruction.observed_action_match_rate == 1.0
            and all(
                value == 1.0
                for value in trial.replication_reconstruction.horizon_match_rates.values()
            )
        ),
        "baseline_fails_behavior_while_cost_floor_remains_comparable": (
            all(
                trial.primary_baseline.functional_gates[key] == 0.0
                for key in (
                    "procedure_representation",
                    "relevance_representation",
                    "requested_change",
                    "task_inference",
                )
            )
            and trial.primary_baseline.functional_gates["system_cost"] == 1.0
        ),
        "candidate_identity_and_cost_floor_hold_in_every_run": all(
            item.candidate.candidate_id == trial.candidate_freeze.candidate_id
            and item.candidate.executable_digest
            == trial.candidate_freeze.executable_digest
            and item.functional_gates["system_cost"] == 1.0
            and item.final_cost.external_service_calls == 0
            for item in (
                trial.primary_candidate,
                trial.order_control_candidate,
                trial.replication_candidate,
            )
        ),
        "trial_internal_checks_and_replication_disposition_pass": (
            trial.passed
            and all(trial.check_results.values())
            and trial.disposition == "replicated"
        ),
        "trial_replay_is_content_identical": trial.trial_id == replay.trial_id,
        "replication_does_not_overclaim_goal_graph_integration": (
            not control_value["campaigns"]
            and progress["objective"]["integrated"] == 0
            and progress["objective"]["total"] == 44
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    return LongHorizonReplicationVerification(
        check_results=checks,
        trial_id=trial.trial_id,
        candidate_id=trial.candidate_freeze.candidate_id,
        primary_registry_id=primary.long_registry_id,
        replication_registry_id=replication.long_registry_id,
        horizon_scores={
            "primary": trial.primary_horizon_scores,
            "order_control": trial.order_control_horizon_scores,
            "replication": trial.replication_horizon_scores,
        },
        replication_reconstruction_id=(
            trial.replication_reconstruction.reconstruction_id
        ),
        disposition=trial.disposition,
        limitations=(
            "This confirms the mechanism through 32 intervening symbolic tasks, not arbitrary real-world trajectory length.",
            "The replication generator and independent reconstructor are local implementations; external replication is still absent.",
            "The evidence supports a replicated Wave-1 microdomain milestone, not completion of the 18-work-package cognitive core.",
        ),
    )
