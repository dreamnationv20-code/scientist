from __future__ import annotations

from scientist.kernel.contracts import MetricDirection, MetricSpec
from scientist.program.goal_graph import (
    CompositionOperator,
    ExecutableLeafContract,
    GoalGraphDecompositionProposal,
    GoalNodeKind,
    GoalNodeSpec,
    ParentCompositionRule,
)

from scientist.domains.cognitive_core.goal_program import (
    COGNITIVE_GOAL_PROGRAM_VERSION,
    fresh_goal_graph_spec,
)


MEASUREMENT_PROGRAM_VERSION = "cognitive-core-measurement-goal-v3"


def _qualification_leaf(
    *,
    goal_id: str,
    title: str,
    question: str,
    hypothesis: str,
    parent_decision: str,
    success_conditions: tuple[str, ...],
    falsification_conditions: tuple[str, ...],
    expected_artifact: str,
    testbed_ref: str,
    experiment_budget: float,
    tags: tuple[str, ...],
) -> GoalNodeSpec:
    metric = MetricSpec(
        name="qualification_gate",
        direction=MetricDirection.TARGET,
        unit="binary gate",
        aggregation="all preregistered checks",
        primary=True,
        target=1.0,
    )
    contract = ExecutableLeafContract(
        hypothesis=hypothesis,
        parent_decision=parent_decision,
        root_metric_link=(
            "A failed measurement qualification blocks every cognitive-core "
            "capability and the terminal Pareto gate."
        ),
        metric=metric,
        success_conditions=success_conditions,
        falsification_conditions=falsification_conditions,
        testbed_ref=testbed_ref,
        parent_integration_test=(
            "The produced evidence must satisfy this leaf and be independently "
            "reconstructed as part of the complete measurement qualification."
        ),
        experiment_budget=experiment_budget,
        preregistration_ref=MEASUREMENT_PROGRAM_VERSION,
    )
    return GoalNodeSpec(
        goal_id=goal_id,
        title=title,
        question=question,
        kind=GoalNodeKind.EXECUTABLE_LEAF,
        rationale=(
            "Measurement is accepted only through executable positive, negative, "
            "tamper, and identity controls."
        ),
        success_conditions=success_conditions,
        falsification_conditions=falsification_conditions,
        expected_artifact=expected_artifact,
        critical=True,
        leaf_contract=contract,
        tags=("measurement-v3", "qualification", *tags),
    )


def measurement_decomposition() -> GoalGraphDecompositionProposal:
    spec = fresh_goal_graph_spec()
    parent = spec.nodes["measurement"]
    partition_integrity = _qualification_leaf(
        goal_id=parent.goal_id,
        title="Partition, identity, and provenance integrity",
        question=(
            "Are development, audit, transfer, and terminal cases generated "
            "deterministically with disjoint identities and hidden targets?"
        ),
        hypothesis=(
            "A keyed dynamic generator and immutable provenance ledger prevent "
            "case reuse, target exposure, and task-family collisions."
        ),
        parent_decision="whether fresh evidence can be treated as quarantined",
        success_conditions=(
            "all partition, case, task-family, and exposure identities are disjoint",
            "regeneration from a frozen contract is byte-identical",
            "public inputs contain neither hidden targets nor verifier secrets",
        ),
        falsification_conditions=(
            "any identity collision or target leakage is detected",
            "a supposedly sealed case was generated from an exposed seed",
        ),
        expected_artifact="partition and provenance qualification report",
        testbed_ref="cognitive-core-measurement-partitions-v3",
        experiment_budget=3.0,
        tags=("partition", "provenance", "contamination"),
    )
    construct_validity = _qualification_leaf(
        goal_id=parent.goal_id,
        title="Multi-capability construct validity",
        question=(
            "Do procedures, rapid learning, knowledge boundaries, evidence use, "
            "updating, and retention produce separable control signatures?"
        ),
        hypothesis=(
            "Oracle, shortcut, specialist, destructive-update, and cost-inflated "
            "controls yield the preregistered opposing capability signatures."
        ),
        parent_decision="whether capability scores measure distinct constructs",
        success_conditions=(
            "the semantic oracle passes every capability axis",
            "each seeded negative control fails its intended axis",
            "control fingerprints are distinct and every axis is discriminated",
        ),
        falsification_conditions=(
            "a shortcut control passes as transferable cognition",
            "two conceptually different controls are measurement-indistinguishable",
        ),
        expected_artifact="control-signature construct-validity report",
        testbed_ref="cognitive-core-measurement-constructs-v3",
        experiment_budget=5.0,
        tags=("construct-validity", "controls", "capability-floors"),
    )
    independent_verification = _qualification_leaf(
        goal_id=parent.goal_id,
        title="Independent semantic and metric reconstruction",
        question=(
            "Can an evaluator-independent verifier reconstruct every hidden "
            "target, capability metric, and aggregate gate?"
        ),
        hypothesis=(
            "A separate semantics implementation rejects altered predictions, "
            "reported correctness, capability labels, and aggregate metrics."
        ),
        parent_decision="whether reported candidate gains are auditable",
        success_conditions=(
            "every case target is independently reconstructed",
            "tampered outcomes and aggregate metrics are rejected",
            "raw case-level evidence deterministically reproduces every score",
        ),
        falsification_conditions=(
            "the evaluator and verifier share an unverified answer path",
            "a modified metric or outcome passes verification",
        ),
        expected_artifact="independent reconstruction and tamper report",
        testbed_ref="cognitive-core-measurement-verifier-v3",
        experiment_budget=4.0,
        tags=("independent-verifier", "tamper", "reconstruction"),
    )
    cost_integrity = _qualification_leaf(
        goal_id=parent.goal_id,
        title="End-to-end cost and horizon integrity",
        question=(
            "Does the laboratory account for model, training, context, retrieval, "
            "storage, inference, and adaptation costs at every horizon?"
        ),
        hypothesis=(
            "A normalized resource ledger detects cost displacement and prevents "
            "cheap-horizon evidence from satisfying a later claim."
        ),
        parent_decision="whether candidate comparisons are total-cost matched",
        success_conditions=(
            "all resource components are finite, non-negative, and reconstructable",
            "a behaviorally identical but cost-inflated control loses dominance",
            "each result is bound to exactly one preregistered horizon",
        ),
        falsification_conditions=(
            "retrieval, storage, context, or adaptation cost is omitted",
            "development evidence can be relabeled as terminal evidence",
        ),
        expected_artifact="resource-ledger and horizon-binding qualification report",
        testbed_ref="cognitive-core-measurement-cost-v3",
        experiment_budget=4.0,
        tags=("system-cost", "horizon", "pareto"),
    )
    children = (
        partition_integrity,
        construct_validity,
        independent_verification,
        cost_integrity,
    )
    rule = ParentCompositionRule(
        parent_id=parent.node_id,
        child_ids=tuple(child.node_id for child in children),
        operator=CompositionOperator.ALL,
        integration_test=(
            "All four qualification leaves pass on the same frozen generator, "
            "semantics, verifier, horizon registry, and resource schema."
        ),
        rationale=(
            "Partition integrity, construct validity, verifier independence, and "
            "cost integrity are non-substitutable measurement requirements."
        ),
        decomposer_ref=(
            COGNITIVE_GOAL_PROGRAM_VERSION + "+" + MEASUREMENT_PROGRAM_VERSION
        ),
    )
    return GoalGraphDecompositionProposal(
        parent_id=parent.node_id,
        nodes=children,
        rule=rule,
        assumptions=(
            "dynamic symbolic probes are mechanism qualifications, not the terminal claim",
            "natural-task and scale validity remain separate downstream gates",
        ),
        distinguishing_predictions=(
            "memorization-only controls fail procedural and rapid-learning axes",
            "unselective evidence controls fail conflict and irrelevance cases",
            "destructive editors pass updates but fail unrelated retention",
            "identical behavior with higher total cost fails Pareto dominance",
        ),
        reasoning=(
            "The literature review rules out a single aggregate benchmark as a "
            "valid laboratory qualification."
        ),
    )

