from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
import random
from typing import Any, Dict, Iterable, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import EvidencePartition


MEASUREMENT_LAB_VERSION = "cognitive-core-measurement-lab-v3"
ABSTAIN = -1
MODULUS = 17


class CapabilityAxis(str, Enum):
    PROCEDURAL_TRANSFER = "procedural_transfer"
    RAPID_TASK_LEARNING = "rapid_task_learning"
    KNOWLEDGE_BOUNDARY = "knowledge_boundary"
    EVIDENCE_USE = "evidence_use"
    KNOWLEDGE_UPDATE = "knowledge_update"
    RETENTION = "retention"


class ReferenceControl(str, Enum):
    SEMANTIC_ORACLE = "semantic_oracle"
    MEMORIZER = "memorizer"
    PROCEDURE_SPECIALIST = "procedure_specialist"
    DEMONSTRATION_LEARNER = "demonstration_learner"
    UNSELECTIVE_EVIDENCE = "unselective_evidence"
    ALWAYS_ANSWER = "always_answer"
    DESTRUCTIVE_EDITOR = "destructive_editor"


@dataclass(frozen=True)
class EvidenceSignal:
    key: int
    value: int
    provenance: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "value": self.value,
            "provenance": self.provenance,
        }


@dataclass(frozen=True)
class MeasurementCase:
    partition: EvidencePartition
    axis: CapabilityAxis
    mode: str
    seed: int
    family_id: str
    query_key: int = 0
    operation: str = ""
    operands: Tuple[int, ...] = ()
    demonstrations: Tuple[Tuple[int, int], ...] = ()
    evidence: Tuple[EvidenceSignal, ...] = ()
    base_answer: int | None = None
    expected_answer: int = ABSTAIN
    generator_version: str = MEASUREMENT_LAB_VERSION

    def __post_init__(self) -> None:
        if not self.mode or not self.family_id:
            raise ValueError("measurement case identity is incomplete")
        if self.expected_answer != ABSTAIN and not (
            0 <= self.expected_answer < MODULUS
        ):
            raise ValueError("measurement target is outside the label space")
        if self.base_answer is not None and not 0 <= self.base_answer < MODULUS:
            raise ValueError("base answer is outside the label space")

    def public_as_dict(self) -> Dict[str, Any]:
        return {
            "axis": self.axis.value,
            "mode": self.mode,
            "query_key": self.query_key,
            "operation": self.operation,
            "operands": list(self.operands),
            "demonstrations": [list(item) for item in self.demonstrations],
            "evidence": [item.as_dict() for item in self.evidence],
        }

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "generator_version": self.generator_version,
            "partition": self.partition.value,
            "axis": self.axis.value,
            "mode": self.mode,
            "seed": self.seed,
            "family_id": self.family_id,
            "public_input": self.public_as_dict(),
            "base_answer": self.base_answer,
            "expected_answer": self.expected_answer,
        }
        if include_id:
            value["case_id"] = self.case_id
        return value

    @property
    def case_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))


@dataclass(frozen=True)
class ResourceLedger:
    trainable_parameters: float
    training_tokens: float
    context_tokens: float
    retrieval_queries: float
    external_storage_bytes: float
    inference_flops: float
    adaptation_flops: float
    wall_clock_seconds: float
    schema_version: str = "cognitive-core-resource-ledger-v1"

    def __post_init__(self) -> None:
        values = self.components.values()
        if not all(math.isfinite(value) and value >= 0.0 for value in values):
            raise ValueError("resource-ledger components must be finite and non-negative")

    @property
    def components(self) -> Mapping[str, float]:
        return {
            "trainable_parameters": float(self.trainable_parameters),
            "training_tokens": float(self.training_tokens),
            "context_tokens": float(self.context_tokens),
            "retrieval_queries": float(self.retrieval_queries),
            "external_storage_bytes": float(self.external_storage_bytes),
            "inference_flops": float(self.inference_flops),
            "adaptation_flops": float(self.adaptation_flops),
            "wall_clock_seconds": float(self.wall_clock_seconds),
        }

    @property
    def normalized_total(self) -> float:
        return (
            self.trainable_parameters / 1_000_000.0
            + self.training_tokens / 1_000_000.0
            + self.context_tokens / 1_000.0
            + self.retrieval_queries
            + self.external_storage_bytes / 1_000_000.0
            + self.inference_flops / 1_000_000_000.0
            + self.adaptation_flops / 1_000_000_000.0
            + self.wall_clock_seconds
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "components": dict(sorted(self.components.items())),
            "normalized_total": self.normalized_total,
        }


@dataclass(frozen=True)
class MeasurementOutcome:
    case_id: str
    control: ReferenceControl
    predicted_answer: int
    reported_correct: bool
    evaluator_ref: str = "cognitive-core-measurement-evaluator-v3"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "case_id": self.case_id,
            "control": self.control.value,
            "predicted_answer": self.predicted_answer,
            "reported_correct": self.reported_correct,
            "evaluator_ref": self.evaluator_ref,
        }


@dataclass(frozen=True)
class MeasurementQualificationReport:
    passed: bool
    checks: Mapping[str, bool]
    signatures: Mapping[str, Mapping[str, float]]
    metrics: Mapping[str, float]
    suite_size: int
    qualification_version: str = MEASUREMENT_LAB_VERSION

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "signatures": {
                name: dict(sorted(values.items()))
                for name, values in sorted(self.signatures.items())
            },
            "metrics": dict(sorted(self.metrics.items())),
            "suite_size": self.suite_size,
            "qualification_version": self.qualification_version,
        }


# Public salts are intentionally limited to laboratory self-qualification.
# Candidate evaluation must inject a fresh, externally held partition nonce.
_QUALIFICATION_PARTITION_NONCES = {
    EvidencePartition.DEVELOPMENT: 104_729,
    EvidencePartition.GUARD: 130_363,
    EvidencePartition.AUDIT: 155_921,
    EvidencePartition.REPLICATION: 196_613,
    EvidencePartition.EXTERNAL_CONFIRMATION: 235_849,
}


def _nonzero(value: int) -> int:
    normalized = value % MODULUS
    return normalized if normalized != 0 else 1


def _execute_operation(operation: str, operands: Tuple[int, ...]) -> int:
    if len(operands) != 2:
        raise ValueError("procedural operation requires two operands")
    left, right = operands
    if operation == "add_mod":
        return (left + right) % MODULUS
    if operation == "xor_mod":
        return (left ^ right) % MODULUS
    if operation == "max":
        return max(left, right)
    if operation == "compose":
        return (left * right + left + right) % MODULUS
    raise ValueError("unknown procedural operation")


def _family_id(
    partition: EvidencePartition,
    axis: CapabilityAxis,
    seed: int,
    partition_nonce: int,
) -> str:
    return content_digest(
        {
            "version": MEASUREMENT_LAB_VERSION,
            "partition": partition.value,
            "axis": axis.value,
            "family_seed": seed // 2,
            "nonce": partition_nonce,
        }
    )


def generate_measurement_case(
    axis: CapabilityAxis,
    seed: int,
    partition: EvidencePartition,
    *,
    partition_nonce: int | None = None,
) -> MeasurementCase:
    nonce = (
        _QUALIFICATION_PARTITION_NONCES[partition]
        if partition_nonce is None
        else partition_nonce
    )
    if nonce <= 0:
        raise ValueError("measurement partition nonce must be positive")
    rng = random.Random(seed + nonce)
    family_id = _family_id(partition, axis, seed, nonce)
    query_key = nonce + seed * 31
    base = _nonzero(rng.randrange(MODULUS))

    if axis == CapabilityAxis.PROCEDURAL_TRANSFER:
        operation = ("add_mod", "xor_mod", "max", "compose")[seed % 4]
        operands = (rng.randrange(1, MODULUS), rng.randrange(1, MODULUS))
        return MeasurementCase(
            partition=partition,
            axis=axis,
            mode="unseen_composition" if seed % 2 else "unseen_operands",
            seed=seed,
            family_id=family_id,
            operation=operation,
            operands=operands,
            expected_answer=_execute_operation(operation, operands),
        )
    if axis == CapabilityAxis.RAPID_TASK_LEARNING:
        slope = rng.randrange(1, MODULUS)
        intercept = rng.randrange(1, MODULUS)
        query = 4 + seed % 5
        while (slope * query + intercept) % MODULUS == 0:
            intercept = (intercept + 1) % MODULUS
        demonstrations = tuple(
            (value, (slope * value + intercept) % MODULUS)
            for value in (1, 2, 3)
        )
        return MeasurementCase(
            partition=partition,
            axis=axis,
            mode="unseen_affine_task",
            seed=seed,
            family_id=family_id,
            query_key=query,
            demonstrations=demonstrations,
            expected_answer=(slope * query + intercept) % MODULUS,
        )
    if axis == CapabilityAxis.KNOWLEDGE_BOUNDARY:
        known = seed % 2 == 0
        return MeasurementCase(
            partition=partition,
            axis=axis,
            mode="known" if known else "unknown",
            seed=seed,
            family_id=family_id,
            query_key=query_key,
            base_answer=base if known else None,
            expected_answer=base if known else ABSTAIN,
        )
    if axis == CapabilityAxis.EVIDENCE_USE:
        mode = ("relevant", "irrelevant", "conflicting", "missing")[seed % 4]
        if mode == "relevant":
            answer = _nonzero(base + 3)
            evidence = (EvidenceSignal(query_key, answer, "current-oracle"),)
            base_answer = None
        elif mode == "irrelevant":
            answer = base
            evidence = (
                EvidenceSignal(query_key + 1, _nonzero(base + 5), "irrelevant"),
            )
            base_answer = base
        elif mode == "conflicting":
            answer = _nonzero(base + 7)
            if answer == base:
                answer = _nonzero(answer + 1)
            evidence = (EvidenceSignal(query_key, answer, "newer-source"),)
            base_answer = base
        else:
            answer = ABSTAIN
            evidence = ()
            base_answer = None
        return MeasurementCase(
            partition=partition,
            axis=axis,
            mode=mode,
            seed=seed,
            family_id=family_id,
            query_key=query_key,
            evidence=evidence,
            base_answer=base_answer,
            expected_answer=answer,
        )
    if axis == CapabilityAxis.KNOWLEDGE_UPDATE:
        updated = _nonzero(base + 1 + seed % (MODULUS - 1))
        if updated == base:
            updated = _nonzero(updated + 1)
        return MeasurementCase(
            partition=partition,
            axis=axis,
            mode="targeted_update",
            seed=seed,
            family_id=family_id,
            query_key=query_key,
            evidence=(EvidenceSignal(query_key, updated, "timestamp-new"),),
            base_answer=base,
            expected_answer=updated,
        )
    if axis == CapabilityAxis.RETENTION:
        return MeasurementCase(
            partition=partition,
            axis=axis,
            mode="unrelated_after_update",
            seed=seed,
            family_id=family_id,
            query_key=query_key + 1,
            evidence=(EvidenceSignal(query_key, _nonzero(base + 4), "other-update"),),
            base_answer=base,
            expected_answer=base,
        )
    raise ValueError("unsupported capability axis")


def generate_measurement_suite(
    partition: EvidencePartition,
    seeds: Iterable[int] = range(8),
    *,
    partition_nonce: int | None = None,
) -> Tuple[MeasurementCase, ...]:
    return tuple(
        generate_measurement_case(
            axis,
            seed,
            partition,
            partition_nonce=partition_nonce,
        )
        for axis in CapabilityAxis
        for seed in seeds
    )


def reconstruct_expected(case: MeasurementCase) -> int:
    if case.axis == CapabilityAxis.PROCEDURAL_TRANSFER:
        return _execute_operation(case.operation, case.operands)
    if case.axis == CapabilityAxis.RAPID_TASK_LEARNING:
        (x1, y1), (x2, y2), *_ = case.demonstrations
        slope = ((y2 - y1) * pow((x2 - x1) % MODULUS, -1, MODULUS)) % MODULUS
        intercept = (y1 - slope * x1) % MODULUS
        return (slope * case.query_key + intercept) % MODULUS
    if case.axis == CapabilityAxis.KNOWLEDGE_BOUNDARY:
        return ABSTAIN if case.mode == "unknown" else int(case.base_answer)
    if case.axis == CapabilityAxis.EVIDENCE_USE:
        matches = tuple(item for item in case.evidence if item.key == case.query_key)
        if matches:
            return matches[0].value
        return ABSTAIN if case.base_answer is None else case.base_answer
    if case.axis == CapabilityAxis.KNOWLEDGE_UPDATE:
        matches = tuple(item for item in case.evidence if item.key == case.query_key)
        if len(matches) != 1:
            raise ValueError("update case lacks one matching update")
        return matches[0].value
    if case.axis == CapabilityAxis.RETENTION:
        if case.base_answer is None:
            raise ValueError("retention case lacks its preserved answer")
        return case.base_answer
    raise ValueError("unsupported capability axis")


def _demo_prediction(case: MeasurementCase) -> int:
    return reconstruct_expected(case)


def reference_prediction(control: ReferenceControl, case: MeasurementCase) -> int:
    if control == ReferenceControl.SEMANTIC_ORACLE:
        return reconstruct_expected(case)
    if control == ReferenceControl.PROCEDURE_SPECIALIST:
        return (
            reconstruct_expected(case)
            if case.axis == CapabilityAxis.PROCEDURAL_TRANSFER
            else 0
        )
    if control == ReferenceControl.DEMONSTRATION_LEARNER:
        return (
            _demo_prediction(case)
            if case.axis == CapabilityAxis.RAPID_TASK_LEARNING
            else 0
        )
    if control == ReferenceControl.UNSELECTIVE_EVIDENCE:
        return case.evidence[0].value if case.evidence else 0
    if control == ReferenceControl.ALWAYS_ANSWER:
        return 0
    if control == ReferenceControl.DESTRUCTIVE_EDITOR:
        if case.axis == CapabilityAxis.KNOWLEDGE_UPDATE:
            return reconstruct_expected(case)
        if case.axis == CapabilityAxis.RETENTION:
            return 0
        return 0
    if control == ReferenceControl.MEMORIZER:
        if case.axis == CapabilityAxis.PROCEDURAL_TRANSFER:
            return 0
        if case.axis == CapabilityAxis.RAPID_TASK_LEARNING:
            return 0
        return 0 if case.base_answer is None else case.base_answer
    raise ValueError("unsupported reference control")


def evaluate_reference(
    control: ReferenceControl,
    cases: Iterable[MeasurementCase],
) -> Tuple[MeasurementOutcome, ...]:
    return tuple(
        MeasurementOutcome(
            case_id=case.case_id,
            control=control,
            predicted_answer=reference_prediction(control, case),
            reported_correct=(
                reference_prediction(control, case) == case.expected_answer
            ),
        )
        for case in cases
    )


def capability_signature(
    cases: Tuple[MeasurementCase, ...],
    outcomes: Tuple[MeasurementOutcome, ...],
) -> Mapping[str, float]:
    by_id = {case.case_id: case for case in cases}
    values: Dict[str, float] = {}
    for axis in CapabilityAxis:
        relevant = tuple(
            item
            for item in outcomes
            if by_id[item.case_id].axis == axis
        )
        values[axis.value] = sum(item.reported_correct for item in relevant) / float(
            len(relevant)
        )
    return values


def pareto_dominates(
    left_score: float,
    left_cost: ResourceLedger,
    right_score: float,
    right_cost: ResourceLedger,
) -> bool:
    return (
        left_score >= right_score
        and left_cost.normalized_total <= right_cost.normalized_total
        and (
            left_score > right_score
            or left_cost.normalized_total < right_cost.normalized_total
        )
    )


def run_measurement_qualification(
    *,
    partition_nonces: Mapping[EvidencePartition, int] | None = None,
) -> MeasurementQualificationReport:
    from scientist.domains.cognitive_core.measurement_verifier_v3 import (
        verify_outcome,
    )

    partitions = tuple(EvidencePartition)
    nonces = (
        dict(_QUALIFICATION_PARTITION_NONCES)
        if partition_nonces is None
        else dict(partition_nonces)
    )
    if set(nonces) != set(partitions):
        raise ValueError("measurement qualification requires every partition nonce")
    if any(
        not isinstance(nonce, int) or nonce <= 0 for nonce in nonces.values()
    ):
        raise ValueError("measurement qualification nonces must be positive integers")
    if len(set(nonces.values())) != len(nonces):
        raise ValueError("measurement qualification nonces must be disjoint")
    suites = {
        partition: generate_measurement_suite(
            partition,
            partition_nonce=nonces[partition],
        )
        for partition in partitions
    }
    regenerated = generate_measurement_suite(
        EvidencePartition.DEVELOPMENT,
        partition_nonce=nonces[EvidencePartition.DEVELOPMENT],
    )
    audit_nonce = nonces[EvidencePartition.AUDIT]
    injected_audit = generate_measurement_suite(
        EvidencePartition.AUDIT,
        partition_nonce=audit_nonce + 2,
    )
    reinjected_audit = generate_measurement_suite(
        EvidencePartition.AUDIT,
        partition_nonce=audit_nonce + 4,
    )
    all_cases = tuple(case for suite in suites.values() for case in suite)
    development = suites[EvidencePartition.DEVELOPMENT]
    outcomes = {
        control: evaluate_reference(control, development)
        for control in ReferenceControl
    }
    signatures = {
        control.value: capability_signature(development, result)
        for control, result in outcomes.items()
    }
    fingerprints = {
        control.value: content_digest(
            tuple(item.predicted_answer for item in result)
        )
        for control, result in outcomes.items()
    }
    semantic = outcomes[ReferenceControl.SEMANTIC_ORACLE]
    tampered = MeasurementOutcome(
        case_id=semantic[0].case_id,
        control=semantic[0].control,
        predicted_answer=semantic[0].predicted_answer,
        reported_correct=not semantic[0].reported_correct,
    )
    base_cost = ResourceLedger(
        trainable_parameters=1_000_000,
        training_tokens=1_000_000,
        context_tokens=1_000,
        retrieval_queries=0,
        external_storage_bytes=0,
        inference_flops=1_000_000_000,
        adaptation_flops=0,
        wall_clock_seconds=1.0,
    )
    inflated_cost = ResourceLedger(
        trainable_parameters=1_000_000,
        training_tokens=1_000_000,
        context_tokens=20_000,
        retrieval_queries=10,
        external_storage_bytes=50_000_000,
        inference_flops=5_000_000_000,
        adaptation_flops=2_000_000_000,
        wall_clock_seconds=10.0,
    )
    invalid_cost_rejected = False
    try:
        ResourceLedger(-1, 0, 0, 0, 0, 0, 0, 0)
    except ValueError:
        invalid_cost_rejected = True
    axis_discriminated = all(
        len({signature[axis.value] for signature in signatures.values()}) >= 2
        for axis in CapabilityAxis
    )
    family_sets = {
        partition: {item.family_id for item in suite}
        for partition, suite in suites.items()
    }
    partition_families_disjoint = all(
        family_sets[left].isdisjoint(family_sets[right])
        for index, left in enumerate(partitions)
        for right in partitions[index + 1 :]
    )
    checks = {
        "partition_case_ids_are_disjoint": (
            len(all_cases) == len({item.case_id for item in all_cases})
        ),
        "partition_family_ids_are_disjoint": partition_families_disjoint,
        "generator_is_deterministic": (
            suites[EvidencePartition.DEVELOPMENT] == regenerated
        ),
        "external_partition_nonce_changes_identities": (
            {item.case_id for item in injected_audit}.isdisjoint(
                item.case_id for item in reinjected_audit
            )
            and {item.family_id for item in injected_audit}.isdisjoint(
                item.family_id for item in reinjected_audit
            )
        ),
        "public_inputs_hide_targets": all(
            "expected_answer" not in case.public_as_dict()
            and "base_answer" not in case.public_as_dict()
            for case in all_cases
        ),
        "axes_are_balanced": all(
            sum(case.axis == axis for case in development) == 8
            for axis in CapabilityAxis
        ),
        "semantic_oracle_is_perfect": all(item.reported_correct for item in semantic),
        "control_fingerprints_are_distinct": (
            len(fingerprints) == len(set(fingerprints.values()))
        ),
        "every_axis_is_discriminated": axis_discriminated,
        "memorizer_does_not_fake_transfer": (
            signatures[ReferenceControl.MEMORIZER.value][
                CapabilityAxis.PROCEDURAL_TRANSFER.value
            ]
            < 0.5
            and signatures[ReferenceControl.MEMORIZER.value][
                CapabilityAxis.RAPID_TASK_LEARNING.value
            ]
            < 0.5
        ),
        "demonstration_learning_is_detected": (
            signatures[ReferenceControl.DEMONSTRATION_LEARNER.value][
                CapabilityAxis.RAPID_TASK_LEARNING.value
            ]
            == 1.0
        ),
        "unselective_evidence_is_detected": (
            0.0
            < signatures[ReferenceControl.UNSELECTIVE_EVIDENCE.value][
                CapabilityAxis.EVIDENCE_USE.value
            ]
            < 1.0
        ),
        "destructive_updates_are_detected": (
            signatures[ReferenceControl.DESTRUCTIVE_EDITOR.value][
                CapabilityAxis.KNOWLEDGE_UPDATE.value
            ]
            == 1.0
            and signatures[ReferenceControl.DESTRUCTIVE_EDITOR.value][
                CapabilityAxis.RETENTION.value
            ]
            == 0.0
        ),
        "always_answer_fails_knowledge_boundary": (
            signatures[ReferenceControl.ALWAYS_ANSWER.value][
                CapabilityAxis.KNOWLEDGE_BOUNDARY.value
            ]
            < 1.0
        ),
        "verifier_reconstructs_all_outcomes": all(
            verify_outcome(case, outcome)
            for case, outcome in zip(development, semantic)
        ),
        "verifier_rejects_tampering": not verify_outcome(
            development[0], tampered
        ),
        "invalid_cost_is_rejected": invalid_cost_rejected,
        "cost_total_is_reconstructable": math.isclose(
            base_cost.normalized_total,
            sum(
                (
                    base_cost.trainable_parameters / 1_000_000.0,
                    base_cost.training_tokens / 1_000_000.0,
                    base_cost.context_tokens / 1_000.0,
                    base_cost.retrieval_queries,
                    base_cost.external_storage_bytes / 1_000_000.0,
                    base_cost.inference_flops / 1_000_000_000.0,
                    base_cost.adaptation_flops / 1_000_000_000.0,
                    base_cost.wall_clock_seconds,
                )
            ),
            abs_tol=1e-12,
        ),
        "cost_inflation_breaks_dominance": pareto_dominates(
            1.0, base_cost, 1.0, inflated_cost
        ),
    }
    metrics = {
        "partition_count": float(len(partitions)),
        "axis_count": float(len(CapabilityAxis)),
        "control_count": float(len(ReferenceControl)),
        "development_case_count": float(len(development)),
        "total_case_count": float(len(all_cases)),
        "base_normalized_cost": base_cost.normalized_total,
        "inflated_normalized_cost": inflated_cost.normalized_total,
    }
    return MeasurementQualificationReport(
        passed=all(checks.values()),
        checks=checks,
        signatures=signatures,
        metrics=metrics,
        suite_size=len(all_cases),
    )
