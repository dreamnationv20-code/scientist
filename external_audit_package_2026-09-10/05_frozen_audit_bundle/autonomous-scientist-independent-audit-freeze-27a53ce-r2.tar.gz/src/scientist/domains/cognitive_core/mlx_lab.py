from __future__ import annotations

import math
import platform
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.learning import (
    ABSTAIN_CLASS,
    LEARNING_CONTRACT_VERSION,
    SEQUENCE_LENGTH,
    VOCAB_SIZE,
    EncodedExample,
    LearningConfig,
    evaluation_suite,
    training_batch,
)

MLX_LAB_VERSION = "cognitive-core-mlx-lab-v6"


class TinyCognitiveTransformer(nn.Module):
    def __init__(self, config: LearningConfig) -> None:
        super().__init__()
        self.token_embedding = nn.Embedding(VOCAB_SIZE, config.width)
        self.position_embedding = nn.Embedding(
            SEQUENCE_LENGTH,
            config.width,
        )
        self.layers = [
            nn.TransformerEncoderLayer(
                dims=config.width,
                num_heads=config.heads,
                mlp_dims=4 * config.width,
                dropout=0.0,
                norm_first=True,
            )
            for _ in range(config.layers)
        ]
        self.norm = nn.LayerNorm(config.width)
        self.output = nn.Linear(config.width, ABSTAIN_CLASS + 1)

    def __call__(self, tokens: mx.array) -> mx.array:
        positions = mx.arange(tokens.shape[1])
        hidden = (
            self.token_embedding(tokens)
            + self.position_embedding(positions)
        )
        for layer in self.layers:
            hidden = layer(hidden, None)
        return self.output(self.norm(hidden[:, 0, :]))


@dataclass(frozen=True)
class CheckpointMetrics:
    step: int
    loss: float
    procedure_accuracy: float
    memory_accuracy: float
    oracle_evidence_accuracy: float
    irrelevant_evidence_accuracy: float
    known_answer_destruction: float

    def as_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "loss": self.loss,
            "procedure_accuracy": self.procedure_accuracy,
            "memory_accuracy": self.memory_accuracy,
            "oracle_evidence_accuracy": self.oracle_evidence_accuracy,
            "irrelevant_evidence_accuracy": (
                self.irrelevant_evidence_accuracy
            ),
            "known_answer_destruction": self.known_answer_destruction,
        }


@dataclass(frozen=True)
class LearnedRunResult:
    run_id: str
    config: LearningConfig
    parameter_count: int
    elapsed_seconds: float
    metrics: Mapping[str, float]
    checkpoints: Tuple[CheckpointMetrics, ...]
    framework: str
    hardware: str
    lab_version: str
    learning_contract_version: str
    execution_mode: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "config": self.config.as_dict(),
            "parameter_count": self.parameter_count,
            "elapsed_seconds": self.elapsed_seconds,
            "metrics": dict(sorted(self.metrics.items())),
            "checkpoints": [
                checkpoint.as_dict()
                for checkpoint in self.checkpoints
            ],
            "framework": self.framework,
            "hardware": self.hardware,
            "lab_version": self.lab_version,
            "learning_contract_version": self.learning_contract_version,
            "execution_mode": self.execution_mode,
        }


def _arrays(
    examples: Sequence[EncodedExample],
) -> Tuple[mx.array, mx.array]:
    return (
        mx.array([example.tokens for example in examples], dtype=mx.int32),
        mx.array([example.label for example in examples], dtype=mx.int32),
    )


def _parameter_count(model: TinyCognitiveTransformer) -> int:
    return sum(
        math.prod(array.shape)
        for _, array in tree_flatten(model.parameters())
    )


def _predict(
    model: TinyCognitiveTransformer,
    examples: Sequence[EncodedExample],
    batch_size: int = 256,
) -> Tuple[int, ...]:
    predictions: List[int] = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        tokens, _ = _arrays(examples[start : start + batch_size])
        batch_predictions = mx.argmax(model(tokens), axis=-1)
        mx.eval(batch_predictions)
        predictions.extend(int(value) for value in batch_predictions.tolist())
    model.train()
    return tuple(predictions)


def _evaluation_metrics(
    model: TinyCognitiveTransformer,
    examples: Sequence[EncodedExample],
    include_composite: bool = True,
) -> Dict[str, float]:
    predictions = _predict(model, examples)
    family_correct: Dict[str, int] = {}
    family_total: Dict[str, int] = {}
    closed_book: Dict[str, bool] = {}
    irrelevant: Dict[str, bool] = {}
    for example, prediction in zip(examples, predictions):
        correct = prediction == example.label
        family_correct[example.family] = (
            family_correct.get(example.family, 0) + int(correct)
        )
        family_total[example.family] = (
            family_total.get(example.family, 0) + 1
        )
        if example.family == "closed_book":
            closed_book[example.pair_id] = correct
        elif example.family == "irrelevant_evidence":
            irrelevant[example.pair_id] = correct

    metrics = {
        family + "_accuracy": (
            family_correct[family] / float(family_total[family])
        )
        for family in sorted(family_total)
    }
    if include_composite:
        eligible = [
            pair_id
            for pair_id, correct in closed_book.items()
            if correct
        ]
        destroyed = sum(
            not irrelevant.get(pair_id, False)
            for pair_id in eligible
        )
        metrics["known_answer_destruction"] = (
            destroyed / float(len(eligible))
            if eligible
            else 0.0
        )
        components = (
            metrics["procedure_accuracy"],
            metrics["oracle_evidence_accuracy"],
            metrics["unknown_accuracy"],
            1.0 - metrics["known_answer_destruction"],
        )
        metrics["cognitive_core_score"] = math.prod(
            max(1e-6, component)
            for component in components
        ) ** (1.0 / len(components))
    return metrics


def train_and_evaluate(
    config: LearningConfig,
    extra_suites: Optional[
        Mapping[str, Sequence[EncodedExample]]
    ] = None,
) -> LearnedRunResult:
    started = time.monotonic()
    mx.set_default_device(
        mx.cpu
        if config.compute_device == "cpu"
        else mx.gpu
    )
    mx.random.seed(config.model_seed)
    model = TinyCognitiveTransformer(config)
    mx.eval(model.parameters())
    optimizer = optim.AdamW(
        learning_rate=config.learning_rate,
        weight_decay=0.0001,
    )

    def loss_fn(
        active_model: TinyCognitiveTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens),
            labels,
            reduction="mean",
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    evaluation = evaluation_suite(config)
    checkpoints: List[CheckpointMetrics] = []
    last_loss = float("nan")

    initial = _evaluation_metrics(model, evaluation)
    checkpoints.append(
        CheckpointMetrics(
            step=0,
            loss=-1.0,
            procedure_accuracy=initial["procedure_accuracy"],
            memory_accuracy=initial["closed_book_accuracy"],
            oracle_evidence_accuracy=initial[
                "oracle_evidence_accuracy"
            ],
            irrelevant_evidence_accuracy=initial[
                "irrelevant_evidence_accuracy"
            ],
            known_answer_destruction=initial[
                "known_answer_destruction"
            ],
        )
    )
    model.train()
    for step in range(1, config.steps + 1):
        tokens, labels = _arrays(training_batch(config, step - 1))
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
        if (
            step % config.checkpoint_interval == 0
            or step == config.steps
        ):
            checkpoint_metrics = _evaluation_metrics(model, evaluation)
            checkpoints.append(
                CheckpointMetrics(
                    step=step,
                    loss=last_loss,
                    procedure_accuracy=checkpoint_metrics[
                        "procedure_accuracy"
                    ],
                    memory_accuracy=checkpoint_metrics[
                        "closed_book_accuracy"
                    ],
                    oracle_evidence_accuracy=checkpoint_metrics[
                        "oracle_evidence_accuracy"
                    ],
                    irrelevant_evidence_accuracy=checkpoint_metrics[
                        "irrelevant_evidence_accuracy"
                    ],
                    known_answer_destruction=checkpoint_metrics[
                        "known_answer_destruction"
                    ],
                )
            )
            model.train()

    metrics = _evaluation_metrics(model, evaluation)
    suite_payload = None
    if extra_suites:
        suite_payload = {}
        for suite_name, suite in sorted(extra_suites.items()):
            suite_metrics = _evaluation_metrics(
                model,
                suite,
                include_composite=False,
            )
            metrics.update(
                {
                    "%s.%s" % (suite_name, metric): value
                    for metric, value in suite_metrics.items()
                }
            )
            suite_payload[suite_name] = [
                {
                    "tokens": list(example.tokens),
                    "label": example.label,
                    "family": example.family,
                    "pair_id": example.pair_id,
                }
                for example in suite
            ]
    metrics["final_training_loss"] = last_loss
    run_payload = {
        "lab_version": MLX_LAB_VERSION,
        "learning_contract_version": LEARNING_CONTRACT_VERSION,
        "config": config.as_dict(),
        "parameter_count": _parameter_count(model),
    }
    if suite_payload is not None:
        run_payload["extra_suites_digest"] = content_digest(suite_payload)
    return LearnedRunResult(
        run_id=content_digest(run_payload)[:20],
        config=config,
        parameter_count=_parameter_count(model),
        elapsed_seconds=time.monotonic() - started,
        metrics=metrics,
        checkpoints=tuple(checkpoints),
        framework="mlx-0.32",
        hardware=platform.machine() + ":" + config.compute_device,
        lab_version=MLX_LAB_VERSION,
        learning_contract_version=LEARNING_CONTRACT_VERSION,
        execution_mode=(
            "deterministic"
            if config.compute_device == "cpu"
            else "stochastic_exploration"
        ),
    )
