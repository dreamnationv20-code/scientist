from __future__ import annotations

import math
from statistics import mean, stdev
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.evidence_invariant_selection_v4 import (
    INDEPENDENT_SELECTION_METRICS,
    score_evidence_invariant_models,
)
from scientist.domains.cognitive_core.heldout_model_selection_v3 import (
    PREDICTION_RESIDUAL_FLOOR,
    FrozenModelPredictionRegistry,
    HeldoutModelSelection,
    HeldoutOutcome,
)
from scientist.program.diagnostics import DiagnosticDisposition


MODEL_AMBIGUITY_DOSSIER_VERSION = (
    "cognitive-core-model-ambiguity-dossier-v4"
)

EVIDENCE_CHANNEL_METRICS = (
    "oracle_evidence_accuracy",
    "irrelevant_evidence_accuracy",
    "conflicting_evidence_accuracy",
    "unknown_accuracy",
)
EVIDENCE_CHANNEL_SIGNS = {
    "oracle_evidence_accuracy": 1.0,
    "irrelevant_evidence_accuracy": 1.0,
    "conflicting_evidence_accuracy": 1.0,
    "unknown_accuracy": 1.0,
}


def _summary(samples: Sequence[float]) -> Dict[str, Any]:
    values = tuple(float(item) for item in samples)
    if len(values) < 2:
        raise ValueError("paired contrast requires at least two seeds")
    standard_error = stdev(values) / math.sqrt(len(values))
    return {
        "mean": mean(values),
        "standard_error": standard_error,
        "normal_95_interval": [
            mean(values) - 1.96 * standard_error,
            mean(values) + 1.96 * standard_error,
        ],
        "samples": list(values),
    }


def _paired_samples(
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
    left_arm: str,
    right_arm: str | None,
    metric: str,
) -> Tuple[float, ...]:
    left = outcomes[left_arm][metric].samples
    right = (
        tuple(0.0 for _ in left)
        if right_arm is None
        else outcomes[right_arm][metric].samples
    )
    if len(left) != len(right):
        raise ValueError("paired arms have different seed counts")
    return tuple(left_item - right_item for left_item, right_item in zip(left, right))


def _evidence_channel_samples(
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
    left_arm: str,
    right_arm: str | None,
) -> Tuple[float, ...]:
    by_metric = {
        metric: _paired_samples(outcomes, left_arm, right_arm, metric)
        for metric in EVIDENCE_CHANNEL_METRICS
    }
    count = len(next(iter(by_metric.values())))
    return tuple(
        sum(
            EVIDENCE_CHANNEL_SIGNS[metric] * by_metric[metric][seed]
            for metric in EVIDENCE_CHANNEL_METRICS
        )
        / float(len(EVIDENCE_CHANNEL_METRICS))
        for seed in range(count)
    )


def _average_samples(
    left: Sequence[float],
    right: Sequence[float],
) -> Tuple[float, ...]:
    if len(left) != len(right):
        raise ValueError("averaged contrasts have different seed counts")
    return tuple((a + b) / 2.0 for a, b in zip(left, right))


def _cell_log_score(
    observed: HeldoutOutcome,
    prediction_mean: float,
    prediction_se: float,
    metric: str,
) -> float:
    variance = (
        observed.standard_error**2
        + prediction_se**2
        + PREDICTION_RESIDUAL_FLOOR[metric] ** 2
    )
    residual = observed.mean - prediction_mean
    return -0.5 * (
        residual**2 / variance + math.log(2.0 * math.pi * variance)
    )


def build_model_ambiguity_dossier(
    registry: FrozenModelPredictionRegistry,
    outcomes: Mapping[str, Mapping[str, HeldoutOutcome]],
    selection: HeldoutModelSelection,
) -> Dict[str, Any]:
    if selection.disposition != DiagnosticDisposition.INCONCLUSIVE:
        raise ValueError("ambiguity dossier requires an inconclusive selection")
    ordered = sorted(
        selection.fits.values(),
        key=lambda item: item.predictive_log_score,
        reverse=True,
    )
    if len(ordered) < 2:
        raise ValueError("ambiguity dossier requires two candidate models")
    top_id, runner_id = ordered[0].model_id, ordered[1].model_id
    model_by_id = {model.model_id: model for model in registry.models}

    cell_evidence = []
    positive_by_metric: Dict[str, float] = {}
    net_by_metric: Dict[str, float] = {}
    discriminating_count = 0
    scored_count = 0
    for arm_id, metrics in sorted(outcomes.items()):
        if arm_id == "sham":
            continue
        for metric, observed in sorted(metrics.items()):
            top_prediction = registry.predictions[top_id][arm_id][metric]
            runner_prediction = registry.predictions[runner_id][arm_id][metric]
            top_log_score = _cell_log_score(
                observed,
                top_prediction.mean,
                top_prediction.standard_error,
                metric,
            )
            runner_log_score = _cell_log_score(
                observed,
                runner_prediction.mean,
                runner_prediction.standard_error,
                metric,
            )
            delta = top_log_score - runner_log_score
            separates = (
                abs(top_prediction.mean - runner_prediction.mean) > 1e-12
                or abs(
                    top_prediction.standard_error
                    - runner_prediction.standard_error
                )
                > 1e-12
            )
            discriminating_count += int(separates)
            scored_count += 1
            positive_by_metric[metric] = positive_by_metric.get(metric, 0.0) + max(
                0.0, delta
            )
            net_by_metric[metric] = net_by_metric.get(metric, 0.0) + delta
            cell_evidence.append(
                {
                    "arm_id": arm_id,
                    "metric": metric,
                    "observed_mean": observed.mean,
                    "top_prediction": top_prediction.mean,
                    "runner_prediction": runner_prediction.mean,
                    "top_minus_runner_log_evidence": delta,
                    "models_are_distinguishable_in_cell": separates,
                }
            )

    total_positive = sum(positive_by_metric.values())
    procedure_composite_share = (
        positive_by_metric.get("procedure_accuracy", 0.0)
        + positive_by_metric.get("cognitive_core_score", 0.0)
    ) / total_positive

    procedure_representation_at_zero = _paired_samples(
        outcomes,
        "representation_half",
        None,
        "procedure_accuracy",
    )
    procedure_representation_at_half_routing = _paired_samples(
        outcomes,
        "representation_half+routing_half",
        "routing_half",
        "procedure_accuracy",
    )
    evidence_representation_at_zero = _evidence_channel_samples(
        outcomes,
        "representation_half",
        None,
    )
    evidence_representation_at_half_routing = _evidence_channel_samples(
        outcomes,
        "representation_half+routing_half",
        "routing_half",
    )
    procedure_routing_at_zero = _paired_samples(
        outcomes,
        "routing_half",
        None,
        "procedure_accuracy",
    )
    procedure_routing_at_half_representation = _paired_samples(
        outcomes,
        "representation_half+routing_half",
        "representation_half",
        "procedure_accuracy",
    )
    evidence_routing_at_zero = _evidence_channel_samples(
        outcomes,
        "routing_half",
        None,
    )
    evidence_routing_at_half_representation = _evidence_channel_samples(
        outcomes,
        "representation_half+routing_half",
        "representation_half",
    )

    average_procedure_representation = _average_samples(
        procedure_representation_at_zero,
        procedure_representation_at_half_routing,
    )
    average_evidence_representation = _average_samples(
        evidence_representation_at_zero,
        evidence_representation_at_half_routing,
    )
    average_procedure_routing = _average_samples(
        procedure_routing_at_zero,
        procedure_routing_at_half_representation,
    )
    average_evidence_routing = _average_samples(
        evidence_routing_at_zero,
        evidence_routing_at_half_representation,
    )
    representation_channel_gap = tuple(
        procedure - evidence
        for procedure, evidence in zip(
            average_procedure_representation,
            average_evidence_representation,
        )
    )
    routing_channel_gap = tuple(
        evidence - procedure
        for procedure, evidence in zip(
            average_procedure_routing,
            average_evidence_routing,
        )
    )
    evidence_representation_interaction = tuple(
        at_half - at_zero
        for at_zero, at_half in zip(
            evidence_representation_at_zero,
            evidence_representation_at_half_routing,
        )
    )

    invariant = score_evidence_invariant_models(registry, outcomes)
    invariant_order = sorted(
        invariant.fits.values(),
        key=lambda item: item.total_predictive_log_score,
        reverse=True,
    )
    old_top_stability = selection.fits[top_id].leave_one_seed_out_win_fraction
    invariant_top_stability = invariant_order[0].leave_one_seed_out_win_fraction
    complexity_gap = (
        model_by_id[top_id].complexity - model_by_id[runner_id].complexity
    )
    v3_effective_complexity_gap = (
        0.01 * complexity_gap * selection.outcome_count
    )
    invariant_complexity_gap = 0.01 * complexity_gap

    mechanism_estimates = {
        "procedure_representation_effect": _summary(
            average_procedure_representation
        ),
        "evidence_representation_effect": _summary(
            average_evidence_representation
        ),
        "representation_channel_gap": _summary(representation_channel_gap),
        "procedure_routing_effect": _summary(average_procedure_routing),
        "evidence_routing_effect": _summary(average_evidence_routing),
        "routing_channel_gap": _summary(routing_channel_gap),
        "evidence_representation_interaction": _summary(
            evidence_representation_interaction
        ),
    }
    latent_concept = {
        "name": "capability_channel_conditional_causality",
        "hypothesis": (
            "Routing and representation separation act on different capability "
            "channels: routing primarily improves evidence control, while "
            "representation separation primarily protects procedure learning; "
            "their aggregate score can therefore hide sub-additive or null "
            "effects inside individual channels."
        ),
        "prospective_predictions": [
            "representation_half improves procedure_accuracy at both routing levels",
            "routing_half improves the signed evidence-control channel more than procedure_accuracy",
            "the representation effect is larger on procedure than on evidence control",
            "routing does not increase the evidence benefit of representation separation",
        ],
        "prospective_falsifiers": [
            "the representation channel gap is non-positive on new seeds and data",
            "the routing channel gap is non-positive on new seeds and data",
            "a derived aggregate is required for the result to pass",
        ],
    }
    latent_concept["concept_id"] = content_digest(latent_concept)

    checks = {
        "official_result_remains_inconclusive": (
            selection.disposition == DiagnosticDisposition.INCONCLUSIVE
        ),
        "most_cells_do_not_separate_top_two": (
            discriminating_count < scored_count / 2.0
        ),
        "positive_evidence_is_channel_concentrated": (
            procedure_composite_share >= 0.75
        ),
        "derived_composite_was_counted_in_v3": (
            "cognitive_core_score"
            not in INDEPENDENT_SELECTION_METRICS
            and "cognitive_core_score" in positive_by_metric
        ),
        "v3_penalty_scaled_with_outcome_count": (
            abs(v3_effective_complexity_gap)
            > abs(invariant_complexity_gap) * 10.0
        ),
        "representation_and_routing_show_opposing_channel_selectivity": (
            mechanism_estimates["representation_channel_gap"]["mean"] > 0.05
            and mechanism_estimates["routing_channel_gap"]["mean"] > 0.05
        ),
        "evidence_invariant_reanalysis_is_still_conservative": (
            invariant.disposition == DiagnosticDisposition.INCONCLUSIVE
        ),
    }
    dossier = {
        "version": MODEL_AMBIGUITY_DOSSIER_VERSION,
        "registry_id": registry.registry_id,
        "official_selection_version": selection.version,
        "official_disposition": selection.disposition.value,
        "top_model_id": top_id,
        "runner_up_model_id": runner_id,
        "official_score_margin": selection.score_margin,
        "scored_cell_count": scored_count,
        "top_two_discriminating_cell_count": discriminating_count,
        "top_two_nondiscriminating_cell_count": scored_count
        - discriminating_count,
        "positive_evidence_share_from_procedure_and_derived_composite": (
            procedure_composite_share
        ),
        "net_log_evidence_by_metric": dict(sorted(net_by_metric.items())),
        "positive_log_evidence_by_metric": dict(
            sorted(positive_by_metric.items())
        ),
        "strongest_top_model_cells": sorted(
            cell_evidence,
            key=lambda item: item["top_minus_runner_log_evidence"],
            reverse=True,
        )[:12],
        "strongest_runner_up_cells": sorted(
            cell_evidence,
            key=lambda item: item["top_minus_runner_log_evidence"],
        )[:12],
        "complexity_penalty_audit": {
            "complexity_gap_terms": complexity_gap,
            "v3_effective_total_penalty_gap": v3_effective_complexity_gap,
            "evidence_invariant_total_penalty_gap": invariant_complexity_gap,
            "amplification_factor": selection.outcome_count,
        },
        "leave_one_seed_stability_audit": {
            "official_top_model_fraction": old_top_stability,
            "evidence_invariant_top_model_id": invariant_order[0].model_id,
            "evidence_invariant_top_model_fraction": invariant_top_stability,
        },
        "evidence_invariant_selection": invariant.as_dict(),
        "mechanism_estimates": mechanism_estimates,
        "latent_concept": latent_concept,
        "prospective_followup": {
            "purpose": (
                "test the channel-conditional concept on unseen data rather "
                "than rescore the discovery outcomes"
            ),
            "data_seed": 20260814,
            "model_seeds": list(range(12, 20)),
            "arms": [
                "baseline",
                "sham",
                "representation_half",
                "routing_half",
                "representation_half+routing_half",
            ],
            "primary_metrics": list(INDEPENDENT_SELECTION_METRICS),
            "derived_metrics_are_report_only": [
                "cognitive_core_score",
                "known_answer_destruction",
            ],
            "minimum_effect_gates": {
                "representation_channel_gap": 0.05,
                "routing_channel_gap": 0.05,
                "procedure_representation_effect": 0.0,
                "evidence_routing_effect": 0.0,
            },
            "uncertainty_gate": (
                "both channel gaps must be positive in at least six of eight "
                "leave-one-seed estimates"
            ),
            "adoption_rule": (
                "revise the causal representation only if all validity checks "
                "and both held-out channel gaps pass; otherwise retain an "
                "inconclusive diagnosis"
            ),
        },
        "checks": checks,
        "ready_for_prospective_test": all(checks.values()),
        "interpretation": (
            "The prior run did not fail to measure a global effect.  It exposed "
            "a model-comparison rule that was sensitive to irrelevant cells and "
            "a mechanism vocabulary that averaged different capability channels."
        ),
    }
    dossier["dossier_id"] = content_digest(dossier)
    return dossier
