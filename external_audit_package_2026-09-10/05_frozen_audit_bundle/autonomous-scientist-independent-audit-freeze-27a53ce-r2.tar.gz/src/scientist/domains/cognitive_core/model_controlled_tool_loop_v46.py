from __future__ import annotations

import hashlib
import json
import random
import re
import time
from dataclasses import replace
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.contrast_experiment_v42 import (
    ContrastPair,
    _best_contrast_pair,
    aggregate_contrasts,
    contrast_prompt,
    pair_members,
)
from scientist.domains.cognitive_core.experiment_invention_v41 import (
    ExperimentTask,
    _candidate_predictions,
    _canonical,
    _program_text,
    input_schema,
    parse_experiment,
    partition_metrics,
    valid_input,
)
from scientist.domains.cognitive_core.internal_core_v28 import (
    _batch_responses,
    _chat_prompt,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
)


MODEL_CONTROLLED_TOOL_LOOP_VERSION = "general-cognitive-model-controlled-tool-loop-v46"
M46_SPLIT_SEEDS = {"calibration": 46061, "test": 46109}
M46_REPRESENTATIONS = ("predicate", "causal")
M46_PER_REPRESENTATION = {"calibration": 6, "test": 30}
M46_MINIMUM_EXCLUSIVE_FRACTION = 0.10
M46_PROPOSAL_TURN_BUDGET = 8
M46_ACTION_MAX_TOKENS = 24
M46_FINAL_MAX_TOKENS = 8
M46_ADAPTER_SHA256 = "f3fa70320bf04b9b54d14fa4f0c891b96d8399da452d8e9a386e2ce3eede7f38"
M46_MODEL_SNAPSHOT = "8b403126fc14f14cfc99bb4cfa72ecbc129ea677"
_SELECT_RE = re.compile(r"SELECT\s*:\s*(\d+)", re.IGNORECASE)


def _source_tasks(
    split: str, per_representation: int, representations: Sequence[str]
) -> Tuple[Any, ...]:
    if split not in M46_SPLIT_SEEDS:
        raise ValueError("unknown M46 split")
    rng = random.Random(M46_SPLIT_SEEDS[split])
    return tuple(
        _build_task(f"m46_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )


def _experiment_task(source: Any) -> ExperimentTask | None:
    task = _m43_experiment_task(source)
    if task is None:
        return None
    task_id = "m46-exp-" + content_digest(
        {
            "source": source.task_id,
            "scenario": task.scenario.scenario_id,
            "version": MODEL_CONTROLLED_TOOL_LOOP_VERSION,
        }
    )[:20]
    return replace(task, task_id=task_id)


def build_m46_pairs(
    split: str,
    per_representation: int | None = None,
    representations: Sequence[str] = M46_REPRESENTATIONS,
) -> Tuple[ContrastPair, ...]:
    if split not in M46_PER_REPRESENTATION:
        raise ValueError("unknown M46 split")
    if per_representation is None:
        per_representation = M46_PER_REPRESENTATION[split]
    bases = tuple(
        task
        for source in _source_tasks(split, per_representation, representations)
        for task in (_experiment_task(source),)
        if task is not None
    )
    return tuple(
        pair
        for base in bases
        for pair in (
            _best_contrast_pair(
                base,
                version=MODEL_CONTROLLED_TOOL_LOOP_VERSION,
                pair_prefix="m46-pair",
                minimum_exclusive_fraction=M46_MINIMUM_EXCLUSIVE_FRACTION,
            ),
        )
        if pair is not None
    )


def raw_candidate_outputs(task: ExperimentTask, experiment: Any) -> Tuple[Any, ...]:
    return tuple(json.loads(value) for value in _candidate_predictions(task, experiment))


def interaction_prompt(
    task: ExperimentTask,
    visible_task: ExperimentTask,
    history: Sequence[Mapping[str, Any]],
    errors: Sequence[str],
    *,
    feedback: bool,
    turn: int,
    final_selection: bool = False,
) -> str:
    observed = sorted({_canonical(value) for value in task.observed_inputs})
    lines = [
        f"Representation: {task.representation}",
        f"Valid experiment input: {input_schema(task.representation)}.",
        "Goal: choose an experiment for which the two unresolved executable mechanisms produce different outputs.",
        "Unresolved executable candidate mechanisms:",
    ]
    for index, intervention in enumerate(visible_task.frontier, 1):
        lines.append(f"  c{index}: {_program_text(intervention.program)}")
    lines.extend(
        (
            "Observed inputs: " + json.dumps(observed),
            "Execution history:",
        )
    )
    if not history:
        lines.append("  none")
    for row in history:
        lines.append(f"  slot {row['slot']} experiment={json.dumps(row['experiment'])}")
        if feedback:
            lines.append(f"    c1_output={json.dumps(row['outputs'][0], sort_keys=True)}")
            lines.append(f"    c2_output={json.dumps(row['outputs'][1], sort_keys=True)}")
        else:
            lines.append("    candidate outputs withheld")
    if errors:
        lines.append("Tool validation messages:")
        lines.extend(f"  {message}" for message in errors[-2:])
    if final_selection:
        lines.extend(
            (
                "The proposal budget is exhausted. Select one previously executed slot.",
                "Interpret the raw outputs yourself; the tool has not ranked the slots.",
                "Return exactly: SELECT: <slot number>",
            )
        )
    else:
        lines.extend(
            (
                f"Interaction turn {turn} of {M46_PROPOSAL_TURN_BUDGET}.",
                "If a previous slot already achieves the goal, select it. Otherwise propose a different legal experiment.",
                "Interpret the raw outputs yourself; the tool has not scored or ranked them.",
                "Return exactly one line, either:",
                "SELECT: <slot number>",
                "or",
                "EXPERIMENT: <JSON list>",
            )
        )
    return "\n".join(lines)


def parse_action(
    response: str,
    task: ExperimentTask,
    history: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    select_match = _SELECT_RE.search(response)
    if select_match is not None:
        slot = int(select_match.group(1))
        valid = 1 <= slot <= len(history)
        return {
            "kind": "select",
            "parsed": True,
            "valid": valid,
            "slot": slot,
            "experiment": history[slot - 1]["experiment"] if valid else None,
            "response": response,
        }
    experiment = parse_experiment(response)
    parsed = experiment is not None
    legal = bool(parsed and valid_input(task.representation, experiment))
    observed = {_canonical(value) for value in task.observed_inputs}
    previous = {_canonical(row["experiment"]) for row in history}
    key = _canonical(experiment) if legal else ""
    novel = bool(legal and key not in observed)
    distinct = bool(novel and key not in previous)
    return {
        "kind": "propose" if parsed else "invalid",
        "parsed": parsed,
        "valid": distinct,
        "slot": None,
        "experiment": experiment,
        "legal": legal,
        "novel": novel,
        "distinct": distinct,
        "response": response,
    }


def _initial_state(task: ExperimentTask) -> Dict[str, Any]:
    return {
        "task_id": task.task_id,
        "representation": task.representation,
        "history": [],
        "errors": [],
        "actions": [],
        "selected_slot": None,
        "selected_experiment": None,
        "final_response": "",
    }


def _interaction_metrics(
    pairs: Sequence[ContrastPair], states: Sequence[Mapping[str, Any]], *, mode: str
) -> Mapping[str, Any]:
    tasks = pair_members(pairs)
    if len(tasks) != len(states):
        raise ValueError("M46 states do not align")
    by_task = {
        pair.left.task_id: (pair.left, pair.right) for pair in pairs
    } | {pair.right.task_id: (pair.right, pair.left) for pair in pairs}
    rows = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    for task, state in zip(tasks, states):
        own, sibling = by_task[task.task_id]
        visible = sibling if mode == "mismatched_feedback" else own
        actions = state["actions"]
        history = state["history"]
        selected_slot = state["selected_slot"]
        selected_row = (
            history[selected_slot - 1]
            if isinstance(selected_slot, int) and 1 <= selected_slot <= len(history)
            else None
        )
        informative_slots = [
            row for row in history if _canonical(row["outputs"][0]) != _canonical(row["outputs"][1])
        ]
        item = {
            "task_id": task.task_id,
            "representation": task.representation,
            "action_count": len(actions),
            "parsed_action_count": sum(bool(action["parsed"]) for action in actions),
            "valid_action_count": sum(bool(action["valid"]) for action in actions),
            "proposal_action_count": sum(action["kind"] == "propose" for action in actions),
            "valid_proposal_count": len(history),
            "distinct_proposals": len(history),
            "selection_completed": selected_row is not None,
            "selected_evidence": bool(
                selected_row
                and _canonical(selected_row["outputs"][0])
                != _canonical(selected_row["outputs"][1])
            ),
            "informative_history_available": bool(informative_slots),
            "selected_available_evidence": bool(
                not informative_slots
                or (
                    selected_row
                    and _canonical(selected_row["outputs"][0])
                    != _canonical(selected_row["outputs"][1])
                )
            ),
            "selected_visible_information": (
                partition_metrics(visible, state["selected_experiment"])[
                    "normalized_information_gain"
                ]
                if state["selected_experiment"] is not None
                else 0.0
            ),
            "stopped_before_forced_selection": bool(
                selected_row
                and any(
                    action["kind"] == "select"
                    and action["valid"]
                    and action.get("turn") != "forced_final_selection"
                    for action in actions
                )
            ),
        }
        rows.append(item)
        by_representation.setdefault(task.representation, []).append(item)

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        if not items:
            return {
                "action_parse_rate": 0.0,
                "valid_action_rate": 0.0,
                "mean_valid_proposals": 0.0,
                "selection_completion_rate": 0.0,
                "selected_evidence_rate": 0.0,
                "available_evidence_selection_rate": 0.0,
                "mean_selected_visible_information": 0.0,
                "early_stop_rate": 0.0,
                "mean_action_count": 0.0,
            }
        action_total = sum(int(row["action_count"]) for row in items)
        evidence_items = [row for row in items if row["informative_history_available"]]
        return {
            "action_parse_rate": sum(int(row["parsed_action_count"]) for row in items)
            / action_total,
            "valid_action_rate": sum(int(row["valid_action_count"]) for row in items)
            / action_total,
            "mean_valid_proposals": sum(int(row["valid_proposal_count"]) for row in items)
            / len(items),
            "selection_completion_rate": sum(bool(row["selection_completed"]) for row in items)
            / len(items),
            "selected_evidence_rate": sum(bool(row["selected_evidence"]) for row in items)
            / len(items),
            "available_evidence_selection_rate": (
                sum(bool(row["selected_available_evidence"]) for row in evidence_items)
                / len(evidence_items)
                if evidence_items
                else 0.0
            ),
            "mean_selected_visible_information": sum(
                float(row["selected_visible_information"]) for row in items
            )
            / len(items),
            "early_stop_rate": sum(bool(row["stopped_before_forced_selection"]) for row in items)
            / len(items),
            "mean_action_count": sum(int(row["action_count"]) for row in items)
            / len(items),
        }

    return {
        **summarize(rows),
        "by_representation": {
            representation: summarize(items)
            for representation, items in sorted(by_representation.items())
        },
        "records": rows,
    }


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def prepare_m46_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    split_pairs = {
        split: build_m46_pairs(split) for split in ("calibration", "test")
    }
    hashes = {}
    for split, pairs in split_pairs.items():
        public_hash, _ = _write_jsonl(
            output / f"{split}-public.jsonl",
            (
                {
                    "pair_id": pair.pair_id,
                    "representation": pair.representation,
                    "left_task_id": pair.left.task_id,
                    "right_task_id": pair.right.task_id,
                    "left_initial_prompt_sha256": hashlib.sha256(
                        interaction_prompt(
                            pair.left,
                            pair.left,
                            (),
                            (),
                            feedback=True,
                            turn=1,
                        ).encode("utf-8")
                    ).hexdigest(),
                    "right_initial_prompt_sha256": hashlib.sha256(
                        interaction_prompt(
                            pair.right,
                            pair.right,
                            (),
                            (),
                            feedback=True,
                            turn=1,
                        ).encode("utf-8")
                    ).hexdigest(),
                }
                for pair in pairs
            ),
        )
        authority_hash, _ = _write_jsonl(
            output / f"{split}-authority.jsonl",
            (
                {
                    "pair_id": pair.pair_id,
                    "authority_program": dict(pair.left.source.authority),
                    "left_frontier": [item.key for item in pair.left.frontier],
                    "right_frontier": [item.key for item in pair.right.frontier],
                }
                for pair in pairs
            ),
        )
        hashes[f"{split}_public"] = public_hash
        hashes[f"{split}_authority"] = authority_hash
    counts = {
        split: {
            "pairs": len(pairs),
            "tasks": len(pairs) * 2,
            "by_representation": {
                representation: sum(
                    int(pair.representation == representation) for pair in pairs
                )
                for representation in M46_REPRESENTATIONS
            },
        }
        for split, pairs in split_pairs.items()
    }
    gates = {
        "minimum_action_parse_rate": 0.95,
        "minimum_valid_action_rate": 0.90,
        "minimum_selection_completion_rate": 0.90,
        "minimum_selected_evidence_rate": 0.80,
        "minimum_available_evidence_selection_rate": 0.90,
        "minimum_predicate_information": 0.70,
        "minimum_causal_information": 0.90,
        "minimum_overall_correct_assignment": 0.65,
        "minimum_information_gain_over_direct": 0.20,
        "minimum_assignment_gain_over_direct": 0.20,
        "minimum_information_gain_over_no_feedback": 0.15,
        "minimum_assignment_gain_over_no_feedback": 0.15,
        "minimum_advantage_gap_over_mismatched": 0.60,
    }
    payload = {
        "version": MODEL_CONTROLLED_TOOL_LOOP_VERSION,
        "parent_version": "general-cognitive-typed-proposal-interface-v45",
        "split_seeds": M46_SPLIT_SEEDS,
        "representations": list(M46_REPRESENTATIONS),
        "per_representation_source_count": M46_PER_REPRESENTATION,
        "minimum_exclusive_fraction": M46_MINIMUM_EXCLUSIVE_FRACTION,
        "counts": counts,
        "hashes": hashes,
        "frozen_model": {
            "snapshot": M46_MODEL_SNAPSHOT,
            "adapter_sha256": M46_ADAPTER_SHA256,
            "adapter_source": "m43_validation_selected_checkpoint_100",
        },
        "interaction_contract": {
            "proposal_turn_budget": M46_PROPOSAL_TURN_BUDGET,
            "action_max_tokens": M46_ACTION_MAX_TOKENS,
            "forced_final_selection_max_tokens": M46_FINAL_MAX_TOKENS,
            "maximum_total_output_tokens_per_task": M46_PROPOSAL_TURN_BUDGET
            * M46_ACTION_MAX_TOKENS
            + M46_FINAL_MAX_TOKENS,
            "batch_size": 8,
            "tool_returns": "raw_c1_and_c2_outputs_only",
            "tool_does_not_return": [
                "information_gain",
                "ranking",
                "recommended_action",
                "stop_decision",
            ],
            "selection_policy": "model_selects_a_previously_executed_slot",
            "external_fallback_selection": False,
            "no_test_time_parameter_updates": True,
        },
        "conditions": [
            "direct_correct",
            "correct_feedback",
            "correct_no_feedback",
            "mismatched_feedback",
        ],
        "calibration_readiness_gates": gates,
        "sealed_test_gates": gates,
        "sealed_test_policy": "test_is_opened_only_if_all_calibration_readiness_gates_pass",
        "claim_boundary": (
            "M46 tests whether the frozen 1.5B model itself can use sequential raw execution evidence "
            "to change proposals and select a diagnostic experiment. The tool returns only the two "
            "candidate outputs; it does not calculate information gain, rank experiments, stop, or "
            "choose a slot. Direct, no-feedback, and swapped-dossier controls use the same model. M46 "
            "does not train a policy, test unseen representation grammars, or establish parity with a 70B model."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def _load_json(path: Path) -> Mapping[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def verify_m46_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = _load_json(output / "benchmark-freeze.json")
    paths = {
        f"{split}_{kind}": output / f"{split}-{kind}.jsonl"
        for split in ("calibration", "test")
        for kind in ("public", "authority")
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    calibration_ids = {pair.pair_id for pair in build_m46_pairs("calibration")}
    test_ids = {pair.pair_id for pair in build_m46_pairs("test")}
    contract = freeze["interaction_contract"]
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": content_digest(payload) == freeze["freeze_id"],
        "splits_are_disjoint": not (calibration_ids & test_ids),
        "exact_adapter_is_frozen": freeze["frozen_model"]["adapter_sha256"]
        == M46_ADAPTER_SHA256,
        "raw_tool_boundary_is_frozen": contract["tool_returns"]
        == "raw_c1_and_c2_outputs_only"
        and "ranking" in contract["tool_does_not_return"],
        "model_owns_selection": contract["selection_policy"]
        == "model_selects_a_previously_executed_slot"
        and contract["external_fallback_selection"] is False,
        "gates_identical_across_splits": freeze["calibration_readiness_gates"]
        == freeze["sealed_test_gates"],
        "sealed_test_policy_is_frozen": freeze["sealed_test_policy"]
        == "test_is_opened_only_if_all_calibration_readiness_gates_pass",
    }
    return {"freeze_id": freeze["freeze_id"], "checks": checks, "passed": all(checks.values())}


def _run_condition(
    pairs: Sequence[ContrastPair],
    model: Any,
    tokenizer: Any,
    *,
    mode: str,
    contract: Mapping[str, Any],
) -> Tuple[list[Mapping[str, Any]], float]:
    if mode not in ("correct_feedback", "correct_no_feedback", "mismatched_feedback"):
        raise ValueError("unknown M46 interaction mode")
    tasks = pair_members(pairs)
    by_task = {
        pair.left.task_id: (pair.left, pair.right) for pair in pairs
    } | {pair.right.task_id: (pair.right, pair.left) for pair in pairs}
    states: list[Dict[str, Any]] = [_initial_state(task) for task in tasks]
    peak_memory = 0.0
    feedback = mode != "correct_no_feedback"
    for turn in range(1, M46_PROPOSAL_TURN_BUDGET + 1):
        active = [index for index, state in enumerate(states) if state["selected_slot"] is None]
        if not active:
            break
        prompts = []
        for index in active:
            task = tasks[index]
            own, sibling = by_task[task.task_id]
            visible = sibling if mode == "mismatched_feedback" else own
            prompts.append(
                interaction_prompt(
                    task,
                    visible,
                    states[index]["history"],
                    states[index]["errors"],
                    feedback=feedback,
                    turn=turn,
                )
            )
        responses, peak = _batch_responses(
            model,
            tokenizer,
            tuple(_chat_prompt(tokenizer, prompt) for prompt in prompts),
            batch_size=int(contract["batch_size"]),
            max_tokens=int(contract["action_max_tokens"]),
            max_batch_tokens=12000,
        )
        peak_memory = max(peak_memory, peak)
        for index, response in zip(active, responses):
            task = tasks[index]
            own, sibling = by_task[task.task_id]
            visible = sibling if mode == "mismatched_feedback" else own
            state = states[index]
            action = dict(parse_action(response, task, state["history"]))
            action["turn"] = turn
            state["actions"].append(action)
            if action["kind"] == "select" and action["valid"]:
                state["selected_slot"] = action["slot"]
                state["selected_experiment"] = action["experiment"]
                state["final_response"] = response
            elif action["kind"] == "propose" and action["valid"]:
                outputs = raw_candidate_outputs(visible, action["experiment"])
                state["history"].append(
                    {
                        "slot": len(state["history"]) + 1,
                        "turn": turn,
                        "experiment": action["experiment"],
                        "outputs": list(outputs),
                        "response": response,
                    }
                )
            else:
                state["errors"].append(
                    f"turn {turn}: invalid, out-of-schema, observed, duplicate, or unavailable selection"
                )
    active = [
        index
        for index, state in enumerate(states)
        if state["selected_slot"] is None and state["history"]
    ]
    if active:
        prompts = []
        for index in active:
            task = tasks[index]
            own, sibling = by_task[task.task_id]
            visible = sibling if mode == "mismatched_feedback" else own
            prompts.append(
                interaction_prompt(
                    task,
                    visible,
                    states[index]["history"],
                    states[index]["errors"],
                    feedback=feedback,
                    turn=M46_PROPOSAL_TURN_BUDGET,
                    final_selection=True,
                )
            )
        responses, peak = _batch_responses(
            model,
            tokenizer,
            tuple(_chat_prompt(tokenizer, prompt) for prompt in prompts),
            batch_size=int(contract["batch_size"]),
            max_tokens=int(contract["forced_final_selection_max_tokens"]),
            max_batch_tokens=12000,
        )
        peak_memory = max(peak_memory, peak)
        for index, response in zip(active, responses):
            task = tasks[index]
            state = states[index]
            action = dict(parse_action(response, task, state["history"]))
            action["turn"] = "forced_final_selection"
            state["actions"].append(action)
            if action["kind"] == "select" and action["valid"]:
                state["selected_slot"] = action["slot"]
                state["selected_experiment"] = action["experiment"]
                state["final_response"] = response
    return states, peak_memory


def evaluate_m46_split(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    adapter_path: Path,
    *,
    split: str,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if split not in ("calibration", "test"):
        raise ValueError("M46 split must be calibration or test")
    freeze = _load_json(benchmark_root / "benchmark-freeze.json")
    if split == "test":
        calibration = output_root / "m46-calibration-assessment.json"
        if not calibration.exists() or not _load_json(calibration)["passed"]:
            raise RuntimeError("sealed M46 test cannot open before calibration passes")
    if not model_path.rstrip("/").endswith(freeze["frozen_model"]["snapshot"]):
        raise ValueError("model path does not match frozen M46 snapshot")
    adapter_hash = hashlib.sha256((adapter_path / "adapters.safetensors").read_bytes()).hexdigest()
    if adapter_hash != freeze["frozen_model"]["adapter_sha256"]:
        raise ValueError("adapter weights do not match frozen M46 hash")
    pairs = build_m46_pairs(split)
    tasks = pair_members(pairs)
    started = time.monotonic()
    model, tokenizer, config = load(
        model_path, adapter_path=str(adapter_path), return_config=True
    )
    states = {}
    peak_memory = 0.0
    for mode in (
        "correct_feedback",
        "correct_no_feedback",
        "mismatched_feedback",
    ):
        condition_states, peak = _run_condition(
            pairs,
            model,
            tokenizer,
            mode=mode,
            contract=freeze["interaction_contract"],
        )
        states[mode] = condition_states
        peak_memory = max(peak_memory, peak)
    direct_prompts = tuple(
        _chat_prompt(tokenizer, contrast_prompt(task, dossier=True)) for task in tasks
    )
    direct_responses, direct_peak = _batch_responses(
        model,
        tokenizer,
        direct_prompts,
        batch_size=int(freeze["interaction_contract"]["batch_size"]),
        max_tokens=40,
        max_batch_tokens=12000,
    )
    peak_memory = max(peak_memory, direct_peak)
    direct_values = tuple(parse_experiment(response) for response in direct_responses)
    conditions = {
        "direct_correct": aggregate_contrasts(
            "direct_correct", pairs, direct_values, direct_responses
        )
    }
    interaction_metrics = {}
    for mode, condition_states in states.items():
        values = [state["selected_experiment"] for state in condition_states]
        responses = [state["final_response"] for state in condition_states]
        conditions[mode] = aggregate_contrasts(mode, pairs, values, responses)
        interaction_metrics[mode] = _interaction_metrics(
            pairs, condition_states, mode=mode
        )
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "model_controlled_tool_loop_predictions",
        {
            "states": states,
            "conditions": {
                name: {
                    "records": result["records"],
                    "pair_records": result["pair_records"],
                }
                for name, result in conditions.items()
            },
            "direct_responses": list(direct_responses),
        },
    )
    payload = {
        "version": MODEL_CONTROLLED_TOOL_LOOP_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "split": split,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path),
        "adapter_config_sha256": hashlib.sha256(
            (adapter_path / "adapter_config.json").read_bytes()
        ).hexdigest(),
        "adapter_weights_sha256": adapter_hash,
        "metrics": {name: result["metrics"] for name, result in conditions.items()},
        "interaction_metrics": {
            mode: {key: item for key, item in metrics.items() if key != "records"}
            for mode, metrics in interaction_metrics.items()
        },
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "interaction_contract": freeze["interaction_contract"],
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(
        f"model-controlled-tool-loop-{split}-{manifest['evaluation_id']}", manifest
    )
    return manifest


def assess_m46_split(
    evaluation: Mapping[str, Any], benchmark_root: Path
) -> Mapping[str, Any]:
    freeze = _load_json(benchmark_root / "benchmark-freeze.json")
    split = str(evaluation["split"])
    gates = (
        freeze["calibration_readiness_gates"]
        if split == "calibration"
        else freeze["sealed_test_gates"]
    )
    metrics = evaluation["metrics"]
    interactions = evaluation["interaction_metrics"]
    candidate = metrics["correct_feedback"]
    direct = metrics["direct_correct"]
    no_feedback = metrics["correct_no_feedback"]
    mismatch = metrics["mismatched_feedback"]
    loop = interactions["correct_feedback"]
    predicate = candidate["by_representation"]["predicate"]
    causal = candidate["by_representation"]["causal"]
    checks = {
        "same_benchmark_freeze": evaluation["benchmark_freeze_id"]
        == freeze["freeze_id"],
        "exact_model_and_adapter": (
            evaluation["model_path"].rstrip("/").endswith(
                freeze["frozen_model"]["snapshot"]
            )
            and evaluation["adapter_weights_sha256"]
            == freeze["frozen_model"]["adapter_sha256"]
        ),
        "fixed_raw_tool_contract": evaluation["interaction_contract"]
        == freeze["interaction_contract"],
        "action_parse_rate": loop["action_parse_rate"]
        >= gates["minimum_action_parse_rate"],
        "valid_action_rate": loop["valid_action_rate"]
        >= gates["minimum_valid_action_rate"],
        "selection_completion_rate": loop["selection_completion_rate"]
        >= gates["minimum_selection_completion_rate"],
        "selected_evidence_rate": loop["selected_evidence_rate"]
        >= gates["minimum_selected_evidence_rate"],
        "available_evidence_selection_rate": loop["available_evidence_selection_rate"]
        >= gates["minimum_available_evidence_selection_rate"],
        "predicate_information": predicate["mean_normalized_information_gain"]
        >= gates["minimum_predicate_information"],
        "causal_information": causal["mean_normalized_information_gain"]
        >= gates["minimum_causal_information"],
        "overall_correct_assignment": candidate["correct_assignment_rate"]
        >= gates["minimum_overall_correct_assignment"],
        "information_gain_over_direct": candidate["mean_normalized_information_gain"]
        - direct["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_direct"],
        "assignment_gain_over_direct": candidate["correct_assignment_rate"]
        - direct["correct_assignment_rate"]
        >= gates["minimum_assignment_gain_over_direct"],
        "information_gain_over_no_feedback": candidate[
            "mean_normalized_information_gain"
        ]
        - no_feedback["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_no_feedback"],
        "assignment_gain_over_no_feedback": candidate["correct_assignment_rate"]
        - no_feedback["correct_assignment_rate"]
        >= gates["minimum_assignment_gain_over_no_feedback"],
        "advantage_gap_over_mismatched": candidate["mean_assignment_advantage"]
        - mismatch["mean_assignment_advantage"]
        >= gates["minimum_advantage_gap_over_mismatched"],
    }
    payload = {
        "version": MODEL_CONTROLLED_TOOL_LOOP_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "split": split,
        "evaluation_id": evaluation["evaluation_id"],
        "metrics": metrics,
        "interaction_metrics": interactions,
        "deltas": {
            "information_gain_over_direct": candidate["mean_normalized_information_gain"]
            - direct["mean_normalized_information_gain"],
            "assignment_gain_over_direct": candidate["correct_assignment_rate"]
            - direct["correct_assignment_rate"],
            "information_gain_over_no_feedback": candidate[
                "mean_normalized_information_gain"
            ]
            - no_feedback["mean_normalized_information_gain"],
            "assignment_gain_over_no_feedback": candidate["correct_assignment_rate"]
            - no_feedback["correct_assignment_rate"],
            "advantage_gap_over_mismatched": candidate["mean_assignment_advantage"]
            - mismatch["mean_assignment_advantage"],
        },
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
        "sealed_test_authorized": split == "calibration" and all(checks.values()),
        "claim_boundary": freeze["claim_boundary"],
    }
    return {**payload, "assessment_id": content_digest(payload)}
