from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import EvidencePartition


ABSTAIN = -1


class ProbeKind(str, Enum):
    PROCEDURE = "procedure"
    CLOSED_BOOK_FACT = "closed_book_fact"
    ORACLE_EVIDENCE = "oracle_evidence"
    IRRELEVANT_EVIDENCE = "irrelevant_evidence"
    CONFLICTING_EVIDENCE = "conflicting_evidence"
    UNKNOWN_FACT = "unknown_fact"


@dataclass(frozen=True)
class EvidenceItem:
    key: int
    value: int

    def as_dict(self) -> Dict[str, int]:
        return {"key": self.key, "value": self.value}


@dataclass(frozen=True)
class ProbeInput:
    kind: ProbeKind
    query_key: int = 0
    operation: str = ""
    operands: Tuple[int, ...] = ()
    evidence: Tuple[EvidenceItem, ...] = ()
    value_modulus: int = 16

    def __post_init__(self) -> None:
        if self.value_modulus <= 1:
            raise ValueError("value_modulus must exceed one")
        if self.kind == ProbeKind.PROCEDURE:
            if self.operation not in ("add_mod", "xor", "max"):
                raise ValueError("unsupported procedure operation")
            if len(self.operands) != 2:
                raise ValueError("procedure probes require two operands")
        elif self.operation or self.operands:
            raise ValueError("fact probes cannot contain procedure fields")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind.value,
            "query_key": self.query_key,
            "operation": self.operation,
            "operands": list(self.operands),
            "evidence": [item.as_dict() for item in self.evidence],
            "value_modulus": self.value_modulus,
        }


@dataclass(frozen=True)
class CognitiveProbe:
    partition: EvidencePartition
    seed: int
    knowledge_seed: int
    fact_count: int
    public_input: ProbeInput
    expected_answer: int
    generator_version: str = "cognitive-probe-generator-v1"

    def __post_init__(self) -> None:
        if self.fact_count <= 0:
            raise ValueError("fact_count must be positive")
        if not (
            self.expected_answer == ABSTAIN
            or 0 <= self.expected_answer < self.public_input.value_modulus
        ):
            raise ValueError("expected answer is outside the label space")

    @property
    def probe_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        payload = {
            "partition": self.partition.value,
            "seed": self.seed,
            "knowledge_seed": self.knowledge_seed,
            "fact_count": self.fact_count,
            "public_input": self.public_input.as_dict(),
            "expected_answer": self.expected_answer,
            "generator_version": self.generator_version,
        }
        if include_id:
            payload["probe_id"] = self.probe_id
        return payload


@dataclass(frozen=True)
class Decision:
    label: int
    confidence: float
    source: str

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be in [0, 1]")
        if not self.source:
            raise ValueError("decision source must not be empty")


@dataclass(frozen=True)
class CognitiveObservation:
    candidate_id: str
    probe_id: str
    predicted_answer: int
    confidence: float
    source: str
    reported_correct: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "probe_id": self.probe_id,
            "predicted_answer": self.predicted_answer,
            "confidence": self.confidence,
            "source": self.source,
            "reported_correct": self.reported_correct,
        }


@dataclass(frozen=True)
class CognitiveFailure:
    probe: CognitiveProbe
    better_answer: int
    worse_answer: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "probe": self.probe.as_dict(),
            "better_answer": self.better_answer,
            "worse_answer": self.worse_answer,
        }
