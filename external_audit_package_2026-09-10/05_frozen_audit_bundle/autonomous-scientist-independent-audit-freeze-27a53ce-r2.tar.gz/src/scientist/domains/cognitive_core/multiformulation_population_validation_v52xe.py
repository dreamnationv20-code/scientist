from __future__ import annotations

from itertools import product
from typing import Any, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.cross_channel_binding_v52x import (
    descriptor_direction,
)
from scientist.domains.cognitive_core.hubness_corrected_alignment_v52xc import (
    calibration_gate_passed,
    evaluate_geometry_records,
    output_installation_gate_passed,
)
from scientist.domains.cognitive_core.reciprocal_role_alignment_v52xd import (
    M52XD_HELDOUT_DIRECTIONS,
    M52XD_TRAINED_DIRECTIONS,
)


MULTIFORMULATION_POPULATION_VALIDATION_VERSION = (
    "general-cognitive-multiformulation-population-validation-v52xe"
)
M52XE_SEED = 53171
M52XE_M52XD_AUDIT_ID = (
    "d03063bb89e0b7c02fda02b071823971d2cb3b2a2351a2b63186400fd2977ca3"
)
M52XE_TRAINED_DIRECTIONS = M52XD_TRAINED_DIRECTIONS
M52XE_HELDOUT_DIRECTIONS = M52XD_HELDOUT_DIRECTIONS
M52XE_STYLE_COUNT = 3

M52XE_TRANSFORMS = {
    "selection": {
        "name": ("designation_reference", "method_identity", "technique_alias"),
        "principle": (
            "governing_condition_reference",
            "decision_invariant_reference",
            "constraint_signature",
        ),
        "action": (
            "operational_behavior_reference",
            "execution_pattern_reference",
            "mechanism_trace_reference",
        ),
    },
    "confirmation": {
        "name": ("reference_designation", "method_signature", "technique_identity"),
        "principle": (
            "reference_governing_rule",
            "criterion_signature",
            "decision_rule_identity",
        ),
        "action": (
            "reference_operation",
            "behavior_signature",
            "mechanism_identity",
        ),
    },
}


def _fresh_text(
    state: Mapping[str, str],
    channel: str,
    role: str,
    formulation: str,
    style: int,
) -> str:
    value = str(state[channel])
    templates = {
        ("selection", 0, "name", "basis"): (
            "Locate the conceptual counterpart for this method designation: {value}."
        ),
        ("selection", 0, "name", "candidate"): (
            "This candidate record carries the method designation {value}."
        ),
        ("selection", 0, "principle", "basis"): (
            "Locate the conceptual counterpart for this governing condition: {value}."
        ),
        ("selection", 0, "principle", "candidate"): (
            "This candidate record follows the governing condition: {value}."
        ),
        ("selection", 0, "action", "basis"): (
            "Locate the conceptual counterpart for this operational behavior: {value}."
        ),
        ("selection", 0, "action", "candidate"): (
            "This candidate record exhibits the operational behavior: {value}."
        ),
        ("selection", 1, "name", "basis"): (
            "Which account corresponds to the following method identity: {value}?"
        ),
        ("selection", 1, "name", "candidate"): (
            "The account specifies the following method identity: {value}."
        ),
        ("selection", 1, "principle", "basis"): (
            "Which account corresponds to the following decision invariant: {value}?"
        ),
        ("selection", 1, "principle", "candidate"): (
            "The account specifies the following decision invariant: {value}."
        ),
        ("selection", 1, "action", "basis"): (
            "Which account corresponds to the following execution pattern: {value}?"
        ),
        ("selection", 1, "action", "candidate"): (
            "The account specifies the following execution pattern: {value}."
        ),
        ("selection", 2, "name", "basis"): (
            "Match an implementation to this technique alias: {value}."
        ),
        ("selection", 2, "name", "candidate"): (
            "The implementation is known by this technique alias: {value}."
        ),
        ("selection", 2, "principle", "basis"): (
            "Match an implementation to this constraint signature: {value}."
        ),
        ("selection", 2, "principle", "candidate"): (
            "The implementation has this constraint signature: {value}."
        ),
        ("selection", 2, "action", "basis"): (
            "Match an implementation to this mechanism trace: {value}."
        ),
        ("selection", 2, "action", "candidate"): (
            "The implementation has this mechanism trace: {value}."
        ),
        ("confirmation", 0, "name", "basis"): (
            "Treat this designation as the fixed reference method: {value}."
        ),
        ("confirmation", 0, "name", "candidate"): (
            "The proposed counterpart has reference designation {value}."
        ),
        ("confirmation", 0, "principle", "basis"): (
            "Treat this governing rule as the fixed reference: {value}."
        ),
        ("confirmation", 0, "principle", "candidate"): (
            "The proposed counterpart follows the reference governing rule: {value}."
        ),
        ("confirmation", 0, "action", "basis"): (
            "Treat this operation as the fixed reference behavior: {value}."
        ),
        ("confirmation", 0, "action", "candidate"): (
            "The proposed counterpart performs the reference operation: {value}."
        ),
        ("confirmation", 1, "name", "basis"): (
            "Verify equivalence to this method signature: {value}."
        ),
        ("confirmation", 1, "name", "candidate"): (
            "The verification candidate presents method signature {value}."
        ),
        ("confirmation", 1, "principle", "basis"): (
            "Verify equivalence to this criterion signature: {value}."
        ),
        ("confirmation", 1, "principle", "candidate"): (
            "The verification candidate presents criterion signature: {value}."
        ),
        ("confirmation", 1, "action", "basis"): (
            "Verify equivalence to this behavior signature: {value}."
        ),
        ("confirmation", 1, "action", "candidate"): (
            "The verification candidate presents behavior signature: {value}."
        ),
        ("confirmation", 2, "name", "basis"): (
            "Use this technique identity to anchor the pairing: {value}."
        ),
        ("confirmation", 2, "name", "candidate"): (
            "The paired description reports technique identity {value}."
        ),
        ("confirmation", 2, "principle", "basis"): (
            "Use this decision-rule identity to anchor the pairing: {value}."
        ),
        ("confirmation", 2, "principle", "candidate"): (
            "The paired description reports decision-rule identity: {value}."
        ),
        ("confirmation", 2, "action", "basis"): (
            "Use this mechanism identity to anchor the pairing: {value}."
        ),
        ("confirmation", 2, "action", "candidate"): (
            "The paired description reports mechanism identity: {value}."
        ),
    }
    try:
        return templates[(formulation, style, channel, role)].format(value=value)
    except KeyError as error:
        raise ValueError(
            f"unknown M52xe formulation/style/channel/role: "
            f"{formulation}/{style}/{channel}/{role}"
        ) from error


def build_multiformulation_rows(
    ledger: Mapping[str, Any], formulation: str
) -> Tuple[Mapping[str, Any], ...]:
    if formulation not in M52XE_TRANSFORMS:
        raise ValueError("M52xe formulation must be selection or confirmation")
    transforms = M52XE_TRANSFORMS[formulation]
    rows = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != "discovery":
            continue
        states = tuple(family_value["states"])
        state_index = {str(state["key"]): state for state in states}
        if len(states) != 4:
            raise ValueError("M52xe requires four states in every discovery family")
        for direction in M52XE_TRAINED_DIRECTIONS:
            basis_channel, candidate_channel = direction.split("->")
            for basis_style, candidate_style in product(
                range(M52XE_STYLE_COUNT), repeat=2
            ):
                for basis_state in states:
                    orbit = content_digest(
                        {
                            "milestone": "M52xe",
                            "formulation": formulation,
                            "family": family,
                            "direction": direction,
                            "basis_style": basis_style,
                            "candidate_style": candidate_style,
                            "basis_state": basis_state["key"],
                        }
                    )
                    for candidate_key, candidate_state in state_index.items():
                        metadata = {
                            "record_id": content_digest(
                                {"orbit": orbit, "candidate_state": candidate_key}
                            ),
                            "orbit_id": orbit,
                            "family": str(family),
                            "semantic_split": "discovery",
                            "formulation_split": formulation,
                            "basis_style": int(basis_style),
                            "candidate_style": int(candidate_style),
                            "basis_state_key": str(basis_state["key"]),
                            "candidate_state_key": candidate_key,
                            "basis_transformation": transforms[basis_channel][basis_style],
                            "basis_transformation_split": "m52xe_fresh_multiformulation",
                            "candidate_transformation": transforms[candidate_channel][
                                candidate_style
                            ],
                            "candidate_transformation_split": (
                                "m52xe_fresh_multiformulation"
                            ),
                            "basis_text": _fresh_text(
                                basis_state,
                                basis_channel,
                                "basis",
                                formulation,
                                basis_style,
                            ),
                            "candidate_text": _fresh_text(
                                candidate_state,
                                candidate_channel,
                                "candidate",
                                formulation,
                                candidate_style,
                            ),
                            "relation_target": (
                                "YES"
                                if str(basis_state["key"]) == candidate_key
                                else "NO"
                            ),
                        }
                        row = {"metadata": metadata}
                        if descriptor_direction(row) != direction:
                            raise ValueError("M52xe transformation routing is inconsistent")
                        rows.append(row)
    return tuple(rows)


def population_geometry_gate_passed(
    geometry: Mapping[str, Any], contract: Mapping[str, float]
) -> tuple[bool, Mapping[str, bool], Mapping[str, float]]:
    retrieval = geometry["retrieval"]
    hubness = geometry["hubness"]
    reciprocity = geometry["reciprocity"]
    group_count = max(int(hubness["top1_group_count"]), 1)
    highest_population_rate = float(
        hubness["errors_to_highest_mean_similarity_column"]
    ) / group_count
    recurrent_population_rate = float(
        hubness["errors_to_recurrent_family_attractor"]
    ) / group_count
    summary = {
        "highest_column_error_population_rate": highest_population_rate,
        "recurrent_attractor_error_population_rate": recurrent_population_rate,
        "conditional_highest_column_error_rate_diagnostic_only": float(
            hubness["errors_to_highest_mean_similarity_column_rate"]
        ),
        "conditional_recurrent_attractor_error_rate_diagnostic_only": float(
            hubness["errors_to_recurrent_family_attractor_rate"]
        ),
    }
    checks = {
        "minimum_hidden_ranking_accuracy": float(
            retrieval["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_hidden_ranking_accuracy"]),
        "minimum_hidden_top1_accuracy": float(
            retrieval["ranking"]["top1_accuracy"]
        )
        >= float(contract["minimum_hidden_top1_accuracy"]),
        "minimum_each_direction_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in retrieval["by_direction"].values()
        )
        >= float(contract["minimum_each_direction_ranking_accuracy"]),
        "minimum_each_direction_top1_accuracy": min(
            float(value["ranking"]["top1_accuracy"])
            for value in retrieval["by_direction"].values()
        )
        >= float(contract["minimum_each_direction_top1_accuracy"]),
        "minimum_each_family_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in retrieval["by_family"].values()
        )
        >= float(contract["minimum_each_family_ranking_accuracy"]),
        "minimum_each_family_top1_accuracy": min(
            float(value["ranking"]["top1_accuracy"])
            for value in retrieval["by_family"].values()
        )
        >= float(contract["minimum_each_family_top1_accuracy"]),
        "maximum_highest_column_error_population_rate": highest_population_rate
        <= float(contract["maximum_highest_column_error_population_rate"]),
        "maximum_recurrent_attractor_error_population_rate": recurrent_population_rate
        <= float(contract["maximum_recurrent_attractor_error_population_rate"]),
        "maximum_candidate_indegree_ratio_to_ideal": float(
            hubness["maximum_candidate_selection_indegree_ratio_to_ideal"]
        )
        <= float(contract["maximum_candidate_indegree_ratio_to_ideal"]),
        "minimum_weakest_pair_reciprocity": float(
            reciprocity["weakest_pair_mean_reciprocal_correlation"]
        )
        >= float(contract["minimum_weakest_pair_reciprocity"]),
        "maximum_direction_ranking_gap": float(
            reciprocity["maximum_direction_ranking_gap"]
        )
        <= float(contract["maximum_direction_ranking_gap"]),
    }
    return all(checks.values()), checks, summary


__all__ = (
    "M52XE_HELDOUT_DIRECTIONS",
    "M52XE_M52XD_AUDIT_ID",
    "M52XE_SEED",
    "M52XE_STYLE_COUNT",
    "M52XE_TRAINED_DIRECTIONS",
    "M52XE_TRANSFORMS",
    "MULTIFORMULATION_POPULATION_VALIDATION_VERSION",
    "build_multiformulation_rows",
    "calibration_gate_passed",
    "evaluate_geometry_records",
    "output_installation_gate_passed",
    "population_geometry_gate_passed",
)
