from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.naturalistic_transfer_v24 import (
    NATURALISTIC_TRANSFER_VERSION,
    NaturalisticTransferFreeze,
    PythonRepairTask,
    PythonTestCase,
)
from scientist.domains.cognitive_core.primitive_invention_audit_v21 import (
    PrimitiveInventionAuditAuthority,
)


NATURALISTIC_AUDIT_AUTHORITY_REF = "sealed-python-transfer-audit-v24"


@dataclass(frozen=True)
class NaturalisticAuditCommitment:
    seeds: Tuple[int, ...]
    tasks_per_family: int
    sealed_spec_digest: str

    @property
    def commitment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": NATURALISTIC_TRANSFER_VERSION,
            "seeds": list(self.seeds),
            "tasks_per_family": self.tasks_per_family,
            "sealed_spec_digest": self.sealed_spec_digest,
            "authority_ref": NATURALISTIC_AUDIT_AUTHORITY_REF,
        }
        if include_id:
            value["commitment_id"] = self.commitment_id
        return value


@dataclass(frozen=True)
class NaturalisticAuditMaterialization:
    commitment: NaturalisticAuditCommitment
    transfer_freeze_id: str
    tasks: Tuple[PythonRepairTask, ...]
    materialization_stage: int

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": NATURALISTIC_TRANSFER_VERSION,
            "commitment": self.commitment.as_dict(),
            "transfer_freeze_id": self.transfer_freeze_id,
            "candidate_tasks": [item.candidate_view() for item in self.tasks],
            "evaluator_digests": [
                content_digest(
                    {
                        "task_id": item.task_id,
                        "family": item.evaluator_family,
                        "hidden": [test.as_dict() for test in item.hidden_tests],
                    }
                )
                for item in self.tasks
            ],
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


_SOURCE_FORMS = (
    'def policy(x):\n    """Return the policy score for x."""\n    return x\n',
    (
        "def decide(value: 'int') -> 'int':\n"
        "    # Existing implementation is known to fail its examples.\n"
        "    return value + 1\n"
    ),
    (
        "def score(size):\n"
        "    baseline = size * 0\n"
        "    return baseline\n"
    ),
    (
        'def choose(amount):\n'
        '    """Behavior is specified by the accompanying executable examples."""\n'
        "    return -amount + 1\n"
    ),
)


class NaturalisticTransferAuditAuthority:
    def __init__(
        self,
        seeds: Tuple[int, ...] = (2411, 2423, 2441, 2459, 2473),
        tasks_per_family: int = 4,
    ) -> None:
        if len(seeds) < 5 or tasks_per_family < 4:
            raise ValueError("Python transfer audit requires five seeds and four tasks per family")
        self._seeds = seeds
        self._tasks_per_family = tasks_per_family
        self._sealed_spec = {
            "seeds": seeds,
            "tasks_per_family": tasks_per_family,
            "families": ("alternating_partition", "ordered_partition"),
            "surface_forms": len(_SOURCE_FORMS),
            "authority": NATURALISTIC_AUDIT_AUTHORITY_REF,
        }
        self.commitment = NaturalisticAuditCommitment(
            seeds, tasks_per_family, content_digest(self._sealed_spec)
        )
        self._materialized = False

    @staticmethod
    def _task(seed: int, index: int, family: str) -> PythonRepairTask:
        primitive = PrimitiveInventionAuditAuthority._task(seed, index, family)
        visible = tuple(
            PythonTestCase(int(item.inputs[0]), int(item.output))
            for item in primitive.visible_examples
        )
        hidden = tuple(
            PythonTestCase(value, expected)
            for value, expected in sorted(primitive.hidden_outputs.items())
        )
        return PythonRepairTask(
            content_digest(
                {
                    "authority": NATURALISTIC_AUDIT_AUTHORITY_REF,
                    "primitive_task_id": primitive.task_id,
                    "surface": index % len(_SOURCE_FORMS),
                }
            ),
            _SOURCE_FORMS[index % len(_SOURCE_FORMS)],
            visible,
            primitive.domain,
            hidden,
            family,
        )

    def materialize(
        self,
        transfer_freeze: NaturalisticTransferFreeze,
        *,
        materialization_stage: int = 5,
    ) -> NaturalisticAuditMaterialization:
        if self._materialized:
            raise ValueError("naturalistic audit may be materialized only once")
        if transfer_freeze.freeze_stage >= materialization_stage:
            raise ValueError("naturalistic adapter did not freeze before audit")
        tasks = tuple(
            self._task(seed, index, family)
            for seed in self._seeds
            for family in self._sealed_spec["families"]
            for index in range(self._tasks_per_family)
        )
        self._materialized = True
        return NaturalisticAuditMaterialization(
            self.commitment, transfer_freeze.freeze_id, tasks, materialization_stage
        )

    def verify(
        self,
        materialization: NaturalisticAuditMaterialization,
        transfer_freeze: NaturalisticTransferFreeze,
    ) -> bool:
        return (
            materialization.commitment == self.commitment
            and materialization.transfer_freeze_id == transfer_freeze.freeze_id
            and self.commitment.sealed_spec_digest == content_digest(self._sealed_spec)
        )


def build_naturalistic_development_tasks() -> Tuple[PythonRepairTask, ...]:
    return tuple(
        NaturalisticTransferAuditAuthority._task(2399, index, family)
        for family in ("alternating_partition", "ordered_partition")
        for index in range(2)
    )
