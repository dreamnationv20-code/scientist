from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import MetaExample
from scientist.domains.cognitive_core.primitive_invention_v21 import (
    InventedPrimitive,
    PrimitiveInventionTrace,
    invent_primitive,
)


NATURALISTIC_TRANSFER_VERSION = "cognitive-core-naturalistic-transfer-v24"


@dataclass(frozen=True)
class PythonTestCase:
    input_value: int
    expected_output: int

    def as_dict(self) -> Dict[str, int]:
        return {"input": self.input_value, "expected": self.expected_output}


@dataclass(frozen=True)
class PythonRepairTask:
    task_id: str
    source: str
    visible_tests: Tuple[PythonTestCase, ...]
    legal_input_domain: Tuple[int, ...]
    hidden_tests: Tuple[PythonTestCase, ...]
    evaluator_family: str

    def candidate_view(self) -> Dict[str, object]:
        return {
            "task_id": self.task_id,
            "source": self.source,
            "visible_tests": [item.as_dict() for item in self.visible_tests],
            "legal_input_domain": list(self.legal_input_domain),
        }


@dataclass(frozen=True)
class PythonRepairPatch:
    task_id: str
    original_source_digest: str
    repaired_source: str | None
    primitive_trace: PrimitiveInventionTrace
    syntax_valid: bool
    visible_tests_pass: bool

    @property
    def patch_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": NATURALISTIC_TRANSFER_VERSION,
            "task_id": self.task_id,
            "original_source_digest": self.original_source_digest,
            "repaired_source": self.repaired_source,
            "primitive_trace": self.primitive_trace.as_dict(),
            "syntax_valid": self.syntax_valid,
            "visible_tests_pass": self.visible_tests_pass,
        }
        if include_id:
            value["patch_id"] = self.patch_id
        return value


def _affine_expression(variable: str, slope: int, intercept: int) -> ast.expr:
    product: ast.expr = ast.BinOp(
        left=ast.Constant(slope), op=ast.Mult(), right=ast.Name(variable, ast.Load())
    )
    return ast.BinOp(left=product, op=ast.Add(), right=ast.Constant(intercept))


def _primitive_expression(program: InventedPrimitive, variable: str) -> ast.expr:
    predicate = program.predicate
    if predicate.operator == "remainder_class":
        divisor, residue = predicate.arguments
        test: ast.expr = ast.Compare(
            left=ast.BinOp(
                left=ast.Name(variable, ast.Load()),
                op=ast.Mod(),
                right=ast.Constant(divisor),
            ),
            ops=[ast.Eq()],
            comparators=[ast.Constant(residue)],
        )
    elif predicate.operator == "ordered_cut":
        (threshold,) = predicate.arguments
        test = ast.Compare(
            left=ast.Name(variable, ast.Load()),
            ops=[ast.Lt()],
            comparators=[ast.Constant(threshold)],
        )
    else:
        raise ValueError("primitive cannot be rendered to the bounded Python adapter")
    return ast.IfExp(
        test=test,
        body=_affine_expression(
            variable, program.when_true.slope, program.when_true.intercept
        ),
        orelse=_affine_expression(
            variable, program.when_false.slope, program.when_false.intercept
        ),
    )


def _single_function(tree: ast.Module) -> ast.FunctionDef:
    functions = [item for item in tree.body if isinstance(item, ast.FunctionDef)]
    if len(functions) != 1 or len(functions[0].args.args) != 1:
        raise ValueError("bounded Python adapter requires one unary function")
    return functions[0]


def _replace_return(function: ast.FunctionDef, expression: ast.expr) -> None:
    returns = [item for item in ast.walk(function) if isinstance(item, ast.Return)]
    if len(returns) != 1:
        raise ValueError("bounded Python adapter requires one return statement")
    returns[0].value = expression


def execute_python_function(source: str, input_value: int) -> int:
    tree = ast.parse(source, mode="exec")
    function = _single_function(tree)
    namespace: Dict[str, object] = {}
    exec(compile(tree, "<candidate-repair>", "exec"), {"__builtins__": {}}, namespace)
    value = namespace[function.name](input_value)  # type: ignore[operator]
    if not isinstance(value, int):
        raise TypeError("repaired function returned a non-integer")
    return value


def render_python_program(source: str, program: InventedPrimitive) -> str:
    """Render a frozen invented program into an existing unary Python function."""

    tree = ast.parse(source, mode="exec")
    function = _single_function(tree)
    variable = function.args.args[0].arg
    _replace_return(function, _primitive_expression(program, variable))
    ast.fix_missing_locations(tree)
    repaired = ast.unparse(tree) + "\n"
    ast.parse(repaired, mode="exec")
    return repaired


def repair_python_task(task: PythonRepairTask) -> PythonRepairPatch:
    examples = tuple(
        MetaExample((item.input_value,), item.expected_output)
        for item in task.visible_tests
    )
    trace = invent_primitive(examples, task.legal_input_domain)
    repaired = None
    syntax_valid = False
    visible_pass = False
    if trace.selected is not None:
        try:
            repaired = render_python_program(task.source, trace.selected)
            syntax_valid = True
            visible_pass = all(
                execute_python_function(repaired, item.input_value)
                == item.expected_output
                for item in task.visible_tests
            )
        except (KeyError, SyntaxError, TypeError, ValueError):
            repaired = None
    return PythonRepairPatch(
        task.task_id,
        content_digest(task.source),
        repaired,
        trace,
        syntax_valid,
        visible_pass,
    )


def score_python_source(source: str | None, tests: Sequence[PythonTestCase]) -> float:
    if source is None:
        return 0.0
    passed = 0
    for item in tests:
        try:
            passed += execute_python_function(source, item.input_value) == item.expected_output
        except (KeyError, SyntaxError, TypeError, ValueError):
            pass
    return passed / len(tests)


@dataclass(frozen=True)
class NaturalisticTransferFreeze:
    source_primitive_freeze_id: str
    source_representation_freeze_id: str
    adapter_source_digest: str
    development_patch_ids: Tuple[str, ...]
    retraining_performed: bool = False
    freeze_stage: int = 4

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": NATURALISTIC_TRANSFER_VERSION,
            "source_primitive_freeze_id": self.source_primitive_freeze_id,
            "source_representation_freeze_id": self.source_representation_freeze_id,
            "adapter_source_digest": self.adapter_source_digest,
            "development_patch_ids": list(self.development_patch_ids),
            "retraining_performed": self.retraining_performed,
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_naturalistic_transfer(
    patches: Mapping[str, PythonRepairPatch],
    *,
    source_primitive_freeze_id: str,
    source_representation_freeze_id: str,
    adapter_source_digest: str,
) -> NaturalisticTransferFreeze:
    if not patches or any(
        item.repaired_source is None or not item.visible_tests_pass
        for item in patches.values()
    ):
        raise ValueError("Python transfer development did not produce valid patches")
    return NaturalisticTransferFreeze(
        source_primitive_freeze_id,
        source_representation_freeze_id,
        adapter_source_digest,
        tuple(sorted(item.patch_id for item in patches.values())),
    )


@dataclass(frozen=True)
class NaturalisticTransferTrial:
    patches: Mapping[str, PythonRepairPatch]
    repaired_scores: Mapping[str, float]
    original_scores: Mapping[str, float]
    family_scores: Mapping[str, float]
    surface_form_count: int
    checks: Mapping[str, bool]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": NATURALISTIC_TRANSFER_VERSION,
            "patches": {key: item.as_dict() for key, item in sorted(self.patches.items())},
            "repaired_scores": dict(sorted(self.repaired_scores.items())),
            "original_scores": dict(sorted(self.original_scores.items())),
            "family_scores": dict(sorted(self.family_scores.items())),
            "surface_form_count": self.surface_form_count,
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def run_naturalistic_trial(tasks: Sequence[PythonRepairTask]) -> NaturalisticTransferTrial:
    patches = {task.task_id: repair_python_task(task) for task in tasks}
    repaired = {
        task.task_id: score_python_source(
            patches[task.task_id].repaired_source, task.hidden_tests
        )
        for task in tasks
    }
    originals = {
        task.task_id: score_python_source(task.source, task.hidden_tests)
        for task in tasks
    }
    families = sorted({task.evaluator_family for task in tasks})
    family_scores = {
        family: sum(repaired[task.task_id] for task in tasks if task.evaluator_family == family)
        / sum(task.evaluator_family == family for task in tasks)
        for family in families
    }
    surfaces = {
        content_digest(ast.dump(ast.parse(task.source), include_attributes=False))
        for task in tasks
    }
    revised_mean = sum(repaired.values()) / len(repaired)
    original_mean = sum(originals.values()) / len(originals)
    checks = {
        "all_generated_patches_parse_and_pass_visible_tests": all(
            item.syntax_valid and item.visible_tests_pass for item in patches.values()
        ),
        "fresh_hidden_python_tests_pass": min(family_scores.values()) >= 0.95,
        "transfer_beats_original_python_functions": (
            revised_mean >= 0.95 and revised_mean - original_mean >= 0.40
        ),
        "multiple_python_surface_forms_transfer": len(surfaces) >= 3,
        "every_patch_contains_invented_control_flow": all(
            item.repaired_source is not None
            and isinstance(
                _single_function(ast.parse(item.repaired_source)).body[-1].value, ast.IfExp  # type: ignore[attr-defined]
            )
            for item in patches.values()
        ),
    }
    return NaturalisticTransferTrial(
        patches, repaired, originals, family_scores, len(surfaces), checks
    )
