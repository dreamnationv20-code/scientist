from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.naturalistic_transfer_audit_v24 import (
    NaturalisticAuditMaterialization,
)
from scientist.domains.cognitive_core.naturalistic_transfer_v24 import (
    NaturalisticTransferFreeze,
    NaturalisticTransferTrial,
    PythonRepairPatch,
    repair_python_task,
)


NATURALISTIC_VERIFIER_REF = "naturalistic-transfer-independent-verifier-v24"


@dataclass(frozen=True)
class NaturalisticTransferVerification:
    checks: Mapping[str, bool]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "verifier_ref": NATURALISTIC_VERIFIER_REF,
            "checks": dict(sorted(self.checks.items())),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_naturalistic_transfer(
    *,
    development_patches: Mapping[str, PythonRepairPatch],
    transfer_freeze: NaturalisticTransferFreeze,
    source_primitive_freeze_id: str,
    source_representation_freeze_id: str,
    materialization: NaturalisticAuditMaterialization,
    trial: NaturalisticTransferTrial,
    artifact_round_trips: Mapping[str, bool],
) -> NaturalisticTransferVerification:
    candidate_text = json.dumps(
        [task.candidate_view() for task in materialization.tasks], sort_keys=True
    ).lower()
    source = inspect.getsource(repair_python_task).lower()
    checks = {
        "development_repairs_compile_and_pass": bool(development_patches)
        and all(
            item.syntax_valid and item.visible_tests_pass
            for item in development_patches.values()
        ),
        "adapter_reuses_prior_core_without_retraining": (
            transfer_freeze.source_primitive_freeze_id == source_primitive_freeze_id
            and transfer_freeze.source_representation_freeze_id
            == source_representation_freeze_id
            and not transfer_freeze.retraining_performed
        ),
        "candidate_view_hides_hidden_tests_and_family": all(
            token not in candidate_text
            for token in ("hidden_tests", "evaluator_family", "hidden_outputs")
        ),
        "adapter_has_no_mechanism_family_dispatch": all(
            token not in source
            for token in ("alternating_partition", "ordered_partition")
        ),
        "audit_materializes_after_adapter_freeze": (
            materialization.transfer_freeze_id == transfer_freeze.freeze_id
            and transfer_freeze.freeze_stage < materialization.materialization_stage
        ),
        "fresh_python_transfer_and_ablation_pass": trial.passed,
        "artifacts_round_trip_exactly": bool(artifact_round_trips)
        and all(artifact_round_trips.values()),
    }
    return NaturalisticTransferVerification(
        checks,
        (
            "The frozen primitive-invention core transferred without retraining from its "
            "synthetic behavioral interface to raw Python source, generated AST-valid "
            "repairs, and passed sealed executable tests across multiple surface forms."
        ),
        (
            "arbitrary software repair is solved",
            "natural-language or machine-learning transfer is established",
            "the general cognitive core is solved",
        ),
        (
            "Transfer is limited to unary integer Python functions with one return statement.",
            "The target behavior remains specified by executable examples.",
            "The Python benchmark is procedurally generated, although compilation and execution are real.",
        ),
    )
