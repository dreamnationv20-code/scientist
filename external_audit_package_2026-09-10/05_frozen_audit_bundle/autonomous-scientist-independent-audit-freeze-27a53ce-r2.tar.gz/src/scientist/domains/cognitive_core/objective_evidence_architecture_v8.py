from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Mapping, Tuple

from scientist.program.goal_graph import (
    CompositionOperator,
    DEFAULT_MAX_EVIDENCE_DEPTH,
    DEFAULT_MAX_META_COMPUTE_FRACTION,
    DependencyEdge,
    DependencyKind,
    GoalGraphDecompositionProposal,
    GoalNodeKind,
    GoalNodeRole,
    GoalNodeSpec,
    ParentCompositionRule,
    STRICT_REPRESENTATION_REVISION_TRIGGER,
)
from scientist.research_programs.cognitive_core import high_level_goal


OBJECTIVE_EVIDENCE_ARCHITECTURE_VERSION = (
    "cognitive-core-objective-evidence-architecture-v8"
)


@dataclass(frozen=True)
class ObjectiveEvidenceArchitecture:
    objective_program: GoalNodeSpec
    capabilities: Mapping[str, GoalNodeSpec]
    work_packages: Mapping[str, GoalNodeSpec]
    root_revision: GoalGraphDecompositionProposal
    capability_decompositions: Tuple[GoalGraphDecompositionProposal, ...]
    max_new_evidence_depth: int = DEFAULT_MAX_EVIDENCE_DEPTH
    maximum_meta_compute_fraction: float = DEFAULT_MAX_META_COMPUTE_FRACTION
    representation_revision_trigger: str = STRICT_REPRESENTATION_REVISION_TRIGGER

    @property
    def objective_node_ids(self) -> Tuple[str, ...]:
        return (
            self.objective_program.node_id,
            *tuple(item.node_id for item in self.capabilities.values()),
            *tuple(item.node_id for item in self.work_packages.values()),
        )


def _objective_node(
    *,
    goal_id: str,
    title: str,
    question: str,
    rationale: str,
    success: Tuple[str, ...],
    falsification: Tuple[str, ...],
    artifact: str,
    tags: Tuple[str, ...],
    kind: GoalNodeKind = GoalNodeKind.CAPABILITY,
) -> GoalNodeSpec:
    return GoalNodeSpec(
        goal_id=goal_id,
        title=title,
        question=question,
        kind=kind,
        rationale=rationale,
        success_conditions=success,
        falsification_conditions=falsification,
        expected_artifact=artifact,
        critical=True,
        tags=("objective", *tags),
        role=GoalNodeRole.OBJECTIVE,
    )


def _all_rule(
    parent: GoalNodeSpec,
    children: Tuple[GoalNodeSpec, ...],
    rationale: str,
    *,
    supersedes_rule_id: str | None = None,
) -> ParentCompositionRule:
    return ParentCompositionRule(
        parent_id=parent.node_id,
        child_ids=tuple(item.node_id for item in children),
        operator=CompositionOperator.ALL,
        integration_test=(
            "Every functional child must be demonstrated in the same candidate; "
            "supporting evidence may validate a child but cannot substitute for it."
        ),
        rationale=rationale,
        decomposer_ref=OBJECTIVE_EVIDENCE_ARCHITECTURE_VERSION,
        supersedes_rule_id=supersedes_rule_id,
    )


def objective_first_architecture(
    *,
    root: GoalNodeSpec,
    active_root_rule_id: str,
) -> ObjectiveEvidenceArchitecture:
    goal = high_level_goal()
    if root.goal_id != goal.goal_id:
        raise ValueError("objective architecture targets another goal")

    objective_program = _objective_node(
        goal_id=goal.goal_id,
        title="Functional compact cognitive core",
        question=(
            "Can one cost-matched system acquire, route, use, update, and "
            "preserve knowledge and procedures across unseen tasks?"
        ),
        kind=GoalNodeKind.INTEGRATION,
        rationale=(
            "This is the object-level deliverable. Laboratory validity and "
            "diagnostics support it but are not components of the deliverable."
        ),
        success=goal.integration_requirements,
        falsification=goal.failure_conditions,
        artifact="frozen cost-matched cognitive-core implementation",
        tags=("functional-core", "cost-matched"),
    )

    capability_definitions = {
        "procedures": (
            "Reusable procedural competence",
            "Can reusable operations transfer compositionally beyond trained templates?",
        ),
        "rapid_learning": (
            "Rapid acquisition of new tasks",
            "Can a new task be inferred and acquired from few demonstrations at fixed cost?",
        ),
        "routing": (
            "Selective information routing",
            "Can the system infer what information should influence which capability channel?",
        ),
        "evidence": (
            "Evidence-grounded decision control",
            "Can the system use relevant evidence and resist irrelevant, conflicting, or adversarial evidence?",
        ),
        "updating": (
            "Targeted knowledge updating",
            "Can requested knowledge change be acquired and confined to its causal target?",
        ),
        "retention": (
            "Protected knowledge and skill retention",
            "Can unrelated knowledge and procedures survive immediate and delayed interventions?",
        ),
        "integration": (
            "Cost-matched joint operation",
            "Can all capabilities coexist in one reconstructable system without hidden cost displacement?",
        ),
    }
    capabilities: Dict[str, GoalNodeSpec] = {}
    for key, (title, question) in capability_definitions.items():
        capabilities[key] = _objective_node(
            goal_id=goal.goal_id,
            title=title,
            question=question,
            rationale="This functional capability is necessary and non-substitutable.",
            success=(
                "the capability floor passes on unseen task families",
                "the capability remains non-regressed when integrated",
            ),
            falsification=(
                "a matched incumbent remains superior",
                "the capability gain destroys another required capability",
            ),
            artifact="%s functional capability certificate" % key,
            tags=("capability", key.replace("_", "-")),
        )

    work_package_definitions = {
        "procedure_representation": (
            "procedures", "Represent reusable operations",
            "Represent procedures independently of incidental fact and prompt templates.",
        ),
        "procedure_composition": (
            "procedures", "Execute unseen procedure compositions",
            "Compose operations at unseen combinations and lengths.",
        ),
        "task_inference": (
            "rapid_learning", "Infer the latent task",
            "Recover a new task specification from sparse demonstrations.",
        ),
        "fast_adaptation": (
            "rapid_learning", "Adapt at fixed marginal cost",
            "Acquire the inferred task without retraining the full system.",
        ),
        "relevance_representation": (
            "routing", "Represent relational relevance",
            "Represent target, protected, irrelevant, and uncertain relationships.",
        ),
        "selector_inference": (
            "routing", "Infer target and protected channels",
            "Select the correct influence path on unseen relational compositions.",
        ),
        "uncertainty_routing": (
            "routing", "Route actions under uncertainty",
            "Choose answer, retrieve, clarify, update, or abstain using calibrated utility.",
        ),
        "evidence_discrimination": (
            "evidence", "Discriminate evidence roles",
            "Separate relevant, irrelevant, conflicting, and adversarial evidence.",
        ),
        "evidence_integration": (
            "evidence", "Integrate evidence without destructive override",
            "Use helpful evidence while preserving correct known answers.",
        ),
        "requested_change": (
            "updating", "Acquire the requested change",
            "Install a new value or rule accurately when an update is warranted.",
        ),
        "update_locality": (
            "updating", "Confine change to its causal target",
            "Prevent a valid update from altering unrelated state or capabilities.",
        ),
        "sequential_update_consistency": (
            "updating", "Maintain sequential update consistency",
            "Preserve the latest correct state across repeated updates and delays.",
        ),
        "knowledge_retention": (
            "retention", "Preserve unrelated knowledge",
            "Retain facts and decisions outside the intervention scope.",
        ),
        "procedure_retention": (
            "retention", "Preserve reusable procedures",
            "Retain procedural competence after knowledge and task changes.",
        ),
        "delayed_interference": (
            "retention", "Prevent delayed interference",
            "Keep local non-regression from reversing over longer trajectories.",
        ),
        "shared_architecture": (
            "integration", "Construct one shared architecture",
            "Realize every capability in one frozen candidate rather than separate demonstrations.",
        ),
        "system_cost": (
            "integration", "Match end-to-end system cost",
            "Account for parameters, training, context, memory, retrieval, and adaptation.",
        ),
        "pareto_floors": (
            "integration", "Satisfy all capability floors jointly",
            "Pareto-improve without hiding a collapsed capability in an aggregate score.",
        ),
    }
    work_packages: Dict[str, GoalNodeSpec] = {}
    packages_by_capability: Dict[str, list[GoalNodeSpec]] = {
        key: [] for key in capabilities
    }
    for key, (parent_key, title, question) in work_package_definitions.items():
        node = _objective_node(
            goal_id=goal.goal_id,
            title=title,
            question=question,
            rationale=(
                "This work package changes the functional candidate and must be "
                "completed independently of the evidence used to validate it."
            ),
            success=("a frozen candidate satisfies the declared functional behavior",),
            falsification=("no candidate satisfies the behavior at matched cost",),
            artifact="%s objective work-package result" % key,
            tags=("work-package", key.replace("_", "-")),
            kind=GoalNodeKind.BOTTLENECK,
        )
        work_packages[key] = node
        packages_by_capability[parent_key].append(node)

    root_rule = _all_rule(
        root,
        (objective_program,),
        "The root is achieved by the functional cognitive core; evidence gates justify the claim but do not count as the deliverable.",
        supersedes_rule_id=active_root_rule_id,
    )
    root_revision = GoalGraphDecompositionProposal(
        parent_id=root.node_id,
        nodes=(objective_program,),
        rule=root_rule,
        assumptions=(
            "the user goal defines the necessary functional outcomes before experiments",
            "evidence completion alone cannot satisfy an objective edge",
        ),
        distinguishing_predictions=(
            "objective progress remains zero until a functional capability integrates",
            "completed diagnostics remain preserved as attached evidence",
        ),
        reasoning="Separate what must be built from how claims about it are validated.",
    )
    program_children = tuple(capabilities.values())
    program_rule = _all_rule(
        objective_program,
        program_children,
        "All functional capabilities must coexist in the same cognitive core.",
    )
    decompositions = [
        GoalGraphDecompositionProposal(
            parent_id=objective_program.node_id,
            nodes=program_children,
            rule=program_rule,
            assumptions=("functional capabilities are non-substitutable",),
            distinguishing_predictions=(
                "a gain in one capability cannot compensate for another capability falling below its floor",
            ),
            reasoning="Directly decompose the user goal into necessary functional capabilities.",
        )
    ]
    for capability_key, capability in capabilities.items():
        children = tuple(packages_by_capability[capability_key])
        rule = _all_rule(
            capability,
            children,
            "Complete every functional work package required by %s."
            % capability.title,
        )
        decompositions.append(
            GoalGraphDecompositionProposal(
                parent_id=capability.node_id,
                nodes=children,
                rule=rule,
                assumptions=(
                    "these work packages describe functional outcomes rather than favored mechanisms",
                ),
                distinguishing_predictions=(
                    "a candidate can fail one work package while passing another",
                ),
                reasoning="Expose object-level work before creating validation experiments.",
            )
        )

    return ObjectiveEvidenceArchitecture(
        objective_program=objective_program,
        capabilities=capabilities,
        work_packages=work_packages,
        root_revision=root_revision,
        capability_decompositions=tuple(decompositions),
    )


def evidence_attachment_targets(
    evidence_node: GoalNodeSpec,
    architecture: ObjectiveEvidenceArchitecture,
) -> Tuple[str, ...]:
    """Route historical evidence to the functional decision it informs."""

    tags = set(evidence_node.tags)
    packages = architecture.work_packages
    if "horizon-transport" in tags or "horizon-transport-map" in tags:
        return (
            packages["sequential_update_consistency"].node_id,
            packages["delayed_interference"].node_id,
        )
    if tags.intersection(
        {
            "representation-adequacy",
            "latent-concept",
            "generator-revision",
            "representation-change",
        }
    ):
        return (
            packages["relevance_representation"].node_id,
            packages["selector_inference"].node_id,
        )
    if tags.intersection(
        {
            "causal-models",
            "causal-model-selection",
            "causal-intervention",
            "factorial",
        }
    ):
        return (packages["selector_inference"].node_id,)
    if tags.intersection({"measurement", "qualification", "system-cost"}):
        return (packages["system_cost"].node_id,)
    if tags.intersection({"terminal", "validation", "replication"}):
        return (architecture.objective_program.node_id,)
    return (architecture.objective_program.node_id,)


def evidence_support_edges(
    *,
    evidence_nodes: Tuple[GoalNodeSpec, ...],
    architecture: ObjectiveEvidenceArchitecture,
) -> Tuple[DependencyEdge, ...]:
    edges = []
    seen = set()
    for evidence_node in evidence_nodes:
        if evidence_node.effective_role != GoalNodeRole.EVIDENCE:
            continue
        for target_id in evidence_attachment_targets(
            evidence_node, architecture
        ):
            edge = DependencyEdge(
                source_id=evidence_node.node_id,
                target_id=target_id,
                kind=DependencyKind.SUPPORTS,
                rationale=(
                    "This evidence constrains or validates the attached functional "
                    "objective but cannot satisfy its composition edge."
                ),
            )
            if edge.edge_id not in seen:
                seen.add(edge.edge_id)
                edges.append(edge)
    return tuple(edges)
