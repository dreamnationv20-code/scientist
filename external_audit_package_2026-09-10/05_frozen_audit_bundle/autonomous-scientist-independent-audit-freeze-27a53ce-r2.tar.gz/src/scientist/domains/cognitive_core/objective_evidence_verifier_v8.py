from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.objective_evidence_architecture_v8 import (
    ObjectiveEvidenceArchitecture,
)
from scientist.program.control_plane import AutonomousScientistControlPlane
from scientist.program.goal_graph import (
    DependencyKind,
    GoalNodeRole,
    GoalNodeStatus,
)


OBJECTIVE_EVIDENCE_VERIFIER_REF = (
    "objective-evidence-separation-independent-verifier-v8"
)


@dataclass(frozen=True)
class ObjectiveEvidenceVerification:
    check_results: Mapping[str, bool]
    pre_migration_progress: Mapping[str, Mapping[str, float | int]]
    post_migration_progress: Mapping[str, Mapping[str, float | int]]
    preserved_evidence_node_ids: Tuple[str, ...]
    attached_evidence_node_ids: Tuple[str, ...]
    objective_node_ids: Tuple[str, ...]
    first_action_node_ids: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str = OBJECTIVE_EVIDENCE_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "pre_migration_progress": self.pre_migration_progress,
            "post_migration_progress": self.post_migration_progress,
            "preserved_evidence_node_ids": list(self.preserved_evidence_node_ids),
            "attached_evidence_node_ids": list(self.attached_evidence_node_ids),
            "objective_node_ids": list(self.objective_node_ids),
            "first_action_node_ids": list(self.first_action_node_ids),
            "passed": self.passed,
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_objective_evidence_migration(
    *,
    control: AutonomousScientistControlPlane,
    architecture: ObjectiveEvidenceArchitecture,
    pre_migration_statuses: Mapping[str, GoalNodeStatus],
    pre_migration_progress: Mapping[str, Mapping[str, float | int]],
) -> ObjectiveEvidenceVerification:
    graph = control.graph
    active_objective_ids = {
        node_id
        for node_id, node in graph.nodes.items()
        if node.effective_role == GoalNodeRole.OBJECTIVE
        and graph.status(node_id)
        not in (GoalNodeStatus.INVALIDATED, GoalNodeStatus.SUPERSEDED)
    }
    active_evidence_ids = {
        node_id
        for node_id, node in graph.nodes.items()
        if node.effective_role == GoalNodeRole.EVIDENCE
        and graph.status(node_id)
        not in (GoalNodeStatus.INVALIDATED, GoalNodeStatus.SUPERSEDED)
    }
    support_edges = tuple(
        edge
        for edge in graph.dependencies.values()
        if edge.kind == DependencyKind.SUPPORTS
    )
    attached_evidence = {edge.source_id for edge in support_edges}
    evidence_status_preserved = all(
        node_id in graph.nodes
        and graph.status(node_id) == status
        for node_id, status in pre_migration_statuses.items()
        if node_id in active_evidence_ids
    )
    objective_compositions_are_pure = all(
        graph.nodes[parent_id].effective_role != GoalNodeRole.OBJECTIVE
        or all(
            graph.nodes[child_id].effective_role == GoalNodeRole.OBJECTIVE
            for child_id in rule.child_ids
        )
        for parent_id in graph.nodes
        for rule in (graph.active_rule(parent_id),)
        if rule is not None
    )
    supports_are_typed = all(
        graph.nodes[edge.source_id].effective_role == GoalNodeRole.EVIDENCE
        and graph.nodes[edge.target_id].effective_role == GoalNodeRole.OBJECTIVE
        for edge in support_edges
    )
    root_rule = graph.active_rule(graph.root_id)
    program_rule = graph.active_rule(architecture.objective_program.node_id)
    post_progress = graph.progress_by_role()
    actions = control.next_actions()
    objective_actions = tuple(
        item
        for item in actions
        if graph.nodes[item.node_id].effective_role == GoalNodeRole.OBJECTIVE
    )
    evidence_actions = tuple(
        item
        for item in actions
        if graph.nodes[item.node_id].effective_role == GoalNodeRole.EVIDENCE
    )
    objective_prefix = tuple(actions[: len(objective_actions)])
    policy = control.objective_evidence_policy

    checks = {
        "root_composes_only_the_functional_program": (
            root_rule is not None
            and root_rule.child_ids
            == (architecture.objective_program.node_id,)
        ),
        "functional_program_directly_decomposes_into_capabilities": (
            program_rule is not None
            and set(program_rule.child_ids)
            == {item.node_id for item in architecture.capabilities.values()}
        ),
        "every_capability_has_direct_objective_work_packages": all(
            graph.active_rule(item.node_id) is not None
            and graph.active_rule(item.node_id).child_ids
            for item in architecture.capabilities.values()
        ),
        "objective_compositions_exclude_evidence_nodes": objective_compositions_are_pure,
        "support_edges_are_evidence_to_objective_only": supports_are_typed,
        "every_active_evidence_node_is_attached": (
            active_evidence_ids.issubset(attached_evidence)
        ),
        "historical_evidence_statuses_are_preserved": evidence_status_preserved,
        "historical_evidence_progress_is_preserved": (
            post_progress["evidence"]["integrated"]
            == pre_migration_progress["evidence"]["integrated"]
        ),
        "objective_progress_is_not_inflated_by_evidence": (
            post_progress["objective"]["integrated"] == 0
            and post_progress["objective"]["fraction"] == 0.0
        ),
        "objective_actions_precede_evidence_actions": (
            bool(objective_actions)
            and all(
                graph.nodes[item.node_id].effective_role
                == GoalNodeRole.OBJECTIVE
                for item in objective_prefix
            )
            and (
                not evidence_actions
                or len(objective_prefix) == len(objective_actions)
            )
        ),
        "objective_decomposition_does_not_require_literature_theater": all(
            control.current_literature(item.node_id) is None
            for item in architecture.capabilities.values()
        ),
        "meta_evidence_depth_limit_is_executable": (
            policy["active"]
            and policy["max_new_evidence_depth"]
            == architecture.max_new_evidence_depth
        ),
        "meta_compute_limit_is_executable": (
            policy["maximum_meta_compute_fraction"]
            == architecture.maximum_meta_compute_fraction
            and policy["evidence_compute_spent"]
            + policy["evidence_compute_committed"]
            <= control.evidence_compute_limit + 1e-12
        ),
        "representation_revision_requires_contrastive_concept_evidence": (
            not policy["generic_representation_revision_allowed"]
            and policy["representation_revision_trigger"]
            == architecture.representation_revision_trigger
        ),
        "memory_chain_remains_valid": control.memory.verify_chain(),
    }
    return ObjectiveEvidenceVerification(
        check_results=checks,
        pre_migration_progress=pre_migration_progress,
        post_migration_progress=post_progress,
        preserved_evidence_node_ids=tuple(sorted(active_evidence_ids)),
        attached_evidence_node_ids=tuple(sorted(attached_evidence)),
        objective_node_ids=tuple(sorted(active_objective_ids)),
        first_action_node_ids=tuple(item.node_id for item in actions[:10]),
        limitations=(
            "This migration changes graph semantics and scheduling, not the functional cognitive-core implementation.",
            "Historical evidence is retained under inferred roles; only new objective-first nodes carry explicit roles.",
            "Meta-compute limits are declared for new work but historical diagnostic spending is not retroactively reclassified.",
        ),
    )
