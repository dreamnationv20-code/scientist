from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    COUNTERFACTUAL_DIAGNOSIS_VERSION,
    DiagnosisDossier,
    apply_selection,
    build_dossier,
    build_m35_suite,
    parse_selection,
    score_on_cases,
)
from scientist.domains.cognitive_core.internal_core_v28 import _batch_responses, _chat_prompt
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
    LOCALIZATION_TRAIN_REPRESENTATIONS,
)


ON_POLICY_REVISION_VERSION = "general-cognitive-on-policy-revision-v35"


def _selection_key(response: str) -> str:
    parsed = parse_selection(response)
    if parsed is None:
        return ""
    return f"{parsed[0]}={json.dumps(parsed[1], sort_keys=True)}"


def verifier_feedback(dossier: DiagnosisDossier, response: str) -> str:
    key = _selection_key(response)
    selected = next((item for item in dossier.interventions if item.key == key), None)
    if selected is None:
        return (
            "The selection is not a legal intervention listed in the table. Select one listed node/value pair "
            "and preserve the exact JSON scalar type."
        )
    active_matches = sum(
        int(
            json.dumps(
                _safe_execute(dossier, selected.program, query["input"]), sort_keys=True
            )
            == json.dumps(query["expected"], sort_keys=True)
        )
        for query in dossier.active_queries
    )
    if key in set(dossier.viable_keys):
        return (
            f"The selection fixes_failure={str(selected.fixes_counterexample).lower()}, "
            f"preserves={selected.visible_preserved}/{selected.visible_count}, and "
            f"active_matches={active_matches}/{len(dossier.active_queries)}. It is consistent with all "
            "currently observed evidence; return the same minimal intervention."
        )
    return (
        f"The selected intervention has fixes_failure={str(selected.fixes_counterexample).lower()}, "
        f"preserves={selected.visible_preserved}/{selected.visible_count}, and "
        f"active_matches={active_matches}/{len(dossier.active_queries)}. Reject it. Choose a listed intervention "
        "that fixes the failure, preserves every invariant, and matches every active query."
    )


def _safe_execute(dossier: DiagnosisDossier, program: Mapping[str, Any], value: Any) -> Any:
    from scientist.domains.cognitive_core.repair_benchmark_v32 import execute

    try:
        return execute(dossier.task.representation, program, value)
    except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
        return "execution_error"


def revision_prompt(dossier: DiagnosisDossier, response: str) -> str:
    return (
        dossier.prompt
        + f"\nPrevious selection: {response}\nVerifier feedback: {verifier_feedback(dossier, response)}\n"
        "Revise conservatively. Return exactly: SELECT: node=<node>; value=<JSON value>"
    )


def revision_record(dossier: DiagnosisDossier, response: str) -> Mapping[str, Any]:
    return {
        "messages": [
            {"role": "user", "content": revision_prompt(dossier, response)},
            {
                "role": "assistant",
                "content": (
                    f"SELECT: node={dossier.task.target_node}; "
                    f"value={json.dumps(dossier.task.correct_edit_value, sort_keys=True)}"
                ),
            },
        ],
        "metadata": {
            "task_id": dossier.task.task_id,
            "representation": dossier.task.representation,
            "mode": "on_policy_counterfactual_revision",
            "first_selection_evidence_consistent": _selection_key(response) in set(dossier.viable_keys),
        },
    }


def _generate_split(
    model: Any,
    tokenizer: Any,
    split: str,
    per_representation: int,
) -> tuple[tuple[DiagnosisDossier, ...], tuple[str, ...], float]:
    dossiers = tuple(
        build_dossier(task)
        for task in build_m35_suite(split, per_representation, LOCALIZATION_TRAIN_REPRESENTATIONS)
    )
    prompts = tuple(_chat_prompt(tokenizer, dossier.prompt) for dossier in dossiers)
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        prompts,
        batch_size=8,
        max_tokens=48,
        max_batch_tokens=12000,
    )
    return dossiers, responses, peak_memory


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def collect_on_policy_data(
    output: Path,
    benchmark_root: Path,
    model_path: str,
    selector_adapter: Path,
) -> Mapping[str, Any]:
    from mlx_lm import load

    benchmark = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    model, tokenizer = load(model_path, adapter_path=str(selector_adapter))
    train_dossiers, train_responses, train_peak = _generate_split(model, tokenizer, "train", 60)
    valid_dossiers, valid_responses, valid_peak = _generate_split(model, tokenizer, "valid", 12)
    train_rows = [
        revision_record(dossier, response)
        for dossier, response in zip(train_dossiers, train_responses)
    ]
    valid_rows = [
        revision_record(dossier, response)
        for dossier, response in zip(valid_dossiers, valid_responses)
    ]
    output.mkdir(parents=True, exist_ok=True)
    hashes = {
        "train": _write_jsonl(output / "train.jsonl", train_rows),
        "valid": _write_jsonl(output / "valid.jsonl", valid_rows),
    }
    train_consistent = sum(
        int(_selection_key(response) in set(dossier.viable_keys))
        for dossier, response in zip(train_dossiers, train_responses)
    )
    valid_consistent = sum(
        int(_selection_key(response) in set(dossier.viable_keys))
        for dossier, response in zip(valid_dossiers, valid_responses)
    )
    payload = {
        "version": ON_POLICY_REVISION_VERSION,
        "benchmark_version": COUNTERFACTUAL_DIAGNOSIS_VERSION,
        "benchmark_freeze_id": benchmark["freeze_id"],
        "model_path": model_path,
        "selector_adapter_path": str(selector_adapter),
        "selector_adapter_sha256": hashlib.sha256(
            (selector_adapter / "adapters.safetensors").read_bytes()
        ).hexdigest(),
        "counts": {"train": len(train_rows), "valid": len(valid_rows)},
        "first_selection_evidence_consistent": {
            "train": train_consistent,
            "valid": valid_consistent,
            "train_rate": train_consistent / len(train_rows),
            "valid_rate": valid_consistent / len(valid_rows),
        },
        "hashes": hashes,
        "peak_memory_gb": max(train_peak, valid_peak),
        "test_examples_used": 0,
        "claim_boundary": (
            "Revision supervision is derived only from the selector's train/validation responses. "
            "No M35 test response or authority is included."
        ),
    }
    freeze = {**payload, "data_freeze_id": content_digest(payload)}
    (output / "data-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_on_policy_data(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "data-freeze.json").read_text(encoding="utf-8"))
    hashes = {
        split: hashlib.sha256((output / f"{split}.jsonl").read_bytes()).hexdigest()
        for split in ("train", "valid")
    }
    rows = [
        json.loads(line)
        for split in ("train", "valid")
        for line in (output / f"{split}.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "no_test_file": not (output / "test.jsonl").exists(),
        "declares_zero_test_examples": freeze["test_examples_used"] == 0,
        "only_training_representations": {
            row["metadata"]["representation"] for row in rows
        } == set(LOCALIZATION_TRAIN_REPRESENTATIONS),
        "all_records_are_on_policy_revision": all(
            row["metadata"]["mode"] == "on_policy_counterfactual_revision" for row in rows
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "data_freeze_id": freeze["data_freeze_id"]}


def aggregate_revisions(
    dossiers: Sequence[DiagnosisDossier],
    first_responses: Sequence[str],
    revision_responses: Sequence[str],
) -> Mapping[str, Any]:
    if not (len(dossiers) == len(first_responses) == len(revision_responses)):
        raise ValueError("revision trajectories do not align")
    records = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    for dossier, first_response, revision_response in zip(
        dossiers, first_responses, revision_responses
    ):
        task = dossier.task
        first_program = apply_selection(task, first_response)
        revision_program = apply_selection(task, revision_response)
        revision_consistent = _selection_key(revision_response) in set(dossier.viable_keys)
        first_consistent = _selection_key(first_response) in set(dossier.viable_keys)
        adopted = revision_consistent and not first_consistent
        fell_back_to_candidate = not first_consistent and not revision_consistent
        if first_consistent:
            final_program = first_program
        elif adopted:
            final_program = revision_program
        else:
            final_program = task.candidate
        first_semantic = score_on_cases(task, first_program, dossier.final_cases)
        final_semantic = score_on_cases(task, final_program, dossier.final_cases)
        assessment = {
            "first_semantic_accuracy": first_semantic,
            "two_step_semantic_accuracy": final_semantic,
            "semantic_gain": final_semantic - first_semantic,
            "preserved_correct_accuracy": score_on_cases(task, final_program, task.visible_correct),
            "first_exact": first_program is not None and dict(first_program) == dict(task.authority),
            "final_exact": final_program is not None and dict(final_program) == dict(task.authority),
            "revision_evidence_consistent": revision_consistent,
            "revision_adopted": adopted,
            "fell_back_to_candidate": fell_back_to_candidate,
        }
        records.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "first_response": first_response,
                "revision_response": revision_response,
                "assessment": assessment,
            }
        )
        by_representation.setdefault(task.representation, []).append(assessment)

    def mean(items: Sequence[Mapping[str, Any]], key: str) -> float:
        return sum(float(item[key]) for item in items) / len(items)

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        return {
            "first_semantic_accuracy": mean(items, "first_semantic_accuracy"),
            "two_step_semantic_accuracy": mean(items, "two_step_semantic_accuracy"),
            "semantic_gain": mean(items, "semantic_gain"),
            "preserved_correct_accuracy": mean(items, "preserved_correct_accuracy"),
            "first_exact_rate": mean(items, "first_exact"),
            "two_step_exact_rate": mean(items, "final_exact"),
            "revision_evidence_consistent_rate": mean(items, "revision_evidence_consistent"),
            "revision_adoption_rate": mean(items, "revision_adopted"),
            "candidate_fallback_rate": mean(items, "fell_back_to_candidate"),
        }

    assessments = [record["assessment"] for record in records]
    heldout = [
        record["assessment"]
        for record in records
        if record["representation"] in HELDOUT_LOCALIZATION_REPRESENTATIONS
    ]
    return {
        "metrics": {
            "task_count": len(dossiers),
            **summarize(assessments),
            "heldout_two_step_semantic_accuracy": summarize(heldout)[
                "two_step_semantic_accuracy"
            ],
            "by_representation": {
                representation: summarize(items)
                for representation, items in sorted(by_representation.items())
            },
        },
        "records": records,
    }


def evaluate_on_policy_revision(
    output_root: Path,
    benchmark_root: Path,
    on_policy_data_root: Path,
    model_path: str,
    selector_evaluation: Mapping[str, Any],
    revision_adapter: Path,
) -> Mapping[str, Any]:
    from mlx_lm import load

    benchmark = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    data_freeze = json.loads((on_policy_data_root / "data-freeze.json").read_text(encoding="utf-8"))
    dossiers = tuple(build_dossier(task) for task in build_m35_suite("test", 30))
    store = ArtifactStore(output_root)
    first_artifact = store.get(selector_evaluation["predictions_digest"])["value"]
    first_by_id = {record["task_id"]: record["response"] for record in first_artifact}
    first_responses = tuple(first_by_id[dossier.task.task_id] for dossier in dossiers)
    model, tokenizer, config = load(
        model_path, adapter_path=str(revision_adapter), return_config=True
    )
    prompts = tuple(
        _chat_prompt(tokenizer, revision_prompt(dossier, response))
        for dossier, response in zip(dossiers, first_responses)
    )
    started = time.monotonic()
    revision_responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        prompts,
        batch_size=8,
        max_tokens=48,
        max_batch_tokens=12000,
    )
    result = aggregate_revisions(dossiers, first_responses, revision_responses)
    predictions_digest = store.put("on_policy_revision_predictions", result["records"])
    metrics = result["metrics"]
    gates = benchmark["revision_gates"]
    selector_assessment = json.loads(
        (output_root / "m35-selector-assessment.json").read_text(encoding="utf-8")
    )
    checks = {
        "oracle_selector_stage_recorded": "oracle_prerequisite_passed" in selector_assessment["checks"],
        "same_benchmark_freeze": (
            selector_evaluation["benchmark_freeze_id"]
            == data_freeze["benchmark_freeze_id"]
            == benchmark["freeze_id"]
        ),
        "zero_test_examples_in_revision_training": data_freeze["test_examples_used"] == 0,
        "two_step_semantic_accuracy": (
            metrics["two_step_semantic_accuracy"] >= gates["minimum_two_step_semantic_accuracy"]
        ),
        "semantic_gain": metrics["semantic_gain"] >= gates["minimum_gain"],
        "preserved_correct_accuracy": (
            metrics["preserved_correct_accuracy"] >= gates["minimum_preserved_correct_accuracy"]
        ),
        "exact_rate": metrics["two_step_exact_rate"] >= gates["minimum_exact_rate"],
    }
    payload = {
        "version": ON_POLICY_REVISION_VERSION,
        "benchmark_freeze_id": benchmark["freeze_id"],
        "on_policy_data_freeze_id": data_freeze["data_freeze_id"],
        "selector_evaluation_id": selector_evaluation["evaluation_id"],
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "revision_adapter_path": str(revision_adapter),
        "revision_adapter_sha256": hashlib.sha256(
            (revision_adapter / "adapters.safetensors").read_bytes()
        ).hexdigest(),
        "metrics": metrics,
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "claim_boundary": (
            "M35 on-policy revision is trained only on non-test mistakes and conservatively adopts "
            "a revision only when it satisfies all observed intervention evidence."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest(f"on-policy-revision-{evaluation_id}", manifest)
    return manifest
