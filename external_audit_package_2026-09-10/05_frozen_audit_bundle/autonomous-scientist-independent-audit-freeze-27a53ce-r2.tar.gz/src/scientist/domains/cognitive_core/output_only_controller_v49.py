from __future__ import annotations

import hashlib
import json
import random
import re
import time
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.contrast_experiment_v42 import (
    ContrastPair,
    _best_contrast_pair,
    aggregate_contrasts,
    contrast_prompt,
    pair_members,
)
from scientist.domains.cognitive_core.experiment_invention_v41 import (
    ExperimentTask,
    _canonical,
    _program_text,
    input_schema,
    parse_experiment,
)
from scientist.domains.cognitive_core.internal_core_v28 import (
    _batch_responses,
    _chat_prompt,
)
from scientist.domains.cognitive_core.model_controlled_tool_loop_v46 import (
    _run_condition,
    parse_action,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
    experiment_classes,
)


OUTPUT_ONLY_CONTROLLER_VERSION = "general-cognitive-output-only-controller-v49"
M49_SPLIT_SEEDS = {
    "train": 49037,
    "valid": 49061,
    "calibration": 49079,
    "test": 49109,
}
M49_REPRESENTATIONS = ("predicate", "causal")
M49_PER_REPRESENTATION = {
    "train": 24,
    "valid": 6,
    "calibration": 6,
    "test": 30,
}
M49_MINIMUM_EXCLUSIVE_FRACTION = 0.10
M49_PARENT_ADAPTER_SHA256 = (
    "001db1f2a4e10a8a118f0b9ebe929ef9c6faa93959aa148997376e600e11ce79"
)
M49_MODEL_SNAPSHOT = "8b403126fc14f14cfc99bb4cfa72ecbc129ea677"
M49_TURN_BUDGET = 4
_SELECT = re.compile(r"^\s*SELECT\s*:\s*(\d+)\s*$", re.IGNORECASE)
_REVISE = re.compile(r"^\s*REVISE\s*$", re.IGNORECASE)


def _source_tasks(
    split: str, per_representation: int, representations: Sequence[str]
) -> Tuple[Any, ...]:
    if split not in M49_SPLIT_SEEDS:
        raise ValueError("unknown M49 split")
    rng = random.Random(M49_SPLIT_SEEDS[split])
    return tuple(
        _build_task(f"m49_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )


def _experiment_task(source: Any) -> ExperimentTask | None:
    task = _m43_experiment_task(source)
    if task is None:
        return None
    return replace(
        task,
        task_id="m49-exp-"
        + content_digest(
            {
                "source": source.task_id,
                "scenario": task.scenario.scenario_id,
                "version": OUTPUT_ONLY_CONTROLLER_VERSION,
            }
        )[:20],
    )


@lru_cache(maxsize=None)
def _build_m49_pairs_cached(
    split: str,
    per_representation: int,
    representations: Tuple[str, ...],
) -> Tuple[ContrastPair, ...]:
    bases = tuple(
        task
        for source in _source_tasks(split, per_representation, representations)
        for task in (_experiment_task(source),)
        if task is not None
    )
    return tuple(
        pair
        for base in bases
        for pair in (
            _best_contrast_pair(
                base,
                version=OUTPUT_ONLY_CONTROLLER_VERSION,
                pair_prefix="m49-pair",
                minimum_exclusive_fraction=M49_MINIMUM_EXCLUSIVE_FRACTION,
            ),
        )
        if pair is not None
    )


def build_m49_pairs(
    split: str,
    per_representation: int | None = None,
    representations: Sequence[str] = M49_REPRESENTATIONS,
) -> Tuple[ContrastPair, ...]:
    if split not in M49_PER_REPRESENTATION:
        raise ValueError("unknown M49 split")
    count = (
        M49_PER_REPRESENTATION[split]
        if per_representation is None
        else int(per_representation)
    )
    return _build_m49_pairs_cached(split, count, tuple(representations))


def _history_lines(
    history: Sequence[Mapping[str, Any]], *, feedback: bool
) -> list[str]:
    lines = ["Execution history:"]
    if not history:
        lines.append("  none")
    for row in history:
        lines.append(f"  slot {row['slot']} experiment={json.dumps(row['experiment'])}")
        if feedback:
            lines.append(
                f"    c1_output={json.dumps(row['outputs'][0], sort_keys=True)}"
            )
            lines.append(
                f"    c2_output={json.dumps(row['outputs'][1], sort_keys=True)}"
            )
        else:
            lines.append("    candidate outputs withheld")
    return lines


def _task_lines(task: ExperimentTask) -> list[str]:
    observed = sorted({_canonical(value) for value in task.observed_inputs})
    lines = [
        f"Representation: {task.representation}",
        f"Valid experiment input: {input_schema(task.representation)}.",
        "Goal: find an executed experiment for which the two unresolved mechanisms produce different outputs.",
        "Unresolved executable candidate mechanisms:",
    ]
    for index, intervention in enumerate(task.frontier, 1):
        lines.append(f"  c{index}: {_program_text(intervention.program)}")
    lines.append("Observed inputs: " + json.dumps(observed))
    return lines


def controller_prompt(
    task: ExperimentTask,
    history: Sequence[Mapping[str, Any]],
    errors: Sequence[str] = (),
    *,
    feedback: bool = True,
    final_selection: bool = False,
) -> str:
    lines = _task_lines(task) + _history_lines(history, feedback=feedback)
    if errors:
        lines.append("Tool validation messages:")
        lines.extend(f"  {message}" for message in errors[-2:])
    lines.extend(
        (
            "Make the control decision yourself from the execution history.",
            "Do not invent an experiment in this response.",
        )
    )
    if final_selection:
        lines.extend(
            (
                "The proposal budget is exhausted.",
                "Return exactly: SELECT: <slot number>",
            )
        )
    else:
        lines.extend(
            (
                "If an executed slot achieves the goal, return exactly: SELECT: <slot number>",
                "If no executed slot achieves the goal, return exactly: REVISE",
            )
        )
    return "\n".join(lines)


def proposal_prompt(
    task: ExperimentTask,
    history: Sequence[Mapping[str, Any]],
    errors: Sequence[str] = (),
    *,
    feedback: bool = True,
) -> str:
    lines = _task_lines(task) + _history_lines(history, feedback=feedback)
    if errors:
        lines.append("Tool validation messages:")
        lines.extend(f"  {message}" for message in errors[-2:])
    lines.extend(
        (
            "Propose one different legal experiment that could achieve the goal.",
            "Do not select a slot in this response. Do not explain.",
            "Return exactly: EXPERIMENT: <JSON list>",
        )
    )
    return "\n".join(lines)


def parse_controller_action(
    response: str,
    history: Sequence[Mapping[str, Any]],
    *,
    final_selection: bool = False,
) -> Mapping[str, Any]:
    select = _SELECT.match(response)
    if select is not None:
        slot = int(select.group(1))
        valid = 1 <= slot <= len(history)
        return {
            "kind": "select",
            "parsed": True,
            "valid": valid,
            "slot": slot,
            "experiment": history[slot - 1]["experiment"] if valid else None,
            "response": response,
        }
    if _REVISE.match(response) is not None:
        return {
            "kind": "revise",
            "parsed": True,
            "valid": not final_selection,
            "slot": None,
            "experiment": None,
            "response": response,
        }
    return {
        "kind": "invalid",
        "parsed": False,
        "valid": False,
        "slot": None,
        "experiment": None,
        "response": response,
    }


def _initial_state(task: ExperimentTask) -> Dict[str, Any]:
    return {
        "task_id": task.task_id,
        "representation": task.representation,
        "history": [],
        "errors": [],
        "actions": [],
        "selected_slot": None,
        "selected_experiment": None,
        "final_response": "",
        "needs_proposal": True,
    }


def _outputs_for_mode(
    own: ExperimentTask,
    sibling: ExperimentTask,
    experiment: Any,
    mode: str,
) -> Tuple[Any, ...]:
    source = sibling if mode == "counterfactual_output_swap" else own
    return raw_candidate_outputs(source, experiment)


def run_controller_condition(
    pairs: Sequence[ContrastPair],
    model: Any,
    tokenizer: Any,
    *,
    mode: str,
    contract: Mapping[str, Any],
) -> Tuple[list[Mapping[str, Any]], float]:
    if mode not in (
        "correct_outputs",
        "outputs_withheld",
        "counterfactual_output_swap",
    ):
        raise ValueError("unknown M49 controller mode")
    tasks = pair_members(pairs)
    by_task = {
        pair.left.task_id: (pair.left, pair.right) for pair in pairs
    } | {pair.right.task_id: (pair.right, pair.left) for pair in pairs}
    states = [_initial_state(task) for task in tasks]
    feedback = mode != "outputs_withheld"
    peak_memory = 0.0
    turn_budget = int(contract["proposal_turn_budget"])
    for turn in range(1, turn_budget + 1):
        proposing = [
            index
            for index, state in enumerate(states)
            if state["selected_slot"] is None and state["needs_proposal"]
        ]
        if proposing:
            prompts = tuple(
                _chat_prompt(
                    tokenizer,
                    proposal_prompt(
                        tasks[index],
                        states[index]["history"],
                        states[index]["errors"],
                        feedback=feedback,
                    ),
                )
                for index in proposing
            )
            responses, peak = _batch_responses(
                model,
                tokenizer,
                prompts,
                batch_size=int(contract["batch_size"]),
                max_tokens=int(contract["proposal_max_tokens"]),
                max_batch_tokens=12000,
            )
            peak_memory = max(peak_memory, peak)
            for index, response in zip(proposing, responses):
                task = tasks[index]
                own, sibling = by_task[task.task_id]
                state = states[index]
                action = dict(parse_action(response, task, state["history"]))
                action.update({"turn": turn, "stage": "proposal"})
                state["actions"].append(action)
                if action["kind"] == "propose" and action["valid"]:
                    outputs = _outputs_for_mode(
                        own, sibling, action["experiment"], mode
                    )
                    state["history"].append(
                        {
                            "slot": len(state["history"]) + 1,
                            "turn": turn,
                            "experiment": action["experiment"],
                            "outputs": list(outputs),
                            "response": response,
                        }
                    )
                    state["needs_proposal"] = False
                else:
                    state["errors"].append(
                        f"turn {turn} proposal: invalid, observed, duplicate, or out of schema"
                    )
        deciding = [
            index
            for index, state in enumerate(states)
            if state["selected_slot"] is None
            and not state["needs_proposal"]
            and state["history"]
        ]
        if deciding:
            prompts = tuple(
                _chat_prompt(
                    tokenizer,
                    controller_prompt(
                        tasks[index],
                        states[index]["history"],
                        states[index]["errors"],
                        feedback=feedback,
                    ),
                )
                for index in deciding
            )
            responses, peak = _batch_responses(
                model,
                tokenizer,
                prompts,
                batch_size=int(contract["batch_size"]),
                max_tokens=int(contract["controller_max_tokens"]),
                max_batch_tokens=12000,
            )
            peak_memory = max(peak_memory, peak)
            for index, response in zip(deciding, responses):
                state = states[index]
                action = dict(parse_controller_action(response, state["history"]))
                action.update(
                    {
                        "turn": turn,
                        "stage": "controller",
                        "history_had_evidence": any(
                            _canonical(row["outputs"][0])
                            != _canonical(row["outputs"][1])
                            for row in state["history"]
                        )
                        if feedback
                        else None,
                    }
                )
                state["actions"].append(action)
                if action["kind"] == "select" and action["valid"]:
                    state["selected_slot"] = action["slot"]
                    state["selected_experiment"] = action["experiment"]
                    state["final_response"] = response
                elif action["kind"] == "revise" and action["valid"]:
                    state["needs_proposal"] = True
                else:
                    state["errors"].append(
                        f"turn {turn} controller: invalid action or unavailable selection"
                    )
    remaining = [
        index
        for index, state in enumerate(states)
        if state["selected_slot"] is None and state["history"]
    ]
    if remaining:
        prompts = tuple(
            _chat_prompt(
                tokenizer,
                controller_prompt(
                    tasks[index],
                    states[index]["history"],
                    states[index]["errors"],
                    feedback=feedback,
                    final_selection=True,
                ),
            )
            for index in remaining
        )
        responses, peak = _batch_responses(
            model,
            tokenizer,
            prompts,
            batch_size=int(contract["batch_size"]),
            max_tokens=int(contract["final_selection_max_tokens"]),
            max_batch_tokens=12000,
        )
        peak_memory = max(peak_memory, peak)
        for index, response in zip(remaining, responses):
            state = states[index]
            action = dict(
                parse_controller_action(
                    response, state["history"], final_selection=True
                )
            )
            action.update(
                {
                    "turn": "forced_final_selection",
                    "stage": "controller",
                    "history_had_evidence": any(
                        _canonical(row["outputs"][0])
                        != _canonical(row["outputs"][1])
                        for row in state["history"]
                    )
                    if feedback
                    else None,
                }
            )
            state["actions"].append(action)
            if action["kind"] == "select" and action["valid"]:
                state["selected_slot"] = action["slot"]
                state["selected_experiment"] = action["experiment"]
                state["final_response"] = response
    return [
        {key: value for key, value in state.items() if key != "needs_proposal"}
        for state in states
    ], peak_memory


def controller_interaction_metrics(
    pairs: Sequence[ContrastPair], states: Sequence[Mapping[str, Any]]
) -> Mapping[str, Any]:
    tasks = pair_members(pairs)
    if len(tasks) != len(states):
        raise ValueError("M49 states do not align")
    rows = []
    for task, state in zip(tasks, states):
        history = state["history"]
        selected_slot = state["selected_slot"]
        selected = (
            history[selected_slot - 1]
            if isinstance(selected_slot, int) and 1 <= selected_slot <= len(history)
            else None
        )
        evidence = [
            row
            for row in history
            if _canonical(row["outputs"][0]) != _canonical(row["outputs"][1])
        ]
        decisions = [
            action
            for action in state["actions"]
            if action["stage"] == "controller"
            and action["turn"] != "forced_final_selection"
        ]
        evaluable = [
            action
            for action in decisions
            if action["history_had_evidence"] is not None
        ]
        correct_decisions = [
            action
            for action in evaluable
            if (
                action["history_had_evidence"]
                and action["kind"] == "select"
                and action["valid"]
            )
            or (
                not action["history_had_evidence"]
                and action["kind"] == "revise"
                and action["valid"]
            )
        ]
        evidence_decisions = [
            action for action in evaluable if action["history_had_evidence"]
        ]
        null_decisions = [
            action for action in evaluable if not action["history_had_evidence"]
        ]
        rows.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "action_count": len(state["actions"]),
                "parsed_action_count": sum(
                    bool(action["parsed"]) for action in state["actions"]
                ),
                "valid_action_count": sum(
                    bool(action["valid"]) for action in state["actions"]
                ),
                "selection_completed": selected is not None,
                "selected_evidence": bool(
                    selected
                    and _canonical(selected["outputs"][0])
                    != _canonical(selected["outputs"][1])
                ),
                "informative_history_available": bool(evidence),
                "selected_available_evidence": bool(
                    not evidence
                    or (
                        selected
                        and _canonical(selected["outputs"][0])
                        != _canonical(selected["outputs"][1])
                    )
                ),
                "early_stop": bool(
                    selected
                    and any(
                        action["kind"] == "select"
                        and action["valid"]
                        and action["turn"] != "forced_final_selection"
                        for action in state["actions"]
                    )
                ),
                "decision_count": len(evaluable),
                "correct_decision_count": len(correct_decisions),
                "evidence_decision_count": len(evidence_decisions),
                "select_after_evidence_count": sum(
                    action["kind"] == "select" and action["valid"]
                    for action in evidence_decisions
                ),
                "null_decision_count": len(null_decisions),
                "revise_after_null_count": sum(
                    action["kind"] == "revise" and action["valid"]
                    for action in null_decisions
                ),
            }
        )

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        action_total = sum(int(row["action_count"]) for row in items)
        decision_total = sum(int(row["decision_count"]) for row in items)
        evidence_total = sum(int(row["evidence_decision_count"]) for row in items)
        null_total = sum(int(row["null_decision_count"]) for row in items)
        evidence_tasks = [row for row in items if row["informative_history_available"]]
        return {
            "action_parse_rate": sum(
                int(row["parsed_action_count"]) for row in items
            )
            / max(action_total, 1),
            "valid_action_rate": sum(
                int(row["valid_action_count"]) for row in items
            )
            / max(action_total, 1),
            "selection_completion_rate": sum(
                bool(row["selection_completed"]) for row in items
            )
            / max(len(items), 1),
            "selected_evidence_rate": sum(
                bool(row["selected_evidence"]) for row in items
            )
            / max(len(items), 1),
            "available_evidence_selection_rate": sum(
                bool(row["selected_available_evidence"]) for row in evidence_tasks
            )
            / max(len(evidence_tasks), 1),
            "early_stop_rate": sum(bool(row["early_stop"]) for row in items)
            / max(len(items), 1),
            "mean_action_count": action_total / max(len(items), 1),
            "controller_decision_accuracy": sum(
                int(row["correct_decision_count"]) for row in items
            )
            / max(decision_total, 1),
            "select_after_evidence_rate": sum(
                int(row["select_after_evidence_count"]) for row in items
            )
            / max(evidence_total, 1),
            "revise_after_null_rate": sum(
                int(row["revise_after_null_count"]) for row in items
            )
            / max(null_total, 1),
        }

    return {
        **summarize(rows),
        "by_representation": {
            representation: summarize(
                [row for row in rows if row["representation"] == representation]
            )
            for representation in M49_REPRESENTATIONS
        },
        "records": rows,
    }


def controller_autonomous_metrics(
    pairs: Sequence[ContrastPair],
    states: Mapping[str, Sequence[Mapping[str, Any]]],
) -> Mapping[str, Any]:
    results = {}
    interactions = {}
    for mode, condition_states in states.items():
        results[mode] = aggregate_contrasts(
            mode,
            pairs,
            [state["selected_experiment"] for state in condition_states],
            [state["final_response"] for state in condition_states],
        )
        interaction = controller_interaction_metrics(pairs, condition_states)
        interactions[mode] = {
            key: value for key, value in interaction.items() if key != "records"
        }
    correct = results["correct_outputs"]["metrics"]
    withheld = results["outputs_withheld"]["metrics"]
    swapped = results["counterfactual_output_swap"]["metrics"]
    return {
        "metrics": {mode: result["metrics"] for mode, result in results.items()},
        "interaction_metrics": interactions,
        "information_gain_over_withheld": correct[
            "mean_normalized_information_gain"
        ]
        - withheld["mean_normalized_information_gain"],
        "assignment_gain_over_withheld": correct["correct_assignment_rate"]
        - withheld["correct_assignment_rate"],
        "advantage_gap_over_output_swap": correct["mean_assignment_advantage"]
        - swapped["mean_assignment_advantage"],
    }


def _history_variant(
    prefix: Sequence[Mapping[str, Any]],
    evidence_outputs: Sequence[Any],
    evidence_slot: int | None,
) -> Tuple[Mapping[str, Any], ...]:
    result = []
    for row in prefix:
        equal_outputs = [row["outputs"][0], row["outputs"][0]]
        outputs = (
            list(evidence_outputs)
            if evidence_slot is not None and int(row["slot"]) == evidence_slot
            else equal_outputs
        )
        result.append({**row, "outputs": outputs})
    return tuple(result)


def controller_rows_from_rollouts(
    pairs: Sequence[ContrastPair],
    states: Sequence[Mapping[str, Any]],
    *,
    prefix_limit: int,
) -> Tuple[Mapping[str, Any], ...]:
    tasks = pair_members(pairs)
    if len(tasks) != len(states):
        raise ValueError("on-policy rollouts do not align with M49 tasks")
    by_task = {
        pair.left.task_id: (pair, pair.left, pair.right) for pair in pairs
    } | {pair.right.task_id: (pair, pair.right, pair.left) for pair in pairs}
    rows = []
    for task, state in zip(tasks, states):
        pair, own, sibling = by_task[task.task_id]
        classes = experiment_classes(own, sibling)
        targets = sorted(classes["frontier_specific"], key=_canonical)
        if not targets:
            continue
        evidence_outputs = raw_candidate_outputs(own, targets[0])
        if _canonical(evidence_outputs[0]) == _canonical(evidence_outputs[1]):
            raise ValueError("M49 diagnostic evidence output is not unequal")
        history = tuple(state["history"][:prefix_limit])
        for length in range(1, len(history) + 1):
            prefix = history[:length]
            null_history = _history_variant(prefix, evidence_outputs, None)
            for slot in range(1, length + 1):
                evidence_history = _history_variant(prefix, evidence_outputs, slot)
                pair_id = content_digest(
                    {
                        "task": task.task_id,
                        "experiments": [row["experiment"] for row in prefix],
                        "slot": slot,
                        "version": OUTPUT_ONLY_CONTROLLER_VERSION,
                    }
                )[:24]
                common = {
                    "intervention_pair_id": pair_id,
                    "pair_id": pair.pair_id,
                    "task_id": task.task_id,
                    "sibling_task_id": sibling.task_id,
                    "representation": task.representation,
                    "evidence_slot": slot,
                    "prefix_length": length,
                    "on_policy_source": True,
                }
                rows.extend(
                    (
                        {
                            "prompt": controller_prompt(own, null_history),
                            "completion": "REVISE",
                            "metadata": {
                                **common,
                                "variant": "output_null",
                                "history": list(null_history),
                            },
                        },
                        {
                            "prompt": controller_prompt(own, evidence_history),
                            "completion": f"SELECT: {slot}",
                            "metadata": {
                                **common,
                                "variant": "output_evidence",
                                "history": list(evidence_history),
                            },
                        },
                    )
                )
    return tuple(rows)


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def _write_json(path: Path, value: Mapping[str, Any]) -> str:
    payload = json.dumps(value, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def prepare_m49_protocol(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    counts = {
        split: {
            "pairs": len(build_m49_pairs(split)),
            "tasks": len(build_m49_pairs(split)) * 2,
        }
        for split in M49_SPLIT_SEEDS
    }
    payload = {
        "version": OUTPUT_ONLY_CONTROLLER_VERSION,
        "parent_version": "general-cognitive-sequential-policy-learning-v47",
        "split_seeds": M49_SPLIT_SEEDS,
        "representations": list(M49_REPRESENTATIONS),
        "per_representation_source_count": M49_PER_REPRESENTATION,
        "counts": counts,
        "frozen_model": {
            "snapshot": M49_MODEL_SNAPSHOT,
            "parent_adapter_sha256": M49_PARENT_ADAPTER_SHA256,
            "parent_adapter_source": "m47_validation_selected_checkpoint_160",
        },
        "on_policy_collection_contract": {
            "splits": ["train", "valid"],
            "policy": "frozen_m47_parent",
            "condition": "correct_feedback",
            "proposal_turn_budget": 8,
            "action_max_tokens": 24,
            "forced_final_selection_max_tokens": 8,
            "maximum_total_output_tokens_per_task": 200,
            "batch_size": 8,
            "prefix_limit": 3,
            "calibration_and_test_unavailable": True,
        },
        "output_only_contract": {
            "fixed_across_pair": [
                "task",
                "candidate_mechanisms",
                "observed_inputs",
                "tested_experiments",
                "history_length",
                "evidence_slot",
            ],
            "only_varied_field": "raw_c1_c2_outputs",
            "null_outputs_prefer": "REVISE",
            "unequal_outputs_prefer": "SELECT_evidence_slot",
            "controller_and_proposer_are_same_model": True,
            "external_decision_or_selection": False,
        },
        "training_recipe": {
            "objective": "balanced_output_only_controller_sft",
            "initialization": "m47_selected_checkpoint_160",
            "lora_layers": 8,
            "lora_rank": 8,
            "lora_scale": 20.0,
            "iterations": 120,
            "learning_rate": 1e-5,
            "gradient_accumulation_steps": 4,
            "checkpoint_interval": 40,
            "max_sequence_length": 1024,
            "seed": 49,
            "checkpoint_selection": "lexicographic_output_causality_micro_gate",
        },
        "micro_gate_contract": {
            "candidates": [0, 40, 80, 120],
            "split": "valid",
            "minimum_parse_rate": 0.98,
            "minimum_valid_rate": 0.98,
            "minimum_null_revision_accuracy": 0.85,
            "minimum_evidence_selection_accuracy": 0.85,
            "minimum_paired_flip_accuracy": 0.80,
            "autonomous_validation_only_after_exact_pair_gate": True,
            "calibration_only_after_autonomous_gate": True,
        },
        "autonomous_validation_contract": {
            "conditions": [
                "correct_outputs",
                "outputs_withheld",
                "counterfactual_output_swap",
            ],
            "minimum_action_parse_rate": 0.95,
            "minimum_valid_action_rate": 0.80,
            "minimum_selection_completion_rate": 0.90,
            "minimum_selected_evidence_rate": 0.70,
            "minimum_controller_decision_accuracy": 0.75,
            "minimum_information_gain_over_withheld": 0.05,
            "minimum_advantage_gap_over_output_swap": 0.20,
            "score_formula": (
                "information + correct_assignment + information_over_withheld + "
                "advantage_over_output_swap + valid_action_rate + controller_decision_accuracy"
            ),
            "eligibility_precedes_score": True,
        },
        "interaction_contract": {
            "proposal_turn_budget": M49_TURN_BUDGET,
            "proposal_max_tokens": 24,
            "controller_max_tokens": 8,
            "final_selection_max_tokens": 8,
            "maximum_total_output_tokens_per_task": 136,
            "batch_size": 8,
            "tool_returns": "raw_c1_and_c2_outputs_only",
            "candidate_descriptions_fixed_across_conditions": True,
            "output_swap_changes_only_tool_outputs": True,
            "external_fallback_selection": False,
            "no_test_time_parameter_updates": True,
        },
        "claim_boundary": (
            "M49 tests whether a frozen 1.5B model can internalize the evidence-to-control decision "
            "under exact output-only interventions and then use that controller in autonomous "
            "propose-execute trajectories. It does not establish general reasoning parity, transfer "
            "to natural scientific tasks, or 70B-equivalent capability."
        ),
    }
    protocol = {**payload, "protocol_freeze_id": content_digest(payload)}
    _write_json(output / "protocol-freeze.json", protocol)
    return protocol


def finalize_m49_benchmark(output: Path) -> Mapping[str, Any]:
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    data_dir = output / "controller"
    hashes: Dict[str, str] = {}
    counts: Dict[str, int] = {}
    for split in ("train", "valid"):
        rollout_path = output / f"on-policy-{split}.json"
        rollout = json.loads(rollout_path.read_text())
        if rollout["protocol_freeze_id"] != protocol["protocol_freeze_id"]:
            raise ValueError("M49 rollout does not match protocol freeze")
        hashes[f"on_policy_{split}"] = hashlib.sha256(
            rollout_path.read_bytes()
        ).hexdigest()
        rows = controller_rows_from_rollouts(
            build_m49_pairs(split),
            rollout["states"],
            prefix_limit=int(
                protocol["on_policy_collection_contract"]["prefix_limit"]
            ),
        )
        digest, count = _write_jsonl(data_dir / f"{split}.jsonl", rows)
        hashes[f"controller_{split}"] = digest
        counts[f"{split}_controller_records"] = count
        counts[f"{split}_intervention_pairs"] = count // 2
    for split in ("calibration", "test"):
        public_hash, _ = _write_jsonl(
            output / f"{split}-public.jsonl",
            (
                {
                    "pair_id": pair.pair_id,
                    "representation": pair.representation,
                    "left_task_id": pair.left.task_id,
                    "right_task_id": pair.right.task_id,
                }
                for pair in build_m49_pairs(split)
            ),
        )
        authority_hash, _ = _write_jsonl(
            output / f"{split}-authority.jsonl",
            (
                {
                    "pair_id": pair.pair_id,
                    "authority_program": dict(pair.left.source.authority),
                    "left_frontier": [item.key for item in pair.left.frontier],
                    "right_frontier": [item.key for item in pair.right.frontier],
                }
                for pair in build_m49_pairs(split)
            ),
        )
        hashes[f"{split}_public"] = public_hash
        hashes[f"{split}_authority"] = authority_hash
    gates = {
        "minimum_action_parse_rate": 0.95,
        "minimum_valid_action_rate": 0.80,
        "minimum_selection_completion_rate": 0.90,
        "minimum_selected_evidence_rate": 0.75,
        "minimum_available_evidence_selection_rate": 0.90,
        "minimum_controller_decision_accuracy": 0.80,
        "minimum_select_after_evidence_rate": 0.85,
        "minimum_revise_after_null_rate": 0.70,
        "minimum_predicate_information": 0.65,
        "minimum_causal_information": 0.80,
        "minimum_overall_correct_assignment": 0.55,
        "minimum_information_gain_over_direct": 0.05,
        "minimum_information_gain_over_withheld": 0.10,
        "minimum_assignment_gain_over_withheld": 0.10,
        "minimum_advantage_gap_over_output_swap": 0.40,
    }
    payload = {
        **protocol,
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "hashes": hashes,
        "controller_counts": counts,
        "calibration_readiness_gates": gates,
        "sealed_test_gates": gates,
        "sealed_test_policy": (
            "test_is_opened_only_if_micro_gate_and_all_calibration_gates_pass"
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    _write_json(output / "benchmark-freeze.json", freeze)
    verification = verify_m49_benchmark(output)
    _write_json(output / "benchmark-verification.json", verification)
    return freeze


def verify_m49_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    paths = {
        **{
            f"on_policy_{split}": output / f"on-policy-{split}.json"
            for split in ("train", "valid")
        },
        **{
            f"controller_{split}": output / f"controller/{split}.jsonl"
            for split in ("train", "valid")
        },
        **{
            f"{split}_{kind}": output / f"{split}-{kind}.jsonl"
            for split in ("calibration", "test")
            for kind in ("public", "authority")
        },
    }
    hashes = {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in paths.items()
    }
    protocol_payload = {
        key: value for key, value in protocol.items() if key != "protocol_freeze_id"
    }
    freeze_payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    rows_reproduce = True
    exact_pairs = True
    for split in ("train", "valid"):
        rollout = json.loads(paths[f"on_policy_{split}"].read_text())
        regenerated = controller_rows_from_rollouts(
            build_m49_pairs(split),
            rollout["states"],
            prefix_limit=int(
                freeze["on_policy_collection_contract"]["prefix_limit"]
            ),
        )
        stored = tuple(
            json.loads(line)
            for line in paths[f"controller_{split}"].read_text().splitlines()
            if line
        )
        rows_reproduce = rows_reproduce and stored == regenerated
        groups: Dict[str, list[Mapping[str, Any]]] = {}
        for row in stored:
            groups.setdefault(row["metadata"]["intervention_pair_id"], []).append(row)
        for group in groups.values():
            if len(group) != 2:
                exact_pairs = False
                continue
            null = next(row for row in group if row["metadata"]["variant"] == "output_null")
            evidence = next(
                row for row in group if row["metadata"]["variant"] == "output_evidence"
            )
            def remove_outputs(prompt: str) -> str:
                return "\n".join(
                    line
                    for line in prompt.splitlines()
                    if "c1_output=" not in line and "c2_output=" not in line
                )
            exact_pairs = exact_pairs and (
                remove_outputs(null["prompt"]) == remove_outputs(evidence["prompt"])
                and null["completion"] == "REVISE"
                and evidence["completion"]
                == f"SELECT: {evidence['metadata']['evidence_slot']}"
            )
    split_ids = {
        split: {pair.pair_id for pair in build_m49_pairs(split)}
        for split in M49_SPLIT_SEEDS
    }
    disjoint = all(
        not (split_ids[left] & split_ids[right])
        for index, left in enumerate(M49_SPLIT_SEEDS)
        for right in tuple(M49_SPLIT_SEEDS)[index + 1 :]
    )
    checks = {
        "protocol_id_is_content_derived": content_digest(protocol_payload)
        == protocol["protocol_freeze_id"],
        "freeze_id_is_content_derived": content_digest(freeze_payload)
        == freeze["freeze_id"],
        "all_hashes_match": hashes == freeze["hashes"],
        "controller_rows_reproduce_from_on_policy_rollouts": rows_reproduce,
        "intervention_pairs_change_only_raw_outputs": exact_pairs,
        "all_splits_are_disjoint": disjoint,
        "calibration_and_test_absent_from_training": not (
            output / "controller/calibration.jsonl"
        ).exists()
        and not (output / "controller/test.jsonl").exists(),
        "candidate_descriptions_are_fixed_across_conditions": freeze[
            "interaction_contract"
        ]["candidate_descriptions_fixed_across_conditions"],
        "eligibility_precedes_scalar_score": freeze[
            "autonomous_validation_contract"
        ]["eligibility_precedes_score"],
        "sealed_gates_are_identical": freeze["calibration_readiness_gates"]
        == freeze["sealed_test_gates"],
    }
    return {
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def evaluate_m49_split(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    adapter_path: Path,
    *,
    split: str,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if split not in ("calibration", "test"):
        raise ValueError("M49 split must be calibration or test")
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text())
    selection = json.loads((output_root / "micro-gate-selection.json").read_text())
    if not selection["calibration_authorized"]:
        raise RuntimeError("M49 calibration is not authorized by the micro-gate")
    if split == "test":
        assessment_path = output_root / "m49-calibration-assessment.json"
        if not assessment_path.exists() or not json.loads(
            assessment_path.read_text()
        )["passed"]:
            raise RuntimeError("sealed M49 test cannot open before calibration passes")
    if not model_path.rstrip("/").endswith(freeze["frozen_model"]["snapshot"]):
        raise ValueError("model path does not match frozen M49 snapshot")
    adapter_hash = hashlib.sha256(
        (adapter_path / "adapters.safetensors").read_bytes()
    ).hexdigest()
    if adapter_hash != selection["selected_adapter_sha256"]:
        raise ValueError("adapter does not match frozen M49 micro-gate selection")
    pairs = build_m49_pairs(split)
    model, tokenizer, config = load(
        model_path, adapter_path=str(adapter_path), return_config=True
    )
    started = time.monotonic()
    states = {}
    peak_memory = 0.0
    for mode in freeze["autonomous_validation_contract"]["conditions"]:
        condition_states, peak = run_controller_condition(
            pairs,
            model,
            tokenizer,
            mode=mode,
            contract=freeze["interaction_contract"],
        )
        states[mode] = condition_states
        peak_memory = max(peak_memory, peak)
    autonomous = controller_autonomous_metrics(pairs, states)
    tasks = pair_members(pairs)
    direct_responses, direct_peak = _batch_responses(
        model,
        tokenizer,
        tuple(
            _chat_prompt(tokenizer, contrast_prompt(task, dossier=True))
            for task in tasks
        ),
        batch_size=int(freeze["interaction_contract"]["batch_size"]),
        max_tokens=40,
        max_batch_tokens=12000,
    )
    peak_memory = max(peak_memory, direct_peak)
    direct = aggregate_contrasts(
        "direct_correct",
        pairs,
        [parse_experiment(response) for response in direct_responses],
        direct_responses,
    )
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "output_only_controller_predictions",
        {"states": states, "direct_responses": list(direct_responses)},
    )
    metrics = {"direct_correct": direct["metrics"], **autonomous["metrics"]}
    payload = {
        "version": OUTPUT_ONLY_CONTROLLER_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "split": split,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path),
        "adapter_weights_sha256": adapter_hash,
        "micro_gate_selection_id": selection["selection_id"],
        "metrics": metrics,
        "interaction_metrics": autonomous["interaction_metrics"],
        "information_gain_over_withheld": autonomous[
            "information_gain_over_withheld"
        ],
        "assignment_gain_over_withheld": autonomous[
            "assignment_gain_over_withheld"
        ],
        "advantage_gap_over_output_swap": autonomous[
            "advantage_gap_over_output_swap"
        ],
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "interaction_contract": freeze["interaction_contract"],
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(
        f"output-only-controller-{split}-{manifest['evaluation_id']}", manifest
    )
    return manifest


def assess_m49_split(
    evaluation: Mapping[str, Any], benchmark_root: Path
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text())
    split = str(evaluation["split"])
    gates = (
        freeze["calibration_readiness_gates"]
        if split == "calibration"
        else freeze["sealed_test_gates"]
    )
    metrics = evaluation["metrics"]
    correct = metrics["correct_outputs"]
    direct = metrics["direct_correct"]
    loop = evaluation["interaction_metrics"]["correct_outputs"]
    checks = {
        "same_benchmark_freeze": evaluation["benchmark_freeze_id"]
        == freeze["freeze_id"],
        "fixed_output_only_contract": evaluation["interaction_contract"]
        == freeze["interaction_contract"],
        "action_parse_rate": loop["action_parse_rate"]
        >= gates["minimum_action_parse_rate"],
        "valid_action_rate": loop["valid_action_rate"]
        >= gates["minimum_valid_action_rate"],
        "selection_completion_rate": loop["selection_completion_rate"]
        >= gates["minimum_selection_completion_rate"],
        "selected_evidence_rate": loop["selected_evidence_rate"]
        >= gates["minimum_selected_evidence_rate"],
        "available_evidence_selection_rate": loop[
            "available_evidence_selection_rate"
        ]
        >= gates["minimum_available_evidence_selection_rate"],
        "controller_decision_accuracy": loop["controller_decision_accuracy"]
        >= gates["minimum_controller_decision_accuracy"],
        "select_after_evidence_rate": loop["select_after_evidence_rate"]
        >= gates["minimum_select_after_evidence_rate"],
        "revise_after_null_rate": loop["revise_after_null_rate"]
        >= gates["minimum_revise_after_null_rate"],
        "predicate_information": correct["by_representation"]["predicate"][
            "mean_normalized_information_gain"
        ]
        >= gates["minimum_predicate_information"],
        "causal_information": correct["by_representation"]["causal"][
            "mean_normalized_information_gain"
        ]
        >= gates["minimum_causal_information"],
        "overall_correct_assignment": correct["correct_assignment_rate"]
        >= gates["minimum_overall_correct_assignment"],
        "information_gain_over_direct": correct[
            "mean_normalized_information_gain"
        ]
        - direct["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_direct"],
        "information_gain_over_withheld": evaluation[
            "information_gain_over_withheld"
        ]
        >= gates["minimum_information_gain_over_withheld"],
        "assignment_gain_over_withheld": evaluation[
            "assignment_gain_over_withheld"
        ]
        >= gates["minimum_assignment_gain_over_withheld"],
        "advantage_gap_over_output_swap": evaluation[
            "advantage_gap_over_output_swap"
        ]
        >= gates["minimum_advantage_gap_over_output_swap"],
    }
    payload = {
        "version": OUTPUT_ONLY_CONTROLLER_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "split": split,
        "evaluation_id": evaluation["evaluation_id"],
        "metrics": metrics,
        "interaction_metrics": evaluation["interaction_metrics"],
        "deltas": {
            "information_gain_over_direct": correct[
                "mean_normalized_information_gain"
            ]
            - direct["mean_normalized_information_gain"],
            "information_gain_over_withheld": evaluation[
                "information_gain_over_withheld"
            ],
            "assignment_gain_over_withheld": evaluation[
                "assignment_gain_over_withheld"
            ],
            "advantage_gap_over_output_swap": evaluation[
                "advantage_gap_over_output_swap"
            ],
        },
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
        "sealed_test_authorized": split == "calibration" and all(checks.values()),
        "claim_boundary": freeze["claim_boundary"],
    }
    return {**payload, "assessment_id": content_digest(payload)}
