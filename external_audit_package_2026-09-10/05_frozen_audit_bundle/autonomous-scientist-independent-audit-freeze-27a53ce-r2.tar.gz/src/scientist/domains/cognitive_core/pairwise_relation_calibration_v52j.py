from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_MODEL_SNAPSHOT,
)
from scientist.domains.cognitive_core.counterfactual_semantic_binding_v52h import (
    _family as _m52h_family,
)
from scientist.domains.cognitive_core.latent_state_validity_v52g import _state
from scientist.domains.cognitive_core.semantic_relation_competence_v52i import (
    M52I_FAMILIES_BY_SPLIT,
    M52I_VARIANTS,
    relation_metrics,
    semantic_relation_prompt,
)


PAIRWISE_RELATION_CALIBRATION_VERSION = (
    "general-cognitive-pairwise-relation-calibration-v52j"
)
M52J_SEED = 52911
M52J_SPLITS = ("train", "valid", "confirmation")
M52J_M52I_AUDIT_ID = (
    "e27ff5c0c8dbacbb426ef2bc1767f73cb9d178a119c9861b800b105027cee1fc"
)


M52J_NEW_FAMILIES: Mapping[str, Tuple[Mapping[str, str], ...]] = {
    "memory_management": (
        _state(
            "manual_ownership",
            "Memory is now released explicitly by the component that owns each allocation.",
            "Program code manually frees every object according to ownership rules.",
            "The conclusion presupposes explicit owner-managed memory release.",
            "This evidence assumes allocation owners manually reclaim their objects.",
        ),
        _state(
            "tracing_collection",
            "Memory is now reclaimed by tracing objects reachable from live roots.",
            "A collector periodically discovers unreachable objects by graph traversal.",
            "The conclusion presupposes tracing garbage collection from live roots.",
            "This evidence assumes reachability traversal determines which objects survive.",
        ),
        _state(
            "reference_counting",
            "Memory is now reclaimed when an object's reference count reaches zero.",
            "Each object tracks incoming references and is freed after the last disappears.",
            "The conclusion presupposes reference-counted memory reclamation.",
            "This evidence assumes objects are reclaimed when their reference counters vanish.",
        ),
        _state(
            "region_allocation",
            "Memory is now allocated into regions that are reclaimed all at once.",
            "Objects share an arena whose entire lifetime ends in one bulk operation.",
            "The conclusion presupposes region-based bulk memory reclamation.",
            "This evidence assumes whole arenas, rather than individual objects, are freed.",
        ),
    ),
    "consistency_requirement": (
        _state(
            "linearizable",
            "Operations must now appear atomic in one real-time-consistent global order.",
            "Every completed operation precedes later operations in a single observable order.",
            "The conclusion presupposes linearizable real-time consistency.",
            "This evidence assumes one atomic order respects the timing of completed operations.",
        ),
        _state(
            "sequential_consistency",
            "Operations must now fit one global order that preserves each client's program order.",
            "All clients agree on an interleaving, though it need not respect real time.",
            "The conclusion presupposes sequential consistency without real-time ordering.",
            "This evidence assumes one shared interleaving preserves local program orders.",
        ),
        _state(
            "causal_consistency",
            "Operations must now preserve causal dependencies while concurrent writes may differ in order.",
            "All observers agree on cause-before-effect but can order unrelated events differently.",
            "The conclusion presupposes causally consistent observation order.",
            "This evidence assumes dependencies are ordered while concurrent events may diverge.",
        ),
        _state(
            "eventual_consistency",
            "Replicas now need only converge after updates stop, without immediate ordering guarantees.",
            "Temporary disagreement is allowed provided all replicas eventually reach the same state.",
            "The conclusion presupposes eventual replica convergence.",
            "This evidence assumes replicas may diverge temporarily but converge in the absence of updates.",
        ),
    ),
    "scheduling_objective": (
        _state(
            "throughput",
            "Scheduling now prioritizes the total number of completed jobs per unit time.",
            "The main objective is maximizing aggregate completion rate.",
            "The conclusion presupposes throughput-maximizing scheduling.",
            "This evidence assumes total completed work per time unit is the primary objective.",
        ),
        _state(
            "tail_latency",
            "Scheduling now prioritizes reducing the slowest high-percentile response times.",
            "The main objective is controlling extreme request delay rather than the mean.",
            "The conclusion presupposes tail-latency-minimizing scheduling.",
            "This evidence assumes high-percentile delay is the primary objective.",
        ),
        _state(
            "fairness",
            "Scheduling now prioritizes equitable resource shares across competing clients.",
            "The main objective is preventing any client from receiving a systematically poor share.",
            "The conclusion presupposes fairness-oriented scheduling.",
            "This evidence assumes equitable allocation across clients is the primary objective.",
        ),
        _state(
            "deadline",
            "Scheduling now prioritizes completing each job before its explicit deadline.",
            "The main objective is avoiding deadline misses even at lower aggregate throughput.",
            "The conclusion presupposes deadline-oriented scheduling.",
            "This evidence assumes meeting explicit completion deadlines is the primary objective.",
        ),
    ),
    "fault_containment": (
        _state(
            "process_isolation",
            "Failures are now contained by separate operating-system process boundaries.",
            "A component crash cannot directly corrupt another process's address space.",
            "The conclusion presupposes process-level fault isolation.",
            "This evidence assumes operating-system process boundaries contain component faults.",
        ),
        _state(
            "shared_fate",
            "Components now share one failure domain and terminate together after a critical fault.",
            "A severe failure in one component brings down the complete service instance.",
            "The conclusion presupposes a shared-fate failure domain.",
            "This evidence assumes one critical component fault terminates all colocated components.",
        ),
        _state(
            "redundant_failover",
            "Failures are now contained by switching service to an independent redundant replica.",
            "A standby replica takes over when the active component fails.",
            "The conclusion presupposes redundant failover fault containment.",
            "This evidence assumes an independent replica replaces a failed active component.",
        ),
        _state(
            "language_sandbox",
            "Failures are now contained by a restricted language-level sandbox.",
            "Component code executes with bounded capabilities inside one host process.",
            "The conclusion presupposes language-sandbox fault containment.",
            "This evidence assumes restricted capabilities contain faulty component behavior.",
        ),
    ),
}

M52J_FAMILIES_BY_SPLIT = {
    "train": tuple(M52I_FAMILIES_BY_SPLIT["train"]),
    "valid": ("memory_management", "consistency_requirement"),
    "confirmation": ("scheduling_objective", "fault_containment"),
}


def _family(name: str) -> Tuple[Mapping[str, str], ...]:
    if name in M52J_NEW_FAMILIES:
        return M52J_NEW_FAMILIES[name]
    return _m52h_family(name)


@lru_cache(maxsize=None)
def build_m52j_rows(split: str) -> Tuple[Mapping[str, Any], ...]:
    if split not in M52J_SPLITS:
        raise ValueError(f"unknown M52j split: {split}")
    rows = []
    for family_name in M52J_FAMILIES_BY_SPLIT[split]:
        states = _family(family_name)
        for state_index, state in enumerate(states):
            for variant_index, variant in enumerate(M52I_VARIANTS):
                basis = (
                    str(state["basis_paraphrase"])
                    if variant in ("basis_paraphrase", "dual_paraphrase")
                    else str(state["basis"])
                )
                positive_current = (
                    str(state["current_paraphrase"])
                    if variant in ("current_paraphrase", "dual_paraphrase")
                    else str(state["current"])
                )
                negative_state = states[
                    (state_index + 1 + variant_index % (len(states) - 1))
                    % len(states)
                ]
                negative_current = (
                    str(negative_state["current_paraphrase"])
                    if variant in ("current_paraphrase", "dual_paraphrase")
                    else str(negative_state["current"])
                )
                contrast_id = "m52j-contrast-" + content_digest(
                    {
                        "split": split,
                        "family": family_name,
                        "basis": state["key"],
                        "variant": variant,
                        "version": PAIRWISE_RELATION_CALIBRATION_VERSION,
                    }
                )[:24]
                for label, current, current_key in (
                    (1, positive_current, state["key"]),
                    (0, negative_current, negative_state["key"]),
                ):
                    rows.append(
                        {
                            "prompt": semantic_relation_prompt(basis, current),
                            "metadata": {
                                "record_id": "m52j-record-"
                                + content_digest(
                                    {
                                        "contrast_id": contrast_id,
                                        "label": label,
                                        "version": PAIRWISE_RELATION_CALIBRATION_VERSION,
                                    }
                                )[:24],
                                "contrast_id": contrast_id,
                                "split": split,
                                "family": family_name,
                                "variant": variant,
                                "basis_state_key": state["key"],
                                "current_state_key": current_key,
                                "basis_text": basis,
                                "current_state_text": current,
                                "label": label,
                            },
                        }
                    )
    return tuple(rows)


def apply_threshold(
    rows: Sequence[Mapping[str, Any]], scores: Sequence[float], threshold: float
) -> Tuple[Mapping[str, Any], ...]:
    records = []
    for row, score in zip(rows, scores):
        metadata = row["metadata"]
        prediction = int(float(score) > float(threshold))
        records.append(
            {
                "record_id": metadata["record_id"],
                "contrast_id": metadata["contrast_id"],
                "family": metadata["family"],
                "variant": metadata["variant"],
                "label": int(metadata["label"]),
                "prediction": prediction,
                "score": float(score),
                "threshold": float(threshold),
                "correct": prediction == int(metadata["label"]),
            }
        )
    return tuple(records)


def select_threshold(
    rows: Sequence[Mapping[str, Any]], scores: Sequence[float]
) -> Mapping[str, Any]:
    ordered = sorted({float(score) for score in scores})
    candidates = [ordered[0] - 1e-6, ordered[-1] + 1e-6]
    candidates.extend(
        (left + right) / 2.0 for left, right in zip(ordered, ordered[1:])
    )
    evaluated = []
    for threshold in candidates:
        metrics = relation_metrics(apply_threshold(rows, scores, threshold))
        evaluated.append({"threshold": threshold, "metrics": metrics})
    return sorted(
        evaluated,
        key=lambda item: (
            -float(item["metrics"]["contrast_pair_accuracy"]),
            -float(item["metrics"]["balanced_accuracy"]),
            -float(item["metrics"]["paraphrase_balanced_accuracy"]),
            -min(
                float(row["balanced_accuracy"])
                for row in item["metrics"]["by_family"].values()
            ),
            abs(float(item["threshold"])),
            float(item["threshold"]),
        ),
    )[0]


def calibrate_leave_one_family_out(
    rows: Sequence[Mapping[str, Any]], scores: Sequence[float]
) -> Mapping[str, Any]:
    families = sorted({str(row["metadata"]["family"]) for row in rows})
    thresholds = []
    records = []
    for family in families:
        fit_indices = [
            index
            for index, row in enumerate(rows)
            if row["metadata"]["family"] != family
        ]
        held_indices = [
            index
            for index, row in enumerate(rows)
            if row["metadata"]["family"] == family
        ]
        selected = select_threshold(
            [rows[index] for index in fit_indices],
            [scores[index] for index in fit_indices],
        )
        threshold = float(selected["threshold"])
        thresholds.append(threshold)
        records.extend(
            apply_threshold(
                [rows[index] for index in held_indices],
                [scores[index] for index in held_indices],
                threshold,
            )
        )
    ordered = sorted(thresholds)
    middle = len(ordered) // 2
    deployed = (
        ordered[middle]
        if len(ordered) % 2
        else (ordered[middle - 1] + ordered[middle]) / 2.0
    )
    return {
        "fold_thresholds": thresholds,
        "deployed_threshold": deployed,
        "cross_validation_metrics": relation_metrics(records),
    }


def m52j_condition_passed(
    metrics: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "balanced_accuracy": metrics["balanced_accuracy"]
        >= contract["minimum_balanced_accuracy"],
        "paraphrase_balanced_accuracy": metrics["paraphrase_balanced_accuracy"]
        >= contract["minimum_paraphrase_balanced_accuracy"],
        "contrast_pair_accuracy": metrics["contrast_pair_accuracy"]
        >= contract["minimum_contrast_pair_accuracy"],
        "contrast_ranking_accuracy": metrics["contrast_ranking_accuracy"]
        >= contract["minimum_contrast_ranking_accuracy"],
        "each_family_balanced_accuracy": min(
            row["balanced_accuracy"] for row in metrics["by_family"].values()
        )
        >= contract["minimum_each_family_balanced_accuracy"],
    }
    return all(checks.values()), checks


def select_m52j_candidate(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    if not candidates:
        raise ValueError("M52j checkpoint selection requires candidates")
    return sorted(
        candidates,
        key=lambda row: (
            -int(bool(row["passed"])),
            -float(row["validation_metrics"]["contrast_pair_accuracy"]),
            -float(row["validation_metrics"]["balanced_accuracy"]),
            -float(row["validation_metrics"]["paraphrase_balanced_accuracy"]),
            -float(row["validation_metrics"]["contrast_ranking_accuracy"]),
            int(row["iteration"]),
        ),
    )[0]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52j artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode()).hexdigest()


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    parent = (
        project
        / "runs/cognitive_core/sequential_policy_learning_v47/selected_adapter/"
        "adapters.safetensors"
    )
    m52i = json.loads(
        (
            project
            / "runs/cognitive_core/semantic_relation_competence_v52i/local-audit.json"
        ).read_text()
    )
    return {
        "version": PAIRWISE_RELATION_CALIBRATION_VERSION,
        "parent_version": "general-cognitive-semantic-relation-competence-v52i",
        "scientific_question": (
            "Can matched-counterfactual margin training and family-robust threshold "
            "calibration convert the small model's relative semantic ordering into reliable "
            "absolute applicability decisions?"
        ),
        "seed": M52J_SEED,
        "families_by_split": {
            split: list(value) for split, value in M52J_FAMILIES_BY_SPLIT.items()
        },
        "variants": list(M52I_VARIANTS),
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "parent_adapter_source": (
                "runs/cognitive_core/sequential_policy_learning_v47/selected_adapter/"
                "adapters.safetensors"
            ),
            "parent_adapter_sha256": _sha256(parent),
            "m52i_audit_id": m52i["audit_id"],
            "failed_m52i_internal_adapter_excluded": True,
        },
        "score_contract": {
            "score": "next-token YES logit minus next-token NO logit",
            "yes_and_no_must_each_be_one_token": True,
            "threshold_calibration": (
                "leave one training family out; deploy the median fold threshold"
            ),
        },
        "training_recipe": {
            "trainable_component": "top_8_existing_M47_LoRA_blocks_only",
            "iterations": 160,
            "learning_rate": 0.000005,
            "batch_size_in_contrast_pairs": 1,
            "gradient_accumulation_steps": 4,
            "max_sequence_length": 256,
            "checkpoint_candidates": [20, 40, 80, 120, 160],
            "pairwise_margin": 1.0,
            "absolute_half_margin": 0.5,
            "loss": (
                "relu(1 - (positive_score - negative_score)) plus 0.5 times "
                "[relu(0.5-positive_score)+relu(0.5+negative_score)]"
            ),
            "confirmation_access_during_selection": False,
        },
        "validation_contract": {
            "minimum_balanced_accuracy": 0.88,
            "minimum_paraphrase_balanced_accuracy": 0.85,
            "minimum_contrast_pair_accuracy": 0.80,
            "minimum_contrast_ranking_accuracy": 0.90,
            "minimum_each_family_balanced_accuracy": 0.80,
        },
        "conditions": {
            "frozen_calibrated_decoder": "calibration-only control",
            "internal_pairwise_margin": "primary intervention",
        },
        "confirmation_rule": (
            "select only among conditions passing every validation gate; if none pass, "
            "confirmation remains closed"
        ),
        "claim_boundary": (
            "M52j tests semantic-relation calibration on synthetic CS state descriptions. "
            "Passing would not yet establish trajectory control, concept invention, general "
            "reasoning parity, or transfer beyond this relation class."
        ),
    }


def prepare_m52j_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol_payload = _protocol_payload(project)
    protocol = {**protocol_payload, "protocol_freeze_id": content_digest(protocol_payload)}
    _write_immutable(
        output / "protocol-freeze.json", json.dumps(protocol, indent=2, sort_keys=True) + "\n"
    )
    hashes = {}
    counts = {}
    for split in M52J_SPLITS:
        rows = build_m52j_rows(split)
        payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
        hashes[split] = _write_immutable(output / f"relation/{split}.jsonl", payload)
        counts[split] = len(rows)
    base = {**protocol, "hashes": hashes, "counts": counts}
    freeze = {**base, "freeze_id": content_digest(base)}
    _write_immutable(
        output / "benchmark-freeze.json", json.dumps(freeze, indent=2, sort_keys=True) + "\n"
    )
    verification = verify_m52j_benchmark(output, project)
    _write_immutable(
        output / "benchmark-verification.json",
        json.dumps(verification, indent=2, sort_keys=True) + "\n",
    )
    return freeze


def _rows(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(json.loads(line) for line in path.read_text().splitlines() if line)


def verify_m52j_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol_payload = {
        key: value for key, value in protocol.items() if key != "protocol_freeze_id"
    }
    freeze_payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    stored = {
        split: _rows(output / f"relation/{split}.jsonl") for split in M52J_SPLITS
    }
    balanced = True
    contrasts = True
    shortcuts_absent = True
    for rows in stored.values():
        groups: dict[str, list[Mapping[str, Any]]] = {}
        for row in rows:
            metadata = row["metadata"]
            groups.setdefault(metadata["contrast_id"], []).append(row)
            shortcuts_absent = shortcuts_absent and all(
                marker not in row["prompt"]
                for marker in ("family=", "state_key=", "basis_state_key", "current_state_key")
            )
        for group in groups.values():
            contrasts = contrasts and (
                len(group) == 2
                and {row["metadata"]["label"] for row in group} == {0, 1}
                and len({row["metadata"]["basis_text"] for row in group}) == 1
            )
        for family in {row["metadata"]["family"] for row in rows}:
            for variant in M52I_VARIANTS:
                labels = [
                    row["metadata"]["label"]
                    for row in rows
                    if row["metadata"]["family"] == family
                    and row["metadata"]["variant"] == variant
                ]
                balanced = balanced and labels.count(0) == labels.count(1) > 0
    parent = project / freeze["frozen_model"]["parent_adapter_source"]
    m52i = json.loads(
        (
            project
            / "runs/cognitive_core/semantic_relation_competence_v52i/local-audit.json"
        ).read_text()
    )
    checks = {
        "protocol_id_content_derived": content_digest(protocol_payload)
        == protocol["protocol_freeze_id"],
        "freeze_id_content_derived": content_digest(freeze_payload)
        == freeze["freeze_id"],
        "stored_rows_reproduce": all(
            stored[split] == build_m52j_rows(split) for split in M52J_SPLITS
        ),
        "hashes_match": all(
            _sha256(output / f"relation/{split}.jsonl") == freeze["hashes"][split]
            for split in M52J_SPLITS
        ),
        "counts_match": all(
            len(stored[split]) == freeze["counts"][split] for split in M52J_SPLITS
        ),
        "balanced_by_family_variant": balanced,
        "contrasts_hold_basis_fixed": contrasts,
        "shortcut_identifiers_absent": shortcuts_absent,
        "families_disjoint": all(
            not bool(
                set(M52J_FAMILIES_BY_SPLIT[left])
                & set(M52J_FAMILIES_BY_SPLIT[right])
            )
            for index, left in enumerate(M52J_SPLITS)
            for right in M52J_SPLITS[index + 1 :]
        ),
        "fresh_validation_and_confirmation_families": not bool(
            (set(M52J_FAMILIES_BY_SPLIT["valid"]) | set(M52J_FAMILIES_BY_SPLIT["confirmation"]))
            & set().union(*M52I_FAMILIES_BY_SPLIT.values())
        ),
        "parent_adapter_matches": _sha256(parent)
        == freeze["frozen_model"]["parent_adapter_sha256"],
        "m52i_parent_matches": (
            m52i["audit_id"]
            == freeze["frozen_model"]["m52i_audit_id"]
            == M52J_M52I_AUDIT_ID
            and not m52i["milestone_passed"]
            and not m52i["confirmation_opened"]
        ),
    }
    return {
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }
