from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.learning import (
    LearningConfig,
    TrainingCondition,
)


@dataclass(frozen=True)
class PilotSummary:
    pilot_id: str
    run_ids: Tuple[str, ...]
    paired_procedure_deltas: Mapping[str, float]
    grouped_metrics: Mapping[str, Mapping[str, float]]
    monotonic_random_load_effect: bool
    interpretation: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "pilot_id": self.pilot_id,
            "run_ids": list(self.run_ids),
            "paired_procedure_deltas": dict(
                sorted(self.paired_procedure_deltas.items())
            ),
            "grouped_metrics": {
                key: dict(sorted(value.items()))
                for key, value in sorted(self.grouped_metrics.items())
            },
            "monotonic_random_load_effect": (
                self.monotonic_random_load_effect
            ),
            "interpretation": self.interpretation,
        }


def pilot_configs(
    fact_counts: Sequence[int] = (8, 64, 192),
    widths: Sequence[int] = (32,),
    seeds: Sequence[int] = (0, 1),
    steps: int = 800,
    compute_device: str = "cpu",
    evidence_schedules: Sequence[str] = ("balanced",),
    relevance_annotations: Sequence[bool] = (False,),
) -> Tuple[LearningConfig, ...]:
    return tuple(
        LearningConfig(
            condition=condition,
            fact_count=fact_count,
            width=width,
            steps=steps,
            model_seed=seed,
            compute_device=compute_device,
            evidence_schedule=evidence_schedule,
            relevance_annotation=relevance_annotation,
        )
        for relevance_annotation in relevance_annotations
        for evidence_schedule in evidence_schedules
        for width in widths
        for fact_count in fact_counts
        for seed in seeds
        for condition in (
            TrainingCondition.RANDOM_FACTS,
            TrainingCondition.STRUCTURED_FACTS,
        )
    )


def summarize_results(results: Iterable[Any]) -> PilotSummary:
    materialized = tuple(results)
    groups: Dict[str, List[Any]] = {}
    index: Dict[Tuple[str, bool, int, int, int, str], Any] = {}
    for result in materialized:
        config = result.config
        group_key = "%s/%s/%s/w%d/f%d" % (
            config.evidence_schedule,
            (
                "annotated"
                if config.relevance_annotation
                else "latent"
            ),
            config.condition.value,
            config.width,
            config.fact_count,
        )
        groups.setdefault(group_key, []).append(result)
        index[
            (
                config.evidence_schedule,
                config.relevance_annotation,
                config.width,
                config.fact_count,
                config.model_seed,
                config.condition.value,
            )
        ] = result

    grouped_metrics = {
        key: {
            metric: mean(
                result.metrics[metric]
                for result in values
            )
            for metric in (
                "procedure_accuracy",
                "closed_book_accuracy",
                "oracle_evidence_accuracy",
                "irrelevant_evidence_accuracy",
                "conflicting_evidence_accuracy",
                "unknown_accuracy",
                "known_answer_destruction",
                "cognitive_core_score",
            )
        }
        for key, values in groups.items()
    }
    paired: Dict[str, float] = {}
    for key, random_result in index.items():
        (
            schedule,
            annotation,
            width,
            fact_count,
            seed,
            condition,
        ) = key
        if condition != TrainingCondition.RANDOM_FACTS.value:
            continue
        structured = index[
            (
                schedule,
                annotation,
                width,
                fact_count,
                seed,
                TrainingCondition.STRUCTURED_FACTS.value,
            )
        ]
        paired["%s/%s/w%d/f%d/s%d" % (
            schedule,
            "annotated" if annotation else "latent",
            width,
            fact_count,
            seed,
        )] = (
            random_result.metrics["procedure_accuracy"]
            - structured.metrics["procedure_accuracy"]
        )

    random_curves: List[bool] = []
    schedules = sorted(
        {result.config.evidence_schedule for result in materialized}
    )
    annotations = sorted(
        {result.config.relevance_annotation for result in materialized}
    )
    widths = sorted({result.config.width for result in materialized})
    for annotation in annotations:
        for schedule in schedules:
            for width in widths:
                loads = sorted(
                    {
                        result.config.fact_count
                        for result in materialized
                        if result.config.width == width
                        and result.config.evidence_schedule == schedule
                        and result.config.relevance_annotation
                        == annotation
                    }
                )
                values = [
                    grouped_metrics[
                        "%s/%s/%s/w%d/f%d"
                        % (
                            schedule,
                            "annotated" if annotation else "latent",
                            TrainingCondition.RANDOM_FACTS.value,
                            width,
                            load,
                        )
                    ]["procedure_accuracy"]
                    for load in loads
                ]
                random_curves.append(
                    len(loads) >= 3
                    and all(
                        right <= left + 1e-12
                        for left, right in zip(values, values[1:])
                    )
                )
    monotonic = bool(random_curves) and all(random_curves)
    paired_mean = mean(paired.values()) if paired else 0.0
    interpretation = (
        "Pilot is consistent with a random-fact load effect; expand to the "
        "frozen two-width, multi-seed causal grid."
        if monotonic and paired_mean < 0.0
        else "Pilot does not yet establish the predicted causal trade-off; "
        "inspect learning curves and controls before expanding."
    )
    payload = {
        "run_ids": sorted(result.run_id for result in materialized),
        "paired": paired,
        "grouped_metrics": grouped_metrics,
    }
    return PilotSummary(
        pilot_id=content_digest(payload)[:20],
        run_ids=tuple(sorted(result.run_id for result in materialized)),
        paired_procedure_deltas=paired,
        grouped_metrics=grouped_metrics,
        monotonic_random_load_effect=monotonic,
        interpretation=interpretation,
    )


def run_pilot(
    output_root: Path,
    configs: Sequence[LearningConfig],
) -> PilotSummary:
    from scientist.domains.cognitive_core.mlx_lab import train_and_evaluate

    store = ArtifactStore(output_root)
    results = []
    for config in configs:
        result = train_and_evaluate(config)
        store.put("cognitive_core_learned_run", result.as_dict())
        results.append(result)
        print(
            json.dumps(
                {
                    "run_id": result.run_id,
                    "condition": config.condition.value,
                    "evidence_schedule": config.evidence_schedule,
                    "relevance_annotation": (
                        config.relevance_annotation
                    ),
                    "fact_count": config.fact_count,
                    "width": config.width,
                    "seed": config.model_seed,
                    "seconds": round(result.elapsed_seconds, 3),
                    "procedure": round(
                        result.metrics["procedure_accuracy"],
                        4,
                    ),
                    "memory": round(
                        result.metrics["closed_book_accuracy"],
                        4,
                    ),
                },
                sort_keys=True,
            ),
            flush=True,
        )
    summary = summarize_results(results)
    store.write_manifest(
        "cognitive-core-pilot-" + summary.pilot_id,
        summary.as_dict(),
    )
    return summary


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/pilot",
    )
    parser.add_argument("--steps", type=int, default=800)
    parser.add_argument(
        "--fact-counts",
        default="8,64,192",
    )
    parser.add_argument("--widths", default="32")
    parser.add_argument("--seeds", default="0,1")
    parser.add_argument(
        "--device",
        choices=("cpu", "gpu"),
        default="cpu",
    )
    parser.add_argument(
        "--evidence-schedules",
        default="balanced",
    )
    parser.add_argument(
        "--relevance-annotations",
        default="false",
        help="comma-separated false,true values",
    )
    arguments = parser.parse_args(list(argv) or None)
    configs = pilot_configs(
        fact_counts=tuple(
            int(value)
            for value in arguments.fact_counts.split(",")
        ),
        widths=tuple(
            int(value)
            for value in arguments.widths.split(",")
        ),
        seeds=tuple(
            int(value)
            for value in arguments.seeds.split(",")
        ),
        steps=arguments.steps,
        compute_device=arguments.device,
        evidence_schedules=tuple(
            value.strip()
            for value in arguments.evidence_schedules.split(",")
        ),
        relevance_annotations=tuple(
            value.strip().lower() == "true"
            for value in arguments.relevance_annotations.split(",")
        ),
    )
    summary = run_pilot(Path(arguments.output), configs)
    print(json.dumps(summary.as_dict(), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
