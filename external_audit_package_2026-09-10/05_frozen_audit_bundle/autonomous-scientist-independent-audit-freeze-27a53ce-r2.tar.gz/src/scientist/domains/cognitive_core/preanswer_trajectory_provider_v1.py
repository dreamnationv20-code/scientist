from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.instrument_provider import (
    DeterministicValidationReceipt,
    InstrumentOutput,
    InstrumentValidatorStageProvider,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.preanswer_trajectory_phenomenon_v1 import (
    CHECKPOINTS,
    EFFECT_THRESHOLD,
    FAILURES_PER_MODEL,
    MODEL_ORDER,
    REAL_CONDITIONS,
    RELIABILITY_THRESHOLD,
    VERSION,
    digest,
    file_sha256,
    positive_control_report,
    spearman,
    summarize_trajectory,
    trajectory_reliability,
    validate_feature_receipt_keys,
)
from scientist.program.research_kernel import (
    CounterfactualContrast,
    PhenomenonAtlas,
    PhenomenonCase,
    ResearchActionKind,
)


PROVIDER_VERSION = "cognitive-preanswer-trajectory-provider-v1"
BINDING_VERSION = "cognitive-preanswer-trajectory-fresh-binding-v1"
MEASUREMENT_REF = "deterministic-answer-blind-trajectory-mapper-v1"
VALIDATOR_REF = "independent-preanswer-trajectory-validator-v1"


def _read_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("expected JSON object: %s" % path)
    return value


def _read_jsonl(path: Path) -> list[Mapping[str, Any]]:
    values = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if any(not isinstance(value, Mapping) for value in values):
        raise ValueError("expected JSON-object rows: %s" % path)
    return values


def _write_immutable(path: Path, value: Mapping[str, Any]) -> None:
    payload = (
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.read_bytes() != payload:
            raise ValueError("refusing to replace frozen trajectory artifact: %s" % path)
        return
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _command_receipt(
    command: Sequence[str],
    *,
    stdout: str,
    stderr: str,
    returncode: int,
    wall_seconds: float,
) -> Mapping[str, Any]:
    body = {
        "command_digest": digest(list(command)),
        "stdout_digest": digest(stdout),
        "stderr_digest": digest(stderr),
        "returncode": int(returncode),
        "wall_seconds": float(wall_seconds),
    }
    return {**body, "receipt_id": digest(body)}


def _verify_identity(value: Mapping[str, Any], identity_key: str) -> str:
    body = dict(value)
    supplied = body.pop(identity_key, None)
    if supplied != digest(body):
        raise ValueError("artifact identity mismatch: %s" % identity_key)
    return str(supplied)


def _mean(values: Sequence[float]) -> float:
    if not values:
        raise ValueError("mean requires values")
    return sum(float(value) for value in values) / len(values)


def _mean_summary(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
    keys = tuple(rows[0]["summary"])
    return {
        key: _mean([float(row["summary"][key]) for row in rows]) for key in keys
    }


def _mean_checkpoint(
    rows: Sequence[Mapping[str, Any]], checkpoint_index: int
) -> Mapping[str, float]:
    scalar_keys = (
        "normalized_entropy",
        "top_probability",
        "probability_margin",
        "checkpoint_js_divergence",
        "mean_hidden_norm",
        "mean_hidden_velocity",
        "mean_hidden_reversal",
    )
    return {
        key: _mean(
            [float(row["checkpoints"][checkpoint_index][key]) for row in rows]
        )
        for key in scalar_keys
    }


def _dynamic_state(checkpoint: Mapping[str, float]) -> float:
    return (
        float(checkpoint["normalized_entropy"])
        + float(checkpoint["mean_hidden_velocity"])
        + float(checkpoint["checkpoint_js_divergence"])
        + 0.25 * float(checkpoint["mean_hidden_reversal"])
    )


def _command_outputs(
    bundle: Path, operation: str, model_key: str | None
) -> tuple[str, ...]:
    if operation == "prepare":
        protocol = _read_json(bundle / "protocol-freeze.json")
        return (str(protocol["freeze_id"]),)
    if operation == "select":
        value = _read_json(bundle / "control/failure-selection-completion.json")
        return (
            str(value["completion_id"]),
            str(value["selected_sha256"]),
            str(value["selection_evidence_id"]),
        )
    if model_key is None:
        raise ValueError("model operation requires model key")
    prefix = "screen" if operation == "screen" else "trajectory"
    value = _read_json(bundle / ("control/%s-%s-completion.json" % (prefix, model_key)))
    return (
        str(value["completion_id"]),
        str(value["receipts_sha256"]),
    )


class TrajectoryReceiptBundleRunner:
    measurement_ref = MEASUREMENT_REF

    def __init__(self, bundle_dir: Path) -> None:
        self.bundle_dir = Path(bundle_dir).resolve()

    def _verify_bundle(self, kernel):
        protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
        if (
            protocol.get("version") != VERSION
            or protocol.get("mission_id") != kernel.mission.mission_id
            or protocol.get("incumbent_portfolio_id")
            != kernel.incumbent.portfolio_id
            or protocol.get("action_id") != kernel.next_action().action_id
        ):
            raise ValueError("trajectory protocol belongs to another frontier")
        _verify_identity(protocol, "freeze_id")
        for source, expected in protocol["source_code_sha256"].items():
            if file_sha256(Path(str(source))) != str(expected):
                raise ValueError("frozen trajectory source changed: %s" % source)
        binding = _read_json(self.bundle_dir / "fresh-run-binding.json")
        _verify_identity(binding, "binding_id")
        if any(
            (
                binding.get("version") != BINDING_VERSION,
                binding.get("mission_id") != kernel.mission.mission_id,
                binding.get("incumbent_portfolio_id")
                != kernel.incumbent.portfolio_id,
                binding.get("action_id") != kernel.next_action().action_id,
                binding.get("freeze_id") != protocol["freeze_id"],
                binding.get("human_interventions") != 0,
                binding.get("out_of_band_interventions") != 0,
                binding.get("development_qualification_only") is not True,
                binding.get("prospective_nature_evidence_claimed") is not False,
            )
        ):
            raise ValueError("trajectory fresh binding is invalid")
        return protocol, binding

    def _invocations(self, kernel, protocol, binding):
        specs = [
            (
                "prepare",
                None,
                "freeze_preanswer_trajectory_protocol",
                "preanswer-trajectory-protocol-runtime-v1",
                AuthorityScope.EXECUTE,
                False,
            ),
            *[
                (
                    "screen",
                    model_key,
                    "execute_baseline_failure_screen:%s" % model_key,
                    "local-mlx-failure-screen-runtime:%s" % model_key,
                    AuthorityScope.EXECUTE,
                    True,
                )
                for model_key in MODEL_ORDER
            ],
            (
                "select",
                None,
                "select_balanced_baseline_failures",
                "sealed-baseline-failure-selector-v1",
                AuthorityScope.MEASURE,
                False,
            ),
            *[
                (
                    "trajectory",
                    model_key,
                    "execute_scalar_preanswer_trajectory:%s" % model_key,
                    "local-mlx-preanswer-trajectory-runtime:%s" % model_key,
                    AuthorityScope.EXECUTE,
                    True,
                )
                for model_key in MODEL_ORDER
            ],
        ]
        invocations = []
        for operation, model_key, operation_ref, actor_ref, scope, charge in specs:
            receipt = binding["command_receipts"][
                operation if model_key is None else "%s:%s" % (operation, model_key)
            ]
            if _verify_identity(receipt, "receipt_id") != receipt["receipt_id"]:
                raise ValueError("command receipt identity mismatch")
            if receipt["returncode"] != 0:
                raise ValueError("bound command did not complete")
            if operation == "prepare":
                inputs = (
                    kernel.mission.mission_id,
                    kernel.incumbent.portfolio_id,
                )
            elif operation == "select":
                inputs = (
                    protocol["freeze_id"],
                    protocol["candidate_panel"]["authority_sha256"],
                )
            else:
                inputs = (
                    protocol["freeze_id"],
                    protocol["models"][model_key]["identity_id"],
                )
            outputs = (
                str(receipt["receipt_id"]),
                *_command_outputs(self.bundle_dir, operation, model_key),
            )
            invocations.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation=operation_ref,
                    actor=ActorIdentity(actor_ref, ActorKind.TOOL_RUNTIME),
                    authority_scope=scope,
                    input_artifact_ids=tuple(inputs),
                    output_artifact_ids=tuple(dict.fromkeys(outputs)),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=float(receipt["wall_seconds"]),
                        compute_units=(
                            float(receipt["wall_seconds"]) if charge else 0.0
                        ),
                    ),
                )
            )
        return invocations

    def _load_telemetry(self, protocol):
        selection = _read_json(
            Path(str(protocol["failure_selection"]["completion_path"]))
        )
        _verify_identity(selection, "completion_id")
        selected_path = Path(str(selection["selected_path"]))
        if (
            file_sha256(selected_path) != selection["selected_sha256"]
            or selection.get("selected_count") != FAILURES_PER_MODEL * len(MODEL_ORDER)
            or selection.get("trajectory_features_used_for_selection") is not False
            or selection.get("answers_opened_after_both_screen_matrices") is not True
        ):
            raise ValueError("selected failure panel is invalid")
        selected = _read_jsonl(selected_path)
        completion_ids = {}
        receipt_hashes = {}
        rows_by_model = {}
        for model_key in MODEL_ORDER:
            completion = _read_json(
                self.bundle_dir
                / ("control/trajectory-%s-completion.json" % model_key)
            )
            completion_id = _verify_identity(completion, "completion_id")
            receipts_path = Path(str(completion["receipts_path"]))
            rows = _read_jsonl(receipts_path)
            expected = FAILURES_PER_MODEL * (len(REAL_CONDITIONS) + 1)
            keys = {
                (
                    str(row["unit_id"]),
                    str(row["condition"]),
                    str(row["paraphrase"]),
                    int(row["seed_index"]),
                )
                for row in rows
            }
            if any(
                (
                    completion.get("status")
                    != "scalar_preanswer_trajectory_matrix_complete",
                    completion.get("freeze_id") != protocol["freeze_id"],
                    completion.get("receipt_count") != expected,
                    len(rows) != expected,
                    len(keys) != expected,
                    file_sha256(receipts_path) != completion["receipts_sha256"],
                    completion.get("terminal_boundaries_detected") != 0,
                    completion.get("serialized_generated_text") is not False,
                    completion.get("serialized_generated_token_identities") is not False,
                )
            ):
                raise ValueError("trajectory completion is invalid")
            for row in rows:
                body = {key: value for key, value in row.items() if key != "receipt_id"}
                if row.get("receipt_id") != digest(body):
                    raise ValueError("trajectory receipt identity mismatch")
                validate_feature_receipt_keys(body)
            completion_ids[model_key] = completion_id
            receipt_hashes[model_key] = completion["receipts_sha256"]
            rows_by_model[model_key] = rows
        return selection, selected, completion_ids, receipt_hashes, rows_by_model

    @staticmethod
    def _permutation_control(rows_by_model):
        report = {}
        for model_key, rows in rows_by_model.items():
            real = [row for row in rows if row["condition"] == "unassisted_prefix"]
            original = []
            permuted = []
            for row in real:
                original.append(float(row["summary"]["fingerprint_score"]))
                reverse_values = list(reversed(row["checkpoints"]))
                reordered = [
                    {**value, "token_checkpoint": CHECKPOINTS[index]}
                    for index, value in enumerate(reverse_values)
                ]
                permuted.append(
                    float(summarize_trajectory(reordered)["fingerprint_score"])
                )
            report[model_key] = {
                "operation": "norm-preserving reversal of checkpoint order",
                "original_vs_permuted_spearman": spearman(original, permuted),
                "fingerprint_changed_fraction": _mean(
                    [abs(left - right) > 1e-12 for left, right in zip(original, permuted)]
                ),
                "analysis_only": True,
            }
        return report

    def _build_atlas(self, kernel, protocol, binding, selected, rows_by_model):
        reliabilities = {
            key: trajectory_reliability(rows_by_model[key]) for key in MODEL_ORDER
        }
        unit_context = {}
        regimes = {}
        sham_control_rows = []
        for model_key in MODEL_ORDER:
            selected_model = [row for row in selected if row["model_key"] == model_key]
            unit_summaries = []
            for item in selected_model:
                unit_id = str(item["unit_id"])
                real = [
                    row
                    for row in rows_by_model[model_key]
                    if row["unit_id"] == unit_id
                    and row["condition"] == "unassisted_prefix"
                ]
                sham = next(
                    row
                    for row in rows_by_model[model_key]
                    if row["unit_id"] == unit_id
                    and row["condition"] == "matched_sham_padding"
                )
                if len(real) != len(REAL_CONDITIONS):
                    raise ValueError("unit trajectory repeat matrix is incomplete")
                summary = _mean_summary(real)
                unit_context[unit_id] = (item, real, sham, summary)
                unit_summaries.append((float(summary["fingerprint_score"]), unit_id))
                real_late = _dynamic_state(_mean_checkpoint(real, 3))
                sham_late = _dynamic_state(sham["checkpoints"][3])
                sham_control_rows.append(
                    {
                        "unit_id": unit_id,
                        "model_key": model_key,
                        "absolute_late_dynamics_difference": abs(real_late - sham_late),
                    }
                )
            ordered = sorted(unit_summaries, key=lambda value: (value[0], value[1]))
            labels = (
                "lower_fingerprint_tercile",
                "middle_fingerprint_tercile",
                "upper_fingerprint_tercile",
            )
            for rank, (_, unit_id) in enumerate(ordered):
                regimes[unit_id] = labels[min(2, rank // 4)]

        cases = []
        contrasts = []
        horizon_specs = (
            ("tokens_16_to_32", 0, 1),
            ("tokens_32_to_48", 1, 2),
            ("tokens_48_to_64", 2, 3),
        )
        for unit_id in sorted(unit_context):
            item, real, sham, summary = unit_context[unit_id]
            for horizon, prior_index, current_index in horizon_specs:
                prior = _mean_checkpoint(real, prior_index)
                current = _mean_checkpoint(real, current_index)
                sham_current = sham["checkpoints"][current_index]
                prior_state = _dynamic_state(prior)
                current_state = _dynamic_state(current)
                effect = prior_state - current_state
                evidence_ids = tuple(str(row["receipt_id"]) for row in real) + (
                    str(sham["receipt_id"]),
                )
                metrics = {
                    "prior_dynamic_state": prior_state,
                    "current_dynamic_state": current_state,
                    "preanswer_transition_effect": effect,
                    "current_normalized_entropy": float(
                        current["normalized_entropy"]
                    ),
                    "current_hidden_velocity": float(
                        current["mean_hidden_velocity"]
                    ),
                    "current_checkpoint_js_divergence": float(
                        current["checkpoint_js_divergence"]
                    ),
                    "current_hidden_reversal": float(
                        current["mean_hidden_reversal"]
                    ),
                    "sham_current_dynamic_state": _dynamic_state(sham_current),
                    "fingerprint_score": float(summary["fingerprint_score"]),
                    "trajectory_reliability": float(
                        reliabilities[str(item["model_key"])]["coefficient"]
                    ),
                    "mean_prompt_tokens": _mean(
                        [float(row["prompt_tokens"]) for row in real]
                    ),
                }
                case = PhenomenonCase(
                    case_ref="%s:%s" % (unit_id, horizon),
                    regime=regimes[unit_id],
                    horizon=horizon,
                    incumbent_decision="truncate_unassisted_prefix_at_%d"
                    % CHECKPOINTS[prior_index],
                    outcome_metrics=metrics,
                    evidence_ids=evidence_ids,
                    trace_ref=digest(
                        {
                            "unit_id": unit_id,
                            "horizon": horizon,
                            "receipt_ids": evidence_ids,
                        }
                    ),
                )
                cases.append(case)
                contrasts.append(
                    CounterfactualContrast(
                        case_id=case.case_id,
                        incumbent_decision=case.incumbent_decision,
                        forced_decision="continue_same_unassisted_prefix_to_%d"
                        % CHECKPOINTS[current_index],
                        terminal_effect=effect,
                        matched_context=(
                            "Passive checkpoints from one continuous answer-suppressed "
                            "trajectory; no treatment outcome or terminal answer is observed."
                        ),
                        mediator_observation=(
                            "preanswer_dynamic_state %.8f -> %.8f; sham_endpoint %.8f"
                            % (prior_state, current_state, _dynamic_state(sham_current))
                        ),
                        existing_descriptors=(
                            "model:%s" % item["model_key"],
                            "fingerprint_regime:%s" % regimes[unit_id],
                            "horizon:%s" % horizon,
                            "scalar_telemetry_only:true",
                        ),
                        unexplained_by_current_representation=abs(effect)
                        >= EFFECT_THRESHOLD,
                        evidence_ids=evidence_ids,
                        analyst_ref=MEASUREMENT_REF,
                    )
                )
        atlas = PhenomenonAtlas(
            mission_id=kernel.mission.mission_id,
            incumbent_portfolio_id=kernel.incumbent.portfolio_id,
            cases=tuple(cases),
            contrasts=tuple(contrasts),
            coverage_axes=(
                "model_size",
                "answer_blind_fingerprint_tercile",
                "preanswer_compute_horizon",
                "seed",
                "semantic_preserving_prompt_frame",
                "matched_step_sham",
            ),
            sealed=True,
            builder_ref="deterministic-preanswer-trajectory-phenomenon-mapper:v1",
        )
        effects = [float(value.terminal_effect) for value in contrasts]
        sham_report = {
            "rows": sham_control_rows,
            "median_absolute_late_dynamics_difference": sorted(
                value["absolute_late_dynamics_difference"]
                for value in sham_control_rows
            )[len(sham_control_rows) // 2],
            "difference_threshold": EFFECT_THRESHOLD,
        }
        sham_report["passed"] = (
            sham_report["median_absolute_late_dynamics_difference"]
            >= EFFECT_THRESHOLD
        )
        summary = {
            "failure_units": len(unit_context),
            "failure_units_per_model": {
                key: sum(item["model_key"] == key for item in selected)
                for key in MODEL_ORDER
            },
            "cases": len(cases),
            "contrasts": len(contrasts),
            "unexplained_contrasts": sum(
                item.unexplained_by_current_representation for item in contrasts
            ),
            "positive_effects": sum(value > 0.0 for value in effects),
            "zero_effects": sum(value == 0.0 for value in effects),
            "negative_effects": sum(value < 0.0 for value in effects),
            "regimes": sorted({case.regime for case in cases}),
            "horizons": sorted({case.horizon for case in cases}),
            "reliability": reliabilities,
            "reliability_passed": all(
                value["passed"] for value in reliabilities.values()
            ),
            "sham_negative_control": sham_report,
            "checkpoint_order_permutation_control": self._permutation_control(
                rows_by_model
            ),
            "positive_controls": positive_control_report(),
            "readiness_failures": list(atlas.readiness_failures(kernel.policy)),
        }
        evidence_body = {
            "version": VERSION,
            "provider_version": PROVIDER_VERSION,
            "mission_id": kernel.mission.mission_id,
            "incumbent_portfolio_id": kernel.incumbent.portfolio_id,
            "freeze_id": protocol["freeze_id"],
            "fresh_run_binding_id": binding["binding_id"],
            "summary": summary,
            "unit_regimes": regimes,
            "feature_receipt_ids": sorted(
                str(row["receipt_id"])
                for rows in rows_by_model.values()
                for row in rows
            ),
            "selected_failure_completion_id": binding[
                "selection_completion_id"
            ],
            "outcomes_withheld": True,
            "terminal_answers_serialized": False,
            "generated_token_identities_serialized": False,
            "correctness_used_as_predictor": False,
            "sham_used_as_predictor": False,
            "development_only": True,
            "prospective_nature_evidence_claimed": False,
        }
        evidence = {**evidence_body, "evidence_id": digest(evidence_body)}
        _write_immutable(self.bundle_dir / "phenomenon-evidence.json", evidence)
        _write_immutable(self.bundle_dir / "phenomenon-atlas.json", atlas.as_dict())
        return atlas, evidence, summary

    def __call__(self, kernel, domain) -> InstrumentOutput:
        del domain
        if (
            kernel.mission is None
            or kernel.incumbent is None
            or kernel.next_action().kind != ResearchActionKind.MAP_PHENOMENON
        ):
            raise ValueError("trajectory mapper received another frontier")
        protocol, binding = self._verify_bundle(kernel)
        invocations = self._invocations(kernel, protocol, binding)
        selection, selected, completion_ids, receipt_hashes, rows_by_model = (
            self._load_telemetry(protocol)
        )
        atlas, evidence, summary = self._build_atlas(
            kernel, protocol, binding, selected, rows_by_model
        )
        score_invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation="compile_answer_blind_preanswer_trajectory_atlas",
            actor=ActorIdentity(MEASUREMENT_REF, ActorKind.TOOL_RUNTIME),
            authority_scope=AuthorityScope.MEASURE,
            input_artifact_ids=(
                str(protocol["freeze_id"]),
                str(binding["binding_id"]),
                str(selection["completion_id"]),
                *(completion_ids[key] for key in MODEL_ORDER),
                *(receipt_hashes[key] for key in MODEL_ORDER),
            ),
            output_artifact_ids=(atlas.atlas_id, str(evidence["evidence_id"])),
            usage=ResourceUsage(tool_calls=1),
        )
        invocations.append(score_invocation)
        if not summary["reliability_passed"]:
            case = TransitionCase(
                case_ref="trajectory-reliability-stop:%s" % evidence["evidence_id"],
                phase="phenomenon_mapping",
                question="Did both model sizes meet the frozen trajectory-reliability gate?",
                observations=tuple(
                    "%s_reliability=%.8f"
                    % (key, summary["reliability"][key]["coefficient"])
                    for key in MODEL_ORDER
                ),
                available_actions=(
                    RecoveryAction.PARK_BRANCH,
                    RecoveryAction.UPDATE_CAUSAL_THEORY,
                ),
                protected_invariants=(
                    "retain the frozen 0.60 reliability threshold",
                    "retain all completed scalar telemetry receipts",
                    "do not inspect prospective or replication outcomes",
                    "do not recalibrate this mission after the stop result",
                ),
                evidence_refs=(
                    str(evidence["evidence_id"]),
                    *(completion_ids[key] for key in MODEL_ORDER),
                ),
                retrospective=False,
                domain=kernel.mission.domain_id,
            )
            raise AdjudicableResearchFailure(
                "frozen trajectory reliability stop rule fired",
                case=case,
                profile=FailureEvidenceProfile(
                    case_id=case.case_id,
                    runtime_available=True,
                    external_dependency_missing=False,
                    implementation_integrity_passed=True,
                    interface_qualified=True,
                    protocol_feasible=True,
                    measurement_qualified=True,
                    scientific_outcome_observed=True,
                    scientific_gate_passed=False,
                    representation_limit_demonstrated=False,
                ),
                attempt_invocations=tuple(invocations),
            )
        return InstrumentOutput(
            artifact=atlas,
            artifact_id=atlas.atlas_id,
            invocations=tuple(invocations),
            measurement_ref=MEASUREMENT_REF,
            details={
                "provider_version": PROVIDER_VERSION,
                "freeze_id": protocol["freeze_id"],
                "fresh_run_binding_id": binding["binding_id"],
                "selection_completion_id": selection["completion_id"],
                "completion_ids": completion_ids,
                "receipt_sha256": receipt_hashes,
                "evidence_id": evidence["evidence_id"],
                "summary": summary,
                "generation_invocations": binding["generation_count"],
                "normalized_compute_definition": binding[
                    "normalized_compute_definition"
                ],
                "normalized_compute_units": binding["normalized_compute_units"],
                "normalized_compute_charge_complete": True,
                "fresh_run_bound_execution": True,
                "prospective_nature_evidence_claimed": False,
            },
        )


class AutonomyBoundTrajectoryRunner:
    def __init__(
        self,
        *,
        project_root: Path,
        mission_dir: Path,
        incumbent_bundle_dir: Path,
        python_executable: Path,
        command_executor: Callable[
            [Sequence[str], Path], tuple[str, str, int, float]
        ]
        | None = None,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.mission_dir = Path(mission_dir).resolve()
        self.incumbent_bundle_dir = Path(incumbent_bundle_dir).resolve()
        self.python_executable = Path(python_executable).absolute()
        self.bundle_dir = self.mission_dir / "preanswer_trajectory_v1"
        self.command_executor = command_executor or self._execute_command

    @staticmethod
    def _execute_command(command: Sequence[str], cwd: Path):
        started = time.perf_counter()
        environment = dict(os.environ)
        existing = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = (
            str(cwd / "src")
            if not existing
            else "%s%s%s" % (str(cwd / "src"), os.pathsep, existing)
        )
        completed = subprocess.run(
            tuple(command),
            cwd=str(cwd),
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )
        return (
            completed.stdout,
            completed.stderr,
            completed.returncode,
            time.perf_counter() - started,
        )

    def _run_command(
        self,
        command: Sequence[str],
        *,
        operation: str,
        model_key: str | None,
        kernel,
        attempted: list[ExternalInvocation],
        charge_compute: bool,
        scope: AuthorityScope,
    ) -> Mapping[str, Any]:
        stdout, stderr, returncode, elapsed = self.command_executor(
            tuple(command), self.project_root
        )
        receipt = _command_receipt(
            command,
            stdout=stdout,
            stderr=stderr,
            returncode=returncode,
            wall_seconds=elapsed,
        )
        outputs = [str(receipt["receipt_id"])]
        if returncode == 0:
            outputs.extend(_command_outputs(self.bundle_dir, operation, model_key))
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation=(
                operation if model_key is None else "%s:%s" % (operation, model_key)
            ),
            actor=ActorIdentity(
                "autonomy-bound-preanswer-trajectory:%s" % operation,
                ActorKind.TOOL_RUNTIME,
            ),
            authority_scope=scope,
            input_artifact_ids=(
                kernel.mission.mission_id,
                kernel.incumbent.portfolio_id,
            ),
            output_artifact_ids=tuple(dict.fromkeys(outputs)),
            usage=ResourceUsage(
                tool_calls=1,
                wall_seconds=elapsed,
                compute_units=elapsed if charge_compute else 0.0,
            ),
        )
        attempted.append(invocation)
        if returncode != 0:
            infrastructure = "No Metal device available" in stderr
            case = TransitionCase(
                case_ref="preanswer-trajectory-command-failure:%s:%s"
                % (operation, receipt["receipt_id"]),
                phase="phenomenon_mapping",
                question="Can the frozen trajectory operation complete validly?",
                observations=(
                    "operation=%s" % operation,
                    "model_key=%s" % (model_key or "none"),
                    "returncode=%s" % returncode,
                    "stderr_digest=%s" % receipt["stderr_digest"],
                ),
                available_actions=(
                    RecoveryAction.EXACT_RETRY,
                    RecoveryAction.REPAIR_IMPLEMENTATION,
                ),
                protected_invariants=(
                    "mission identity",
                    "incumbent identity",
                    "frozen panel and feature contract",
                    "completed partial receipts",
                ),
                evidence_refs=tuple(
                    artifact_id
                    for item in attempted
                    for artifact_id in item.output_artifact_ids
                ),
                retrospective=False,
                domain=kernel.mission.domain_id,
            )
            raise AdjudicableResearchFailure(
                "autonomy-bound trajectory command failed: %s" % operation,
                case=case,
                profile=FailureEvidenceProfile(
                    case_id=case.case_id,
                    runtime_available=not infrastructure,
                    external_dependency_missing=False,
                    implementation_integrity_passed=None if infrastructure else False,
                    interface_qualified=None,
                    protocol_feasible=True,
                    measurement_qualified=None,
                    scientific_outcome_observed=False,
                    scientific_gate_passed=None,
                    representation_limit_demonstrated=False,
                ),
                attempt_invocations=tuple(attempted),
            )
        return receipt

    def __call__(self, kernel, domain):
        del domain
        if (
            kernel.mission is None
            or kernel.incumbent is None
            or kernel.next_action().kind != ResearchActionKind.MAP_PHENOMENON
        ):
            raise ValueError("trajectory runner received another frontier")
        binding_path = self.bundle_dir / "fresh-run-binding.json"
        if binding_path.exists():
            return TrajectoryReceiptBundleRunner(self.bundle_dir)(kernel, None)
        attempted: list[ExternalInvocation] = []
        receipts = {}
        prepare = (
            str(self.python_executable),
            "scripts/prepare_cognitive_preanswer_trajectory_v1.py",
            "--project",
            str(self.project_root),
            "--mission-dir",
            str(self.mission_dir),
            "--incumbent-dir",
            str(self.incumbent_bundle_dir),
            "--source-dir",
            str(self.project_root / "third_party/grade-school-math"),
        )
        receipts["prepare"] = self._run_command(
            prepare,
            operation="prepare",
            model_key=None,
            kernel=kernel,
            attempted=attempted,
            charge_compute=False,
            scope=AuthorityScope.EXECUTE,
        )
        protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
        for model_key in MODEL_ORDER:
            command = (
                str(self.python_executable),
                "scripts/run_cognitive_preanswer_trajectory_v1.py",
                "--output",
                str(self.bundle_dir),
                "--phase",
                "screen",
                "--model-key",
                model_key,
            )
            receipts["screen:%s" % model_key] = self._run_command(
                command,
                operation="screen",
                model_key=model_key,
                kernel=kernel,
                attempted=attempted,
                charge_compute=True,
                scope=AuthorityScope.EXECUTE,
            )
        select_command = (
            str(self.python_executable),
            "scripts/run_cognitive_preanswer_trajectory_v1.py",
            "--output",
            str(self.bundle_dir),
            "--phase",
            "select",
        )
        receipts["select"] = self._run_command(
            select_command,
            operation="select",
            model_key=None,
            kernel=kernel,
            attempted=attempted,
            charge_compute=False,
            scope=AuthorityScope.MEASURE,
        )
        for model_key in MODEL_ORDER:
            command = (
                str(self.python_executable),
                "scripts/run_cognitive_preanswer_trajectory_v1.py",
                "--output",
                str(self.bundle_dir),
                "--phase",
                "trajectory",
                "--model-key",
                model_key,
            )
            receipts["trajectory:%s" % model_key] = self._run_command(
                command,
                operation="trajectory",
                model_key=model_key,
                kernel=kernel,
                attempted=attempted,
                charge_compute=True,
                scope=AuthorityScope.EXECUTE,
            )
        selection = _read_json(
            self.bundle_dir / "control/failure-selection-completion.json"
        )
        generation_count = 0
        for model_key in MODEL_ORDER:
            generation_count += int(
                _read_json(
                    self.bundle_dir / ("control/screen-%s-completion.json" % model_key)
                )["receipt_count"]
            )
            generation_count += int(
                _read_json(
                    self.bundle_dir
                    / ("control/trajectory-%s-completion.json" % model_key)
                )["receipt_count"]
            )
        binding_body = {
            "version": BINDING_VERSION,
            "mission_id": kernel.mission.mission_id,
            "incumbent_portfolio_id": kernel.incumbent.portfolio_id,
            "action_id": kernel.next_action().action_id,
            "freeze_id": protocol["freeze_id"],
            "selection_completion_id": selection["completion_id"],
            "command_receipts": receipts,
            "generation_count": generation_count,
            "normalized_compute_definition": "sum of complete local model-process wall seconds",
            "normalized_compute_units": sum(
                float(receipts[key]["wall_seconds"])
                for key in receipts
                if key.startswith("screen:") or key.startswith("trajectory:")
            ),
            "normalized_compute_charge_complete": True,
            "human_interventions": 0,
            "out_of_band_interventions": 0,
            "orchestrated_inside_autonomy_boundary": True,
            "development_qualification_only": True,
            "prospective_nature_evidence_claimed": False,
        }
        binding = {**binding_body, "binding_id": digest(binding_body)}
        _write_immutable(binding_path, binding)
        return TrajectoryReceiptBundleRunner(self.bundle_dir)(kernel, None)


def validate_preanswer_trajectory_output(output, kernel, domain):
    del domain
    atlas = output.artifact
    if not isinstance(atlas, PhenomenonAtlas):
        raise ValueError("trajectory mapper returned another artifact")
    summary = output.details["summary"]
    checks = {
        "artifact_identity": output.artifact_id == atlas.atlas_id,
        "mission_identity": atlas.mission_id == kernel.mission.mission_id,
        "incumbent_identity": atlas.incumbent_portfolio_id
        == kernel.incumbent.portfolio_id,
        "atlas_sealed": atlas.sealed,
        "kernel_readiness": not atlas.readiness_failures(kernel.policy),
        "balanced_24_failure_units": summary["failure_units"] == 24
        and all(value == 12 for value in summary["failure_units_per_model"].values()),
        "three_horizons": len(summary["horizons"]) == 3,
        "three_answer_blind_regimes": len(summary["regimes"]) == 3,
        "reliability_threshold_each_model": all(
            summary["reliability"][key]["coefficient"] >= RELIABILITY_THRESHOLD
            for key in MODEL_ORDER
        ),
        "positive_controls_passed": summary["positive_controls"]["passed"],
        "sham_negative_control_passed": summary["sham_negative_control"]["passed"],
        "opposing_preanswer_effects": summary["positive_effects"] > 0
        and summary["negative_effects"] > 0,
        "all_telemetry_charged": output.details["generation_invocations"] == 216,
        "compute_charge_complete": output.details[
            "normalized_compute_charge_complete"
        ]
        and output.details["normalized_compute_units"] > 0.0,
        "fresh_run_bound": output.details["fresh_run_bound_execution"],
        "nature_evidence_not_claimed": output.details[
            "prospective_nature_evidence_claimed"
        ]
        is False,
    }
    return DeterministicValidationReceipt(
        artifact_id=output.artifact_id,
        verifier_ref=VALIDATOR_REF,
        checks=checks,
        evidence_ids=(
            str(output.details["freeze_id"]),
            str(output.details["fresh_run_binding_id"]),
            str(output.details["selection_completion_id"]),
            str(output.details["evidence_id"]),
            *(str(output.details["completion_ids"][key]) for key in MODEL_ORDER),
        ),
    )


def build_autonomy_bound_preanswer_trajectory_stage_provider(
    *,
    project_root: Path,
    mission_dir: Path,
    incumbent_bundle_dir: Path,
    python_executable: Path,
    command_executor: Callable[
        [Sequence[str], Path], tuple[str, str, int, float]
    ]
    | None = None,
) -> InstrumentValidatorStageProvider:
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.MAP_PHENOMENON,
        runner=AutonomyBoundTrajectoryRunner(
            project_root=project_root,
            mission_dir=mission_dir,
            incumbent_bundle_dir=incumbent_bundle_dir,
            python_executable=python_executable,
            command_executor=command_executor,
        ),
        validator=validate_preanswer_trajectory_output,
        outcome="answer_blind_preanswer_trajectory_atlas_mapped",
        adjudicable_failures=True,
    )


__all__ = [
    "BINDING_VERSION",
    "MEASUREMENT_REF",
    "PROVIDER_VERSION",
    "VALIDATOR_REF",
    "AutonomyBoundTrajectoryRunner",
    "TrajectoryReceiptBundleRunner",
    "build_autonomy_bound_preanswer_trajectory_stage_provider",
    "validate_preanswer_trajectory_output",
]
