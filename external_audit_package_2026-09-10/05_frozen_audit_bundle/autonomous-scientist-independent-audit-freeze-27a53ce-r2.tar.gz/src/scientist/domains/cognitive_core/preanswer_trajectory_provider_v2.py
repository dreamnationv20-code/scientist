from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Callable, Mapping, Sequence

from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.instrument_provider import (
    DeterministicValidationReceipt,
    InstrumentOutput,
    InstrumentValidatorStageProvider,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.domains.cognitive_core.preanswer_trajectory_phenomenon_v1 import (
    MODEL_ORDER,
    RELIABILITY_THRESHOLD,
    VERSION as SCIENTIFIC_VERSION,
    digest,
    file_sha256,
)
from scientist.domains.cognitive_core.preanswer_trajectory_provider_v1 import (
    MEASUREMENT_REF,
    TrajectoryReceiptBundleRunner,
)
from scientist.program.research_kernel import PhenomenonAtlas, ResearchActionKind


PROVIDER_VERSION = "cognitive-preanswer-trajectory-provider-v2"
BINDING_VERSION = "cognitive-preanswer-trajectory-repair-binding-v2"
VALIDATOR_REF = "independent-preanswer-trajectory-repair-validator-v2"


def _read_json(path: Path):
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("expected JSON object: %s" % path)
    return value


def _write_immutable(path: Path, value: Mapping) -> None:
    payload = (
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.read_bytes() != payload:
            raise ValueError("refusing to replace repaired binding: %s" % path)
        return
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _verified(value: Mapping, identity_key: str) -> str:
    body = dict(value)
    supplied = body.pop(identity_key, None)
    if supplied != digest(body):
        raise ValueError("identity mismatch: %s" % identity_key)
    return str(supplied)


def _command_receipt(command, stdout, stderr, returncode, wall_seconds):
    body = {
        "command_digest": digest(list(command)),
        "stdout_digest": digest(stdout),
        "stderr_digest": digest(stderr),
        "returncode": int(returncode),
        "wall_seconds": float(wall_seconds),
    }
    return {**body, "receipt_id": digest(body)}


class RepairedTrajectoryReceiptBundleRunner:
    measurement_ref = MEASUREMENT_REF

    def __init__(self, bundle_dir: Path) -> None:
        self.bundle_dir = Path(bundle_dir).resolve()

    def __call__(self, kernel, domain):
        del domain
        protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
        freeze_id = _verified(protocol, "freeze_id")
        if (
            protocol.get("version") != SCIENTIFIC_VERSION
            or protocol.get("mission_id") != kernel.mission.mission_id
            or protocol.get("incumbent_portfolio_id")
            != kernel.incumbent.portfolio_id
            or protocol.get("action_id") != kernel.next_action().action_id
            or protocol.get("implementation_repair", {}).get(
                "scientific_contract_changed"
            )
            is not False
        ):
            raise ValueError("repaired trajectory protocol is incompatible")
        for source, expected in protocol["source_code_sha256"].items():
            if file_sha256(Path(str(source))) != str(expected):
                raise ValueError("repaired trajectory source changed: %s" % source)
        binding = _read_json(self.bundle_dir / "fresh-run-binding.json")
        binding_id = _verified(binding, "binding_id")
        if any(
            (
                binding.get("version") != BINDING_VERSION,
                binding.get("mission_id") != kernel.mission.mission_id,
                binding.get("incumbent_portfolio_id")
                != kernel.incumbent.portfolio_id,
                binding.get("action_id") != kernel.next_action().action_id,
                binding.get("freeze_id") != freeze_id,
                binding.get("human_interventions") != 0,
                binding.get("out_of_band_interventions") != 0,
                binding.get("screen_reexecution") is not False,
                binding.get("development_qualification_only") is not True,
                binding.get("prospective_nature_evidence_claimed") is not False,
            )
        ):
            raise ValueError("repaired trajectory binding is invalid")
        selection = _read_json(
            Path(str(protocol["failure_selection"]["completion_path"]))
        )
        selection_id = _verified(selection, "completion_id")
        imported = binding["command_receipts"]["prepare"]
        _verified(imported, "receipt_id")
        invocations = [
            ExternalInvocation(
                kind=InvocationKind.TOOL,
                operation="freeze_float32_repair_and_import_blinded_failure_panel",
                actor=ActorIdentity(
                    "preanswer-trajectory-repair-runtime-v2", ActorKind.TOOL_RUNTIME
                ),
                authority_scope=AuthorityScope.IMPORT,
                input_artifact_ids=(
                    str(protocol["implementation_repair"]["source_failed_attempt_id"]),
                    str(protocol["implementation_repair"][
                        "source_selection_completion_id"
                    ]),
                ),
                output_artifact_ids=(
                    str(imported["receipt_id"]),
                    freeze_id,
                    selection_id,
                ),
                usage=ResourceUsage(
                    tool_calls=1, wall_seconds=float(imported["wall_seconds"])
                ),
            )
        ]
        for model_key in MODEL_ORDER:
            receipt = binding["command_receipts"]["trajectory:%s" % model_key]
            _verified(receipt, "receipt_id")
            completion = _read_json(
                self.bundle_dir
                / ("control/trajectory-%s-completion.json" % model_key)
            )
            completion_id = _verified(completion, "completion_id")
            invocations.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="execute_float32_scalar_preanswer_trajectory:%s"
                    % model_key,
                    actor=ActorIdentity(
                        "local-mlx-preanswer-trajectory-runtime-v2:%s" % model_key,
                        ActorKind.TOOL_RUNTIME,
                    ),
                    authority_scope=AuthorityScope.EXECUTE,
                    input_artifact_ids=(
                        freeze_id,
                        protocol["models"][model_key]["identity_id"],
                        selection_id,
                    ),
                    output_artifact_ids=(
                        str(receipt["receipt_id"]),
                        completion_id,
                        str(completion["receipts_sha256"]),
                    ),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=float(receipt["wall_seconds"]),
                        compute_units=float(receipt["wall_seconds"]),
                    ),
                )
            )
        inherited = TrajectoryReceiptBundleRunner(self.bundle_dir)
        _, selected, completion_ids, receipt_hashes, rows_by_model = (
            inherited._load_telemetry(protocol)
        )
        atlas, evidence, summary = inherited._build_atlas(
            kernel, protocol, binding, selected, rows_by_model
        )
        invocations.append(
            ExternalInvocation(
                kind=InvocationKind.TOOL,
                operation="compile_repaired_answer_blind_preanswer_trajectory_atlas",
                actor=ActorIdentity(MEASUREMENT_REF, ActorKind.TOOL_RUNTIME),
                authority_scope=AuthorityScope.MEASURE,
                input_artifact_ids=(
                    freeze_id,
                    binding_id,
                    selection_id,
                    *(completion_ids[key] for key in MODEL_ORDER),
                    *(receipt_hashes[key] for key in MODEL_ORDER),
                ),
                output_artifact_ids=(atlas.atlas_id, str(evidence["evidence_id"])),
                usage=ResourceUsage(tool_calls=1),
            )
        )
        if not summary["reliability_passed"]:
            case = TransitionCase(
                case_ref="trajectory-reliability-stop:%s" % evidence["evidence_id"],
                phase="phenomenon_mapping",
                question="Did both model sizes meet the frozen trajectory-reliability gate?",
                observations=tuple(
                    "%s_reliability=%.8f"
                    % (key, summary["reliability"][key]["coefficient"])
                    for key in MODEL_ORDER
                ),
                available_actions=(
                    RecoveryAction.PARK_BRANCH,
                    RecoveryAction.UPDATE_CAUSAL_THEORY,
                ),
                protected_invariants=(
                    "retain the frozen 0.60 reliability threshold",
                    "retain all completed scalar telemetry receipts",
                    "do not inspect prospective or replication outcomes",
                    "do not recalibrate this mission after the stop result",
                ),
                evidence_refs=(
                    str(evidence["evidence_id"]),
                    *(completion_ids[key] for key in MODEL_ORDER),
                ),
                retrospective=False,
                domain=kernel.mission.domain_id,
            )
            raise AdjudicableResearchFailure(
                "frozen trajectory reliability stop rule fired",
                case=case,
                profile=FailureEvidenceProfile(
                    case_id=case.case_id,
                    runtime_available=True,
                    external_dependency_missing=False,
                    implementation_integrity_passed=True,
                    interface_qualified=True,
                    protocol_feasible=True,
                    measurement_qualified=True,
                    scientific_outcome_observed=True,
                    scientific_gate_passed=False,
                    representation_limit_demonstrated=False,
                ),
                attempt_invocations=tuple(invocations),
            )
        return InstrumentOutput(
            artifact=atlas,
            artifact_id=atlas.atlas_id,
            invocations=tuple(invocations),
            measurement_ref=MEASUREMENT_REF,
            details={
                "provider_version": PROVIDER_VERSION,
                "freeze_id": freeze_id,
                "fresh_run_binding_id": binding_id,
                "selection_completion_id": selection_id,
                "source_selection_completion_id": protocol[
                    "implementation_repair"
                ]["source_selection_completion_id"],
                "completion_ids": completion_ids,
                "receipt_sha256": receipt_hashes,
                "evidence_id": evidence["evidence_id"],
                "summary": summary,
                "generation_invocations": binding["generation_count"],
                "normalized_compute_definition": binding[
                    "normalized_compute_definition"
                ],
                "normalized_compute_units": binding["normalized_compute_units"],
                "normalized_compute_charge_complete": True,
                "fresh_run_bound_execution": True,
                "screen_reexecution": False,
                "prospective_nature_evidence_claimed": False,
            },
        )


class AutonomyBoundRepairedTrajectoryRunner:
    def __init__(
        self,
        *,
        project_root: Path,
        mission_dir: Path,
        failed_bundle_dir: Path,
        failed_manifest_path: Path,
        python_executable: Path,
        command_executor: Callable[
            [Sequence[str], Path], tuple[str, str, int, float]
        ]
        | None = None,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.mission_dir = Path(mission_dir).resolve()
        self.failed_bundle_dir = Path(failed_bundle_dir).resolve()
        self.failed_manifest_path = Path(failed_manifest_path).resolve()
        self.python_executable = Path(python_executable).absolute()
        self.bundle_dir = self.mission_dir / "preanswer_trajectory_v1"
        self.command_executor = command_executor or self._execute

    @staticmethod
    def _execute(command, cwd):
        started = time.perf_counter()
        environment = dict(os.environ)
        existing = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = (
            str(cwd / "src")
            if not existing
            else "%s%s%s" % (str(cwd / "src"), os.pathsep, existing)
        )
        completed = subprocess.run(
            tuple(command),
            cwd=str(cwd),
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )
        return (
            completed.stdout,
            completed.stderr,
            completed.returncode,
            time.perf_counter() - started,
        )

    def _run(self, command, operation, model_key, kernel, attempted, compute):
        stdout, stderr, returncode, elapsed = self.command_executor(
            command, self.project_root
        )
        receipt = _command_receipt(
            command, stdout, stderr, returncode, elapsed
        )
        outputs = [str(receipt["receipt_id"])]
        if returncode == 0:
            if operation == "prepare":
                protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
                selection = _read_json(
                    self.bundle_dir / "control/failure-selection-completion.json"
                )
                outputs.extend((protocol["freeze_id"], selection["completion_id"]))
            else:
                completion = _read_json(
                    self.bundle_dir
                    / ("control/trajectory-%s-completion.json" % model_key)
                )
                outputs.extend(
                    (completion["completion_id"], completion["receipts_sha256"])
                )
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation="%s%s"
            % (operation, "" if model_key is None else ":%s" % model_key),
            actor=ActorIdentity(
                "autonomy-bound-trajectory-repair:%s" % operation,
                ActorKind.TOOL_RUNTIME,
            ),
            authority_scope=(
                AuthorityScope.IMPORT
                if operation == "prepare"
                else AuthorityScope.EXECUTE
            ),
            input_artifact_ids=(
                kernel.mission.mission_id,
                kernel.incumbent.portfolio_id,
            ),
            output_artifact_ids=tuple(outputs),
            usage=ResourceUsage(
                tool_calls=1,
                wall_seconds=elapsed,
                compute_units=elapsed if compute else 0.0,
            ),
        )
        attempted.append(invocation)
        if returncode != 0:
            terminal_boundary = "terminal boundary reached" in stderr
            infrastructure = "No Metal device available" in stderr
            available = (
                (RecoveryAction.PARK_BRANCH, RecoveryAction.AMEND_PROTOCOL)
                if terminal_boundary
                else (RecoveryAction.EXACT_RETRY, RecoveryAction.REPAIR_IMPLEMENTATION)
            )
            case = TransitionCase(
                case_ref="preanswer-trajectory-v2-command-failure:%s:%s"
                % (operation, receipt["receipt_id"]),
                phase="phenomenon_mapping",
                question="Can the repaired frozen trajectory operation complete validly?",
                observations=(
                    "operation=%s" % operation,
                    "model_key=%s" % (model_key or "none"),
                    "returncode=%s" % returncode,
                    "stderr_digest=%s" % receipt["stderr_digest"],
                    "terminal_boundary=%s" % terminal_boundary,
                ),
                available_actions=available,
                protected_invariants=(
                    "mission identity",
                    "carried-forward failure panel",
                    "frozen feature contract and reliability threshold",
                    "completed partial scalar receipts",
                ),
                evidence_refs=tuple(
                    artifact_id
                    for item in attempted
                    for artifact_id in item.output_artifact_ids
                ),
                retrospective=False,
                domain=kernel.mission.domain_id,
            )
            raise AdjudicableResearchFailure(
                "repaired autonomy-bound trajectory command failed",
                case=case,
                profile=FailureEvidenceProfile(
                    case_id=case.case_id,
                    runtime_available=not infrastructure,
                    external_dependency_missing=False,
                    implementation_integrity_passed=(
                        True if terminal_boundary else None if infrastructure else False
                    ),
                    interface_qualified=True if terminal_boundary else None,
                    protocol_feasible=False if terminal_boundary else True,
                    measurement_qualified=None,
                    scientific_outcome_observed=False,
                    scientific_gate_passed=None,
                    representation_limit_demonstrated=False,
                ),
                attempt_invocations=tuple(attempted),
            )
        return receipt

    def __call__(self, kernel, domain):
        del domain
        if kernel.next_action().kind != ResearchActionKind.MAP_PHENOMENON:
            raise ValueError("repaired trajectory runner received another action")
        binding_path = self.bundle_dir / "fresh-run-binding.json"
        if binding_path.exists():
            return RepairedTrajectoryReceiptBundleRunner(self.bundle_dir)(kernel, None)
        attempted = []
        receipts = {}
        command = (
            str(self.python_executable),
            "scripts/prepare_cognitive_preanswer_trajectory_repair_v2.py",
            "--project",
            str(self.project_root),
            "--mission-dir",
            str(self.mission_dir),
            "--failed-bundle",
            str(self.failed_bundle_dir),
            "--failed-manifest",
            str(self.failed_manifest_path),
        )
        receipts["prepare"] = self._run(
            command, "prepare", None, kernel, attempted, False
        )
        protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
        for model_key in MODEL_ORDER:
            command = (
                str(self.python_executable),
                "scripts/run_cognitive_preanswer_trajectory_repair_v2.py",
                "--output",
                str(self.bundle_dir),
                "--model-key",
                model_key,
            )
            receipts["trajectory:%s" % model_key] = self._run(
                command, "trajectory", model_key, kernel, attempted, True
            )
        generation_count = sum(
            int(
                _read_json(
                    self.bundle_dir
                    / ("control/trajectory-%s-completion.json" % model_key)
                )["receipt_count"]
            )
            for model_key in MODEL_ORDER
        )
        selection = _read_json(
            self.bundle_dir / "control/failure-selection-completion.json"
        )
        binding_body = {
            "version": BINDING_VERSION,
            "mission_id": kernel.mission.mission_id,
            "incumbent_portfolio_id": kernel.incumbent.portfolio_id,
            "action_id": kernel.next_action().action_id,
            "freeze_id": protocol["freeze_id"],
            "selection_completion_id": selection["completion_id"],
            "source_selection_completion_id": protocol["implementation_repair"][
                "source_selection_completion_id"
            ],
            "command_receipts": receipts,
            "generation_count": generation_count,
            "normalized_compute_definition": (
                "sum of complete repaired local trajectory-process wall seconds"
            ),
            "normalized_compute_units": sum(
                float(receipts["trajectory:%s" % key]["wall_seconds"])
                for key in MODEL_ORDER
            ),
            "normalized_compute_charge_complete": True,
            "screen_reexecution": False,
            "human_interventions": 0,
            "out_of_band_interventions": 0,
            "orchestrated_inside_autonomy_boundary": True,
            "development_qualification_only": True,
            "prospective_nature_evidence_claimed": False,
        }
        binding = {**binding_body, "binding_id": digest(binding_body)}
        _write_immutable(binding_path, binding)
        return RepairedTrajectoryReceiptBundleRunner(self.bundle_dir)(kernel, None)


def validate_repaired_preanswer_trajectory(output, kernel, domain):
    del domain
    atlas = output.artifact
    if not isinstance(atlas, PhenomenonAtlas):
        raise ValueError("repaired trajectory mapper returned another artifact")
    summary = output.details["summary"]
    checks = {
        "artifact_identity": output.artifact_id == atlas.atlas_id,
        "mission_identity": atlas.mission_id == kernel.mission.mission_id,
        "incumbent_identity": atlas.incumbent_portfolio_id
        == kernel.incumbent.portfolio_id,
        "atlas_sealed": atlas.sealed,
        "kernel_readiness": not atlas.readiness_failures(kernel.policy),
        "balanced_24_failure_units": summary["failure_units"] == 24
        and all(value == 12 for value in summary["failure_units_per_model"].values()),
        "three_horizons": len(summary["horizons"]) == 3,
        "three_answer_blind_regimes": len(summary["regimes"]) == 3,
        "reliability_threshold_each_model": all(
            summary["reliability"][key]["coefficient"] >= RELIABILITY_THRESHOLD
            for key in MODEL_ORDER
        ),
        "positive_controls_passed": summary["positive_controls"]["passed"],
        "sham_negative_control_passed": summary["sham_negative_control"]["passed"],
        "opposing_preanswer_effects": summary["positive_effects"] > 0
        and summary["negative_effects"] > 0,
        "all_repaired_telemetry_charged": output.details[
            "generation_invocations"
        ]
        == 120,
        "screen_not_reexecuted": output.details["screen_reexecution"] is False,
        "compute_charge_complete": output.details[
            "normalized_compute_charge_complete"
        ]
        and output.details["normalized_compute_units"] > 0.0,
        "fresh_run_bound": output.details["fresh_run_bound_execution"],
        "nature_evidence_not_claimed": output.details[
            "prospective_nature_evidence_claimed"
        ]
        is False,
    }
    return DeterministicValidationReceipt(
        artifact_id=output.artifact_id,
        verifier_ref=VALIDATOR_REF,
        checks=checks,
        evidence_ids=(
            str(output.details["freeze_id"]),
            str(output.details["fresh_run_binding_id"]),
            str(output.details["source_selection_completion_id"]),
            str(output.details["selection_completion_id"]),
            str(output.details["evidence_id"]),
            *(str(output.details["completion_ids"][key]) for key in MODEL_ORDER),
        ),
    )


def build_autonomy_bound_repaired_preanswer_trajectory_stage_provider(
    *,
    project_root: Path,
    mission_dir: Path,
    failed_bundle_dir: Path,
    failed_manifest_path: Path,
    python_executable: Path,
    command_executor: Callable[
        [Sequence[str], Path], tuple[str, str, int, float]
    ]
    | None = None,
):
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.MAP_PHENOMENON,
        runner=AutonomyBoundRepairedTrajectoryRunner(
            project_root=project_root,
            mission_dir=mission_dir,
            failed_bundle_dir=failed_bundle_dir,
            failed_manifest_path=failed_manifest_path,
            python_executable=python_executable,
            command_executor=command_executor,
        ),
        validator=validate_repaired_preanswer_trajectory,
        outcome="answer_blind_preanswer_trajectory_atlas_mapped_after_float32_repair",
        adjudicable_failures=True,
    )


__all__ = [
    "BINDING_VERSION",
    "PROVIDER_VERSION",
    "VALIDATOR_REF",
    "AutonomyBoundRepairedTrajectoryRunner",
    "RepairedTrajectoryReceiptBundleRunner",
    "build_autonomy_bound_repaired_preanswer_trajectory_stage_provider",
    "validate_repaired_preanswer_trajectory",
]
