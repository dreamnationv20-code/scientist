from __future__ import annotations

from pathlib import Path
from typing import Callable, Sequence

from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.instrument_provider import (
    DeterministicValidationReceipt,
    InstrumentValidatorStageProvider,
)
from scientist.autonomy.state import ActorIdentity, ActorKind, AuthorityScope, ResourceUsage
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.domains.cognitive_core.preanswer_trajectory_provider_v2 import (
    AutonomyBoundRepairedTrajectoryRunner,
    validate_repaired_preanswer_trajectory,
)
from scientist.program.research_kernel import ResearchActionKind


PROVIDER_VERSION = "cognitive-preanswer-trajectory-provider-v3"
VALIDATOR_REF = "independent-preanswer-trajectory-repair-validator-v3"


class QualifiedAutonomyBoundRepairedTrajectoryRunner(
    AutonomyBoundRepairedTrajectoryRunner
):
    """V3 governance repair: tool carry-forward uses executable tool authority."""

    def _run(self, command, operation, model_key, kernel, attempted, compute):
        if operation != "prepare":
            return super()._run(
                command, operation, model_key, kernel, attempted, compute
            )
        command = tuple(command)
        mutable = list(command)
        mutable[1] = "scripts/prepare_cognitive_preanswer_trajectory_repair_v3.py"
        command = tuple(mutable)
        stdout, stderr, returncode, elapsed = self.command_executor(
            command, self.project_root
        )
        from scientist.domains.cognitive_core.preanswer_trajectory_provider_v2 import (
            _command_receipt,
            _read_json,
        )

        receipt = _command_receipt(
            command, stdout, stderr, returncode, elapsed
        )
        outputs = [str(receipt["receipt_id"])]
        if returncode == 0:
            protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
            selection = _read_json(
                self.bundle_dir / "control/failure-selection-completion.json"
            )
            outputs.extend((protocol["freeze_id"], selection["completion_id"]))
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation="prepare",
            actor=ActorIdentity(
                "autonomy-bound-trajectory-repair:prepare-v3",
                ActorKind.TOOL_RUNTIME,
            ),
            authority_scope=AuthorityScope.EXECUTE,
            input_artifact_ids=(
                kernel.mission.mission_id,
                kernel.incumbent.portfolio_id,
            ),
            output_artifact_ids=tuple(outputs),
            usage=ResourceUsage(tool_calls=1, wall_seconds=elapsed),
        )
        attempted.append(invocation)
        if returncode != 0:
            case = TransitionCase(
                case_ref="preanswer-trajectory-v3-prepare-failure:%s"
                % receipt["receipt_id"],
                phase="phenomenon_mapping",
                question="Can the frozen implementation-repair protocol be prepared?",
                observations=(
                    "returncode=%s" % returncode,
                    "stderr_digest=%s" % receipt["stderr_digest"],
                ),
                available_actions=(RecoveryAction.REPAIR_IMPLEMENTATION,),
                protected_invariants=(
                    "mission identity",
                    "carried-forward failure panel",
                    "frozen feature contract",
                ),
                evidence_refs=tuple(outputs),
                retrospective=False,
                domain=kernel.mission.domain_id,
            )
            raise AdjudicableResearchFailure(
                "trajectory repair preparation failed",
                case=case,
                profile=FailureEvidenceProfile(
                    case_id=case.case_id,
                    runtime_available=True,
                    external_dependency_missing=False,
                    implementation_integrity_passed=False,
                    interface_qualified=None,
                    protocol_feasible=True,
                    measurement_qualified=None,
                    scientific_outcome_observed=False,
                    scientific_gate_passed=None,
                    representation_limit_demonstrated=False,
                ),
                attempt_invocations=tuple(attempted),
            )
        return receipt


def validate_qualified_repaired_preanswer_trajectory(output, kernel, domain):
    prior = validate_repaired_preanswer_trajectory(output, kernel, domain)
    return DeterministicValidationReceipt(
        artifact_id=prior.artifact_id,
        verifier_ref=VALIDATOR_REF,
        checks=prior.checks,
        evidence_ids=prior.evidence_ids,
    )


def build_qualified_autonomy_bound_repaired_preanswer_trajectory_stage_provider(
    *,
    project_root: Path,
    mission_dir: Path,
    failed_bundle_dir: Path,
    failed_manifest_path: Path,
    python_executable: Path,
    command_executor: Callable[
        [Sequence[str], Path], tuple[str, str, int, float]
    ]
    | None = None,
):
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.MAP_PHENOMENON,
        runner=QualifiedAutonomyBoundRepairedTrajectoryRunner(
            project_root=project_root,
            mission_dir=mission_dir,
            failed_bundle_dir=failed_bundle_dir,
            failed_manifest_path=failed_manifest_path,
            python_executable=python_executable,
            command_executor=command_executor,
        ),
        validator=validate_qualified_repaired_preanswer_trajectory,
        outcome=(
            "answer_blind_preanswer_trajectory_atlas_mapped_after_qualified_repair"
        ),
        adjudicable_failures=True,
    )


__all__ = [
    "PROVIDER_VERSION",
    "VALIDATOR_REF",
    "QualifiedAutonomyBoundRepairedTrajectoryRunner",
    "build_qualified_autonomy_bound_repaired_preanswer_trajectory_stage_provider",
    "validate_qualified_repaired_preanswer_trajectory",
]
