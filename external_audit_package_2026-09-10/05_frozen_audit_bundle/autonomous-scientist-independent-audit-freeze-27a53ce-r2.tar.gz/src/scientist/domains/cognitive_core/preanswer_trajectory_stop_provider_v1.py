from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Mapping

from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.state import ActorIdentity, ActorKind, AuthorityScope, ResourceUsage
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.preanswer_trajectory_phenomenon_v1 import (
    MODEL_ORDER,
    REAL_CONDITIONS,
    RELIABILITY_THRESHOLD,
    digest,
    file_sha256,
    trajectory_reliability,
    validate_feature_receipt_keys,
)
from scientist.program.research_kernel import ResearchActionKind


VERSION = "cognitive-preanswer-trajectory-scientific-stop-v1"
ANALYST_REF = "independent-single-model-reliability-stop-auditor-v1"


def _read_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("expected JSON object: %s" % path)
    return value


def _read_jsonl(path: Path) -> list[Mapping[str, Any]]:
    values = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if any(not isinstance(value, Mapping) for value in values):
        raise ValueError("expected JSON-object rows: %s" % path)
    return values


def _verified(value: Mapping[str, Any], identity_key: str) -> str:
    body = dict(value)
    supplied = body.pop(identity_key, None)
    if supplied != content_digest(body):
        raise ValueError("identity mismatch: %s" % identity_key)
    return str(supplied)


def _write_immutable(path: Path, value: Mapping[str, Any]) -> None:
    payload = (
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.read_bytes() != payload:
            raise ValueError("refusing to replace scientific-stop certificate")
        return
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


class PreanswerTrajectoryScientificStopProvider:
    """Apply a frozen early stop as soon as one complete model fails reliability."""

    def __init__(self, *, source_run: Path, mission_dir: Path) -> None:
        self.source_run = Path(source_run).resolve()
        self.mission_dir = Path(mission_dir).resolve()

    def __call__(self, action, kernel, domain, component_ref):
        del domain, component_ref
        if (
            action.kind != ResearchActionKind.MAP_PHENOMENON
            or kernel.mission is None
            or kernel.incumbent is None
        ):
            raise ValueError("trajectory stop auditor received another frontier")
        failed_manifest_path = (
            self.source_run
            / "artifacts/manifests/"
            / "cognitive-preanswer-trajectory-v3-qualification-v1-failed-attempt.json"
        )
        failed_manifest = _read_json(failed_manifest_path)
        failed_attempt_id = _verified(failed_manifest, "attempt_id")
        if any(
            (
                failed_manifest.get("mission_id") != kernel.mission.mission_id,
                failed_manifest.get("passed") is not False,
                failed_manifest.get("boundary")
                != "recovery_amend_protocol_required",
                failed_manifest.get("scientific_stop_summary") is not None,
                failed_manifest.get("confirmatory_outcomes_unopened") is not True,
            )
        ):
            raise ValueError("source run is not the qualified protocol failure")
        bundle = self.source_run / "preanswer_trajectory_v1"
        protocol = _read_json(bundle / "protocol-freeze.json")
        freeze_id = _verified(protocol, "freeze_id")
        for source, expected in protocol["source_code_sha256"].items():
            if file_sha256(Path(str(source))) != str(expected):
                raise ValueError("source run code changed: %s" % source)
        model_key = MODEL_ORDER[0]
        completion = _read_json(
            bundle / ("control/trajectory-%s-completion.json" % model_key)
        )
        completion_id = _verified(completion, "completion_id")
        receipts_path = Path(str(completion["receipts_path"]))
        rows = _read_jsonl(receipts_path)
        expected_receipts = 12 * (len(REAL_CONDITIONS) + 1)
        keys = {
            (
                str(row["unit_id"]),
                str(row["condition"]),
                str(row["paraphrase"]),
                int(row["seed_index"]),
            )
            for row in rows
        }
        if any(
            (
                completion.get("status")
                != "scalar_preanswer_trajectory_matrix_complete",
                completion.get("freeze_id") != freeze_id,
                completion.get("receipt_count") != expected_receipts,
                len(rows) != expected_receipts,
                len(keys) != expected_receipts,
                file_sha256(receipts_path) != completion["receipts_sha256"],
                completion.get("terminal_boundaries_detected") != 0,
                completion.get("serialized_generated_text") is not False,
                completion.get("serialized_generated_token_identities") is not False,
            )
        ):
            raise ValueError("complete first-model telemetry is invalid")
        for row in rows:
            body = {key: value for key, value in row.items() if key != "receipt_id"}
            if row.get("receipt_id") != digest(body):
                raise ValueError("first-model trajectory receipt identity mismatch")
            validate_feature_receipt_keys(body)
        reliability = trajectory_reliability(rows)
        if (
            reliability["threshold"] != RELIABILITY_THRESHOLD
            or reliability["coefficient"] >= RELIABILITY_THRESHOLD
            or reliability["passed"] is not False
        ):
            raise ValueError("source model does not establish the frozen stop rule")
        certificate_body = {
            "version": VERSION,
            "mission_id": kernel.mission.mission_id,
            "claim_signature_id": kernel.mission.claim_signature.signature_id,
            "incumbent_portfolio_id": kernel.incumbent.portfolio_id,
            "source_failed_attempt_id": failed_attempt_id,
            "source_protocol_freeze_id": freeze_id,
            "source_model_key": model_key,
            "source_completion_id": completion_id,
            "source_receipts_sha256": completion["receipts_sha256"],
            "reliability": reliability,
            "frozen_stop_rule": (
                "stop mission if trajectory reliability is below 0.60 in either model"
            ),
            "stop_rule_triggered": True,
            "remaining_model_required_for_decision": False,
            "incomplete_second_model_excluded": True,
            "protocol_amendment_after_stop_forbidden": True,
            "disposition": "update_causal_theory",
            "scientific_interpretation": (
                "The preregistered convergence fingerprint is not stable across "
                "semantic-preserving prompt frames in the 1.7B model. It is therefore "
                "not eligible for calibration or prospective testing."
            ),
            "development_only": True,
            "confirmatory_outcomes_unopened": True,
            "prospective_nature_evidence_claimed": False,
            "analyst_ref": ANALYST_REF,
        }
        certificate = {
            **certificate_body,
            "stop_certificate_id": content_digest(certificate_body),
        }
        certificate_path = (
            self.mission_dir / "trajectory_scientific_stop_v1/certificate.json"
        )
        _write_immutable(certificate_path, certificate)
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation="independently_reconstruct_first_model_reliability_and_apply_stop",
            actor=ActorIdentity(ANALYST_REF, ActorKind.TOOL_RUNTIME),
            authority_scope=AuthorityScope.MEASURE,
            input_artifact_ids=(
                failed_attempt_id,
                freeze_id,
                completion_id,
                str(completion["receipts_sha256"]),
            ),
            output_artifact_ids=(str(certificate["stop_certificate_id"]),),
            usage=ResourceUsage(tool_calls=1),
        )
        case = TransitionCase(
            case_ref="preanswer-trajectory-reliability-scientific-stop:%s"
            % certificate["stop_certificate_id"],
            phase="phenomenon_mapping",
            question=(
                "May the trajectory hypothesis proceed after the first complete "
                "model failed its frozen reliability threshold?"
            ),
            observations=(
                "model_key=%s" % model_key,
                "reliability=%.12f" % reliability["coefficient"],
                "threshold=%.2f" % RELIABILITY_THRESHOLD,
                "pairwise_comparisons=%d" % len(reliability["pairwise"]),
                "second_model_incomplete_and_excluded=true",
            ),
            available_actions=(RecoveryAction.UPDATE_CAUSAL_THEORY,),
            protected_invariants=(
                "retain the frozen 0.60 reliability threshold",
                "retain the 2x2 seed-paraphrase repeat definition",
                "do not amend checkpoints after the stop result",
                "exclude incomplete second-model telemetry",
                "do not open prospective or replication outcomes",
            ),
            evidence_refs=(
                str(certificate["stop_certificate_id"]),
                completion_id,
                str(completion["receipts_sha256"]),
            ),
            retrospective=False,
            domain=kernel.mission.domain_id,
        )
        raise AdjudicableResearchFailure(
            "frozen trajectory reliability gate failed in the first complete model",
            case=case,
            profile=FailureEvidenceProfile(
                case_id=case.case_id,
                runtime_available=True,
                external_dependency_missing=False,
                implementation_integrity_passed=True,
                interface_qualified=True,
                protocol_feasible=True,
                measurement_qualified=True,
                scientific_outcome_observed=True,
                scientific_gate_passed=False,
                representation_limit_demonstrated=False,
            ),
            attempt_invocations=(invocation,),
        )


__all__ = [
    "ANALYST_REF",
    "VERSION",
    "PreanswerTrajectoryScientificStopProvider",
]
