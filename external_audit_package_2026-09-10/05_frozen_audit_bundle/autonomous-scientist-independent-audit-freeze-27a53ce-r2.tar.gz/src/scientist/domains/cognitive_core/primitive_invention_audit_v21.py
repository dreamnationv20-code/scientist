from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import MetaExample
from scientist.domains.cognitive_core.primitive_invention_v21 import (
    PRIMITIVE_INVENTION_VERSION,
    PrimitiveTask,
)


PRIMITIVE_AUDIT_AUTHORITY_REF = "sealed-primitive-invention-audit-v21"


@dataclass(frozen=True)
class PrimitiveAuditCommitment:
    seeds: Tuple[int, ...]
    tasks_per_family: int
    sealed_spec_digest: str
    rule: str

    @property
    def commitment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": PRIMITIVE_INVENTION_VERSION,
            "seeds": list(self.seeds),
            "tasks_per_family": self.tasks_per_family,
            "sealed_spec_digest": self.sealed_spec_digest,
            "rule": self.rule,
            "authority_ref": PRIMITIVE_AUDIT_AUTHORITY_REF,
        }
        if include_id:
            value["commitment_id"] = self.commitment_id
        return value


@dataclass(frozen=True)
class PrimitiveAuditMaterialization:
    commitment: PrimitiveAuditCommitment
    candidate_freeze_id: str
    tasks: Tuple[PrimitiveTask, ...]
    materialization_stage: int

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": PRIMITIVE_INVENTION_VERSION,
            "commitment": self.commitment.as_dict(),
            "candidate_freeze_id": self.candidate_freeze_id,
            # Candidate-visible fields are persisted separately from evaluator fields.
            "candidate_tasks": [item.candidate_view() for item in self.tasks],
            "evaluator_task_digests": [
                content_digest(
                    {
                        "task_id": item.task_id,
                        "family": item.evaluator_family,
                        "hidden_outputs": dict(item.hidden_outputs),
                    }
                )
                for item in self.tasks
            ],
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


class PrimitiveInventionAuditAuthority:
    def __init__(
        self,
        seeds: Tuple[int, ...] = (2111, 2131, 2141, 2161, 2179),
        tasks_per_family: int = 6,
    ) -> None:
        if len(seeds) < 5 or tasks_per_family < 4:
            raise ValueError("primitive audit requires five seeds and four tasks per family")
        self._seeds = seeds
        self._tasks_per_family = tasks_per_family
        self._sealed_spec = {
            "seeds": seeds,
            "tasks_per_family": tasks_per_family,
            "families": ("alternating_partition", "ordered_partition"),
            "domain": tuple(range(16)),
            "holdouts_per_task": 4,
            "authority": PRIMITIVE_AUDIT_AUTHORITY_REF,
        }
        self.commitment = PrimitiveAuditCommitment(
            seeds,
            tasks_per_family,
            content_digest(self._sealed_spec),
            "commit before candidate freeze; materialize hidden tasks after freeze",
        )
        self._materialized = False

    @staticmethod
    def _task(seed: int, index: int, family: str) -> PrimitiveTask:
        rng = random.Random(seed * 1009 + index * 917 + (0 if family == "alternating_partition" else 1))
        domain = tuple(range(16))
        if family == "alternating_partition":
            slopes = (rng.choice((-3, -2, 2, 3)), rng.choice((-4, -1, 1, 4)))
            if slopes[0] == slopes[1]:
                slopes = (slopes[0], slopes[1] + 1)
            intercepts = (rng.randint(-7, 7), rng.randint(-7, 7))

            def oracle(x: int) -> int:
                branch = 0 if x % 2 == 0 else 1
                return slopes[branch] * x + intercepts[branch]

            even_hidden = rng.sample([2, 4, 10, 12], 2)
            odd_hidden = rng.sample([3, 5, 11, 13], 2)
            hidden = set((*even_hidden, *odd_hidden))
        else:
            threshold = rng.randint(6, 10)
            slopes = (rng.choice((-3, -2, 2, 3)), rng.choice((-4, -1, 1, 4)))
            if slopes[0] == slopes[1]:
                slopes = (slopes[0], slopes[1] + 1)
            intercepts = (rng.randint(-7, 7), rng.randint(-7, 7))

            def oracle(x: int) -> int:
                branch = 0 if x < threshold else 1
                return slopes[branch] * x + intercepts[branch]

            eligible = [x for x in domain if x not in (threshold - 1, threshold)]
            lower = [x for x in eligible if x < threshold]
            upper = [x for x in eligible if x >= threshold]
            hidden = set((*rng.sample(lower, 2), *rng.sample(upper, 2)))
        visible = tuple(
            MetaExample((x,), oracle(x)) for x in domain if x not in hidden
        )
        hidden_outputs = {x: oracle(x) for x in sorted(hidden)}
        return PrimitiveTask(
            content_digest(
                {
                    "authority": PRIMITIVE_AUDIT_AUTHORITY_REF,
                    "seed": seed,
                    "index": index,
                    "family": family,
                }
            ),
            visible,
            domain,
            hidden_outputs,
            family,
        )

    def materialize(
        self, candidate_freeze_id: str, *, materialization_stage: int = 5
    ) -> PrimitiveAuditMaterialization:
        if self._materialized:
            raise ValueError("primitive audit may be materialized only once")
        if not candidate_freeze_id:
            raise ValueError("candidate freeze identity is required")
        tasks = tuple(
            self._task(seed, index, family)
            for seed in self._seeds
            for family in self._sealed_spec["families"]
            for index in range(self._tasks_per_family)
        )
        self._materialized = True
        return PrimitiveAuditMaterialization(
            self.commitment, candidate_freeze_id, tasks, materialization_stage
        )

    def verify(self, value: PrimitiveAuditMaterialization) -> bool:
        return (
            value.commitment == self.commitment
            and self.commitment.sealed_spec_digest == content_digest(self._sealed_spec)
            and value.candidate_freeze_id != ""
        )


def build_primitive_development_tasks() -> Tuple[PrimitiveTask, ...]:
    return tuple(
        PrimitiveInventionAuditAuthority._task(2099, index, family)
        for family in ("alternating_partition", "ordered_partition")
        for index in range(2)
    )
