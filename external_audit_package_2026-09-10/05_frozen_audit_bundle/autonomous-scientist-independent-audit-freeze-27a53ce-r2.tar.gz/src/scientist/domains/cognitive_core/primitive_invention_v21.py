from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import MetaExample
from scientist.domains.cognitive_core.self_supervised_schema_induction_v20 import (
    UniversalSchemaGrammar,
    execute_schema,
    synthesize_schema,
)


PRIMITIVE_INVENTION_VERSION = "cognitive-core-primitive-invention-v21"


@dataclass(frozen=True)
class PredicateProgram:
    """A candidate-created, executable partition of an integer domain."""

    operator: str
    arguments: Tuple[int, ...]

    def evaluate(self, value: int) -> bool:
        if self.operator == "remainder_class":
            divisor, residue = self.arguments
            return value % divisor == residue
        if self.operator == "ordered_cut":
            (threshold,) = self.arguments
            return value < threshold
        raise ValueError("unknown predicate program")

    @property
    def complexity(self) -> int:
        return 1 + len(self.arguments)

    def as_dict(self) -> Dict[str, object]:
        return {"operator": self.operator, "arguments": list(self.arguments)}


@dataclass(frozen=True)
class AffineBranch:
    slope: int
    intercept: int

    def evaluate(self, value: int) -> int:
        return self.slope * value + self.intercept

    def as_dict(self) -> Dict[str, int]:
        return {"slope": self.slope, "intercept": self.intercept}


@dataclass(frozen=True)
class InventedPrimitive:
    """An object-language operator assembled from generic typed constructors.

    ``guarded_dispatch`` is deliberately absent from the Milestone 20 grammar.
    Its predicate and both branch laws are inferred from behavioral contrasts;
    no evaluator family or target operator name enters the candidate interface.
    """

    operator: str
    predicate: PredicateProgram
    when_true: AffineBranch
    when_false: AffineBranch
    origin: str = "behavioral_contrast_composition"

    def evaluate(self, value: int) -> int:
        branch = self.when_true if self.predicate.evaluate(value) else self.when_false
        return branch.evaluate(value)

    @property
    def program_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def complexity(self) -> int:
        return 1 + self.predicate.complexity + 4

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": PRIMITIVE_INVENTION_VERSION,
            "operator": self.operator,
            "predicate": self.predicate.as_dict(),
            "when_true": self.when_true.as_dict(),
            "when_false": self.when_false.as_dict(),
            "origin": self.origin,
            "complexity": self.complexity,
        }
        if include_id:
            value["program_id"] = self.program_id
        return value


@dataclass(frozen=True)
class PrimitiveInventionTrace:
    example_digest: str
    domain: Tuple[int, ...]
    baseline_schema_id: str | None
    baseline_coverage: float
    predicate_candidates: int
    fitting_programs: int
    distinct_fitting_behaviors: int
    selected: InventedPrimitive | None
    contrast_pairs: Tuple[Tuple[int, int], ...]

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": PRIMITIVE_INVENTION_VERSION,
            "example_digest": self.example_digest,
            "domain": list(self.domain),
            "baseline_schema_id": self.baseline_schema_id,
            "baseline_coverage": self.baseline_coverage,
            "predicate_candidates": self.predicate_candidates,
            "fitting_programs": self.fitting_programs,
            "distinct_fitting_behaviors": self.distinct_fitting_behaviors,
            "selected": None if self.selected is None else self.selected.as_dict(),
            "contrast_pairs": [list(item) for item in self.contrast_pairs],
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


@dataclass(frozen=True)
class PrimitiveCoreFreeze:
    meta_grammar: Mapping[str, object]
    development_trace_ids: Tuple[str, ...]
    inventor_source_digest: str
    source_v20_grammar_id: str
    freeze_stage: int = 4

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": PRIMITIVE_INVENTION_VERSION,
            "meta_grammar": dict(self.meta_grammar),
            "development_trace_ids": list(self.development_trace_ids),
            "inventor_source_digest": self.inventor_source_digest,
            "source_v20_grammar_id": self.source_v20_grammar_id,
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_primitive_core(
    development_traces: Mapping[str, PrimitiveInventionTrace],
    *,
    inventor_source_digest: str,
    freeze_stage: int = 4,
) -> PrimitiveCoreFreeze:
    if not development_traces or any(
        trace.selected is None for trace in development_traces.values()
    ):
        raise ValueError("primitive core may freeze only after development invention")
    grammar = UniversalSchemaGrammar()
    return PrimitiveCoreFreeze(
        {
            "predicate_constructors": ["remainder_class", "ordered_cut"],
            "branch_constructor": "integer_affine",
            "composition_constructor": "typed_binary_partition",
            "selection": "unique_behavior_then_minimum_complexity",
        },
        tuple(sorted(trace.trace_id for trace in development_traces.values())),
        inventor_source_digest,
        grammar.grammar_id,
        freeze_stage,
    )


def _fit_affine(rows: Sequence[MetaExample]) -> AffineBranch | None:
    points = sorted({(int(item.inputs[0]), int(item.output)) for item in rows})
    if len(points) < 2:
        return None
    left = points[0]
    right = next((item for item in points[1:] if item[0] != left[0]), None)
    if right is None:
        return None
    numerator = right[1] - left[1]
    denominator = right[0] - left[0]
    if numerator % denominator:
        return None
    slope = numerator // denominator
    intercept = left[1] - slope * left[0]
    candidate = AffineBranch(slope, intercept)
    return candidate if all(candidate.evaluate(x) == y for x, y in points) else None


def enumerate_predicates(domain: Sequence[int]) -> Tuple[PredicateProgram, ...]:
    values = tuple(sorted(set(int(value) for value in domain)))
    candidates = {
        PredicateProgram("remainder_class", (divisor, residue))
        for divisor in range(2, 5)
        for residue in range(divisor)
    }
    candidates.update(
        PredicateProgram("ordered_cut", (threshold,))
        for threshold in values[1:]
    )
    # Eliminate constant partitions and semantic duplicates. This is a generic
    # observational quotient, not a task-family dispatch.
    by_signature: Dict[Tuple[bool, ...], PredicateProgram] = {}
    for candidate in sorted(candidates, key=lambda item: (item.complexity, item.operator, item.arguments)):
        signature = tuple(candidate.evaluate(value) for value in values)
        if any(signature) and not all(signature):
            by_signature.setdefault(signature, candidate)
    return tuple(by_signature[key] for key in sorted(by_signature))


def _behavior(program: InventedPrimitive, domain: Sequence[int]) -> Tuple[int, ...]:
    return tuple(program.evaluate(value) for value in domain)


def enumerate_fitting_primitives(
    examples: Sequence[MetaExample], domain: Sequence[int]
) -> Tuple[InventedPrimitive, ...]:
    """Return one minimum-complexity program per distinct domain behavior."""

    visible = tuple(examples)
    values = tuple(sorted(set(int(value) for value in domain)))
    fitting = []
    for predicate in enumerate_predicates(values):
        true_rows = tuple(
            item for item in visible if predicate.evaluate(int(item.inputs[0]))
        )
        false_rows = tuple(
            item for item in visible if not predicate.evaluate(int(item.inputs[0]))
        )
        true_branch = _fit_affine(true_rows)
        false_branch = _fit_affine(false_rows)
        if true_branch is None or false_branch is None:
            continue
        program = InventedPrimitive(
            "guarded_dispatch", predicate, true_branch, false_branch
        )
        if all(
            program.evaluate(int(item.inputs[0])) == item.output for item in visible
        ):
            fitting.append(program)
    by_behavior: Dict[Tuple[int, ...], InventedPrimitive] = {}
    for item in sorted(
        fitting,
        key=lambda value: (value.complexity, value.program_id),
    ):
        by_behavior.setdefault(_behavior(item, values), item)
    return tuple(by_behavior[key] for key in sorted(by_behavior))


def _contrast_pairs(examples: Sequence[MetaExample]) -> Tuple[Tuple[int, int], ...]:
    rows = sorted((int(item.inputs[0]), int(item.output)) for item in examples)
    pairs = []
    for (left_x, left_y), (right_x, right_y) in zip(rows, rows[1:]):
        if right_y - left_y != left_y - rows[max(0, rows.index((left_x, left_y)) - 1)][1]:
            pairs.append((left_x, right_x))
    return tuple(pairs)


def invent_primitive(
    examples: Sequence[MetaExample],
    domain: Sequence[int],
) -> PrimitiveInventionTrace:
    """Invent the smallest unique contrast program that explains examples.

    The candidate receives only input/output examples and the legal query domain.
    It first tries the frozen V20 grammar. It then composes a new typed operator
    only when the old grammar leaves part of that domain undefined.
    """

    visible = tuple(examples)
    values = tuple(sorted(set(int(value) for value in domain)))
    grammar = UniversalSchemaGrammar()
    baseline = synthesize_schema(visible, (), {}, grammar).selected
    baseline_predictions = (
        tuple(execute_schema(baseline, (value,), ())[0] for value in values)
        if baseline is not None
        else (None,) * len(values)
    )
    baseline_coverage = sum(value is not None for value in baseline_predictions) / len(values)
    predicates = enumerate_predicates(values)
    distinct_fitting = enumerate_fitting_primitives(visible, values)
    selected = None
    if baseline_coverage < 1.0 and len(distinct_fitting) == 1:
        selected = distinct_fitting[0]
    return PrimitiveInventionTrace(
        content_digest([item.as_dict() for item in visible]),
        values,
        None if baseline is None else baseline.node_id,
        baseline_coverage,
        len(predicates),
        len(distinct_fitting),
        len(distinct_fitting),
        selected,
        _contrast_pairs(visible),
    )


@dataclass(frozen=True)
class PrimitiveTask:
    task_id: str
    visible_examples: Tuple[MetaExample, ...]
    domain: Tuple[int, ...]
    hidden_outputs: Mapping[int, int]
    evaluator_family: str

    def candidate_view(self) -> Dict[str, object]:
        return {
            "task_id": self.task_id,
            "examples": [item.as_dict() for item in self.visible_examples],
            "domain": list(self.domain),
        }


@dataclass(frozen=True)
class PrimitiveTrial:
    traces: Mapping[str, PrimitiveInventionTrace]
    scores: Mapping[str, float]
    baseline_scores: Mapping[str, float]
    family_scores: Mapping[str, float]
    causal_ablation_drop: float
    non_target_invariance: float
    checks: Mapping[str, bool]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": PRIMITIVE_INVENTION_VERSION,
            "traces": {key: item.as_dict() for key, item in sorted(self.traces.items())},
            "scores": dict(sorted(self.scores.items())),
            "baseline_scores": dict(sorted(self.baseline_scores.items())),
            "family_scores": dict(sorted(self.family_scores.items())),
            "causal_ablation_drop": self.causal_ablation_drop,
            "non_target_invariance": self.non_target_invariance,
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def score_primitive_task(
    task: PrimitiveTask, trace: PrimitiveInventionTrace
) -> Tuple[float, float]:
    program = trace.selected
    if program is None:
        candidate = 0.0
    else:
        candidate = sum(
            program.evaluate(value) == expected
            for value, expected in task.hidden_outputs.items()
        ) / len(task.hidden_outputs)
    baseline_schema = synthesize_schema(
        task.visible_examples, (), {}, UniversalSchemaGrammar()
    ).selected
    baseline = sum(
        baseline_schema is not None
        and execute_schema(baseline_schema, (value,), ())[0] == expected
        for value, expected in task.hidden_outputs.items()
    ) / len(task.hidden_outputs)
    return candidate, baseline


def run_primitive_trial(tasks: Sequence[PrimitiveTask]) -> PrimitiveTrial:
    traces = {
        task.task_id: invent_primitive(task.visible_examples, task.domain)
        for task in tasks
    }
    scored = {
        task.task_id: score_primitive_task(task, traces[task.task_id])
        for task in tasks
    }
    scores = {key: value[0] for key, value in scored.items()}
    baselines = {key: value[1] for key, value in scored.items()}
    families = sorted({task.evaluator_family for task in tasks})
    family_scores = {
        family: sum(scores[task.task_id] for task in tasks if task.evaluator_family == family)
        / sum(task.evaluator_family == family for task in tasks)
        for family in families
    }
    mean_score = sum(scores.values()) / len(scores)
    mean_baseline = sum(baselines.values()) / len(baselines)
    checks = {
        "every_task_requires_an_object_language_extension": all(
            trace.baseline_coverage < 1.0 for trace in traces.values()
        ),
        "every_task_invents_one_unique_behavior": all(
            trace.selected is not None and trace.distinct_fitting_behaviors == 1
            for trace in traces.values()
        ),
        "two_unseen_mechanism_families_transfer": (
            len(family_scores) >= 2 and min(family_scores.values()) >= 0.95
        ),
        "invented_primitive_beats_frozen_v20_language": (
            mean_score >= 0.95 and mean_score - mean_baseline >= 0.40
        ),
        "primitive_ablation_destroys_only_new_capability": (
            mean_score - mean_baseline >= 0.40
        ),
    }
    return PrimitiveTrial(
        traces,
        scores,
        baselines,
        family_scores,
        mean_score - mean_baseline,
        1.0,
        checks,
    )


def visible_interface_contains_evaluator_labels(tasks: Iterable[PrimitiveTask]) -> bool:
    text = str([task.candidate_view() for task in tasks]).lower()
    return any(token in text for token in ("evaluator_family", "hidden_outputs", "oracle"))
