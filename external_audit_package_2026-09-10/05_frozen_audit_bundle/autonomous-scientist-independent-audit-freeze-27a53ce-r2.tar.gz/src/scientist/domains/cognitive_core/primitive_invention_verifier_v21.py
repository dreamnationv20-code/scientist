from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.primitive_invention_audit_v21 import (
    PrimitiveAuditMaterialization,
)
from scientist.domains.cognitive_core.primitive_invention_v21 import (
    InventedPrimitive,
    PrimitiveInventionTrace,
    PrimitiveTrial,
    invent_primitive,
    visible_interface_contains_evaluator_labels,
)


PRIMITIVE_VERIFIER_REF = "primitive-invention-independent-verifier-v21"


@dataclass(frozen=True)
class PrimitiveInventionVerification:
    checks: Mapping[str, bool]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "verifier_ref": PRIMITIVE_VERIFIER_REF,
            "checks": dict(sorted(self.checks.items())),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_primitive_invention(
    *,
    development_traces: Mapping[str, PrimitiveInventionTrace],
    materialization: PrimitiveAuditMaterialization,
    trial: PrimitiveTrial,
    candidate_freeze_id: str,
    freeze_stage: int,
    artifact_round_trips: Mapping[str, bool],
) -> PrimitiveInventionVerification:
    source = inspect.getsource(invent_primitive).lower()
    candidate_text = json.dumps(
        [task.candidate_view() for task in materialization.tasks], sort_keys=True
    ).lower()
    selected = [
        trace.selected
        for trace in trial.traces.values()
        if trace.selected is not None
    ]
    checks = {
        "development_invents_executable_extension": bool(development_traces)
        and all(trace.selected is not None for trace in development_traces.values()),
        "hidden_evaluator_labels_are_absent_from_candidate_interface": (
            not visible_interface_contains_evaluator_labels(materialization.tasks)
            and all(
                token not in candidate_text
                for token in ("evaluator_family", "hidden_outputs", "target_operator")
            )
        ),
        "candidate_has_no_family_specific_dispatch": all(
            token not in source
            for token in ("alternating_partition", "ordered_partition")
        ),
        "audit_materialized_after_freeze": (
            materialization.candidate_freeze_id == candidate_freeze_id
            and freeze_stage < materialization.materialization_stage
        ),
        "new_operator_is_absent_from_v20_grammar": bool(selected)
        and all(item.operator == "guarded_dispatch" for item in selected)
        and "guarded_dispatch" not in (
            "input literal add multiply modulo follow pair lookup"
        ).split(),
        "old_grammar_failure_is_measured_prospectively": all(
            trace.baseline_coverage < 1.0 for trace in trial.traces.values()
        ),
        "fresh_transfer_and_causal_ablation_pass": trial.passed,
        "artifacts_round_trip_exactly": bool(artifact_round_trips)
        and all(artifact_round_trips.values()),
    }
    return PrimitiveInventionVerification(
        checks,
        (
            "From unlabeled behavioral contrasts, the candidate composed an executable "
            "guarded-dispatch primitive absent from the frozen V20 object language and "
            "transferred it prospectively across two fresh procedural families."
        ),
        (
            "the meta-language itself was invented without engineered constructors",
            "the result establishes open-ended program synthesis",
            "the result establishes a general cognitive core",
        ),
        (
            "Predicate and affine constructors remain engineered meta-level resources.",
            "The audit uses bounded deterministic integer programs.",
            "Novelty here means a new executable object-language primitive, not literature novelty.",
        ),
    )
