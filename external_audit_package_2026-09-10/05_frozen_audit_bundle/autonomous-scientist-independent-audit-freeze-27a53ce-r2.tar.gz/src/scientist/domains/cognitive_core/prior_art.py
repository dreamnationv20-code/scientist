from __future__ import annotations

from scientist.kernel.contracts import ProblemCharter
from scientist.program.contracts import HighLevelGoal, ResearchNode
from scientist.program.literature import (
    ClaimClassification,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)
from scientist.program.runtime import CampaignExecution


REVIEW_DATE = "2026-07-30"


def routing_signature(subject_id: str) -> ClaimSignature:
    return ClaimSignature(
        subject_id=subject_id,
        statement=(
            "A relevance annotation plus a routing-heavy context mixture "
            "lets a same-size learner use relevant or updating evidence "
            "while preserving answers under irrelevant evidence."
        ),
        problem=(
            "language model parametric knowledge destroyed by irrelevant "
            "retrieved context"
        ),
        phenomenon=(
            "parametric versus contextual knowledge conflict and irrelevant "
            "context interference"
        ),
        intervention=(
            "fine-tuning on relevant irrelevant and counterfactual context "
            "with explicit relevance signals"
        ),
        mechanism=(
            "selective routing between working context and parametric memory"
        ),
        evaluation=(
            "known-answer preservation relevant context use knowledge "
            "conflict and abstention"
        ),
    )


def routing_prior_art_assessment(
    subject_id: str,
    trigger: LiteratureTrigger = LiteratureTrigger.CLAIM_ESCALATION,
) -> PriorArtAssessment:
    signature = routing_signature(subject_id)
    return PriorArtAssessment(
        signature=signature,
        trigger=trigger,
        queries=(
            LiteratureQuery(
                signature.problem,
                SearchFacet.PROBLEM,
                "arXiv",
            ),
            LiteratureQuery(
                signature.phenomenon,
                SearchFacet.PHENOMENON,
                "ACL Anthology",
            ),
            LiteratureQuery(
                signature.intervention,
                SearchFacet.INTERVENTION,
                "arXiv",
            ),
            LiteratureQuery(
                signature.mechanism,
                SearchFacet.MECHANISM,
                "OpenReview",
            ),
            LiteratureQuery(
                signature.evaluation,
                SearchFacet.EVALUATION,
                "ACL Anthology",
            ),
            LiteratureQuery(
                "citation-neighborhood:kaft-2023",
                SearchFacet.CITATION_NEIGHBORHOOD,
                "Semantic Scholar",
            ),
        ),
        closest_works=(
            PriorWork(
                work_id="li-et-al-kaft-2023",
                title="Large Language Models with Controllable Working Memory",
                year=2023,
                locator="https://arxiv.org/abs/2211.05110",
                relation=PriorArtRelation.DUPLICATES_CORE,
                matched_components=(
                    "relevant context use",
                    "irrelevant context rejection",
                    "counterfactual context training",
                    "fallback to parametric memory",
                ),
                executable=True,
            ),
            PriorWork(
                work_id="kim-et-al-re-rag-2024",
                title=(
                    "RE-RAG: Improving Open-Domain QA Performance "
                    "and Interpretability with Relevance Estimator"
                ),
                year=2024,
                locator="https://arxiv.org/abs/2406.05794",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "explicit relevance estimation",
                    "parametric fallback",
                    "irrelevant context resistance",
                ),
                executable=True,
            ),
            PriorWork(
                work_id="asai-et-al-self-rag-2024",
                title=(
                    "Self-RAG: Learning to Retrieve, Generate, "
                    "and Critique through Self-Reflection"
                ),
                year=2024,
                locator="https://arxiv.org/abs/2310.11511",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "relevance tokens",
                    "adaptive evidence use",
                    "context critique",
                ),
                executable=True,
            ),
        ),
        classification=ClaimClassification.REDISCOVERY,
        rationale=(
            "KAFT already trains the core relevant, irrelevant, and "
            "counterfactual-context behaviors. RE-RAG and Self-RAG also "
            "precede the explicit relevance-routing component. The exact "
            "MiniLab mixture is an implementation detail, not a distinct "
            "scientific mechanism."
        ),
        novel_delta=(),
        citation_snowball_complete=True,
        searched_at=REVIEW_DATE,
        reviewer_ref="cognitive-core-prior-art-red-team-v1",
        executable_incumbent_id="li-et-al-kaft-2023",
    )


def engineering_assessment(
    subject_id: str,
    statement: str,
) -> PriorArtAssessment:
    signature = ClaimSignature(
        subject_id=subject_id,
        statement=statement,
        problem="validate deterministic local experimental infrastructure",
        phenomenon="measurement and partition integrity",
        intervention="independent reconstruction and seeded controls",
        mechanism="engineering verification",
        evaluation="qualification checks",
    )
    return PriorArtAssessment(
        signature=signature,
        trigger=LiteratureTrigger.INITIAL_SCOPE,
        queries=(),
        closest_works=(),
        classification=ClaimClassification.NOT_APPLICABLE,
        rationale=(
            "This is an internal engineering qualification, not a "
            "scientific novelty claim."
        ),
        novel_delta=(),
        citation_snowball_complete=True,
        searched_at=REVIEW_DATE,
        reviewer_ref="cognitive-core-engineering-review-v1",
    )


def tradeoff_scope_assessment(subject_id: str) -> PriorArtAssessment:
    signature = ClaimSignature(
        subject_id=subject_id,
        statement=(
            "Increasing incompressible factual load at matched compute may "
            "reduce procedural generalization in compact transformers."
        ),
        problem="parametric factual memorization versus transferable procedures",
        phenomenon="in-weights memorization and procedural generalization tradeoff",
        intervention="vary random fact load at matched model and token budgets",
        mechanism="finite capacity or optimization competition",
        evaluation="procedural out-of-distribution accuracy by factual load",
    )
    return PriorArtAssessment(
        signature=signature,
        trigger=LiteratureTrigger.INITIAL_SCOPE,
        queries=(
            LiteratureQuery(
                signature.problem,
                SearchFacet.PROBLEM,
                "arXiv",
            ),
            LiteratureQuery(
                signature.intervention,
                SearchFacet.INTERVENTION,
                "Semantic Scholar",
            ),
            LiteratureQuery(
                signature.mechanism,
                SearchFacet.MECHANISM,
                "arXiv",
            ),
            LiteratureQuery(
                signature.evaluation,
                SearchFacet.EVALUATION,
                "Semantic Scholar",
            ),
            LiteratureQuery(
                "citation-neighborhood:incompressible-knowledge-probes",
                SearchFacet.CITATION_NEIGHBORHOOD,
                "Semantic Scholar",
            ),
        ),
        closest_works=(
            PriorWork(
                work_id="incompressible-knowledge-probes-2026",
                title="Incompressible Knowledge Probes",
                year=2026,
                locator="https://arxiv.org/abs/2604.24827",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "random factual capacity",
                    "procedural capability density",
                    "model scaling",
                ),
            ),
        ),
        classification=ClaimClassification.REPRODUCTION,
        rationale=(
            "The scoped trade-off is directly motivated by existing work; "
            "the MiniLab is a discriminating reproduction attempt."
        ),
        novel_delta=(),
        citation_snowball_complete=True,
        searched_at=REVIEW_DATE,
        reviewer_ref="cognitive-core-initial-scope-review-v2",
    )


def evidence_utilization_scope_assessment(
    subject_id: str,
    trigger: LiteratureTrigger = LiteratureTrigger.INITIAL_SCOPE,
) -> PriorArtAssessment:
    """Prior art for the semantic evidence-use milestone.

    This assessment deliberately classifies the next MiniLab run as a
    reproduction/diagnostic.  It prevents robustness to noisy relevance
    signals from being mistaken for a new retrieval or conflict-mitigation
    method before comparison on the published CUB benchmark.
    """

    signature = ClaimSignature(
        subject_id=subject_id,
        statement=(
            "Measure whether a compact learner that routes between "
            "parametric memory and external evidence remains reliable when "
            "relevance signals are imperfect, then transfer the surviving "
            "candidate to natural-language context-use benchmarks."
        ),
        problem=(
            "language models must use relevant retrieved evidence while "
            "resisting irrelevant or conflicting context"
        ),
        phenomenon=(
            "parametric and contextual knowledge conflict under gold "
            "conflicting and irrelevant retrieved contexts"
        ),
        intervention=(
            "relevance-aware training or confidence-based control of "
            "external evidence use and parametric fallback"
        ),
        mechanism=(
            "selective routing between retrieved context parametric memory "
            "and abstention under noisy relevance estimates"
        ),
        evaluation=(
            "context utilization balance on natural and synthetic question "
            "answering with gold conflicting and irrelevant contexts"
        ),
    )
    return PriorArtAssessment(
        signature=signature,
        trigger=trigger,
        queries=(
            LiteratureQuery(
                signature.problem,
                SearchFacet.PROBLEM,
                "ACL Anthology",
            ),
            LiteratureQuery(
                signature.phenomenon,
                SearchFacet.PHENOMENON,
                "ACL Anthology",
            ),
            LiteratureQuery(
                signature.intervention,
                SearchFacet.INTERVENTION,
                "arXiv",
            ),
            LiteratureQuery(
                signature.mechanism,
                SearchFacet.MECHANISM,
                "OpenReview",
            ),
            LiteratureQuery(
                signature.evaluation,
                SearchFacet.EVALUATION,
                "ACL Anthology",
            ),
            LiteratureQuery(
                "citation-neighborhood:kaft-2023,cub-2026",
                SearchFacet.CITATION_NEIGHBORHOOD,
                "Semantic Scholar",
            ),
        ),
        closest_works=(
            PriorWork(
                work_id="chen-et-al-cub-2026",
                title=(
                    "CUB: Benchmarking Context Utilisation Methods for "
                    "Language Models"
                ),
                year=2026,
                locator="https://aclanthology.org/2026.acl-long.1151/",
                relation=PriorArtRelation.EXECUTABLE_BASELINE,
                matched_components=(
                    "gold conflicting and irrelevant contexts",
                    "context-versus-memory utilization metric",
                    "natural and synthetic evaluation",
                    "published implementations of context-use methods",
                ),
                executable=True,
            ),
            PriorWork(
                work_id="li-et-al-kaft-2023",
                title="Large Language Models with Controllable Working Memory",
                year=2023,
                locator="https://arxiv.org/abs/2211.05110",
                relation=PriorArtRelation.DUPLICATES_CORE,
                matched_components=(
                    "relevant context use",
                    "irrelevant context rejection",
                    "counterfactual context training",
                    "fallback to parametric memory",
                ),
                executable=True,
            ),
            PriorWork(
                work_id="kim-et-al-re-rag-2024",
                title=(
                    "RE-RAG: Improving Open-Domain QA Performance "
                    "and Interpretability with Relevance Estimator"
                ),
                year=2024,
                locator="https://arxiv.org/abs/2406.05794",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "weakly supervised relevance estimation",
                    "confidence-aware parametric fallback",
                    "irrelevant context resistance",
                ),
                executable=True,
            ),
            PriorWork(
                work_id="shi-et-al-ck-plug-2026",
                title=(
                    "CK-PLUG: Learning Your Contextual Knowledge with "
                    "Information-theoretic Fine-tuning"
                ),
                year=2026,
                locator=(
                    "https://openreview.net/forum?id=TJ3DqFiGau"
                ),
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "confidence-gain relevance signal",
                    "fine-grained context utilization control",
                    "parametric-contextual knowledge arbitration",
                ),
                executable=False,
            ),
        ),
        classification=ClaimClassification.REPRODUCTION,
        rationale=(
            "KAFT already establishes training for relevant, irrelevant, "
            "and counterfactual contexts; RE-RAG and CK-PLUG add learned "
            "relevance or confidence control. CUB supplies an executable "
            "frontier evaluation and warns that synthetic settings can "
            "overstate context-utilization performance. Therefore relevance-"
            "noise tests in the MiniLab are mechanism diagnostics only. A "
            "scientific advance cannot be considered until a frozen method "
            "beats published CUB incumbents on natural data."
        ),
        novel_delta=(),
        citation_snowball_complete=True,
        searched_at=REVIEW_DATE,
        reviewer_ref="cognitive-core-evidence-scope-review-v1",
        executable_incumbent_id="chen-et-al-cub-2026",
    )


class HistoricalCognitiveCoreReviewer:
    """Fail-closed reviewer for already completed MiniLab milestones."""

    name = "historical-cognitive-core-reviewer"
    reviewer_version = "v1"

    def review_scope(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
    ) -> PriorArtAssessment:
        del goal, charter
        if "laboratory" in node.tags:
            return engineering_assessment(
                node.node_id,
                "The Cognitive Core MiniLab passes its frozen qualification.",
            )
        if "memorization" in node.tags and "procedure" in node.tags:
            return tradeoff_scope_assessment(node.node_id)
        if "routing" in node.tags and "context" in node.tags:
            return routing_prior_art_assessment(
                node.node_id,
                trigger=LiteratureTrigger.NEW_PHENOMENON,
            )
        if {"retrieval", "abstention", "calibration"}.intersection(
            node.tags
        ):
            return evidence_utilization_scope_assessment(node.node_id)
        raise ValueError(
            "a fresh event-driven literature review is required for node %s"
            % node.title
        )


    def review(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        execution: CampaignExecution,
    ) -> PriorArtAssessment:
        del goal, execution
        if "laboratory" in node.tags:
            return engineering_assessment(
                node.node_id,
                "The Cognitive Core MiniLab passes its frozen qualification.",
            )
        if "routing" in node.tags and "context" in node.tags:
            return routing_prior_art_assessment(node.node_id)
        if {"retrieval", "abstention", "calibration"}.intersection(
            node.tags
        ):
            return evidence_utilization_scope_assessment(
                node.node_id,
                trigger=LiteratureTrigger.CLAIM_ESCALATION,
            )
        raise ValueError(
            "a fresh event-driven literature review is required for node %s"
            % node.title
        )


class LiveCognitiveCoreReviewer(HistoricalCognitiveCoreReviewer):
    """Event-driven reviewer for unfinished cognitive-core campaigns."""

    name = "live-cognitive-core-reviewer"
    reviewer_version = "cognitive-core-evidence-review-v1"
