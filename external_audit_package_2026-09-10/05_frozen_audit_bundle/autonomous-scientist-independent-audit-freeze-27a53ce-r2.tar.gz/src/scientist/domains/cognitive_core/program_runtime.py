from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Mapping, Sequence, Tuple


from scientist.kernel.contracts import (
    MetricDirection,
    MetricSpec,
    ProblemCharter,
)
from scientist.program.contracts import (
    ChildCampaignOutcome,
    ChildCampaignProgress,
    ChildCampaignResult,
    HighLevelGoal,
    ResearchNode,
)
from scientist.program.literature import ClaimLevel
from scientist.program.runtime import (
    CampaignExecution,
    CampaignProgressExecution,
    ProgramRuntime,
)
from scientist.research_programs.cognitive_core import build_legacy_program

from scientist.domains.cognitive_core.prior_art import (
    HistoricalCognitiveCoreReviewer,
    LiveCognitiveCoreReviewer,
)


HISTORICAL_DRIVER_VERSION = "cognitive-core-historical-import-v1"
LIVE_DRIVER_VERSION = "cognitive-core-live-program-v1"
ROUTING_REPORT_ID = (
    "replication-report-7003da509b058f4f9e83"
)


class HistoricalCognitiveCoreDriver:
    """Imports completed milestones; it cannot invent future experiments."""

    name = "historical-cognitive-core-driver"
    driver_version = HISTORICAL_DRIVER_VERSION

    @staticmethod
    def charter_for(
        goal: HighLevelGoal,
        node: ResearchNode,
    ) -> ProblemCharter:
        del goal
        return ProblemCharter(
            name=node.title,
            statement=node.question,
            domain_id="cognitive_core_minilab",
            scope=("historical MiniLab evidence import",),
            anti_scope=(
                "new natural-language or scaled-model claims",
                "scientific novelty inferred from local performance",
            ),
            metrics=(
                MetricSpec(
                    name="frozen_child_outcome",
                    direction=MetricDirection.TARGET,
                    unit="binary",
                    aggregation="frozen historical record",
                    primary=True,
                    target=1.0,
                ),
            ),
            success_definition=node.acceptance_conditions[0],
            falsification_conditions=node.falsification_conditions,
        )

    @staticmethod
    def run(
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
        scope_assessment,
    ) -> CampaignExecution:
        del goal
        if "laboratory" in node.tags:
            return CampaignExecution(
                result=ChildCampaignResult(
                    node_id=node.node_id,
                    child_charter_id=charter.charter_id,
                    outcome=ChildCampaignOutcome.CONFIRMED,
                    evidence_ids=(
                        "cognitive-core-minilab-qualification-tests-v1",
                    ),
                    summary=(
                        "The seeded MiniLab passed its partition, control, "
                        "determinism, and independent-verification checks."
                    ),
                    implications=(
                        "child scientific questions may run in the MiniLab",
                    ),
                    compute_spent=5.0,
                    claim_id="cognitive-core-minilab-qualified-v1",
                ),
                scope_assessment_id=scope_assessment.assessment_id,
                requested_claim_level=ClaimLevel.REPLICATED_EFFECT,
            )
        if "memorization" in node.tags and "procedure" in node.tags:
            return CampaignExecution(
                result=ChildCampaignResult(
                    node_id=node.node_id,
                    child_charter_id=charter.charter_id,
                    outcome=ChildCampaignOutcome.REFUTED,
                    evidence_ids=(ROUTING_REPORT_ID,),
                    summary=(
                        "The matched MiniLab did not support a monotonic "
                        "random-fact-load penalty on procedures."
                    ),
                    implications=(
                        "do not pursue capacity or kinetics as confirmed "
                        "descendants of this refuted trade-off",
                    ),
                    compute_spent=40.0,
                ),
                scope_assessment_id=scope_assessment.assessment_id,
            )
        if "routing" in node.tags and "context" in node.tags:
            return CampaignExecution(
                result=ChildCampaignResult(
                    node_id=node.node_id,
                    child_charter_id=charter.charter_id,
                    outcome=ChildCampaignOutcome.CONFIRMED,
                    evidence_ids=(ROUTING_REPORT_ID,),
                    summary=(
                        "The MiniLab replicated a strong KAFT-style "
                        "memory/context routing effect. Targeted prior-art "
                        "review classifies the intervention as rediscovery."
                    ),
                    implications=(
                        "install KAFT-style routing as an incumbent",
                        "continue to semantic evidence use and curriculum",
                    ),
                    compute_spent=45.0,
                    claim_id="cognitive-core-routing-effect-v1",
                ),
                scope_assessment_id=scope_assessment.assessment_id,
                requested_claim_level=ClaimLevel.BREAKTHROUGH,
            )
        raise RuntimeError(
            "historical evidence cannot execute unfinished node %s"
            % node.title
        )


def _read_manifests(root: Path) -> Tuple[Mapping, ...]:
    manifest_root = root / "manifests"
    if not manifest_root.exists():
        return ()
    return tuple(
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted(manifest_root.glob("*.json"))
    )


class LiveCognitiveCoreDriver:
    """Legacy v2 continuation driver; never used by the fresh v3 program."""

    """Progressive driver for unfinished cognitive-core campaigns."""

    name = "live-cognitive-core-driver"
    driver_version = LIVE_DRIVER_VERSION

    def __init__(self, project_root: Path = Path(".")) -> None:
        self.project_root = Path(project_root)

    @staticmethod
    def charter_for(
        goal: HighLevelGoal,
        node: ResearchNode,
    ) -> ProblemCharter:
        del goal
        if not {"retrieval", "abstention", "calibration"}.intersection(
            node.tags
        ):
            raise ValueError(
                "the live v1 driver supports only the evidence-use node"
            )
        return ProblemCharter(
            name=node.title,
            statement=node.question,
            domain_id="cognitive_core_evidence_transfer",
            scope=(
                "counterfactual MiniLab mechanism diagnostics",
                "CUB CounterFact validation and frozen test transfer",
                "small open-weight MLX models on local hardware",
            ),
            anti_scope=(
                "novelty claims for KAFT, prompting, or relevance routing",
                "scaled-model claims from quantized validation subsets",
                "closing the child node after a development-only win",
            ),
            metrics=(
                MetricSpec(
                    name="cub_context_accuracy_edited",
                    direction=MetricDirection.MAXIMIZE,
                    unit="accuracy fraction",
                    aggregation="frozen CUB context-conflict split",
                    primary=True,
                ),
                MetricSpec(
                    name="cub_memory_accuracy_irrelevant",
                    direction=MetricDirection.MAXIMIZE,
                    unit="accuracy fraction",
                    aggregation="frozen CUB irrelevant-context split",
                ),
                MetricSpec(
                    name="cub_context_accuracy_gold",
                    direction=MetricDirection.MAXIMIZE,
                    unit="accuracy fraction",
                    aggregation="frozen CUB gold-context split",
                ),
            ),
            success_definition=(
                "A frozen candidate improves the CUB context/memory Pareto "
                "front on held-out data without using context-type labels."
            ),
            falsification_conditions=node.falsification_conditions,
        )

    def _progress_from_existing_artifacts(
        self,
        node: ResearchNode,
        charter: ProblemCharter,
        history: Tuple[ChildCampaignProgress, ...],
    ) -> ChildCampaignProgress:
        stage = len(history)
        if stage == 0:
            manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/evidence_stress_v1"
            )
            if len(manifests) < 7:
                raise RuntimeError(
                    "the frozen seven-arm evidence-stress grid is missing"
                )
            evidence_ids = tuple(
                "evidence-stress-" + str(item["summary_id"])
                for item in manifests
            )
            return ChildCampaignProgress(
                node_id=node.node_id,
                child_charter_id=charter.charter_id,
                stage="mechanism_diagnostic",
                hypothesis_id="perfect-relevance-marker-robustness",
                evidence_ids=evidence_ids,
                summary=(
                    "The original router failed under relevance-label "
                    "noise, and no schedule/noise revision passed all "
                    "clean and 25%-noise gates."
                ),
                implications=(
                    "do not replicate the exact-marker MiniLab candidate",
                    "move to the executable natural-language incumbent",
                ),
                compute_spent=3.5,
                next_action=(
                    "reproduce CUB's published Qwen 1.5B validation baseline"
                ),
            )
        if stage == 1:
            manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_baseline_v1"
            )
            if len(manifests) != 1:
                raise RuntimeError("the CUB baseline manifest is missing")
            manifest = manifests[0]
            metrics = manifest["metrics"]
            return ChildCampaignProgress(
                node_id=node.node_id,
                child_charter_id=charter.charter_id,
                stage="executable_incumbent_reproduction",
                hypothesis_id="cub-regular-open-book-baseline",
                evidence_ids=(
                    "cub-baseline-" + str(manifest["baseline_id"]),
                ),
                summary=(
                    "The published regular Qwen 1.5B validation predictions "
                    "were reproduced through the local CUB metric adapter: "
                    "gold %.3f, edited %.3f, irrelevant-memory %.3f."
                    % (
                        metrics["context_accuracy_gold"],
                        metrics["context_accuracy_edited"],
                        metrics["memory_accuracy_irrelevant"],
                    )
                ),
                implications=(
                    "CUB is the active executable incumbent",
                    "context conflict is the dominant regular-mode gap",
                ),
                compute_spent=0.25,
                next_action=(
                    "measure the published tuned-prompt Pareto trade-off "
                    "on a local quantized model"
                ),
            )
        if stage == 2:
            manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_mlx_validation_v1"
            )
            if len(manifests) != 1:
                raise RuntimeError(
                    "the full CUB MLX validation manifest is missing"
                )
            manifest = manifests[0]
            regular = manifest["mlx_regular_metrics"]
            tuned = manifest["mlx_published_tuned_prompt_metrics"]
            return ChildCampaignProgress(
                node_id=node.node_id,
                child_charter_id=charter.charter_id,
                stage="natural_language_transfer_development",
                hypothesis_id="published-cub-tuned-prompt",
                evidence_ids=(
                    "cub-mlx-validation-" + str(manifest["smoke_id"]),
                ),
                summary=(
                    "On all 198 quantized-model validation examples, the "
                    "published prompt raised edited-context accuracy from "
                    "%.3f to %.3f but reduced irrelevant-memory accuracy "
                    "from %.3f to %.3f."
                    % (
                        regular["context_accuracy_edited"],
                        tuned["context_accuracy_edited"],
                        regular["memory_accuracy_irrelevant"],
                        tuned["memory_accuracy_irrelevant"],
                    )
                ),
                implications=(
                    "the prompt is a strong incumbent but not Pareto-safe",
                    "test label-free relevance routing before any holdout run",
                ),
                compute_spent=1.5,
                next_action=(
                    "tune a label-free relevance router on validation, "
                    "then freeze it for CUB test"
                ),
            )
        if stage == 3:
            manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_router_validation_v1"
            )
            if len(manifests) != 1:
                raise RuntimeError(
                    "the CUB router validation manifest is missing"
                )
            manifest = manifests[0]
            selected = manifest["selected"]
            metrics = selected["metrics"]
            return ChildCampaignProgress(
                node_id=node.node_id,
                child_charter_id=charter.charter_id,
                stage="candidate_development",
                hypothesis_id="label-free-lexical-relevance-router",
                evidence_ids=(
                    "cub-router-validation-" + str(
                        manifest["router_id"]
                    ),
                ),
                summary=(
                    "A prompt-only lexical router at frozen threshold %.3f "
                    "retained edited-context accuracy %.3f and restored "
                    "irrelevant-memory accuracy to %.3f, for validation "
                    "combined score %.3f."
                    % (
                        selected["threshold"],
                        metrics["context_accuracy_edited"],
                        metrics["memory_accuracy_irrelevant"],
                        metrics["combined_score"],
                    )
                ),
                implications=(
                    "the validation Pareto conflict is routable",
                    "the rule may exploit CounterFact lexical structure",
                    "do not close the node before holdout and semantic transfer",
                ),
                compute_spent=0.1,
                next_action=(
                    "freeze threshold 0.8333333333333333 for CounterFact "
                    "test, then test semantic relevance on NQ and DRUID"
                ),
            )
        if stage == 4:
            manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_router_test300_v1"
            )
            if len(manifests) != 1:
                raise RuntimeError(
                    "the frozen CUB router holdout manifest is missing"
                )
            manifest = manifests[0]
            routed = manifest["routed_metrics"]
            tuned = manifest["published_tuned_prompt_metrics"]
            regular = manifest["regular_metrics"]
            return ChildCampaignProgress(
                node_id=node.node_id,
                child_charter_id=charter.charter_id,
                stage="frozen_subset_holdout",
                hypothesis_id="label-free-lexical-relevance-router",
                evidence_ids=(
                    "cub-router-test300-" + str(
                        manifest["router_id"]
                    ),
                ),
                summary=(
                    "Without retuning, the router retained tuned-prompt "
                    "edited accuracy %.3f and regular irrelevant-memory "
                    "accuracy %.3f on a balanced 300-example CounterFact "
                    "test subset; combined score %.3f versus %.3f tuned."
                    % (
                        routed["context_accuracy_edited"],
                        routed["memory_accuracy_irrelevant"],
                        routed["combined_score"],
                        tuned["combined_score"],
                    )
                ),
                implications=(
                    "the validation routing effect survives a frozen holdout",
                    "the rule remains CounterFact-format-specific",
                    "semantic cross-dataset transfer is still unresolved",
                ),
                compute_spent=2.0,
                next_action=(
                    "replace lexical overlap with a semantic relevance "
                    "estimator and evaluate on NQ and DRUID validation"
                ),
            )
        if stage == 5:
            relevance_manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_semantic_relevance_v1"
            )
            rescore_manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_relevance_prompt_rescore_v1"
            )
            heldout_manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_frozen_veto_nq_test_v1"
            )
            if (
                len(relevance_manifests) != 1
                or len(rescore_manifests) != 1
                or len(heldout_manifests) != 1
            ):
                raise RuntimeError(
                    "the semantic-router reproduction or frozen "
                    "falsification manifest is missing"
                )
            relevance = relevance_manifests[0]
            rescore = rescore_manifests[0]
            heldout = heldout_manifests[0]
            changes = heldout["paired_changes"][
                "copenlu/cub-nq"
            ]
            return ChildCampaignProgress(
                node_id=node.node_id,
                child_charter_id=charter.charter_id,
                stage="semantic_transfer_falsification",
                hypothesis_id="prompt-confidence-semantic-router",
                evidence_ids=(
                    "cub-semantic-relevance-"
                    + str(relevance["qualification_id"]),
                    "cub-relevance-rescore-"
                    + str(rescore["rescore_id"]),
                    "cub-frozen-veto-"
                    + str(heldout["evaluation_id"]),
                ),
                summary=(
                    "The published semantic relevance expert was "
                    "reproduced on NQ and DRUID. Alternative prompts "
                    "failed the incumbent-relative safety constraints. "
                    "A validation-selected confidence veto then failed "
                    "on 300 held-out NQ cases: %d corrections versus %d "
                    "harms, with audited balanced delta %.4f."
                    % (
                        changes["total"]["corrected"],
                        changes["total"]["harmed"],
                        heldout["mean_audited_balanced_delta"],
                    )
                ),
                implications=(
                    "reject prompt-only confidence vetoing at this scale",
                    "do not spend downstream evaluation on a refuted gate",
                    "decompose semantic relevance before training a router",
                ),
                compute_spent=6.0,
                next_action=(
                    "audit paired semantic errors, then test a frozen "
                    "subject-and-relation decomposition on validation"
                ),
            )
        if stage == 6:
            witness_manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_witness_router_nq_validation_v2"
            )
            learned_manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/"
                "cub_learned_router_druid_test_expanded_v1"
            )
            union_manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_capacity_union_nq_test300_v1"
            )
            if (
                len(witness_manifests) != 1
                or len(learned_manifests) != 1
                or len(union_manifests) != 1
            ):
                raise RuntimeError(
                    "the decomposed, learned, or capacity-control "
                    "falsification manifest is missing"
                )
            witness = witness_manifests[0]
            learned = learned_manifests[0]
            union = union_manifests[0]
            return ChildCampaignProgress(
                node_id=node.node_id,
                child_charter_id=charter.charter_id,
                stage="semantic_router_branch_closure",
                hypothesis_id=(
                    "prompt-decomposition-calibration-and-capacity"
                ),
                evidence_ids=(
                    "cub-witness-router-" + str(witness["search_id"]),
                    "cub-learned-evaluation-"
                    + str(learned["evaluation_id"]),
                    "cub-capacity-union-"
                    + str(union["evaluation_id"]),
                ),
                summary=(
                    "Grounded witness extraction failed validation safety. "
                    "A grouped learned DRUID calibrator fixed all seven "
                    "targeted distractors in the expanded test but harmed "
                    "ten incumbent decisions and corrected eight. A frozen "
                    "1.5B/3B NQ union rescued eight relevant decisions but "
                    "harmed four distractors, exceeding the two-case gate."
                ),
                implications=(
                    "close prompt-only and post-hoc calibration branches",
                    "larger judge capacity changes bias rather than solving routing",
                    "move to explicit supervised relevance training",
                ),
                compute_spent=12.0,
                next_action=(
                    "train a small relevance adapter on CUB development "
                    "labels under a fixed recipe, then evaluate once on "
                    "held-out NQ and DRUID"
                ),
            )
        if stage == 7:
            relevance_manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/"
                "cub_relevance_sft_veto_heldout_v1"
            )
            downstream_manifests = _read_manifests(
                self.project_root
                / "runs/cognitive_core/cub_downstream_router_v1"
            )
            if (
                len(relevance_manifests) != 1
                or len(downstream_manifests) != 1
            ):
                raise RuntimeError(
                    "the supervised relevance or downstream causal "
                    "manifest is missing"
                )
            relevance = relevance_manifests[0]
            downstream = downstream_manifests[0]
            relevance_gate = relevance["heldout_gate"]
            downstream_gate = downstream["downstream_gate"]
            return ChildCampaignProgress(
                node_id=node.node_id,
                child_charter_id=charter.charter_id,
                stage="supervised_router_causal_falsification",
                hypothesis_id="supervised-selective-relevance-veto",
                evidence_ids=(
                    "cub-relevance-sft-veto-heldout-"
                    + str(relevance["evaluation_id"]),
                    "cub-downstream-router-"
                    + str(downstream["evaluation_id"]),
                ),
                summary=(
                    "A frozen trained veto passed the held-out relevance "
                    "gate with %d net corrections and mean audited "
                    "balanced delta %.4f. The causal answer-routing check "
                    "then failed: %d downstream net corrections and mean "
                    "combined delta %.4f."
                    % (
                        relevance_gate["net_corrections"],
                        relevance_gate[
                            "mean_audited_balanced_delta"
                        ],
                        downstream_gate["net_corrections"],
                        downstream_gate["mean_combined_delta"],
                    )
                ),
                implications=(
                    "do not promote relevance accuracy as the objective",
                    "train source arbitration against answer utility",
                    "treat no-op relevance corrections as zero value",
                ),
                compute_spent=10.0,
                next_action=(
                    "construct leakage-controlled memory-versus-context "
                    "utility labels, train a selective answer controller, "
                    "and reserve a fresh held-out slice"
                ),
            )
        raise RuntimeError(
            "the next live campaign artifact has not been materialized"
        )

    def run_next(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
        scope_assessment,
        history: Tuple[ChildCampaignProgress, ...],
    ) -> CampaignProgressExecution:
        del goal
        progress = self._progress_from_existing_artifacts(
            node,
            charter,
            history,
        )
        return CampaignProgressExecution(
            progress=progress,
            scope_assessment_id=scope_assessment.assessment_id,
        )

    def run(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
        scope_assessment,
    ) -> CampaignProgressExecution:
        return self.run_next(
            goal,
            node,
            charter,
            scope_assessment,
            (),
        )


def bootstrap_runtime(checkpoint: Path) -> ProgramRuntime:
    """Load or create the frozen v2 historical runtime.

    The fresh diagnostic-first cognitive-core program uses ``GoalGraphRuntime``
    and is initialized by the ``cognitive-goal-init`` command instead.
    """
    runtime = ProgramRuntime(
        manager=build_legacy_program(),
        campaign_driver=HistoricalCognitiveCoreDriver(),
        prior_art_reviewer=HistoricalCognitiveCoreReviewer(),
        checkpoint_path=checkpoint,
    )
    runtime.run_until_terminal(max_cycles=3)
    return runtime


def status_payload(runtime: ProgramRuntime) -> dict:
    return {
        "runtime_state": runtime.state.value,
        "goal_resolved": (
            runtime.manager.resolution is not None
            and runtime.manager.resolution.resolved
        ),
        "cycle": runtime.cycle,
        "compute_spent": runtime.manager.compute_spent,
        "compute_remaining": runtime.manager.compute_remaining,
        "frontier": [
            {
                "node_id": node.node_id,
                "title": node.title,
            }
            for node in runtime.manager.graph.frontier()
        ],
        "active": [
            {
                "node_id": node.node_id,
                "title": node.title,
            }
            for node in runtime.manager.graph.active()
        ],
        "child_outcomes": {
            node_id: result.outcome.value
            for node_id, result in sorted(
                runtime.manager.child_results.items()
            )
        },
        "campaign_progress": {
            node_id: [
                {
                    "stage": progress.stage,
                    "hypothesis_id": progress.hypothesis_id,
                    "summary": progress.summary,
                    "next_action": progress.next_action,
                }
                for progress in progress_items
            ]
            for node_id, progress_items in sorted(
                runtime.manager.campaign_progress.items()
            )
        },
        "claim_authorizations": [
            {
                "claim_id": authorization.claim_id,
                "requested_level": (
                    authorization.requested_level.name.lower()
                ),
                "authorized": authorization.authorized,
                "reasons": list(authorization.reasons),
            }
            for authorization in runtime.manager.claim_authorizations.values()
        ],
        "termination": (
            None
            if runtime.termination is None
            else runtime.termination.as_dict()
        ),
    }


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--checkpoint",
        default="runs/cognitive_core/program/checkpoint.json",
    )
    parser.add_argument(
        "--upgrade-live",
        action="store_true",
        help=(
            "audit-upgrade the historical importer to the progressive "
            "live cognitive-core driver"
        ),
    )
    parser.add_argument(
        "--live-cycles",
        type=int,
        default=0,
        help="number of already-materialized live progress stages to ingest",
    )
    parser.add_argument(
        "--bootstrap",
        action="store_true",
        help="import the three completed historical child milestones",
    )
    arguments = parser.parse_args(list(argv) or None)
    checkpoint = Path(arguments.checkpoint)
    if arguments.bootstrap:
        if checkpoint.exists():
            raise SystemExit(
                "checkpoint already exists; refusing to overwrite it"
            )
        runtime = bootstrap_runtime(checkpoint)
    elif arguments.upgrade_live:
        runtime = ProgramRuntime.from_checkpoint(
            checkpoint,
            campaign_driver=LiveCognitiveCoreDriver(),
            prior_art_reviewer=LiveCognitiveCoreReviewer(),
            allow_component_upgrade=True,
            component_upgrade_reason=(
                "historical evidence import is complete; continue the "
                "unresolved goal with durable within-campaign progress"
            ),
        )
        if arguments.live_cycles:
            runtime.run_until_terminal(
                max_cycles=arguments.live_cycles
            )
    else:
        with checkpoint.open("r", encoding="utf-8") as handle:
            checkpoint_driver = json.load(handle)["campaign_driver"]["name"]
        driver = (
            LiveCognitiveCoreDriver()
            if checkpoint_driver == LiveCognitiveCoreDriver.name
            else HistoricalCognitiveCoreDriver()
        )
        reviewer = (
            LiveCognitiveCoreReviewer()
            if checkpoint_driver == LiveCognitiveCoreDriver.name
            else HistoricalCognitiveCoreReviewer()
        )
        runtime = ProgramRuntime.from_checkpoint(
            checkpoint,
            campaign_driver=driver,
            prior_art_reviewer=reviewer,
        )
        if arguments.live_cycles:
            runtime.run_until_terminal(
                max_cycles=arguments.live_cycles
            )
    print(json.dumps(status_payload(runtime), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
