from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.internal_core_v28 import _batch_responses, _chat_prompt
from scientist.domains.cognitive_core.proposal_verification_v36 import (
    PROPOSAL_VERIFICATION_VERSION,
    aggregate_proposal_sets,
    build_m36_suite,
    parse_proposals,
    proposal_prompt,
)


PROPOSAL_MODEL_VERSION = "general-cognitive-proposal-model-v36"


def evaluate_proposal_model(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    condition: str,
    *,
    adapter_path: Optional[Path] = None,
    batch_size: int = 8,
    max_tokens: int = 112,
) -> Mapping[str, Any]:
    from mlx_lm import load

    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m36_suite("test", 30)
    started = time.monotonic()
    load_arguments: Dict[str, Any] = {"return_config": True}
    if adapter_path is not None:
        load_arguments["adapter_path"] = str(adapter_path)
    model, tokenizer, config = load(model_path, **load_arguments)
    prompts = tuple(_chat_prompt(tokenizer, proposal_prompt(task)) for task in tasks)
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        prompts,
        batch_size=batch_size,
        max_tokens=max_tokens,
        max_batch_tokens=12000,
    )
    proposal_sets = tuple(parse_proposals(task, response) for task, response in zip(tasks, responses))
    parsed_flags = tuple(bool(proposals) for proposals in proposal_sets)
    result = aggregate_proposal_sets(
        condition,
        tasks,
        proposal_sets,
        parsed_flags=parsed_flags,
    )
    records = []
    for response, record in zip(responses, result["records"]):
        records.append({**record, "response": response})
    store = ArtifactStore(output_root)
    predictions_digest = store.put("proposal_model_predictions", records)
    payload = {
        "version": PROPOSAL_MODEL_VERSION,
        "benchmark_version": PROPOSAL_VERIFICATION_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "condition": condition,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path) if adapter_path else None,
        "adapter_config_sha256": (
            hashlib.sha256((adapter_path / "adapter_config.json").read_bytes()).hexdigest()
            if adapter_path else None
        ),
        "adapter_weights_sha256": (
            hashlib.sha256((adapter_path / "adapters.safetensors").read_bytes()).hexdigest()
            if adapter_path else None
        ),
        "metrics": result["metrics"],
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "generation": {"batch_size": batch_size, "max_tokens": max_tokens},
        "claim_boundary": (
            "The model proposes four typed edits; all execution, query selection, safety filtering, "
            "winner selection, and abstention are performed by the external controller."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest(f"proposal-model-{condition}-{evaluation_id}", manifest)
    return manifest


def assess_proposal_model(
    candidate: Mapping[str, Any],
    benchmark_root: Path,
    baselines: Mapping[str, Any],
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["proposal_gates"]
    metrics = candidate["metrics"]
    random_metrics = baselines["random_k4_metrics"]
    exact_coverage_gain = (
        metrics["exact_repair_coverage_at_k"] - random_metrics["exact_repair_coverage_at_k"]
    )
    checks = {
        "feasibility_prerequisite_passed": bool(baselines["passed"]),
        "same_benchmark_freeze": (
            candidate["benchmark_freeze_id"] == baselines["benchmark_freeze_id"] == freeze["freeze_id"]
        ),
        "adapter_present": candidate.get("adapter_path") is not None,
        "parse_coverage": metrics["parse_coverage"] >= gates["minimum_parse_coverage"],
        "unique_legal_proposals": (
            metrics["mean_unique_legal_proposals"] >= gates["minimum_mean_unique_legal_proposals"]
        ),
        "exact_repair_coverage_at_k": (
            metrics["exact_repair_coverage_at_k"] >= gates["minimum_exact_repair_coverage_at_k"]
        ),
        "behavioral_repair_coverage_at_k": (
            metrics["behavioral_repair_coverage_at_k"]
            >= gates["minimum_behavioral_repair_coverage_at_k"]
        ),
        "selected_semantic_accuracy": (
            metrics["selected_semantic_accuracy"] >= gates["minimum_selected_semantic_accuracy"]
        ),
        "selected_preservation": (
            metrics["selected_preserved_correct_accuracy"] >= gates["minimum_selected_preservation"]
        ),
        "selected_exact_rate": (
            metrics["selected_exact_rate"] >= gates["minimum_selected_exact_rate"]
        ),
        "heldout_selected_semantic_accuracy": (
            metrics["heldout_selected_semantic_accuracy"]
            >= gates["minimum_heldout_selected_semantic_accuracy"]
        ),
        "gain_over_top1": metrics["gain_over_top1"] >= gates["minimum_gain_over_top1"],
        "exact_coverage_gain_over_random": (
            exact_coverage_gain >= gates["minimum_exact_coverage_gain_over_random"]
        ),
    }
    payload = {
        "version": PROPOSAL_MODEL_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "candidate_evaluation_id": candidate["evaluation_id"],
        "controller_baseline_evaluation_id": baselines["evaluation_id"],
        "metrics": metrics,
        "random_k4_metrics": random_metrics,
        "exact_coverage_gain_over_random": exact_coverage_gain,
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
    }
    return {**payload, "assessment_id": content_digest(payload)}
