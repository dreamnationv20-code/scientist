from __future__ import annotations

import hashlib
import json
import random
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    Intervention,
    enumerate_interventions,
    legal_values,
    score_on_cases,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
    LOCALIZATION_TRAIN_REPRESENTATIONS,
    REPRESENTATIONS,
    RepairTask,
    _build_task,
    execute,
)


PROPOSAL_VERIFICATION_VERSION = "general-cognitive-proposal-verification-v36"
M36_SPLIT_SEEDS = {"train": 36037, "valid": 36061, "test": 36109}
PROPOSAL_BUDGET = 4
MAX_ACTIVE_QUERIES = 3


@dataclass(frozen=True)
class ControllerOutcome:
    program: Mapping[str, Any]
    selected_key: str
    fallback_to_candidate: bool
    active_queries: Tuple[Mapping[str, Any], ...]
    viable_proposal_count: int


def build_m36_suite(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[RepairTask, ...]:
    if split not in M36_SPLIT_SEEDS:
        raise ValueError("unknown M36 split")
    rng = random.Random(M36_SPLIT_SEEDS[split])
    tasks = tuple(
        _build_task(f"m36_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("M36 task ids are not unique")
    return tasks


def proposal_prompt(task: RepairTask) -> str:
    nodes = "\n".join(
        f"  {node}={json.dumps(value, sort_keys=True)}"
        for node, value in sorted(task.candidate.items())
    )
    correct = "\n".join(
        f"  input={json.dumps(case['input'])} -> required={json.dumps(case['expected'])}"
        for case in task.visible_correct
    )
    bad = task.counterexample
    domains = "\n".join(
        f"  {node}: {json.dumps(list(legal_values(task, node)), sort_keys=True)}"
        for node in sorted(task.candidate)
    )
    return (
        f"Representation: {task.representation}\n"
        "A candidate mechanism has exactly one faulty typed node. Propose four distinct minimal one-node "
        "repairs for an external executor to test. Optimize coverage: include the likely repair, but use "
        "different nodes when evidence is uncertain. Do not choose a winner or regenerate the mechanism.\n"
        f"Candidate nodes:\n{nodes}\n"
        f"Known invariants:\n{correct}\n"
        f"Failing case: input={json.dumps(bad['input'])}; candidate_output={json.dumps(bad['candidate'])}; "
        f"required={json.dumps(bad['expected'])}\n"
        f"Allowed replacement values (current values already excluded):\n{domains}\n"
        "Return exactly four lines after PROPOSALS, using JSON scalar values:\n"
        "PROPOSALS:\n1. node=<node>; value=<JSON value>\n2. node=<node>; value=<JSON value>\n"
        "3. node=<node>; value=<JSON value>\n4. node=<node>; value=<JSON value>"
    )


def _key(node: str, value: Any) -> str:
    return f"{node}={json.dumps(value, sort_keys=True)}"


def curated_training_proposals(task: RepairTask) -> Tuple[Intervention, ...]:
    interventions = list(enumerate_interventions(task))
    correct_key = _key(task.target_node, task.correct_edit_value)
    correct = next(item for item in interventions if item.key == correct_key)
    alternatives = [item for item in interventions if item.key != correct_key]
    alternatives.sort(
        key=lambda item: (
            -int(item.fixes_counterexample),
            -item.visible_preserved,
            item.node,
            item.key,
        )
    )
    selected = [correct]
    used_nodes = {correct.node}
    for item in alternatives:
        if len(selected) >= PROPOSAL_BUDGET:
            break
        if item.node not in used_nodes:
            selected.append(item)
            used_nodes.add(item.node)
    for item in alternatives:
        if len(selected) >= PROPOSAL_BUDGET:
            break
        if item not in selected:
            selected.append(item)
    seed = int(hashlib.sha256(task.task_id.encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(selected)
    return tuple(selected)


def proposal_record(task: RepairTask) -> Mapping[str, Any]:
    lines = ["PROPOSALS:"]
    for index, proposal in enumerate(curated_training_proposals(task), 1):
        lines.append(
            f"{index}. node={proposal.node}; value={json.dumps(proposal.value, sort_keys=True)}"
        )
    return {
        "messages": [
            {"role": "user", "content": proposal_prompt(task)},
            {"role": "assistant", "content": "\n".join(lines)},
        ],
        "metadata": {
            "task_id": task.task_id,
            "representation": task.representation,
            "mode": "diverse_typed_proposals",
            "proposal_budget": PROPOSAL_BUDGET,
        },
    }


_PROPOSAL_RE = re.compile(
    r"(?:^|\n)\s*\d+\.\s*node\s*=\s*([^;\s]+)\s*;\s*value\s*=\s*([^\n\r]+)",
    re.IGNORECASE,
)


def parse_proposals(task: RepairTask, response: str) -> Tuple[Intervention, ...]:
    intervention_by_key = {item.key: item for item in enumerate_interventions(task)}
    proposals = []
    seen = set()
    for node, raw in _PROPOSAL_RE.findall(response):
        raw = raw.strip().rstrip(".;")
        try:
            value = json.loads(raw)
        except json.JSONDecodeError:
            value = raw.strip("`\"'")
        key = _key(node.strip(), value)
        if key in intervention_by_key and key not in seen:
            proposals.append(intervention_by_key[key])
            seen.add(key)
        if len(proposals) >= PROPOSAL_BUDGET:
            break
    return tuple(proposals)


def _prediction(task: RepairTask, intervention: Intervention, case: Mapping[str, Any]) -> str:
    try:
        value = execute(task.representation, intervention.program, case["input"])
    except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
        value = "execution_error"
    return json.dumps(value, sort_keys=True)


def fixed_case_partition(task: RepairTask) -> Tuple[Tuple[Mapping[str, Any], ...], Tuple[Mapping[str, Any], ...]]:
    diagnostic_count = min(MAX_ACTIVE_QUERIES, max(0, len(task.hidden_cases) // 2))
    diagnostic = tuple(task.hidden_cases[:diagnostic_count])
    final = tuple(task.hidden_cases[diagnostic_count:])
    return diagnostic, final


def verified_select(task: RepairTask, proposals: Sequence[Intervention]) -> ControllerOutcome:
    survivors = [proposal for proposal in proposals if proposal.viable]
    initial_viable_count = len(survivors)
    diagnostic, _ = fixed_case_partition(task)
    used = []
    remaining = list(diagnostic)
    while len(survivors) > 1 and remaining and len(used) < MAX_ACTIVE_QUERIES:
        ranked = []
        for index, case in enumerate(remaining):
            diversity = len({_prediction(task, proposal, case) for proposal in survivors})
            ranked.append((diversity, -index, index, case))
        diversity, _, index, case = max(ranked, key=lambda item: (item[0], item[1]))
        if diversity <= 1:
            break
        remaining.pop(index)
        used.append({"input": case["input"], "expected": case["expected"]})
        expected = json.dumps(case["expected"], sort_keys=True)
        survivors = [
            proposal for proposal in survivors if _prediction(task, proposal, case) == expected
        ]
    if not survivors:
        return ControllerOutcome(dict(task.candidate), "", True, tuple(used), initial_viable_count)
    selected = min(survivors, key=lambda proposal: proposal.key)
    return ControllerOutcome(
        dict(selected.program), selected.key, False, tuple(used), initial_viable_count
    )


def random_proposals(task: RepairTask) -> Tuple[Intervention, ...]:
    interventions = list(enumerate_interventions(task))
    seed = int(hashlib.sha256(("random-v36-" + task.task_id).encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(interventions)
    return tuple(interventions[:PROPOSAL_BUDGET])


def aggregate_proposal_sets(
    condition: str,
    tasks: Sequence[RepairTask],
    proposal_sets: Sequence[Sequence[Intervention]],
    *,
    parsed_flags: Sequence[bool] | None = None,
    proposal_budget: int | None = PROPOSAL_BUDGET,
) -> Mapping[str, Any]:
    if len(tasks) != len(proposal_sets):
        raise ValueError("tasks and proposal sets do not align")
    if parsed_flags is None:
        parsed_flags = [True] * len(tasks)
    records = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    for task, proposals, parsed in zip(tasks, proposal_sets, parsed_flags):
        proposals = tuple(proposals if proposal_budget is None else proposals[:proposal_budget])
        _, final_cases = fixed_case_partition(task)
        correct_key = _key(task.target_node, task.correct_edit_value)
        exact_coverage = correct_key in {proposal.key for proposal in proposals}
        behavioral_coverage = any(
            score_on_cases(task, proposal.program, final_cases) == 1.0 for proposal in proposals
        )
        outcome = verified_select(task, proposals)
        top1_outcome = verified_select(task, proposals[:1])
        assessment = {
            "parsed": bool(parsed),
            "unique_legal_proposals": len(proposals),
            "exact_repair_coverage": exact_coverage,
            "behavioral_repair_coverage": behavioral_coverage,
            "selected_semantic_accuracy": score_on_cases(task, outcome.program, final_cases),
            "selected_preserved_correct_accuracy": score_on_cases(
                task, outcome.program, task.visible_correct
            ),
            "selected_exact": dict(outcome.program) == dict(task.authority),
            "fallback_to_candidate": outcome.fallback_to_candidate,
            "active_query_count": len(outcome.active_queries),
            "top1_semantic_accuracy": score_on_cases(task, top1_outcome.program, final_cases),
        }
        records.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "proposal_keys": [proposal.key for proposal in proposals],
                "selected_key": outcome.selected_key,
                "assessment": assessment,
            }
        )
        by_representation.setdefault(task.representation, []).append(assessment)

    def mean(items: Sequence[Mapping[str, Any]], key: str) -> float:
        return sum(float(item[key]) for item in items) / len(items)

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        return {
            "parse_coverage": mean(items, "parsed"),
            "mean_unique_legal_proposals": mean(items, "unique_legal_proposals"),
            "exact_repair_coverage_at_k": mean(items, "exact_repair_coverage"),
            "behavioral_repair_coverage_at_k": mean(items, "behavioral_repair_coverage"),
            "selected_semantic_accuracy": mean(items, "selected_semantic_accuracy"),
            "selected_preserved_correct_accuracy": mean(
                items, "selected_preserved_correct_accuracy"
            ),
            "selected_exact_rate": mean(items, "selected_exact"),
            "fallback_rate": mean(items, "fallback_to_candidate"),
            "mean_active_queries": mean(items, "active_query_count"),
            "top1_semantic_accuracy": mean(items, "top1_semantic_accuracy"),
            "gain_over_top1": mean(items, "selected_semantic_accuracy")
            - mean(items, "top1_semantic_accuracy"),
        }

    assessments = [record["assessment"] for record in records]
    heldout = [
        record["assessment"]
        for record in records
        if record["representation"] in HELDOUT_LOCALIZATION_REPRESENTATIONS
    ]
    return {
        "metrics": {
            "condition": condition,
            "task_count": len(tasks),
            **summarize(assessments),
            "heldout_selected_semantic_accuracy": summarize(heldout)[
                "selected_semantic_accuracy"
            ],
            "by_representation": {
                representation: summarize(items)
                for representation, items in sorted(by_representation.items())
            },
        },
        "records": records,
    }


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def prepare_m36_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    train = build_m36_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)
    valid = build_m36_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)
    test = build_m36_suite("test", 30)
    (output / "proposal").mkdir(parents=True, exist_ok=True)
    hashes = {
        "proposal_train": _write_jsonl(
            output / "proposal/train.jsonl", (proposal_record(task) for task in train)
        ),
        "proposal_valid": _write_jsonl(
            output / "proposal/valid.jsonl", (proposal_record(task) for task in valid)
        ),
        "test_public": _write_jsonl(
            output / "test-public.jsonl",
            (
                {
                    "task_id": task.task_id,
                    "representation": task.representation,
                    "prompt": proposal_prompt(task),
                }
                for task in test
            ),
        ),
        "test_authority": _write_jsonl(
            output / "test-authority.jsonl",
            (
                {
                    "task_id": task.task_id,
                    "representation": task.representation,
                    "target_node": task.target_node,
                    "correct_edit_value": task.correct_edit_value,
                    "final_cases": list(fixed_case_partition(task)[1]),
                }
                for task in test
            ),
        ),
    }
    payload = {
        "version": PROPOSAL_VERIFICATION_VERSION,
        "split_seeds": M36_SPLIT_SEEDS,
        "representations": list(REPRESENTATIONS),
        "training_representations": list(LOCALIZATION_TRAIN_REPRESENTATIONS),
        "heldout_representations": list(HELDOUT_LOCALIZATION_REPRESENTATIONS),
        "proposal_budget": PROPOSAL_BUDGET,
        "max_active_queries": MAX_ACTIVE_QUERIES,
        "counts": {"train": len(train), "valid": len(valid), "test": len(test)},
        "hashes": hashes,
        "feasibility_gates": {
            "minimum_full_enumeration_semantic_accuracy": 0.98,
            "minimum_full_enumeration_preservation": 1.0,
            "minimum_full_enumeration_exact_rate": 0.90,
        },
        "proposal_gates": {
            "minimum_parse_coverage": 0.98,
            "minimum_mean_unique_legal_proposals": 3.5,
            "minimum_exact_repair_coverage_at_k": 0.70,
            "minimum_behavioral_repair_coverage_at_k": 0.78,
            "minimum_selected_semantic_accuracy": 0.85,
            "minimum_selected_preservation": 1.0,
            "minimum_selected_exact_rate": 0.60,
            "minimum_heldout_selected_semantic_accuracy": 0.80,
            "minimum_gain_over_top1": 0.10,
            "minimum_exact_coverage_gain_over_random": 0.20,
        },
        "claim_boundary": (
            "M36 measures budgeted typed hypothesis coverage and deterministic verification on fresh "
            "synthetic single-fault mechanisms. Fixed diagnostic cases are excluded from final scoring."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m36_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "proposal_train": output / "proposal/train.jsonl",
        "proposal_valid": output / "proposal/valid.jsonl",
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    train_text = (output / "proposal/train.jsonl").read_text(encoding="utf-8")
    train_ids = {task.task_id for task in build_m36_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    valid_ids = {task.task_id for task in build_m36_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)}
    test_ids = {task.task_id for task in build_m36_suite("test", 30)}
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "heldout_representations_absent_from_training": (
            '"representation": "program"' not in train_text
            and '"representation": "planning"' not in train_text
        ),
        "splits_are_disjoint": not (train_ids & valid_ids or train_ids & test_ids or valid_ids & test_ids),
        "test_not_exposed_to_mlx": not (output / "proposal/test.jsonl").exists(),
        "gates_frozen": "feasibility_gates" in freeze and "proposal_gates" in freeze,
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}


def run_controller_baselines(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_m36_suite("test", 30)
    full_sets = [enumerate_interventions(task) for task in tasks]
    random_sets = [random_proposals(task) for task in tasks]
    full = aggregate_proposal_sets(
        "full_enumeration", tasks, full_sets, proposal_budget=None
    )
    random_result = aggregate_proposal_sets("random_k4", tasks, random_sets)
    gates = freeze["feasibility_gates"]
    checks = {
        "semantic_accuracy": (
            full["metrics"]["selected_semantic_accuracy"]
            >= gates["minimum_full_enumeration_semantic_accuracy"]
        ),
        "preservation": (
            full["metrics"]["selected_preserved_correct_accuracy"]
            >= gates["minimum_full_enumeration_preservation"]
        ),
        "exact_rate": (
            full["metrics"]["selected_exact_rate"]
            >= gates["minimum_full_enumeration_exact_rate"]
        ),
    }
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "proposal_controller_baselines",
        {"full_enumeration": full["records"], "random_k4": random_result["records"]},
    )
    payload = {
        "version": PROPOSAL_VERIFICATION_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "full_enumeration_metrics": full["metrics"],
        "random_k4_metrics": random_result["metrics"],
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
        "predictions_digest": predictions_digest,
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"proposal-controller-baselines-{manifest['evaluation_id']}", manifest)
    return manifest
