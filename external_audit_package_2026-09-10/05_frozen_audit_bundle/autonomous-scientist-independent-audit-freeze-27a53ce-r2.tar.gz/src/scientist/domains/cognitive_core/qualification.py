from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.domains.cognitive_core.adapter import CognitiveCoreAdapter
from scientist.domains.cognitive_core.generators import (
    generate_suite,
    knowledge_table,
)
from scientist.domains.cognitive_core.models import (
    CognitiveObservation,
    CognitiveProbe,
    ProbeKind,
)
from scientist.domains.cognitive_core.policies import (
    PolicyKind,
    ReferencePolicy,
)
from scientist.kernel.conformance import check_adapter_conformance
from scientist.kernel.contracts import EvidencePartition


@dataclass(frozen=True)
class QualificationReport:
    passed: bool
    checks: Mapping[str, bool]
    metrics: Mapping[str, float]
    suite_size: int
    qualification_version: str = "cognitive-core-qualification-v1"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "metrics": dict(sorted(self.metrics.items())),
            "suite_size": self.suite_size,
            "qualification_version": self.qualification_version,
        }


def _accuracy(
    adapter: CognitiveCoreAdapter,
    candidate: ReferencePolicy,
    probes: Tuple[CognitiveProbe, ...],
) -> float:
    return sum(
        adapter.evaluate(candidate, probe).reported_correct
        for probe in probes
    ) / float(len(probes))


def run_qualification(
    seeds: range = range(24),
    knowledge_seed: int = 1729,
    fact_count: int = 32,
) -> QualificationReport:
    adapter = CognitiveCoreAdapter()
    facts = tuple(
        sorted(knowledge_table(knowledge_seed, fact_count, 16).items())
    )
    oracle = ReferencePolicy(
        "semantic oracle",
        PolicyKind.COGNITIVE_ORACLE,
        facts,
    )
    memorizer = ReferencePolicy(
        "parametric memorizer",
        PolicyKind.MEMORIZER,
        facts,
    )
    follower = ReferencePolicy(
        "unselective evidence follower",
        PolicyKind.EVIDENCE_FOLLOWER,
        facts,
    )

    kinds = tuple(ProbeKind)
    partition_suites = {
        partition: generate_suite(
            kinds,
            seeds,
            partition,
            knowledge_seed=knowledge_seed,
            fact_count=fact_count,
        )
        for partition in (
            EvidencePartition.DEVELOPMENT,
            EvidencePartition.GUARD,
            EvidencePartition.AUDIT,
            EvidencePartition.REPLICATION,
        )
    }
    development = partition_suites[EvidencePartition.DEVELOPMENT]
    by_kind = {
        kind: tuple(
            probe
            for probe in development
            if probe.public_input.kind == kind
        )
        for kind in kinds
    }
    all_ids = [
        probe.probe_id
        for suite in partition_suites.values()
        for probe in suite
    ]
    regenerated = generate_suite(
        kinds,
        seeds,
        EvidencePartition.DEVELOPMENT,
        knowledge_seed=knowledge_seed,
        fact_count=fact_count,
    )
    conformance = check_adapter_conformance(
        adapter,
        oracle,
        memorizer,
        development[0],
    )
    valid_observation = adapter.evaluate(oracle, development[0])
    tampered = CognitiveObservation(
        candidate_id=valid_observation.candidate_id,
        probe_id=valid_observation.probe_id,
        predicted_answer=valid_observation.predicted_answer,
        confidence=valid_observation.confidence,
        source=valid_observation.source,
        reported_correct=not valid_observation.reported_correct,
    )

    metrics = {
        "oracle_overall_accuracy": _accuracy(
            adapter,
            oracle,
            development,
        ),
        "memorizer_closed_book_accuracy": _accuracy(
            adapter,
            memorizer,
            by_kind[ProbeKind.CLOSED_BOOK_FACT],
        ),
        "memorizer_procedure_accuracy": _accuracy(
            adapter,
            memorizer,
            by_kind[ProbeKind.PROCEDURE],
        ),
        "memorizer_unknown_abstention_accuracy": _accuracy(
            adapter,
            memorizer,
            by_kind[ProbeKind.UNKNOWN_FACT],
        ),
        "follower_oracle_evidence_accuracy": _accuracy(
            adapter,
            follower,
            by_kind[ProbeKind.ORACLE_EVIDENCE],
        ),
        "follower_irrelevant_evidence_accuracy": _accuracy(
            adapter,
            follower,
            by_kind[ProbeKind.IRRELEVANT_EVIDENCE],
        ),
    }
    checks = {
        "partition_ids_are_disjoint": len(all_ids) == len(set(all_ids)),
        "generator_is_deterministic": development == regenerated,
        "adapter_conforms": conformance.passed,
        "verifier_rejects_tampered_correctness": (
            not adapter.verify(development[0], tampered).passed
        ),
        "semantic_oracle_is_detected": (
            metrics["oracle_overall_accuracy"] == 1.0
        ),
        "memorization_is_not_procedural_transfer": (
            metrics["memorizer_closed_book_accuracy"] == 1.0
            and metrics["memorizer_procedure_accuracy"] < 0.5
        ),
        "memorizer_does_not_fake_abstention": (
            metrics["memorizer_unknown_abstention_accuracy"] == 0.0
        ),
        "unselective_evidence_use_is_detected": (
            metrics["follower_oracle_evidence_accuracy"] < 0.5
            and metrics["follower_irrelevant_evidence_accuracy"] < 0.5
        ),
    }
    return QualificationReport(
        passed=all(checks.values()),
        checks=checks,
        metrics=metrics,
        suite_size=len(all_ids),
    )
