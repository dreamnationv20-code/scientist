from __future__ import annotations

import ast
import hashlib
import json
import re
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


VERSION = "general-cognitive-reasoning-posttraining-baseline-v53ar"
SELECTION_SEED = 53002
ITEMS_PER_FAMILY = 8
FAMILIES = ("math", "code", "planning", "counterfactual", "tool_use")

MODEL_CONTRACT = (
    {
        "key": "general_1p5b",
        "repository": "mlx-community/Qwen2.5-1.5B-Instruct-4bit",
        "revision": "8b403126fc14f14cfc99bb4cfa72ecbc129ea677",
        "role": "same-size general-instruction control",
    },
    {
        "key": "math_1p5b",
        "repository": "mlx-community/Qwen2.5-Math-1.5B-Instruct-4bit",
        "revision": "ab004e134e47042c3db99d1721371626b520ac73",
        "role": "same-size domain-specialization control",
    },
    {
        "key": "reasoning_1p5b",
        "repository": "mlx-community/DeepSeek-R1-Distill-Qwen-1.5B-4bit",
        "revision": "933185be1b8f81d9a21dcfa15ff73470d3545240",
        "role": "reasoning-distilled candidate",
    },
    {
        "key": "general_3b",
        "repository": "mlx-community/Qwen2.5-3B-Instruct-4bit",
        "revision": "4f83f8f146fdf28b512a06562b671d7af4fab457",
        "role": "ordinary scale control",
    },
)

SOURCE_CONTRACT = {
    "gsm8k": {
        "repository": "https://github.com/openai/grade-school-math",
        "revision": "3101c7d5072418e28b9008a6636bde82a006892c",
        "path": "third_party/grade-school-math/grade_school_math/data/test.jsonl",
        "license": "MIT",
    },
    "cruxeval": {
        "repository": "https://github.com/facebookresearch/cruxeval",
        "revision": "190faf16d175b5847b0af05d937872b1fb395942",
        "path": "third_party/cruxeval/data/cruxeval.jsonl",
        "license": "MIT",
    },
    "planbench": {
        "repository": "https://github.com/harshakokel/PlanBench",
        "revision": "1f4d600f4806bedbefebbbe44b168372aaf5060d",
        "path": "third_party/PlanBench/plan-bench/prompts/blocksworld/task_1_plan_generation.json",
        "instance_root": "third_party/PlanBench/plan-bench/instances/blocksworld/generated_basic",
        "license": "repository license",
    },
    "cladder": {
        "repository": "https://github.com/causalNLP/cladder",
        "revision": "3d2d1169b4b939a09048a6a75956c8972a93cc38",
        "path": "third_party/cladder/data/cladder-v1-questions.json",
        "license": "MIT",
    },
    "bfcl": {
        "repository": "https://huggingface.co/datasets/gorilla-llm/Berkeley-Function-Calling-Leaderboard",
        "revision": "61fc0608cfd831fcfbbaa676ebdfef0ed963eeda",
        "path": "third_party/BFCL-v1/BFCL_v3_simple.json",
        "answer_path": "third_party/BFCL-v1/possible_answer/BFCL_v3_simple.json",
        "license": "Apache-2.0",
    },
}

TOKEN_BUDGETS = {
    "math": 640,
    "code": 512,
    "planning": 768,
    "counterfactual": 640,
    "tool_use": 256,
}


@dataclass(frozen=True)
class BaselineTask:
    task_id: str
    family: str
    prompt: str
    authority: Mapping[str, Any]
    source_id: str

    def public_dict(self) -> Mapping[str, Any]:
        return {
            "task_id": self.task_id,
            "family": self.family,
            "prompt": self.prompt,
            "source_id": self.source_id,
            "maximum_new_tokens": TOKEN_BUDGETS[self.family],
        }

    def authority_dict(self) -> Mapping[str, Any]:
        return {**self.public_dict(), "authority": dict(self.authority)}


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _read_jsonl(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    )


def _write_immutable(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M53A artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")


def _jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _stable_select(
    rows: Sequence[Mapping[str, Any]], identity_key: str, count: int
) -> Tuple[Mapping[str, Any], ...]:
    ranked = sorted(
        rows,
        key=lambda row: hashlib.sha256(
            f"{SELECTION_SEED}:{row[identity_key]}".encode("utf-8")
        ).hexdigest(),
    )
    if len(ranked) < count:
        raise ValueError("not enough source rows for frozen M53A sample")
    return tuple(ranked[:count])


def _math_tasks(project: Path) -> Tuple[BaselineTask, ...]:
    source = project / str(SOURCE_CONTRACT["gsm8k"]["path"])
    rows = tuple({**row, "row_id": index} for index, row in enumerate(_read_jsonl(source)))
    selected = _stable_select(rows, "row_id", ITEMS_PER_FAMILY)
    tasks = []
    for row in selected:
        gold = str(row["answer"]).rsplit("####", 1)[-1].strip()
        prompt = (
            "Solve this grade-school mathematics problem. You may reason step by step, "
            "but finish with exactly one line `FINAL: <number>`.\n\n"
            + str(row["question"])
        )
        tasks.append(
            BaselineTask(
                f"m53a-math-{int(row['row_id']):04d}",
                "math",
                prompt,
                {"answer": gold},
                f"gsm8k-test-{int(row['row_id'])}",
            )
        )
    return tuple(tasks)


def _code_tasks(project: Path) -> Tuple[BaselineTask, ...]:
    source = project / str(SOURCE_CONTRACT["cruxeval"]["path"])
    candidates = []
    for row in _read_jsonl(source):
        try:
            ast.literal_eval(str(row["input"]))
            ast.literal_eval(str(row["output"]))
        except (SyntaxError, ValueError):
            continue
        if len(str(row["code"])) <= 900 and len(str(row["output"])) <= 240:
            candidates.append(row)
    selected = _stable_select(candidates, "id", ITEMS_PER_FAMILY)
    return tuple(
        BaselineTask(
            f"m53a-code-{row['id']}",
            "code",
            (
                "Predict the exact Python value returned by this call without running it. "
                "You may reason step by step, but finish with exactly one line containing "
                "`FINAL: <Python literal>`.\n\n"
                f"{row['code']}\n\nCall: f({row['input']})"
            ),
            {"output": str(row["output"])},
            str(row["id"]),
        )
        for row in selected
    )


def _planning_tasks(project: Path) -> Tuple[BaselineTask, ...]:
    source = project / str(SOURCE_CONTRACT["planbench"]["path"])
    payload = json.loads(source.read_text(encoding="utf-8"))
    candidates = [
        row
        for row in payload["instances"]
        if 1 <= len(str(row["ground_truth_plan"]).splitlines()) <= 8
    ]
    selected = _stable_select(candidates, "instance_id", ITEMS_PER_FAMILY)
    root = project / str(SOURCE_CONTRACT["planbench"]["instance_root"])
    tasks = []
    for row in selected:
        instance_id = int(row["instance_id"])
        pddl_path = root / f"instance-{instance_id}.pddl"
        prompt = (
            str(row["query"])
            + "\nReturn only the actions after the final [PLAN] marker. End with a line `FINAL: done`."
        )
        tasks.append(
            BaselineTask(
                f"m53a-planning-{instance_id:04d}",
                "planning",
                prompt,
                {
                    "pddl": pddl_path.read_text(encoding="utf-8"),
                    "reference_plan": str(row["ground_truth_plan"]),
                },
                f"planbench-blocksworld-{instance_id}",
            )
        )
    return tuple(tasks)


def _counterfactual_tasks(project: Path) -> Tuple[BaselineTask, ...]:
    source = project / str(SOURCE_CONTRACT["cladder"]["path"])
    rows = json.loads(source.read_text(encoding="utf-8"))
    candidates = [
        row
        for row in rows
        if int(row.get("meta", {}).get("rung", 0)) == 3
        and str(row.get("answer", "")).casefold() in {"yes", "no"}
    ]
    positives = [row for row in candidates if str(row["answer"]).casefold() == "yes"]
    negatives = [row for row in candidates if str(row["answer"]).casefold() == "no"]
    selected = (
        *_stable_select(positives, "question_id", ITEMS_PER_FAMILY // 2),
        *_stable_select(negatives, "question_id", ITEMS_PER_FAMILY // 2),
    )
    return tuple(
        BaselineTask(
            f"m53a-counterfactual-{int(row['question_id']):05d}",
            "counterfactual",
            (
                "Answer the causal or counterfactual question using only the supplied "
                "structural/probabilistic information. You may reason step by step, but "
                "finish with exactly `FINAL: yes` or `FINAL: no`.\n\n"
                f"Information: {row['given_info']}\nQuestion: {row['question']}"
            ),
            {
                "answer": str(row["answer"]).casefold(),
                "query_type": str(row["meta"]["query_type"]),
                "story_id": str(row["meta"]["story_id"]),
            },
            f"cladder-{int(row['question_id'])}",
        )
        for row in selected
    )


def _tool_tasks(project: Path) -> Tuple[BaselineTask, ...]:
    questions = _read_jsonl(project / str(SOURCE_CONTRACT["bfcl"]["path"]))
    answers = {
        str(row["id"]): row
        for row in _read_jsonl(project / str(SOURCE_CONTRACT["bfcl"]["answer_path"]))
    }
    candidates = [
        row
        for row in questions
        if len(row.get("function", ())) == 1
        and str(row["id"]) in answers
        and len(answers[str(row["id"])].get("ground_truth", ())) == 1
    ]
    selected = _stable_select(candidates, "id", ITEMS_PER_FAMILY)
    tasks = []
    for row in selected:
        user = str(row["question"][0][0]["content"])
        functions = row["function"]
        prompt = (
            "Choose the correct function and arguments for the user request. Do not execute "
            "the function. Finish with exactly one JSON line of the form "
            "`FINAL: {\"name\":\"function_name\",\"arguments\":{...}}`.\n\n"
            f"Functions: {json.dumps(functions, sort_keys=True)}\nUser: {user}"
        )
        tasks.append(
            BaselineTask(
                f"m53a-tool-{row['id']}",
                "tool_use",
                prompt,
                {
                    "ground_truth": answers[str(row["id"])]["ground_truth"],
                    "function_schema": functions[0],
                },
                f"bfcl-{row['id']}",
            )
        )
    return tuple(tasks)


def build_tasks(project: Path) -> Tuple[BaselineTask, ...]:
    tasks = (
        *_math_tasks(project),
        *_code_tasks(project),
        *_planning_tasks(project),
        *_counterfactual_tasks(project),
        *_tool_tasks(project),
    )
    if len(tasks) != ITEMS_PER_FAMILY * len(FAMILIES):
        raise RuntimeError("M53A task count is not balanced")
    if {task.family for task in tasks} != set(FAMILIES):
        raise RuntimeError("M53A family coverage is incomplete")
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("M53A task IDs are not unique")
    return tuple(tasks)


def prepare_benchmark(project: Path, output: Path) -> Mapping[str, Any]:
    tasks = build_tasks(project)
    public_payload = _jsonl(task.public_dict() for task in tasks)
    authority_payload = _jsonl(task.authority_dict() for task in tasks)
    source_files = {}
    for name, contract in SOURCE_CONTRACT.items():
        keys = [key for key in ("path", "answer_path") if key in contract]
        source_files[name] = {
            str(contract[key]): _sha256(project / str(contract[key])) for key in keys
        }
        if name == "planbench":
            source_files[name]["selected_pddl_sha256"] = content_digest(
                {
                    task.source_id: hashlib.sha256(
                        str(task.authority["pddl"]).encode("utf-8")
                    ).hexdigest()
                    for task in tasks
                    if task.family == "planning"
                }
            )
    invalid_preflight = (
        project
        / "data/cognitive_core/reasoning_posttraining_baseline_v53a/tasks-public.jsonl"
    )
    opened_source_ids = (
        {str(row["source_id"]) for row in _read_jsonl(invalid_preflight)}
        if invalid_preflight.exists()
        else set()
    )
    overlap = sorted(opened_source_ids & {task.source_id for task in tasks})
    if overlap:
        raise RuntimeError("M53A-R reuses an item opened by the invalid preflight")
    body = {
        "version": VERSION,
        "milestone": "M53A-R",
        "question": (
            "Does reasoning-oriented post-training improve a same-size small model across "
            "math, code reasoning, planning, counterfactual reasoning, and tool calling?"
        ),
        "selection_seed": SELECTION_SEED,
        "families": list(FAMILIES),
        "items_per_family": ITEMS_PER_FAMILY,
        "task_count": len(tasks),
        "source_contract": SOURCE_CONTRACT,
        "source_file_hashes": source_files,
        "model_contract": list(MODEL_CONTRACT),
        "inference_contract": {
            "sampling": "greedy",
            "temperature": 0.0,
            "single_sample_per_task": True,
            "matched_family_token_budgets": TOKEN_BUDGETS,
            "system_prompt": None,
            "model_specific_prompting": False,
            "tool_execution": False,
            "format_robust_scoring": {
                "math": "FINAL, boxed answer, then standard last-number extraction",
                "code": "FINAL, boxed literal, then last fenced or nonempty line",
                "counterfactual": "FINAL yes/no, then terminal yes/no extraction",
                "planning": "execute every recognized action sequence against PDDL",
                "tool_use": "FINAL call or last parseable JSON/Python call object",
            },
        },
        "gates": {
            "minimum_reasoning_gain_over_general_1p5b": 0.05,
            "minimum_reasoning_gain_over_math_1p5b": 0.025,
            "minimum_family_wins_over_general_1p5b": 3,
            "maximum_family_regression": 0.125,
            "minimum_parse_rate": 0.90,
        },
        "decision_rule": (
            "Proceed to verifier-filtered reasoning/plan distillation only if the reasoning "
            "checkpoint passes every frozen gate. A failure stops same-recipe distillation "
            "and redirects diagnosis to data coverage or recurrent test-time compute."
        ),
        "claim_boundary": (
            "This 40-item local pilot is a feasibility diagnostic. It is not a leaderboard "
            "result, a causal isolation of post-training, evidence of 70B parity, a general "
            "cognitive-core demonstration, or publication evidence. Quantization, model-base "
            "differences, benchmark contamination, and the small sample remain confounds."
        ),
        "public_tasks_sha256": hashlib.sha256(public_payload.encode("utf-8")).hexdigest(),
        "authority_tasks_sha256": hashlib.sha256(authority_payload.encode("utf-8")).hexdigest(),
        "labels_excluded_from_public_tasks": True,
        "no_development_selection": True,
        "invalid_preflight_exclusion": {
            "preflight_freeze_id": "a3bd3cf428a07ac26badaa144a65b41aedfcfbeb830c9b3228f90f529151039c",
            "opened_source_id_count": len(opened_source_ids),
            "opened_public_tasks_sha256": (
                _sha256(invalid_preflight) if invalid_preflight.exists() else None
            ),
            "overlap_count": len(overlap),
            "overlap": overlap,
        },
    }
    freeze = {**body, "freeze_id": content_digest(body)}
    _write_immutable(output / "tasks-public.jsonl", public_payload)
    _write_immutable(output / "tasks-authority.jsonl", authority_payload)
    _write_immutable(
        output / "protocol-freeze.json",
        json.dumps(freeze, indent=2, sort_keys=True) + "\n",
    )
    verification = verify_benchmark(project, output)
    _write_immutable(
        output / "protocol-verification.json",
        json.dumps(verification, indent=2, sort_keys=True) + "\n",
    )
    return freeze


def verify_benchmark(project: Path, output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "protocol-freeze.json").read_text(encoding="utf-8"))
    public_path = output / "tasks-public.jsonl"
    authority_path = output / "tasks-authority.jsonl"
    public_rows = _read_jsonl(public_path)
    authority_rows = _read_jsonl(authority_path)
    body = {key: value for key, value in freeze.items() if key != "freeze_id"}
    checks = {
        "freeze_id_is_content_derived": content_digest(body) == freeze["freeze_id"],
        "public_hash_matches": _sha256(public_path) == freeze["public_tasks_sha256"],
        "authority_hash_matches": _sha256(authority_path) == freeze["authority_tasks_sha256"],
        "balanced_families": all(
            sum(row["family"] == family for row in public_rows) == ITEMS_PER_FAMILY
            for family in FAMILIES
        ),
        "public_rows_have_no_authority": all("authority" not in row for row in public_rows),
        "public_authority_identities_match": [row["task_id"] for row in public_rows]
        == [row["task_id"] for row in authority_rows],
        "all_source_hashes_match": all(
            _sha256(project / path) == digest
            for files in freeze["source_file_hashes"].values()
            for path, digest in files.items()
            if path != "selected_pddl_sha256"
        ),
        "four_control_models_frozen": len(freeze["model_contract"]) == 4,
        "matched_token_budgets": freeze["inference_contract"][
            "matched_family_token_budgets"
        ]
        == TOKEN_BUDGETS,
        "invalid_preflight_items_excluded": freeze["invalid_preflight_exclusion"][
            "opened_source_id_count"
        ]
        == 40
        and freeze["invalid_preflight_exclusion"]["overlap_count"] == 0,
    }
    return {
        "version": VERSION,
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


_FINAL_RE = re.compile(r"FINAL\s*:\s*([^\n\r]+)", re.IGNORECASE)


def _final_value(response: str) -> str | None:
    values = _FINAL_RE.findall(response)
    return values[-1].strip().strip("`") if values else None


def _boxed_values(response: str) -> Tuple[str, ...]:
    values = []
    marker = "\\boxed{"
    start = 0
    while True:
        index = response.find(marker, start)
        if index < 0:
            break
        depth = 1
        cursor = index + len(marker)
        begin = cursor
        while cursor < len(response) and depth:
            if response[cursor] == "{":
                depth += 1
            elif response[cursor] == "}":
                depth -= 1
            cursor += 1
        if depth == 0:
            values.append(response[begin : cursor - 1].strip())
        start = max(cursor, index + len(marker))
    return tuple(values)


def _fraction(value: str) -> Fraction:
    cleaned = value.strip().replace(",", "").replace("$", "")
    cleaned = re.sub(r"[^0-9eE+./-].*$", "", cleaned)
    return Fraction(cleaned)


def score_math(authority: Mapping[str, Any], response: str) -> Mapping[str, Any]:
    answer = _final_value(response)
    method = "final"
    boxed = _boxed_values(response)
    if answer is None and boxed:
        answer = boxed[-1]
        method = "boxed"
    if answer is None:
        numbers = re.findall(r"(?<![A-Za-z0-9_])[-+]?\$?[0-9][0-9,]*(?:\.[0-9]+)?(?:/[0-9]+)?", response)
        if numbers:
            answer = numbers[-1]
            method = "last_number"
    if answer is None:
        return {"parsed": False, "correct": False, "answer": None}
    try:
        correct = _fraction(answer) == _fraction(str(authority["answer"]))
    except (ValueError, ZeroDivisionError):
        correct = False
    return {"parsed": True, "correct": bool(correct), "answer": answer, "method": method}


def score_code(authority: Mapping[str, Any], response: str) -> Mapping[str, Any]:
    answer = _final_value(response)
    method = "final"
    boxed = _boxed_values(response)
    if answer is None and boxed:
        answer = boxed[-1]
        method = "boxed"
    if answer is None:
        fences = re.findall(r"```(?:python)?\s*(.*?)```", response, re.IGNORECASE | re.DOTALL)
        candidates = [line.strip() for block in fences for line in block.splitlines() if line.strip()]
        if not candidates:
            candidates = [line.strip() for line in response.splitlines() if line.strip()]
        if candidates:
            answer = candidates[-1].strip("`")
            method = "terminal_line"
    if answer is None:
        return {"parsed": False, "correct": False, "answer": None}
    try:
        candidate = ast.literal_eval(answer)
        expected = ast.literal_eval(str(authority["output"]))
        correct = candidate == expected and type(candidate) is type(expected)
    except (MemoryError, RecursionError, SyntaxError, ValueError):
        correct = False
    return {"parsed": True, "correct": bool(correct), "answer": answer, "method": method}


_OBJECTS = {
    "red": "a",
    "blue": "b",
    "orange": "c",
    "yellow": "d",
    "white": "e",
    "magenta": "f",
    "black": "g",
    "cyan": "h",
    "green": "i",
    "violet": "j",
    "silver": "k",
    "gold": "l",
}


def _parse_plan(response: str) -> Tuple[Tuple[str, ...], ...]:
    plan_region = response.rsplit("[PLAN]", 1)[-1]
    plan_region = plan_region.split("FINAL:", 1)[0]
    actions = []
    pddl_pattern = re.compile(
        r"\((pick-up|put-down|stack|unstack)\s+([a-l])(?:\s+([a-l]))?\)",
        re.IGNORECASE,
    )
    for match in pddl_pattern.finditer(plan_region):
        actions.append(tuple(value.lower() for value in match.groups() if value))
    if actions:
        return tuple(actions)
    for raw in plan_region.splitlines():
        line = raw.strip().lower().strip("-*0123456789. )(")
        if not line:
            continue
        match = re.search(r"pick up the (\w+)(?: block)?", line)
        if match and match.group(1) in _OBJECTS:
            actions.append(("pick-up", _OBJECTS[match.group(1)]))
            continue
        match = re.search(r"put down the (\w+)(?: block)?", line)
        if match and match.group(1) in _OBJECTS:
            actions.append(("put-down", _OBJECTS[match.group(1)]))
            continue
        match = re.search(
            r"unstack the (\w+)(?: block)? from on top of the (\w+)", line
        )
        if match and all(value in _OBJECTS for value in match.groups()):
            actions.append(("unstack", *(_OBJECTS[value] for value in match.groups())))
            continue
        match = re.search(r"stack the (\w+)(?: block)? on top of the (\w+)", line)
        if match and all(value in _OBJECTS for value in match.groups()):
            actions.append(("stack", *(_OBJECTS[value] for value in match.groups())))
    return tuple(actions)


def _facts(text: str) -> Tuple[Tuple[str, ...], ...]:
    return tuple(
        (match.group(1).lower(), *match.group(2).lower().split())
        for match in re.finditer(
            r"\((handempty|holding|ontable|clear|on)\s*([^()]*)\)",
            text,
            re.IGNORECASE,
        )
    )


def execute_blocksworld(pddl: str, actions: Sequence[Sequence[str]]) -> Mapping[str, Any]:
    init_text, goal_text = pddl.split("(:goal", 1)
    init = _facts(init_text)
    goals = _facts(goal_text)
    on = {fact[1]: fact[2] for fact in init if fact[0] == "on"}
    ontable = {fact[1] for fact in init if fact[0] == "ontable"}
    clear = {fact[1] for fact in init if fact[0] == "clear"}
    holding = next((fact[1] for fact in init if fact[0] == "holding"), None)
    invalid_step = None
    for index, action in enumerate(actions):
        name, *args = action
        valid = False
        if name == "pick-up" and len(args) == 1:
            (x,) = args
            valid = holding is None and x in ontable and x in clear
            if valid:
                ontable.remove(x)
                clear.discard(x)
                holding = x
        elif name == "put-down" and len(args) == 1:
            (x,) = args
            valid = holding == x
            if valid:
                holding = None
                ontable.add(x)
                clear.add(x)
        elif name == "unstack" and len(args) == 2:
            x, y = args
            valid = holding is None and on.get(x) == y and x in clear
            if valid:
                del on[x]
                clear.discard(x)
                clear.add(y)
                holding = x
        elif name == "stack" and len(args) == 2:
            x, y = args
            valid = holding == x and y in clear and x != y
            if valid:
                holding = None
                on[x] = y
                clear.add(x)
                clear.discard(y)
        if not valid:
            invalid_step = index
            break
    def holds(fact: Sequence[str]) -> bool:
        if fact[0] == "on":
            return on.get(fact[1]) == fact[2]
        if fact[0] == "ontable":
            return fact[1] in ontable
        if fact[0] == "clear":
            return fact[1] in clear
        if fact[0] == "holding":
            return holding == fact[1]
        if fact[0] == "handempty":
            return holding is None
        return False
    return {
        "valid": invalid_step is None,
        "goal_reached": invalid_step is None and all(holds(fact) for fact in goals),
        "invalid_step": invalid_step,
        "action_count": len(actions),
    }


def score_planning(authority: Mapping[str, Any], response: str) -> Mapping[str, Any]:
    actions = _parse_plan(response)
    execution = execute_blocksworld(str(authority["pddl"]), actions)
    return {
        "parsed": bool(actions),
        "correct": bool(actions) and bool(execution["goal_reached"]),
        "actions": [list(action) for action in actions],
        "execution": execution,
    }


def score_counterfactual(
    authority: Mapping[str, Any], response: str
) -> Mapping[str, Any]:
    answer = _final_value(response)
    method = "final"
    if answer is None or answer.casefold() not in {"yes", "no"}:
        candidates = re.findall(r"\b(yes|no)\b", response, re.IGNORECASE)
        answer = candidates[-1] if candidates else None
        method = "terminal_yes_no"
    parsed = answer is not None and answer.casefold() in {"yes", "no"}
    return {
        "parsed": parsed,
        "correct": parsed and answer.casefold() == str(authority["answer"]).casefold(),
        "answer": answer,
        "method": method,
    }


def _parse_call(response: str) -> Mapping[str, Any] | None:
    candidates = []
    final = _final_value(response)
    if final is not None:
        candidates.append(final)
    candidates.extend(
        block.strip()
        for block in re.findall(r"```(?:json|python)?\s*(.*?)```", response, re.IGNORECASE | re.DOTALL)
    )
    for index, character in enumerate(response):
        if character != "{":
            continue
        depth = 0
        quoted = False
        escaped = False
        for cursor in range(index, len(response)):
            char = response[cursor]
            if quoted:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    quoted = False
                continue
            if char == '"':
                quoted = True
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    candidates.append(response[index : cursor + 1])
                    break
    parsed = []
    for answer in candidates:
        for loader in (json.loads, ast.literal_eval):
            try:
                value = loader(answer)
            except (SyntaxError, TypeError, ValueError, json.JSONDecodeError):
                continue
            if isinstance(value, dict) and {"name", "arguments"}.issubset(value):
                parsed.append(value)
    if parsed:
        return parsed[-1]
    return None


def score_tool_use(authority: Mapping[str, Any], response: str) -> Mapping[str, Any]:
    call = _parse_call(response)
    if call is None:
        return {"parsed": False, "correct": False, "call": None}
    name = call.get("name")
    arguments = call.get("arguments")
    if not isinstance(name, str) or not isinstance(arguments, dict):
        return {"parsed": False, "correct": False, "call": call}
    truth = authority["ground_truth"][0]
    expected_name = next(iter(truth))
    expected_arguments = truth[expected_name]
    schema = authority["function_schema"]["parameters"]
    required = set(schema.get("required", ()))
    allowed = set(expected_arguments)
    correct = name == expected_name and set(arguments).issubset(allowed)
    correct = correct and required.issubset(arguments)
    for key, value in arguments.items():
        correct = correct and value in expected_arguments[key]
    return {"parsed": True, "correct": bool(correct), "call": call}


SCORERS = {
    "math": score_math,
    "code": score_code,
    "planning": score_planning,
    "counterfactual": score_counterfactual,
    "tool_use": score_tool_use,
}


def score_response(
    family: str, authority: Mapping[str, Any], response: str
) -> Mapping[str, Any]:
    if family not in SCORERS:
        raise ValueError(f"unknown M53A family: {family}")
    return SCORERS[family](authority, response)


def summarize_records(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    if not records:
        raise ValueError("M53A requires records")
    by_family = {}
    for family in FAMILIES:
        local = [row for row in records if row["family"] == family]
        if len(local) != ITEMS_PER_FAMILY:
            raise ValueError(f"M53A incomplete family: {family}")
        by_family[family] = {
            "count": len(local),
            "accuracy": sum(bool(row["score"]["correct"]) for row in local) / len(local),
            "parse_rate": sum(bool(row["score"]["parsed"]) for row in local) / len(local),
            "mean_output_tokens": sum(int(row["output_tokens"]) for row in local) / len(local),
            "mean_seconds": sum(float(row["elapsed_seconds"]) for row in local) / len(local),
        }
    return {
        "count": len(records),
        "macro_accuracy": sum(value["accuracy"] for value in by_family.values()) / len(by_family),
        "micro_accuracy": sum(bool(row["score"]["correct"]) for row in records) / len(records),
        "parse_rate": sum(bool(row["score"]["parsed"]) for row in records) / len(records),
        "total_output_tokens": sum(int(row["output_tokens"]) for row in records),
        "total_seconds": sum(float(row["elapsed_seconds"]) for row in records),
        "by_family": by_family,
    }


def adjudicate(
    summaries: Mapping[str, Mapping[str, Any]], gates: Mapping[str, Any]
) -> Mapping[str, Any]:
    required = {item["key"] for item in MODEL_CONTRACT}
    if set(summaries) != required:
        raise ValueError("M53A requires all four frozen model summaries")
    reasoning = summaries["reasoning_1p5b"]
    general = summaries["general_1p5b"]
    math = summaries["math_1p5b"]
    family_deltas = {
        family: reasoning["by_family"][family]["accuracy"]
        - general["by_family"][family]["accuracy"]
        for family in FAMILIES
    }
    checks = {
        "reasoning_gain_over_general_1p5b": reasoning["macro_accuracy"]
        - general["macro_accuracy"]
        >= float(gates["minimum_reasoning_gain_over_general_1p5b"]),
        "reasoning_gain_over_math_1p5b": reasoning["macro_accuracy"]
        - math["macro_accuracy"]
        >= float(gates["minimum_reasoning_gain_over_math_1p5b"]),
        "family_win_count": sum(delta > 0 for delta in family_deltas.values())
        >= int(gates["minimum_family_wins_over_general_1p5b"]),
        "no_large_family_regression": min(family_deltas.values())
        >= -float(gates["maximum_family_regression"]),
        "reasoning_parse_rate": reasoning["parse_rate"]
        >= float(gates["minimum_parse_rate"]),
    }
    passed = all(checks.values())
    return {
        "checks": checks,
        "passed": passed,
        "reasoning_macro_gain_over_general_1p5b": reasoning["macro_accuracy"]
        - general["macro_accuracy"],
        "reasoning_macro_gain_over_math_1p5b": reasoning["macro_accuracy"]
        - math["macro_accuracy"],
        "reasoning_macro_gain_over_general_3b": reasoning["macro_accuracy"]
        - summaries["general_3b"]["macro_accuracy"],
        "family_deltas_over_general_1p5b": family_deltas,
        "family_win_count": sum(delta > 0 for delta in family_deltas.values()),
        "next_action": (
            "M53B_verifier_filtered_reasoning_and_plan_distillation"
            if passed
            else "halt_same_recipe_distillation_and_diagnose_family_failures"
        ),
    }
