from __future__ import annotations

from typing import Any, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.hubness_corrected_alignment_v52xc import (
    M52XC_HELDOUT_DIRECTIONS,
    M52XC_TRAINED_DIRECTIONS,
    calibration_gate_passed,
    evaluate_geometry_records,
    geometry_gate_passed,
    output_installation_gate_passed,
    select_earliest_pass,
)


RECIPROCAL_ROLE_ALIGNMENT_VERSION = "general-cognitive-reciprocal-role-alignment-v52xd"
M52XD_SEED = 53147
M52XD_M52XC_AUDIT_ID = (
    "c26925fce804e74be60588f75ccb5aa361f1184addc207e33d1bd4b8afbd351d"
)
M52XD_TRAINED_DIRECTIONS = M52XC_TRAINED_DIRECTIONS
M52XD_HELDOUT_DIRECTIONS = M52XC_HELDOUT_DIRECTIONS
M52XD_TRAINED_UNDIRECTED_EDGES = (
    ("name", "principle"),
    ("principle", "action"),
)
M52XD_ROLE_CONTEXTS = (
    "target_inspection",
    "requirement_observation",
    "goal_trace",
)

M52XD_SELECTION_TRANSFORM = {
    "name": "canonical",
    "principle": "contrastive_boundary",
    "action": "mechanistic_expansion",
}
M52XD_CONFIRMATION_TRANSFORM = {
    "name": "canonical",
    "principle": "invariant_abstraction",
    "action": "operational_trace",
}


def reciprocal_role_text(
    state: Mapping[str, str], channel: str, role: str, context: str
) -> str:
    value = str(state[channel])
    templates = {
        ("target_inspection", "name", "basis"): (
            "The target design calls for the method named {value}."
        ),
        ("target_inspection", "name", "candidate"): (
            "Inspection identifies the method as {value}."
        ),
        ("target_inspection", "principle", "basis"): (
            "The target design calls for this decision principle: {value}."
        ),
        ("target_inspection", "principle", "candidate"): (
            "Inspection identifies this decision principle: {value}."
        ),
        ("target_inspection", "action", "basis"): (
            "The target design calls for this operation: {value}."
        ),
        ("target_inspection", "action", "candidate"): (
            "Inspection identifies this operation: {value}."
        ),
        ("requirement_observation", "name", "basis"): (
            "The requirement specifies the technique {value}."
        ),
        ("requirement_observation", "name", "candidate"): (
            "The observation reveals the technique {value}."
        ),
        ("requirement_observation", "principle", "basis"): (
            "The requirement imposes the following rule: {value}."
        ),
        ("requirement_observation", "principle", "candidate"): (
            "The observation reveals the following rule: {value}."
        ),
        ("requirement_observation", "action", "basis"): (
            "The requirement specifies this operational step: {value}."
        ),
        ("requirement_observation", "action", "candidate"): (
            "The observation reveals this operational step: {value}."
        ),
        ("goal_trace", "name", "basis"): (
            "The intended solution uses the approach called {value}."
        ),
        ("goal_trace", "name", "candidate"): (
            "The execution trace uses the approach called {value}."
        ),
        ("goal_trace", "principle", "basis"): (
            "The intended solution is governed by this criterion: {value}."
        ),
        ("goal_trace", "principle", "candidate"): (
            "The execution trace is governed by this criterion: {value}."
        ),
        ("goal_trace", "action", "basis"): (
            "The intended solution performs this behavior: {value}."
        ),
        ("goal_trace", "action", "candidate"): (
            "The execution trace performs this behavior: {value}."
        ),
    }
    try:
        return templates[(context, channel, role)].format(value=value)
    except KeyError as error:
        raise ValueError(
            f"unknown M52xd context/channel/role: {context}/{channel}/{role}"
        ) from error


def build_reciprocal_training_groups(
    ledger: Mapping[str, Any],
) -> Tuple[Mapping[str, Any], ...]:
    groups = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != "discovery":
            continue
        states = tuple(family_value["states"])
        if len(states) != 4:
            raise ValueError("M52xd requires four states in every training family")
        for left_channel, right_channel in M52XD_TRAINED_UNDIRECTED_EDGES:
            for context in M52XD_ROLE_CONTEXTS:
                groups.append(
                    {
                        "group_id": (
                            f"{family}::{context}::{left_channel}<->{right_channel}"
                        ),
                        "family": str(family),
                        "semantic_split": "discovery",
                        "context": context,
                        "left_channel": left_channel,
                        "right_channel": right_channel,
                        "states": [
                            {
                                "state_key": str(state["key"]),
                                "left_basis_text": reciprocal_role_text(
                                    state, left_channel, "basis", context
                                ),
                                "left_candidate_text": reciprocal_role_text(
                                    state, left_channel, "candidate", context
                                ),
                                "right_basis_text": reciprocal_role_text(
                                    state, right_channel, "basis", context
                                ),
                                "right_candidate_text": reciprocal_role_text(
                                    state, right_channel, "candidate", context
                                ),
                            }
                            for state in states
                        ],
                    }
                )
    return tuple(groups)


def _fresh_text(
    state: Mapping[str, str], channel: str, role: str, formulation: str
) -> str:
    value = str(state[channel])
    templates = {
        ("selection", "name", "basis"): (
            "Find the counterpart of this method designation: {value}."
        ),
        ("selection", "name", "candidate"): (
            "This option bears the method designation {value}."
        ),
        ("selection", "principle", "basis"): (
            "Find the counterpart of this governing condition: {value}."
        ),
        ("selection", "principle", "candidate"): (
            "This option obeys the governing condition: {value}."
        ),
        ("selection", "action", "basis"): (
            "Find the counterpart of this operational behavior: {value}."
        ),
        ("selection", "action", "candidate"): (
            "This option exhibits the operational behavior: {value}."
        ),
        ("confirmation", "name", "basis"): (
            "Use this technique label as the reference: {value}."
        ),
        ("confirmation", "name", "candidate"): (
            "The possible counterpart has technique label {value}."
        ),
        ("confirmation", "principle", "basis"): (
            "Use this decision invariant as the reference: {value}."
        ),
        ("confirmation", "principle", "candidate"): (
            "The possible counterpart has decision invariant: {value}."
        ),
        ("confirmation", "action", "basis"): (
            "Use this execution pattern as the reference: {value}."
        ),
        ("confirmation", "action", "candidate"): (
            "The possible counterpart has execution pattern: {value}."
        ),
    }
    try:
        return templates[(formulation, channel, role)].format(value=value)
    except KeyError as error:
        raise ValueError(
            f"unknown M52xd formulation/channel/role: {formulation}/{channel}/{role}"
        ) from error


def build_fresh_reciprocal_rows(
    ledger: Mapping[str, Any], formulation: str
) -> Tuple[Mapping[str, Any], ...]:
    if formulation not in {"selection", "confirmation"}:
        raise ValueError("M52xd formulation must be selection or confirmation")
    transform = (
        M52XD_SELECTION_TRANSFORM
        if formulation == "selection"
        else M52XD_CONFIRMATION_TRANSFORM
    )
    rows = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != "discovery":
            continue
        states = tuple(family_value["states"])
        state_index = {str(state["key"]): state for state in states}
        for direction in M52XD_TRAINED_DIRECTIONS:
            basis_channel, candidate_channel = direction.split("->")
            for basis_state in states:
                orbit = content_digest(
                    {
                        "milestone": "M52xd",
                        "formulation": formulation,
                        "family": family,
                        "direction": direction,
                        "basis_state": basis_state["key"],
                    }
                )
                for candidate_key, candidate_state in state_index.items():
                    metadata = {
                        "record_id": content_digest(
                            {"orbit": orbit, "candidate_state": candidate_key}
                        ),
                        "orbit_id": orbit,
                        "family": str(family),
                        "semantic_split": "discovery",
                        "formulation_split": formulation,
                        "basis_state_key": str(basis_state["key"]),
                        "candidate_state_key": candidate_key,
                        "basis_transformation": transform[basis_channel],
                        "basis_transformation_split": "m52xd_fresh",
                        "candidate_transformation": transform[candidate_channel],
                        "candidate_transformation_split": "m52xd_fresh",
                        "basis_text": _fresh_text(
                            basis_state, basis_channel, "basis", formulation
                        ),
                        "candidate_text": _fresh_text(
                            candidate_state,
                            candidate_channel,
                            "candidate",
                            formulation,
                        ),
                        "relation_target": (
                            "YES"
                            if str(basis_state["key"]) == candidate_key
                            else "NO"
                        ),
                    }
                    rows.append({"metadata": metadata})
    return tuple(rows)


__all__ = (
    "M52XD_HELDOUT_DIRECTIONS",
    "M52XD_M52XC_AUDIT_ID",
    "M52XD_ROLE_CONTEXTS",
    "M52XD_SEED",
    "M52XD_TRAINED_DIRECTIONS",
    "RECIPROCAL_ROLE_ALIGNMENT_VERSION",
    "build_fresh_reciprocal_rows",
    "build_reciprocal_training_groups",
    "calibration_gate_passed",
    "evaluate_geometry_records",
    "geometry_gate_passed",
    "output_installation_gate_passed",
    "reciprocal_role_text",
    "select_earliest_pass",
)
