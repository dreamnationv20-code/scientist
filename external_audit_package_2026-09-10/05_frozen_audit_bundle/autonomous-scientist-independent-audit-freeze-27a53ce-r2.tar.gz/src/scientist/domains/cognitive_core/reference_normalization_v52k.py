from __future__ import annotations

import hashlib
import json
import statistics
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_MODEL_SNAPSHOT,
)
from scientist.domains.cognitive_core.latent_state_validity_v52g import _state
from scientist.domains.cognitive_core.pairwise_relation_calibration_v52j import (
    M52J_FAMILIES_BY_SPLIT,
    _family as _m52j_family,
    apply_threshold,
    calibrate_leave_one_family_out,
    m52j_condition_passed,
    select_threshold,
)
from scientist.domains.cognitive_core.semantic_relation_competence_v52i import (
    M52I_VARIANTS,
    relation_metrics,
    semantic_relation_prompt,
)


REFERENCE_NORMALIZATION_VERSION = "general-cognitive-reference-normalization-v52k"
M52K_SEED = 52921
M52K_SPLITS = ("development", "validation", "confirmation")
M52K_M52J_AUDIT_ID = (
    "536db3c421a78ed198e2704f739eb27342aa91850c630fcbcc1010c7762e3b8e"
)

BASIS_PRESERVING_NULL_CURRENT = (
    "The current report explicitly provides no information about the relevant operating "
    "condition."
)
CURRENT_PRESERVING_NULL_BASIS = (
    "The conclusion depends on an unspecified system property, with no particular "
    "operating condition identified."
)

M52K_METHODS = (
    "raw_global",
    "basis_null_centered",
    "current_null_centered",
    "dual_null_centered",
    "explicit_pair_midpoint",
)
M52K_INTERVENTION_PRIORITY = (
    "basis_null_centered",
    "current_null_centered",
    "dual_null_centered",
    "explicit_pair_midpoint",
)


M52K_NEW_FAMILIES: Mapping[str, Tuple[Mapping[str, str], ...]] = {
    "transaction_isolation": (
        _state(
            "serializable",
            "Transactions must now behave like some serial execution with no isolation anomaly.",
            "Concurrent transactions are accepted only when their outcome matches a serial order.",
            "The conclusion presupposes serializable transaction isolation.",
            "This evidence assumes concurrent outcomes are equivalent to a serial schedule.",
        ),
        _state(
            "snapshot_isolation",
            "Transactions now read from a consistent snapshot and conflicting writers cannot both commit.",
            "Each transaction observes one snapshot while write-write conflicts trigger abortion.",
            "The conclusion presupposes snapshot isolation with write-conflict detection.",
            "This evidence assumes snapshot reads and prevention of concurrent conflicting commits.",
        ),
        _state(
            "read_committed",
            "Transactions may now observe different committed values across repeated reads.",
            "Every read excludes uncommitted data, but later reads may see newer commits.",
            "The conclusion presupposes read-committed transaction isolation.",
            "This evidence assumes dirty reads are blocked while repeatable reads are not guaranteed.",
        ),
        _state(
            "read_uncommitted",
            "Transactions may now read values written by transactions that have not committed.",
            "Intermediate uncommitted writes can be observed by concurrent work.",
            "The conclusion presupposes read-uncommitted transaction isolation.",
            "This evidence assumes dirty reads from in-progress transactions are permitted.",
        ),
    ),
    "message_delivery": (
        _state(
            "at_most_once",
            "Message delivery now permits loss but prevents processing the same message twice.",
            "A request is handled zero or one time, with no retry-caused duplicate execution.",
            "The conclusion presupposes at-most-once message delivery.",
            "This evidence assumes messages may be lost but cannot be delivered more than once.",
        ),
        _state(
            "at_least_once",
            "Message delivery now retries until acknowledged and may process duplicates.",
            "A request is delivered one or more times, requiring duplicate-tolerant handling.",
            "The conclusion presupposes at-least-once message delivery.",
            "This evidence assumes retries prevent loss while duplicate delivery remains possible.",
        ),
        _state(
            "effectively_once",
            "Message effects now appear once through idempotence and durable deduplication.",
            "Retries may occur, but repeated identifiers cannot apply the operation twice.",
            "The conclusion presupposes effectively-once processing through deduplication.",
            "This evidence assumes durable identifiers and idempotence suppress repeated effects.",
        ),
        _state(
            "best_effort",
            "Message delivery now makes no guarantee against loss, duplication, or reordering.",
            "The transport attempts delivery without retry or uniqueness guarantees.",
            "The conclusion presupposes best-effort message delivery.",
            "This evidence assumes loss, duplicates, and reordering may all occur.",
        ),
    ),
    "cache_write_policy": (
        _state(
            "write_through",
            "Cache updates must now synchronously update backing storage before completion.",
            "Every cache write is propagated to the durable store on the request path.",
            "The conclusion presupposes a write-through cache policy.",
            "This evidence assumes cache and backing storage are synchronously updated together.",
        ),
        _state(
            "write_back",
            "Cache updates may now reach backing storage later through asynchronous flushing.",
            "Dirty cache entries are acknowledged before their deferred durable write.",
            "The conclusion presupposes a write-back cache policy.",
            "This evidence assumes dirty entries are flushed after the cache write completes.",
        ),
        _state(
            "write_around",
            "Writes now bypass the cache and update backing storage directly.",
            "Newly written values enter durable storage without populating the cache.",
            "The conclusion presupposes a write-around cache policy.",
            "This evidence assumes writes skip the cache and go directly to backing storage.",
        ),
        _state(
            "no_write_allocate",
            "A cache miss on write now updates lower storage without allocating a cache entry.",
            "Only writes to resident lines update the cache; missed lines remain absent.",
            "The conclusion presupposes a no-write-allocate cache policy.",
            "This evidence assumes write misses do not bring the target line into cache.",
        ),
    ),
    "access_control_model": (
        _state(
            "discretionary",
            "Resource owners now decide which principals receive access permissions.",
            "An object's owner can grant or revoke access at their discretion.",
            "The conclusion presupposes discretionary owner-controlled access.",
            "This evidence assumes resource owners directly assign permissions to principals.",
        ),
        _state(
            "mandatory",
            "Access is now determined by centrally enforced security labels and clearances.",
            "Users and owners cannot override the system's label comparison policy.",
            "The conclusion presupposes mandatory label-based access control.",
            "This evidence assumes central security labels override owner discretion.",
        ),
        _state(
            "role_based",
            "Permissions are now assigned to organizational roles rather than individual users.",
            "A principal receives operations through membership in one or more roles.",
            "The conclusion presupposes role-based access control.",
            "This evidence assumes permissions attach to roles that are assigned to users.",
        ),
        _state(
            "attribute_based",
            "Access is now decided by policies over subject, resource, action, and environment attributes.",
            "A policy engine evaluates contextual attributes for every authorization decision.",
            "The conclusion presupposes attribute-based access control.",
            "This evidence assumes authorization policies evaluate multiple contextual attributes.",
        ),
    ),
}


M52K_FAMILIES_BY_SPLIT = {
    "development": tuple(
        M52J_FAMILIES_BY_SPLIT["train"] + M52J_FAMILIES_BY_SPLIT["valid"]
    ),
    "validation": ("transaction_isolation", "message_delivery"),
    "confirmation": ("cache_write_policy", "access_control_model"),
}


def _family(name: str) -> Tuple[Mapping[str, str], ...]:
    if name in M52K_NEW_FAMILIES:
        return M52K_NEW_FAMILIES[name]
    return _m52j_family(name)


@lru_cache(maxsize=None)
def build_m52k_rows(split: str) -> Tuple[Mapping[str, Any], ...]:
    if split not in M52K_SPLITS:
        raise ValueError(f"unknown M52k split: {split}")
    rows = []
    for family_name in M52K_FAMILIES_BY_SPLIT[split]:
        states = _family(family_name)
        for state_index, state in enumerate(states):
            for variant_index, variant in enumerate(M52I_VARIANTS):
                basis = (
                    str(state["basis_paraphrase"])
                    if variant in ("basis_paraphrase", "dual_paraphrase")
                    else str(state["basis"])
                )
                positive_current = (
                    str(state["current_paraphrase"])
                    if variant in ("current_paraphrase", "dual_paraphrase")
                    else str(state["current"])
                )
                negative_state = states[
                    (state_index + 1 + variant_index % (len(states) - 1))
                    % len(states)
                ]
                negative_current = (
                    str(negative_state["current_paraphrase"])
                    if variant in ("current_paraphrase", "dual_paraphrase")
                    else str(negative_state["current"])
                )
                contrast_id = "m52k-contrast-" + content_digest(
                    {
                        "split": split,
                        "family": family_name,
                        "basis": state["key"],
                        "variant": variant,
                        "version": REFERENCE_NORMALIZATION_VERSION,
                    }
                )[:24]
                for label, current, current_key in (
                    (1, positive_current, state["key"]),
                    (0, negative_current, negative_state["key"]),
                ):
                    rows.append(
                        {
                            "prompt": semantic_relation_prompt(basis, current),
                            "reference_prompts": {
                                "basis_null": semantic_relation_prompt(
                                    basis, BASIS_PRESERVING_NULL_CURRENT
                                ),
                                "current_null": semantic_relation_prompt(
                                    CURRENT_PRESERVING_NULL_BASIS, current
                                ),
                            },
                            "metadata": {
                                "record_id": "m52k-record-"
                                + content_digest(
                                    {
                                        "contrast_id": contrast_id,
                                        "label": label,
                                        "version": REFERENCE_NORMALIZATION_VERSION,
                                    }
                                )[:24],
                                "contrast_id": contrast_id,
                                "split": split,
                                "family": family_name,
                                "variant": variant,
                                "basis_state_key": state["key"],
                                "current_state_key": current_key,
                                "basis_text": basis,
                                "current_state_text": current,
                                "label": label,
                            },
                        }
                    )
    return tuple(rows)


def normalized_scores(
    rows: Sequence[Mapping[str, Any]],
    raw_scores: Sequence[float],
    basis_null_scores: Sequence[float],
    current_null_scores: Sequence[float],
    method: str,
) -> Tuple[float, ...]:
    if method not in M52K_METHODS:
        raise ValueError(f"unknown M52k normalization method: {method}")
    if not (
        len(rows)
        == len(raw_scores)
        == len(basis_null_scores)
        == len(current_null_scores)
    ):
        raise ValueError("M52k score channels must align exactly with rows")
    if method == "raw_global":
        return tuple(float(value) for value in raw_scores)
    if method == "basis_null_centered":
        return tuple(
            float(raw) - float(reference)
            for raw, reference in zip(raw_scores, basis_null_scores)
        )
    if method == "current_null_centered":
        return tuple(
            float(raw) - float(reference)
            for raw, reference in zip(raw_scores, current_null_scores)
        )
    if method == "dual_null_centered":
        return tuple(
            float(raw) - 0.5 * (float(basis) + float(current))
            for raw, basis, current in zip(
                raw_scores, basis_null_scores, current_null_scores
            )
        )
    groups: dict[str, list[int]] = {}
    for index, row in enumerate(rows):
        groups.setdefault(str(row["metadata"]["contrast_id"]), []).append(index)
    result = [0.0] * len(rows)
    for indices in groups.values():
        if len(indices) != 2:
            raise ValueError("M52k explicit references require exact two-member contrasts")
        midpoint = statistics.mean(float(raw_scores[index]) for index in indices)
        for index in indices:
            result[index] = float(raw_scores[index]) - midpoint
    return tuple(result)


def score_records(
    rows: Sequence[Mapping[str, Any]], scores: Sequence[float], threshold: float
) -> Tuple[Mapping[str, Any], ...]:
    return apply_threshold(rows, scores, threshold)


def family_offset_atlas(
    rows: Sequence[Mapping[str, Any]], scores: Sequence[float]
) -> Mapping[str, Any]:
    families = sorted({str(row["metadata"]["family"]) for row in rows})
    by_family = {}
    for family in families:
        indices = [
            index
            for index, row in enumerate(rows)
            if row["metadata"]["family"] == family
        ]
        family_rows = [rows[index] for index in indices]
        family_scores = [float(scores[index]) for index in indices]
        positive = [
            score
            for row, score in zip(family_rows, family_scores)
            if int(row["metadata"]["label"]) == 1
        ]
        negative = [
            score
            for row, score in zip(family_rows, family_scores)
            if int(row["metadata"]["label"]) == 0
        ]
        optimal = select_threshold(family_rows, family_scores)
        by_family[family] = {
            "record_count": len(family_rows),
            "score_center": statistics.mean(family_scores),
            "positive_mean": statistics.mean(positive),
            "negative_mean": statistics.mean(negative),
            "semantic_gap": statistics.mean(positive) - statistics.mean(negative),
            "optimal_threshold": float(optimal["threshold"]),
            "optimal_metrics": optimal["metrics"],
        }
    centers = [float(row["score_center"]) for row in by_family.values()]
    thresholds = [float(row["optimal_threshold"]) for row in by_family.values()]
    gaps = [float(row["semantic_gap"]) for row in by_family.values()]
    raw_metrics = relation_metrics(score_records(rows, scores, 0.0))
    ranked = normalized_scores(rows, scores, scores, scores, "explicit_pair_midpoint")
    ranking_metrics = relation_metrics(score_records(rows, ranked, 0.0))
    return {
        "by_family": by_family,
        "family_score_center_range": max(centers) - min(centers),
        "family_optimal_threshold_range": max(thresholds) - min(thresholds),
        "mean_within_family_semantic_gap": statistics.mean(gaps),
        "raw_zero_threshold_metrics": raw_metrics,
        "within_pair_ranking_metrics": ranking_metrics,
    }


def offset_diagnosis_passed(
    atlas: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    ranking = atlas["within_pair_ranking_metrics"]
    checks = {
        "minimum_pair_ranking": ranking["contrast_ranking_accuracy"]
        >= contract["minimum_pair_ranking"],
        "minimum_family_center_range": atlas["family_score_center_range"]
        >= contract["minimum_family_center_range"],
        "minimum_family_threshold_range": atlas["family_optimal_threshold_range"]
        >= contract["minimum_family_threshold_range"],
        "positive_mean_semantic_gap": atlas["mean_within_family_semantic_gap"] > 0.0,
    }
    return all(checks.values()), checks


def intervention_passed(
    metrics: Mapping[str, Any],
    raw_metrics: Mapping[str, Any],
    validation_contract: Mapping[str, Any],
    improvement_contract: Mapping[str, Any],
) -> Tuple[bool, Mapping[str, bool]]:
    base_passed, base_checks = m52j_condition_passed(metrics, validation_contract)
    checks = {
        **base_checks,
        "balanced_improvement_over_raw": (
            float(metrics["balanced_accuracy"])
            - float(raw_metrics["balanced_accuracy"])
            >= float(improvement_contract["minimum_balanced_accuracy_delta"])
        ),
        "pair_improvement_over_raw": (
            float(metrics["contrast_pair_accuracy"])
            - float(raw_metrics["contrast_pair_accuracy"])
            >= float(improvement_contract["minimum_contrast_pair_accuracy_delta"])
        ),
    }
    return base_passed and all(checks.values()), checks


def select_m52k_method(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    passing = [
        row
        for row in candidates
        if row["method"] in M52K_INTERVENTION_PRIORITY and bool(row["passed"])
    ]
    if not passing:
        return None
    priority = {method: index for index, method in enumerate(M52K_INTERVENTION_PRIORITY)}
    return sorted(
        passing,
        key=lambda row: (
            priority[str(row["method"])],
            -float(row["metrics"]["contrast_pair_accuracy"]),
            -float(row["metrics"]["balanced_accuracy"]),
        ),
    )[0]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _jsonl(rows: Sequence[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52k artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode()).hexdigest()


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    parent = (
        project
        / "runs/cognitive_core/sequential_policy_learning_v47/selected_adapter/"
        "adapters.safetensors"
    )
    m52j = json.loads(
        (
            project
            / "runs/cognitive_core/pairwise_relation_calibration_v52j/local-audit.json"
        ).read_text()
    )
    return {
        "version": REFERENCE_NORMALIZATION_VERSION,
        "parent_version": "general-cognitive-pairwise-relation-calibration-v52j",
        "scientific_question": (
            "Are family-dependent score offsets the cause of failed absolute semantic "
            "decisions, and can a context-local reference remove them without updating "
            "model weights?"
        ),
        "seed": M52K_SEED,
        "families_by_split": {
            split: list(value) for split, value in M52K_FAMILIES_BY_SPLIT.items()
        },
        "variants": list(M52I_VARIANTS),
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "parent_adapter_source": (
                "runs/cognitive_core/sequential_policy_learning_v47/selected_adapter/"
                "adapters.safetensors"
            ),
            "parent_adapter_sha256": _sha256(parent),
            "m52j_audit_id": m52j["audit_id"],
            "failed_m52j_internal_adapter_excluded": True,
        },
        "score_contract": {
            "raw_score": "next-token YES logit minus next-token NO logit",
            "yes_and_no_must_each_be_one_token": True,
            "methods": {
                "raw_global": "raw score; family-LOO median threshold control",
                "basis_null_centered": "raw minus same-basis generic-null-current score",
                "current_null_centered": "raw minus same-current generic-null-basis score",
                "dual_null_centered": "raw minus mean of both generic-null scores",
                "explicit_pair_midpoint": (
                    "raw minus the midpoint of an unlabeled two-candidate matched contrast; "
                    "exactly one candidate is applicable"
                ),
            },
            "generic_method_threshold": (
                "leave one development family out; deploy median fold threshold"
            ),
            "explicit_pair_threshold": 0.0,
        },
        "diagnostic_contract": {
            "minimum_pair_ranking": 0.90,
            "minimum_family_center_range": 0.75,
            "minimum_family_threshold_range": 0.75,
        },
        "validation_contract": {
            "minimum_balanced_accuracy": 0.88,
            "minimum_paraphrase_balanced_accuracy": 0.85,
            "minimum_contrast_pair_accuracy": 0.80,
            "minimum_contrast_ranking_accuracy": 0.90,
            "minimum_each_family_balanced_accuracy": 0.80,
        },
        "improvement_contract": {
            "minimum_balanced_accuracy_delta": 0.05,
            "minimum_contrast_pair_accuracy_delta": 0.10,
        },
        "selection_rule": (
            "Use development labels only. Select the least restrictive intervention that "
            "passes every absolute, ranking, per-family, and improvement gate, in frozen "
            "priority order: basis-null, current-null, dual-null, explicit-pair."
        ),
        "staged_access": {
            "validation_opened_only_after_offset_diagnosis_and_development_method_pass": True,
            "confirmation_opened_only_after_selected_method_passes_validation": True,
            "m52j_sealed_confirmation_reused": False,
        },
        "claim_boundary": (
            "M52k tests score-offset diagnosis and reference-normalized semantic relation "
            "decisions on synthetic CS state descriptions. Generic-null success would "
            "support single-candidate local normalization. Explicit-pair success would be "
            "limited to a closed-world two-candidate interface with exactly one applicable "
            "candidate. Neither establishes trajectory control, autonomous concept invention, "
            "general reasoning parity, or broad task transfer."
        ),
    }


def verify_m52k_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol = _protocol_payload(project)
    protocol_id = content_digest(protocol)
    reproduced = {split: build_m52k_rows(split) for split in M52K_SPLITS}
    checks = {
        "protocol_id_content_derived": protocol_id == freeze["protocol_freeze_id"],
        "freeze_id_content_derived": content_digest(
            {key: value for key, value in freeze.items() if key != "freeze_id"}
        )
        == freeze["freeze_id"],
        "counts_match": all(
            len(reproduced[split]) == int(freeze["counts"][split])
            for split in M52K_SPLITS
        ),
        "hashes_match": all(
            hashlib.sha256((output / f"{split}.jsonl").read_bytes()).hexdigest()
            == freeze["hashes"][split]
            for split in M52K_SPLITS
        ),
        "stored_rows_reproduce": all(
            (output / f"{split}.jsonl").read_text() == _jsonl(reproduced[split])
            for split in M52K_SPLITS
        ),
        "families_disjoint": all(
            not (
                set(M52K_FAMILIES_BY_SPLIT[left])
                & set(M52K_FAMILIES_BY_SPLIT[right])
            )
            for index, left in enumerate(M52K_SPLITS)
            for right in M52K_SPLITS[index + 1 :]
        ),
        "fresh_validation_and_confirmation_families": not (
            set(M52K_FAMILIES_BY_SPLIT["validation"])
            | set(M52K_FAMILIES_BY_SPLIT["confirmation"])
        )
        & set(
            M52J_FAMILIES_BY_SPLIT["train"]
            + M52J_FAMILIES_BY_SPLIT["valid"]
            + M52J_FAMILIES_BY_SPLIT["confirmation"]
        ),
        "matched_contrasts_have_one_positive": all(
            len(group) == 2
            and {int(row["metadata"]["label"]) for row in group} == {0, 1}
            and len({row["metadata"]["basis_text"] for row in group}) == 1
            for split in M52K_SPLITS
            for group in _contrast_groups(reproduced[split]).values()
        ),
        "basis_null_is_shared_inside_contrast": all(
            len({row["reference_prompts"]["basis_null"] for row in group}) == 1
            for split in M52K_SPLITS
            for group in _contrast_groups(reproduced[split]).values()
        ),
        "shortcut_identifiers_absent_from_prompt_text": all(
            "m52k-record" not in row["prompt"].lower()
            and "m52k-contrast" not in row["prompt"].lower()
            and all(
                "m52k-record" not in prompt.lower()
                and "m52k-contrast" not in prompt.lower()
                for prompt in row["reference_prompts"].values()
            )
            for split in M52K_SPLITS
            for row in reproduced[split]
        ),
        "parent_adapter_matches": _sha256(
            project / freeze["frozen_model"]["parent_adapter_source"]
        )
        == freeze["frozen_model"]["parent_adapter_sha256"],
        "m52j_audit_matches": json.loads(
            (
                project
                / "runs/cognitive_core/pairwise_relation_calibration_v52j/local-audit.json"
            ).read_text()
        )["audit_id"]
        == freeze["frozen_model"]["m52j_audit_id"]
        == M52K_M52J_AUDIT_ID,
    }
    result = {
        "freeze_id": freeze["freeze_id"],
        "protocol_freeze_id": freeze["protocol_freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }
    (output / "benchmark-verification.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    return result


def _contrast_groups(
    rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, list[Mapping[str, Any]]]:
    groups: dict[str, list[Mapping[str, Any]]] = {}
    for row in rows:
        groups.setdefault(str(row["metadata"]["contrast_id"]), []).append(row)
    return groups


def prepare_m52k_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol = _protocol_payload(project)
    protocol_id = content_digest(protocol)
    hashes = {}
    counts = {}
    for split in M52K_SPLITS:
        rows = build_m52k_rows(split)
        payload = _jsonl(rows)
        hashes[split] = _write_immutable(output / f"{split}.jsonl", payload)
        counts[split] = len(rows)
    freeze_payload = {
        **protocol,
        "protocol_freeze_id": protocol_id,
        "counts": counts,
        "hashes": hashes,
    }
    freeze = {**freeze_payload, "freeze_id": content_digest(freeze_payload)}
    _write_immutable(
        output / "benchmark-freeze.json",
        json.dumps(freeze, indent=2, sort_keys=True) + "\n",
    )
    return verify_m52k_benchmark(output, project)
