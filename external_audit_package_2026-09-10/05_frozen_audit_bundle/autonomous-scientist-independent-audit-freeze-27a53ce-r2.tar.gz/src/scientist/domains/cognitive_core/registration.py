from __future__ import annotations

from scientist.domains.cognitive_core.adapter import CognitiveCoreAdapter
from scientist.domains.cognitive_core.generators import (
    CognitiveProbeFactory,
    generate_probe,
    knowledge_table,
)
from scientist.domains.cognitive_core.models import ProbeKind
from scientist.domains.cognitive_core.policies import PolicyKind, ReferencePolicy
from scientist.domains.cognitive_core.research_decision import (
    EvidenceBoundProgramDecisionComponent,
)
from scientist.domains.cognitive_core.standard import campaign_contract, problem_charter
from scientist.kernel.contracts import EvidencePartition
from scientist.kernel.domain_registry import (
    DomainConformanceFixture,
    ScientificDomainBundle,
)
from scientist.program.research_kernel import ResearchActionKind


def domain_bundle() -> ScientificDomainBundle:
    adapter = CognitiveCoreAdapter()
    facts = tuple(sorted(knowledge_table(1729, 32, 16).items()))
    candidate = ReferencePolicy("oracle", PolicyKind.COGNITIVE_ORACLE, facts)
    control = ReferencePolicy("memorizer", PolicyKind.MEMORIZER, facts)
    program_authority = EvidenceBoundProgramDecisionComponent()

    def fixture() -> DomainConformanceFixture:
        return DomainConformanceFixture(
            candidate=candidate,
            control=control,
            experiment=generate_probe(
                ProbeKind.PROCEDURE,
                11,
                EvidencePartition.DEVELOPMENT,
            ),
        )

    return ScientificDomainBundle(
        domain_id=adapter.domain_id,
        adapter=adapter,
        charter_factory=problem_charter,
        campaign_factory=lambda incumbent_id: campaign_contract(
            incumbent_id or adapter.candidate_id(control)
        ),
        fixture_factory=fixture,
        capability_manifest=adapter.capabilities,
        bundle_ref="cognitive-core-scientific-domain-bundle-v1",
        experiment_factory=CognitiveProbeFactory(),
        research_components={
            ResearchActionKind.MAKE_PROGRAM_DECISION.value: program_authority,
            ResearchActionKind.REPORT_TERMINAL.value: program_authority,
        },
    )
