from __future__ import annotations

import math
from typing import Any, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.representation_atlas_v52w import (
    ranking_metrics,
)


RELATION_COMPLEMENTARITY_VERSION = (
    "general-cognitive-relation-complementarity-v52xjy"
)
M52XJY_SEED = 53537
M52XJY_M52XJX_AUDIT_ID = (
    "d07347e1382df25df97192ee9671284a9792ae8c3c8841f7bd611c6c325a2426"
)
M52XJY_CHECKPOINTS = (40, 80, 160)
M52XJY_FUSION_SCHEMES = ("raw_residual", "centered_l2", "ordinal_rank")
M52XJY_ALPHA_GRID = (-2.0, -1.0, -0.5, -0.25, 0.0, 0.25, 0.5, 1.0, 2.0)


def fusion_rules() -> Tuple[Mapping[str, Any], ...]:
    rules = []
    for checkpoint in M52XJY_CHECKPOINTS:
        for scheme in M52XJY_FUSION_SCHEMES:
            for alpha in M52XJY_ALPHA_GRID:
                alpha_label = str(alpha).replace("-", "minus_").replace(".", "p")
                rules.append(
                    {
                        "rule_id": f"checkpoint_{checkpoint}__{scheme}__alpha_{alpha_label}",
                        "checkpoint": checkpoint,
                        "scheme": scheme,
                        "alpha": alpha,
                        "rule_index": len(rules),
                    }
                )
    return tuple(rules)


def _record_map(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[str, Mapping[str, Any]]:
    mapped = {str(row["record_id"]): row for row in records}
    if len(mapped) != len(records):
        raise ValueError("M52xj-Y relation records require unique record IDs")
    return mapped


def _groups(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[tuple[str, str, str, str], Tuple[Mapping[str, Any], ...]]:
    groups: dict[tuple[str, str, str, str], list[Mapping[str, Any]]] = {}
    for row in records:
        key = (
            str(row["family"]),
            str(row["basis_state_key"]),
            str(row["basis_transformation"]),
            str(row["candidate_transformation"]),
        )
        groups.setdefault(key, []).append(row)
    output = {key: tuple(value) for key, value in groups.items()}
    if not output or not all(
        len(group) == 4
        and sum(row["target"] == "YES" for row in group) == 1
        and sum(row["target"] == "NO" for row in group) == 3
        for group in output.values()
    ):
        raise ValueError("M52xj-Y requires complete one-positive/three-negative groups")
    return output


def complementarity_metrics(
    baseline_records: Sequence[Mapping[str, Any]],
    candidate_record_sets: Sequence[Sequence[Mapping[str, Any]]],
) -> Mapping[str, Any]:
    if not candidate_record_sets:
        raise ValueError("M52xj-Y requires at least one candidate checkpoint")
    baseline_groups = _groups(baseline_records)
    candidate_maps = tuple(_record_map(records) for records in candidate_record_sets)
    baseline_ids = set(_record_map(baseline_records))
    if any(set(records) != baseline_ids for records in candidate_maps):
        raise ValueError("M52xj-Y baseline/candidate record identities differ")
    baseline_correct = 0
    baseline_wrong = 0
    repaired_by_any = 0
    damaged_by_all = 0
    union_correct = 0
    candidate_correct_counts = [0 for _ in candidate_maps]
    candidate_repairs = [0 for _ in candidate_maps]
    candidate_damages = [0 for _ in candidate_maps]
    baseline_top1 = 0
    union_top1 = 0
    candidate_top1 = [0 for _ in candidate_maps]
    total_comparisons = 0
    total_groups = 0
    for group in baseline_groups.values():
        positive = next(row for row in group if row["target"] == "YES")
        negatives = tuple(row for row in group if row["target"] == "NO")
        positive_id = str(positive["record_id"])
        baseline_gaps = [
            float(positive["margin"]) - float(negative["margin"])
            for negative in negatives
        ]
        candidate_gap_sets = [
            [
                float(records[positive_id]["margin"])
                - float(records[str(negative["record_id"])]["margin"])
                for negative in negatives
            ]
            for records in candidate_maps
        ]
        baseline_group_top1 = all(gap > 0.0 for gap in baseline_gaps)
        candidate_group_top1 = [
            all(gap > 0.0 for gap in gaps) for gaps in candidate_gap_sets
        ]
        baseline_top1 += baseline_group_top1
        union_top1 += baseline_group_top1 or any(candidate_group_top1)
        for index, correct in enumerate(candidate_group_top1):
            candidate_top1[index] += correct
        total_groups += 1
        for negative_index, baseline_gap in enumerate(baseline_gaps):
            baseline_ok = baseline_gap > 0.0
            candidate_ok = [
                gaps[negative_index] > 0.0 for gaps in candidate_gap_sets
            ]
            baseline_correct += baseline_ok
            baseline_wrong += not baseline_ok
            repaired_by_any += (not baseline_ok) and any(candidate_ok)
            damaged_by_all += baseline_ok and not any(candidate_ok)
            union_correct += baseline_ok or any(candidate_ok)
            for index, correct in enumerate(candidate_ok):
                candidate_correct_counts[index] += correct
                candidate_repairs[index] += (not baseline_ok) and correct
                candidate_damages[index] += baseline_ok and not correct
            total_comparisons += 1
    checkpoint_metrics = []
    for index in range(len(candidate_maps)):
        checkpoint_metrics.append(
            {
                "candidate_index": index,
                "ranking_accuracy": candidate_correct_counts[index]
                / total_comparisons,
                "top1_accuracy": candidate_top1[index] / total_groups,
                "baseline_error_repair_fraction": candidate_repairs[index]
                / max(baseline_wrong, 1),
                "baseline_correct_damage_fraction": candidate_damages[index]
                / max(baseline_correct, 1),
                "net_corrected_comparisons": (
                    candidate_repairs[index] - candidate_damages[index]
                ),
            }
        )
    return {
        "comparison_count": total_comparisons,
        "group_count": total_groups,
        "baseline_correct_comparisons": baseline_correct,
        "baseline_wrong_comparisons": baseline_wrong,
        "baseline_errors_repaired_by_any_checkpoint": repaired_by_any,
        "baseline_correct_comparisons_missed_by_all_checkpoints": damaged_by_all,
        "baseline_ranking_accuracy": baseline_correct / total_comparisons,
        "baseline_top1_accuracy": baseline_top1 / total_groups,
        "all_checkpoint_oracle_union_ranking_accuracy": union_correct
        / total_comparisons,
        "all_checkpoint_policy_oracle_union_top1_accuracy": union_top1
        / total_groups,
        "all_checkpoint_baseline_error_repair_fraction": repaired_by_any
        / max(baseline_wrong, 1),
        "all_checkpoint_irrecoverable_baseline_correct_fraction": damaged_by_all
        / max(baseline_correct, 1),
        "checkpoint_metrics": checkpoint_metrics,
    }


def _normalized_scores(
    group: Sequence[Mapping[str, Any]], scheme: str
) -> Mapping[str, float]:
    if scheme == "raw_residual":
        return {str(row["record_id"]): float(row["margin"]) for row in group}
    values = [float(row["margin"]) for row in group]
    if scheme == "centered_l2":
        center = sum(values) / len(values)
        norm = math.sqrt(sum((value - center) ** 2 for value in values))
        denominator = max(norm, 1e-12)
        return {
            str(row["record_id"]): (float(row["margin"]) - center) / denominator
            for row in group
        }
    if scheme == "ordinal_rank":
        return {
            str(row["record_id"]): float(
                sum(value < float(row["margin"]) for value in values)
            )
            for row in group
        }
    raise ValueError(f"unknown M52xj-Y fusion scheme: {scheme}")


def fuse_relation_records(
    baseline_records: Sequence[Mapping[str, Any]],
    candidate_records: Sequence[Mapping[str, Any]],
    scheme: str,
    alpha: float,
) -> Tuple[Mapping[str, Any], ...]:
    if scheme not in M52XJY_FUSION_SCHEMES:
        raise ValueError("M52xj-Y fusion scheme was not frozen")
    baseline_groups = _groups(baseline_records)
    candidate_map = _record_map(candidate_records)
    if set(candidate_map) != set(_record_map(baseline_records)):
        raise ValueError("M52xj-Y fusion identities differ")
    fused_by_id = {}
    for group in baseline_groups.values():
        candidate_group = tuple(
            candidate_map[str(row["record_id"])] for row in group
        )
        baseline_scores = _normalized_scores(group, scheme)
        candidate_scores = _normalized_scores(candidate_group, scheme)
        for row in group:
            record_id = str(row["record_id"])
            margin = baseline_scores[record_id] + float(alpha) * candidate_scores[
                record_id
            ]
            fused_by_id[record_id] = {
                **row,
                "margin": margin,
                "prediction": "YES" if margin > 0.0 else "NO",
            }
    return tuple(fused_by_id[str(row["record_id"])] for row in baseline_records)


def ranking_panel(
    records_by_formulation: Mapping[str, Sequence[Mapping[str, Any]]]
) -> Mapping[str, Any]:
    metrics = {
        name: ranking_metrics(records)
        for name, records in records_by_formulation.items()
    }
    return {
        "formulations": metrics,
        "minimum_ranking_accuracy": min(
            float(value["ranking_accuracy"]) for value in metrics.values()
        ),
        "minimum_top1_accuracy": min(
            float(value["top1_accuracy"]) for value in metrics.values()
        ),
        "mean_ranking_accuracy": sum(
            float(value["ranking_accuracy"]) for value in metrics.values()
        )
        / len(metrics),
        "mean_top1_accuracy": sum(
            float(value["top1_accuracy"]) for value in metrics.values()
        )
        / len(metrics),
    }


def select_cross_fitted_rule(
    rules: Sequence[Mapping[str, Any]],
    panels_by_rule: Mapping[str, Mapping[str, Mapping[str, Any]]],
    baseline_panels: Mapping[str, Mapping[str, Any]],
    training_families: Sequence[str],
) -> Mapping[str, Any]:
    if not training_families:
        raise ValueError("M52xj-Y cross-fitted selection requires training families")
    candidates = []
    for rule in rules:
        rule_id = str(rule["rule_id"])
        if rule_id not in panels_by_rule:
            raise ValueError(f"missing M52xj-Y rule panel: {rule_id}")
        ranking_deltas = []
        top1_deltas = []
        rankings = []
        top1s = []
        for family in training_families:
            panel = panels_by_rule[rule_id][family]
            baseline = baseline_panels[family]
            rankings.append(float(panel["minimum_ranking_accuracy"]))
            top1s.append(float(panel["minimum_top1_accuracy"]))
            ranking_deltas.append(
                float(panel["minimum_ranking_accuracy"])
                - float(baseline["minimum_ranking_accuracy"])
            )
            top1_deltas.append(
                float(panel["minimum_top1_accuracy"])
                - float(baseline["minimum_top1_accuracy"])
            )
        selection_vector = (
            min(ranking_deltas),
            min(top1_deltas),
            sum(ranking_deltas) / len(ranking_deltas),
            sum(top1_deltas) / len(top1_deltas),
            min(rankings),
            min(top1s),
            -abs(float(rule["alpha"])),
            -int(rule["rule_index"]),
        )
        candidates.append(
            {
                **rule,
                "training_family_count": len(training_families),
                "minimum_training_ranking_delta": min(ranking_deltas),
                "minimum_training_top1_delta": min(top1_deltas),
                "mean_training_ranking_delta": sum(ranking_deltas)
                / len(ranking_deltas),
                "mean_training_top1_delta": sum(top1_deltas) / len(top1_deltas),
                "minimum_training_ranking_accuracy": min(rankings),
                "minimum_training_top1_accuracy": min(top1s),
                "selection_vector": list(selection_vector),
            }
        )
    return max(candidates, key=lambda row: tuple(row["selection_vector"]))


__all__ = (
    "M52XJY_ALPHA_GRID",
    "M52XJY_CHECKPOINTS",
    "M52XJY_FUSION_SCHEMES",
    "M52XJY_M52XJX_AUDIT_ID",
    "M52XJY_SEED",
    "RELATION_COMPLEMENTARITY_VERSION",
    "complementarity_metrics",
    "fusion_rules",
    "fuse_relation_records",
    "ranking_panel",
    "select_cross_fitted_rule",
)
