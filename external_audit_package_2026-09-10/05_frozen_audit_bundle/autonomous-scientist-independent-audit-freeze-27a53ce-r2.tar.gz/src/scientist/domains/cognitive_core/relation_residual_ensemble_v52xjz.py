from __future__ import annotations

import math
from typing import Any, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.relation_complementarity_v52xjy import (
    ranking_panel,
)


RELATION_RESIDUAL_ENSEMBLE_VERSION = (
    "general-cognitive-relation-residual-ensemble-v52xjz"
)
M52XJZ_SEED = 53538
M52XJZ_M52XJY_AUDIT_ID = (
    "020137ae7669e0f0626f738cb2b8b5a25d4cfeb9297b339e198b276116036c60"
)
M52XJZ_CHECKPOINT = 160
M52XJZ_SCHEME = "centered_l2"
M52XJZ_ALPHA = 0.25


def _record_map(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[str, Mapping[str, Any]]:
    mapped = {str(row["record_id"]): row for row in records}
    if len(mapped) != len(records):
        raise ValueError("M52xj-Z requires unique relation-record identities")
    return mapped


def _groups(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[tuple[str, str, str, str], Tuple[Mapping[str, Any], ...]]:
    groups: dict[tuple[str, str, str, str], list[Mapping[str, Any]]] = {}
    for row in records:
        key = (
            str(row["family"]),
            str(row["basis_state_key"]),
            str(row["basis_transformation"]),
            str(row["candidate_transformation"]),
        )
        groups.setdefault(key, []).append(row)
    output = {key: tuple(value) for key, value in groups.items()}
    if not output or not all(
        len(group) == 4
        and sum(row["target"] == "YES" for row in group) == 1
        and sum(row["target"] == "NO" for row in group) == 3
        for group in output.values()
    ):
        raise ValueError("M52xj-Z requires complete one-positive/three-negative groups")
    return output


def _centered_l2(group: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
    values = [float(row["margin"]) for row in group]
    center = sum(values) / len(values)
    norm = math.sqrt(sum((value - center) ** 2 for value in values))
    denominator = max(norm, 1e-12)
    return {
        str(row["record_id"]): (float(row["margin"]) - center) / denominator
        for row in group
    }


def ensemble_residual_records(
    baseline_records: Sequence[Mapping[str, Any]],
    member_record_sets: Sequence[Sequence[Mapping[str, Any]]],
    alpha: float = M52XJZ_ALPHA,
) -> Tuple[Mapping[str, Any], ...]:
    if not member_record_sets:
        raise ValueError("M52xj-Z requires at least one residual member")
    baseline_groups = _groups(baseline_records)
    baseline_ids = set(_record_map(baseline_records))
    member_maps = tuple(_record_map(records) for records in member_record_sets)
    if any(set(records) != baseline_ids for records in member_maps):
        raise ValueError("M52xj-Z baseline/member record identities differ")
    fused_by_id = {}
    for group in baseline_groups.values():
        baseline_scores = _centered_l2(group)
        member_scores = []
        for records in member_maps:
            member_group = tuple(records[str(row["record_id"])] for row in group)
            member_scores.append(_centered_l2(member_group))
        for row in group:
            record_id = str(row["record_id"])
            residual = sum(scores[record_id] for scores in member_scores) / len(
                member_scores
            )
            margin = baseline_scores[record_id] + float(alpha) * residual
            fused_by_id[record_id] = {
                **row,
                "margin": margin,
                "prediction": "YES" if margin > 0.0 else "NO",
            }
    return tuple(fused_by_id[str(row["record_id"])] for row in baseline_records)


def family_ranking_panels(
    records_by_formulation: Mapping[str, Sequence[Mapping[str, Any]]]
) -> Mapping[str, Mapping[str, Any]]:
    families = sorted(
        {
            str(row["family"])
            for records in records_by_formulation.values()
            for row in records
        }
    )
    return {
        family: ranking_panel(
            {
                formulation: tuple(
                    row for row in records if str(row["family"]) == family
                )
                for formulation, records in records_by_formulation.items()
            }
        )
        for family in families
    }


def residual_development_gate(
    baseline_panels: Mapping[str, Mapping[str, Any]],
    candidate_panels: Mapping[str, Mapping[str, Any]],
    leave_one_member_out_panels: Sequence[Mapping[str, Mapping[str, Any]]],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, Any]]:
    if set(candidate_panels) != set(baseline_panels):
        raise ValueError("M52xj-Z baseline/candidate families differ")
    if not leave_one_member_out_panels:
        raise ValueError("M52xj-Z requires leave-one-member-out robustness panels")
    coordinates = []
    for family in sorted(baseline_panels):
        baseline_forms = baseline_panels[family]["formulations"]
        candidate_forms = candidate_panels[family]["formulations"]
        if set(candidate_forms) != set(baseline_forms):
            raise ValueError("M52xj-Z baseline/candidate formulations differ")
        for formulation in sorted(baseline_forms):
            coordinates.append(
                {
                    "family": family,
                    "formulation": formulation,
                    "ranking_delta": float(
                        candidate_forms[formulation]["ranking_accuracy"]
                    )
                    - float(baseline_forms[formulation]["ranking_accuracy"]),
                    "top1_delta": float(candidate_forms[formulation]["top1_accuracy"])
                    - float(baseline_forms[formulation]["top1_accuracy"]),
                }
            )
    robustness_coordinates = []
    for member_index, panels in enumerate(leave_one_member_out_panels):
        if set(panels) != set(baseline_panels):
            raise ValueError("M52xj-Z robustness families differ")
        for family in sorted(baseline_panels):
            for formulation in sorted(baseline_panels[family]["formulations"]):
                baseline = baseline_panels[family]["formulations"][formulation]
                active = panels[family]["formulations"][formulation]
                robustness_coordinates.append(
                    {
                        "excluded_member_index": member_index,
                        "family": family,
                        "formulation": formulation,
                        "ranking_delta": float(active["ranking_accuracy"])
                        - float(baseline["ranking_accuracy"]),
                        "top1_delta": float(active["top1_accuracy"])
                        - float(baseline["top1_accuracy"]),
                    }
                )
    checks = {
        "every_development_coordinate_ranking_improves": all(
            row["ranking_delta"]
            >= float(contract["minimum_each_coordinate_ranking_delta"])
            for row in coordinates
        ),
        "no_development_coordinate_top1_declines": all(
            row["top1_delta"]
            >= float(contract["minimum_each_coordinate_top1_delta"])
            for row in coordinates
        ),
        "every_leave_one_member_out_ranking_nondegrades": all(
            row["ranking_delta"]
            >= float(contract["minimum_leave_one_member_out_ranking_delta"])
            for row in robustness_coordinates
        ),
        "every_leave_one_member_out_top1_nondegrades": all(
            row["top1_delta"]
            >= float(contract["minimum_leave_one_member_out_top1_delta"])
            for row in robustness_coordinates
        ),
    }
    return all(checks.values()), {
        "coordinates": coordinates,
        "leave_one_member_out_coordinates": robustness_coordinates,
        "minimum_ranking_delta": min(row["ranking_delta"] for row in coordinates),
        "mean_ranking_delta": sum(row["ranking_delta"] for row in coordinates)
        / len(coordinates),
        "minimum_top1_delta": min(row["top1_delta"] for row in coordinates),
        "mean_top1_delta": sum(row["top1_delta"] for row in coordinates)
        / len(coordinates),
        "minimum_leave_one_member_out_ranking_delta": min(
            row["ranking_delta"] for row in robustness_coordinates
        ),
        "minimum_leave_one_member_out_top1_delta": min(
            row["top1_delta"] for row in robustness_coordinates
        ),
        "checks": checks,
        "passed": all(checks.values()),
    }


__all__ = (
    "M52XJZ_ALPHA",
    "M52XJZ_CHECKPOINT",
    "M52XJZ_M52XJY_AUDIT_ID",
    "M52XJZ_SCHEME",
    "M52XJZ_SEED",
    "RELATION_RESIDUAL_ENSEMBLE_VERSION",
    "ensemble_residual_records",
    "family_ranking_panels",
    "residual_development_gate",
)
