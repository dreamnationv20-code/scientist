from __future__ import annotations

import hashlib
import json
import random
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


REPAIR_BENCHMARK_VERSION = "general-cognitive-repair-benchmark-v32"
REPRESENTATIONS = ("predicate", "temporal", "causal", "program", "planning")
LOCALIZATION_TRAIN_REPRESENTATIONS = ("predicate", "temporal", "causal")
HELDOUT_LOCALIZATION_REPRESENTATIONS = ("program", "planning")
SPLIT_SEEDS = {
    "train": 32101,
    "valid": 32143,
    "localization_test": 32203,
    "repair_test": 32251,
    "trajectory_test": 32303,
}


@dataclass(frozen=True)
class RepairTask:
    task_id: str
    split: str
    representation: str
    candidate: Mapping[str, Any]
    authority: Mapping[str, Any]
    target_node: str
    failure_type: str
    visible_correct: Tuple[Mapping[str, Any], ...]
    counterexample: Mapping[str, Any]
    hidden_cases: Tuple[Mapping[str, Any], ...]

    @property
    def preserve_nodes(self) -> Tuple[str, ...]:
        return tuple(sorted(node for node in self.candidate if node != self.target_node))

    @property
    def correct_edit_value(self) -> Any:
        return self.authority[self.target_node]

    @property
    def prompt(self) -> str:
        nodes = "\n".join(
            f"{node} = {json.dumps(value, sort_keys=True)}"
            for node, value in sorted(self.candidate.items())
        )
        correct = "\n".join(
            f"input={json.dumps(case['input'])} -> output={json.dumps(case['expected'])}"
            for case in self.visible_correct
        )
        bad = self.counterexample
        return (
            f"Representation: {self.representation}\n"
            "A candidate mechanism is correct on several cases but fails one counterexample. Exactly one "
            "typed node is responsible. Diagnose the failing node, classify the failure, and list every "
            "other node that must be preserved.\n"
            f"Candidate nodes:\n{nodes}\n"
            f"Correct cases:\n{correct}\n"
            f"Counterexample: input={json.dumps(bad['input'])}; candidate_output={json.dumps(bad['candidate'])}; "
            f"required_output={json.dumps(bad['expected'])}\n"
            "Failure types: wrong_variable, wrong_constant, wrong_operator, missing_state, missing_dependency, wrong_recovery.\n"
            "Return exactly: ANSWER: target=<node>; type=<failure_type>; preserve=<comma-separated nodes>"
        )

    def localization_record(self) -> Mapping[str, Any]:
        return {
            "messages": [
                {"role": "user", "content": self.prompt},
                {
                    "role": "assistant",
                    "content": (
                        f"ANSWER: target={self.target_node}; type={self.failure_type}; "
                        f"preserve={','.join(self.preserve_nodes)}"
                    ),
                },
            ],
            "metadata": {
                "task_id": self.task_id,
                "representation": self.representation,
                "mode": "localization",
            },
        }

    def edit_prompt(self) -> str:
        return (
            self.prompt
            + "\nApply one typed minimal edit. Return exactly: EDIT: <node>=<JSON value>"
        )

    def edit_record(self) -> Mapping[str, Any]:
        return {
            "messages": [
                {"role": "user", "content": self.edit_prompt()},
                {
                    "role": "assistant",
                    "content": f"EDIT: {self.target_node}={json.dumps(self.correct_edit_value, sort_keys=True)}",
                },
            ],
            "metadata": {
                "task_id": self.task_id,
                "representation": self.representation,
                "mode": "typed_edit",
            },
        }

    def regeneration_record(self) -> Mapping[str, Any]:
        program = ";".join(
            f"{node}={json.dumps(value, sort_keys=True)}"
            for node, value in sorted(self.authority.items())
        )
        return {
            "messages": [
                {"role": "user", "content": self.edit_prompt().replace(
                    "Apply one typed minimal edit. Return exactly: EDIT: <node>=<JSON value>",
                    "Regenerate the complete mechanism. Return exactly: PROGRAM: <node>=<JSON value>;...",
                )},
                {"role": "assistant", "content": "PROGRAM: " + program},
            ],
            "metadata": {
                "task_id": self.task_id,
                "representation": self.representation,
                "mode": "regeneration",
            },
        }

    def public_dict(self) -> Mapping[str, Any]:
        return {
            "task_id": self.task_id,
            "split": self.split,
            "representation": self.representation,
            "prompt": self.prompt,
        }

    def authority_dict(self) -> Mapping[str, Any]:
        return {
            **self.public_dict(),
            "candidate": dict(self.candidate),
            "authority": dict(self.authority),
            "target_node": self.target_node,
            "failure_type": self.failure_type,
            "preserve_nodes": list(self.preserve_nodes),
            "hidden_cases": list(self.hidden_cases),
        }


def execute(representation: str, program: Mapping[str, Any], value: Any) -> Any:
    if representation == "predicate":
        row = value
        source = int(program["n1_source"])
        score = int(row[source]) + int(program["n2_weight"]) * int(row[1])
        return score % int(program["n3_modulus"]) == int(program["n4_residue"])
    if representation == "temporal":
        sequence = tuple(int(item) for item in value)
        outputs = []
        cumulative = 0
        for index, current in enumerate(sequence):
            cumulative += current
            memory = str(program["n1_memory"])
            if memory == "previous":
                state = sequence[index - 1] if index else 0
            elif memory == "cumulative":
                state = cumulative
            else:
                state = current
            outputs.append(
                (int(program["n2_coefficient"]) * state + int(program["n3_offset"]))
                % int(program["n4_modulus"])
            )
        return outputs
    if representation == "causal":
        intervention_index, intervention_value = value
        effect = (
            int(program["n2_coefficient"]) * int(intervention_value)
            if int(intervention_index) == int(program["n1_cause"])
            else 0
        )
        return int(program["n3_baseline"]) + int(program["n4_sign"]) * effect
    if representation == "program":
        row = value
        raw = (
            int(row[int(program["n1_variable"])]) * int(program["n2_multiplier"])
            + int(program["n3_offset"])
        )
        return raw % int(program["n4_modulus"])
    if representation == "planning":
        stage, blocked = int(value[0]), bool(value[1])
        if blocked and stage == int(program["n1_blocked_stage"]):
            return str(program["n2_recovery_action"])
        if stage >= 4:
            return str(program["n4_terminal_action"])
        return str(program["n3_advance_action"])
    raise ValueError("unknown representation")


def _authority(representation: str, rng: random.Random) -> Dict[str, Any]:
    if representation == "predicate":
        modulus = rng.choice((3, 4, 5, 6))
        return {
            "n1_source": rng.choice((0, 2)),
            "n2_weight": rng.choice((1, 2, 3, 4)),
            "n3_modulus": modulus,
            "n4_residue": rng.randrange(modulus),
        }
    if representation == "temporal":
        return {
            "n1_memory": rng.choice(("previous", "cumulative")),
            "n2_coefficient": rng.choice((1, 2, 3)),
            "n3_offset": rng.choice((0, 1, 2, 3)),
            "n4_modulus": rng.choice((5, 7, 8, 9)),
        }
    if representation == "causal":
        return {
            "n1_cause": rng.randrange(3),
            "n2_coefficient": rng.choice((1, 2, 3, 4)),
            "n3_baseline": rng.choice((0, 1, 2)),
            "n4_sign": rng.choice((-1, 1)),
        }
    if representation == "program":
        return {
            "n1_variable": rng.randrange(3),
            "n2_multiplier": rng.choice((1, 2, 3, 4)),
            "n3_offset": rng.choice((0, 1, 2, 3, 4)),
            "n4_modulus": rng.choice((5, 7, 8, 9)),
        }
    return {
        "n1_blocked_stage": rng.choice((1, 2, 3)),
        "n2_recovery_action": rng.choice(("repair_alpha", "repair_beta", "repair_gamma")),
        "n3_advance_action": rng.choice(("advance_alpha", "advance_beta")),
        "n4_terminal_action": rng.choice(("audit", "release")),
    }


def _alternatives(representation: str, node: str, authority: Mapping[str, Any]) -> Tuple[Any, ...]:
    options: Mapping[str, Sequence[Any]] = {
        "n1_source": (0, 2),
        "n2_weight": (1, 2, 3, 4),
        "n3_modulus": (3, 4, 5, 6),
        "n1_memory": ("current", "previous", "cumulative"),
        "n2_coefficient": (1, 2, 3, 4),
        "n3_offset": (0, 1, 2, 3, 4),
        "n4_modulus": (5, 7, 8, 9),
        "n1_cause": (0, 1, 2),
        "n3_baseline": (0, 1, 2),
        "n4_sign": (-1, 1),
        "n1_variable": (0, 1, 2),
        "n2_multiplier": (1, 2, 3, 4),
        "n1_blocked_stage": (1, 2, 3),
        "n2_recovery_action": ("repair_alpha", "repair_beta", "repair_gamma"),
        "n3_advance_action": ("advance_alpha", "advance_beta"),
        "n4_terminal_action": ("audit", "release"),
    }
    node_options = (
        tuple(range(int(authority["n3_modulus"])))
        if node == "n4_residue"
        else options[node]
    )
    return tuple(value for value in node_options if value != authority[node])


def _failure_type(representation: str, node: str, candidate: Any, authority: Any) -> str:
    if node in ("n1_source", "n1_cause", "n1_variable"):
        return "wrong_variable"
    if node == "n1_memory":
        return "missing_state" if candidate == "current" else "wrong_operator"
    if representation == "planning" and node == "n1_blocked_stage":
        return "missing_dependency"
    if representation == "planning" and node == "n2_recovery_action":
        return "wrong_recovery"
    if representation == "planning":
        return "wrong_operator"
    return "wrong_constant"


def _inputs(representation: str, rng: random.Random, count: int = 60) -> Tuple[Any, ...]:
    values = []
    seen = set()
    maximum = 12 if representation in ("causal", "planning") else count
    while len(values) < maximum:
        if representation in ("predicate", "program"):
            value = [rng.randrange(10), rng.randrange(10), rng.randrange(10)]
        elif representation == "temporal":
            value = [rng.randrange(5) for _ in range(5)]
        elif representation == "causal":
            value = [rng.randrange(3), rng.randrange(1, 5)]
        else:
            value = [rng.randrange(6), bool(rng.randrange(2))]
        marker = json.dumps(value, sort_keys=True)
        if marker not in seen:
            values.append(value)
            seen.add(marker)
    return tuple(values)


def _build_task(split: str, representation: str, index: int, rng: random.Random) -> RepairTask:
    for attempt in range(500):
        authority = _authority(representation, rng)
        nodes = tuple(authority)
        target = nodes[(index + attempt) % len(nodes)]
        alternatives = _alternatives(representation, target, authority)
        if not alternatives:
            continue
        candidate = dict(authority)
        candidate[target] = rng.choice(alternatives)
        cases = []
        for value in _inputs(representation, rng):
            expected = execute(representation, authority, value)
            observed = execute(representation, candidate, value)
            cases.append({"input": value, "expected": expected, "candidate": observed})
        correct = [case for case in cases if case["candidate"] == case["expected"]]
        wrong = [case for case in cases if case["candidate"] != case["expected"]]
        minimum_wrong = 1
        if len(correct) < 4 or len(wrong) < minimum_wrong:
            continue
        rng.shuffle(correct)
        rng.shuffle(wrong)
        visible_correct = tuple(correct[:4])
        counterexample = wrong[0]
        used = {json.dumps(case["input"], sort_keys=True) for case in visible_correct + (counterexample,)}
        hidden_pool = [case for case in cases if json.dumps(case["input"], sort_keys=True) not in used]
        rng.shuffle(hidden_pool)
        hidden = tuple(hidden_pool[: min(30, len(hidden_pool))])
        body = json.dumps(
            {"split": split, "representation": representation, "index": index, "candidate": candidate},
            sort_keys=True,
        )
        task_id = "repair-v32-" + hashlib.sha256(body.encode("utf-8")).hexdigest()[:20]
        return RepairTask(
            task_id,
            split,
            representation,
            candidate,
            authority,
            target,
            _failure_type(representation, target, candidate[target], authority[target]),
            visible_correct,
            counterexample,
            hidden,
        )
    raise RuntimeError(f"could not generate informative {representation} task")


def build_suite(
    split: str,
    per_representation: int,
    representations: Sequence[str] = REPRESENTATIONS,
) -> Tuple[RepairTask, ...]:
    if split not in SPLIT_SEEDS:
        raise ValueError("unknown repair split")
    rng = random.Random(SPLIT_SEEDS[split])
    tasks = tuple(
        _build_task(split, representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )
    if len({task.task_id for task in tasks}) != len(tasks):
        raise RuntimeError("repair task ids are not unique")
    return tasks


_LOCALIZATION_RE = re.compile(
    r"ANSWER\s*:\s*target\s*=\s*([^;\s]+)\s*;\s*type\s*=\s*([^;\s]+)\s*;\s*preserve\s*=\s*([^\n\r]+)",
    re.IGNORECASE,
)
_EDIT_RE = re.compile(r"EDIT\s*:\s*([^=\s]+)\s*=\s*([^\n\r]+)", re.IGNORECASE)
_PROGRAM_RE = re.compile(r"PROGRAM\s*:\s*([^\n\r]+)", re.IGNORECASE)


def parse_localization(response: str) -> Mapping[str, Any] | None:
    matches = _LOCALIZATION_RE.findall(response)
    if not matches:
        return None
    target, failure_type, preserve = matches[-1]
    return {
        "target": target.strip(),
        "failure_type": failure_type.strip(),
        "preserve": tuple(sorted(item.strip() for item in preserve.split(",") if item.strip())),
    }


def score_localization(task: RepairTask, response: str) -> Mapping[str, Any]:
    parsed = parse_localization(response)
    if parsed is None:
        return {
            "parsed": False,
            "target_correct": False,
            "type_correct": False,
            "preservation_f1": 0.0,
            "joint_correct": False,
        }
    predicted = set(parsed["preserve"])
    expected = set(task.preserve_nodes)
    precision = len(predicted & expected) / len(predicted) if predicted else 0.0
    recall = len(predicted & expected) / len(expected) if expected else 1.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    target_correct = parsed["target"] == task.target_node
    type_correct = parsed["failure_type"] == task.failure_type
    return {
        "parsed": True,
        "target_correct": target_correct,
        "type_correct": type_correct,
        "preservation_f1": f1,
        "joint_correct": target_correct and type_correct and predicted == expected,
        "parsed_value": parsed,
    }


def parse_edit(response: str) -> Tuple[str, Any] | None:
    matches = _EDIT_RE.findall(response)
    if not matches:
        return None
    node, raw = matches[-1]
    raw = raw.strip().rstrip(".;")
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        value = raw.strip("`\"'")
    return node.strip(), value


def apply_edit(task: RepairTask, response: str) -> Mapping[str, Any] | None:
    parsed = parse_edit(response)
    if parsed is None:
        return None
    node, value = parsed
    if node not in task.candidate:
        return None
    program = dict(task.candidate)
    program[node] = value
    return program


def parse_program(task: RepairTask, response: str) -> Mapping[str, Any] | None:
    matches = _PROGRAM_RE.findall(response)
    if not matches:
        return None
    values: Dict[str, Any] = {}
    for part in matches[-1].split(";"):
        if "=" not in part:
            continue
        node, raw = part.split("=", 1)
        node = node.strip()
        if node not in task.candidate:
            continue
        try:
            values[node] = json.loads(raw.strip())
        except json.JSONDecodeError:
            values[node] = raw.strip().strip("`\"'")
    return values if set(values) == set(task.candidate) else None


def score_program(task: RepairTask, program: Mapping[str, Any] | None) -> Mapping[str, Any]:
    if program is None:
        return {
            "valid": False,
            "semantic_accuracy": 0.0,
            "preserved_correct_accuracy": 0.0,
            "exact_program": False,
        }
    semantic = []
    for case in task.hidden_cases:
        try:
            semantic.append(execute(task.representation, program, case["input"]) == case["expected"])
        except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
            semantic.append(False)
    preserved = []
    for case in task.visible_correct:
        try:
            preserved.append(execute(task.representation, program, case["input"]) == case["expected"])
        except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
            preserved.append(False)
    return {
        "valid": True,
        "semantic_accuracy": sum(semantic) / len(semantic),
        "preserved_correct_accuracy": sum(preserved) / len(preserved),
        "exact_program": dict(program) == dict(task.authority),
    }


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def prepare_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    localization_train = build_suite("train", 60, LOCALIZATION_TRAIN_REPRESENTATIONS)
    localization_valid = build_suite("valid", 12, LOCALIZATION_TRAIN_REPRESENTATIONS)
    edit_train = build_suite("train", 50, REPRESENTATIONS)
    edit_valid = build_suite("valid", 10, REPRESENTATIONS)
    test_suites = {
        "localization_test": build_suite("localization_test", 30, REPRESENTATIONS),
        "repair_test": build_suite("repair_test", 30, REPRESENTATIONS),
        "trajectory_test": build_suite("trajectory_test", 30, REPRESENTATIONS),
    }
    (output / "localization").mkdir(parents=True, exist_ok=True)
    hashes = {
        "localization_train": _write_jsonl(
            output / "localization/train.jsonl",
            (task.localization_record() for task in localization_train),
        ),
    }
    hashes["localization_valid"] = _write_jsonl(
        output / "localization/valid.jsonl", (task.localization_record() for task in localization_valid)
    )
    (output / "typed_edit").mkdir(parents=True, exist_ok=True)
    hashes["edit_train"] = _write_jsonl(
        output / "typed_edit/train.jsonl", (task.edit_record() for task in edit_train)
    )
    hashes["edit_valid"] = _write_jsonl(
        output / "typed_edit/valid.jsonl", (task.edit_record() for task in edit_valid)
    )
    (output / "regeneration").mkdir(parents=True, exist_ok=True)
    hashes["regeneration_train"] = _write_jsonl(
        output / "regeneration/train.jsonl", (task.regeneration_record() for task in edit_train)
    )
    hashes["regeneration_valid"] = _write_jsonl(
        output / "regeneration/valid.jsonl", (task.regeneration_record() for task in edit_valid)
    )
    for split, tasks in test_suites.items():
        hashes[split + "_public"] = _write_jsonl(
            output / f"{split}-public.jsonl", (task.public_dict() for task in tasks)
        )
        hashes[split + "_authority"] = _write_jsonl(
            output / f"{split}-authority.jsonl", (task.authority_dict() for task in tasks)
        )
    payload = {
        "version": REPAIR_BENCHMARK_VERSION,
        "split_seeds": SPLIT_SEEDS,
        "representations": list(REPRESENTATIONS),
        "localization_training_representations": list(LOCALIZATION_TRAIN_REPRESENTATIONS),
        "heldout_localization_representations": list(HELDOUT_LOCALIZATION_REPRESENTATIONS),
        "counts": {
            "localization_train": len(localization_train),
            "localization_valid": len(localization_valid),
            "edit_train": len(edit_train),
            "edit_valid": len(edit_valid),
            **{name: len(tasks) for name, tasks in test_suites.items()},
        },
        "hashes": hashes,
        "m32_gates": {
            "minimum_parse_coverage": 0.95,
            "minimum_target_accuracy": 0.75,
            "minimum_failure_type_accuracy": 0.75,
            "minimum_preservation_f1": 0.95,
            "minimum_heldout_representation_target_accuracy": 0.60,
        },
        "m33_gates": {
            "minimum_semantic_accuracy": 0.65,
            "minimum_gain_over_candidate": 0.10,
            "minimum_preserved_correct_accuracy": 0.95,
            "minimum_exact_rate": 0.25,
        },
        "m34_gates": {
            "minimum_localized_advantage_over_regeneration": 0.08,
            "minimum_two_step_semantic_accuracy": 0.75,
            "minimum_monotonic_gain": 0.05,
            "minimum_preserved_correct_accuracy": 0.95,
        },
        "claim_boundary": (
            "This is a fresh executable repair benchmark with representation-level holdout for M32. "
            "It is still procedurally generated and cannot establish naturalistic general cognition."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    file_map = {
        "localization_train": output / "localization/train.jsonl",
        "localization_valid": output / "localization/valid.jsonl",
        "edit_train": output / "typed_edit/train.jsonl",
        "edit_valid": output / "typed_edit/valid.jsonl",
        "regeneration_train": output / "regeneration/train.jsonl",
        "regeneration_valid": output / "regeneration/valid.jsonl",
    }
    for split in ("localization_test", "repair_test", "trajectory_test"):
        file_map[split + "_public"] = output / f"{split}-public.jsonl"
        file_map[split + "_authority"] = output / f"{split}-authority.jsonl"
    observed = {key: hashlib.sha256(path.read_bytes()).hexdigest() for key, path in file_map.items()}
    train_representations = {
        json.loads(line)["metadata"]["representation"]
        for line in (output / "localization/train.jsonl").read_text(encoding="utf-8").splitlines()
    }
    checks = {
        "hashes_match": observed == freeze["hashes"],
        "program_and_planning_absent_from_localization_training": not (
            set(HELDOUT_LOCALIZATION_REPRESENTATIONS) & train_representations
        ),
        "all_five_representations_in_localization_test": {
            task.representation for task in build_suite("localization_test", 30)
        } == set(REPRESENTATIONS),
        "test_splits_are_disjoint": len({
            task.task_id
            for split in ("localization_test", "repair_test", "trajectory_test")
            for task in build_suite(split, 30)
        }) == 450,
        "gates_frozen": all(name in freeze for name in ("m32_gates", "m33_gates", "m34_gates")),
    }
    return {
        "version": REPAIR_BENCHMARK_VERSION,
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }
