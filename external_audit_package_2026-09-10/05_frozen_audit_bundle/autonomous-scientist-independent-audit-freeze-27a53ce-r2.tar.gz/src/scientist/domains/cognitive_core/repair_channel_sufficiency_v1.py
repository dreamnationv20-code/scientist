from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from scientist.program.causal_failure import CausalFailureModelSet
from scientist.program.research_kernel import (
    DiagnosticConceptHypothesis,
    PhenomenonAtlas,
)


VERSION = "cognitive-repair-channel-sufficiency-concept-v1"
FORBIDDEN_PRIMITIVE_TERMS = (
    "answer",
    "authority",
    "correctness",
    "gold",
    "label",
    "outcome",
)


@dataclass(frozen=True)
class ConceptCandidate:
    name: str
    definition: str
    input_primitives: tuple[str, ...]
    computation: str
    causal_explanation: str
    covered_cluster_ids: tuple[str, ...]
    distinguishing_predictions: tuple[str, ...]
    boundary_conditions: tuple[str, ...]
    falsification_conditions: tuple[str, ...]

    def as_dict(self) -> Mapping[str, Any]:
        return {
            "name": self.name,
            "definition": self.definition,
            "input_primitives": list(self.input_primitives),
            "computation": self.computation,
            "causal_explanation": self.causal_explanation,
            "covered_cluster_ids": list(self.covered_cluster_ids),
            "distinguishing_predictions": list(self.distinguishing_predictions),
            "boundary_conditions": list(self.boundary_conditions),
            "falsification_conditions": list(self.falsification_conditions),
            "answer_blindness_failures": list(answer_blindness_failures(self)),
        }


def answer_blindness_failures(candidate: ConceptCandidate) -> tuple[str, ...]:
    failures = []
    for primitive in candidate.input_primitives:
        lowered = primitive.casefold()
        for term in FORBIDDEN_PRIMITIVE_TERMS:
            if term in lowered:
                failures.append("%s:%s" % (primitive, term))
    return tuple(failures)


def candidate_registry(diagnosis: CausalFailureModelSet) -> tuple[ConceptCandidate, ...]:
    clusters = set(diagnosis.failure_cluster_ids)

    def covered(*values: str) -> tuple[str, ...]:
        return tuple(value for value in values if value in clusters)

    return (
        ConceptCandidate(
            name="repair-channel sufficiency",
            definition=(
                "The weakest post-intervention reasoning slot support after accounting "
                "for whether the repair supplies that slot, whether its current value is "
                "reliably bound, and whether the remaining dependency schedule is executable."
            ),
            input_primitives=(
                "reasoning dependency slots",
                "intervention supplied-slot mask",
                "internal slot stability",
                "source availability prior",
                "decomposition schedule coverage",
                "current-version exclusivity",
                "stale-write conflict load",
                "source-role compatibility",
                "residual unsupplied-slot stability",
            ),
            computation=(
                "For each slot s and repair r: support_s=max(internal_stability_s, "
                "supplied_s*source_availability_s); binding_s=current_exclusivity_s*"
                "source_role_compatibility_s*(1-stale_conflict_s). Then "
                "RCS(x,r)=min_s(support_s*binding_s)*(1+schedule_coverage_r)/2, "
                "and repair lift is RCS(x,r)-RCS(x,raw)."
            ),
            causal_explanation=(
                "A nonparametric repair works only when it raises the support of the "
                "actual limiting slot without corrupting its version/provenance binding, "
                "while leaving every unsupplied downstream slot sufficiently stable."
            ),
            covered_cluster_ids=covered(
                "decomposition-scaffold-availability",
                "trusted-first-hop-state-availability",
                "interleaved-stale-write-hazard",
                "provenance-role-binding-contamination",
            ),
            distinguishing_predictions=(
                "decomposition helps when slot stability is high but dependency-schedule coverage is low",
                "explicit state helps when the supplied slot is limiting and residual unsupplied-slot stability is high",
                "interleaving lowers repairability in proportion to stale-write conflict despite identical proposition values",
                "provenance swapping lowers repairability when it reduces compatibility of the current proposition",
                "when every qualified nonparametric arm leaves the minimum slot support low, representation change becomes the leading class",
            ),
            boundary_conditions=(
                "the task admits a finite dependency-slot representation",
                "all primitives are measurable before intervention effects are observed",
                "internal stability is computed from agreement without reference values",
                "source roles and version structure are visible in the intervention contract",
            ),
            falsification_conditions=(
                "prospective repair probabilities do not improve over family-only and complexity-only baselines",
                "paired repair effects are not ordered by preregistered repair-channel lift",
                "transaction and provenance effects vanish under independently phrased matched controls",
                "predicted representation-required cases are repaired by a qualified nonparametric arm",
            ),
        ),
        ConceptCandidate(
            name="repair-target bottleneck match",
            definition=(
                "A repair succeeds when the information or computation it supplies matches "
                "the single dominant missing reasoning stage."
            ),
            input_primitives=(
                "reasoning dependency slots",
                "intervention supplied-slot mask",
                "internal slot stability",
                "residual unsupplied-slot stability",
            ),
            computation=(
                "Score the overlap between the lowest-stability slot and the supplied-slot mask."
            ),
            causal_explanation=(
                "Repairs are heterogeneous because they target different bottleneck locations."
            ),
            covered_cluster_ids=covered(
                "decomposition-scaffold-availability",
                "trusted-first-hop-state-availability",
            ),
            distinguishing_predictions=(
                "state helps when a supplied slot is the stability minimum",
                "decomposition helps when relation order rather than slot availability is limiting",
            ),
            boundary_conditions=(
                "one bottleneck dominates each failure",
                "slot stability localizes that bottleneck without reference values",
            ),
            falsification_conditions=(
                "multi-bottleneck cases are predicted as reliably as single-bottleneck cases",
                "repair effects do not depend on supplied-slot overlap",
            ),
        ),
        ConceptCandidate(
            name="transactional interference load",
            definition=(
                "The amount of conflicting state that can compete with the intended current proposition."
            ),
            input_primitives=(
                "current-version exclusivity",
                "stale-write conflict load",
                "source-role compatibility",
                "state record count",
            ),
            computation=(
                "Interference is stale conflict plus source-role conflict minus current exclusivity."
            ),
            causal_explanation=(
                "Repairs fail when conflicting records contaminate selection of the intended state."
            ),
            covered_cluster_ids=covered(
                "interleaved-stale-write-hazard",
                "provenance-role-binding-contamination",
            ),
            distinguishing_predictions=(
                "atomic invalidation helps under high stale conflict",
                "trusted-current provenance helps under source-role conflict",
            ),
            boundary_conditions=(
                "the intervention exposes multiple competing propositions",
                "record versions and source roles are explicit",
            ),
            falsification_conditions=(
                "conflict-free controls show the same effect",
                "interference load is unrelated to state uptake prospectively",
            ),
        ),
        ConceptCandidate(
            name="instructional control burden",
            definition=(
                "The control-token and rule-following burden imposed by an intervention relative to the model's stable execution capacity."
            ),
            input_primitives=(
                "instruction token count",
                "state record count",
                "conditional rule count",
                "dependency depth",
                "internal slot stability",
            ),
            computation=(
                "Burden is normalized instruction length times conditional-rule count divided by internal stability."
            ),
            causal_explanation=(
                "Some repairs harm by consuming control capacity rather than by supplying the wrong information."
            ),
            covered_cluster_ids=covered(
                "trusted-first-hop-state-availability",
                "interleaved-stale-write-hazard",
            ),
            distinguishing_predictions=(
                "longer rule sets harm low-stability models more strongly",
                "semantically equivalent compressed state restores part of the lost effect",
            ),
            boundary_conditions=(
                "instruction burden varies independently of supplied information",
                "token and rule counts are fixed before execution",
            ),
            falsification_conditions=(
                "length-matched compressed controls preserve the original harm",
                "burden does not interact with model size or dependency depth",
            ),
        ),
    )


def selection_table(
    candidates: Sequence[ConceptCandidate],
    diagnosis: CausalFailureModelSet,
) -> tuple[Mapping[str, Any], ...]:
    required = set(diagnosis.failure_cluster_ids)
    rows = []
    for candidate in candidates:
        covered = set(candidate.covered_cluster_ids)
        rows.append(
            {
                "name": candidate.name,
                "covered_cluster_count": len(required.intersection(covered)),
                "coverage_complete": required.issubset(covered),
                "answer_blindness_passed": not answer_blindness_failures(candidate),
                "prediction_count": len(candidate.distinguishing_predictions),
                "falsifier_count": len(candidate.falsification_conditions),
                "primitive_count": len(candidate.input_primitives),
            }
        )
    return tuple(rows)


def select_candidate(
    candidates: Sequence[ConceptCandidate],
    diagnosis: CausalFailureModelSet,
) -> ConceptCandidate:
    table = {row["name"]: row for row in selection_table(candidates, diagnosis)}
    eligible = [
        candidate
        for candidate in candidates
        if bool(table[candidate.name]["answer_blindness_passed"])
    ]
    if not eligible:
        raise ValueError("no answer-blind concept candidate survived")
    return max(
        eligible,
        key=lambda candidate: (
            int(table[candidate.name]["coverage_complete"]),
            int(table[candidate.name]["covered_cluster_count"]),
            int(table[candidate.name]["prediction_count"]),
            int(table[candidate.name]["falsifier_count"]),
            -int(table[candidate.name]["primitive_count"]),
            candidate.name,
        ),
    )


def build_diagnostic_concept(
    atlas: PhenomenonAtlas,
    diagnosis: CausalFailureModelSet,
    candidate: ConceptCandidate,
) -> DiagnosticConceptHypothesis:
    if answer_blindness_failures(candidate):
        raise ValueError("selected concept contains forbidden predictor primitives")
    if set(candidate.covered_cluster_ids) != set(diagnosis.failure_cluster_ids):
        raise ValueError("selected concept does not cover every causal failure cluster")
    return DiagnosticConceptHypothesis(
        atlas_id=atlas.atlas_id,
        causal_model_set_id=diagnosis.model_set_id,
        name=candidate.name,
        definition=candidate.definition,
        input_primitives=candidate.input_primitives,
        computation=candidate.computation,
        causal_explanation=candidate.causal_explanation,
        distinguishing_predictions=candidate.distinguishing_predictions,
        boundary_conditions=candidate.boundary_conditions,
        falsification_conditions=candidate.falsification_conditions,
        development_contrast_ids=tuple(item.contrast_id for item in atlas.contrasts),
        required_predictive_score=0.60,
        minimum_predictive_improvement=0.10,
        prospective_case_count=24,
        validation_protocol_ref=(
            "fresh-disjoint-repair-channel-sufficiency-validation-v1"
        ),
        proposer_ref="codex-assisted-causal-concept-inventor-v1",
    )


__all__ = [
    "FORBIDDEN_PRIMITIVE_TERMS",
    "VERSION",
    "ConceptCandidate",
    "answer_blindness_failures",
    "build_diagnostic_concept",
    "candidate_registry",
    "select_candidate",
    "selection_table",
]
