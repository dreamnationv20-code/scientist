from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.internal_core_v28 import _batch_responses, _chat_prompt
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    HELDOUT_LOCALIZATION_REPRESENTATIONS,
    REPAIR_BENCHMARK_VERSION,
    RepairTask,
    build_suite,
    score_localization,
)


REPAIR_LOCALIZATION_VERSION = "general-cognitive-repair-localization-v32"


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def aggregate_localization(
    condition: str,
    tasks: Sequence[RepairTask],
    responses: Sequence[str],
    *,
    elapsed_seconds: float = 0.0,
    peak_memory_gb: float = 0.0,
) -> Mapping[str, Any]:
    if len(tasks) != len(responses):
        raise ValueError("tasks and responses do not align")
    records = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    for task, response in zip(tasks, responses):
        assessment = score_localization(task, response)
        record = {
            "task_id": task.task_id,
            "representation": task.representation,
            "response": response,
            "assessment": assessment,
        }
        records.append(record)
        by_representation.setdefault(task.representation, []).append(assessment)

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        return {
            "parse_coverage": _mean([float(bool(item["parsed"])) for item in items]),
            "target_accuracy": _mean([float(bool(item["target_correct"])) for item in items]),
            "failure_type_accuracy": _mean([float(bool(item["type_correct"])) for item in items]),
            "preservation_f1": _mean([float(item["preservation_f1"]) for item in items]),
            "joint_accuracy": _mean([float(bool(item["joint_correct"])) for item in items]),
        }

    all_assessments = [record["assessment"] for record in records]
    heldout = [
        record["assessment"]
        for record in records
        if record["representation"] in HELDOUT_LOCALIZATION_REPRESENTATIONS
    ]
    metrics = {
        "condition": condition,
        "task_count": len(tasks),
        **summarize(all_assessments),
        "heldout_representation_target_accuracy": summarize(heldout)["target_accuracy"],
        "by_representation": {
            representation: summarize(items)
            for representation, items in sorted(by_representation.items())
        },
        "elapsed_seconds": elapsed_seconds,
        "peak_memory_gb": peak_memory_gb,
    }
    return {"metrics": metrics, "records": records}


def evaluate_localization(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    condition: str,
    *,
    adapter_path: Optional[Path] = None,
    batch_size: int = 8,
    max_tokens: int = 80,
    max_batch_tokens: int = 12000,
) -> Mapping[str, Any]:
    from mlx_lm import load

    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    tasks = build_suite("localization_test", 30)
    started = time.monotonic()
    arguments: Dict[str, Any] = {"return_config": True}
    if adapter_path is not None:
        arguments["adapter_path"] = str(adapter_path)
    model, tokenizer, config = load(model_path, **arguments)
    prompts = tuple(_chat_prompt(tokenizer, task.prompt) for task in tasks)
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        prompts,
        batch_size=batch_size,
        max_tokens=max_tokens,
        max_batch_tokens=max_batch_tokens,
    )
    result = aggregate_localization(
        condition,
        tasks,
        responses,
        elapsed_seconds=time.monotonic() - started,
        peak_memory_gb=peak_memory,
    )
    store = ArtifactStore(output_root)
    predictions_digest = store.put("repair_localization_predictions", result["records"])
    payload = {
        "version": REPAIR_LOCALIZATION_VERSION,
        "benchmark_version": REPAIR_BENCHMARK_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "condition": condition,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path) if adapter_path else None,
        "adapter_config_sha256": (
            hashlib.sha256((adapter_path / "adapter_config.json").read_bytes()).hexdigest()
            if adapter_path else None
        ),
        "adapter_weights_sha256": (
            hashlib.sha256((adapter_path / "adapters.safetensors").read_bytes()).hexdigest()
            if adapter_path else None
        ),
        "metrics": result["metrics"],
        "predictions_digest": predictions_digest,
        "generation": {
            "batch_size": batch_size,
            "max_tokens": max_tokens,
            "max_batch_tokens": max_batch_tokens,
        },
        "claim_boundary": (
            "M32 tests single-fault localization on fresh executable synthetic mechanisms; "
            "it does not establish localization on natural programs or unrestricted tasks."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest(f"repair-localization-{condition}-{evaluation_id}", manifest)
    return manifest


def compare_localization(
    baseline: Mapping[str, Any],
    candidate: Mapping[str, Any],
    benchmark_root: Path,
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["m32_gates"]
    base = baseline["metrics"]
    proposed = candidate["metrics"]
    checks = {
        "same_benchmark_freeze": (
            baseline["benchmark_freeze_id"] == candidate["benchmark_freeze_id"] == freeze["freeze_id"]
        ),
        "same_model": baseline["model_path"] == candidate["model_path"],
        "adapter_only_on_candidate": baseline.get("adapter_path") is None and candidate.get("adapter_path") is not None,
        "parse_coverage": proposed["parse_coverage"] >= gates["minimum_parse_coverage"],
        "target_accuracy": proposed["target_accuracy"] >= gates["minimum_target_accuracy"],
        "failure_type_accuracy": proposed["failure_type_accuracy"] >= gates["minimum_failure_type_accuracy"],
        "preservation_f1": proposed["preservation_f1"] >= gates["minimum_preservation_f1"],
        "heldout_representation_target_accuracy": (
            proposed["heldout_representation_target_accuracy"]
            >= gates["minimum_heldout_representation_target_accuracy"]
        ),
    }
    payload = {
        "version": REPAIR_LOCALIZATION_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "baseline_evaluation_id": baseline["evaluation_id"],
        "candidate_evaluation_id": candidate["evaluation_id"],
        "gains": {
            key: proposed[key] - base[key]
            for key in (
                "parse_coverage",
                "target_accuracy",
                "failure_type_accuracy",
                "preservation_f1",
                "joint_accuracy",
                "heldout_representation_target_accuracy",
            )
        },
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
    }
    return {**payload, "comparison_id": content_digest(payload)}
