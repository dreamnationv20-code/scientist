from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.repair_benchmark_v32 import RepairTask, build_suite, execute


TRAJECTORY_DATA_VERSION = "general-cognitive-repair-trajectory-data-v34"


def program_text(program: Mapping[str, Any]) -> str:
    return "PROGRAM: " + ";".join(
        f"{node}={json.dumps(value, sort_keys=True)}" for node, value in sorted(program.items())
    )


def failed_edit(task: RepairTask) -> str:
    return f"EDIT: {task.target_node}={json.dumps(task.candidate[task.target_node], sort_keys=True)}"


def verifier_feedback(task: RepairTask, program: Mapping[str, Any]) -> str:
    cases = (task.counterexample,) + task.hidden_cases
    for case in cases:
        try:
            observed = execute(task.representation, program, case["input"])
        except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
            observed = "execution_error"
        if observed != case["expected"]:
            return (
                f"Additional counterexample: input={json.dumps(case['input'])}; "
                f"attempt_output={json.dumps(observed)}; required_output={json.dumps(case['expected'])}. "
                "The four previously correct cases must remain correct."
            )
    return "The verifier found no remaining failing case; preserve the successful mechanism exactly."


def localized_revision_prompt(task: RepairTask, previous_attempt: str) -> str:
    from scientist.domains.cognitive_core.repair_benchmark_v32 import apply_edit

    attempted = apply_edit(task, previous_attempt)
    program = attempted if attempted is not None else task.candidate
    return (
        task.edit_prompt()
        + f"\nPrevious attempt: {previous_attempt}\nVerifier feedback: {verifier_feedback(task, program)}\n"
        "Revise the previous attempt. Return exactly one typed edit: EDIT: <node>=<JSON value>"
    )


def regeneration_prompt(task: RepairTask) -> str:
    return task.edit_prompt().replace(
        "Apply one typed minimal edit. Return exactly: EDIT: <node>=<JSON value>",
        "Regenerate the complete mechanism. Return exactly: PROGRAM: <node>=<JSON value>;...",
    )


def regeneration_revision_prompt(task: RepairTask, previous_attempt: str) -> str:
    from scientist.domains.cognitive_core.repair_benchmark_v32 import parse_program

    attempted = parse_program(task, previous_attempt)
    program = attempted if attempted is not None else task.candidate
    return (
        regeneration_prompt(task)
        + f"\nPrevious attempt: {previous_attempt}\nVerifier feedback: {verifier_feedback(task, program)}\n"
        "Regenerate the corrected complete mechanism. Return exactly: PROGRAM: <node>=<JSON value>;..."
    )


def localized_records(tasks: Sequence[RepairTask]) -> list[Mapping[str, Any]]:
    rows = []
    for task in tasks:
        rows.append(task.edit_record())
        wrong = failed_edit(task)
        rows.append(
            {
                "messages": [
                    {"role": "user", "content": localized_revision_prompt(task, wrong)},
                    {
                        "role": "assistant",
                        "content": f"EDIT: {task.target_node}={json.dumps(task.correct_edit_value, sort_keys=True)}",
                    },
                ],
                "metadata": {
                    "task_id": task.task_id,
                    "representation": task.representation,
                    "mode": "counterexample_to_typed_edit",
                },
            }
        )
    return rows


def regeneration_records(tasks: Sequence[RepairTask]) -> list[Mapping[str, Any]]:
    rows = []
    for task in tasks:
        rows.append(task.regeneration_record())
        wrong = program_text(task.candidate)
        rows.append(
            {
                "messages": [
                    {"role": "user", "content": regeneration_revision_prompt(task, wrong)},
                    {"role": "assistant", "content": program_text(task.authority)},
                ],
                "metadata": {
                    "task_id": task.task_id,
                    "representation": task.representation,
                    "mode": "counterexample_to_regeneration",
                },
            }
        )
    return rows


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> str:
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def prepare_trajectory_data(output: Path, benchmark_root: Path) -> Mapping[str, Any]:
    parent = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    train_tasks = build_suite("train", 50)
    valid_tasks = build_suite("valid", 10)
    localized_train = localized_records(train_tasks)
    localized_valid = localized_records(valid_tasks)
    regeneration_train = regeneration_records(train_tasks)
    regeneration_valid = regeneration_records(valid_tasks)
    random.Random(3401).shuffle(localized_train)
    random.Random(3403).shuffle(localized_valid)
    random.Random(3401).shuffle(regeneration_train)
    random.Random(3403).shuffle(regeneration_valid)
    (output / "localized").mkdir(parents=True, exist_ok=True)
    (output / "regeneration").mkdir(parents=True, exist_ok=True)
    hashes = {
        "localized_train": _write_jsonl(output / "localized/train.jsonl", localized_train),
        "localized_valid": _write_jsonl(output / "localized/valid.jsonl", localized_valid),
        "regeneration_train": _write_jsonl(output / "regeneration/train.jsonl", regeneration_train),
        "regeneration_valid": _write_jsonl(output / "regeneration/valid.jsonl", regeneration_valid),
    }
    payload = {
        "version": TRAJECTORY_DATA_VERSION,
        "parent_benchmark_freeze_id": parent["freeze_id"],
        "counts": {
            "localized_train": len(localized_train),
            "localized_valid": len(localized_valid),
            "regeneration_train": len(regeneration_train),
            "regeneration_valid": len(regeneration_valid),
        },
        "hashes": hashes,
        "matched_training_examples": len(localized_train) == len(regeneration_train),
        "claim_boundary": "Training pairs are synthetic and expose only training/validation authorities.",
    }
    manifest = {**payload, "data_freeze_id": content_digest(payload)}
    (output / "data-freeze.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return manifest


def verify_trajectory_data(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "data-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "localized_train": output / "localized/train.jsonl",
        "localized_valid": output / "localized/valid.jsonl",
        "regeneration_train": output / "regeneration/train.jsonl",
        "regeneration_valid": output / "regeneration/valid.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "matched_training_examples": freeze["matched_training_examples"],
        "equal_train_counts": freeze["counts"]["localized_train"] == freeze["counts"]["regeneration_train"],
        "equal_valid_counts": freeze["counts"]["localized_valid"] == freeze["counts"]["regeneration_valid"],
    }
    return {"checks": checks, "passed": all(checks.values()), "data_freeze_id": freeze["data_freeze_id"]}
