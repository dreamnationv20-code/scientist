"""Fresh, bounded test of the candidate-availability repair hypothesis.

This module intentionally has no dependency on the previous repairability runs.
It exposes only prompt-visible candidate constraints to the executor.  Gold answers
live in a separate authority file and are opened only by the development
qualification step or terminal scorer.
"""

from __future__ import annotations

import hashlib
import json
import random
import re
from collections import Counter, deque
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from scientist.domains.cognitive_core.repairability_reframe_v1 import digest


VERSION = "cognitive-repairability-candidate-availability-v1"
MODEL_ORDER = ("qwen3_1p7b", "qwen2p5_3b")
TASK_SEED = 860_401_100
SCHEDULE_SEED = 860_401_200
DEVELOPMENT_TASK_COUNT = 16
PROSPECTIVE_POOL_COUNT = 32
INVARIANCE_TASK_COUNT = 8
SELECTED_PROSPECTIVE_COUNT = 12
CANDIDATE_BANK_CALLS = 5
MAXIMUM_NEW_TOKENS = 48
TEMPERATURE = 0.55
MODEL_HOUR_CAPS = {"qwen3_1p7b": 0.85, "qwen2p5_3b": 1.20}
MAXIMUM_TOTAL_HOURS = 2.05

# The forged candidate-and-state proposal for the candidate availability mediator.
FORGE_HYPOTHESIS_ID = "0645ff9673f5a7c8071caee1c372d88e51bbf5935e58d169146253b6f41c01e0"
FORGE_PROPOSAL_ID = "c4ac5505b32a7acea06284e5dba48e7fce5655c6eee9d766742085ee6f484acf"


def file_sha256(path: Path) -> str:
    body = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            body.update(block)
    return body.hexdigest()


def jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(
        json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n" for row in rows
    )


def read_rows(path: Path) -> list[Mapping[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    ]


def derive_seed(*labels: object) -> int:
    payload = "\0".join(str(value) for value in (SCHEDULE_SEED, *labels))
    return int.from_bytes(hashlib.sha256(payload.encode("utf-8")).digest()[:4], "big")


def _aliases(rng: random.Random, count: int, prefix: str) -> list[str]:
    values = list(range(100, 1000))
    rng.shuffle(values)
    return [f"{prefix}{value}" for value in values[:count]]


def _shortest_actions(
    start: str, goal: str, edges: Sequence[tuple[str, str, str]]
) -> tuple[str, ...]:
    by_source: dict[str, list[tuple[str, str]]] = {}
    for source, target, action in edges:
        by_source.setdefault(source, []).append((target, action))
    queue: deque[tuple[str, tuple[str, ...]]] = deque([(start, ())])
    seen = {start}
    while queue:
        node, actions = queue.popleft()
        if node == goal:
            return actions
        for target, action in by_source.get(node, ()):
            if target not in seen:
                seen.add(target)
                queue.append((target, (*actions, action)))
    raise RuntimeError("generated transition task has no route to its goal")


def _planning_prompt(
    start: str,
    goal: str,
    edges: Sequence[tuple[str, str, str]],
    first_options: Sequence[str],
) -> str:
    facts = [
        f"Operation {action} can be used only in {source}; it moves the agent to {target}."
        for source, target, action in edges
    ]
    return (
        "An agent is in an unfamiliar transition system. It starts in "
        f"{start} and must reach {goal} in the fewest operations.\n"
        + "\n".join(facts)
        + "\nThe only prompt-valid first-operation labels are: "
        + ", ".join(first_options)
        + ".\nWhich operation must it execute first? Reason briefly. "
        "Your last output line must be exactly `FINAL: <operation-label>`."
    )


def _planning_task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    nodes = _aliases(rng, 18, "sector-")
    actions = _aliases(rng, 24, "op-")
    start, goal, correct_mid = nodes[:3]
    edges: list[tuple[str, str, str]] = [
        (start, correct_mid, actions[0]),
        (correct_mid, goal, actions[1]),
    ]
    # Three genuine alternatives give a prompt-visible selection mediator but only
    # the shortest path's first operation is stored in the sealed authority.
    cursor = 3
    for branch, length in enumerate((3, 4, 5), 1):
        previous = start
        for step in range(length):
            target = goal if step == length - 1 else nodes[cursor]
            if step != length - 1:
                cursor += 1
            action = actions[1 + branch * 5 + step]
            edges.append((previous, target, action))
            previous = target
    rng.shuffle(edges)
    answer_path = _shortest_actions(start, goal, edges)
    if answer_path[0] != actions[0] or len(answer_path) != 2:
        raise RuntimeError("planning task lost its unique shortest path")
    first_options = [actions[0], actions[6], actions[11], actions[16]]
    rng.shuffle(first_options)
    task_id = f"cav1-{split}-planning-{index:02d}"
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": split,
        "family": "candidate_availability_planning",
        "profile": "candidate_selection_target",
        "prompt": _planning_prompt(start, goal, edges, first_options),
        "prompt_valid_labels": first_options,
        "maximum_new_tokens": MAXIMUM_NEW_TOKENS,
        "matched_features": {
            "answer_format": "operation_label",
            "first_operation_option_count": 4,
            "shortest_path_length": 2,
            "alternative_path_lengths": [3, 4, 5],
            "semantic_novelty_proxy": "opaque_seeded_aliases",
        },
    }
    authority = {"task_id": task_id, "family": public["family"], "answer": actions[0]}
    return public, authority


def _invariance_prompt(
    start: str,
    middle: str,
    goal: str,
    relation_a: str,
    relation_b: str,
    facts: Sequence[tuple[str, str, str]],
    options: Sequence[str],
) -> str:
    return (
        "Use only the relation facts. A fact `(x, r, y)` means relation r from x reaches y.\n"
        + "\n".join(f"({source}, {relation}, {target})" for source, relation, target in facts)
        + f"\nStart at {start}, follow {relation_a}, then {relation_b}. "
        + "The prompt-valid final-entity labels are: "
        + ", ".join(options)
        + ".\nReturn the final entity. Reason briefly. "
        "Your last output line must be exactly `FINAL: <entity-label>`."
    )


def _invariance_task(index: int, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    entities = _aliases(rng, 14, "entity-")
    relations = _aliases(rng, 5, "rel-")
    start, middle, goal = entities[:3]
    facts = [(start, relations[0], middle), (middle, relations[1], goal)]
    for offset in range(3, 13, 2):
        facts.append((entities[offset], relations[2 + (offset % 3)], entities[offset + 1]))
    rng.shuffle(facts)
    options = [goal, entities[4], entities[7], entities[10]]
    rng.shuffle(options)
    task_id = f"cav1-prospective-invariance-{index:02d}"
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": "prospective",
        "family": "candidate_selection_invariance",
        "profile": "unrelated_invariance",
        "prompt": _invariance_prompt(
            start, middle, goal, relations[0], relations[1], facts, options
        ),
        "prompt_valid_labels": options,
        "maximum_new_tokens": MAXIMUM_NEW_TOKENS,
        "matched_features": {
            "answer_format": "entity_label",
            "relation_hops": 2,
            "semantic_novelty_proxy": "opaque_seeded_aliases",
        },
    }
    authority = {"task_id": task_id, "family": public["family"], "answer": goal}
    return public, authority


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(TASK_SEED)
    public: list[Mapping[str, Any]] = []
    authority: list[Mapping[str, Any]] = []
    for index in range(DEVELOPMENT_TASK_COUNT):
        task, answer = _planning_task(index, "development", rng)
        public.append(task)
        authority.append(answer)
    for index in range(PROSPECTIVE_POOL_COUNT):
        task, answer = _planning_task(index, "prospective", rng)
        public.append(task)
        authority.append(answer)
    for index in range(INVARIANCE_TASK_COUNT):
        task, answer = _invariance_task(index, rng)
        public.append(task)
        authority.append(answer)
    if len(public) != DEVELOPMENT_TASK_COUNT + PROSPECTIVE_POOL_COUNT + INVARIANCE_TASK_COUNT:
        raise RuntimeError("candidate availability panel count mismatch")
    if len({row["task_id"] for row in public}) != len(public):
        raise RuntimeError("candidate availability task identifiers are not unique")
    return public, authority


def build_schedule(public: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []
    for model_key in MODEL_ORDER:
        for split in ("development", "prospective"):
            task_ids = sorted(
                str(row["task_id"]) for row in public if row["split"] == split
            )
            random.Random(derive_seed(model_key, split, "task_order")).shuffle(task_ids)
            for order_index, task_id in enumerate(task_ids):
                rows.append(
                    {
                        "model_key": model_key,
                        "split": split,
                        "task_id": task_id,
                        "task_order_index": order_index,
                        "candidate_seeds": [
                            derive_seed(model_key, task_id, "candidate", call)
                            for call in range(CANDIDATE_BANK_CALLS)
                        ],
                    }
                )
    return rows


def canonical_candidate(candidate: str) -> str:
    return re.sub(r"\s+", "", candidate).casefold().strip("`*_.,;:")


def prompt_valid_candidate(task: Mapping[str, Any], candidate: str) -> str | None:
    labels = {
        canonical_candidate(str(label)): str(label)
        for label in task["prompt_valid_labels"]
    }
    return labels.get(canonical_candidate(candidate))


def candidate_bank_gate(
    task: Mapping[str, Any], calls: Sequence[Mapping[str, Any]]
) -> Mapping[str, Any]:
    """Evaluate a gold-blind mediator gate and choose an eligible candidate.

    The first generated candidate is the equal-generation control.  The treatment
    only changes the answer-blind selector over the same bank; it receives no
    extra calls, different prompt, answer, or verifier signal.
    """

    receipt_rows = [call["candidate_receipt"] for call in calls]
    normalized: list[str | None] = []
    for receipt in receipt_rows:
        if bool(receipt.get("delivered")):
            normalized.append(prompt_valid_candidate(task, str(receipt.get("candidate", ""))))
        else:
            normalized.append(None)
    valid = [value for value in normalized if value is not None]
    counts = Counter(valid)
    ranked = sorted(counts, key=lambda value: (-counts[value], canonical_candidate(value)))
    top_support = counts[ranked[0]] if ranked else 0
    runner_up_support = counts[ranked[1]] if len(ranked) > 1 else 0
    control = normalized[0] if normalized else None
    treatment = ranked[0] if ranked else None
    delivery_passed = len(calls) == CANDIDATE_BANK_CALLS and len(valid) >= 3
    diversity_passed = len(counts) >= 2
    ordering_passed = len(ranked) >= 2 and top_support > runner_up_support
    control_passed = control is not None
    selection_changed = control_passed and treatment is not None and treatment != control
    eligible = all(
        (delivery_passed, diversity_passed, ordering_passed, control_passed, selection_changed)
    )
    return {
        "expected_calls": CANDIDATE_BANK_CALLS,
        "completed_calls": len(calls),
        "prompt_valid_candidate_count": len(valid),
        "prompt_valid_unique_count": len(counts),
        "candidate_support": {value: counts[value] for value in ranked},
        "top_support": top_support,
        "runner_up_support": runner_up_support,
        "delivery_passed": delivery_passed,
        "availability_passed": delivery_passed and diversity_passed,
        "ordering_signal_passed": ordering_passed,
        "control_delivery_passed": control_passed,
        "selection_changed": selection_changed,
        "eligible_for_causal_score": eligible,
        "abstention_reason": (
            None
            if eligible
            else (
                "candidate_bank_delivery_failure"
                if not delivery_passed
                else "candidate_availability_failure"
                if not diversity_passed
                else "nondegenerate_ordering_failure"
                if not ordering_passed
                else "first_candidate_delivery_failure"
                if not control_passed
                else "selector_did_not_change_candidate"
            )
        ),
        "control_candidate": control,
        "treatment_candidate": treatment,
        "selector": "prompt_valid_majority_then_canonical_label",
        "selection_used_gold_or_correctness": False,
    }


def invariance_selection(task: Mapping[str, Any], calls: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    """A descriptive, pre-specified non-target-task sensitivity comparator."""

    gate = candidate_bank_gate(task, calls)
    control = gate["control_candidate"]
    # If the target mediator is unavailable on an invariance item, retain the
    # first valid candidate; this avoids manufacturing an intervention effect.
    treatment = gate["treatment_candidate"] if gate["ordering_signal_passed"] else control
    return {
        **gate,
        "treatment_candidate": treatment,
        "invariance_pair_delivered": control is not None and treatment is not None,
        "invariance_fallback": "first_prompt_valid_candidate_when_ordering_degenerate",
    }


def development_qualified(
    development_rows: Sequence[Mapping[str, Any]], authority: Mapping[str, Mapping[str, Any]]
) -> Mapping[str, Any]:
    """Score only development controls and issue a one-way release decision."""

    expected = DEVELOPMENT_TASK_COUNT
    delivered = [row for row in development_rows if row["control_candidate"] is not None]
    correct = sum(
        score_candidate(authority[str(row["task_id"])], str(row["control_candidate"]))
        for row in delivered
    )
    availability = sum(bool(row["availability_passed"]) for row in development_rows)
    # This rejects only complete/near-complete floors and ceilings, as well as
    # pervasive format failure.  It does not tune task selection by outcome.
    checks = {
        "expected_task_count": len(development_rows) == expected,
        "control_delivery_at_least_75pct": len(delivered) >= 12,
        "control_correctness_not_floor": correct >= 2,
        "control_correctness_not_ceiling": correct <= 14,
        "availability_on_at_least_25pct": availability >= 4,
    }
    return {
        "development_task_count": len(development_rows),
        "control_delivered_count": len(delivered),
        "control_correct_count": correct,
        "availability_passed_count": availability,
        "checks": checks,
        "qualified": all(checks.values()),
        "qualification_uses_only_development_authority": True,
        "prospective_authority_loaded": False,
    }


def score_candidate(authority: Mapping[str, Any], candidate: str) -> bool:
    return canonical_candidate(candidate) == canonical_candidate(str(authority["answer"]))


def conservative_difference_interval(
    treatment_correct: int, control_correct: int, n: int
) -> tuple[float, float]:
    """Boundary-aware Wilson sensitivity interval for a paired contrast.

    It is deliberately conservative: Wilson intervals are formed for each
    marginal accuracy, then subtracted.  Unlike a normal interval on paired
    differences, complete agreement never collapses to [0, 0].
    """

    if n <= 0:
        return (float("nan"), float("nan"))

    def wilson(successes: int) -> tuple[float, float]:
        z = 1.959963984540054
        proportion = successes / n
        denominator = 1.0 + z * z / n
        centre = (proportion + z * z / (2 * n)) / denominator
        radius = z * ((proportion * (1 - proportion) / n + z * z / (4 * n * n)) ** 0.5) / denominator
        return (max(0.0, centre - radius), min(1.0, centre + radius))

    control_low, control_high = wilson(control_correct)
    treatment_low, treatment_high = wilson(treatment_correct)
    return (treatment_low - control_high, treatment_high - control_low)
