"""Answer-blind factorial fixtures for closure and policy-collision discovery."""
from __future__ import annotations

import hashlib
import random
from typing import Any, Mapping

from scientist.core.artifacts import content_digest


VERSION = "cognitive-repairability-closure-collision-fixtures-v1"
MODEL_KEYS = ("qwen3_1p7b", "qwen2p5_3b")
CANDIDATES = tuple(str(value) for value in range(5))
STRUCTURAL_PAIRS = 12
REPLICAS = 2
COMPOSITION_CONDITIONS = tuple(
    (closure, shadow)
    for closure in ("left_grouped", "right_grouped")
    for shadow in ("filler", "compatible", "incompatible")
)


_NAMES = (
    ("KAV", "LER", "MOR", "NIV"),
    ("PEL", "QAR", "RUV", "SEN"),
    ("TOV", "WEX", "YAL", "ZIR"),
    ("BEM", "COR", "DAX", "FEN"),
    ("GIL", "HOR", "JUP", "KEL"),
    ("LUM", "MEV", "NOR", "PAX"),
    ("QIN", "RAS", "SUL", "TEV"),
    ("UMA", "VOR", "WIL", "XEN"),
    ("YOR", "ZAL", "BRI", "CEM"),
    ("DOR", "EVI", "FAL", "GEM"),
    ("HIL", "IVO", "JAR", "KOR"),
    ("LIS", "MAV", "NER", "ORL"),
    ("PIR", "QUV", "REL", "SOR"),
    ("TAR", "ULV", "VES", "WOR"),
    ("XIL", "YEV", "ZOR", "BAL"),
    ("CIR", "DEL", "ERI", "FOV"),
    ("GAL", "HER", "ION", "JEV"),
    ("KIR", "LOV", "MER", "NAL"),
    ("OZI", "PER", "QEL", "RIN"),
    ("SAL", "TIR", "URV", "VEL"),
    ("WEN", "XAR", "YIL", "ZEV"),
    ("BOR", "CAL", "DUR", "ELI"),
    ("FIR", "GOR", "HAL", "IRV"),
    ("JOL", "KAR", "LEV", "MIR"),
)


def _parameters(structure_id: int) -> Mapping[str, int]:
    rng = random.Random(9_505_100 + structure_id)
    return {
        "input": rng.randrange(5),
        "a": rng.randrange(1, 5),
        "b": rng.randrange(1, 5),
        "c": rng.randrange(1, 5),
    }


def _shadow(
    *, family: str, shadow: str, middle: str, auxiliary: str, parameters: Mapping[str, int]
) -> str:
    b = parameters["b"]
    incompatible_b = b % 4 + 1
    name = auxiliary if shadow == "filler" else middle
    value = b if shadow != "incompatible" else incompatible_b
    if family == "affine_chain":
        rule = f"{name}(t) = ({value}*t) mod 5"
    else:
        rule = f"{name}(PAIR(u,v)) = PAIR(v,(u+{value}) mod 5)"
    return (
        "ARCHIVED EXAMPLE OUTSIDE THE ACTIVE SCOPE: "
        f"{rule}. The archived example is inactive and must not be applied."
    )


def _definitions(
    family: str, first: str, middle: str, last: str, parameters: Mapping[str, int]
) -> str:
    a, b, c = parameters["a"], parameters["b"], parameters["c"]
    if family == "affine_chain":
        return (
            f"Active signatures: {first}: residue->residue; {middle}: residue->residue; "
            f"{last}: residue->residue. Active rules: {first}(t)=(t+{a}) mod 5; "
            f"{middle}(t)=({b}*t) mod 5; {last}(t)=(t+{c}) mod 5."
        )
    return (
        f"Active signatures: {first}: residue->packet; {middle}: packet->packet; "
        f"{last}: packet->residue. Active rules: {first}(t)=PAIR(t,(t+{a}) mod 5); "
        f"{middle}(PAIR(u,v))=PAIR(v,(u+{b}) mod 5); "
        f"{last}(PAIR(u,v))=(u+{c}*v) mod 5."
    )


def _composition_expression(first: str, middle: str, last: str, closure: str) -> str:
    if closure == "left_grouped":
        return f"COMPOSE(COMPOSE({last},{middle}),{first})"
    return f"COMPOSE({last},COMPOSE({middle},{first}))"


def _composition_prompt(
    *,
    unit_id: str,
    family: str,
    closure: str,
    shadow: str,
    names: tuple[str, str, str, str],
    parameters: Mapping[str, int],
) -> str:
    first, middle, last, auxiliary = names
    expression = _composition_expression(first, middle, last, closure)
    return (
        f"Independent distributional probe {unit_id}.\n"
        "COMPOSE(f,g)(x) means f(g(x)); function composition is associative when signatures match.\n"
        + _shadow(
            family=family,
            shadow=shadow,
            middle=middle,
            auxiliary=auxiliary,
            parameters=parameters,
        )
        + "\nACTIVE SCOPE ONLY. "
        + _definitions(family, first, middle, last, parameters)
        + f"\nApply {expression} to active input {parameters['input']}. Return only the final residue.\nFinal residue:"
    )


def _primitive_prompt(
    *,
    unit_id: str,
    family: str,
    surface: int,
    names: tuple[str, str, str, str],
    parameters: Mapping[str, int],
) -> str:
    first, _, last, _ = names
    if family == "affine_chain":
        rule = f"{first}(t)=(t+{parameters['a']}) mod 5"
        query = f"{first}({parameters['input']})"
    else:
        rule = f"{last}(PAIR(u,v))=(u+{parameters['c']}*v) mod 5"
        query = f"{last}(PAIR({parameters['input']},{parameters['a']}))"
    if surface == 0:
        body = f"Active primitive rule: {rule}. Evaluate {query}."
    else:
        body = f"Within the active primitive scope, use {rule}. The requested value is {query}."
    return (
        f"Independent primitive probe {unit_id}.\n{body} "
        "Return only the resulting residue.\nFinal residue:"
    )


def build_fixtures() -> list[Mapping[str, Any]]:
    fixtures: list[Mapping[str, Any]] = []
    for structure_id in range(STRUCTURAL_PAIRS):
        family = "affine_chain" if structure_id < STRUCTURAL_PAIRS // 2 else "typed_packet"
        parameters = _parameters(structure_id)
        for replica in range(REPLICAS):
            names = _NAMES[structure_id * REPLICAS + replica]
            unit_id = f"ccdist_{family}_{structure_id:02d}_r{replica}"
            composition = [
                {
                    "condition_id": f"{closure}__{shadow}",
                    "closure_form": closure,
                    "shadow_kind": shadow,
                    "prompt": _composition_prompt(
                        unit_id=unit_id,
                        family=family,
                        closure=closure,
                        shadow=shadow,
                        names=names,
                        parameters=parameters,
                    ),
                }
                for closure, shadow in COMPOSITION_CONDITIONS
            ]
            primitive = [
                {
                    "condition_id": f"primitive_surface_{surface}",
                    "primitive_surface": surface,
                    "prompt": _primitive_prompt(
                        unit_id=unit_id,
                        family=family,
                        surface=surface,
                        names=names,
                        parameters=parameters,
                    ),
                }
                for surface in range(2)
            ]
            body = {
                "version": VERSION,
                "unit_id": unit_id,
                "structural_pair_id": f"ccdist_pair_{structure_id:02d}",
                "structure_id": structure_id,
                "replica": replica,
                "family": family,
                "operator_names": list(names),
                "public_parameters": dict(parameters),
                "candidate_completions": [f" {candidate}" for candidate in CANDIDATES],
                "composition_conditions": composition,
                "primitive_conditions": primitive,
                "reference_answer_present": False,
            }
            fixtures.append({**body, "fixture_id": content_digest(body)})
    return fixtures


def build_schedule(fixtures: list[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []
    index = 0
    for model_key in MODEL_KEYS:
        for fixture in fixtures:
            conditions = [
                *(dict(condition, probe_kind="composition") for condition in fixture["composition_conditions"]),
                *(dict(condition, probe_kind="primitive") for condition in fixture["primitive_conditions"]),
            ]
            for condition in conditions:
                for candidate in CANDIDATES:
                    body = {
                        "version": VERSION,
                        "schedule_index": index,
                        "model_key": model_key,
                        "fixture_id": fixture["fixture_id"],
                        "unit_id": fixture["unit_id"],
                        "structural_pair_id": fixture["structural_pair_id"],
                        "replica": fixture["replica"],
                        "family": fixture["family"],
                        "probe_kind": condition["probe_kind"],
                        "condition_id": condition["condition_id"],
                        "closure_form": condition.get("closure_form"),
                        "shadow_kind": condition.get("shadow_kind"),
                        "primitive_surface": condition.get("primitive_surface"),
                        "prompt": condition["prompt"],
                        "candidate": candidate,
                        "candidate_completion": f" {candidate}",
                        "reference_answer_present": False,
                    }
                    rows.append({**body, "job_id": content_digest(body)})
                    index += 1
    return rows
