"""Fresh-panel successor to v14 using the direct-token generation runtime."""
from __future__ import annotations

import random
from typing import Any, Mapping

from scientist.domains.cognitive_core import repairability_compiler_lora_v14 as v14
from scientist.domains.cognitive_core import repairability_compiler_lora_v7 as v7

VERSION = "cognitive-repairability-compiler-lora-v15"
MODEL_KEY = v7.MODEL_KEY
PROSPECTIVE_COUNT = v7.PROSPECTIVE_COUNT
TASK_SEED = 860_415_100
TRAIN_STEPS = v14.TRAIN_STEPS
TRAIN_PARTITION_SIZE = v14.TRAIN_PARTITION_SIZE
TRAIN_BATCH_SIZE = v14.TRAIN_BATCH_SIZE
UPDATES_PER_PARTITION = v14.UPDATES_PER_PARTITION
MAX_SEQ_LENGTH = v14.MAX_SEQ_LENGTH
digest, file_sha256, jsonl, read_rows, execute_canonical = v7.digest, v7.file_sha256, v7.jsonl, v7.read_rows, v7.execute_canonical


def _task(index: int, split: str, style: int, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    task, authority = v14._task(index, split, style, rng)
    task_id = str(task["task_id"]).replace("v14-", "v15-")
    return {**task, "version": VERSION, "task_id": task_id}, {**authority, "task_id": task_id}


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(TASK_SEED)
    train: list[Mapping[str, Any]] = []
    preflight: list[Mapping[str, Any]] = []
    public: list[Mapping[str, Any]] = []
    authority: list[Mapping[str, Any]] = []
    for index in range(v7.TRAINING_COUNT):
        task, auth = _task(index, "adaptation", index % 2, rng)
        train.append({"task_id": task["task_id"], "messages": [{"role": "system", "content": "Compile the described program into the exact canonical state."}, {"role": "user", "content": task["compiler_prompt"]}, {"role": "assistant", "content": auth["canonical"]}], "sham_messages": [{"role": "system", "content": "Copy the requested canonical output format."}, {"role": "user", "content": task["compiler_prompt"]}, {"role": "assistant", "content": "INITIAL=0\nOPS=ADD:0|MUL:1|SUB:0|ADD:0"}]})
    for index in range(v7.PREFLIGHT_COUNT):
        task, _ = _task(index, "preflight", 2, rng)
        preflight.append(task)
    for index in range(v7.DEVELOPMENT_COUNT):
        task, auth = _task(index, "development", 2, rng)
        public.append(task); authority.append(auth)
    for index in range(v7.PROSPECTIVE_COUNT):
        task, auth = _task(index, "prospective", 3 + index % 2, rng)
        public.append(task); authority.append(auth)
    if len(train) != 64 or len(preflight) != 8 or len(public) != 48 or len(authority) != 48: raise RuntimeError("v15 panel mismatch")
    return train, preflight, public, authority


def training_slice(step: int) -> tuple[int, int]:
    if step not in range(TRAIN_STEPS): raise ValueError("training step out of range")
    return step * TRAIN_PARTITION_SIZE, (step + 1) * TRAIN_PARTITION_SIZE
