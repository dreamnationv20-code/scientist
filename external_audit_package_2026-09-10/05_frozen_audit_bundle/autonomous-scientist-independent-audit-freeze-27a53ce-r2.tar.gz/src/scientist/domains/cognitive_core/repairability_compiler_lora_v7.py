"""Held-out state-compilation task for the v7 parameter contrast."""
from __future__ import annotations

import hashlib
import random
import re
from typing import Any, Mapping

from scientist.domains.cognitive_core.repairability_candidate_availability_v1 import digest, file_sha256, jsonl, read_rows

VERSION = "cognitive-repairability-compiler-lora-v7"
MODEL_KEY = "qwen2p5_3b"
TASK_SEED = 860_407_100
TRAINING_COUNT = 64
PREFLIGHT_COUNT = 8
DEVELOPMENT_COUNT = 16
PROSPECTIVE_COUNT = 32
CHOICE_LABELS = ("A", "B", "C", "D")
STEPS = 4
_INITIAL = re.compile(r"INITIAL\s*=\s*(-?\d+)")
_OPS = re.compile(r"OPS\s*=\s*((?:(?:ADD|SUB|MUL):-?\d+\|?)+)")

def _spec(rng: random.Random) -> tuple[int, tuple[tuple[str, int], ...]]:
    start = rng.randint(4, 17)
    ops = (("ADD", rng.randint(5, 19)), ("MUL", rng.choice((2, 3, 4))), ("SUB", rng.randint(3, 13)), ("ADD", rng.randint(7, 23)))
    return start, ops

def _value(start: int, ops: tuple[tuple[str, int], ...]) -> int:
    result = start
    for op, operand in ops: result = result + operand if op == "ADD" else result - operand if op == "SUB" else result * operand
    return result

def canonical(start: int, ops: tuple[tuple[str, int], ...]) -> str:
    return "INITIAL=" + str(start) + "\nOPS=" + "|".join(f"{op}:{value}" for op, value in ops)

def _surface(style: int, start: int, ops: tuple[tuple[str, int], ...]) -> str:
    words = {"ADD": ("add", "increase by", "raise it by", "plus", "add the amount"), "SUB": ("subtract", "decrease by", "lower it by", "minus", "remove the amount"), "MUL": ("multiply by", "scale by", "times", "multiply it by", "scale it by")}
    intro = ("Start the register at ", "Initialize the running quantity to ", "Set the counter initially to ", "Let the accumulator begin at ", "A quantity has initial value ")[style]
    clauses = []
    for index, (op, operand) in enumerate(ops, 1):
        phrase = words[op][style]
        clauses.append((f"Step {index}: {phrase} {operand}.", f"Then {phrase} {operand}.", f"After that, {phrase} {operand}.", f"Next, {phrase} {operand}.", f"Operation {index} is {phrase} {operand}.")[style])
    return intro + str(start) + ". " + " ".join(clauses)

def compiler_prompt(surface: str, mapping: Mapping[str, str]) -> str:
    choices = "\n".join(f"{label}: {mapping[label]}" for label in CHOICE_LABELS)
    return "Translate the visible accumulator description into the required canonical state. Do not calculate or select an answer. Output exactly two lines: INITIAL=<integer> and OPS=ADD:<integer>|MUL:<integer>|SUB:<integer>|ADD:<integer>.\n\nDESCRIPTION:\n" + surface + "\n\nThe eventual answer options are public but must not be used in the canonical state:\n" + choices

def _task(index: int, split: str, style: int, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    start, ops = _spec(rng); result = _value(start, ops)
    distractors = {result + delta for delta in (-17, -9, 11, 23) if result + delta != result}
    options = [str(result), *(str(value) for value in sorted(distractors)[:3])]; rng.shuffle(options)
    mapping = dict(zip(CHOICE_LABELS, options, strict=True)); answer = next(label for label, value in mapping.items() if value == str(result))
    surface = _surface(style, start, ops); task_id = f"v7-{split}-compiler-{index:03d}"
    public = {"version": VERSION, "task_id": task_id, "split": split, "family": "paraphrased_accumulator_compilation", "surface_style": style, "surface": surface, "compiler_prompt": compiler_prompt(surface, mapping), "choice_mapping_prompt_visible": mapping, "prompt_valid_labels": list(CHOICE_LABELS), "canonical_schema": "INITIAL=<int> then OPS=ADD:<int>|MUL:<int>|SUB:<int>|ADD:<int>", "tool_reads": "model-generated canonical state plus public choice mapping only"}
    return public, {"task_id": task_id, "family": public["family"], "answer": answer, "canonical": canonical(start, ops)}

def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(TASK_SEED); train=[]; preflight=[]; public=[]; authority=[]
    for index in range(TRAINING_COUNT):
        task, auth = _task(index, "adaptation", index % 2, rng)
        train.append({"task_id": task["task_id"], "messages": [{"role": "system", "content": "Compile the described program into the exact canonical state."}, {"role": "user", "content": task["compiler_prompt"]}, {"role": "assistant", "content": auth["canonical"]}], "sham_messages": [{"role": "system", "content": "Copy the requested canonical output format."}, {"role": "user", "content": task["compiler_prompt"]}, {"role": "assistant", "content": "INITIAL=0\nOPS=ADD:0|MUL:1|SUB:0|ADD:0"}]})
    for index in range(PREFLIGHT_COUNT):
        task,_ = _task(index, "preflight", 2, rng); preflight.append(task)
    for index in range(DEVELOPMENT_COUNT):
        task,auth = _task(index, "development", 2, rng); public.append(task); authority.append(auth)
    for index in range(PROSPECTIVE_COUNT):
        task,auth = _task(index, "prospective", 3 + index % 2, rng); public.append(task); authority.append(auth)
    if len(train)!=64 or len(preflight)!=8 or len(public)!=48 or len(authority)!=48: raise RuntimeError("v7 panel mismatch")
    return train, preflight, public, authority

def execute_canonical(text: str, mapping: Mapping[str, str]) -> Mapping[str, Any]:
    initial = _INITIAL.search(text); operations = _OPS.search(text)
    if initial is None or operations is None: return {"delivered": False, "candidate": None, "reason": "canonical_schema_parse_failure", "uses_evaluation_authority": False, "tool_contract_satisfied": False}
    pieces = operations[1].split("|")
    if len(pieces)!=STEPS: return {"delivered": False, "candidate": None, "reason": "canonical_step_count_failure", "uses_evaluation_authority": False, "tool_contract_satisfied": False}
    try: parsed = tuple((piece.split(":",1)[0],int(piece.split(":",1)[1])) for piece in pieces)
    except (IndexError, ValueError): return {"delivered": False, "candidate": None, "reason": "canonical_operand_parse_failure", "uses_evaluation_authority": False, "tool_contract_satisfied": False}
    if tuple(op for op,_ in parsed)!=("ADD","MUL","SUB","ADD"): return {"delivered": False, "candidate": None, "reason": "canonical_operation_schema_failure", "uses_evaluation_authority": False, "tool_contract_satisfied": False}
    result=_value(int(initial[1]), parsed); inverse={str(value):str(label) for label,value in mapping.items()}; candidate=inverse.get(str(result))
    return {"delivered": candidate is not None, "candidate": candidate, "reason": None if candidate is not None else "tool_result_not_in_public_choices", "uses_evaluation_authority": False, "tool_contract_satisfied": candidate is not None}
