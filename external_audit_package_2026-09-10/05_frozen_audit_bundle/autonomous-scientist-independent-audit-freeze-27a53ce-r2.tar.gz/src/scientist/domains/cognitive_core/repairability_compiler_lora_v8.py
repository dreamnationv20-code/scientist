"""Fresh engineering successor to v7; no v7 execution is reopened."""
from __future__ import annotations
from typing import Any, Mapping
from scientist.domains.cognitive_core import repairability_compiler_lora_v7 as v7

VERSION = "cognitive-repairability-compiler-lora-v8"
MODEL_KEY = v7.MODEL_KEY
PROSPECTIVE_COUNT = v7.PROSPECTIVE_COUNT
digest, file_sha256, jsonl, read_rows, execute_canonical = v7.digest, v7.file_sha256, v7.jsonl, v7.read_rows, v7.execute_canonical

def _replace(row: Mapping[str, Any]) -> Mapping[str, Any]:
    task_id = str(row.get("task_id", "")).replace("v7-", "v8-")
    return {**row, "version": VERSION, **({"task_id": task_id} if "task_id" in row else {})}

def build_panel():
    training, preflight, public, authority = v7.build_panel()
    return ([_replace(row) for row in training], [_replace(row) for row in preflight], [_replace(row) for row in public], [_replace(row) for row in authority])
