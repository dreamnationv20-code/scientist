"""Delivery-qualified candidate-selection study using an answer-blind choice decoder.

Free-form decoding in the preceding program consumed its output budget before a
machine-readable answer was emitted.  This successor is a new protocol: it
samples a single token from only the prompt-visible A/B/C/D choice labels.  The
constraint governs format and candidate set, never correctness or a gold answer.
"""

from __future__ import annotations

import random
import re
from pathlib import Path
from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.repairability_candidate_availability_v1 import (
    FORGE_HYPOTHESIS_ID,
    FORGE_PROPOSAL_ID,
    candidate_bank_gate,
    conservative_difference_interval,
    development_qualified,
    digest,
    file_sha256,
    invariance_selection,
    jsonl,
    read_rows,
    score_candidate,
)
from scientist.domains.cognitive_core.repairability_candidate_availability_v1 import (
    _invariance_task as _source_invariance_task,
)
from scientist.domains.cognitive_core.repairability_candidate_availability_v1 import (
    _planning_task as _source_planning_task,
)


VERSION = "cognitive-repairability-constrained-choice-v2"
MODEL_ORDER = ("qwen3_1p7b", "qwen2p5_3b")
TASK_SEED = 860_402_100
SCHEDULE_SEED = 860_402_200
PREFLIGHT_TASK_COUNT = 8
PREFLIGHT_CALLS = 3
DEVELOPMENT_TASK_COUNT = 16
PROSPECTIVE_POOL_COUNT = 32
INVARIANCE_TASK_COUNT = 8
SELECTED_PROSPECTIVE_COUNT = 12
CANDIDATE_BANK_CALLS = 5
CHOICE_LABELS = ("A", "B", "C", "D")
TEMPERATURE = 0.70
MODEL_HOUR_CAPS = {"qwen3_1p7b": 0.55, "qwen2p5_3b": 0.85}
MAXIMUM_TOTAL_HOURS = 1.40


def derive_seed(*labels: object) -> int:
    payload = "\0".join(str(value) for value in (SCHEDULE_SEED, *labels))
    return int.from_bytes(__import__("hashlib").sha256(payload.encode("utf-8")).digest()[:4], "big")


def _choice_prompt(base_prompt: str, mapping: Mapping[str, str], noun: str) -> str:
    prefix = base_prompt.split("Which operation", 1)[0].split("Return the final entity", 1)[0]
    options = "\n".join(f"{label}: {mapping[label]}" for label in CHOICE_LABELS)
    return (
        prefix.rstrip()
        + "\n\nChoose the correct " + noun + " option.\n"
        + options
        + "\nOutput only one option letter. Do not explain.\nFINAL: "
    )


def _planning_task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    source_public, source_authority = _source_planning_task(index, split, rng)
    operation_labels = list(source_public["prompt_valid_labels"])
    rng.shuffle(operation_labels)
    choices = dict(zip(CHOICE_LABELS, operation_labels, strict=True))
    answer = next(label for label, operation in choices.items() if operation == source_authority["answer"])
    task_id = str(source_public["task_id"]).replace("cav1-", "ccv2-")
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": split,
        "family": "constrained_choice_planning",
        "profile": "candidate_selection_target",
        "prompt": _choice_prompt(str(source_public["prompt"]), choices, "first-operation"),
        "prompt_valid_labels": list(CHOICE_LABELS),
        "choice_mapping_prompt_visible": choices,
        "matched_features": {**source_public["matched_features"], "choice_count": 4, "decoder": "single_token_choice"},
    }
    return public, {"task_id": task_id, "family": public["family"], "answer": answer}


def _invariance_task(index: int, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    source_public, source_authority = _source_invariance_task(index, rng)
    entity_labels = list(source_public["prompt_valid_labels"])
    rng.shuffle(entity_labels)
    choices = dict(zip(CHOICE_LABELS, entity_labels, strict=True))
    answer = next(label for label, entity in choices.items() if entity == source_authority["answer"])
    task_id = str(source_public["task_id"]).replace("cav1-", "ccv2-")
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": "prospective",
        "family": "constrained_choice_invariance",
        "profile": "unrelated_invariance",
        "prompt": _choice_prompt(str(source_public["prompt"]), choices, "final-entity"),
        "prompt_valid_labels": list(CHOICE_LABELS),
        "choice_mapping_prompt_visible": choices,
        "matched_features": {**source_public["matched_features"], "choice_count": 4, "decoder": "single_token_choice"},
    }
    return public, {"task_id": task_id, "family": public["family"], "answer": answer}


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(TASK_SEED)
    preflight: list[Mapping[str, Any]] = []
    public: list[Mapping[str, Any]] = []
    authority: list[Mapping[str, Any]] = []
    for index in range(PREFLIGHT_TASK_COUNT):
        task, _ = _planning_task(index, "decoder_preflight", rng)
        preflight.append({**task, "profile": "decoder_delivery_preflight"})
    for index in range(DEVELOPMENT_TASK_COUNT):
        task, answer = _planning_task(index, "development", rng)
        public.append(task)
        authority.append(answer)
    for index in range(PROSPECTIVE_POOL_COUNT):
        task, answer = _planning_task(index, "prospective", rng)
        public.append(task)
        authority.append(answer)
    for index in range(INVARIANCE_TASK_COUNT):
        task, answer = _invariance_task(index, rng)
        public.append(task)
        authority.append(answer)
    if len(preflight) != PREFLIGHT_TASK_COUNT or len(public) != 56 or len(authority) != 56:
        raise RuntimeError("constrained-choice panel count mismatch")
    task_ids = [str(row["task_id"]) for row in (*preflight, *public)]
    if len(task_ids) != len(set(task_ids)):
        raise RuntimeError("constrained-choice task identifiers are not unique")
    return preflight, public, authority


def build_schedule(preflight: Sequence[Mapping[str, Any]], public: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []
    for model_key in MODEL_ORDER:
        for split, tasks, calls in (
            ("decoder_preflight", preflight, PREFLIGHT_CALLS),
            ("development", [row for row in public if row["split"] == "development"], CANDIDATE_BANK_CALLS),
            ("prospective", [row for row in public if row["split"] == "prospective"], CANDIDATE_BANK_CALLS),
        ):
            task_ids = sorted(str(row["task_id"]) for row in tasks)
            random.Random(derive_seed(model_key, split, "order")).shuffle(task_ids)
            for task_order_index, task_id in enumerate(task_ids):
                rows.append(
                    {
                        "model_key": model_key,
                        "split": split,
                        "task_id": task_id,
                        "task_order_index": task_order_index,
                        "choice_seeds": [derive_seed(model_key, task_id, "choice", call) for call in range(calls)],
                    }
                )
    return rows


def choice_token_ids(tokenizer: Any) -> Mapping[str, int]:
    """Return the verified single-token realization for each public choice label."""
    values: dict[str, int] = {}
    for label in CHOICE_LABELS:
        ids = tokenizer.encode(label, add_special_tokens=False)
        if len(ids) != 1:
            raise RuntimeError(f"choice label is not a single token: {label}")
        values[label] = int(ids[0])
    if len(set(values.values())) != len(CHOICE_LABELS):
        raise RuntimeError("choice labels do not map to distinct decoder tokens")
    return values


def choice_receipt(token_id: int, token_ids: Mapping[str, int]) -> Mapping[str, Any]:
    reverse = {value: key for key, value in token_ids.items()}
    candidate = reverse.get(int(token_id), "")
    return {
        "candidate": candidate,
        "method": "answer_blind_single_token_choice_constraint",
        "delivered": bool(candidate),
        "token_id": int(token_id),
    }


def preflight_passed(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    expected = PREFLIGHT_TASK_COUNT * PREFLIGHT_CALLS
    delivered = sum(int(row["delivered_calls"]) for row in rows)
    calls = sum(int(row["completed_calls"]) for row in rows)
    valid = all(bool(row["all_candidates_prompt_valid"]) for row in rows)
    return {
        "expected_calls": expected,
        "completed_calls": calls,
        "delivered_calls": delivered,
        "all_candidates_prompt_valid": valid,
        "qualified": calls == expected and delivered == expected and valid,
        "uses_no_evaluation_authority": True,
    }


def canonical_candidate(candidate: str) -> str:
    return re.sub(r"\s+", "", candidate).casefold()
