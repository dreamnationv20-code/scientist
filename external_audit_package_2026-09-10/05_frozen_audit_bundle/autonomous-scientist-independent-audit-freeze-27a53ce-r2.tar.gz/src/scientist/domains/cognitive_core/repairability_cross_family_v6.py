"""Cross-family, answer-blind replication of the v5 repairability contrast."""

from __future__ import annotations

import hashlib
import random
import re
from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.repairability_candidate_availability_v1 import (
    _aliases, digest, file_sha256, jsonl, read_rows,
)
from scientist.domains.cognitive_core.repairability_verified_search_v5 import (
    _v5_task as _path_source_task,
    canonical_state as _path_state,
    verified_search_tool as _path_tool,
)


VERSION = "cognitive-repairability-cross-family-v6"
MODEL_ORDER = ("qwen3_1p7b", "qwen2p5_3b")
FAMILIES = ("shortest_path", "relation_composition", "accumulator_program")
TASK_SEED = 860_406_100
SCHEDULE_SEED = 860_406_200
PREFLIGHT_PER_FAMILY = 4
DEVELOPMENT_PER_FAMILY = 12
PROSPECTIVE_PER_FAMILY = 24
REASONING_MAX_TOKENS = 192
MODEL_HOUR_CAPS = {"qwen3_1p7b": 1.60, "qwen2p5_3b": 2.40}
MAXIMUM_TOTAL_HOURS = 4.20
CHOICE_LABELS = ("A", "B", "C", "D")

_REL_FACT = re.compile(r"^Relation (?P<relation>rel-\d+) maps (?P<source>entity-\d+) to (?P<target>entity-\d+)\.$", re.MULTILINE)
_REL_QUERY = re.compile(r"Begin at (?P<start>entity-\d+) and apply, in order: (?P<relations>(?:rel-\d+)(?:, rel-\d+)*)\.")
_ACC_START = re.compile(r"^Initial accumulator: (?P<value>-?\d+)\.$", re.MULTILINE)
_ACC_STEP = re.compile(r"^Step \d+: (?P<op>ADD|SUBTRACT|MULTIPLY) (?P<value>-?\d+)\.$", re.MULTILINE)


def derive_seed(*labels: object) -> int:
    payload = "\0".join(str(value) for value in (SCHEDULE_SEED, *labels))
    return int.from_bytes(hashlib.sha256(payload.encode("utf-8")).digest()[:4], "big")


def _choice_prompt(context: str, mapping: Mapping[str, str], noun: str) -> str:
    choices = "\n".join(f"{label}: {mapping[label]}" for label in CHOICE_LABELS)
    return context.rstrip() + f"\n\nChoose the correct {noun} option.\n" + choices + "\nOutput only one option letter. Do not explain.\nFINAL: "


def _reasoning_prompt(prompt: str, description: str) -> str:
    context = prompt.split("\n\nChoose the correct", 1)[0]
    return context + "\n\nWork through the visible structured task carefully. This is a private scratchpad for a later constrained answer step. " + description + " Do not use information outside the prompt."


def _path_task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    source, authority = _path_source_task(index, split, rng)
    task_id = f"v6-{split}-shortest-path-{index:02d}"
    task = {**source, "version": VERSION, "task_id": task_id, "family": "shortest_path", "profile": "cross_family_target"}
    return task, {**authority, "task_id": task_id, "family": "shortest_path"}


def _relation_task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    entities = _aliases(rng, 22, "entity-")
    relations = _aliases(rng, 8, "rel-")
    start, *chain, goal = entities[:6]
    ordered_relations = relations[:5]
    facts: list[tuple[str, str, str]] = []
    current = start
    for relation, target in zip(ordered_relations, [*chain, goal], strict=True):
        facts.append((relation, current, target)); current = target
    for offset in range(7, 19, 2):
        facts.append((relations[(offset + 2) % len(relations)], entities[offset], entities[offset + 1]))
    rng.shuffle(facts)
    options = [goal, entities[6], entities[9], entities[12]]
    rng.shuffle(options)
    mapping = dict(zip(CHOICE_LABELS, options, strict=True))
    answer = next(label for label, entity in mapping.items() if entity == goal)
    context = (
        "An agent operates in an unfamiliar relation system.\n"
        + "\n".join(f"Relation {relation} maps {source} to {target}." for relation, source, target in facts)
        + f"\nBegin at {start} and apply, in order: " + ", ".join(ordered_relations) + "."
    )
    prompt = _choice_prompt(context, mapping, "final-entity")
    task_id = f"v6-{split}-relation-composition-{index:02d}"
    public = {"version": VERSION, "task_id": task_id, "split": split, "family": "relation_composition", "profile": "cross_family_target", "prompt": prompt, "reasoning_prompt": _reasoning_prompt(prompt, "Follow the ordered relation chain from the stated start."), "prompt_valid_labels": list(CHOICE_LABELS), "choice_mapping_prompt_visible": mapping, "matched_features": {"relation_hops": 5, "distractor_facts": len(facts) - 5, "choice_count": 4, "semantic_novelty_proxy": "opaque_seeded_aliases", "tool_contract": "parse_visible_relation_facts_then_compose_query"}}
    return public, {"task_id": task_id, "family": public["family"], "answer": answer}


def _accumulator_task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    value = rng.randint(7, 19)
    operations = (("ADD", rng.randint(11, 29)), ("MULTIPLY", rng.choice((3, 4, 5))), ("SUBTRACT", rng.randint(6, 18)), ("ADD", rng.randint(13, 31)), ("MULTIPLY", rng.choice((2, 3))))
    result = value
    for operation, operand in operations:
        result = result + operand if operation == "ADD" else result - operand if operation == "SUBTRACT" else result * operand
    distractors = {result + rng.choice((-31, -17, 13, 29)), result + rng.choice((-19, -11, 7, 23)), result + rng.choice((-37, -5, 19, 41))}
    while len(distractors) < 3 or result in distractors:
        distractors.add(result + rng.randint(-50, 50) or 1)
        distractors.discard(result)
    options = [str(result), *(str(item) for item in sorted(distractors)[:3])]
    rng.shuffle(options)
    mapping = dict(zip(CHOICE_LABELS, options, strict=True))
    answer = next(label for label, candidate in mapping.items() if candidate == str(result))
    context = "A deterministic accumulator begins with visible state and executes operations in order.\nInitial accumulator: " + str(value) + ".\n" + "\n".join(f"Step {step}: {operation} {operand}." for step, (operation, operand) in enumerate(operations, 1))
    prompt = _choice_prompt(context, mapping, "final-accumulator")
    task_id = f"v6-{split}-accumulator-program-{index:02d}"
    public = {"version": VERSION, "task_id": task_id, "split": split, "family": "accumulator_program", "profile": "cross_family_target", "prompt": prompt, "reasoning_prompt": _reasoning_prompt(prompt, "Execute every operation in order and preserve the accumulator state."), "prompt_valid_labels": list(CHOICE_LABELS), "choice_mapping_prompt_visible": mapping, "matched_features": {"operation_count": 5, "choice_count": 4, "semantic_novelty_proxy": "fresh_integer_operands", "tool_contract": "parse_visible_accumulator_program_then_execute"}}
    return public, {"task_id": task_id, "family": public["family"], "answer": answer}


def _family_task(family: str, index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    if family == "shortest_path": return _path_task(index, split, rng)
    if family == "relation_composition": return _relation_task(index, split, rng)
    if family == "accumulator_program": return _accumulator_task(index, split, rng)
    raise RuntimeError(f"unknown v6 family: {family}")


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(TASK_SEED)
    preflight: list[Mapping[str, Any]] = []; public: list[Mapping[str, Any]] = []; authority: list[Mapping[str, Any]] = []
    for family in FAMILIES:
        for index in range(PREFLIGHT_PER_FAMILY):
            task, _ = _family_task(family, index, "preflight", rng); preflight.append({**task, "profile": "cross_family_preflight"})
        for index in range(DEVELOPMENT_PER_FAMILY):
            task, answer = _family_task(family, index, "development", rng); public.append(task); authority.append(answer)
        for index in range(PROSPECTIVE_PER_FAMILY):
            task, answer = _family_task(family, index, "prospective", rng); public.append(task); authority.append(answer)
    if len(preflight) != 12 or len(public) != 108 or len(authority) != 108:
        raise RuntimeError("v6 panel count mismatch")
    identifiers = [str(row["task_id"]) for row in (*preflight, *public)]
    if len(identifiers) != len(set(identifiers)):
        raise RuntimeError("v6 task identifiers are not unique")
    return preflight, public, authority


def build_schedule(preflight: Sequence[Mapping[str, Any]], public: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []
    for model_key in MODEL_ORDER:
        for split, tasks in (("preflight", preflight), ("development", [row for row in public if row["split"] == "development"]), ("prospective", [row for row in public if row["split"] == "prospective"])):
            identifiers = sorted(str(row["task_id"]) for row in tasks)
            random.Random(derive_seed(model_key, split, "order")).shuffle(identifiers)
            rows.extend({"model_key": model_key, "split": split, "task_id": task_id, "task_order_index": order, "seed": derive_seed(model_key, task_id, "reasoned_choice")} for order, task_id in enumerate(identifiers))
    return rows


def _relation_state_and_tool(task: Mapping[str, Any]) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    prompt = str(task["prompt"])
    query = _REL_QUERY.search(prompt)
    facts = [(match["relation"], match["source"], match["target"]) for match in _REL_FACT.finditer(prompt)]
    if query is None or len(facts) < 5: raise RuntimeError("relation tool could not parse visible task")
    state_text = "relations:\n" + "\n".join(f"{source} --{relation}--> {target}" for relation, source, target in sorted(facts)) + "\nquery_start: " + query["start"] + "\nquery_relations: " + query["relations"]
    transition = {(relation, source): target for relation, source, target in facts}
    current = query["start"]
    for relation in query["relations"].split(", "):
        current = transition.get((relation, current), "")
        if not current: raise RuntimeError("relation tool query is not executable")
    inverse = {str(value): str(label) for label, value in task["choice_mapping_prompt_visible"].items()}
    candidate = inverse.get(current)
    if candidate not in task["prompt_valid_labels"]: raise RuntimeError("relation tool result is not a visible option")
    return {"method": "lossless_canonical_relation_state_from_visible_prompt", "state": state_text, "state_sha256": hashlib.sha256(state_text.encode()).hexdigest(), "uses_evaluation_authority": False}, {"method": "answer_blind_visible_relation_composition", "candidate": candidate, "delivered": True, "tool_contract_satisfied": True, "uses_evaluation_authority": False, "visible_state_sha256": hashlib.sha256(state_text.encode()).hexdigest()}


def _accumulator_state_and_tool(task: Mapping[str, Any]) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    prompt = str(task["prompt"]); start = _ACC_START.search(prompt); steps = [(match["op"], int(match["value"])) for match in _ACC_STEP.finditer(prompt)]
    if start is None or len(steps) != 5: raise RuntimeError("accumulator tool could not parse visible program")
    state_text = "initial: " + start["value"] + "\nprogram:\n" + "\n".join(f"{index}: {operation} {operand}" for index, (operation, operand) in enumerate(steps, 1))
    result = int(start["value"])
    for operation, operand in steps: result = result + operand if operation == "ADD" else result - operand if operation == "SUBTRACT" else result * operand
    inverse = {str(value): str(label) for label, value in task["choice_mapping_prompt_visible"].items()}; candidate = inverse.get(str(result))
    if candidate not in task["prompt_valid_labels"]: raise RuntimeError("accumulator tool result is not a visible option")
    return {"method": "lossless_canonical_accumulator_program_from_visible_prompt", "state": state_text, "state_sha256": hashlib.sha256(state_text.encode()).hexdigest(), "uses_evaluation_authority": False}, {"method": "answer_blind_visible_accumulator_execution", "candidate": candidate, "delivered": True, "tool_contract_satisfied": True, "uses_evaluation_authority": False, "visible_state_sha256": hashlib.sha256(state_text.encode()).hexdigest()}


def canonical_state_and_tool(task: Mapping[str, Any]) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    if task["family"] == "shortest_path":
        state, tool = _path_state(task), _path_tool(task)
        return state, {**tool, "visible_state_sha256": state["state_sha256"]}
    if task["family"] == "relation_composition": return _relation_state_and_tool(task)
    if task["family"] == "accumulator_program": return _accumulator_state_and_tool(task)
    raise RuntimeError("unknown v6 task family")


def state_augmented_task(task: Mapping[str, Any]) -> tuple[Mapping[str, Any], Mapping[str, Any], Mapping[str, Any]]:
    state, tool = canonical_state_and_tool(task)
    marker = "\n\nChoose the correct"; prefix, suffix = str(task["prompt"]).split(marker, 1)
    block = "\n\nEXTERNAL CANONICAL STATE (a transcription, not a solved answer):\n" + str(state["state"])
    return {**task, "prompt": prefix + block + marker + suffix, "reasoning_prompt": str(task["reasoning_prompt"]) + block}, state, tool
