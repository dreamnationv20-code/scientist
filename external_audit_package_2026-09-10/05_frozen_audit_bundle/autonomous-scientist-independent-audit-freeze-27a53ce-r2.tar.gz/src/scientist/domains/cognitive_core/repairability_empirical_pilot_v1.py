from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from scientist.domains.cognitive_core.gate1_causal_decomposition_v1 import (
    FAMILIES,
    GateTask,
    build_tasks,
    score_response,
)
from scientist.domains.cognitive_core.repairability_reframe_v1 import digest


VERSION = "cognitive-repairability-empirical-mechanism-pilot-v1"
MODEL_ORDER = ("qwen3_1p7b", "qwen2p5_3b")
CONTRASTS = (
    "compute",
    "explicit_state",
    "verification",
    "tools",
    "parameter_change",
)
ARMS = ("control", "treatment")
EVALUATION_SEED = 860_300_200
DEVELOPMENT_SEED = 860_300_100
RANDOMIZATION_SEED = 860_300_300
ITEMS_PER_FAMILY = 4
DEVELOPMENT_ITEMS_PER_FAMILY = 8
MAXIMUM_NEW_TOKENS = 160
MAXIMUM_TOTAL_NORMALIZED_HOURS = 1.365
MODEL_HOUR_CAPS = {"qwen3_1p7b": 0.45, "qwen2p5_3b": 0.75}
SHARED_HOUR_CAP = 0.165
CALLS_PER_ARM = {
    "compute": 3,
    "explicit_state": 1,
    "verification": 2,
    "tools": 1,
    "parameter_change": 1,
}


FEATURE_PROFILES: Mapping[str, Mapping[str, Any]] = {
    "obfuscated_planning": {
        "profile": "state_burden",
        "dependency_depth": "high",
        "intermediate_state_burden": "high",
        "checkability": "medium",
        "tool_affordance": "low",
        "semantic_novelty": "low",
        "predicted_best": "explicit_state",
    },
    "novel_rule_induction": {
        "profile": "parameter_update",
        "dependency_depth": "medium",
        "intermediate_state_burden": "low",
        "checkability": "low",
        "tool_affordance": "low",
        "semantic_novelty": "high",
        "predicted_best": "parameter_change",
    },
    "counterfactual_causal": {
        "profile": "verifiability",
        "dependency_depth": "high",
        "intermediate_state_burden": "medium",
        "checkability": "high",
        "tool_affordance": "low",
        "semantic_novelty": "low",
        "predicted_best": "verification",
    },
    "stateful_tool_workflow": {
        "profile": "tool_affordance",
        "dependency_depth": "high",
        "intermediate_state_burden": "high",
        "checkability": "high",
        "tool_affordance": "high",
        "semantic_novelty": "low",
        "predicted_best": "tools",
    },
    "evidence_grounding": {
        "profile": "search_width",
        "dependency_depth": "medium",
        "intermediate_state_burden": "medium",
        "checkability": "medium",
        "tool_affordance": "low",
        "semantic_novelty": "low",
        "predicted_best": "compute",
    },
}


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def file_sha256(path: Path) -> str:
    body = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            body.update(block)
    return body.hexdigest()


def jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(
        json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n"
        for row in rows
    )


def read_rows(path: Path) -> list[Mapping[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    ]


def _suffix(prompt: str) -> str:
    marker = "\n\nORACLE INTERVENTION (not the answer):\n"
    if marker not in prompt:
        raise ValueError("intervention prompt lacks its public intervention marker")
    return prompt.split(marker, 1)[1]


def task_public_row(task: GateTask) -> Mapping[str, Any]:
    row = dict(task.public_dict())
    pilot_task_id = "rp1-" + str(task.task_id)
    raw_prompt = str(row["prompts"]["raw"])
    return {
        "version": VERSION,
        "task_id": pilot_task_id,
        "family": task.family,
        "raw_prompt": raw_prompt,
        "state_payload": _suffix(str(row["prompts"]["state"])),
        "verification_payload": _suffix(str(row["prompts"]["verifier"])),
        "tool_payload": (
            _suffix(str(row["prompts"]["dynamics"]))
            if task.family == "stateful_tool_workflow"
            else "TOOL_NOT_APPLICABLE_FOR_THIS_PROMPT_PROFILE"
        ),
        "maximum_new_tokens": MAXIMUM_NEW_TOKENS,
        "features": {
            **FEATURE_PROFILES[task.family],
            "prompt_character_count": len(raw_prompt),
            "prompt_line_count": len(raw_prompt.splitlines()),
        },
    }


def task_authority_row(task: GateTask) -> Mapping[str, Any]:
    public = task_public_row(task)
    return {
        "version": VERSION,
        "task_id": public["task_id"],
        "family": task.family,
        "authority": dict(task.authority),
    }


def build_evaluation_rows() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    tasks = build_tasks(seed=EVALUATION_SEED, items_per_family=ITEMS_PER_FAMILY)
    public = [task_public_row(task) for task in tasks]
    authority = [task_authority_row(task) for task in tasks]
    if len(public) != ITEMS_PER_FAMILY * len(FAMILIES):
        raise RuntimeError("pilot evaluation panel is incomplete")
    return public, authority


def build_development_rows() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    tasks = build_tasks(
        seed=DEVELOPMENT_SEED,
        items_per_family=DEVELOPMENT_ITEMS_PER_FAMILY,
    )
    rule_tasks = [task for task in tasks if task.family == "novel_rule_induction"]
    treatment = []
    answers = [str(task.authority["answer"]) for task in rule_tasks]
    shifted = answers[1:] + answers[:1]
    sham = []
    for task, correct, wrong in zip(rule_tasks, answers, shifted):
        public = task_public_row(task)
        treatment.append(
            {
                "task_id": "dev-" + public["task_id"],
                "prompt": public["raw_prompt"],
                "response": "FINAL: " + correct + "\n",
            }
        )
        sham.append(
            {
                "task_id": "dev-" + public["task_id"],
                "prompt": public["raw_prompt"],
                "response": "FINAL: " + wrong + "\n",
            }
        )
    if len(treatment) != DEVELOPMENT_ITEMS_PER_FAMILY:
        raise RuntimeError("pilot development partition is incomplete")
    return treatment, sham


def derive_seed(*labels: object) -> int:
    payload = "\0".join(str(label) for label in (RANDOMIZATION_SEED, *labels))
    return int.from_bytes(hashlib.sha256(payload.encode()).digest()[:4], "big")


def build_schedule(public_rows: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    schedule = []
    for model_key in MODEL_ORDER:
        for task in public_rows:
            task_id = str(task["task_id"])
            for contrast in CONTRASTS:
                treatment_first = bool(derive_seed(model_key, task_id, contrast, "order") % 2)
                order = (
                    ("treatment", "control")
                    if treatment_first
                    else ("control", "treatment")
                )
                schedule.append(
                    {
                        "model_key": model_key,
                        "task_id": task_id,
                        "contrast": contrast,
                        "arm_order": list(order),
                        "call_seeds": {
                            arm: [
                                derive_seed(model_key, task_id, contrast, arm, index)
                                for index in range(CALLS_PER_ARM[contrast])
                            ]
                            for arm in ARMS
                        },
                    }
                )
    return schedule


def extract_candidate(response: str, family: str) -> Mapping[str, Any]:
    text = response.strip()
    matches = re.findall(
        r"(?im)^\s*(?:\*\*)?FINAL\s*:\s*(.+?)(?:\*\*)?\s*$",
        response,
    )
    if matches:
        candidate = matches[-1].strip()
        method = "final_marker"
    elif family == "stateful_tool_workflow":
        starts = [index for index, character in enumerate(response) if character == "["]
        candidate = ""
        for start in reversed(starts):
            end = response.rfind("]")
            if end <= start:
                continue
            value = response[start : end + 1].strip()
            try:
                parsed = json.loads(value)
            except json.JSONDecodeError:
                continue
            if isinstance(parsed, list):
                candidate = json.dumps(parsed, sort_keys=True, separators=(",", ":"))
                break
        method = "json_array_recovery" if candidate else "unparsed"
    else:
        lines = [
            re.sub(r"^[-*`#\s]+|[-*`\s]+$", "", line).strip()
            for line in text.splitlines()
            if line.strip()
        ]
        candidate = lines[-1] if lines else ""
        method = "last_nonempty_line" if candidate else "unparsed"
    return {
        "candidate": candidate,
        "method": method,
        "delivered": bool(candidate),
        "response_sha256": hashlib.sha256(response.encode()).hexdigest(),
    }


def candidate_key(candidate: str, family: str) -> str:
    if family == "stateful_tool_workflow":
        try:
            return json.dumps(
                json.loads(candidate),
                sort_keys=True,
                separators=(",", ":"),
            )
        except json.JSONDecodeError:
            pass
    return re.sub(r"\s+", "", candidate).casefold()


def majority_candidate(
    receipts: Sequence[Mapping[str, Any]], family: str
) -> Mapping[str, Any]:
    delivered = [row for row in receipts if row["delivered"]]
    if not delivered:
        return {"candidate": "", "method": "no_delivered_candidate", "delivered": False}
    counts: dict[str, int] = {}
    first: dict[str, Mapping[str, Any]] = {}
    for row in delivered:
        key = candidate_key(str(row["candidate"]), family)
        counts[key] = counts.get(key, 0) + 1
        first.setdefault(key, row)
    best = max(counts, key=lambda key: (counts[key], -list(first).index(key)))
    return {
        "candidate": first[best]["candidate"],
        "method": "answer_blind_majority_then_first",
        "delivered": True,
        "support": counts[best],
        "candidate_count": len(delivered),
    }


def score_candidate(
    family: str, authority: Mapping[str, Any], candidate: str
) -> Mapping[str, Any]:
    return score_response(family, authority, "FINAL: " + candidate + "\n")


def neutral_payload(payload: str, label: str) -> str:
    prefix = "CONTROL_%s:" % label.upper()
    remaining = max(0, len(payload) - len(prefix))
    return prefix + ("_" * remaining)


def protocol_body(
    transition_id: str,
    public_rows: Sequence[Mapping[str, Any]],
    authority_sha256: str,
    development_treatment_sha256: str,
    development_sham_sha256: str,
    schedule: Sequence[Mapping[str, Any]],
    predictions: Sequence[Mapping[str, Any]],
    analysis_plan: Sequence[str],
) -> Mapping[str, Any]:
    return {
        "version": VERSION,
        "parent_transition_id": transition_id,
        "research_goal": (
            "Prospectively test whether sealed answer-blind task features predict "
            "relative causal benefit from compute, explicit state, verification, "
            "tools, or a frozen parameter update."
        ),
        "models": list(MODEL_ORDER),
        "model_hour_caps": dict(MODEL_HOUR_CAPS),
        "shared_hour_cap": SHARED_HOUR_CAP,
        "maximum_total_normalized_hours": MAXIMUM_TOTAL_NORMALIZED_HOURS,
        "evaluation_seed": EVALUATION_SEED,
        "development_seed": DEVELOPMENT_SEED,
        "randomization_seed": RANDOMIZATION_SEED,
        "items_per_family": ITEMS_PER_FAMILY,
        "families": list(FAMILIES),
        "task_count": len(public_rows),
        "contrasts": list(CONTRASTS),
        "arms": list(ARMS),
        "calls_per_arm": dict(CALLS_PER_ARM),
        "maximum_new_tokens": MAXIMUM_NEW_TOKENS,
        "public_panel_root": digest(list(public_rows)),
        "authority_vault_sha256": authority_sha256,
        "development_treatment_sha256": development_treatment_sha256,
        "development_sham_sha256": development_sham_sha256,
        "randomization_schedule_root": digest(list(schedule)),
        "feature_profiles": FEATURE_PROFILES,
        "prospective_predictions": list(predictions),
        "analysis_plan": list(analysis_plan),
        "estimands": {
            "primary": "within-task treatment-minus-control correctness by model and profile",
            "delivery": "within-arm valid delivery rate and manipulation-check rate",
            "causal_nonresponse_rule": (
                "only delivery-certified arms whose 95% interval excludes a benefit "
                "of at least 0.05; ordinary nonsignificance is inconclusive"
            ),
            "invariance_margin": -0.05,
            "multiplicity": "Holm across four registered prediction families",
        },
        "parameter_update": {
            "implementation": "rank-2 LoRA on final attention output projections",
            "training_steps": 8,
            "batch_size": 1,
            "maximum_sequence_length": 512,
            "development_scope": "fresh novel_rule_induction tasks only",
            "treatment_labels": "correct disjoint-development completions",
            "sham_labels": "within-family one-position cyclic permutation",
            "evaluation_authority_access": False,
        },
        "delivery_contract": {
            "accepted_channels": [
                "last FINAL marker",
                "last valid JSON array for tool-workflow tasks",
                "last nonempty line fallback",
            ],
            "minimum_delivery_rate_per_arm": 0.95,
            "raw_response_retained": True,
            "per_call_receipt_required": True,
            "per_arm_manipulation_check_required": True,
            "delivery_failure_separate_from_incorrectness": True,
        },
        "firewall": {
            "runner_reads_evaluation_authority": False,
            "scorer_starts_only_after_runner_terminal_manifest": True,
            "predictions_and_assignments_sealed_before_scoring": True,
            "raw_outcomes_available_to_transition_reviewer": False,
        },
        "attempt_and_review_caps": {
            "execution_attempts": 1,
            "measurement_recovery_sprints": 1,
            "scientific_review_rounds": 0,
            "automatic_restarts": 0,
        },
        "stop_rules": [
            "Any recovery-certificate failure permanently parks the current program.",
            "Any runner failure or model-hour-cap breach permanently parks the current program without restart.",
            "No task, feature, prediction, intervention, threshold, or analysis change after seal.",
            "No model above 3B may be run locally.",
        ],
        "claim_boundary": (
            "This is a small prospective causal-mechanism pilot. It can test the "
            "registered feature-intervention predictions in this synthetic panel; "
            "it cannot establish a final general theory, representation necessity, "
            "class-wide ineffectiveness, or model-size effects."
        ),
    }


def verify_public_rows(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, bool]:
    return {
        "balanced_families": len(rows) == ITEMS_PER_FAMILY * len(FAMILIES)
        and all(
            sum(row["family"] == family for row in rows) == ITEMS_PER_FAMILY
            for family in FAMILIES
        ),
        "unique_task_ids": len({row["task_id"] for row in rows}) == len(rows),
        "no_authority_key": all("authority" not in row for row in rows),
        "no_answer_key": all("answer" not in row for row in rows),
        "all_feature_profiles_frozen": all(
            row["features"]["profile"] == FEATURE_PROFILES[row["family"]]["profile"]
            for row in rows
        ),
        "tool_payload_prompt_gated": all(
            (row["tool_payload"] != "TOOL_NOT_APPLICABLE_FOR_THIS_PROMPT_PROFILE")
            == (row["family"] == "stateful_tool_workflow")
            for row in rows
        ),
    }

