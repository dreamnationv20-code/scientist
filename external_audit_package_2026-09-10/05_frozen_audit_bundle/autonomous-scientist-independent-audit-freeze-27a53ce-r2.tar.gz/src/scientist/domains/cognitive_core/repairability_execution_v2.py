from __future__ import annotations

import hashlib
import hmac
import json
import re
import string
import time
import unicodedata
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.domains.cognitive_core.repairability_qualification_v2 import (
    STATE_SYMBOLS,
    canonical_json,
    check_verification_candidate,
    digest,
    evaluate_integer_ast,
    sha256_bytes,
)


VERSION = "cognitive-repairability-execution-v2"
ALLOWED_STATE_TYPES = {"string", "integer", "boolean", "identifier_list"}
STATE_SLOTS = tuple(f"S{index}" for index in range(1, 9))
COMPUTE_IDENTIFIERS = {"x0", "p", "a_k", "b_k", "c_k", "target"}


def normalize_text(text: str) -> str:
    return unicodedata.normalize("NFC", text).replace("\r\n", "\n").replace("\r", "\n")


def strip_one_outer_fence(text: str) -> str:
    value = normalize_text(text).strip()
    match = re.fullmatch(r"```(?:json)?\s*\n?(.*?)\n?```", value, flags=re.S | re.I)
    return match.group(1).strip() if match else value


def extract_exact_tag(text: str, tag: str) -> str | None:
    value = strip_one_outer_fence(text)
    if "<!" in value or "<?" in value:
        return None
    try:
        root = ET.fromstring(value)
    except ET.ParseError:
        return None
    if root.tag != tag or root.attrib or list(root) or (root.tail or "").strip():
        return None
    return (root.text or "").strip()


def extract_first_tag(text: str, tags: Sequence[str]) -> Mapping[str, Any] | None:
    value = normalize_text(text)
    candidates = []
    for tag in tags:
        if tag == "write":
            pattern = re.compile(
                r'^<write slot="S[1-8]" type="(?:string|integer|boolean|identifier_list)" '
                r'source="(?:prompt|model)">.*?</write>',
                flags=re.S,
            )
        elif tag == "read":
            pattern = re.compile(r'^<read slot="S[1-8]"/>')
        elif tag == "tool":
            pattern = re.compile(r"^<tool>(.*?)</tool>", flags=re.S)
        elif tag == "final":
            pattern = re.compile(r"^<final>(.*?)</final>", flags=re.S)
        else:
            raise ValueError(f"unsupported finite-state tag: {tag}")
        match = pattern.match(value)
        if match is not None:
            content = match.group(1) if match.lastindex else ""
            candidates.append((match.start(), match.end(), tag, match.group(0), content))
    if not candidates:
        return None
    start, end, tag, raw, content = min(candidates, key=lambda item: item[0])
    return {"start": start, "end": end, "tag": tag, "raw": raw, "content": content or ""}


def strict_json(text: str) -> Any | None:
    def reject_duplicate_members(pairs: Sequence[tuple[str, Any]]) -> Mapping[str, Any]:
        value: Dict[str, Any] = {}
        for key, item in pairs:
            if key in value:
                raise ValueError(f"duplicate JSON member: {key}")
            value[key] = item
        return value

    def reject_nonfinite(value: str) -> None:
        raise ValueError(f"non-finite JSON number: {value}")

    try:
        return json.loads(
            strip_one_outer_fence(text),
            object_pairs_hook=reject_duplicate_members,
            parse_constant=reject_nonfinite,
        )
    except (json.JSONDecodeError, TypeError, ValueError):
        return None


def compute_level_is_prompt_derived(level: str, task: Mapping[str, Any]) -> bool:
    text = normalize_text(level).strip()
    if not text:
        return False
    return any(
        re.search(
            r"(?<![A-Za-z0-9_])" + re.escape(str(identifier)) + r"(?![A-Za-z0-9_])",
            text,
        )
        is not None
        for identifier in task.get("declared_identifiers", ())
    )


def parse_compute_path_response(
    response: str, expected_id: str, task: Mapping[str, Any]
) -> Mapping[str, Any]:
    value = normalize_text(response).strip()
    root = None
    if "<!" not in value and "<?" not in value:
        try:
            root = ET.fromstring(value)
        except ET.ParseError:
            root = None
    nodes = list(root) if root is not None else []
    level_texts = [
        (node.text or "").strip() for node in nodes[:3]
    ] if len(nodes) >= 3 else []
    candidate_text = (nodes[3].text or "").strip() if len(nodes) == 4 else ""
    valid = bool(
        root is not None
        and root.tag == "path"
        and root.attrib == {"id": expected_id}
        and not (root.text or "").strip()
        and [node.tag for node in nodes] == ["level", "level", "level", "candidate"]
        and [node.attrib for node in nodes[:3]]
        == [{"n": "1"}, {"n": "2"}, {"n": "3"}]
        and not nodes[3].attrib
        and all(not list(node) and not (node.tail or "").strip() for node in nodes)
        and len(level_texts) == 3
        and len(set(level_texts)) == 3
        and all(compute_level_is_prompt_derived(level, task) for level in level_texts)
        and bool(candidate_text)
    )
    candidate = candidate_text if valid else response
    parsed = strict_json(
        extract_exact_tag(candidate, "final")
        if extract_exact_tag(candidate, "final") is not None
        else candidate
    )
    return {
        "valid": valid,
        "text": candidate,
        "value": parsed,
        "schema_conforming": validate_final("compute", parsed, task),
        "raw": response,
        "path_id": expected_id,
        "levels": level_texts if valid else [],
        "prompt_derived_levels": bool(valid),
    }


def validate_final(repair_class: str, value: Any, task: Mapping[str, Any]) -> bool:
    if repair_class == "compute":
        return (
            isinstance(value, dict)
            and set(value) == {"code", "states"}
            and isinstance(value["code"], str)
            and re.fullmatch(r"[ABC]{6}", value["code"]) is not None
            and isinstance(value["states"], list)
            and len(value["states"]) == 7
            and all(isinstance(item, int) and not isinstance(item, bool) for item in value["states"])
        )
    if repair_class == "explicit_state":
        return (
            isinstance(value, dict)
            and set(value) == {"selected", "checksum"}
            and isinstance(value["selected"], list)
            and len(value["selected"]) == 6
            and all(item in STATE_SYMBOLS for item in value["selected"])
            and isinstance(value["checksum"], str)
            and re.fullmatch(r"[0-9]{2}", value["checksum"]) is not None
        )
    if repair_class == "verification":
        return (
            isinstance(value, dict)
            and set(value) == {"rows"}
            and isinstance(value["rows"], list)
            and len(value["rows"]) == 5
            and all(
                isinstance(row, str) and re.fullmatch(r"[ABCDE]{5}", row)
                for row in value["rows"]
            )
        )
    if repair_class == "tools":
        return (
            isinstance(value, dict)
            and set(value) == {"code"}
            and isinstance(value["code"], str)
            and re.fullmatch(r"K[0-9]+Z[0-9]{2}", value["code"]) is not None
        )
    if repair_class == "parameter_or_representation_change":
        return (
            isinstance(value, dict)
            and set(value) == {"label"}
            and value["label"] in task["label_vocabulary"]
        )
    raise ValueError(f"unknown repair class: {repair_class}")


def parse_final_response(
    repair_class: str, response: str, task: Mapping[str, Any]
) -> Mapping[str, Any]:
    tagged = extract_exact_tag(response, "final")
    value = None if tagged is None else strict_json(tagged)
    return {
        "value": value,
        "schema_valid": validate_final(repair_class, value, task),
        "canonical_hash": digest(value) if value is not None else sha256_bytes(normalize_text(response).encode()),
    }


def render_strict(template: str, values: Mapping[str, Any]) -> str:
    formatter = string.Formatter()
    fields = [name for _literal, name, _format, _conversion in formatter.parse(template) if name]
    if len(fields) != len(set(fields)):
        repeated = sorted(name for name in set(fields) if fields.count(name) > 1)
        raise ValueError(f"template placeholder repeated: {repeated}")
    if set(values) != set(fields):
        raise ValueError(
            f"template placeholder mismatch missing={sorted(set(fields)-set(values))} "
            f"extra={sorted(set(values)-set(fields))}"
        )
    return template.format(**values)


def _token_count(text: str) -> int:
    return len(re.findall(r"\S+", text))


def compute_rank_tuple(text: str, declared_identifiers: Iterable[str]) -> Tuple[Any, ...]:
    normalized = normalize_text(text)
    identifiers = set(declared_identifiers)
    coverage = sum(
        re.search(rf"(?<![A-Za-z0-9_]){re.escape(name)}(?![A-Za-z0-9_])", normalized)
        is not None
        for name in identifiers
    )
    assignments: Dict[str, set[str]] = {}
    for name, value in re.findall(
        r"\b([A-Za-z][A-Za-z0-9_]*)\s*=\s*([-+]?[A-Za-z0-9_.]+)", normalized
    ):
        if name in identifiers:
            assignments.setdefault(name, set()).add(value)
    conflicts = sum(max(0, len(values) - 1) for values in assignments.values())
    references = set(re.findall(r"\b(?:C|L|S)[0-9]+\b", normalized))
    declared_refs = set(re.findall(r"\b(?:C|L|S)[0-9]+\b", " ".join(identifiers)))
    unresolved = len(references - declared_refs)
    return (-coverage, conflicts, unresolved, _token_count(normalized), sha256_bytes(normalized.encode()))


def select_compute_candidates(
    candidates: Sequence[Mapping[str, Any]], declared_identifiers: Sequence[str], keep: int = 2
) -> Tuple[Mapping[str, Any], ...]:
    survivors = [
        row
        for row in candidates
        if bool(row.get("valid", True)) and bool(row.get("schema_conforming", True))
    ]
    ranked = sorted(
        survivors,
        key=lambda row: compute_rank_tuple(str(row["text"]), declared_identifiers),
    )
    selected = list(ranked[:keep])
    selected_hashes = {str(row["hash"]) for row in selected}
    supplements = sorted(
        (row for row in candidates if str(row["hash"]) not in selected_hashes),
        key=lambda row: str(row["hash"]),
    )
    selected.extend(supplements[: max(0, keep - len(selected))])
    if len(selected) != keep:
        raise ValueError("compute selection cannot supply the frozen candidate count")
    return tuple(selected)


@dataclass
class TypedStateService:
    task: Mapping[str, Any]
    sham: bool
    sham_key: bytes
    alternate_table: bool = False
    token_counter: Any | None = None
    slots: Dict[str, Mapping[str, Any]] = field(default_factory=dict)
    writes: int = 0
    reads: int = 0
    accepted_value_tokens: int = 0
    operations: list[Mapping[str, Any]] = field(default_factory=list)
    _event_index: int = 0

    def _sham_hex_value(self, label: Any, target_tokens: int) -> str | None:
        raw = hmac.new(
            self.sham_key, canonical_json(label), hashlib.sha256
        ).hexdigest()
        if self.token_counter is None:
            return " ".join(
                raw[(2 * index) % len(raw) : (2 * index) % len(raw) + 2]
                for index in range(target_tokens)
            )
        for offset in range(len(raw)):
            rotated = raw[offset:] + raw[:offset]
            stream = rotated * (16 * target_tokens + 2)
            for end in range(1, len(stream) + 1):
                candidate = stream[:end]
                observed = int(self.token_counter(candidate))
                if observed == target_tokens:
                    return candidate
                if observed > target_tokens:
                    break
        return None

    def _error(self, operation: str, slot: str | None, code: str) -> Mapping[str, Any]:
        record = {
            "ok": False,
            "slot": slot,
            "type": None,
            "value": None,
            "value_hash": None,
            "error_code": code,
        }
        self._event_index += 1
        self.operations.append({"event_index": self._event_index, "operation": operation, **record})
        return record

    def write(
        self,
        slot: str,
        declared_type: str,
        source: str,
        value: str,
        generation_call_hash: str | None = None,
    ) -> Mapping[str, Any]:
        if self.writes >= 8:
            return self._error("write", slot, "LIMIT_EXCEEDED")
        if slot not in STATE_SLOTS or declared_type not in ALLOWED_STATE_TYPES:
            return self._error("write", slot, "SCHEMA_INVALID")
        if source not in {"prompt", "model"}:
            return self._error("write", slot, "PROVENANCE_INVALID")
        value = normalize_text(value)
        value_token_count = (
            int(self.token_counter(value)) if self.token_counter is not None else _token_count(value)
        )
        if value_token_count > 256:
            return self._error("write", slot, "VALUE_LIMIT_EXCEEDED")
        if declared_type == "integer" and re.fullmatch(r"[-+]?[0-9]+", value) is None:
            return self._error("write", slot, "TYPE_INVALID")
        if declared_type == "boolean" and value not in {"true", "false"}:
            return self._error("write", slot, "TYPE_INVALID")
        if declared_type == "identifier_list":
            parsed_list = strict_json(value)
            if not (
                isinstance(parsed_list, list)
                and all(isinstance(item, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", item) for item in parsed_list)
            ):
                return self._error("write", slot, "TYPE_INVALID")
        declared_spans = [
            str(self.task["prompt"])[int(item["start"]) : int(item["end"])]
            for item in self.task.get("declared_entities", [])
        ]
        if source == "prompt" and value not in declared_spans:
            return self._error("write", slot, "PROMPT_SPAN_INVALID")
        if source == "model" and not generation_call_hash:
            return self._error("write", slot, "PROVENANCE_INVALID")
        lowered = value.casefold()
        forbidden_markers = (
            "answer", "correctness", "checker", "verdict", "verifier",
            "tool_output", "tool result", "scorer", "score", "outcome",
            "prospective", "<final", "<tool", "<verify",
        )
        parsed_value = strict_json(value)
        answer_shaped = bool(
            source == "model"
            and (
                validate_final("explicit_state", parsed_value, self.task)
                or (
                    isinstance(parsed_value, list)
                    and len(parsed_value) == 6
                    and all(item in STATE_SYMBOLS for item in parsed_value)
                )
            )
        )
        forbidden_content = source == "model" and (
            answer_shaped or any(marker in lowered for marker in forbidden_markers)
        )
        if forbidden_content:
            return self._error("write", slot, "NON_ANSWER_BOUNDARY_VIOLATION")
        forbidden_hashes = {
            sha256_bytes(item.encode("utf-8"))
            for item in ("OUTCOME_CANARY_DO_NOT_STORE", "SCORER_CANARY_DO_NOT_STORE")
        }
        if sha256_bytes(value.encode("utf-8")) in forbidden_hashes:
            return self._error("write", slot, "CANARY_REJECTED")
        self.writes += 1
        self.accepted_value_tokens += value_token_count
        stored = value
        if self.sham:
            stored = self._sham_hex_value(
                [self.task["task_id"], slot, self.writes, value], value_token_count
            )
            if stored is None:
                self.writes -= 1
                self.accepted_value_tokens -= value_token_count
                return self._error("write", slot, "SHAM_TOKEN_MATCH_FAILED")
        record = {
            "ok": True,
            "slot": slot,
            "type": declared_type,
            "value": stored,
            "value_hash": sha256_bytes(stored.encode("utf-8")),
            "input_value_hash": sha256_bytes(value.encode("utf-8")),
            "error_code": None,
            "source": source,
            "generation_call_hash": generation_call_hash,
            "write_index": self.writes,
            "value_token_count": value_token_count,
            "non_answer_boundary_passed": True,
            "answer_schema_match": False,
            "forbidden_content_marker_count": 0,
        }
        self.slots[slot] = record
        self._event_index += 1
        exposed = {
            key: item
            for key, item in record.items()
            if key not in {"value"}
        }
        self.operations.append({"event_index": self._event_index, "operation": "write", **exposed})
        return {
            "ok": record["ok"],
            "slot": record["slot"],
            "type": record["type"],
            "value": None,
            "value_hash": None,
            "error_code": record["error_code"],
        }

    def read(self, slot: str) -> Any:
        if self.reads >= 12:
            return self._error("read", slot, "LIMIT_EXCEEDED")
        if slot not in STATE_SLOTS:
            return self._error("read", slot, "SCHEMA_INVALID")
        self.reads += 1
        effective_slot = slot
        if self.sham:
            raw = hmac.new(
                self.sham_key,
                canonical_json(["sham", self.task["task_id"], slot, self.reads]),
                hashlib.sha256,
            ).digest()
            effective_slot = STATE_SLOTS[raw[0] % len(STATE_SLOTS)]
        stored = self.slots.get(effective_slot)
        if self.alternate_table and stored is None:
            exact_row = self.storage_table()[STATE_SLOTS.index(effective_slot)]
            self._event_index += 1
            self.operations.append(
                {
                    "event_index": self._event_index,
                    "operation": "read",
                    "ok": True,
                    "slot": slot,
                    "effective_slot": effective_slot,
                    "type": None,
                    "value_hash": None,
                    "error_code": None,
                    "exact_stored_table_row": True,
                }
            )
            return exact_row
        if self.sham and stored is None and self.slots.get(slot) is not None:
            reference = self.slots[slot]
            synthetic = self._sham_hex_value(
                ["sham-read", self.task["task_id"], slot, effective_slot, self.reads],
                int(reference["value_token_count"]),
            )
            if synthetic is None:
                return self._error("read", slot, "SHAM_TOKEN_MATCH_FAILED")
            stored = {
                **reference,
                "value": synthetic,
                "value_hash": sha256_bytes(synthetic.encode("utf-8")),
                "synthetic_empty_slot": True,
            }
        if stored is None:
            return self._error("read", slot, "EMPTY_SLOT")
        record = {
            "ok": True,
            "slot": slot,
            "type": stored["type"],
            "value": stored["value"],
            "value_hash": stored["value_hash"],
            "error_code": None,
        }
        self._event_index += 1
        self.operations.append(
            {
                "event_index": self._event_index,
                "operation": "read",
                "effective_slot": effective_slot,
                **{key: item for key, item in record.items() if key != "value"},
            }
        )
        if self.alternate_table:
            return [
                effective_slot,
                stored["type"],
                stored["value"],
                stored["source"],
                stored["write_index"],
                stored["value_hash"],
            ]
        return record

    def process_tag(self, raw: str, generation_call_hash: str) -> Any:
        write = re.fullmatch(
            r'<write slot="(S[1-8])" type="(string|integer|boolean|identifier_list)" '
            r'source="(prompt|model)">(.*?)</write>',
            raw,
            flags=re.S,
        )
        if write:
            return self.write(
                write.group(1),
                write.group(2),
                write.group(3),
                write.group(4),
                generation_call_hash=generation_call_hash,
            )
        read = re.fullmatch(r'<read slot="(S[1-8])"\s*/>', raw)
        if read:
            return self.read(read.group(1))
        return self._error("unknown", None, "SCHEMA_INVALID")

    def storage_table(self, *, redact_values: bool = False) -> list[list[Any]]:
        rows = []
        for slot in STATE_SLOTS:
            stored = self.slots.get(slot)
            if stored is None:
                rows.append([slot, None, None, None, None, None])
            else:
                rows.append(
                    [
                        slot,
                        stored["type"],
                        None if redact_values else stored["value"],
                        stored["source"],
                        stored["write_index"],
                        stored["value_hash"],
                    ]
                )
        return rows

    def redacted_table(self) -> list[list[Any]]:
        return self.storage_table(redact_values=True)

    def delivery(self) -> Mapping[str, Any]:
        successful_writes = [row for row in self.operations if row["operation"] == "write" and row["ok"]]
        successful_reads = [row for row in self.operations if row["operation"] == "read" and row["ok"]]
        entity = self.task.get("declared_entities", [{}])[0]
        exact_tape_hash = str(entity.get("sha256", ""))
        matching_writes = [
            row
            for row in successful_writes
            if row["slot"] == "S1"
            and row.get("source") == "prompt"
            and row.get("input_value_hash") == exact_tape_hash
        ]
        mandatory_write = len(matching_writes) == 1
        tape_write = matching_writes[0] if mandatory_write else None
        if self.sham:
            mandatory_read = bool(
                tape_write
                and any(
                    row["operation"] == "read"
                    and row.get("slot") == "S1"
                    and row["event_index"] > tape_write["event_index"]
                    for row in self.operations
                )
            )
        else:
            mandatory_read = bool(
                tape_write
                and any(
                    row["slot"] == "S1"
                    and row["event_index"] > tape_write["event_index"]
                    and row.get("value_hash") == tape_write.get("value_hash")
                    and not any(
                        intervening["operation"] == "write"
                        and intervening.get("slot") == "S1"
                        and tape_write["event_index"] < intervening["event_index"] < row["event_index"]
                        for intervening in self.operations
                    )
                    for row in successful_reads
                )
            )
        integrity = True
        if not self.sham:
            current: Dict[str, str] = {}
            for row in self.operations:
                if row["operation"] == "write" and row["ok"]:
                    current[str(row["slot"])] = str(row["value_hash"])
                elif row["operation"] == "read" and row["ok"]:
                    integrity = integrity and current.get(str(row["slot"])) == row["value_hash"]
        return {
            "mandatory_write": mandatory_write,
            "mandatory_read": mandatory_read,
            "integrity": integrity,
            "write_count": self.writes,
            "read_count": self.reads,
            "passed": mandatory_write and mandatory_read and (integrity or self.sham),
        }

    def redacted_operations(self) -> list[Mapping[str, Any]]:
        return [
            {key: item for key, item in row.items() if key != "value"}
            for row in self.operations
        ]


@dataclass
class NullStatePaddingService:
    task_id: str
    arm: str
    slot_value_hash: str = field(default_factory=lambda: sha256_bytes(b""))
    value_tokens: int = 0
    writes: int = 0
    reads: int = 0
    operations: list[Mapping[str, Any]] = field(default_factory=list)
    token_counter: Any | None = None
    token_materializer: Any | None = None

    def execute(self, value_tokens: int, writes: int, reads: int) -> Mapping[str, Any]:
        if min(value_tokens, writes, reads) < 0:
            raise ValueError("null-state padding counts cannot be negative")
        materialized_hashes = []
        remaining = value_tokens
        index = 0
        while remaining:
            count = min(256, remaining)
            value = (
                str(self.token_materializer(count))
                if self.token_materializer is not None
                else " ".join(["N0"] * count)
            )
            observed_count = (
                int(self.token_counter(value))
                if self.token_counter is not None
                else _token_count(value)
            )
            if observed_count != count:
                raise RuntimeError("null-state value failed exact tokenizer accounting")
            payload = canonical_json([self.task_id, self.arm, "value", index, value])
            materialized_hashes.append(sha256_bytes(payload))
            self.value_tokens += observed_count
            remaining -= count
            index += 1
        for write_index in range(writes):
            payload = canonical_json(
                [self.task_id, self.arm, "write", write_index, self.slot_value_hash]
            )
            self.slot_value_hash = sha256_bytes(payload)
            self.writes += 1
            self.operations.append(
                {
                    "operation": "write",
                    "slot": "N0",
                    "value_hash": self.slot_value_hash,
                }
            )
        for read_index in range(reads):
            replay_hash = sha256_bytes(
                canonical_json(
                    [self.task_id, self.arm, "read", read_index, self.slot_value_hash]
                )
            )
            self.reads += 1
            self.operations.append(
                {
                    "operation": "read",
                    "slot": "N0",
                    "retrieved_hash": self.slot_value_hash,
                    "replay_hash": replay_hash,
                }
            )
        return {
            "value_tokens": self.value_tokens,
            "writes": self.writes,
            "reads": self.reads,
            "materialized_value_hashes": materialized_hashes,
            "operation_log_hash": digest(self.operations),
        }


@dataclass(frozen=True)
class VerificationChecker:
    task: Mapping[str, Any]
    alternate: bool = False

    def check(self, candidate_text: str) -> Mapping[str, Any]:
        value = strict_json(candidate_text)
        result = check_verification_candidate(value, self.task["clues"])
        if self.alternate:
            return {
                "valid": bool(result["valid"]),
                "violated_constraint_ids": sorted(set(result["violated_constraint_ids"]))[:4],
            }
        return {"valid": bool(result["valid"])}


def sham_verifier_sequence(seed: int) -> Tuple[bool, ...]:
    sequence = (True, False, True, False, False, True)
    raw = hmac.new(
        seed.to_bytes(8, "big"), b"sham-checker", hashlib.sha256
    ).digest()
    offset = int.from_bytes(raw, "big") % 6
    return tuple(sequence[(index + offset) % 6] for index in range(6))


def select_verified_candidate(
    candidates: Sequence[Mapping[str, Any]], validity: Sequence[bool]
) -> Mapping[str, Any]:
    if len(candidates) != 6 or len(validity) != 6:
        raise ValueError("verification requires exactly six candidates and verdicts")
    conforming = [row for row in candidates if row["schema_conforming"]]
    survivors = [
        row for row, valid in zip(candidates, validity) if valid and row["schema_conforming"]
    ]
    if survivors:
        return min(survivors, key=lambda row: (int(row["token_count"]), row["hash"]))
    if conforming:
        return min(conforming, key=lambda row: row["hash"])
    return min(candidates, key=lambda row: row["hash"])


def _latin_fixture(clues: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    clue_map = {
        (int(item["row"]), int(item["column"])): str(item["symbol"])
        for item in clues
    }
    grid = [[""] * 5 for _ in range(5)]
    row_used = [set() for _ in range(5)]
    column_used = [set() for _ in range(5)]

    def solve(index: int) -> bool:
        if index == 25:
            return True
        row, column = divmod(index, 5)
        allowed = (
            (clue_map[(row, column)],)
            if (row, column) in clue_map
            else tuple("ABCDE")
        )
        for symbol in allowed:
            if symbol in row_used[row] or symbol in column_used[column]:
                continue
            grid[row][column] = symbol
            row_used[row].add(symbol)
            column_used[column].add(symbol)
            if solve(index + 1):
                return True
            row_used[row].remove(symbol)
            column_used[column].remove(symbol)
            grid[row][column] = ""
        return False

    if not solve(0):
        raise RuntimeError("verification fixture clues are unsatisfiable")
    return {"rows": ["".join(row) for row in grid]}


def verification_fixture_report(
    task: Mapping[str, Any], *, alternate: bool | None = None
) -> Mapping[str, Any]:
    alternate = str(task.get("attempt")) == "A" if alternate is None else alternate
    checker = VerificationChecker(task, alternate=alternate)
    valid = _latin_fixture(task["clues"])
    valid_fixtures = [json.dumps(valid, sort_keys=True) for _index in range(10)]
    invalid_values = []
    for index in range(10):
        rows = list(valid["rows"])
        row = list(rows[index % 5])
        row[1] = row[0]
        rows[index % 5] = "".join(row)
        invalid_values.append(json.dumps({"rows": rows}, sort_keys=True))
    valid_results = [checker.check(value)["valid"] for value in valid_fixtures]
    invalid_results = [checker.check(value)["valid"] for value in invalid_values]
    sensitivity = sum(valid_results) / len(valid_results)
    specificity = sum(not item for item in invalid_results) / len(invalid_results)
    responses = [checker.check(value) for value in (*valid_fixtures, *invalid_values)]
    allowed_response_fields = (
        {"valid", "violated_constraint_ids"} if alternate else {"valid"}
    )
    disclosure_safe = all(
        set(row) == allowed_response_fields
        and set(row.get("violated_constraint_ids", ())).issubset(
            set(task["constraint_ids"])
        )
        for row in responses
    )
    body = {
        "fixture_count": 20,
        "sensitivity": sensitivity,
        "specificity": specificity,
        "disclosure_safe": disclosure_safe,
        "alternate_contract": alternate,
        "passed": sensitivity >= 0.90 and specificity >= 0.90 and disclosure_safe,
        "fixture_hash": digest([valid_fixtures, invalid_values]),
    }
    return {**body, "report_id": digest(body)}


@dataclass
class BoundedToolService:
    task: Mapping[str, Any]
    sham: bool
    sham_key: bytes
    alternate_direct: bool = False
    calls: int = 0
    records: list[Mapping[str, Any]] = field(default_factory=list)

    def execute(self, request: Any) -> Mapping[str, Any]:
        started = time.monotonic_ns()
        self.calls += 1
        required = self.task["required_request"]
        direct_required = {
            "operation": "integer_arithmetic",
            "ast": required["arguments"]["ast"],
        }
        error = None
        subresult = None
        request_id = (
            required["request_id"]
            if self.alternate_direct
            else (request.get("request_id") if isinstance(request, dict) else "")
        )
        if self.calls > 1:
            error = "LIMIT_EXCEEDED"
        elif not isinstance(request, dict):
            error = "SCHEMA_INVALID"
        elif len(canonical_json(request)) > 1024:
            error = "SCHEMA_INVALID"
        elif any(word in canonical_json(request).decode("utf-8").lower() for word in ("answer", "correct", "authority")):
            error = "AUTHORITY_REQUEST_REJECTED"
        elif self.alternate_direct and set(request) != {"operation", "ast"}:
            error = "SCHEMA_INVALID"
        elif not self.alternate_direct and set(request) != {"request_id", "operation", "arguments"}:
            error = "SCHEMA_INVALID"
        elif (self.alternate_direct and request != direct_required) or (
            not self.alternate_direct and request != required
        ):
            error = "OP_NOT_ALLOWED"
        else:
            ast = request["ast"] if self.alternate_direct else request["arguments"]["ast"]
            subresult = evaluate_integer_ast(ast)
            if self.sham:
                digits = len(str(abs(subresult)))
                raw = hmac.new(
                    self.sham_key,
                    canonical_json([self.task["task_id"], request_id]),
                    hashlib.sha256,
                ).digest()
                minimum = 10 ** max(0, digits - 1)
                span = 9 * minimum if digits > 1 else 10
                subresult = minimum + int.from_bytes(raw, "big") % span
        response = {
            "request_id": request_id,
            "ok": error is None,
            "subresult_type": "integer" if error is None else None,
            "subresult": subresult,
            "error_code": error,
            "truncated": False,
        }
        self.records.append(
            {
                "request_hash": digest(request),
                "response_hash": digest(response),
                "request_schema_valid": isinstance(request, dict)
                and request == (direct_required if self.alternate_direct else required),
                "response_schema_valid": set(response)
                == {"request_id", "ok", "subresult_type", "subresult", "error_code", "truncated"},
                "local_execution_ns": time.monotonic_ns() - started,
                "error_code": error,
            }
        )
        return response


def tool_fixture_report(
    task: Mapping[str, Any], *, alternate: bool | None = None
) -> Mapping[str, Any]:
    expected = evaluate_integer_ast(task["required_request"]["arguments"]["ast"])
    alternate = str(task.get("attempt")) == "A" if alternate is None else alternate
    fixture_request = (
        task["direct_required_request"] if alternate else task["required_request"]
    )
    correct = 0
    deterministic = True
    for index in range(10):
        key = hashlib.sha256(f"fixture-{index}".encode()).digest()
        first = BoundedToolService(
            task, sham=False, sham_key=key, alternate_direct=alternate
        ).execute(fixture_request)
        second = BoundedToolService(
            task, sham=False, sham_key=key, alternate_direct=alternate
        ).execute(fixture_request)
        correct += int(first["ok"] and first["subresult"] == expected)
        deterministic = deterministic and first == second
    adversarial = dict(fixture_request)
    adversarial["operation"] = "authority_answer"
    rejected = BoundedToolService(
        task, sham=False, sham_key=b"a" * 32, alternate_direct=alternate
    ).execute(adversarial)
    body = {
        "fixture_count": 10,
        "fixture_execution_rate": correct / 10,
        "deterministic_replay": deterministic,
        "authority_request_rejected": rejected["error_code"] == "AUTHORITY_REQUEST_REJECTED",
        "bounded_response_schema": set(rejected)
        == {"request_id", "ok", "subresult_type", "subresult", "error_code", "truncated"},
        "alternate_contract": alternate,
    }
    body["passed"] = all(
        (
            body["fixture_execution_rate"] >= 0.90,
            body["deterministic_replay"],
            body["authority_request_rejected"],
            body["bounded_response_schema"],
        )
    )
    return {**body, "report_id": digest(body)}


def score_value(
    task: Mapping[str, Any], authority: Mapping[str, Any], value: Any
) -> bool:
    if task["repair_class"] == "verification":
        return bool(check_verification_candidate(value, task["clues"])["valid"])
    return value == authority["answer"]


def paired_gate(
    records: Sequence[Mapping[str, Any]],
    *,
    additional_checks_passed: bool,
    maximum_cost_difference: float = 0.10,
    maximum_resource_difference: float = 0.15,
) -> Mapping[str, Any]:
    if len(records) != 5:
        raise ValueError("qualification gate requires exactly five paired units")
    treatment = [
        int(bool(row["treatment_correct"])) if bool(row["completed"]) else 0
        for row in records
    ]
    control = [
        int(bool(row["control_correct"])) if bool(row["completed"]) else 0
        for row in records
    ]
    completed = sum(bool(row["completed"]) for row in records)
    wins = sum(left > right for left, right in zip(treatment, control))
    gain = sum(treatment) / 5 - sum(control) / 5
    maximum_observed_cost = max(float(row["cost_difference"]) for row in records)
    maximum_observed_resource = max(
        max(float(item) for item in row["principal_resource_differences"])
        for row in records
    )
    checks = {
        "additional_checks_passed": additional_checks_passed,
        "minimum_completed": completed >= 4,
        "minimum_paired_wins": wins >= 3,
        "minimum_accuracy_gain": gain >= 0.20 - 1e-12,
        "maximum_cost_difference": maximum_observed_cost <= maximum_cost_difference + 1e-12,
        "maximum_principal_resource_difference": maximum_observed_resource
        <= maximum_resource_difference + 1e-12,
    }
    return {
        "checks": checks,
        "passed": all(checks.values()),
        "completed": completed,
        "paired_wins": wins,
        "accuracy_gain": gain,
        "treatment_accuracy": sum(treatment) / 5,
        "control_accuracy": sum(control) / 5,
        "maximum_cost_difference": maximum_observed_cost,
        "maximum_principal_resource_difference": maximum_observed_resource,
    }
