"""Exact answer-preserving gauge transformations for repairability discovery."""
from __future__ import annotations

import random
from typing import Any, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.repairability_closure_collision_fixtures_v1 import CANDIDATES, MODEL_KEYS


VERSION = "cognitive-repairability-gauge-distribution-fixtures-v1"
UNIT_COUNT = 24
CONDITIONS = (
    "canonical_surface_0",
    "canonical_surface_1",
    "gauge_a",
    "gauge_b",
    "broken_semantics",
)

_AFFINE_NAMES_A = (
    ("KAV", "LER", "MOR"), ("PEL", "QAR", "RUV"), ("TOV", "WEX", "YAL"),
    ("BEM", "COR", "DAX"), ("GIL", "HOR", "JUP"), ("LUM", "MEV", "NOR"),
    ("QIN", "RAS", "SUL"), ("UMA", "VOR", "WIL"), ("YOR", "ZAL", "BRI"),
    ("DOR", "EVI", "FAL"), ("HIL", "IVO", "JAR"), ("KIR", "LOV", "MER"),
)
_AFFINE_NAMES_B = (
    ("NAL", "OZI", "PER"), ("QEL", "RIN", "SAL"), ("TIR", "URV", "VEL"),
    ("WEN", "XAR", "YIL"), ("ZEV", "BOR", "CAL"), ("DUR", "ELI", "FIR"),
    ("GOR", "HAL", "IRV"), ("JOL", "KAR", "LEV"), ("MIR", "NOV", "ORV"),
    ("PAV", "QIR", "ROV"), ("SEV", "TUL", "URO"), ("VAN", "WOR", "XEL"),
)
_GRAPH_NAMES_A = (
    ("alven", "borin", "cressa", "dorin", "elvar"),
    ("faren", "gorda", "helin", "irven", "joral"),
    ("kelda", "lorin", "maven", "norel", "orvin"),
    ("pella", "quorin", "ravel", "sorin", "tavin"),
    ("ulmar", "vessa", "woren", "xalin", "yorva"),
    ("zorel", "brina", "coral", "daven", "erlin"),
    ("fovel", "garen", "hessa", "ilvar", "juren"),
    ("korin", "laven", "meral", "nissa", "ophel"),
    ("perin", "quess", "rimar", "selva", "toren"),
    ("urell", "varin", "wesla", "xorin", "yaren"),
    ("zavin", "belor", "ciran", "delva", "evren"),
    ("falor", "giren", "heral", "isven", "joval"),
)
_GRAPH_NAMES_B = tuple(tuple(reversed(names)) for names in _GRAPH_NAMES_A)


def _parameters(index: int) -> Mapping[str, int]:
    rng = random.Random(9_505_200 + index)
    return {"input": rng.randrange(5), "a": rng.randrange(1, 5), "b": rng.randrange(1, 5), "c": rng.randrange(1, 5)}


def _affine_prompt(
    *, unit_id: str, names: Sequence[str], parameters: Mapping[str, int], surface: int, broken: bool
) -> str:
    first, middle, last = names
    c = parameters["c"] % 4 + 1 if broken else parameters["c"]
    rules = (
        f"{first}(t)=(t+{parameters['a']}) mod 5; "
        f"{middle}(t)=({parameters['b']}*t) mod 5; {last}(t)=(t+{c}) mod 5"
    )
    if surface == 0:
        instruction = f"Active rules: {rules}. Apply {last}({middle}({first}({parameters['input']})))."
    else:
        instruction = f"Starting from {parameters['input']}, use these active definitions in listed order: {rules}."
    return (
        f"Independent gauge probe {unit_id}. Identifiers are arbitrary names whose definitions below are complete.\n"
        f"{instruction} Return only the canonical residue from 0 through 4.\nCanonical residue:"
    )


def _graph_prompt(
    *, unit_id: str, names: Sequence[str], start: int, surface: int, broken: bool
) -> str:
    table = "; ".join(f"{name}=slot {index}" for index, name in enumerate(names))
    edges = "; ".join(f"NEXT({names[index]})={names[(index + 1) % 5]}" for index in range(5))
    moves = 3 if broken else 2
    if surface == 0:
        instruction = f"Gauge table: {table}. Active cycle: {edges}. Begin at {names[start]} and follow NEXT exactly {moves} times."
    else:
        instruction = f"Use {moves} active NEXT steps from {names[start]}. The active cycle is {edges}. Translate the destination with this gauge table: {table}."
    return (
        f"Independent gauge probe {unit_id}. Node names are arbitrary; slot numbers define the canonical coordinates.\n"
        f"{instruction} Return only the destination's canonical slot number from 0 through 4.\nCanonical slot:"
    )


def build_fixtures() -> list[Mapping[str, Any]]:
    fixtures = []
    for index in range(UNIT_COUNT):
        family = "affine_identifiers" if index < UNIT_COUNT // 2 else "graph_coordinates"
        local = index if index < 12 else index - 12
        parameters = _parameters(index)
        unit_id = f"gauge_{family}_{local:02d}"
        condition_rows = []
        for condition in CONDITIONS:
            if family == "affine_identifiers":
                if condition.startswith("canonical"):
                    names = ("FIRST", "MIDDLE", "LAST")
                elif condition in {"gauge_a", "broken_semantics"}:
                    names = _AFFINE_NAMES_A[local]
                else:
                    names = _AFFINE_NAMES_B[local]
                prompt = _affine_prompt(
                    unit_id=unit_id,
                    names=names,
                    parameters=parameters,
                    surface=1 if condition == "canonical_surface_1" else 0,
                    broken=condition == "broken_semantics",
                )
            else:
                canonical = ("NODEA", "NODEB", "NODEC", "NODED", "NODEE")
                if condition.startswith("canonical"):
                    names = canonical
                elif condition in {"gauge_a", "broken_semantics"}:
                    names = _GRAPH_NAMES_A[local]
                else:
                    names = _GRAPH_NAMES_B[local]
                prompt = _graph_prompt(
                    unit_id=unit_id,
                    names=names,
                    start=parameters["input"],
                    surface=1 if condition == "canonical_surface_1" else 0,
                    broken=condition == "broken_semantics",
                )
            condition_rows.append({"condition_id": condition, "prompt": prompt})
        body = {
            "version": VERSION,
            "unit_id": unit_id,
            "family": family,
            "public_parameters": dict(parameters),
            "conditions": condition_rows,
            "candidate_completions": [f" {candidate}" for candidate in CANDIDATES],
            "gauge_a_and_b_are_answer_preserving": True,
            "broken_semantics_changes_active_function": True,
            "reference_answer_present": False,
        }
        fixtures.append({**body, "fixture_id": content_digest(body)})
    return fixtures


def build_schedule(fixtures: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    rows = []; index = 0
    for model_key in MODEL_KEYS:
        for fixture in fixtures:
            for condition in fixture["conditions"]:
                for candidate in CANDIDATES:
                    body = {
                        "version": VERSION,
                        "schedule_index": index,
                        "model_key": model_key,
                        "fixture_id": fixture["fixture_id"],
                        "unit_id": fixture["unit_id"],
                        "family": fixture["family"],
                        "condition_id": condition["condition_id"],
                        "prompt": condition["prompt"],
                        "candidate": candidate,
                        "candidate_completion": f" {candidate}",
                        "reference_answer_present": False,
                    }
                    rows.append({**body, "job_id": content_digest(body)}); index += 1
    return rows
