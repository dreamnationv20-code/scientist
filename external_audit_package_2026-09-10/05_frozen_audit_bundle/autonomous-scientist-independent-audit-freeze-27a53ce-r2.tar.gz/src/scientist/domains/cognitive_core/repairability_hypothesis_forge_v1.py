from __future__ import annotations

"""Source-grounded causal hypotheses for small-model reasoning repairability.

This module turns a broad question ("which repair should we try?") into a
small, competing set of answer-blind causal claims.  It deliberately does not
read answers, correctness, model text, or intervention outcomes.  In
particular, it treats a missing correct candidate as a *classification
abstention* condition, not proof that a representation or parameter change is
required.
"""

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.kernel.contracts import ChannelRelation, DiscoveryChannelSpec
from scientist.program.literature import PriorArtRelation
from scientist.program.literature_grounding import (
    LiteratureHypothesisContext,
    LiteratureMechanismEvidence,
    LiteratureSourcePacket,
)
from scientist.science.hypotheses import (
    CausalHypothesisContract,
    MechanismFingerprint,
    RelationalMapping,
)
from scientist.science.hypothesis_forge import (
    ForgedCausalHypothesis,
    HypothesisForgeBrief,
    HypothesisForgePortfolio,
    OpportunityKind,
    PrimarySourceSpan,
    ResearchOpportunity,
    StructuralProblemSignature,
    StructuralTransferMapping,
)


REPAIRABILITY_HYPOTHESIS_FORGE_VERSION = "cognitive-repairability-hypothesis-forge-v1"
TARGET_NODE_ID = "cognitive_core.answer_blind_repairability"

CHANNELS = (
    DiscoveryChannelSpec(
        "candidate_and_state",
        ChannelRelation.INDEPENDENT,
        "Candidate-bank and prompt-visible state mechanisms only.",
        False,
    ),
    DiscoveryChannelSpec(
        "verification_and_tools",
        ChannelRelation.INDEPENDENT,
        "Verifier and tool channels require a prompt-defined interface.",
        False,
    ),
    DiscoveryChannelSpec(
        "representation_boundary",
        ChannelRelation.INDEPENDENT,
        "Parameter claims require a successful, independently qualified parameter intervention.",
        False,
    ),
)


@dataclass(frozen=True)
class _Source:
    work_id: str
    title: str
    year: int
    locator: str
    source_domain: str
    abstract: str
    excerpt: str
    supports: str
    limitations: Tuple[str, ...]


# These are short, checkable abstract passages from the linked primary papers.
# The surrounding packet is a paraphrase so proposal generation is not driven by
# an architecture taxonomy or an outcome from this project.
SOURCES = (
    _Source(
        "snell-2024-test-time-compute",
        "Scaling LLM Test-Time Compute Optimally can be More Effective than Scaling Model Parameters",
        2024,
        "https://arxiv.org/abs/2408.03314",
        "test-time compute allocation",
        (
            "Test-time compute mechanisms differ in how they search or adapt a "
            "response distribution, and their effectiveness varies with prompt "
            "difficulty rather than following one universal rule."
        ),
        "effectiveness of different approaches to scaling test-time compute critically varies depending on the difficulty of the prompt",
        "compute must be routed by an answer-blind capability condition, not applied uniformly",
        ("The paper does not establish a repair rule for the small local models in this program.",),
    ),
    _Source(
        "nye-2021-scratchpads",
        "Show Your Work: Scratchpads for Intermediate Computation with Language Models",
        2021,
        "https://arxiv.org/abs/2112.00114",
        "scratchpad intermediate computation",
        (
            "Scratchpads expose intermediate computations and can improve multistep "
            "tasks, motivating an explicit-state mechanism rather than a generic "
            "longer-prompt treatment."
        ),
        "emit intermediate computation steps into a scratchpad",
        "state can help only when intermediate values are written, retained, and read by the final decision",
        ("Reported gains do not prove that an arbitrary state payload is actionable.",),
    ),
    _Source(
        "cobbe-2021-verifiers",
        "Training Verifiers to Solve Math Word Problems",
        2021,
        "https://arxiv.org/abs/2110.14168",
        "verifier-guided candidate selection",
        (
            "Verification is a distinct generator-selector system: a bank of "
            "candidate solutions is generated and a verifier ranks them."
        ),
        "generate many candidate solutions and select the one ranked highest by the verifier",
        "verification requires candidate discrimination; generic self-critique is not the same intervention",
        ("A verifier cannot select a correct candidate that the generator never supplies.",),
    ),
    _Source(
        "huang-2023-self-correction",
        "Large Language Models Cannot Self-Correct Reasoning Yet",
        2023,
        "https://arxiv.org/abs/2310.01798",
        "intrinsic self-correction limits",
        (
            "Intrinsic self-correction without external feedback can fail or reduce "
            "reasoning performance, so a revision prompt alone is not an informative "
            "verification treatment."
        ),
        "struggle to self-correct their responses without external feedback",
        "a verification arm needs an independently checkable signal and an intervention on the selected candidate",
        ("The result does not rule out verification with informative external feedback.",),
    ),
    _Source(
        "schick-2023-toolformer",
        "Toolformer: Language Models Can Teach Themselves to Use Tools",
        2023,
        "https://arxiv.org/abs/2302.04761",
        "tool-integrated language modeling",
        (
            "Tool use requires an agent to choose an API, form valid arguments, and "
            "incorporate a returned result; delivery is therefore part of the causal "
            "path rather than a nuisance variable."
        ),
        "decide which APIs to call, when to call them, what arguments to pass, and how to best incorporate the results",
        "a tool treatment is valid only when request formation, execution, and result use are all measured",
        ("Tool-use evidence does not make an undelivered tool channel a negative efficacy result.",),
    ),
    _Source(
        "hu-2021-lora",
        "LoRA: Low-Rank Adaptation of Large Language Models",
        2021,
        "https://arxiv.org/abs/2106.09685",
        "parameter-efficient adaptation",
        (
            "Low-rank adaptation changes a frozen model through trainable low-rank "
            "matrices, making it a concrete parameter intervention that needs its "
            "own disjoint training and positive-control qualification."
        ),
        "freezes the pre-trained model weights and injects trainable rank decomposition matrices",
        "parameter change is a separately delivered causal treatment, not an interpretation of a nonparametric null",
        ("One failed adapter configuration does not identify a representation requirement.",),
    ),
)

SOURCE_BY_ID = {item.work_id: item for item in SOURCES}


def repairability_literature_context(channel_id: str) -> LiteratureHypothesisContext:
    """Build a source-preserving context for one pre-outcome discovery channel."""

    if channel_id not in {item.channel_id for item in CHANNELS}:
        raise ValueError("unknown repairability hypothesis channel")
    packets = tuple(
        LiteratureSourcePacket(
            work_id=source.work_id,
            title=source.title,
            year=source.year,
            locator=source.locator,
            relation=PriorArtRelation.ADJACENT,
            abstract=source.abstract,
            matched_components=(source.supports,),
            mechanism_passages=(source.excerpt,),
            equations=(),
            limitations=source.limitations,
            causal_mappings=(source.supports,),
            executable=False,
        )
        for source in SOURCES
    )
    evidence = tuple(
        LiteratureMechanismEvidence(
            mechanism=source.work_id,
            work_id=source.work_id,
            title=source.title,
            year=source.year,
            locator=source.locator,
            relation=PriorArtRelation.ADJACENT,
            evidence_excerpt=source.abstract,
            is_executable_incumbent=False,
            is_latest_cohort=True,
        )
        for source in SOURCES
    )
    return LiteratureHypothesisContext(
        island_family=channel_id,
        assessment_id="repairability-primary-sources-2026-08-31",
        searched_at="2026-08-31T00:00:00Z",
        source_work_ids=tuple(source.work_id for source in SOURCES),
        evidence=evidence,
        known_mechanisms=tuple(source.source_domain for source in SOURCES),
        hypothesis_mechanisms=(
            "candidate availability",
            "state actionability",
            "verifier selectivity",
            "tool closure",
            "representation-boundary abstention",
        ),
        novelty_exclusions=(
            "a blanket claim that any intervention class always works or never works",
        ),
        open_questions=(
            "Which observable, answer-blind preconditions identify an actionable repair channel?",
        ),
        causal_questions=(
            "Does the proposed intervention change its declared mediator before it changes final correctness?",
        ),
        source_packets=packets,
        grounding_mode="source_preserving_primary_paper_abstracts",
    )


@dataclass(frozen=True)
class _Proposal:
    key: str
    opportunity_kind: OpportunityKind
    question: str
    source_ids: Tuple[str, ...]
    objective: str
    constraints: Tuple[str, ...]
    hardness: str
    solution_shape: str
    statement: str
    target_failure: str
    causal_mechanism: str
    observed_information: Tuple[str, ...]
    unavailable_information: str
    intervention: str
    mediator: str
    outcome: str
    source_domain: str
    source_mechanism: str
    broken_assumptions: Tuple[str, ...]
    predictions: Tuple[str, ...]
    ablations: Tuple[str, ...]
    boundary_conditions: Tuple[str, ...]
    expected_failure: str
    falsifiers: Tuple[str, ...]
    mappings: Tuple[Tuple[str, str, str, str], ...]
    first_experiment: str


PROPOSALS_BY_CHANNEL = {
    "candidate_and_state": (
        _Proposal(
            "candidate_availability",
            OpportunityKind.BOTTLENECK,
            "Can candidate selection repair a failure when no answer-blind probe candidate satisfies the prompt-visible necessary constraints?",
            ("snell-2024-test-time-compute", "cobbe-2021-verifiers"),
            "select an already viable candidate without observing its answer",
            ("fixed candidate budget", "answer-blind ranking", "prompt-visible necessary constraints"),
            "selection cannot create a missing candidate",
            "a candidate-bank availability gate before compute or verifier routing",
            "Additional compute or verifier selection repairs a failure only when a gold-blind probe bank contains nonzero prompt-valid candidate diversity; otherwise the system must abstain from assigning compute or verification as the repair.",
            "candidate-generation or candidate-format floor",
            "candidate availability is a necessary mediator for selection-based repair",
            ("parseable candidate rate", "prompt-visible constraint validity", "candidate disagreement"),
            "whether any candidate is correct",
            "resource-matched candidate generation plus answer-blind selection",
            "availability of at least one usable candidate and a nondegenerate ordering signal",
            "paired final correctness after terminal scoring",
            "test-time compute allocation",
            "candidate generation and answer-blind selection",
            ("more samples are useful even when every candidate fails necessary constraints",),
            (
                "Among delivery-certified units with nonzero prompt-valid candidate diversity, answer-blind selection exceeds the equal-generation first-candidate control.",
                "When the availability gate fails, selection produces no mediator improvement and is not labelled a representation failure.",
            ),
            ("shuffle candidate ranking", "replace the selection rule with first-candidate selection"),
            ("validity checks are necessary but not sufficient for correctness",),
            "A candidate bank contains no prompt-valid candidate or no ranking variation.",
            (
                "A positive selection effect appears in the zero-availability stratum without an alternative mediator.",
                "The availability gate does not predict the preregistered selection mediator on a fresh partition.",
            ),
            (
                ("candidate support", "prompt-valid candidate diversity", "necessary mediator", "cobbe-2021-verifiers"),
                ("difficulty-routed compute", "pre-outcome availability gate", "routing rule", "snell-2024-test-time-compute"),
            ),
            "On a fresh, sealed panel, compare answer-blind candidate selection with an equal-generation first-candidate control separately above and below the availability gate.",
        ),
        _Proposal(
            "state_actionability",
            OpportunityKind.LOAD_BEARING_ASSUMPTION,
            "Does state help because it is actionable, rather than merely because a task has many intermediate steps?",
            ("nye-2021-scratchpads", "huang-2023-self-correction"),
            "preserve prompt-required intermediate values until the final decision",
            ("prompt-derived state schema", "authenticated write/read replay", "no answer payload"),
            "a long context can contain state that the final decision never uses",
            "a state ledger whose writes, reads, and ablations are externally auditable",
            "Explicit state repairs a failure only when prompt-derived variables can be written, replayed, and causally read by the final decision; raw intermediate-state burden alone is insufficient.",
            "state retention or state-use failure",
            "state read/write fidelity mediates the explicit-state effect",
            ("declared variable lifetime", "state write/read coverage", "state replay hash"),
            "the correct final answer",
            "typed prompt-derived state ledger with replay versus a length-matched neutral ledger",
            "completed state writes are replayed and change the final decision under a state ablation",
            "paired final correctness after terminal scoring",
            "scratchpad intermediate computation",
            "explicit intermediate state",
            ("any longer scratchpad is a usable external state",),
            (
                "The treatment improves the registered state read/write mediator before any final-answer effect is interpreted.",
                "Replacing populated state with a same-length neutral ledger removes the effect on units with long variable lifetimes.",
            ),
            ("erase one required state field", "permute state-field order while preserving length"),
            ("every stored field is copied from the prompt or generated by the model and has a declared reader",),
            "The ledger is delivered but no declared state field is read or mediator ablation changes nothing.",
            (
                "A final-answer gain occurs without state read/write mediation or survives the state ablation.",
                "State actionability fails to transport to a fresh task family with the same declared variable-lifetime pattern.",
            ),
            (
                ("scratchpad step", "typed state field", "state mediator", "nye-2021-scratchpads"),
                ("intrinsic revision limit", "required external replay", "boundary condition", "huang-2023-self-correction"),
            ),
            "On matched high-lifetime tasks, compare typed replayable state with a length-matched neutral ledger and then erase one preregistered required field.",
        ),
    ),
    "verification_and_tools": (
        _Proposal(
            "verifier_selectivity",
            OpportunityKind.CONTRADICTION,
            "Can a generic revise prompt work when its checker cannot distinguish candidates, despite successful verifier-based selection elsewhere?",
            ("cobbe-2021-verifiers", "huang-2023-self-correction"),
            "select or revise a candidate using an informative answer-independent signal",
            ("candidate bank", "prompt-visible checker", "fixed repair map"),
            "self-critique can change text without improving the selected mechanism",
            "a verifier that creates a measurable candidate ordering and a checker-informed revision",
            "Verification repairs a reasoning failure only when an answer-independent checker creates a nondegenerate ordering over delivered candidates and the selected or revised candidate changes accordingly; a generic self-revise prompt is not a verification test.",
            "checker-uninformative revision failure",
            "checker selectivity and checker-conditioned action mediate verification",
            ("checker disagreement rate", "candidate rank changes", "checker-conditioned edit rate"),
            "whether the selected answer is correct",
            "candidate-bank verifier selection or checker-conditioned revision versus a neutral-message control",
            "the checker changes rank or edit decisions on a preregistered fraction of delivered candidates",
            "paired final correctness after terminal scoring",
            "verifier-guided candidate selection",
            "informative verifier selection",
            ("a second model pass is equivalent to verification",),
            (
                "Verification is evaluated only in the checker-selective stratum and beats its matched neutral-message control there.",
                "A checker-shuffled ablation removes the rank/edit mediator and any target effect.",
            ),
            ("shuffle checker verdicts across candidates", "hold candidate generation fixed and remove the checker from the revision prompt"),
            ("the checker cannot access gold or a transform of the answer",),
            "The checker has no nondegenerate ranking or the candidate action ignores its result.",
            (
                "Checker-selective verification has no mediator change while a matched generic message produces the same causal effect.",
                "The checker-shuffled ablation preserves the effect on a fresh panel.",
            ),
            (
                ("verifier rank", "answer-blind candidate ordering", "mediator", "cobbe-2021-verifiers"),
                ("external feedback", "checker-conditioned action", "intervention condition", "huang-2023-self-correction"),
            ),
            "Freeze a prompt-visible checker, pretest only its rank/edit mediator on a development partition, then compare true versus shuffled checker outputs on a sealed panel.",
        ),
        _Proposal(
            "tool_closure",
            OpportunityKind.BOTTLENECK,
            "Is an apparent tool null caused by missing knowledge, or by a broken request-execution-integration chain?",
            ("schick-2023-toolformer", "huang-2023-self-correction"),
            "use an external operation without supplying a final answer through the tool",
            ("prompt-defined request schema", "deterministic bounded tool", "post-tool integration step"),
            "a tool payload can be delivered without being correctly requested or used",
            "a closed tool channel with separate request, execution, and integration receipts",
            "Tools repair a reasoning failure only when prompt-defined request formation, bounded tool execution, and post-tool result integration each pass delivery checks; an undelivered or unused tool result is an invalid measurement, not a tool null.",
            "tool-interface closure failure",
            "request-execution-integration closure mediates the tool effect",
            ("request schema validity", "tool success receipt", "result-reference coverage"),
            "the correct final answer",
            "closed deterministic tool call and integration prompt versus a shape-matched null result",
            "each delivered treatment response cites a returned bounded subresult without requesting a final answer",
            "paired final correctness after terminal scoring",
            "tool-integrated language modeling",
            "API decision, invocation, and result incorporation",
            ("the presence of a tool result proves the model used it",),
            (
                "Only closure-certified units enter the tool efficacy estimand.",
                "Replacing the returned subresult with a schema-matched null removes the integration mediator and any benefit.",
            ),
            ("supply a balanced null tool result", "permit execution but remove the returned subresult from the integration prompt"),
            ("the tool can return only a bounded subresult and rejects final-answer requests",),
            "Any request, execution, or integration receipt is missing or fails its registered threshold.",
            (
                "A tool effect survives the null-result ablation without a result-use mediator.",
                "The closure gate does not predict tool delivery on a fresh task family.",
            ),
            (
                ("API decision", "prompt-defined request schema", "delivery stage", "schick-2023-toolformer"),
                ("external feedback", "returned bounded subresult", "causal input", "huang-2023-self-correction"),
            ),
            "On a fresh sealed panel, require a request, execution, and integration receipt before comparing a real bounded subresult with a shape-matched null result.",
        ),
    ),
    "representation_boundary": (
        _Proposal(
            "parameter_qualification",
            OpportunityKind.TENSION,
            "When does a parameter intervention demonstrate a repair that nonparametric channels could not deliver?",
            ("hu-2021-lora", "snell-2024-test-time-compute"),
            "separate a learned update from inference-time selection",
            ("disjoint adaptation data", "frozen update recipe", "matched sham", "qualified nonparametric controls"),
            "a parameter update can be mislabeled by a training leak, sham mismatch, or a weak compute baseline",
            "a separately qualified adaptation intervention with a disjoint development split and matched sham",
            "A parameter intervention is evidence of a parameter-repair route only when its frozen update passes a disjoint positive-control qualification and exceeds a matched sham after all nonparametric arms have passed delivery and manipulation checks; it is not evidence that representations are necessary.",
            "unqualified parameter-update comparison",
            "a delivered, disjoint parameter update mediates any claimed parameter repair",
            ("adaptation/evaluation disjointness", "positive-control pass", "sham-matched update receipt"),
            "whether nonparametric arms happen to be wrong",
            "frozen low-rank update versus point-free matched sham and unchanged base",
            "a qualified parameter intervention produces its registered positive-control effect without evaluation leakage",
            "paired final correctness after terminal scoring",
            "parameter-efficient adaptation",
            "low-rank parameter intervention",
            ("a zero from an inference-time method identifies a representation deficit",),
            (
                "The parameter arm is admitted only after its own disjoint positive control and sham-matching checks pass.",
                "On delivery-certified units, a parameter effect that survives the sham comparison remains a parameter-route finding, not a necessity finding.",
            ),
            ("shuffle development labels in the sham", "remove the trained update while holding parameter runtime fixed"),
            ("adaptation examples, evaluation prompts, and gold authority remain disjoint",),
            "The update lacks a positive-control effect, breaks disjointness, or cannot beat its matched sham.",
            (
                "A claimed parameter effect is unchanged by the sham or by removing the trained update.",
                "The positive-control qualification fails on either allowed model configuration.",
            ),
            (
                ("low-rank update", "frozen parameter intervention", "treatment", "hu-2021-lora"),
                ("compute allocation baseline", "qualified nonparametric comparison", "contrast", "snell-2024-test-time-compute"),
            ),
            "First run the frozen update and sham on disjoint positive-control tasks; only then compare the qualified update with qualified nonparametric arms on a new sealed panel.",
        ),
        _Proposal(
            "representation_abstention",
            OpportunityKind.LOAD_BEARING_ASSUMPTION,
            "Can final-answer floors alone identify a failure as representation-required?",
            ("huang-2023-self-correction", "hu-2021-lora"),
            "make a representation-required claim without using an uninformative final-answer floor",
            ("delivery-certified nonparametric arms", "answer-blind mediator checks", "qualified parameter success"),
            "a final-answer null confounds delivery, candidate generation, selection, and latent competence",
            "an explicit abstention class: unidentified within the tested repair envelope",
            "A failure may be called representation-required only if all qualified nonparametric routes fail their declared mediators and a separately qualified parameter intervention succeeds on the same preregistered failure stratum; otherwise it remains unidentified within the tested envelope.",
            "overclaimed representation requirement",
            "the joint pattern of qualified nonparametric mediator failure plus parameter success identifies the claim boundary",
            ("delivery and mediator certificates for every nonparametric arm", "parameter positive-control qualification", "same-stratum frozen comparison"),
            "the correct answers during routing or feature extraction",
            "a preregistered abstention/representation decision rule applied only after terminal scoring",
            "all nonparametric mediator checks fail while the parameter intervention passes its qualified effect criterion",
            "claim-boundary classification after terminal scoring",
            "intrinsic self-correction limits",
            "limits of uninformative internal revision",
            ("a correctness floor alone diagnoses missing learned representation",),
            (
                "A complete final-answer floor without the required mediator and parameter evidence is classified unidentified, never representation-required.",
                "A representation-required label transports only if the entire joint evidence pattern repeats on a new model or family.",
            ),
            ("withhold the parameter positive-control certificate", "replace the parameter effect with its sham effect in the decision rule"),
            ("the rule is frozen before prospective outcome access and cannot route on correctness",),
            "Any evidence cell is delivery-invalid, mediator-undefined, or lacks a successful qualified parameter intervention.",
            (
                "The representation label is assigned when the parameter intervention is unqualified or ineffective.",
                "The label remains after substituting an all-tie boundary-aware interval that does not exclude practical benefit.",
            ),
            (
                ("intrinsic correction limit", "nonparametric mediator failure", "insufficient condition", "huang-2023-self-correction"),
                ("qualified low-rank update", "separate parameter-route evidence", "necessary additional evidence", "hu-2021-lora"),
            ),
            "Pre-register the abstention rule, then use a boundary-aware paired analysis to compare it with the prohibited floor-only rule on a fresh sealed panel.",
        ),
    ),
}


def _source_span(source_id: str) -> PrimarySourceSpan:
    source = SOURCE_BY_ID[source_id]
    return PrimarySourceSpan(
        work_id=source.work_id,
        locator=source.locator,
        section="Abstract",
        excerpt=source.excerpt,
        supports=source.supports,
    )


def _hypothesis(
    *,
    brief: HypothesisForgeBrief,
    proposal: _Proposal,
) -> CausalHypothesisContract:
    return CausalHypothesisContract(
        target_node_id=brief.target_node_id,
        discovery_channel=brief.channel_id,
        research_object="answer-blind repairability routing for small-model reasoning failures",
        statement=proposal.statement,
        target_failure=proposal.target_failure,
        causal_mechanism=proposal.causal_mechanism,
        observed_information=proposal.observed_information,
        unavailable_or_latent_information=proposal.unavailable_information,
        intervention=proposal.intervention,
        mediator=proposal.mediator,
        outcome=proposal.outcome,
        source_domain=proposal.source_domain,
        source_mechanism=proposal.source_mechanism,
        relational_mappings=tuple(
            RelationalMapping(source, target, role)
            for source, target, role, _ in proposal.mappings
        ),
        broken_assumptions=proposal.broken_assumptions,
        distinguishing_predictions=proposal.predictions,
        ablations=proposal.ablations,
        boundary_conditions=proposal.boundary_conditions,
        expected_failure=proposal.expected_failure,
        falsification_conditions=proposal.falsifiers,
        mechanism_fingerprint=MechanismFingerprint(
            information_used=proposal.observed_information,
            state_or_memory=proposal.mediator,
            inference_horizon="pre-outcome intervention routing followed by terminal scoring",
            coupling_scope="one model-task-treatment matched unit",
            optimization_object="causal repair assignment with an explicit abstention class",
            intervention_structure=proposal.intervention,
            fallback_or_control="resource-matched sham or control plus delivery gate",
            known_family="answer-blind reasoning repairability",
            computational_topology="source-grounded mediator gate",
        ),
        literature_refs=proposal.source_ids,
        generator_ref=REPAIRABILITY_HYPOTHESIS_FORGE_VERSION,
        cross_domain=False,
    )


class RepairabilityHypothesisForge:
    """A deterministic, source-grounded proposer for this specific research goal.

    It is intentionally deterministic: this run tests whether the new forge
    changes the *hypothesis contract*.  It does not present an LLM's prose as
    experimental evidence or claim that a creative model has been validated.
    """

    name = "repairability-source-grounded-forge"
    generator_version = REPAIRABILITY_HYPOTHESIS_FORGE_VERSION

    def forge(
        self,
        *,
        brief: HypothesisForgeBrief,
        count: int,
    ) -> HypothesisForgePortfolio:
        candidates = PROPOSALS_BY_CHANNEL.get(brief.channel_id)
        if candidates is None:
            raise ValueError("repairability forge received an unknown channel")
        if count != len(candidates):
            raise ValueError("repairability forge requires exactly two proposals per channel")
        required_sources = {source_id for proposal in candidates for source_id in proposal.source_ids}
        if not required_sources.issubset(brief.source_work_ids):
            raise ValueError("repairability forge brief omitted a required primary source")
        source_spans = tuple(
            _source_span(source_id)
            for source_id in sorted(required_sources)
        )
        span_by_work = {span.work_id: span for span in source_spans}
        opportunities = tuple(
            ResearchOpportunity(
                target_node_id=brief.target_node_id,
                kind=proposal.opportunity_kind,
                question=proposal.question,
                source_span_ids=tuple(span_by_work[source_id].span_id for source_id in proposal.source_ids),
                confirmation_stakes=(
                    "Confirmation changes the registered routing and preserves a falsifiable causal mediator."
                ),
                refutation_stakes=(
                    "Refutation removes this route from prospective repair assignment without relabelling its null as representation need."
                ),
                kill_check=proposal.falsifiers[0],
            )
            for proposal in candidates
        )
        signatures = tuple(
            StructuralProblemSignature(
                opportunity_id=opportunity.opportunity_id,
                objective=proposal.objective,
                constraints=proposal.constraints,
                hardness=proposal.hardness,
                solution_shape=proposal.solution_shape,
                builder_ref=REPAIRABILITY_HYPOTHESIS_FORGE_VERSION,
            )
            for proposal, opportunity in zip(candidates, opportunities)
        )
        proposals = tuple(
            ForgedCausalHypothesis(
                hypothesis=_hypothesis(brief=brief, proposal=proposal),
                opportunity_id=opportunity.opportunity_id,
                signature_id=signature.signature_id,
                source_domain=proposal.source_domain,
                mappings=tuple(
                    StructuralTransferMapping(
                        source_element=source,
                        target_element=target,
                        causal_role=role,
                        source_span_id=span_by_work[source_id].span_id,
                    )
                    for source, target, role, source_id in proposal.mappings
                ),
                first_discriminating_experiment=proposal.first_experiment,
            )
            for proposal, opportunity, signature in zip(candidates, opportunities, signatures)
        )
        return HypothesisForgePortfolio(
            brief=brief,
            source_spans=source_spans,
            opportunities=opportunities,
            signatures=signatures,
            proposals=proposals,
            selected_hypothesis_ids=tuple(item.hypothesis.hypothesis_id for item in proposals),
            proposer_ref=self.name,
        )


def build_answer_blind_prospective_protocol(
    portfolios: Sequence[HypothesisForgePortfolio],
) -> Dict[str, Any]:
    """Freeze the decision boundary required before prospective model outcomes.

    The protocol contains no evaluation answers, scored correctness, raw model
    responses, or post-intervention measurements.  Its role is to prevent the
    old study's floor and nondelivery results from being reinterpreted as a
    representation diagnosis.
    """

    portfolios = tuple(portfolios)
    if {item.brief.channel_id for item in portfolios} != {item.channel_id for item in CHANNELS}:
        raise ValueError("repairability protocol requires one portfolio per channel")
    hypotheses = tuple(
        hypothesis
        for portfolio in portfolios
        for hypothesis in portfolio.selected_hypotheses()
    )
    if len(hypotheses) != 6:
        raise ValueError("repairability protocol requires six competing hypotheses")
    return {
        "version": REPAIRABILITY_HYPOTHESIS_FORGE_VERSION,
        "target_node_id": TARGET_NODE_ID,
        "status": "theory_frozen_model_outcomes_not_generated",
        "source_portfolio_ids": [item.portfolio_id for item in portfolios],
        "hypothesis_ids": [item.hypothesis_id for item in hypotheses],
        "answer_blind_inputs": [
            "prompt-derived dependency depth, variable lifetime, and constraint identifiers",
            "parseability and delivery telemetry",
            "prompt-visible necessary-constraint validity and candidate disagreement from gold-blind probes",
            "state write/read replay receipts",
            "checker selectivity, rank/edit changes, and checker-shuffle ablations",
            "tool request, execution, and result-integration receipts",
            "adaptation/evaluation disjointness, sham matching, and parameter positive-control qualification",
        ],
        "forbidden_routing_inputs": [
            "evaluation answers or answer transforms",
            "correctness, reward, or intervention outcome from a prospective unit",
            "raw evaluation responses",
            "a floor-only inference that a representation or parameter update is required",
        ],
        "registered_gates": [
            "Run each repair efficacy estimand only after the corresponding delivery and mediator gate passes.",
            "Use a disjoint development partition to pre-register a competence band and a boundary-aware paired interval before opening prospective outcomes.",
            "Classify delivery failure, missing mediator, or complete-floor evidence as invalid or unidentified within the tested envelope.",
            "Permit a representation-required label only after every nonparametric mediator fails and a separately qualified parameter intervention succeeds in the same frozen stratum.",
            "Require a fresh model or task-family replication before transporting any repair rule.",
        ],
        "prospective_outputs": [
            "pre-outcome repair probabilities including an unidentified-within-budget class",
            "delivery, manipulation, mediator, and efficacy reports kept separate",
            "boundary-aware paired effect intervals and a claim-boundary certificate",
        ],
        "model_calls": 0,
        "raw_model_responses_read": False,
        "evaluation_answers_read": False,
    }
