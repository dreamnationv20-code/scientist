"""Held-out finite-state transition task for parameter-route qualification.

The evaluation prompt never states the transition table.  Treatment training
installs the table through examples; a matched sham sees identical prompts and
a fixed derangement of every target label.  Evaluation requires transfer to
new surface forms and to longer, unseen operation compositions.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import random
from typing import Any, Mapping, Sequence


VERSION = "cognitive-repairability-novel-transition-parameter-v1"
ROOT = "repairability_novel_transition_parameter_v1"
MODEL_KEY = "qwen2p5_3b"
SEED = 861_001_006
LABELS = ("A", "B", "C", "D")
OPERATORS = ("lorn", "vesk", "daro", "peln")
CHECKPOINTS = (40, 80, 120, 160)
TRAINING_COUNT = 240
POSITIVE_CONTROL_COUNT = 80
DEVELOPMENT_COUNT = 64
PROSPECTIVE_COUNT = 96

# Four non-identical permutations.  The pair generates non-commuting
# compositions, so success on longer tapes cannot be obtained from an operator
# bag or a single output-label prior.
TRANSITIONS: Mapping[str, tuple[int, int, int, int]] = {
    "lorn": (1, 2, 3, 0),
    "vesk": (1, 0, 3, 2),
    "daro": (2, 3, 0, 1),
    "peln": (0, 3, 2, 1),
}
SHAM_LABEL = {"A": "B", "B": "C", "C": "D", "D": "A"}


def digest(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    ).hexdigest()


def file_sha256(path: Any) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def jsonl(rows: Sequence[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n" for row in rows)


def read_rows(path: Any) -> list[Mapping[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def apply_tape(start: str, tape: Sequence[str]) -> str:
    state = LABELS.index(start)
    for operator in tape:
        state = TRANSITIONS[operator][state]
    return LABELS[state]


def _render(start: str, tape: Sequence[str], style: int) -> str:
    joined_arrow = " > ".join(tape)
    joined_space = " ".join(tape)
    templates = {
        0: (
            "Neralis register exercise.\n"
            f"Initial register: {start}\nInstruction tape: {joined_arrow}\n"
            "After executing the tape from left to right, which register is active?"
        ),
        1: (
            "Run the learned Neralis state protocol.\n"
            f"The register begins at {start}.\nApply in order: {joined_space}.\n"
            "Report the final register."
        ),
        2: (
            f"Protocol Neralis starts in register {start}. The ordered commands are "
            f"{', then '.join(tape)}. Which register remains at the end?"
        ),
        3: (
            "Use the memorized Neralis transition convention.\n"
            f"START={start}\nTAPE={joined_arrow}\nFINAL REGISTER?"
        ),
        4: (
            f"A Neralis machine is initialized to {start}. It receives, in sequence, "
            f"{', '.join(tape)}. Name its state after the last command."
        ),
        5: (
            "Complete this Neralis trace using the learned transition system.\n"
            f"origin register: {start}\nordered operations: {joined_space}\n"
            "terminal register:"
        ),
        6: (
            f"Beginning with Neralis state {start}, process {joined_arrow} without "
            "reordering any operation. Select the resulting state."
        ),
    }
    return templates[style] + "\n\nReturn only one letter: A, B, C, or D."


def _public_task(split: str, index: int, start: str, tape: Sequence[str], style: int) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    task_id = f"ntp1-{split}-{index:03d}"
    prompt = _render(start, tape, style)
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": split,
        "surface_style": style,
        "composition_length": len(tape),
        "prompt": prompt,
        "valid_labels": list(LABELS),
    }
    authority = {
        "task_id": task_id,
        "answer": apply_tape(start, tape),
        "start": start,
        "tape": list(tape),
        "semantic_key": f"{start}|{'/'.join(tape)}",
    }
    return public, authority


def _messages(task: Mapping[str, Any], answer: str) -> list[Mapping[str, str]]:
    return [
        {
            "role": "system",
            "content": "Apply the learned Neralis protocol. Return only the final register letter.",
        },
        {"role": "user", "content": str(task["prompt"])},
        {"role": "assistant", "content": answer},
    ]


def _all_cases(length: int) -> list[tuple[str, tuple[str, ...]]]:
    return [
        (start, tuple(tape))
        for start in LABELS
        for tape in itertools.product(OPERATORS, repeat=length)
    ]


def _balanced_cases(length: int, count: int, seed: int) -> list[tuple[str, tuple[str, ...]]]:
    if count % len(LABELS):
        raise ValueError("balanced panel size must be divisible by four")
    groups = {label: [] for label in LABELS}
    for case in _all_cases(length):
        groups[apply_tape(*case)].append(case)
    selected: list[tuple[str, tuple[str, ...]]] = []
    for offset, label in enumerate(LABELS):
        values = groups[label]
        random.Random(seed + offset).shuffle(values)
        selected.extend(values[: count // len(LABELS)])
    random.Random(seed + 100).shuffle(selected)
    if len(selected) != count:
        raise RuntimeError("insufficient balanced transition cases")
    return selected


def build_panel() -> Mapping[str, list[Mapping[str, Any]]]:
    # Training exhaustively covers every one- and two-step semantic case under
    # three surfaces.  Evaluation surfaces are disjoint.  Development and
    # prospective cases require new three- and four-step compositions.
    primitive_cases = _all_cases(1) + _all_cases(2)
    training: list[Mapping[str, Any]] = []
    positive_public: list[Mapping[str, Any]] = []
    positive_authority: list[Mapping[str, Any]] = []
    for style in (0, 1, 2):
        for index, (start, tape) in enumerate(primitive_cases):
            task, authority = _public_task("adaptation", style * len(primitive_cases) + index, start, tape, style)
            answer = str(authority["answer"])
            training.append(
                {
                    "task_id": task["task_id"],
                    "messages": _messages(task, answer),
                    "sham_messages": _messages(task, SHAM_LABEL[answer]),
                    "semantic_key": authority["semantic_key"],
                    "surface_style": style,
                }
            )
    for index, (start, tape) in enumerate(primitive_cases):
        task, authority = _public_task("positive_control", index, start, tape, 3)
        positive_public.append(task)
        positive_authority.append(authority)

    development_public: list[Mapping[str, Any]] = []
    development_authority: list[Mapping[str, Any]] = []
    for index, (start, tape) in enumerate(_balanced_cases(3, DEVELOPMENT_COUNT, SEED + 1)):
        task, authority = _public_task("development", index, start, tape, 4)
        development_public.append(task)
        development_authority.append(authority)

    prospective_public: list[Mapping[str, Any]] = []
    prospective_authority: list[Mapping[str, Any]] = []
    for index, (start, tape) in enumerate(_balanced_cases(4, PROSPECTIVE_COUNT, SEED + 2)):
        task, authority = _public_task("prospective", index, start, tape, 5 + index % 2)
        prospective_public.append(task)
        prospective_authority.append(authority)

    panels: Mapping[str, list[Mapping[str, Any]]] = {
        "training": training,
        "positive_control": positive_public,
        "positive_control_authority": positive_authority,
        "development": development_public,
        "development_authority": development_authority,
        "prospective": prospective_public,
        "prospective_authority": prospective_authority,
    }
    _validate_panel(panels)
    return panels


def _validate_panel(panels: Mapping[str, list[Mapping[str, Any]]]) -> None:
    expected = {
        "training": TRAINING_COUNT,
        "positive_control": POSITIVE_CONTROL_COUNT,
        "positive_control_authority": POSITIVE_CONTROL_COUNT,
        "development": DEVELOPMENT_COUNT,
        "development_authority": DEVELOPMENT_COUNT,
        "prospective": PROSPECTIVE_COUNT,
        "prospective_authority": PROSPECTIVE_COUNT,
    }
    if {key: len(panels[key]) for key in expected} != expected:
        raise RuntimeError("novel-transition panel size mismatch")
    train_prompts = [str(row["messages"][1]["content"]) for row in panels["training"]]
    eval_prompts = [
        str(row["prompt"])
        for split in ("positive_control", "development", "prospective")
        for row in panels[split]
    ]
    if len(set(train_prompts)) != len(train_prompts) or len(set(eval_prompts)) != len(eval_prompts):
        raise RuntimeError("duplicate prompt detected")
    if set(train_prompts) & set(eval_prompts):
        raise RuntimeError("training/evaluation prompt overlap")
    if {row["surface_style"] for row in panels["training"]} & {
        row["surface_style"] for split in ("positive_control", "development", "prospective") for row in panels[split]
    }:
        raise RuntimeError("training/evaluation surface overlap")
    for split in ("positive_control", "development", "prospective"):
        public_ids = [row["task_id"] for row in panels[split]]
        authority = panels[f"{split}_authority"]
        if public_ids != [row["task_id"] for row in authority]:
            raise RuntimeError(f"{split} public/authority mismatch")
        counts = {label: sum(row["answer"] == label for row in authority) for label in LABELS}
        if len(set(counts.values())) != 1:
            raise RuntimeError(f"{split} answers are not balanced")
    correct = [str(row["messages"][-1]["content"]) for row in panels["training"]]
    sham = [str(row["sham_messages"][-1]["content"]) for row in panels["training"]]
    if any(left == right for left, right in zip(correct, sham, strict=True)):
        raise RuntimeError("sham label is not deranged")
    if {label: correct.count(label) for label in LABELS} != {label: sham.count(label) for label in LABELS}:
        raise RuntimeError("treatment and sham label marginals differ")

