"""Fresh candidate-token-only successor for parameter-route qualification."""
from __future__ import annotations

import itertools
import random
from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.repairability_novel_transition_parameter_v1 import (
    digest,
    file_sha256,
    jsonl,
    read_rows,
)


VERSION = "cognitive-repairability-novel-transition-parameter-v2"
ROOT = "repairability_novel_transition_parameter_v2"
MODEL_KEY = "qwen2p5_3b"
SEED = 861_002_006
LABELS = ("A", "B", "C", "D")
OPERATORS = ("nuvet", "sarka", "bilem", "toru")
CHECKPOINTS = (20, 40, 60, 80)
TRAINING_COUNT = 240
POSITIVE_CONTROL_COUNT = 80
DEVELOPMENT_COUNT = 64
PROSPECTIVE_COUNT = 96
TRANSITIONS: Mapping[str, tuple[int, int, int, int]] = {
    "nuvet": (1, 2, 3, 0),
    "sarka": (3, 0, 1, 2),
    "bilem": (1, 0, 3, 2),
    "toru": (0, 3, 2, 1),
}
SHAM_LABEL = {"A": "B", "B": "C", "C": "D", "D": "A"}


def apply_tape(start: str, tape: Sequence[str]) -> str:
    state = LABELS.index(start)
    for operator in tape:
        state = TRANSITIONS[operator][state]
    return LABELS[state]


def _render(start: str, tape: Sequence[str], style: int) -> str:
    arrow = " -> ".join(tape)
    space = " ".join(tape)
    templates = {
        0: (
            "Tavren register drill.\n"
            f"Opening state: {start}\nCommand ribbon: {arrow}\n"
            "Execute from left to right. Which state is active afterward?"
        ),
        1: (
            "Apply the learned Tavren state convention.\n"
            f"The device opens at {start}.\nOrdered commands: {space}.\n"
            "Report the closing state."
        ),
        2: (
            f"A Tavren register begins at {start}. Process {', followed by '.join(tape)}. "
            "Which register is active at completion?"
        ),
        3: (
            "Use the memorized Tavren transition protocol.\n"
            f"ORIGIN={start}\nRIBBON={arrow}\nTERMINAL STATE?"
        ),
        4: (
            f"Initialize a Tavren machine in state {start}. Its instruction sequence is "
            f"{', '.join(tape)}. Select the state after the final instruction."
        ),
        5: (
            "Finish this Tavren trace using its learned transition system.\n"
            f"opening register: {start}\noperation order: {space}\n"
            "closing register:"
        ),
        6: (
            f"Starting from Tavren state {start}, carry out {arrow} in the displayed order. "
            "Which state results?"
        ),
    }
    return templates[style] + "\n\nReturn only A, B, C, or D."


def _task(split: str, index: int, start: str, tape: Sequence[str], style: int) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    task_id = f"ntp2-{split}-{index:03d}"
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": split,
        "surface_style": style,
        "composition_length": len(tape),
        "prompt": _render(start, tape, style),
        "valid_labels": list(LABELS),
    }
    authority = {
        "task_id": task_id,
        "answer": apply_tape(start, tape),
        "start": start,
        "tape": list(tape),
        "semantic_key": f"{start}|{'/'.join(tape)}",
    }
    return public, authority


def _messages(task: Mapping[str, Any], answer: str) -> list[Mapping[str, str]]:
    return [
        {"role": "system", "content": "Apply the learned Tavren protocol. Return only the final state letter."},
        {"role": "user", "content": str(task["prompt"])},
        {"role": "assistant", "content": answer},
    ]


def _all_cases(length: int) -> list[tuple[str, tuple[str, ...]]]:
    return [(start, tuple(tape)) for start in LABELS for tape in itertools.product(OPERATORS, repeat=length)]


def _balanced_cases(length: int, count: int, seed: int) -> list[tuple[str, tuple[str, ...]]]:
    if count % 4:
        raise ValueError("panel size must be divisible by four")
    by_answer = {label: [] for label in LABELS}
    for case in _all_cases(length):
        by_answer[apply_tape(*case)].append(case)
    selected: list[tuple[str, tuple[str, ...]]] = []
    for offset, label in enumerate(LABELS):
        values = by_answer[label]
        random.Random(seed + offset).shuffle(values)
        selected.extend(values[: count // 4])
    random.Random(seed + 100).shuffle(selected)
    if len(selected) != count:
        raise RuntimeError("insufficient balanced cases")
    return selected


def build_panel() -> Mapping[str, list[Mapping[str, Any]]]:
    primitives = _all_cases(1) + _all_cases(2)
    training: list[Mapping[str, Any]] = []
    for style in (0, 1, 2):
        for index, (start, tape) in enumerate(primitives):
            task, authority = _task("adaptation", style * len(primitives) + index, start, tape, style)
            answer = str(authority["answer"])
            training.append(
                {
                    "task_id": task["task_id"],
                    "messages": _messages(task, answer),
                    "sham_messages": _messages(task, SHAM_LABEL[answer]),
                    "semantic_key": authority["semantic_key"],
                    "surface_style": style,
                }
            )

    positive: list[Mapping[str, Any]] = []
    positive_authority: list[Mapping[str, Any]] = []
    for index, (start, tape) in enumerate(primitives):
        task, authority = _task("positive_control", index, start, tape, 3)
        positive.append(task)
        positive_authority.append(authority)

    development: list[Mapping[str, Any]] = []
    development_authority: list[Mapping[str, Any]] = []
    for index, (start, tape) in enumerate(_balanced_cases(3, DEVELOPMENT_COUNT, SEED + 1)):
        task, authority = _task("development", index, start, tape, 4)
        development.append(task)
        development_authority.append(authority)

    prospective: list[Mapping[str, Any]] = []
    prospective_authority: list[Mapping[str, Any]] = []
    for index, (start, tape) in enumerate(_balanced_cases(4, PROSPECTIVE_COUNT, SEED + 2)):
        task, authority = _task("prospective", index, start, tape, 5 + index % 2)
        prospective.append(task)
        prospective_authority.append(authority)

    panel: Mapping[str, list[Mapping[str, Any]]] = {
        "training": training,
        "positive_control": positive,
        "positive_control_authority": positive_authority,
        "development": development,
        "development_authority": development_authority,
        "prospective": prospective,
        "prospective_authority": prospective_authority,
    }
    _validate(panel)
    return panel


def _validate(panel: Mapping[str, list[Mapping[str, Any]]]) -> None:
    expected = {
        "training": TRAINING_COUNT,
        "positive_control": POSITIVE_CONTROL_COUNT,
        "positive_control_authority": POSITIVE_CONTROL_COUNT,
        "development": DEVELOPMENT_COUNT,
        "development_authority": DEVELOPMENT_COUNT,
        "prospective": PROSPECTIVE_COUNT,
        "prospective_authority": PROSPECTIVE_COUNT,
    }
    if {key: len(panel[key]) for key in expected} != expected:
        raise RuntimeError("v2 panel size mismatch")
    training_prompts = [str(row["messages"][1]["content"]) for row in panel["training"]]
    evaluation_prompts = [str(row["prompt"]) for split in ("positive_control", "development", "prospective") for row in panel[split]]
    if len(set(training_prompts)) != len(training_prompts) or len(set(evaluation_prompts)) != len(evaluation_prompts):
        raise RuntimeError("duplicate prompt")
    if set(training_prompts) & set(evaluation_prompts):
        raise RuntimeError("training/evaluation prompt overlap")
    if any("Neralis" in prompt or any(word in prompt for word in ("lorn", "vesk", "daro", "peln")) for prompt in training_prompts + evaluation_prompts):
        raise RuntimeError("v1 vocabulary leaked into v2")
    for split in ("positive_control", "development", "prospective"):
        authority = panel[f"{split}_authority"]
        if [row["task_id"] for row in panel[split]] != [row["task_id"] for row in authority]:
            raise RuntimeError(f"{split} identity mismatch")
        counts = {label: sum(row["answer"] == label for row in authority) for label in LABELS}
        if len(set(counts.values())) != 1:
            raise RuntimeError(f"{split} labels are unbalanced")
    correct = [str(row["messages"][-1]["content"]) for row in panel["training"]]
    sham = [str(row["sham_messages"][-1]["content"]) for row in panel["training"]]
    if any(SHAM_LABEL[left] != right for left, right in zip(correct, sham, strict=True)):
        raise RuntimeError("sham is not the frozen derangement")
    if {label: correct.count(label) for label in LABELS} != {label: sham.count(label) for label in LABELS}:
        raise RuntimeError("treatment/sham label marginals differ")
