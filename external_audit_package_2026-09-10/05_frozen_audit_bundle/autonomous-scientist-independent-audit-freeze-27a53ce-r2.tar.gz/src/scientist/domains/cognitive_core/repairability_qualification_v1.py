from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


VERSION = "cognitive-repairability-qualification-v1"
AUTHORIZATION_RECORD_ID = (
    "c1dabeb05a3c6deaf84efc04f49bc68867d2e143de05485b9bacb696a743cbc2"
)
CANONICAL_GRAPH_ID = (
    "e2700626cbbd3bbf86ad6fdd43890a30c719e94ae555d8f182f4672ac941b4ec"
)

MODEL_CONTRACT = (
    {
        "key": "qwen3_1p7b",
        "parameter_class": "1.7B",
        "repository": "Qwen/Qwen3-1.7B-MLX-4bit",
        "revision": "21457c6f51ed54a7c16e988c0844db973815c137",
    },
    {
        "key": "qwen2p5_3b",
        "parameter_class": "3B",
        "repository": "mlx-community/Qwen2.5-3B-Instruct-4bit",
        "revision": "4f83f8f146fdf28b512a06562b671d7af4fab457",
    },
)

REPAIR_CLASSES = (
    "compute",
    "explicit_state",
    "verification",
    "tools",
    "parameter_or_representation_change",
)

UNITS_PER_CLASS_AND_MODEL = 5
ADAPTATION_EXAMPLES_PER_MODEL = 64


def _seed(*parts: str) -> int:
    body = "\x1f".join((VERSION, *parts)).encode("utf-8")
    return int.from_bytes(hashlib.sha256(body).digest()[:8], "big")


def _answer_digest(task_id: str, answer: str) -> str:
    return hashlib.sha256(
        (VERSION + "\x1f" + task_id + "\x1f" + answer).encode("utf-8")
    ).hexdigest()


def _compute_task(model_key: str, index: int) -> tuple[Dict[str, Any], Dict[str, Any]]:
    rng = random.Random(_seed(model_key, "compute", str(index)))
    people = ["Ari", "Bea", "Cy", "Dee", "Eli"]
    rng.shuffle(people)
    positions = {person: rank + 1 for rank, person in enumerate(people)}
    answer = people[2]
    constraints = []
    for left, right in zip(people, people[1:]):
        constraints.append(f"{left} finished before {right}.")
    distractor_pairs = [(people[0], people[3]), (people[1], people[4])]
    rng.shuffle(distractor_pairs)
    constraints.extend(
        f"{left} did not finish after {right}." for left, right in distractor_pairs
    )
    rng.shuffle(constraints)
    prompt = (
        "Five runners Ari, Bea, Cy, Dee, and Eli occupy distinct positions 1 "
        "through 5. Use every constraint and determine who finished third.\n"
        + "\n".join(f"- {item}" for item in constraints)
        + "\nReturn only the runner name."
    )
    task_id = f"qual-{model_key}-compute-{index:02d}"
    public = {
        "task_id": task_id,
        "model_key": model_key,
        "repair_class": "compute",
        "control_index": index,
        "prompt": prompt,
        "maximum_new_tokens": 192,
        "treatment_contract": "frozen_width2_depth3_decomposition_search",
        "matched_control_contract": "equal_cost_uniform_generation",
        "prompt_visible_constraints": constraints,
        "answer_blind_payload": {
            "subproblem_axes": [
                "derive precedence closure",
                "enumerate feasible middle positions",
                "cross-check every stated constraint",
            ],
            "retention_rule": "retain branches agreeing on all prompt-visible constraints",
        },
    }
    authority = {
        "task_id": task_id,
        "answer": answer,
        "complete_order": people,
        "positions": positions,
        "scorer": "exact_casefolded_name",
    }
    return public, authority


def _state_task(model_key: str, index: int) -> tuple[Dict[str, Any], Dict[str, Any]]:
    rng = random.Random(_seed(model_key, "explicit_state", str(index)))
    keys = ["copper", "jade", "amber", "silver", "indigo", "pearl"]
    rng.shuffle(keys)
    values = rng.sample(range(21, 90), len(keys))
    records = dict(zip(keys, values))
    target = keys[index % len(keys)]
    offset = rng.choice((7, 11, 13, 17))
    modulus = rng.choice((5, 7, 9))
    answer = str((records[target] + offset) % modulus)
    distractors = [
        f"Archive note {number}: status={rng.choice(('open', 'closed', 'queued'))}."
        for number in range(1, 13)
    ]
    prompt = (
        "Read the registry, then process the unrelated archive notes. The final "
        "query depends on one earlier registry value.\nREGISTRY\n"
        + "\n".join(f"{key}={value}" for key, value in records.items())
        + "\nARCHIVE\n"
        + "\n".join(distractors)
        + f"\nFINAL QUERY: Compute ({target} + {offset}) mod {modulus}. "
        "Return only the integer."
    )
    state_payload = {
        "slot": "required_registry_value",
        "key": target,
        "value": records[target],
        "provenance": "verbatim_prompt_registry",
    }
    sham_key = keys[(keys.index(target) + 1) % len(keys)]
    sham_payload = {
        "slot": "required_registry_value",
        "key": sham_key,
        "value": records[sham_key],
        "provenance": "verbatim_prompt_registry_irrelevant_control",
    }
    task_id = f"qual-{model_key}-explicit-state-{index:02d}"
    public = {
        "task_id": task_id,
        "model_key": model_key,
        "repair_class": "explicit_state",
        "control_index": index,
        "prompt": prompt,
        "maximum_new_tokens": 96,
        "treatment_contract": "typed_key_value_state",
        "matched_control_contract": "cost_matched_irrelevant_state",
        "answer_blind_payload": state_payload,
        "sham_payload": sham_payload,
        "payload_is_final_answer": False,
    }
    authority = {
        "task_id": task_id,
        "answer": answer,
        "target_key": target,
        "target_value": records[target],
        "offset": offset,
        "modulus": modulus,
        "scorer": "exact_integer",
    }
    return public, authority


def _verification_task(
    model_key: str, index: int
) -> tuple[Dict[str, Any], Dict[str, Any]]:
    rng = random.Random(_seed(model_key, "verification", str(index)))
    digits = rng.sample(range(1, 10), 3)
    answer = "".join(str(item) for item in digits)
    total = sum(digits)
    delta_ab = digits[0] - digits[1]
    delta_bc = digits[1] - digits[2]
    constraints = [
        "C1: The code has exactly three distinct nonzero decimal digits.",
        f"C2: The digits sum to {total}.",
        f"C3: first minus second equals {delta_ab}.",
        f"C4: second minus third equals {delta_bc}.",
    ]
    prompt = (
        "Find the unique three-digit code satisfying all declared constraints.\n"
        + "\n".join(constraints)
        + "\nReturn only the code."
    )
    task_id = f"qual-{model_key}-verification-{index:02d}"
    public = {
        "task_id": task_id,
        "model_key": model_key,
        "repair_class": "verification",
        "control_index": index,
        "prompt": prompt,
        "maximum_new_tokens": 128,
        "treatment_contract": "six_candidates_prompt_constraint_checker",
        "matched_control_contract": "balanced_sham_checker",
        "prompt_visible_constraints": constraints,
        "checker_output_schema": {
            "valid": "boolean",
            "violated_constraint_ids": "list drawn only from C1,C2,C3,C4",
        },
        "checker_forbidden_fields": [
            "correct_code",
            "correct_digit",
            "distance_to_answer",
            "repair_instruction",
        ],
    }
    authority = {
        "task_id": task_id,
        "answer": answer,
        "digits": digits,
        "constraint_parameters": {
            "sum": total,
            "delta_ab": delta_ab,
            "delta_bc": delta_bc,
        },
        "scorer": "exact_three_digit_code",
    }
    return public, authority


def _tool_task(model_key: str, index: int) -> tuple[Dict[str, Any], Dict[str, Any]]:
    rng = random.Random(_seed(model_key, "tools", str(index)))
    nodes = ["A", "B", "C", "D", "E"]
    edges = []
    for left, right in zip(nodes, nodes[1:]):
        edges.append((left, right, rng.randint(2, 9)))
    edges.extend(
        [
            ("A", "C", rng.randint(6, 14)),
            ("B", "D", rng.randint(6, 14)),
            ("C", "E", rng.randint(6, 14)),
        ]
    )
    offset = rng.randint(3, 12)
    shortest = _shortest_path(edges, "A", "E")
    answer = "EVEN" if (shortest + offset) % 2 == 0 else "ODD"
    prompt = (
        "A local route service exposes shortest_path(start,end) for a hidden "
        "weighted map. Call it for A to E. Then add the public offset "
        f"{offset} to the returned distance and answer EVEN or ODD. The tool "
        "distance is a subresult, not the requested parity.\nReturn exactly one "
        "of EVEN or ODD."
    )
    task_id = f"qual-{model_key}-tools-{index:02d}"
    public = {
        "task_id": task_id,
        "model_key": model_key,
        "repair_class": "tools",
        "control_index": index,
        "prompt": prompt,
        "maximum_new_tokens": 128,
        "treatment_contract": "typed_shortest_path_subresult_api",
        "matched_control_contract": "schema_matched_irrelevant_distance_api",
        "tool_schema": {
            "name": "shortest_path",
            "arguments": {"start": "node", "end": "node"},
            "returns": {"distance": "nonnegative integer"},
        },
        "maximum_tool_calls": 4,
        "authority_answer_is_tool_output": False,
    }
    authority = {
        "task_id": task_id,
        "answer": answer,
        "tool_environment": {"nodes": nodes, "edges": edges},
        "tool_result": shortest,
        "offset": offset,
        "scorer": "exact_even_odd",
    }
    return public, authority


def _shortest_path(edges: Sequence[Sequence[Any]], start: str, end: str) -> int:
    frontier = [(0, start)]
    distances = {start: 0}
    while frontier:
        frontier.sort(reverse=True)
        distance, node = frontier.pop()
        if node == end:
            return distance
        for left, right, weight in edges:
            if left == node:
                neighbor = right
            elif right == node:
                neighbor = left
            else:
                continue
            candidate = distance + int(weight)
            if candidate < distances.get(neighbor, 10**9):
                distances[neighbor] = candidate
                frontier.append((candidate, neighbor))
    raise ValueError("qualification graph is disconnected")


def _parameter_mapping(model_key: str) -> Mapping[str, str]:
    symbols = ["zorp", "keld", "miv", "tarn", "plin", "sova", "drek", "nume"]
    labels = ["ALPHA", "BETA", "GAMMA", "DELTA"] * 2
    rng = random.Random(_seed(model_key, "parameter-mapping"))
    rng.shuffle(labels)
    return dict(zip(symbols, labels))


def _parameter_task(
    model_key: str, index: int
) -> tuple[Dict[str, Any], Dict[str, Any]]:
    mapping = _parameter_mapping(model_key)
    symbols = sorted(mapping)
    target = symbols[(index * 3 + 1) % len(symbols)]
    task_id = f"qual-{model_key}-parameter-change-{index:02d}"
    prompt = (
        "Classify the opaque token under the learned laboratory convention. "
        f"TOKEN: {target}\nReturn exactly one of ALPHA, BETA, GAMMA, DELTA."
    )
    public = {
        "task_id": task_id,
        "model_key": model_key,
        "repair_class": "parameter_or_representation_change",
        "control_index": index,
        "prompt": prompt,
        "maximum_new_tokens": 48,
        "treatment_contract": "rank8_lora_one_epoch_64_disjoint_examples",
        "matched_control_contract": "irrelevant_mapping_sham_adapter_and_base",
        "adaptation_partition_ref": f"qualification-adaptation-{model_key}",
        "mapping_disclosed_in_prompt": False,
    }
    authority = {
        "task_id": task_id,
        "answer": mapping[target],
        "target_symbol": target,
        "scorer": "exact_class_label",
    }
    return public, authority


TASK_BUILDERS = {
    "compute": _compute_task,
    "explicit_state": _state_task,
    "verification": _verification_task,
    "tools": _tool_task,
    "parameter_or_representation_change": _parameter_task,
}


def build_tasks() -> tuple[Tuple[Dict[str, Any], ...], Tuple[Dict[str, Any], ...]]:
    public = []
    authority = []
    for model in MODEL_CONTRACT:
        model_key = str(model["key"])
        for repair_class in REPAIR_CLASSES:
            for index in range(UNITS_PER_CLASS_AND_MODEL):
                visible, hidden = TASK_BUILDERS[repair_class](model_key, index)
                visible["answer_commitment"] = _answer_digest(
                    str(hidden["task_id"]), str(hidden["answer"])
                )
                public.append(visible)
                authority.append(hidden)
    return tuple(public), tuple(authority)


def build_adaptation_rows() -> Tuple[Dict[str, Any], ...]:
    rows = []
    for model in MODEL_CONTRACT:
        model_key = str(model["key"])
        mapping = _parameter_mapping(model_key)
        symbols = sorted(mapping)
        rng = random.Random(_seed(model_key, "adaptation-examples"))
        for index in range(ADAPTATION_EXAMPLES_PER_MODEL):
            symbol = symbols[index % len(symbols)]
            nonce = rng.randrange(1000, 9999)
            rows.append(
                {
                    "adaptation_id": f"adapt-{model_key}-{index:03d}",
                    "model_key": model_key,
                    "partition": "qualification_adaptation",
                    "prompt": (
                        "Classify the opaque token under the laboratory convention. "
                        f"Context nonce {nonce}. TOKEN: {symbol}\nReturn exactly one "
                        "of ALPHA, BETA, GAMMA, DELTA."
                    ),
                    "answer": mapping[symbol],
                    "symbol": symbol,
                    "nonce": nonce,
                }
            )
    return tuple(rows)


def _jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _write_immutable(path: Path, payload: str) -> None:
    if path.exists():
        if path.read_text(encoding="utf-8") != payload:
            raise RuntimeError(f"refusing to overwrite frozen qualification artifact: {path}")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload, encoding="utf-8")


def verify_benchmark(output: Path) -> Mapping[str, Any]:
    public = [
        json.loads(line)
        for line in (output / "tasks-public.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    authority = [
        json.loads(line)
        for line in (output / "tasks-authority.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    adaptation = [
        json.loads(line)
        for line in (output / "adaptation-authority.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    public_ids = {row["task_id"] for row in public}
    authority_ids = {row["task_id"] for row in authority}
    expected_tasks = len(MODEL_CONTRACT) * len(REPAIR_CLASSES) * UNITS_PER_CLASS_AND_MODEL
    counts = {
        (model["key"], repair_class): sum(
            row["model_key"] == model["key"] and row["repair_class"] == repair_class
            for row in public
        )
        for model in MODEL_CONTRACT
        for repair_class in REPAIR_CLASSES
    }
    authority_by_id = {row["task_id"]: row for row in authority}
    checks = {
        "authorization_bound": _read_json(output / "protocol-freeze.json")[
            "authorization_record_id"
        ]
        == AUTHORIZATION_RECORD_ID,
        "balanced_complete_panel": len(public) == expected_tasks
        and all(value == UNITS_PER_CLASS_AND_MODEL for value in counts.values()),
        "unique_public_ids": len(public_ids) == len(public),
        "authority_matches_public": public_ids == authority_ids,
        "answer_commitments_reproduce": all(
            row["answer_commitment"]
            == _answer_digest(
                str(row["task_id"]), str(authority_by_id[row["task_id"]]["answer"])
            )
            for row in public
        ),
        "no_public_answer_field": all("answer" not in row for row in public),
        "adaptation_count": len(adaptation)
        == len(MODEL_CONTRACT) * ADAPTATION_EXAMPLES_PER_MODEL,
        "adaptation_ids_disjoint": not public_ids.intersection(
            row["adaptation_id"] for row in adaptation
        ),
        "only_allowed_models": {row["model_key"] for row in public}
        == {model["key"] for model in MODEL_CONTRACT},
        "tool_outputs_are_subresults": all(
            not row.get("authority_answer_is_tool_output", False)
            for row in public
            if row["repair_class"] == "tools"
        ),
        "state_payloads_not_declared_final": all(
            not row.get("payload_is_final_answer", False)
            for row in public
            if row["repair_class"] == "explicit_state"
        ),
    }
    body = {
        "version": VERSION,
        "checks": checks,
        "passed": all(checks.values()),
        "task_count": len(public),
        "adaptation_count": len(adaptation),
        "counts": {f"{key[0]}:{key[1]}": value for key, value in counts.items()},
        "public_sha256": hashlib.sha256(
            (output / "tasks-public.jsonl").read_bytes()
        ).hexdigest(),
        "authority_sha256": hashlib.sha256(
            (output / "tasks-authority.jsonl").read_bytes()
        ).hexdigest(),
        "adaptation_sha256": hashlib.sha256(
            (output / "adaptation-authority.jsonl").read_bytes()
        ).hexdigest(),
    }
    return {**body, "verification_id": content_digest(body)}


def _read_json(path: Path) -> Mapping[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def prepare_benchmark(output: Path) -> Mapping[str, Any]:
    output = Path(output)
    public, authority = build_tasks()
    adaptation = build_adaptation_rows()
    public_payload = _jsonl(public)
    authority_payload = _jsonl(authority)
    adaptation_payload = _jsonl(adaptation)
    protocol_body = {
        "version": VERSION,
        "partition": "qualification",
        "authorization_record_id": AUTHORIZATION_RECORD_ID,
        "canonical_graph_id": CANONICAL_GRAPH_ID,
        "model_contract": list(MODEL_CONTRACT),
        "repair_classes": list(REPAIR_CLASSES),
        "units_per_class_and_model": UNITS_PER_CLASS_AND_MODEL,
        "adaptation_examples_per_model": ADAPTATION_EXAMPLES_PER_MODEL,
        "task_count": len(public),
        "qualification_gates": {
            "minimum_completed_controls_per_class_and_model": 4,
            "minimum_paired_wins_per_class_and_model": 3,
            "minimum_aggregate_accuracy_gain": 0.20,
            "maximum_normalized_cost_difference": 0.10,
            "maximum_principal_resource_difference": 0.15,
            "maximum_replacements_per_class": 1,
        },
        "outcome_use": (
            "Qualification pass/fail, delivery, leakage, cost, and bounded "
            "replacement decisions only. Outcomes cannot train or select a theory."
        ),
        "forbidden_next_stages": [
            "discovery",
            "calibration",
            "prospective",
            "replication",
        ],
        "claim_boundary": (
            "This benchmark can establish implementation competence only. It "
            "cannot establish a repairability theory, transport, novelty, a "
            "representation-required case, or a causal parameter-count effect."
        ),
        "public_sha256": hashlib.sha256(public_payload.encode("utf-8")).hexdigest(),
        "authority_sha256": hashlib.sha256(authority_payload.encode("utf-8")).hexdigest(),
        "adaptation_sha256": hashlib.sha256(adaptation_payload.encode("utf-8")).hexdigest(),
    }
    protocol = {**protocol_body, "freeze_id": content_digest(protocol_body)}
    _write_immutable(output / "tasks-public.jsonl", public_payload)
    _write_immutable(output / "tasks-authority.jsonl", authority_payload)
    _write_immutable(output / "adaptation-authority.jsonl", adaptation_payload)
    _write_immutable(
        output / "protocol-freeze.json",
        json.dumps(protocol, indent=2, sort_keys=True) + "\n",
    )
    verification = verify_benchmark(output)
    _write_immutable(
        output / "protocol-verification.json",
        json.dumps(verification, indent=2, sort_keys=True) + "\n",
    )
    if not verification["passed"]:
        raise RuntimeError("qualification benchmark verification failed")
    return {
        "version": VERSION,
        "output": str(output.resolve()),
        "freeze_id": protocol["freeze_id"],
        "verification_id": verification["verification_id"],
        "task_count": len(public),
        "adaptation_count": len(adaptation),
        "authorized_stage": "qualification_only",
    }
