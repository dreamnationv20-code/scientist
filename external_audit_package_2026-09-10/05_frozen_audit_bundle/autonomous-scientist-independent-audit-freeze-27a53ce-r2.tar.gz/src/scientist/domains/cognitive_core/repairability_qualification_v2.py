from __future__ import annotations

import hashlib
import hmac
import itertools
import json
import math
import re
import unicodedata
from decimal import Decimal
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple


VERSION = "cognitive-repairability-qualification-v3"
CLEAN_IMPLEMENTATION_DESIGN_ID = (
    "55eb855a2321e85575b9e7412436b1c4b37fd5b062a58de89dc6316fb6cca0ae"
)
CLEAN_TASK_DESIGN_ID = (
    "a269c3284de66c76b525d05708dd74a1e034137d1e8bc8ae22dab02fb4cf844e"
)
PILOT_FREEZE_ID = (
    "30a2ce7cba2fc6d031da8eae1e6dabf3f177519d616bf00102f7d94cbdb626f3"
)
PILOT_QUARANTINE_ID = (
    "bb43ecf160bd597781a9309287165ffe750d3e2fa04136942d092eb05ff09c6f"
)

MODEL_CONTRACT = (
    {
        "key": "qwen3_1p7b",
        "parameter_class": "1.7B",
        "repository": "Qwen/Qwen3-1.7B-MLX-4bit",
        "revision": "21457c6f51ed54a7c16e988c0844db973815c137",
        "parameter_boundary_rule": "exact_frozen_1p7b_class_identity",
    },
    {
        "key": "qwen2p5_3b",
        "parameter_class": "3B",
        "repository": "mlx-community/Qwen2.5-3B-Instruct-4bit",
        "revision": "4f83f8f146fdf28b512a06562b671d7af4fab457",
        "exact_parameters": 3_085_625_856,
        "parameter_boundary_rule": "sole_adjudicated_exact_frozen_3b_class_exception",
    },
)

REPAIR_CLASSES = (
    "compute",
    "explicit_state",
    "verification",
    "tools",
    "parameter_or_representation_change",
)
ATTEMPTS = ("P", "A")
UNITS_PER_CELL = 5


COMPUTE_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "additionalProperties": False,
    "required": ["code", "states"],
    "properties": {
        "code": {"type": "string", "pattern": "^[ABC]{6}$"},
        "states": {
            "type": "array",
            "minItems": 7,
            "maxItems": 7,
            "items": {"type": "integer"},
        },
    },
}

STATE_SYMBOLS = (
    "ka", "ke", "ki", "ko", "ku", "la", "le", "li",
    "lo", "lu", "ma", "me", "mi", "mo", "mu", "na",
)
STATE_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "additionalProperties": False,
    "required": ["selected", "checksum"],
    "properties": {
        "selected": {
            "type": "array",
            "minItems": 6,
            "maxItems": 6,
            "items": {"type": "string", "enum": list(STATE_SYMBOLS)},
        },
        "checksum": {"type": "string", "pattern": "^[0-9]{2}$"},
    },
}

VERIFICATION_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "additionalProperties": False,
    "required": ["rows"],
    "properties": {
        "rows": {
            "type": "array",
            "minItems": 5,
            "maxItems": 5,
            "items": {"type": "string", "pattern": "^[ABCDE]{5}$"},
        }
    },
}

TOOLS_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "additionalProperties": False,
    "required": ["code"],
    "properties": {
        "code": {"type": "string", "pattern": "^K[0-9]+Z[0-9]{2}$"}
    },
}


def canonical_json(value: Any) -> bytes:
    """RFC 8785 JSON Canonicalization Scheme bytes."""
    return _canonical_encode(_normalize(value)).encode("utf-8")


def _jcs_number(value: float) -> str:
    if not math.isfinite(value):
        raise ValueError("RFC 8785 forbids non-finite numbers")
    if value == 0:
        return "0"
    negative = value < 0
    absolute = abs(value)
    shortest = repr(absolute)
    decimal = Decimal(shortest)
    if 1e-6 <= absolute < 1e21:
        rendered = format(decimal, "f")
        if "." in rendered:
            rendered = rendered.rstrip("0").rstrip(".")
    else:
        rendered = format(decimal.normalize(), "e")
        mantissa, exponent = rendered.split("e")
        mantissa = mantissa.rstrip("0").rstrip(".")
        exponent_value = int(exponent)
        rendered = mantissa + "e" + ("+" if exponent_value >= 0 else "") + str(exponent_value)
    return ("-" if negative else "") + rendered


def _canonical_encode(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return _jcs_number(value)
    if isinstance(value, str):
        value.encode("utf-8", "strict")
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, list):
        return "[" + ",".join(_canonical_encode(item) for item in value) + "]"
    if isinstance(value, dict):
        ordered = sorted(value, key=lambda key: str(key).encode("utf-16be", "surrogatepass"))
        return "{" + ",".join(
            _canonical_encode(str(key)) + ":" + _canonical_encode(value[key])
            for key in ordered
        ) + "}"
    raise TypeError(f"unsupported canonical value: {type(value).__name__}")


def _normalize(value: Any) -> Any:
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value).replace("\r\n", "\n").replace("\r", "\n")
    if isinstance(value, list):
        return [_normalize(item) for item in value]
    if isinstance(value, tuple):
        return [_normalize(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalize(item) for key, item in value.items()}
    if value is None or isinstance(value, (bool, int, float)):
        return value
    raise TypeError(f"unsupported canonical value: {type(value).__name__}")


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest(value: Any) -> str:
    return sha256_bytes(canonical_json(value))


def _hmac(salt: bytes, prefix: bytes, freeze_id: str, value: Any) -> bytes:
    return hmac.new(
        salt,
        prefix + freeze_id.encode("ascii") + canonical_json(value),
        hashlib.sha256,
    ).digest()


def draw(
    salt: bytes,
    freeze_id: str,
    name: str,
    model_key: str,
    repair_class: str,
    attempt: str,
    arm: str,
    unit_index: int,
    extra: Any,
) -> bytes:
    return _hmac(
        salt,
        b"fresh-task-v1",
        freeze_id,
        [name, model_key, repair_class, attempt, arm, unit_index, extra],
    )


def draw_int(*args: Any) -> int:
    return int.from_bytes(draw(*args), "big")


def execution_seed(
    salt: bytes,
    freeze_id: str,
    model_key: str,
    repair_class: str,
    attempt: str,
    arm: str,
    unit_index: int,
    call_index: int,
) -> int:
    body = [model_key, repair_class, attempt, arm, unit_index, call_index]
    raw = _hmac(salt, b"seed-v1", freeze_id, body)
    return int.from_bytes(raw[:8], "big")


def seed_commitment(seed: int) -> str:
    return sha256_bytes(seed.to_bytes(8, "big"))


def task_id(
    salt: bytes,
    freeze_id: str,
    model_key: str,
    repair_class: str,
    attempt: str,
    unit_index: int,
) -> str:
    payload = (
        b"task-v1"
        + salt
        + freeze_id.encode("ascii")
        + model_key.encode("utf-8")
        + repair_class.encode("utf-8")
        + attempt.encode("ascii")
        + str(unit_index).encode("ascii")
    )
    return "q2_" + sha256_bytes(payload)[:24]


def _seed_manifest(
    salt: bytes,
    freeze_id: str,
    model_key: str,
    repair_class: str,
    attempt: str,
    unit_index: int,
) -> Mapping[str, Any]:
    arms = {
        "treatment": 21,
        "control": 21,
        "sham": 21,
        "treatment_padding": 4,
        "control_padding": 4,
        "sham_padding": 4,
        "base_padding": 4,
        "no_update_padding": 4,
        "training": 8,
        "sham_training": 8,
        "no_update_training": 4,
        "base": 4,
        "no_update": 4,
    }
    return {
        arm: [
            seed_commitment(
                execution_seed(
                    salt,
                    freeze_id,
                    model_key,
                    repair_class,
                    attempt,
                    arm,
                    unit_index,
                    call_index,
                )
            )
            for call_index in range(count)
        ]
        for arm, count in arms.items()
    }


@dataclass(frozen=True)
class BuiltTask:
    public: Mapping[str, Any]
    authority: Mapping[str, Any]


def _base_public(
    salt: bytes,
    freeze_id: str,
    model_key: str,
    repair_class: str,
    attempt: str,
    unit_index: int,
    prompt: str,
    output_schema: Mapping[str, Any],
) -> Dict[str, Any]:
    identifier = task_id(
        salt, freeze_id, model_key, repair_class, attempt, unit_index
    )
    body: Dict[str, Any] = {
        "version": VERSION,
        "freeze_id": freeze_id,
        "task_id": identifier,
        "model_key": model_key,
        "repair_class": repair_class,
        "attempt": attempt,
        "unit_index": unit_index,
        "prompt": prompt,
        "prompt_hash": sha256_bytes(prompt.encode("utf-8")),
        "output_schema": dict(output_schema),
        "output_schema_hash": digest(output_schema),
        "seed_commitments": _seed_manifest(
            salt,
            freeze_id,
            model_key,
            repair_class,
            attempt,
            unit_index,
        ),
        "partition": "qualification",
        "pilot_excluded": True,
    }
    return body


def _finalize(public: Dict[str, Any], authority: Mapping[str, Any]) -> BuiltTask:
    public["authority_commitment"] = digest(authority)
    public["public_content_hash"] = digest(public)
    return BuiltTask(public, authority)


def _compute_apply(
    code: Sequence[str], x0: int, p: int, rows: Sequence[Sequence[int]]
) -> Tuple[int, ...]:
    states = [x0]
    value = x0
    for letter, (_stage, a, b, c) in zip(code, rows):
        if letter == "A":
            value = (2 * value + a) % p
        elif letter == "B":
            value = (3 * value - b) % p
        elif letter == "C":
            value = (value * value + c) % p
        else:
            raise ValueError("invalid compute route letter")
        states.append(value)
    return tuple(states)


def build_compute_task(
    salt: bytes, freeze_id: str, model_key: str, attempt: str, unit_index: int
) -> BuiltTask:
    p = (101, 103, 107, 109, 113)[unit_index]
    repair_class = "compute"
    x0 = 1 + draw_int(
        salt, freeze_id, "x0", model_key, repair_class, attempt, "shared", unit_index, 0
    ) % (p - 1)
    rows = []
    hidden = []
    for stage in range(6):
        values = [
            1
            + draw_int(
                salt,
                freeze_id,
                name,
                model_key,
                repair_class,
                attempt,
                "shared",
                unit_index,
                stage,
            )
            % (p - 1)
            for name in ("a", "b", "c")
        ]
        rows.append((stage, *values))
        route = (
            draw_int(
                salt,
                freeze_id,
                "route",
                model_key,
                repair_class,
                attempt,
                "shared",
                unit_index,
                stage,
            )
            + unit_index
            + stage
        ) % 3
        hidden.append("ABC"[route])
    target = _compute_apply(hidden, x0, p, rows)[-1]
    successful = []
    for code in itertools.product("ABC", repeat=6):
        states = _compute_apply(code, x0, p, rows)
        if states[-1] == target:
            successful.append(("".join(code), states))
    answer_code, answer_states = successful[0]
    stage_table = "; ".join(
        f"({stage},{a},{b},{c})" for stage, a, b, c in rows
    )
    prompt = (
        f"A modular machine starts at x0={x0} and uses modulus p={p}. At stage k, "
        "choose exactly one operation: A: x=(2*x+a_k) mod p; B: x=(3*x-b_k) "
        "mod p; C: x=(x*x+c_k) mod p. Stage rows (k,a_k,b_k,c_k): "
        f"{stage_table}. The required final value after exactly six stages is "
        f"{target}. Among every six-letter code over A,B,C that reaches the target, "
        "return the lexicographically first under A<B<C and all seven states "
        f"including x0. Return only JSON matching {json.dumps(COMPUTE_SCHEMA, sort_keys=True)}. "
        "No checker or tool is available."
    )
    public = _base_public(
        salt, freeze_id, model_key, repair_class, attempt, unit_index, prompt, COMPUTE_SCHEMA
    )
    public.update(
        {
            "family_name": "modular_transformation_search",
            "declared_identifiers": ["x0", "p", "a_k", "b_k", "c_k", "target"],
            "path_labels": [format(index, "03b") for index in range(8)],
            "answer_blind_payload": {
                "machine_table": rows,
                "target": target,
                "ranking_rule": [
                    "identifier_coverage_desc",
                    "assignment_conflicts_asc",
                    "unresolved_cross_references_asc",
                    "token_count_asc",
                    "sha256_asc",
                ],
            },
        }
    )
    authority = {
        "task_id": public["task_id"],
        "answer": {"code": answer_code, "states": list(answer_states)},
        "answer_rule": "exact_json_object",
        "successful_code_count": len(successful),
    }
    return _finalize(public, authority)


def build_state_task(
    salt: bytes, freeze_id: str, model_key: str, attempt: str, unit_index: int
) -> BuiltTask:
    repair_class = "explicit_state"
    tape = [STATE_SYMBOLS[(3 * unit_index) % 16]]
    for position in range(2, 33):
        value = draw_int(
            salt,
            freeze_id,
            "tape",
            model_key,
            repair_class,
            attempt,
            "shared",
            unit_index,
            position,
        ) % 16
        tape.append(STATE_SYMBOLS[value])
    first = unit_index + 1
    candidates = sorted(
        (position for position in range(1, 33) if position != first),
        key=lambda position: (
            draw(
                salt,
                freeze_id,
                "query-rank",
                model_key,
                repair_class,
                attempt,
                "shared",
                unit_index,
                position,
            ),
            position,
        ),
    )
    query = [first, *candidates[:5]]
    tape_text = " ".join(tape)
    selected = [tape[position - 1] for position in query]
    checksum = f"{sum(STATE_SYMBOLS.index(item) + 1 for item in selected) % 97:02d}"
    schema_text = json.dumps(STATE_SCHEMA, sort_keys=True)
    prompt = (
        "Symbol table in index order 1 through 16: "
        + ",".join(STATE_SYMBOLS)
        + f". Tape: {tape_text}. Query positions, using 1-based indexing: "
        + ",".join(str(item) for item in query)
        + ". First write the complete Tape span byte-for-byte to S1 using type=\"string\" "
        "and source=\"prompt\". After that write is accepted, issue <read slot=\"S1\"/>. "
        "Use the value returned by that later read: split it on single spaces, return "
        "the tokens at the six query positions, and compute checksum as the sum of "
        "their symbol-table indices modulo 97 formatted as two decimal digits. Finish "
        f"with only JSON matching {schema_text}. The stored tape is a dependency and "
        "is not itself the final answer."
    )
    public = _base_public(
        salt, freeze_id, model_key, repair_class, attempt, unit_index, prompt, STATE_SCHEMA
    )
    tape_offset = prompt.index(tape_text)
    public.update(
        {
            "family_name": "persistent_tape_dependency",
            "declared_entities": [
                {
                    "name": "TAPE",
                    "start": tape_offset,
                    "end": tape_offset + len(tape_text),
                    "sha256": sha256_bytes(tape_text.encode("utf-8")),
                }
            ],
            "mandatory_state_protocol": {
                "write": {"slot": "S1", "type": "string", "source": "prompt"},
                "read_after_write": "S1",
                "maximum_accepted_writes": 8,
                "maximum_reads": 12,
            },
        }
    )
    authority = {
        "task_id": public["task_id"],
        "answer": {"selected": selected, "checksum": checksum},
        "answer_rule": "exact_json_object",
        "tape_sha256": sha256_bytes(tape_text.encode("utf-8")),
        "query_positions": query,
    }
    return _finalize(public, authority)


def _verification_predicates(
    value: Any, clues: Sequence[Mapping[str, Any]]
) -> Mapping[str, bool]:
    schema_valid = (
        isinstance(value, dict)
        and set(value) == {"rows"}
        and isinstance(value.get("rows"), list)
        and len(value["rows"]) == 5
        and all(
            isinstance(row, str)
            and len(row) == 5
            and set(row).issubset(set("ABCDE"))
            for row in value["rows"]
        )
    )
    if not schema_valid:
        return {"C1": False, "C2": False, "C3": False, "C4": False}
    rows = value["rows"]
    row_valid = all(sorted(row) == list("ABCDE") for row in rows)
    col_valid = all(
        sorted(rows[row][column] for row in range(5)) == list("ABCDE")
        for column in range(5)
    )
    clues_valid = all(
        rows[int(clue["row"])][int(clue["column"])] == clue["symbol"]
        for clue in clues
    )
    return {"C1": True, "C2": row_valid, "C3": col_valid, "C4": clues_valid}


def check_verification_candidate(
    value: Any, clues: Sequence[Mapping[str, Any]]
) -> Mapping[str, Any]:
    checks = _verification_predicates(value, clues)
    return {
        "valid": all(checks.values()),
        "violated_constraint_ids": [key for key, passed in checks.items() if not passed],
    }


def build_verification_task(
    salt: bytes, freeze_id: str, model_key: str, attempt: str, unit_index: int
) -> BuiltTask:
    repair_class = "verification"
    a, b = ((1, 1), (1, 2), (1, 3), (1, 4), (2, 1))[unit_index]
    symbols = sorted(
        "ABCDE",
        key=lambda symbol: (
            draw(
                salt,
                freeze_id,
                "symbol-permutation",
                model_key,
                repair_class,
                attempt,
                "shared",
                unit_index,
                symbol,
            ),
            symbol,
        ),
    )
    selected_columns = set()
    clues = []
    for row in range(5):
        ranked = sorted(
            range(5),
            key=lambda column: (
                draw(
                    salt,
                    freeze_id,
                    "clue-column",
                    model_key,
                    repair_class,
                    attempt,
                    "shared",
                    unit_index,
                    [row, column],
                ),
                column,
            ),
        )
        column = next(item for item in ranked if item not in selected_columns)
        selected_columns.add(column)
        clues.append(
            {"row": row, "column": column, "symbol": symbols[(a * row + b * column) % 5]}
        )
    clue_text = ", ".join(
        f"({item['row']},{item['column']})={item['symbol']}" for item in clues
    )
    prompt = (
        "Construct a 5-by-5 grid. Return only JSON matching "
        f"{json.dumps(VERIFICATION_SCHEMA, sort_keys=True)}. Constraint C1: the JSON "
        "must match that schema exactly. Constraint C2: each row must contain A,B,C,D,E "
        "exactly once. Constraint C3: each column must contain A,B,C,D,E exactly once. "
        "Constraint C4: the following zero-based cells must equal their listed symbols: "
        f"{clue_text}. External verification may test only C1,C2,C3,C4 and cannot "
        "compare your grid with a reference answer."
    )
    public = _base_public(
        salt,
        freeze_id,
        model_key,
        repair_class,
        attempt,
        unit_index,
        prompt,
        VERIFICATION_SCHEMA,
    )
    public.update(
        {
            "family_name": "named_constraint_latin_grid",
            "constraint_ids": ["C1", "C2", "C3", "C4"],
            "clues": clues,
            "checker_contract": "prompt_visible_predicates_only",
        }
    )
    authority = {
        "task_id": public["task_id"],
        "answer": None,
        "answer_rule": "all_prompt_visible_predicates_true",
        "predicate_registry": {"C1": "schema", "C2": "rows", "C3": "columns", "C4": "clues"},
        "clues": clues,
    }
    return _finalize(public, authority)


def evaluate_integer_ast(ast: Mapping[str, Any]) -> int:
    operation = ast.get("op")
    if operation == "const":
        value = ast.get("value")
        if not isinstance(value, int):
            raise ValueError("constant must be integer")
        return value
    arguments = ast.get("args")
    if not isinstance(arguments, list):
        raise ValueError("operator args must be a list")
    values = [evaluate_integer_ast(item) for item in arguments]
    if operation == "add" and len(values) == 2:
        return values[0] + values[1]
    if operation == "sub" and len(values) == 2:
        return values[0] - values[1]
    if operation == "mul" and len(values) == 2:
        return values[0] * values[1]
    if operation == "gcd" and len(values) == 2:
        import math

        return math.gcd(values[0], values[1])
    raise ValueError("operation outside frozen integer AST")


def _constant(value: int) -> Mapping[str, Any]:
    return {"op": "const", "value": value}


def build_tools_task(
    salt: bytes, freeze_id: str, model_key: str, attempt: str, unit_index: int
) -> BuiltTask:
    repair_class = "tools"
    n1 = 100_003 + 1009 * unit_index
    numbers = [n1]
    for name in ("n2", "n3", "n4"):
        numbers.append(
            100_000
            + draw_int(
                salt,
                freeze_id,
                name,
                model_key,
                repair_class,
                attempt,
                "shared",
                unit_index,
                0,
            )
            % 900_000
        )
    for name in ("n5", "n6"):
        numbers.append(
            1000
            + draw_int(
                salt,
                freeze_id,
                name,
                model_key,
                repair_class,
                attempt,
                "shared",
                unit_index,
                0,
            )
            % 9000
        )
    n1, n2, n3, n4, n5, n6 = numbers
    ast = {
        "op": "sub",
        "args": [
            {
                "op": "add",
                "args": [
                    {"op": "mul", "args": [_constant(n1), _constant(n2)]},
                    {"op": "mul", "args": [_constant(n3), _constant(n4)]},
                ],
            },
            {"op": "gcd", "args": [_constant(n5), _constant(n6)]},
        ],
    }
    request_id = "rq_" + sha256_bytes(canonical_json(ast))[:16]
    request = {
        "request_id": request_id,
        "operation": "integer_arithmetic",
        "arguments": {"ast": ast},
    }
    direct_request = {
        "operation": "integer_arithmetic",
        "ast": ast,
    }
    request_for_prompt = direct_request if attempt == "A" else request
    subresult = evaluate_integer_ast(ast)
    digits = str(abs(subresult))
    answer = f"K{digits[::-1]}Z{abs(subresult) % 97:02d}"
    prompt = (
        "You must make exactly one tool call. The only allowed operation is "
        "integer_arithmetic, and the call must equal this request exactly: "
        f"{canonical_json(request_for_prompt).decode('utf-8')}. Let the returned integer "
        "subresult be S. After the response, form d as the decimal digits of abs(S), "
        "reverse d, and output code K+reverse(d)+Z+two_digit(abs(S) mod 97). The "
        "final code must not equal or repeat the tool's integer output. Finish with "
        f"only JSON matching {json.dumps(TOOLS_SCHEMA, sort_keys=True)}. A second "
        "call or a changed request is invalid."
    )
    public = _base_public(
        salt, freeze_id, model_key, repair_class, attempt, unit_index, prompt, TOOLS_SCHEMA
    )
    public.update(
        {
            "family_name": "single_subresult_code_transform",
            "allowed_operations": ["integer_arithmetic"],
            "required_request": request,
            "direct_required_request": direct_request,
            "maximum_tool_calls": 1,
            "tool_request_schema": {
                "$schema": "https://json-schema.org/draft/2020-12/schema",
                "type": "object",
                "properties": {
                    "request_id": {"type": "string", "const": request_id},
                    "operation": {"type": "string", "const": "integer_arithmetic"},
                    "arguments": {
                        "type": "object",
                        "properties": {"ast": {"type": "object", "const": ast}},
                        "required": ["ast"],
                        "additionalProperties": False,
                    },
                },
                "additionalProperties": False,
                "required": ["request_id", "operation", "arguments"],
            },
            "tool_response_schema": {
                "$schema": "https://json-schema.org/draft/2020-12/schema",
                "type": "object",
                "properties": {
                    "request_id": {"type": "string"},
                    "ok": {"type": "boolean"},
                    "subresult_type": {"enum": ["integer", None]},
                    "subresult": {"type": ["integer", "null"]},
                    "error_code": {
                        "enum": [
                            None,
                            "SCHEMA_INVALID",
                            "OP_NOT_ALLOWED",
                            "LIMIT_EXCEEDED",
                            "AUTHORITY_REQUEST_REJECTED",
                            "EXECUTION_ERROR",
                        ]
                    },
                    "truncated": {"type": "boolean", "const": False},
                },
                "additionalProperties": False,
                "required": [
                    "request_id", "ok", "subresult_type", "subresult", "error_code", "truncated"
                ],
            },
            "direct_tool_request_schema": {
                "$schema": "https://json-schema.org/draft/2020-12/schema",
                "type": "object",
                "properties": {
                    "operation": {"type": "string", "const": "integer_arithmetic"},
                    "ast": {"type": "object", "const": ast},
                },
                "required": ["operation", "ast"],
                "additionalProperties": False,
            },
        }
    )
    authority = {
        "task_id": public["task_id"],
        "answer": {"code": answer},
        "answer_rule": "exact_json_object",
        "tool_subresult": subresult,
        "required_request_hash": digest(request_for_prompt),
    }
    return _finalize(public, authority)


def _namespace_tokens(
    salt: bytes, freeze_id: str, model_key: str
) -> Tuple[Tuple[str, ...], Tuple[str, ...], Tuple[str, ...]]:
    repair_class = "parameter_or_representation_change"
    glyphs = tuple(
        "ZG"
        + draw(
            salt, freeze_id, "glyph-token", model_key, repair_class, "P", "shared", 0, index
        ).hex()[:12]
        for index in range(16)
    )
    relations = tuple(
        "ZR"
        + draw(
            salt,
            freeze_id,
            "relation-token",
            model_key,
            repair_class,
            "P",
            "shared",
            0,
            index,
        ).hex()[:12]
        for index in range(4)
    )
    labels = tuple(
        "ZL"
        + draw(
            salt, freeze_id, "label-token", model_key, repair_class, "P", "shared", 0, index
        ).hex()[:12]
        for index in range(4)
    )
    if len(set((*glyphs, *relations, *labels))) != 24:
        raise RuntimeError("synthetic namespace collision")
    return glyphs, relations, labels


def build_parameter_partition(
    salt: bytes, freeze_id: str, model_key: str
) -> tuple[Tuple[Mapping[str, Any], ...], Mapping[str, Tuple[BuiltTask, ...]]]:
    repair_class = "parameter_or_representation_change"
    glyphs, relations, labels = _namespace_tokens(salt, freeze_id, model_key)
    tuples = list(itertools.product(range(16), range(16), range(4)))
    ranked_adaptation = sorted(
        tuples,
        key=lambda item: (
            draw(
                salt,
                freeze_id,
                "adapt-rank",
                model_key,
                repair_class,
                "P",
                "training",
                0,
                list(item),
            ),
            canonical_json(item),
        ),
    )
    adapt_tuples = ranked_adaptation[:64]
    pair_set = {(i, j) for i, j, _k in adapt_tuples}
    adaptation = []
    for i, j, k in adapt_tuples:
        identifier = "ad_" + sha256_bytes(
            b"adapt-id-v1"
            + freeze_id.encode("ascii")
            + model_key.encode("utf-8")
            + canonical_json([i, j, k])
        )[:24]
        user_content = f"glyphs={glyphs[i]},{glyphs[j]}; relation={relations[k]}"
        if model_key == "qwen3_1p7b":
            user_content += "\n/no_think"
        messages = [
            {"role": "system", "content": "Return exactly one allowed synthetic label."},
            {"role": "user", "content": user_content},
            {"role": "assistant", "content": f"<label>{labels[(i + 3 * j + k) % 4]}</label>"},
        ]
        adaptation.append(
            {
                "record_id": identifier,
                "model_key": model_key,
                "split": "adapt",
                "tuple": [i, j, k],
                "tuple_hash": digest(["synthetic_tuple", model_key, [i, j, k]]),
                "ordered_pair_hash": digest(["ordered_pair", model_key, [i, j]]),
                "messages": messages,
                "provenance_hash": digest([model_key, i, j, k, messages]),
            }
        )
    sham_order = sorted(
        adaptation,
        key=lambda row: (
            draw(
                salt,
                freeze_id,
                "sham-label-order",
                model_key,
                repair_class,
                "P",
                "sham-training",
                0,
                row["record_id"],
            ),
            row["record_id"],
        ),
    )
    sham_label_by_id = {
        row["record_id"]: labels[position % 4] for position, row in enumerate(sham_order)
    }
    finalized = []
    for row in adaptation:
        sham_messages = [dict(item) for item in row["messages"]]
        sham_messages[-1] = {
            "role": "assistant",
            "content": f"<label>{sham_label_by_id[row['record_id']]}</label>",
        }
        record_body = {**row, "sham_messages": sham_messages}
        finalized.append({**record_body, "raw_record_hash": digest(record_body)})

    evaluations: Dict[str, Tuple[BuiltTask, ...]] = {}
    excluded_pairs = set(pair_set)
    excluded_tuples = set(adapt_tuples)
    for attempt in ATTEMPTS:
        eligible = [
            item
            for item in tuples
            if item not in excluded_tuples and (item[0], item[1]) not in excluded_pairs
        ]
        ranked = sorted(
            eligible,
            key=lambda item: (
                draw(
                    salt,
                    freeze_id,
                    "evaluation-rank",
                    model_key,
                    repair_class,
                    attempt,
                    "evaluation",
                    0,
                    list(item),
                ),
                canonical_json(item),
            ),
        )
        accepted = []
        accepted_pairs = set()
        for item in ranked:
            pair = (item[0], item[1])
            if pair in accepted_pairs:
                continue
            accepted.append(item)
            accepted_pairs.add(pair)
            if len(accepted) == 5:
                break
        if len(accepted) != 5:
            raise RuntimeError("not enough disjoint parameter evaluation tuples")
        built = []
        for unit_index, (i, j, k) in enumerate(accepted):
            heldout = f"glyphs={glyphs[i]},{glyphs[j]}; relation={relations[k]}"
            prompt = (
                "SYSTEM: Apply the distinctions learned during adaptation. Return exactly "
                "<label>LABEL</label> and no explanation.\nUSER: Synthetic record: "
                f"{heldout}\nAllowed labels: {','.join(labels)}"
            )
            parameter_schema = {
                "$schema": "https://json-schema.org/draft/2020-12/schema",
                "type": "object",
                "additionalProperties": False,
                "required": ["label"],
                "properties": {"label": {"type": "string", "enum": list(labels)}},
            }
            public = _base_public(
                salt,
                freeze_id,
                model_key,
                repair_class,
                attempt,
                unit_index,
                prompt,
                parameter_schema,
            )
            evaluation_id = "ev_" + sha256_bytes(
                b"eval-id-v1"
                + freeze_id.encode("ascii")
                + model_key.encode("utf-8")
                + attempt.encode("ascii")
                + str(unit_index).encode("ascii")
                + canonical_json([i, j, k])
            )[:24]
            public.update(
                {
                    "family_name": "frozen_synthetic_lora_distinction",
                    "evaluation_id": evaluation_id,
                    "tuple_hash": digest(["synthetic_tuple", model_key, [i, j, k]]),
                    "ordered_pair_hash": digest(["ordered_pair", model_key, [i, j]]),
                    "raw_record_hash": digest(
                        ["heldout_record", model_key, attempt, heldout]
                    ),
                    "mapping_commitment": digest(
                        [glyphs, relations, labels, "label=(i+3*j+k)%4"]
                    ),
                    "heldout_synthetic_input": heldout,
                    "label_vocabulary": list(labels),
                    "namespace_tokens": list((*glyphs, *relations, *labels)),
                    "adapter_contract": {
                        "primary_rank": 8,
                        "primary_alpha": 16,
                        "alternate_rank": 16,
                        "alternate_alpha": 32,
                        "target_modules": ["self_attn.q_proj", "self_attn.v_proj"],
                    },
                }
            )
            authority = {
                "task_id": public["task_id"],
                "evaluation_id": evaluation_id,
                "answer": {"label": labels[(i + 3 * j + k) % 4]},
                "answer_rule": "exact_label_tag_or_json_label",
                "tuple": [i, j, k],
            }
            built.append(_finalize(public, authority))
        evaluations[attempt] = tuple(built)
        excluded_tuples.update(accepted)
        excluded_pairs.update((i, j) for i, j, _k in accepted)
    return tuple(finalized), evaluations


def build_panel(
    salt: bytes, freeze_id: str
) -> Mapping[str, Tuple[Mapping[str, Any], ...]]:
    if len(salt) != 32:
        raise ValueError("fresh qualification salt must be exactly 256 bits")
    public = []
    authority = []
    adaptation = []
    for model in MODEL_CONTRACT:
        model_key = str(model["key"])
        parameter_adaptation, parameter_tasks = build_parameter_partition(
            salt, freeze_id, model_key
        )
        adaptation.extend(parameter_adaptation)
        for attempt in ATTEMPTS:
            builders = (
                build_compute_task,
                build_state_task,
                build_verification_task,
                build_tools_task,
            )
            for builder in builders:
                for unit_index in range(UNITS_PER_CELL):
                    built = builder(salt, freeze_id, model_key, attempt, unit_index)
                    public.append(built.public)
                    authority.append(built.authority)
            for built in parameter_tasks[attempt]:
                public.append(built.public)
                authority.append(built.authority)
    model_order = {str(row["key"]): index for index, row in enumerate(MODEL_CONTRACT)}
    class_order = {name: index for index, name in enumerate(REPAIR_CLASSES)}
    attempt_order = {name: index for index, name in enumerate(ATTEMPTS)}
    panel_key = lambda row: (
        attempt_order[str(row["attempt"])],
        model_order[str(row["model_key"])],
        class_order[str(row["repair_class"])],
        int(row["unit_index"]),
    )
    public.sort(key=panel_key)
    authority_by_id = {str(row["task_id"]): row for row in authority}
    authority = [authority_by_id[str(row["task_id"])] for row in public]
    _validate_panel(public, authority, adaptation)
    return {
        "public": tuple(public),
        "authority": tuple(authority),
        "adaptation": tuple(adaptation),
    }


def _validate_panel(
    public: Sequence[Mapping[str, Any]],
    authority: Sequence[Mapping[str, Any]],
    adaptation: Sequence[Mapping[str, Any]],
) -> None:
    expected = len(MODEL_CONTRACT) * len(REPAIR_CLASSES) * len(ATTEMPTS) * UNITS_PER_CELL
    if len(public) != expected or len(authority) != expected:
        raise RuntimeError("fresh panel is incomplete")
    task_ids = [str(row["task_id"]) for row in public]
    if len(set(task_ids)) != len(task_ids):
        raise RuntimeError("fresh task IDs collide")
    if any(not item.startswith("q2_") for item in task_ids):
        raise RuntimeError("fresh task ID escaped q2 namespace")
    if any(item.startswith("qual-") for item in task_ids):
        raise RuntimeError("pilot task ID entered fresh panel")
    public_hashes = [str(row["public_content_hash"]) for row in public]
    if len(set(public_hashes)) != len(public_hashes):
        raise RuntimeError("fresh public stimuli collide")
    if any(
        str(row["public_content_hash"])
        != digest({key: value for key, value in row.items() if key != "public_content_hash"})
        for row in public
    ):
        raise RuntimeError("fresh public content hash mismatch")
    authority_by_id = {str(row["task_id"]): row for row in authority}
    if set(task_ids) != set(authority_by_id):
        raise RuntimeError("authority/public task IDs differ")
    if any(
        str(row["authority_commitment"]) != digest(authority_by_id[str(row["task_id"])])
        for row in public
    ):
        raise RuntimeError("authority commitment mismatch")
    counts = {
        (row["model_key"], row["repair_class"], row["attempt"]): 0 for row in public
    }
    for row in public:
        counts[(row["model_key"], row["repair_class"], row["attempt"])] += 1
    if any(value != UNITS_PER_CELL for value in counts.values()) or len(counts) != 20:
        raise RuntimeError("fresh panel cell imbalance")
    adaptation_ids = [str(row["record_id"]) for row in adaptation]
    if len(adaptation) != 128 or len(set(adaptation_ids)) != len(adaptation_ids):
        raise RuntimeError("fresh adaptation panel is incomplete or colliding")
    adaptation_tuple_hashes = {str(row["tuple_hash"]) for row in adaptation}
    adaptation_pair_hashes = {str(row["ordered_pair_hash"]) for row in adaptation}
    evaluation_rows = [
        row
        for row in public
        if row["repair_class"] == "parameter_or_representation_change"
    ]
    evaluation_tuple_hashes = {str(row["tuple_hash"]) for row in evaluation_rows}
    evaluation_pair_hashes = {str(row["ordered_pair_hash"]) for row in evaluation_rows}
    if (
        adaptation_tuple_hashes.intersection(evaluation_tuple_hashes)
        or adaptation_pair_hashes.intersection(evaluation_pair_hashes)
        or len(evaluation_tuple_hashes) != len(evaluation_rows)
        or len(evaluation_pair_hashes) != len(evaluation_rows)
    ):
        raise RuntimeError("parameter adaptation/evaluation tuple or pair disjointness failed")
    public_raw_hashes = {
        str(row["raw_record_hash"])
        for row in evaluation_rows
    }
    adaptation_raw_hashes = {str(row["raw_record_hash"]) for row in adaptation}
    if public_raw_hashes.intersection(adaptation_raw_hashes):
        raise RuntimeError("parameter adaptation/evaluation raw records collide")
    namespace_by_model: Dict[str, Tuple[str, ...]] = {}
    for model in MODEL_CONTRACT:
        model_key = str(model["key"])
        parameter_rows = [
            row for row in evaluation_rows if row["model_key"] == model_key
        ]
        declared = {
            tuple(str(token) for token in row.get("namespace_tokens", ()))
            for row in parameter_rows
        }
        if len(declared) != 1:
            raise RuntimeError("parameter namespace manifest differs across evaluation rows")
        tokens = next(iter(declared))
        if len(tokens) != 24 or len(set(tokens)) != 24:
            raise RuntimeError("parameter namespace does not contain 24 distinct tokens")
        namespace_by_model[model_key] = tokens
    all_namespace_tokens = [
        token for tokens in namespace_by_model.values() for token in tokens
    ]
    if len(all_namespace_tokens) != len(set(all_namespace_tokens)):
        raise RuntimeError("model-specific parameter namespaces collide")
    nonparameter_complete_tokens = {
        token
        for row in public
        if row["repair_class"] != "parameter_or_representation_change"
        for token in re.findall(
            r"[A-Za-z0-9]+", canonical_json(row).decode("utf-8")
        )
    }
    if set(all_namespace_tokens).intersection(nonparameter_complete_tokens):
        raise RuntimeError("parameter namespace token entered a non-parameter stimulus")
    commitments = [
        str(commitment)
        for row in public
        for arm in row["seed_commitments"].values()
        for commitment in arm
    ]
    if len(commitments) != len(set(commitments)):
        raise RuntimeError("fresh execution seed commitments collide")


def verify_public_task(row: Mapping[str, Any], freeze_id: str) -> None:
    if row.get("freeze_id") != freeze_id or row.get("partition") != "qualification":
        raise RuntimeError("task is outside the fresh qualification freeze")
    if not str(row.get("task_id", "")).startswith("q2_") or not row.get("pilot_excluded"):
        raise RuntimeError("task failed fresh namespace or pilot exclusion")
    observed_prompt_hash = sha256_bytes(str(row["prompt"]).encode("utf-8"))
    if observed_prompt_hash != row.get("prompt_hash"):
        raise RuntimeError("task prompt hash mismatch")
    if digest(row["output_schema"]) != row.get("output_schema_hash"):
        raise RuntimeError("task output-schema hash mismatch")
    body = {key: value for key, value in row.items() if key != "public_content_hash"}
    if digest(body) != row.get("public_content_hash"):
        raise RuntimeError("task public-content hash mismatch")


def panel_commitments(panel: Mapping[str, Iterable[Mapping[str, Any]]]) -> Mapping[str, Any]:
    body = {
        "version": VERSION,
        "public_root": digest(list(panel["public"])),
        "authority_root": digest(list(panel["authority"])),
        "adaptation_root": digest(list(panel["adaptation"])),
        "public_count": len(tuple(panel["public"])),
        "authority_count": len(tuple(panel["authority"])),
        "adaptation_count": len(tuple(panel["adaptation"])),
    }
    return {**body, "panel_commitment_id": digest(body)}
