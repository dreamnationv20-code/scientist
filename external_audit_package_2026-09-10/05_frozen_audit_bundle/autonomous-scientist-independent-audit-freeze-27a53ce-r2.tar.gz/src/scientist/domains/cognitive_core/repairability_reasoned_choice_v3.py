"""Reasoning-then-choice successor for candidate-availability repairability.

Each candidate consists of a bounded free-form solve pass followed by a forced,
prompt-visible A/B/C/D choice.  This prevents both historic interface errors:
truncated ``FINAL:`` markers and a first-token constraint that precluded
reasoning.  Gates are per model, so an unqualified model abstains without
blocking a qualified model's pre-registered prospective panel.
"""

from __future__ import annotations

import hashlib
import random
from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.repairability_constrained_choice_v2 import (
    FORGE_HYPOTHESIS_ID, FORGE_PROPOSAL_ID, candidate_bank_gate, choice_receipt,
    choice_token_ids, conservative_difference_interval, development_qualified,
    digest, file_sha256, invariance_selection, jsonl, read_rows, score_candidate,
)
from scientist.domains.cognitive_core.repairability_constrained_choice_v2 import (
    _invariance_task as _source_invariance_task,
)
from scientist.domains.cognitive_core.repairability_constrained_choice_v2 import (
    _planning_task as _source_planning_task,
)


VERSION = "cognitive-repairability-reasoned-choice-v3"
MODEL_ORDER = ("qwen3_1p7b", "qwen2p5_3b")
TASK_SEED = 860_403_100
SCHEDULE_SEED = 860_403_200
PREFLIGHT_TASK_COUNT = 8
PREFLIGHT_CALLS = 1
DEVELOPMENT_TASK_COUNT = 16
PROSPECTIVE_POOL_COUNT = 32
INVARIANCE_TASK_COUNT = 8
SELECTED_PROSPECTIVE_COUNT = 12
CANDIDATE_BANK_CALLS = 5
TEMPERATURE = 0.55
REASONING_MAX_TOKENS = 192
MINIMUM_REASONING_TOKENS = 24
MODEL_HOUR_CAPS = {"qwen3_1p7b": 0.95, "qwen2p5_3b": 1.35}
MAXIMUM_TOTAL_HOURS = 2.30


def derive_seed(*labels: object) -> int:
    payload = "\0".join(str(value) for value in (SCHEDULE_SEED, *labels))
    return int.from_bytes(hashlib.sha256(payload.encode("utf-8")).digest()[:4], "big")


def _v3_task(task: Mapping[str, Any]) -> Mapping[str, Any]:
    task_id = str(task["task_id"]).replace("ccv2-", "rcv3-")
    task_context = str(task["prompt"]).split("\n\nChoose the correct", 1)[0]
    reasoning_prompt = (
        task_context
        + "\n\nWork through the transition or relation task carefully. This is a "
        "private scratchpad for a later answer-selection step. State the route or "
        "relation reasoning that determines the correct option; do not rely on any "
        "information outside the prompt."
    )
    return {**task, "version": VERSION, "task_id": task_id, "reasoning_prompt": reasoning_prompt}


def _planning_task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    task, authority = _source_planning_task(index, split, rng)
    v3 = _v3_task(task)
    return v3, {**authority, "task_id": v3["task_id"], "family": v3["family"]}


def _invariance_task(index: int, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    task, authority = _source_invariance_task(index, rng)
    v3 = _v3_task(task)
    return v3, {**authority, "task_id": v3["task_id"], "family": v3["family"]}


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(TASK_SEED)
    preflight: list[Mapping[str, Any]] = []
    public: list[Mapping[str, Any]] = []
    authority: list[Mapping[str, Any]] = []
    for index in range(PREFLIGHT_TASK_COUNT):
        task, _ = _planning_task(index, "reasoning_preflight", rng)
        preflight.append({**task, "profile": "reasoning_delivery_preflight"})
    for index in range(DEVELOPMENT_TASK_COUNT):
        task, answer = _planning_task(index, "development", rng); public.append(task); authority.append(answer)
    for index in range(PROSPECTIVE_POOL_COUNT):
        task, answer = _planning_task(index, "prospective", rng); public.append(task); authority.append(answer)
    for index in range(INVARIANCE_TASK_COUNT):
        task, answer = _invariance_task(index, rng); public.append(task); authority.append(answer)
    if len(preflight) != 8 or len(public) != 56 or len(authority) != 56:
        raise RuntimeError("reasoned-choice panel count mismatch")
    if len({str(row["task_id"]) for row in (*preflight, *public)}) != 64:
        raise RuntimeError("reasoned-choice task identifiers are not unique")
    return preflight, public, authority


def build_schedule(preflight: Sequence[Mapping[str, Any]], public: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []
    for model_key in MODEL_ORDER:
        for split, tasks, calls in (
            ("reasoning_preflight", preflight, PREFLIGHT_CALLS),
            ("development", [row for row in public if row["split"] == "development"], CANDIDATE_BANK_CALLS),
            ("prospective", [row for row in public if row["split"] == "prospective"], CANDIDATE_BANK_CALLS),
        ):
            identifiers = sorted(str(row["task_id"]) for row in tasks)
            random.Random(derive_seed(model_key, split, "order")).shuffle(identifiers)
            for order, task_id in enumerate(identifiers):
                rows.append({"model_key": model_key, "split": split, "task_id": task_id, "task_order_index": order, "candidate_seeds": [derive_seed(model_key, task_id, "candidate", call) for call in range(calls)]})
    return rows


def reasoning_preflight_passed(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    expected = PREFLIGHT_TASK_COUNT * PREFLIGHT_CALLS
    completed = sum(int(row["completed_calls"]) for row in rows)
    choice_delivered = sum(int(row["choice_delivered_calls"]) for row in rows)
    reasoning_delivered = sum(int(row["reasoning_delivered_calls"]) for row in rows)
    valid = all(bool(row["all_choices_prompt_valid"]) for row in rows)
    return {"expected_calls": expected, "completed_calls": completed, "choice_delivered_calls": choice_delivered, "reasoning_delivered_calls": reasoning_delivered, "all_choices_prompt_valid": valid, "qualified": completed == expected and choice_delivered == expected and reasoning_delivered == expected and valid, "uses_no_evaluation_authority": True}


def choice_prompt_with_scratchpad(task: Mapping[str, Any], scratchpad: str) -> str:
    context = str(task["prompt"]).split("\n\nChoose the correct", 1)[0]
    mapping = task["choice_mapping_prompt_visible"]
    options = "\n".join(f"{label}: {mapping[label]}" for label in ("A", "B", "C", "D"))
    return (
        context
        + "\n\nPRIVATE SCRATCHPAD FROM THIS MODEL'S SOLVE PASS:\n"
        + scratchpad
        + "\n\nChoose the correct option using the original task and this scratchpad.\n"
        + options
        + "\nOutput only one option letter. Do not explain.\nFINAL: "
    )
