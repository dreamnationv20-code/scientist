from __future__ import annotations

import hashlib
import hmac
import json
import math
import os
import random
import tempfile
import base64
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence


VERSION = "cognitive-repairability-theory-neutral-reframe-runtime-v1"
CAMPAIGN_NAME = "cognitive-repairability-theory-neutral-qualification-reframe-q0"
MODEL_ORDER = ("qwen3_1p7b", "qwen2p5_3b")
MODEL_CONTRACT = {
    "qwen3_1p7b": {
        "path": "models/Qwen3-1.7B-MLX-4bit",
        "maximum_attempt_hours": {
            "compute": 0.08,
            "explicit_state": 0.07,
            "verification": 0.07,
            "tools": 0.07,
            "parameter_or_representation_change": 0.20,
        },
    },
    "qwen2p5_3b": {
        "path": "models/Qwen2.5-3B-Instruct-4bit",
        "maximum_attempt_hours": {
            "compute": 0.14,
            "explicit_state": 0.12,
            "verification": 0.12,
            "tools": 0.12,
            "parameter_or_representation_change": 0.35,
        },
    },
}
REPAIR_CLASSES = (
    "compute",
    "explicit_state",
    "verification",
    "tools",
    "parameter_or_representation_change",
)
ATTEMPTS = ("P", "A")
CODES = ("A", "B", "C", "D")
SYMBOLS = ("ka", "mi", "su", "to")
PARAMETER_FEATURES = (
    "zanu|pev",
    "zanu|rok",
    "zanu|sil",
    "zanu|tav",
    "bemi|pev",
    "bemi|rok",
    "bemi|sil",
    "bemi|tav",
    "coru|pev",
    "coru|rok",
    "coru|sil",
    "coru|tav",
    "dafi|pev",
    "dafi|rok",
    "dafi|sil",
    "dafi|tav",
)
POSITIVE_COUNT = 64
INVARIANCE_COUNT = 32
TRIALS_PER_ATTEMPT = POSITIVE_COUNT + INVARIANCE_COUNT
MAXIMUM_NORMALIZED_HOURS = 3.28


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def file_sha256(path: Path) -> str:
    body = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            body.update(block)
    return body.hexdigest()


def derive_bytes(secret: bytes, *labels: object, length: int = 32) -> bytes:
    message = b"\0".join(str(label).encode("utf-8") for label in labels)
    output = b""
    counter = 0
    while len(output) < length:
        output += hmac.new(
            secret,
            b"repairability-reframe-v1\0"
            + counter.to_bytes(4, "big")
            + message,
            hashlib.sha256,
        ).digest()
        counter += 1
    return output[:length]


def derive_seed(secret: bytes, *labels: object) -> int:
    return int.from_bytes(derive_bytes(secret, *labels, length=8), "big")


def seed_commitment(seed: int) -> str:
    return hashlib.sha256(seed.to_bytes(8, "big")).hexdigest()


def _record_keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    output = b""
    counter = 0
    while len(output) < length:
        output += hmac.new(
            key,
            b"record-stream-v1\0" + nonce + counter.to_bytes(8, "big"),
            hashlib.sha256,
        ).digest()
        counter += 1
    return output[:length]


def seal_record(key: bytes, identity: str, value: Mapping[str, Any]) -> Mapping[str, str]:
    nonce = hashlib.sha256(("record-nonce-v1\0" + identity).encode()).digest()[:16]
    plaintext = canonical_json(value)
    stream = _record_keystream(key, nonce, len(plaintext))
    ciphertext = bytes(left ^ right for left, right in zip(plaintext, stream))
    tag = hmac.new(
        key,
        b"record-tag-v1\0" + nonce + ciphertext,
        hashlib.sha256,
    ).digest()
    return {
        "identity": identity,
        "nonce_b64": base64.b64encode(nonce).decode("ascii"),
        "ciphertext_b64": base64.b64encode(ciphertext).decode("ascii"),
        "tag_b64": base64.b64encode(tag).decode("ascii"),
    }


def open_record(key: bytes, sealed: Mapping[str, str]) -> Mapping[str, Any]:
    nonce = base64.b64decode(sealed["nonce_b64"], validate=True)
    ciphertext = base64.b64decode(sealed["ciphertext_b64"], validate=True)
    tag = base64.b64decode(sealed["tag_b64"], validate=True)
    expected = hmac.new(
        key,
        b"record-tag-v1\0" + nonce + ciphertext,
        hashlib.sha256,
    ).digest()
    if not hmac.compare_digest(tag, expected):
        raise RuntimeError("sealed response record authentication failed")
    stream = _record_keystream(key, nonce, len(ciphertext))
    plaintext = bytes(left ^ right for left, right in zip(ciphertext, stream))
    value = json.loads(plaintext.decode("utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("sealed response record is not an object")
    return value


def combine_entropy(custodian_entropy: bytes, broker_entropy: bytes) -> bytes:
    if len(custodian_entropy) < 32 or len(broker_entropy) < 32:
        raise ValueError("each entropy contribution must contain at least 256 bits")
    return hmac.new(
        custodian_entropy,
        b"campaign-combined-entropy\0" + broker_entropy,
        hashlib.sha256,
    ).digest()


def parse_final_response_bytes(value: bytes) -> str | None:
    if value not in {b"A\n", b"B\n", b"C\n", b"D\n"}:
        return None
    return value[:1].decode("ascii")


def parse_call_ack_bytes(value: bytes) -> bool:
    return value == b"!"


def _permutation(rng: random.Random, values: Sequence[str]) -> tuple[str, ...]:
    result = list(values)
    rng.shuffle(result)
    return tuple(result)


def _legend(rng: random.Random) -> Mapping[str, str]:
    codes = _permutation(rng, CODES)
    return {symbol: code for symbol, code in zip(SYMBOLS, codes)}


def _legend_text(legend: Mapping[str, str]) -> str:
    return "; ".join(f"{symbol}->{legend[symbol]}" for symbol in SYMBOLS)


def _common_instruction() -> str:
    return (
        "Reply with exactly one capital code letter followed by a newline. "
        "Allowed byte strings are A\\n, B\\n, C\\n, or D\\n. Emit nothing else."
    )


def _compute_task(rng: random.Random, index: int, attempt: str) -> Mapping[str, Any]:
    legend = _legend(rng)
    signal = next(symbol for symbol, code in legend.items() if code == CODES[index % 4])
    invariant = index >= POSITIVE_COUNT
    distractor = SYMBOLS[(SYMBOLS.index(signal) + 1 + rng.randrange(2)) % 4]
    view_symbols = (signal, signal, signal) if invariant else (distractor, signal, signal)
    permutations = [_permutation(rng, SYMBOLS) for _ in range(3)]
    prompts = []
    for view_index, (visible, order) in enumerate(zip(view_symbols, permutations), start=1):
        ordered_legend = "; ".join(f"{symbol}->{legend[symbol]}" for symbol in order)
        prompts.append(
            (
                f"Synthetic redundancy probe {attempt}, view {view_index}. "
                f"Visible signal: {visible}. Legend: {ordered_legend}. "
                f"Use the legend for this view. {_common_instruction()}"
            )
        )
    return {
        "kind": "invariance" if invariant else "positive_control",
        "gold_code": legend[signal],
        "prompt_payload": {
            "view_prompts": prompts,
            "primary_aggregator": "majority_then_lexicographic_code",
            "alternate_sequence": "initial_then_two_checklist_revisions_with_commit",
        },
        "fixture": {
            "signal": signal,
            "view_symbols": list(view_symbols),
            "legend": legend,
        },
    }


def _state_task(rng: random.Random, index: int, attempt: str) -> Mapping[str, Any]:
    legend = _legend(rng)
    carry = next(symbol for symbol, code in legend.items() if code == CODES[index % 4])
    invariant = index >= POSITIVE_COUNT
    distractors = " ".join(_permutation(rng, ("red", "blue", "round", "square")))
    stage_one = (
        f"Synthetic state probe {attempt}. Carry the visible token {carry} across the "
        f"interruption. Interruption words: {distractors}. Reply with exactly !"
    )
    direct = f" Direct visible token: {carry}." if invariant else ""
    stage_two_template = (
        "Resume the synthetic state probe. Authenticated sidecar carry={CARRY}; "
        f"legend: {_legend_text(legend)}.{direct} {_common_instruction()}"
    )
    return {
        "kind": "invariance" if invariant else "positive_control",
        "gold_code": legend[carry],
        "prompt_payload": {
            "stage_one_prompt": stage_one,
            "stage_two_template": stage_two_template,
            "treatment_state": carry,
            "control_state": "zz",
        },
        "fixture": {"carry": carry, "legend": legend, "invariant": invariant},
    }


def _verification_candidates(
    rng: random.Random, target_index: int
) -> tuple[list[str], Mapping[str, Any]]:
    length = 4 + rng.randrange(3)
    checksum = rng.randrange(10)
    candidates = []
    for candidate_index in range(4):
        candidate_length = length if candidate_index == target_index else length + 1
        digits = [rng.randrange(10) for _ in range(candidate_length)]
        desired = checksum if candidate_index == target_index else (checksum + 1) % 10
        digits[-1] = (desired - sum(digits[:-1])) % 10
        candidates.append("".join(str(value) for value in digits))
    return candidates, {"required_length": length, "checksum_mod10": checksum}


def verification_bits(task: Mapping[str, Any]) -> tuple[int, int, int, int]:
    candidates = task["prompt_payload"]["candidates"]
    required_length = int(task["prompt_payload"]["required_length"])
    checksum = int(task["prompt_payload"]["checksum_mod10"])
    return tuple(
        int(len(candidate) == required_length and sum(map(int, candidate)) % 10 == checksum)
        for candidate in candidates
    )  # type: ignore[return-value]


def _verification_task(
    rng: random.Random, index: int, attempt: str
) -> Mapping[str, Any]:
    position_codes = _permutation(rng, CODES)
    target_index = position_codes.index(CODES[index % 4])
    candidates, constraint = _verification_candidates(rng, target_index)
    invariant = index >= POSITIVE_COUNT
    direct = (
        f" Visible one-hot certificate: {' '.join(str(int(i == target_index)) for i in range(4))}."
        if invariant
        else ""
    )
    prompt = (
        f"Synthetic verification probe {attempt}. Candidates: "
        + ", ".join(f"{i + 1}={value}" for i, value in enumerate(candidates))
        + f". Visible constraint: length={constraint['required_length']} and digit-sum mod 10="
        + f"{constraint['checksum_mod10']}. Position legend: "
        + "; ".join(f"{i + 1}->{code}" for i, code in enumerate(position_codes))
        + ". Authenticated verifier vector={BITS}."
        + direct
        + " Select the position whose verifier bit is 1. "
        + _common_instruction()
    )
    return {
        "kind": "invariance" if invariant else "positive_control",
        "gold_code": position_codes[target_index],
        "prompt_payload": {
            "prompt_template": prompt,
            "candidates": candidates,
            **constraint,
            "position_codes": list(position_codes),
            "control_bits": [int((index + offset) % 4 == 0) for offset in range(4)],
        },
        "fixture": {"target_index": target_index, "invariant": invariant},
    }


def _transform_symbol(operation: str, left: str, right: str) -> str:
    left_index = SYMBOLS.index(left)
    right_index = SYMBOLS.index(right)
    if operation == "forward_sum":
        result = (left_index + right_index) % 4
    elif operation == "reverse_difference":
        result = (right_index - left_index) % 4
    else:
        raise ValueError("unknown finite-symbol operation")
    return SYMBOLS[result]


_ALTERNATE_TOOL_TABLE = {
    ("forward_sum", "ka", "ka"): "ka",
    ("forward_sum", "ka", "mi"): "mi",
    ("forward_sum", "ka", "su"): "su",
    ("forward_sum", "ka", "to"): "to",
    ("forward_sum", "mi", "ka"): "mi",
    ("forward_sum", "mi", "mi"): "su",
    ("forward_sum", "mi", "su"): "to",
    ("forward_sum", "mi", "to"): "ka",
    ("forward_sum", "su", "ka"): "su",
    ("forward_sum", "su", "mi"): "to",
    ("forward_sum", "su", "su"): "ka",
    ("forward_sum", "su", "to"): "mi",
    ("forward_sum", "to", "ka"): "to",
    ("forward_sum", "to", "mi"): "ka",
    ("forward_sum", "to", "su"): "mi",
    ("forward_sum", "to", "to"): "su",
    ("reverse_difference", "ka", "ka"): "ka",
    ("reverse_difference", "ka", "mi"): "mi",
    ("reverse_difference", "ka", "su"): "su",
    ("reverse_difference", "ka", "to"): "to",
    ("reverse_difference", "mi", "ka"): "to",
    ("reverse_difference", "mi", "mi"): "ka",
    ("reverse_difference", "mi", "su"): "mi",
    ("reverse_difference", "mi", "to"): "su",
    ("reverse_difference", "su", "ka"): "su",
    ("reverse_difference", "su", "mi"): "to",
    ("reverse_difference", "su", "su"): "ka",
    ("reverse_difference", "su", "to"): "mi",
    ("reverse_difference", "to", "ka"): "mi",
    ("reverse_difference", "to", "mi"): "su",
    ("reverse_difference", "to", "su"): "to",
    ("reverse_difference", "to", "to"): "ka",
}


def tool_output(task: Mapping[str, Any], alternate: bool = False) -> str:
    payload = task["prompt_payload"]
    operation = str(payload["operation"])
    left = str(payload["left"])
    right = str(payload["right"])
    if alternate:
        return _ALTERNATE_TOOL_TABLE[(operation, left, right)]
    return _transform_symbol(operation, left, right)


def _tool_task(rng: random.Random, index: int, attempt: str) -> Mapping[str, Any]:
    legend = _legend(rng)
    operation = ("forward_sum", "reverse_difference")[rng.randrange(2)]
    left = SYMBOLS[rng.randrange(4)]
    right = SYMBOLS[rng.randrange(4)]
    intermediate = _transform_symbol(operation, left, right)
    target_code = CODES[index % 4]
    # Rotate the visible legend so the tool-derived intermediate maps to the
    # balanced target code while remaining independently visible to the model.
    other_symbols = [symbol for symbol in SYMBOLS if symbol != intermediate]
    other_codes = [code for code in CODES if code != target_code]
    rng.shuffle(other_codes)
    legend = {intermediate: target_code, **dict(zip(other_symbols, other_codes))}
    invariant = index >= POSITIVE_COUNT
    direct = f" Direct visible intermediate: {intermediate}." if invariant else ""
    ack_prompt = (
        f"Synthetic tool probe {attempt}. Authorized operation={operation}; "
        f"left={left}; right={right}. Reply with exactly ! to request the declared tool."
    )
    final_template = (
        f"Tool returned fixed-width intermediate {{INTERMEDIATE}}. Legend: {_legend_text(legend)}."
        + direct
        + " Map the intermediate through the visible legend. "
        + _common_instruction()
    )
    return {
        "kind": "invariance" if invariant else "positive_control",
        "gold_code": target_code,
        "prompt_payload": {
            "ack_prompt": ack_prompt,
            "final_template": final_template,
            "operation": operation,
            "left": left,
            "right": right,
            "control_intermediate": SYMBOLS[(SYMBOLS.index(intermediate) + 1) % 4],
        },
        "fixture": {"intermediate": intermediate, "legend": legend, "invariant": invariant},
    }


def _parameter_rule(feature: str, attempt: str) -> str:
    if feature not in PARAMETER_FEATURES or attempt not in ATTEMPTS:
        raise ValueError("parameter rule received an unknown feature family")
    # Two balanced, non-numeric rule families.  The mapping is deliberately not
    # written into evaluation prompts; it is defined by the adaptation examples.
    permutations = {
        "P": (2, 0, 3, 1, 1, 3, 0, 2, 3, 1, 2, 0, 0, 2, 1, 3),
        "A": (1, 3, 0, 2, 2, 0, 3, 1, 0, 2, 1, 3, 3, 1, 2, 0),
    }
    return CODES[permutations[attempt][PARAMETER_FEATURES.index(feature)]]


def _parameter_task(
    rng: random.Random, index: int, attempt: str
) -> Mapping[str, Any]:
    invariant = index >= POSITIVE_COUNT
    feature_index = index % len(PARAMETER_FEATURES)
    feature = PARAMETER_FEATURES[feature_index]
    # The task RNG is domain-separated by model, attempt, and trial index in
    # ``build_trial``; drawing here makes raw evaluation prompts disjoint across
    # both model partitions as well as P/A.
    nonce = rng.getrandbits(32).to_bytes(4, "big").hex()
    gold = _parameter_rule(feature, attempt)
    if invariant:
        prompt = (
            f"Visible identity probe: pair {feature} maps directly to code {gold}. "
            f"Nonce={nonce}. {_common_instruction()}"
        )
    else:
        prompt = (
            f"Learned synthetic mapping probe {attempt}: pair={feature}; nonce={nonce}. "
            f"Apply the adaptation mapping. {_common_instruction()}"
        )
    return {
        "kind": "invariance" if invariant else "positive_control",
        "gold_code": gold,
        "prompt_payload": {"prompt": prompt, "feature": feature, "nonce": nonce},
        "fixture": {"feature": feature, "invariant": invariant},
    }


def build_trial(
    secret: bytes,
    campaign_id: str,
    model_key: str,
    repair_class: str,
    attempt: str,
    index: int,
) -> tuple[Mapping[str, Any], str]:
    if model_key not in MODEL_ORDER or repair_class not in REPAIR_CLASSES:
        raise ValueError("unknown qualification cell")
    if attempt not in ATTEMPTS or not 0 <= index < TRIALS_PER_ATTEMPT:
        raise ValueError("invalid attempt or trial index")
    seed = derive_seed(
        secret, campaign_id, "task", model_key, repair_class, attempt, index
    )
    rng = random.Random(seed)
    builder = {
        "compute": _compute_task,
        "explicit_state": _state_task,
        "verification": _verification_task,
        "tools": _tool_task,
        "parameter_or_representation_change": _parameter_task,
    }[repair_class]
    generated = builder(rng, index, attempt)
    partition_tag = digest(
        {
            "campaign_id": campaign_id,
            "model_key": model_key,
            "repair_class": repair_class,
            "attempt": attempt,
            "trial_index": index,
            "task_seed_commitment": seed_commitment(seed),
        }
    )[:24]
    prompt_payload = {
        **generated["prompt_payload"],
        "partition_tag": partition_tag,
    }
    identity = {
        "campaign_id": campaign_id,
        "model_key": model_key,
        "repair_class": repair_class,
        "attempt": attempt,
        "trial_index": index,
        "kind": generated["kind"],
        "prompt_payload": prompt_payload,
    }
    trial_id = digest(identity)
    public = {
        **identity,
        "trial_id": trial_id,
        "task_seed_commitment": seed_commitment(seed),
        "fixture_commitment": digest(generated["fixture"]),
    }
    return public, str(generated["gold_code"])


def parameter_adaptation_rows(
    secret: bytes,
    campaign_id: str,
    model_key: str,
    attempt: str,
    sham: bool = False,
) -> list[Mapping[str, Any]]:
    rng = random.Random(
        derive_seed(secret, campaign_id, "adaptation", model_key, attempt)
    )
    rows = []
    for index in range(256):
        feature = PARAMETER_FEATURES[index % len(PARAMETER_FEATURES)]
        nonce = derive_bytes(
            secret,
            campaign_id,
            "adaptation-nonce",
            model_key,
            attempt,
            index,
            length=4,
        ).hex()
        code = _parameter_rule(feature, attempt)
        if sham:
            # A fixed point-free balanced permutation; prompts, identifiers,
            # batches, and order remain identical to treatment.
            code = CODES[(CODES.index(code) + 1) % 4]
        prompt = (
            f"Synthetic adaptation example {attempt}: pair={feature}; nonce={nonce}. "
            + _common_instruction()
        )
        rows.append(
            {
                "adaptation_id": digest(
                    {
                        "campaign_id": campaign_id,
                        "model_key": model_key,
                        "attempt": attempt,
                        "index": index,
                        "prompt": prompt,
                    }
                ),
                "prompt": prompt,
                "response": code + "\n",
                "feature": feature,
            }
        )
    rng.shuffle(rows)
    return rows


def release_roles(repair_class: str) -> Mapping[str, int]:
    return {
        "compute": {"treatment": 3, "control": 3},
        "explicit_state": {"treatment": 2, "control": 2},
        "verification": {"treatment": 1, "control": 1},
        "tools": {"treatment": 2, "control": 2},
        "parameter_or_representation_change": {
            "treatment": 1,
            "sham": 1,
            "base": 1,
        },
    }[repair_class]


def build_panel(secret: bytes, campaign_id: str) -> Mapping[str, Any]:
    public_trials = []
    gold: Dict[str, str] = {}
    releases = []
    raw_seeds: Dict[str, int] = {}
    for model_key in MODEL_ORDER:
        for repair_class in REPAIR_CLASSES:
            for attempt in ATTEMPTS:
                for index in range(TRIALS_PER_ATTEMPT):
                    trial, code = build_trial(
                        secret,
                        campaign_id,
                        model_key,
                        repair_class,
                        attempt,
                        index,
                    )
                    public_trials.append(trial)
                    gold[str(trial["trial_id"])] = code
                    for arm, call_count in release_roles(repair_class).items():
                        for call_index in range(call_count):
                            seed = derive_seed(
                                secret,
                                campaign_id,
                                "call",
                                model_key,
                                repair_class,
                                attempt,
                                trial["trial_id"],
                                "paired-arms",
                                call_index,
                            )
                            body = {
                                "campaign_id": campaign_id,
                                "model_key": model_key,
                                "repair_class": repair_class,
                                "attempt": attempt,
                                "trial_id": trial["trial_id"],
                                "arm": arm,
                                "call_index": call_index,
                                "seed_commitment": seed_commitment(seed),
                            }
                            release_id = digest(body)
                            releases.append({**body, "release_id": release_id})
                            raw_seeds[release_id] = seed
                if repair_class == "parameter_or_representation_change":
                    for training_arm in ("treatment_training", "sham_training"):
                        seed = derive_seed(
                            secret,
                            campaign_id,
                            "training",
                            model_key,
                            repair_class,
                            attempt,
                            training_arm,
                        )
                        body = {
                            "campaign_id": campaign_id,
                            "model_key": model_key,
                            "repair_class": repair_class,
                            "attempt": attempt,
                            "trial_id": None,
                            "arm": training_arm,
                            "call_index": 0,
                            "seed_commitment": seed_commitment(seed),
                        }
                        release_id = digest(body)
                        releases.append({**body, "release_id": release_id})
                        raw_seeds[release_id] = seed
    release_ids = [str(row["release_id"]) for row in releases]
    if len(release_ids) != len(set(release_ids)):
        raise RuntimeError("release schedule contains a duplicate identity")
    if len(public_trials) != len(MODEL_ORDER) * len(REPAIR_CLASSES) * 2 * 96:
        raise RuntimeError("panel does not cover the exact frozen matrix")
    record_key = derive_bytes(secret, campaign_id, "sealed-record-key", length=32)
    scorer_salt = derive_bytes(secret, campaign_id, "scorer-salt", length=32)
    public_body = {
        "version": VERSION,
        "campaign_id": campaign_id,
        "models": list(MODEL_ORDER),
        "repair_classes": list(REPAIR_CLASSES),
        "attempts": list(ATTEMPTS),
        "positive_count": POSITIVE_COUNT,
        "invariance_count": INVARIANCE_COUNT,
        "sealed_record_key_commitment": hashlib.sha256(record_key).hexdigest(),
        "scorer_salt_commitment": hashlib.sha256(scorer_salt).hexdigest(),
        "trials": public_trials,
        "release_schedule": releases,
    }
    public = {**public_body, "panel_id": digest(public_body)}
    sealed_body = {
        "version": VERSION,
        "campaign_id": campaign_id,
        "panel_id": public["panel_id"],
        "gold_by_trial": gold,
        "raw_seed_by_release": raw_seeds,
        "sealed_record_key_hex": record_key.hex(),
        "scorer_salt_hex": scorer_salt.hex(),
    }
    sealed = {**sealed_body, "vault_id": digest(sealed_body)}
    return {"public": public, "sealed": sealed}


def state_sidecar(
    trial_id: str, carry: str, source_prompt_hash: str, treatment: bool
) -> Mapping[str, Any]:
    value = carry if treatment else "zz"
    body = {
        "schema": "typed-state-sidecar-v1",
        "trial_id": trial_id,
        "progress": 1,
        "carry": value,
        "checklist": 1 if treatment else 0,
        "source_prompt_hash": source_prompt_hash,
    }
    carry_code = SYMBOLS.index(carry) if treatment else 255
    payload = (
        b"STV1"
        + bytes((1, carry_code, 1 if treatment else 0, 0))
        + bytes.fromhex(source_prompt_hash)[:8]
    )
    return {
        "body": body,
        "payload_hex": payload.hex(),
        "sidecar_hash": hashlib.sha256(payload).hexdigest(),
        "byte_length": 16,
        "log_projection": {
            "trial_id": trial_id,
            "sidecar_hash": hashlib.sha256(payload).hexdigest(),
            "schema_valid": True,
        },
    }


def bitmap_sidecar(
    trial_id: str, carry: str, source_prompt_hash: str, treatment: bool
) -> Mapping[str, Any]:
    """Distinct eight-bit checklist representation with a 16-byte envelope."""
    bitmap = (1 << SYMBOLS.index(carry)) if treatment else 0
    payload = bytes((bitmap,)) + bytes.fromhex(source_prompt_hash)[:8] + b"\0" * 7
    return {
        "bitmap": bitmap,
        "payload_hex": payload.hex(),
        "sidecar_hash": hashlib.sha256(payload).hexdigest(),
        "byte_length": len(payload),
        "log_projection": {
            "trial_id": trial_id,
            "sidecar_hash": hashlib.sha256(payload).hexdigest(),
            "schema_valid": len(payload) == 16 and 0 <= bitmap <= 15,
        },
    }


def verification_certificates(
    task: Mapping[str, Any], alternate: bool = False
) -> tuple[Mapping[str, Any], ...]:
    payload = task["prompt_payload"]
    required_length = int(payload["required_length"])
    required_checksum = int(payload["checksum_mod10"])
    rows = []
    for index, candidate in enumerate(payload["candidates"]):
        if alternate:
            # A finite-state scan, separate from the primary predicate path.
            state_length = 0
            state_checksum = 0
            for character in str(candidate):
                state_length += 1
                state_checksum = (state_checksum + ord(character) - ord("0")) % 10
            passed = state_length == required_length and state_checksum == required_checksum
            implementation = "table-driven-character-dfa-v1"
        else:
            passed = len(str(candidate)) == required_length and sum(
                int(character) for character in str(candidate)
            ) % 10 == required_checksum
            implementation = "per-candidate-checksum-length-verifier-v1"
        body = {
            "candidate_index": index,
            "request_hash": digest(
                {
                    "candidate": candidate,
                    "required_length": required_length,
                    "required_checksum": required_checksum,
                }
            ),
            "status_bit": int(passed),
            "implementation": implementation,
        }
        rows.append({**body, "certificate_tag": digest(body)})
    return tuple(rows)


class ConsumeOnceBroker:
    """Campaign-scoped transactional seed release with no retry semantics."""

    def __init__(
        self,
        schedule: Sequence[Mapping[str, Any]],
        raw_seed_by_release: Mapping[str, int],
        ledger_path: Path,
    ) -> None:
        self.schedule = {str(row["release_id"]): dict(row) for row in schedule}
        if len(self.schedule) != len(schedule):
            raise RuntimeError("broker schedule contains duplicate release IDs")
        self.raw_seed_by_release = {
            str(key): int(value) for key, value in raw_seed_by_release.items()
        }
        if set(self.schedule) != set(self.raw_seed_by_release):
            raise RuntimeError("broker schedule and sealed seed vault disagree")
        self.ledger_path = Path(ledger_path)
        self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
        self._consumed: Dict[str, Mapping[str, Any]] = {}
        self._tail: str | None = None
        if self.ledger_path.exists():
            for line in self.ledger_path.read_text(encoding="utf-8").splitlines():
                if not line:
                    continue
                record = json.loads(line)
                body = {key: value for key, value in record.items() if key != "entry_id"}
                if digest(body) != record.get("entry_id"):
                    raise RuntimeError("broker consume ledger identity mismatch")
                if body["previous_entry_id"] != self._tail:
                    raise RuntimeError("broker consume ledger chain mismatch")
                release_id = str(body["release_id"])
                if release_id in self._consumed:
                    raise RuntimeError("broker consume ledger reused a release")
                self._consumed[release_id] = record
                self._tail = str(record["entry_id"])

    @property
    def consumed_release_ids(self) -> frozenset[str]:
        return frozenset(self._consumed)

    def release(self, release_id: str, rendered_prompt_hash: str) -> int:
        if release_id not in self.schedule:
            raise RuntimeError("seed release is outside the sealed schedule")
        if release_id in self._consumed:
            raise RuntimeError("seed release was already consumed; retries are forbidden")
        if len(rendered_prompt_hash) != 64 or any(
            character not in "0123456789abcdef" for character in rendered_prompt_hash
        ):
            raise RuntimeError("seed release requires a rendered-prompt hash")
        seed = self.raw_seed_by_release[release_id]
        contract = self.schedule[release_id]
        if seed_commitment(seed) != contract["seed_commitment"]:
            raise RuntimeError("seed vault fails the sealed commitment")
        body = {
            "version": VERSION,
            "sequence": len(self._consumed),
            "previous_entry_id": self._tail,
            "release_id": release_id,
            "campaign_id": contract["campaign_id"],
            "model_key": contract["model_key"],
            "repair_class": contract["repair_class"],
            "attempt": contract["attempt"],
            "trial_id": contract["trial_id"],
            "arm": contract["arm"],
            "call_index": contract["call_index"],
            "seed_commitment": contract["seed_commitment"],
            "rendered_prompt_hash": rendered_prompt_hash,
            "consume_status": "atomically_consumed_before_dispatch",
        }
        record = {**body, "entry_id": digest(body)}
        descriptor = os.open(
            self.ledger_path,
            os.O_WRONLY | os.O_CREAT | os.O_APPEND,
            0o600,
        )
        with os.fdopen(descriptor, "a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(self.ledger_path, 0o600)
        self._consumed[release_id] = record
        self._tail = str(record["entry_id"])
        return seed


def select_release(
    schedule: Sequence[Mapping[str, Any]],
    *,
    model_key: str,
    repair_class: str,
    attempt: str,
    trial_id: str | None,
    arm: str,
    call_index: int,
) -> Mapping[str, Any]:
    matches = [
        row
        for row in schedule
        if row["model_key"] == model_key
        and row["repair_class"] == repair_class
        and row["attempt"] == attempt
        and row["trial_id"] == trial_id
        and row["arm"] == arm
        and int(row["call_index"]) == call_index
    ]
    if len(matches) != 1:
        raise RuntimeError("sealed release schedule lookup is not unique")
    return matches[0]


def exact_mcnemar_two_sided(treatment: Sequence[bool], control: Sequence[bool]) -> float:
    if len(treatment) != len(control):
        raise ValueError("paired outcomes must have equal length")
    treatment_only = sum(t and not c for t, c in zip(treatment, control))
    control_only = sum(c and not t for t, c in zip(treatment, control))
    discordant = treatment_only + control_only
    if discordant == 0:
        return 1.0
    tail = min(treatment_only, control_only)
    probability = sum(math.comb(discordant, k) for k in range(tail + 1)) / (2**discordant)
    return min(1.0, 2.0 * probability)


def qualification_gate(
    repair_class: str,
    positive_treatment: Sequence[bool],
    positive_controls: Sequence[Sequence[bool]],
    invariance_treatment: Sequence[bool],
    invariance_controls: Sequence[Sequence[bool]],
    delivery_count: int,
    total_delivery_count: int,
    certificates_passed: bool,
) -> Mapping[str, Any]:
    if len(positive_treatment) != POSITIVE_COUNT:
        raise ValueError("qualification gate requires exactly 64 positive controls")
    if len(invariance_treatment) != INVARIANCE_COUNT:
        raise ValueError("qualification gate requires exactly 32 invariance controls")
    comparisons = []
    for positive_control, invariance_control in zip(
        positive_controls, invariance_controls
    ):
        wins = sum(
            treatment and not control
            for treatment, control in zip(positive_treatment, positive_control)
        )
        losses = sum(
            control and not treatment
            for treatment, control in zip(positive_treatment, positive_control)
        )
        comparisons.append(
            {
                "control_correct": sum(positive_control),
                "gain_count": sum(positive_treatment) - sum(positive_control),
                "wins_minus_losses": wins - losses,
                "mcnemar_p": exact_mcnemar_two_sided(
                    positive_treatment, positive_control
                ),
                "invariance_control_correct": sum(invariance_control),
                "invariance_difference": sum(invariance_treatment)
                - sum(invariance_control),
            }
        )
    components = {
        "certificates_passed": bool(certificates_passed),
        "treatment_positive_correct": sum(positive_treatment) >= 61,
        "gain_over_every_control": all(row["gain_count"] >= 16 for row in comparisons),
        "paired_margin_over_every_control": all(
            row["wins_minus_losses"] >= 12 for row in comparisons
        ),
        "mcnemar_over_every_control": all(row["mcnemar_p"] <= 0.01 for row in comparisons),
        "treatment_invariance_correct": sum(invariance_treatment) >= 30,
        "invariance_noninferior_to_every_control": all(
            row["invariance_difference"] >= -1 for row in comparisons
        ),
        "all_positive_delivered": delivery_count >= POSITIVE_COUNT,
        "at_least_95_total_delivered": total_delivery_count >= 95,
    }
    return {
        "repair_class": repair_class,
        "components": components,
        "comparisons": comparisons,
        "treatment_positive_correct_count": sum(positive_treatment),
        "treatment_invariance_correct_count": sum(invariance_treatment),
        "delivery_count": delivery_count,
        "total_delivery_count": total_delivery_count,
        "passed": all(components.values()),
    }


def fixture_report(fixture_root: Path | None = None) -> Mapping[str, Any]:
    fixture_secret = hashlib.sha256(b"reframe-model-free-fixture-secret").digest()
    campaign_id = digest({"fixture": VERSION})
    checks: Dict[str, bool] = {}

    checks["final_parser_exact"] = all(
        parse_final_response_bytes((code + "\n").encode("ascii")) == code
        for code in CODES
    ) and all(
        parse_final_response_bytes(value) is None
        for value in (b"A", b"A\nextra", b" A\n", b"a\n", b"E\n", b"")
    )
    checks["ack_parser_exact"] = parse_call_ack_bytes(b"!") and not any(
        parse_call_ack_bytes(value) for value in (b"!\n", b"CALL", b" !")
    )

    sample_trials = {}
    for repair_class in REPAIR_CLASSES:
        task, gold = build_trial(
            fixture_secret,
            campaign_id,
            "qwen3_1p7b",
            repair_class,
            "P",
            0,
        )
        sample_trials[repair_class] = task
        checks[f"{repair_class}_gold_valid"] = gold in CODES

    compute = sample_trials["compute"]
    view_symbols = compute["fixture_commitment"]
    checks["compute_three_nonempty_views"] = (
        len(compute["prompt_payload"]["view_prompts"]) == 3
        and all(compute["prompt_payload"]["view_prompts"])
        and isinstance(view_symbols, str)
    )

    state = sample_trials["explicit_state"]
    sidecar = state_sidecar(
        str(state["trial_id"]),
        str(state["prompt_payload"]["treatment_state"]),
        hashlib.sha256(
            str(state["prompt_payload"]["stage_one_prompt"]).encode()
        ).hexdigest(),
        True,
    )
    checks["state_hash_only_log"] = (
        "body" not in sidecar["log_projection"]
        and sidecar["byte_length"] == 16
        and len(sidecar["sidecar_hash"]) == 64
        and hashlib.sha256(bytes.fromhex(sidecar["payload_hex"])).hexdigest()
        == sidecar["sidecar_hash"]
    )
    bitmap = bitmap_sidecar(
        str(state["trial_id"]),
        str(state["prompt_payload"]["treatment_state"]),
        hashlib.sha256(str(state["prompt_payload"]["stage_one_prompt"]).encode()).hexdigest(),
        True,
    )
    checks["state_alternate_bitmap_distinct_and_fixed_width"] = (
        bitmap["byte_length"] == 16
        and bitmap["payload_hex"] != sidecar["payload_hex"]
        and 0 < int(bitmap["bitmap"]) <= 8
    )

    verification = sample_trials["verification"]
    bits = verification_bits(verification)
    checks["verification_one_hot"] = sum(bits) == 1 and len(bits) == 4
    primary_certificates = verification_certificates(verification, False)
    alternate_certificates = verification_certificates(verification, True)
    checks["verification_distinct_implementations_agree"] = (
        tuple(row["status_bit"] for row in primary_certificates) == bits
        and tuple(row["status_bit"] for row in alternate_certificates) == bits
        and {row["implementation"] for row in primary_certificates}
        != {row["implementation"] for row in alternate_certificates}
    )

    tool = sample_trials["tools"]
    checks["tool_primary_alternate_agree"] = (
        tool_output(tool, alternate=False) == tool_output(tool, alternate=True)
        and tool_output(tool) in SYMBOLS
        and "code" not in tool_output(tool).lower()
    )

    treatment_adaptation = parameter_adaptation_rows(
        fixture_secret, campaign_id, "qwen3_1p7b", "P", sham=False
    )
    sham_adaptation = parameter_adaptation_rows(
        fixture_secret, campaign_id, "qwen3_1p7b", "P", sham=True
    )
    checks["parameter_sham_inputs_and_batches_exact"] = (
        [row["adaptation_id"] for row in treatment_adaptation]
        == [row["adaptation_id"] for row in sham_adaptation]
        and [row["prompt"] for row in treatment_adaptation]
        == [row["prompt"] for row in sham_adaptation]
        and all(
            left["response"] != right["response"]
            for left, right in zip(treatment_adaptation, sham_adaptation)
        )
    )
    checks["parameter_rule_families_balanced_and_distinct"] = all(
        [_parameter_rule(feature, attempt) for feature in PARAMETER_FEATURES].count(code) == 4
        for attempt in ATTEMPTS
        for code in CODES
    ) and any(
        _parameter_rule(feature, "P") != _parameter_rule(feature, "A")
        for feature in PARAMETER_FEATURES
    )

    panel = build_panel(fixture_secret, campaign_id)
    releases = panel["public"]["release_schedule"]
    release_ids = [row["release_id"] for row in releases]
    checks["panel_exact_size"] = len(panel["public"]["trials"]) == 1920
    checks["partition_tags_globally_unique"] = len(
        {row["prompt_payload"]["partition_tag"] for row in panel["public"]["trials"]}
    ) == len(panel["public"]["trials"])
    checks["release_ids_globally_unique"] = len(release_ids) == len(set(release_ids))
    checks["public_panel_has_no_gold_or_raw_seed"] = (
        "gold_by_trial" not in json.dumps(panel["public"])
        and "raw_seed_by_release" not in json.dumps(panel["public"])
    )
    checks["sealed_panel_binds_public"] = (
        panel["sealed"]["panel_id"] == panel["public"]["panel_id"]
        and hashlib.sha256(
            bytes.fromhex(panel["sealed"]["sealed_record_key_hex"])
        ).hexdigest()
        == panel["public"]["sealed_record_key_commitment"]
    )
    sealed_fixture = seal_record(
        bytes.fromhex(panel["sealed"]["sealed_record_key_hex"]),
        "fixture-record",
        {"response_hex": "410a", "trial_id": "fixture"},
    )
    checks["response_record_authenticated_encryption_roundtrip"] = (
        open_record(
            bytes.fromhex(panel["sealed"]["sealed_record_key_hex"]),
            sealed_fixture,
        )
        == {"response_hex": "410a", "trial_id": "fixture"}
        and "410a" not in json.dumps(sealed_fixture)
    )
    first_trial = panel["public"]["trials"][0]
    treatment_release = select_release(
        releases,
        model_key=str(first_trial["model_key"]),
        repair_class=str(first_trial["repair_class"]),
        attempt=str(first_trial["attempt"]),
        trial_id=str(first_trial["trial_id"]),
        arm="treatment",
        call_index=0,
    )
    control_release = select_release(
        releases,
        model_key=str(first_trial["model_key"]),
        repair_class=str(first_trial["repair_class"]),
        attempt=str(first_trial["attempt"]),
        trial_id=str(first_trial["trial_id"]),
        arm="control",
        call_index=0,
    )
    checks["paired_arms_share_seed_commitment"] = (
        treatment_release["seed_commitment"] == control_release["seed_commitment"]
    )
    broker_root = fixture_root or Path(
        tempfile.mkdtemp(prefix="repairability-reframe-model-free-fixture-")
    )
    broker_ledger = broker_root / "consume-ledger.jsonl"
    if broker_ledger.exists():
        broker_ledger.unlink()
    broker = ConsumeOnceBroker(
        releases,
        panel["sealed"]["raw_seed_by_release"],
        broker_ledger,
    )
    prompt_hash = hashlib.sha256(b"fixture-rendered-prompt").hexdigest()
    released_seed = broker.release(str(treatment_release["release_id"]), prompt_hash)
    checks["broker_commit_before_dispatch"] = (
        seed_commitment(released_seed) == treatment_release["seed_commitment"]
        and str(treatment_release["release_id"]) in broker.consumed_release_ids
    )
    try:
        broker.release(str(treatment_release["release_id"]), prompt_hash)
    except RuntimeError:
        checks["broker_rejects_retry"] = True
    else:
        checks["broker_rejects_retry"] = False
    if broker_ledger.exists():
        broker_ledger.unlink()

    perfect = [True] * 64
    weak = [index % 4 == 0 for index in range(64)]
    invariant = [True] * 32
    gate = qualification_gate(
        "compute",
        perfect,
        (weak,),
        invariant,
        (invariant,),
        64,
        96,
        True,
    )
    checks["gate_accepts_only_complete_strong_fixture"] = bool(gate["passed"])
    checks["gate_rejects_missing_delivery"] = not qualification_gate(
        "compute",
        perfect,
        (weak,),
        invariant,
        (invariant,),
        63,
        95,
        True,
    )["passed"]

    body = {
        "version": VERSION,
        "fixture_namespace": campaign_id,
        "qualification_seed_or_task_consumed": False,
        "model_loaded_or_called": False,
        "checks": checks,
        "passed": all(checks.values()),
    }
    return {**body, "fixture_report_id": digest(body)}
