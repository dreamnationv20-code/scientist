"""Fresh forced-choice parameter study for held-out relational compositions."""
from __future__ import annotations

import hashlib
import json
import random
from typing import Any, Mapping


VERSION = "cognitive-repairability-relational-binding-forced-choice-parameter-v1"
MODEL_KEY = "qwen2p5_3b"
SEED = 860_903_100
LABELS = ("A", "B", "C", "D")
QUADRANTS = ("north-east", "north-west", "south-east", "south-west")
TRAINING_COUNT = 128
POSITIVE_CONTROL_COUNT = 16
DEVELOPMENT_COUNT = 32
PROSPECTIVE_COUNT = 48


def digest(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")).hexdigest()


def file_sha256(path: Any) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def jsonl(rows: list[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n" for row in rows)


def read_rows(path: Any) -> list[Mapping[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


_NAMES = {
    "adaptation": ("Ari", "Bela", "Cato", "Demi", "Enzo", "Fia", "Gita", "Hugo", "Iris", "Juno", "Kian", "Lena", "Miro", "Nia", "Oren", "Pema", "Rafi", "Sela", "Tari", "Ugo", "Vina", "Wes", "Xavi", "Yana"),
    "positive_control": ("Adil", "Bina", "Cian", "Dora", "Evan", "Fara", "Galen", "Hiba", "Idris", "Jia", "Kavi", "Lior", "Maya", "Naren", "Oona", "Pia", "Rian", "Suri", "Tarin", "Ula", "Vik", "Wafa", "Xena", "Yuri"),
    "development": ("Mira", "Niko", "Orla", "Pavel", "Quinn", "Ravi", "Sana", "Toma", "Uma", "Vera", "Wren", "Yara", "Zane", "Asha", "Bryn", "Cleo", "Dara", "Eli", "Faro", "Gwen", "Hana", "Ivo", "Jaya", "Kora"),
    "prospective": ("Noel", "Opal", "Priya", "Quade", "Rosa", "Seth", "Talia", "Umar", "Veda", "Willa", "Xiomara", "Yosef", "Zuri", "Amos", "Bria", "Ciro", "Davin", "Esme", "Fionn", "Gala", "Hector", "Ines", "Jared", "Kira"),
}


def _names(split: str, index: int) -> list[str]:
    values = list(_NAMES[split])
    random.Random(SEED + 101 * index + 7 * len(split)).shuffle(values)
    return values


def _route(answer: str, depth: int, rng: random.Random) -> tuple[list[str], bool]:
    vertical = "north" if answer.startswith("north") else "south"
    horizontal = "east" if answer.endswith("east") else "west"
    route = [vertical, horizontal] * (depth // 2)
    rng.shuffle(route)
    reversed_query = bool(rng.randrange(2))
    if reversed_query:
        inverse = {"north": "south", "south": "north", "east": "west", "west": "east"}
        route = [inverse[value] for value in route]
    return route, reversed_query


def _mapping(answer: str, label: str, rng: random.Random) -> Mapping[str, str]:
    remaining = [value for value in QUADRANTS if value != answer]
    rng.shuffle(remaining)
    return {option: answer if option == label else remaining.pop() for option in LABELS}


def _surface(split: str, source: str, direction: str, target: str) -> str:
    if split == "adaptation":
        return f"{target} is {direction} of {source}."
    if split == "positive_control":
        return f"A move {direction} from {source} arrives at {target}."
    if split == "development":
        return f"Starting at {source}, walking {direction} reaches {target}."
    if split == "prospective":
        return f"A traveler leaving {source} toward {direction} arrives at {target}."
    raise ValueError("unknown relational-binding split")


def _question(split: str, first: str, last: str, reversed_query: bool) -> str:
    left, right = (first, last) if reversed_query else (last, first)
    templates = {
        "adaptation": f"Where is {left} relative to {right}?",
        "positive_control": f"Which diagonal direction locates {left} from {right}?",
        "development": f"Which diagonal direction locates {left} from {right}?",
        "prospective": f"Which diagonal route leads from {right} to {left}?",
    }
    return templates[split]


def _task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    if split not in _NAMES:
        raise ValueError("unknown relational-binding split")
    depth = 2 if split in {"adaptation", "positive_control"} else 4
    answer_relation = QUADRANTS[(3 * index + len(split)) % len(QUADRANTS)]
    answer_label = LABELS[(index + 2 * len(split)) % len(LABELS)]
    route, reversed_query = _route(answer_relation, depth, rng)
    names = _names(split, index)
    chain = names[: depth + 1]
    facts = [_surface(split, source, direction, target) for source, direction, target in zip(chain[:-1], route, chain[1:], strict=True)]
    facts.extend((_surface(split, names[8], "north", names[9]), _surface(split, names[10], "west", names[11]), _surface(split, names[12], "south", names[13])))
    rng.shuffle(facts)
    mapping = _mapping(answer_relation, answer_label, rng)
    prompt = (
        "Read the map facts and bind every directional relation to its stated source and destination.\n"
        + "\n".join(facts)
        + "\n\n"
        + _question(split, chain[0], chain[-1], reversed_query)
        + "\n\nChoose one visible option:\n"
        + "\n".join(f"{label}: {mapping[label]}" for label in LABELS)
        + "\n\nReturn only one option letter: A, B, C, or D."
    )
    task_id = f"rbfcp1-{split}-{index:03d}"
    public = {"version": VERSION, "task_id": task_id, "split": split, "template": f"{split}_relational_surface", "composition_depth": depth, "query_reversed": reversed_query, "prompt": prompt, "choice_mapping_prompt_visible": mapping, "prompt_valid_labels": list(LABELS)}
    authority = {"task_id": task_id, "answer": answer_label, "answer_relation": answer_relation, "template": public["template"], "entity_lexicon": tuple(chain)}
    if mapping[answer_label] != answer_relation:
        raise RuntimeError("answer mapping mismatch")
    return public, authority


def _messages(task: Mapping[str, Any], label: str) -> list[Mapping[str, str]]:
    return [
        {"role": "system", "content": "Choose the best visible option. Respond with only its option letter."},
        {"role": "user", "content": str(task["prompt"])},
        {"role": "assistant", "content": label},
    ]


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(SEED)
    sham = {"A": "B", "B": "C", "C": "D", "D": "A"}
    training: list[Mapping[str, Any]] = []
    for index in range(TRAINING_COUNT):
        task, authority = _task(index, "adaptation", rng)
        correct = str(authority["answer"])
        training.append({"task_id": task["task_id"], "messages": _messages(task, correct), "sham_messages": _messages(task, sham[correct]), "correct_label": correct, "sham_label": sham[correct]})
    panels: dict[str, list[Mapping[str, Any]]] = {}
    authorities: dict[str, list[Mapping[str, Any]]] = {}
    for split, count in (("positive_control", POSITIVE_CONTROL_COUNT), ("development", DEVELOPMENT_COUNT), ("prospective", PROSPECTIVE_COUNT)):
        records = [_task(index, split, rng) for index in range(count)]
        panels[split] = [task for task, _ in records]
        authorities[split] = [answer for _, answer in records]
    if any(len({row["correct_label"] for row in training}) != 4 for _ in (0,)):
        raise RuntimeError("training labels are incomplete")
    if {row["correct_label"]: sum(item["correct_label"] == row["correct_label"] for item in training) for row in training} != {label: TRAINING_COUNT // 4 for label in LABELS}:
        raise RuntimeError("treatment labels are not balanced")
    if {row["sham_label"]: sum(item["sham_label"] == row["sham_label"] for item in training) for row in training} != {label: TRAINING_COUNT // 4 for label in LABELS}:
        raise RuntimeError("sham labels are not balanced")
    if any(row["correct_label"] == row["sham_label"] for row in training):
        raise RuntimeError("sham is not a fixed derangement")
    all_templates = {split: {row["template"] for row in rows} for split, rows in panels.items()}
    if len({next(iter(values)) for values in all_templates.values()}) != 3:
        raise RuntimeError("evaluation templates are not disjoint")
    return training, panels["positive_control"], panels["development"], panels["prospective"], [*authorities["positive_control"], *authorities["development"], *authorities["prospective"]]
