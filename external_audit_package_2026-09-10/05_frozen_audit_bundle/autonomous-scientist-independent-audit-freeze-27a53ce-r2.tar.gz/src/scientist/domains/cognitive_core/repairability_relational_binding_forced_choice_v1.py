"""Fresh forced-choice screen for relational role binding.

This is a measurement-interface qualification only.  It has no parameter
update and no prospective authority; a failure stops the parameter route rather
than creating another automatic task successor.
"""
from __future__ import annotations

import hashlib
import json
import random
from typing import Any, Mapping


VERSION = "cognitive-repairability-relational-binding-forced-choice-v1"
MODEL_KEY = "qwen2p5_3b"
SEED = 860_902_100
LABELS = ("A", "B", "C", "D")
QUADRANTS = ("north-east", "north-west", "south-east", "south-west")
DEVELOPMENT_COUNT = 32


def digest(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    ).hexdigest()


def file_sha256(path: Any) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def jsonl(rows: list[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n" for row in rows)


def read_rows(path: Any) -> list[Mapping[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def _names(index: int) -> list[str]:
    values = [
        "Adil", "Bina", "Cian", "Dora", "Evan", "Fara", "Galen", "Hiba",
        "Idris", "Jia", "Kavi", "Lior", "Maya", "Naren", "Oona", "Pia",
        "Rian", "Suri", "Tarin", "Ula", "Vik", "Wafa", "Xena", "Yuri",
    ]
    random.Random(SEED + 193 * index).shuffle(values)
    return values


def _route(answer: str, rng: random.Random) -> tuple[list[str], bool]:
    vertical = "north" if answer.startswith("north") else "south"
    horizontal = "east" if answer.endswith("east") else "west"
    steps = [vertical, horizontal, vertical, horizontal]
    rng.shuffle(steps)
    reverse_query = bool(rng.randrange(2))
    if reverse_query:
        inverse = {"north": "south", "south": "north", "east": "west", "west": "east"}
        steps = [inverse[item] for item in steps]
    return steps, reverse_query


def _mapping(answer: str, label: str, rng: random.Random) -> Mapping[str, str]:
    remaining = [value for value in QUADRANTS if value != answer]
    rng.shuffle(remaining)
    values: list[str] = []
    for option in LABELS:
        values.append(answer if option == label else remaining.pop())
    return dict(zip(LABELS, values))


def _task(index: int, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    answer_relation = QUADRANTS[index % 4]
    answer_label = LABELS[(3 * index + 1) % 4]
    steps, reverse_query = _route(answer_relation, rng)
    names = _names(index)
    chain = names[:5]
    facts = [
        f"Starting at {source}, walking {direction} reaches {target}."
        for source, direction, target in zip(chain[:-1], steps, chain[1:], strict=True)
    ]
    facts.extend(
        (
            f"Starting at {names[5]}, walking north reaches {names[6]}.",
            f"Starting at {names[7]}, walking west reaches {names[8]}.",
            f"Starting at {names[9]}, walking south reaches {names[10]}.",
        )
    )
    rng.shuffle(facts)
    mapping = _mapping(answer_relation, answer_label, rng)
    question = (
        f"Which diagonal direction locates {chain[0]} from {chain[-1]}?"
        if reverse_query
        else f"Which diagonal direction locates {chain[-1]} from {chain[0]}?"
    )
    prompt = (
        "Read the map facts and bind every directional relation to its stated source and destination.\n"
        + "\n".join(facts)
        + "\n\n"
        + question
        + "\n\nChoose one visible option:\n"
        + "\n".join(f"{label}: {mapping[label]}" for label in LABELS)
        + "\n\nReturn only one option letter: A, B, C, or D."
    )
    task_id = f"rbfcq1-development-{index:03d}"
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": "development",
        "template": "heldout_walk_relation_query_forced_choice",
        "composition_depth": 4,
        "query_reversed": reverse_query,
        "prompt": prompt,
        "choice_mapping_prompt_visible": mapping,
        "prompt_valid_labels": list(LABELS),
    }
    authority = {"task_id": task_id, "answer": answer_label, "answer_relation": answer_relation}
    if mapping[answer_label] != answer_relation:
        raise RuntimeError("forced-choice answer mapping is inconsistent")
    return public, authority


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(SEED)
    pairs = [_task(index, rng) for index in range(DEVELOPMENT_COUNT)]
    tasks, authority = zip(*pairs)
    if len(tasks) != DEVELOPMENT_COUNT or len({row["task_id"] for row in tasks}) != DEVELOPMENT_COUNT:
        raise RuntimeError("forced-choice panel identity mismatch")
    labels = [row["answer"] for row in authority]
    if {label: labels.count(label) for label in LABELS} != {label: DEVELOPMENT_COUNT // 4 for label in LABELS}:
        raise RuntimeError("forced-choice answer labels are not balanced")
    return list(tasks), list(authority)
