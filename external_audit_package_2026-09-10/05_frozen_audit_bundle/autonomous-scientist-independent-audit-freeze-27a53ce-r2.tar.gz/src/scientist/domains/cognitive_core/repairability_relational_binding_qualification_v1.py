"""One-shot qualification panel for a parameterized relational-binding route.

The public prompts contain no answer key.  The development authority is stored
separately and is opened only after base candidates are written.  There is no
prospective split in this design version.
"""
from __future__ import annotations

import hashlib
import json
import random
import re
from typing import Any, Mapping


VERSION = "cognitive-repairability-relational-binding-qualification-v1"
MODEL_KEY = "qwen2p5_3b"
SEED = 860_901_100
LABELS = ("A", "B", "C", "D")
QUADRANTS = ("north-east", "north-west", "south-east", "south-west")
_ANSWER = re.compile(r"\A\s*ANSWER:\s*([ABCD])\s*\Z", re.IGNORECASE)

TRAINING_COUNT = 64
BASE_DEVELOPMENT_COUNT = 16
ADAPTER_PREFLIGHT_COUNT = 16


def digest(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    ).hexdigest()


def file_sha256(path: Any) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def jsonl(rows: list[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n" for row in rows)


def read_rows(path: Any) -> list[Mapping[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def parse_answer(text: str) -> Mapping[str, Any]:
    match = _ANSWER.fullmatch(text)
    if match is None:
        return {"delivered": False, "candidate": None, "reason": "noncanonical_answer"}
    return {"delivered": True, "candidate": match.group(1).upper(), "reason": None}


def _names(split: str, index: int) -> list[str]:
    pools = {
        "adaptation": ("Ari", "Bela", "Cato", "Demi", "Enzo", "Fia", "Gita", "Hugo", "Iris", "Juno", "Kian", "Lena"),
        "development": ("Mira", "Niko", "Orla", "Pavel", "Quinn", "Ravi", "Sana", "Toma", "Uma", "Vera", "Wren", "Yara"),
        "preflight": ("Zane", "Asha", "Bryn", "Cleo", "Dara", "Eli", "Faro", "Gwen", "Hana", "Ivo", "Jaya", "Kora"),
    }
    values = list(pools[split])
    random.Random(SEED + 97 * index + len(split)).shuffle(values)
    return values


def _route(answer: str, depth: int, rng: random.Random) -> tuple[list[str], bool]:
    vertical = "north" if answer.startswith("north") else "south"
    horizontal = "east" if answer.endswith("east") else "west"
    steps = [vertical, horizontal] * (depth // 2)
    if depth % 2:
        steps.append(vertical)
    rng.shuffle(steps)
    reverse_query = bool(rng.randrange(2))
    if reverse_query:
        inverse = {"north": "south", "south": "north", "east": "west", "west": "east"}
        steps = [inverse[item] for item in steps]
    return steps, reverse_query


def _mapping(answer: str, answer_label: str, rng: random.Random) -> dict[str, str]:
    remaining = [value for value in QUADRANTS if value != answer]
    rng.shuffle(remaining)
    values: list[str] = []
    iterator = iter(remaining)
    for label in LABELS:
        values.append(answer if label == answer_label else next(iterator))
    return dict(zip(LABELS, values))


def _task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    if split not in {"adaptation", "development", "preflight"}:
        raise ValueError("unknown relational-binding split")
    depth = 2 if split == "adaptation" else 4
    answer = QUADRANTS[index % len(QUADRANTS)]
    answer_label = LABELS[index % len(LABELS)]
    route, reverse_query = _route(answer, depth, rng)
    names = _names(split, index)
    chain = names[: depth + 1]
    distractors = [(names[depth + 1], "north", names[depth + 2]), (names[depth + 3], "west", names[depth + 4])]
    mapping = _mapping(answer, answer_label, rng)
    if split == "adaptation":
        facts = [f"{target} is {direction} of {source}." for source, direction, target in zip(chain[:-1], route, chain[1:], strict=True)]
        facts.extend(f"{target} is {direction} of {source}." for source, direction, target in distractors)
        question = f"Where is {chain[-1]} relative to {chain[0]}?"
        template = "training_subject_relation_object"
    else:
        facts = [f"Starting at {source}, walking {direction} reaches {target}." for source, direction, target in zip(chain[:-1], route, chain[1:], strict=True)]
        facts.extend(f"Starting at {source}, walking {direction} reaches {target}." for source, direction, target in distractors)
        if reverse_query:
            question = f"Which diagonal direction locates {chain[0]} from {chain[-1]}?"
        else:
            question = f"Which diagonal direction locates {chain[-1]} from {chain[0]}?"
        template = "heldout_walk_relation_query"
    rng.shuffle(facts)
    choices = "\n".join(f"{label}: {mapping[label]}" for label in LABELS)
    prompt = (
        "Read the map facts and bind each directional relation to its stated source and destination.\n"
        + "\n".join(facts)
        + "\n\n"
        + question
        + "\n\nChoose one visible option:\n"
        + choices
        + "\n\nOutput exactly one line: ANSWER: <option letter>"
    )
    task_id = f"rbq1-{split}-{index:03d}"
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": split,
        "template": template,
        "composition_depth": depth,
        "query_reversed": reverse_query,
        "prompt": prompt,
        "choice_mapping_prompt_visible": mapping,
        "prompt_valid_labels": list(LABELS),
    }
    authority = {
        "task_id": task_id,
        "answer": answer_label,
        "answer_relation": answer,
        "template": template,
        "entity_lexicon": tuple(chain),
    }
    if mapping[answer_label] != answer:
        raise RuntimeError("answer mapping is inconsistent")
    return public, authority


def _messages(task: Mapping[str, Any], answer: str) -> list[Mapping[str, str]]:
    return [
        {"role": "system", "content": "Solve the visible map task. Output only the requested canonical answer line."},
        {"role": "user", "content": str(task["prompt"])},
        {"role": "assistant", "content": f"ANSWER: {answer}"},
    ]


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(SEED)
    training: list[Mapping[str, Any]] = []
    development: list[Mapping[str, Any]] = []
    preflight: list[Mapping[str, Any]] = []
    authority: list[Mapping[str, Any]] = []
    sham_derangement = {"A": "B", "B": "C", "C": "D", "D": "A"}
    for index in range(TRAINING_COUNT):
        task, answer = _task(index, "adaptation", rng)
        correct = str(answer["answer"])
        sham = sham_derangement[correct]
        training.append(
            {
                "task_id": task["task_id"],
                "messages": _messages(task, correct),
                "sham_messages": _messages(task, sham),
                "correct_label": correct,
                "sham_label": sham,
            }
        )
    for index in range(BASE_DEVELOPMENT_COUNT):
        task, answer = _task(index, "development", rng)
        development.append(task)
        authority.append(answer)
    for index in range(ADAPTER_PREFLIGHT_COUNT):
        task, _ = _task(index, "preflight", rng)
        preflight.append(task)
    if len(training) != TRAINING_COUNT or len(development) != BASE_DEVELOPMENT_COUNT or len(preflight) != ADAPTER_PREFLIGHT_COUNT:
        raise RuntimeError("relational-binding panel count mismatch")
    if {row["correct_label"] for row in training} != set(LABELS):
        raise RuntimeError("treatment training labels are not balanced")
    if {row["sham_label"] for row in training} != set(LABELS):
        raise RuntimeError("sham training labels are not balanced")
    if any(row["correct_label"] == row["sham_label"] for row in training):
        raise RuntimeError("sham is not a derangement")
    if {row["template"] for row in development} & {"training_subject_relation_object"}:
        raise RuntimeError("development composition template leaked from adaptation")
    return training, development, preflight, authority
