from __future__ import annotations

from scientist.kernel.contracts import MetricDirection, MetricSpec
from scientist.program.contracts import HighLevelGoal


REPAIRABILITY_ROOT_GOAL_VERSION = "cognitive-repairability-root-goal-v3"


def repairability_root_goal() -> HighLevelGoal:
    """Return the broad user-level objective that survives child-mission failure.

    A successor mission is allowed to replace a failed causal representation,
    but it is not allowed to quietly replace this objective or its claim gates.
    """

    return HighLevelGoal(
        name="Answer-blind causal theory of small-model reasoning repairability",
        outcome=(
            "Discover and prospectively validate an answer-blind causal theory "
            "that predicts which reasoning failures in small language models can "
            "be repaired by additional computation, explicit state, verification, "
            "or tools, and which require changing learned representations or "
            "parameters."
        ),
        scope=(
            "1.7B- and 3B-class open-weight language models",
            "causal interventions for compute, explicit state, verification, tools, and representation or parameter change",
            "failure-unit predictions frozen before prospective intervention outcomes",
            "answer-blind features available before target outcomes are generated",
            "multiple reasoning families and at least one held-out family or mechanism regime",
            "matched end-to-end inference, tool, verification, and adaptation cost",
        ),
        anti_scope=(
            "using answers, correctness, authority labels, or prospective outcomes as predictor inputs",
            "reclassifying repair labels after prospective outcomes are visible",
            "using a larger model as an oracle answer source",
            "treating prompt scaffolding as proof of learned representation change",
            "treating one weak implementation as proof that an intervention class cannot work",
            "reviving a refuted representation by renaming its variables",
            "locally downloading or executing models above 3B parameters",
        ),
        terminal_metrics=(
            MetricSpec(
                name="prospective_repair_classification_log_loss",
                direction=MetricDirection.MINIMIZE,
                unit="mean multiclass log loss",
                aggregation=(
                    "mean over answer-blind probabilities frozen for independent "
                    "failure units before prospective intervention outcomes"
                ),
                primary=True,
            ),
            MetricSpec(
                name="selected_repair_causal_gain",
                direction=MetricDirection.MAXIMIZE,
                unit="paired accuracy-probability difference",
                aggregation=(
                    "paired effect of the preregistered selected repair versus raw "
                    "inference and cost-matched generic compute"
                ),
            ),
            MetricSpec(
                name="representation_required_precision",
                direction=MetricDirection.MAXIMIZE,
                unit="precision fraction",
                aggregation=(
                    "fraction of representation-required predictions confirmed by "
                    "failed qualified nonparametric repairs and successful frozen adaptation"
                ),
            ),
            MetricSpec(
                name="intervention_cost",
                direction=MetricDirection.MINIMIZE,
                unit="normalized local compute",
                aggregation=(
                    "generation tokens, wall time, tool calls, verification work, "
                    "and parameter-update work"
                ),
            ),
        ),
        success_definition=(
            "On untouched prospective and independent-replication partitions "
            "spanning both allowed model sizes and a held-out family or mechanism "
            "regime, the frozen theory beats frequency, family-only, complexity-only, "
            "and generic-compute predictors on multiclass log loss; its selected "
            "repairs produce positive paired causal gain; and representation-required "
            "predictions are accepted only after qualified nonparametric repairs fail "
            "and a separately frozen representation or parameter intervention succeeds."
        ),
        failure_conditions=(
            "the predictor consumes answers, correctness, hidden authority data, or prospective outcomes",
            "repair labels, ontology, thresholds, or scope change after prospective outcomes are visible",
            "an intervention class lacks qualified positive controls and a matched implementation",
            "the theory does not outperform every frozen noncausal baseline",
            "effects fail to transport across the allowed model sizes and held-out regime",
            "representation-required claims lack a successful frozen representation or parameter intervention",
        ),
        integration_requirements=(
            "immutable mission, causal ontology, feature contract, repair-label rule, and stop rules",
            "disjoint discovery, calibration, prospective, and replication partitions",
            "answer-blind leakage audit before prospective outcomes are generated",
            "qualified implementations and positive controls for every intervention class",
            "pre-outcome probabilistic predictions for every prospective failure unit",
            "independent reconstruction of scores, costs, and the final claim boundary",
        ),
        total_compute_budget=36.0,
        max_parallel_campaigns=2,
        risk_tier="research_only",
        human_owner="user",
    )


__all__ = ["REPAIRABILITY_ROOT_GOAL_VERSION", "repairability_root_goal"]
