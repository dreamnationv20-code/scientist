from __future__ import annotations

import hashlib
import hmac
import importlib.metadata
import json
import os
import re
import time
import sys
from pathlib import Path
from typing import Any, Mapping

from scientist.domains.cognitive_core.repairability_qualification_v2 import (
    MODEL_CONTRACT,
    digest,
)


def read_json(path: Path) -> Mapping[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[Mapping[str, Any]]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def file_sha256(path: Path) -> str:
    body = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            body.update(block)
    return body.hexdigest()


def verify_runtime_environment(package: Mapping[str, Any]) -> Mapping[str, Any]:
    """Bind every qualification process to the audited interpreter and wheels."""

    expected = package["runtime"]
    observed_packages: dict[str, str] = {}
    for name, expected_version in expected["packages"].items():
        try:
            observed_version = importlib.metadata.version(str(name))
        except importlib.metadata.PackageNotFoundError:
            observed_version = "not-installed"
        observed_packages[str(name)] = observed_version
        if observed_version != expected_version:
            raise RuntimeError(f"runtime dependency version changed: {name}")
    observed = {
        "environment_path": str(Path(sys.executable).resolve()),
        "python": sys.version,
        "packages": observed_packages,
    }
    if (
        observed["environment_path"] != expected["environment_path"]
        or observed["python"] != expected["python"]
    ):
        raise RuntimeError("active interpreter differs from the audited runtime")
    return {**observed, "runtime_identity_id": digest(observed)}


def ensure_qwen_streaming_detokenizer_compatibility(tokenizer: Any) -> Mapping[str, Any]:
    """Repair the installed MLX/Transformers Qwen streaming API mismatch.

    Transformers 5 Qwen tokenizers no longer expose ``vocab`` as an attribute,
    while the installed MLX BPE streaming detokenizer requires it. The fallback
    changes only incremental token-to-text reconstruction; sampled token IDs,
    prompts, seeds, stopping rules, and model parameters remain untouched.
    """

    from mlx_lm.tokenizer_utils import NaiveStreamingDetokenizer

    original = getattr(tokenizer, "__dict__", {}).get("_detokenizer_class")
    try:
        probe = tokenizer.detokenizer
        probe.reset()
        return {
            "compatibility_shim_applied": False,
            "detokenizer_class": type(probe).__name__,
            "sampled_token_ids_unchanged": True,
        }
    except AttributeError as exc:
        underlying = getattr(tokenizer, "_tokenizer", None)
        if (
            underlying is None
            or not type(underlying).__name__.startswith("Qwen")
            or getattr(original, "__name__", "") != "BPEStreamingDetokenizer"
        ):
            raise RuntimeError(
                "unexpected streaming detokenizer initialization failure"
            ) from exc
        tokenizer._detokenizer_class = NaiveStreamingDetokenizer
        probe = tokenizer.detokenizer
        probe.reset()
        return {
            "compatibility_shim_applied": True,
            "original_detokenizer_class": "BPEStreamingDetokenizer",
            "detokenizer_class": type(probe).__name__,
            "underlying_tokenizer_class": type(underlying).__name__,
            "reason": (
                "Transformers 5 Qwen tokenizer has no vocab attribute required "
                "by MLX BPEStreamingDetokenizer"
            ),
            "sampled_token_ids_unchanged": True,
        }


def materialize_frozen_prompt_template(template: str) -> str:
    """Restore static line separators without modifying interpolated task data."""

    literal_breaks = template.count("\\n")
    actual_breaks = template.count("\n")
    if literal_breaks and actual_breaks:
        raise ValueError("frozen prompt template mixes serialized and real line breaks")
    materialized = template.replace("\\n", "\n") if literal_breaks else template
    if (
        not materialized.startswith("SYSTEM:")
        or materialized.count("\nUSER:") != 1
    ):
        raise ValueError("frozen prompt template has no unique SYSTEM/USER boundary")
    return materialized


def _alternate_keys(
    salt: bytes, freeze_id: str, scope: str
) -> tuple[bytes, bytes, bytes]:
    if len(salt) != 32:
        raise ValueError("alternate-store key source must be the one 256-bit salt")
    if not scope or "\0" in scope:
        raise ValueError("alternate-store scope must name exactly one model/class cell")
    context = freeze_id.encode("ascii") + b"\0" + scope.encode("ascii")
    encryption_key = hmac.new(salt, b"alternate-encryption-v1\0" + context, hashlib.sha256).digest()
    authentication_key = hmac.new(salt, b"alternate-authentication-v1\0" + context, hashlib.sha256).digest()
    nonce = hmac.new(salt, b"alternate-nonce-v1\0" + context, hashlib.sha256).digest()[:16]
    return encryption_key, authentication_key, nonce


def _hmac_stream_xor(data: bytes, key: bytes, nonce: bytes) -> bytes:
    output = bytearray()
    for counter in range((len(data) + 31) // 32):
        block = hmac.new(
            key, nonce + counter.to_bytes(8, "big"), hashlib.sha256
        ).digest()
        start = counter * 32
        output.extend(left ^ right for left, right in zip(data[start : start + 32], block))
    return bytes(output)


def seal_alternate_task_store(
    plaintext: bytes, salt: bytes, freeze_id: str, row_count: int, scope: str
) -> Mapping[str, Any]:
    encryption_key, authentication_key, nonce = _alternate_keys(salt, freeze_id, scope)
    ciphertext = _hmac_stream_xor(plaintext, encryption_key, nonce)
    tag = hmac.new(authentication_key, nonce + ciphertext, hashlib.sha256).hexdigest()
    body = {
        "algorithm": "hmac-sha256-stream-xor-then-hmac-v1",
        "freeze_id": freeze_id,
        "scope": scope,
        "nonce_hex": nonce.hex(),
        "ciphertext_hex": ciphertext.hex(),
        "authentication_tag": tag,
        "plaintext_sha256": hashlib.sha256(plaintext).hexdigest(),
        "row_count": row_count,
    }
    return {**body, "encrypted_store_id": digest(body)}


def open_alternate_task_store(
    record: Mapping[str, Any], salt: bytes, freeze_id: str, scope: str
) -> bytes:
    body = {key: value for key, value in record.items() if key != "encrypted_store_id"}
    if (
        digest(body) != record.get("encrypted_store_id")
        or record.get("freeze_id") != freeze_id
        or record.get("scope") != scope
    ):
        raise RuntimeError("encrypted alternate store identity mismatch")
    encryption_key, authentication_key, nonce = _alternate_keys(salt, freeze_id, scope)
    if str(record.get("nonce_hex")) != nonce.hex():
        raise RuntimeError("encrypted alternate store nonce mismatch")
    ciphertext = bytes.fromhex(str(record["ciphertext_hex"]))
    observed_tag = hmac.new(
        authentication_key, nonce + ciphertext, hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(observed_tag, str(record["authentication_tag"])):
        raise RuntimeError("encrypted alternate store authentication failed")
    plaintext = _hmac_stream_xor(ciphertext, encryption_key, nonce)
    if hashlib.sha256(plaintext).hexdigest() != record.get("plaintext_sha256"):
        raise RuntimeError("encrypted alternate store plaintext hash mismatch")
    return plaintext


def global_budget_allows(
    normalized_hours: float, maximum_hours: float = 6.0
) -> bool:
    return normalized_hours < maximum_hours - 1e-12


_REGISTRY_KEYS = {
    "task_id": "task_id",
    "task_ids": "task_id",
    "adaptation_id": "adaptation_id",
    "adaptation_ids": "adaptation_id",
    "record_id": "adaptation_id",
    "evaluation_id": "evaluation_id",
    "evaluation_ids": "evaluation_id",
    "freeze_id": "freeze_id",
    "partition": "partition_id",
    "partition_id": "partition_id",
    "seed_commitment": "seed_commitment",
    "seed_commitments": "seed_commitment",
    "public_content_hash": "raw_content_hash",
    "prompt_hash": "raw_content_hash",
    "raw_record_hash": "raw_content_hash",
    "provenance_hash": "raw_content_hash",
    "raw_content_hash": "raw_content_hash",
}

_RAW_CONTENT_FIELDS = {
    "answer_blind_payload",
    "clues",
    "input",
    "inputs",
    "messages",
    "problem",
    "prompt",
    "query",
    "question",
    "required_request",
    "text",
    "tuple",
}


def _local_raw_content_fingerprints(value: Mapping[str, Any]) -> set[str]:
    content_fields = {
        str(key).lower(): item
        for key, item in value.items()
        if str(key).lower() in _RAW_CONTENT_FIELDS
    }
    if not content_fields:
        return set()
    return {
        digest(["raw-record-v2", value]),
        *(
            digest(["raw-field-v2", key, item])
            for key, item in sorted(content_fields.items())
        ),
    }


def raw_content_fingerprints(value: Any) -> set[str]:
    """Return metadata-independent fingerprints for exact task-content reuse.

    Whole records are useful for byte-equivalent replay, while field fingerprints
    still detect reuse after IDs, partitions, attempts, or seed commitments change.
    Only task-bearing fields are projected so generic manifest/schema fragments do
    not create false collisions.
    """

    fingerprints: set[str] = set()

    def visit(node: Any) -> None:
        if isinstance(node, dict):
            fingerprints.update(_local_raw_content_fingerprints(node))
            for item in node.values():
                visit(item)
        elif isinstance(node, list):
            for item in node:
                visit(item)

    visit(value)
    return fingerprints


def _registry_add(target: dict[str, set[str]], kind: str, value: Any) -> None:
    if isinstance(value, dict):
        for item in value.values():
            _registry_add(target, kind, item)
    elif isinstance(value, list):
        for item in value:
            _registry_add(target, kind, item)
    elif isinstance(value, (str, int)):
        target.setdefault(kind, set()).add(digest([kind, str(value)]))


def _walk_registry(value: Any, target: dict[str, set[str]]) -> None:
    if isinstance(value, dict):
        for fingerprint in _local_raw_content_fingerprints(value):
            _registry_add(target, "raw_content_hash", fingerprint)
        for key, item in value.items():
            lowered = str(key).lower()
            kind = _REGISTRY_KEYS.get(lowered)
            if kind is not None:
                _registry_add(target, kind, item)
            elif "seed" in lowered:
                stack = [item]
                while stack:
                    candidate = stack.pop()
                    if isinstance(candidate, dict):
                        stack.extend(candidate.values())
                    elif isinstance(candidate, list):
                        stack.extend(candidate)
                    elif isinstance(candidate, int) and 0 <= candidate < 2**64:
                        commitment = hashlib.sha256(candidate.to_bytes(8, "big")).hexdigest()
                        _registry_add(target, "seed_commitment", commitment)
                    elif isinstance(candidate, str) and re.fullmatch(r"[0-9a-f]{64}", candidate):
                        _registry_add(target, "seed_commitment", candidate)
            _walk_registry(item, target)
    elif isinstance(value, list):
        for item in value:
            _walk_registry(item, target)


def build_prior_registry(
    project: Path, *, include_commitments: bool = False
) -> Mapping[str, Any]:
    roots = (project / "data/cognitive_core", project / "runs/cognitive_core")
    selected: list[Path] = []
    filename_pattern = re.compile(
        r"task|seed|adapt|evaluat|freeze|partition|manifest|quarantine", re.I
    )
    for root in roots:
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix not in {".json", ".jsonl"}:
                continue
            relative = str(path.relative_to(project))
            if (
                "repairability_qualification_v2" in relative
                or "repairability_qualification_v3" in relative
            ):
                continue
            if str(root).endswith("data/cognitive_core") or filename_pattern.search(relative):
                selected.append(path)
    registry: dict[str, set[str]] = {
        "task_id": set(),
        "seed_commitment": set(),
        "adaptation_id": set(),
        "evaluation_id": set(),
        "freeze_id": set(),
        "partition_id": set(),
        "raw_content_hash": set(),
    }
    sources = []
    for path in sorted(set(selected)):
        try:
            if path.suffix == ".jsonl":
                for line in path.read_text(encoding="utf-8").splitlines():
                    if line:
                        _walk_registry(json.loads(line), registry)
            else:
                _walk_registry(json.loads(path.read_text(encoding="utf-8")), registry)
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise RuntimeError(f"prior-registry source is not valid JSON: {path}")
        sources.append(
            {
                "path": str(path.relative_to(project)),
                "bytes": path.stat().st_size,
                "sha256": file_sha256(path),
            }
        )
    body = {
        "algorithm": "recursive-key-registry-v1",
        "source_files": sources,
        "commitment_roots": {
            key: digest(sorted(values)) for key, values in sorted(registry.items())
        },
        "counts": {key: len(values) for key, values in sorted(registry.items())},
    }
    result: dict[str, Any] = {**body, "registry_id": digest(body)}
    if include_commitments:
        result["commitments"] = {
            key: sorted(values) for key, values in sorted(registry.items())
        }
    return result


def verify_launch_and_package(
    project: Path, launch_path: Path
) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    manifest = read_json(launch_path.resolve())
    if manifest.get("activation_status") != "fresh_qualification_execution_authorized":
        raise RuntimeError("post-salt launch manifest is not execution-authorized")
    launch_body = {key: value for key, value in manifest.items() if key != "launch_manifest_id"}
    if digest(launch_body) != manifest.get("launch_manifest_id"):
        raise RuntimeError("launch manifest self-hash mismatch")
    package = read_json(Path(str(manifest["package_path"])).resolve())
    package_body = {key: value for key, value in package.items() if key != "package_id"}
    if (
        digest(package_body) != package.get("package_id")
        or package.get("package_id") != manifest.get("package_id")
        or package.get("code_hash") != manifest.get("code_hash")
    ):
        raise RuntimeError("audited execution package identity mismatch")
    for item in package["files"]:
        path = project / str(item["path"])
        if (
            not path.is_file()
            or path.stat().st_size != int(item["bytes"])
            or file_sha256(path) != item["sha256"]
        ):
            raise RuntimeError(f"packaged runtime file changed: {item['path']}")
    verify_runtime_environment(package)
    return manifest, package


def verify_model_snapshot(
    model_key: str,
    path: Path,
    manifest: Mapping[str, Any],
) -> Mapping[str, Any]:
    contract = next((row for row in MODEL_CONTRACT if row["key"] == model_key), None)
    if contract is None:
        raise ValueError("model is outside the frozen small-model allowlist")
    expected_cache = "models--" + str(contract["repository"]).replace("/", "--")
    if (
        path.name != contract["revision"]
        or path.parent.name != "snapshots"
        or path.parent.parent.name != expected_cache
    ):
        raise ValueError("model repository or revision violates the frozen allowlist")
    expected = next(
        row for row in manifest["model_manifests"] if row["model_key"] == model_key
    )
    weights = [
        {"name": item.name, "bytes": item.stat().st_size, "sha256": file_sha256(item)}
        for item in sorted(path.glob("*.safetensors"))
    ]
    tokenizers = [
        {"name": item.name, "bytes": item.stat().st_size, "sha256": file_sha256(item)}
        for item in sorted(path.iterdir())
        if item.is_file()
        and (item.name.startswith("tokenizer") or item.name in {"vocab.json", "merges.txt"})
    ]
    observed = {
        "repository": contract["repository"],
        "revision": contract["revision"],
        "path": str(path),
        "config_sha256": file_sha256(path / "config.json"),
        "weights": weights,
        "tokenizer_files": tokenizers,
        "exact_parameters": contract.get("exact_parameters"),
        "parameter_boundary_rule": contract["parameter_boundary_rule"],
    }
    for key in (
        "repository",
        "revision",
        "path",
        "config_sha256",
        "weights",
        "tokenizer_files",
        "exact_parameters",
        "parameter_boundary_rule",
    ):
        if observed[key] != expected.get(key):
            raise RuntimeError(f"runtime model manifest mismatch: {key}")
    return {"model_key": model_key, **observed, "model_identity_id": digest(observed)}


def verify_orchestration_ticket(
    path: Path,
    manifest: Mapping[str, Any],
    model_key: str,
    repair_class: str,
    attempt: str,
    stage: str,
    arm: str | None,
) -> Mapping[str, Any]:
    ticket = read_json(path.resolve())
    expected_role = {
        "execute": "generation",
        "train": "trainer",
        "evaluate": "evaluator",
        "leakage": "leakage",
        "score": "scorer",
        "decide": "decision",
    }[stage]
    expected = {
        "freeze_id": manifest["freeze_id"],
        "package_id": manifest["package_id"],
        "launch_manifest_id": manifest["launch_manifest_id"],
        "model_key": model_key,
        "repair_class": repair_class,
        "attempt": attempt,
        "stage": stage,
        "arm": arm,
        "authorized": True,
        "role": expected_role,
    }
    if any(ticket.get(key) != value for key, value in expected.items()):
        raise RuntimeError("global orchestration ticket scope mismatch")
    body = {key: value for key, value in ticket.items() if key != "ticket_id"}
    if digest(body) != ticket.get("ticket_id"):
        raise RuntimeError("global orchestration ticket self-hash mismatch")
    if (
        Path(str(ticket.get("active_ticket_path", ""))).resolve() != path.resolve()
        or ticket.get("raw_seed_release_in_ticket") is not False
        or "seed_release" in ticket
        or digest(ticket.get("seed_request_contracts", {}))
        != ticket.get("seed_request_contracts_root")
    ):
        raise RuntimeError("ticket is not an ephemeral commitment-only capability")
    ledger = read_jsonl(Path(str(ticket["ledger_path"])).resolve())
    issued = next(
        (row for row in ledger if row.get("entry_id") == ticket.get("ledger_entry_id")),
        None,
    )
    if issued is None or any(
        issued.get(key) != ticket.get(key)
        for key in ("model_key", "repair_class", "attempt", "stage", "arm")
    ):
        raise RuntimeError("ticket was not issued by the global ledger")
    consumed = sum(
        float(row.get("normalized_laptop_hours", 0.0))
        for row in ledger
        if row.get("event") in {"stage_completed", "stage_budget_terminated"}
        and int(row.get("sequence", 0)) < int(issued["sequence"])
    )
    if consumed >= float(ticket["maximum_normalized_laptop_hours"]) - 1e-12:
        raise RuntimeError("ticket was issued after the global budget stop")
    if (
        os.environ.get("REPAIRABILITY_SANDBOX_ROLE") != expected_role
        or os.environ.get("REPAIRABILITY_SANDBOX_PROFILE_SHA256")
        != ticket.get("sandbox_profile_sha256")
        or os.environ.get("REPAIRABILITY_PROJECT_ROOT") != ticket.get("project_root")
        or os.environ.get("REPAIRABILITY_TICKET_ID") != ticket.get("ticket_id")
    ):
        raise RuntimeError("active process lacks the ticket-bound sandbox identity")
    project = Path(str(ticket["project_root"])).resolve()
    if project != Path.cwd().resolve():
        raise RuntimeError("sandbox project root differs from the audited workspace")
    protected = {
        "authority": project / "data/cognitive_core/repairability_qualification_v2/sealed/authority.jsonl",
        "vault": project / "data/cognitive_core/repairability_qualification_v2/sealed/seed-vault.json",
        "adaptation": project / "data/cognitive_core/repairability_qualification_v2/training/adaptation.jsonl",
        "public": project / "data/cognitive_core/repairability_qualification_v2/public/tasks.jsonl",
        "alternate_tasks": project / "data/cognitive_core/repairability_qualification_v2/sealed/alternate-tasks/qwen3_1p7b/compute.encrypted.json",
        "protected_write": project / "data/cognitive_core/repairability_qualification_v2/public/tasks.jsonl",
        "pilot_history": project / "data/cognitive_core/repairability_qualification_v1/tasks-public.jsonl",
        "execution_write": project / "runs/cognitive_core/repairability_qualification_v2/sealed_execution/.firewall-sentinel.json",
        "adapter_write": project / "runs/cognitive_core/repairability_qualification_v2/sealed_adapters/.firewall-sentinel.json",
        "parameter_write": project / "runs/cognitive_core/repairability_qualification_v2/sealed_parameter_execution/.firewall-sentinel.json",
        "current_ticket": path.resolve(),
        "other_ticket": project / "runs/cognitive_core/repairability_qualification_v2/control/tickets/.permission-probe-other.json",
    }
    probe_root = project / "runs/cognitive_core/repairability_qualification_v2/sealed_execution/.permission-probe"
    role_outputs = {
        "generation": probe_root / "unit-scores-generation.jsonl",
        "trainer": probe_root / "unit-scores-trainer.jsonl",
        "evaluator": probe_root / "unit-scores-evaluator.jsonl",
        "leakage": probe_root / "leakage-certificate-leakage.json",
        "scorer": probe_root / "unit-scores-scorer.jsonl",
        "decision": probe_root / "decision-decision.json",
    }
    expectations = {
        "generation": {"authority": False, "vault": False, "public": False, "alternate_tasks": False, "protected_write": False, "pilot_history": False, "execution_write": True, "adapter_write": False, "parameter_write": False, "current_ticket": True, "other_ticket": False, "own_output_write": False},
        "trainer": {"authority": False, "vault": False, "adaptation": True, "public": False, "alternate_tasks": False, "protected_write": False, "pilot_history": False, "execution_write": False, "adapter_write": True, "parameter_write": False, "current_ticket": True, "other_ticket": False, "own_output_write": False},
        "evaluator": {"authority": False, "vault": False, "adaptation": False, "public": False, "alternate_tasks": False, "protected_write": False, "pilot_history": False, "execution_write": False, "adapter_write": False, "parameter_write": True, "current_ticket": True, "other_ticket": False, "own_output_write": False},
        "leakage": {"authority": False, "vault": False, "public": False, "alternate_tasks": False, "protected_write": False, "pilot_history": False, "execution_write": True, "adapter_write": False, "parameter_write": False, "current_ticket": True, "other_ticket": False, "own_output_write": True},
        "scorer": {"authority": True, "vault": False, "adaptation": False, "public": False, "alternate_tasks": False, "protected_write": False, "pilot_history": False, "execution_write": True, "adapter_write": False, "parameter_write": False, "current_ticket": True, "other_ticket": False, "own_output_write": True},
        "decision": {"authority": False, "vault": False, "adaptation": False, "public": False, "alternate_tasks": False, "protected_write": False, "pilot_history": False, "execution_write": True, "adapter_write": False, "parameter_write": False, "current_ticket": True, "other_ticket": False, "own_output_write": True},
    }[expected_role]
    for name, should_read in expectations.items():
        probe_path = role_outputs[expected_role] if name == "own_output_write" else protected[name]
        try:
            if name in {"protected_write", "execution_write", "adapter_write", "parameter_write", "own_output_write"}:
                probe_path.open("r+b").close()
            else:
                probe_path.read_bytes()
            observed = True
        except PermissionError:
            observed = False
        if observed != should_read:
            raise RuntimeError(
                f"active {expected_role} sandbox permission probe failed for {name}"
            )
    consumption_path = path.resolve().with_suffix(path.resolve().suffix + ".consumed")
    consumption = {
        "ticket_id": ticket["ticket_id"],
        "process_id": os.getpid(),
        "status": "consumed_before_protected_stage",
    }
    try:
        descriptor = os.open(
            consumption_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600
        )
    except FileExistsError as error:
        raise RuntimeError("orchestration ticket replay or crash-window retry forbidden") from error
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        handle.write(json.dumps(consumption, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    return ticket


def secure_append_jsonl(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, sort_keys=True, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(path, 0o600)


def secure_write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    payload = json.dumps(value, indent=2, sort_keys=True) + "\n"
    pending = path.with_name(
        f".{path.name}.{os.getpid()}.{time.monotonic_ns()}.pending"
    )
    descriptor = os.open(pending, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(pending, 0o600)
        try:
            os.link(pending, path)
        except FileExistsError:
            if path.read_text(encoding="utf-8") != payload:
                raise RuntimeError(f"refusing to overwrite immutable JSON: {path}")
    finally:
        if pending.exists():
            pending.unlink()


def request_named_seed(
    ticket: Mapping[str, Any],
    task: Mapping[str, Any],
    arm: str,
    call_index: int,
    rendered_prompt_hash: str,
    purpose: str,
    timeout_seconds: float = 30.0,
) -> int:
    """Request one ticket-scoped seed bound to the immediate rendered call.

    Raw seeds exist only in the ephemeral broker response directory while the
    named stage is alive.  Persistent tickets contain commitments, never seeds.
    """
    task_id = str(task["task_id"])
    try:
        contract = ticket["seed_request_contracts"][task_id][arm][call_index]
    except (KeyError, IndexError, TypeError) as error:
        raise RuntimeError("named seed request is outside the ticket contract") from error
    if (
        contract["task_id"] != task_id
        or contract["arm"] != arm
        or int(contract["call_index"]) != int(call_index)
        or contract["seed_commitment"]
        != task["seed_commitments"][arm][call_index]
        or re.fullmatch(r"[0-9a-f]{64}", rendered_prompt_hash) is None
    ):
        raise RuntimeError("named seed request contract mismatch")
    request_body = {
        "ticket_id": ticket["ticket_id"],
        "capability": ticket["seed_broker_capability"],
        "task_id": task_id,
        "arm": arm,
        "call_index": int(call_index),
        "seed_commitment": contract["seed_commitment"],
        "rendered_prompt_hash": rendered_prompt_hash,
        "purpose": purpose,
    }
    request = {**request_body, "request_id": digest(request_body)}
    broker_root = Path(str(ticket["seed_broker_root"])).resolve()
    request_path = broker_root / "requests" / f"{request['request_id']}.json"
    response_path = broker_root / "responses" / f"{request['request_id']}.json"
    if request_path.exists():
        if read_json(request_path) != request:
            raise RuntimeError("named seed request identity collision")
    else:
        secure_write_json(request_path, request)
    deadline = time.monotonic() + timeout_seconds
    while not response_path.exists():
        if time.monotonic() >= deadline:
            raise RuntimeError("named seed broker did not answer the current call")
        time.sleep(0.01)
    response = read_json(response_path)
    response_body = {
        key: value for key, value in response.items() if key != "response_id"
    }
    seed = int(response["seed"])
    if (
        digest(response_body) != response.get("response_id")
        or response.get("request_id") != request["request_id"]
        or response.get("ticket_id") != ticket["ticket_id"]
        or response.get("rendered_prompt_hash") != rendered_prompt_hash
        or response.get("seed_commitment") != contract["seed_commitment"]
        or hashlib.sha256(seed.to_bytes(8, "big")).hexdigest()
        != contract["seed_commitment"]
    ):
        raise RuntimeError("named seed broker response failed call binding")
    return seed
