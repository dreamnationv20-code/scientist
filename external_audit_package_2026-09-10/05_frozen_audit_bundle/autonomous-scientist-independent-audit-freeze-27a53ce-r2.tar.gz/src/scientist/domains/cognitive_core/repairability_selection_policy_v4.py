"""Primary 3B test of the answer-blind candidate-selection policy.

Unlike v3, agreement between first-candidate and selector policies is a valid
zero-effect policy pair.  It is reported as a mediator/compliance statistic but
is never an eligibility condition for the causal estimand.
"""

from __future__ import annotations

import hashlib
import random
import re
from collections import Counter
from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.repairability_candidate_availability_v1 import (
    development_qualified, digest, file_sha256, jsonl, read_rows, score_candidate,
)
from scientist.domains.cognitive_core.repairability_reasoned_choice_v3 import (
    FORGE_HYPOTHESIS_ID, FORGE_PROPOSAL_ID, MINIMUM_REASONING_TOKENS,
    choice_prompt_with_scratchpad, choice_receipt, choice_token_ids,
)
from scientist.domains.cognitive_core.repairability_reasoned_choice_v3 import (
    _invariance_task as _source_invariance_task,
)
from scientist.domains.cognitive_core.repairability_reasoned_choice_v3 import (
    _planning_task as _source_planning_task,
)


VERSION = "cognitive-repairability-selection-policy-v4"
MODEL_KEY = "qwen2p5_3b"
MODEL_ORDER = (MODEL_KEY,)
TASK_SEED = 860_404_100
SCHEDULE_SEED = 860_404_200
PREFLIGHT_TASK_COUNT = 8
PREFLIGHT_CALLS = 1
DEVELOPMENT_TASK_COUNT = 16
PROSPECTIVE_POOL_COUNT = 48
INVARIANCE_TASK_COUNT = 8
SELECTED_PROSPECTIVE_COUNT = 24
CANDIDATE_BANK_CALLS = 5
TEMPERATURE = 0.55
REASONING_MAX_TOKENS = 192
# The execution contains a fixed 328 candidate bank calls and cannot restart.
# These ceilings only guard against a stalled runtime; they leave normal Metal
# load-time variation room to complete the registered program.
MODEL_HOUR_CAP = 1.70
MAXIMUM_TOTAL_HOURS = 2.00


def derive_seed(*labels: object) -> int:
    payload = "\0".join(str(value) for value in (SCHEDULE_SEED, *labels))
    return int.from_bytes(hashlib.sha256(payload.encode("utf-8")).digest()[:4], "big")


def _v4_task(task: Mapping[str, Any]) -> Mapping[str, Any]:
    task_id = str(task["task_id"]).replace("rcv3-", "spv4-")
    return {**task, "version": VERSION, "task_id": task_id}


def _planning_task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    task, authority = _source_planning_task(index, split, rng)
    v4 = _v4_task(task)
    return v4, {**authority, "task_id": v4["task_id"], "family": v4["family"]}


def _invariance_task(index: int, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    task, authority = _source_invariance_task(index, rng)
    v4 = _v4_task(task)
    return v4, {**authority, "task_id": v4["task_id"], "family": v4["family"]}


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(TASK_SEED)
    preflight: list[Mapping[str, Any]] = []
    public: list[Mapping[str, Any]] = []
    authority: list[Mapping[str, Any]] = []
    for index in range(PREFLIGHT_TASK_COUNT):
        task, _ = _planning_task(index, "reasoning_preflight", rng)
        preflight.append({**task, "profile": "reasoning_delivery_preflight"})
    for index in range(DEVELOPMENT_TASK_COUNT):
        task, answer = _planning_task(index, "development", rng); public.append(task); authority.append(answer)
    for index in range(PROSPECTIVE_POOL_COUNT):
        task, answer = _planning_task(index, "prospective", rng); public.append(task); authority.append(answer)
    for index in range(INVARIANCE_TASK_COUNT):
        task, answer = _invariance_task(index, rng); public.append(task); authority.append(answer)
    if len(preflight) != 8 or len(public) != 72 or len(authority) != 72:
        raise RuntimeError("selection-policy panel count mismatch")
    if len({str(row["task_id"]) for row in (*preflight, *public)}) != 80:
        raise RuntimeError("selection-policy task identifiers are not unique")
    return preflight, public, authority


def build_schedule(preflight: Sequence[Mapping[str, Any]], public: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []
    for split, tasks, calls in (
        ("preflight", preflight, PREFLIGHT_CALLS),
        ("development", [row for row in public if row["split"] == "development"], CANDIDATE_BANK_CALLS),
        ("prospective", [row for row in public if row["split"] == "prospective"], CANDIDATE_BANK_CALLS),
    ):
        task_ids = sorted(str(row["task_id"]) for row in tasks)
        random.Random(derive_seed(MODEL_KEY, split, "order")).shuffle(task_ids)
        for order, task_id in enumerate(task_ids):
            rows.append({"model_key": MODEL_KEY, "split": split, "task_id": task_id, "task_order_index": order, "candidate_seeds": [derive_seed(MODEL_KEY, task_id, "candidate", call) for call in range(calls)]})
    return rows


def canonical(candidate: str) -> str:
    return re.sub(r"\s+", "", candidate).casefold()


def policy_gate(task: Mapping[str, Any], calls: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    """Gold-blind gate and both pre-registered answer policies over one bank."""
    valid_labels = {canonical(str(label)): str(label) for label in task["prompt_valid_labels"]}
    candidates = []
    for call in calls:
        receipt = call["candidate_receipt"]
        candidates.append(valid_labels.get(canonical(str(receipt.get("candidate", "")))) if receipt.get("delivered") else None)
    valid = [value for value in candidates if value is not None]
    counts = Counter(valid)
    ranked = sorted(counts, key=lambda value: (-counts[value], canonical(value)))
    top_support = counts[ranked[0]] if ranked else 0
    second_support = counts[ranked[1]] if len(ranked) > 1 else 0
    control = candidates[0] if candidates else None
    treatment = ranked[0] if ranked else None
    delivery = len(calls) == CANDIDATE_BANK_CALLS and len(valid) >= 3
    diversity = len(counts) >= 2
    ordering = len(ranked) >= 2 and top_support > second_support
    control_delivered = control is not None
    eligible = delivery and diversity and ordering and control_delivered and treatment is not None
    return {
        "expected_calls": CANDIDATE_BANK_CALLS, "completed_calls": len(calls),
        "prompt_valid_candidate_count": len(valid), "prompt_valid_unique_count": len(counts),
        "candidate_support": {value: counts[value] for value in ranked}, "top_support": top_support, "runner_up_support": second_support,
        "delivery_passed": delivery, "availability_passed": delivery and diversity,
        "ordering_signal_passed": ordering, "control_delivery_passed": control_delivered,
        "selection_changed": control is not None and treatment is not None and control != treatment,
        "eligible_for_causal_score": eligible,
        "abstention_reason": None if eligible else "candidate_bank_delivery_failure" if not delivery else "candidate_availability_failure" if not diversity else "nondegenerate_ordering_failure" if not ordering else "first_candidate_delivery_failure",
        "control_candidate": control, "treatment_candidate": treatment,
        "selector": "prompt_valid_plurality_then_canonical_label", "selection_used_gold_or_correctness": False,
    }


def invariance_policy(task: Mapping[str, Any], calls: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    gate = policy_gate(task, calls)
    return {**gate, "treatment_candidate": gate["treatment_candidate"] if gate["ordering_signal_passed"] else gate["control_candidate"], "invariance_pair_delivered": gate["control_candidate"] is not None and gate["treatment_candidate"] is not None}


def reasoning_preflight(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    expected = PREFLIGHT_TASK_COUNT * PREFLIGHT_CALLS
    completed = sum(int(row["completed_calls"]) for row in rows)
    choice_delivered = sum(int(row["choice_delivered_calls"]) for row in rows)
    reasoning_delivered = sum(int(row["reasoning_delivered_calls"]) for row in rows)
    valid = all(bool(row["all_choices_prompt_valid"]) for row in rows)
    return {"expected_calls": expected, "completed_calls": completed, "choice_delivered_calls": choice_delivered, "reasoning_delivered_calls": reasoning_delivered, "all_choices_prompt_valid": valid, "qualified": completed == expected and choice_delivered == expected and reasoning_delivered == expected and valid, "uses_no_evaluation_authority": True}
