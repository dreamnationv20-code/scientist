"""Fresh, answer-blind test of state externalization and verified search.

The v4 plurality-policy result is terminal.  This new program does not reopen
or rescore it.  It tests a narrower causal prediction on newly generated,
prompt-visible transition graphs: a deterministic graph-search tool can repair
failures caused by externally executable shortest-path search, while a faithful
state rendering may or may not suffice for the language model by itself.
"""

from __future__ import annotations

import hashlib
import random
import re
from collections import deque
from typing import Any, Mapping, Sequence

from scientist.domains.cognitive_core.repairability_candidate_availability_v1 import (
    _planning_task as _source_planning_task,
)
from scientist.domains.cognitive_core.repairability_candidate_availability_v1 import (
    digest, file_sha256, jsonl, read_rows,
)
from scientist.domains.cognitive_core.repairability_reasoned_choice_v3 import (
    MINIMUM_REASONING_TOKENS, choice_prompt_with_scratchpad,
)


VERSION = "cognitive-repairability-verified-search-v5"
MODEL_KEY = "qwen2p5_3b"
TASK_SEED = 860_405_100
SCHEDULE_SEED = 860_405_200
PREFLIGHT_TASK_COUNT = 8
DEVELOPMENT_TASK_COUNT = 16
PROSPECTIVE_TASK_COUNT = 32
REASONING_MAX_TOKENS = 192
MODEL_HOUR_CAP = 1.40
MAXIMUM_TOTAL_HOURS = 1.40
CHOICE_LABELS = ("A", "B", "C", "D")

_EDGE = re.compile(
    r"^Operation (?P<action>op-\d+) can be used only in (?P<source>sector-\d+); "
    r"it moves the agent to (?P<target>sector-\d+)\.$",
    re.MULTILINE,
)
_GOAL = re.compile(
    r"It starts in (?P<start>sector-\d+) and must reach (?P<goal>sector-\d+) "
    r"in the fewest operations\."
)


def derive_seed(*labels: object) -> int:
    payload = "\0".join(str(value) for value in (SCHEDULE_SEED, *labels))
    return int.from_bytes(hashlib.sha256(payload.encode("utf-8")).digest()[:4], "big")


def _choice_prompt(base_prompt: str, mapping: Mapping[str, str]) -> str:
    prefix = base_prompt.split("Which operation", 1)[0]
    options = "\n".join(f"{label}: {mapping[label]}" for label in CHOICE_LABELS)
    return (
        prefix.rstrip()
        + "\n\nChoose the correct first-operation option.\n"
        + options
        + "\nOutput only one option letter. Do not explain.\nFINAL: "
    )


def _v5_task(index: int, split: str, rng: random.Random) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    source, source_authority = _source_planning_task(index, split, rng)
    operations = list(source["prompt_valid_labels"])
    rng.shuffle(operations)
    mapping = dict(zip(CHOICE_LABELS, operations, strict=True))
    answer = next(label for label, operation in mapping.items() if operation == source_authority["answer"])
    task_id = f"v5-{split}-verified-search-{index:02d}"
    prompt = _choice_prompt(str(source["prompt"]), mapping)
    context = prompt.split("\n\nChoose the correct", 1)[0]
    reasoning_prompt = (
        context
        + "\n\nWork through the transition graph carefully. This is a private "
        "scratchpad for a later constrained answer step. Identify the shortest "
        "route from the visible facts; do not use information outside the prompt."
    )
    public = {
        "version": VERSION,
        "task_id": task_id,
        "split": split,
        "family": "opaque_shortest_path_planning",
        "profile": "verified_search_target",
        "prompt": prompt,
        "reasoning_prompt": reasoning_prompt,
        "prompt_valid_labels": list(CHOICE_LABELS),
        "choice_mapping_prompt_visible": mapping,
        "matched_features": {
            **source["matched_features"],
            "choice_count": 4,
            "decoder": "single_token_choice",
            "tool_contract": "parse_visible_transition_facts_then_breadth_first_search",
        },
    }
    authority = {"task_id": task_id, "family": public["family"], "answer": answer}
    return public, authority


def build_panel() -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], list[Mapping[str, Any]]]:
    rng = random.Random(TASK_SEED)
    preflight: list[Mapping[str, Any]] = []
    public: list[Mapping[str, Any]] = []
    authority: list[Mapping[str, Any]] = []
    for index in range(PREFLIGHT_TASK_COUNT):
        task, _ = _v5_task(index, "preflight", rng)
        preflight.append({**task, "profile": "delivery_and_tool_preflight"})
    for index in range(DEVELOPMENT_TASK_COUNT):
        task, answer = _v5_task(index, "development", rng)
        public.append(task); authority.append(answer)
    for index in range(PROSPECTIVE_TASK_COUNT):
        task, answer = _v5_task(index, "prospective", rng)
        public.append(task); authority.append(answer)
    if len(preflight) != PREFLIGHT_TASK_COUNT or len(public) != 48 or len(authority) != 48:
        raise RuntimeError("v5 panel count mismatch")
    identifiers = [str(row["task_id"]) for row in (*preflight, *public)]
    if len(identifiers) != len(set(identifiers)):
        raise RuntimeError("v5 task identifiers are not unique")
    return preflight, public, authority


def build_schedule(preflight: Sequence[Mapping[str, Any]], public: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    rows: list[Mapping[str, Any]] = []
    for split, tasks in (
        ("preflight", preflight),
        ("development", [row for row in public if row["split"] == "development"]),
        ("prospective", [row for row in public if row["split"] == "prospective"]),
    ):
        identifiers = sorted(str(row["task_id"]) for row in tasks)
        random.Random(derive_seed(MODEL_KEY, split, "order")).shuffle(identifiers)
        rows.extend(
            {
                "model_key": MODEL_KEY,
                "split": split,
                "task_id": task_id,
                "task_order_index": order,
                "seed": derive_seed(MODEL_KEY, task_id, "reasoned_choice"),
            }
            for order, task_id in enumerate(identifiers)
        )
    return rows


def _graph(task: Mapping[str, Any]) -> tuple[str, str, list[tuple[str, str, str]]]:
    prompt = str(task["prompt"])
    goal_match = _GOAL.search(prompt)
    edges = [(match["source"], match["target"], match["action"]) for match in _EDGE.finditer(prompt)]
    if goal_match is None or len(edges) < 2:
        raise RuntimeError("visible graph parser could not establish task state")
    actions = [action for _, _, action in edges]
    if len(actions) != len(set(actions)):
        raise RuntimeError("visible graph actions are not unique")
    return goal_match["start"], goal_match["goal"], edges


def canonical_state(task: Mapping[str, Any]) -> Mapping[str, Any]:
    """A lossless, non-solving state rendering of only prompt-visible facts."""
    start, goal, edges = _graph(task)
    lines = [f"start: {start}", f"goal: {goal}", "transitions:"]
    for source, target, action in sorted(edges):
        lines.append(f"{source} --{action}--> {target}")
    text = "\n".join(lines)
    return {
        "method": "lossless_canonical_graph_state_from_visible_prompt",
        "state": text,
        "state_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "edge_count": len(edges),
        "uses_evaluation_authority": False,
    }


def state_augmented_task(task: Mapping[str, Any]) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    state = canonical_state(task)
    marker = "\n\nChoose the correct"
    prefix, suffix = str(task["prompt"]).split(marker, 1)
    state_block = "\n\nEXTERNAL CANONICAL STATE (a transcription, not a solved answer):\n" + str(state["state"])
    prompt = prefix + state_block + marker + suffix
    reasoning = str(task["reasoning_prompt"]) + state_block
    return {**task, "prompt": prompt, "reasoning_prompt": reasoning}, state


def verified_search_tool(task: Mapping[str, Any]) -> Mapping[str, Any]:
    """Answer-blind BFS over the task's visible graph; no authority is accepted."""
    start, goal, edges = _graph(task)
    outgoing: dict[str, list[tuple[str, str]]] = {}
    for source, target, action in edges:
        outgoing.setdefault(source, []).append((target, action))
    frontier: deque[tuple[str, tuple[str, ...]]] = deque([(start, ())])
    seen = {start}
    route: tuple[str, ...] | None = None
    while frontier:
        node, actions = frontier.popleft()
        if node == goal:
            route = actions
            break
        for target, action in sorted(outgoing.get(node, ())):
            if target not in seen:
                seen.add(target)
                frontier.append((target, (*actions, action)))
    if not route:
        raise RuntimeError("visible graph tool found no route")
    inverse = {str(operation): str(label) for label, operation in task["choice_mapping_prompt_visible"].items()}
    candidate = inverse.get(route[0])
    if candidate not in task["prompt_valid_labels"]:
        raise RuntimeError("tool route does not map to a prompt-visible answer label")
    visible_graph = "\n".join(f"{source}\0{target}\0{action}" for source, target, action in sorted(edges))
    return {
        "method": "answer_blind_visible_graph_breadth_first_search",
        "candidate": candidate,
        "delivered": True,
        "route_operations": list(route),
        "route_length": len(route),
        "visible_graph_sha256": hashlib.sha256(visible_graph.encode("utf-8")).hexdigest(),
        "uses_evaluation_authority": False,
        "tool_contract_satisfied": True,
    }


def preflight_certificate(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    expected = PREFLIGHT_TASK_COUNT
    baseline = sum(bool(row["baseline_delivered"]) for row in rows)
    state = sum(bool(row["state_delivered"]) for row in rows)
    tool = sum(bool(row["tool_delivered"] and row["tool_contract_satisfied"]) for row in rows)
    reasoning = sum(bool(row["baseline_reasoning_delivered"] and row["state_reasoning_delivered"]) for row in rows)
    qualified = len(rows) == expected and baseline == expected and state == expected and tool == expected and reasoning == expected
    return {"expected_tasks": expected, "completed_tasks": len(rows), "baseline_delivered": baseline, "state_delivered": state, "tool_delivered": tool, "both_reasoning_delivered": reasoning, "qualified": qualified, "uses_no_evaluation_authority": True}


def development_certificate(rows: Sequence[Mapping[str, Any]], authority: Mapping[str, Mapping[str, Any]]) -> Mapping[str, Any]:
    def correct(row: Mapping[str, Any], arm: str) -> bool:
        return str(row[f"{arm}_candidate"]) == str(authority[str(row["task_id"])]["answer"])
    baseline_delivered = sum(bool(row["baseline_delivered"]) for row in rows)
    baseline_correct = sum(correct(row, "baseline") for row in rows if row["baseline_delivered"])
    tool_delivered = sum(bool(row["tool_delivered"] and row["tool_contract_satisfied"]) for row in rows)
    tool_correct = sum(correct(row, "tool") for row in rows if row["tool_delivered"])
    checks = {
        "expected_task_count": len(rows) == DEVELOPMENT_TASK_COUNT,
        "baseline_delivery_at_least_75pct": baseline_delivered >= 12,
        "baseline_correctness_not_floor": baseline_correct >= 2,
        "baseline_correctness_not_ceiling": baseline_correct <= 14,
        "tool_contract_delivered_all": tool_delivered == DEVELOPMENT_TASK_COUNT,
        "tool_visible_graph_solution_correct_all": tool_correct == DEVELOPMENT_TASK_COUNT,
    }
    return {"development_task_count": len(rows), "baseline_delivered_count": baseline_delivered, "baseline_correct_count": baseline_correct, "tool_delivered_count": tool_delivered, "tool_correct_count": tool_correct, "checks": checks, "qualified": all(checks.values()), "qualification_uses_only_development_authority": True, "prospective_authority_loaded": False}
