from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Dict, List, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.learning import (
    LEARNING_CONTRACT_VERSION,
    LearningConfig,
    TrainingCondition,
)


REPLICATION_VERSION = "cognitive-core-router-replication-v1"
DEVELOPMENT_DATA_SEED = 20260729


@dataclass(frozen=True)
class ReplicationPair:
    model_seed: int
    data_seed: int

    def as_dict(self) -> Dict[str, int]:
        return {
            "model_seed": self.model_seed,
            "data_seed": self.data_seed,
        }


@dataclass(frozen=True)
class Arm:
    name: str
    evidence_schedule: str
    relevance_annotation: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "evidence_schedule": self.evidence_schedule,
            "relevance_annotation": self.relevance_annotation,
        }


@dataclass(frozen=True)
class ReplicationSpec:
    pairs: Tuple[ReplicationPair, ...]
    arms: Tuple[Arm, ...]
    fact_count: int = 192
    width: int = 32
    steps: int = 1600
    compute_device: str = "cpu"

    def __post_init__(self) -> None:
        if len(self.pairs) < 3:
            raise ValueError("replication requires at least three pairs")
        if any(
            pair.data_seed == DEVELOPMENT_DATA_SEED
            for pair in self.pairs
        ):
            raise ValueError("replication cannot reuse development data")
        if len({pair.data_seed for pair in self.pairs}) != len(self.pairs):
            raise ValueError("replication data seeds must be distinct")
        names = {arm.name for arm in self.arms}
        required = {
            "baseline",
            "annotation_only",
            "schedule_only",
            "candidate",
        }
        if names != required:
            raise ValueError("replication arms must match the frozen design")

    @property
    def spec_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))[:20]

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        payload = {
            "replication_version": REPLICATION_VERSION,
            "learning_contract_version": LEARNING_CONTRACT_VERSION,
            "pairs": [pair.as_dict() for pair in self.pairs],
            "arms": [arm.as_dict() for arm in self.arms],
            "fact_count": self.fact_count,
            "width": self.width,
            "steps": self.steps,
            "compute_device": self.compute_device,
        }
        if include_id:
            payload["spec_id"] = self.spec_id
        return payload


def frozen_spec() -> ReplicationSpec:
    return ReplicationSpec(
        pairs=(
            ReplicationPair(model_seed=11, data_seed=20260801),
            ReplicationPair(model_seed=12, data_seed=20260802),
            ReplicationPair(model_seed=13, data_seed=20260803),
        ),
        arms=(
            Arm("baseline", "balanced", False),
            Arm("annotation_only", "balanced", True),
            Arm("schedule_only", "routing_10", False),
            Arm("candidate", "routing_10", True),
        ),
    )


def _config(
    spec: ReplicationSpec,
    pair: ReplicationPair,
    arm: Arm,
) -> LearningConfig:
    return LearningConfig(
        condition=TrainingCondition.RANDOM_FACTS,
        fact_count=spec.fact_count,
        width=spec.width,
        steps=spec.steps,
        model_seed=pair.model_seed,
        data_seed=pair.data_seed,
        compute_device=spec.compute_device,
        evidence_schedule=arm.evidence_schedule,
        relevance_annotation=arm.relevance_annotation,
    )


def _mean_metric(
    results: Mapping[str, Sequence[Any]],
    arm: str,
    metric: str,
) -> float:
    return mean(result.metrics[metric] for result in results[arm])


def _deltas(
    results: Mapping[str, Sequence[Any]],
    metric: str,
) -> Tuple[float, ...]:
    return tuple(
        candidate.metrics[metric] - baseline.metrics[metric]
        for candidate, baseline in zip(
            results["candidate"],
            results["baseline"],
        )
    )


def summarize(
    spec: ReplicationSpec,
    results: Mapping[str, Sequence[Any]],
) -> Dict[str, Any]:
    metrics = (
        "procedure_accuracy",
        "closed_book_accuracy",
        "oracle_evidence_accuracy",
        "irrelevant_evidence_accuracy",
        "conflicting_evidence_accuracy",
        "unknown_accuracy",
        "known_answer_destruction",
        "cognitive_core_score",
    )
    arm_means = {
        arm.name: {
            metric: _mean_metric(results, arm.name, metric)
            for metric in metrics
        }
        for arm in spec.arms
    }
    paired_deltas = {
        metric: list(_deltas(results, metric))
        for metric in metrics
    }
    procedure_deltas = paired_deltas["procedure_accuracy"]
    oracle_deltas = paired_deltas["oracle_evidence_accuracy"]
    destruction_deltas = paired_deltas["known_answer_destruction"]
    candidate = arm_means["candidate"]
    baseline = arm_means["baseline"]
    candidate_scores = [
        result.metrics["cognitive_core_score"]
        for result in results["candidate"]
    ]
    baseline_scores = [
        result.metrics["cognitive_core_score"]
        for result in results["baseline"]
    ]
    ablation_best = max(
        arm_means["annotation_only"]["cognitive_core_score"],
        arm_means["schedule_only"]["cognitive_core_score"],
    )
    checks = {
        "closed_book_memory_retained": (
            candidate["closed_book_accuracy"] >= 0.95
        ),
        "procedure_noninferior": (
            mean(procedure_deltas) >= -0.05
            and min(procedure_deltas) >= -0.10
        ),
        "oracle_evidence_improves": mean(oracle_deltas) >= 0.05,
        "known_answer_destruction_bounded": (
            candidate["known_answer_destruction"] <= 0.10
        ),
        "known_answer_destruction_rescued": (
            mean(destruction_deltas) <= -0.50
        ),
        "conflict_handling_retained": (
            candidate["conflicting_evidence_accuracy"] >= 0.95
        ),
        "unknown_abstention_retained": (
            candidate["unknown_accuracy"] >= 0.95
        ),
        "composite_improves_every_pair": all(
            candidate_score > baseline_score
            for candidate_score, baseline_score in zip(
                candidate_scores,
                baseline_scores,
            )
        ),
        "hybrid_beats_each_ablation": (
            candidate["cognitive_core_score"] > ablation_best
        ),
    }
    return {
        "replication_version": REPLICATION_VERSION,
        "spec_id": spec.spec_id,
        "passed": all(checks.values()),
        "checks": dict(sorted(checks.items())),
        "arm_means": arm_means,
        "paired_candidate_minus_baseline": paired_deltas,
        "run_ids": {
            name: [result.run_id for result in arm_results]
            for name, arm_results in sorted(results.items())
        },
    }


def run_replication(
    output_root: Path,
    spec: ReplicationSpec,
) -> Dict[str, Any]:
    from scientist.domains.cognitive_core.mlx_lab import train_and_evaluate

    store = ArtifactStore(output_root)
    store.write_manifest(
        "frozen-spec-" + spec.spec_id,
        spec.as_dict(),
    )
    results: Dict[str, List[Any]] = {
        arm.name: []
        for arm in spec.arms
    }
    for pair in spec.pairs:
        for arm in spec.arms:
            result = train_and_evaluate(_config(spec, pair, arm))
            store.put("cognitive_core_replication_run", result.as_dict())
            results[arm.name].append(result)
            print(
                json.dumps(
                    {
                        "arm": arm.name,
                        "data_seed": pair.data_seed,
                        "model_seed": pair.model_seed,
                        "run_id": result.run_id,
                        "procedure": round(
                            result.metrics["procedure_accuracy"],
                            4,
                        ),
                        "oracle": round(
                            result.metrics[
                                "oracle_evidence_accuracy"
                            ],
                            4,
                        ),
                        "destruction": round(
                            result.metrics[
                                "known_answer_destruction"
                            ],
                            4,
                        ),
                        "score": round(
                            result.metrics["cognitive_core_score"],
                            4,
                        ),
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
    report = summarize(spec, results)
    report_id = content_digest(report)[:20]
    store.write_manifest(
        "replication-report-" + report_id,
        report,
    )
    return report


def main(argv: Sequence[str] = ()) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="runs/cognitive_core/router_replication_v1",
    )
    arguments = parser.parse_args(list(argv) or None)
    report = run_replication(
        Path(arguments.output),
        frozen_spec(),
    )
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
