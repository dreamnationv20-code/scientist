from __future__ import annotations

from statistics import mean, median, pstdev
from typing import Any, Mapping, Sequence, Tuple


REPRESENTATION_ATLAS_VERSION = "general-cognitive-representation-atlas-v52w"
M52W_SEED = 53051
M52W_M52V_AUDIT_ID = (
    "38ac87a550374e364ebfbaee41a2c2137489bb1df08e4d47b64f6f08569f014b"
)


def authorized_atlas_rows(
    rows: Sequence[Mapping[str, Any]],
    semantic_splits: Sequence[str],
    transformation_splits: Sequence[str],
) -> Tuple[Mapping[str, Any], ...]:
    allowed_semantic = set(semantic_splits)
    allowed_transformations = set(transformation_splits)
    return tuple(
        row
        for row in rows
        if str(row["metadata"]["semantic_split"]) in allowed_semantic
        and str(row["metadata"]["basis_transformation_split"])
        in allowed_transformations
        and str(row["metadata"]["candidate_transformation_split"])
        in allowed_transformations
    )


def authorized_rows_are_closed(
    rows: Sequence[Mapping[str, Any]],
    semantic_splits: Sequence[str],
    transformation_splits: Sequence[str],
) -> bool:
    allowed_semantic = set(semantic_splits)
    allowed_transformations = set(transformation_splits)
    return bool(rows) and all(
        str(row["metadata"]["semantic_split"]) in allowed_semantic
        and str(row["metadata"]["basis_transformation_split"])
        in allowed_transformations
        and str(row["metadata"]["candidate_transformation_split"])
        in allowed_transformations
        for row in rows
    )


def relation_margin_records(
    rows: Sequence[Mapping[str, Any]], margins: Sequence[float]
) -> Tuple[Mapping[str, Any], ...]:
    if len(rows) != len(margins):
        raise ValueError("M52w requires one margin per frozen relation row")
    records = []
    for row, margin in zip(rows, margins):
        metadata = row["metadata"]
        records.append(
            {
                "record_id": str(metadata["record_id"]),
                "orbit_id": str(metadata["orbit_id"]),
                "family": str(metadata["family"]),
                "semantic_split": str(metadata["semantic_split"]),
                "basis_state_key": str(metadata["basis_state_key"]),
                "candidate_state_key": str(metadata["candidate_state_key"]),
                "basis_transformation": str(metadata["basis_transformation"]),
                "basis_transformation_split": str(
                    metadata["basis_transformation_split"]
                ),
                "candidate_transformation": str(
                    metadata["candidate_transformation"]
                ),
                "candidate_transformation_split": str(
                    metadata["candidate_transformation_split"]
                ),
                "target": str(metadata["relation_target"]),
                "margin": float(margin),
                "prediction": "YES" if float(margin) > 0.0 else "NO",
            }
        )
    return tuple(records)


def _ranking_groups(
    records: Sequence[Mapping[str, Any]],
) -> Mapping[tuple[str, str, str, str], Tuple[Mapping[str, Any], ...]]:
    groups: dict[tuple[str, str, str, str], list[Mapping[str, Any]]] = {}
    for row in records:
        key = (
            str(row["family"]),
            str(row["basis_state_key"]),
            str(row["basis_transformation"]),
            str(row["candidate_transformation"]),
        )
        groups.setdefault(key, []).append(row)
    return {key: tuple(values) for key, values in groups.items()}


def ranking_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, float | int]:
    comparisons = []
    top1 = []
    ties = 0
    for group in _ranking_groups(records).values():
        positive = [row for row in group if row["target"] == "YES"]
        negative = [row for row in group if row["target"] == "NO"]
        if len(positive) != 1 or len(negative) != 3:
            raise ValueError("M52w ranking groups require one positive and three negatives")
        positive_margin = float(positive[0]["margin"])
        gaps = [positive_margin - float(row["margin"]) for row in negative]
        comparisons.extend(gap > 0.0 for gap in gaps)
        top1.append(all(gap > 0.0 for gap in gaps))
        ties += sum(gap == 0.0 for gap in gaps)
    gaps_values = []
    for group in _ranking_groups(records).values():
        positive_margin = float(
            next(row["margin"] for row in group if row["target"] == "YES")
        )
        gaps_values.extend(
            positive_margin - float(row["margin"])
            for row in group
            if row["target"] == "NO"
        )
    return {
        "group_count": len(top1),
        "comparison_count": len(comparisons),
        "ranking_accuracy": sum(comparisons) / max(len(comparisons), 1),
        "top1_accuracy": sum(top1) / max(len(top1), 1),
        "mean_ranking_gap": mean(gaps_values) if gaps_values else 0.0,
        "median_ranking_gap": median(gaps_values) if gaps_values else 0.0,
        "minimum_ranking_gap": min(gaps_values, default=0.0),
        "tie_count": ties,
    }


def absolute_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, float | int]:
    true_positive = sum(
        row["target"] == "YES" and row["prediction"] == "YES" for row in records
    )
    true_negative = sum(
        row["target"] == "NO" and row["prediction"] == "NO" for row in records
    )
    false_positive = sum(
        row["target"] == "NO" and row["prediction"] == "YES" for row in records
    )
    false_negative = sum(
        row["target"] == "YES" and row["prediction"] == "NO" for row in records
    )
    positive_count = true_positive + false_negative
    negative_count = true_negative + false_positive
    sensitivity = true_positive / max(positive_count, 1)
    specificity = true_negative / max(negative_count, 1)
    return {
        "count": len(records),
        "true_positive": true_positive,
        "true_negative": true_negative,
        "false_positive": false_positive,
        "false_negative": false_negative,
        "sensitivity": sensitivity,
        "specificity": specificity,
        "balanced_accuracy": (sensitivity + specificity) / 2.0,
        "accuracy": (true_positive + true_negative) / max(len(records), 1),
        "predicted_yes_rate": (true_positive + false_positive)
        / max(len(records), 1),
    }


def _slice_metrics(
    records: Sequence[Mapping[str, Any]], key: str
) -> Mapping[str, Mapping[str, Any]]:
    values = sorted({str(row[key]) for row in records})
    return {
        value: {
            "ranking": ranking_metrics(
                [row for row in records if str(row[key]) == value]
            ),
            "absolute": absolute_metrics(
                [row for row in records if str(row[key]) == value]
            ),
        }
        for value in values
    }


def _transform_pair_metrics(
    records: Sequence[Mapping[str, Any]], split_level: bool = False
) -> Mapping[str, Mapping[str, Any]]:
    basis_key = (
        "basis_transformation_split" if split_level else "basis_transformation"
    )
    candidate_key = (
        "candidate_transformation_split"
        if split_level
        else "candidate_transformation"
    )
    pairs = sorted(
        {
            (str(row[basis_key]), str(row[candidate_key]))
            for row in records
        }
    )
    return {
        f"{basis}|{candidate}": {
            "ranking": ranking_metrics(
                [
                    row
                    for row in records
                    if str(row[basis_key]) == basis
                    and str(row[candidate_key]) == candidate
                ]
            ),
            "absolute": absolute_metrics(
                [
                    row
                    for row in records
                    if str(row[basis_key]) == basis
                    and str(row[candidate_key]) == candidate
                ]
            ),
        }
        for basis, candidate in pairs
    }


def _invariance_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    expected_style_pairs = len(
        {str(row["basis_transformation"]) for row in records}
    ) * len({str(row["candidate_transformation"]) for row in records})
    relation_orbits: dict[tuple[str, str, str], list[Mapping[str, Any]]] = {}
    for row in records:
        key = (
            str(row["family"]),
            str(row["basis_state_key"]),
            str(row["candidate_state_key"]),
        )
        relation_orbits.setdefault(key, []).append(row)
    prediction_consistent = []
    correct_all_styles = []
    style_accuracies = []
    margin_standard_deviations = []
    margin_ranges = []
    for orbit in relation_orbits.values():
        if len(orbit) != expected_style_pairs:
            raise ValueError("M52w relation orbits require the complete style crossing")
        predictions = {str(row["prediction"]) for row in orbit}
        correctness = [row["prediction"] == row["target"] for row in orbit]
        margins = [float(row["margin"]) for row in orbit]
        prediction_consistent.append(len(predictions) == 1)
        correct_all_styles.append(all(correctness))
        style_accuracies.append(sum(correctness) / len(correctness))
        margin_standard_deviations.append(pstdev(margins))
        margin_ranges.append(max(margins) - min(margins))

    basis_orbits: dict[tuple[str, str], list[bool]] = {}
    for key, group in _ranking_groups(records).items():
        family, basis_state, _, _ = key
        positive = float(next(row["margin"] for row in group if row["target"] == "YES"))
        correct = all(
            positive > float(row["margin"])
            for row in group
            if row["target"] == "NO"
        )
        basis_orbits.setdefault((family, basis_state), []).append(correct)
    if not all(len(values) == expected_style_pairs for values in basis_orbits.values()):
        raise ValueError("M52w basis orbits require the complete style crossing")
    basis_rates = [sum(values) / len(values) for values in basis_orbits.values()]
    return {
        "relation_orbit_count": len(relation_orbits),
        "prediction_consistency_rate": sum(prediction_consistent)
        / max(len(prediction_consistent), 1),
        "correct_on_all_styles_rate": sum(correct_all_styles)
        / max(len(correct_all_styles), 1),
        "mean_relation_orbit_accuracy": mean(style_accuracies),
        "median_margin_standard_deviation": median(margin_standard_deviations),
        "median_margin_range": median(margin_ranges),
        "basis_orbit_count": len(basis_orbits),
        "all_transform_top1_rate": sum(rate == 1.0 for rate in basis_rates)
        / max(len(basis_rates), 1),
        "mean_basis_orbit_top1_rate": mean(basis_rates),
        "minimum_basis_orbit_top1_rate": min(basis_rates, default=0.0),
    }


def atlas_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    if not records:
        raise ValueError("M52w atlas requires records")
    by_family = _slice_metrics(records, "family")
    by_basis = _slice_metrics(records, "basis_transformation")
    by_candidate = _slice_metrics(records, "candidate_transformation")
    transform_pairs = _transform_pair_metrics(records)
    quadrants = _transform_pair_metrics(records, split_level=True)
    return {
        "overall": {
            "ranking": ranking_metrics(records),
            "absolute": absolute_metrics(records),
        },
        "by_family": by_family,
        "by_semantic_split": _slice_metrics(records, "semantic_split"),
        "by_basis_transformation": by_basis,
        "by_candidate_transformation": by_candidate,
        "by_transformation_pair": transform_pairs,
        "by_transformation_quadrant": quadrants,
        "invariance": _invariance_metrics(records),
        "extrema": {
            "minimum_family_ranking_accuracy": min(
                value["ranking"]["ranking_accuracy"] for value in by_family.values()
            ),
            "maximum_family_ranking_accuracy": max(
                value["ranking"]["ranking_accuracy"] for value in by_family.values()
            ),
            "minimum_basis_transformation_ranking_accuracy": min(
                value["ranking"]["ranking_accuracy"] for value in by_basis.values()
            ),
            "minimum_candidate_transformation_ranking_accuracy": min(
                value["ranking"]["ranking_accuracy"] for value in by_candidate.values()
            ),
            "minimum_transformation_pair_ranking_accuracy": min(
                value["ranking"]["ranking_accuracy"]
                for value in transform_pairs.values()
            ),
        },
    }


def diagnose_atlas(
    metrics: Mapping[str, Any], thresholds: Mapping[str, float]
) -> Mapping[str, Any]:
    quadrants = metrics["by_transformation_quadrant"]
    discovery = float(quadrants["discovery|discovery"]["ranking"]["ranking_accuracy"])
    development_values = [
        float(value["ranking"]["ranking_accuracy"])
        for key, value in quadrants.items()
        if "development" in key
    ]
    worst_development = min(development_values)
    family_values = [
        float(value["ranking"]["ranking_accuracy"])
        for value in metrics["by_family"].values()
    ]
    basis_values = [
        float(value["ranking"]["ranking_accuracy"])
        for value in metrics["by_basis_transformation"].values()
    ]
    candidate_values = [
        float(value["ranking"]["ranking_accuracy"])
        for value in metrics["by_candidate_transformation"].values()
    ]
    overall = float(metrics["overall"]["ranking"]["ranking_accuracy"])
    worst_pair = float(metrics["extrema"]["minimum_transformation_pair_ranking_accuracy"])
    all_transform = float(metrics["invariance"]["all_transform_top1_rate"])
    checks = {
        "minimum_overall_ranking_accuracy": overall
        >= float(thresholds["minimum_overall_ranking_accuracy"]),
        "minimum_each_family_ranking_accuracy": min(family_values)
        >= float(thresholds["minimum_each_family_ranking_accuracy"]),
        "minimum_each_transformation_pair_ranking_accuracy": worst_pair
        >= float(thresholds["minimum_each_transformation_pair_ranking_accuracy"]),
        "minimum_development_quadrant_ranking_accuracy": worst_development
        >= float(thresholds["minimum_development_quadrant_ranking_accuracy"]),
        "maximum_discovery_to_development_decline": discovery - worst_development
        <= float(thresholds["maximum_discovery_to_development_decline"]),
        "minimum_all_transform_top1_rate": all_transform
        >= float(thresholds["minimum_all_transform_top1_rate"]),
    }
    diagnoses = {
        "uniform_relation_deficit": discovery
        < float(thresholds["uniform_relation_deficit_below"]),
        "semantic_family_generalization_failure": min(family_values)
        < float(thresholds["minimum_each_family_ranking_accuracy"])
        and max(family_values) - min(family_values)
        > float(thresholds["family_spread_failure_above"]),
        "transformation_generalization_failure": not checks[
            "minimum_development_quadrant_ranking_accuracy"
        ]
        or not checks["maximum_discovery_to_development_decline"],
        "localized_style_interaction": worst_pair
        < float(thresholds["minimum_each_transformation_pair_ranking_accuracy"])
        and min(basis_values)
        >= float(thresholds["minimum_marginal_style_accuracy_for_interaction"])
        and min(candidate_values)
        >= float(thresholds["minimum_marginal_style_accuracy_for_interaction"]),
        "robust_exposed_axis_relation": all(checks.values()),
    }
    return {
        "checks": checks,
        "diagnoses": diagnoses,
        "discovery_discovery_ranking_accuracy": discovery,
        "worst_development_involving_quadrant_ranking_accuracy": worst_development,
        "discovery_to_worst_development_decline": discovery - worst_development,
    }
