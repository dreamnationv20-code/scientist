from __future__ import annotations

import math
from itertools import product
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.cross_channel_binding_v52x import (
    descriptor_direction,
)
from scientist.domains.cognitive_core.independent_paraphrase_orbits_v52v import (
    semantic_relation_prompt,
)
from scientist.domains.cognitive_core.representation_atlas_v52w import (
    relation_margin_records,
)
from scientist.domains.cognitive_core.reciprocal_role_alignment_v52xd import (
    M52XD_HELDOUT_DIRECTIONS,
    M52XD_TRAINED_DIRECTIONS,
)


REPRESENTATION_CONDITIONED_READOUT_VERSION = (
    "general-cognitive-representation-conditioned-readout-v52xf"
)
M52XF_SEED = 53189
M52XF_M52XE_AUDIT_ID = (
    "93e3a1882678fd3419b56674c6cf8d5d2b44a64896f06d12a776d5f0c63e8e05"
)
M52XF_TRAINED_DIRECTIONS = M52XD_TRAINED_DIRECTIONS
M52XF_HELDOUT_DIRECTIONS = M52XD_HELDOUT_DIRECTIONS
M52XF_STYLE_COUNT = 3

M52XF_TRANSFORMS = {
    "selection": {
        "name": ("catalog_identifier", "method_label_clue", "algorithm_alias_marker"),
        "principle": (
            "decision_criterion_statement",
            "invariant_clue",
            "constraint_rule_marker",
        ),
        "action": (
            "runtime_operation_statement",
            "execution_clue",
            "behavior_trace_marker",
        ),
    },
    "confirmation": {
        "name": (
            "verification_identifier",
            "algorithm_label_signature",
            "method_alias_check",
        ),
        "principle": (
            "verification_criterion",
            "invariant_signature_check",
            "rule_identity_check",
        ),
        "action": (
            "verification_operation",
            "execution_signature_check",
            "behavior_identity_check",
        ),
    },
}


def _fresh_text(
    state: Mapping[str, str],
    channel: str,
    role: str,
    formulation: str,
    style: int,
) -> str:
    value = str(state[channel])
    templates = {
        ("selection", 0, "name", "basis"): "Find the entry corresponding to this catalog identifier: {value}.",
        ("selection", 0, "name", "candidate"): "The candidate entry is catalogued as {value}.",
        ("selection", 0, "principle", "basis"): "Find the entry governed by this decision criterion: {value}.",
        ("selection", 0, "principle", "candidate"): "The candidate entry is governed by this decision criterion: {value}.",
        ("selection", 0, "action", "basis"): "Find the entry producing this runtime operation: {value}.",
        ("selection", 0, "action", "candidate"): "The candidate entry produces this runtime operation: {value}.",
        ("selection", 1, "name", "basis"): "Resolve the mechanism indicated by this method-label clue: {value}.",
        ("selection", 1, "name", "candidate"): "This mechanism bears the method-label clue {value}.",
        ("selection", 1, "principle", "basis"): "Resolve the mechanism indicated by this invariant clue: {value}.",
        ("selection", 1, "principle", "candidate"): "This mechanism obeys the invariant clue: {value}.",
        ("selection", 1, "action", "basis"): "Resolve the mechanism indicated by this execution clue: {value}.",
        ("selection", 1, "action", "candidate"): "This mechanism realizes the execution clue: {value}.",
        ("selection", 2, "name", "basis"): "Pair a design with the following algorithm-alias marker: {value}.",
        ("selection", 2, "name", "candidate"): "The design carries this algorithm-alias marker: {value}.",
        ("selection", 2, "principle", "basis"): "Pair a design with the following constraint-rule marker: {value}.",
        ("selection", 2, "principle", "candidate"): "The design carries this constraint-rule marker: {value}.",
        ("selection", 2, "action", "basis"): "Pair a design with the following behavior-trace marker: {value}.",
        ("selection", 2, "action", "candidate"): "The design carries this behavior-trace marker: {value}.",
        ("confirmation", 0, "name", "basis"): "Confirm a counterpart for this verification identifier: {value}.",
        ("confirmation", 0, "name", "candidate"): "The counterpart reports verification identifier {value}.",
        ("confirmation", 0, "principle", "basis"): "Confirm a counterpart for this verification criterion: {value}.",
        ("confirmation", 0, "principle", "candidate"): "The counterpart reports this verification criterion: {value}.",
        ("confirmation", 0, "action", "basis"): "Confirm a counterpart for this verification operation: {value}.",
        ("confirmation", 0, "action", "candidate"): "The counterpart reports this verification operation: {value}.",
        ("confirmation", 1, "name", "basis"): "Check equivalence using this algorithm-label signature: {value}.",
        ("confirmation", 1, "name", "candidate"): "The checked account has algorithm-label signature {value}.",
        ("confirmation", 1, "principle", "basis"): "Check equivalence using this invariant signature: {value}.",
        ("confirmation", 1, "principle", "candidate"): "The checked account has this invariant signature: {value}.",
        ("confirmation", 1, "action", "basis"): "Check equivalence using this execution signature: {value}.",
        ("confirmation", 1, "action", "candidate"): "The checked account has this execution signature: {value}.",
        ("confirmation", 2, "name", "basis"): "Validate the pairing from this method-alias check: {value}.",
        ("confirmation", 2, "name", "candidate"): "The pairing candidate satisfies method-alias check {value}.",
        ("confirmation", 2, "principle", "basis"): "Validate the pairing from this rule-identity check: {value}.",
        ("confirmation", 2, "principle", "candidate"): "The pairing candidate satisfies this rule-identity check: {value}.",
        ("confirmation", 2, "action", "basis"): "Validate the pairing from this behavior-identity check: {value}.",
        ("confirmation", 2, "action", "candidate"): "The pairing candidate satisfies this behavior-identity check: {value}.",
    }
    try:
        return templates[(formulation, style, channel, role)].format(value=value)
    except KeyError as error:
        raise ValueError(
            "unknown M52xf formulation/style/channel/role: "
            f"{formulation}/{style}/{channel}/{role}"
        ) from error


def build_fresh_readout_rows(
    ledger: Mapping[str, Any], formulation: str
) -> Tuple[Mapping[str, Any], ...]:
    if formulation not in M52XF_TRANSFORMS:
        raise ValueError("M52xf formulation must be selection or confirmation")
    transforms = M52XF_TRANSFORMS[formulation]
    rows = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != "discovery":
            continue
        states = tuple(family_value["states"])
        if len(states) != 4:
            raise ValueError("M52xf requires four states per discovery family")
        for direction in M52XF_TRAINED_DIRECTIONS:
            basis_channel, candidate_channel = direction.split("->")
            for basis_style, candidate_style in product(
                range(M52XF_STYLE_COUNT), repeat=2
            ):
                for basis_state in states:
                    orbit = content_digest(
                        {
                            "milestone": "M52xf",
                            "formulation": formulation,
                            "family": family,
                            "direction": direction,
                            "basis_style": basis_style,
                            "candidate_style": candidate_style,
                            "basis_state": basis_state["key"],
                        }
                    )
                    basis_text = _fresh_text(
                        basis_state,
                        basis_channel,
                        "basis",
                        formulation,
                        basis_style,
                    )
                    for candidate_state in states:
                        candidate_text = _fresh_text(
                            candidate_state,
                            candidate_channel,
                            "candidate",
                            formulation,
                            candidate_style,
                        )
                        metadata = {
                            "record_id": content_digest(
                                {
                                    "orbit": orbit,
                                    "candidate_state": candidate_state["key"],
                                }
                            ),
                            "orbit_id": orbit,
                            "family": str(family),
                            "semantic_split": "discovery",
                            "formulation_split": formulation,
                            "basis_style": int(basis_style),
                            "candidate_style": int(candidate_style),
                            "basis_state_key": str(basis_state["key"]),
                            "candidate_state_key": str(candidate_state["key"]),
                            "basis_transformation": transforms[basis_channel][basis_style],
                            "basis_transformation_split": "m52xf_fresh_readout",
                            "candidate_transformation": transforms[candidate_channel][candidate_style],
                            "candidate_transformation_split": "m52xf_fresh_readout",
                            "basis_text": basis_text,
                            "candidate_text": candidate_text,
                            "relation_target": (
                                "YES"
                                if str(basis_state["key"])
                                == str(candidate_state["key"])
                                else "NO"
                            ),
                        }
                        row = {
                            "prompt": semantic_relation_prompt(
                                basis_text, candidate_text
                            ),
                            "metadata": metadata,
                        }
                        if descriptor_direction(row) != direction:
                            raise ValueError("M52xf transformation routing is inconsistent")
                        rows.append(row)
    return tuple(rows)


def build_readout_training_groups(
    reciprocal_groups: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    groups = []
    for source in reciprocal_groups:
        states = tuple(source["states"])
        if len(states) != 4:
            raise ValueError("M52xf readout training requires four-state groups")
        matrices = (
            ("forward", "left_basis_text", "right_candidate_text"),
            ("reverse", "right_basis_text", "left_candidate_text"),
            ("left_closure", "left_basis_text", "left_candidate_text"),
            ("right_closure", "right_basis_text", "right_candidate_text"),
        )
        for matrix, basis_key, candidate_key in matrices:
            for basis_index, basis_state in enumerate(states):
                rows = []
                for candidate_index, candidate_state in enumerate(states):
                    rows.append(
                        {
                            "basis_text": str(basis_state[basis_key]),
                            "candidate_text": str(candidate_state[candidate_key]),
                            "target": "YES" if basis_index == candidate_index else "NO",
                            "candidate_index": candidate_index,
                        }
                    )
                groups.append(
                    {
                        "group_id": content_digest(
                            {
                                "milestone": "M52xf",
                                "source_group": source["group_id"],
                                "matrix": matrix,
                                "basis_index": basis_index,
                            }
                        ),
                        "source_group_id": str(source["group_id"]),
                        "family": str(source["family"]),
                        "semantic_split": "discovery",
                        "matrix": matrix,
                        "positive_index": basis_index,
                        "rows": rows,
                    }
                )
    return tuple(groups)


def positive_scale(raw_scale: float) -> float:
    value = float(raw_scale)
    if value > 30.0:
        return value
    if value < -30.0:
        return math.exp(value)
    return math.log1p(math.exp(value))


def calibrated_margin(cosine: float, raw_scale: float, bias: float) -> float:
    return positive_scale(raw_scale) * float(cosine) + float(bias)


def calibrated_readout_records(
    rows: Sequence[Mapping[str, Any]],
    similarities: Sequence[float],
    raw_scale: float,
    bias: float,
) -> Tuple[Mapping[str, Any], ...]:
    margins = [
        calibrated_margin(value, raw_scale, bias) for value in similarities
    ]
    return relation_margin_records(rows, margins)


def _sigmoid(value: float) -> float:
    if value >= 0.0:
        inverse = math.exp(-value)
        return 1.0 / (1.0 + inverse)
    direct = math.exp(value)
    return direct / (1.0 + direct)


def _softplus(value: float) -> float:
    return max(value, 0.0) + math.log1p(math.exp(-abs(value)))


def balanced_logistic_loss(
    similarities: Sequence[float],
    targets: Sequence[str],
    raw_scale: float,
    bias: float,
) -> float:
    if len(similarities) != len(targets) or not similarities:
        raise ValueError("M52xf calibration inputs must align and be non-empty")
    positives = [
        _softplus(-calibrated_margin(value, raw_scale, bias))
        for value, target in zip(similarities, targets)
        if target == "YES"
    ]
    negatives = [
        _softplus(calibrated_margin(value, raw_scale, bias))
        for value, target in zip(similarities, targets)
        if target == "NO"
    ]
    if not positives or not negatives:
        raise ValueError("M52xf calibration requires both target classes")
    return 0.5 * (
        sum(positives) / len(positives) + sum(negatives) / len(negatives)
    )


def train_calibrated_readout(
    similarities: Sequence[float],
    targets: Sequence[str],
    *,
    steps: int,
    learning_rate: float,
    checkpoint_steps: Sequence[int],
    initial_raw_scale: float,
    initial_bias: float,
) -> Tuple[Mapping[str, float | int], ...]:
    if len(similarities) != len(targets) or not similarities:
        raise ValueError("M52xf calibration inputs must align and be non-empty")
    positive_count = sum(target == "YES" for target in targets)
    negative_count = sum(target == "NO" for target in targets)
    if positive_count == 0 or negative_count == 0:
        raise ValueError("M52xf calibration requires both target classes")
    requested = {int(step) for step in checkpoint_steps}
    if not requested or min(requested) <= 0 or max(requested) > int(steps):
        raise ValueError("M52xf checkpoint steps must fall inside optimization")
    raw_scale = float(initial_raw_scale)
    bias = float(initial_bias)
    first_moment = [0.0, 0.0]
    second_moment = [0.0, 0.0]
    beta1 = 0.9
    beta2 = 0.999
    epsilon = 1e-8
    checkpoints = []
    for iteration in range(1, int(steps) + 1):
        scale = positive_scale(raw_scale)
        scale_derivative = _sigmoid(raw_scale)
        raw_gradient = 0.0
        bias_gradient = 0.0
        for similarity, target in zip(similarities, targets):
            margin = scale * float(similarity) + bias
            if target == "YES":
                margin_gradient = 0.5 * (_sigmoid(margin) - 1.0) / positive_count
            elif target == "NO":
                margin_gradient = 0.5 * _sigmoid(margin) / negative_count
            else:
                raise ValueError(f"unknown M52xf target: {target}")
            raw_gradient += margin_gradient * float(similarity) * scale_derivative
            bias_gradient += margin_gradient
        gradients = (raw_gradient, bias_gradient)
        values = [raw_scale, bias]
        for index, gradient in enumerate(gradients):
            first_moment[index] = beta1 * first_moment[index] + (1.0 - beta1) * gradient
            second_moment[index] = beta2 * second_moment[index] + (1.0 - beta2) * gradient * gradient
            corrected_first = first_moment[index] / (1.0 - beta1**iteration)
            corrected_second = second_moment[index] / (1.0 - beta2**iteration)
            values[index] -= float(learning_rate) * corrected_first / (
                math.sqrt(corrected_second) + epsilon
            )
        raw_scale, bias = values
        if iteration in requested:
            checkpoints.append(
                {
                    "iteration": iteration,
                    "raw_scale": raw_scale,
                    "scale": positive_scale(raw_scale),
                    "bias": bias,
                    "training_loss": balanced_logistic_loss(
                        similarities, targets, raw_scale, bias
                    ),
                }
            )
    return tuple(checkpoints)


def readout_gate_passed(
    metrics: Mapping[str, Any], contract: Mapping[str, float]
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_readout_ranking_accuracy": float(
            metrics["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_readout_ranking_accuracy"]),
        "minimum_readout_top1_accuracy": float(metrics["ranking"]["top1_accuracy"])
        >= float(contract["minimum_readout_top1_accuracy"]),
        "minimum_each_direction_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in metrics["by_direction"].values()
        )
        >= float(contract["minimum_each_direction_ranking_accuracy"]),
        "minimum_each_family_ranking_accuracy": min(
            float(value["ranking"]["ranking_accuracy"])
            for value in metrics["by_family"].values()
        )
        >= float(contract["minimum_each_family_ranking_accuracy"]),
        "minimum_absolute_balanced_accuracy": float(
            metrics["absolute"]["balanced_accuracy"]
        )
        >= float(contract["minimum_absolute_balanced_accuracy"]),
        "minimum_each_family_absolute_balanced_accuracy": min(
            float(value["absolute"]["balanced_accuracy"])
            for value in metrics["by_family"].values()
        )
        >= float(contract["minimum_each_family_absolute_balanced_accuracy"]),
    }
    return all(checks.values()), checks


__all__ = (
    "M52XF_HELDOUT_DIRECTIONS",
    "M52XF_M52XE_AUDIT_ID",
    "M52XF_SEED",
    "M52XF_STYLE_COUNT",
    "M52XF_TRAINED_DIRECTIONS",
    "M52XF_TRANSFORMS",
    "REPRESENTATION_CONDITIONED_READOUT_VERSION",
    "build_fresh_readout_rows",
    "build_readout_training_groups",
    "balanced_logistic_loss",
    "calibrated_margin",
    "calibrated_readout_records",
    "positive_scale",
    "readout_gate_passed",
    "train_calibrated_readout",
)
