from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.primitive_invention_v21 import AffineBranch
from scientist.domains.cognitive_core.representation_revision_v23 import (
    REPRESENTATION_REVISION_VERSION,
    ObservedSequence,
    RepresentationCoreFreeze,
    RepresentationTask,
    SequenceObservation,
)


REPRESENTATION_AUDIT_AUTHORITY_REF = "sealed-representation-revision-audit-v23"


@dataclass(frozen=True)
class RepresentationAuditCommitment:
    seeds: Tuple[int, ...]
    tasks_per_family: int
    sealed_spec_digest: str

    @property
    def commitment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": REPRESENTATION_REVISION_VERSION,
            "seeds": list(self.seeds),
            "tasks_per_family": self.tasks_per_family,
            "sealed_spec_digest": self.sealed_spec_digest,
            "authority_ref": REPRESENTATION_AUDIT_AUTHORITY_REF,
        }
        if include_id:
            value["commitment_id"] = self.commitment_id
        return value


@dataclass(frozen=True)
class RepresentationAuditMaterialization:
    commitment: RepresentationAuditCommitment
    core_freeze_id: str
    tasks: Tuple[RepresentationTask, ...]
    materialization_stage: int

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": REPRESENTATION_REVISION_VERSION,
            "commitment": self.commitment.as_dict(),
            "core_freeze_id": self.core_freeze_id,
            "candidate_tasks": [item.candidate_view() for item in self.tasks],
            "evaluator_digests": [
                content_digest(
                    {
                        "task_id": item.task_id,
                        "family": item.evaluator_family,
                        "hidden": [value.as_dict() for value in item.hidden_sequences],
                    }
                )
                for item in self.tasks
            ],
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


class RepresentationRevisionAuditAuthority:
    def __init__(
        self,
        seeds: Tuple[int, ...] = (2309, 2333, 2341, 2357, 2371),
        tasks_per_family: int = 4,
    ) -> None:
        if len(seeds) < 5 or tasks_per_family < 3:
            raise ValueError("representation audit requires five seeds and three tasks per family")
        self._seeds = seeds
        self._tasks_per_family = tasks_per_family
        self._sealed_spec = {
            "seeds": seeds,
            "tasks_per_family": tasks_per_family,
            "families": ("one_step_memory", "accumulated_memory"),
            "visible_sequences": 4,
            "hidden_sequences": 2,
            "sequence_length": 48,
            "authority": REPRESENTATION_AUDIT_AUTHORITY_REF,
        }
        self.commitment = RepresentationAuditCommitment(
            seeds, tasks_per_family, content_digest(self._sealed_spec)
        )
        self._materialized = False

    @staticmethod
    def _sequence(
        rng: random.Random,
        sequence_id: str,
        family: str,
        branches: Tuple[AffineBranch, AffineBranch],
        length: int = 48,
    ) -> ObservedSequence:
        inputs = [rng.randint(0, 9) for _ in range(length)]
        observations = []
        running_sum = 0
        for index, current in enumerate(inputs):
            if index == 0:
                state = 0
            elif family == "one_step_memory":
                state = inputs[index - 1] % 2
            else:
                state = running_sum % 2
            observations.append(
                SequenceObservation(current, branches[state].evaluate(current))
            )
            running_sum += current
        return ObservedSequence(sequence_id, tuple(observations))

    @classmethod
    def _task(cls, seed: int, index: int, family: str) -> RepresentationTask:
        rng = random.Random(seed * 1019 + index * 937 + (family == "accumulated_memory"))
        branches = (
            AffineBranch(rng.choice((-3, -2, 2, 3)), rng.randint(-6, 6)),
            AffineBranch(rng.choice((-4, -1, 1, 4)), rng.randint(-6, 6)),
        )
        if branches[0] == branches[1]:
            branches = (branches[0], AffineBranch(branches[1].slope + 1, branches[1].intercept))
        task_id = content_digest(
            {
                "authority": REPRESENTATION_AUDIT_AUTHORITY_REF,
                "seed": seed,
                "index": index,
                "family": family,
            }
        )
        visible = tuple(
            cls._sequence(rng, f"{task_id}-visible-{item}", family, branches)
            for item in range(4)
        )
        hidden = tuple(
            cls._sequence(rng, f"{task_id}-hidden-{item}", family, branches)
            for item in range(2)
        )
        return RepresentationTask(task_id, visible, hidden, family)

    def materialize(
        self, core_freeze: RepresentationCoreFreeze, *, materialization_stage: int = 5
    ) -> RepresentationAuditMaterialization:
        if self._materialized:
            raise ValueError("representation audit may be materialized only once")
        if core_freeze.freeze_stage >= materialization_stage:
            raise ValueError("representation core did not freeze before audit")
        tasks = tuple(
            self._task(seed, index, family)
            for seed in self._seeds
            for family in self._sealed_spec["families"]
            for index in range(self._tasks_per_family)
        )
        self._materialized = True
        return RepresentationAuditMaterialization(
            self.commitment, core_freeze.freeze_id, tasks, materialization_stage
        )

    def verify(
        self,
        materialization: RepresentationAuditMaterialization,
        core_freeze: RepresentationCoreFreeze,
    ) -> bool:
        return (
            materialization.commitment == self.commitment
            and materialization.core_freeze_id == core_freeze.freeze_id
            and self.commitment.sealed_spec_digest == content_digest(self._sealed_spec)
        )


def build_representation_development_tasks() -> Tuple[RepresentationTask, ...]:
    return tuple(
        RepresentationRevisionAuditAuthority._task(2297, index, family)
        for family in ("one_step_memory", "accumulated_memory")
        for index in range(2)
    )
