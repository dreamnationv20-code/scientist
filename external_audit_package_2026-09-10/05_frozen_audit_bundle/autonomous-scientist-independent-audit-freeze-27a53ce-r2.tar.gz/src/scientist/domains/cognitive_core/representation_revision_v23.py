from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.primitive_invention_v21 import AffineBranch


REPRESENTATION_REVISION_VERSION = "cognitive-core-representation-revision-v23"


@dataclass(frozen=True)
class SequenceObservation:
    input_value: int
    output_value: int

    def as_dict(self) -> Dict[str, int]:
        return {"input": self.input_value, "output": self.output_value}


@dataclass(frozen=True)
class ObservedSequence:
    sequence_id: str
    observations: Tuple[SequenceObservation, ...]

    def as_dict(self) -> Dict[str, object]:
        return {
            "sequence_id": self.sequence_id,
            "observations": [item.as_dict() for item in self.observations],
        }


@dataclass(frozen=True)
class RepresentationTask:
    task_id: str
    visible_sequences: Tuple[ObservedSequence, ...]
    hidden_sequences: Tuple[ObservedSequence, ...]
    evaluator_family: str

    def candidate_view(self) -> Dict[str, object]:
        return {
            "task_id": self.task_id,
            "sequences": [item.as_dict() for item in self.visible_sequences],
        }


@dataclass(frozen=True)
class RepresentationFailureDossier:
    task_id: str
    repeated_input_groups: int
    contradictory_input_groups: int
    contradiction_rate: float
    stateless_training_ceiling: float
    revision_required: bool

    @property
    def dossier_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": REPRESENTATION_REVISION_VERSION,
            "task_id": self.task_id,
            "repeated_input_groups": self.repeated_input_groups,
            "contradictory_input_groups": self.contradictory_input_groups,
            "contradiction_rate": self.contradiction_rate,
            "stateless_training_ceiling": self.stateless_training_ceiling,
            "revision_required": self.revision_required,
        }
        if include_id:
            value["dossier_id"] = self.dossier_id
        return value


def diagnose_representation(task: RepresentationTask) -> RepresentationFailureDossier:
    groups: Dict[int, list[int]] = {}
    for sequence in task.visible_sequences:
        for item in sequence.observations[1:]:
            groups.setdefault(item.input_value, []).append(item.output_value)
    repeated = {key: values for key, values in groups.items() if len(values) > 1}
    contradictory = {
        key: values for key, values in repeated.items() if len(set(values)) > 1
    }
    total = sum(len(values) for values in groups.values())
    ceiling = (
        sum(max(values.count(value) for value in set(values)) for values in groups.values())
        / total
    )
    rate = len(contradictory) / len(repeated) if repeated else 0.0
    return RepresentationFailureDossier(
        task.task_id,
        len(repeated),
        len(contradictory),
        rate,
        ceiling,
        bool(contradictory) and ceiling < 0.95,
    )


@dataclass(frozen=True)
class StateFeatureProgram:
    source_operator: str
    source_argument: int
    post_operator: str
    post_argument: int

    def evaluate(self, prefix: Sequence[int], step_index: int) -> int | None:
        if self.source_operator == "take_lag":
            lag = self.source_argument
            if len(prefix) < lag:
                return None
            raw = prefix[-lag]
        elif self.source_operator == "fold_sum":
            raw = sum(prefix)
        elif self.source_operator == "position":
            raw = step_index
        else:
            raise ValueError("unknown history-source operator")
        if self.post_operator != "modulo":
            raise ValueError("unknown history post-operator")
        return raw % self.post_argument

    @property
    def complexity(self) -> int:
        source_cost = 1 if self.source_operator in ("take_lag", "position") else 2
        return source_cost + 1 + self.post_argument

    def as_dict(self) -> Dict[str, object]:
        return {
            "source_operator": self.source_operator,
            "source_argument": self.source_argument,
            "post_operator": self.post_operator,
            "post_argument": self.post_argument,
            "complexity": self.complexity,
        }


@dataclass(frozen=True)
class RevisedRepresentation:
    base_fields: Tuple[str, ...]
    invented_state: StateFeatureProgram
    branch_models: Mapping[int, AffineBranch]
    origin: str = "contradiction_driven_history_composition"

    def predict(self, prefix: Sequence[int], input_value: int, step_index: int) -> int | None:
        state = self.invented_state.evaluate(prefix, step_index)
        branch = self.branch_models.get(state) if state is not None else None
        return None if branch is None else branch.evaluate(input_value)

    @property
    def representation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def complexity(self) -> int:
        return self.invented_state.complexity + 2 * len(self.branch_models)

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": REPRESENTATION_REVISION_VERSION,
            "base_fields": list(self.base_fields),
            "invented_state": self.invented_state.as_dict(),
            "branch_models": {
                str(key): item.as_dict()
                for key, item in sorted(self.branch_models.items())
            },
            "origin": self.origin,
            "complexity": self.complexity,
        }
        if include_id:
            value["representation_id"] = self.representation_id
        return value


def enumerate_state_features() -> Tuple[StateFeatureProgram, ...]:
    programs = []
    for modulus in range(2, 5):
        programs.extend(
            StateFeatureProgram("take_lag", lag, "modulo", modulus)
            for lag in range(1, 4)
        )
        programs.append(StateFeatureProgram("fold_sum", 0, "modulo", modulus))
        programs.append(StateFeatureProgram("position", 0, "modulo", modulus))
    return tuple(sorted(programs, key=lambda item: (item.complexity, str(item.as_dict()))))


def _fit_branch(points: Sequence[Tuple[int, int]]) -> AffineBranch | None:
    unique = sorted(set(points))
    if len({x for x, _ in unique}) < 2:
        return None
    left = unique[0]
    right = next(item for item in unique[1:] if item[0] != left[0])
    numerator = right[1] - left[1]
    denominator = right[0] - left[0]
    if numerator % denominator:
        return None
    branch = AffineBranch(numerator // denominator, left[1] - (numerator // denominator) * left[0])
    return branch if all(branch.evaluate(x) == y for x, y in unique) else None


def _fit_revision(
    sequences: Sequence[ObservedSequence], feature: StateFeatureProgram
) -> RevisedRepresentation | None:
    groups: Dict[int, list[Tuple[int, int]]] = {}
    for sequence in sequences:
        prefix = []
        for index, observation in enumerate(sequence.observations):
            state = feature.evaluate(prefix, index)
            if state is not None:
                groups.setdefault(state, []).append(
                    (observation.input_value, observation.output_value)
                )
            prefix.append(observation.input_value)
    if len(groups) < 2:
        return None
    models = {state: _fit_branch(points) for state, points in groups.items()}
    if any(model is None for model in models.values()):
        return None
    return RevisedRepresentation(
        ("current_input",),
        feature,
        {state: model for state, model in models.items() if model is not None},
    )


def _prediction_signature(
    model: RevisedRepresentation, sequences: Sequence[ObservedSequence]
) -> Tuple[int | None, ...]:
    values = []
    for sequence in sequences:
        prefix = []
        for index, observation in enumerate(sequence.observations):
            values.append(model.predict(prefix, observation.input_value, index))
            prefix.append(observation.input_value)
    return tuple(values)


@dataclass(frozen=True)
class RepresentationRevisionTrace:
    task_id: str
    dossier: RepresentationFailureDossier
    candidate_features: int
    fitting_representations: int
    minimum_complexity_finalists: int
    selected: RevisedRepresentation | None

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": REPRESENTATION_REVISION_VERSION,
            "task_id": self.task_id,
            "dossier": self.dossier.as_dict(),
            "candidate_features": self.candidate_features,
            "fitting_representations": self.fitting_representations,
            "minimum_complexity_finalists": self.minimum_complexity_finalists,
            "selected": None if self.selected is None else self.selected.as_dict(),
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


def revise_representation(task: RepresentationTask) -> RepresentationRevisionTrace:
    dossier = diagnose_representation(task)
    features = enumerate_state_features()
    fitting = tuple(
        model
        for feature in features
        for model in (_fit_revision(task.visible_sequences, feature),)
        if model is not None
    )
    by_signature: Dict[Tuple[int | None, ...], RevisedRepresentation] = {}
    for model in fitting:
        signature = _prediction_signature(model, task.visible_sequences)
        incumbent = by_signature.get(signature)
        if incumbent is None or (model.complexity, model.representation_id) < (
            incumbent.complexity,
            incumbent.representation_id,
        ):
            by_signature[signature] = model
    selected = None
    finalists = []
    if dossier.revision_required and by_signature:
        minimum = min(item.complexity for item in by_signature.values())
        finalists = [item for item in by_signature.values() if item.complexity == minimum]
        if len(finalists) == 1:
            selected = finalists[0]
    return RepresentationRevisionTrace(
        task.task_id,
        dossier,
        len(features),
        len(by_signature),
        len(finalists),
        selected,
    )


@dataclass(frozen=True)
class RepresentationCoreFreeze:
    source_experiment_freeze_id: str
    temporal_meta_grammar: Mapping[str, object]
    revision_source_digest: str
    development_trace_ids: Tuple[str, ...]
    freeze_stage: int = 4

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": REPRESENTATION_REVISION_VERSION,
            "source_experiment_freeze_id": self.source_experiment_freeze_id,
            "temporal_meta_grammar": dict(self.temporal_meta_grammar),
            "revision_source_digest": self.revision_source_digest,
            "development_trace_ids": list(self.development_trace_ids),
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_representation_core(
    traces: Mapping[str, RepresentationRevisionTrace],
    *,
    source_experiment_freeze_id: str,
    revision_source_digest: str,
) -> RepresentationCoreFreeze:
    if not traces or any(item.selected is None for item in traces.values()):
        raise ValueError("representation core development did not revise every task")
    return RepresentationCoreFreeze(
        source_experiment_freeze_id,
        {
            "history_sources": ["take_lag", "fold_sum", "position"],
            "history_post_operators": ["modulo"],
            "maximum_lag": 3,
            "maximum_modulus": 4,
            "adoption_trigger": "observable_input_output_collision",
        },
        revision_source_digest,
        tuple(sorted(item.trace_id for item in traces.values())),
    )


def score_representation(
    model: RevisedRepresentation | None, sequences: Sequence[ObservedSequence]
) -> float:
    passed = 0
    total = 0
    for sequence in sequences:
        prefix = []
        for index, observation in enumerate(sequence.observations):
            if index > 0:
                total += 1
                passed += bool(
                    model is not None
                    and model.predict(prefix, observation.input_value, index)
                    == observation.output_value
                )
            prefix.append(observation.input_value)
    return passed / total


def stateless_score(
    visible: Sequence[ObservedSequence], hidden: Sequence[ObservedSequence]
) -> float:
    groups: Dict[int, list[int]] = {}
    for sequence in visible:
        for item in sequence.observations[1:]:
            groups.setdefault(item.input_value, []).append(item.output_value)
    modes = {
        key: min(
            (value for value in set(values)),
            key=lambda value: (-values.count(value), value),
        )
        for key, values in groups.items()
    }
    passed = total = 0
    for sequence in hidden:
        for item in sequence.observations[1:]:
            total += 1
            passed += modes.get(item.input_value) == item.output_value
    return passed / total


@dataclass(frozen=True)
class RepresentationRevisionTrial:
    traces: Mapping[str, RepresentationRevisionTrace]
    revised_scores: Mapping[str, float]
    stateless_scores: Mapping[str, float]
    family_scores: Mapping[str, float]
    causal_history_sensitivity: float
    checks: Mapping[str, bool]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "version": REPRESENTATION_REVISION_VERSION,
            "traces": {key: item.as_dict() for key, item in sorted(self.traces.items())},
            "revised_scores": dict(sorted(self.revised_scores.items())),
            "stateless_scores": dict(sorted(self.stateless_scores.items())),
            "family_scores": dict(sorted(self.family_scores.items())),
            "causal_history_sensitivity": self.causal_history_sensitivity,
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def _history_sensitivity(model: RevisedRepresentation) -> float:
    changed = total = 0
    for current in range(2, 8):
        for left, right in (([2], [3]), ([1, 1], [1, 2])):
            left_value = model.predict(left, current, len(left))
            right_value = model.predict(right, current, len(right))
            total += 1
            changed += left_value is not None and right_value is not None and left_value != right_value
    return changed / total


def run_representation_trial(tasks: Sequence[RepresentationTask]) -> RepresentationRevisionTrial:
    traces = {task.task_id: revise_representation(task) for task in tasks}
    revised = {
        task.task_id: score_representation(
            traces[task.task_id].selected, task.hidden_sequences
        )
        for task in tasks
    }
    stateless = {
        task.task_id: stateless_score(task.visible_sequences, task.hidden_sequences)
        for task in tasks
    }
    families = sorted({task.evaluator_family for task in tasks})
    family_scores = {
        family: sum(revised[task.task_id] for task in tasks if task.evaluator_family == family)
        / sum(task.evaluator_family == family for task in tasks)
        for family in families
    }
    sensitivity = sum(
        _history_sensitivity(trace.selected)
        for trace in traces.values()
        if trace.selected is not None
    ) / len(traces)
    revised_mean = sum(revised.values()) / len(revised)
    stateless_mean = sum(stateless.values()) / len(stateless)
    checks = {
        "every_task_diagnoses_irreducible_stateless_collisions": all(
            trace.dossier.revision_required for trace in traces.values()
        ),
        "every_task_constructs_one_minimal_revised_representation": all(
            trace.selected is not None and trace.minimum_complexity_finalists == 1
            for trace in traces.values()
        ),
        "two_unseen_temporal_families_transfer": min(family_scores.values()) >= 0.95,
        "representation_revision_beats_stateless_model": (
            revised_mean >= 0.95 and revised_mean - stateless_mean >= 0.25
        ),
        "invented_state_has_counterfactual_effect": sensitivity >= 0.45,
    }
    return RepresentationRevisionTrial(
        traces, revised, stateless, family_scores, sensitivity, checks
    )


def visible_interface_contains_target_state(tasks: Iterable[RepresentationTask]) -> bool:
    text = str([task.candidate_view() for task in tasks]).lower()
    return any(token in text for token in ("evaluator_family", "hidden_sequences", "target_state"))
