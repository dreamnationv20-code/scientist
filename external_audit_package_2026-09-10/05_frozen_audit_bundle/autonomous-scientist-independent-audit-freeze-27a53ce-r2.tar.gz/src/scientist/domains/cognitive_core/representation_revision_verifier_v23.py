from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.representation_revision_audit_v23 import (
    RepresentationAuditMaterialization,
)
from scientist.domains.cognitive_core.representation_revision_v23 import (
    RepresentationCoreFreeze,
    RepresentationRevisionTrace,
    RepresentationRevisionTrial,
    diagnose_representation,
    revise_representation,
    visible_interface_contains_target_state,
)


REPRESENTATION_VERIFIER_REF = "representation-revision-independent-verifier-v23"


@dataclass(frozen=True)
class RepresentationRevisionVerification:
    checks: Mapping[str, bool]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.checks.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, object]:
        value: Dict[str, object] = {
            "verifier_ref": REPRESENTATION_VERIFIER_REF,
            "checks": dict(sorted(self.checks.items())),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_representation_revision(
    *,
    development_traces: Mapping[str, RepresentationRevisionTrace],
    core_freeze: RepresentationCoreFreeze,
    source_experiment_freeze_id: str,
    materialization: RepresentationAuditMaterialization,
    trial: RepresentationRevisionTrial,
    artifact_round_trips: Mapping[str, bool],
) -> RepresentationRevisionVerification:
    candidate_text = json.dumps(
        [task.candidate_view() for task in materialization.tasks], sort_keys=True
    ).lower()
    source = "\n".join(
        (inspect.getsource(diagnose_representation), inspect.getsource(revise_representation))
    ).lower()
    selected_sources = {
        trace.selected.invented_state.source_operator
        for trace in trial.traces.values()
        if trace.selected is not None
    }
    checks = {
        "development_diagnoses_then_revises": bool(development_traces)
        and all(
            item.dossier.revision_required and item.selected is not None
            for item in development_traces.values()
        ),
        "candidate_view_hides_target_state_and_hidden_suffix": (
            not visible_interface_contains_target_state(materialization.tasks)
            and all(
                token not in candidate_text
                for token in ("evaluator_family", "hidden_sequences", "target_state")
            )
        ),
        "candidate_has_no_family_named_dispatch": all(
            token not in source for token in ("one_step_memory", "accumulated_memory")
        ),
        "core_extends_exact_prior_freeze": (
            core_freeze.source_experiment_freeze_id == source_experiment_freeze_id
        ),
        "audit_materializes_after_representation_freeze": (
            materialization.core_freeze_id == core_freeze.freeze_id
            and core_freeze.freeze_stage < materialization.materialization_stage
        ),
        "different_temporal_compositions_are_actually_selected": (
            {"take_lag", "fold_sum"}.issubset(selected_sources)
        ),
        "prospective_transfer_and_counterfactual_test_pass": trial.passed,
        "artifacts_round_trip_exactly": bool(artifact_round_trips)
        and all(artifact_round_trips.values()),
    }
    return RepresentationRevisionVerification(
        checks,
        (
            "The candidate detected contradictions impossible under its stateless input "
            "representation, composed a new executable history variable, and transferred "
            "the revised representation across two fresh temporal families."
        ),
        (
            "the temporal meta-grammar was itself invented",
            "unbounded open-world ontology revision is established",
            "the general cognitive core is solved",
        ),
        (
            "Revision searches a bounded engineered temporal-composition grammar.",
            "The audit uses procedurally generated integer sequences.",
        ),
    )
