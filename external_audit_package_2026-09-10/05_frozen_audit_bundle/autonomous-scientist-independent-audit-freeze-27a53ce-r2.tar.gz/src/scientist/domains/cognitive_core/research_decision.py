from __future__ import annotations

from scientist.program.research_kernel import (
    ProgramDisposition,
    ResearchActionKind,
    ResearchDispatchResult,
    ResearchProgramDecision,
)
from scientist.autonomy.state import ActorKind, AuthorityScope
from scientist.autonomy.tracing import ComponentExecutionTrace


class EvidenceBoundProgramDecisionComponent:
    """Conservative program authority derived only from registered evidence.

    This component deliberately cannot invent a replacement hypothesis. A
    failed concept terminates its V3 branch; any materially new hypothesis must
    be opened as a new, preregistered mission by the goal-graph controller.
    """

    name = "cognitive-evidence-bound-program-authority"
    component_version = "v1"
    dispatch_actor_kind = ActorKind.SCIENTIST_POLICY.value
    dispatch_authority_scope = AuthorityScope.GOVERN.value

    def dispatch(self, action, kernel, domain) -> ResearchDispatchResult:
        del domain
        trace = ComponentExecutionTrace.deterministic(
            action.action_id,
            "%s@%s" % (self.name, self.component_version),
        ).as_dict()
        if action.kind == ResearchActionKind.REPORT_TERMINAL:
            if kernel.terminal_disposition is None:
                raise ValueError("terminal reporting requires a terminal decision")
            return ResearchDispatchResult(
                progressed=False,
                stop=True,
                outcome="terminal_%s" % kernel.terminal_disposition.value,
                details={
                    "terminal_disposition": kernel.terminal_disposition.value,
                    "decision_id": kernel.decisions[-1].decision_id,
                    "decision_ref": kernel.decisions[-1].decision_ref,
                    "_authority_trace": trace,
                },
            )
        if action.kind != ResearchActionKind.MAKE_PROGRAM_DECISION:
            raise ValueError("program authority cannot perform another research phase")

        decision = self._decision(kernel)
        kernel.record_program_decision(decision)
        return ResearchDispatchResult(
            progressed=True,
            stop=False,
            outcome="program_%s" % decision.disposition.value,
            details={
                "decision_id": decision.decision_id,
                "disposition": decision.disposition.value,
                "evidence_ids": list(decision.evidence_ids),
                "adaptive_model_used": False,
                "_authority_trace": trace,
            },
        )

    @staticmethod
    def _decision(kernel) -> ResearchProgramDecision:
        mission = kernel.mission
        if mission is None:
            raise ValueError("program decision requires a frozen mission")
        concept = kernel.concept
        central_hypothesis = (
            "initial causal research program"
            if concept is None
            else concept.causal_explanation
        )
        disposition: ProgramDisposition
        evidence_id: str
        reasons: tuple[str, ...]
        localized_failure = None
        repair_target = None

        if kernel.concept_validation is not None and not kernel.concept_validation.passed:
            disposition = ProgramDisposition.KILL
            evidence_id = kernel.concept_validation.validation_id
            reasons = (
                "The preregistered prospective concept-validation gate failed.",
                "A materially different representation requires a new mission rather than an in-branch relabeling.",
            )
        elif kernel.mechanism is not None and not kernel.mechanism.passed:
            evidence_id = kernel.mechanism.certificate_id
            if kernel.repair_count < kernel.policy.maximum_repairs_per_concept:
                disposition = ProgramDisposition.REPAIR
                localized_failure = "behavioral mechanism or incumbent fallback"
                repair_target = "compiler and behavioral-parity boundary"
                reasons = (
                    "The concept passed prospectively but its executable mechanism audit failed.",
                    "One localized compiler repair remains within the frozen repair budget.",
                )
            else:
                disposition = ProgramDisposition.KILL
                reasons = (
                    "The behavioral mechanism audit failed.",
                    "The frozen localized-repair budget is exhausted.",
                )
        elif kernel.evaluation is not None:
            evidence_id = kernel.evaluation.evaluation_id
            if kernel.evaluation.claim_eligible:
                disposition = ProgramDisposition.PROMOTE
                reasons = (
                    "The oracle-free multi-horizon terminal gate passed.",
                    "The registered independent replication evidence supports promotion.",
                )
            else:
                disposition = ProgramDisposition.KILL
                reasons = (
                    "The frozen multi-horizon terminal claim gate failed.",
                    "A failed terminal test cannot be repaired by reinterpretation.",
                )
        else:
            raise ValueError("no registered evidence licenses a program decision")

        return ResearchProgramDecision(
            mission_id=mission.mission_id,
            disposition=disposition,
            central_hypothesis=central_hypothesis,
            reasons=reasons,
            evidence_ids=(evidence_id,),
            localized_failure=localized_failure,
            repair_target=repair_target,
            replacement_hypothesis=None,
            changed_representation_dimensions=(),
            decision_ref="deterministic-evidence-bound-program-strategist-v1",
        )
