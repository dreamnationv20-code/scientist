from __future__ import annotations

from typing import Any, Mapping, Sequence, Tuple


RESIDUAL_COMPLEMENT_EXPERT_VERSION = (
    "general-cognitive-residual-complement-expert-v52o"
)
M52O_SEED = 52961
M52O_M52N_AUDIT_ID = (
    "8cc398386fa0577bf2412e6b5e9cd33cdc75e3798070b934b7beb54b34c2f344"
)


def residual_prompt_weights(
    contrast_ids: Sequence[str],
    independent_pair_correctness: Mapping[str, bool],
    *,
    failure_weight: float,
    success_weight: float,
) -> Tuple[float, ...]:
    missing = [
        str(contrast_id)
        for contrast_id in contrast_ids
        if str(contrast_id) not in independent_pair_correctness
    ]
    if missing:
        raise ValueError("M52o residual weights require independent pair evidence")
    return tuple(
        float(success_weight)
        if independent_pair_correctness[str(contrast_id)]
        else float(failure_weight)
        for contrast_id in contrast_ids
    )


def residual_support_authorized(
    dossier: Mapping[str, Any], contract: Mapping[str, Any]
) -> Tuple[bool, Mapping[str, bool]]:
    statuses = dossier["status_counts"]
    oracle_delta = float(dossier["oracle_metrics"]["balanced_accuracy"]) - float(
        dossier["independent_metrics"]["balanced_accuracy"]
    )
    checks = {
        "minimum_oracle_balanced_accuracy_delta": oracle_delta
        >= float(contract["minimum_oracle_balanced_accuracy_delta"]),
        "minimum_oracle_swap_pair_accuracy": float(
            dossier["oracle_metrics"]["swap_pair_accuracy"]
        )
        >= float(contract["minimum_oracle_swap_pair_accuracy"]),
        "minimum_recoverable_contrasts": int(statuses["joint_only_recoverable"])
        >= int(contract["minimum_recoverable_contrasts"]),
        "maximum_unavoidable_contrasts": int(statuses["neither_correct"])
        <= int(contract["maximum_unavoidable_contrasts"]),
        "minimum_recoverable_families": len(dossier["recoverable_families"])
        >= int(contract["minimum_recoverable_families"]),
        "minimum_recoverable_variants": len(dossier["recoverable_variants"])
        >= int(contract["minimum_recoverable_variants"]),
    }
    return all(checks.values()), checks
