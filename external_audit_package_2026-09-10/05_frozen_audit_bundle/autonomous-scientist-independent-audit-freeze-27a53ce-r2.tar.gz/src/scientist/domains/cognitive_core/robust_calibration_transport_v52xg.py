from __future__ import annotations

from bisect import bisect_right
from itertools import product
from statistics import mean
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.cross_channel_binding_v52x import (
    descriptor_direction,
)
from scientist.domains.cognitive_core.independent_paraphrase_orbits_v52v import (
    semantic_relation_prompt,
)
from scientist.domains.cognitive_core.representation_atlas_v52w import (
    relation_margin_records,
)
from scientist.domains.cognitive_core.representation_conditioned_readout_v52xf import (
    M52XF_HELDOUT_DIRECTIONS,
    M52XF_TRAINED_DIRECTIONS,
    readout_gate_passed,
)


ROBUST_CALIBRATION_TRANSPORT_VERSION = (
    "general-cognitive-robust-calibration-transport-v52xg"
)
M52XG_SEED = 53201
M52XG_M52XF_AUDIT_ID = (
    "083e0c05f90cb380c9dcf5907f2bf57a26679548488621794d50fcc3cf3b4482"
)
M52XG_TRAINED_DIRECTIONS = M52XF_TRAINED_DIRECTIONS
M52XG_HELDOUT_DIRECTIONS = M52XF_HELDOUT_DIRECTIONS
M52XG_STYLE_COUNT = 3

M52XG_TRANSFORMS = {
    "selection": {
        "name": ("registry_designation", "technique_reference_clue", "method_alias_token"),
        "principle": (
            "governing_test_statement",
            "criterion_reference_clue",
            "invariant_rule_token",
        ),
        "action": (
            "enacted_operation_statement",
            "runtime_reference_clue",
            "execution_trace_token",
        ),
    },
    "confirmation": {
        "name": ("audit_designation", "technique_signature_probe", "method_identity_token"),
        "principle": (
            "audit_governing_test",
            "criterion_signature_probe",
            "invariant_identity_token",
        ),
        "action": (
            "audit_enacted_operation",
            "runtime_signature_probe",
            "execution_identity_token",
        ),
    },
}


def _fresh_text(
    state: Mapping[str, str], channel: str, role: str, formulation: str, style: int
) -> str:
    value = str(state[channel])
    templates = {
        ("selection", 0, "name", "basis"): "Retrieve the design associated with registry designation {value}.",
        ("selection", 0, "name", "candidate"): "This design is filed under registry designation {value}.",
        ("selection", 0, "principle", "basis"): "Retrieve the design satisfying this governing test: {value}.",
        ("selection", 0, "principle", "candidate"): "This design satisfies the following governing test: {value}.",
        ("selection", 0, "action", "basis"): "Retrieve the design whose enacted operation is to {value}.",
        ("selection", 0, "action", "candidate"): "This design has the enacted operation to {value}.",
        ("selection", 1, "name", "basis"): "Identify the implementation from this technique-reference clue: {value}.",
        ("selection", 1, "name", "candidate"): "The implementation matches technique-reference clue {value}.",
        ("selection", 1, "principle", "basis"): "Identify the implementation from this criterion-reference clue: {value}.",
        ("selection", 1, "principle", "candidate"): "The implementation matches this criterion-reference clue: {value}.",
        ("selection", 1, "action", "basis"): "Identify the implementation from this runtime-reference clue: {value}.",
        ("selection", 1, "action", "candidate"): "The implementation matches this runtime-reference clue: {value}.",
        ("selection", 2, "name", "basis"): "Choose a counterpart using the method-alias token {value}.",
        ("selection", 2, "name", "candidate"): "The counterpart exposes method-alias token {value}.",
        ("selection", 2, "principle", "basis"): "Choose a counterpart using this invariant-rule token: {value}.",
        ("selection", 2, "principle", "candidate"): "The counterpart exposes this invariant-rule token: {value}.",
        ("selection", 2, "action", "basis"): "Choose a counterpart using this execution-trace token: {value}.",
        ("selection", 2, "action", "candidate"): "The counterpart exposes this execution-trace token: {value}.",
        ("confirmation", 0, "name", "basis"): "Audit correspondence to the following designation: {value}.",
        ("confirmation", 0, "name", "candidate"): "The audited candidate carries designation {value}.",
        ("confirmation", 0, "principle", "basis"): "Audit correspondence to this governing test: {value}.",
        ("confirmation", 0, "principle", "candidate"): "The audited candidate meets this governing test: {value}.",
        ("confirmation", 0, "action", "basis"): "Audit correspondence to the enacted operation to {value}.",
        ("confirmation", 0, "action", "candidate"): "The audited candidate has the enacted operation to {value}.",
        ("confirmation", 1, "name", "basis"): "Probe equivalence with technique signature {value}.",
        ("confirmation", 1, "name", "candidate"): "The probed candidate reports technique signature {value}.",
        ("confirmation", 1, "principle", "basis"): "Probe equivalence with this criterion signature: {value}.",
        ("confirmation", 1, "principle", "candidate"): "The probed candidate reports this criterion signature: {value}.",
        ("confirmation", 1, "action", "basis"): "Probe equivalence with this runtime signature: {value}.",
        ("confirmation", 1, "action", "candidate"): "The probed candidate reports this runtime signature: {value}.",
        ("confirmation", 2, "name", "basis"): "Verify the pair through method-identity token {value}.",
        ("confirmation", 2, "name", "candidate"): "The verified candidate presents method-identity token {value}.",
        ("confirmation", 2, "principle", "basis"): "Verify the pair through this invariant-identity token: {value}.",
        ("confirmation", 2, "principle", "candidate"): "The verified candidate presents this invariant-identity token: {value}.",
        ("confirmation", 2, "action", "basis"): "Verify the pair through this execution-identity token: {value}.",
        ("confirmation", 2, "action", "candidate"): "The verified candidate presents this execution-identity token: {value}.",
    }
    try:
        return templates[(formulation, style, channel, role)].format(value=value)
    except KeyError as error:
        raise ValueError(
            "unknown M52xg formulation/style/channel/role: "
            f"{formulation}/{style}/{channel}/{role}"
        ) from error


def build_fresh_calibration_rows(
    ledger: Mapping[str, Any], formulation: str
) -> Tuple[Mapping[str, Any], ...]:
    if formulation not in M52XG_TRANSFORMS:
        raise ValueError("M52xg formulation must be selection or confirmation")
    transforms = M52XG_TRANSFORMS[formulation]
    rows = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != "discovery":
            continue
        states = tuple(family_value["states"])
        if len(states) != 4:
            raise ValueError("M52xg requires four states per discovery family")
        for direction in M52XG_TRAINED_DIRECTIONS:
            basis_channel, candidate_channel = direction.split("->")
            for basis_style, candidate_style in product(
                range(M52XG_STYLE_COUNT), repeat=2
            ):
                for basis_state in states:
                    orbit = content_digest(
                        {
                            "milestone": "M52xg",
                            "formulation": formulation,
                            "family": family,
                            "direction": direction,
                            "basis_style": basis_style,
                            "candidate_style": candidate_style,
                            "basis_state": basis_state["key"],
                        }
                    )
                    basis_text = _fresh_text(
                        basis_state, basis_channel, "basis", formulation, basis_style
                    )
                    for candidate_state in states:
                        candidate_text = _fresh_text(
                            candidate_state,
                            candidate_channel,
                            "candidate",
                            formulation,
                            candidate_style,
                        )
                        metadata = {
                            "record_id": content_digest(
                                {
                                    "orbit": orbit,
                                    "candidate_state": candidate_state["key"],
                                }
                            ),
                            "orbit_id": orbit,
                            "family": str(family),
                            "semantic_split": "discovery",
                            "formulation_split": formulation,
                            "basis_style": int(basis_style),
                            "candidate_style": int(candidate_style),
                            "basis_state_key": str(basis_state["key"]),
                            "candidate_state_key": str(candidate_state["key"]),
                            "basis_transformation": transforms[basis_channel][basis_style],
                            "basis_transformation_split": "m52xg_fresh_calibration",
                            "candidate_transformation": transforms[candidate_channel][candidate_style],
                            "candidate_transformation_split": "m52xg_fresh_calibration",
                            "basis_text": basis_text,
                            "candidate_text": candidate_text,
                            "relation_target": (
                                "YES"
                                if str(basis_state["key"])
                                == str(candidate_state["key"])
                                else "NO"
                            ),
                        }
                        row = {
                            "prompt": semantic_relation_prompt(basis_text, candidate_text),
                            "metadata": metadata,
                        }
                        if descriptor_direction(row) != direction:
                            raise ValueError("M52xg transformation routing is inconsistent")
                        rows.append(row)
    return tuple(rows)


def _class_values(
    records: Sequence[Mapping[str, Any]],
) -> tuple[list[float], list[float]]:
    positives = sorted(
        float(row["margin"]) for row in records if str(row["target"]) == "YES"
    )
    negatives = sorted(
        float(row["margin"]) for row in records if str(row["target"]) == "NO"
    )
    if not positives or not negatives:
        raise ValueError("M52xg calibration distributions require both classes")
    return positives, negatives


def _threshold_metrics_from_sorted(
    positives: Sequence[float], negatives: Sequence[float], threshold: float
) -> Mapping[str, float | int]:
    false_negative = bisect_right(positives, float(threshold))
    true_positive = len(positives) - false_negative
    true_negative = bisect_right(negatives, float(threshold))
    false_positive = len(negatives) - true_negative
    sensitivity = true_positive / len(positives)
    specificity = true_negative / len(negatives)
    return {
        "threshold": float(threshold),
        "count": len(positives) + len(negatives),
        "balanced_accuracy": 0.5 * (sensitivity + specificity),
        "accuracy": (true_positive + true_negative)
        / (len(positives) + len(negatives)),
        "sensitivity": sensitivity,
        "specificity": specificity,
        "true_positive": true_positive,
        "true_negative": true_negative,
        "false_positive": false_positive,
        "false_negative": false_negative,
    }


def threshold_metrics(
    records: Sequence[Mapping[str, Any]], threshold: float
) -> Mapping[str, float | int]:
    positives, negatives = _class_values(records)
    return _threshold_metrics_from_sorted(positives, negatives, threshold)


def fit_minimax_threshold(
    distributions: Mapping[str, Sequence[Mapping[str, Any]]]
) -> Mapping[str, Any]:
    if len(distributions) < 2:
        raise ValueError("M52xg minimax calibration requires multiple distributions")
    values = sorted(
        {
            float(row["margin"])
            for records in distributions.values()
            for row in records
        }
    )
    candidates = [values[0] - 1e-9]
    candidates.extend(
        (left + right) / 2.0 for left, right in zip(values, values[1:])
    )
    candidates.append(values[-1] + 1e-9)
    class_values = {
        key: _class_values(records) for key, records in distributions.items()
    }
    best = None
    for threshold in candidates:
        metrics = {
            key: _threshold_metrics_from_sorted(positives, negatives, threshold)
            for key, (positives, negatives) in class_values.items()
        }
        balanced = [float(row["balanced_accuracy"]) for row in metrics.values()]
        score = (min(balanced), mean(balanced), -abs(threshold - 0.5))
        if best is None or score > best[0]:
            best = (score, threshold, metrics)
    assert best is not None
    return {
        "threshold": float(best[1]),
        "minimum_distribution_balanced_accuracy": float(best[0][0]),
        "mean_distribution_balanced_accuracy": float(best[0][1]),
        "by_distribution": best[2],
    }


def leave_one_distribution_out(
    distributions: Mapping[str, Sequence[Mapping[str, Any]]]
) -> Mapping[str, Any]:
    results = {}
    for held_name, held_records in distributions.items():
        fitted = fit_minimax_threshold(
            {
                key: records
                for key, records in distributions.items()
                if key != held_name
            }
        )
        results[held_name] = {
            "training_threshold": fitted["threshold"],
            "training_minimum_balanced_accuracy": fitted[
                "minimum_distribution_balanced_accuracy"
            ],
            "heldout_metrics": threshold_metrics(
                held_records, float(fitted["threshold"])
            ),
        }
    return results


def threshold_readout_records(
    rows: Sequence[Mapping[str, Any]],
    similarities: Sequence[float],
    threshold: float,
    scale: float = 1.0,
) -> Tuple[Mapping[str, Any], ...]:
    if float(scale) <= 0.0:
        raise ValueError("M52xg readout scale must be positive")
    margins = [
        float(scale) * (float(value) - float(threshold))
        for value in similarities
    ]
    return relation_margin_records(rows, margins)


__all__ = (
    "M52XG_HELDOUT_DIRECTIONS",
    "M52XG_M52XF_AUDIT_ID",
    "M52XG_SEED",
    "M52XG_STYLE_COUNT",
    "M52XG_TRAINED_DIRECTIONS",
    "M52XG_TRANSFORMS",
    "ROBUST_CALIBRATION_TRANSPORT_VERSION",
    "build_fresh_calibration_rows",
    "fit_minimax_threshold",
    "leave_one_distribution_out",
    "readout_gate_passed",
    "threshold_metrics",
    "threshold_readout_records",
)
