from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.behavioral_predicate_audit_authority_v19 import (
    BehavioralPredicateAuditAuthority,
    build_table_registry,
)
from scientist.domains.cognitive_core.latent_object_audit_authority_v17 import (
    LatentObjectAuditAuthority,
)
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    build_latent_registry,
)
from scientist.domains.cognitive_core.self_supervised_object_discovery_v18 import (
    EVIDENCE_MODES,
    SelfSupervisedRegistry,
    degrade_identity_evidence,
)
from scientist.domains.cognitive_core.self_supervised_schema_induction_v20 import (
    SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION,
    SchemaCoreFreeze,
)


SCHEMA_AUDIT_AUTHORITY_REF = "sealed-schema-induction-audit-authority-v20"


@dataclass(frozen=True)
class SchemaAuditCommitment:
    sealed_spec_digest: str
    seeds: Tuple[int, ...]
    tasks_per_family: int
    families: Tuple[str, ...]
    evidence_modes: Tuple[str, ...]
    rule: str

    @property
    def commitment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION,
            "sealed_spec_digest": self.sealed_spec_digest,
            "seeds": list(self.seeds),
            "tasks_per_family": self.tasks_per_family,
            "families": list(self.families),
            "evidence_modes": list(self.evidence_modes),
            "rule": self.rule,
            "authority_ref": SCHEMA_AUDIT_AUTHORITY_REF,
        }
        if include_id:
            value["commitment_id"] = self.commitment_id
        return value


@dataclass(frozen=True)
class SchemaAuditMaterialization:
    commitment: SchemaAuditCommitment
    candidate_freeze_id: str
    registries: Mapping[str, SelfSupervisedRegistry]
    causal_registry: SelfSupervisedRegistry
    materialization_stage: int

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION,
            "commitment": self.commitment.as_dict(),
            "candidate_freeze_id": self.candidate_freeze_id,
            "registries": {
                key: item.as_dict() for key, item in sorted(self.registries.items())
            },
            "causal_registry": self.causal_registry.as_dict(),
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


class SchemaInductionAuditAuthority:
    def __init__(
        self,
        *,
        seeds: Tuple[int, ...] = (2027, 2053, 2063, 2081, 2089),
        tasks_per_family: int = 24,
    ) -> None:
        if len(seeds) != 5 or tasks_per_family < 24:
            raise ValueError("schema audit requires five seeds and 24 tasks")
        self._seeds = seeds
        self._tasks_per_family = tasks_per_family
        self._sealed_spec = {
            "seeds": seeds,
            "tasks_per_family": tasks_per_family,
            "families": ("numeric", "relational", "lookup"),
            "evidence_modes": EVIDENCE_MODES,
            "generic_repairs": "one AST literal or context-cell edit",
            "authority_ref": SCHEMA_AUDIT_AUTHORITY_REF,
        }
        self.commitment = SchemaAuditCommitment(
            content_digest(self._sealed_spec),
            seeds,
            tasks_per_family,
            self._sealed_spec["families"],
            EVIDENCE_MODES,
            (
                "materialize fresh three-family registries only after the grammar, "
                "frozen predicate model, and generic repair rule are frozen"
            ),
        )
        self._materialized = False

    def materialize(
        self,
        candidate_freeze: SchemaCoreFreeze,
        *,
        materialization_stage: int = 5,
    ) -> SchemaAuditMaterialization:
        if self._materialized:
            raise ValueError("schema audit may be materialized only once")
        if candidate_freeze.freeze_stage >= materialization_stage:
            raise ValueError("schema candidate did not freeze before audit")
        registries = {}
        for seed in self._seeds:
            table_tasks = BehavioralPredicateAuditAuthority._table_tasks(
                seed + 9000, self._tasks_per_family
            )
            base = {
                "numeric-%d" % seed: build_latent_registry(
                    partition="audit",
                    tasks=LatentObjectAuditAuthority._numeric_tasks(
                        seed, self._tasks_per_family
                    ),
                    authority_ref=SCHEMA_AUDIT_AUTHORITY_REF,
                    exposure_stage=materialization_stage,
                    seed=seed + 10000,
                ),
                "relational-%d" % seed: build_latent_registry(
                    partition="audit",
                    tasks=LatentObjectAuditAuthority._relational_tasks(
                        seed + 5000, self._tasks_per_family
                    ),
                    authority_ref=SCHEMA_AUDIT_AUTHORITY_REF,
                    exposure_stage=materialization_stage,
                    seed=seed + 20000,
                ),
                "table-%d" % seed: build_table_registry(
                    partition="audit",
                    tasks=table_tasks,
                    authority_ref=SCHEMA_AUDIT_AUTHORITY_REF,
                    exposure_stage=materialization_stage,
                    seed=seed + 30000,
                ),
            }
            for offset, (key, registry) in enumerate(base.items()):
                registries[key] = degrade_identity_evidence(
                    registry,
                    seed=seed + 70000 + 10000 * offset,
                    authority_ref=SCHEMA_AUDIT_AUTHORITY_REF,
                    exposure_stage=materialization_stage,
                )
        mixed_seed = self._seeds[0] + 120000
        mixed_tasks = [
            *LatentObjectAuditAuthority._numeric_tasks(mixed_seed, 8),
            *LatentObjectAuditAuthority._relational_tasks(mixed_seed + 1, 8),
        ]
        random.Random(mixed_seed + 2).shuffle(mixed_tasks)
        mixed = build_latent_registry(
            partition="causal_audit",
            tasks=tuple(mixed_tasks),
            authority_ref=SCHEMA_AUDIT_AUTHORITY_REF,
            exposure_stage=materialization_stage,
            seed=mixed_seed + 3,
        )
        causal = degrade_identity_evidence(
            mixed,
            seed=mixed_seed + 4,
            authority_ref=SCHEMA_AUDIT_AUTHORITY_REF,
            exposure_stage=materialization_stage,
        )
        self._materialized = True
        return SchemaAuditMaterialization(
            self.commitment,
            candidate_freeze.freeze_id,
            registries,
            causal,
            materialization_stage,
        )

    def verify_commitment(self, value: SchemaAuditMaterialization) -> bool:
        return (
            value.commitment == self.commitment
            and self.commitment.sealed_spec_digest
            == content_digest(self._sealed_spec)
        )
