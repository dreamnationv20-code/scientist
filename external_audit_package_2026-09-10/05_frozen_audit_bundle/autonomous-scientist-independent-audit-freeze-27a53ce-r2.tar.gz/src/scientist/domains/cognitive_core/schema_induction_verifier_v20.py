from __future__ import annotations

import inspect
import json
import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.behavioral_predicate_verifier_v19 import (
    _independent_joint_rate,
)
from scientist.domains.cognitive_core.schema_induction_audit_authority_v20 import (
    SchemaAuditMaterialization,
)
from scientist.domains.cognitive_core.self_supervised_object_discovery_v18 import (
    CandidateVisibleEventStream,
)
from scientist.domains.cognitive_core.self_supervised_schema_induction_v20 import (
    SchemaAuditTrial,
    SchemaCoreFreeze,
    SchemaInductionTrace,
    SchemaObjectRuntime,
    repair_schema_from_behavior,
    synthesize_schema,
)
from scientist.program.control_plane import AutonomousScientistControlPlane


SCHEMA_INDUCTION_VERIFIER_REF = (
    "cognitive-core-schema-induction-independent-verifier-v20"
)


@dataclass(frozen=True)
class SchemaInductionVerification:
    check_results: Mapping[str, bool]
    cognitive_core_criteria: Mapping[str, bool]
    independent_match_rates: Mapping[str, float]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str = SCHEMA_INDUCTION_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def schema_induction_milestone_demonstrated(self) -> bool:
        required = (
            "fixed_schema_dispatch_is_absent",
            "schemas_are_induced_from_behavioral_examples",
            "updates_use_generic_behavioral_repair",
            "three_schema_families_transfer",
            "schema_representation_has_selective_causal_effect",
        )
        return all(self.cognitive_core_criteria[item] for item in required)

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "cognitive_core_criteria": dict(
                sorted(self.cognitive_core_criteria.items())
            ),
            "independent_match_rates": dict(
                sorted(self.independent_match_rates.items())
            ),
            "schema_induction_milestone_demonstrated": (
                self.schema_induction_milestone_demonstrated
            ),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _operators(trace) -> set[str]:
    values = set()

    def visit(node) -> None:
        values.add(node.operator)
        for argument in node.arguments:
            if hasattr(argument, "operator"):
                visit(argument)

    for decision in trace.synthesis_decisions:
        if decision.selected_schema is not None:
            visit(decision.selected_schema)
    return values


def verify_schema_induction(
    *,
    control: AutonomousScientistControlPlane,
    candidate_stream: CandidateVisibleEventStream,
    development_trace: SchemaInductionTrace,
    candidate_freeze: SchemaCoreFreeze,
    source_predicate_model_id: str,
    materialization: SchemaAuditMaterialization,
    trial: SchemaAuditTrial,
    artifact_round_trip_checks: Mapping[str, bool],
) -> SchemaInductionVerification:
    stream_text = json.dumps(candidate_stream.as_dict(), sort_keys=True).lower()
    trace_text = json.dumps(development_trace.as_dict(), sort_keys=True).lower()
    implementation_text = "\n".join(
        inspect.getsource(value)
        for value in (
            synthesize_schema,
            repair_schema_from_behavior,
            SchemaObjectRuntime,
        )
    ).lower()
    forbidden_fixed_paths = (
        "infer_typed_expression",
        "_infer_mutation",
        "_fixed_repair",
        "polynomial_mod",
        "relation_path",
        "table_item",
    )
    hidden_event_ids = {
        event.event_id
        for item in materialization.registries.values()
        for event in item.registry.events
    }
    match_rates = {
        key: _independent_joint_rate(
            materialization.registries[key].registry, evaluation
        )
        for key, evaluation in trial.candidate_evaluations.items()
    }
    hidden_operators = set().union(
        *(_operators(trace) for trace in trial.schema_oracle_traces.values())
    )
    progress = control.graph.progress_by_role()["objective"]
    checks = {
        "all_artifacts_round_trip_exactly": (
            bool(artifact_round_trip_checks)
            and all(artifact_round_trip_checks.values())
        ),
        "candidate_stream_contains_no_evaluator_addresses_or_answers": all(
            token not in stream_text
            for token in (
                "task_ref",
                "object_ref",
                "evaluator_family",
                "update_address",
                "expected_payload",
            )
        ),
        "development_trace_contains_no_evaluator_labels": all(
            token not in trace_text
            for token in (
                "task_ref",
                "object_ref",
                "evaluator_family",
                "expected_payload",
            )
        ),
        "fixed_schema_inference_and_mutation_paths_are_absent": all(
            token not in implementation_text for token in forbidden_fixed_paths
        ),
        "schema_core_reuses_exact_frozen_predicate_model": (
            candidate_freeze.address_model.model_id == source_predicate_model_id
        ),
        "schema_core_is_bound_only_to_development_experience": (
            candidate_freeze.development_trace_id == development_trace.trace_id
            and candidate_freeze.development_registry_id
            == candidate_stream.registry_id
            and not hidden_event_ids.intersection(
                decision.event_id
                for decision in development_trace.synthesis_decisions
            )
        ),
        "audit_materialized_after_complete_schema_freeze": (
            candidate_freeze.freeze_stage < materialization.materialization_stage
            and materialization.candidate_freeze_id == candidate_freeze.freeze_id
            and trial.candidate_freeze.freeze_id == candidate_freeze.freeze_id
        ),
        "all_preregistered_schema_audits_pass": trial.passed,
        "independent_reconstruction_confirms_every_hidden_score": all(
            math.isclose(match_rates[key], evaluation.joint_score, abs_tol=1e-12)
            for key, evaluation in trial.candidate_evaluations.items()
        ),
        "schema_only_oracle_saturates_every_hidden_registry": min(
            item.joint_score for item in trial.schema_oracle_evaluations.values()
        ) == 1.0,
        "hidden_audit_exercises_arithmetic_follow_and_lookup_compositions": (
            {"modulo", "follow", "lookup"}.issubset(hidden_operators)
        ),
        "address_and_schema_causal_interventions_are_selective": (
            trial.address_intervention.passed and trial.schema_intervention.passed
        ),
        "objective_graph_is_not_advanced_by_microdomain_evidence": (
            progress["integrated"] == 0
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    criteria = {
        "fixed_schema_dispatch_is_absent": checks[
            "fixed_schema_inference_and_mutation_paths_are_absent"
        ],
        "schemas_are_induced_from_behavioral_examples": (
            checks["schema_only_oracle_saturates_every_hidden_registry"]
            and trial.check_results["every_hidden_schema_is_uniquely_induced"]
        ),
        "updates_use_generic_behavioral_repair": trial.check_results[
            "every_hidden_update_uses_unique_generic_repair"
        ],
        "three_schema_families_transfer": checks[
            "hidden_audit_exercises_arithmetic_follow_and_lookup_compositions"
        ],
        "schema_representation_has_selective_causal_effect": (
            trial.schema_intervention.passed
        ),
        "operator_grammar_is_learned_from_raw_data": False,
        "naturalistic_language_or_code_transfer_is_demonstrated": False,
        "general_cognitive_core_is_demonstrated": False,
    }
    return SchemaInductionVerification(
        checks,
        criteria,
        match_rates,
        (
            "A single typed grammar induced executable schema compositions and "
            "unique one-edit repairs from candidate-visible behavioral examples, "
            "without fixed schema-family dispatch, while reusing the frozen "
            "Milestone 19 addressing representation across three hidden families."
        ),
        (
            "the universal operator grammar was learned from unrestricted raw data",
            "arbitrary programs or natural-language procedures can be induced",
            "the full cognitive core is solved",
            "external software-engineering or scientific transfer is established",
        ),
        (
            "The typed operator grammar and maximum search depths remain engineered.",
            "The current grammar covers bounded arithmetic, graph-following, and lookup schemas only.",
            "Examples and desired update behaviors are explicitly candidate-visible.",
            "All replication remains local and procedurally generated.",
        ),
    )
