from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import replace
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from scientist.autonomy.instrument_provider import (
    DeterministicValidationReceipt,
    InstrumentOutput,
    InstrumentValidatorStageProvider,
)
from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.self_ask_incumbent_v1 import (
    MODEL_ORDER,
    OFFICIAL_COMMIT,
    OFFICIAL_REPOSITORY,
    SOURCE_WORK_ID,
    VERSION,
    digest,
    file_sha256,
    score_model_receipts,
)
from scientist.program.campaigns import (
    IncumbentEntry,
    IncumbentPortfolio,
    IncumbentRole,
)
from scientist.program.research_kernel import ResearchActionKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase


SELF_ASK_PROVIDER_VERSION = "cognitive-self-ask-receipt-provider-v3"
SELF_ASK_FRESH_BINDING_VERSION = "cognitive-self-ask-fresh-run-binding-v1"
_VALID_EVIDENCE_MODES = {"historical_replay", "fresh_bound_run"}


def _read_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("expected JSON object: %s" % path)
    return value


def _read_jsonl(path: Path) -> list[Mapping[str, Any]]:
    values = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    ]
    if any(not isinstance(value, Mapping) for value in values):
        raise ValueError("expected JSON-object records: %s" % path)
    return values


def _without_rows(summary: Mapping[str, Any]) -> Mapping[str, float]:
    return {
        str(key): float(value)
        for key, value in summary.items()
        if key != "rows"
        and isinstance(value, (int, float))
        and not isinstance(value, bool)
    }


def _stored_artifact_id(kind: str, value: Any) -> str:
    return content_digest({"schema": 1, "kind": kind, "value": value})


def _write_immutable_json(path: Path, value: Mapping[str, Any]) -> None:
    payload = (
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.read_bytes() != payload:
            raise ValueError("refusing to replace Self-Ask binding: %s" % path)
        return
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _verified_command_receipt(value: Mapping[str, Any]) -> Mapping[str, Any]:
    body = dict(value)
    supplied = body.pop("receipt_id", None)
    if supplied != digest(body):
        raise ValueError("Self-Ask command receipt identity mismatch")
    if value.get("returncode") != 0 or float(value.get("wall_seconds", -1.0)) < 0:
        raise ValueError("Self-Ask command receipt did not complete")
    return value


def _command_receipt(
    command: Sequence[str],
    *,
    stdout: str,
    stderr: str,
    returncode: int,
    wall_seconds: float,
) -> Mapping[str, Any]:
    body = {
        "command_digest": digest(list(command)),
        "stdout_digest": digest(stdout),
        "stderr_digest": digest(stderr),
        "returncode": int(returncode),
        "wall_seconds": float(wall_seconds),
    }
    return {**body, "receipt_id": digest(body)}


class SelfAskReceiptBundleRunner:
    """Re-score an immutable Self-Ask execution bundle without state mutation.

    The runner is deliberately agnostic to how receipts were produced. A fresh
    autonomous execution service may write the same frozen contract, whereas a
    legacy bundle can be admitted only as explicitly labelled regression evidence.
    """

    measurement_ref = "self-ask-receipt-measurement-runtime-v3"

    def __init__(self, bundle_dir: Path, *, evidence_mode: str) -> None:
        if evidence_mode not in _VALID_EVIDENCE_MODES:
            raise ValueError("unknown Self-Ask evidence mode")
        self.bundle_dir = Path(bundle_dir).resolve()
        self.evidence_mode = evidence_mode

    def __call__(self, kernel, domain) -> InstrumentOutput:
        del domain
        if kernel.mission is None or kernel.prior_art is None:
            raise ValueError("Self-Ask reproduction requires mission prior art")
        protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
        if (
            protocol.get("version") != VERSION
            or protocol.get("mission_id") != kernel.mission.mission_id
            or protocol.get("literature_assessment_id")
            != kernel.prior_art.assessment_id
        ):
            raise ValueError("Self-Ask protocol belongs to another frontier")
        for source, expected_hash in protocol["source_code_sha256"].items():
            if file_sha256(Path(str(source))) != str(expected_hash):
                raise ValueError("Self-Ask frozen source changed: %s" % source)

        public_path = Path(str(protocol["selection"]["public_path"]))
        authority_path = Path(str(protocol["selection"]["authority_path"]))
        if (
            file_sha256(public_path) != protocol["selection"]["public_sha256"]
            or file_sha256(authority_path)
            != protocol["selection"]["authority_sha256"]
        ):
            raise ValueError("Self-Ask frozen panel changed")
        public = _read_jsonl(public_path)
        authority = {
            str(row["item_id"]): row for row in _read_jsonl(authority_path)
        }
        if len(public) != 8 or len(authority) != 8:
            raise ValueError("Self-Ask scoring panel is incomplete")

        model_metrics: dict[str, Mapping[str, float]] = {}
        model_rows: dict[str, Any] = {}
        completion_ids = []
        receipt_hashes: dict[str, str] = {}
        invocations = []
        for model_key in MODEL_ORDER:
            completion = _read_json(
                self.bundle_dir / ("control/%s-completion.json" % model_key)
            )
            completion_body = dict(completion)
            supplied_completion_id = completion_body.pop("completion_id", None)
            if supplied_completion_id != digest(completion_body):
                raise ValueError("Self-Ask completion identity mismatch")
            receipts_path = Path(str(completion["receipts_path"]))
            receipt_hash = file_sha256(receipts_path)
            if (
                completion.get("status") != "frozen_receipt_matrix_complete"
                or completion.get("freeze_id") != protocol["freeze_id"]
                or receipt_hash != completion["receipts_sha256"]
                or completion.get("answers_opened_before_receipts") is not False
                or completion.get("external_search_used") is not False
            ):
                raise ValueError("Self-Ask model cell is not validly closed")
            receipts = _read_jsonl(receipts_path)
            if any(
                str(row.get("receipt_id"))
                != digest({key: value for key, value in row.items() if key != "receipt_id"})
                for row in receipts
            ):
                raise ValueError("Self-Ask receipt identity mismatch")
            summary = score_model_receipts(public, authority, receipts)
            model_metrics[model_key] = _without_rows(summary)
            model_rows[model_key] = summary["rows"]
            completion_id = str(supplied_completion_id)
            completion_ids.append(completion_id)
            receipt_hashes[model_key] = receipt_hash
            invocations.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="execute_frozen_self_ask_cell:%s" % model_key,
                    actor=ActorIdentity(
                        "local-mlx-self-ask-runtime:%s" % model_key,
                        ActorKind.TOOL_RUNTIME,
                    ),
                    authority_scope=AuthorityScope.EXECUTE,
                    input_artifact_ids=(
                        str(protocol["freeze_id"]),
                        str(protocol["models"][model_key]["identity_id"]),
                    ),
                    output_artifact_ids=(completion_id, receipt_hash),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=sum(
                            float(row.get("elapsed_seconds", 0.0)) for row in receipts
                        ),
                    ),
                )
            )

        fresh_binding: Mapping[str, Any] | None = None
        if self.evidence_mode == "fresh_bound_run":
            fresh_binding = _read_json(self.bundle_dir / "fresh-run-binding.json")
            binding_body = dict(fresh_binding)
            supplied_binding_id = binding_body.pop("binding_id", None)
            if supplied_binding_id != digest(binding_body):
                raise ValueError("Self-Ask fresh-run binding identity mismatch")
            expected_receipts = {
                key: receipt_hashes[key] for key in MODEL_ORDER
            }
            preparation_receipt = _verified_command_receipt(
                fresh_binding["preparation_receipt"]
            )
            model_execution_receipts = {
                key: _verified_command_receipt(
                    fresh_binding["model_execution_receipts"][key]
                )
                for key in MODEL_ORDER
            }
            if any(
                (
                    fresh_binding.get("version")
                    != SELF_ASK_FRESH_BINDING_VERSION,
                    fresh_binding.get("mission_id") != kernel.mission.mission_id,
                    fresh_binding.get("literature_assessment_id")
                    != kernel.prior_art.assessment_id,
                    fresh_binding.get("action_id")
                    != kernel.next_action().action_id,
                    fresh_binding.get("completion_ids") != completion_ids,
                    fresh_binding.get("receipt_sha256") != expected_receipts,
                    fresh_binding.get("freeze_id") != protocol["freeze_id"],
                    fresh_binding.get("human_interventions") != 0,
                    fresh_binding.get("out_of_band_interventions") != 0,
                    fresh_binding.get("normalized_compute_charge_complete")
                    is not True,
                    fresh_binding.get("orchestrated_inside_autonomy_boundary")
                    is not True,
                    fresh_binding.get("development_qualification_only") is not True,
                    fresh_binding.get("prospective_nature_evidence_claimed")
                    is not False,
                )
            ):
                raise ValueError("Self-Ask fresh-run binding is invalid")
            invocations = [
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="freeze_self_ask_reproduction_protocol",
                    actor=ActorIdentity(
                        "self-ask-protocol-runtime-v1", ActorKind.TOOL_RUNTIME
                    ),
                    authority_scope=AuthorityScope.EXECUTE,
                    input_artifact_ids=(
                        kernel.mission.mission_id,
                        kernel.prior_art.assessment_id,
                    ),
                    output_artifact_ids=(
                        str(protocol["freeze_id"]),
                        str(preparation_receipt["receipt_id"]),
                    ),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=float(preparation_receipt["wall_seconds"]),
                    ),
                ),
                *(
                    replace(
                        invocation,
                        output_artifact_ids=(
                            *invocation.output_artifact_ids,
                            str(model_execution_receipts[model_key]["receipt_id"]),
                        ),
                        usage=ResourceUsage(
                            tool_calls=1,
                            wall_seconds=float(
                                model_execution_receipts[model_key]["wall_seconds"]
                            ),
                            compute_units=float(
                                model_execution_receipts[model_key]["wall_seconds"]
                            ),
                        ),
                    )
                    for model_key, invocation in zip(MODEL_ORDER, invocations)
                ),
            ]

        pooled_n = sum(int(model_metrics[key]["n"]) for key in MODEL_ORDER)
        pooled_direct = sum(
            model_metrics[key]["direct_accuracy"] * model_metrics[key]["n"]
            for key in MODEL_ORDER
        ) / pooled_n
        pooled_self_ask = sum(
            model_metrics[key]["self_ask_accuracy"] * model_metrics[key]["n"]
            for key in MODEL_ORDER
        ) / pooled_n
        pooled_protocol = sum(
            model_metrics[key]["self_ask_protocol_complete_rate"]
            * model_metrics[key]["n"]
            for key in MODEL_ORDER
        ) / pooled_n
        evidence_body = {
            "version": VERSION,
            "freeze_id": protocol["freeze_id"],
            "mission_id": kernel.mission.mission_id,
            "literature_assessment_id": kernel.prior_art.assessment_id,
            "source_work_id": SOURCE_WORK_ID,
            "official_repository": OFFICIAL_REPOSITORY,
            "official_commit": OFFICIAL_COMMIT,
            "model_metrics": model_metrics,
            "item_scores": model_rows,
            "pooled": {
                "n": pooled_n,
                "direct_accuracy": pooled_direct,
                "self_ask_accuracy": pooled_self_ask,
                "self_ask_accuracy_delta": pooled_self_ask - pooled_direct,
                "self_ask_protocol_complete_rate": pooled_protocol,
            },
            "completion_ids": completion_ids,
            "receipt_sha256": receipt_hashes,
            "result_interpretation": (
                "This is a completed small-model reproduction whether the frozen "
                "Self-Ask delta is positive, zero, or negative. It does not reproduce "
                "the paper's proprietary GPT-3 effect size and makes no mechanism claim."
            ),
            "external_search_used": False,
            "codex_exchange_used": False,
        }
        evidence = {**evidence_body, "reproduction_id": digest(evidence_body)}
        reproduction_artifact = _stored_artifact_id(
            "self_ask_reproduction", evidence
        )
        protocol_artifact = _stored_artifact_id("self_ask_protocol", protocol)
        direct_entry = IncumbentEntry(
            candidate_id="direct-four-shot-null-v1",
            name="Direct four-shot answer baseline",
            role=IncumbentRole.NULL,
            executable_digest=content_digest(
                {"arm": "composed_direct", "freeze_id": protocol["freeze_id"]}
            ),
            source_locator="internal:null:direct-four-shot",
            reproduction_evidence_ids=(reproduction_artifact,),
            metric_summary={
                "pooled_accuracy": pooled_direct,
                "qwen3_1p7b_accuracy": model_metrics["qwen3_1p7b"][
                    "direct_accuracy"
                ],
                "qwen2p5_3b_accuracy": model_metrics["qwen2p5_3b"][
                    "direct_accuracy"
                ],
            },
            limitations=(
                "Null arm is an adapted four-shot direct-answer prompt, not a paper-released baseline script.",
            ),
        )
        self_ask_entry = IncumbentEntry(
            candidate_id="published-self-ask-four-shot-local-v1",
            name="Published Self-Ask four-shot prompt adapted to frozen local models",
            role=IncumbentRole.BEST_PUBLISHED_COMPONENT,
            executable_digest=content_digest(
                {
                    "official_commit": OFFICIAL_COMMIT,
                    "official_notebook_sha256": protocol[
                        "official_notebook_sha256"
                    ],
                    "protocol_artifact": protocol_artifact,
                }
            ),
            source_locator="%s/tree/%s" % (OFFICIAL_REPOSITORY, OFFICIAL_COMMIT),
            source_work_id=SOURCE_WORK_ID,
            reproduction_evidence_ids=(reproduction_artifact, *completion_ids),
            metric_summary={
                "pooled_accuracy": pooled_self_ask,
                "pooled_accuracy_delta_vs_direct": pooled_self_ask - pooled_direct,
                "pooled_protocol_complete_rate": pooled_protocol,
                "qwen3_1p7b_accuracy": model_metrics["qwen3_1p7b"][
                    "self_ask_accuracy"
                ],
                "qwen2p5_3b_accuracy": model_metrics["qwen2p5_3b"][
                    "self_ask_accuracy"
                ],
                "qwen3_1p7b_gap_reduction": model_metrics["qwen3_1p7b"][
                    "compositionality_gap_reduction"
                ],
                "qwen2p5_3b_gap_reduction": model_metrics["qwen2p5_3b"][
                    "compositionality_gap_reduction"
                ],
            },
            limitations=(
                "The published text-davinci-002 result is not directly comparable to these 1.7B/3B instruction models.",
                "The official completion prompt is wrapped in each local model's chat template.",
                "External search is excluded because conclusion-equivalent snippets are outside the cognitive-repair claim boundary.",
                "Eight preregistered public-dataset items constitute a reproduction screen, not a precision effect-size estimate.",
                "The public 2022 dataset may have appeared in model pretraining.",
                "Observed behavior cannot establish an internal causal mechanism.",
            ),
        )
        portfolio = IncumbentPortfolio(
            node_id=kernel.mission.root_node_id,
            literature_assessment_id=kernel.prior_art.assessment_id,
            entries=(direct_entry, self_ask_entry),
            primary_incumbent_id=self_ask_entry.candidate_id,
            selection_rationale=(
                "Self-Ask is the frozen closest executable published component. The "
                "local reproduction retains its measured result without requiring a "
                "positive effect and supplies the decomposition baseline for the next "
                "phenomenon-mapping stage."
            ),
        )
        invocations.append(
            ExternalInvocation(
                kind=InvocationKind.TOOL,
                operation="score_frozen_self_ask_receipts",
                actor=ActorIdentity(
                    self.measurement_ref, ActorKind.TOOL_RUNTIME
                ),
                authority_scope=AuthorityScope.MEASURE,
                input_artifact_ids=(
                    str(protocol["freeze_id"]),
                    str(protocol["selection"]["authority_sha256"]),
                    *(
                        ()
                        if fresh_binding is None
                        else (str(fresh_binding["binding_id"]),)
                    ),
                    *completion_ids,
                    *tuple(receipt_hashes[key] for key in MODEL_ORDER),
                ),
                output_artifact_ids=(
                    portfolio.portfolio_id,
                    str(evidence["reproduction_id"]),
                    reproduction_artifact,
                    protocol_artifact,
                ),
                usage=ResourceUsage(tool_calls=1),
            )
        )
        return InstrumentOutput(
            artifact=portfolio,
            artifact_id=portfolio.portfolio_id,
            invocations=tuple(invocations),
            measurement_ref=self.measurement_ref,
            details={
                "self_ask_provider_version": SELF_ASK_PROVIDER_VERSION,
                "evidence_mode": self.evidence_mode,
                "fresh_run_bound_execution": self.evidence_mode
                == "fresh_bound_run",
                "prospective_autonomy_evidence": False,
                "prospective_nature_evidence_claimed": False,
                "fresh_run_binding_id": (
                    None
                    if fresh_binding is None
                    else str(fresh_binding["binding_id"])
                ),
                "freeze_id": protocol["freeze_id"],
                "reproduction_id": evidence["reproduction_id"],
                "reproduction_artifact": reproduction_artifact,
                "protocol_artifact": protocol_artifact,
                "completion_ids": completion_ids,
                "receipt_sha256": receipt_hashes,
                "model_metrics": model_metrics,
                "pooled": evidence["pooled"],
                "normalized_compute_charge_complete": fresh_binding is not None,
            },
        )


class AutonomyBoundSelfAskRunner:
    """Create a fresh Self-Ask bundle entirely inside one V3 stage call."""

    def __init__(
        self,
        *,
        project_root: Path,
        mission_dir: Path,
        python_executable: Path,
        command_executor: Callable[
            [Sequence[str], Path], tuple[str, str, int, float]
        ]
        | None = None,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.mission_dir = Path(mission_dir).resolve()
        # Preserve a virtual-environment launcher path. Resolving its symlink
        # can bypass the environment's site-packages while keeping the same
        # base interpreter binary.
        self.python_executable = Path(python_executable).absolute()
        self.bundle_dir = self.mission_dir / "incumbent_self_ask_v1"
        self.command_executor = command_executor or self._execute_command

    @staticmethod
    def _execute_command(
        command: Sequence[str], cwd: Path
    ) -> tuple[str, str, int, float]:
        started = time.perf_counter()
        environment = dict(os.environ)
        existing_python_path = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = (
            str(cwd / "src")
            if not existing_python_path
            else "%s%s%s"
            % (str(cwd / "src"), os.pathsep, existing_python_path)
        )
        completed = subprocess.run(
            tuple(command),
            cwd=str(cwd),
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )
        elapsed = time.perf_counter() - started
        return completed.stdout, completed.stderr, completed.returncode, elapsed

    def _run_command(
        self,
        command: Sequence[str],
        *,
        operation: str,
        actor_ref: str,
        input_artifact_ids: Sequence[str],
        charge_compute: bool,
    ) -> tuple[Mapping[str, Any], ExternalInvocation, str]:
        stdout, stderr, returncode, elapsed = self.command_executor(
            tuple(command), self.project_root
        )
        receipt = _command_receipt(
            command,
            stdout=stdout,
            stderr=stderr,
            returncode=returncode,
            wall_seconds=elapsed,
        )
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation=operation,
            actor=ActorIdentity(actor_ref, ActorKind.TOOL_RUNTIME),
            authority_scope=AuthorityScope.EXECUTE,
            input_artifact_ids=tuple(str(item) for item in input_artifact_ids),
            output_artifact_ids=(str(receipt["receipt_id"]),),
            usage=ResourceUsage(
                tool_calls=1,
                wall_seconds=elapsed,
                compute_units=elapsed if charge_compute else 0.0,
            ),
        )
        return receipt, invocation, stderr

    @staticmethod
    def _raise_command_failure(
        *,
        kernel,
        operation: str,
        receipt: Mapping[str, Any],
        stderr: str,
        invocations: Sequence[ExternalInvocation],
    ) -> None:
        infrastructure = "No Metal device available" in stderr
        case = TransitionCase(
            case_ref="self-ask-command-failure:%s:%s"
            % (operation, receipt["receipt_id"]),
            phase="incumbent_reproduction",
            question="Can the frozen Self-Ask operation complete validly?",
            observations=(
                "operation=%s" % operation,
                "returncode=%s" % receipt["returncode"],
                "stderr_digest=%s" % receipt["stderr_digest"],
            ),
            available_actions=(
                RecoveryAction.EXACT_RETRY,
                RecoveryAction.REPAIR_IMPLEMENTATION,
            ),
            protected_invariants=(
                "mission identity",
                "prior-art identity",
                "frozen panel",
                "model identity",
            ),
            evidence_refs=tuple(
                item_id
                for invocation in invocations
                for item_id in invocation.output_artifact_ids
            ),
            retrospective=False,
            domain=kernel.mission.domain_id,
        )
        profile = FailureEvidenceProfile(
            case_id=case.case_id,
            runtime_available=not infrastructure,
            external_dependency_missing=False,
            implementation_integrity_passed=None if infrastructure else False,
            interface_qualified=None,
            protocol_feasible=None,
            measurement_qualified=None,
            scientific_outcome_observed=False,
            scientific_gate_passed=None,
            representation_limit_demonstrated=False,
        )
        raise AdjudicableResearchFailure(
            "autonomy-bound Self-Ask command failed: %s" % operation,
            case=case,
            profile=profile,
            attempt_invocations=tuple(invocations),
        )

    def __call__(self, kernel, domain) -> InstrumentOutput:
        del domain
        if kernel.mission is None or kernel.prior_art is None:
            raise ValueError("autonomous Self-Ask execution requires mission prior art")
        if kernel.next_action().kind != ResearchActionKind.REPRODUCE_INCUMBENT:
            raise ValueError("autonomous Self-Ask runner received another action")
        checkpoint = self.mission_dir / "research-kernel-checkpoint.json"
        if not checkpoint.is_file():
            raise ValueError("autonomous Self-Ask mission checkpoint is absent")
        binding_path = self.bundle_dir / "fresh-run-binding.json"
        if binding_path.exists():
            return SelfAskReceiptBundleRunner(
                self.bundle_dir,
                evidence_mode="fresh_bound_run",
            )(kernel, None)
        if self.bundle_dir.exists() and any(self.bundle_dir.iterdir()):
            case = TransitionCase(
                case_ref="partial-unbound-self-ask-bundle:%s"
                % content_digest(str(self.bundle_dir)),
                phase="incumbent_reproduction",
                question="Can a partial unbound bundle be resumed without mutation?",
                observations=("partial bundle exists without fresh binding",),
                available_actions=(RecoveryAction.REPAIR_IMPLEMENTATION,),
                protected_invariants=("frozen artifacts", "receipt identities"),
                evidence_refs=(content_digest(str(self.bundle_dir)),),
                retrospective=False,
                domain=kernel.mission.domain_id,
            )
            profile = FailureEvidenceProfile(
                case_id=case.case_id,
                runtime_available=True,
                external_dependency_missing=False,
                implementation_integrity_passed=False,
                interface_qualified=None,
                protocol_feasible=None,
                measurement_qualified=None,
                scientific_outcome_observed=False,
                scientific_gate_passed=None,
                representation_limit_demonstrated=False,
            )
            raise AdjudicableResearchFailure(
                "partial unbound Self-Ask bundle requires typed recovery",
                case=case,
                profile=profile,
            )

        prepare_command = (
            str(self.python_executable),
            "scripts/prepare_cognitive_self_ask_incumbent_v1.py",
            "--project",
            str(self.project_root),
            "--mission-dir",
            str(self.mission_dir),
            "--source-dir",
            str(self.project_root / "third_party" / "self-ask"),
        )
        attempted_invocations = []
        preparation_receipt, preparation_invocation, preparation_stderr = (
            self._run_command(
                prepare_command,
                operation="freeze_self_ask_reproduction_protocol",
                actor_ref="self-ask-protocol-runtime-v1",
                input_artifact_ids=(
                    kernel.mission.mission_id,
                    kernel.prior_art.assessment_id,
                ),
                charge_compute=False,
            )
        )
        attempted_invocations.append(preparation_invocation)
        if preparation_receipt["returncode"] != 0:
            self._raise_command_failure(
                kernel=kernel,
                operation="freeze_self_ask_reproduction_protocol",
                receipt=preparation_receipt,
                stderr=preparation_stderr,
                invocations=attempted_invocations,
            )
        protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
        model_receipts = {}
        for model_key in MODEL_ORDER:
            model_command = (
                str(self.python_executable),
                "scripts/run_cognitive_self_ask_incumbent_v1.py",
                "--output",
                str(self.bundle_dir),
                "--model-key",
                model_key,
            )
            receipt, invocation, stderr = self._run_command(
                model_command,
                operation="execute_frozen_self_ask_cell:%s" % model_key,
                actor_ref="local-mlx-self-ask-runtime:%s" % model_key,
                input_artifact_ids=(
                    str(protocol["freeze_id"]),
                    str(protocol["models"][model_key]["identity_id"]),
                ),
                charge_compute=True,
            )
            attempted_invocations.append(invocation)
            if receipt["returncode"] != 0:
                self._raise_command_failure(
                    kernel=kernel,
                    operation="execute_frozen_self_ask_cell:%s" % model_key,
                    receipt=receipt,
                    stderr=stderr,
                    invocations=attempted_invocations,
                )
            model_receipts[model_key] = receipt

        completion_ids = []
        receipt_hashes = {}
        for model_key in MODEL_ORDER:
            completion = _read_json(
                self.bundle_dir / ("control/%s-completion.json" % model_key)
            )
            completion_ids.append(str(completion["completion_id"]))
            receipt_hashes[model_key] = str(completion["receipts_sha256"])
        binding_body = {
            "version": SELF_ASK_FRESH_BINDING_VERSION,
            "mission_id": kernel.mission.mission_id,
            "literature_assessment_id": kernel.prior_art.assessment_id,
            "action_id": kernel.next_action().action_id,
            "freeze_id": protocol["freeze_id"],
            "completion_ids": completion_ids,
            "receipt_sha256": receipt_hashes,
            "preparation_receipt": preparation_receipt,
            "model_execution_receipts": model_receipts,
            "normalized_compute_definition": "local-model-process-wall-second",
            "normalized_compute_units": sum(
                float(model_receipts[key]["wall_seconds"]) for key in MODEL_ORDER
            ),
            "normalized_compute_charge_complete": True,
            "human_interventions": 0,
            "out_of_band_interventions": 0,
            "orchestrated_inside_autonomy_boundary": True,
            "development_qualification_only": True,
            "prospective_nature_evidence_claimed": False,
        }
        binding = {**binding_body, "binding_id": digest(binding_body)}
        _write_immutable_json(binding_path, binding)
        return SelfAskReceiptBundleRunner(
            self.bundle_dir,
            evidence_mode="fresh_bound_run",
        )(kernel, None)


def validate_self_ask_receipt_output(
    output: InstrumentOutput,
    kernel,
    domain,
) -> DeterministicValidationReceipt:
    del domain
    portfolio = output.artifact
    if not isinstance(portfolio, IncumbentPortfolio):
        raise ValueError("Self-Ask runner returned another artifact type")
    if kernel.mission is None or kernel.prior_art is None:
        raise ValueError("Self-Ask validation requires mission prior art")
    completion_ids = tuple(str(item) for item in output.details["completion_ids"])
    receipt_hashes = tuple(
        str(output.details["receipt_sha256"][key]) for key in MODEL_ORDER
    )
    checks = {
        "artifact_identity": output.artifact_id == portfolio.portfolio_id,
        "mission_root_identity": portfolio.node_id
        == kernel.mission.root_node_id,
        "literature_identity": portfolio.literature_assessment_id
        == kernel.prior_art.assessment_id,
        "portfolio_closed": portfolio.closed,
        "primary_reproduced": portfolio.primary.reproduced,
        "published_source_bound": portfolio.primary.source_work_id
        == SOURCE_WORK_ID,
        "two_model_cells_complete": len(completion_ids) == len(MODEL_ORDER),
        "receipt_hashes_complete": len(receipt_hashes) == len(MODEL_ORDER),
        "execution_trace_complete": len(output.invocations)
        == len(MODEL_ORDER)
        + 1
        + int(bool(output.details["fresh_run_bound_execution"])),
        "evidence_mode_declared": output.details["evidence_mode"]
        in _VALID_EVIDENCE_MODES,
        "fresh_execution_requires_binding": (
            not output.details["fresh_run_bound_execution"]
            or (
                output.details["fresh_run_binding_id"] is not None
                and output.details["normalized_compute_charge_complete"]
            )
        ),
        "nature_evidence_not_claimed": output.details[
            "prospective_nature_evidence_claimed"
        ]
        is False,
    }
    return DeterministicValidationReceipt(
        artifact_id=output.artifact_id,
        verifier_ref="independent-self-ask-bundle-validator-v1",
        checks=checks,
        evidence_ids=(
            str(output.details["freeze_id"]),
            str(output.details["reproduction_id"]),
            str(output.details["reproduction_artifact"]),
            str(output.details["protocol_artifact"]),
            *(
                ()
                if output.details["fresh_run_binding_id"] is None
                else (str(output.details["fresh_run_binding_id"]),)
            ),
            *completion_ids,
            *receipt_hashes,
        ),
    )


def build_self_ask_receipt_stage_provider(
    bundle_dir: Path,
    *,
    evidence_mode: str,
) -> InstrumentValidatorStageProvider:
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.REPRODUCE_INCUMBENT,
        runner=SelfAskReceiptBundleRunner(
            bundle_dir,
            evidence_mode=evidence_mode,
        ),
        validator=validate_self_ask_receipt_output,
        outcome="self_ask_incumbent_reproduced_from_closed_receipts",
    )


def build_autonomy_bound_self_ask_stage_provider(
    *,
    project_root: Path,
    mission_dir: Path,
    python_executable: Path,
    command_executor: Callable[
        [Sequence[str], Path], tuple[str, str, int, float]
    ]
    | None = None,
) -> InstrumentValidatorStageProvider:
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.REPRODUCE_INCUMBENT,
        runner=AutonomyBoundSelfAskRunner(
            project_root=project_root,
            mission_dir=mission_dir,
            python_executable=python_executable,
            command_executor=command_executor,
        ),
        validator=validate_self_ask_receipt_output,
        outcome="self_ask_incumbent_freshly_reproduced",
    )


__all__ = [
    "SELF_ASK_FRESH_BINDING_VERSION",
    "SELF_ASK_PROVIDER_VERSION",
    "AutonomyBoundSelfAskRunner",
    "SelfAskReceiptBundleRunner",
    "build_autonomy_bound_self_ask_stage_provider",
    "build_self_ask_receipt_stage_provider",
    "validate_self_ask_receipt_output",
]
