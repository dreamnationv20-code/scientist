from __future__ import annotations

import hashlib
import json
import re
from decimal import Decimal, InvalidOperation
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence


VERSION = "cognitive-trajectory-self-consistency-incumbent-v1"
SOURCE_WORK_ID = "doi:10.48550/arxiv.2203.11171"
SOURCE_LOCATOR = "https://arxiv.org/abs/2203.11171"
SOURCE_REPOSITORY = "https://github.com/openai/grade-school-math"
SOURCE_REVISION = "3101c7d5072418e28b9008a6636bde82a006892c"
MODEL_ORDER = ("qwen3_1p7b", "qwen2p5_3b")
MODEL_CONTRACT = {
    "qwen3_1p7b": {
        "parameter_class": "1.7B",
        "repository": "Qwen/Qwen3-1.7B-MLX-4bit",
        "revision": "21457c6f51ed54a7c16e988c0844db973815c137",
        "path": (
            "/Users/krishnachaitanya/.cache/huggingface/hub/"
            "models--Qwen--Qwen3-1.7B-MLX-4bit/snapshots/"
            "21457c6f51ed54a7c16e988c0844db973815c137"
        ),
    },
    "qwen2p5_3b": {
        "parameter_class": "3B",
        "repository": "mlx-community/Qwen2.5-3B-Instruct-4bit",
        "revision": "4f83f8f146fdf28b512a06562b671d7af4fab457",
        "path": (
            "/Users/krishnachaitanya/.cache/huggingface/hub/"
            "models--mlx-community--Qwen2.5-3B-Instruct-4bit/snapshots/"
            "4f83f8f146fdf28b512a06562b671d7af4fab457"
        ),
    },
}
SELECTION_SEED = 20260908
EVALUATION_ITEMS = 8
DEMONSTRATION_ITEMS = 4
SELF_CONSISTENCY_SAMPLES = 5
MAXIMUM_NEW_TOKENS = 192


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def file_sha256(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def select_rows_answer_blind(
    rows: Sequence[Mapping[str, Any]],
    *,
    count: int,
    split: str,
) -> tuple[Mapping[str, Any], ...]:
    ranked = sorted(
        enumerate(rows),
        key=lambda item: hashlib.sha256(
            (
                "%s\x1f%s\x1f%d\x1f%s"
                % (VERSION, split, SELECTION_SEED, str(item[1]["question"]))
            ).encode("utf-8")
        ).hexdigest(),
    )
    if len(ranked) < count:
        raise ValueError("insufficient GSM8K rows")
    return tuple(
        {
            "row_id": index,
            "question": str(row["question"]),
            "answer": str(row["answer"]),
        }
        for index, row in ranked[:count]
    )


def demonstration_text(rows: Sequence[Mapping[str, Any]]) -> str:
    blocks = []
    for row in rows:
        reasoning, marker, answer = str(row["answer"]).rpartition("####")
        if not marker:
            raise ValueError("GSM8K demonstration lacks final answer marker")
        blocks.append(
            "Question: %s\nReasoning: %s\nFINAL: %s"
            % (
                str(row["question"]),
                reasoning.strip().replace("<<", "(").replace(">>", ")"),
                answer.strip(),
            )
        )
    return "\n\n".join(blocks)


def reasoning_prompt(demonstrations: str, question: str) -> str:
    return (
        "Solve each problem by reasoning step by step. Finish with exactly one "
        "line in the form `FINAL: <number>`.\n\n"
        + demonstrations
        + "\n\nQuestion: "
        + question
        + "\nReasoning:"
    )


_NUMBER = re.compile(r"[-+]?\d[\d,]*(?:\.\d+)?(?:/[-+]?\d[\d,]*)?")


def canonical_number(text: str) -> str | None:
    final_lines = re.findall(r"(?im)^\s*FINAL\s*:\s*(.+?)\s*$", text)
    candidate = final_lines[-1] if final_lines else text
    matches = _NUMBER.findall(candidate)
    if not matches:
        return None
    raw = matches[-1].replace(",", "")
    try:
        if "/" in raw:
            value = Fraction(raw)
            if value.denominator == 1:
                return str(value.numerator)
            return "%d/%d" % (value.numerator, value.denominator)
        value = Decimal(raw)
    except (InvalidOperation, ValueError, ZeroDivisionError):
        return None
    if value == value.to_integral():
        return str(int(value))
    return format(value.normalize(), "f")


def deterministic_seed(
    freeze_id: str,
    model_key: str,
    item_id: str,
    arm: str,
    sample_index: int,
) -> int:
    value = "%s\x1f%s\x1f%s\x1f%s\x1f%s\x1f%d" % (
        VERSION,
        freeze_id,
        model_key,
        item_id,
        arm,
        sample_index,
    )
    return int.from_bytes(hashlib.sha256(value.encode("utf-8")).digest()[:8], "big")


def majority_vote(values: Sequence[str | None]) -> str | None:
    observed = [value for value in values if value is not None]
    if not observed:
        return None
    counts = {value: observed.count(value) for value in set(observed)}
    return sorted(counts, key=lambda value: (-counts[value], value))[0]


def score_model_receipts(
    public: Sequence[Mapping[str, Any]],
    authority: Mapping[str, Mapping[str, Any]],
    receipts: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    expected = len(public) * (1 + SELF_CONSISTENCY_SAMPLES)
    keys = {
        (
            str(row["item_id"]),
            str(row["arm"]),
            int(row["sample_index"]),
        )
        for row in receipts
    }
    if len(receipts) != expected or len(keys) != expected:
        raise ValueError("Self-Consistency receipt matrix is incomplete or duplicated")
    rows = []
    for item in public:
        item_id = str(item["item_id"])
        item_receipts = [row for row in receipts if row["item_id"] == item_id]
        greedy = next(row for row in item_receipts if row["arm"] == "greedy_cot")
        samples = sorted(
            (row for row in item_receipts if row["arm"] == "self_consistency"),
            key=lambda row: int(row["sample_index"]),
        )
        if len(samples) != SELF_CONSISTENCY_SAMPLES:
            raise ValueError("Self-Consistency sample count differs from protocol")
        gold = canonical_number(str(authority[item_id]["answer"]))
        greedy_answer = canonical_number(str(greedy["response"]))
        sample_answers = [canonical_number(str(row["response"])) for row in samples]
        voted = majority_vote(sample_answers)
        rows.append(
            {
                "item_id": item_id,
                "gold": gold,
                "greedy_answer": greedy_answer,
                "self_consistency_answer": voted,
                "sample_answers": sample_answers,
                "greedy_correct": greedy_answer == gold,
                "self_consistency_correct": voted == gold,
                "valid_sample_count": sum(value is not None for value in sample_answers),
                "unique_sample_answer_count": len(
                    {value for value in sample_answers if value is not None}
                ),
                "greedy_output_tokens": int(greedy["output_tokens"]),
                "sample_output_tokens": sum(
                    int(row["output_tokens"]) for row in samples
                ),
            }
        )
    n = len(rows)
    greedy_correct = sum(row["greedy_correct"] for row in rows)
    self_consistency_correct = sum(
        row["self_consistency_correct"] for row in rows
    )
    return {
        "n": n,
        "greedy_accuracy": greedy_correct / n,
        "self_consistency_accuracy": self_consistency_correct / n,
        "self_consistency_accuracy_delta": (
            self_consistency_correct - greedy_correct
        )
        / n,
        "valid_sample_rate": sum(row["valid_sample_count"] for row in rows)
        / (n * SELF_CONSISTENCY_SAMPLES),
        "mean_unique_sample_answers": sum(
            row["unique_sample_answer_count"] for row in rows
        )
        / n,
        "greedy_mean_output_tokens": sum(
            row["greedy_output_tokens"] for row in rows
        )
        / n,
        "self_consistency_mean_total_output_tokens": sum(
            row["sample_output_tokens"] for row in rows
        )
        / n,
        "rows": rows,
    }


__all__ = [
    "DEMONSTRATION_ITEMS",
    "EVALUATION_ITEMS",
    "MAXIMUM_NEW_TOKENS",
    "MODEL_CONTRACT",
    "MODEL_ORDER",
    "SELECTION_SEED",
    "SELF_CONSISTENCY_SAMPLES",
    "SOURCE_LOCATOR",
    "SOURCE_REPOSITORY",
    "SOURCE_REVISION",
    "SOURCE_WORK_ID",
    "VERSION",
    "canonical_json",
    "canonical_number",
    "demonstration_text",
    "deterministic_seed",
    "digest",
    "file_sha256",
    "majority_vote",
    "reasoning_prompt",
    "score_model_receipts",
    "select_rows_answer_blind",
]
