from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import replace
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from scientist.autonomy.failure_adjudication import (
    AdjudicableResearchFailure,
    FailureEvidenceProfile,
)
from scientist.autonomy.instrument_provider import (
    DeterministicValidationReceipt,
    InstrumentOutput,
    InstrumentValidatorStageProvider,
)
from scientist.autonomy.state import (
    ActorIdentity,
    ActorKind,
    AuthorityScope,
    ResourceUsage,
)
from scientist.autonomy.tracing import ExternalInvocation, InvocationKind
from scientist.autonomy.transitions import RecoveryAction, TransitionCase
from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.self_consistency_incumbent_v1 import (
    MODEL_ORDER,
    SELF_CONSISTENCY_SAMPLES,
    SOURCE_LOCATOR,
    SOURCE_WORK_ID,
    VERSION,
    digest,
    file_sha256,
    score_model_receipts,
)
from scientist.program.campaigns import (
    IncumbentEntry,
    IncumbentPortfolio,
    IncumbentRole,
)
from scientist.program.research_kernel import ResearchActionKind


SELF_CONSISTENCY_PROVIDER_VERSION = (
    "cognitive-self-consistency-receipt-provider-v1"
)
SELF_CONSISTENCY_FRESH_BINDING_VERSION = (
    "cognitive-self-consistency-fresh-run-binding-v1"
)


def _read_json(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise ValueError("expected JSON object: %s" % path)
    return value


def _read_jsonl(path: Path) -> list[Mapping[str, Any]]:
    values = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if any(not isinstance(value, Mapping) for value in values):
        raise ValueError("expected JSON-object records: %s" % path)
    return values


def _stored_artifact_id(kind: str, value: Any) -> str:
    return content_digest({"schema": 1, "kind": kind, "value": value})


def _write_immutable_json(path: Path, value: Mapping[str, Any]) -> None:
    payload = (
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if path.read_bytes() != payload:
            raise ValueError("refusing to replace binding: %s" % path)
        return
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _command_receipt(
    command: Sequence[str],
    *,
    stdout: str,
    stderr: str,
    returncode: int,
    wall_seconds: float,
) -> Mapping[str, Any]:
    body = {
        "command_digest": digest(list(command)),
        "stdout_digest": digest(stdout),
        "stderr_digest": digest(stderr),
        "returncode": int(returncode),
        "wall_seconds": float(wall_seconds),
    }
    return {**body, "receipt_id": digest(body)}


def _verified_command_receipt(value: Mapping[str, Any]) -> Mapping[str, Any]:
    body = dict(value)
    supplied = body.pop("receipt_id", None)
    if supplied != digest(body):
        raise ValueError("command receipt identity mismatch")
    if value.get("returncode") != 0 or float(value.get("wall_seconds", -1.0)) < 0:
        raise ValueError("command receipt did not complete")
    return value


class SelfConsistencyReceiptBundleRunner:
    measurement_ref = "self-consistency-receipt-measurement-runtime-v1"

    def __init__(self, bundle_dir: Path) -> None:
        self.bundle_dir = Path(bundle_dir).resolve()

    def __call__(self, kernel, domain) -> InstrumentOutput:
        del domain
        if kernel.mission is None or kernel.prior_art is None:
            raise ValueError("Self-Consistency reproduction requires prior art")
        protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
        if (
            protocol.get("version") != VERSION
            or protocol.get("mission_id") != kernel.mission.mission_id
            or protocol.get("literature_assessment_id")
            != kernel.prior_art.assessment_id
            or protocol.get("source_work_id") != SOURCE_WORK_ID
        ):
            raise ValueError("Self-Consistency protocol belongs to another frontier")
        for source, expected_hash in protocol["source_code_sha256"].items():
            if file_sha256(Path(str(source))) != str(expected_hash):
                raise ValueError("Self-Consistency frozen source changed: %s" % source)
        public_path = Path(str(protocol["selection"]["public_path"]))
        authority_path = Path(str(protocol["selection"]["authority_path"]))
        demonstrations_path = Path(
            str(protocol["selection"]["demonstration_path"])
        )
        if any(
            (
                file_sha256(public_path)
                != protocol["selection"]["public_sha256"],
                file_sha256(authority_path)
                != protocol["selection"]["authority_sha256"],
                file_sha256(demonstrations_path)
                != protocol["selection"]["demonstration_sha256"],
            )
        ):
            raise ValueError("Self-Consistency frozen panel changed")
        public = _read_jsonl(public_path)
        authority = {
            str(row["item_id"]): row for row in _read_jsonl(authority_path)
        }
        if len(public) != protocol["selection"]["n"] or len(authority) != len(public):
            raise ValueError("Self-Consistency scoring panel is incomplete")

        binding = _read_json(self.bundle_dir / "fresh-run-binding.json")
        binding_body = dict(binding)
        supplied_binding_id = binding_body.pop("binding_id", None)
        if supplied_binding_id != digest(binding_body):
            raise ValueError("Self-Consistency fresh binding identity mismatch")
        preparation_receipt = _verified_command_receipt(
            binding["preparation_receipt"]
        )
        model_command_receipts = {
            key: _verified_command_receipt(
                binding["model_execution_receipts"][key]
            )
            for key in MODEL_ORDER
        }

        completion_ids = []
        receipt_hashes = {}
        model_metrics = {}
        model_rows = {}
        for model_key in MODEL_ORDER:
            completion = _read_json(
                self.bundle_dir / ("control/%s-completion.json" % model_key)
            )
            completion_body = dict(completion)
            completion_id = completion_body.pop("completion_id", None)
            receipts_path = Path(str(completion["receipts_path"]))
            receipt_hash = file_sha256(receipts_path)
            receipts = _read_jsonl(receipts_path)
            if (
                completion_id != digest(completion_body)
                or completion.get("status") != "frozen_receipt_matrix_complete"
                or completion.get("freeze_id") != protocol["freeze_id"]
                or completion.get("receipts_sha256") != receipt_hash
                or completion.get("receipt_count")
                != len(public) * (1 + SELF_CONSISTENCY_SAMPLES)
                or completion.get("answers_opened_before_receipts") is not False
                or any(
                    row.get("receipt_id")
                    != digest(
                        {
                            key: value
                            for key, value in row.items()
                            if key != "receipt_id"
                        }
                    )
                    for row in receipts
                )
            ):
                raise ValueError("Self-Consistency model cell is invalid")
            scored = score_model_receipts(public, authority, receipts)
            model_metrics[model_key] = {
                key: value for key, value in scored.items() if key != "rows"
            }
            model_rows[model_key] = scored["rows"]
            completion_ids.append(str(completion_id))
            receipt_hashes[model_key] = receipt_hash

        if any(
            (
                binding.get("version")
                != SELF_CONSISTENCY_FRESH_BINDING_VERSION,
                binding.get("mission_id") != kernel.mission.mission_id,
                binding.get("literature_assessment_id")
                != kernel.prior_art.assessment_id,
                binding.get("action_id") != kernel.next_action().action_id,
                binding.get("freeze_id") != protocol["freeze_id"],
                binding.get("completion_ids") != completion_ids,
                binding.get("receipt_sha256") != receipt_hashes,
                binding.get("human_interventions") != 0,
                binding.get("out_of_band_interventions") != 0,
                binding.get("orchestrated_inside_autonomy_boundary") is not True,
                binding.get("development_qualification_only") is not True,
                binding.get("prospective_nature_evidence_claimed") is not False,
            )
        ):
            raise ValueError("Self-Consistency fresh binding is invalid")

        pooled_n = sum(int(model_metrics[key]["n"]) for key in MODEL_ORDER)
        pooled_greedy = sum(
            model_metrics[key]["greedy_accuracy"] * model_metrics[key]["n"]
            for key in MODEL_ORDER
        ) / pooled_n
        pooled_consistency = sum(
            model_metrics[key]["self_consistency_accuracy"]
            * model_metrics[key]["n"]
            for key in MODEL_ORDER
        ) / pooled_n
        evidence_body = {
            "version": VERSION,
            "freeze_id": protocol["freeze_id"],
            "mission_id": kernel.mission.mission_id,
            "literature_assessment_id": kernel.prior_art.assessment_id,
            "source_work_id": SOURCE_WORK_ID,
            "source_locator": SOURCE_LOCATOR,
            "model_metrics": model_metrics,
            "item_scores": model_rows,
            "pooled": {
                "n": pooled_n,
                "greedy_accuracy": pooled_greedy,
                "self_consistency_accuracy": pooled_consistency,
                "self_consistency_accuracy_delta": (
                    pooled_consistency - pooled_greedy
                ),
            },
            "completion_ids": completion_ids,
            "receipt_sha256": receipt_hashes,
            "answers_opened_after_both_receipt_matrices": True,
            "external_search_used": False,
            "foundation_model_api_used": False,
            "result_interpretation": (
                "A completed local reproduction screen regardless of effect sign; "
                "it does not claim the original paper's model-scale effect size."
            ),
        }
        evidence = {**evidence_body, "reproduction_id": digest(evidence_body)}
        reproduction_artifact = _stored_artifact_id(
            "self_consistency_reproduction", evidence
        )
        protocol_artifact = _stored_artifact_id(
            "self_consistency_protocol", protocol
        )
        direct_entry = IncumbentEntry(
            candidate_id="greedy-cot-local-null-v1",
            name="Greedy chain-of-thought local control",
            role=IncumbentRole.NULL,
            executable_digest=content_digest(
                {"arm": "greedy_cot", "freeze_id": protocol["freeze_id"]}
            ),
            source_locator="internal:null:greedy-cot",
            reproduction_evidence_ids=(reproduction_artifact,),
            metric_summary={
                "pooled_accuracy": pooled_greedy,
                **{
                    "%s_accuracy" % key: model_metrics[key]["greedy_accuracy"]
                    for key in MODEL_ORDER
                },
            },
            limitations=(
                "The null is an implementation-matched greedy CoT arm.",
            ),
        )
        consistency_entry = IncumbentEntry(
            candidate_id="published-self-consistency-local-v1",
            name="Published Self-Consistency adapted to frozen local models",
            role=IncumbentRole.BEST_PUBLISHED_COMPONENT,
            executable_digest=content_digest(
                {
                    "source_work_id": SOURCE_WORK_ID,
                    "protocol_artifact": protocol_artifact,
                }
            ),
            source_locator=SOURCE_LOCATOR,
            source_work_id=SOURCE_WORK_ID,
            reproduction_evidence_ids=(reproduction_artifact, *completion_ids),
            metric_summary={
                "pooled_accuracy": pooled_consistency,
                "pooled_accuracy_delta_vs_greedy": (
                    pooled_consistency - pooled_greedy
                ),
                **{
                    "%s_accuracy" % key: model_metrics[key][
                        "self_consistency_accuracy"
                    ]
                    for key in MODEL_ORDER
                },
            },
            limitations=(
                "Five samples per item are a bounded local approximation to the original paper's larger sample counts.",
                "Eight GSM8K items per model form a reproduction screen, not a precision effect estimate.",
                "The evaluated 1.7B and 3B quantized instruction models differ from the original paper's models.",
                "Public GSM8K items may have appeared in model pretraining.",
            ),
        )
        portfolio = IncumbentPortfolio(
            node_id=kernel.mission.root_node_id,
            literature_assessment_id=kernel.prior_art.assessment_id,
            entries=(direct_entry, consistency_entry),
            primary_incumbent_id=consistency_entry.candidate_id,
            selection_rationale=(
                "Self-Consistency is the audited closest executable published "
                "compute intervention. Its measured local result is retained "
                "without requiring a positive effect."
            ),
        )
        invocations = [
            ExternalInvocation(
                kind=InvocationKind.TOOL,
                operation="freeze_self_consistency_reproduction_protocol",
                actor=ActorIdentity(
                    "self-consistency-protocol-runtime-v1", ActorKind.TOOL_RUNTIME
                ),
                authority_scope=AuthorityScope.EXECUTE,
                input_artifact_ids=(
                    kernel.mission.mission_id,
                    kernel.prior_art.assessment_id,
                ),
                output_artifact_ids=(
                    str(protocol["freeze_id"]),
                    str(preparation_receipt["receipt_id"]),
                ),
                usage=ResourceUsage(
                    tool_calls=1,
                    wall_seconds=float(preparation_receipt["wall_seconds"]),
                ),
            )
        ]
        for model_key, completion_id in zip(MODEL_ORDER, completion_ids):
            command_receipt = model_command_receipts[model_key]
            invocations.append(
                ExternalInvocation(
                    kind=InvocationKind.TOOL,
                    operation="execute_frozen_self_consistency_cell:%s"
                    % model_key,
                    actor=ActorIdentity(
                        "local-mlx-self-consistency-runtime:%s" % model_key,
                        ActorKind.TOOL_RUNTIME,
                    ),
                    authority_scope=AuthorityScope.EXECUTE,
                    input_artifact_ids=(
                        str(protocol["freeze_id"]),
                        str(protocol["models"][model_key]["identity_id"]),
                    ),
                    output_artifact_ids=(
                        completion_id,
                        receipt_hashes[model_key],
                        str(command_receipt["receipt_id"]),
                    ),
                    usage=ResourceUsage(
                        tool_calls=1,
                        wall_seconds=float(command_receipt["wall_seconds"]),
                        compute_units=float(command_receipt["wall_seconds"]),
                    ),
                )
            )
        invocations.append(
            ExternalInvocation(
                kind=InvocationKind.TOOL,
                operation="score_frozen_self_consistency_receipts",
                actor=ActorIdentity(
                    self.measurement_ref, ActorKind.TOOL_RUNTIME
                ),
                authority_scope=AuthorityScope.MEASURE,
                input_artifact_ids=(
                    str(protocol["freeze_id"]),
                    str(protocol["selection"]["authority_sha256"]),
                    str(binding["binding_id"]),
                    *completion_ids,
                    *(receipt_hashes[key] for key in MODEL_ORDER),
                ),
                output_artifact_ids=(
                    portfolio.portfolio_id,
                    str(evidence["reproduction_id"]),
                    reproduction_artifact,
                    protocol_artifact,
                ),
                usage=ResourceUsage(tool_calls=1),
            )
        )
        return InstrumentOutput(
            artifact=portfolio,
            artifact_id=portfolio.portfolio_id,
            invocations=tuple(invocations),
            measurement_ref=self.measurement_ref,
            details={
                "self_consistency_provider_version": (
                    SELF_CONSISTENCY_PROVIDER_VERSION
                ),
                "fresh_run_bound_execution": True,
                "fresh_run_binding_id": binding["binding_id"],
                "freeze_id": protocol["freeze_id"],
                "reproduction_id": evidence["reproduction_id"],
                "reproduction_artifact": reproduction_artifact,
                "protocol_artifact": protocol_artifact,
                "completion_ids": completion_ids,
                "receipt_sha256": receipt_hashes,
                "model_metrics": model_metrics,
                "pooled": evidence["pooled"],
                "normalized_compute_charge_complete": True,
                "prospective_nature_evidence_claimed": False,
            },
        )


class AutonomyBoundSelfConsistencyRunner:
    def __init__(
        self,
        *,
        project_root: Path,
        mission_dir: Path,
        python_executable: Path,
        command_executor: Callable[
            [Sequence[str], Path], tuple[str, str, int, float]
        ]
        | None = None,
    ) -> None:
        self.project_root = Path(project_root).resolve()
        self.mission_dir = Path(mission_dir).resolve()
        self.python_executable = Path(python_executable).absolute()
        self.bundle_dir = self.mission_dir / "incumbent_self_consistency_v1"
        self.command_executor = command_executor or self._execute_command

    @staticmethod
    def _execute_command(
        command: Sequence[str], cwd: Path
    ) -> tuple[str, str, int, float]:
        started = time.perf_counter()
        environment = dict(os.environ)
        existing = environment.get("PYTHONPATH")
        environment["PYTHONPATH"] = (
            str(cwd / "src")
            if not existing
            else "%s%s%s" % (str(cwd / "src"), os.pathsep, existing)
        )
        completed = subprocess.run(
            tuple(command),
            cwd=str(cwd),
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )
        return (
            completed.stdout,
            completed.stderr,
            completed.returncode,
            time.perf_counter() - started,
        )

    def _run_command(
        self,
        command: Sequence[str],
        *,
        operation: str,
        actor_ref: str,
        input_artifact_ids: Sequence[str],
        charge_compute: bool,
    ):
        stdout, stderr, returncode, elapsed = self.command_executor(
            tuple(command), self.project_root
        )
        receipt = _command_receipt(
            command,
            stdout=stdout,
            stderr=stderr,
            returncode=returncode,
            wall_seconds=elapsed,
        )
        invocation = ExternalInvocation(
            kind=InvocationKind.TOOL,
            operation=operation,
            actor=ActorIdentity(actor_ref, ActorKind.TOOL_RUNTIME),
            authority_scope=AuthorityScope.EXECUTE,
            input_artifact_ids=tuple(str(value) for value in input_artifact_ids),
            output_artifact_ids=(str(receipt["receipt_id"]),),
            usage=ResourceUsage(
                tool_calls=1,
                wall_seconds=elapsed,
                compute_units=elapsed if charge_compute else 0.0,
            ),
        )
        return receipt, invocation, stderr

    @staticmethod
    def _raise_failure(
        kernel,
        operation: str,
        receipt: Mapping[str, Any],
        stderr: str,
        invocations: Sequence[ExternalInvocation],
    ) -> None:
        infrastructure = "No Metal device available" in stderr
        case = TransitionCase(
            case_ref="self-consistency-command-failure:%s:%s"
            % (operation, receipt["receipt_id"]),
            phase="incumbent_reproduction",
            question="Can the frozen Self-Consistency operation complete validly?",
            observations=(
                "operation=%s" % operation,
                "returncode=%s" % receipt["returncode"],
                "stderr_digest=%s" % receipt["stderr_digest"],
            ),
            available_actions=(
                RecoveryAction.EXACT_RETRY,
                RecoveryAction.REPAIR_IMPLEMENTATION,
            ),
            protected_invariants=(
                "mission identity",
                "prior-art identity",
                "frozen panel",
                "model identity",
                "completed partial receipts",
            ),
            evidence_refs=tuple(
                value
                for invocation in invocations
                for value in invocation.output_artifact_ids
            ),
            retrospective=False,
            domain=kernel.mission.domain_id,
        )
        raise AdjudicableResearchFailure(
            "autonomy-bound Self-Consistency command failed: %s" % operation,
            case=case,
            profile=FailureEvidenceProfile(
                case_id=case.case_id,
                runtime_available=not infrastructure,
                external_dependency_missing=False,
                implementation_integrity_passed=None if infrastructure else False,
                interface_qualified=None,
                protocol_feasible=True,
                measurement_qualified=None,
                scientific_outcome_observed=False,
                scientific_gate_passed=None,
                representation_limit_demonstrated=False,
            ),
            attempt_invocations=tuple(invocations),
        )

    def __call__(self, kernel, domain) -> InstrumentOutput:
        del domain
        if kernel.mission is None or kernel.prior_art is None:
            raise ValueError("autonomous Self-Consistency requires prior art")
        if kernel.next_action().kind != ResearchActionKind.REPRODUCE_INCUMBENT:
            raise ValueError("Self-Consistency runner received another action")
        checkpoint = self.mission_dir / "research-kernel-checkpoint.json"
        if not checkpoint.is_file():
            raise ValueError("autonomous mission checkpoint is absent")
        binding_path = self.bundle_dir / "fresh-run-binding.json"
        if binding_path.exists():
            return SelfConsistencyReceiptBundleRunner(self.bundle_dir)(kernel, None)

        attempted = []
        prepare_command = (
            str(self.python_executable),
            "scripts/prepare_cognitive_self_consistency_incumbent_v1.py",
            "--project",
            str(self.project_root),
            "--mission-dir",
            str(self.mission_dir),
            "--source-dir",
            str(self.project_root / "third_party" / "grade-school-math"),
        )
        prep, prep_invocation, prep_stderr = self._run_command(
            prepare_command,
            operation="freeze_self_consistency_reproduction_protocol",
            actor_ref="self-consistency-protocol-runtime-v1",
            input_artifact_ids=(
                kernel.mission.mission_id,
                kernel.prior_art.assessment_id,
            ),
            charge_compute=False,
        )
        attempted.append(prep_invocation)
        if prep["returncode"] != 0:
            self._raise_failure(
                kernel, prepare_command[1], prep, prep_stderr, attempted
            )
        protocol = _read_json(self.bundle_dir / "protocol-freeze.json")
        model_receipts = {}
        for model_key in MODEL_ORDER:
            command = (
                str(self.python_executable),
                "scripts/run_cognitive_self_consistency_incumbent_v1.py",
                "--output",
                str(self.bundle_dir),
                "--model-key",
                model_key,
            )
            receipt, invocation, stderr = self._run_command(
                command,
                operation="execute_frozen_self_consistency_cell:%s" % model_key,
                actor_ref="local-mlx-self-consistency-runtime:%s" % model_key,
                input_artifact_ids=(
                    protocol["freeze_id"],
                    protocol["models"][model_key]["identity_id"],
                ),
                charge_compute=True,
            )
            attempted.append(invocation)
            if receipt["returncode"] != 0:
                self._raise_failure(kernel, model_key, receipt, stderr, attempted)
            model_receipts[model_key] = receipt
        completions = [
            _read_json(
                self.bundle_dir / ("control/%s-completion.json" % model_key)
            )
            for model_key in MODEL_ORDER
        ]
        completion_ids = [str(value["completion_id"]) for value in completions]
        receipt_hashes = {
            model_key: str(value["receipts_sha256"])
            for model_key, value in zip(MODEL_ORDER, completions)
        }
        binding_body = {
            "version": SELF_CONSISTENCY_FRESH_BINDING_VERSION,
            "mission_id": kernel.mission.mission_id,
            "literature_assessment_id": kernel.prior_art.assessment_id,
            "action_id": kernel.next_action().action_id,
            "freeze_id": protocol["freeze_id"],
            "completion_ids": completion_ids,
            "receipt_sha256": receipt_hashes,
            "preparation_receipt": prep,
            "model_execution_receipts": model_receipts,
            "normalized_compute_definition": "local-model-process-wall-second",
            "normalized_compute_units": sum(
                float(model_receipts[key]["wall_seconds"]) for key in MODEL_ORDER
            ),
            "normalized_compute_charge_complete": True,
            "human_interventions": 0,
            "out_of_band_interventions": 0,
            "orchestrated_inside_autonomy_boundary": True,
            "development_qualification_only": True,
            "prospective_nature_evidence_claimed": False,
        }
        binding = {**binding_body, "binding_id": digest(binding_body)}
        _write_immutable_json(binding_path, binding)
        return SelfConsistencyReceiptBundleRunner(self.bundle_dir)(kernel, None)


def validate_self_consistency_output(
    output: InstrumentOutput,
    kernel,
    domain,
) -> DeterministicValidationReceipt:
    del domain
    portfolio = output.artifact
    if not isinstance(portfolio, IncumbentPortfolio):
        raise ValueError("Self-Consistency runner returned another artifact")
    if kernel.mission is None or kernel.prior_art is None:
        raise ValueError("Self-Consistency validation requires prior art")
    completion_ids = tuple(output.details["completion_ids"])
    receipt_hashes = tuple(
        output.details["receipt_sha256"][key] for key in MODEL_ORDER
    )
    checks = {
        "artifact_identity": output.artifact_id == portfolio.portfolio_id,
        "mission_root_identity": portfolio.node_id == kernel.mission.root_node_id,
        "literature_identity": portfolio.literature_assessment_id
        == kernel.prior_art.assessment_id,
        "incumbent_matches_literature": kernel.prior_art.executable_incumbent_id
        == portfolio.primary.source_work_id
        == SOURCE_WORK_ID,
        "portfolio_closed": portfolio.closed,
        "primary_reproduced": portfolio.primary.reproduced,
        "two_model_cells_complete": len(completion_ids) == len(MODEL_ORDER),
        "receipt_hashes_complete": len(receipt_hashes) == len(MODEL_ORDER),
        "execution_trace_complete": len(output.invocations)
        == len(MODEL_ORDER) + 2,
        "fresh_binding_present": output.details["fresh_run_binding_id"]
        is not None,
        "compute_charge_complete": output.details[
            "normalized_compute_charge_complete"
        ],
        "nature_evidence_not_claimed": output.details[
            "prospective_nature_evidence_claimed"
        ]
        is False,
    }
    return DeterministicValidationReceipt(
        artifact_id=output.artifact_id,
        verifier_ref="independent-self-consistency-bundle-validator-v1",
        checks=checks,
        evidence_ids=(
            str(output.details["freeze_id"]),
            str(output.details["reproduction_id"]),
            str(output.details["reproduction_artifact"]),
            str(output.details["protocol_artifact"]),
            str(output.details["fresh_run_binding_id"]),
            *completion_ids,
            *receipt_hashes,
        ),
    )


def build_autonomy_bound_self_consistency_stage_provider(
    *,
    project_root: Path,
    mission_dir: Path,
    python_executable: Path,
    command_executor: Callable[
        [Sequence[str], Path], tuple[str, str, int, float]
    ]
    | None = None,
) -> InstrumentValidatorStageProvider:
    return InstrumentValidatorStageProvider(
        action_kind=ResearchActionKind.REPRODUCE_INCUMBENT,
        runner=AutonomyBoundSelfConsistencyRunner(
            project_root=project_root,
            mission_dir=mission_dir,
            python_executable=python_executable,
            command_executor=command_executor,
        ),
        validator=validate_self_consistency_output,
        outcome="self_consistency_incumbent_freshly_reproduced",
        adjudicable_failures=True,
    )


__all__ = [
    "SELF_CONSISTENCY_FRESH_BINDING_VERSION",
    "SELF_CONSISTENCY_PROVIDER_VERSION",
    "AutonomyBoundSelfConsistencyRunner",
    "SelfConsistencyReceiptBundleRunner",
    "build_autonomy_bound_self_consistency_stage_provider",
    "validate_self_consistency_output",
]
