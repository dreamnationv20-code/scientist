from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.latent_object_audit_authority_v17 import (
    LatentObjectAuditAuthority,
)
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    build_latent_registry,
)
from scientist.domains.cognitive_core.self_supervised_object_discovery_v18 import (
    SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
    SelfSupervisedCoreFreeze,
    SelfSupervisedRegistry,
    degrade_identity_evidence,
)


SELF_SUPERVISED_AUDIT_AUTHORITY_REF = (
    "sealed-self-supervised-object-audit-authority-v18"
)


@dataclass(frozen=True)
class SelfSupervisedAuditCommitment:
    sealed_spec_digest: str
    seeds: Tuple[int, ...]
    tasks_per_family: int
    evidence_modes: Tuple[str, ...]
    rule: str
    authority_ref: str = SELF_SUPERVISED_AUDIT_AUTHORITY_REF

    @property
    def commitment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
            "sealed_spec_digest": self.sealed_spec_digest,
            "seeds": list(self.seeds),
            "tasks_per_family": self.tasks_per_family,
            "evidence_modes": list(self.evidence_modes),
            "rule": self.rule,
            "authority_ref": self.authority_ref,
        }
        if include_id:
            value["commitment_id"] = self.commitment_id
        return value


@dataclass(frozen=True)
class SelfSupervisedAuditMaterialization:
    commitment: SelfSupervisedAuditCommitment
    candidate_freeze_id: str
    registries: Mapping[str, SelfSupervisedRegistry]
    causal_registry: SelfSupervisedRegistry
    materialization_stage: int

    @property
    def materialization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
            "commitment": self.commitment.as_dict(),
            "candidate_freeze_id": self.candidate_freeze_id,
            "registries": {
                key: item.as_dict()
                for key, item in sorted(self.registries.items())
            },
            "causal_registry": self.causal_registry.as_dict(),
            "materialization_stage": self.materialization_stage,
        }
        if include_id:
            value["materialization_id"] = self.materialization_id
        return value


class SelfSupervisedObjectAuditAuthority:
    def __init__(
        self,
        *,
        seeds: Tuple[int, ...] = (1823, 1831, 1847, 1861, 1877),
        tasks_per_family: int = 24,
    ) -> None:
        if len(seeds) < 5 or tasks_per_family < 24:
            raise ValueError("self-supervised audit requires five seeds and 24 tasks")
        self._seeds = tuple(seeds)
        self._tasks_per_family = tasks_per_family
        self._sealed_spec = {
            "seeds": self._seeds,
            "tasks_per_family": tasks_per_family,
            "evidence_modes": (
                "full",
                "partial",
                "noisy",
                "consequence_only",
            ),
            "degradation_seed_offset": 70000,
            "authority_ref": SELF_SUPERVISED_AUDIT_AUTHORITY_REF,
        }
        self.commitment = SelfSupervisedAuditCommitment(
            sealed_spec_digest=content_digest(self._sealed_spec),
            seeds=self._seeds,
            tasks_per_family=tasks_per_family,
            evidence_modes=self._sealed_spec["evidence_modes"],
            rule=(
                "generate all hidden tasks and identity-evidence degradations only "
                "after the unlabeled address model freezes"
            ),
        )
        self._materialized = False

    def materialize(
        self,
        candidate_freeze: SelfSupervisedCoreFreeze,
        *,
        materialization_stage: int = 5,
    ) -> SelfSupervisedAuditMaterialization:
        if self._materialized:
            raise ValueError("self-supervised audit may be materialized only once")
        if candidate_freeze.freeze_stage >= materialization_stage:
            raise ValueError("candidate did not freeze before audit materialization")
        registries = {}
        for seed in self._seeds:
            numeric = build_latent_registry(
                partition="audit",
                tasks=LatentObjectAuditAuthority._numeric_tasks(
                    seed, self._tasks_per_family
                ),
                authority_ref=SELF_SUPERVISED_AUDIT_AUTHORITY_REF,
                exposure_stage=materialization_stage,
                seed=seed + 10000,
            )
            relational = build_latent_registry(
                partition="audit",
                tasks=LatentObjectAuditAuthority._relational_tasks(
                    seed + 5000, self._tasks_per_family
                ),
                authority_ref=SELF_SUPERVISED_AUDIT_AUTHORITY_REF,
                exposure_stage=materialization_stage,
                seed=seed + 20000,
            )
            registries["numeric-%d" % seed] = degrade_identity_evidence(
                numeric,
                seed=seed + 70000,
                authority_ref=SELF_SUPERVISED_AUDIT_AUTHORITY_REF,
                exposure_stage=materialization_stage,
            )
            registries["relational-%d" % seed] = degrade_identity_evidence(
                relational,
                seed=seed + 80000,
                authority_ref=SELF_SUPERVISED_AUDIT_AUTHORITY_REF,
                exposure_stage=materialization_stage,
            )
        mixed_seed = self._seeds[0] + 90000
        mixed_tasks = [
            *LatentObjectAuditAuthority._numeric_tasks(mixed_seed, 8),
            *LatentObjectAuditAuthority._relational_tasks(mixed_seed + 1, 8),
        ]
        random.Random(mixed_seed + 2).shuffle(mixed_tasks)
        mixed = build_latent_registry(
            partition="causal_audit",
            tasks=tuple(mixed_tasks),
            authority_ref=SELF_SUPERVISED_AUDIT_AUTHORITY_REF,
            exposure_stage=materialization_stage,
            seed=mixed_seed + 3,
        )
        causal = degrade_identity_evidence(
            mixed,
            seed=mixed_seed + 4,
            authority_ref=SELF_SUPERVISED_AUDIT_AUTHORITY_REF,
            exposure_stage=materialization_stage,
        )
        self._materialized = True
        return SelfSupervisedAuditMaterialization(
            commitment=self.commitment,
            candidate_freeze_id=candidate_freeze.freeze_id,
            registries=registries,
            causal_registry=causal,
            materialization_stage=materialization_stage,
        )

    def verify_commitment(
        self, materialization: SelfSupervisedAuditMaterialization
    ) -> bool:
        return (
            materialization.commitment == self.commitment
            and self.commitment.sealed_spec_digest
            == content_digest(self._sealed_spec)
        )
