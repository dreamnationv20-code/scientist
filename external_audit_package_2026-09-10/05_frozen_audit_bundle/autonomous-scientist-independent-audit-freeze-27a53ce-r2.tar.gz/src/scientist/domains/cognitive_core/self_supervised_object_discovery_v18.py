from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    ADDRESS_FEATURE_NAMES,
    CausalAddressIntervention,
    LatentAddressModel,
    LatentCoreFreeze,
    LatentEvaluation,
    LatentEvent,
    LatentEventKind,
    LatentObjectAuditTrial,
    LatentObjectRuntime,
    LatentRegistry,
    address_features,
    build_latent_development_registry,
    evaluate_latent_runtime,
    run_latent_object_audit,
)


SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION = (
    "cognitive-core-self-supervised-object-discovery-v18"
)
EVIDENCE_MODES = ("full", "partial", "noisy", "consequence_only")


@dataclass(frozen=True)
class CandidateVisibleEventStream:
    events: Tuple[LatentEvent, ...]
    registry_id: str

    @property
    def stream_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
            "events": [event.as_dict() for event in self.events],
            "registry_id": self.registry_id,
        }
        if include_id:
            value["stream_id"] = self.stream_id
        return value


@dataclass(frozen=True)
class SelfSupervisedRegistry:
    registry: LatentRegistry
    evidence_mode_by_event_id: Mapping[str, str]
    source_registry_id: str
    transformation_rule: str

    @property
    def registry_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def candidate_stream(self) -> CandidateVisibleEventStream:
        return CandidateVisibleEventStream(
            events=self.registry.events,
            registry_id=self.registry.registry_id,
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
            "registry": self.registry.as_dict(),
            "evidence_mode_by_event_id": dict(
                sorted(self.evidence_mode_by_event_id.items())
            ),
            "source_registry_id": self.source_registry_id,
            "transformation_rule": self.transformation_rule,
        }
        if include_id:
            value["self_supervised_registry_id"] = self.registry_id
        return value


def _corrupt_output(value: Any, randomizer: random.Random) -> Any:
    if isinstance(value, int):
        return value + 1000 + randomizer.randrange(1, 100)
    return "%s-noise-%08x" % (value, randomizer.getrandbits(32))


def degrade_identity_evidence(
    registry: LatentRegistry,
    *,
    seed: int,
    authority_ref: str,
    exposure_stage: int,
) -> SelfSupervisedRegistry:
    randomizer = random.Random(seed)
    tasks = {item.task_ref: item for item in registry.tasks}
    transformed = []
    modes: Dict[str, str] = {}
    non_discovery_index = 0
    for event in registry.events:
        if event.kind == LatentEventKind.DISCOVER:
            transformed.append(event)
            modes[event.event_id] = "creation"
            continue
        object_ref = registry.event_object_refs[event.event_id]
        task = tasks[object_ref]
        proposed = EVIDENCE_MODES[non_discovery_index % len(EVIDENCE_MODES)]
        non_discovery_index += 1
        locators = list(event.payload.get("locators", ()))
        if proposed == "consequence_only":
            consequence_available = (
                event.kind == LatentEventKind.UPDATE
                or (
                    event.kind in (LatentEventKind.QUERY, LatentEventKind.SELECT)
                    and "relational" in task.evaluator_family
                )
            )
            mode = "consequence_only" if consequence_available else "partial"
        else:
            mode = proposed
        payload = dict(event.payload)
        if mode == "partial":
            keep = max(1, len(locators) // 2)
            payload["locators"] = locators[:keep]
        elif mode == "noisy":
            if locators:
                source = dict(locators[-1])
                source["output"] = _corrupt_output(
                    source["output"], randomizer
                )
                payload["locators"] = [*locators, source]
        elif mode == "consequence_only":
            payload["locators"] = []
        transformed.append(
            LatentEvent(
                event_id=event.event_id,
                kind=event.kind,
                alias=event.alias,
                payload=payload,
            )
        )
        modes[event.event_id] = mode
    revised = LatentRegistry(
        partition=registry.partition,
        tasks=registry.tasks,
        events=tuple(transformed),
        probes=registry.probes,
        event_object_refs=registry.event_object_refs,
        discovery_object_refs=registry.discovery_object_refs,
        authority_ref=authority_ref,
        exposure_stage=exposure_stage,
        seed=seed,
    )
    return SelfSupervisedRegistry(
        registry=revised,
        evidence_mode_by_event_id=modes,
        source_registry_id=registry.registry_id,
        transformation_rule=(
            "deterministically rotate full, partial, noisy, and consequence-only "
            "evidence without adding any candidate-visible identity"
        ),
    )


@dataclass(frozen=True)
class UnlabeledAssignmentDecision:
    event_id: str
    chosen_slot_id: str
    consequence_cost_by_slot: Mapping[str, float]
    feature_rows_by_slot: Mapping[str, Mapping[str, float]]
    ambiguity_margin: float

    def as_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "chosen_slot_id": self.chosen_slot_id,
            "consequence_cost_by_slot": dict(
                sorted(self.consequence_cost_by_slot.items())
            ),
            "feature_rows_by_slot": {
                key: dict(sorted(value.items()))
                for key, value in sorted(self.feature_rows_by_slot.items())
            },
            "ambiguity_margin": self.ambiguity_margin,
        }


@dataclass(frozen=True)
class SelfSupervisedTrainingTrace:
    development_registry_id: str
    exposed_event_ids: Tuple[str, ...]
    decisions: Tuple[UnlabeledAssignmentDecision, ...]
    feature_names: Tuple[str, ...]
    objective: str
    forbidden_information: Tuple[str, ...]

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
            "development_registry_id": self.development_registry_id,
            "exposed_event_ids": list(self.exposed_event_ids),
            "decisions": [item.as_dict() for item in self.decisions],
            "feature_names": list(self.feature_names),
            "objective": self.objective,
            "forbidden_information": list(self.forbidden_information),
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


def _consequence_cost(
    event: LatentEvent, features: Mapping[str, float]
) -> float:
    locators_present = bool(event.payload.get("locators", ()))
    cost = 0.0
    if locators_present:
        cost += 3.0 * (1.0 - features["locator_fit"])
        cost += 1.0 * (1.0 - features["locator_coverage"])
    if event.kind == LatentEventKind.UPDATE:
        cost += 3.0 * (1.0 - features["mutation_feasible"])
    if event.kind in (LatentEventKind.QUERY, LatentEventKind.SELECT):
        cost += 2.0 * (1.0 - features["query_executable"])
    if not locators_present:
        cost += 0.05 * (1.0 - features["recency"])
    return cost


def induce_unlabeled_training_trace(
    stream: CandidateVisibleEventStream,
) -> SelfSupervisedTrainingTrace:
    # The runtime is forced only by self-consistency costs computed from
    # candidate-visible prediction and intervention consequences.
    provisional = LatentAddressModel(
        feature_names=ADDRESS_FEATURE_NAMES,
        weights=tuple(0.0 for _ in ADDRESS_FEATURE_NAMES),
        training_set_id="unlabeled-provisional",
        training_steps=0,
        learning_rate=0.0,
    )
    runtime = LatentObjectRuntime(address_mode="learned", model=provisional)
    decisions = []
    exposed = []
    for event in stream.events:
        if event.kind != LatentEventKind.DISCOVER:
            rows = runtime.feature_rows(event)
            costs = {
                slot_id: _consequence_cost(event, features)
                for slot_id, features in rows.items()
            }
            ordered = sorted(
                costs,
                key=lambda slot_id: (
                    costs[slot_id],
                    -rows[slot_id]["locator_fit"],
                    -rows[slot_id]["mutation_feasible"],
                    -rows[slot_id]["query_executable"],
                    slot_id,
                ),
            )
            chosen = ordered[0]
            margin = (
                costs[ordered[1]] - costs[ordered[0]]
                if len(ordered) > 1
                else float("inf")
            )
            runtime.forced_slots[event.event_id] = chosen
            decisions.append(
                UnlabeledAssignmentDecision(
                    event_id=event.event_id,
                    chosen_slot_id=chosen,
                    consequence_cost_by_slot=costs,
                    feature_rows_by_slot=rows,
                    ambiguity_margin=margin,
                )
            )
            exposed.append(event.event_id)
        runtime.act(event)
    return SelfSupervisedTrainingTrace(
        development_registry_id=stream.registry_id,
        exposed_event_ids=tuple(exposed),
        decisions=tuple(decisions),
        feature_names=ADDRESS_FEATURE_NAMES,
        objective=(
            "minimize prediction inconsistency, undefined execution, and "
            "unrealizable intervention consequences without object labels"
        ),
        forbidden_information=(
            "evaluator object references",
            "co-reference labels",
            "probe expected actions",
            "hidden audit events",
        ),
    )


@dataclass(frozen=True)
class SelfSupervisedAddressModel:
    feature_names: Tuple[str, ...]
    weights: Tuple[float, ...]
    training_trace_id: str
    training_steps: int
    learning_rate: float

    @property
    def model_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def score(self, features: Mapping[str, float]) -> float:
        return sum(
            weight * float(features[name])
            for name, weight in zip(self.feature_names, self.weights)
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
            "feature_names": list(self.feature_names),
            "weights": list(self.weights),
            "training_trace_id": self.training_trace_id,
            "training_steps": self.training_steps,
            "learning_rate": self.learning_rate,
            "parameter_count": len(self.weights),
        }
        if include_id:
            value["model_id"] = self.model_id
        return value


def train_self_supervised_address_model(
    trace: SelfSupervisedTrainingTrace,
    *,
    steps: int = 800,
    learning_rate: float = 0.15,
) -> SelfSupervisedAddressModel:
    names = trace.feature_names
    pairs = []
    for decision in trace.decisions:
        chosen = decision.feature_rows_by_slot[decision.chosen_slot_id]
        for slot_id, alternative in decision.feature_rows_by_slot.items():
            if slot_id == decision.chosen_slot_id:
                continue
            if (
                decision.consequence_cost_by_slot[slot_id]
                <= decision.consequence_cost_by_slot[decision.chosen_slot_id]
            ):
                continue
            pairs.append(
                [chosen[name] - alternative[name] for name in names]
            )
    if not pairs:
        raise ValueError("self-supervised trace contains no ranked consequences")
    weights = [0.0 for _ in names]
    for _ in range(steps):
        gradient = [0.0 for _ in names]
        for delta in pairs:
            margin = sum(weight * value for weight, value in zip(weights, delta))
            scale = 1.0 / (1.0 + math.exp(min(40.0, max(-40.0, margin))))
            for index, value in enumerate(delta):
                gradient[index] -= scale * value
        for index in range(len(weights)):
            gradient[index] = gradient[index] / len(pairs) + 0.001 * weights[index]
            weights[index] -= learning_rate * gradient[index]
    return SelfSupervisedAddressModel(
        feature_names=names,
        weights=tuple(round(item, 12) for item in weights),
        training_trace_id=trace.trace_id,
        training_steps=steps,
        learning_rate=learning_rate,
    )


@dataclass(frozen=True)
class SelfSupervisedCoreFreeze:
    model: SelfSupervisedAddressModel
    training_trace_id: str
    development_registry_id: str
    development_evaluation_id: str
    interpreter_source_digest: str
    freeze_stage: int

    @property
    def executable_digest(self) -> str:
        return content_digest(
            {
                "model": self.model.as_dict(),
                "interpreter_source_digest": self.interpreter_source_digest,
            }
        )

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
            "model": self.model.as_dict(),
            "training_trace_id": self.training_trace_id,
            "development_registry_id": self.development_registry_id,
            "development_evaluation_id": self.development_evaluation_id,
            "interpreter_source_digest": self.interpreter_source_digest,
            "executable_digest": self.executable_digest,
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_self_supervised_core(
    *,
    model: SelfSupervisedAddressModel,
    trace: SelfSupervisedTrainingTrace,
    development_evaluation: LatentEvaluation,
    interpreter_source_digest: str,
    freeze_stage: int = 4,
) -> SelfSupervisedCoreFreeze:
    if model.training_trace_id != trace.trace_id:
        raise ValueError("model and unlabeled trace identities differ")
    if development_evaluation.model_id != model.model_id:
        raise ValueError("development evaluation used another model")
    if development_evaluation.joint_score < 0.95:
        raise ValueError("self-supervised model did not clear development floor")
    return SelfSupervisedCoreFreeze(
        model=model,
        training_trace_id=trace.trace_id,
        development_registry_id=trace.development_registry_id,
        development_evaluation_id=development_evaluation.evaluation_id,
        interpreter_source_digest=interpreter_source_digest,
        freeze_stage=freeze_stage,
    )


def build_self_supervised_development_registry() -> SelfSupervisedRegistry:
    source = build_latent_development_registry()
    return degrade_identity_evidence(
        source,
        seed=1801,
        authority_ref="self-supervised-development-authority-v18",
        exposure_stage=1,
    )


@dataclass(frozen=True)
class SelfSupervisedAuditTrial:
    base_trial: LatentObjectAuditTrial
    evidence_mode_scores: Mapping[str, float]
    supervised_reference_scores: Mapping[str, float]
    self_supervised_mean_score: float
    supervised_mean_score: float
    check_results: Mapping[str, bool]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return self.base_trial.passed and all(self.check_results.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_OBJECT_DISCOVERY_VERSION,
            "base_trial": self.base_trial.as_dict(),
            "evidence_mode_scores": dict(sorted(self.evidence_mode_scores.items())),
            "supervised_reference_scores": dict(
                sorted(self.supervised_reference_scores.items())
            ),
            "self_supervised_mean_score": self.self_supervised_mean_score,
            "supervised_mean_score": self.supervised_mean_score,
            "check_results": dict(sorted(self.check_results.items())),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def run_self_supervised_audit(
    *,
    candidate_freeze: SelfSupervisedCoreFreeze,
    audit_commitment_id: str,
    audit_materialization_id: str,
    registries: Mapping[str, SelfSupervisedRegistry],
    causal_registry: SelfSupervisedRegistry,
    materialization_stage: int,
    supervised_reference_model: LatentAddressModel,
) -> SelfSupervisedAuditTrial:
    plain = {key: item.registry for key, item in registries.items()}
    base_trial = run_latent_object_audit(
        candidate_freeze=candidate_freeze,  # type: ignore[arg-type]
        audit_commitment_id=audit_commitment_id,
        audit_materialization_id=audit_materialization_id,
        registries=plain,
        causal_registry=causal_registry.registry,
        materialization_stage=materialization_stage,
    )
    mode_outcomes: Dict[str, list[bool]] = {mode: [] for mode in EVIDENCE_MODES}
    for key, evaluation in base_trial.candidate_evaluations.items():
        modes = registries[key].evidence_mode_by_event_id
        for outcome in evaluation.outcomes:
            mode = modes[outcome.probe.event_id]
            if mode in mode_outcomes:
                mode_outcomes[mode].append(outcome.passed)
    mode_scores = {
        mode: sum(values) / len(values)
        for mode, values in mode_outcomes.items()
        if values
    }
    supervised = {
        key: evaluate_latent_runtime(
            item.registry,
            address_mode="learned",
            model=supervised_reference_model,
        )[0].joint_score
        for key, item in registries.items()
    }
    candidate_scores = tuple(
        item.joint_score for item in base_trial.candidate_evaluations.values()
    )
    self_mean = sum(candidate_scores) / len(candidate_scores)
    supervised_mean = sum(supervised.values()) / len(supervised)
    checks = {
        "all_identity_evidence_modes_are_exercised": (
            set(mode_scores) == set(EVIDENCE_MODES)
        ),
        "every_identity_evidence_mode_clears_floor": all(
            value >= 0.95 for value in mode_scores.values()
        ),
        "self_supervised_model_is_within_five_points_of_supervised_reference": (
            self_mean >= supervised_mean - 0.05
        ),
        "self_supervised_candidate_clears_every_hidden_registry": (
            min(candidate_scores) >= 0.95
        ),
    }
    return SelfSupervisedAuditTrial(
        base_trial=base_trial,
        evidence_mode_scores=mode_scores,
        supervised_reference_scores=supervised,
        self_supervised_mean_score=self_mean,
        supervised_mean_score=supervised_mean,
        check_results=checks,
        limitations=(
            "Training uses no object labels, but its inconsistency objective and generic compatibility measurements are engineered.",
            "Consequence-only cases remain information-bearing through executable queries or desired intervention outcomes.",
            "Typed executable schemas and mutation search remain frozen symbolic infrastructure.",
            "The experiment does not yet learn object features directly from natural language, code, or pixels.",
        ),
    )
