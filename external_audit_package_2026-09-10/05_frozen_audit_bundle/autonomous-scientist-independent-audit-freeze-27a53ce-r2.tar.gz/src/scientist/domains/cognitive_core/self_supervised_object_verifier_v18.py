from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.latent_object_formation_verifier_v17 import (
    _independent_actions,
)
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    LatentEvaluation,
    LatentEventKind,
    LatentRegistry,
)
from scientist.domains.cognitive_core.self_supervised_audit_authority_v18 import (
    SelfSupervisedAuditMaterialization,
)
from scientist.domains.cognitive_core.self_supervised_object_discovery_v18 import (
    EVIDENCE_MODES,
    SelfSupervisedAuditTrial,
    SelfSupervisedCoreFreeze,
    SelfSupervisedRegistry,
    SelfSupervisedTrainingTrace,
)
from scientist.program.control_plane import AutonomousScientistControlPlane


SELF_SUPERVISED_OBJECT_VERIFIER_REF = (
    "cognitive-core-self-supervised-object-independent-verifier-v18"
)


@dataclass(frozen=True)
class SelfSupervisedObjectVerification:
    check_results: Mapping[str, bool]
    cognitive_core_criteria: Mapping[str, bool]
    independent_match_rates: Mapping[str, float]
    supported_claim: str
    rejected_claims: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str = SELF_SUPERVISED_OBJECT_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def self_supervised_object_milestone_demonstrated(self) -> bool:
        required = (
            "co_reference_labels_are_absent_from_training",
            "assignment_is_induced_from_candidate_visible_consequences",
            "degraded_identity_modes_transfer_across_five_seeds",
            "persistent_objects_survive_lag_64",
            "addressing_has_selective_causal_effect",
        )
        return all(self.cognitive_core_criteria[item] for item in required)

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "cognitive_core_criteria": dict(
                sorted(self.cognitive_core_criteria.items())
            ),
            "independent_match_rates": dict(
                sorted(self.independent_match_rates.items())
            ),
            "self_supervised_object_milestone_demonstrated": (
                self.self_supervised_object_milestone_demonstrated
            ),
            "supported_claim": self.supported_claim,
            "rejected_claims": list(self.rejected_claims),
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def _all_decisions_minimize_declared_cost(
    trace: SelfSupervisedTrainingTrace,
) -> bool:
    return bool(trace.decisions) and all(
        decision.consequence_cost_by_slot[decision.chosen_slot_id]
        == min(decision.consequence_cost_by_slot.values())
        for decision in trace.decisions
    )


def _independent_joint_rate(
    registry: LatentRegistry, evaluation: LatentEvaluation
) -> float:
    expected_actions = _independent_actions(registry)
    expected_slots = {}
    slot_index = 0
    for event in registry.events:
        if event.kind != LatentEventKind.DISCOVER:
            continue
        expected_slots[registry.discovery_object_refs[event.event_id]] = (
            "slot-%04d" % slot_index
        )
        slot_index += 1
    return sum(
        outcome.observed == expected_actions[outcome.probe.event_id]
        and outcome.resolved_slot_id
        == expected_slots[outcome.probe.evaluator_object_ref]
        for outcome in evaluation.outcomes
    ) / len(evaluation.outcomes)


def verify_self_supervised_object_discovery(
    *,
    control: AutonomousScientistControlPlane,
    development_registry: SelfSupervisedRegistry,
    training_trace: SelfSupervisedTrainingTrace,
    candidate_freeze: SelfSupervisedCoreFreeze,
    materialization: SelfSupervisedAuditMaterialization,
    trial: SelfSupervisedAuditTrial,
    artifact_round_trip_checks: Mapping[str, bool],
) -> SelfSupervisedObjectVerification:
    trace_text = json.dumps(training_trace.as_dict(), sort_keys=True).lower()
    visible_event_text = json.dumps(
        [event.as_dict() for event in development_registry.registry.events],
        sort_keys=True,
    ).lower()
    hidden_event_ids = {
        event.event_id
        for item in materialization.registries.values()
        for event in item.registry.events
    }
    match_rates = {
        key: _independent_joint_rate(
            materialization.registries[key].registry, evaluation
        )
        for key, evaluation in trial.base_trial.candidate_evaluations.items()
    }
    progress = control.graph.progress_by_role()["objective"]
    forbidden_trace_tokens = (
        "evaluator_object_ref",
        "event_object_refs",
        "co_reference_label",
        "probe_expected_action",
        "task_ref",
        "evaluator_family",
        "update_address",
    )
    checks = {
        "all_artifacts_round_trip_exactly": (
            bool(artifact_round_trip_checks)
            and all(artifact_round_trip_checks.values())
        ),
        "candidate_visible_events_lack_explicit_addresses": all(
            token not in visible_event_text
            for token in (
                "task_ref",
                "object_ref",
                "update_address",
                "evaluator_family",
            )
        ),
        "training_trace_contains_no_evaluator_identity_or_answer_labels": all(
            token not in trace_text for token in forbidden_trace_tokens
        ),
        "every_pseudo_label_minimizes_declared_visible_consequence_cost": (
            _all_decisions_minimize_declared_cost(training_trace)
        ),
        "model_is_bound_only_to_unlabeled_development_trace": (
            candidate_freeze.model.training_trace_id == training_trace.trace_id
            and candidate_freeze.training_trace_id == training_trace.trace_id
            and training_trace.development_registry_id
            == development_registry.registry.registry_id
            and not hidden_event_ids.intersection(
                training_trace.exposed_event_ids
            )
        ),
        "audit_materialized_after_frozen_model": (
            candidate_freeze.freeze_stage < materialization.materialization_stage
            and materialization.candidate_freeze_id == candidate_freeze.freeze_id
            and trial.base_trial.candidate_freeze.freeze_id
            == candidate_freeze.freeze_id
        ),
        "all_preregistered_audit_checks_pass": trial.passed,
        "all_four_degraded_identity_modes_clear_floor": (
            set(trial.evidence_mode_scores) == set(EVIDENCE_MODES)
            and all(value >= 0.95 for value in trial.evidence_mode_scores.values())
        ),
        "independent_reconstruction_confirms_every_reported_hidden_score": all(
            math.isclose(
                match_rates[key], evaluation.joint_score, abs_tol=1e-12
            )
            for key, evaluation in trial.base_trial.candidate_evaluations.items()
        ),
        "causal_swap_changes_only_the_two_target_addresses": (
            trial.base_trial.causal_intervention.passed
            and set(trial.base_trial.causal_intervention.changed_probe_ids)
            == set(trial.base_trial.causal_intervention.target_probe_ids)
        ),
        "objective_graph_is_not_advanced_by_microdomain_evidence": (
            progress["integrated"] == 0
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    criteria = {
        "co_reference_labels_are_absent_from_training": checks[
            "training_trace_contains_no_evaluator_identity_or_answer_labels"
        ],
        "assignment_is_induced_from_candidate_visible_consequences": (
            checks[
                "every_pseudo_label_minimizes_declared_visible_consequence_cost"
            ]
            and candidate_freeze.model.training_steps > 0
            and candidate_freeze.model.weights
            != tuple(0.0 for _ in candidate_freeze.model.weights)
        ),
        "degraded_identity_modes_transfer_across_five_seeds": (
            checks["all_four_degraded_identity_modes_clear_floor"]
            and trial.base_trial.check_results[
                "five_disjoint_seeds_per_hidden_family"
            ]
            and trial.base_trial.check_results[
                "both_hidden_families_clear_floor"
            ]
        ),
        "persistent_objects_survive_lag_64": (
            trial.base_trial.aggregate_horizon_scores.get("64", 0.0) >= 0.95
        ),
        "addressing_has_selective_causal_effect": checks[
            "causal_swap_changes_only_the_two_target_addresses"
        ],
        "generic_feature_vocabulary_is_learned_from_raw_data": False,
        "executable_schema_induction_is_self_supervised": False,
        "naturalistic_language_or_code_transfer_is_demonstrated": False,
        "general_cognitive_core_is_demonstrated": False,
    }
    return SelfSupervisedObjectVerification(
        check_results=checks,
        cognitive_core_criteria=criteria,
        independent_match_rates=match_rates,
        supported_claim=(
            "A routing model induced latent-object assignments without evaluator "
            "co-reference labels, using only candidate-visible prediction and "
            "intervention consistency, and transferred across four identity-evidence "
            "conditions, two task families, five sealed seeds, and lag-64 audits."
        ),
        rejected_claims=(
            "the full cognitive core is solved",
            "object representations emerged directly from unrestricted raw data",
            "the generic compatibility feature vocabulary was learned",
            "typed executable schemas were learned self-supervised",
            "the result transfers to natural language, code, or external tasks",
        ),
        limitations=(
            "The consequence objective and eight generic compatibility features are engineered.",
            "Consequence-only events still expose executable query or intervention outcomes.",
            "Typed program induction and mutation search remain frozen symbolic infrastructure.",
            "All current replications are local and procedurally generated.",
        ),
    )
