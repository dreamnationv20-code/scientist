from __future__ import annotations

import itertools
from dataclasses import dataclass, replace
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.autonomous_concept_synthesis_v16 import (
    KnowledgeRow,
    MetaExample,
)
from scientist.domains.cognitive_core.behavioral_predicate_discovery_v19 import (
    BehavioralPredicateProgram,
    DiscoveredPredicateModel,
)
from scientist.domains.cognitive_core.latent_object_formation_v17 import (
    CausalAddressIntervention,
    LatentAction,
    LatentActionKind,
    LatentEvaluation,
    LatentEvent,
    LatentEventKind,
    LatentProbeOutcome,
    LatentRegistry,
    LatentStep,
    _decode_examples,
    _decode_rows,
    evaluate_latent_runtime,
)
from scientist.domains.cognitive_core.self_supervised_object_discovery_v18 import (
    EVIDENCE_MODES,
    SelfSupervisedRegistry,
)


SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION = (
    "cognitive-core-self-supervised-schema-induction-v20"
)


def _encode_argument(value: Any) -> Any:
    if isinstance(value, SchemaNode):
        return value.as_dict(include_id=False)
    if isinstance(value, tuple):
        return [_encode_argument(item) for item in value]
    return value


@dataclass(frozen=True)
class SchemaNode:
    operator: str
    arguments: Tuple[Any, ...]

    @property
    def node_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def complexity(self) -> int:
        return 1 + sum(
            item.complexity for item in self.arguments if isinstance(item, SchemaNode)
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "operator": self.operator,
            "arguments": [_encode_argument(item) for item in self.arguments],
            "complexity": self.complexity,
        }
        if include_id:
            value["node_id"] = self.node_id
        return value


def literal(value: Any, *, mutable: bool = True) -> SchemaNode:
    return SchemaNode("literal", (value, mutable))


INPUT_NODE = SchemaNode("input", ())


@dataclass(frozen=True)
class UniversalSchemaGrammar:
    operators: Tuple[str, ...] = (
        "input",
        "literal",
        "add",
        "multiply",
        "modulo",
        "follow",
        "pair",
        "lookup",
    )
    maximum_arithmetic_order: int = 2
    maximum_follow_depth: int = 3
    maximum_integer_atom: int = 64
    selection_rule: str = (
        "minimum-complexity unique behaviorally consistent AST"
    )

    @property
    def grammar_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION,
            "operators": list(self.operators),
            "maximum_arithmetic_order": self.maximum_arithmetic_order,
            "maximum_follow_depth": self.maximum_follow_depth,
            "maximum_integer_atom": self.maximum_integer_atom,
            "selection_rule": self.selection_rule,
        }
        if include_id:
            value["grammar_id"] = self.grammar_id
        return value


def _evaluate_node(
    node: SchemaNode,
    input_value: Any,
    context: Sequence[KnowledgeRow],
) -> Tuple[Any | None, Tuple[str, ...]]:
    op = node.operator
    if op == "input":
        return input_value, ()
    if op == "literal":
        return node.arguments[0], ()
    if op in ("add", "multiply"):
        left, left_rows = _evaluate_node(node.arguments[0], input_value, context)
        right, right_rows = _evaluate_node(node.arguments[1], input_value, context)
        if not isinstance(left, int) or not isinstance(right, int):
            return None, ()
        value = left + right if op == "add" else left * right
        return value, (*left_rows, *right_rows)
    if op == "modulo":
        value, used = _evaluate_node(node.arguments[0], input_value, context)
        modulus, _ = _evaluate_node(node.arguments[1], input_value, context)
        if not isinstance(value, int) or not isinstance(modulus, int) or modulus <= 1:
            return None, ()
        return value % modulus, used
    if op == "follow":
        current, used = _evaluate_node(node.arguments[0], input_value, context)
        relation, _ = _evaluate_node(node.arguments[1], input_value, context)
        matches = [
            row
            for row in context
            if len(row.cells) == 3
            and row.cells[0] == current
            and row.cells[1] == relation
        ]
        if len(matches) != 1:
            return None, ()
        return matches[0].cells[2], (*used, matches[0].row_id)
    if op == "lookup":
        key, _ = _evaluate_node(node.arguments[0], input_value, context)
        matches = []
        for pair in node.arguments[1:]:
            pair_key, _ = _evaluate_node(pair.arguments[0], input_value, context)
            pair_value, _ = _evaluate_node(pair.arguments[1], input_value, context)
            if key == pair_key:
                matches.append(pair_value)
        return (matches[0], ()) if len(matches) == 1 else (None, ())
    return None, ()


def execute_schema(
    node: SchemaNode,
    inputs: Sequence[Any],
    context: Sequence[KnowledgeRow],
) -> Tuple[Any | None, Tuple[str, ...]]:
    if len(inputs) != 1:
        return None, ()
    try:
        return _evaluate_node(node, inputs[0], context)
    except (KeyError, TypeError, ValueError):
        return None, ()


def _horner_ast(coefficients: Sequence[int], modulus: int) -> SchemaNode:
    value = literal(int(coefficients[-1]))
    for coefficient in reversed(coefficients[:-1]):
        value = SchemaNode(
            "add",
            (
                literal(int(coefficient)),
                SchemaNode("multiply", (INPUT_NODE, value)),
            ),
        )
    return SchemaNode(
        "modulo", (value, literal(int(modulus), mutable=False))
    )


def _relation_ast(relations: Sequence[Any]) -> SchemaNode:
    value = INPUT_NODE
    for relation in relations:
        value = SchemaNode(
            "follow", (value, literal(relation, mutable=False))
        )
    return value


def _lookup_ast(examples: Sequence[MetaExample]) -> SchemaNode:
    return SchemaNode(
        "lookup",
        (
            INPUT_NODE,
            *(
                SchemaNode(
                    "pair",
                    (
                        literal(item.inputs[0], mutable=False),
                        literal(item.output),
                    ),
                )
                for item in examples
            ),
        ),
    )


@dataclass(frozen=True)
class SchemaCandidateSet:
    candidates: Tuple[SchemaNode, ...]
    fitting: Tuple[SchemaNode, ...]
    selected: SchemaNode | None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_count": len(self.candidates),
            "fitting_count": len(self.fitting),
            "selected": None if self.selected is None else self.selected.as_dict(),
            "minimum_fitting_complexity": (
                None
                if not self.fitting
                else min(item.complexity for item in self.fitting)
            ),
        }


def synthesize_schema(
    examples: Sequence[MetaExample],
    context: Sequence[KnowledgeRow],
    metadata: Mapping[str, Any],
    grammar: UniversalSchemaGrammar,
) -> SchemaCandidateSet:
    if not examples or any(len(item.inputs) != 1 for item in examples):
        return SchemaCandidateSet((), (), None)
    candidates = [_lookup_ast(examples)]
    integer_atoms = sorted(
        {
            int(value)
            for value in metadata.values()
            if isinstance(value, int)
            and 1 < value <= grammar.maximum_integer_atom
        }
    )
    for modulus in integer_atoms:
        for order in range(grammar.maximum_arithmetic_order + 1):
            candidates.extend(
                _horner_ast(coefficients, modulus)
                for coefficients in itertools.product(
                    range(modulus), repeat=order + 1
                )
            )
    relation_atoms = sorted(
        {row.cells[1] for row in context if len(row.cells) == 3}, key=str
    )
    for depth in range(1, grammar.maximum_follow_depth + 1):
        candidates.extend(
            _relation_ast(path)
            for path in itertools.product(relation_atoms, repeat=depth)
        )
    unique = {item.node_id: item for item in candidates}
    candidate_rows = tuple(unique[key] for key in sorted(unique))
    fitting = tuple(
        item
        for item in candidate_rows
        if all(
            execute_schema(item, example.inputs, context)[0] == example.output
            for example in examples
        )
    )
    if not fitting:
        selected = None
    else:
        minimum = min(item.complexity for item in fitting)
        finalists = tuple(item for item in fitting if item.complexity == minimum)
        selected = finalists[0] if len(finalists) == 1 else None
    return SchemaCandidateSet(candidate_rows, fitting, selected)


def _walk_literals(
    node: SchemaNode, path: Tuple[int, ...] = ()
) -> Iterable[Tuple[Tuple[int, ...], Any]]:
    if node.operator == "literal":
        if len(node.arguments) < 2 or bool(node.arguments[1]):
            yield path, node.arguments[0]
        return
    for index, argument in enumerate(node.arguments):
        if isinstance(argument, SchemaNode):
            yield from _walk_literals(argument, (*path, index))


def _replace_literal(
    node: SchemaNode, path: Tuple[int, ...], value: Any
) -> SchemaNode:
    if not path:
        if node.operator != "literal":
            raise ValueError("literal replacement path is invalid")
        return literal(value)
    index = path[0]
    arguments = list(node.arguments)
    child = arguments[index]
    if not isinstance(child, SchemaNode):
        raise ValueError("literal replacement crossed a non-node argument")
    arguments[index] = _replace_literal(child, path[1:], value)
    return SchemaNode(node.operator, tuple(arguments))


@dataclass
class SchemaObject:
    slot_id: str
    schema: SchemaNode
    examples: Tuple[MetaExample, ...]
    context: Tuple[KnowledgeRow, ...]
    metadata: Mapping[str, Any]
    aliases: Tuple[str, ...]
    created_at: int
    last_touched: int


@dataclass(frozen=True)
class GenericRepairResult:
    schema: SchemaNode
    context: Tuple[KnowledgeRow, ...]
    fitting_edit_count: int
    edits_considered: int


def _repair_atoms(
    obj: SchemaObject,
    desired: Sequence[MetaExample],
    grammar: UniversalSchemaGrammar,
) -> Tuple[Any, ...]:
    atoms = {value for _, value in _walk_literals(obj.schema)}
    for item in desired:
        atoms.update(item.inputs)
        try:
            atoms.add(item.output)
        except TypeError:
            pass
    # Replacement atoms come from the requested behavior. Existing context
    # strings are deliberately not exhaustively recycled: that would turn a
    # one-edit search into a quadratic vocabulary scan without adding evidence
    # about the desired consequence.
    desired_atoms = {
        atom
        for item in desired
        for atom in (*item.inputs, item.output)
        if isinstance(atom, (int, str))
    }
    atoms = {
        atom
        for atom in atoms
        if isinstance(atom, int)
    } | desired_atoms
    integer_limits = [
        int(value)
        for value in obj.metadata.values()
        if isinstance(value, int)
        and 1 < value <= grammar.maximum_integer_atom
    ]
    if integer_limits:
        atoms.update(range(max(integer_limits)))
    return tuple(sorted(atoms, key=lambda item: (type(item).__name__, str(item))))


def repair_schema_from_behavior(
    obj: SchemaObject,
    desired: Sequence[MetaExample],
    grammar: UniversalSchemaGrammar,
) -> GenericRepairResult | None:
    if not desired:
        return None
    atoms = _repair_atoms(obj, desired, grammar)
    candidates: Dict[str, Tuple[SchemaNode, Tuple[KnowledgeRow, ...]]] = {}
    considered = 0
    for path, old_value in _walk_literals(obj.schema):
        for value in atoms:
            if value == old_value or type(value) is not type(old_value):
                continue
            considered += 1
            revised = _replace_literal(obj.schema, path, value)
            if all(
                execute_schema(revised, item.inputs, obj.context)[0] == item.output
                for item in desired
            ):
                key = content_digest(
                    {
                        "schema": revised.as_dict(),
                        "context": [row.as_dict() for row in obj.context],
                    }
                )
                candidates[key] = (revised, obj.context)
    for row_index, row in enumerate(obj.context):
        for cell_index, old_value in enumerate(row.cells):
            for value in atoms:
                if value == old_value or type(value) is not type(old_value):
                    continue
                considered += 1
                revised_rows = list(obj.context)
                revised_cells = list(row.cells)
                revised_cells[cell_index] = value
                revised_rows[row_index] = KnowledgeRow(row.row_id, tuple(revised_cells))
                revised_context = tuple(revised_rows)
                if all(
                    execute_schema(obj.schema, item.inputs, revised_context)[0]
                    == item.output
                    for item in desired
                ):
                    key = content_digest(
                        {
                            "schema": obj.schema.as_dict(),
                            "context": [item.as_dict() for item in revised_context],
                        }
                    )
                    candidates[key] = (obj.schema, revised_context)
    if len(candidates) != 1:
        return None
    schema, context = next(iter(candidates.values()))
    return GenericRepairResult(schema, context, len(candidates), considered)


def evaluate_schema_predicate(
    program: BehavioralPredicateProgram,
    event: LatentEvent,
    obj: SchemaObject,
    sequence: int,
    grammar: UniversalSchemaGrammar,
) -> float:
    op = program.operator
    arguments = program.arguments
    if op == "constant":
        return float(arguments["value"])
    if op == "replay_reduce":
        examples = _decode_examples(event.payload.get(arguments["source"], ()))
        if not examples:
            return 0.0
        predictions = tuple(
            execute_schema(obj.schema, item.inputs, obj.context)[0]
            for item in examples
        )
        values = (
            tuple(
                prediction == item.output
                for prediction, item in zip(predictions, examples)
            )
            if arguments["test"] == "equals_observed"
            else tuple(item is not None for item in predictions)
        )
        return sum(values) / len(values)
    if op == "shape_relation":
        locators = _decode_examples(event.payload.get("locators", ()))
        if not locators or not obj.examples:
            return 0.0
        return float(
            tuple(type(item).__name__ for item in locators[0].inputs)
            == tuple(type(item).__name__ for item in obj.examples[0].inputs)
        )
    if op == "local_edit_cardinality":
        desired = _decode_examples(event.payload.get(arguments["source"], ()))
        return float(
            repair_schema_from_behavior(obj, desired, grammar) is not None
        )
    if op == "query_replay":
        inputs = tuple(event.payload.get("inputs", ()))
        if not inputs:
            return 0.0
        value, used = execute_schema(obj.schema, inputs, obj.context)
        return (
            float(bool(used))
            if arguments["test"] == "uses_context"
            else float(value is not None)
        )
    if op == "set_overlap":
        left = set(event.alias.split("-"))
        right = {atom for alias in obj.aliases for atom in alias.split("-")}
        union = left | right
        return len(left & right) / len(union) if union else 0.0
    if op == "time_kernel":
        lag = max(0, sequence - obj.last_touched)
        return 1.0 / ((1.0 + lag) ** int(arguments["power"]))
    if op == "event_indicator":
        return float(event.kind.value == arguments["kind"])
    if op == "size_kernel":
        values = {
            "stored_examples": obj.examples,
            "stored_context": obj.context,
            "locators": event.payload.get("locators", ()),
            "desired_examples": event.payload.get("desired_examples", ()),
        }[arguments["source"]]
        return 1.0 / (1.0 + len(values))
    raise ValueError("unknown frozen predicate operator")


@dataclass(frozen=True)
class SchemaSynthesisDecision:
    event_id: str
    slot_id: str
    candidate_count: int
    fitting_count: int
    selected_schema: SchemaNode | None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "slot_id": self.slot_id,
            "candidate_count": self.candidate_count,
            "fitting_count": self.fitting_count,
            "selected_schema": (
                None if self.selected_schema is None else self.selected_schema.as_dict()
            ),
        }


@dataclass(frozen=True)
class SchemaRepairDecision:
    event_id: str
    slot_id: str | None
    accepted: bool
    edits_considered: int
    selected_schema_id: str | None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "slot_id": self.slot_id,
            "accepted": self.accepted,
            "edits_considered": self.edits_considered,
            "selected_schema_id": self.selected_schema_id,
        }


@dataclass(frozen=True)
class SchemaInductionTrace:
    registry_id: str
    grammar_id: str
    synthesis_decisions: Tuple[SchemaSynthesisDecision, ...]
    repair_decisions: Tuple[SchemaRepairDecision, ...]

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION,
            "registry_id": self.registry_id,
            "grammar_id": self.grammar_id,
            "synthesis_decisions": [
                item.as_dict() for item in self.synthesis_decisions
            ],
            "repair_decisions": [item.as_dict() for item in self.repair_decisions],
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


class SchemaObjectRuntime:
    def __init__(
        self,
        address_model: DiscoveredPredicateModel,
        grammar: UniversalSchemaGrammar,
        *,
        forced_slots: Mapping[str, str] | None = None,
        schema_overrides: Mapping[str, SchemaNode] | None = None,
    ) -> None:
        self.address_model = address_model
        self.grammar = grammar
        self.forced_slots = dict(forced_slots or {})
        self.schema_overrides = dict(schema_overrides or {})
        self.objects: Dict[str, SchemaObject] = {}
        self.sequence = 0
        self.feature_evaluations = 0
        self.synthesis_decisions: list[SchemaSynthesisDecision] = []
        self.repair_decisions: list[SchemaRepairDecision] = []

    def _feature_rows(
        self, event: LatentEvent
    ) -> Mapping[str, Mapping[str, float]]:
        return {
            slot_id: {
                program.program_id: evaluate_schema_predicate(
                    program, event, obj, self.sequence, self.grammar
                )
                for program in self.address_model.programs
            }
            for slot_id, obj in sorted(self.objects.items())
        }

    def _resolve(
        self, event: LatentEvent
    ) -> Tuple[SchemaObject | None, Mapping[str, float]]:
        if event.event_id in self.forced_slots:
            slot_id = self.forced_slots[event.event_id]
            return self.objects.get(slot_id), {slot_id: float("inf")}
        rows = self._feature_rows(event)
        self.feature_evaluations += len(rows)
        if not rows:
            return None, {}
        scores = {
            slot_id: self.address_model.score(values)
            for slot_id, values in rows.items()
        }
        slot_id = max(
            scores,
            key=lambda key: (scores[key], self.objects[key].last_touched, key),
        )
        return self.objects[slot_id], scores

    def act(self, event: LatentEvent) -> LatentStep:
        sequence = self.sequence
        self.sequence += 1
        before = self.feature_evaluations
        scores: Mapping[str, float] = {}
        resolved: SchemaObject | None = None
        if event.kind == LatentEventKind.DISCOVER:
            examples = _decode_examples(event.payload["examples"])
            context = _decode_rows(event.payload["context"])
            metadata = dict(event.payload["metadata"])
            candidates = synthesize_schema(examples, context, metadata, self.grammar)
            selected = self.schema_overrides.get(event.event_id, candidates.selected)
            slot_id = "slot-%04d" % len(self.objects)
            self.synthesis_decisions.append(
                SchemaSynthesisDecision(
                    event.event_id,
                    slot_id,
                    len(candidates.candidates),
                    len(candidates.fitting),
                    selected,
                )
            )
            if selected is None:
                action = LatentAction(
                    LatentActionKind.ABSTAIN,
                    {"reason": "grammar found no unique minimal schema"},
                )
            else:
                resolved = SchemaObject(
                    slot_id,
                    selected,
                    examples,
                    context,
                    metadata,
                    (event.alias,),
                    sequence,
                    sequence,
                )
                self.objects[slot_id] = resolved
                action = LatentAction(
                    LatentActionKind.DISCOVERED, {"accepted": True}
                )
        else:
            resolved, scores = self._resolve(event)
            if resolved is None:
                action = LatentAction(
                    LatentActionKind.ABSTAIN, {"reason": "no compatible object"}
                )
            elif event.kind == LatentEventKind.ATTACH:
                rows = _decode_rows(event.payload["rows"])
                existing = {row.row_id for row in resolved.context}
                resolved.context = (
                    *resolved.context,
                    *(row for row in rows if row.row_id not in existing),
                )
                action = LatentAction(
                    LatentActionKind.ATTACHED, {"count": len(rows)}
                )
            elif event.kind in (LatentEventKind.QUERY, LatentEventKind.SELECT):
                value, used = execute_schema(
                    resolved.schema,
                    tuple(event.payload["inputs"]),
                    resolved.context,
                )
                if value is None:
                    action = LatentAction(
                        LatentActionKind.ABSTAIN,
                        {"reason": "induced schema cannot execute query"},
                    )
                elif event.kind == LatentEventKind.QUERY:
                    action = LatentAction(LatentActionKind.ANSWER, {"value": value})
                else:
                    action = LatentAction(
                        LatentActionKind.SELECTION, {"row_ids": list(used)}
                    )
            elif event.kind == LatentEventKind.UPDATE:
                desired = _decode_examples(event.payload["desired_examples"])
                repair = repair_schema_from_behavior(resolved, desired, self.grammar)
                self.repair_decisions.append(
                    SchemaRepairDecision(
                        event.event_id,
                        resolved.slot_id,
                        repair is not None,
                        0 if repair is None else repair.edits_considered,
                        None if repair is None else repair.schema.node_id,
                    )
                )
                if repair is None:
                    action = LatentAction(
                        LatentActionKind.ABSTAIN,
                        {"reason": "no unique behaviorally consistent local edit"},
                    )
                else:
                    resolved.schema = repair.schema
                    resolved.context = repair.context
                    action = LatentAction(
                        LatentActionKind.UPDATED, {"accepted": True}
                    )
            else:  # pragma: no cover
                action = LatentAction(LatentActionKind.ABSTAIN, {})
            if resolved is not None:
                resolved.aliases = (*resolved.aliases, event.alias)
                resolved.last_touched = sequence
        return LatentStep(
            sequence,
            event,
            action,
            None if resolved is None else resolved.slot_id,
            scores,
            self.feature_evaluations - before,
        )


def evaluate_schema_runtime(
    registry: LatentRegistry,
    address_model: DiscoveredPredicateModel,
    grammar: UniversalSchemaGrammar,
    *,
    forced_slots: Mapping[str, str] | None = None,
    schema_overrides: Mapping[str, SchemaNode] | None = None,
) -> Tuple[LatentEvaluation, Tuple[LatentStep, ...], SchemaInductionTrace]:
    runtime = SchemaObjectRuntime(
        address_model,
        grammar,
        forced_slots=forced_slots,
        schema_overrides=schema_overrides,
    )
    steps = tuple(runtime.act(event) for event in registry.events)
    by_event = {item.event.event_id: item for item in steps}
    expected_slot_by_object = {
        object_ref: by_event[event_id].resolved_slot_id
        for event_id, object_ref in registry.discovery_object_refs.items()
    }
    outcomes = tuple(
        LatentProbeOutcome(
            probe,
            by_event[probe.event_id].action,
            by_event[probe.event_id].resolved_slot_id,
            expected_slot_by_object[probe.evaluator_object_ref],
            (
                by_event[probe.event_id].action.kind == probe.expected_kind
                and by_event[probe.event_id].action.payload == probe.expected_payload
            ),
            (
                by_event[probe.event_id].resolved_slot_id
                == expected_slot_by_object[probe.evaluator_object_ref]
            ),
        )
        for probe in registry.probes
    )
    families = sorted({item.probe.evaluator_family for item in outcomes})
    horizons = sorted({item.probe.horizon for item in outcomes})
    identity = content_digest(
        {"address_model_id": address_model.model_id, "grammar_id": grammar.grammar_id}
    )
    evaluation = LatentEvaluation(
        "self_supervised_schema_grammar",
        identity,
        registry.registry_id,
        outcomes,
        {
            family: sum(
                item.passed for item in outcomes if item.probe.evaluator_family == family
            )
            / sum(item.probe.evaluator_family == family for item in outcomes)
            for family in families
        },
        {
            str(horizon): sum(
                item.passed for item in outcomes if item.probe.horizon == horizon
            )
            / sum(item.probe.horizon == horizon for item in outcomes)
            for horizon in horizons
        },
        sum(item.action_passed for item in outcomes) / len(outcomes),
        sum(item.address_passed for item in outcomes) / len(outcomes),
        sum(item.feature_evaluations for item in steps),
        len(address_model.weights),
    )
    trace = SchemaInductionTrace(
        registry.registry_id,
        grammar.grammar_id,
        tuple(runtime.synthesis_decisions),
        tuple(runtime.repair_decisions),
    )
    return evaluation, steps, trace


@dataclass(frozen=True)
class SchemaCoreFreeze:
    address_model: DiscoveredPredicateModel
    source_predicate_freeze_id: str
    grammar: UniversalSchemaGrammar
    development_trace_id: str
    development_registry_id: str
    development_evaluation_id: str
    runtime_identity: str
    interpreter_source_digest: str
    freeze_stage: int

    @property
    def executable_digest(self) -> str:
        return content_digest(
            {
                "address_model": self.address_model.as_dict(),
                "grammar": self.grammar.as_dict(),
                "interpreter_source_digest": self.interpreter_source_digest,
            }
        )

    @property
    def freeze_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION,
            "address_model": self.address_model.as_dict(),
            "source_predicate_freeze_id": self.source_predicate_freeze_id,
            "grammar": self.grammar.as_dict(),
            "development_trace_id": self.development_trace_id,
            "development_registry_id": self.development_registry_id,
            "development_evaluation_id": self.development_evaluation_id,
            "runtime_identity": self.runtime_identity,
            "interpreter_source_digest": self.interpreter_source_digest,
            "executable_digest": self.executable_digest,
            "freeze_stage": self.freeze_stage,
        }
        if include_id:
            value["freeze_id"] = self.freeze_id
        return value


def freeze_schema_core(
    *,
    address_model: DiscoveredPredicateModel,
    source_predicate_freeze_id: str,
    grammar: UniversalSchemaGrammar,
    development_trace: SchemaInductionTrace,
    development_evaluation: LatentEvaluation,
    interpreter_source_digest: str,
    freeze_stage: int = 4,
) -> SchemaCoreFreeze:
    runtime_identity = content_digest(
        {"address_model_id": address_model.model_id, "grammar_id": grammar.grammar_id}
    )
    if development_evaluation.model_id != runtime_identity:
        raise ValueError("development evaluation used another schema core")
    if development_trace.grammar_id != grammar.grammar_id:
        raise ValueError("development trace used another grammar")
    if development_evaluation.joint_score < 0.95:
        raise ValueError("self-supervised schema core missed development floor")
    if any(item.selected_schema is None for item in development_trace.synthesis_decisions):
        raise ValueError("development contains unresolved schema synthesis")
    if any(not item.accepted for item in development_trace.repair_decisions):
        raise ValueError("development contains unresolved schema repair")
    return SchemaCoreFreeze(
        address_model,
        source_predicate_freeze_id,
        grammar,
        development_trace.trace_id,
        development_trace.registry_id,
        development_evaluation.evaluation_id,
        runtime_identity,
        interpreter_source_digest,
        freeze_stage,
    )


@dataclass(frozen=True)
class SchemaCausalIntervention:
    registry_id: str
    target_object_refs: Tuple[str, str]
    target_discovery_event_ids: Tuple[str, str]
    changed_probe_ids: Tuple[str, ...]
    target_changed_probe_ids: Tuple[str, ...]
    non_target_invariance: float
    both_target_objects_are_disrupted: bool

    @property
    def passed(self) -> bool:
        return self.both_target_objects_are_disrupted and self.non_target_invariance == 1.0

    @property
    def intervention_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION,
            "registry_id": self.registry_id,
            "target_object_refs": list(self.target_object_refs),
            "target_discovery_event_ids": list(self.target_discovery_event_ids),
            "changed_probe_ids": list(self.changed_probe_ids),
            "target_changed_probe_ids": list(self.target_changed_probe_ids),
            "non_target_invariance": self.non_target_invariance,
            "both_target_objects_are_disrupted": self.both_target_objects_are_disrupted,
            "passed": self.passed,
        }
        if include_id:
            value["intervention_id"] = self.intervention_id
        return value


def run_schema_causal_swap(
    registry: LatentRegistry,
    address_model: DiscoveredPredicateModel,
    grammar: UniversalSchemaGrammar,
) -> SchemaCausalIntervention:
    normal, _, trace = evaluate_schema_runtime(registry, address_model, grammar)
    decisions = trace.synthesis_decisions
    left, right = next(
        (left, right)
        for left in decisions
        for right in decisions
        if registry.discovery_object_refs[left.event_id]
        != registry.discovery_object_refs[right.event_id]
        and left.selected_schema is not None
        and right.selected_schema is not None
        and left.selected_schema.node_id != right.selected_schema.node_id
    )
    left_ref = registry.discovery_object_refs[left.event_id]
    right_ref = registry.discovery_object_refs[right.event_id]
    intervened, _, _ = evaluate_schema_runtime(
        registry,
        address_model,
        grammar,
        schema_overrides={
            left.event_id: right.selected_schema,
            right.event_id: left.selected_schema,
        },
    )
    normal_by_probe = {item.probe.probe_id: item for item in normal.outcomes}
    changed = tuple(
        item.probe.probe_id
        for item in intervened.outcomes
        if item.observed != normal_by_probe[item.probe.probe_id].observed
        or item.resolved_slot_id
        != normal_by_probe[item.probe.probe_id].resolved_slot_id
    )
    target_probe_ids = {
        item.probe.probe_id
        for item in normal.outcomes
        if item.probe.evaluator_object_ref in (left_ref, right_ref)
    }
    target_changed = tuple(item for item in changed if item in target_probe_ids)
    non_targets = tuple(
        item for item in intervened.outcomes if item.probe.probe_id not in target_probe_ids
    )
    invariance = sum(
        item.observed == normal_by_probe[item.probe.probe_id].observed
        and item.resolved_slot_id
        == normal_by_probe[item.probe.probe_id].resolved_slot_id
        for item in non_targets
    ) / len(non_targets)
    changed_refs = {
        normal_by_probe[probe_id].probe.evaluator_object_ref
        for probe_id in target_changed
    }
    return SchemaCausalIntervention(
        registry.registry_id,
        (left_ref, right_ref),
        (left.event_id, right.event_id),
        changed,
        target_changed,
        invariance,
        changed_refs == {left_ref, right_ref},
    )


@dataclass(frozen=True)
class SchemaAuditTrial:
    candidate_freeze: SchemaCoreFreeze
    audit_commitment_id: str
    audit_materialization_id: str
    candidate_evaluations: Mapping[str, LatentEvaluation]
    induction_traces: Mapping[str, SchemaInductionTrace]
    schema_oracle_evaluations: Mapping[str, LatentEvaluation]
    schema_oracle_traces: Mapping[str, SchemaInductionTrace]
    fixed_schema_reference_scores: Mapping[str, float]
    evidence_mode_scores: Mapping[str, float]
    family_scores: Mapping[str, float]
    horizon_scores: Mapping[str, float]
    address_intervention: CausalAddressIntervention
    schema_intervention: SchemaCausalIntervention
    check_results: Mapping[str, bool]
    limitations: Tuple[str, ...]

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def trial_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": SELF_SUPERVISED_SCHEMA_INDUCTION_VERSION,
            "candidate_freeze": self.candidate_freeze.as_dict(),
            "audit_commitment_id": self.audit_commitment_id,
            "audit_materialization_id": self.audit_materialization_id,
            "candidate_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.candidate_evaluations.items())
            },
            "induction_traces": {
                key: item.as_dict() for key, item in sorted(self.induction_traces.items())
            },
            "schema_oracle_evaluations": {
                key: item.as_dict()
                for key, item in sorted(self.schema_oracle_evaluations.items())
            },
            "schema_oracle_traces": {
                key: item.as_dict()
                for key, item in sorted(self.schema_oracle_traces.items())
            },
            "fixed_schema_reference_scores": dict(
                sorted(self.fixed_schema_reference_scores.items())
            ),
            "evidence_mode_scores": dict(sorted(self.evidence_mode_scores.items())),
            "family_scores": dict(sorted(self.family_scores.items())),
            "horizon_scores": dict(sorted(self.horizon_scores.items())),
            "address_intervention": self.address_intervention.as_dict(),
            "schema_intervention": self.schema_intervention.as_dict(),
            "check_results": dict(sorted(self.check_results.items())),
            "limitations": list(self.limitations),
            "passed": self.passed,
        }
        if include_id:
            value["trial_id"] = self.trial_id
        return value


def _run_schema_address_swap(
    registry: LatentRegistry,
    address_model: DiscoveredPredicateModel,
    grammar: UniversalSchemaGrammar,
) -> CausalAddressIntervention:
    normal, _, _ = evaluate_schema_runtime(registry, address_model, grammar)
    candidates = tuple(
        item
        for item in normal.outcomes
        if item.probe.expected_kind == LatentActionKind.ANSWER
        and item.probe.horizon == 1
        and item.passed
    )
    left, right = next(
        (left, right)
        for left in candidates
        for right in candidates
        if left.probe.evaluator_family != right.probe.evaluator_family
        and left.observed.payload != right.observed.payload
    )
    forced = {
        left.probe.event_id: str(right.resolved_slot_id),
        right.probe.event_id: str(left.resolved_slot_id),
    }
    intervened, _, _ = evaluate_schema_runtime(
        registry, address_model, grammar, forced_slots=forced
    )
    normal_by_probe = {item.probe.probe_id: item for item in normal.outcomes}
    changed = tuple(
        item.probe.probe_id
        for item in intervened.outcomes
        if item.observed != normal_by_probe[item.probe.probe_id].observed
        or item.resolved_slot_id
        != normal_by_probe[item.probe.probe_id].resolved_slot_id
    )
    targets = (left.probe.probe_id, right.probe.probe_id)
    non_targets = tuple(
        item for item in intervened.outcomes if item.probe.probe_id not in targets
    )
    invariance = sum(
        item.observed == normal_by_probe[item.probe.probe_id].observed
        and item.resolved_slot_id
        == normal_by_probe[item.probe.probe_id].resolved_slot_id
        for item in non_targets
    ) / len(non_targets)
    by_probe = {item.probe.probe_id: item for item in intervened.outcomes}
    return CausalAddressIntervention(
        registry.registry_id,
        targets,
        {
            left.probe.probe_id: str(left.resolved_slot_id),
            right.probe.probe_id: str(right.resolved_slot_id),
        },
        forced,
        changed,
        invariance,
        all(not by_probe[item].passed for item in targets),
    )


def run_schema_audit(
    *,
    candidate_freeze: SchemaCoreFreeze,
    audit_commitment_id: str,
    audit_materialization_id: str,
    registries: Mapping[str, SelfSupervisedRegistry],
    causal_registry: SelfSupervisedRegistry,
    materialization_stage: int,
    fixed_schema_reference_evaluator,
) -> SchemaAuditTrial:
    if candidate_freeze.freeze_stage >= materialization_stage:
        raise ValueError("schema core was not frozen before hidden materialization")
    candidate = {}
    traces = {}
    schema_oracle = {}
    schema_oracle_traces = {}
    reference = {}
    for key, item in registries.items():
        evaluation, _, trace = evaluate_schema_runtime(
            item.registry, candidate_freeze.address_model, candidate_freeze.grammar
        )
        candidate[key] = evaluation
        traces[key] = trace
        slot_by_object = {}
        slot_index = 0
        for event in item.registry.events:
            if event.kind == LatentEventKind.DISCOVER:
                slot_by_object[
                    item.registry.discovery_object_refs[event.event_id]
                ] = "slot-%04d" % slot_index
                slot_index += 1
        forced = {
            event.event_id: slot_by_object[
                item.registry.event_object_refs[event.event_id]
            ]
            for event in item.registry.events
            if event.kind != LatentEventKind.DISCOVER
        }
        oracle_evaluation, _, oracle_trace = evaluate_schema_runtime(
            item.registry,
            candidate_freeze.address_model,
            candidate_freeze.grammar,
            forced_slots=forced,
        )
        schema_oracle[key] = oracle_evaluation
        schema_oracle_traces[key] = oracle_trace
        reference[key] = fixed_schema_reference_evaluator(item.registry).joint_score
    outcomes = tuple(
        outcome for evaluation in candidate.values() for outcome in evaluation.outcomes
    )
    families = sorted({item.probe.evaluator_family for item in outcomes})
    family_scores = {
        family: sum(
            item.passed for item in outcomes if item.probe.evaluator_family == family
        )
        / sum(item.probe.evaluator_family == family for item in outcomes)
        for family in families
    }
    horizons = sorted({item.probe.horizon for item in outcomes})
    horizon_scores = {
        str(horizon): sum(
            item.passed for item in outcomes if item.probe.horizon == horizon
        )
        / sum(item.probe.horizon == horizon for item in outcomes)
        for horizon in horizons
    }
    mode_values: Dict[str, list[bool]] = {mode: [] for mode in EVIDENCE_MODES}
    for key, evaluation in candidate.items():
        modes = registries[key].evidence_mode_by_event_id
        for outcome in evaluation.outcomes:
            mode = modes[outcome.probe.event_id]
            if mode in mode_values:
                mode_values[mode].append(outcome.passed)
    mode_scores = {
        mode: sum(values) / len(values)
        for mode, values in mode_values.items()
        if values
    }
    scores = {key: value.joint_score for key, value in candidate.items()}
    address_intervention = _run_schema_address_swap(
        causal_registry.registry,
        candidate_freeze.address_model,
        candidate_freeze.grammar,
    )
    schema_intervention = run_schema_causal_swap(
        causal_registry.registry,
        candidate_freeze.address_model,
        candidate_freeze.grammar,
    )
    all_synthesis = tuple(
        decision
        for trace in schema_oracle_traces.values()
        for decision in trace.synthesis_decisions
    )
    all_repairs = tuple(
        decision
        for trace in schema_oracle_traces.values()
        for decision in trace.repair_decisions
    )
    checks = {
        "candidate_frozen_before_hidden_materialization": (
            candidate_freeze.freeze_stage < materialization_stage
        ),
        "fifteen_new_hidden_registries_cover_three_families": (
            len(registries) == 15
            and all(
                sum(key.startswith(prefix) for key in registries) == 5
                for prefix in ("numeric-", "relational-", "table-")
            )
        ),
        "every_hidden_registry_clears_ninety_percent": min(scores.values()) >= 0.90,
        "every_family_clears_ninety_five_percent": all(
            value >= 0.95 for value in family_scores.values()
        ),
        "every_evidence_mode_clears_ninety_five_percent": (
            set(mode_scores) == set(EVIDENCE_MODES)
            and all(value >= 0.95 for value in mode_scores.values())
        ),
        "all_horizons_through_sixty_four_clear_floor": all(
            value >= 0.95 for value in horizon_scores.values()
        ),
        "within_five_points_of_fixed_schema_reference": (
            sum(scores.values()) / len(scores)
            >= sum(reference.values()) / len(reference) - 0.05
        ),
        "every_hidden_schema_is_uniquely_induced": (
            bool(all_synthesis)
            and all(item.selected_schema is not None for item in all_synthesis)
        ),
        "every_hidden_update_uses_unique_generic_repair": (
            bool(all_repairs)
            and all(item.accepted for item in all_repairs)
            and min(item.joint_score for item in schema_oracle.values()) == 1.0
        ),
        "address_intervention_is_selective": address_intervention.passed,
        "schema_intervention_is_selective": schema_intervention.passed,
    }
    return SchemaAuditTrial(
        candidate_freeze,
        audit_commitment_id,
        audit_materialization_id,
        candidate,
        traces,
        schema_oracle,
        schema_oracle_traces,
        reference,
        mode_scores,
        family_scores,
        horizon_scores,
        address_intervention,
        schema_intervention,
        checks,
        (
            "Schema compositions and repairs are induced from behavior, but the universal operator grammar is engineered.",
            "The grammar is bounded to arithmetic, graph-following, and finite lookup operations.",
            "Candidate-visible examples and desired update behavior remain explicit supervision signals.",
            "All audits remain procedural local microdomains rather than natural language or software tasks.",
        ),
    )
