from __future__ import annotations

from itertools import product
from typing import Any, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.cross_channel_binding_v52x import (
    descriptor_direction,
)
from scientist.domains.cognitive_core.formulation_invariant_representation_v52xjr import (
    evaluate_fixed_boundary_ensemble,
    summarize_development_panel,
)
from scientist.domains.cognitive_core.independent_paraphrase_orbits_v52v import (
    semantic_relation_prompt,
)
from scientist.domains.cognitive_core.reciprocal_role_alignment_v52xd import (
    M52XD_TRAINED_DIRECTIONS,
)


SEMANTIC_FAMILY_TRANSFER_VERSION = (
    "general-cognitive-semantic-family-transfer-v52xjt"
)
M52XJT_SEED = 53287
M52XJT_M52XJS_AUDIT_ID = (
    "d86eed57138e762698948e91347b310e3bea1b4ec0c28011814bca6984ba3e9d"
)
M52XJT_STYLE_COUNT = 3
M52XJT_FORMULATION_SPLIT = {
    "development_a": "development",
    "development_b": "development",
    "sealed_a": "sealed",
    "sealed_b": "sealed",
}


M52XJT_TRANSFORMS = {
    "development_a": {
        "name": (
            "semantic_transfer_label",
            "family_holdout_method",
            "concept_bridge_name",
        ),
        "principle": (
            "semantic_transfer_rule",
            "family_holdout_criterion",
            "concept_bridge_rule",
        ),
        "action": (
            "semantic_transfer_operation",
            "family_holdout_execution",
            "concept_bridge_behavior",
        ),
    },
    "development_b": {
        "name": (
            "novel_family_label",
            "unseen_domain_method",
            "semantic_bridge_name",
        ),
        "principle": (
            "novel_family_rule",
            "unseen_domain_criterion",
            "semantic_bridge_rule",
        ),
        "action": (
            "novel_family_operation",
            "unseen_domain_execution",
            "semantic_bridge_behavior",
        ),
    },
    "sealed_a": {
        "name": (
            "blind_transfer_label",
            "sealed_family_method",
            "latent_concept_name",
        ),
        "principle": (
            "blind_transfer_rule",
            "sealed_family_criterion",
            "latent_concept_rule",
        ),
        "action": (
            "blind_transfer_operation",
            "sealed_family_execution",
            "latent_concept_behavior",
        ),
    },
    "sealed_b": {
        "name": (
            "independent_transfer_label",
            "quarantine_family_method",
            "final_concept_name",
        ),
        "principle": (
            "independent_transfer_rule",
            "quarantine_family_criterion",
            "final_concept_rule",
        ),
        "action": (
            "independent_transfer_operation",
            "quarantine_family_execution",
            "final_concept_behavior",
        ),
    },
}


_CHANNEL_NOUN = {
    "name": "method identity",
    "principle": "decision principle",
    "action": "execution behavior",
}


def semantic_family_transfer_text(
    state: Mapping[str, str],
    channel: str,
    role: str,
    formulation: str,
    style: int,
) -> str:
    if formulation not in M52XJT_TRANSFORMS:
        raise ValueError(f"unknown M52xj-T formulation: {formulation}")
    if channel not in _CHANNEL_NOUN or role not in {"basis", "candidate"}:
        raise ValueError(f"unknown M52xj-T channel/role: {channel}/{role}")
    if not 0 <= int(style) < M52XJT_STYLE_COUNT:
        raise ValueError(f"unknown M52xj-T style: {style}")
    frame = {
        "development_a": "development transfer",
        "development_b": "unseen-domain transfer",
        "sealed_a": "blind sealed transfer",
        "sealed_b": "independent sealed validation",
    }[formulation]
    noun = _CHANNEL_NOUN[channel]
    value = str(state[channel])
    basis_templates = (
        "In the {frame} trial, locate a counterpart from this {noun}: {value}",
        "Use this {frame} reference to resolve the matching {noun}: {value}",
        "The {frame} query anchors correspondence on this {noun}: {value}",
    )
    candidate_templates = (
        "The {frame} candidate exposes the following {noun}: {value}",
        "This option in {frame} carries the candidate {noun}: {value}",
        "The proposed {frame} counterpart reports this {noun}: {value}",
    )
    return (basis_templates if role == "basis" else candidate_templates)[
        int(style)
    ].format(frame=frame, noun=noun, value=value)


def build_semantic_family_transfer_rows(
    ledger: Mapping[str, Any], formulation: str
) -> Tuple[Mapping[str, Any], ...]:
    if formulation not in M52XJT_FORMULATION_SPLIT:
        raise ValueError("unknown M52xj-T formulation")
    semantic_split = M52XJT_FORMULATION_SPLIT[formulation]
    transforms = M52XJT_TRANSFORMS[formulation]
    rows = []
    for family, family_value in ledger["semantic_families"].items():
        if str(family_value["split"]) != semantic_split:
            continue
        states = tuple(family_value["states"])
        if len(states) != 4:
            raise ValueError("M52xj-T requires four states per semantic family")
        for direction in M52XD_TRAINED_DIRECTIONS:
            basis_channel, candidate_channel = direction.split("->")
            for basis_style, candidate_style in product(
                range(M52XJT_STYLE_COUNT), repeat=2
            ):
                for basis_state in states:
                    orbit = content_digest(
                        {
                            "milestone": "M52xj-T",
                            "formulation": formulation,
                            "family": family,
                            "direction": direction,
                            "basis_style": basis_style,
                            "candidate_style": candidate_style,
                            "basis_state": basis_state["key"],
                        }
                    )
                    basis_text = semantic_family_transfer_text(
                        basis_state,
                        basis_channel,
                        "basis",
                        formulation,
                        basis_style,
                    )
                    for candidate_state in states:
                        candidate_text = semantic_family_transfer_text(
                            candidate_state,
                            candidate_channel,
                            "candidate",
                            formulation,
                            candidate_style,
                        )
                        metadata = {
                            "record_id": content_digest(
                                {
                                    "orbit": orbit,
                                    "candidate_state": candidate_state["key"],
                                }
                            ),
                            "orbit_id": orbit,
                            "family": str(family),
                            "semantic_split": semantic_split,
                            "formulation_split": formulation,
                            "basis_style": int(basis_style),
                            "candidate_style": int(candidate_style),
                            "basis_state_key": str(basis_state["key"]),
                            "candidate_state_key": str(candidate_state["key"]),
                            "basis_transformation": transforms[basis_channel][
                                basis_style
                            ],
                            "basis_transformation_split": (
                                "m52xjt_semantic_family_transfer"
                            ),
                            "candidate_transformation": transforms[
                                candidate_channel
                            ][candidate_style],
                            "candidate_transformation_split": (
                                "m52xjt_semantic_family_transfer"
                            ),
                            "basis_text": basis_text,
                            "candidate_text": candidate_text,
                            "relation_target": (
                                "YES"
                                if str(basis_state["key"])
                                == str(candidate_state["key"])
                                else "NO"
                            ),
                        }
                        row = {
                            "prompt": semantic_relation_prompt(
                                basis_text, candidate_text
                            ),
                            "metadata": metadata,
                        }
                        if descriptor_direction(row) != direction:
                            raise ValueError(
                                "M52xj-T transformation routing is inconsistent"
                            )
                        rows.append(row)
    return tuple(rows)


def semantic_transfer_development_gate_passed(
    candidate: Mapping[str, Any],
    parent: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "all_development_formulations_pass": bool(
            candidate["all_ensembles_passed"]
        ),
        "minimum_worst_family_improvement": float(
            candidate["minimum_family_balanced_accuracy"]
        )
        - float(parent["minimum_family_balanced_accuracy"])
        >= float(contract["minimum_worst_family_improvement"]),
        "maximum_overall_regression": float(
            candidate["minimum_overall_balanced_accuracy"]
        )
        - float(parent["minimum_overall_balanced_accuracy"])
        >= -float(contract["maximum_overall_regression"]),
        "maximum_oracle_threshold_range": float(
            candidate["oracle_threshold_range"]
        )
        <= float(contract["maximum_oracle_threshold_range"]),
        "maximum_oracle_threshold_range_increase": float(
            candidate["oracle_threshold_range"]
        )
        - float(parent["oracle_threshold_range"])
        <= float(contract["maximum_oracle_threshold_range_increase"]),
        "minimum_ranking_accuracy": float(candidate["minimum_ranking_accuracy"])
        >= float(contract["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(candidate["minimum_top1_accuracy"])
        >= float(contract["minimum_top1_accuracy"]),
        "minimum_weakest_reciprocity": float(
            candidate["minimum_weakest_reciprocity"]
        )
        >= float(contract["minimum_weakest_reciprocity"]),
    }
    return all(checks.values()), checks


def semantic_transfer_confirmation_gate_passed(
    candidate: Mapping[str, Any],
    parent: Mapping[str, Any],
    contract: Mapping[str, float],
) -> tuple[bool, Mapping[str, bool]]:
    checks = {
        "all_sealed_formulations_pass": bool(candidate["all_ensembles_passed"]),
        "maximum_worst_family_regression": float(
            candidate["minimum_family_balanced_accuracy"]
        )
        - float(parent["minimum_family_balanced_accuracy"])
        >= -float(contract["maximum_worst_family_regression"]),
        "maximum_overall_regression": float(
            candidate["minimum_overall_balanced_accuracy"]
        )
        - float(parent["minimum_overall_balanced_accuracy"])
        >= -float(contract["maximum_overall_regression"]),
        "maximum_oracle_threshold_range": float(
            candidate["oracle_threshold_range"]
        )
        <= float(contract["maximum_oracle_threshold_range"]),
        "maximum_oracle_threshold_range_increase": float(
            candidate["oracle_threshold_range"]
        )
        - float(parent["oracle_threshold_range"])
        <= float(contract["maximum_oracle_threshold_range_increase"]),
        "minimum_ranking_accuracy": float(candidate["minimum_ranking_accuracy"])
        >= float(contract["minimum_ranking_accuracy"]),
        "minimum_top1_accuracy": float(candidate["minimum_top1_accuracy"])
        >= float(contract["minimum_top1_accuracy"]),
        "minimum_weakest_reciprocity": float(
            candidate["minimum_weakest_reciprocity"]
        )
        >= float(contract["minimum_weakest_reciprocity"]),
    }
    return all(checks.values()), checks


__all__ = (
    "M52XJT_FORMULATION_SPLIT",
    "M52XJT_M52XJS_AUDIT_ID",
    "M52XJT_SEED",
    "M52XJT_STYLE_COUNT",
    "M52XJT_TRANSFORMS",
    "SEMANTIC_FAMILY_TRANSFER_VERSION",
    "build_semantic_family_transfer_rows",
    "evaluate_fixed_boundary_ensemble",
    "semantic_family_transfer_text",
    "semantic_transfer_confirmation_gate_passed",
    "semantic_transfer_development_gate_passed",
    "summarize_development_panel",
)
