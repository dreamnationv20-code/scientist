from __future__ import annotations

import random
from typing import Dict

from scientist.domains.cognitive_core.models import (
    ABSTAIN,
    CognitiveProbe,
    ProbeInput,
    ProbeKind,
)


def knowledge_table(
    knowledge_seed: int,
    fact_count: int,
    value_modulus: int,
) -> Dict[int, int]:
    if fact_count <= 0:
        raise ValueError("fact_count must be positive")
    if value_modulus <= 1:
        raise ValueError("value_modulus must exceed one")
    rng = random.Random(knowledge_seed)
    keys = list(range(1000, 1000 + fact_count))
    values = [rng.randrange(value_modulus) for _ in keys]
    return dict(zip(keys, values))


def execute_procedure(public_input: ProbeInput) -> int:
    left, right = public_input.operands
    if public_input.operation == "add_mod":
        return (left + right) % public_input.value_modulus
    if public_input.operation == "xor":
        return (left ^ right) % public_input.value_modulus
    if public_input.operation == "max":
        return max(left, right) % public_input.value_modulus
    raise ValueError("unsupported procedure operation")


def reconstruct_expected(probe: CognitiveProbe) -> int:
    public_input = probe.public_input
    if public_input.kind == ProbeKind.PROCEDURE:
        return execute_procedure(public_input)
    if public_input.kind == ProbeKind.UNKNOWN_FACT:
        return ABSTAIN
    if public_input.kind in (
        ProbeKind.ORACLE_EVIDENCE,
        ProbeKind.CONFLICTING_EVIDENCE,
    ):
        matches = [
            item.value
            for item in public_input.evidence
            if item.key == public_input.query_key
        ]
        if len(matches) != 1:
            raise ValueError("answering evidence must contain one exact match")
        return matches[0]
    table = knowledge_table(
        probe.knowledge_seed,
        probe.fact_count,
        public_input.value_modulus,
    )
    if public_input.query_key not in table:
        raise ValueError("closed-book query is outside the knowledge table")
    return table[public_input.query_key]
