from __future__ import annotations

import hashlib
import itertools
import json
import random
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_MODEL_SNAPSHOT,
    M50_OUTPUT_ALGEBRAS,
    M50_REPRESENTATIONS,
    _support,
    _task_signature,
)
from scientist.domains.cognitive_core.causal_actuator_validation_v52c import (
    build_m52c_cases,
)
from scientist.domains.cognitive_core.causal_controller_installation_v52 import (
    _slot_difference_targets,
    build_m52_cases,
)
from scientist.domains.cognitive_core.causal_pointer_readout_repair_v52b import (
    build_m52b_cases,
)
from scientist.domains.cognitive_core.dynamic_pointer_validation_v52d import (
    build_m52d_cases,
)
from scientist.domains.cognitive_core.output_only_controller_v49 import (
    _task_lines,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
)


SEQUENTIAL_CONTROLLER_VALIDATION_VERSION = (
    "general-cognitive-sequential-controller-validation-v52e"
)
M52E_CONFIRMATION_SEED = 52609
M52E_TRAJECTORIES_PER_REPRESENTATION = 5
M52E_STAGES = (1, 2, 3, 4)
M52E_CONTEXT_VARIANTS = ("persistent", "current_only", "scope_rotated")
M52E_REPRESENTATIONS = M50_REPRESENTATIONS
M52E_M52_CHECKPOINT_SHA256 = (
    "08ec0414d6386ea340c9fa2c227f9b9872af939810101070329e82949e708982"
)
M52E_M52_RESULT_ID = (
    "e840cf07c8de9b968744b9f4a8851568dd981904d59b4cc74a0d2452c30c55a9"
)
M52E_M52D_RESULT_ID = (
    "e87d009f912999383b69d49bc6b3061394871d31287e55e22958c81f3bd3bb3b"
)


def _stable_seed(representation: str, source_index: int) -> int:
    material = f"{M52E_CONFIRMATION_SEED}:{representation}:{source_index}"
    return int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)


def _two_candidate_task(
    representation: str, source_index: int
) -> Tuple[Any, Tuple[Any, ...], Tuple[Any, ...]] | None:
    rng = random.Random(_stable_seed(representation, source_index))
    source = _build_task("m52e_confirmation", representation, source_index, rng)
    base = _m43_experiment_task(source)
    if base is None:
        return None
    candidates = sorted(base.frontier, key=lambda item: item.key)
    for left, right in itertools.combinations(candidates, 2):
        provisional = replace(base, frontier=(left, right))
        equal, unequal = _support(provisional)
        if equal and unequal:
            task_id = "m52e-task-" + content_digest(
                {
                    "representation": representation,
                    "source_index": source_index,
                    "frontier": [left.key, right.key],
                    "version": SEQUENTIAL_CONTROLLER_VALIDATION_VERSION,
                }
            )[:24]
            return replace(provisional, task_id=task_id), equal, unequal
    return None


def _display_history(
    history: Sequence[Mapping[str, Any]], material: str
) -> Tuple[Mapping[str, Any], ...]:
    ordered = list(history)
    seed = int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(ordered)
    return tuple(
        {**row, "slot": slot}
        for slot, row in enumerate(ordered, 1)
    )


def _current_only_history(
    history: Sequence[Mapping[str, Any]], current_stage: int
) -> Tuple[Mapping[str, Any], ...]:
    selected = [
        row for row in history if int(row["scope_stage"]) == int(current_stage)
    ]
    return tuple({**row, "slot": index} for index, row in enumerate(selected, 1))


def _scope_rotated_history(
    history: Sequence[Mapping[str, Any]], current_stage: int
) -> Tuple[Mapping[str, Any], ...]:
    if len(history) <= 1:
        return tuple(dict(row) for row in history)
    labels = [(row["scope_stage"], row["turn"]) for row in history]
    shift = 1 + (int(current_stage) * 2) % (len(labels) - 1)
    rotated = labels[-shift:] + labels[:-shift]
    return tuple(
        {**row, "scope_stage": int(label[0]), "turn": int(label[1])}
        for row, label in zip(history, rotated)
    )


def scoped_informative_slots(
    history: Sequence[Mapping[str, Any]], current_stage: int
) -> Tuple[int, ...]:
    result = []
    for row in history:
        if int(row["scope_stage"]) != int(current_stage):
            continue
        left, right = row["outputs"]
        if json.dumps(left, sort_keys=True, separators=(",", ":")) != json.dumps(
            right, sort_keys=True, separators=(",", ":")
        ):
            result.append(int(row["slot"]))
    return tuple(result)


def execute_scoped_action(
    history: Sequence[Mapping[str, Any]],
    action: int,
    phase: str,
    current_stage: int,
) -> Mapping[str, Any]:
    action = int(action)
    informative = scoped_informative_slots(history, current_stage)
    if phase == "pre_evidence":
        correct = action == 0 and not informative
        return {
            "phase": phase,
            "action": action,
            "current_informative_slots": list(informative),
            "transitioned": bool(correct),
            "terminal": not bool(correct),
            "success": False,
        }
    if phase != "post_evidence":
        raise ValueError("unknown M52e phase")
    selected = action if 1 <= action <= len(history) else None
    success = selected is not None and selected in informative
    return {
        "phase": phase,
        "action": action,
        "current_informative_slots": list(informative),
        "selected_slot": selected,
        "transitioned": False,
        "terminal": True,
        "success": bool(success),
    }


def sequential_controller_prompt(
    task: Any,
    history: Sequence[Mapping[str, Any]],
    current_stage: int,
) -> str:
    lines = _task_lines(task)
    lines.extend(
        (
            f"Current scope_stage: {int(current_stage)}",
            "Execution history is shown in display-slot order, not chronological order.",
            "A result is valid only when its scope_stage equals the current scope_stage.",
            "Results from earlier scope_stage values are stale even when their outputs differ.",
            "Execution history:",
        )
    )
    for row in history:
        lines.append(
            "  slot %d scope_stage=%d turn=%d experiment=%s"
            % (
                int(row["slot"]),
                int(row["scope_stage"]),
                int(row["turn"]),
                json.dumps(row["experiment"]),
            )
        )
        lines.append(
            "    c1_output=" + json.dumps(row["outputs"][0], sort_keys=True)
        )
        lines.append(
            "    c2_output=" + json.dumps(row["outputs"][1], sort_keys=True)
        )
    lines.extend(
        (
            "Make the control decision yourself from current-scope evidence.",
            "Do not invent an experiment in this response.",
            "If a current-scope slot achieves the goal, return exactly: SELECT: <slot number>",
            "If no current-scope slot achieves the goal, return exactly: REVISE",
        )
    )
    return "\n".join(lines)


@lru_cache(maxsize=None)
def build_m52e_trajectories(
    representations: Tuple[str, ...] = M52E_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    excluded = {
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52_cases(split)
    }
    excluded.update(
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52b_cases(split)
    )
    excluded.update(case["task_signature"] for case in build_m52c_cases())
    excluded.update(case["task_signature"] for case in build_m52d_cases())
    used = set(excluded)
    trajectories = []
    for representation in representations:
        source_index = 0
        for trajectory_index in range(M52E_TRAJECTORIES_PER_REPRESENTATION):
            chronological = []
            stages = []
            task_signatures = []
            for stage in M52E_STAGES:
                while True:
                    candidate = _two_candidate_task(representation, source_index)
                    source_index += 1
                    if candidate is None:
                        if source_index > 20_000:
                            raise RuntimeError(
                                f"could not build M52e {representation} tasks"
                            )
                        continue
                    task, equal_values, unequal_values = candidate
                    signature = _task_signature(task)
                    if signature in used:
                        continue
                    used.add(signature)
                    break
                task_signatures.append(signature)
                equal_value = equal_values[
                    (trajectory_index + stage) % len(equal_values)
                ]
                evidence_value = unequal_values[
                    (trajectory_index * 2 + stage) % len(unequal_values)
                ]
                turn = len(chronological) + 1
                chronological.append(
                    {
                        "slot": turn,
                        "turn": turn,
                        "scope_stage": stage,
                        "semantic_id": f"stage-{stage}-equal",
                        "experiment": equal_value,
                        "outputs": list(raw_candidate_outputs(task, equal_value)),
                        "response": "EXPERIMENT: " + json.dumps(equal_value),
                    }
                )
                pre = _display_history(
                    chronological,
                    f"{representation}:{trajectory_index}:{stage}:pre",
                )
                turn = len(chronological) + 1
                chronological.append(
                    {
                        "slot": turn,
                        "turn": turn,
                        "scope_stage": stage,
                        "semantic_id": f"stage-{stage}-evidence",
                        "experiment": evidence_value,
                        "outputs": list(raw_candidate_outputs(task, evidence_value)),
                        "response": "EXPERIMENT: " + json.dumps(evidence_value),
                    }
                )
                post = _display_history(
                    chronological,
                    f"{representation}:{trajectory_index}:{stage}:post",
                )
                stages.append(
                    {
                        "stage": stage,
                        "task": task,
                        "task_signature": signature,
                        "pre_evidence_history": pre,
                        "post_evidence_history": post,
                    }
                )
            trajectory_id = "m52e-trajectory-" + content_digest(
                {
                    "representation": representation,
                    "trajectory_index": trajectory_index,
                    "task_signatures": task_signatures,
                    "version": SEQUENTIAL_CONTROLLER_VALIDATION_VERSION,
                }
            )[:24]
            trajectories.append(
                {
                    "trajectory_id": trajectory_id,
                    "representation": representation,
                    "output_algebra": M50_OUTPUT_ALGEBRAS[representation],
                    "stages": tuple(stages),
                }
            )
    return tuple(trajectories)


def build_m52e_rows(
    representations: Tuple[str, ...] = M52E_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for trajectory in build_m52e_trajectories(representations):
        for stage_state in trajectory["stages"]:
            stage = int(stage_state["stage"])
            for phase, persistent_history in (
                ("pre_evidence", stage_state["pre_evidence_history"]),
                ("post_evidence", stage_state["post_evidence_history"]),
            ):
                contexts = {
                    "persistent": persistent_history,
                    "current_only": _current_only_history(persistent_history, stage),
                    "scope_rotated": _scope_rotated_history(
                        persistent_history, stage
                    ),
                }
                for context_variant in M52E_CONTEXT_VARIANTS:
                    prompt_history = contexts[context_variant]
                    environment_history = (
                        contexts["current_only"]
                        if context_variant == "current_only"
                        else persistent_history
                    )
                    informative = scoped_informative_slots(environment_history, stage)
                    expected_action = 0 if phase == "pre_evidence" else informative[0]
                    record_id = "m52e-record-" + content_digest(
                        {
                            "trajectory_id": trajectory["trajectory_id"],
                            "stage": stage,
                            "phase": phase,
                            "context_variant": context_variant,
                            "version": SEQUENTIAL_CONTROLLER_VALIDATION_VERSION,
                        }
                    )[:24]
                    rows.append(
                        {
                            "prompt": sequential_controller_prompt(
                                stage_state["task"], prompt_history, stage
                            ),
                            "metadata": {
                                "record_id": record_id,
                                "trajectory_id": trajectory["trajectory_id"],
                                "stage": stage,
                                "phase": phase,
                                "context_variant": context_variant,
                                "task_id": stage_state["task"].task_id,
                                "task_signature": stage_state["task_signature"],
                                "representation": trajectory["representation"],
                                "output_algebra": trajectory["output_algebra"],
                                "prefix_length": len(prompt_history),
                                "prompt_history": list(prompt_history),
                                "environment_history": list(environment_history),
                                "slot_difference_targets": list(
                                    _slot_difference_targets(prompt_history)
                                ),
                                "action_target": int(expected_action),
                                "stale_informative_slots": list(
                                    slot
                                    for row in environment_history
                                    for slot in (int(row["slot"]),)
                                    if int(row["scope_stage"]) < stage
                                    and json.dumps(
                                        row["outputs"][0],
                                        sort_keys=True,
                                        separators=(",", ":"),
                                    )
                                    != json.dumps(
                                        row["outputs"][1],
                                        sort_keys=True,
                                        separators=(",", ":"),
                                    )
                                ),
                            },
                        }
                    )
    return tuple(rows)


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52e artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json_payload(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def _jsonl_payload(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    m52_root = project / "runs/cognitive_core/causal_controller_installation_v52"
    m52_result = json.loads((m52_root / "causal-controller-result.json").read_text())
    m52d_result = json.loads(
        (
            project
            / "runs/cognitive_core/dynamic_pointer_validation_v52d/dynamic-pointer-result.json"
        ).read_text()
    )
    checkpoint = m52_root / "adapter/0000160_adapters.safetensors"
    return {
        "version": SEQUENTIAL_CONTROLLER_VALIDATION_VERSION,
        "parent_version": "general-cognitive-dynamic-pointer-validation-v52d",
        "scientific_question": (
            "Can the frozen dynamic causal pointer maintain current-stage validity, "
            "reject formerly useful but stale evidence, and complete multi-stage "
            "trajectories under persistent state?"
        ),
        "confirmation_seed": M52E_CONFIRMATION_SEED,
        "representations": list(M52E_REPRESENTATIONS),
        "trajectories_per_representation": M52E_TRAJECTORIES_PER_REPRESENTATION,
        "stages_per_trajectory": len(M52E_STAGES),
        "context_variants": list(M52E_CONTEXT_VARIANTS),
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "m52_checkpoint_source": (
                "runs/cognitive_core/causal_controller_installation_v52/adapter/"
                "0000160_adapters.safetensors"
            ),
            "m52_checkpoint_sha256": _sha256(checkpoint),
            "m52_result_id": m52_result["result_id"],
            "m52d_result_id": m52d_result["result_id"],
            "m52d_passed": bool(m52d_result["milestone_passed"]),
        },
        "sequential_contract": {
            "model_weight_updates": 0,
            "language_decoder_calls": 0,
            "trajectory_stages": list(M52E_STAGES),
            "post_evidence_history_lengths": [2, 4, 6, 8],
            "persistent_state": (
                "prior-stage results remain visible with their original scope_stage"
            ),
            "state_transition": (
                "a correct REVISE reveals one current-stage differentiating result; a "
                "correct SELECT advances to a new unresolved mechanism pair"
            ),
            "display_order": (
                "history is deterministically shuffled at each state; slot position "
                "does not encode recency or validity"
            ),
            "current_only_control": (
                "remove stale state while preserving current-stage mechanisms and outputs"
            ),
            "scope_rotated_control": (
                "rotate scope_stage and turn labels while preserving visible positions, "
                "experiments, and outputs"
            ),
            "pointer_rotated_control": (
                "rotate persistent pointer logits while preserving the revise logit"
            ),
        },
        "confirmation_contract": {
            "minimum_persistent_decision_accuracy": 0.80,
            "minimum_persistent_stage_success": 0.75,
            "minimum_persistent_trajectory_success": 0.50,
            "minimum_each_representation_persistent_decision_accuracy": 0.70,
            "minimum_each_later_stage_recovery_accuracy": 0.70,
            "minimum_persistent_terminal_select_accuracy": 0.80,
            "minimum_current_only_stage_success": 0.90,
            "minimum_gain_over_scope_rotated_control": 0.20,
            "minimum_gain_over_pointer_rotated_control": 0.30,
            "require_zero_trainable_tensors": True,
            "require_checkpoint_unchanged": True,
        },
        "integrity_contract": {
            "all_prior_mechanisms_excluded": True,
            "every_trajectory_has_four_ordered_stages": True,
            "stale_evidence_persists_after_stage_transition": True,
            "current_only_control_removes_all_stale_rows": True,
            "scope_rotation_preserves_outputs_and_positions": True,
            "terminal_success_recomputed_from_scoped_candidate_outputs": True,
            "no_training_or_checkpoint_selection": True,
        },
        "claim_boundary": (
            "M52e tests frozen sequential validity control on synthetic staged mechanism "
            "episodes. Passing would justify independent certification; it would not "
            "establish natural-task transfer, autonomous tool use, or general reasoning parity."
        ),
    }


def prepare_m52e_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol_payload = _protocol_payload(project)
    protocol = {**protocol_payload, "protocol_freeze_id": content_digest(protocol_payload)}
    _write_immutable(output / "protocol-freeze.json", _json_payload(protocol))
    rows = build_m52e_rows()
    row_hash = _write_immutable(
        output / "sequential/confirmation.jsonl", _jsonl_payload(rows)
    )
    payload = {
        **protocol,
        "hashes": {"confirmation": row_hash},
        "counts": {
            "records": len(rows),
            "trajectories": len(build_m52e_trajectories()),
            "stages": len(build_m52e_trajectories()) * len(M52E_STAGES),
            "records_by_context": {
                context: sum(
                    row["metadata"]["context_variant"] == context for row in rows
                )
                for context in M52E_CONTEXT_VARIANTS
            },
        },
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    _write_immutable(output / "benchmark-freeze.json", _json_payload(freeze))
    verification = verify_m52e_benchmark(output, project)
    _write_immutable(output / "benchmark-verification.json", _json_payload(verification))
    return freeze


def _rows(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(json.loads(line) for line in path.read_text().splitlines() if line)


def _row_semantics(history: Sequence[Mapping[str, Any]]) -> Tuple[Mapping[str, Any], ...]:
    return tuple(
        {
            "slot": row["slot"],
            "experiment": row["experiment"],
            "outputs": row["outputs"],
        }
        for row in history
    )


def verify_m52e_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    pp = {key: value for key, value in protocol.items() if key != "protocol_freeze_id"}
    fp = {key: value for key, value in freeze.items() if key != "freeze_id"}
    path = output / "sequential/confirmation.jsonl"
    stored = _rows(path)
    groups: Dict[Tuple[str, int, str], list[Mapping[str, Any]]] = {}
    for row in stored:
        metadata = row["metadata"]
        key = (
            metadata["trajectory_id"],
            int(metadata["stage"]),
            metadata["context_variant"],
        )
        groups.setdefault(key, []).append(row)
    exact = True
    environment_valid = True
    current_only_valid = True
    rotation_valid = True
    stale_persists = True
    for (trajectory_id, stage, context), group in groups.items():
        del trajectory_id
        phases = {row["metadata"]["phase"] for row in group}
        exact = exact and len(group) == 2 and phases == {
            "pre_evidence",
            "post_evidence",
        }
        for row in group:
            metadata = row["metadata"]
            history = metadata["environment_history"]
            action = int(metadata["action_target"])
            replay = execute_scoped_action(history, action, metadata["phase"], stage)
            environment_valid = environment_valid and (
                replay["transitioned"]
                if metadata["phase"] == "pre_evidence"
                else replay["success"]
            )
            if context == "current_only":
                current_only_valid = current_only_valid and all(
                    int(item["scope_stage"]) == stage for item in history
                )
            if context == "persistent" and stage > 1:
                stale_persists = stale_persists and bool(
                    metadata["stale_informative_slots"]
                )
        if context == "scope_rotated":
            for row in group:
                metadata = row["metadata"]
                rotation_valid = rotation_valid and (
                    _row_semantics(metadata["prompt_history"])
                    == _row_semantics(metadata["environment_history"])
                )
    trajectories = build_m52e_trajectories()
    trajectory_valid = all(
        tuple(int(stage["stage"]) for stage in trajectory["stages"])
        == M52E_STAGES
        for trajectory in trajectories
    )
    old_signatures = {
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52_cases(split)
    }
    old_signatures.update(
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52b_cases(split)
    )
    old_signatures.update(case["task_signature"] for case in build_m52c_cases())
    old_signatures.update(case["task_signature"] for case in build_m52d_cases())
    current = {row["metadata"]["task_signature"] for row in stored}
    checkpoint = project / freeze["frozen_model"]["m52_checkpoint_source"]
    m52_result = json.loads(
        (
            project
            / "runs/cognitive_core/causal_controller_installation_v52/causal-controller-result.json"
        ).read_text()
    )
    m52d_result = json.loads(
        (
            project
            / "runs/cognitive_core/dynamic_pointer_validation_v52d/dynamic-pointer-result.json"
        ).read_text()
    )
    checks = {
        "protocol_id_is_content_derived": content_digest(pp)
        == protocol["protocol_freeze_id"],
        "freeze_id_is_content_derived": content_digest(fp) == freeze["freeze_id"],
        "confirmation_hash_matches": _sha256(path)
        == freeze["hashes"]["confirmation"],
        "rows_reproduce": stored == build_m52e_rows(),
        "exact_stage_context_pairs": exact,
        "environment_semantics_valid": environment_valid,
        "every_trajectory_has_four_stages": trajectory_valid,
        "stale_evidence_persists": stale_persists,
        "current_only_removes_stale_rows": current_only_valid,
        "scope_rotation_preserves_outputs_and_positions": rotation_valid,
        "all_prior_mechanisms_excluded": not bool(current & old_signatures),
        "m52_checkpoint_matches": _sha256(checkpoint)
        == freeze["frozen_model"]["m52_checkpoint_sha256"]
        == M52E_M52_CHECKPOINT_SHA256,
        "parent_results_match": (
            m52_result["result_id"]
            == freeze["frozen_model"]["m52_result_id"]
            == M52E_M52_RESULT_ID
            and m52d_result["result_id"]
            == freeze["frozen_model"]["m52d_result_id"]
            == M52E_M52D_RESULT_ID
            and m52d_result["milestone_passed"]
        ),
        "protocol_has_no_training_or_selection": (
            freeze["sequential_contract"]["model_weight_updates"] == 0
            and "training_recipe" not in freeze
            and "checkpoint_selection" not in freeze
        ),
    }
    return {
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def _summarize(
    records: Sequence[Mapping[str, Any]], condition: str
) -> Mapping[str, Any]:
    if not records:
        return {
            "stage_count": 0,
            "decision_accuracy": 0.0,
            "stage_success": 0.0,
            "pre_evidence_revise_accuracy": 0.0,
            "post_evidence_select_accuracy": 0.0,
        }
    return {
        "stage_count": len(records),
        "decision_accuracy": sum(
            int(bool(row[f"{condition}_pre_correct"]))
            + int(bool(row[f"{condition}_post_correct"]))
            for row in records
        )
        / (2 * len(records)),
        "stage_success": sum(
            bool(row[f"{condition}_stage_success"]) for row in records
        )
        / len(records),
        "pre_evidence_revise_accuracy": sum(
            bool(row[f"{condition}_pre_correct"]) for row in records
        )
        / len(records),
        "post_evidence_select_accuracy": sum(
            bool(row[f"{condition}_post_correct"]) for row in records
        )
        / len(records),
    }


def sequential_metrics(
    records: Sequence[Mapping[str, Any]], condition: str
) -> Mapping[str, Any]:
    overall = _summarize(records, condition)
    trajectories: Dict[str, list[Mapping[str, Any]]] = {}
    for row in records:
        trajectories.setdefault(str(row["trajectory_id"]), []).append(row)
    trajectory_success = sum(
        len(group) == len(M52E_STAGES)
        and all(row[f"{condition}_stage_success"] for row in group)
        for group in trajectories.values()
    ) / max(len(trajectories), 1)
    return {
        **overall,
        "trajectory_count": len(trajectories),
        "trajectory_success": trajectory_success,
        "later_stage_recovery_accuracy": (
            sum(
                bool(row[f"{condition}_pre_correct"])
                for row in records
                if int(row["stage"]) > 1
            )
            / max(sum(int(row["stage"]) > 1 for row in records), 1)
        ),
        "stale_preselection_rate": (
            sum(
                int(row[f"{condition}_pre_action"])
                in set(row["pre_stale_informative_slots"])
                for row in records
                if int(row["stage"]) > 1
            )
            / max(sum(int(row["stage"]) > 1 for row in records), 1)
        ),
        "by_representation": {
            representation: _summarize(
                [row for row in records if row["representation"] == representation],
                condition,
            )
            for representation in M52E_REPRESENTATIONS
        },
        "by_stage": {
            str(stage): _summarize(
                [row for row in records if int(row["stage"]) == stage], condition
            )
            for stage in M52E_STAGES
        },
        "records": list(records),
    }


def m52e_passed(
    persistent: Mapping[str, Any],
    current_only: Mapping[str, Any],
    scope_rotated: Mapping[str, Any],
    pointer_rotated: Mapping[str, Any],
    contract: Mapping[str, Any],
    *,
    trainable_tensor_count: int,
    checkpoint_unchanged: bool,
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "persistent_decision_accuracy": persistent["decision_accuracy"]
        >= contract["minimum_persistent_decision_accuracy"],
        "persistent_stage_success": persistent["stage_success"]
        >= contract["minimum_persistent_stage_success"],
        "persistent_trajectory_success": persistent["trajectory_success"]
        >= contract["minimum_persistent_trajectory_success"],
        "each_representation_persistent_decision_accuracy": min(
            row["decision_accuracy"]
            for row in persistent["by_representation"].values()
        )
        >= contract["minimum_each_representation_persistent_decision_accuracy"],
        "each_later_stage_recovery_accuracy": min(
            persistent["by_stage"][str(stage)]["pre_evidence_revise_accuracy"]
            for stage in M52E_STAGES
            if stage > 1
        )
        >= contract["minimum_each_later_stage_recovery_accuracy"],
        "persistent_terminal_select_accuracy": persistent[
            "post_evidence_select_accuracy"
        ]
        >= contract["minimum_persistent_terminal_select_accuracy"],
        "current_only_stage_success": current_only["stage_success"]
        >= contract["minimum_current_only_stage_success"],
        "gain_over_scope_rotated_control": (
            persistent["stage_success"] - scope_rotated["stage_success"]
            >= contract["minimum_gain_over_scope_rotated_control"]
        ),
        "gain_over_pointer_rotated_control": (
            persistent["stage_success"] - pointer_rotated["stage_success"]
            >= contract["minimum_gain_over_pointer_rotated_control"]
        ),
        "zero_trainable_tensors": (
            trainable_tensor_count == 0
            if contract["require_zero_trainable_tensors"]
            else True
        ),
        "checkpoint_unchanged": (
            checkpoint_unchanged
            if contract["require_checkpoint_unchanged"]
            else True
        ),
    }
    return all(checks.values()), checks
