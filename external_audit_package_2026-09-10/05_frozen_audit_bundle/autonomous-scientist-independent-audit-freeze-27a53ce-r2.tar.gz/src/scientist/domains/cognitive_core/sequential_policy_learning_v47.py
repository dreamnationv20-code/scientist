from __future__ import annotations

import hashlib
import json
import random
import time
from dataclasses import replace
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.contrast_experiment_v42 import (
    ContrastPair,
    _best_contrast_pair,
    aggregate_contrasts,
    contrast_prompt,
    pair_members,
)
from scientist.domains.cognitive_core.experiment_invention_v41 import (
    ExperimentTask,
    _canonical,
    parse_experiment,
    partition_metrics,
)
from scientist.domains.cognitive_core.internal_core_v28 import (
    _batch_responses,
    _chat_prompt,
)
from scientist.domains.cognitive_core.model_controlled_tool_loop_v46 import (
    _interaction_metrics,
    _run_condition,
    interaction_prompt,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
    experiment_classes,
)


SEQUENTIAL_POLICY_LEARNING_VERSION = "general-cognitive-sequential-policy-learning-v47"
M47_SPLIT_SEEDS = {
    "train": 47037,
    "valid": 47061,
    "calibration": 47079,
    "test": 47109,
}
M47_REPRESENTATIONS = ("predicate", "causal")
M47_PER_REPRESENTATION = {
    "train": 60,
    "valid": 12,
    "calibration": 6,
    "test": 30,
}
M47_MINIMUM_EXCLUSIVE_FRACTION = 0.10
M47_PARENT_ADAPTER_SHA256 = (
    "f3fa70320bf04b9b54d14fa4f0c891b96d8399da452d8e9a386e2ce3eede7f38"
)
M47_MODEL_SNAPSHOT = "8b403126fc14f14cfc99bb4cfa72ecbc129ea677"


def _source_tasks(
    split: str, per_representation: int, representations: Sequence[str]
) -> Tuple[Any, ...]:
    if split not in M47_SPLIT_SEEDS:
        raise ValueError("unknown M47 split")
    rng = random.Random(M47_SPLIT_SEEDS[split])
    return tuple(
        _build_task(f"m47_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )


def _experiment_task(source: Any) -> ExperimentTask | None:
    task = _m43_experiment_task(source)
    if task is None:
        return None
    task_id = "m47-exp-" + content_digest(
        {
            "source": source.task_id,
            "scenario": task.scenario.scenario_id,
            "version": SEQUENTIAL_POLICY_LEARNING_VERSION,
        }
    )[:20]
    return replace(task, task_id=task_id)


def build_m47_pairs(
    split: str,
    per_representation: int | None = None,
    representations: Sequence[str] = M47_REPRESENTATIONS,
) -> Tuple[ContrastPair, ...]:
    if split not in M47_PER_REPRESENTATION:
        raise ValueError("unknown M47 split")
    if per_representation is None:
        per_representation = M47_PER_REPRESENTATION[split]
    bases = tuple(
        task
        for source in _source_tasks(split, per_representation, representations)
        for task in (_experiment_task(source),)
        if task is not None
    )
    return tuple(
        pair
        for base in bases
        for pair in (
            _best_contrast_pair(
                base,
                version=SEQUENTIAL_POLICY_LEARNING_VERSION,
                pair_prefix="m47-pair",
                minimum_exclusive_fraction=M47_MINIMUM_EXCLUSIVE_FRACTION,
            ),
        )
        if pair is not None
    )


def _ordered_sample(values: Sequence[Any], salt: str) -> Tuple[Any, ...]:
    materialized = list(values)
    random.Random(
        int(hashlib.sha256(salt.encode("utf-8")).hexdigest()[:16], 16)
    ).shuffle(materialized)
    return tuple(materialized)


def _history_row(task: ExperimentTask, experiment: Any, slot: int, turn: int) -> Mapping[str, Any]:
    return {
        "slot": slot,
        "turn": turn,
        "experiment": experiment,
        "outputs": list(raw_candidate_outputs(task, experiment)),
        "response": "EXPERIMENT: " + json.dumps(experiment),
    }


def _record(
    pair: ContrastPair,
    own: ExperimentTask,
    sibling: ExperimentTask,
    *,
    record_type: str,
    history: Sequence[Mapping[str, Any]],
    errors: Sequence[str],
    completion: str,
    turn: int,
    final_selection: bool = False,
) -> Mapping[str, Any]:
    prompt = interaction_prompt(
        own,
        own,
        history,
        errors,
        feedback=True,
        turn=turn,
        final_selection=final_selection,
    )
    return {
        "prompt": prompt,
        "completion": completion,
        "metadata": {
            "pair_id": pair.pair_id,
            "task_id": own.task_id,
            "sibling_task_id": sibling.task_id,
            "representation": own.representation,
            "record_type": record_type,
            "history": list(history),
            "errors": list(errors),
            "turn": turn,
            "final_selection": final_selection,
            "teacher_source": "executable_partition_available_during_training_only",
        },
    }


def trajectory_records(
    pair: ContrastPair, own: ExperimentTask, sibling: ExperimentTask
) -> Tuple[Mapping[str, Any], ...]:
    classes = experiment_classes(own, sibling)
    targets = _ordered_sample(
        classes["frontier_specific"], f"m47:{own.task_id}:target"
    )
    failures = _ordered_sample(
        classes["sibling_specific"] + classes["uninformative"],
        f"m47:{own.task_id}:failure",
    )
    if not targets or not failures:
        raise ValueError("M47 trajectory lacks target or failure support")

    def target(index: int) -> Any:
        return targets[index % len(targets)]

    def failure(index: int) -> Any:
        return failures[index % len(failures)]

    t0, t1, t2 = target(0), target(1), target(2)
    f0, f1 = failure(0), failure(1)
    h_f0 = (_history_row(own, f0, 1, 1),)
    h_f0_f1 = (
        _history_row(own, f0, 1, 1),
        _history_row(own, f1, 2, 2),
    )
    h_t0 = (_history_row(own, t0, 1, 1),)
    h_f0_t1 = (
        _history_row(own, f0, 1, 1),
        _history_row(own, t1, 2, 2),
    )
    h_t2_f1 = (
        _history_row(own, t2, 1, 1),
        _history_row(own, f1, 2, 2),
    )
    proposal = lambda value: "EXPERIMENT: " + json.dumps(value)
    records = (
        _record(
            pair,
            own,
            sibling,
            record_type="initial_frontier_specific_proposal",
            history=(),
            errors=(),
            completion=proposal(t0),
            turn=1,
        ),
        _record(
            pair,
            own,
            sibling,
            record_type="revise_after_one_equal_output",
            history=h_f0,
            errors=(),
            completion=proposal(t1),
            turn=2,
        ),
        _record(
            pair,
            own,
            sibling,
            record_type="revise_after_two_equal_outputs",
            history=h_f0_f1,
            errors=(),
            completion=proposal(t2),
            turn=3,
        ),
        _record(
            pair,
            own,
            sibling,
            record_type="select_single_informative_slot",
            history=h_t0,
            errors=(),
            completion="SELECT: 1",
            turn=2,
        ),
        _record(
            pair,
            own,
            sibling,
            record_type="select_informative_slot_after_failure",
            history=h_f0_t1,
            errors=(),
            completion="SELECT: 2",
            turn=3,
        ),
        _record(
            pair,
            own,
            sibling,
            record_type="select_earlier_informative_slot",
            history=h_t2_f1,
            errors=(),
            completion="SELECT: 1",
            turn=3,
        ),
        _record(
            pair,
            own,
            sibling,
            record_type="recover_after_invalid_action",
            history=(),
            errors=(
                "turn 1: invalid, out-of-schema, observed, duplicate, or unavailable selection",
            ),
            completion=proposal(t1),
            turn=2,
        ),
        _record(
            pair,
            own,
            sibling,
            record_type="forced_final_select_informative_slot",
            history=h_f0_t1,
            errors=(),
            completion="SELECT: 2",
            turn=8,
            final_selection=True,
        ),
    )
    return records


def _all_trajectory_records(pairs: Sequence[ContrastPair]) -> Iterable[Mapping[str, Any]]:
    for pair in pairs:
        yield from trajectory_records(pair, pair.left, pair.right)
        yield from trajectory_records(pair, pair.right, pair.left)


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def _trajectory_summary(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    types: Dict[str, int] = {}
    representations: Dict[str, int] = {}
    for row in rows:
        metadata = row["metadata"]
        types[metadata["record_type"]] = types.get(metadata["record_type"], 0) + 1
        representation = metadata["representation"]
        representations[representation] = representations.get(representation, 0) + 1
    return {
        "records": len(rows),
        "by_type": dict(sorted(types.items())),
        "by_representation": dict(sorted(representations.items())),
    }


def prepare_m47_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    data = output / "trajectory"
    data.mkdir(parents=True, exist_ok=True)
    pairs = {split: build_m47_pairs(split) for split in M47_SPLIT_SEEDS}
    rows = {
        split: tuple(_all_trajectory_records(pairs[split]))
        for split in ("train", "valid")
    }
    hashes: Dict[str, str] = {}
    counts: Dict[str, Any] = {}
    for split in ("train", "valid"):
        digest, count = _write_jsonl(data / f"{split}.jsonl", rows[split])
        hashes[f"trajectory_{split}"] = digest
        counts[f"{split}_trajectory_records"] = count
    for split in ("calibration", "test"):
        public_hash, _ = _write_jsonl(
            output / f"{split}-public.jsonl",
            (
                {
                    "pair_id": pair.pair_id,
                    "representation": pair.representation,
                    "left_task_id": pair.left.task_id,
                    "right_task_id": pair.right.task_id,
                    "left_initial_prompt_sha256": hashlib.sha256(
                        interaction_prompt(
                            pair.left,
                            pair.left,
                            (),
                            (),
                            feedback=True,
                            turn=1,
                        ).encode("utf-8")
                    ).hexdigest(),
                    "right_initial_prompt_sha256": hashlib.sha256(
                        interaction_prompt(
                            pair.right,
                            pair.right,
                            (),
                            (),
                            feedback=True,
                            turn=1,
                        ).encode("utf-8")
                    ).hexdigest(),
                }
                for pair in pairs[split]
            ),
        )
        authority_hash, _ = _write_jsonl(
            output / f"{split}-authority.jsonl",
            (
                {
                    "pair_id": pair.pair_id,
                    "authority_program": dict(pair.left.source.authority),
                    "left_frontier": [item.key for item in pair.left.frontier],
                    "right_frontier": [item.key for item in pair.right.frontier],
                }
                for pair in pairs[split]
            ),
        )
        hashes[f"{split}_public"] = public_hash
        hashes[f"{split}_authority"] = authority_hash
    counts.update(
        {
            split: {
                "pairs": len(split_pairs),
                "tasks": len(split_pairs) * 2,
                "by_representation": {
                    representation: sum(
                        int(pair.representation == representation)
                        for pair in split_pairs
                    )
                    for representation in M47_REPRESENTATIONS
                },
            }
            for split, split_pairs in pairs.items()
        }
    )
    gates = {
        "minimum_action_parse_rate": 0.95,
        "minimum_valid_action_rate": 0.85,
        "minimum_selection_completion_rate": 0.90,
        "minimum_selected_evidence_rate": 0.80,
        "minimum_available_evidence_selection_rate": 0.90,
        "minimum_predicate_information": 0.70,
        "minimum_causal_information": 0.90,
        "minimum_overall_correct_assignment": 0.65,
        "minimum_information_gain_over_direct": 0.15,
        "minimum_assignment_gain_over_direct": 0.15,
        "minimum_information_gain_over_no_feedback": 0.15,
        "minimum_assignment_gain_over_no_feedback": 0.15,
        "minimum_advantage_gap_over_mismatched": 0.60,
    }
    interaction_contract = {
        "proposal_turn_budget": 8,
        "action_max_tokens": 24,
        "forced_final_selection_max_tokens": 8,
        "maximum_total_output_tokens_per_task": 200,
        "batch_size": 8,
        "tool_returns": "raw_c1_and_c2_outputs_only",
        "tool_does_not_return": [
            "information_gain",
            "ranking",
            "recommended_action",
            "stop_decision",
        ],
        "selection_policy": "model_selects_a_previously_executed_slot",
        "external_fallback_selection": False,
        "no_test_time_parameter_updates": True,
    }
    payload = {
        "version": SEQUENTIAL_POLICY_LEARNING_VERSION,
        "parent_version": "general-cognitive-model-controlled-tool-loop-v46",
        "split_seeds": M47_SPLIT_SEEDS,
        "representations": list(M47_REPRESENTATIONS),
        "per_representation_source_count": M47_PER_REPRESENTATION,
        "minimum_exclusive_fraction": M47_MINIMUM_EXCLUSIVE_FRACTION,
        "counts": counts,
        "trajectory_summary": {
            split: _trajectory_summary(split_rows) for split, split_rows in rows.items()
        },
        "hashes": hashes,
        "frozen_model": {
            "snapshot": M47_MODEL_SNAPSHOT,
            "parent_adapter_sha256": M47_PARENT_ADAPTER_SHA256,
            "parent_adapter_source": "m43_validation_selected_checkpoint_100",
        },
        "trajectory_contract": {
            "records_per_task": 8,
            "teacher_available_only_during_training": True,
            "teacher_source": "executable_partition",
            "proposal_target": "frontier_specific_experiment",
            "equal_outputs_action": "propose_a_new_frontier_specific_experiment",
            "unequal_outputs_action": "select_the_informative_tested_slot",
            "includes_nonlatest_informative_slot": True,
            "includes_invalid_action_recovery": True,
            "includes_forced_final_selection": True,
            "metrics_or_ranks_in_prompt": False,
        },
        "training_recipe": {
            "objective": "sequential_action_supervised_fine_tuning",
            "initialization": "m43_selected_checkpoint_100",
            "lora_layers": 8,
            "lora_rank": 8,
            "lora_scale": 20.0,
            "iterations": 240,
            "learning_rate": 1e-5,
            "gradient_accumulation_steps": 4,
            "checkpoint_interval": 80,
            "validation_interval": 80,
            "max_sequence_length": 1024,
            "seed": 47,
            "checkpoint_selection": "minimum_frozen_validation_action_nll",
        },
        "interaction_contract": interaction_contract,
        "conditions": [
            "direct_correct",
            "correct_feedback",
            "correct_no_feedback",
            "mismatched_feedback",
        ],
        "calibration_readiness_gates": gates,
        "sealed_test_gates": gates,
        "sealed_test_policy": "test_is_opened_only_if_all_calibration_readiness_gates_pass",
        "claim_boundary": (
            "M47 tests whether supervised internalization of propose-observe-revise/select trajectories "
            "lets a frozen 1.5B model causally use raw execution feedback on fresh predicate and causal "
            "frontiers. Executable scoring creates training targets only. At evaluation, the tool returns "
            "only raw c1/c2 outputs and the model alone proposes, revises, stops, and selects. M47 does not "
            "test unseen representation grammars, natural scientific experiments, or parity with a 70B model."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def _load_json(path: Path) -> Mapping[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def verify_m47_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = _load_json(output / "benchmark-freeze.json")
    paths = {
        "trajectory_train": output / "trajectory/train.jsonl",
        "trajectory_valid": output / "trajectory/valid.jsonl",
        **{
            f"{split}_{kind}": output / f"{split}-{kind}.jsonl"
            for split in ("calibration", "test")
            for kind in ("public", "authority")
        },
    }
    hashes = {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in paths.items()
    }
    payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    split_ids = {
        split: {pair.pair_id for pair in build_m47_pairs(split)}
        for split in M47_SPLIT_SEEDS
    }
    rows = tuple(
        json.loads(line)
        for line in paths["trajectory_train"].read_text(encoding="utf-8").splitlines()
        if line
    )
    prompt_text = "\n".join(str(row["prompt"]) for row in rows)
    all_disjoint = all(
        not (split_ids[left] & split_ids[right])
        for index, left in enumerate(M47_SPLIT_SEEDS)
        for right in tuple(M47_SPLIT_SEEDS)[index + 1 :]
    )
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": content_digest(payload) == freeze["freeze_id"],
        "all_splits_are_disjoint": all_disjoint,
        "calibration_and_test_absent_from_training": not (
            output / "trajectory/calibration.jsonl"
        ).exists()
        and not (output / "trajectory/test.jsonl").exists(),
        "all_action_types_have_training_support": set(
            freeze["trajectory_summary"]["train"]["by_type"]
        )
        == {
            "initial_frontier_specific_proposal",
            "revise_after_one_equal_output",
            "revise_after_two_equal_outputs",
            "select_single_informative_slot",
            "select_informative_slot_after_failure",
            "select_earlier_informative_slot",
            "recover_after_invalid_action",
            "forced_final_select_informative_slot",
        },
        "no_scores_or_ranks_in_training_prompts": "normalized_information_gain"
        not in prompt_text
        and "recommended_action" not in prompt_text,
        "teacher_is_training_only": freeze["trajectory_contract"][
            "teacher_available_only_during_training"
        ]
        and freeze["interaction_contract"]["external_fallback_selection"] is False,
        "parent_adapter_hash_is_frozen": freeze["frozen_model"][
            "parent_adapter_sha256"
        ]
        == M47_PARENT_ADAPTER_SHA256,
        "gates_are_identical_across_splits": freeze["calibration_readiness_gates"]
        == freeze["sealed_test_gates"],
        "sealed_test_policy_is_frozen": freeze["sealed_test_policy"]
        == "test_is_opened_only_if_all_calibration_readiness_gates_pass",
    }
    return {
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def evaluate_m47_split(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    adapter_path: Path,
    *,
    split: str,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if split not in ("calibration", "test"):
        raise ValueError("M47 split must be calibration or test")
    freeze = _load_json(benchmark_root / "benchmark-freeze.json")
    selection = _load_json(output_root / "checkpoint-selection.json")
    if split == "test":
        calibration = output_root / "m47-calibration-assessment.json"
        if not calibration.exists() or not _load_json(calibration)["passed"]:
            raise RuntimeError("sealed M47 test cannot open before calibration passes")
    if not model_path.rstrip("/").endswith(freeze["frozen_model"]["snapshot"]):
        raise ValueError("model path does not match frozen M47 snapshot")
    adapter_hash = hashlib.sha256(
        (adapter_path / "adapters.safetensors").read_bytes()
    ).hexdigest()
    if (
        adapter_hash != selection["selected_adapter_sha256"]
        or selection["benchmark_freeze_id"] != freeze["freeze_id"]
        or selection["criterion"]
        != freeze["training_recipe"]["checkpoint_selection"]
    ):
        raise ValueError("adapter does not match frozen M47 validation selection")
    pairs = build_m47_pairs(split)
    tasks = pair_members(pairs)
    started = time.monotonic()
    model, tokenizer, config = load(
        model_path, adapter_path=str(adapter_path), return_config=True
    )
    states = {}
    peak_memory = 0.0
    for mode in ("correct_feedback", "correct_no_feedback", "mismatched_feedback"):
        condition_states, peak = _run_condition(
            pairs,
            model,
            tokenizer,
            mode=mode,
            contract=freeze["interaction_contract"],
        )
        states[mode] = condition_states
        peak_memory = max(peak_memory, peak)
    direct_responses, direct_peak = _batch_responses(
        model,
        tokenizer,
        tuple(
            _chat_prompt(tokenizer, contrast_prompt(task, dossier=True))
            for task in tasks
        ),
        batch_size=int(freeze["interaction_contract"]["batch_size"]),
        max_tokens=40,
        max_batch_tokens=12000,
    )
    peak_memory = max(peak_memory, direct_peak)
    conditions = {
        "direct_correct": aggregate_contrasts(
            "direct_correct",
            pairs,
            tuple(parse_experiment(response) for response in direct_responses),
            direct_responses,
        )
    }
    interaction_metrics = {}
    for mode, condition_states in states.items():
        conditions[mode] = aggregate_contrasts(
            mode,
            pairs,
            [state["selected_experiment"] for state in condition_states],
            [state["final_response"] for state in condition_states],
        )
        interaction_metrics[mode] = _interaction_metrics(
            pairs, condition_states, mode=mode
        )
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "sequential_policy_learning_predictions",
        {
            "states": states,
            "conditions": {
                name: {
                    "records": result["records"],
                    "pair_records": result["pair_records"],
                }
                for name, result in conditions.items()
            },
            "direct_responses": list(direct_responses),
        },
    )
    payload = {
        "version": SEQUENTIAL_POLICY_LEARNING_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "split": split,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path),
        "adapter_config_sha256": hashlib.sha256(
            (adapter_path / "adapter_config.json").read_bytes()
        ).hexdigest(),
        "adapter_weights_sha256": adapter_hash,
        "checkpoint_selection_id": selection["selection_id"],
        "metrics": {name: result["metrics"] for name, result in conditions.items()},
        "interaction_metrics": {
            mode: {key: item for key, item in metrics.items() if key != "records"}
            for mode, metrics in interaction_metrics.items()
        },
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "interaction_contract": freeze["interaction_contract"],
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(
        f"sequential-policy-learning-{split}-{manifest['evaluation_id']}", manifest
    )
    return manifest


def assess_m47_split(
    evaluation: Mapping[str, Any], benchmark_root: Path
) -> Mapping[str, Any]:
    freeze = _load_json(benchmark_root / "benchmark-freeze.json")
    split = str(evaluation["split"])
    gates = (
        freeze["calibration_readiness_gates"]
        if split == "calibration"
        else freeze["sealed_test_gates"]
    )
    metrics = evaluation["metrics"]
    interactions = evaluation["interaction_metrics"]
    candidate = metrics["correct_feedback"]
    direct = metrics["direct_correct"]
    no_feedback = metrics["correct_no_feedback"]
    mismatch = metrics["mismatched_feedback"]
    loop = interactions["correct_feedback"]
    predicate = candidate["by_representation"]["predicate"]
    causal = candidate["by_representation"]["causal"]
    checks = {
        "same_benchmark_freeze": evaluation["benchmark_freeze_id"]
        == freeze["freeze_id"],
        "fixed_raw_tool_contract": evaluation["interaction_contract"]
        == freeze["interaction_contract"],
        "action_parse_rate": loop["action_parse_rate"]
        >= gates["minimum_action_parse_rate"],
        "valid_action_rate": loop["valid_action_rate"]
        >= gates["minimum_valid_action_rate"],
        "selection_completion_rate": loop["selection_completion_rate"]
        >= gates["minimum_selection_completion_rate"],
        "selected_evidence_rate": loop["selected_evidence_rate"]
        >= gates["minimum_selected_evidence_rate"],
        "available_evidence_selection_rate": loop[
            "available_evidence_selection_rate"
        ]
        >= gates["minimum_available_evidence_selection_rate"],
        "predicate_information": predicate["mean_normalized_information_gain"]
        >= gates["minimum_predicate_information"],
        "causal_information": causal["mean_normalized_information_gain"]
        >= gates["minimum_causal_information"],
        "overall_correct_assignment": candidate["correct_assignment_rate"]
        >= gates["minimum_overall_correct_assignment"],
        "information_gain_over_direct": candidate["mean_normalized_information_gain"]
        - direct["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_direct"],
        "assignment_gain_over_direct": candidate["correct_assignment_rate"]
        - direct["correct_assignment_rate"]
        >= gates["minimum_assignment_gain_over_direct"],
        "information_gain_over_no_feedback": candidate[
            "mean_normalized_information_gain"
        ]
        - no_feedback["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_no_feedback"],
        "assignment_gain_over_no_feedback": candidate["correct_assignment_rate"]
        - no_feedback["correct_assignment_rate"]
        >= gates["minimum_assignment_gain_over_no_feedback"],
        "advantage_gap_over_mismatched": candidate["mean_assignment_advantage"]
        - mismatch["mean_assignment_advantage"]
        >= gates["minimum_advantage_gap_over_mismatched"],
    }
    payload = {
        "version": SEQUENTIAL_POLICY_LEARNING_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "split": split,
        "evaluation_id": evaluation["evaluation_id"],
        "metrics": metrics,
        "interaction_metrics": interactions,
        "deltas": {
            "information_gain_over_direct": candidate[
                "mean_normalized_information_gain"
            ]
            - direct["mean_normalized_information_gain"],
            "assignment_gain_over_direct": candidate["correct_assignment_rate"]
            - direct["correct_assignment_rate"],
            "information_gain_over_no_feedback": candidate[
                "mean_normalized_information_gain"
            ]
            - no_feedback["mean_normalized_information_gain"],
            "assignment_gain_over_no_feedback": candidate["correct_assignment_rate"]
            - no_feedback["correct_assignment_rate"],
            "advantage_gap_over_mismatched": candidate["mean_assignment_advantage"]
            - mismatch["mean_assignment_advantage"],
        },
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
        "sealed_test_authorized": split == "calibration" and all(checks.values()),
        "claim_boundary": freeze["claim_boundary"],
    }
    return {**payload, "assessment_id": content_digest(payload)}
