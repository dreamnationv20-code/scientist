from __future__ import annotations

import hashlib
import json
import random
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.ambiguity_stress_v40 import (
    _short_horizon_scenario,
    robust_evidence_policy,
)
from scientist.domains.cognitive_core.contrast_experiment_v42 import (
    ContrastPair,
    _best_contrast_pair,
    _control_values,
    aggregate_contrasts,
    contrast_prompt,
    pair_members,
)
from scientist.domains.cognitive_core.counterfactual_diagnosis_v35 import (
    enumerate_interventions,
)
from scientist.domains.cognitive_core.evidence_algebra_v39 import evidence_cases
from scientist.domains.cognitive_core.experiment_invention_v41 import (
    ExperimentTask,
    _available_inputs,
    _canonical,
    parse_experiment,
    partition_metrics,
)
from scientist.domains.cognitive_core.internal_core_v28 import _batch_responses, _chat_prompt
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task


SET_VALUED_EXPERIMENT_VERSION = "general-cognitive-set-valued-experiment-v43"
M43_SPLIT_SEEDS = {"train": 43037, "valid": 43061, "test": 43109}
M43_REPRESENTATIONS = ("predicate", "causal")
M43_PER_REPRESENTATION = {"train": 60, "valid": 12, "test": 30}
M43_MINIMUM_EXCLUSIVE_FRACTION = 0.10
M43_SEARCH_BUDGET = 8
TRAIN_PREFERENCES_PER_TASK = 4
VALID_PREFERENCES_PER_TASK = 2
PARENT_ADAPTER_SHA256 = "dbb62580e82059c51c0146d03b31b525a29e6f1cf6a6553f849927178b6539eb"


def _source_tasks(
    split: str, per_representation: int, representations: Sequence[str]
) -> Tuple[Any, ...]:
    if split not in M43_SPLIT_SEEDS:
        raise ValueError("unknown M43 split")
    rng = random.Random(M43_SPLIT_SEEDS[split])
    return tuple(
        _build_task(f"m43_{split}", representation, index, rng)
        for representation in representations
        for index in range(per_representation)
    )


def _experiment_task(source: Any) -> ExperimentTask | None:
    scenario = _short_horizon_scenario(source)
    if scenario is None:
        return None
    raw_cases = evidence_cases(source, "active")[: len(scenario.cases)]
    policy = robust_evidence_policy(scenario.cases, scenario.candidates)
    frontier_ids = set(policy["robust_frontier_ids"])
    interventions = {
        intervention.key: intervention for intervention in enumerate_interventions(source)
    }
    frontier = tuple(
        interventions[candidate.candidate_id]
        for candidate in sorted(scenario.candidates, key=lambda item: item.ordinal)
        if candidate.candidate_id in frontier_ids
    )
    correct = f"{source.target_node}={json.dumps(source.correct_edit_value, sort_keys=True)}"
    if correct not in {item.key for item in frontier} or len(frontier) < 2:
        return None
    task_id = "m43-exp-" + content_digest(
        {
            "source": source.task_id,
            "scenario": scenario.scenario_id,
            "version": SET_VALUED_EXPERIMENT_VERSION,
        }
    )[:20]
    return ExperimentTask(
        task_id,
        source,
        scenario,
        tuple(case["input"] for case in raw_cases),
        frontier,
    )


def build_m43_pairs(
    split: str,
    per_representation: int | None = None,
    representations: Sequence[str] = M43_REPRESENTATIONS,
) -> Tuple[ContrastPair, ...]:
    if split not in M43_PER_REPRESENTATION:
        raise ValueError("unknown M43 split")
    if per_representation is None:
        per_representation = M43_PER_REPRESENTATION[split]
    bases = tuple(
        task
        for source in _source_tasks(split, per_representation, representations)
        for task in (_experiment_task(source),)
        if task is not None
    )
    return tuple(
        pair
        for base in bases
        for pair in (
            _best_contrast_pair(
                base,
                version=SET_VALUED_EXPERIMENT_VERSION,
                pair_prefix="m43-pair",
                minimum_exclusive_fraction=M43_MINIMUM_EXCLUSIVE_FRACTION,
            ),
        )
        if pair is not None
    )


def experiment_classes(
    own: ExperimentTask, sibling: ExperimentTask
) -> Mapping[str, Tuple[Any, ...]]:
    classes: Dict[str, list[Any]] = {
        "frontier_specific": [],
        "shared_informative": [],
        "sibling_specific": [],
        "uninformative": [],
    }
    for value in _available_inputs(own):
        own_info = partition_metrics(own, value)["normalized_information_gain"] > 0.0
        sibling_info = (
            partition_metrics(sibling, value)["normalized_information_gain"] > 0.0
        )
        if own_info and not sibling_info:
            label = "frontier_specific"
        elif own_info and sibling_info:
            label = "shared_informative"
        elif sibling_info:
            label = "sibling_specific"
        else:
            label = "uninformative"
        classes[label].append(value)
    return {
        label: tuple(sorted(values, key=_canonical))
        for label, values in classes.items()
    }


def _cycled_sample(values: Sequence[Any], count: int, salt: str) -> Tuple[Any, ...]:
    if not values:
        return ()
    materialized = list(values)
    rng = random.Random(
        int(hashlib.sha256(salt.encode("utf-8")).hexdigest()[:16], 16)
    )
    rng.shuffle(materialized)
    return tuple(materialized[index % len(materialized)] for index in range(count))


def preference_records(
    pair: ContrastPair,
    own: ExperimentTask,
    sibling: ExperimentTask,
    *,
    count: int,
) -> Tuple[Mapping[str, Any], ...]:
    classes = experiment_classes(own, sibling)
    positives = _cycled_sample(
        classes["frontier_specific"], count, f"{own.task_id}:positive"
    )
    negative_samples: Dict[str, Tuple[Any, ...]] = {}
    for label in ("sibling_specific", "shared_informative", "uninformative"):
        sampled = _cycled_sample(classes[label], count, f"{own.task_id}:{label}")
        if sampled:
            negative_samples[label] = sampled
    if not positives or not negative_samples:
        raise ValueError("M43 preference task lacks positive or negative support")
    negative_labels = tuple(negative_samples)
    records = []
    for index, chosen in enumerate(positives):
        rejected_label = negative_labels[index % len(negative_labels)]
        sampled = negative_samples[rejected_label]
        rejected = sampled[index % len(sampled)]
        records.append(
            {
                "prompt": contrast_prompt(own, dossier=True),
                "chosen": "EXPERIMENT: " + json.dumps(chosen),
                "rejected": "EXPERIMENT: " + json.dumps(rejected),
                "metadata": {
                    "pair_id": pair.pair_id,
                    "task_id": own.task_id,
                    "representation": own.representation,
                    "chosen_class": "frontier_specific",
                    "rejected_class": rejected_label,
                    "objective": "set_valued_executable_preference",
                },
            }
        )
    return tuple(records)


def _all_preferences(
    pairs: Sequence[ContrastPair], count: int
) -> Iterable[Mapping[str, Any]]:
    for pair in pairs:
        yield from preference_records(pair, pair.left, pair.right, count=count)
        yield from preference_records(pair, pair.right, pair.left, count=count)


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[str, int]:
    materialized = tuple(rows)
    payload = "".join(json.dumps(row, sort_keys=True) + "\n" for row in materialized)
    path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), len(materialized)


def _class_summary(pairs: Sequence[ContrastPair]) -> Mapping[str, Mapping[str, float]]:
    values: Dict[str, Dict[str, list[int]]] = {}
    for pair in pairs:
        for own, sibling in ((pair.left, pair.right), (pair.right, pair.left)):
            classes = experiment_classes(own, sibling)
            representation = values.setdefault(own.representation, {})
            for label, members in classes.items():
                representation.setdefault(label, []).append(len(members))
    return {
        representation: {
            f"mean_{label}_count": sum(counts) / len(counts)
            for label, counts in sorted(labels.items())
        }
        for representation, labels in sorted(values.items())
    }


def prepare_m43_benchmark(output: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    data = output / "preference"
    data.mkdir(parents=True, exist_ok=True)
    train = build_m43_pairs("train")
    valid = build_m43_pairs("valid")
    test = build_m43_pairs("test")
    train_hash, train_records = _write_jsonl(
        data / "train.jsonl", _all_preferences(train, TRAIN_PREFERENCES_PER_TASK)
    )
    valid_hash, valid_records = _write_jsonl(
        data / "valid.jsonl", _all_preferences(valid, VALID_PREFERENCES_PER_TASK)
    )
    public_hash, _ = _write_jsonl(
        output / "test-public.jsonl",
        (
            {
                "pair_id": pair.pair_id,
                "representation": pair.representation,
                "left_task_id": pair.left.task_id,
                "right_task_id": pair.right.task_id,
                "left_prompt_hash": hashlib.sha256(
                    contrast_prompt(pair.left, dossier=True).encode("utf-8")
                ).hexdigest(),
                "right_prompt_hash": hashlib.sha256(
                    contrast_prompt(pair.right, dossier=True).encode("utf-8")
                ).hexdigest(),
                "blind_prompt_identical": contrast_prompt(pair.left, dossier=False)
                == contrast_prompt(pair.right, dossier=False),
            }
            for pair in test
        ),
    )
    authority_hash, _ = _write_jsonl(
        output / "test-authority.jsonl",
        (
            {
                "pair_id": pair.pair_id,
                "left_class_counts": {
                    label: len(values)
                    for label, values in experiment_classes(pair.left, pair.right).items()
                },
                "right_class_counts": {
                    label: len(values)
                    for label, values in experiment_classes(pair.right, pair.left).items()
                },
                "authority_program": dict(pair.left.source.authority),
            }
            for pair in test
        ),
    )
    counts_by_representation = {
        split: {
            representation: sum(int(pair.representation == representation) for pair in pairs)
            for representation in M43_REPRESENTATIONS
        }
        for split, pairs in (("train", train), ("valid", valid), ("test", test))
    }
    payload = {
        "version": SET_VALUED_EXPERIMENT_VERSION,
        "parent_version": "general-cognitive-contrast-experiment-v42",
        "split_seeds": M43_SPLIT_SEEDS,
        "representations": list(M43_REPRESENTATIONS),
        "per_representation_source_count": M43_PER_REPRESENTATION,
        "minimum_exclusive_fraction": M43_MINIMUM_EXCLUSIVE_FRACTION,
        "counts": {
            "train_pairs": len(train),
            "valid_pairs": len(valid),
            "test_pairs": len(test),
            "test_tasks": len(test) * 2,
            "train_preference_records": train_records,
            "valid_preference_records": valid_records,
            "by_representation": counts_by_representation,
        },
        "class_summary": {
            "train": _class_summary(train),
            "valid": _class_summary(valid),
            "test": _class_summary(test),
        },
        "hashes": {
            "preference_train": train_hash,
            "preference_valid": valid_hash,
            "test_public": public_hash,
            "test_authority": authority_hash,
        },
        "parent_adapter_sha256": PARENT_ADAPTER_SHA256,
        "preference_contract": {
            "positive_class": "frontier_specific",
            "negative_classes": [
                "sibling_specific",
                "shared_informative",
                "uninformative",
            ],
            "train_preferences_per_task": TRAIN_PREFERENCES_PER_TASK,
            "valid_preferences_per_task": VALID_PREFERENCES_PER_TASK,
            "single_canonical_target": False,
            "reward_source": "external_executable_partition",
        },
        "training_recipe": {
            "objective": "simpo_set_valued_executable_preference",
            "initialization": "m42_checkpoint_250",
            "lora_layers": 8,
            "lora_rank": 8,
            "lora_scale": 20.0,
            "iterations": 300,
            "learning_rate": 1e-5,
            "gradient_accumulation_steps": 4,
            "preference_beta": 2.0,
            "chosen_sft_weight": 0.25,
            "checkpoint_interval": 50,
            "validation_interval": 100,
            "max_sequence_length": 1024,
            "seed": 43,
            "checkpoint_selection": "minimum_validation_preference_loss",
        },
        "feasibility_gates": {
            "minimum_contrast_oracle_information_gain": 0.98,
            "minimum_contrast_oracle_assignment_advantage": 0.98,
            "minimum_positive_and_negative_class_coverage": 1.0,
        },
        "model_gates": {
            "minimum_valid_experiment_rate": 0.95,
            "minimum_novel_experiment_rate": 0.90,
            "minimum_predicate_information_gain": 0.75,
            "minimum_predicate_correct_assignment_rate": 0.70,
            "minimum_predicate_assignment_advantage": 0.50,
            "minimum_causal_information_gain": 0.85,
            "minimum_causal_correct_assignment_rate": 0.85,
            "minimum_causal_assignment_advantage": 0.70,
            "minimum_overall_correct_assignment_rate": 0.75,
            "minimum_overall_assignment_advantage": 0.55,
            "minimum_pair_differentiation_rate": 0.80,
            "minimum_information_gain_over_blind": 0.20,
            "minimum_information_gain_over_mismatched": 0.20,
            "minimum_predicate_assignment_gain_over_parent": 0.30,
            "minimum_information_ratio_to_contrast_search8": 0.85,
        },
        "claim_boundary": (
            "M43 tests whether executable set-valued preference learning fixes M42's arbitrary-target "
            "failure on fresh predicate and causal paired frontiers. It initializes from the frozen M42 "
            "adapter, ranks multiple frontier-specific probes above sibling-specific, shared, and "
            "uninformative probes, and evaluates only new seeds. M43 does not test unseen mechanism "
            "grammars or natural scientific experiments."
        ),
    }
    freeze = {**payload, "freeze_id": content_digest(payload)}
    (output / "benchmark-freeze.json").write_text(
        json.dumps(freeze, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return freeze


def verify_m43_benchmark(output: Path) -> Mapping[str, Any]:
    freeze = json.loads((output / "benchmark-freeze.json").read_text(encoding="utf-8"))
    paths = {
        "preference_train": output / "preference/train.jsonl",
        "preference_valid": output / "preference/valid.jsonl",
        "test_public": output / "test-public.jsonl",
        "test_authority": output / "test-authority.jsonl",
    }
    hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    train_ids = {pair.pair_id for pair in build_m43_pairs("train")}
    valid_ids = {pair.pair_id for pair in build_m43_pairs("valid")}
    test = build_m43_pairs("test")
    test_ids = {pair.pair_id for pair in test}
    train_rows = [
        json.loads(line)
        for line in paths["preference_train"].read_text(encoding="utf-8").splitlines()
        if line
    ]
    checks = {
        "hashes_match": hashes == freeze["hashes"],
        "freeze_id_is_content_derived": content_digest(payload) == freeze["freeze_id"],
        "splits_are_disjoint": not (
            train_ids & valid_ids or train_ids & test_ids or valid_ids & test_ids
        ),
        "test_not_available_to_trainer": not (output / "preference/test.jsonl").exists(),
        "multiple_positive_targets_per_prompt": any(
            len({row["chosen"] for row in train_rows if row["prompt"] == prompt}) > 1
            for prompt in {row["prompt"] for row in train_rows}
        ),
        "preferences_are_externally_classified": all(
            row["metadata"]["chosen_class"] == "frontier_specific"
            and row["metadata"]["rejected_class"]
            in set(freeze["preference_contract"]["negative_classes"])
            for row in train_rows
        ),
        "paired_blind_prompts_are_identical": all(
            contrast_prompt(pair.left, dossier=False)
            == contrast_prompt(pair.right, dossier=False)
            for pair in test
        ),
        "parent_adapter_hash_frozen": freeze["parent_adapter_sha256"]
        == PARENT_ADAPTER_SHA256,
        "gates_recipe_and_objective_frozen": (
            "feasibility_gates" in freeze
            and "model_gates" in freeze
            and "training_recipe" in freeze
            and freeze["preference_contract"]["single_canonical_target"] is False
        ),
    }
    return {"checks": checks, "passed": all(checks.values()), "freeze_id": freeze["freeze_id"]}


def run_m43_baselines(output_root: Path, benchmark_root: Path) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    pairs = build_m43_pairs("test")
    conditions = ("random", "search8", "oracle", "contrast_search8", "contrast_oracle")
    results = {
        condition: aggregate_contrasts(
            condition, pairs, _control_values(pairs, condition)
        )
        for condition in conditions
    }
    oracle = results["contrast_oracle"]["metrics"]
    class_coverage = all(
        experiment_classes(own, sibling)["frontier_specific"]
        and any(
            experiment_classes(own, sibling)[label]
            for label in ("sibling_specific", "shared_informative", "uninformative")
        )
        for pair in pairs
        for own, sibling in ((pair.left, pair.right), (pair.right, pair.left))
    )
    gates = freeze["feasibility_gates"]
    checks = {
        "contrast_oracle_information_gain": oracle["mean_normalized_information_gain"]
        >= gates["minimum_contrast_oracle_information_gain"],
        "contrast_oracle_assignment_advantage": oracle["mean_assignment_advantage"]
        >= gates["minimum_contrast_oracle_assignment_advantage"],
        "positive_and_negative_class_coverage": float(class_coverage)
        >= gates["minimum_positive_and_negative_class_coverage"],
    }
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "set_valued_experiment_baselines",
        {
            condition: {
                "records": result["records"],
                "pair_records": result["pair_records"],
            }
            for condition, result in results.items()
        },
    )
    payload = {
        "version": SET_VALUED_EXPERIMENT_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "metrics": {condition: result["metrics"] for condition, result in results.items()},
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
        "predictions_digest": predictions_digest,
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(f"set-valued-experiment-baselines-{manifest['evaluation_id']}", manifest)
    return manifest


def evaluate_m43_model(
    output_root: Path,
    benchmark_root: Path,
    model_path: str,
    condition: str,
    *,
    dossier_mode: str,
    adapter_path: Path,
    batch_size: int = 8,
    max_tokens: int = 40,
) -> Mapping[str, Any]:
    from mlx_lm import load

    if dossier_mode not in {"correct", "blind", "mismatched"}:
        raise ValueError("invalid dossier mode")
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    pairs = build_m43_pairs("test")
    tasks = pair_members(pairs)
    prompts = []
    by_task = {
        pair.left.task_id: (pair.left, pair.right)
        for pair in pairs
    } | {
        pair.right.task_id: (pair.right, pair.left)
        for pair in pairs
    }
    for task in tasks:
        own, sibling = by_task[task.task_id]
        if dossier_mode == "blind":
            prompt = contrast_prompt(own, dossier=False)
        elif dossier_mode == "mismatched":
            prompt = contrast_prompt(own, dossier=True, dossier_task=sibling)
        else:
            prompt = contrast_prompt(own, dossier=True)
        prompts.append(prompt)
    started = time.monotonic()
    model, tokenizer, config = load(
        model_path, adapter_path=str(adapter_path), return_config=True
    )
    chat_prompts = tuple(_chat_prompt(tokenizer, prompt) for prompt in prompts)
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        chat_prompts,
        batch_size=batch_size,
        max_tokens=max_tokens,
        max_batch_tokens=12000,
    )
    values = tuple(parse_experiment(response) for response in responses)
    aggregate = aggregate_contrasts(condition, pairs, values, responses)
    store = ArtifactStore(output_root)
    predictions_digest = store.put(
        "set_valued_experiment_model_predictions",
        {"records": aggregate["records"], "pair_records": aggregate["pair_records"]},
    )
    payload = {
        "version": SET_VALUED_EXPERIMENT_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "condition": condition,
        "dossier_mode": dossier_mode,
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "adapter_path": str(adapter_path),
        "adapter_config_sha256": hashlib.sha256(
            (adapter_path / "adapter_config.json").read_bytes()
        ).hexdigest(),
        "adapter_weights_sha256": hashlib.sha256(
            (adapter_path / "adapters.safetensors").read_bytes()
        ).hexdigest(),
        "metrics": aggregate["metrics"],
        "predictions_digest": predictions_digest,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": peak_memory,
        "generation": {"batch_size": batch_size, "max_tokens": max_tokens},
        "claim_boundary": freeze["claim_boundary"],
    }
    manifest = {**payload, "evaluation_id": content_digest(payload)[:20], "schema": 1}
    store.write_manifest(
        f"set-valued-experiment-model-{condition}-{manifest['evaluation_id']}", manifest
    )
    return manifest


def assess_m43(
    candidate: Mapping[str, Any],
    parent: Mapping[str, Any],
    blind: Mapping[str, Any],
    mismatched: Mapping[str, Any],
    baselines: Mapping[str, Any],
    benchmark_root: Path,
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["model_gates"]
    metrics = candidate["metrics"]
    predicate = metrics["by_representation"]["predicate"]
    causal = metrics["by_representation"]["causal"]
    parent_predicate = parent["metrics"]["by_representation"]["predicate"]
    blind_metrics = blind["metrics"]
    mismatch_metrics = mismatched["metrics"]
    search = baselines["metrics"]["contrast_search8"]
    info = metrics["mean_normalized_information_gain"]
    checks = {
        "feasibility_passed": baselines["passed"],
        "same_benchmark_freeze": all(
            evaluation["benchmark_freeze_id"] == freeze["freeze_id"]
            for evaluation in (candidate, parent, blind, mismatched, baselines)
        ),
        "same_exact_model": (
            candidate["model_path"]
            == parent["model_path"]
            == blind["model_path"]
            == mismatched["model_path"]
        ),
        "valid_experiment_rate": metrics["valid_experiment_rate"]
        >= gates["minimum_valid_experiment_rate"],
        "novel_experiment_rate": metrics["novel_experiment_rate"]
        >= gates["minimum_novel_experiment_rate"],
        "predicate_information_gain": predicate["mean_normalized_information_gain"]
        >= gates["minimum_predicate_information_gain"],
        "predicate_correct_assignment": predicate["correct_assignment_rate"]
        >= gates["minimum_predicate_correct_assignment_rate"],
        "predicate_assignment_advantage": predicate["mean_assignment_advantage"]
        >= gates["minimum_predicate_assignment_advantage"],
        "causal_information_gain": causal["mean_normalized_information_gain"]
        >= gates["minimum_causal_information_gain"],
        "causal_correct_assignment": causal["correct_assignment_rate"]
        >= gates["minimum_causal_correct_assignment_rate"],
        "causal_assignment_advantage": causal["mean_assignment_advantage"]
        >= gates["minimum_causal_assignment_advantage"],
        "overall_correct_assignment": metrics["correct_assignment_rate"]
        >= gates["minimum_overall_correct_assignment_rate"],
        "overall_assignment_advantage": metrics["mean_assignment_advantage"]
        >= gates["minimum_overall_assignment_advantage"],
        "pair_differentiation_rate": metrics["pair_differentiation_rate"]
        >= gates["minimum_pair_differentiation_rate"],
        "information_gain_over_blind": info
        - blind_metrics["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_blind"],
        "information_gain_over_mismatched": info
        - mismatch_metrics["mean_normalized_information_gain"]
        >= gates["minimum_information_gain_over_mismatched"],
        "predicate_assignment_gain_over_parent": predicate["correct_assignment_rate"]
        - parent_predicate["correct_assignment_rate"]
        >= gates["minimum_predicate_assignment_gain_over_parent"],
        "ratio_to_contrast_search8": info / search["mean_normalized_information_gain"]
        >= gates["minimum_information_ratio_to_contrast_search8"],
    }
    payload = {
        "version": SET_VALUED_EXPERIMENT_VERSION,
        "benchmark_freeze_id": freeze["freeze_id"],
        "candidate_evaluation_id": candidate["evaluation_id"],
        "parent_evaluation_id": parent["evaluation_id"],
        "blind_evaluation_id": blind["evaluation_id"],
        "mismatched_evaluation_id": mismatched["evaluation_id"],
        "baseline_evaluation_id": baselines["evaluation_id"],
        "metrics": metrics,
        "controls": {
            "parent_correct": parent["metrics"],
            "adapted_blind": blind_metrics,
            "adapted_mismatched": mismatch_metrics,
            **baselines["metrics"],
        },
        "deltas": {
            "information_gain_over_blind": info
            - blind_metrics["mean_normalized_information_gain"],
            "information_gain_over_mismatched": info
            - mismatch_metrics["mean_normalized_information_gain"],
            "predicate_assignment_gain_over_parent": predicate[
                "correct_assignment_rate"
            ]
            - parent_predicate["correct_assignment_rate"],
            "information_ratio_to_contrast_search8": info
            / search["mean_normalized_information_gain"],
        },
        "gates": gates,
        "checks": checks,
        "passed": all(checks.values()),
    }
    return {**payload, "assessment_id": content_digest(payload)}
