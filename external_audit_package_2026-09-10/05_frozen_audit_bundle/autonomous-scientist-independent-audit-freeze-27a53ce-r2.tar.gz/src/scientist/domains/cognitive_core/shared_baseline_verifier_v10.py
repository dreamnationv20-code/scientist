from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.functional_contracts_v9 import (
    FunctionalContractBundle,
)
from scientist.domains.cognitive_core.shared_substrate_v10 import (
    CandidateCostLedger,
    SharedBaselineReconstruction,
    WAVE_ONE_KEYS,
)
from scientist.domains.cognitive_core.wave1_prior_art_v10 import (
    SHARED_BASELINE_WORK_ID,
    WaveOneBaselineRegistration,
)
from scientist.program.control_plane import (
    AutonomousScientistControlPlane,
    ControlActionKind,
)
from scientist.program.goal_graph import GoalNodeStatus
from scientist.program.literature import ClaimClassification


SHARED_BASELINE_VERIFIER_REF = (
    "cognitive-core-shared-baseline-independent-verifier-v10"
)


@dataclass(frozen=True)
class SharedBaselineVerification:
    check_results: Mapping[str, bool]
    candidate_id: str
    interface_id: str
    trajectory_id: str
    work_package_scores: Mapping[str, float]
    action_kinds: Mapping[str, str]
    pre_progress: Mapping[str, Mapping[str, float | int]]
    post_progress: Mapping[str, Mapping[str, float | int]]
    source_manifest_passed: Mapping[str, bool]
    limitations: Tuple[str, ...]
    verifier_ref: str = SHARED_BASELINE_VERIFIER_REF

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "check_results": dict(sorted(self.check_results.items())),
            "candidate_id": self.candidate_id,
            "interface_id": self.interface_id,
            "trajectory_id": self.trajectory_id,
            "work_package_scores": dict(sorted(self.work_package_scores.items())),
            "action_kinds": dict(sorted(self.action_kinds.items())),
            "pre_progress": self.pre_progress,
            "post_progress": self.post_progress,
            "source_manifest_passed": dict(
                sorted(self.source_manifest_passed.items())
            ),
            "limitations": list(self.limitations),
            "verifier_ref": self.verifier_ref,
            "passed": self.passed,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_shared_baseline_registration(
    *,
    control: AutonomousScientistControlPlane,
    bundle: FunctionalContractBundle,
    reconstruction: SharedBaselineReconstruction,
    registration: WaveOneBaselineRegistration,
    source_manifest_passed: Mapping[str, bool],
    pre_statuses: Mapping[str, GoalNodeStatus],
    pre_progress: Mapping[str, Mapping[str, float | int]],
    pre_compute_spent: float,
) -> SharedBaselineVerification:
    expected_keys = set(bundle.wave_keys[1])
    work_keys = set(WAVE_ONE_KEYS)
    leaf_ids = {
        key: bundle.contracts[key].leaf.node_id for key in WAVE_ONE_KEYS
    }
    actions = {
        item.node_id: item for item in control.next_actions()
    }
    action_kinds = {
        key: actions[leaf_id].kind.value
        for key, leaf_id in leaf_ids.items()
        if leaf_id in actions
    }
    control_value = control.as_dict()
    current_portfolios = control_value["current_portfolio_ids"]
    portfolio_by_id = {
        item["portfolio_id"]: item
        for item in control_value["incumbent_portfolios"]
    }
    registered_primary_rows = tuple(
        next(
            entry
            for entry in portfolio_by_id[current_portfolios[leaf_id]]["entries"]
            if entry["candidate_id"]
            == portfolio_by_id[current_portfolios[leaf_id]]["primary_incumbent_id"]
        )
        for leaf_id in leaf_ids.values()
    ) if all(leaf_id in current_portfolios for leaf_id in leaf_ids.values()) else ()

    observed_by_probe = {
        item.expectation.probe_id: item for item in reconstruction.probe_outcomes
    }
    reconstructed_passes = {
        probe_id: (
            item.observed.kind == item.expectation.action_kind
            and item.observed.payload == item.expectation.payload
        )
        for probe_id, item in observed_by_probe.items()
    }
    reconstructed_scores: Dict[str, float] = {}
    for key in WAVE_ONE_KEYS:
        if key == "system_cost":
            continue
        rows = tuple(
            item
            for item in reconstruction.probe_outcomes
            if item.expectation.work_package_key == key
        )
        reconstructed_scores[key] = (
            sum(reconstructed_passes[item.expectation.probe_id] for item in rows)
            / len(rows)
        )
    expected_cost_fields = set(CandidateCostLedger().as_dict())
    reconstructed_scores["system_cost"] = float(
        set(reconstruction.final_cost.as_dict()) == expected_cost_fields
        and all(
            value >= 0
            for value in reconstruction.final_cost.as_dict().values()
        )
        and reconstruction.final_cost.external_service_calls == 0
    )
    state_chain_valid = bool(reconstruction.steps) and all(
        left.state_after_id == right.state_before_id
        and left.cost_after == right.cost_before
        for left, right in zip(
            reconstruction.steps,
            reconstruction.steps[1:],
        )
    )
    assessment_rows = tuple(registration.assessments.values())
    portfolio_rows = tuple(registration.portfolios.values())
    post_progress = control.graph.progress_by_role()
    checks = {
        "wave_one_contract_set_is_exact": (
            expected_keys == work_keys
            and set(registration.assessments) == work_keys
            and set(registration.portfolios) == work_keys
        ),
        "one_frozen_interface_covers_events_state_identity_and_cost": (
            bool(reconstruction.interface.event_kinds)
            and bool(reconstruction.interface.action_kinds)
            and bool(reconstruction.interface.persistent_state_fields)
            and set(reconstruction.interface.cost_dimensions)
            == expected_cost_fields
            and bool(reconstruction.interface.candidate_identity_rule)
            and bool(reconstruction.interface.state_lifecycle_rule)
        ),
        "one_candidate_identity_is_shared_across_all_five_portfolios": (
            len(registered_primary_rows) == len(WAVE_ONE_KEYS)
            and {
                row["candidate_id"] for row in registered_primary_rows
            } == {reconstruction.candidate.candidate_id}
            and {
                row["executable_digest"] for row in registered_primary_rows
            } == {reconstruction.candidate.executable_digest}
            and {
                row["source_locator"] for row in registered_primary_rows
            } == {"artifact:%s" % registration.baseline_artifact_id}
        ),
        "one_persistent_state_and_cost_trajectory_is_used": (
            state_chain_valid
            and reconstruction.steps[0].state_before_id
            == reconstruction.initial_state_id
            and reconstruction.steps[-1].state_after_id
            == reconstruction.final_state_id
            and reconstruction.steps[-1].cost_after
            == reconstruction.final_cost
        ),
        "candidate_replay_is_exactly_deterministic": (
            reconstruction.replay_identical
        ),
        "all_case_outcomes_and_scores_are_independently_reconstructed": (
            all(
                item.passed == reconstructed_passes[probe_id]
                for probe_id, item in observed_by_probe.items()
            )
            and reconstructed_scores == reconstruction.work_package_scores
        ),
        "smoke_scores_are_honest_about_known_residuals": (
            reconstruction.work_package_scores
            == {
                "procedure_representation": 0.5,
                "relevance_representation": 0.5,
                "requested_change": 1.0,
                "system_cost": 1.0,
                "task_inference": 0.0,
            }
        ),
        "no_full_functional_contract_is_prematurely_claimed": all(
            math.isclose(
                reconstruction.metric_summary["%s_functional_gate" % key],
                0.0,
                rel_tol=0.0,
                abs_tol=1e-12,
            )
            for key in WAVE_ONE_KEYS
        ),
        "cost_ledger_is_complete_nonnegative_and_external_service_free": (
            set(reconstruction.final_cost.as_dict()) == expected_cost_fields
            and all(
                value >= 0
                for value in reconstruction.final_cost.as_dict().values()
            )
            and reconstruction.final_cost.external_service_calls == 0
        ),
        "all_local_source_manifests_passed": (
            bool(source_manifest_passed)
            and all(source_manifest_passed.values())
            and set(source_manifest_passed)
            == set(reconstruction.source_manifests)
        ),
        "literature_reviews_are_closed_and_bound_to_exact_leaves": (
            len(assessment_rows) == len(WAVE_ONE_KEYS)
            and all(item.closure_passed for item in assessment_rows)
            and {
                item.signature.subject_id for item in assessment_rows
            } == set(leaf_ids.values())
            and all(
                item.classification == ClaimClassification.REPRODUCTION
                and item.executable_incumbent_id == SHARED_BASELINE_WORK_ID
                for item in assessment_rows
            )
        ),
        "literature_searches_cover_required_facets_and_multiple_providers": all(
            len({query.provider for query in item.queries}) >= 2
            and item.citation_snowball_complete
            for item in assessment_rows
        ),
        "incumbent_portfolios_are_closed_and_match_current_literature": (
            len(portfolio_rows) == len(WAVE_ONE_KEYS)
            and all(item.closed for item in portfolio_rows)
            and all(
                item.literature_assessment_id
                == registration.assessments[key].assessment_id
                and item.primary.source_work_id == SHARED_BASELINE_WORK_ID
                for key, item in registration.portfolios.items()
            )
        ),
        "wave_one_is_ready_for_campaign_without_starting_one": (
            set(action_kinds) == work_keys
            and all(
                kind == ControlActionKind.START_CAMPAIGN.value
                for kind in action_kinds.values()
            )
            and not control_value["active_campaign_ids"]
            and not control_value["campaigns"]
        ),
        "registration_changed_no_goal_status_or_progress": (
            control.graph.statuses == pre_statuses
            and post_progress == pre_progress
        ),
        "registration_spent_no_experimental_compute": math.isclose(
            control.compute_spent,
            pre_compute_spent,
            rel_tol=0.0,
            abs_tol=1e-12,
        ),
        "scientific_memory_chain_remains_valid": control.memory.verify_chain(),
    }
    return SharedBaselineVerification(
        check_results=checks,
        candidate_id=reconstruction.candidate.candidate_id,
        interface_id=reconstruction.interface.interface_id,
        trajectory_id=reconstruction.trajectory_id,
        work_package_scores=reconstruction.work_package_scores,
        action_kinds=action_kinds,
        pre_progress=pre_progress,
        post_progress=post_progress,
        source_manifest_passed=source_manifest_passed,
        limitations=(
            "This closes baseline reconstruction, not any Wave-1 functional contract.",
            "The frozen smoke suite is deliberately small; Phase 3 must build held-out functional families and shortcut controls.",
            "The literature record supports baseline choice and scope only; it does not authorize a novelty claim.",
        ),
    )
