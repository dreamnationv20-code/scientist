from __future__ import annotations

from scientist.domains.cognitive_core.adapter import CognitiveCoreAdapter
from scientist.kernel.capabilities import ComparisonMode
from scientist.kernel.contracts import (
    AnalysisKind,
    BudgetContract,
    CampaignContract,
    ChannelRelation,
    DiscoveryChannelSpec,
    EvidenceAnalysisContract,
    EvidencePartition,
    GateContract,
    GateCriterion,
    GateKind,
    MetricDirection,
    MetricSpec,
    ProblemCharter,
)


def problem_charter() -> ProblemCharter:
    return ProblemCharter(
        name="Cognitive-core evidence routing",
        statement=(
            "Find a compact learner that preserves known answers under irrelevant "
            "context while using relevant evidence and calibrated abstention."
        ),
        domain_id=CognitiveCoreAdapter.domain_id,
        scope=(
            "matched synthetic cognitive probes",
            "memory, procedure, evidence use, and abstention",
            "seeded train, audit, and replication worlds",
        ),
        anti_scope=(
            "claims about general intelligence",
            "human-facing deployment",
            "unmatched model or token budgets",
        ),
        metrics=(
            MetricSpec(
                name="improvement",
                direction=MetricDirection.MAXIMIZE,
                unit="correctness delta",
                aggregation="paired mean by probe world and seed",
                primary=True,
            ),
            MetricSpec(
                name="candidate_correct",
                direction=MetricDirection.MAXIMIZE,
                unit="correctness",
                aggregation="mean by probe family",
            ),
        ),
        success_definition=(
            "A frozen design improves the preregistered paired score on fresh "
            "probe worlds and survives multi-seed replication."
        ),
        falsification_conditions=(
            "the effect disappears on fresh task worlds",
            "known-answer preservation is traded for evidence-use failure",
            "the independent verifier cannot reconstruct reported correctness",
        ),
    )


def campaign_contract(incumbent_candidate_id: str | None) -> CampaignContract:
    if not incumbent_candidate_id:
        raise ValueError("cognitive-core optimization requires a control")
    adapter = CognitiveCoreAdapter()
    return CampaignContract(
        charter_id=problem_charter().charter_id,
        domain_adapter_ref=adapter.adapter_version,
        incumbent_candidate_id=incumbent_candidate_id,
        search_families=(),
        budget=BudgetContract(
            outer_rounds=3,
            proposals_per_family_per_round=8,
            failure_mining_evaluations_per_round=24,
            audit_cases_per_proposal=48,
            replication_cases=240,
        ),
        evaluator_ref=adapter.evaluator_ref,
        verifier_ref=adapter.verifier_ref,
        development_partitions=(
            EvidencePartition.DEVELOPMENT,
            EvidencePartition.GUARD,
        ),
        gates=(
            GateContract(
                kind=GateKind.REPLICATION_NOMINATION,
                evidence_partition=EvidencePartition.AUDIT,
                criteria=(
                    GateCriterion(
                        metric="mean_improvement_ci_lower",
                        operator=">",
                        threshold=0.0,
                        description="paired audit confidence interval is positive",
                    ),
                ),
                minimum_evidence_count=48,
            ),
        ),
        comparison_mode=ComparisonMode.PAIRED_INCUMBENT,
        discovery_channels=(
            DiscoveryChannelSpec(
                "architecture_revision",
                ChannelRelation.INCUMBENT_DESCENDANT,
                "current model architecture and training trace",
                True,
            ),
            DiscoveryChannelSpec(
                "independent_training_mechanism",
                ChannelRelation.INDEPENDENT,
                "task contract but no incumbent weights or code",
                True,
            ),
            DiscoveryChannelSpec(
                "causal_intervention",
                ChannelRelation.EXPERIMENT_DESIGN,
                "failure evidence and intervention variables",
                True,
            ),
        ),
        evidence_analysis=EvidenceAnalysisContract(
            analysis_kind=AnalysisKind.PAIRED_MEAN_CONFIDENCE,
            primary_metric="improvement",
            independent_unit="probe world and seed",
            group_keys=("probe_kind", "seed", "knowledge_seed"),
            analyzer_ref="cognitive-core-paired-evidence-v1",
            minimum_independent_units=48,
            confidence_level=0.95,
        ),
    )

