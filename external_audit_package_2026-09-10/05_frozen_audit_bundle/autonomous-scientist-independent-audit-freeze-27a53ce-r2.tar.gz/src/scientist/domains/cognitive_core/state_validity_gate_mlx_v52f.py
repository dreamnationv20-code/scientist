from __future__ import annotations

from typing import Any, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.domains.cognitive_core.causal_controller_mlx_v52 import (
    InstalledCausalController,
    prompt_token_layout,
)


def validity_token_layout(
    tokenizer: Any,
    prompt: str,
    history: Sequence[Mapping[str, Any]],
    current_scope_label: str,
) -> Mapping[str, Any]:
    """Bind output and scope labels to their internal token positions."""
    base = dict(prompt_token_layout(tokenizer, prompt, history))
    rendered = str(base["rendered"])
    underlying = getattr(tokenizer, "_tokenizer", tokenizer)
    encoded = underlying(
        rendered,
        add_special_tokens=False,
        return_offsets_mapping=True,
    )
    offsets = tuple(
        (int(left), int(right)) for left, right in encoded["offset_mapping"]
    )

    def last_token_for_span(start: int, end: int) -> int:
        candidates = [
            index
            for index, (left, right) in enumerate(offsets)
            if right > start and left < end and right > left
        ]
        if not candidates:
            raise RuntimeError("could not bind an M52f scope label to a token")
        return max(candidates)

    current_marker = f"Current scope_id: {current_scope_label}"
    current_line = rendered.find(current_marker)
    if current_line < 0:
        raise RuntimeError("could not locate the M52f current scope label")
    current_start = current_line + current_marker.rfind(current_scope_label)
    current_position = last_token_for_span(
        current_start, current_start + len(current_scope_label)
    )

    cursor = 0
    scope_positions = []
    for row in history:
        marker = "slot %d scope_id=%s" % (
            int(row["slot"]),
            str(row["scope_label"]),
        )
        line = rendered.find(marker, cursor)
        if line < 0:
            raise RuntimeError("could not locate an M52f evidence scope label")
        label = str(row["scope_label"])
        start = line + marker.rfind(label)
        scope_positions.append(last_token_for_span(start, start + len(label)))
        cursor = line + len(marker)
    return {
        **base,
        "slot_scope_positions": tuple(scope_positions),
        "current_scope_position": int(current_position),
    }


def semantic_validity_token_layout(
    tokenizer: Any,
    prompt: str,
    history: Sequence[Mapping[str, Any]],
    current_state_text: str,
) -> Mapping[str, Any]:
    """Bind natural-language state descriptions to layer-internal positions."""
    base = dict(prompt_token_layout(tokenizer, prompt, history))
    rendered = str(base["rendered"])
    underlying = getattr(tokenizer, "_tokenizer", tokenizer)
    encoded = underlying(
        rendered,
        add_special_tokens=False,
        return_offsets_mapping=True,
    )
    offsets = tuple(
        (int(left), int(right)) for left, right in encoded["offset_mapping"]
    )

    def last_token_for_span(start: int, end: int) -> int:
        candidates = [
            index
            for index, (left, right) in enumerate(offsets)
            if right > start and left < end and right > left
        ]
        if not candidates:
            raise RuntimeError("could not bind an M52g semantic state span")
        return max(candidates)

    current_marker = f"Current research state: {current_state_text}"
    current_line = rendered.find(current_marker)
    if current_line < 0:
        raise RuntimeError("could not locate the M52g current research state")
    current_start = current_line + current_marker.rfind(current_state_text)
    current_position = last_token_for_span(
        current_start, current_start + len(current_state_text)
    )

    cursor = 0
    state_positions = []
    for row in history:
        basis = str(row["applicability_basis"])
        marker = f"Applicability basis: {basis}"
        line = rendered.find(marker, cursor)
        if line < 0:
            raise RuntimeError("could not locate an M52g applicability basis")
        start = line + marker.rfind(basis)
        state_positions.append(last_token_for_span(start, start + len(basis)))
        cursor = line + len(marker)
    return {
        **base,
        "slot_scope_positions": tuple(state_positions),
        "current_scope_position": int(current_position),
    }


class StateValidityGate(nn.Module):
    """Compare an evidence scope with the current scope inside the model."""

    def __init__(self, hidden_size: int, width: int = 32) -> None:
        super().__init__()
        self.slot_scope_in = nn.Linear(hidden_size, width)
        self.current_scope_in = nn.Linear(hidden_size, width)
        self.joint_in = nn.Linear(4 * width, width)
        self.validity_out = nn.Linear(width, 1)

    def __call__(
        self,
        slot_scope_states: mx.array,
        current_scope_state: mx.array,
    ) -> mx.array:
        slot = nn.silu(self.slot_scope_in(slot_scope_states.astype(mx.float32)))
        current = nn.silu(
            self.current_scope_in(current_scope_state.astype(mx.float32))
        )
        current = mx.broadcast_to(
            current[:, None, :],
            (slot.shape[0], slot.shape[1], current.shape[-1]),
        )
        joint = mx.concatenate(
            (slot, current, mx.abs(slot - current), slot * current), axis=-1
        )
        return self.validity_out(nn.silu(self.joint_in(joint))).squeeze(-1)


class ValidityGatedController(nn.Module):
    """A frozen M52 controller with one trainable state-validity gate."""

    def __init__(
        self,
        controller: InstalledCausalController,
        *,
        gate_width: int = 32,
        validity_penalty_scale: float = 4.0,
    ) -> None:
        super().__init__()
        self.controller = controller
        self.gate = StateValidityGate(
            int(controller.backbone.args.hidden_size), int(gate_width)
        )
        self.validity_penalty_scale = float(validity_penalty_scale)

    @staticmethod
    def effective_action_logits(
        raw_difference: mx.array,
        validity_logits: mx.array,
        slot_mask: mx.array,
        revise_threshold: mx.array,
        penalty_scale: float,
    ) -> Tuple[mx.array, mx.array]:
        # log(sigmoid(v)) is approximately zero for valid evidence and tends to
        # negative infinity for evidence judged invalid.  It can therefore only
        # suppress the already-frozen M52 difference score, never manufacture one.
        log_validity = -mx.logaddexp(
            mx.zeros_like(validity_logits), -validity_logits
        )
        effective_difference = raw_difference.astype(mx.float32) + (
            float(penalty_scale) * log_validity
        )
        effective_difference = mx.where(
            slot_mask,
            effective_difference,
            mx.full(
                effective_difference.shape,
                -1e4,
                dtype=effective_difference.dtype,
            ),
        )
        revise = mx.broadcast_to(
            revise_threshold[None, :], (raw_difference.shape[0], 1)
        )
        return effective_difference, mx.concatenate(
            (revise.astype(mx.float32), effective_difference), axis=-1
        )

    def encode_with_validity(
        self,
        inputs: mx.array,
        difference_positions: mx.array,
        slot_scope_positions: mx.array,
        current_scope_positions: mx.array,
        slot_mask: mx.array,
    ) -> Tuple[mx.array, mx.array, mx.array, mx.array]:
        h, _, raw_difference, _, _ = self.controller.encode_to_causal_site(
            inputs, difference_positions, slot_mask
        )
        batch_indices = mx.arange(h.shape[0])[:, None]
        safe_slot_positions = mx.maximum(slot_scope_positions, mx.array(0))
        slot_scope_states = h[batch_indices, safe_slot_positions]
        current_scope_states = h[
            mx.arange(h.shape[0]), mx.maximum(current_scope_positions, mx.array(0))
        ]
        validity_logits = self.gate(slot_scope_states, current_scope_states)
        effective_difference, action_logits = self.effective_action_logits(
            raw_difference,
            validity_logits,
            slot_mask,
            self.controller.bottleneck.revise_threshold,
            self.validity_penalty_scale,
        )
        return raw_difference, validity_logits, effective_difference, action_logits


def _binary_cross_entropy(logits: mx.array, targets: mx.array) -> mx.array:
    return (
        mx.maximum(logits, 0.0)
        - logits * targets
        + mx.log1p(mx.exp(-mx.abs(logits)))
    )


def state_validity_gate_loss(
    gate: StateValidityGate,
    slot_scope_states: mx.array,
    current_scope_states: mx.array,
    raw_difference: mx.array,
    validity_targets: mx.array,
    action_targets: mx.array,
    slot_mask: mx.array,
    revise_threshold: mx.array,
    penalty_scale: float,
) -> Tuple[mx.array, Tuple[mx.array, mx.array]]:
    validity_logits = gate(slot_scope_states, current_scope_states)
    validity_values = _binary_cross_entropy(
        validity_logits.astype(mx.float32), validity_targets.astype(mx.float32)
    )
    count = mx.maximum(slot_mask.sum(), mx.array(1))
    validity_loss = (
        validity_values * slot_mask.astype(mx.float32)
    ).sum() / count
    _, action_logits = ValidityGatedController.effective_action_logits(
        raw_difference,
        validity_logits,
        slot_mask,
        revise_threshold,
        penalty_scale,
    )
    action_loss = nn.losses.cross_entropy(action_logits, action_targets).mean()
    return validity_loss + action_loss, (validity_loss, action_loss)
