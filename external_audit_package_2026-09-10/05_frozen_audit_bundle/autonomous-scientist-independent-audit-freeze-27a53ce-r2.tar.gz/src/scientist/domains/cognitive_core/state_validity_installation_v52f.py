from __future__ import annotations

import hashlib
import itertools
import json
import random
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.balanced_output_controller_v50 import (
    M50_MODEL_SNAPSHOT,
    M50_OUTPUT_ALGEBRAS,
    M50_REPRESENTATIONS,
    _support,
    _task_signature,
)
from scientist.domains.cognitive_core.causal_controller_installation_v52 import (
    _slot_difference_targets,
    build_m52_cases,
)
from scientist.domains.cognitive_core.output_only_controller_v49 import (
    _task_lines,
    raw_candidate_outputs,
)
from scientist.domains.cognitive_core.repair_benchmark_v32 import _build_task
from scientist.domains.cognitive_core.sequential_controller_validation_v52e import (
    M52E_M52_CHECKPOINT_SHA256,
    M52E_REPRESENTATIONS,
    M52E_STAGES,
    build_m52e_trajectories,
    execute_scoped_action,
    scoped_informative_slots,
    sequential_metrics,
)
from scientist.domains.cognitive_core.set_valued_experiment_v43 import (
    _experiment_task as _m43_experiment_task,
)


STATE_VALIDITY_INSTALLATION_VERSION = (
    "general-cognitive-state-validity-installation-v52f"
)
M52F_SEED = 52671
M52F_SPLITS = ("train", "valid", "confirmation")
M52F_TRAJECTORIES_PER_REPRESENTATION = {
    "train": 5,
    "valid": 2,
    "confirmation": 5,
}
M52F_CONTEXTS = {
    "train": ("persistent",),
    "valid": ("persistent",),
    "confirmation": ("persistent", "current_only", "scope_rotated"),
}
M52F_SCOPE_LABELS = {
    "train": ("scope-17", "scope-29", "scope-43", "scope-61"),
    "valid": ("scope-71", "scope-83", "scope-97", "scope-109"),
    "confirmation": ("scope-127", "scope-149", "scope-173", "scope-197"),
}
M52F_REPRESENTATIONS = M52E_REPRESENTATIONS
M52F_M52E_RESULT_ID = (
    "98917b7dd01e10ec3b47fc52069a9125dd85b35354132e690e5f09091040e712"
)


def _stable_seed(split: str, representation: str, source_index: int) -> int:
    material = f"{M52F_SEED}:{split}:{representation}:{source_index}"
    return int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)


def _two_candidate_task(
    split: str, representation: str, source_index: int
) -> Tuple[Any, Tuple[Any, ...], Tuple[Any, ...]] | None:
    rng = random.Random(_stable_seed(split, representation, source_index))
    source = _build_task(f"m52f_{split}", representation, source_index, rng)
    base = _m43_experiment_task(source)
    if base is None:
        return None
    candidates = sorted(base.frontier, key=lambda item: item.key)
    for left, right in itertools.combinations(candidates, 2):
        provisional = replace(base, frontier=(left, right))
        equal, unequal = _support(provisional)
        if equal and unequal:
            task_id = "m52f-task-" + content_digest(
                {
                    "split": split,
                    "representation": representation,
                    "source_index": source_index,
                    "frontier": [left.key, right.key],
                    "version": STATE_VALIDITY_INSTALLATION_VERSION,
                }
            )[:24]
            return replace(provisional, task_id=task_id), equal, unequal
    return None


def _display_history(
    history: Sequence[Mapping[str, Any]], material: str
) -> Tuple[Mapping[str, Any], ...]:
    ordered = list(history)
    seed = int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)
    random.Random(seed).shuffle(ordered)
    return tuple({**row, "slot": slot} for slot, row in enumerate(ordered, 1))


def _current_only_history(
    history: Sequence[Mapping[str, Any]], current_stage: int
) -> Tuple[Mapping[str, Any], ...]:
    selected = [
        row for row in history if int(row["scope_stage"]) == int(current_stage)
    ]
    return tuple({**row, "slot": index} for index, row in enumerate(selected, 1))


def _scope_rotated_history(
    history: Sequence[Mapping[str, Any]], current_stage: int
) -> Tuple[Mapping[str, Any], ...]:
    if len(history) <= 1:
        return tuple(dict(row) for row in history)
    labels = [str(row["scope_label"]) for row in history]
    shift = 1 + (int(current_stage) * 2) % (len(labels) - 1)
    rotated = labels[-shift:] + labels[:-shift]
    return tuple(
        {**row, "scope_label": label}
        for row, label in zip(history, rotated)
    )


def state_validity_prompt(
    task: Any,
    history: Sequence[Mapping[str, Any]],
    current_scope_label: str,
) -> str:
    lines = _task_lines(task)
    lines.extend(
        (
            f"Current scope_id: {current_scope_label}",
            "Execution history is shown in display-slot order, not chronological order.",
            "A result is valid only when its scope_id equals the current scope_id.",
            "Results from any other scope_id are stale even when their outputs differ.",
            "Execution history:",
        )
    )
    for row in history:
        lines.append(
            "  slot %d scope_id=%s turn=%d experiment=%s"
            % (
                int(row["slot"]),
                str(row["scope_label"]),
                int(row["turn"]),
                json.dumps(row["experiment"]),
            )
        )
        lines.append("    c1_output=" + json.dumps(row["outputs"][0], sort_keys=True))
        lines.append("    c2_output=" + json.dumps(row["outputs"][1], sort_keys=True))
    lines.extend(
        (
            "Make the control decision yourself from current-scope evidence.",
            "Do not invent an experiment in this response.",
            "If a current-scope slot achieves the goal, return exactly: SELECT: <slot number>",
            "If no current-scope slot achieves the goal, return exactly: REVISE",
        )
    )
    return "\n".join(lines)


def _prior_signatures() -> set[str]:
    result = {
        case["task_signature"]
        for split in ("train", "valid", "confirmation")
        for case in build_m52_cases(split)
    }
    result.update(
        stage["task_signature"]
        for trajectory in build_m52e_trajectories()
        for stage in trajectory["stages"]
    )
    return result


@lru_cache(maxsize=None)
def build_m52f_trajectories(
    split: str,
    representations: Tuple[str, ...] = M52F_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    if split not in M52F_SPLITS:
        raise ValueError(f"unknown M52f split: {split}")
    used = _prior_signatures()
    split_index = M52F_SPLITS.index(split)
    for earlier in M52F_SPLITS[:split_index]:
        used.update(
            stage["task_signature"]
            for trajectory in build_m52f_trajectories(earlier, M52F_REPRESENTATIONS)
            for stage in trajectory["stages"]
        )
    trajectories = []
    count = M52F_TRAJECTORIES_PER_REPRESENTATION[split]
    labels = M52F_SCOPE_LABELS[split]
    for representation in representations:
        source_index = 0
        for trajectory_index in range(count):
            chronological = []
            stages = []
            task_signatures = []
            for stage, scope_label in zip(M52E_STAGES, labels):
                while True:
                    candidate = _two_candidate_task(
                        split, representation, source_index
                    )
                    source_index += 1
                    if candidate is None:
                        if source_index > 30_000:
                            raise RuntimeError(
                                f"could not build M52f {split} {representation} tasks"
                            )
                        continue
                    task, equal_values, unequal_values = candidate
                    signature = _task_signature(task)
                    if signature in used:
                        continue
                    used.add(signature)
                    break
                task_signatures.append(signature)
                equal_value = equal_values[(trajectory_index + stage) % len(equal_values)]
                evidence_value = unequal_values[
                    (trajectory_index * 3 + stage) % len(unequal_values)
                ]
                turn = len(chronological) + 1
                chronological.append(
                    {
                        "slot": turn,
                        "turn": turn,
                        "scope_stage": stage,
                        "scope_label": scope_label,
                        "semantic_id": f"stage-{stage}-equal",
                        "experiment": equal_value,
                        "outputs": list(raw_candidate_outputs(task, equal_value)),
                    }
                )
                pre = _display_history(
                    chronological,
                    f"{split}:{representation}:{trajectory_index}:{stage}:pre",
                )
                turn = len(chronological) + 1
                chronological.append(
                    {
                        "slot": turn,
                        "turn": turn,
                        "scope_stage": stage,
                        "scope_label": scope_label,
                        "semantic_id": f"stage-{stage}-evidence",
                        "experiment": evidence_value,
                        "outputs": list(raw_candidate_outputs(task, evidence_value)),
                    }
                )
                post = _display_history(
                    chronological,
                    f"{split}:{representation}:{trajectory_index}:{stage}:post",
                )
                stages.append(
                    {
                        "stage": stage,
                        "scope_label": scope_label,
                        "task": task,
                        "task_signature": signature,
                        "pre_evidence_history": pre,
                        "post_evidence_history": post,
                    }
                )
            trajectory_id = "m52f-trajectory-" + content_digest(
                {
                    "split": split,
                    "representation": representation,
                    "trajectory_index": trajectory_index,
                    "task_signatures": task_signatures,
                    "version": STATE_VALIDITY_INSTALLATION_VERSION,
                }
            )[:24]
            trajectories.append(
                {
                    "trajectory_id": trajectory_id,
                    "representation": representation,
                    "output_algebra": M50_OUTPUT_ALGEBRAS[representation],
                    "stages": tuple(stages),
                }
            )
    return tuple(trajectories)


def build_m52f_rows(
    split: str,
    representations: Tuple[str, ...] = M52F_REPRESENTATIONS,
) -> Tuple[Mapping[str, Any], ...]:
    rows = []
    for trajectory in build_m52f_trajectories(split, representations):
        for stage_state in trajectory["stages"]:
            stage = int(stage_state["stage"])
            current_label = str(stage_state["scope_label"])
            for phase, persistent_history in (
                ("pre_evidence", stage_state["pre_evidence_history"]),
                ("post_evidence", stage_state["post_evidence_history"]),
            ):
                contexts = {
                    "persistent": persistent_history,
                    "current_only": _current_only_history(persistent_history, stage),
                    "scope_rotated": _scope_rotated_history(persistent_history, stage),
                }
                for context in M52F_CONTEXTS[split]:
                    prompt_history = contexts[context]
                    environment_history = (
                        contexts["current_only"]
                        if context == "current_only"
                        else persistent_history
                    )
                    informative = scoped_informative_slots(environment_history, stage)
                    expected_action = 0 if phase == "pre_evidence" else informative[0]
                    record_id = "m52f-record-" + content_digest(
                        {
                            "split": split,
                            "trajectory_id": trajectory["trajectory_id"],
                            "stage": stage,
                            "phase": phase,
                            "context": context,
                            "version": STATE_VALIDITY_INSTALLATION_VERSION,
                        }
                    )[:24]
                    rows.append(
                        {
                            "prompt": state_validity_prompt(
                                stage_state["task"], prompt_history, current_label
                            ),
                            "metadata": {
                                "record_id": record_id,
                                "split": split,
                                "trajectory_id": trajectory["trajectory_id"],
                                "stage": stage,
                                "phase": phase,
                                "context_variant": context,
                                "current_scope_label": current_label,
                                "task_id": stage_state["task"].task_id,
                                "task_signature": stage_state["task_signature"],
                                "representation": trajectory["representation"],
                                "output_algebra": trajectory["output_algebra"],
                                "prefix_length": len(prompt_history),
                                "prompt_history": list(prompt_history),
                                "environment_history": list(environment_history),
                                "slot_difference_targets": list(
                                    _slot_difference_targets(prompt_history)
                                ),
                                "slot_validity_targets": [
                                    int(str(row["scope_label"]) == current_label)
                                    for row in prompt_history
                                ],
                                "action_target": int(expected_action),
                                "stale_informative_slots": [
                                    int(row["slot"])
                                    for row in environment_history
                                    if int(row["scope_stage"]) < stage
                                    and json.dumps(
                                        row["outputs"][0],
                                        sort_keys=True,
                                        separators=(",", ":"),
                                    )
                                    != json.dumps(
                                        row["outputs"][1],
                                        sort_keys=True,
                                        separators=(",", ":"),
                                    )
                                ],
                            },
                        }
                    )
    return tuple(rows)


def _write_immutable(path: Path, payload: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != payload:
        raise RuntimeError(f"refusing to overwrite immutable M52f artifact: {path}")
    if not path.exists():
        path.write_text(payload, encoding="utf-8")
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json_payload(value: Any) -> str:
    return json.dumps(value, indent=2, sort_keys=True) + "\n"


def _jsonl_payload(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _protocol_payload(project: Path) -> Mapping[str, Any]:
    m52_root = project / "runs/cognitive_core/causal_controller_installation_v52"
    m52e_root = project / "runs/cognitive_core/sequential_controller_validation_v52e"
    checkpoint = m52_root / "adapter/0000160_adapters.safetensors"
    m52e_result = json.loads((m52e_root / "sequential-controller-result.json").read_text())
    return {
        "version": STATE_VALIDITY_INSTALLATION_VERSION,
        "parent_version": "general-cognitive-sequential-controller-validation-v52e",
        "scientific_question": (
            "Can a small internal state-validity gate repair the exact M52e stale-"
            "evidence failure while the proven M52 difference scorer and pointer remain frozen?"
        ),
        "seed": M52F_SEED,
        "representations": list(M52F_REPRESENTATIONS),
        "stages": list(M52E_STAGES),
        "scope_labels": {key: list(value) for key, value in M52F_SCOPE_LABELS.items()},
        "trajectories_per_representation": dict(M52F_TRAJECTORIES_PER_REPRESENTATION),
        "frozen_model": {
            "snapshot": M50_MODEL_SNAPSHOT,
            "m52_checkpoint_source": (
                "runs/cognitive_core/causal_controller_installation_v52/adapter/"
                "0000160_adapters.safetensors"
            ),
            "m52_checkpoint_sha256": _sha256(checkpoint),
            "m52e_result_id": m52e_result["result_id"],
            "m52e_diagnosis": "missing_state_validity_representation",
        },
        "architecture_contract": {
            "causal_layer": 14,
            "frozen_components": [
                "Qwen2.5-1.5B backbone",
                "M47 LoRA policy",
                "M52 difference scorer",
                "M52 revise threshold",
                "M52 pointer",
                "language decoder",
            ],
            "trainable_component": "state_validity_gate_only",
            "gate_inputs": (
                "layer-14 hidden states at each evidence scope label and the current scope label"
            ),
            "gate_output": (
                "a multiplicative log-probability penalty that can suppress but cannot create "
                "an M52 difference score"
            ),
            "scope_generalization": (
                "train, validation, and confirmation use disjoint scope identifiers"
            ),
            "language_decoder_calls": 0,
        },
        "training_recipe": {
            "seed": M52F_SEED,
            "gate_width": 32,
            "validity_penalty_scale": 4.0,
            "learning_rate": 0.003,
            "iterations": 1200,
            "checkpoint_interval": 200,
            "checkpoint_candidates": [200, 400, 600, 800, 1000, 1200],
            "loss": "slot-validity binary cross entropy plus frozen-pointer action cross entropy",
            "checkpoint_selection": (
                "highest validation action accuracy, then validity accuracy, then earliest checkpoint"
            ),
            "confirmation_access_during_selection": False,
        },
        "confirmation_controls": {
            "m52_baseline": "remove the learned validity penalty",
            "current_only": "remove all stale evidence",
            "scope_rotated": "rotate only visible scope labels",
            "validity_rotated": "rotate only learned validity logits",
            "oracle_validity": "apply the same actuator using true scope validity",
        },
        "confirmation_contract": {
            "minimum_persistent_decision_accuracy": 0.90,
            "minimum_persistent_stage_success": 0.85,
            "minimum_persistent_trajectory_success": 0.70,
            "minimum_each_representation_decision_accuracy": 0.80,
            "minimum_each_later_stage_recovery_accuracy": 0.85,
            "minimum_terminal_select_accuracy": 0.90,
            "minimum_current_only_stage_success": 0.95,
            "minimum_validity_accuracy": 0.90,
            "minimum_each_representation_validity_accuracy": 0.85,
            "minimum_gain_over_m52_baseline": 0.50,
            "minimum_gain_over_scope_rotated": 0.25,
            "minimum_gain_over_validity_rotated": 0.35,
            "minimum_oracle_validity_stage_success": 0.95,
            "require_m52_checkpoint_unchanged": True,
            "require_zero_trainable_base_tensors": True,
        },
        "integrity_contract": {
            "all_prior_and_split_mechanisms_disjoint": True,
            "scope_identifiers_disjoint_across_splits": True,
            "confirmation_evaluated_only_after_checkpoint_selection": True,
            "terminal_outcomes_recomputed_from_scoped_outputs": True,
            "base_checkpoint_immutable": True,
        },
        "claim_boundary": (
            "M52f tests an internal validity gate on held-out synthetic staged mechanism "
            "episodes. Passing would establish this sequential control primitive, not natural-"
            "task transfer, autonomous tool use, or general reasoning parity."
        ),
    }


def prepare_m52f_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    protocol_payload = _protocol_payload(project)
    protocol = {**protocol_payload, "protocol_freeze_id": content_digest(protocol_payload)}
    _write_immutable(output / "protocol-freeze.json", _json_payload(protocol))
    hashes = {}
    counts = {}
    for split in M52F_SPLITS:
        rows = build_m52f_rows(split)
        hashes[split] = _write_immutable(
            output / f"controller/{split}.jsonl", _jsonl_payload(rows)
        )
        counts[split] = len(rows)
    payload = {**protocol, "hashes": hashes, "counts": counts}
    freeze = {**payload, "freeze_id": content_digest(payload)}
    _write_immutable(output / "benchmark-freeze.json", _json_payload(freeze))
    verification = verify_m52f_benchmark(output, project)
    _write_immutable(output / "benchmark-verification.json", _json_payload(verification))
    return freeze


def _rows(path: Path) -> Tuple[Mapping[str, Any], ...]:
    return tuple(json.loads(line) for line in path.read_text().splitlines() if line)


def verify_m52f_benchmark(output: Path, project: Path) -> Mapping[str, Any]:
    protocol = json.loads((output / "protocol-freeze.json").read_text())
    freeze = json.loads((output / "benchmark-freeze.json").read_text())
    protocol_payload = {
        key: value for key, value in protocol.items() if key != "protocol_freeze_id"
    }
    freeze_payload = {key: value for key, value in freeze.items() if key != "freeze_id"}
    stored = {
        split: _rows(output / f"controller/{split}.jsonl") for split in M52F_SPLITS
    }
    signatures = {
        split: {row["metadata"]["task_signature"] for row in rows}
        for split, rows in stored.items()
    }
    prior = _prior_signatures()
    split_disjoint = all(
        not bool(signatures[left] & signatures[right])
        for index, left in enumerate(M52F_SPLITS)
        for right in M52F_SPLITS[index + 1 :]
    )
    targets_valid = True
    controls_valid = True
    for split, rows in stored.items():
        for row in rows:
            metadata = row["metadata"]
            prompt_history = metadata["prompt_history"]
            expected_validity = [
                int(str(item["scope_label"]) == metadata["current_scope_label"])
                for item in prompt_history
            ]
            targets_valid = targets_valid and (
                expected_validity == metadata["slot_validity_targets"]
                and len(prompt_history) == metadata["prefix_length"]
            )
            replay = execute_scoped_action(
                metadata["environment_history"],
                int(metadata["action_target"]),
                metadata["phase"],
                int(metadata["stage"]),
            )
            targets_valid = targets_valid and bool(
                replay["transitioned"]
                if metadata["phase"] == "pre_evidence"
                else replay["success"]
            )
            if metadata["context_variant"] == "current_only":
                controls_valid = controls_valid and all(
                    int(item["scope_stage"]) == int(metadata["stage"])
                    for item in metadata["environment_history"]
                )
            if metadata["context_variant"] == "scope_rotated":
                controls_valid = controls_valid and [
                    (item["slot"], item["experiment"], item["outputs"])
                    for item in metadata["prompt_history"]
                ] == [
                    (item["slot"], item["experiment"], item["outputs"])
                    for item in metadata["environment_history"]
                ]
    checkpoint = project / freeze["frozen_model"]["m52_checkpoint_source"]
    m52e_result = json.loads(
        (
            project
            / "runs/cognitive_core/sequential_controller_validation_v52e/"
            "sequential-controller-result.json"
        ).read_text()
    )
    checks = {
        "protocol_id_is_content_derived": content_digest(protocol_payload)
        == protocol["protocol_freeze_id"],
        "freeze_id_is_content_derived": content_digest(freeze_payload)
        == freeze["freeze_id"],
        "stored_rows_reproduce": all(
            stored[split] == build_m52f_rows(split) for split in M52F_SPLITS
        ),
        "file_hashes_match": all(
            _sha256(output / f"controller/{split}.jsonl")
            == freeze["hashes"][split]
            for split in M52F_SPLITS
        ),
        "counts_match": all(
            len(stored[split]) == freeze["counts"][split] for split in M52F_SPLITS
        ),
        "prior_mechanisms_excluded": all(
            not bool(signatures[split] & prior) for split in M52F_SPLITS
        ),
        "splits_are_mechanism_disjoint": split_disjoint,
        "scope_labels_are_split_disjoint": all(
            not bool(set(M52F_SCOPE_LABELS[left]) & set(M52F_SCOPE_LABELS[right]))
            for index, left in enumerate(M52F_SPLITS)
            for right in M52F_SPLITS[index + 1 :]
        ),
        "targets_and_terminal_semantics_replay": targets_valid,
        "confirmation_controls_preserve_required_semantics": controls_valid,
        "m52_checkpoint_matches": _sha256(checkpoint)
        == freeze["frozen_model"]["m52_checkpoint_sha256"]
        == M52E_M52_CHECKPOINT_SHA256,
        "m52e_parent_result_matches": m52e_result["result_id"]
        == freeze["frozen_model"]["m52e_result_id"]
        == M52F_M52E_RESULT_ID,
    }
    return {
        "protocol_freeze_id": protocol["protocol_freeze_id"],
        "freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }


def validity_metrics(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    def summarize(rows: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
        correct = sum(int(item) for row in rows for item in row["validity_correct"])
        total = sum(len(row["validity_correct"]) for row in rows)
        return {"slot_count": total, "accuracy": correct / max(total, 1)}

    return {
        **summarize(records),
        "by_representation": {
            representation: summarize(
                [row for row in records if row["representation"] == representation]
            )
            for representation in M52F_REPRESENTATIONS
        },
    }


def select_m52f_checkpoint(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    if not candidates:
        raise ValueError("M52f checkpoint selection requires candidates")
    return sorted(
        candidates,
        key=lambda row: (
            -float(row["action_accuracy"]),
            -float(row["validity_accuracy"]),
            int(row["iteration"]),
        ),
    )[0]


def m52f_passed(
    learned: Mapping[str, Any],
    current_only: Mapping[str, Any],
    scope_rotated: Mapping[str, Any],
    validity_rotated: Mapping[str, Any],
    baseline: Mapping[str, Any],
    oracle: Mapping[str, Any],
    validity: Mapping[str, Any],
    contract: Mapping[str, Any],
    *,
    base_trainable_tensor_count: int,
    m52_checkpoint_unchanged: bool,
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "persistent_decision_accuracy": learned["decision_accuracy"]
        >= contract["minimum_persistent_decision_accuracy"],
        "persistent_stage_success": learned["stage_success"]
        >= contract["minimum_persistent_stage_success"],
        "persistent_trajectory_success": learned["trajectory_success"]
        >= contract["minimum_persistent_trajectory_success"],
        "each_representation_decision_accuracy": min(
            row["decision_accuracy"] for row in learned["by_representation"].values()
        )
        >= contract["minimum_each_representation_decision_accuracy"],
        "each_later_stage_recovery_accuracy": min(
            learned["by_stage"][str(stage)]["pre_evidence_revise_accuracy"]
            for stage in M52E_STAGES
            if stage > 1
        )
        >= contract["minimum_each_later_stage_recovery_accuracy"],
        "terminal_select_accuracy": learned["post_evidence_select_accuracy"]
        >= contract["minimum_terminal_select_accuracy"],
        "current_only_stage_success": current_only["stage_success"]
        >= contract["minimum_current_only_stage_success"],
        "validity_accuracy": validity["accuracy"]
        >= contract["minimum_validity_accuracy"],
        "each_representation_validity_accuracy": min(
            row["accuracy"] for row in validity["by_representation"].values()
        )
        >= contract["minimum_each_representation_validity_accuracy"],
        "gain_over_m52_baseline": learned["stage_success"]
        - baseline["stage_success"]
        >= contract["minimum_gain_over_m52_baseline"],
        "gain_over_scope_rotated": learned["stage_success"]
        - scope_rotated["stage_success"]
        >= contract["minimum_gain_over_scope_rotated"],
        "gain_over_validity_rotated": learned["stage_success"]
        - validity_rotated["stage_success"]
        >= contract["minimum_gain_over_validity_rotated"],
        "oracle_validity_stage_success": oracle["stage_success"]
        >= contract["minimum_oracle_validity_stage_success"],
        "zero_trainable_base_tensors": (
            base_trainable_tensor_count == 0
            if contract["require_zero_trainable_base_tensors"]
            else True
        ),
        "m52_checkpoint_unchanged": (
            m52_checkpoint_unchanged
            if contract["require_m52_checkpoint_unchanged"]
            else True
        ),
    }
    return all(checks.values()), checks


def confirmation_metrics(
    records: Sequence[Mapping[str, Any]], condition: str
) -> Mapping[str, Any]:
    return sequential_metrics(records, condition)
