from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Mapping

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core import training_recipe_micro_world_v58 as base


VERSION = "cognitive-core-all-on-transport-data-v60"
SEEDS = {
    "transport_train": 62011,
    "transport_evaluation": 62021,
}
DEFAULT_PER_FAMILY = {
    "transport_train": 2048,
    "transport_evaluation": 256,
}


@contextmanager
def _v60_context() -> Iterator[None]:
    original_version = base.VERSION
    original_seeds = base.SEEDS
    original_defaults = base.DEFAULT_PER_FAMILY
    try:
        base.VERSION = VERSION
        base.SEEDS = SEEDS
        base.DEFAULT_PER_FAMILY = DEFAULT_PER_FAMILY
        yield
    finally:
        base.VERSION = original_version
        base.SEEDS = original_seeds
        base.DEFAULT_PER_FAMILY = original_defaults


def generate_split(split: str, per_family: int | None = None):
    with _v60_context():
        return base.generate_split(split, per_family)


def audit_dataset(public_rows, authority_rows):
    with _v60_context():
        return base.audit_dataset(public_rows, authority_rows)


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
):
    with _v60_context():
        return base.freeze_dataset(output, per_family_by_split)


def nested_base_ids(public_rows, per_family: int = 1024):
    by_family = {}
    for row in public_rows:
        by_family.setdefault(str(row["family"]), set()).add(str(row["base_id"]))
    selected = set()
    for family, base_ids in sorted(by_family.items()):
        ordered = sorted(
            base_ids,
            key=lambda base_id: content_digest(
                {"version": VERSION, "family": family, "base_id": base_id}
            ),
        )
        if len(ordered) < per_family:
            raise ValueError("V60 nested pool is smaller than requested")
        selected.update(ordered[:per_family])
    return frozenset(selected)


load_split = base.load_split


__all__ = [
    "DEFAULT_PER_FAMILY",
    "SEEDS",
    "VERSION",
    "audit_dataset",
    "freeze_dataset",
    "generate_split",
    "load_split",
    "nested_base_ids",
]
