from __future__ import annotations

import json
import platform
import statistics
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

import mlx.core as mx

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_all_on_transport_data_v60 import (
    audit_dataset,
    load_split,
    nested_base_ids,
)
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_v59 import (
    PROTOCOL_ID,
    QUALIFICATION_RUN_ID,
    _deterministic_controller_predictions,
    _evaluation_digest,
    _schedule_digest,
    _train_model,
    build_training_plan,
)
from scientist.domains.cognitive_core.training_recipe_factorial_v56 import FACTORS
from scientist.domains.cognitive_core.training_recipe_learnability_v59 import (
    adjudicate_terminal,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
)


VERSION = "cognitive-core-all-on-data-seed-transport-v60-r1"
PREDECESSOR_PILOT_ID = (
    "e8124fef3a58742aa6d1430db4851a1cd04607ad6693376d1c5a237a1cec2cfa"
)
POOL_SIZES = (4096, 8192)
MODEL_SEEDS = (62101, 62201, 62301)
DATA_SEEDS = (62111, 62211, 62311)
STABLE_PASS_COUNT = 2
DETERMINISTIC_CLEAN_ADVANTAGE = 0.01
DETERMINISTIC_INVALID_TOLERANCE = 0.01


def prepare_grid(
    dataset_root: Path,
    capability_profile_path: Path,
    qualification_result_path: Path,
    pilot_result_path: Path,
) -> Mapping[str, Any]:
    qualification = json.loads(
        qualification_result_path.read_text(encoding="utf-8")
    )
    pilot = json.loads(pilot_result_path.read_text(encoding="utf-8"))
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if (
        qualification["run_id"] != QUALIFICATION_RUN_ID
        or qualification["qualified"] is not True
        or qualification["protocol_id"] != PROTOCOL_ID
    ):
        raise RuntimeError("V60 qualification link mismatch")
    if (
        pilot["pilot_id"] != PREDECESSOR_PILOT_ID
        or pilot["verification"]["passed"] is not False
        or pilot["next_action"] != "repair_v59_pilot_before_any_scale_decision"
    ):
        raise RuntimeError("V60 predecessor failure link mismatch")
    train_public, train_authority = load_split(dataset_root, "transport_train")
    evaluation_public, evaluation_authority = load_split(
        dataset_root, "transport_evaluation"
    )
    train_audit = audit_dataset(train_public, train_authority)
    evaluation_audit = audit_dataset(evaluation_public, evaluation_authority)
    selected = nested_base_ids(train_public, 1024)
    selected_families = {}
    for row in train_public:
        if row["base_id"] in selected:
            selected_families.setdefault(str(row["family"]), set()).add(
                str(row["base_id"])
            )
    checks = {
        "raw_train_audit": train_audit["passed"],
        "raw_evaluation_audit": evaluation_audit["passed"],
        "full_pool_8192": len({row["base_id"] for row in train_public}) == 8192,
        "nested_pool_4096": len(selected) == 4096,
        "nested_family_stratification": all(
            len(values) == 1024 for values in selected_families.values()
        )
        and len(selected_families) == 4,
        "fresh_evaluation_1024": (
            len({row["base_id"] for row in evaluation_public}) == 1024
        ),
        "three_paired_seeds": (
            len(MODEL_SEEDS) == len(DATA_SEEDS) == 3
            and len(set(MODEL_SEEDS)) == len(set(DATA_SEEDS)) == 3
        ),
    }
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "qualification_run_id": QUALIFICATION_RUN_ID,
        "predecessor_pilot_id": PREDECESSOR_PILOT_ID,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "pool_sizes": list(POOL_SIZES),
        "nested_small_pool_base_ids_digest": content_digest(sorted(selected)),
        "model_seeds": list(MODEL_SEEDS),
        "data_seeds": list(DATA_SEEDS),
        "steps": 5200,
        "batch_size": 128,
        "decision_rule": {
            "stable_pass_count": STABLE_PASS_COUNT,
            "deterministic_clean_tool_advantage": DETERMINISTIC_CLEAN_ADVANTAGE,
            "deterministic_invalid_acceptance_tolerance": (
                DETERMINISTIC_INVALID_TOLERANCE
            ),
        },
        "all_on_factors": {factor: True for factor in FACTORS},
        "checks": checks,
        "passed": all(checks.values()),
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def adjudicate_grid(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    pass_counts = {
        str(pool): sum(
            int(bool(row["terminal_decision"]["passed"]))
            for row in records
            if int(row["pool_size"]) == pool
        )
        for pool in POOL_SIZES
    }
    stable = {
        pool: count >= STABLE_PASS_COUNT for pool, count in pass_counts.items()
    }
    if stable["8192"] and (
        not stable["4096"] or pass_counts["8192"] > pass_counts["4096"]
    ):
        selected_pool = 8192
    elif stable["4096"]:
        selected_pool = 4096
    elif stable["8192"]:
        selected_pool = 8192
    else:
        selected_pool = None

    learned_clean = statistics.fmean(
        float(row["learned_end_to_end"]["primary_estimands"]["clean_tool_value"])
        for row in records
    )
    deterministic_clean = statistics.fmean(
        float(
            row["deterministic_end_to_end"]["primary_estimands"]
            ["clean_tool_value"]
        )
        for row in records
    )
    learned_invalid = statistics.fmean(
        float(
            row["learned_end_to_end"]["primary_estimands"]
            ["invalid_evidence_acceptance_rate"]
        )
        for row in records
    )
    deterministic_invalid = statistics.fmean(
        float(
            row["deterministic_end_to_end"]["primary_estimands"]
            ["invalid_evidence_acceptance_rate"]
        )
        for row in records
    )
    clean_advantage = deterministic_clean - learned_clean
    invalid_delta = deterministic_invalid - learned_invalid
    deterministic_preferred = (
        clean_advantage >= DETERMINISTIC_CLEAN_ADVANTAGE
        and invalid_delta <= DETERMINISTIC_INVALID_TOLERANCE
    )
    return {
        "pass_counts": pass_counts,
        "stable": stable,
        "selected_pool_size": selected_pool,
        "learned_mean_clean_tool_value": learned_clean,
        "deterministic_mean_clean_tool_value": deterministic_clean,
        "deterministic_clean_tool_advantage": clean_advantage,
        "learned_mean_invalid_acceptance": learned_invalid,
        "deterministic_mean_invalid_acceptance": deterministic_invalid,
        "deterministic_invalid_acceptance_delta": invalid_delta,
        "deterministic_controller_preferred": deterministic_preferred,
        "successor_pilot_design_authorized": selected_pool is not None,
        "next_action": (
            "freeze_successor_factorial_pilot_with_selected_pool_and_controller"
            if selected_pool is not None
            else "revise_all_on_optimization_before_another_factorial_cube"
        ),
    }


def run_grid(
    dataset_root: Path,
    capability_profile_path: Path,
    plan_path: Path,
) -> Mapping[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if not plan["passed"] or plan["predecessor_pilot_id"] != PREDECESSOR_PILOT_ID:
        raise RuntimeError("V60 plan is not authorized")
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if profile["profile_id"] != plan["capability_profile_id"]:
        raise RuntimeError("V60 capability profile mismatch")
    train_public, train_authority = load_split(dataset_root, "transport_train")
    evaluation_public, evaluation_authority = load_split(
        dataset_root, "transport_evaluation"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    full_training = training_examples(train_public, train_materialized)
    if not audit_nuisance_controls(full_training)["passed"]:
        raise RuntimeError("V60 full-pool nuisance audit failed")
    selected = nested_base_ids(train_public, 1024)
    base_by_view = {str(row["view_id"]): str(row["base_id"]) for row in train_public}
    small_training = tuple(
        row
        for row in full_training
        if base_by_view[str(row["view_id"])] in selected
    )
    evaluation_materialized = materialize_policy_labels(
        evaluation_public, evaluation_authority, profile
    )
    evaluation = training_examples(evaluation_public, evaluation_materialized)
    evaluation_digest = _evaluation_digest(evaluation)
    pools = {4096: small_training, 8192: full_training}
    all_on = {
        "arm_id": "all-on",
        "factors": {factor: True for factor in FACTORS},
        "model_facing_arm_label": False,
    }
    mx.set_default_device(mx.gpu)
    started = time.monotonic()
    records = []
    for model_seed, data_seed in zip(MODEL_SEEDS, DATA_SEEDS):
        for pool_size in POOL_SIZES:
            config = SmokeConfig(
                steps=int(plan["steps"]),
                batch_size=int(plan["batch_size"]),
                model_seed=model_seed,
                data_seed=data_seed,
                compute_device="gpu",
            )
            frozen_schedule = build_training_plan(pools[pool_size], config)
            trained, predictions = _train_model(
                all_on,
                frozen_schedule,
                evaluation,
                evaluation_public,
                evaluation_materialized,
                config,
                _schedule_digest(frozen_schedule),
                evaluation_digest,
            )
            deterministic_predictions = _deterministic_controller_predictions(
                evaluation, evaluation_public, predictions
            )
            deterministic_end_to_end = evaluate_end_to_end(
                evaluation_public,
                evaluation_materialized,
                deterministic_predictions,
            )
            record: Dict[str, Any] = {
                "pool_size": pool_size,
                "model_seed": model_seed,
                "data_seed": data_seed,
                "initial_parameter_digest": trained["initial_parameter_digest"],
                "training_schedule_digest": trained["training_schedule_digest"],
                "evaluation_digest": trained["evaluation_digest"],
                "parameter_count": trained["parameter_count"],
                "metrics": trained["metrics"],
                "terminal_decision": adjudicate_terminal(trained["metrics"]),
                "learned_end_to_end": trained["end_to_end"],
                "deterministic_end_to_end": deterministic_end_to_end,
                "elapsed_seconds": trained["elapsed_seconds"],
                "training_kernel_run_id": trained["run_id"],
            }
            record["record_id"] = content_digest(record)
            records.append(record)
            print(
                json.dumps(
                    {
                        "event": "v60_model_complete",
                        "pool_size": pool_size,
                        "model_seed": model_seed,
                        "terminal_passed": record["terminal_decision"]["passed"],
                        "elapsed_seconds": record["elapsed_seconds"],
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
    pairing_checks = {
        str(model_seed): (
            len(
                {
                    row["initial_parameter_digest"]
                    for row in records
                    if row["model_seed"] == model_seed
                }
            )
            == 1
        )
        for model_seed in MODEL_SEEDS
    }
    checks = {
        "six_models_complete": len(records) == 6,
        "paired_initialization_within_seed": all(pairing_checks.values()),
        "identical_evaluation_cases": len(
            {row["evaluation_digest"] for row in records}
        )
        == 1,
        "identical_parameter_counts": len(
            {row["parameter_count"] for row in records}
        )
        == 1,
        "three_models_per_pool": all(
            sum(row["pool_size"] == pool for row in records) == 3
            for pool in POOL_SIZES
        ),
    }
    decision = adjudicate_grid(records)
    result: Dict[str, Any] = {
        "version": VERSION,
        "plan_id": plan["plan_id"],
        "dataset_manifest_id": plan["dataset_manifest_id"],
        "capability_profile_id": plan["capability_profile_id"],
        "predecessor_pilot_id": PREDECESSOR_PILOT_ID,
        "records": records,
        "pairing_checks": pairing_checks,
        "checks": checks,
        "verification_passed": all(checks.values()),
        "decision": decision,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": decision["next_action"],
    }
    result["grid_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V60 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(path: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(path, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    decision = result["decision"]
    rows = []
    for record in result["records"]:
        observations = record["terminal_decision"]["observations"]
        rows.append(
            "| %d | %d | %s | %.1f%% | %.1f%% | %.1f%% | %.1f%% |"
            % (
                record["model_seed"],
                record["pool_size"],
                record["terminal_decision"]["passed"],
                observations["answer_accuracy"] * 100.0,
                observations["evidence_validity_accuracy"] * 100.0,
                observations["faithful_policy_accuracy"] * 100.0,
                observations["worst_family_accuracy"] * 100.0,
            )
        )
    report = "\n".join(
        (
            "# Cognitive-core V60 all-on transport grid",
            "",
            "- Execution verification passed: **%s**"
            % result["verification_passed"],
            "- 4,096-world pass count: **%d/3**"
            % decision["pass_counts"]["4096"],
            "- 8,192-world pass count: **%d/3**"
            % decision["pass_counts"]["8192"],
            "- Selected pool: **%s**" % decision["selected_pool_size"],
            "- Deterministic controller preferred: **%s**"
            % decision["deterministic_controller_preferred"],
            "- Scientific effect claim authorized: **False**",
            "- 20M-50M execution authorized: **False**",
            "- 3B training authorized: **False**",
            "- Grid ID: `%s`" % result["grid_id"],
            "",
            "| Seed | Pool | Pass | Answer | Validity | Faithful policy | Worst family |",
            "|---:|---:|---|---:|---:|---:|---:|",
            *rows,
            "",
            "Deterministic clean-tool advantage: **%+.1f pp**"
            % (decision["deterministic_clean_tool_advantage"] * 100.0),
            "Deterministic invalid-acceptance delta: **%+.1f pp**"
            % (decision["deterministic_invalid_acceptance_delta"] * 100.0),
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = [
    "VERSION",
    "adjudicate_grid",
    "prepare_grid",
    "run_grid",
    "write_plan",
    "write_result",
]
