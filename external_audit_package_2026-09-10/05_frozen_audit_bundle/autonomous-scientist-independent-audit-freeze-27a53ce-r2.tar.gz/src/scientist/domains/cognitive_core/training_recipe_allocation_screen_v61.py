from __future__ import annotations

import json
import platform
import random
import statistics
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_allocation_screen_data_v61 import (
    audit_dataset,
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_v59 import (
    PROTOCOL_ID,
    _deterministic_controller_predictions,
    _evaluation_digest,
    _schedule_digest,
    _train_model,
)
from scientist.domains.cognitive_core.training_recipe_factorial_v56 import FACTORS
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    TARGETS,
    SmokeConfig,
    _balanced_rows,
)


VERSION = "cognitive-core-deterministic-allocation-screen-v61-r1"
PREDECESSOR_GRID_ID = (
    "2a132cee58d7baec827cab6e83648f4363b5d56248876ca681c316c1151f193a"
)
ALLOCATIONS = {
    "balanced": {
        "answer": 32,
        "state": 32,
        "evidence_validity": 32,
        "tool_policy": 32,
    },
    "validity_heavy": {
        "answer": 32,
        "state": 32,
        "evidence_validity": 48,
        "tool_policy": 16,
    },
    "validity_dominant": {
        "answer": 24,
        "state": 24,
        "evidence_validity": 64,
        "tool_policy": 16,
    },
}
MODEL_SEEDS = (63101, 63201)
DATA_SEEDS = (63111, 63211)
MODEL_GATES = {
    "answer_accuracy": 0.70,
    "answer_class_recall": 0.20,
    "state_accuracy": 0.75,
    "state_class_recall": 0.20,
    "evidence_validity_accuracy": 0.80,
    "evidence_validity_class_recall": 0.65,
    "faithful_validity_accuracy": 0.65,
    "core_worst_family_accuracy": 0.60,
    "deterministic_clean_tool_value": 0.03,
    "deterministic_faithful_coverage_delta": 0.05,
    "maximum_deterministic_invalid_acceptance": 0.07,
    "response_parse_rate": 0.99,
    "action_schema_validity": 0.99,
}


def _allocation_batch(
    examples_by_target: Mapping[str, Sequence[Mapping[str, Any]]],
    allocation: Mapping[str, int],
    config: SmokeConfig,
    step: int,
) -> Tuple[Mapping[str, Any], ...]:
    if set(allocation) != set(TARGETS) or sum(allocation.values()) != config.batch_size:
        raise ValueError("V61 allocation must cover 128 examples across four targets")
    result = []
    for target_index, target in enumerate(TARGETS):
        result.extend(
            _balanced_rows(
                examples_by_target[target],
                int(allocation[target]),
                config.data_seed + 104729 * step + 1009 * target_index,
            )
        )
    random.Random(config.data_seed + 130363 * step).shuffle(result)
    return tuple(result)


def build_training_plan(
    examples: Sequence[Mapping[str, Any]],
    allocation: Mapping[str, int],
    config: SmokeConfig,
) -> Tuple[Tuple[Mapping[str, Any], ...], ...]:
    by_target = {
        target: tuple(row for row in examples if row["target"] == target)
        for target in TARGETS
    }
    return tuple(
        _allocation_batch(by_target, allocation, config, step)
        for step in range(1, config.steps + 1)
    )


def _core_family_metrics(
    evaluation: Sequence[Mapping[str, Any]],
    predictions: Sequence[int],
) -> Mapping[str, float]:
    core_targets = {"answer", "state", "evidence_validity"}
    values: Dict[str, list[bool]] = {}
    for row, prediction in zip(evaluation, predictions):
        if row["target"] in core_targets:
            values.setdefault(str(row["family"]), []).append(
                int(prediction) == int(row["semantic_label"])
            )
    return {
        family: sum(outcomes) / len(outcomes)
        for family, outcomes in sorted(values.items())
    }


def adjudicate_model(
    metrics: Mapping[str, Any],
    core_family: Mapping[str, float],
    deterministic_end_to_end: Mapping[str, Any],
) -> Mapping[str, Any]:
    targets = metrics["by_target"]
    e2e = deterministic_end_to_end["primary_estimands"]
    observations = {
        "answer_accuracy": targets["answer"]["accuracy"],
        "answer_class_recall": targets["answer"]["minimum_class_recall"],
        "state_accuracy": targets["state"]["accuracy"],
        "state_class_recall": targets["state"]["minimum_class_recall"],
        "evidence_validity_accuracy": targets["evidence_validity"]["accuracy"],
        "evidence_validity_class_recall": targets["evidence_validity"]
        ["minimum_class_recall"],
        "faithful_validity_accuracy": metrics["by_target_variant"]
        ["evidence_validity"]["faithful_observation"],
        "core_worst_family_accuracy": min(core_family.values()),
        "deterministic_clean_tool_value": e2e["clean_tool_value"],
        "deterministic_faithful_coverage_delta": e2e["faithful_coverage_delta"],
        "deterministic_invalid_acceptance": e2e[
            "invalid_evidence_acceptance_rate"
        ],
        "response_parse_rate": metrics["response_parse_rate"],
        "action_schema_validity": metrics["action_schema_validity"],
    }
    checks = {
        key: observations[key] >= threshold
        for key, threshold in MODEL_GATES.items()
        if key != "maximum_deterministic_invalid_acceptance"
    }
    checks["deterministic_invalid_acceptance"] = (
        observations["deterministic_invalid_acceptance"]
        <= MODEL_GATES["maximum_deterministic_invalid_acceptance"]
    )
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "observations": observations,
        "gates": MODEL_GATES,
    }


def adjudicate_screen(records: Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    candidates = {}
    for name in ALLOCATIONS:
        rows = [row for row in records if row["candidate"] == name]
        passes = sum(int(row["development_decision"]["passed"]) for row in rows)
        candidates[name] = {
            "passes": passes,
            "eligible": len(rows) == 2 and passes == 2,
            "mean_validity_accuracy": statistics.fmean(
                row["development_decision"]["observations"]
                ["evidence_validity_accuracy"]
                for row in rows
            ),
            "mean_core_worst_family_accuracy": statistics.fmean(
                row["development_decision"]["observations"]
                ["core_worst_family_accuracy"]
                for row in rows
            ),
            "mean_deterministic_clean_tool_value": statistics.fmean(
                row["development_decision"]["observations"]
                ["deterministic_clean_tool_value"]
                for row in rows
            ),
        }
    eligible = [name for name, row in candidates.items() if row["eligible"]]
    selected = (
        max(
            eligible,
            key=lambda name: (
                candidates[name]["mean_validity_accuracy"],
                candidates[name]["mean_core_worst_family_accuracy"],
                candidates[name]["mean_deterministic_clean_tool_value"],
                name,
            ),
        )
        if eligible
        else None
    )
    return {
        "candidates": candidates,
        "selected_candidate": selected,
        "v62_replication_authorized": selected is not None,
        "next_action": (
            "freeze_v62_multiseed_replication_of_selected_allocation"
            if selected is not None
            else "design_separate_validity_encoder_or_validity_first_curriculum"
        ),
    }


def prepare_screen(
    dataset_root: Path,
    capability_profile_path: Path,
    predecessor_grid_path: Path,
) -> Mapping[str, Any]:
    predecessor = json.loads(predecessor_grid_path.read_text(encoding="utf-8"))
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if (
        predecessor["grid_id"] != PREDECESSOR_GRID_ID
        or predecessor["decision"]["selected_pool_size"] is not None
        or predecessor["decision"]["deterministic_controller_preferred"] is not True
    ):
        raise RuntimeError("V61 predecessor decision mismatch")
    train_public, train_authority = load_split(dataset_root, "allocation_train")
    development_public, development_authority = load_split(
        dataset_root, "allocation_development"
    )
    checks = {
        "train_audit": audit_dataset(train_public, train_authority)["passed"],
        "development_audit": audit_dataset(
            development_public, development_authority
        )["passed"],
        "train_worlds_8192": (
            len({row["base_id"] for row in train_public}) == 8192
        ),
        "development_worlds_2048": (
            len({row["base_id"] for row in development_public}) == 2048
        ),
        "allocations_cover_batch": all(
            set(allocation) == set(TARGETS) and sum(allocation.values()) == 128
            for allocation in ALLOCATIONS.values()
        ),
        "two_paired_seeds": len(MODEL_SEEDS) == len(DATA_SEEDS) == 2,
        "deterministic_delivery_fixed": True,
        "learned_policy_not_a_delivery_gate": (
            "tool_policy_accuracy" not in MODEL_GATES
            and "faithful_policy_accuracy" not in MODEL_GATES
        ),
    }
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "predecessor_grid_id": PREDECESSOR_GRID_ID,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "allocations": ALLOCATIONS,
        "model_seeds": list(MODEL_SEEDS),
        "data_seeds": list(DATA_SEEDS),
        "steps": 5200,
        "batch_size": 128,
        "development_gates": MODEL_GATES,
        "selection_rule": (
            "two_of_two_then_lexicographic_validity_core_family_clean_tool"
        ),
        "checks": checks,
        "passed": all(checks.values()),
        "development_only": True,
        "v62_terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def run_screen(
    dataset_root: Path,
    capability_profile_path: Path,
    plan_path: Path,
) -> Mapping[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if not plan["passed"] or not plan["development_only"]:
        raise RuntimeError("V61 plan is not authorized")
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if profile["profile_id"] != plan["capability_profile_id"]:
        raise RuntimeError("V61 capability profile mismatch")
    train_public, train_authority = load_split(dataset_root, "allocation_train")
    development_public, development_authority = load_split(
        dataset_root, "allocation_development"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    training = training_examples(train_public, train_materialized)
    if not audit_nuisance_controls(training)["passed"]:
        raise RuntimeError("V61 nuisance audit failed")
    development_materialized = materialize_policy_labels(
        development_public, development_authority, profile
    )
    development = training_examples(
        development_public, development_materialized
    )
    evaluation_digest = _evaluation_digest(development)
    all_on = {
        "arm_id": "all-on",
        "factors": {factor: True for factor in FACTORS},
        "model_facing_arm_label": False,
    }
    mx.set_default_device(mx.gpu)
    started = time.monotonic()
    records = []
    for model_seed, data_seed in zip(MODEL_SEEDS, DATA_SEEDS):
        for candidate, allocation in ALLOCATIONS.items():
            config = SmokeConfig(
                steps=int(plan["steps"]),
                batch_size=int(plan["batch_size"]),
                model_seed=model_seed,
                data_seed=data_seed,
                compute_device="gpu",
            )
            frozen_schedule = build_training_plan(training, allocation, config)
            trained, predictions = _train_model(
                all_on,
                frozen_schedule,
                development,
                development_public,
                development_materialized,
                config,
                _schedule_digest(frozen_schedule),
                evaluation_digest,
            )
            deterministic_predictions = _deterministic_controller_predictions(
                development, development_public, predictions
            )
            deterministic_e2e = evaluate_end_to_end(
                development_public,
                development_materialized,
                deterministic_predictions,
            )
            core_family = _core_family_metrics(development, predictions)
            decision = adjudicate_model(
                trained["metrics"], core_family, deterministic_e2e
            )
            record: Dict[str, Any] = {
                "candidate": candidate,
                "allocation": allocation,
                "model_seed": model_seed,
                "data_seed": data_seed,
                "initial_parameter_digest": trained["initial_parameter_digest"],
                "training_schedule_digest": trained["training_schedule_digest"],
                "evaluation_digest": trained["evaluation_digest"],
                "parameter_count": trained["parameter_count"],
                "metrics": trained["metrics"],
                "core_family_accuracy": core_family,
                "learned_end_to_end": trained["end_to_end"],
                "deterministic_end_to_end": deterministic_e2e,
                "development_decision": decision,
                "elapsed_seconds": trained["elapsed_seconds"],
                "training_kernel_run_id": trained["run_id"],
            }
            record["record_id"] = content_digest(record)
            records.append(record)
            print(
                json.dumps(
                    {
                        "event": "v61_model_complete",
                        "candidate": candidate,
                        "model_seed": model_seed,
                        "development_passed": decision["passed"],
                        "elapsed_seconds": record["elapsed_seconds"],
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
    pairing_checks = {
        str(model_seed): len(
            {
                row["initial_parameter_digest"]
                for row in records
                if row["model_seed"] == model_seed
            }
        )
        == 1
        for model_seed in MODEL_SEEDS
    }
    checks = {
        "six_models_complete": len(records) == 6,
        "three_candidates_per_seed": all(
            sum(row["model_seed"] == seed for row in records) == 3
            for seed in MODEL_SEEDS
        ),
        "paired_initialization": all(pairing_checks.values()),
        "identical_evaluation_cases": len(
            {row["evaluation_digest"] for row in records}
        )
        == 1,
        "identical_parameter_counts": len(
            {row["parameter_count"] for row in records}
        )
        == 1,
    }
    decision = adjudicate_screen(records)
    result: Dict[str, Any] = {
        "version": VERSION,
        "plan_id": plan["plan_id"],
        "dataset_manifest_id": plan["dataset_manifest_id"],
        "capability_profile_id": plan["capability_profile_id"],
        "predecessor_grid_id": PREDECESSOR_GRID_ID,
        "records": records,
        "pairing_checks": pairing_checks,
        "checks": checks,
        "verification_passed": all(checks.values()),
        "decision": decision,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "development_only": True,
        "v62_terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": decision["next_action"],
    }
    result["screen_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V61 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(path: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(path, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    rows = []
    for record in result["records"]:
        observations = record["development_decision"]["observations"]
        rows.append(
            "| %d | %s | %s | %.1f%% | %.1f%% | %.1f%% | %+.1f pp | %.1f%% |"
            % (
                record["model_seed"],
                record["candidate"],
                record["development_decision"]["passed"],
                observations["answer_accuracy"] * 100.0,
                observations["evidence_validity_accuracy"] * 100.0,
                observations["core_worst_family_accuracy"] * 100.0,
                observations["deterministic_clean_tool_value"] * 100.0,
                observations["deterministic_invalid_acceptance"] * 100.0,
            )
        )
    report = "\n".join(
        (
            "# Cognitive-core V61 deterministic-delivery allocation screen",
            "",
            "- Execution verification passed: **%s**"
            % result["verification_passed"],
            "- Selected candidate: **%s**"
            % result["decision"]["selected_candidate"],
            "- V62 replication authorized: **%s**"
            % result["decision"]["v62_replication_authorized"],
            "- V62 terminal data opened: **False**",
            "- Scientific effect claim authorized: **False**",
            "- 20M-50M execution authorized: **False**",
            "- 3B training authorized: **False**",
            "- Screen ID: `%s`" % result["screen_id"],
            "",
            "| Seed | Candidate | Pass | Answer | Validity | Core worst family | Deterministic clean value | Invalid accept |",
            "|---:|---|---|---:|---:|---:|---:|---:|",
            *rows,
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = [
    "ALLOCATIONS",
    "MODEL_GATES",
    "VERSION",
    "adjudicate_model",
    "adjudicate_screen",
    "build_training_plan",
    "prepare_screen",
    "run_screen",
    "write_plan",
    "write_result",
]
