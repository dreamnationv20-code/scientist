from __future__ import annotations

import json
import platform
import statistics
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core import training_recipe_micro_world_v55 as micro
from scientist.domains.cognitive_core.training_recipe_allocation_screen_v61 import (
    _core_family_metrics,
    adjudicate_model,
    build_training_plan,
)
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
    prediction_index,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_v59 import (
    PROTOCOL_ID,
    _deterministic_controller_predictions,
    _evaluation_digest,
    _schedule_digest,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    TARGET_ANSWER,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    _arrays,
    _optimizer,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    parameter_count,
)
from scientist.domains.cognitive_core.training_recipe_model_v68 import (
    V68AutoregressiveTraceTransformer,
)
from scientist.domains.cognitive_core.training_recipe_specificity_data_v67 import (
    audit_dataset,
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_state_bridge_screen_v62 import (
    ALLOCATION,
    ARITHMETIC_FAMILY,
    _parameter_digest,
    _training_payload_digest,
)
from scientist.domains.cognitive_core.training_recipe_structured_fusion_factorial_v65 import (
    _answer_family_accuracy,
    _metrics_from_predictions,
)
from scientist.domains.cognitive_core.training_recipe_structured_state_v65 import (
    attach_structured_controls,
    audit_structured_controls,
)
from scientist.domains.cognitive_core.training_recipe_trace_feasibility_v68t import (
    ANSWER_BASE,
    BOS_TOKEN,
    CURRENT_BASE,
    EOS_TOKEN,
    OPERAND_BASE,
    OPERATOR_BASE,
    TRACE_LABEL_TO_OPERATOR_CLASS,
    TRACE_LENGTH,
    OPERATOR_CLASS_TO_TRACE_LABEL,
    compile_trace,
)
from scientist.domains.cognitive_core.training_recipe_structured_state_v65 import (
    CLASS_TO_OPERATOR,
)


VERSION = "cognitive-core-autoregressive-execution-trace-v68-r2"
SOURCE_SPECIFICITY_ID = (
    "1edc3493480ed0f6f3aaeaadc9627dfa510a06790395557c724250e8322dc135"
)
SOURCE_TRACE_AUDIT_ID = (
    "363967a2976c8055df3b46e023b1493761612f1edc3b4ffc1ae9718df591081f"
)
MODEL_SEEDS = (69101, 69201, 69301)
DATA_SEEDS = (69111, 69211, 69311)
ARMS = {
    "direct_answer": {"answer_objective": "direct"},
    "nuisance_trace": {"answer_objective": "nuisance_trace"},
    "semantic_trace": {"answer_objective": "semantic_trace"},
}
MINIMUM_MEAN_TRACE_EFFECT = 0.05
MAXIMUM_SINGLE_SEED_EFFECT_DECREMENT = 0.02
MEAN_NONINFERIORITY_MARGIN = 0.02
SINGLE_SEED_NONINFERIORITY_MARGIN = 0.05
MINIMUM_PREFIX_JOINT_ACCURACY = 0.70
MINIMUM_COUNTERFACTUAL_FOLLOW_MEAN = 0.50
MINIMUM_COUNTERFACTUAL_FOLLOW_SEED = 0.40
MINIMUM_COUNTERFACTUAL_PREFERENCE_MEAN = 0.20
MINIMUM_COUNTERFACTUAL_PREFERENCE_SEED = 0.10
MINIMUM_UNIFORM_PREFIX_CHANGE_RATE = 0.10


def _nuisance_trace(
    row: Mapping[str, Any], answer: int
) -> tuple[int, ...]:
    values = row["structured_nuisance"]
    semantic_operator = int(values["pending_operator"])
    return (
        CURRENT_BASE + int(values["current_value"]),
        OPERATOR_BASE + OPERATOR_CLASS_TO_TRACE_LABEL[semantic_operator],
        OPERAND_BASE + int(values["pending_operand"]),
        ANSWER_BASE + int(answer),
        EOS_TOKEN,
    )


def attach_trace_targets(
    examples: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    authority_by_view = {
        str(row["view_id"]): row for row in authority_rows
    }
    result = []
    for row in examples:
        authority = authority_by_view[str(row["view_id"])]
        enriched = dict(row)
        enriched["semantic_trace"] = list(compile_trace(authority))
        enriched["nuisance_trace"] = list(
            _nuisance_trace(enriched, int(authority["answer"]))
        )
        result.append(enriched)
    return tuple(result)


def audit_trace_targets(
    examples: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    answer_rows = [row for row in examples if row["target"] == "answer"]
    semantic_histograms = [dict() for _ in range(3)]
    nuisance_histograms = [dict() for _ in range(3)]
    for row in answer_rows:
        for position in range(3):
            semantic = int(row["semantic_trace"][position])
            nuisance = int(row["nuisance_trace"][position])
            semantic_histograms[position][semantic] = (
                semantic_histograms[position].get(semantic, 0) + 1
            )
            nuisance_histograms[position][nuisance] = (
                nuisance_histograms[position].get(nuisance, 0) + 1
            )
    checks = {
        "one_answer_trace_per_view": len(answer_rows)
        == len({str(row["view_id"]) for row in examples}),
        "fixed_trace_length": all(
            len(row["semantic_trace"]) == TRACE_LENGTH
            and len(row["nuisance_trace"]) == TRACE_LENGTH
            for row in examples
        ),
        "semantic_nuisance_position_histograms_match":
        semantic_histograms == nuisance_histograms,
        "answer_and_eos_targets_match": all(
            row["semantic_trace"][3:] == row["nuisance_trace"][3:]
            for row in examples
        ),
        "semantic_and_nuisance_prefixes_differ": any(
            row["semantic_trace"][:3] != row["nuisance_trace"][:3]
            for row in answer_rows
        ),
    }
    result: Dict[str, Any] = {
        "answer_rows": len(answer_rows),
        "checks": checks,
        "passed": all(checks.values()),
    }
    result["audit_id"] = content_digest(result)
    return result


def _trace_arrays(
    examples: Sequence[Mapping[str, Any]], field: str
) -> Tuple[mx.array, mx.array]:
    targets = mx.array([row[field] for row in examples], dtype=mx.int32)
    bos = mx.full((targets.shape[0], 1), BOS_TOKEN, dtype=mx.int32)
    teacher_inputs = mx.concatenate((bos, targets[:, :-1]), axis=1)
    return teacher_inputs, targets


def _execute_prefix(trace: Sequence[int]) -> int:
    current = int(trace[0]) - CURRENT_BASE
    operator_label = int(trace[1]) - OPERATOR_BASE
    operand = int(trace[2]) - OPERAND_BASE
    operator_class = TRACE_LABEL_TO_OPERATOR_CLASS[operator_label]
    return micro._apply(CLASS_TO_OPERATOR[operator_class], current, operand)


def _generate(
    model: V68AutoregressiveTraceTransformer,
    rows: Sequence[Mapping[str, Any]],
    *,
    forced_prefixes: Sequence[Sequence[int]] | None = None,
    uniform_prefix: bool = False,
    batch_size: int = 512,
) -> Tuple[Tuple[int, ...], ...]:
    generated = []
    model.eval()
    for start in range(0, len(rows), batch_size):
        batch = rows[start : start + batch_size]
        tokens, _ = _arrays(batch)
        forced = None
        if forced_prefixes is not None:
            forced = mx.array(
                forced_prefixes[start : start + batch_size], dtype=mx.int32
            )
        values = model.generate_trace(
            tokens, forced_prefix=forced, uniform_prefix=uniform_prefix
        )
        mx.eval(values)
        generated.extend(tuple(int(token) for token in row) for row in values.tolist())
    model.train()
    return tuple(generated)


def _teacher_forced_metrics(
    model: V68AutoregressiveTraceTransformer,
    rows: Sequence[Mapping[str, Any]],
    field: str,
    batch_size: int = 512,
) -> Mapping[str, Any]:
    correct = [0] * TRACE_LENGTH
    total = 0
    model.eval()
    for start in range(0, len(rows), batch_size):
        batch = rows[start : start + batch_size]
        tokens, _ = _arrays(batch)
        teacher, targets = _trace_arrays(batch, field)
        predictions = mx.argmax(model.trace_logits(tokens, teacher), axis=-1)
        mx.eval(predictions, targets)
        predicted_rows = predictions.tolist()
        target_rows = targets.tolist()
        for predicted, target in zip(predicted_rows, target_rows):
            total += 1
            for position in range(TRACE_LENGTH):
                correct[position] += int(
                    int(predicted[position]) == int(target[position])
                )
    model.train()
    return {
        "diagnostic_only": True,
        "position_accuracy": [value / total for value in correct],
        "rows": total,
    }


def _permuted_prefixes(
    rows: Sequence[Mapping[str, Any]],
) -> Tuple[Tuple[int, int, int], ...]:
    result: list[tuple[int, int, int] | None] = [None] * len(rows)
    by_family: Dict[str, list[int]] = {}
    for index, row in enumerate(rows):
        by_family.setdefault(str(row["family"]), []).append(index)
    for indices in by_family.values():
        shift = len(indices) // 2 + 1
        for offset, target_index in enumerate(indices):
            source_index = indices[(offset + shift) % len(indices)]
            result[target_index] = tuple(
                int(value)
                for value in rows[source_index]["semantic_trace"][:3]
            )
    if any(prefix is None for prefix in result):
        raise AssertionError("permuted trace prefix construction failed")
    return tuple(prefix for prefix in result if prefix is not None)


def _trace_metrics(
    model: V68AutoregressiveTraceTransformer,
    evaluation: Sequence[Mapping[str, Any]],
    objective: str,
) -> tuple[Mapping[str, Any], Mapping[int, int]]:
    indexed_answer_rows = [
        (index, row)
        for index, row in enumerate(evaluation)
        if row["target"] == "answer"
    ]
    rows = [row for _, row in indexed_answer_rows]
    intact = _generate(model, rows)
    answer_predictions = {
        index: int(trace[3]) - ANSWER_BASE
        for (index, _), trace in zip(indexed_answer_rows, intact)
    }
    semantic_prefix_correct = [0, 0, 0]
    semantic_joint = []
    full_consistency = []
    executor_correct = []
    answer_correct = []
    arithmetic_answer_correct = []
    for row, trace in zip(rows, intact):
        target = row["semantic_trace"]
        prefix_outcomes = [
            int(trace[position]) == int(target[position])
            for position in range(3)
        ]
        for position, outcome in enumerate(prefix_outcomes):
            semantic_prefix_correct[position] += int(outcome)
        semantic_joint.append(all(prefix_outcomes))
        executed = _execute_prefix(trace)
        predicted = int(trace[3]) - ANSWER_BASE
        expected = int(row["semantic_label"])
        full_consistency.append(executed == predicted)
        executor_correct.append(executed == expected)
        answer_correct.append(predicted == expected)
        if row["family"] == ARITHMETIC_FAMILY:
            arithmetic_answer_correct.append(predicted == expected)

    permuted_prefixes = _permuted_prefixes(rows)
    permuted = _generate(model, rows, forced_prefixes=permuted_prefixes)
    eligible = []
    follow = []
    retain = []
    permuted_original = []
    arithmetic_eligible = []
    arithmetic_follow = []
    arithmetic_retain = []
    arithmetic_permuted_original = []
    for row, trace, prefix in zip(rows, permuted, permuted_prefixes):
        expected = int(row["semantic_label"])
        counterfactual = _execute_prefix(prefix)
        predicted = int(trace[3]) - ANSWER_BASE
        changed = counterfactual != expected
        eligible.append(changed)
        permuted_original.append(predicted == expected)
        if row["family"] == ARITHMETIC_FAMILY:
            arithmetic_permuted_original.append(predicted == expected)
        if changed:
            follow.append(predicted == counterfactual)
            retain.append(predicted == expected)
        if row["family"] == ARITHMETIC_FAMILY and changed:
            arithmetic_eligible.append(True)
            arithmetic_follow.append(predicted == counterfactual)
            arithmetic_retain.append(predicted == expected)

    uniform = _generate(model, rows, uniform_prefix=True)
    uniform_answers = [int(trace[3]) - ANSWER_BASE for trace in uniform]
    intact_answers = [int(trace[3]) - ANSWER_BASE for trace in intact]
    uniform_change = [
        altered != original
        for altered, original in zip(uniform_answers, intact_answers)
    ]
    uniform_original = [
        predicted == int(row["semantic_label"])
        for predicted, row in zip(uniform_answers, rows)
    ]

    target_field = (
        "semantic_trace" if objective == "semantic_trace" else "nuisance_trace"
    )
    metrics = {
        "primary_evaluation": "free_running_generated_answer_token",
        "answer_accuracy": sum(answer_correct) / len(answer_correct),
        "arithmetic_answer_accuracy": sum(arithmetic_answer_correct)
        / len(arithmetic_answer_correct),
        "semantic_prefix_position_accuracy": [
            value / len(rows) for value in semantic_prefix_correct
        ],
        "semantic_prefix_joint_accuracy": sum(semantic_joint)
        / len(semantic_joint),
        "generated_answer_executor_consistency": sum(full_consistency)
        / len(full_consistency),
        "executor_answer_accuracy": sum(executor_correct)
        / len(executor_correct),
        "permuted_prefix": {
            "eligible_rows": sum(eligible),
            "eligible_rate": sum(eligible) / len(eligible),
            "counterfactual_follow_accuracy": sum(follow) / len(follow),
            "original_answer_retention": sum(retain) / len(retain),
            "counterfactual_preference": (
                sum(follow) / len(follow) - sum(retain) / len(retain)
            ),
            "original_answer_accuracy": sum(permuted_original)
            / len(permuted_original),
            "arithmetic_eligible_rows": len(arithmetic_eligible),
            "arithmetic_counterfactual_follow_accuracy": sum(
                arithmetic_follow
            )
            / len(arithmetic_follow),
            "arithmetic_original_answer_retention": sum(arithmetic_retain)
            / len(arithmetic_retain),
            "arithmetic_counterfactual_preference": (
                sum(arithmetic_follow) / len(arithmetic_follow)
                - sum(arithmetic_retain) / len(arithmetic_retain)
            ),
            "arithmetic_original_answer_accuracy": sum(
                arithmetic_permuted_original
            )
            / len(arithmetic_permuted_original),
        },
        "uniform_prefix": {
            "answer_change_rate": sum(uniform_change) / len(uniform_change),
            "original_answer_accuracy": sum(uniform_original)
            / len(uniform_original),
        },
        "teacher_forced": _teacher_forced_metrics(model, rows, target_field),
    }
    return metrics, answer_predictions


def _predict_and_diagnose(
    model: V68AutoregressiveTraceTransformer,
    evaluation: Sequence[Mapping[str, Any]],
    objective: str,
) -> tuple[Tuple[int, ...], Mapping[str, Any]]:
    predictions = []
    model.eval()
    for start in range(0, len(evaluation), 512):
        tokens, _ = _arrays(evaluation[start : start + 512])
        values = mx.argmax(model(tokens), axis=-1)
        mx.eval(values)
        predictions.extend(int(value) for value in values.tolist())
    model.train()
    if objective == "direct":
        return tuple(predictions), {"not_applicable": True}
    trace_metrics, replacements = _trace_metrics(model, evaluation, objective)
    for index, prediction in replacements.items():
        predictions[index] = prediction
    return tuple(predictions), trace_metrics


def _train_arm(
    arm_name: str,
    schedule: Sequence[Sequence[Mapping[str, Any]]],
    evaluation: Sequence[Mapping[str, Any]],
    evaluation_public: Sequence[Mapping[str, Any]],
    evaluation_authority: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    schedule_digest: str,
    evaluation_digest: str,
):
    objective = str(ARMS[arm_name]["answer_objective"])
    started = time.monotonic()
    mx.random.seed(config.model_seed)
    model = V68AutoregressiveTraceTransformer(config)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    parameters = parameter_count(model)
    optimizer = _optimizer(config, config.steps)

    def loss_fn(active_model, tokens, labels, teacher_inputs, trace_targets):
        main_logits = active_model(tokens)
        main_losses = nn.losses.cross_entropy(
            main_logits, labels, reduction="none"
        )
        if objective == "direct":
            return mx.mean(main_losses)
        trace_logits = active_model.trace_logits(tokens, teacher_inputs)
        trace_losses = nn.losses.cross_entropy(
            trace_logits.reshape(-1, trace_logits.shape[-1]),
            trace_targets.reshape(-1),
            reduction="none",
        ).reshape(trace_targets.shape)
        trace_row_losses = mx.mean(trace_losses, axis=1)
        answer_mask = tokens[:, 1] == TARGET_ANSWER
        return mx.mean(mx.where(answer_mask, trace_row_losses, main_losses))

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    trace_field = (
        "semantic_trace" if objective == "semantic_trace" else "nuisance_trace"
    )
    for batch in schedule:
        tokens, labels = _arrays(batch)
        teacher, targets = _trace_arrays(batch, trace_field)
        loss, gradients = loss_and_grad(model, tokens, labels, teacher, targets)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())

    final_parameter_digest = _parameter_digest(model)
    predictions, trace_metrics = _predict_and_diagnose(
        model, evaluation, objective
    )
    metrics = _metrics_from_predictions(evaluation, predictions)
    learned_end_to_end = evaluate_end_to_end(
        evaluation_public,
        evaluation_authority,
        prediction_index(evaluation, predictions),
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "arm_name": arm_name,
        "factors": ARMS[arm_name],
        "answer_objective": objective,
        "config": config.as_dict(),
        "initial_parameter_digest": initial_parameter_digest,
        "final_parameter_digest": final_parameter_digest,
        "parameter_count": parameters,
        "training_schedule_digest": schedule_digest,
        "training_payload_digest": _training_payload_digest(schedule),
        "trace_target_payload_digest": content_digest(
            [
                row[trace_field]
                for batch in schedule
                for row in batch
                if row["target"] == "answer"
            ]
        ),
        "evaluation_digest": evaluation_digest,
        "last_training_loss": last_loss,
        "metrics": metrics,
        "trace_metrics": trace_metrics,
        "answer_family_accuracy": _answer_family_accuracy(
            evaluation, predictions
        ),
        "learned_end_to_end": learned_end_to_end,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "compute_device": "cpu",
        "inferential": False,
    }
    result["run_id"] = content_digest(result)
    return result, predictions


def _mean(values: Sequence[float]) -> float:
    return statistics.fmean(values) if values else float("nan")


def _effect_checks(values: Sequence[float]) -> Mapping[str, bool]:
    return {
        "mean_at_least_five_points": len(values) == 3
        and _mean(values) >= MINIMUM_MEAN_TRACE_EFFECT,
        "no_seed_below_minus_two_points": len(values) == 3
        and min(values) >= -MAXIMUM_SINGLE_SEED_EFFECT_DECREMENT,
    }


def _noninferiority_checks(values: Sequence[float]) -> Mapping[str, bool]:
    return {
        "mean_not_below_minus_two_points": len(values) == 3
        and _mean(values) >= -MEAN_NONINFERIORITY_MARGIN,
        "no_seed_below_minus_five_points": len(values) == 3
        and min(values) >= -SINGLE_SEED_NONINFERIORITY_MARGIN,
    }


def adjudicate_trace(
    records: Sequence[Mapping[str, Any]], verification_passed: bool
) -> Mapping[str, Any]:
    seed_results = {}
    semantic_vs_nuisance = []
    semantic_vs_direct = []
    core_noninferiority = []
    evidence_noninferiority = []
    prefix_joint = []
    follow = []
    preference = []
    uniform_change = []
    permuted_drop = []
    for seed in MODEL_SEEDS:
        rows = {
            str(row["arm_name"]): row
            for row in records
            if int(row["model_seed"]) == seed
        }
        if set(rows) != set(ARMS):
            continue
        answer = {
            arm: float(row["answer_family_accuracy"][ARITHMETIC_FAMILY])
            for arm, row in rows.items()
        }
        semantic = rows["semantic_trace"]
        trace = semantic["trace_metrics"]
        semantic_vs_nuisance.append(
            answer["semantic_trace"] - answer["nuisance_trace"]
        )
        semantic_vs_direct.append(
            answer["semantic_trace"] - answer["direct_answer"]
        )
        semantic_core = float(
            semantic["core_family_accuracy"][ARITHMETIC_FAMILY]
        )
        best_control_core = max(
            float(rows[arm]["core_family_accuracy"][ARITHMETIC_FAMILY])
            for arm in ("direct_answer", "nuisance_trace")
        )
        semantic_evidence = float(
            semantic["metrics"]["by_target"]["evidence_validity"]["accuracy"]
        )
        best_control_evidence = max(
            float(rows[arm]["metrics"]["by_target"]["evidence_validity"]["accuracy"])
            for arm in ("direct_answer", "nuisance_trace")
        )
        core_delta = semantic_core - best_control_core
        evidence_delta = semantic_evidence - best_control_evidence
        core_noninferiority.append(core_delta)
        evidence_noninferiority.append(evidence_delta)
        prefix_joint.append(float(trace["semantic_prefix_joint_accuracy"]))
        permuted = trace["permuted_prefix"]
        follow.append(
            float(permuted["arithmetic_counterfactual_follow_accuracy"])
        )
        preference.append(
            float(permuted["arithmetic_counterfactual_preference"])
        )
        uniform_change.append(float(trace["uniform_prefix"]["answer_change_rate"]))
        permuted_drop.append(
            float(trace["arithmetic_answer_accuracy"])
            - float(permuted["arithmetic_original_answer_accuracy"])
        )
        seed_results[str(seed)] = {
            "arithmetic_answer_accuracy": answer,
            "semantic_vs_nuisance": semantic_vs_nuisance[-1],
            "semantic_vs_direct": semantic_vs_direct[-1],
            "arithmetic_core_delta_vs_best_control": core_delta,
            "evidence_accuracy_delta_vs_best_control": evidence_delta,
            "semantic_prefix_joint_accuracy": prefix_joint[-1],
            "arithmetic_counterfactual_follow_accuracy": follow[-1],
            "arithmetic_counterfactual_preference": preference[-1],
            "uniform_prefix_answer_change_rate": uniform_change[-1],
            "permuted_original_accuracy_drop": permuted_drop[-1],
            "semantic_main_gate": semantic["development_decision"]["passed"],
        }

    common_checks = {
        "execution_verification_passed": verification_passed,
        "three_complete_paired_blocks": len(seed_results) == 3,
        "free_running_primary": len(seed_results) == 3
        and all(
            row["trace_metrics"]["primary_evaluation"]
            == "free_running_generated_answer_token"
            for row in records
            if row["arm_name"] == "semantic_trace"
        ),
        "teacher_forcing_diagnostic_only": len(seed_results) == 3
        and all(
            row["trace_metrics"]["teacher_forced"]["diagnostic_only"]
            for row in records
            if row["arm_name"] == "semantic_trace"
        ),
    }
    effect_checks = {
        "semantic_vs_nuisance": _effect_checks(semantic_vs_nuisance),
        "semantic_vs_direct": _effect_checks(semantic_vs_direct),
    }
    safety_checks = {
        "arithmetic_core": _noninferiority_checks(core_noninferiority),
        "evidence_validity": _noninferiority_checks(evidence_noninferiority),
    }
    representation_checks = {
        "prefix_joint_at_least_seventy_percent_each_seed":
        len(prefix_joint) == 3
        and min(prefix_joint) >= MINIMUM_PREFIX_JOINT_ACCURACY,
    }
    causal_checks = {
        "counterfactual_follow_mean_at_least_fifty_percent": len(follow) == 3
        and _mean(follow) >= MINIMUM_COUNTERFACTUAL_FOLLOW_MEAN,
        "counterfactual_follow_each_seed_at_least_forty_percent":
        len(follow) == 3 and min(follow) >= MINIMUM_COUNTERFACTUAL_FOLLOW_SEED,
        "counterfactual_preference_mean_at_least_twenty_points":
        len(preference) == 3
        and _mean(preference) >= MINIMUM_COUNTERFACTUAL_PREFERENCE_MEAN,
        "counterfactual_preference_each_seed_at_least_ten_points":
        len(preference) == 3
        and min(preference) >= MINIMUM_COUNTERFACTUAL_PREFERENCE_SEED,
        "uniform_prefix_changes_at_least_ten_percent_each_seed":
        len(uniform_change) == 3
        and min(uniform_change) >= MINIMUM_UNIFORM_PREFIX_CHANGE_RATE,
        "permuted_prefix_reduces_original_accuracy": all(
            _effect_checks(permuted_drop).values()
        ),
    }
    trace_recipe_established = (
        all(common_checks.values())
        and all(all(group.values()) for group in effect_checks.values())
        and all(all(group.values()) for group in safety_checks.values())
        and all(representation_checks.values())
        and all(causal_checks.values())
    )
    representation_learned = all(representation_checks.values())
    causal_use_established = all(causal_checks.values())
    if trace_recipe_established:
        next_action = "freeze_v69_fresh_trace_recipe_replication"
    elif representation_learned and not causal_use_established:
        next_action = "pivot_to_deterministic_typed_trace_executor"
    elif not representation_learned:
        next_action = "redesign_trace_token_curriculum_once"
    else:
        next_action = "retire_learned_trace_answer_and_test_typed_executor"
    return {
        "seed_results": seed_results,
        "means": {
            "semantic_vs_nuisance": _mean(semantic_vs_nuisance),
            "semantic_vs_direct": _mean(semantic_vs_direct),
            "arithmetic_core_delta_vs_best_control": _mean(core_noninferiority),
            "evidence_accuracy_delta_vs_best_control": _mean(evidence_noninferiority),
            "semantic_prefix_joint_accuracy": _mean(prefix_joint),
            "arithmetic_counterfactual_follow_accuracy": _mean(follow),
            "arithmetic_counterfactual_preference": _mean(preference),
            "uniform_prefix_answer_change_rate": _mean(uniform_change),
            "permuted_original_accuracy_drop": _mean(permuted_drop),
        },
        "common_checks": common_checks,
        "effect_checks": effect_checks,
        "safety_checks": safety_checks,
        "representation_checks": representation_checks,
        "causal_checks": causal_checks,
        "trace_recipe_established": trace_recipe_established,
        "representation_learned": representation_learned,
        "causal_use_established": causal_use_established,
        "next_action": next_action,
        "terminal_evaluation_authorized": False,
        "scaling_authorized": False,
    }


def _verified_digest(payload: Mapping[str, Any], id_field: str) -> bool:
    candidate = dict(payload)
    observed = candidate.pop(id_field)
    return observed == content_digest(candidate)


def _load_bundle(
    dataset_root: Path,
    capability_profile_path: Path,
) -> tuple:
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    train_public, train_authority = load_split(dataset_root, "specificity_train")
    dev_public, dev_authority = load_split(
        dataset_root, "specificity_development"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    dev_materialized = materialize_policy_labels(dev_public, dev_authority, profile)
    training = attach_trace_targets(
        attach_structured_controls(
            training_examples(train_public, train_materialized), train_materialized
        ),
        train_materialized,
    )
    development = attach_trace_targets(
        attach_structured_controls(
            training_examples(dev_public, dev_materialized), dev_materialized
        ),
        dev_materialized,
    )
    return (
        profile,
        train_public,
        train_authority,
        train_materialized,
        dev_public,
        dev_authority,
        dev_materialized,
        training,
        development,
    )


def prepare_trace_screen(
    dataset_root: Path,
    capability_profile_path: Path,
    source_specificity_path: Path,
    trace_audit_path: Path,
) -> Mapping[str, Any]:
    source = json.loads(source_specificity_path.read_text(encoding="utf-8"))
    trace_audit = json.loads(trace_audit_path.read_text(encoding="utf-8"))
    (
        profile,
        train_public,
        train_raw_authority,
        train_materialized,
        dev_public,
        dev_raw_authority,
        dev_materialized,
        training,
        development,
    ) = _load_bundle(dataset_root, capability_profile_path)
    manifest = json.loads(
        (dataset_root / "manifest.json").read_text(encoding="utf-8")
    )
    checks = {
        "source_digest_valid": _verified_digest(source, "specificity_id"),
        "source_specificity_matches": source["specificity_id"]
        == SOURCE_SPECIFICITY_ID,
        "source_execution_verified": source["verification_passed"] is True,
        "source_specificity_rejected": source["decision"]
        ["semantic_specificity_established"]
        is False,
        "source_selected_trace_pivot": source["next_action"]
        == "pivot_to_token_execution_trace",
        "trace_audit_digest_valid": _verified_digest(trace_audit, "audit_id"),
        "trace_audit_matches": trace_audit["audit_id"]
        == SOURCE_TRACE_AUDIT_ID,
        "trace_audit_passed": trace_audit["passed"] is True,
        "trace_audit_selected_freeze": trace_audit["recommended_next_action"]
        == "freeze_v68_autoregressive_execution_trace_screen",
        "capability_profile_matches": profile["profile_id"]
        == source["capability_profile_id"],
        "dataset_manifest_matches_source": manifest["manifest_id"]
        == source["dataset_manifest_id"],
        "train_raw_audit": audit_dataset(
            train_public, train_raw_authority
        )["passed"],
        "development_raw_audit": audit_dataset(
            dev_public, dev_raw_authority
        )["passed"],
        "train_main_nuisance_audit": audit_nuisance_controls(training)["passed"],
        "development_main_nuisance_audit": audit_nuisance_controls(development)["passed"],
        "train_structured_control_audit": audit_structured_controls(
            training, train_materialized
        )["passed"],
        "development_structured_control_audit": audit_structured_controls(
            development, dev_materialized
        )["passed"],
        "train_trace_target_audit": audit_trace_targets(training)["passed"],
        "development_trace_target_audit": audit_trace_targets(development)["passed"],
        "three_parameter_matched_arms": set(ARMS)
        == {"direct_answer", "nuisance_trace", "semantic_trace"},
        "three_independent_seed_blocks": len(MODEL_SEEDS)
        == len(DATA_SEEDS)
        == 3,
        "free_running_primary": True,
        "teacher_forcing_diagnostic_only": True,
        "development_only": True,
    }
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "source_specificity_id": SOURCE_SPECIFICITY_ID,
        "source_trace_audit_id": SOURCE_TRACE_AUDIT_ID,
        "dataset_manifest_id": manifest["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "arms": ARMS,
        "allocation": ALLOCATION,
        "model_seeds": list(MODEL_SEEDS),
        "data_seeds": list(DATA_SEEDS),
        "steps": 5200,
        "batch_size": 128,
        "compute_device": "cpu",
        "thresholds": {
            "minimum_mean_trace_effect": MINIMUM_MEAN_TRACE_EFFECT,
            "maximum_single_seed_effect_decrement": MAXIMUM_SINGLE_SEED_EFFECT_DECREMENT,
            "mean_noninferiority_margin": MEAN_NONINFERIORITY_MARGIN,
            "single_seed_noninferiority_margin": SINGLE_SEED_NONINFERIORITY_MARGIN,
            "minimum_prefix_joint_accuracy": MINIMUM_PREFIX_JOINT_ACCURACY,
            "minimum_counterfactual_follow_mean": MINIMUM_COUNTERFACTUAL_FOLLOW_MEAN,
            "minimum_counterfactual_follow_seed": MINIMUM_COUNTERFACTUAL_FOLLOW_SEED,
            "minimum_counterfactual_preference_mean": MINIMUM_COUNTERFACTUAL_PREFERENCE_MEAN,
            "minimum_counterfactual_preference_seed": MINIMUM_COUNTERFACTUAL_PREFERENCE_SEED,
            "minimum_uniform_prefix_change_rate": MINIMUM_UNIFORM_PREFIX_CHANGE_RATE,
        },
        "selection_rule": (
            "semantic_trace_beats_nuisance_and_direct_by_mean_0.05;"
            "core_and_evidence_noninferior;free_running_prefix_joint_ge_0.70;"
            "permuted_counterfactual_follow_and_preference_gates;"
            "uniform_prefix_sensitivity_gate"
        ),
        "checks": checks,
        "passed": all(checks.values()),
        "development_only": True,
        "terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "terminal_evaluation_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def _load_progress(path: Path | None, plan_id: str) -> list[Mapping[str, Any]]:
    if path is None or not path.exists():
        return []
    progress = json.loads(path.read_text(encoding="utf-8"))
    if progress.get("version") != VERSION or progress.get("plan_id") != plan_id:
        raise RuntimeError("V68 progress does not match the frozen plan")
    records = list(progress.get("complete_records", []))
    for record in records:
        candidate = dict(record)
        observed = candidate.pop("record_id")
        if observed != content_digest(candidate):
            raise RuntimeError("V68 progress record digest mismatch")
    return records


def _write_progress(
    path: Path | None,
    plan_id: str,
    records: Sequence[Mapping[str, Any]],
    *,
    sealed: bool = False,
    trace_result_id: str | None = None,
) -> None:
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "version": VERSION,
                "plan_id": plan_id,
                "complete_count": len(records),
                "complete_records": records,
                "final_result_sealed": sealed,
                "trace_result_id": trace_result_id,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def run_trace_screen(
    dataset_root: Path,
    capability_profile_path: Path,
    source_specificity_path: Path,
    plan_path: Path,
    progress_path: Path | None = None,
) -> Mapping[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    source = json.loads(source_specificity_path.read_text(encoding="utf-8"))
    if not plan["passed"] or plan["compute_device"] != "cpu":
        raise RuntimeError("V68 plan is not authorized")
    if source["specificity_id"] != plan["source_specificity_id"]:
        raise RuntimeError("V68 source specificity mismatch")
    (
        profile,
        _train_public,
        _train_raw_authority,
        _train_authority,
        development_public,
        _development_raw_authority,
        development_authority,
        training,
        development,
    ) = _load_bundle(dataset_root, capability_profile_path)
    if profile["profile_id"] != plan["capability_profile_id"]:
        raise RuntimeError("V68 capability profile mismatch")
    evaluation_digest = _evaluation_digest(development)
    mx.set_default_device(mx.cpu)
    started = time.monotonic()
    records = _load_progress(progress_path, plan["plan_id"])
    completed = {
        (int(row["model_seed"]), str(row["arm_name"])) for row in records
    }
    for model_seed, data_seed in zip(MODEL_SEEDS, DATA_SEEDS):
        config = SmokeConfig(
            steps=int(plan["steps"]),
            batch_size=int(plan["batch_size"]),
            model_seed=model_seed,
            data_seed=data_seed,
            compute_device="cpu",
        )
        schedule = build_training_plan(training, ALLOCATION, config)
        schedule_digest = _schedule_digest(schedule)
        for arm_name in ARMS:
            key = (model_seed, arm_name)
            if key in completed:
                continue
            trained, predictions = _train_arm(
                arm_name,
                schedule,
                development,
                development_public,
                development_authority,
                config,
                schedule_digest,
                evaluation_digest,
            )
            deterministic_predictions = _deterministic_controller_predictions(
                development, development_public, predictions
            )
            deterministic_e2e = evaluate_end_to_end(
                development_public,
                development_authority,
                deterministic_predictions,
            )
            core_family = _core_family_metrics(development, predictions)
            development_decision = adjudicate_model(
                trained["metrics"], core_family, deterministic_e2e
            )
            record: Dict[str, Any] = {
                **trained,
                "model_seed": model_seed,
                "data_seed": data_seed,
                "allocation": ALLOCATION,
                "core_family_accuracy": core_family,
                "deterministic_end_to_end": deterministic_e2e,
                "development_decision": development_decision,
            }
            record["record_id"] = content_digest(record)
            records.append(record)
            completed.add(key)
            _write_progress(progress_path, plan["plan_id"], records)
            print(
                json.dumps(
                    {
                        "event": "v68_arm_complete",
                        "arm_name": arm_name,
                        "model_seed": model_seed,
                        "main_gate_passed": development_decision["passed"],
                        "arithmetic_answer_accuracy": trained[
                            "answer_family_accuracy"
                        ][ARITHMETIC_FAMILY],
                        "elapsed_seconds": record["elapsed_seconds"],
                    },
                    sort_keys=True,
                ),
                flush=True,
            )

    pairing_checks = {}
    for seed in MODEL_SEEDS:
        block = [row for row in records if int(row["model_seed"]) == seed]
        pairing_checks[str(seed)] = {
            "three_arms": len(block) == 3
            and {row["arm_name"] for row in block} == set(ARMS),
            "identical_initialization": len(
                {row["initial_parameter_digest"] for row in block}
            )
            == 1,
            "identical_schedule": len(
                {row["training_schedule_digest"] for row in block}
            )
            == 1,
            "identical_main_payload": len(
                {row["training_payload_digest"] for row in block}
            )
            == 1,
            "identical_evaluation": len(
                {row["evaluation_digest"] for row in block}
            )
            == 1,
            "identical_parameter_count": len(
                {row["parameter_count"] for row in block}
            )
            == 1,
        }
    checks = {
        "nine_models_complete": len(records) == 9,
        "three_complete_blocks": all(
            row["three_arms"] for row in pairing_checks.values()
        ),
        "paired_initialization": all(
            row["identical_initialization"] for row in pairing_checks.values()
        ),
        "paired_schedule": all(
            row["identical_schedule"] for row in pairing_checks.values()
        ),
        "paired_main_payload": all(
            row["identical_main_payload"] for row in pairing_checks.values()
        ),
        "paired_evaluation": all(
            row["identical_evaluation"] for row in pairing_checks.values()
        ),
        "paired_parameter_count": all(
            row["identical_parameter_count"] for row in pairing_checks.values()
        ),
        "final_parameter_digests_recorded": all(
            bool(row["final_parameter_digest"]) for row in records
        ),
        "cpu_backend_used": all(row["compute_device"] == "cpu" for row in records),
        "trace_primary_is_free_running": all(
            row["trace_metrics"].get("primary_evaluation")
            == "free_running_generated_answer_token"
            for row in records
            if row["answer_objective"] != "direct"
        ),
    }
    verification_passed = all(checks.values())
    decision = adjudicate_trace(records, verification_passed)
    result: Dict[str, Any] = {
        "version": VERSION,
        "plan_id": plan["plan_id"],
        "source_specificity_id": SOURCE_SPECIFICITY_ID,
        "source_trace_audit_id": SOURCE_TRACE_AUDIT_ID,
        "dataset_manifest_id": plan["dataset_manifest_id"],
        "capability_profile_id": plan["capability_profile_id"],
        "records": records,
        "pairing_checks": pairing_checks,
        "checks": checks,
        "verification_passed": verification_passed,
        "decision": decision,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "compute_device": "cpu",
        "development_only": True,
        "terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "terminal_evaluation_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": decision["next_action"],
    }
    result["trace_result_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V68 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(path: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(path, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    means = result["decision"]["means"]
    lines = [
        "# Cognitive-core V68 autoregressive execution trace",
        "",
        "- Verification passed: **%s**" % result["verification_passed"],
        "- Trace recipe established: **%s**"
        % result["decision"]["trace_recipe_established"],
        "- Mean semantic vs nuisance: **%+.1f percentage points**"
        % (means["semantic_vs_nuisance"] * 100.0),
        "- Mean semantic vs direct: **%+.1f percentage points**"
        % (means["semantic_vs_direct"] * 100.0),
        "- Mean evidence delta: **%+.1f percentage points**"
        % (means["evidence_accuracy_delta_vs_best_control"] * 100.0),
        "- Mean semantic prefix joint accuracy: **%.1f%%**"
        % (means["semantic_prefix_joint_accuracy"] * 100.0),
        "- Trace result ID: `%s`" % result["trace_result_id"],
        "",
        "Next action: `%s`." % result["next_action"],
        "",
    ]
    _write_immutable(output / "LOCAL_RESULTS.md", "\n".join(lines))


def seal_progress(path: Path, result: Mapping[str, Any]) -> None:
    _write_progress(
        path,
        str(result["plan_id"]),
        result["records"],
        sealed=True,
        trace_result_id=str(result["trace_result_id"]),
    )


__all__ = [
    "ARMS",
    "DATA_SEEDS",
    "MODEL_SEEDS",
    "SOURCE_SPECIFICITY_ID",
    "SOURCE_TRACE_AUDIT_ID",
    "VERSION",
    "adjudicate_trace",
    "attach_trace_targets",
    "audit_trace_targets",
    "prepare_trace_screen",
    "run_trace_screen",
    "seal_progress",
    "write_plan",
    "write_result",
]
