from __future__ import annotations

import json
import platform
import time
from pathlib import Path
from typing import Any, Dict, Mapping

import mlx.core as mx

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_micro_world_v57 import (
    audit_materialized_policy,
    closed_book_answer_examples,
    estimate_capability_profile,
    load_split,
    materialize_policy_labels,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    _parameter_count,
    _train_answer_calibrator,
)


VERSION = "cognitive-core-uncertainty-aware-control-calibration-v57-r1"


def run_calibration(
    dataset_root: Path,
    config: SmokeConfig,
    *,
    calibration_steps: int = 1200,
) -> Mapping[str, Any]:
    if calibration_steps <= 0:
        raise ValueError("calibration_steps must be positive")
    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    started = time.monotonic()
    development_public, development_authority = load_split(
        dataset_root, "learnability_development"
    )
    calibration_public, calibration_authority = load_split(
        dataset_root, "capability_calibration"
    )
    development = closed_book_answer_examples(
        development_public, development_authority
    )
    calibration = closed_book_answer_examples(
        calibration_public, calibration_authority
    )
    model, calibration_result = _train_answer_calibrator(
        development, calibration, config, calibration_steps
    )
    parameter_count = _parameter_count(model)
    predictions = calibration_result.pop("predictions")
    profile = estimate_capability_profile(
        calibration_public,
        calibration_authority,
        predictions,
        model_id="v57-shared-encoder-%d" % parameter_count,
        checkpoint_id=calibration_result["checkpoint_id"],
    )
    del model

    static_audits = {}
    for split in ("learnability_development", "learnability_replication"):
        public_rows, authority_rows = load_split(dataset_root, split)
        materialized = materialize_policy_labels(
            public_rows, authority_rows, profile
        )
        static_audits[split] = audit_materialized_policy(
            public_rows, materialized
        )
    static_passed = all(audit["passed"] for audit in static_audits.values())

    result: Dict[str, Any] = {
        "version": VERSION,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "config": config.as_dict(),
        "calibration_steps": calibration_steps,
        "parameter_count": parameter_count,
        "calibration_result": calibration_result,
        "capability_profile": profile,
        "static_policy_audits": static_audits,
        "static_gate_passed": static_passed,
        "replication_model_scoring_opened": False,
        "probe_training_authorized": static_passed,
        "joint_training_authorized": False,
        "factorial_authorized": False,
        "hardware": platform.platform(),
        "framework": "mlx",
        "elapsed_seconds": time.monotonic() - started,
        "next_action": (
            "run_v57_target_specific_probes"
            if static_passed
            else "repair_v57_static_oracle_before_training"
        ),
    }
    result["run_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V57 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    _write_immutable(
        output / "capability-profile.json",
        json.dumps(result["capability_profile"], indent=2, sort_keys=True) + "\n",
    )
    audit_rows = result["static_policy_audits"]
    report = "\n".join(
        (
            "# Cognitive-core V57 calibration and static policy audit",
            "",
            "- Static gate passed: **%s**" % result["static_gate_passed"],
            "- Parameters: **%s**" % f"{result['parameter_count']:,}",
            "- Capability profile: `%s`"
            % result["capability_profile"]["profile_id"],
            "- Run ID: `%s`" % result["run_id"],
            "- Replication model scoring opened: **False**",
            "",
            "## Static policy checks",
            "",
            "| Split | Bayes accuracy | Actions | Passed |",
            "|---|---:|---:|---:|",
            *(
                "| %s | %.1f%% | %d | %s |"
                % (
                    split,
                    audit["exact_input_bayes_accuracy"] * 100.0,
                    len(audit["action_counts"]),
                    audit["passed"],
                )
                for split, audit in sorted(audit_rows.items())
            ),
            "",
            "## Decision",
            "",
            "Next action: `%s`. Joint training and the factorial remain unauthorized."
            % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = ["VERSION", "run_calibration", "write_result"]
