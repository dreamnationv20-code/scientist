from __future__ import annotations

import json
import platform
import statistics
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_allocation_screen_v61 import (
    _core_family_metrics,
    adjudicate_model,
    build_training_plan,
)
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
    prediction_index,
)
from scientist.domains.cognitive_core.training_recipe_factorial_data_v65 import (
    audit_dataset,
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_v59 import (
    PROTOCOL_ID,
    _deterministic_controller_predictions,
    _evaluation_digest,
    _schedule_digest,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    TARGET_STATE,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    _arrays,
    _optimizer,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    parameter_count,
)
from scientist.domains.cognitive_core.training_recipe_model_v65c import (
    V65CContextOnlyFusionTransformer,
)
from scientist.domains.cognitive_core.training_recipe_state_bridge_screen_v62 import (
    ALLOCATION,
    ARITHMETIC_FAMILY,
    _parameter_digest,
    _training_payload_digest,
)
from scientist.domains.cognitive_core.training_recipe_structured_fusion_factorial_v65 import (
    CPU_REFERENCE_COMPARISON_ID,
    DATA_SEEDS,
    MODEL_SEEDS,
    STATE_AUDIT_ID,
    STRUCTURED_GATES,
    STRUCTURED_LOSS_WEIGHT,
    _answer_family_accuracy,
    _component_arrays,
    _metrics_from_predictions,
    _structured_decision,
    _structured_metrics,
)
from scientist.domains.cognitive_core.training_recipe_structured_state_v65 import (
    COMPONENTS,
    attach_structured_controls,
    audit_structured_controls,
)


VERSION = "cognitive-core-context-only-matched-control-v65c-r1"
SOURCE_FACTORIAL_ID = (
    "503a701c6a9601d8a1a6473332238a18a555a678430205ac9f620ef813503e76"
)
CONTROL_ARMS = {
    "legacy_context_nonlinear": {"structured_state_supervision": False},
    "structured_context_nonlinear": {"structured_state_supervision": True},
}
MINIMUM_MEAN_DECODED_STATE_ADVANTAGE = 0.03
MINIMUM_MEAN_SEMANTIC_REPRESENTATION_EFFECT = 0.05
MINIMUM_MEAN_GENERIC_CONTEXT_EFFECT = 0.03
MAXIMUM_SINGLE_SEED_DECREMENT = 0.02


def _predict(
    model: V65CContextOnlyFusionTransformer,
    examples: Sequence[Mapping[str, Any]],
    batch_size: int = 512,
) -> Tuple[int, ...]:
    predictions = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        batch = examples[start : start + batch_size]
        tokens, _ = _arrays(batch)
        nuisance_codes = _component_arrays(batch, "structured_nuisance")
        values = mx.argmax(model(tokens, nuisance_codes), axis=-1)
        mx.eval(values)
        predictions.extend(int(value) for value in values.tolist())
    model.train()
    return tuple(predictions)


def _predict_structured(
    model: V65CContextOnlyFusionTransformer,
    examples: Sequence[Mapping[str, Any]],
    batch_size: int = 512,
) -> Mapping[str, Tuple[int, ...]]:
    state_examples = [row for row in examples if row["target"] == "state"]
    predictions = {component: [] for component in COMPONENTS}
    model.eval()
    for start in range(0, len(state_examples), batch_size):
        batch = state_examples[start : start + batch_size]
        tokens, _ = _arrays(batch)
        nuisance_codes = _component_arrays(batch, "structured_nuisance")
        _, logits = model.forward_with_context_control(tokens, nuisance_codes)
        values = tuple(mx.argmax(row, axis=-1) for row in logits)
        mx.eval(values)
        for component, component_values in zip(COMPONENTS, values):
            predictions[component].extend(
                int(value) for value in component_values.tolist()
            )
    model.train()
    return {component: tuple(values) for component, values in predictions.items()}


def _train_control_arm(
    arm_name: str,
    schedule: Sequence[Sequence[Mapping[str, Any]]],
    evaluation: Sequence[Mapping[str, Any]],
    evaluation_public: Sequence[Mapping[str, Any]],
    evaluation_authority: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    schedule_digest: str,
    evaluation_digest: str,
):
    semantic_supervision = CONTROL_ARMS[arm_name][
        "structured_state_supervision"
    ]
    target_field = (
        "structured_semantic"
        if semantic_supervision
        else "structured_nuisance"
    )
    started = time.monotonic()
    mx.random.seed(config.model_seed)
    model = V65CContextOnlyFusionTransformer(config)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    parameters = parameter_count(model)
    optimizer = _optimizer(config, config.steps)

    def loss_fn(
        active_model,
        tokens,
        labels,
        nuisance_current,
        nuisance_operator,
        nuisance_operand,
        target_current,
        target_operator,
        target_operand,
    ):
        logits, structured_logits = active_model.forward_with_context_control(
            tokens,
            (nuisance_current, nuisance_operator, nuisance_operand),
        )
        main_loss = nn.losses.cross_entropy(logits, labels, reduction="mean")
        mask = (tokens[:, 1] == TARGET_STATE).astype(logits.dtype)
        count = mx.sum(mask)
        auxiliary = []
        for component_logits, targets in zip(
            structured_logits,
            (target_current, target_operator, target_operand),
        ):
            losses = nn.losses.cross_entropy(
                component_logits, targets, reduction="none"
            )
            auxiliary.append(mx.sum(losses * mask) / count)
        return main_loss + STRUCTURED_LOSS_WEIGHT * sum(auxiliary) / 3.0

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    for batch in schedule:
        tokens, labels = _arrays(batch)
        nuisance = _component_arrays(batch, "structured_nuisance")
        targets = _component_arrays(batch, target_field)
        loss, gradients = loss_and_grad(
            model, tokens, labels, *nuisance, *targets
        )
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())

    final_parameter_digest = _parameter_digest(model)
    predictions = _predict(model, evaluation)
    metrics = _metrics_from_predictions(evaluation, predictions)
    structured_predictions = _predict_structured(model, evaluation)
    structured_metrics = _structured_metrics(evaluation, structured_predictions)
    learned_end_to_end = evaluate_end_to_end(
        evaluation_public,
        evaluation_authority,
        prediction_index(evaluation, predictions),
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "arm_name": arm_name,
        "factors": CONTROL_ARMS[arm_name],
        "fusion_mode": "context_only_nonlinear",
        "structured_target_kind": (
            "semantic" if semantic_supervision else "nuisance"
        ),
        "config": config.as_dict(),
        "initial_parameter_digest": initial_parameter_digest,
        "final_parameter_digest": final_parameter_digest,
        "parameter_count": parameters,
        "training_schedule_digest": schedule_digest,
        "training_payload_digest": _training_payload_digest(schedule),
        "evaluation_digest": evaluation_digest,
        "last_training_loss": last_loss,
        "metrics": metrics,
        "structured_metrics": structured_metrics,
        "structured_decision": _structured_decision(
            structured_metrics,
            "semantic" if semantic_supervision else "nuisance",
        ),
        "answer_family_accuracy": _answer_family_accuracy(
            evaluation, predictions
        ),
        "learned_end_to_end": learned_end_to_end,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "compute_device": "cpu",
        "inferential": False,
    }
    result["run_id"] = content_digest(result)
    return result, predictions


def _mean_or_nan(values: Sequence[float]) -> float:
    return statistics.fmean(values) if values else float("nan")


def adjudicate_context_control(
    control_records: Sequence[Mapping[str, Any]],
    source_records: Sequence[Mapping[str, Any]],
    verification_passed: bool,
) -> Mapping[str, Any]:
    seed_results = {}
    decoded_effects = []
    semantic_representation_effects = []
    generic_context_effects = []
    structured_context_effects = []
    for seed in MODEL_SEEDS:
        controls = {
            str(row["arm_name"]): row
            for row in control_records
            if int(row["model_seed"]) == seed
        }
        source = {
            str(row["arm_name"]): row
            for row in source_records
            if int(row["model_seed"]) == seed
        }
        if set(controls) != set(CONTROL_ARMS):
            continue
        legacy_context = float(
            controls["legacy_context_nonlinear"]["answer_family_accuracy"]
            [ARITHMETIC_FAMILY]
        )
        structured_context = float(
            controls["structured_context_nonlinear"]
            ["answer_family_accuracy"][ARITHMETIC_FAMILY]
        )
        legacy_additive = float(
            source["legacy_additive"]["answer_family_accuracy"]
            [ARITHMETIC_FAMILY]
        )
        structured_additive = float(
            source["structured_additive"]["answer_family_accuracy"]
            [ARITHMETIC_FAMILY]
        )
        structured_decoded = float(
            source["structured_nonlinear"]["answer_family_accuracy"]
            [ARITHMETIC_FAMILY]
        )
        legacy_decoded = float(
            source["legacy_nonlinear"]["answer_family_accuracy"]
            [ARITHMETIC_FAMILY]
        )
        decoded_effect = structured_decoded - structured_context
        semantic_effect = structured_context - legacy_context
        generic_effect = legacy_context - legacy_additive
        structured_context_effect = structured_context - structured_additive
        decoded_effects.append(decoded_effect)
        semantic_representation_effects.append(semantic_effect)
        generic_context_effects.append(generic_effect)
        structured_context_effects.append(structured_context_effect)
        seed_results[str(seed)] = {
            "arithmetic_answer_accuracy": {
                "legacy_additive": legacy_additive,
                "legacy_decoded_nonlinear": legacy_decoded,
                "legacy_context_nonlinear": legacy_context,
                "structured_additive": structured_additive,
                "structured_decoded_nonlinear": structured_decoded,
                "structured_context_nonlinear": structured_context,
            },
            "decoded_state_advantage": decoded_effect,
            "semantic_representation_effect": semantic_effect,
            "generic_context_effect": generic_effect,
            "structured_context_effect": structured_context_effect,
            "legacy_control_gate": controls["legacy_context_nonlinear"]
            ["structured_decision"]["passed"],
            "structured_control_gate": controls[
                "structured_context_nonlinear"
            ]["structured_decision"]["passed"],
            "structured_context_main_gate": controls[
                "structured_context_nonlinear"
            ]["development_decision"]["passed"],
        }

    mean_decoded = _mean_or_nan(decoded_effects)
    mean_semantic = _mean_or_nan(semantic_representation_effects)
    mean_generic = _mean_or_nan(generic_context_effects)
    mean_structured_context = _mean_or_nan(structured_context_effects)
    complete = len(seed_results) == 2
    common_checks = {
        "execution_verification_passed": verification_passed,
        "two_complete_paired_blocks": complete,
        "legacy_nuisance_gates_pass_two_of_two": complete
        and all(row["legacy_control_gate"] for row in seed_results.values()),
        "structured_semantic_gates_pass_two_of_two": complete
        and all(
            row["structured_control_gate"] for row in seed_results.values()
        ),
    }
    decoded_checks = {
        "mean_at_least_three_points": complete
        and mean_decoded >= MINIMUM_MEAN_DECODED_STATE_ADVANTAGE,
        "no_seed_below_minus_two_points": complete
        and min(decoded_effects) >= -MAXIMUM_SINGLE_SEED_DECREMENT,
    }
    semantic_checks = {
        "mean_at_least_five_points": complete
        and mean_semantic >= MINIMUM_MEAN_SEMANTIC_REPRESENTATION_EFFECT,
        "no_seed_below_minus_two_points": complete
        and min(semantic_representation_effects)
        >= -MAXIMUM_SINGLE_SEED_DECREMENT,
    }
    generic_checks = {
        "mean_at_least_three_points": complete
        and mean_generic >= MINIMUM_MEAN_GENERIC_CONTEXT_EFFECT,
        "no_seed_below_minus_two_points": complete
        and min(generic_context_effects) >= -MAXIMUM_SINGLE_SEED_DECREMENT,
    }
    common_passed = all(common_checks.values())
    decoded_supported = common_passed and all(decoded_checks.values())
    representation_shaping_supported = common_passed and all(
        semantic_checks.values()
    )
    generic_context_supported = common_passed and all(generic_checks.values())
    if decoded_supported and representation_shaping_supported:
        next_action = "freeze_fresh_decoded_state_mediation_replication"
    elif representation_shaping_supported:
        next_action = "optimize_semantic_auxiliary_representation_shaping"
    elif generic_context_supported:
        next_action = (
            "retain_context_mlp_and_replace_categorical_state_with_"
            "token_execution_trace"
        )
    else:
        next_action = "replace_categorical_state_heads_with_token_execution_trace"
    return {
        "seed_results": seed_results,
        "mean_decoded_state_advantage": mean_decoded,
        "mean_semantic_representation_effect": mean_semantic,
        "mean_generic_context_effect": mean_generic,
        "mean_structured_context_effect": mean_structured_context,
        "common_checks": common_checks,
        "decoded_state_checks": decoded_checks,
        "semantic_representation_checks": semantic_checks,
        "generic_context_checks": generic_checks,
        "decoded_state_supported": decoded_supported,
        "representation_shaping_supported": representation_shaping_supported,
        "generic_context_supported": generic_context_supported,
        "next_action": next_action,
        "fresh_replication_authorized": False,
        "scaling_authorized": False,
    }


def _verified_digest(payload: Mapping[str, Any], id_field: str) -> bool:
    candidate = dict(payload)
    observed = candidate.pop(id_field)
    return observed == content_digest(candidate)


def prepare_context_control(
    dataset_root: Path,
    capability_profile_path: Path,
    source_result_path: Path,
) -> Mapping[str, Any]:
    source = json.loads(source_result_path.read_text(encoding="utf-8"))
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    train_public, train_authority = load_split(dataset_root, "factorial_train")
    development_public, development_authority = load_split(
        dataset_root, "factorial_development"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    development_materialized = materialize_policy_labels(
        development_public, development_authority, profile
    )
    training = attach_structured_controls(
        training_examples(train_public, train_materialized), train_materialized
    )
    development = attach_structured_controls(
        training_examples(development_public, development_materialized),
        development_materialized,
    )
    manifest = json.loads(
        (dataset_root / "manifest.json").read_text(encoding="utf-8")
    )
    checks = {
        "source_digest_valid": _verified_digest(source, "factorial_id"),
        "source_factorial_matches": source["factorial_id"]
        == SOURCE_FACTORIAL_ID,
        "source_execution_verified": source["verification_passed"] is True,
        "source_selected_context_control": source["next_action"]
        == "add_parameter_matched_context_only_mlp_control",
        "source_v66_not_authorized": source["decision"]
        ["v66_replication_authorized"]
        is False,
        "source_has_eight_records": len(source["records"]) == 8,
        "dataset_manifest_matches": manifest["manifest_id"]
        == source["dataset_manifest_id"],
        "capability_profile_matches": profile["profile_id"]
        == source["capability_profile_id"],
        "train_raw_audit": audit_dataset(train_public, train_authority)[
            "passed"
        ],
        "development_raw_audit": audit_dataset(
            development_public, development_authority
        )["passed"],
        "train_main_nuisance_audit": audit_nuisance_controls(training)[
            "passed"
        ],
        "development_main_nuisance_audit": audit_nuisance_controls(
            development
        )["passed"],
        "train_structured_control_audit": audit_structured_controls(
            training, train_materialized
        )["passed"],
        "development_structured_control_audit": audit_structured_controls(
            development, development_materialized
        )["passed"],
        "two_supervision_levels": {
            row["structured_state_supervision"]
            for row in CONTROL_ARMS.values()
        }
        == {False, True},
        "development_only": True,
    }
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "source_factorial_id": SOURCE_FACTORIAL_ID,
        "source_plan_id": source["plan_id"],
        "state_audit_id": STATE_AUDIT_ID,
        "cpu_reference_comparison_id": CPU_REFERENCE_COMPARISON_ID,
        "dataset_manifest_id": manifest["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "control_arms": CONTROL_ARMS,
        "allocation": ALLOCATION,
        "model_seeds": list(MODEL_SEEDS),
        "data_seeds": list(DATA_SEEDS),
        "steps": 5200,
        "batch_size": 128,
        "compute_device": "cpu",
        "structured_loss_weight": STRUCTURED_LOSS_WEIGHT,
        "structured_gates": STRUCTURED_GATES,
        "thresholds": {
            "minimum_mean_decoded_state_advantage": (
                MINIMUM_MEAN_DECODED_STATE_ADVANTAGE
            ),
            "minimum_mean_semantic_representation_effect": (
                MINIMUM_MEAN_SEMANTIC_REPRESENTATION_EFFECT
            ),
            "minimum_mean_generic_context_effect": (
                MINIMUM_MEAN_GENERIC_CONTEXT_EFFECT
            ),
            "maximum_single_seed_decrement": MAXIMUM_SINGLE_SEED_DECREMENT,
        },
        "selection_rule": (
            "direct_decoded_state_if_mean_decoded_minus_context_ge_0.03_and_"
            "no_seed_lt_minus_0.02;representation_shaping_if_mean_semantic_"
            "context_effect_ge_0.05_and_no_seed_lt_minus_0.02;otherwise_"
            "generic_context_or_token_trace_branch"
        ),
        "checks": checks,
        "passed": all(checks.values()),
        "development_only": True,
        "terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "fresh_replication_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def _load_progress(
    progress_path: Path | None, plan_id: str
) -> list[Mapping[str, Any]]:
    if progress_path is None or not progress_path.exists():
        return []
    progress = json.loads(progress_path.read_text(encoding="utf-8"))
    if progress.get("version") != VERSION or progress.get("plan_id") != plan_id:
        raise RuntimeError("V65C progress does not match the frozen plan")
    records = list(progress.get("complete_records", []))
    for record in records:
        candidate = dict(record)
        observed = candidate.pop("record_id")
        if observed != content_digest(candidate):
            raise RuntimeError("V65C progress record digest mismatch")
    return records


def _write_progress(
    progress_path: Path | None,
    plan_id: str,
    records: Sequence[Mapping[str, Any]],
    final_result_sealed: bool = False,
    control_id: str | None = None,
) -> None:
    if progress_path is None:
        return
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    progress_path.write_text(
        json.dumps(
            {
                "version": VERSION,
                "plan_id": plan_id,
                "complete_count": len(records),
                "complete_records": records,
                "final_result_sealed": final_result_sealed,
                "control_id": control_id,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def run_context_control(
    dataset_root: Path,
    capability_profile_path: Path,
    source_result_path: Path,
    plan_path: Path,
    progress_path: Path | None = None,
) -> Mapping[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    source = json.loads(source_result_path.read_text(encoding="utf-8"))
    if not plan["passed"] or plan["compute_device"] != "cpu":
        raise RuntimeError("V65C plan is not authorized")
    if source["factorial_id"] != plan["source_factorial_id"]:
        raise RuntimeError("V65C source factorial mismatch")
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if profile["profile_id"] != plan["capability_profile_id"]:
        raise RuntimeError("V65C capability profile mismatch")

    train_public, train_authority = load_split(dataset_root, "factorial_train")
    development_public, development_authority = load_split(
        dataset_root, "factorial_development"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    training = attach_structured_controls(
        training_examples(train_public, train_materialized), train_materialized
    )
    development_materialized = materialize_policy_labels(
        development_public, development_authority, profile
    )
    development = attach_structured_controls(
        training_examples(development_public, development_materialized),
        development_materialized,
    )
    evaluation_digest = _evaluation_digest(development)
    source_by_seed = {
        (int(row["model_seed"]), str(row["arm_name"])): row
        for row in source["records"]
    }
    mx.set_default_device(mx.cpu)
    started = time.monotonic()
    records = _load_progress(progress_path, plan["plan_id"])
    completed = {
        (int(row["model_seed"]), str(row["arm_name"])) for row in records
    }
    for model_seed, data_seed in zip(MODEL_SEEDS, DATA_SEEDS):
        config = SmokeConfig(
            steps=int(plan["steps"]),
            batch_size=int(plan["batch_size"]),
            model_seed=model_seed,
            data_seed=data_seed,
            compute_device="cpu",
        )
        frozen_schedule = build_training_plan(training, ALLOCATION, config)
        schedule_digest = _schedule_digest(frozen_schedule)
        for arm_name in CONTROL_ARMS:
            key = (model_seed, arm_name)
            if key in completed:
                continue
            trained, predictions = _train_control_arm(
                arm_name,
                frozen_schedule,
                development,
                development_public,
                development_materialized,
                config,
                schedule_digest,
                evaluation_digest,
            )
            deterministic_predictions = _deterministic_controller_predictions(
                development, development_public, predictions
            )
            deterministic_e2e = evaluate_end_to_end(
                development_public,
                development_materialized,
                deterministic_predictions,
            )
            core_family = _core_family_metrics(development, predictions)
            development_decision = adjudicate_model(
                trained["metrics"], core_family, deterministic_e2e
            )
            record: Dict[str, Any] = {
                **trained,
                "model_seed": model_seed,
                "data_seed": data_seed,
                "allocation": ALLOCATION,
                "core_family_accuracy": core_family,
                "deterministic_end_to_end": deterministic_e2e,
                "development_decision": development_decision,
            }
            record["record_id"] = content_digest(record)
            records.append(record)
            completed.add(key)
            _write_progress(progress_path, plan["plan_id"], records)
            print(
                json.dumps(
                    {
                        "event": "v65c_arm_complete",
                        "arm_name": arm_name,
                        "model_seed": model_seed,
                        "main_gate_passed": development_decision["passed"],
                        "structured_gate_passed": trained[
                            "structured_decision"
                        ]["passed"],
                        "elapsed_seconds": record["elapsed_seconds"],
                    },
                    sort_keys=True,
                ),
                flush=True,
            )

    pairing_checks = {}
    for seed in MODEL_SEEDS:
        block = [row for row in records if int(row["model_seed"]) == seed]
        source_reference = source_by_seed[(seed, "legacy_additive")]
        pairing_checks[str(seed)] = {
            "two_control_arms": len(block) == 2
            and {row["arm_name"] for row in block} == set(CONTROL_ARMS),
            "identical_control_initialization": len(
                {row["initial_parameter_digest"] for row in block}
            )
            == 1,
            "initialization_matches_source": all(
                row["initial_parameter_digest"]
                == source_reference["initial_parameter_digest"]
                for row in block
            ),
            "schedule_matches_source": all(
                row["training_schedule_digest"]
                == source_reference["training_schedule_digest"]
                for row in block
            ),
            "main_payload_matches_source": all(
                row["training_payload_digest"]
                == source_reference["training_payload_digest"]
                for row in block
            ),
            "evaluation_matches_source": all(
                row["evaluation_digest"]
                == source_reference["evaluation_digest"]
                for row in block
            ),
            "parameter_count_matches_source": all(
                row["parameter_count"] == source_reference["parameter_count"]
                for row in block
            ),
        }
    checks = {
        "four_control_models_complete": len(records) == 4,
        "two_complete_paired_blocks": all(
            row["two_control_arms"] for row in pairing_checks.values()
        ),
        "paired_initialization": all(
            row["identical_control_initialization"]
            for row in pairing_checks.values()
        ),
        "source_initialization_matched": all(
            row["initialization_matches_source"]
            for row in pairing_checks.values()
        ),
        "source_schedule_matched": all(
            row["schedule_matches_source"] for row in pairing_checks.values()
        ),
        "source_main_payload_matched": all(
            row["main_payload_matches_source"]
            for row in pairing_checks.values()
        ),
        "source_evaluation_matched": all(
            row["evaluation_matches_source"] for row in pairing_checks.values()
        ),
        "source_parameter_count_matched": all(
            row["parameter_count_matches_source"]
            for row in pairing_checks.values()
        ),
        "final_parameter_digests_recorded": all(
            bool(row["final_parameter_digest"]) for row in records
        ),
        "cpu_reference_backend_used": all(
            row["compute_device"] == "cpu" for row in records
        ),
    }
    verification_passed = all(checks.values())
    decision = adjudicate_context_control(
        records, source["records"], verification_passed
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "plan_id": plan["plan_id"],
        "source_factorial_id": SOURCE_FACTORIAL_ID,
        "dataset_manifest_id": plan["dataset_manifest_id"],
        "capability_profile_id": plan["capability_profile_id"],
        "state_audit_id": STATE_AUDIT_ID,
        "cpu_reference_comparison_id": CPU_REFERENCE_COMPARISON_ID,
        "records": records,
        "pairing_checks": pairing_checks,
        "checks": checks,
        "verification_passed": verification_passed,
        "decision": decision,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "compute_device": "cpu",
        "development_only": True,
        "terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "fresh_replication_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": decision["next_action"],
    }
    result["control_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V65C artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(path: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(path, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    rows = []
    for record in result["records"]:
        rows.append(
            "| %d | %s | %s | %s | %.1f%% | %.1f%% | %.1f%% |"
            % (
                record["model_seed"],
                record["arm_name"],
                record["development_decision"]["passed"],
                record["structured_decision"]["passed"],
                record["answer_family_accuracy"][ARITHMETIC_FAMILY] * 100.0,
                record["core_family_accuracy"][ARITHMETIC_FAMILY] * 100.0,
                record["structured_metrics"]["semantic"]["current_value"]
                ["accuracy"]
                * 100.0,
            )
        )
    decision = result["decision"]
    report = "\n".join(
        [
            "# Cognitive-core V65C context-only matched control",
            "",
            "- Verification passed: **%s**" % result["verification_passed"],
            "- Mean decoded-state advantage: **%+.1f percentage points**"
            % (decision["mean_decoded_state_advantage"] * 100.0),
            "- Mean semantic representation effect: **%+.1f percentage points**"
            % (decision["mean_semantic_representation_effect"] * 100.0),
            "- Mean generic context effect: **%+.1f percentage points**"
            % (decision["mean_generic_context_effect"] * 100.0),
            "- Control ID: `%s`" % result["control_id"],
            "",
            "| Seed | Arm | Main pass | Structured/control pass | Arithmetic answer | Arithmetic core | Semantic current |",
            "|---:|---|---|---|---:|---:|---:|",
            *rows,
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        ]
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


def seal_progress(
    progress_path: Path, result: Mapping[str, Any]
) -> None:
    _write_progress(
        progress_path,
        str(result["plan_id"]),
        result["records"],
        final_result_sealed=True,
        control_id=str(result["control_id"]),
    )


__all__ = [
    "CONTROL_ARMS",
    "SOURCE_FACTORIAL_ID",
    "VERSION",
    "adjudicate_context_control",
    "prepare_context_control",
    "run_context_control",
    "seal_progress",
    "write_plan",
    "write_result",
]
