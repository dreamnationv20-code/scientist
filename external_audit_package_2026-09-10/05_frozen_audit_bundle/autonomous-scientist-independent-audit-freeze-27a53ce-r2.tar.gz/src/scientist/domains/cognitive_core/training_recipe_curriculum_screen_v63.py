from __future__ import annotations

import json
import platform
import statistics
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_allocation_screen_v61 import (
    _core_family_metrics,
    adjudicate_model,
    build_training_plan,
)
from scientist.domains.cognitive_core.training_recipe_curriculum_data_v63 import (
    audit_dataset,
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
    prediction_index,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_v59 import (
    PROTOCOL_ID,
    _deterministic_controller_predictions,
    _evaluation_digest,
    _schedule_digest,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    _arrays,
    _optimizer,
    _predict,
    evaluate,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import parameter_count
from scientist.domains.cognitive_core.training_recipe_model_v63 import (
    V63TeacherTransitionTransformer,
)
from scientist.domains.cognitive_core.training_recipe_state_bridge_screen_v62 import (
    ALLOCATION,
    ARITHMETIC_FAMILY,
    _parameter_digest,
    _training_payload_digest,
)


VERSION = "cognitive-core-state-curriculum-screen-v63-r1"
PREDECESSOR_SCREEN_ID = (
    "924fe4df7438836a9568df0ad49a7aa48055eb6e7dd44132289ed5919ea5ba75"
)
CPU_REFERENCE_COMPARISON_ID = (
    "72c7ee32be30dd553b763cb88be01cbc769360c2a4f323c88cc3902def160d5f"
)
CANDIDATES = ("predicted_control", "state_curriculum")
MODEL_SEEDS = (65101, 65201)
DATA_SEEDS = (65111, 65211)
TEACHER_PHASE_END = 1300
TRANSITION_PHASE_END = 3900
TOTAL_STEPS = 5200
MINIMUM_MEAN_ARITHMETIC_GAIN = 0.03
MAXIMUM_SINGLE_SEED_ARITHMETIC_DECREMENT = 0.02
ORACLE_LIFT_DIAGNOSTIC_THRESHOLD = 0.05


def teacher_alpha(step: int) -> float:
    if not 1 <= step <= TOTAL_STEPS:
        raise ValueError("V63 curriculum step is outside the frozen schedule")
    if step <= TEACHER_PHASE_END:
        return 1.0
    if step <= TRANSITION_PHASE_END:
        return (TRANSITION_PHASE_END - step) / (
            TRANSITION_PHASE_END - TEACHER_PHASE_END
        )
    return 0.0


def _state_by_view(
    authority_rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, int]:
    return {str(row["view_id"]): int(row["state"]) for row in authority_rows}


def _teacher_state_array(
    examples: Sequence[Mapping[str, Any]], state_by_view: Mapping[str, int]
) -> mx.array:
    return mx.array(
        [state_by_view[str(row["view_id"])] for row in examples],
        dtype=mx.int32,
    )


def _predict_with_teacher_state(
    model: V63TeacherTransitionTransformer,
    examples: Sequence[Mapping[str, Any]],
    state_by_view: Mapping[str, int],
    batch_size: int = 512,
) -> Tuple[int, ...]:
    predictions = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        batch = examples[start : start + batch_size]
        tokens, _ = _arrays(batch)
        states = _teacher_state_array(batch, state_by_view)
        values = mx.argmax(model(tokens, states, 1.0), axis=-1)
        mx.eval(values)
        predictions.extend(int(value) for value in values.tolist())
    model.train()
    return tuple(predictions)


def _answer_family_accuracy(
    examples: Sequence[Mapping[str, Any]], predictions: Sequence[int]
) -> Mapping[str, float]:
    outcomes: Dict[str, list[bool]] = {}
    for row, prediction in zip(examples, predictions):
        if row["target"] == "answer":
            outcomes.setdefault(str(row["family"]), []).append(
                int(prediction) == int(row["semantic_label"])
            )
    return {
        family: sum(values) / len(values)
        for family, values in sorted(outcomes.items())
    }


def _train_candidate(
    candidate: str,
    plan: Sequence[Sequence[Mapping[str, Any]]],
    training_state_by_view: Mapping[str, int],
    evaluation: Sequence[Mapping[str, Any]],
    evaluation_public: Sequence[Mapping[str, Any]],
    evaluation_authority: Sequence[Mapping[str, Any]],
    evaluation_state_by_view: Mapping[str, int],
    config: SmokeConfig,
    schedule_digest: str,
    evaluation_digest: str,
):
    if candidate not in CANDIDATES:
        raise ValueError("unknown V63 candidate: %s" % candidate)
    started = time.monotonic()
    mx.random.seed(config.model_seed)
    model = V63TeacherTransitionTransformer(config)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    parameters = parameter_count(model)
    optimizer = _optimizer(config, config.steps)

    def loss_fn(active_model, tokens, labels, teacher_state, alpha):
        return nn.losses.cross_entropy(
            active_model(tokens, teacher_state, alpha),
            labels,
            reduction="mean",
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    alpha_digest_values = []
    for step, batch in enumerate(plan, start=1):
        alpha = teacher_alpha(step) if candidate == "state_curriculum" else 0.0
        tokens, labels = _arrays(batch)
        teacher_state = _teacher_state_array(batch, training_state_by_view)
        loss, gradients = loss_and_grad(
            model, tokens, labels, teacher_state, alpha
        )
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
        alpha_digest_values.append(alpha)
    final_parameter_digest = _parameter_digest(model)
    predictions = _predict(model, evaluation)
    metrics = evaluate(model, evaluation)
    learned_end_to_end = evaluate_end_to_end(
        evaluation_public,
        evaluation_authority,
        prediction_index(evaluation, predictions),
    )
    oracle_predictions = _predict_with_teacher_state(
        model, evaluation, evaluation_state_by_view
    )
    predicted_answer_family = _answer_family_accuracy(evaluation, predictions)
    oracle_answer_family = _answer_family_accuracy(evaluation, oracle_predictions)
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "candidate": candidate,
        "config": config.as_dict(),
        "initial_parameter_digest": initial_parameter_digest,
        "final_parameter_digest": final_parameter_digest,
        "parameter_count": parameters,
        "training_schedule_digest": schedule_digest,
        "training_payload_digest": _training_payload_digest(plan),
        "teacher_alpha_digest": content_digest(alpha_digest_values),
        "teacher_alpha_summary": {
            "first": alpha_digest_values[0],
            "teacher_phase_end": alpha_digest_values[TEACHER_PHASE_END - 1],
            "transition_first": alpha_digest_values[TEACHER_PHASE_END],
            "transition_end": alpha_digest_values[TRANSITION_PHASE_END - 1],
            "final": alpha_digest_values[-1],
        },
        "evaluation_digest": evaluation_digest,
        "last_training_loss": last_loss,
        "metrics": metrics,
        "learned_end_to_end": learned_end_to_end,
        "predicted_answer_family_accuracy": predicted_answer_family,
        "oracle_answer_family_accuracy": oracle_answer_family,
        "oracle_arithmetic_answer_lift": (
            oracle_answer_family[ARITHMETIC_FAMILY]
            - predicted_answer_family[ARITHMETIC_FAMILY]
        ),
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "compute_device": "cpu",
        "inferential": False,
    }
    result["run_id"] = content_digest(result)
    return result, predictions


def adjudicate_screen(
    records: Sequence[Mapping[str, Any]], verification_passed: bool
) -> Mapping[str, Any]:
    paired_results = {}
    effects = []
    for seed in MODEL_SEEDS:
        rows = {
            str(row["candidate"]): row
            for row in records
            if int(row["model_seed"]) == seed
        }
        if set(rows) != set(CANDIDATES):
            continue
        control = float(
            rows["predicted_control"]["core_family_accuracy"][ARITHMETIC_FAMILY]
        )
        curriculum = float(
            rows["state_curriculum"]["core_family_accuracy"][ARITHMETIC_FAMILY]
        )
        effect = curriculum - control
        effects.append(effect)
        paired_results[str(seed)] = {
            "predicted_control_arithmetic_core_accuracy": control,
            "state_curriculum_arithmetic_core_accuracy": curriculum,
            "paired_arithmetic_effect": effect,
            "state_curriculum_full_gate_passed": rows["state_curriculum"]
            ["development_decision"]["passed"],
            "state_curriculum_oracle_arithmetic_answer_lift": rows[
                "state_curriculum"
            ]["oracle_arithmetic_answer_lift"],
        }
    curriculum_rows = [
        row for row in records if row["candidate"] == "state_curriculum"
    ]
    curriculum_passes = sum(
        int(row["development_decision"]["passed"]) for row in curriculum_rows
    )
    mean_effect = statistics.fmean(effects) if effects else float("nan")
    oracle_lifts = [
        float(row["oracle_arithmetic_answer_lift"]) for row in curriculum_rows
    ]
    mean_oracle_lift = (
        statistics.fmean(oracle_lifts) if oracle_lifts else float("nan")
    )
    checks = {
        "execution_verification_passed": verification_passed,
        "two_complete_pairs": len(effects) == 2,
        "curriculum_passes_two_of_two": (
            len(curriculum_rows) == 2 and curriculum_passes == 2
        ),
        "mean_arithmetic_gain_at_least_three_points": (
            len(effects) == 2 and mean_effect >= MINIMUM_MEAN_ARITHMETIC_GAIN
        ),
        "no_arithmetic_decrement_worse_than_two_points": (
            len(effects) == 2
            and min(effects) >= -MAXIMUM_SINGLE_SEED_ARITHMETIC_DECREMENT
        ),
    }
    eligible = all(checks.values())
    if eligible:
        next_action = "freeze_fresh_v64_terminal_replication_of_state_curriculum"
    elif mean_oracle_lift >= ORACLE_LIFT_DIAGNOSTIC_THRESHOLD:
        next_action = (
            "freeze_noisy_teacher_distillation_and_uncertainty_gated_state_bridge"
        )
    else:
        next_action = "audit_and_redesign_state_target_for_causal_sufficiency"
    return {
        "paired_results": paired_results,
        "curriculum_full_gate_passes": curriculum_passes,
        "mean_paired_arithmetic_effect": mean_effect,
        "mean_curriculum_oracle_arithmetic_answer_lift": mean_oracle_lift,
        "checks": checks,
        "state_curriculum_eligible": eligible,
        "v64_terminal_replication_authorized": eligible,
        "next_action": next_action,
    }


def prepare_screen(
    dataset_root: Path,
    capability_profile_path: Path,
    predecessor_result_path: Path,
    cpu_reference_comparison_path: Path,
) -> Mapping[str, Any]:
    predecessor = json.loads(predecessor_result_path.read_text(encoding="utf-8"))
    cpu_reference = json.loads(
        cpu_reference_comparison_path.read_text(encoding="utf-8")
    )
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if (
        predecessor["screen_id"] != PREDECESSOR_SCREEN_ID
        or predecessor["decision"]["state_bound_eligible"] is not False
        or predecessor["decision"]["v63_terminal_replication_authorized"]
        is not False
    ):
        raise RuntimeError("V63 predecessor decision mismatch")
    if (
        cpu_reference["comparison_id"] != CPU_REFERENCE_COMPARISON_ID
        or cpu_reference["exact_cross_process_reproducibility"] is not True
        or cpu_reference["next_action"]
        != "authorize_cpu_as_deterministic_reference_backend"
    ):
        raise RuntimeError("V63 CPU reference audit mismatch")
    train_public, train_authority = load_split(dataset_root, "curriculum_train")
    development_public, development_authority = load_split(
        dataset_root, "curriculum_development"
    )
    checks = {
        "v62_bridge_rejected": True,
        "cpu_full_horizon_exact": True,
        "train_audit": audit_dataset(train_public, train_authority)["passed"],
        "development_audit": audit_dataset(
            development_public, development_authority
        )["passed"],
        "train_worlds_8192": len({row["base_id"] for row in train_public}) == 8192,
        "development_worlds_2048": (
            len({row["base_id"] for row in development_public}) == 2048
        ),
        "two_paired_seeds": len(MODEL_SEEDS) == len(DATA_SEEDS) == 2,
        "identical_architecture_across_candidates": True,
        "validity_heavy_allocation_fixed": sum(ALLOCATION.values()) == 128,
        "deterministic_delivery_fixed": True,
        "deployment_uses_predicted_state": True,
        "oracle_is_diagnostic_only": True,
    }
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "predecessor_screen_id": PREDECESSOR_SCREEN_ID,
        "cpu_reference_comparison_id": CPU_REFERENCE_COMPARISON_ID,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "candidates": list(CANDIDATES),
        "allocation": ALLOCATION,
        "model_seeds": list(MODEL_SEEDS),
        "data_seeds": list(DATA_SEEDS),
        "steps": TOTAL_STEPS,
        "batch_size": 128,
        "compute_device": "cpu",
        "curriculum": {
            "teacher_phase_end": TEACHER_PHASE_END,
            "transition_phase_end": TRANSITION_PHASE_END,
            "predicted_only_phase_start": TRANSITION_PHASE_END + 1,
        },
        "minimum_mean_arithmetic_gain": MINIMUM_MEAN_ARITHMETIC_GAIN,
        "maximum_single_seed_arithmetic_decrement": (
            MAXIMUM_SINGLE_SEED_ARITHMETIC_DECREMENT
        ),
        "oracle_lift_diagnostic_threshold": ORACLE_LIFT_DIAGNOSTIC_THRESHOLD,
        "selection_rule": (
            "curriculum_two_of_two_full_gates_and_mean_paired_arithmetic_gain_"
            "ge_0.03_and_no_single_seed_effect_lt_minus_0.02"
        ),
        "checks": checks,
        "passed": all(checks.values()),
        "development_only": True,
        "v64_terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def run_screen(
    dataset_root: Path,
    capability_profile_path: Path,
    plan_path: Path,
    progress_path: Path | None = None,
) -> Mapping[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if (
        not plan["passed"]
        or not plan["development_only"]
        or plan["compute_device"] != "cpu"
    ):
        raise RuntimeError("V63 plan is not authorized")
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if profile["profile_id"] != plan["capability_profile_id"]:
        raise RuntimeError("V63 capability profile mismatch")
    train_public, train_authority = load_split(dataset_root, "curriculum_train")
    development_public, development_authority = load_split(
        dataset_root, "curriculum_development"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    training = training_examples(train_public, train_materialized)
    if not audit_nuisance_controls(training)["passed"]:
        raise RuntimeError("V63 nuisance audit failed")
    development_materialized = materialize_policy_labels(
        development_public, development_authority, profile
    )
    development = training_examples(development_public, development_materialized)
    training_states = _state_by_view(train_materialized)
    development_states = _state_by_view(development_materialized)
    evaluation_digest = _evaluation_digest(development)
    mx.set_default_device(mx.cpu)
    started = time.monotonic()
    records = []
    for model_seed, data_seed in zip(MODEL_SEEDS, DATA_SEEDS):
        config = SmokeConfig(
            steps=int(plan["steps"]),
            batch_size=int(plan["batch_size"]),
            model_seed=model_seed,
            data_seed=data_seed,
            compute_device="cpu",
        )
        frozen_schedule = build_training_plan(training, ALLOCATION, config)
        schedule_digest = _schedule_digest(frozen_schedule)
        for candidate in CANDIDATES:
            trained, predictions = _train_candidate(
                candidate,
                frozen_schedule,
                training_states,
                development,
                development_public,
                development_materialized,
                development_states,
                config,
                schedule_digest,
                evaluation_digest,
            )
            deterministic_predictions = _deterministic_controller_predictions(
                development, development_public, predictions
            )
            deterministic_e2e = evaluate_end_to_end(
                development_public,
                development_materialized,
                deterministic_predictions,
            )
            core_family = _core_family_metrics(development, predictions)
            development_decision = adjudicate_model(
                trained["metrics"], core_family, deterministic_e2e
            )
            record: Dict[str, Any] = {
                **trained,
                "model_seed": model_seed,
                "data_seed": data_seed,
                "allocation": ALLOCATION,
                "core_family_accuracy": core_family,
                "deterministic_end_to_end": deterministic_e2e,
                "development_decision": development_decision,
            }
            record["record_id"] = content_digest(record)
            records.append(record)
            if progress_path is not None:
                progress_path.parent.mkdir(parents=True, exist_ok=True)
                progress_path.write_text(
                    json.dumps(
                        {
                            "version": VERSION,
                            "plan_id": plan["plan_id"],
                            "complete_records": records,
                            "complete_count": len(records),
                            "final_result_sealed": False,
                        },
                        indent=2,
                        sort_keys=True,
                    )
                    + "\n",
                    encoding="utf-8",
                )
            print(
                json.dumps(
                    {
                        "event": "v63_model_complete",
                        "candidate": candidate,
                        "model_seed": model_seed,
                        "development_passed": development_decision["passed"],
                        "elapsed_seconds": record["elapsed_seconds"],
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
    pairing_checks = {}
    for seed in MODEL_SEEDS:
        paired = [row for row in records if row["model_seed"] == seed]
        pairing_checks[str(seed)] = {
            "two_candidates": len(paired) == 2
            and {row["candidate"] for row in paired} == set(CANDIDATES),
            "identical_initialization": len(
                {row["initial_parameter_digest"] for row in paired}
            )
            == 1,
            "identical_training_schedule": len(
                {row["training_schedule_digest"] for row in paired}
            )
            == 1,
            "identical_training_payload": len(
                {row["training_payload_digest"] for row in paired}
            )
            == 1,
        }
    checks = {
        "four_models_complete": len(records) == 4,
        "two_candidates_per_seed": all(
            row["two_candidates"] for row in pairing_checks.values()
        ),
        "paired_initialization": all(
            row["identical_initialization"] for row in pairing_checks.values()
        ),
        "paired_training_schedule": all(
            row["identical_training_schedule"] for row in pairing_checks.values()
        ),
        "paired_training_payload": all(
            row["identical_training_payload"] for row in pairing_checks.values()
        ),
        "identical_evaluation_cases": len(
            {row["evaluation_digest"] for row in records}
        )
        == 1,
        "identical_parameter_counts": len(
            {row["parameter_count"] for row in records}
        )
        == 1,
        "cpu_reference_backend_used": all(
            row["compute_device"] == "cpu" for row in records
        ),
        "final_parameter_digests_recorded": all(
            bool(row["final_parameter_digest"]) for row in records
        ),
    }
    verification_passed = all(checks.values())
    decision = adjudicate_screen(records, verification_passed)
    result: Dict[str, Any] = {
        "version": VERSION,
        "plan_id": plan["plan_id"],
        "dataset_manifest_id": plan["dataset_manifest_id"],
        "capability_profile_id": plan["capability_profile_id"],
        "predecessor_screen_id": PREDECESSOR_SCREEN_ID,
        "cpu_reference_comparison_id": CPU_REFERENCE_COMPARISON_ID,
        "records": records,
        "pairing_checks": pairing_checks,
        "checks": checks,
        "verification_passed": verification_passed,
        "decision": decision,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "compute_device": "cpu",
        "development_only": True,
        "v64_terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": decision["next_action"],
    }
    result["screen_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V63 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(path: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(path, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    rows = []
    for record in result["records"]:
        observations = record["development_decision"]["observations"]
        rows.append(
            "| %d | %s | %s | %.1f%% | %.1f%% | %.1f%% | %+.1f pp |"
            % (
                record["model_seed"],
                record["candidate"],
                record["development_decision"]["passed"],
                observations["answer_accuracy"] * 100.0,
                record["core_family_accuracy"][ARITHMETIC_FAMILY] * 100.0,
                record["oracle_answer_family_accuracy"][ARITHMETIC_FAMILY]
                * 100.0,
                record["oracle_arithmetic_answer_lift"] * 100.0,
            )
        )
    report = "\n".join(
        (
            "# Cognitive-core V63 state-curriculum screen",
            "",
            "- Execution verification passed: **%s**" % result["verification_passed"],
            "- State curriculum eligible: **%s**"
            % result["decision"]["state_curriculum_eligible"],
            "- Mean paired arithmetic effect: **%+.1f percentage points**"
            % (result["decision"]["mean_paired_arithmetic_effect"] * 100.0),
            "- Mean curriculum oracle answer lift: **%+.1f percentage points**"
            % (
                result["decision"][
                    "mean_curriculum_oracle_arithmetic_answer_lift"
                ]
                * 100.0
            ),
            "- V64 terminal replication authorized: **%s**"
            % result["decision"]["v64_terminal_replication_authorized"],
            "- V64 terminal data opened: **False**",
            "- Screen ID: `%s`" % result["screen_id"],
            "",
            "| Seed | Candidate | Full pass | Answer | Arithmetic core | Oracle arithmetic answer | Oracle lift |",
            "|---:|---|---|---:|---:|---:|---:|",
            *rows,
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = [
    "CANDIDATES",
    "DATA_SEEDS",
    "MODEL_SEEDS",
    "VERSION",
    "adjudicate_screen",
    "prepare_screen",
    "run_screen",
    "teacher_alpha",
    "write_plan",
    "write_result",
]
