from __future__ import annotations

import json
import platform
import statistics
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_allocation_screen_v61 import (
    _core_family_metrics,
    adjudicate_model,
    build_training_plan,
)
from scientist.domains.cognitive_core.training_recipe_context_control_v65c import (
    _metrics_from_predictions,
)
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
    prediction_index,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_v59 import (
    PROTOCOL_ID,
    _deterministic_controller_predictions,
    _evaluation_digest,
    _schedule_digest,
)
from scientist.domains.cognitive_core.training_recipe_mediation_data_v66 import (
    audit_dataset,
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    TARGET_STATE,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    _arrays,
    _optimizer,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    parameter_count,
)
from scientist.domains.cognitive_core.training_recipe_model_v66 import (
    V66MediationTransformer,
)
from scientist.domains.cognitive_core.training_recipe_state_bridge_screen_v62 import (
    ALLOCATION,
    ARITHMETIC_FAMILY,
    _parameter_digest,
    _training_payload_digest,
)
from scientist.domains.cognitive_core.training_recipe_structured_fusion_factorial_v65 import (
    CPU_REFERENCE_COMPARISON_ID,
    STATE_AUDIT_ID,
    STRUCTURED_GATES,
    STRUCTURED_LOSS_WEIGHT,
    _answer_family_accuracy,
    _component_arrays,
    _structured_decision,
    _structured_metrics,
)
from scientist.domains.cognitive_core.training_recipe_structured_state_v65 import (
    COMPONENTS,
    attach_structured_controls,
    audit_structured_controls,
)


VERSION = "cognitive-core-decoded-state-mediation-v66-r1"
SOURCE_CONTROL_ID = (
    "b0913b15875af13409181b07ea88ce0914cff1bd2868350133a3d1171df37046"
)
MODEL_SEEDS = (67101, 67201, 67301)
DATA_SEEDS = (67111, 67211, 67311)
ARMS = {
    "structured_additive": {"answer_mode": "additive"},
    "structured_context_nonlinear": {"answer_mode": "context_nonlinear"},
    "structured_decoded_nonlinear": {"answer_mode": "decoded_nonlinear"},
}
INTERVENTION_MODES = ("decoded_permuted", "decoded_uniform")
MINIMUM_MEAN_UTILITY = 0.03
MAXIMUM_SINGLE_SEED_UTILITY_DECREMENT = 0.02
MEAN_NONINFERIORITY_MARGIN = 0.02
SINGLE_SEED_NONINFERIORITY_MARGIN = 0.05


def _predict(
    model: V66MediationTransformer,
    examples: Sequence[Mapping[str, Any]],
    answer_mode: str,
    batch_size: int = 512,
) -> Tuple[int, ...]:
    predictions = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        batch = examples[start : start + batch_size]
        tokens, _ = _arrays(batch)
        nuisance_codes = _component_arrays(batch, "structured_nuisance")
        values = mx.argmax(
            model(tokens, answer_mode, nuisance_codes), axis=-1
        )
        mx.eval(values)
        predictions.extend(int(value) for value in values.tolist())
    model.train()
    return tuple(predictions)


def _predict_structured(
    model: V66MediationTransformer,
    examples: Sequence[Mapping[str, Any]],
    answer_mode: str,
    batch_size: int = 512,
) -> Mapping[str, Tuple[int, ...]]:
    state_examples = [row for row in examples if row["target"] == "state"]
    predictions = {component: [] for component in COMPONENTS}
    model.eval()
    for start in range(0, len(state_examples), batch_size):
        batch = state_examples[start : start + batch_size]
        tokens, _ = _arrays(batch)
        nuisance_codes = _component_arrays(batch, "structured_nuisance")
        _, logits = model.forward_with_mediation(
            tokens, answer_mode, nuisance_codes
        )
        values = tuple(mx.argmax(row, axis=-1) for row in logits)
        mx.eval(values)
        for component, component_values in zip(COMPONENTS, values):
            predictions[component].extend(
                int(value) for value in component_values.tolist()
            )
    model.train()
    return {component: tuple(values) for component, values in predictions.items()}


def _train_arm(
    arm_name: str,
    schedule: Sequence[Sequence[Mapping[str, Any]]],
    evaluation: Sequence[Mapping[str, Any]],
    evaluation_public: Sequence[Mapping[str, Any]],
    evaluation_authority: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    schedule_digest: str,
    evaluation_digest: str,
):
    answer_mode = str(ARMS[arm_name]["answer_mode"])
    started = time.monotonic()
    mx.random.seed(config.model_seed)
    model = V66MediationTransformer(config)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    parameters = parameter_count(model)
    optimizer = _optimizer(config, config.steps)

    def loss_fn(
        active_model,
        tokens,
        labels,
        nuisance_current,
        nuisance_operator,
        nuisance_operand,
        target_current,
        target_operator,
        target_operand,
    ):
        logits, structured_logits = active_model.forward_with_mediation(
            tokens,
            answer_mode,
            (nuisance_current, nuisance_operator, nuisance_operand),
        )
        main_loss = nn.losses.cross_entropy(logits, labels, reduction="mean")
        mask = (tokens[:, 1] == TARGET_STATE).astype(logits.dtype)
        count = mx.sum(mask)
        auxiliary = []
        for component_logits, targets in zip(
            structured_logits,
            (target_current, target_operator, target_operand),
        ):
            losses = nn.losses.cross_entropy(
                component_logits, targets, reduction="none"
            )
            auxiliary.append(mx.sum(losses * mask) / count)
        return main_loss + STRUCTURED_LOSS_WEIGHT * sum(auxiliary) / 3.0

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    for batch in schedule:
        tokens, labels = _arrays(batch)
        nuisance = _component_arrays(batch, "structured_nuisance")
        semantic_targets = _component_arrays(batch, "structured_semantic")
        loss, gradients = loss_and_grad(
            model, tokens, labels, *nuisance, *semantic_targets
        )
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())

    final_parameter_digest = _parameter_digest(model)
    predictions = _predict(model, evaluation, answer_mode)
    metrics = _metrics_from_predictions(evaluation, predictions)
    structured_predictions = _predict_structured(
        model, evaluation, answer_mode
    )
    structured_metrics = _structured_metrics(evaluation, structured_predictions)
    learned_end_to_end = evaluate_end_to_end(
        evaluation_public,
        evaluation_authority,
        prediction_index(evaluation, predictions),
    )
    intervention_answer_family_accuracy = {}
    intervention_prediction_digests = {}
    if answer_mode == "decoded_nonlinear":
        for intervention in INTERVENTION_MODES:
            intervention_predictions = _predict(
                model, evaluation, intervention
            )
            intervention_answer_family_accuracy[intervention] = (
                _answer_family_accuracy(
                    evaluation, intervention_predictions
                )
            )
            intervention_prediction_digests[intervention] = content_digest(
                {"predictions": list(intervention_predictions)}
            )
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "arm_name": arm_name,
        "factors": ARMS[arm_name],
        "answer_mode": answer_mode,
        "structured_target_kind": "semantic",
        "config": config.as_dict(),
        "initial_parameter_digest": initial_parameter_digest,
        "final_parameter_digest": final_parameter_digest,
        "parameter_count": parameters,
        "training_schedule_digest": schedule_digest,
        "training_payload_digest": _training_payload_digest(schedule),
        "evaluation_digest": evaluation_digest,
        "last_training_loss": last_loss,
        "metrics": metrics,
        "structured_metrics": structured_metrics,
        "structured_decision": _structured_decision(
            structured_metrics, "semantic"
        ),
        "answer_family_accuracy": _answer_family_accuracy(
            evaluation, predictions
        ),
        "intervention_answer_family_accuracy": (
            intervention_answer_family_accuracy
        ),
        "intervention_prediction_digests": intervention_prediction_digests,
        "intervention_specification": {
            "permuted": (
                "deterministic half-batch cyclic shift at evaluation only"
            ),
            "uniform": (
                "valid component-wise uniform simplex at evaluation only"
            ),
            "batch_size": 512,
        },
        "learned_end_to_end": learned_end_to_end,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "compute_device": "cpu",
        "inferential": False,
    }
    result["run_id"] = content_digest(result)
    return result, predictions


def _mean(values: Sequence[float]) -> float:
    return statistics.fmean(values) if values else float("nan")


def _utility_checks(values: Sequence[float]) -> Mapping[str, bool]:
    return {
        "mean_at_least_three_points": len(values) == 3
        and _mean(values) >= MINIMUM_MEAN_UTILITY,
        "no_seed_below_minus_two_points": len(values) == 3
        and min(values) >= -MAXIMUM_SINGLE_SEED_UTILITY_DECREMENT,
    }


def _noninferiority_checks(values: Sequence[float]) -> Mapping[str, bool]:
    return {
        "mean_not_below_minus_two_points": len(values) == 3
        and _mean(values) >= -MEAN_NONINFERIORITY_MARGIN,
        "no_seed_below_minus_five_points": len(values) == 3
        and min(values) >= -SINGLE_SEED_NONINFERIORITY_MARGIN,
    }


def adjudicate_mediation(
    records: Sequence[Mapping[str, Any]], verification_passed: bool
) -> Mapping[str, Any]:
    seed_results = {}
    decoded_vs_context = []
    decoded_vs_additive = []
    live_vs_permuted = []
    live_vs_uniform = []
    core_noninferiority = []
    evidence_noninferiority = []
    for seed in MODEL_SEEDS:
        rows = {
            str(row["arm_name"]): row
            for row in records
            if int(row["model_seed"]) == seed
        }
        if set(rows) != set(ARMS):
            continue
        answer = {
            arm: float(row["answer_family_accuracy"][ARITHMETIC_FAMILY])
            for arm, row in rows.items()
        }
        decoded = rows["structured_decoded_nonlinear"]
        permuted = float(
            decoded["intervention_answer_family_accuracy"]
            ["decoded_permuted"][ARITHMETIC_FAMILY]
        )
        uniform = float(
            decoded["intervention_answer_family_accuracy"]
            ["decoded_uniform"][ARITHMETIC_FAMILY]
        )
        decoded_context_delta = (
            answer["structured_decoded_nonlinear"]
            - answer["structured_context_nonlinear"]
        )
        decoded_additive_delta = (
            answer["structured_decoded_nonlinear"]
            - answer["structured_additive"]
        )
        permuted_delta = answer["structured_decoded_nonlinear"] - permuted
        uniform_delta = answer["structured_decoded_nonlinear"] - uniform
        comparator_core = max(
            float(rows["structured_additive"]["core_family_accuracy"]
                  [ARITHMETIC_FAMILY]),
            float(rows["structured_context_nonlinear"]
                  ["core_family_accuracy"][ARITHMETIC_FAMILY]),
        )
        decoded_core = float(
            decoded["core_family_accuracy"][ARITHMETIC_FAMILY]
        )
        comparator_evidence = max(
            float(rows["structured_additive"]["metrics"]["by_target"]
                  ["evidence_validity"]["accuracy"]),
            float(rows["structured_context_nonlinear"]["metrics"]
                  ["by_target"]["evidence_validity"]["accuracy"]),
        )
        decoded_evidence = float(
            decoded["metrics"]["by_target"]["evidence_validity"]
            ["accuracy"]
        )
        core_delta = decoded_core - comparator_core
        evidence_delta = decoded_evidence - comparator_evidence
        decoded_vs_context.append(decoded_context_delta)
        decoded_vs_additive.append(decoded_additive_delta)
        live_vs_permuted.append(permuted_delta)
        live_vs_uniform.append(uniform_delta)
        core_noninferiority.append(core_delta)
        evidence_noninferiority.append(evidence_delta)
        seed_results[str(seed)] = {
            "arithmetic_answer_accuracy": answer,
            "decoded_permuted_answer_accuracy": permuted,
            "decoded_uniform_answer_accuracy": uniform,
            "decoded_vs_context": decoded_context_delta,
            "decoded_vs_additive": decoded_additive_delta,
            "live_vs_permuted": permuted_delta,
            "live_vs_uniform": uniform_delta,
            "arithmetic_core_delta_vs_best_control": core_delta,
            "evidence_accuracy_delta_vs_best_control": evidence_delta,
            "decoded_main_gate": decoded["development_decision"]["passed"],
            "all_semantic_gates": all(
                row["structured_decision"]["passed"]
                for row in rows.values()
            ),
        }

    common_checks = {
        "execution_verification_passed": verification_passed,
        "three_complete_paired_blocks": len(seed_results) == 3,
        "all_nine_semantic_head_gates_pass": len(records) == 9
        and all(row["structured_decision"]["passed"] for row in records),
    }
    contrast_checks = {
        "decoded_vs_context": _utility_checks(decoded_vs_context),
        "decoded_vs_additive": _utility_checks(decoded_vs_additive),
        "live_vs_permuted": _utility_checks(live_vs_permuted),
        "live_vs_uniform": _utility_checks(live_vs_uniform),
    }
    safety_checks = {
        "arithmetic_core": _noninferiority_checks(core_noninferiority),
        "evidence_validity": _noninferiority_checks(
            evidence_noninferiority
        ),
    }
    all_contrasts_pass = all(
        all(check.values()) for check in contrast_checks.values()
    )
    safety_pass = all(
        all(check.values()) for check in safety_checks.values()
    )
    replicated = (
        all(common_checks.values()) and all_contrasts_pass and safety_pass
    )
    absolute_main_pass = len(seed_results) == 3 and all(
        row["decoded_main_gate"] for row in seed_results.values()
    )
    if replicated and absolute_main_pass:
        next_action = "freeze_v67_cross_family_component_mediation"
    elif replicated:
        next_action = (
            "repair_absolute_core_and_evidence_gates_with_decoded_"
            "mediation_frozen"
        )
    elif common_checks["all_nine_semantic_head_gates_pass"]:
        next_action = (
            "drop_direct_fusion_and_optimize_semantic_auxiliary_"
            "representation_shaping"
        )
    else:
        next_action = "replace_categorical_state_heads_with_token_execution_trace"
    return {
        "seed_results": seed_results,
        "means": {
            "decoded_vs_context": _mean(decoded_vs_context),
            "decoded_vs_additive": _mean(decoded_vs_additive),
            "live_vs_permuted": _mean(live_vs_permuted),
            "live_vs_uniform": _mean(live_vs_uniform),
            "arithmetic_core_delta_vs_best_control": _mean(
                core_noninferiority
            ),
            "evidence_accuracy_delta_vs_best_control": _mean(
                evidence_noninferiority
            ),
        },
        "common_checks": common_checks,
        "contrast_checks": contrast_checks,
        "safety_checks": safety_checks,
        "decoded_mediation_replicated": replicated,
        "decoded_main_gate_passes_three_of_three": absolute_main_pass,
        "next_action": next_action,
        "terminal_evaluation_authorized": False,
        "scaling_authorized": False,
    }


def _verified_digest(payload: Mapping[str, Any], id_field: str) -> bool:
    candidate = dict(payload)
    observed = candidate.pop(id_field)
    return observed == content_digest(candidate)


def prepare_mediation(
    dataset_root: Path,
    capability_profile_path: Path,
    source_control_path: Path,
) -> Mapping[str, Any]:
    source = json.loads(source_control_path.read_text(encoding="utf-8"))
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    train_public, train_authority = load_split(dataset_root, "mediation_train")
    development_public, development_authority = load_split(
        dataset_root, "mediation_development"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    development_materialized = materialize_policy_labels(
        development_public, development_authority, profile
    )
    training = attach_structured_controls(
        training_examples(train_public, train_materialized), train_materialized
    )
    development = attach_structured_controls(
        training_examples(development_public, development_materialized),
        development_materialized,
    )
    manifest = json.loads(
        (dataset_root / "manifest.json").read_text(encoding="utf-8")
    )
    checks = {
        "source_digest_valid": _verified_digest(source, "control_id"),
        "source_control_matches": source["control_id"] == SOURCE_CONTROL_ID,
        "source_execution_verified": source["verification_passed"] is True,
        "source_selected_fresh_mediation": source["next_action"]
        == "freeze_fresh_decoded_state_mediation_replication",
        "source_decoded_screen_passed": source["decision"]
        ["decoded_state_supported"]
        is True,
        "source_representation_screen_passed": source["decision"]
        ["representation_shaping_supported"]
        is True,
        "fresh_manifest_differs_from_source": manifest["manifest_id"]
        != source["dataset_manifest_id"],
        "capability_profile_matches": profile["profile_id"]
        == source["capability_profile_id"],
        "train_raw_audit": audit_dataset(train_public, train_authority)[
            "passed"
        ],
        "development_raw_audit": audit_dataset(
            development_public, development_authority
        )["passed"],
        "train_main_nuisance_audit": audit_nuisance_controls(training)[
            "passed"
        ],
        "development_main_nuisance_audit": audit_nuisance_controls(
            development
        )["passed"],
        "train_structured_control_audit": audit_structured_controls(
            training, train_materialized
        )["passed"],
        "development_structured_control_audit": audit_structured_controls(
            development, development_materialized
        )["passed"],
        "three_matched_answer_routes": set(
            row["answer_mode"] for row in ARMS.values()
        )
        == {"additive", "context_nonlinear", "decoded_nonlinear"},
        "three_independent_seed_blocks": len(MODEL_SEEDS)
        == len(DATA_SEEDS)
        == 3,
        "development_only": True,
    }
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "source_control_id": SOURCE_CONTROL_ID,
        "source_factorial_id": source["source_factorial_id"],
        "state_audit_id": STATE_AUDIT_ID,
        "cpu_reference_comparison_id": CPU_REFERENCE_COMPARISON_ID,
        "dataset_manifest_id": manifest["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "arms": ARMS,
        "intervention_modes": list(INTERVENTION_MODES),
        "allocation": ALLOCATION,
        "model_seeds": list(MODEL_SEEDS),
        "data_seeds": list(DATA_SEEDS),
        "steps": 5200,
        "batch_size": 128,
        "compute_device": "cpu",
        "structured_loss_weight": STRUCTURED_LOSS_WEIGHT,
        "structured_gates": STRUCTURED_GATES["semantic"],
        "thresholds": {
            "minimum_mean_utility": MINIMUM_MEAN_UTILITY,
            "maximum_single_seed_utility_decrement": (
                MAXIMUM_SINGLE_SEED_UTILITY_DECREMENT
            ),
            "mean_noninferiority_margin": MEAN_NONINFERIORITY_MARGIN,
            "single_seed_noninferiority_margin": (
                SINGLE_SEED_NONINFERIORITY_MARGIN
            ),
        },
        "selection_rule": (
            "all_decoded_vs_context,decoded_vs_additive,live_vs_permuted,"
            "live_vs_uniform_means_ge_0.03_with_no_seed_lt_minus_0.02;"
            "core_and_evidence_mean_ge_minus_0.02_with_no_seed_lt_minus_0.05"
        ),
        "checks": checks,
        "passed": all(checks.values()),
        "development_only": True,
        "terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "terminal_evaluation_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def _load_progress(
    progress_path: Path | None, plan_id: str
) -> list[Mapping[str, Any]]:
    if progress_path is None or not progress_path.exists():
        return []
    progress = json.loads(progress_path.read_text(encoding="utf-8"))
    if progress.get("version") != VERSION or progress.get("plan_id") != plan_id:
        raise RuntimeError("V66 progress does not match the frozen plan")
    records = list(progress.get("complete_records", []))
    for record in records:
        candidate = dict(record)
        observed = candidate.pop("record_id")
        if observed != content_digest(candidate):
            raise RuntimeError("V66 progress record digest mismatch")
    return records


def _write_progress(
    progress_path: Path | None,
    plan_id: str,
    records: Sequence[Mapping[str, Any]],
    final_result_sealed: bool = False,
    mediation_id: str | None = None,
) -> None:
    if progress_path is None:
        return
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    progress_path.write_text(
        json.dumps(
            {
                "version": VERSION,
                "plan_id": plan_id,
                "complete_count": len(records),
                "complete_records": records,
                "final_result_sealed": final_result_sealed,
                "mediation_id": mediation_id,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def run_mediation(
    dataset_root: Path,
    capability_profile_path: Path,
    source_control_path: Path,
    plan_path: Path,
    progress_path: Path | None = None,
) -> Mapping[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    source = json.loads(source_control_path.read_text(encoding="utf-8"))
    if not plan["passed"] or plan["compute_device"] != "cpu":
        raise RuntimeError("V66 plan is not authorized")
    if source["control_id"] != plan["source_control_id"]:
        raise RuntimeError("V66 source control mismatch")
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if profile["profile_id"] != plan["capability_profile_id"]:
        raise RuntimeError("V66 capability profile mismatch")
    train_public, train_authority = load_split(dataset_root, "mediation_train")
    development_public, development_authority = load_split(
        dataset_root, "mediation_development"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    training = attach_structured_controls(
        training_examples(train_public, train_materialized), train_materialized
    )
    development_materialized = materialize_policy_labels(
        development_public, development_authority, profile
    )
    development = attach_structured_controls(
        training_examples(development_public, development_materialized),
        development_materialized,
    )
    evaluation_digest = _evaluation_digest(development)
    mx.set_default_device(mx.cpu)
    started = time.monotonic()
    records = _load_progress(progress_path, plan["plan_id"])
    completed = {
        (int(row["model_seed"]), str(row["arm_name"])) for row in records
    }
    for model_seed, data_seed in zip(MODEL_SEEDS, DATA_SEEDS):
        config = SmokeConfig(
            steps=int(plan["steps"]),
            batch_size=int(plan["batch_size"]),
            model_seed=model_seed,
            data_seed=data_seed,
            compute_device="cpu",
        )
        schedule = build_training_plan(training, ALLOCATION, config)
        schedule_digest = _schedule_digest(schedule)
        for arm_name in ARMS:
            key = (model_seed, arm_name)
            if key in completed:
                continue
            trained, predictions = _train_arm(
                arm_name,
                schedule,
                development,
                development_public,
                development_materialized,
                config,
                schedule_digest,
                evaluation_digest,
            )
            deterministic_predictions = _deterministic_controller_predictions(
                development, development_public, predictions
            )
            deterministic_e2e = evaluate_end_to_end(
                development_public,
                development_materialized,
                deterministic_predictions,
            )
            core_family = _core_family_metrics(development, predictions)
            development_decision = adjudicate_model(
                trained["metrics"], core_family, deterministic_e2e
            )
            record: Dict[str, Any] = {
                **trained,
                "model_seed": model_seed,
                "data_seed": data_seed,
                "allocation": ALLOCATION,
                "core_family_accuracy": core_family,
                "deterministic_end_to_end": deterministic_e2e,
                "development_decision": development_decision,
            }
            record["record_id"] = content_digest(record)
            records.append(record)
            completed.add(key)
            _write_progress(progress_path, plan["plan_id"], records)
            print(
                json.dumps(
                    {
                        "event": "v66_arm_complete",
                        "arm_name": arm_name,
                        "model_seed": model_seed,
                        "main_gate_passed": development_decision["passed"],
                        "semantic_gate_passed": trained[
                            "structured_decision"
                        ]["passed"],
                        "elapsed_seconds": record["elapsed_seconds"],
                    },
                    sort_keys=True,
                ),
                flush=True,
            )

    pairing_checks = {}
    for seed in MODEL_SEEDS:
        block = [row for row in records if int(row["model_seed"]) == seed]
        pairing_checks[str(seed)] = {
            "three_arms": len(block) == 3
            and {row["arm_name"] for row in block} == set(ARMS),
            "identical_initialization": len(
                {row["initial_parameter_digest"] for row in block}
            )
            == 1,
            "identical_schedule": len(
                {row["training_schedule_digest"] for row in block}
            )
            == 1,
            "identical_main_payload": len(
                {row["training_payload_digest"] for row in block}
            )
            == 1,
            "identical_evaluation": len(
                {row["evaluation_digest"] for row in block}
            )
            == 1,
            "identical_parameter_count": len(
                {row["parameter_count"] for row in block}
            )
            == 1,
        }
    decoded_records = [
        row
        for row in records
        if row["arm_name"] == "structured_decoded_nonlinear"
    ]
    checks = {
        "nine_models_complete": len(records) == 9,
        "three_complete_blocks": all(
            row["three_arms"] for row in pairing_checks.values()
        ),
        "paired_initialization": all(
            row["identical_initialization"] for row in pairing_checks.values()
        ),
        "paired_schedule": all(
            row["identical_schedule"] for row in pairing_checks.values()
        ),
        "paired_main_payload": all(
            row["identical_main_payload"] for row in pairing_checks.values()
        ),
        "paired_evaluation": all(
            row["identical_evaluation"] for row in pairing_checks.values()
        ),
        "paired_parameter_count": all(
            row["identical_parameter_count"]
            for row in pairing_checks.values()
        ),
        "interventions_complete": len(decoded_records) == 3
        and all(
            set(row["intervention_answer_family_accuracy"])
            == set(INTERVENTION_MODES)
            for row in decoded_records
        ),
        "intervention_prediction_digests_recorded": len(decoded_records) == 3
        and all(
            set(row["intervention_prediction_digests"])
            == set(INTERVENTION_MODES)
            for row in decoded_records
        ),
        "final_parameter_digests_recorded": all(
            bool(row["final_parameter_digest"]) for row in records
        ),
        "cpu_reference_backend_used": all(
            row["compute_device"] == "cpu" for row in records
        ),
    }
    verification_passed = all(checks.values())
    decision = adjudicate_mediation(records, verification_passed)
    result: Dict[str, Any] = {
        "version": VERSION,
        "plan_id": plan["plan_id"],
        "source_control_id": SOURCE_CONTROL_ID,
        "dataset_manifest_id": plan["dataset_manifest_id"],
        "capability_profile_id": plan["capability_profile_id"],
        "state_audit_id": STATE_AUDIT_ID,
        "cpu_reference_comparison_id": CPU_REFERENCE_COMPARISON_ID,
        "records": records,
        "pairing_checks": pairing_checks,
        "checks": checks,
        "verification_passed": verification_passed,
        "decision": decision,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "compute_device": "cpu",
        "development_only": True,
        "terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "terminal_evaluation_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": decision["next_action"],
    }
    result["mediation_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V66 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(path: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(path, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    rows = []
    for seed, values in result["decision"]["seed_results"].items():
        answer = values["arithmetic_answer_accuracy"]
        rows.append(
            "| %s | %.1f%% | %.1f%% | %.1f%% | %+.1f pp | %+.1f pp | %+.1f pp | %+.1f pp |"
            % (
                seed,
                answer["structured_additive"] * 100.0,
                answer["structured_context_nonlinear"] * 100.0,
                answer["structured_decoded_nonlinear"] * 100.0,
                values["decoded_vs_context"] * 100.0,
                values["decoded_vs_additive"] * 100.0,
                values["live_vs_permuted"] * 100.0,
                values["live_vs_uniform"] * 100.0,
            )
        )
    means = result["decision"]["means"]
    report = "\n".join(
        [
            "# Cognitive-core V66 fresh decoded-state mediation",
            "",
            "- Verification passed: **%s**" % result["verification_passed"],
            "- Decoded mediation replicated: **%s**"
            % result["decision"]["decoded_mediation_replicated"],
            "- Mean decoded vs context: **%+.1f percentage points**"
            % (means["decoded_vs_context"] * 100.0),
            "- Mean decoded vs additive: **%+.1f percentage points**"
            % (means["decoded_vs_additive"] * 100.0),
            "- Mean live vs permuted: **%+.1f percentage points**"
            % (means["live_vs_permuted"] * 100.0),
            "- Mean live vs uniform: **%+.1f percentage points**"
            % (means["live_vs_uniform"] * 100.0),
            "- Mediation ID: `%s`" % result["mediation_id"],
            "",
            "| Seed | Additive | Context MLP | Decoded MLP | Decoded-context | Decoded-additive | Live-permuted | Live-uniform |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|",
            *rows,
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        ]
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


def seal_progress(progress_path: Path, result: Mapping[str, Any]) -> None:
    _write_progress(
        progress_path,
        str(result["plan_id"]),
        result["records"],
        final_result_sealed=True,
        mediation_id=str(result["mediation_id"]),
    )


__all__ = [
    "ARMS",
    "DATA_SEEDS",
    "INTERVENTION_MODES",
    "MODEL_SEEDS",
    "SOURCE_CONTROL_ID",
    "VERSION",
    "adjudicate_mediation",
    "prepare_mediation",
    "run_mediation",
    "seal_progress",
    "write_plan",
    "write_result",
]
