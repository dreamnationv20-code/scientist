from __future__ import annotations

import hashlib
import json
import math
import platform
import random
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_data_v57 import (
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_factorial_v56 import (
    FACTORS,
    factorial_arms,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v57 import (
    CAPABILITY_CODE_BASE,
    TOOL_POLICY_LABEL_BASE,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    TARGETS,
    SmokeConfig,
    V56SeparatedHeadTransformer,
    _arrays,
    _balanced_batch,
    _optimizer,
    _parameter_count,
    evaluate,
)


VERSION = "cognitive-core-submillion-factorial-pilot-v57-r1"
PROTOCOL_ID = "00bde408c09dbc480e300e68ed2cedc5bde2b0abcdcdd56fae7f20e242fd353e"
CONTROL_SEED = 571337
TARGET_TO_FACTOR = {
    "state": "explicit_state_supervision",
    "evidence_validity": "evidence_validity_supervision",
    "tool_policy": "adaptive_tool_policy_supervision",
}
FACTOR_SHORT_NAMES = {
    "explicit_state_supervision": "state",
    "evidence_validity_supervision": "validity",
    "adaptive_tool_policy_supervision": "policy",
}
SENTINEL_METRICS = (
    "overall_accuracy",
    "answer_accuracy",
    "state_accuracy",
    "evidence_validity_accuracy",
    "tool_policy_accuracy",
    "worst_family_accuracy",
    "faithful_validity_accuracy",
    "faithful_policy_accuracy",
)


def _permutation(length: int, seed: int) -> Tuple[int, ...]:
    values = list(range(length))
    random.Random(seed).shuffle(values)
    return tuple(values)


def _control_batch(
    batch: Sequence[Mapping[str, Any]],
    factors: Mapping[str, bool],
    step: int,
) -> Tuple[Mapping[str, Any], ...]:
    result = [dict(row) for row in batch]
    for target_index, target in enumerate(TARGETS):
        factor = TARGET_TO_FACTOR.get(target)
        if factor is None or bool(factors[factor]):
            continue
        indices = [index for index, row in enumerate(batch) if row["target"] == target]
        label_permutation = _permutation(
            len(indices),
            CONTROL_SEED + 104729 * step + 1009 * target_index,
        )
        labels = [int(batch[index]["label"]) for index in indices]
        for destination, source_position in zip(indices, label_permutation):
            result[destination]["label"] = labels[source_position]

        if target == "tool_policy":
            token_permutation = _permutation(
                len(indices),
                CONTROL_SEED + 130363 * step + 2017 * target_index,
            )
            capability_tokens = [int(batch[index]["tokens"][-1]) for index in indices]
            for destination, source_position in zip(indices, token_permutation):
                tokens = list(result[destination]["tokens"])
                tokens[-1] = capability_tokens[source_position]
                result[destination]["tokens"] = tuple(tokens)
    return tuple(result)


def _load_examples(
    dataset_root: Path,
    capability_profile_path: Path,
    split: str,
) -> Tuple[Tuple[Mapping[str, Any], ...], str]:
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    public_rows, authority_rows = load_split(dataset_root, split)
    materialized = materialize_policy_labels(public_rows, authority_rows, profile)
    return training_examples(public_rows, materialized), str(profile["profile_id"])


def build_training_plan(
    examples: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
) -> Tuple[Tuple[Mapping[str, Any], ...], ...]:
    by_target = {
        target: tuple(row for row in examples if row["target"] == target)
        for target in TARGETS
    }
    return tuple(
        _balanced_batch(by_target, config, step)
        for step in range(1, config.steps + 1)
    )


def _schedule_digest(
    plan: Sequence[Sequence[Mapping[str, Any]]],
) -> str:
    return content_digest(
        [row["example_id"] for batch in plan for row in batch]
    )


def _evaluation_digest(examples: Sequence[Mapping[str, Any]]) -> str:
    return content_digest(
        [
            {
                "example_id": row["example_id"],
                "tokens": list(row["tokens"]),
                "label": row["label"],
            }
            for row in examples
        ]
    )


def _arm_payload_digest(
    plan: Sequence[Sequence[Mapping[str, Any]]],
    factors: Mapping[str, bool],
) -> str:
    digest = hashlib.sha256()
    for step, batch in enumerate(plan, start=1):
        for row in _control_batch(batch, factors, step):
            digest.update(bytes(int(token) for token in row["tokens"]))
            digest.update(int(row["label"]).to_bytes(2, "big"))
    return digest.hexdigest()


def _parameter_digest(model: V56SeparatedHeadTransformer) -> str:
    digest = hashlib.sha256()
    for name, array in tree_flatten(model.parameters()):
        mx.eval(array)
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(array.shape)).encode("ascii"))
        digest.update(repr(array.tolist()).encode("utf-8"))
    return digest.hexdigest()


def _target_label_histogram(
    rows: Sequence[Mapping[str, Any]], target: str
) -> Mapping[int, int]:
    counts: Dict[int, int] = {}
    for row in rows:
        if row["target"] == target:
            label = int(row["label"])
            counts[label] = counts.get(label, 0) + 1
    return dict(sorted(counts.items()))


def audit_control_construction(
    examples: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    preview_steps: int = 32,
) -> Mapping[str, Any]:
    preview_config = SmokeConfig(
        width=config.width,
        layers=config.layers,
        heads=config.heads,
        steps=min(preview_steps, config.steps),
        batch_size=config.batch_size,
        learning_rate=config.learning_rate,
        final_learning_rate=config.final_learning_rate,
        learning_rate_schedule=config.learning_rate_schedule,
        model_seed=config.model_seed,
        data_seed=config.data_seed,
        checkpoint_interval=config.checkpoint_interval,
        compute_device=config.compute_device,
    )
    plan = build_training_plan(examples, preview_config)
    arms = factorial_arms()
    checks: Dict[str, bool] = {
        "complete_eight_arm_cube": len(arms) == 8,
        "identical_example_schedule": True,
        "target_counts_matched": True,
        "control_label_histograms_matched": True,
        "policy_capability_token_histograms_matched": True,
        "semantic_targets_preserved_when_on": True,
        "every_off_factor_changes_training_payload": True,
        "arm_identity_absent_from_tokens": True,
    }
    changed_counts = {factor: 0 for factor in FACTORS}
    for arm in arms:
        factors = arm["factors"]
        for step, batch in enumerate(plan, start=1):
            controlled = _control_batch(batch, factors, step)
            checks["identical_example_schedule"] &= [
                row["example_id"] for row in batch
            ] == [row["example_id"] for row in controlled]
            checks["target_counts_matched"] &= [row["target"] for row in batch] == [
                row["target"] for row in controlled
            ]
            checks["arm_identity_absent_from_tokens"] &= all(
                len(row["tokens"]) == 32 for row in controlled
            )
            for target, factor in TARGET_TO_FACTOR.items():
                original_histogram = _target_label_histogram(batch, target)
                controlled_histogram = _target_label_histogram(controlled, target)
                checks["control_label_histograms_matched"] &= (
                    original_histogram == controlled_histogram
                )
                paired = [
                    (left, right)
                    for left, right in zip(batch, controlled)
                    if left["target"] == target
                ]
                changed = sum(
                    int(left["label"] != right["label"]) for left, right in paired
                )
                if factors[factor]:
                    checks["semantic_targets_preserved_when_on"] &= changed == 0
                else:
                    changed_counts[factor] += changed
                if target == "tool_policy":
                    before = sorted(int(left["tokens"][-1]) for left, _ in paired)
                    after = sorted(int(right["tokens"][-1]) for _, right in paired)
                    checks["policy_capability_token_histograms_matched"] &= (
                        before == after
                        and all(token >= CAPABILITY_CODE_BASE for token in after)
                    )
    checks["every_off_factor_changes_training_payload"] = all(
        count > 0 for count in changed_counts.values()
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "preview_steps": len(plan),
        "arms": len(arms),
        "changed_label_counts": changed_counts,
        "checks": checks,
        "passed": all(checks.values()),
    }
    result["audit_id"] = content_digest(result)
    return result


def prepare_pilot(
    dataset_root: Path,
    capability_profile_path: Path,
    protocol_path: Path,
    config: SmokeConfig,
) -> Mapping[str, Any]:
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    if protocol["protocol_id"] != PROTOCOL_ID:
        raise RuntimeError("V57 protocol ID mismatch")
    examples, profile_id = _load_examples(
        dataset_root, capability_profile_path, "factorial_pilot_train"
    )
    audit = audit_control_construction(examples, config)
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile_id,
        "config": config.as_dict(),
        "arms": [arm["arm_id"] for arm in factorial_arms()],
        "inferential": False,
        "outcomes_may_select_scientific_conclusions": False,
        "pilot_purpose": [
            "arm_construction",
            "resource_matching",
            "logging",
            "effect_coded_estimator_plumbing",
            "faithful_evidence_sentinel",
        ],
        "control_audit": audit,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def _resource_ledger(
    config: SmokeConfig,
    parameter_count: int,
    evaluation_examples: int,
) -> Mapping[str, Any]:
    ledger = {
        "parameter_count": parameter_count,
        "optimizer_steps": config.steps,
        "batch_size": config.batch_size,
        "training_examples": config.steps * config.batch_size,
        "training_tokens": config.steps * config.batch_size * 32,
        "evaluation_examples": evaluation_examples,
        "evaluation_passes": 1,
    }
    return {**ledger, "match_signature": content_digest(ledger)}


def _flatten_metrics(metrics: Mapping[str, Any]) -> Mapping[str, float]:
    return {
        "overall_accuracy": float(metrics["overall_accuracy"]),
        "answer_accuracy": float(metrics["by_target"]["answer"]["accuracy"]),
        "state_accuracy": float(metrics["by_target"]["state"]["accuracy"]),
        "evidence_validity_accuracy": float(
            metrics["by_target"]["evidence_validity"]["accuracy"]
        ),
        "tool_policy_accuracy": float(
            metrics["by_target"]["tool_policy"]["accuracy"]
        ),
        "worst_family_accuracy": min(
            float(value) for value in metrics["by_family"].values()
        ),
        "faithful_validity_accuracy": float(
            metrics["by_target_variant"]["evidence_validity"][
                "faithful_observation"
            ]
        ),
        "faithful_policy_accuracy": float(
            metrics["by_target_variant"]["tool_policy"]["faithful_observation"]
        ),
    }


def train_arm(
    arm: Mapping[str, Any],
    plan: Sequence[Sequence[Mapping[str, Any]]],
    evaluation: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    schedule_digest: str,
    evaluation_digest: str,
) -> Mapping[str, Any]:
    started = time.monotonic()
    mx.random.seed(config.model_seed)
    model = V56SeparatedHeadTransformer(config)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    parameter_count = _parameter_count(model)
    optimizer = _optimizer(config, config.steps)

    def loss_fn(
        active_model: V56SeparatedHeadTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    for step, batch in enumerate(plan, start=1):
        controlled = _control_batch(batch, arm["factors"], step)
        tokens, labels = _arrays(controlled)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
    metrics = evaluate(model, evaluation)
    ledger = _resource_ledger(config, parameter_count, len(evaluation))
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "arm": arm,
        "config": config.as_dict(),
        "initial_parameter_digest": initial_parameter_digest,
        "parameter_count": parameter_count,
        "training_schedule_digest": schedule_digest,
        "training_payload_digest": _arm_payload_digest(plan, arm["factors"]),
        "evaluation_digest": evaluation_digest,
        "resource_ledger": ledger,
        "last_training_loss": last_loss,
        "metrics": metrics,
        "sentinel_metrics": _flatten_metrics(metrics),
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "inferential": False,
    }
    result["run_id"] = content_digest(result)
    return result


def _term_sign(arm: Mapping[str, Any], term: Sequence[str]) -> int:
    sign = 1
    for factor in term:
        sign *= 1 if arm["factors"][factor] else -1
    return sign


def estimate_effect_coded_coefficients(
    arm_results: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    terms = {
        "state": ("explicit_state_supervision",),
        "validity": ("evidence_validity_supervision",),
        "policy": ("adaptive_tool_policy_supervision",),
        "state_by_validity": (
            "explicit_state_supervision",
            "evidence_validity_supervision",
        ),
        "state_by_policy": (
            "explicit_state_supervision",
            "adaptive_tool_policy_supervision",
        ),
        "validity_by_policy": (
            "evidence_validity_supervision",
            "adaptive_tool_policy_supervision",
        ),
        "state_by_validity_by_policy": tuple(FACTORS),
    }
    coefficients = {}
    for metric in SENTINEL_METRICS:
        coefficients[metric] = {
            term_name: sum(
                float(result["sentinel_metrics"][metric])
                * _term_sign(result["arm"], term)
                for result in arm_results
            )
            / len(arm_results)
            for term_name, term in terms.items()
        }
    return {
        "coding": "minus_one_plus_one",
        "quantity": "orthogonal_regression_coefficient",
        "single_seed": True,
        "inferential": False,
        "confidence_intervals": False,
        "coefficients": coefficients,
    }


def verify_pilot(
    arm_results: Sequence[Mapping[str, Any]],
    plan_record: Mapping[str, Any],
) -> Mapping[str, Any]:
    expected_arms = {arm["arm_id"] for arm in factorial_arms()}
    observed_arms = {result["arm"]["arm_id"] for result in arm_results}
    checks = {
        "preflight_control_audit_passed": plan_record["control_audit"]["passed"],
        "complete_eight_arm_cube": observed_arms == expected_arms,
        "one_result_per_arm": len(arm_results) == len(observed_arms) == 8,
        "paired_initial_parameters": len(
            {result["initial_parameter_digest"] for result in arm_results}
        )
        == 1,
        "identical_parameter_counts": len(
            {result["parameter_count"] for result in arm_results}
        )
        == 1,
        "identical_example_schedules": len(
            {result["training_schedule_digest"] for result in arm_results}
        )
        == 1,
        "identical_evaluation_cases": len(
            {result["evaluation_digest"] for result in arm_results}
        )
        == 1,
        "identical_resource_ledgers": len(
            {result["resource_ledger"]["match_signature"] for result in arm_results}
        )
        == 1,
        "training_controls_are_active": len(
            {result["training_payload_digest"] for result in arm_results}
        )
        > 1,
        "all_results_noninferential": all(
            result["inferential"] is False for result in arm_results
        ),
        "three_billion_not_authorized": True,
    }
    result: Dict[str, Any] = {
        "version": VERSION,
        "checks": checks,
        "passed": all(checks.values()),
        "arm_count": len(arm_results),
        "seed_count": 1,
        "inferential": False,
        "limitations": [
            "One seed cannot estimate sampling uncertainty.",
            "The 239k-parameter pilot validates plumbing, not paper-scale effects.",
            "Sham labels are per-batch permutations and are not a natural baseline.",
            "Wall-clock time is measured but not forced equal.",
        ],
    }
    result["verification_id"] = content_digest(result)
    return result


def run_pilot(
    dataset_root: Path,
    capability_profile_path: Path,
    plan_path: Path,
) -> Mapping[str, Any]:
    plan_record = json.loads(plan_path.read_text(encoding="utf-8"))
    if not plan_record["control_audit"]["passed"]:
        raise RuntimeError("V57 pilot control preflight did not pass")
    config = SmokeConfig(**plan_record["config"])
    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    training, training_profile_id = _load_examples(
        dataset_root, capability_profile_path, "factorial_pilot_train"
    )
    evaluation, evaluation_profile_id = _load_examples(
        dataset_root, capability_profile_path, "factorial_pilot_evaluation"
    )
    if training_profile_id != evaluation_profile_id or training_profile_id != plan_record[
        "capability_profile_id"
    ]:
        raise RuntimeError("V57 pilot capability profile mismatch")
    frozen_plan = build_training_plan(training, config)
    schedule_digest = _schedule_digest(frozen_plan)
    evaluation_digest = _evaluation_digest(evaluation)
    started = time.monotonic()
    arm_results = tuple(
        train_arm(
            arm,
            frozen_plan,
            evaluation,
            config,
            schedule_digest,
            evaluation_digest,
        )
        for arm in factorial_arms()
    )
    verification = verify_pilot(arm_results, plan_record)
    estimators = estimate_effect_coded_coefficients(arm_results)
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "plan_id": plan_record["plan_id"],
        "dataset_manifest_id": plan_record["dataset_manifest_id"],
        "capability_profile_id": training_profile_id,
        "config": config.as_dict(),
        "arms": list(arm_results),
        "verification": verification,
        "estimators": estimators,
        "elapsed_seconds": time.monotonic() - started,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "official_factorial_authorized": verification["passed"],
        "three_billion_training_authorized": False,
        "next_action": (
            "freeze_20m_50m_four_seed_execution_package"
            if verification["passed"]
            else "repair_factorial_pipeline_before_scaling"
        ),
    }
    result["pilot_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V57 pilot artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(output: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(output, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    for arm in result["arms"]:
        _write_immutable(
            output / "arms" / (arm["arm"]["arm_id"] + ".json"),
            json.dumps(arm, indent=2, sort_keys=True) + "\n",
        )
    rows = []
    for arm in result["arms"]:
        metrics = arm["sentinel_metrics"]
        rows.append(
            "| %s | %.1f%% | %.1f%% | %.1f%% | %.1f%% |"
            % (
                arm["arm"]["arm_id"],
                metrics["answer_accuracy"] * 100.0,
                metrics["evidence_validity_accuracy"] * 100.0,
                metrics["tool_policy_accuracy"] * 100.0,
                metrics["faithful_policy_accuracy"] * 100.0,
            )
        )
    report = "\n".join(
        (
            "# Cognitive-core V57 sub-million factorial pipeline pilot",
            "",
            "- Pipeline verification passed: **%s**"
            % result["verification"]["passed"],
            "- Arms: **%d**" % len(result["arms"]),
            "- Seeds: **1**",
            "- Inferential: **False**",
            "- Scientific effect claim authorized: **False**",
            "- Official 20M-50M factorial authorized: **%s**"
            % result["official_factorial_authorized"],
            "- Pilot ID: `%s`" % result["pilot_id"],
            "",
            "| Arm | Answer | Validity | Policy | Faithful-policy sentinel |",
            "|---|---:|---:|---:|---:|",
            *rows,
            "",
            "The cell values and effect-coded coefficients validate estimator "
            "plumbing only. They may not be interpreted as scientific effects.",
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = [
    "PROTOCOL_ID",
    "VERSION",
    "audit_control_construction",
    "estimate_effect_coded_coefficients",
    "prepare_pilot",
    "run_pilot",
    "verify_pilot",
    "write_plan",
    "write_result",
]
