from __future__ import annotations

import hashlib
import json
import platform
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
    prediction_index,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_data_v59 import (
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_factorial_v56 import (
    FACTORS,
    factorial_arms,
)
from scientist.domains.cognitive_core.training_recipe_learnability_v59 import (
    adjudicate_terminal,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    EVIDENCE_VALIDITY_LABEL_BASE,
    EVIDENCE_VALIDITY_LABELS,
    TARGET_ANSWER,
    TOOL_POLICY_LABEL_BASE,
    TOOL_POLICY_LABELS,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v57 import (
    CAPABILITY_CODE_BASE,
    TOOL_ADVANTAGE_MARGIN,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    TARGETS,
    SmokeConfig,
    _arrays,
    _balanced_batch,
    _optimizer,
    _predict,
    evaluate,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    V58RelationalControlTransformer,
    parameter_count,
)


VERSION = "cognitive-core-relational-factorial-pilot-v59-r1"
PROTOCOL_ID = "874252487c861280069f04a1b45e0298f308a80089e7674080eac9cccee7132d"
QUALIFICATION_RUN_ID = (
    "31fb294b72a3effa20647bf90d2ce3341ce3cbfac0c2ef10ad674257f3eca6c9"
)
NUISANCE_ACCURACY_FLOOR = 0.90
TARGET_TO_FACTOR = {
    "state": "explicit_state_supervision",
    "evidence_validity": "evidence_validity_supervision",
    "tool_policy": "adaptive_tool_policy_supervision",
}
SENTINEL_METRICS = (
    "overall_accuracy",
    "answer_accuracy",
    "state_accuracy",
    "evidence_validity_accuracy",
    "tool_policy_accuracy",
    "worst_family_accuracy",
    "faithful_validity_accuracy",
    "faithful_policy_accuracy",
    "clean_tool_value",
    "misleading_tool_harm",
    "invalid_evidence_acceptance_rate",
    "absent_unconditional_correct",
    "faithful_unconditional_correct",
)


def _control_batch(
    batch: Sequence[Mapping[str, Any]],
    factors: Mapping[str, bool],
) -> Tuple[Mapping[str, Any], ...]:
    result = []
    for row in batch:
        target = str(row["target"])
        factor = TARGET_TO_FACTOR.get(target)
        use_semantic = factor is None or bool(factors[factor])
        result.append(
            {
                **row,
                "label": int(
                    row["semantic_label"] if use_semantic else row["nuisance_label"]
                ),
            }
        )
    return tuple(result)


def _load_bundle(
    dataset_root: Path,
    capability_profile_path: Path,
    split: str,
):
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    public_rows, authority_rows = load_split(dataset_root, split)
    materialized = materialize_policy_labels(public_rows, authority_rows, profile)
    examples = training_examples(public_rows, materialized)
    return examples, public_rows, materialized, str(profile["profile_id"])


def build_training_plan(
    examples: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
) -> Tuple[Tuple[Mapping[str, Any], ...], ...]:
    by_target = {
        target: tuple(row for row in examples if row["target"] == target)
        for target in TARGETS
    }
    return tuple(
        _balanced_batch(by_target, config, step)
        for step in range(1, config.steps + 1)
    )


def _schedule_digest(plan: Sequence[Sequence[Mapping[str, Any]]]) -> str:
    return content_digest([row["example_id"] for batch in plan for row in batch])


def _evaluation_digest(examples: Sequence[Mapping[str, Any]]) -> str:
    return content_digest(
        [
            {
                "example_id": row["example_id"],
                "tokens": list(row["tokens"]),
                "semantic_label": row["semantic_label"],
                "nuisance_label": row["nuisance_label"],
            }
            for row in examples
        ]
    )


def _arm_payload_digest(
    plan: Sequence[Sequence[Mapping[str, Any]]],
    factors: Mapping[str, bool],
) -> str:
    digest = hashlib.sha256()
    for batch in plan:
        for row in _control_batch(batch, factors):
            digest.update(bytes(int(token) for token in row["tokens"]))
            digest.update(int(row["label"]).to_bytes(2, "big"))
    return digest.hexdigest()


def _parameter_digest(model: V58RelationalControlTransformer) -> str:
    digest = hashlib.sha256()
    for name, array in tree_flatten(model.parameters()):
        mx.eval(array)
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(array.shape)).encode("ascii"))
        digest.update(repr(array.tolist()).encode("utf-8"))
    return digest.hexdigest()


def audit_control_construction(
    examples: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    preview_steps: int = 32,
) -> Mapping[str, Any]:
    preview_config = SmokeConfig(
        width=config.width,
        layers=config.layers,
        heads=config.heads,
        steps=min(preview_steps, config.steps),
        batch_size=config.batch_size,
        learning_rate=config.learning_rate,
        final_learning_rate=config.final_learning_rate,
        learning_rate_schedule=config.learning_rate_schedule,
        model_seed=config.model_seed,
        data_seed=config.data_seed,
        checkpoint_interval=config.checkpoint_interval,
        compute_device=config.compute_device,
    )
    plan = build_training_plan(examples, preview_config)
    nuisance_audit = audit_nuisance_controls(examples)
    checks: Dict[str, bool] = {
        "complete_eight_arm_cube": len(factorial_arms()) == 8,
        "nuisance_dataset_audit_passed": nuisance_audit["passed"],
        "identical_example_schedule": True,
        "identical_tokens_across_arms": True,
        "semantic_targets_preserved_when_on": True,
        "nuisance_targets_used_when_off": True,
        "every_off_factor_changes_training_payload": True,
        "arm_identity_absent_from_examples": all(
            "arm" not in row and "factors" not in row for row in examples
        ),
    }
    changed_counts = {factor: 0 for factor in FACTORS}
    for arm in factorial_arms():
        factors = arm["factors"]
        for batch in plan:
            controlled = _control_batch(batch, factors)
            checks["identical_example_schedule"] &= [
                row["example_id"] for row in batch
            ] == [row["example_id"] for row in controlled]
            checks["identical_tokens_across_arms"] &= [
                row["tokens"] for row in batch
            ] == [row["tokens"] for row in controlled]
            for original, changed in zip(batch, controlled):
                target = str(original["target"])
                factor = TARGET_TO_FACTOR.get(target)
                if factor is None or bool(factors[factor]):
                    checks["semantic_targets_preserved_when_on"] &= (
                        int(changed["label"]) == int(original["semantic_label"])
                    )
                else:
                    checks["nuisance_targets_used_when_off"] &= (
                        int(changed["label"]) == int(original["nuisance_label"])
                    )
                    changed_counts[factor] += int(
                        int(original["semantic_label"])
                        != int(original["nuisance_label"])
                    )
    checks["every_off_factor_changes_training_payload"] = all(
        count > 0 for count in changed_counts.values()
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "preview_steps": len(plan),
        "arms": len(factorial_arms()),
        "changed_label_counts": changed_counts,
        "nuisance_audit_id": nuisance_audit["audit_id"],
        "checks": checks,
        "passed": all(checks.values()),
    }
    result["audit_id"] = content_digest(result)
    return result


def prepare_pilot(
    dataset_root: Path,
    capability_profile_path: Path,
    protocol_path: Path,
    qualification_result_path: Path,
    config: SmokeConfig,
) -> Mapping[str, Any]:
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    qualification = json.loads(
        qualification_result_path.read_text(encoding="utf-8")
    )
    if protocol["protocol_id"] != PROTOCOL_ID:
        raise RuntimeError("V59 protocol ID mismatch")
    if (
        qualification["run_id"] != QUALIFICATION_RUN_ID
        or qualification["protocol_id"] != PROTOCOL_ID
        or qualification["qualified"] is not True
        or qualification["factorial_pilot_authorized"] is not True
    ):
        raise RuntimeError("V59 qualification authorization mismatch")
    examples, _, _, profile_id = _load_bundle(
        dataset_root, capability_profile_path, "factorial_pilot_train"
    )
    audit = audit_control_construction(examples, config)
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "qualification_run_id": QUALIFICATION_RUN_ID,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile_id,
        "config": config.as_dict(),
        "arms": [arm["arm_id"] for arm in factorial_arms()],
        "comparators": [
            "no_auxiliary_loss_answer_only",
            "deterministic_controller_over_all_on_learned_validity",
        ],
        "quality_gates": {
            "all_on_terminal_qualification": True,
            "minimum_off_factor_nuisance_accuracy": NUISANCE_ACCURACY_FLOOR,
            "all_end_to_end_evaluations_complete": True,
            "comparators_complete": True,
        },
        "inferential": False,
        "outcomes_may_select_scientific_conclusions": False,
        "outcomes_may_authorize_large_compute_without_audit": False,
        "pilot_purpose": [
            "learnable_nuisance_arm_construction",
            "fixed_relational_architecture",
            "resource_matching",
            "end_to_end_controller_evaluation",
            "effect_coded_estimator_plumbing",
            "required_comparator_execution",
        ],
        "control_audit": audit,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def _resource_ledger(
    config: SmokeConfig,
    parameters: int,
    evaluation_examples: int,
) -> Mapping[str, Any]:
    ledger = {
        "parameter_count": parameters,
        "optimizer_steps": config.steps,
        "batch_size": config.batch_size,
        "training_examples": config.steps * config.batch_size,
        "training_tokens": config.steps * config.batch_size * 32,
        "evaluation_examples": evaluation_examples,
        "evaluation_passes": 1,
        "relational_validity_second_pass": True,
    }
    return {**ledger, "match_signature": content_digest(ledger)}


def _control_metrics(
    evaluation: Sequence[Mapping[str, Any]],
    predictions: Sequence[int],
) -> Mapping[str, Any]:
    result = {}
    for target in TARGET_TO_FACTOR:
        pairs = [
            (row, prediction)
            for row, prediction in zip(evaluation, predictions)
            if row["target"] == target
        ]
        result[target] = {
            "semantic_accuracy": sum(
                int(int(prediction) == int(row["semantic_label"]))
                for row, prediction in pairs
            )
            / len(pairs),
            "nuisance_accuracy": sum(
                int(int(prediction) == int(row["nuisance_label"]))
                for row, prediction in pairs
            )
            / len(pairs),
            "count": len(pairs),
        }
    return result


def _flatten_metrics(
    metrics: Mapping[str, Any],
    end_to_end: Mapping[str, Any],
) -> Mapping[str, float]:
    estimands = end_to_end["primary_estimands"]
    regimes = end_to_end["regimes"]
    return {
        "overall_accuracy": float(metrics["overall_accuracy"]),
        "answer_accuracy": float(metrics["by_target"]["answer"]["accuracy"]),
        "state_accuracy": float(metrics["by_target"]["state"]["accuracy"]),
        "evidence_validity_accuracy": float(
            metrics["by_target"]["evidence_validity"]["accuracy"]
        ),
        "tool_policy_accuracy": float(
            metrics["by_target"]["tool_policy"]["accuracy"]
        ),
        "worst_family_accuracy": min(
            float(value) for value in metrics["by_family"].values()
        ),
        "faithful_validity_accuracy": float(
            metrics["by_target_variant"]["evidence_validity"]
            ["faithful_observation"]
        ),
        "faithful_policy_accuracy": float(
            metrics["by_target_variant"]["tool_policy"]["faithful_observation"]
        ),
        "clean_tool_value": float(estimands["clean_tool_value"]),
        "misleading_tool_harm": float(estimands["misleading_tool_harm"]),
        "invalid_evidence_acceptance_rate": float(
            estimands["invalid_evidence_acceptance_rate"]
        ),
        "absent_unconditional_correct": float(
            regimes["absent_observation"]["unconditional_correct"]
        ),
        "faithful_unconditional_correct": float(
            regimes["faithful_observation"]["unconditional_correct"]
        ),
    }


def _train_model(
    arm: Mapping[str, Any] | None,
    plan: Sequence[Sequence[Mapping[str, Any]]],
    evaluation: Sequence[Mapping[str, Any]],
    evaluation_public: Sequence[Mapping[str, Any]],
    evaluation_authority: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    schedule_digest: str,
    evaluation_digest: str,
    *,
    answer_only: bool = False,
):
    started = time.monotonic()
    mx.random.seed(config.model_seed)
    model = V58RelationalControlTransformer(config)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    parameters = parameter_count(model)
    optimizer = _optimizer(config, config.steps)
    factors = (
        arm["factors"]
        if arm is not None
        else {factor: False for factor in FACTORS}
    )

    def loss_fn(active_model, tokens, labels):
        losses = nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="none"
        )
        if not answer_only:
            return mx.mean(losses)
        mask = tokens[:, 1] == TARGET_ANSWER
        weights = mask.astype(losses.dtype)
        return mx.sum(losses * weights) / mx.sum(weights)

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    for batch in plan:
        controlled = batch if answer_only else _control_batch(batch, factors)
        tokens, labels = _arrays(controlled)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
    predictions = _predict(model, evaluation)
    metrics = evaluate(model, evaluation)
    indexed = prediction_index(evaluation, predictions)
    end_to_end = evaluate_end_to_end(
        evaluation_public, evaluation_authority, indexed
    )
    ledger = _resource_ledger(config, parameters, len(evaluation))
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "role": "no_auxiliary_loss_comparator" if answer_only else "factorial_arm",
        "arm": arm,
        "config": config.as_dict(),
        "initial_parameter_digest": initial_parameter_digest,
        "parameter_count": parameters,
        "training_schedule_digest": schedule_digest,
        "training_payload_digest": (
            content_digest({"schedule": schedule_digest, "loss": "answer_only"})
            if answer_only
            else _arm_payload_digest(plan, factors)
        ),
        "evaluation_digest": evaluation_digest,
        "resource_ledger": ledger,
        "last_training_loss": last_loss,
        "metrics": metrics,
        "control_metrics": _control_metrics(evaluation, predictions),
        "end_to_end": end_to_end,
        "sentinel_metrics": _flatten_metrics(metrics, end_to_end),
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "inferential": False,
    }
    result["run_id"] = content_digest(result)
    return result, predictions


def _deterministic_controller_predictions(
    evaluation: Sequence[Mapping[str, Any]],
    public_rows: Sequence[Mapping[str, Any]],
    learned_predictions: Sequence[int],
) -> Mapping[Tuple[str, str], int]:
    indexed = dict(prediction_index(evaluation, learned_predictions))
    public_by_view = {str(row["view_id"]): row for row in public_rows}
    policy_rows = {
        str(row["view_id"]): row
        for row in evaluation
        if row["target"] == "tool_policy"
    }
    accept_label = EVIDENCE_VALIDITY_LABEL_BASE + EVIDENCE_VALIDITY_LABELS["accept"]
    for view_id, policy_row in policy_rows.items():
        public = public_by_view[view_id]
        code = int(policy_row["tokens"][-1]) - CAPABILITY_CODE_BASE
        if not 0 <= code < 20:
            raise RuntimeError("invalid V59 capability code")
        robust_direct = code >= 10
        conservative_upper = (code % 10 + 1) / 10.0
        cost = int(public["declared_tool_cost"])
        budget = int(public["remaining_budget"])
        robust_tool_benefit = (
            bool(public["tool_available"])
            and budget >= cost
            and float(public["tool_reliability"]) - 0.05 * cost
            > conservative_upper + TOOL_ADVANTAGE_MARGIN
        )
        if str(policy_row["variant"]) == "absent_observation":
            action = (
                "call"
                if robust_tool_benefit
                else ("answer" if robust_direct else "abstain")
            )
        else:
            predicted_validity = indexed[(view_id, "evidence_validity")]
            if predicted_validity == accept_label:
                action = "answer"
            elif robust_tool_benefit and budget >= 2 * cost:
                action = "retry"
            elif robust_direct:
                action = "stop"
            else:
                action = "abstain"
        indexed[(view_id, "tool_policy")] = (
            TOOL_POLICY_LABEL_BASE + TOOL_POLICY_LABELS[action]
        )
    return indexed


def _term_sign(arm: Mapping[str, Any], term: Sequence[str]) -> int:
    sign = 1
    for factor in term:
        sign *= 1 if arm["factors"][factor] else -1
    return sign


def estimate_effect_coded_coefficients(
    arm_results: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    terms = {
        "state": ("explicit_state_supervision",),
        "validity": ("evidence_validity_supervision",),
        "policy": ("adaptive_tool_policy_supervision",),
        "state_by_validity": (
            "explicit_state_supervision",
            "evidence_validity_supervision",
        ),
        "state_by_policy": (
            "explicit_state_supervision",
            "adaptive_tool_policy_supervision",
        ),
        "validity_by_policy": (
            "evidence_validity_supervision",
            "adaptive_tool_policy_supervision",
        ),
        "state_by_validity_by_policy": tuple(FACTORS),
    }
    return {
        "coding": "minus_one_plus_one",
        "quantity": "orthogonal_regression_coefficient",
        "single_seed": True,
        "inferential": False,
        "confidence_intervals": False,
        "coefficients": {
            metric: {
                term_name: sum(
                    float(result["sentinel_metrics"][metric])
                    * _term_sign(result["arm"], term)
                    for result in arm_results
                )
                / len(arm_results)
                for term_name, term in terms.items()
            }
            for metric in SENTINEL_METRICS
        },
    }


def verify_pilot(
    arm_results: Sequence[Mapping[str, Any]],
    no_auxiliary: Mapping[str, Any],
    deterministic_controller: Mapping[str, Any],
    plan_record: Mapping[str, Any],
) -> Mapping[str, Any]:
    expected_arms = {arm["arm_id"] for arm in factorial_arms()}
    observed_arms = {result["arm"]["arm_id"] for result in arm_results}
    all_on = next(
        result
        for result in arm_results
        if all(bool(result["arm"]["factors"][factor]) for factor in FACTORS)
    )
    off_nuisance_checks = {}
    for result in arm_results:
        for target, factor in TARGET_TO_FACTOR.items():
            if not bool(result["arm"]["factors"][factor]):
                key = "%s:%s" % (result["arm"]["arm_id"], target)
                off_nuisance_checks[key] = (
                    result["control_metrics"][target]["nuisance_accuracy"]
                    >= NUISANCE_ACCURACY_FLOOR
                )
    all_on_decision = adjudicate_terminal(all_on["metrics"])
    checks = {
        "preflight_control_audit_passed": plan_record["control_audit"]["passed"],
        "complete_eight_arm_cube": observed_arms == expected_arms,
        "one_result_per_arm": len(arm_results) == len(observed_arms) == 8,
        "paired_initial_parameters": len(
            {result["initial_parameter_digest"] for result in arm_results}
        )
        == 1,
        "identical_parameter_counts": len(
            {result["parameter_count"] for result in arm_results}
        )
        == 1,
        "identical_example_schedules": len(
            {result["training_schedule_digest"] for result in arm_results}
        )
        == 1,
        "identical_evaluation_cases": len(
            {result["evaluation_digest"] for result in arm_results}
        )
        == 1,
        "identical_resource_ledgers": len(
            {result["resource_ledger"]["match_signature"] for result in arm_results}
        )
        == 1,
        "training_controls_are_active": len(
            {result["training_payload_digest"] for result in arm_results}
        )
        == 8,
        "all_off_targets_learn_nuisance": all(off_nuisance_checks.values()),
        "all_on_terminal_qualification": all_on_decision["passed"],
        "all_end_to_end_evaluations_complete": all(
            result["end_to_end"]["base_worlds"] > 0 for result in arm_results
        ),
        "no_auxiliary_comparator_complete": (
            no_auxiliary["role"] == "no_auxiliary_loss_comparator"
            and no_auxiliary["end_to_end"]["base_worlds"] > 0
        ),
        "deterministic_controller_complete": (
            deterministic_controller["end_to_end"]["base_worlds"] > 0
        ),
        "all_results_noninferential": all(
            result["inferential"] is False for result in arm_results
        ),
        "large_compute_not_automatically_authorized": True,
        "three_billion_not_authorized": True,
    }
    result: Dict[str, Any] = {
        "version": VERSION,
        "checks": checks,
        "off_nuisance_checks": off_nuisance_checks,
        "all_on_terminal_decision": all_on_decision,
        "passed": all(checks.values()),
        "arm_count": len(arm_results),
        "seed_count": 1,
        "inferential": False,
        "limitations": [
            "One seed cannot estimate sampling uncertainty.",
            "The 239k-parameter pilot validates execution, not paper-scale effects.",
            "Effect-coded coefficients are plumbing diagnostics without intervals.",
            "Wall-clock time is measured but not forced equal.",
        ],
    }
    result["verification_id"] = content_digest(result)
    return result


def run_pilot(
    dataset_root: Path,
    capability_profile_path: Path,
    plan_path: Path,
) -> Mapping[str, Any]:
    plan_record = json.loads(plan_path.read_text(encoding="utf-8"))
    if (
        plan_record["protocol_id"] != PROTOCOL_ID
        or plan_record["qualification_run_id"] != QUALIFICATION_RUN_ID
        or not plan_record["control_audit"]["passed"]
    ):
        raise RuntimeError("V59 pilot preflight authorization mismatch")
    config = SmokeConfig(**plan_record["config"])
    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    training, _, _, training_profile_id = _load_bundle(
        dataset_root, capability_profile_path, "factorial_pilot_train"
    )
    evaluation, evaluation_public, evaluation_authority, evaluation_profile_id = (
        _load_bundle(
            dataset_root, capability_profile_path, "factorial_pilot_evaluation"
        )
    )
    if (
        training_profile_id != evaluation_profile_id
        or training_profile_id != plan_record["capability_profile_id"]
    ):
        raise RuntimeError("V59 pilot capability profile mismatch")
    frozen_plan = build_training_plan(training, config)
    schedule_digest = _schedule_digest(frozen_plan)
    evaluation_digest = _evaluation_digest(evaluation)
    started = time.monotonic()
    arm_results = []
    all_on_predictions = None
    for arm in factorial_arms():
        result, predictions = _train_model(
            arm,
            frozen_plan,
            evaluation,
            evaluation_public,
            evaluation_authority,
            config,
            schedule_digest,
            evaluation_digest,
        )
        arm_results.append(result)
        print(
            json.dumps(
                {
                    "event": "v59_pilot_arm_complete",
                    "arm": arm["arm_id"],
                    "elapsed_seconds": result["elapsed_seconds"],
                },
                sort_keys=True,
            ),
            flush=True,
        )
        if all(bool(arm["factors"][factor]) for factor in FACTORS):
            all_on_predictions = predictions
    no_auxiliary, _ = _train_model(
        None,
        frozen_plan,
        evaluation,
        evaluation_public,
        evaluation_authority,
        config,
        schedule_digest,
        evaluation_digest,
        answer_only=True,
    )
    print(
        json.dumps(
            {
                "event": "v59_pilot_comparator_complete",
                "comparator": "no_auxiliary_loss",
                "elapsed_seconds": no_auxiliary["elapsed_seconds"],
            },
            sort_keys=True,
        ),
        flush=True,
    )
    if all_on_predictions is None:
        raise AssertionError("V59 all-on arm was not executed")
    deterministic_predictions = _deterministic_controller_predictions(
        evaluation, evaluation_public, all_on_predictions
    )
    deterministic_e2e = evaluate_end_to_end(
        evaluation_public,
        evaluation_authority,
        deterministic_predictions,
    )
    deterministic_controller = {
        "version": VERSION,
        "role": "deterministic_controller_over_all_on_learned_validity",
        "source_arm": "s1-e1-p1",
        "policy_inputs": [
            "learned_validity",
            "capability_code",
            "public_cost_budget_availability_reliability",
        ],
        "end_to_end": deterministic_e2e,
        "inferential": False,
    }
    deterministic_controller["comparator_id"] = content_digest(
        deterministic_controller
    )
    verification = verify_pilot(
        arm_results, no_auxiliary, deterministic_controller, plan_record
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "qualification_run_id": QUALIFICATION_RUN_ID,
        "plan_id": plan_record["plan_id"],
        "dataset_manifest_id": plan_record["dataset_manifest_id"],
        "capability_profile_id": training_profile_id,
        "config": config.as_dict(),
        "arms": arm_results,
        "comparators": {
            "no_auxiliary_loss": no_auxiliary,
            "deterministic_controller": deterministic_controller,
        },
        "verification": verification,
        "estimators": estimate_effect_coded_coefficients(arm_results),
        "elapsed_seconds": time.monotonic() - started,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": (
            "independent_audit_v59_pilot_before_scale_decision"
            if verification["passed"]
            else "repair_v59_pilot_before_any_scale_decision"
        ),
    }
    result["pilot_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V59 pilot artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(output: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(output, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    for arm in result["arms"]:
        _write_immutable(
            output / "arms" / (arm["arm"]["arm_id"] + ".json"),
            json.dumps(arm, indent=2, sort_keys=True) + "\n",
        )
    _write_immutable(
        output / "comparators" / "no_auxiliary_loss.json",
        json.dumps(
            result["comparators"]["no_auxiliary_loss"], indent=2, sort_keys=True
        )
        + "\n",
    )
    _write_immutable(
        output / "comparators" / "deterministic_controller.json",
        json.dumps(
            result["comparators"]["deterministic_controller"],
            indent=2,
            sort_keys=True,
        )
        + "\n",
    )
    rows = []
    for arm in result["arms"]:
        metrics = arm["sentinel_metrics"]
        rows.append(
            "| %s | %.1f%% | %.1f%% | %.1f%% | %+.1f pp | %.1f%% |"
            % (
                arm["arm"]["arm_id"],
                metrics["answer_accuracy"] * 100.0,
                metrics["evidence_validity_accuracy"] * 100.0,
                metrics["faithful_policy_accuracy"] * 100.0,
                metrics["clean_tool_value"] * 100.0,
                metrics["invalid_evidence_acceptance_rate"] * 100.0,
            )
        )
    deterministic = result["comparators"]["deterministic_controller"]
    report = "\n".join(
        (
            "# Cognitive-core V59 relational factorial pipeline pilot",
            "",
            "- Pipeline verification passed: **%s**"
            % result["verification"]["passed"],
            "- Factorial arms: **8**",
            "- Required comparators: **2**",
            "- Seeds: **1**",
            "- Inferential: **False**",
            "- Scientific effect claim authorized: **False**",
            "- 20M-50M execution authorized: **False**",
            "- 3B training authorized: **False**",
            "- Pilot ID: `%s`" % result["pilot_id"],
            "",
            "| Arm | Answer | Validity | Faithful policy | Clean-tool value | Invalid accept |",
            "|---|---:|---:|---:|---:|---:|",
            *rows,
            "",
            "Deterministic-controller clean-tool value: **%+.1f pp**"
            % (
                deterministic["end_to_end"]["primary_estimands"]
                ["clean_tool_value"]
                * 100.0
            ),
            "",
            "Cell values and coefficients are engineering diagnostics only and "
            "may not be interpreted as scientific effects.",
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = [
    "PROTOCOL_ID",
    "QUALIFICATION_RUN_ID",
    "VERSION",
    "_control_batch",
    "audit_control_construction",
    "estimate_effect_coded_coefficients",
    "prepare_pilot",
    "run_pilot",
    "verify_pilot",
    "write_plan",
    "write_result",
]
