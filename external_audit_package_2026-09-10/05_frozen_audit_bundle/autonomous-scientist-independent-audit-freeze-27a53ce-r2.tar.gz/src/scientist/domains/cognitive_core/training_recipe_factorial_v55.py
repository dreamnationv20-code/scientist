from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


VERSION = "cognitive-core-causal-training-recipe-v55"
FACTORS = (
    "explicit_state_supervision",
    "counterfactual_verification",
    "adaptive_tool_control",
)
TASK_FAMILIES = (
    "deductive_logic",
    "arithmetic_programs",
    "graph_search",
    "typed_tool_use",
)
SPLITS = (
    "micro_development",
    "micro_replication",
    "proxy_validation",
    "scale_transfer",
    "terminal_system_validation",
)


def _arm_id(values: Sequence[bool]) -> str:
    return "s%d-v%d-r%d" % tuple(int(value) for value in values)


def factorial_arms() -> Tuple[Mapping[str, Any], ...]:
    """Return the complete 2^3 recipe-discovery matrix.

    The short arm identifiers encode state, verification, and routing in that
    order.  The identifiers never enter model-facing examples.
    """

    arms = []
    for values in itertools.product((False, True), repeat=len(FACTORS)):
        factors = dict(zip(FACTORS, values))
        arms.append(
            {
                "arm_id": _arm_id(values),
                "factors": factors,
                "model_facing_arm_label": False,
            }
        )
    return tuple(arms)


def factorial_edges(
    arms: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    """Return every one-factor contrast in the cube exactly once."""

    edges = []
    for left_index, left in enumerate(arms):
        for right in arms[left_index + 1 :]:
            changed = tuple(
                factor
                for factor in FACTORS
                if bool(left["factors"][factor])
                != bool(right["factors"][factor])
            )
            if len(changed) == 1:
                edges.append(
                    {
                        "left": left["arm_id"],
                        "right": right["arm_id"],
                        "factor": changed[0],
                    }
                )
    return tuple(edges)


def build_protocol() -> Mapping[str, Any]:
    arms = factorial_arms()
    protocol: Dict[str, Any] = {
        "version": VERSION,
        "paper": {
            "working_title": (
                "Train the State, Not the Answer: A Causal Recipe for "
                "Tool-Augmented Reasoning in Small Language Models"
            ),
            "primary_question": (
                "Which training signals causally install transferable state "
                "construction, evidence verification, and adaptive tool control "
                "in a small decoder-only language model?"
            ),
            "claim_boundary": (
                "The terminal comparison is system-level 3B-plus-tools versus "
                "70B controls at matched declared cost; it is not a claim of "
                "unassisted or general intrinsic 3B/70B equivalence."
            ),
        },
        "factors": list(FACTORS),
        "factor_definitions": {
            "explicit_state_supervision": {
                "treatment": (
                    "machine-checkable STATE and UPDATE targets before action or answer"
                ),
                "control": (
                    "resource-matched non-semantic auxiliary tokens with no state target"
                ),
            },
            "counterfactual_verification": {
                "treatment": (
                    "matched valid, broken, misleading, stale, and wrong-formalization "
                    "observations with ACCEPT/REJECT/RETRY targets"
                ),
                "control": (
                    "resource-matched valid trajectories and sham perturbations"
                ),
            },
            "adaptive_tool_control": {
                "treatment": (
                    "multi-turn CALL/OBSERVE/VERIFY/UPDATE/STOP trajectories under "
                    "randomized tool costs and availability"
                ),
                "control": (
                    "resource-matched single-pass examples without action selection"
                ),
            },
        },
        "arms": list(arms),
        "one_factor_contrasts": list(factorial_edges(arms)),
        "task_families": list(TASK_FAMILIES),
        "splits": list(SPLITS),
        "model_interface": {
            "protocol_tokens": [
                "STATE",
                "PLAN",
                "CALL",
                "OBSERVE",
                "VERIFY",
                "UPDATE",
                "ANSWER",
                "ABSTAIN",
            ],
            "router_visible_fields": [
                "problem",
                "tool_schema",
                "current_state",
                "prior_actions",
                "raw_observations",
                "remaining_budget",
            ],
            "authority_only_fields": [
                "correct_answer",
                "gold_state",
                "valid_actions",
                "observation_validity",
                "optimal_action",
                "arm_assignment",
            ],
            "prohibited_router_fields": [
                "correct_answer",
                "gold_state",
                "valid_actions",
                "observation_validity",
                "optimal_action",
                "repairability_label",
                "arm_assignment",
            ],
        },
        "corruption_contract": {
            "classes": [
                "surface_matched_broken_state",
                "misleading_final_step",
                "wrong_tool_arguments",
                "incorrect_tool_response",
                "stale_observation",
                "contradictory_observation",
                "valid_certificate_for_wrong_formalization",
            ],
            "matching_fields": [
                "line_count",
                "record_types",
                "entity_occurrences",
                "predicate_presence",
                "tool_signature",
                "declared_cost",
            ],
            "maximum_token_count_delta": 2,
            "semantic_authority_independent_of_surface_generator": True,
        },
        "training_ladder": [
            {
                "stage": "micro_factorial",
                "parameter_range": "20M-50M",
                "location": "local",
                "arms": [arm["arm_id"] for arm in arms],
                "minimum_seeds": 4,
                "purpose": "estimate all main effects and interactions",
                "promotion": (
                    "promote the full recipe, answer-only baseline, and the two "
                    "ablations with the largest preregistered harmful deltas"
                ),
            },
            {
                "stage": "proxy_replication",
                "parameter_range": "100M-150M",
                "location": "local",
                "maximum_arms": 4,
                "minimum_seeds": 3,
                "purpose": "replicate effect directions on unseen generators",
            },
            {
                "stage": "local_confirmation",
                "parameter_range": "300M",
                "location": "local_or_single_remote_gpu",
                "maximum_arms": 3,
                "minimum_seeds": 2,
                "purpose": "confirm the full recipe and decisive ablations",
            },
            {
                "stage": "scale_bridge",
                "parameter_range": "1B",
                "location": "remote_multi_gpu",
                "maximum_arms": 2,
                "minimum_seeds": 1,
                "purpose": "test scale transport before authorizing 3B",
            },
            {
                "stage": "terminal_training",
                "parameter_range": "3B",
                "location": "remote_multi_gpu",
                "maximum_arms": 2,
                "minimum_seeds": 1,
                "purpose": "confirm the selected recipe and one decisive ablation",
            },
        ],
        "evaluation": {
            "primary_metrics": [
                "validity_component",
                "misleading_observation_follow_rate",
                "state_depth_generalization",
                "valid_tool_action_rate",
                "tool_feedback_use_effect",
                "selective_accuracy",
                "accuracy_cost_frontier",
            ],
            "qualification_metrics": [
                "response_parse_rate",
                "action_schema_validity",
                "per_class_recall",
            ],
            "comparators": [
                "same_size_answer_only",
                "same_size_long_cot_distillation",
                "3B_unassisted",
                "70B_unassisted",
                "70B_same_tools",
                "oracle_router",
            ],
            "reporting_rule": (
                "Report unassisted capability, tool-augmented system capability, "
                "same-tool controller quality, and cost separately."
            ),
        },
        "promotion_gates": {
            "micro_to_proxy": [
                "full_recipe_beats_answer_only_on_cognitive_geometric_mean",
                "verification_reduces_misleading_following",
                "state_supervision_improves_unseen_depth",
                "tool_control_improves_valid_sequential_actions",
            ],
            "proxy_to_300m": [
                "all_primary_effect_directions_replicate",
                "no_task_family_regresses_beyond_frozen_margin",
                "unseen_generator_transfer_is_positive",
            ],
            "300m_to_1b": [
                "full_recipe_beats_each_decisive_ablation",
                "answer_channel_does_not_explain_state_channel_gain",
            ],
            "1b_to_3b": [
                "effect_directions_survive_scale",
                "3B_compute_budget_and_terminal_comparators_are_frozen",
            ],
        },
        "failure_branches": {
            "micro_no_effect": (
                "repair task learnability or supervision delivery; do not scale"
            ),
            "verification_no_effect": (
                "test whether the validity target is learned before changing the model"
            ),
            "state_increases_gullibility": (
                "retain the result and require verification-by-state interaction"
            ),
            "proxy_reversal": (
                "treat scale as a moderator and fit a scaling interaction"
            ),
            "tool_transfer_failure": (
                "separate schema parsing from policy transfer and narrow the claim"
            ),
            "one_billion_failure": (
                "stop the 3B launch and revise the recipe"
            ),
            "three_billion_below_70b": (
                "report the accuracy-cost frontier without claiming parity"
            ),
        },
        "firewalls": {
            "terminal_split_single_use": True,
            "no_terminal_feedback_into_training": True,
            "arm_selection_uses_proxy_validation_only": True,
            "all_outcome_authorities_sealed_before_scoring": True,
            "teacher_may_surface_realize_but_never_authorize_correctness": True,
        },
    }
    protocol["protocol_id"] = content_digest(protocol)
    return protocol


def audit_protocol(protocol: Mapping[str, Any]) -> Mapping[str, Any]:
    checks: Dict[str, bool] = {}
    checks["version"] = protocol.get("version") == VERSION
    checks["factor_order"] = tuple(protocol.get("factors", ())) == FACTORS

    arms = tuple(protocol.get("arms", ()))
    expected_vectors = set(itertools.product((False, True), repeat=3))
    observed_vectors = {
        tuple(bool(arm.get("factors", {}).get(factor)) for factor in FACTORS)
        for arm in arms
    }
    checks["complete_factorial"] = (
        len(arms) == 8 and observed_vectors == expected_vectors
    )
    checks["unique_arm_ids"] = len({arm.get("arm_id") for arm in arms}) == 8
    checks["arm_labels_hidden"] = all(
        arm.get("model_facing_arm_label") is False for arm in arms
    )

    edges = tuple(protocol.get("one_factor_contrasts", ()))
    edge_keys = {
        tuple(sorted((edge.get("left"), edge.get("right"))))
        for edge in edges
    }
    checks["complete_cube_edges"] = len(edges) == 12 and len(edge_keys) == 12
    checks["edge_factor_valid"] = all(
        edge.get("factor") in FACTORS for edge in edges
    )

    interface = protocol.get("model_interface", {})
    visible = set(interface.get("router_visible_fields", ()))
    prohibited = set(interface.get("prohibited_router_fields", ()))
    checks["answer_blind_router"] = not visible.intersection(prohibited)
    checks["authority_separation"] = prohibited.issubset(
        set(interface.get("authority_only_fields", ()))
        | {"repairability_label"}
    )

    corruption = protocol.get("corruption_contract", {})
    checks["wrong_formalization_included"] = (
        "valid_certificate_for_wrong_formalization"
        in corruption.get("classes", ())
    )
    checks["surface_matching_declared"] = len(
        corruption.get("matching_fields", ())
    ) >= 5
    checks["independent_semantic_authority"] = (
        corruption.get("semantic_authority_independent_of_surface_generator")
        is True
    )

    ladder = tuple(protocol.get("training_ladder", ()))
    stages = tuple(stage.get("stage") for stage in ladder)
    checks["scale_ladder"] = stages == (
        "micro_factorial",
        "proxy_replication",
        "local_confirmation",
        "scale_bridge",
        "terminal_training",
    )
    checks["local_full_factorial_only_at_micro"] = (
        bool(ladder)
        and len(ladder[0].get("arms", ())) == 8
        and all(stage.get("maximum_arms", 8) < 8 for stage in ladder[1:])
    )
    checks["one_billion_gate_precedes_three_billion"] = (
        stages.index("scale_bridge") < stages.index("terminal_training")
        if set(stages) >= {"scale_bridge", "terminal_training"}
        else False
    )

    firewalls = protocol.get("firewalls", {})
    checks["terminal_firewall"] = all(
        firewalls.get(key) is True
        for key in (
            "terminal_split_single_use",
            "no_terminal_feedback_into_training",
            "arm_selection_uses_proxy_validation_only",
            "all_outcome_authorities_sealed_before_scoring",
            "teacher_may_surface_realize_but_never_authorize_correctness",
        )
    )

    supplied_id = protocol.get("protocol_id")
    unsigned = dict(protocol)
    unsigned.pop("protocol_id", None)
    checks["protocol_digest"] = supplied_id == content_digest(unsigned)
    return {
        "version": VERSION,
        "passed": all(checks.values()),
        "checks": checks,
        "audit_id": content_digest(
            {"version": VERSION, "protocol_id": supplied_id, "checks": checks}
        ),
    }


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable M55 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def freeze_protocol(output: Path) -> Mapping[str, Any]:
    protocol = build_protocol()
    audit = audit_protocol(protocol)
    if not audit["passed"]:
        raise RuntimeError("M55 protocol failed its structural audit")
    protocol_text = json.dumps(protocol, indent=2, sort_keys=True) + "\n"
    audit_text = json.dumps(audit, indent=2, sort_keys=True) + "\n"
    _write_immutable(output / "protocol.json", protocol_text)
    _write_immutable(output / "audit.json", audit_text)
    checks = audit["checks"]
    report = "\n".join(
        (
            "# Cognitive-core M55 training-recipe preflight",
            "",
            "- Structural audit passed: **%s**" % audit["passed"],
            "- Protocol ID: `%s`" % protocol["protocol_id"],
            "- Audit ID: `%s`" % audit["audit_id"],
            "- Factorial arms: **%d**" % len(protocol["arms"]),
            "- One-factor contrasts: **%d**"
            % len(protocol["one_factor_contrasts"]),
            "",
            "## Decision",
            "",
            "The protocol is structurally qualified to begin the micro-scale data "
            "and training implementation. No model-effect claim has been tested.",
            "",
            "## Checks",
            "",
            *(
                "- %s: **%s**" % (key, value)
                for key, value in sorted(checks.items())
            ),
            "",
            "## Next executable gate",
            "",
            "Construct a sealed micro-world dataset in all four task families, "
            "verify matched corruptions and answer-blind router views, then run a "
            "short learnability smoke test before the 2^3 factorial.",
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)
    return {"protocol": protocol, "audit": audit}

