from __future__ import annotations

import itertools
import json
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


VERSION = "cognitive-core-calibrated-tool-trust-v56"
FACTORS = (
    "explicit_state_supervision",
    "evidence_validity_supervision",
    "adaptive_tool_policy_supervision",
)
TASK_FAMILIES = (
    "deductive_logic",
    "arithmetic_programs",
    "graph_search",
    "typed_tool_use",
)


def _arm_id(values: Sequence[bool]) -> str:
    return "s%d-e%d-p%d" % tuple(int(value) for value in values)


def factorial_arms() -> Tuple[Mapping[str, Any], ...]:
    arms = []
    for values in itertools.product((False, True), repeat=len(FACTORS)):
        arms.append(
            {
                "arm_id": _arm_id(values),
                "factors": dict(zip(FACTORS, values)),
                "model_facing_arm_label": False,
            }
        )
    return tuple(arms)


def factorial_edges(
    arms: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    edges = []
    for left_index, left in enumerate(arms):
        for right in arms[left_index + 1 :]:
            changed = tuple(
                factor
                for factor in FACTORS
                if bool(left["factors"][factor])
                != bool(right["factors"][factor])
            )
            if len(changed) == 1:
                edges.append(
                    {
                        "left": left["arm_id"],
                        "right": right["arm_id"],
                        "factor": changed[0],
                    }
                )
    return tuple(edges)


def build_protocol() -> Mapping[str, Any]:
    arms = factorial_arms()
    protocol: Dict[str, Any] = {
        "version": VERSION,
        "supersession": {
            "predecessor": "cognitive-core-causal-training-recipe-v55",
            "predecessor_protocol_id": (
                "c6d6e379681daafd65b3f6cd6ba52a16414bfeda1690e2ce836d395e04eca2c5"
            ),
            "reason": "claim-specific literature closure dated 2026-09-06",
            "historical_artifacts_immutable": True,
            "r8_architecture_evidence_only": True,
        },
        "literature_closure": {
            "date": "2026-09-06",
            "audit": "docs/cognitive-core/m55-literature-novelty-audit-2026-09.md",
            "novelty_object": (
                "randomized learned-supervision factorial for calibrated tool trust"
            ),
            "excluded_first_claims": [
                "general_tool_use_recipe",
                "small_model_beats_large_model_with_tools",
                "explicit_verified_agent_state",
                "noisy_tool_benchmark",
                "factorial_agent_component_analysis",
                "small_agentic_model_pretrained_from_scratch",
            ],
        },
        "paper": {
            "working_title": (
                "What Teaches a Small Model to Trust Tools? A Randomized "
                "Factorial Study of State, Evidence Validity, and Control"
            ),
            "primary_question": (
                "Which learned supervision channels cause a small decoder-only "
                "model to use external computation as calibrated evidence, and "
                "how do their effects interact across task family and scale?"
            ),
            "contribution_type": "randomized_training_factorial",
            "paper_2_terminal_scope": "causal_components_through_optional_1b_bridge",
            "three_billion_training_authorized": False,
            "separate_paper_3": (
                "3B scale transport and system-level 70B comparisons under "
                "no-tool, equal-tool, and equal-total-cost conditions"
            ),
        },
        "factors": list(FACTORS),
        "factor_definitions": {
            "explicit_state_supervision": {
                "treatment": (
                    "machine-checkable STATE and UPDATE targets before action or answer"
                ),
                "control": (
                    "non-semantic auxiliary targets matched for count, tokens, and loss weight"
                ),
            },
            "evidence_validity_supervision": {
                "treatment": (
                    "ACCEPT, REJECT, and RETRY targets over matched faithful and "
                    "invalid observations"
                ),
                "control": (
                    "the same observation exposures and loss budget without "
                    "validity-directed targets"
                ),
            },
            "adaptive_tool_policy_supervision": {
                "treatment": (
                    "CALL, RETRY, STOP, ANSWER, and ABSTAIN decisions under "
                    "randomized tool cost and availability"
                ),
                "control": (
                    "token- and step-matched trajectories without policy-decision supervision"
                ),
            },
        },
        "arms": list(arms),
        "one_factor_contrasts": list(factorial_edges(arms)),
        "fixed_delivery_architecture": {
            "shared_encoder": True,
            "target_local_output_heads": True,
            "global_cross_target_softmax_prohibited": True,
            "fixed_across_arms": [
                "head_structure",
                "parameter_count",
                "optimizer",
                "training_tokens",
                "optimizer_updates",
                "target_opportunities",
                "selection_budget",
            ],
            "historical_evidence_run": (
                "runs/cognitive_core/training_recipe_mlx_separated_heads_v55_r8"
            ),
            "historical_evidence_run_id": (
                "6f2264686ced294f2022950be800389a43beb04f41fbd29c2b7493ae5981c9e9"
            ),
            "architecture_is_not_a_factor": True,
        },
        "model_interface": {
            "protocol_tokens": [
                "STATE",
                "PLAN",
                "CALL",
                "OBSERVE",
                "VERIFY",
                "UPDATE",
                "ANSWER",
                "ABSTAIN",
            ],
            "policy_visible_fields": [
                "problem",
                "tool_schema",
                "declared_tool_cost",
                "current_state",
                "prior_actions",
                "raw_observations",
                "remaining_budget",
            ],
            "authority_only_fields": [
                "correct_answer",
                "gold_state",
                "valid_actions",
                "observation_validity",
                "semantic_faithfulness",
                "optimal_action",
                "model_adaptive_tool_necessity",
                "arm_assignment",
            ],
            "prohibited_policy_fields": [
                "correct_answer",
                "gold_state",
                "valid_actions",
                "observation_validity",
                "semantic_faithfulness",
                "optimal_action",
                "model_adaptive_tool_necessity",
                "repairability_label",
                "arm_assignment",
            ],
        },
        "task_families": list(TASK_FAMILIES),
        "generator_firewall": {
            "procedural_executable_authorities": True,
            "llm_may_surface_realize_but_not_authorize": True,
            "disjoint_partitions": [
                "learnability_development",
                "learnability_replication",
                "factorial_discovery",
                "factorial_replication",
                "scale_transfer",
                "external_system_evaluation",
            ],
        },
        "evidence_regimes": {
            "required_matched_triad": [
                "faithful_observation",
                "misleading_observation",
                "absent_observation",
            ],
            "triad_fixed_fields": [
                "agent_loop",
                "prompt_outside_observation",
                "action_history",
                "decoding_configuration",
                "budget",
            ],
            "only_varied_field": "returned_observation",
            "additional_invalidity_classes": [
                "surface_matched_broken_state",
                "misleading_final_step",
                "wrong_tool_arguments",
                "incorrect_tool_response",
                "stale_observation",
                "contradictory_observation",
                "valid_certificate_for_wrong_formalization",
            ],
            "surface_matching_fields": [
                "line_count",
                "record_types",
                "entity_occurrences",
                "predicate_presence",
                "tool_signature",
                "declared_cost",
            ],
            "maximum_token_count_delta": 2,
        },
        "correctness_layers": [
            "tool_syntax_and_execution",
            "formal_validity_given_supplied_formalization",
            "semantic_faithfulness_to_original_problem",
            "epistemic_admissibility_for_state_update",
        ],
        "model_adaptive_tool_necessity": {
            "enabled": True,
            "closed_book_capability_split_disjoint": True,
            "capability_estimate_frozen_before_treatment_scoring": True,
            "randomized_fields": ["tool_cost", "tool_availability"],
            "expected_value_inputs": [
                "closed_book_success_probability",
                "tool_reliability",
                "declared_cost",
                "remaining_budget",
            ],
            "labels_authority_only": True,
        },
        "causal_estimands": [
            "clean_tool_value_faithful_minus_absent",
            "misleading_tool_harm_misleading_minus_absent",
            "value_inversion_clean_positive_and_misleading_negative",
            "observation_acceptance_rejection_calibration",
            "valid_state_update_rate",
            "unseen_state_depth_generalization",
            "legal_and_semantically_correct_tool_action_rate",
            "clean_no_tool_competence_retention",
            "selective_accuracy_and_abstention",
            "accuracy_tool_token_wallclock_and_combined_cost_frontiers",
        ],
        "factorial_analysis": {
            "effect_coding": [-1, 1],
            "terms": [
                "state",
                "validity",
                "policy",
                "state_by_validity",
                "state_by_policy",
                "validity_by_policy",
                "state_by_validity_by_policy",
            ],
            "moderators": ["seed", "task_family", "generator", "model_scale"],
            "report_all_terms_not_only_winning_arm": True,
            "smallest_effects_of_interest_frozen_before_scoring": True,
            "multiplicity_correction_required": True,
        },
        "mandatory_comparators": [
            "same_size_answer_only",
            "same_size_long_cot_distillation",
            "standard_supervised_finetuning",
            "outcome_only_rl_if_rl_is_used",
            "rationale_aware_robustness_objective",
            "runtime_contract_verifier_without_learned_validity",
            "inference_skepticism_or_single_requery",
            "matched_no_feedback_fallback",
            "no_tool_fallback",
            "schema_aligned_unseen_tool_control",
            "oracle_router",
        ],
        "prospective_learnability_gate": {
            "fresh_sealed_authority_split_required": True,
            "historical_r8_does_not_pass_v56_gate": True,
            "minimum_answer_accuracy": 0.70,
            "minimum_answer_class_recall": 0.20,
            "minimum_state_accuracy": 0.75,
            "minimum_state_class_recall": 0.20,
            "minimum_evidence_validity_accuracy": 0.80,
            "minimum_evidence_validity_class_recall": 0.65,
            "minimum_tool_policy_accuracy": 0.80,
            "minimum_tool_policy_class_recall": 0.65,
            "minimum_worst_family_accuracy": 0.60,
            "minimum_parse_rate": 0.99,
            "minimum_action_schema_validity": 0.99,
        },
        "training_ladder": [
            {
                "stage": "micro_factorial",
                "parameter_range": "20M-50M",
                "arms": [arm["arm_id"] for arm in arms],
                "minimum_seeds": 4,
            },
            {
                "stage": "proxy_replication",
                "parameter_range": "100M-150M",
                "maximum_arms": 4,
                "minimum_seeds": 3,
            },
            {
                "stage": "local_confirmation",
                "parameter_range": "300M",
                "maximum_arms": 3,
                "minimum_seeds": 2,
            },
            {
                "stage": "optional_scale_bridge",
                "parameter_range": "1B",
                "maximum_arms": 2,
                "minimum_seeds": 2,
            },
        ],
        "promotion_rules": {
            "micro_to_proxy": [
                "all_target_delivery_qualification_gates_pass",
                "all_factorial_terms_are_identifiable",
                "at_least_one_preregistered_effect_or_interaction_exceeds_its_seseoi",
                "arm_selection_is_based_on_causal_informativeness_not_only_accuracy",
            ],
            "proxy_to_300m": [
                "selected_effect_directions_replicate_or_scale_reversal_is_preregistered",
                "no_unreported_task_family_regression",
                "heldout_generator_transfer_is_measured",
            ],
            "paper_2_to_future_3b": [
                "causal_result_replicates_beyond_micro_scale",
                "one_billion_bridge_passes_if_run",
                "new_3b_protocol_and_compute_budget_are_frozen_separately",
            ],
        },
        "failure_branches": {
            "all_effects_below_seseoi": (
                "report the replicated local null and do not scale"
            ),
            "state_increases_misleading_following": (
                "retain the result and test the state-by-validity interaction"
            ),
            "policy_improves_clean_cost_but_amplifies_corruption": (
                "treat validity and policy as a required joint intervention"
            ),
            "proxy_direction_reversal": (
                "treat scale as a moderator rather than choosing a preferred scale"
            ),
            "unseen_tool_transfer_failure": (
                "separate schema parsing from sequential policy transfer"
            ),
            "runtime_contract_dominates_learned_validity": (
                "report the boundary and test the combined system"
            ),
            "one_billion_bridge_failure": (
                "do not authorize a later 3B study"
            ),
        },
        "firewalls": {
            "terminal_split_single_use": True,
            "no_terminal_feedback_into_training": True,
            "arm_selection_uses_nonterminal_data_only": True,
            "all_authorities_sealed_before_scoring": True,
            "teacher_never_authorizes_correctness": True,
            "null_harmful_and_scale_reversing_results_are_reportable": True,
        },
    }
    protocol["protocol_id"] = content_digest(protocol)
    return protocol


def audit_protocol(protocol: Mapping[str, Any]) -> Mapping[str, Any]:
    checks: Dict[str, bool] = {}
    checks["version"] = protocol.get("version") == VERSION
    checks["factor_order"] = tuple(protocol.get("factors", ())) == FACTORS

    arms = tuple(protocol.get("arms", ()))
    expected_vectors = set(itertools.product((False, True), repeat=3))
    observed_vectors = {
        tuple(bool(arm.get("factors", {}).get(factor)) for factor in FACTORS)
        for arm in arms
    }
    checks["complete_factorial"] = (
        len(arms) == 8 and observed_vectors == expected_vectors
    )
    checks["unique_hidden_arm_ids"] = (
        len({arm.get("arm_id") for arm in arms}) == 8
        and all(arm.get("model_facing_arm_label") is False for arm in arms)
    )

    edges = tuple(protocol.get("one_factor_contrasts", ()))
    edge_keys = {
        tuple(sorted((edge.get("left"), edge.get("right")))) for edge in edges
    }
    checks["complete_cube_edges"] = (
        len(edges) == 12
        and len(edge_keys) == 12
        and all(edge.get("factor") in FACTORS for edge in edges)
    )

    interface = protocol.get("model_interface", {})
    visible = set(interface.get("policy_visible_fields", ()))
    prohibited = set(interface.get("prohibited_policy_fields", ()))
    checks["answer_blind_policy"] = not visible.intersection(prohibited)
    checks["model_adaptive_labels_hidden"] = (
        "model_adaptive_tool_necessity" in prohibited
        and protocol.get("model_adaptive_tool_necessity", {}).get(
            "labels_authority_only"
        )
        is True
    )

    architecture = protocol.get("fixed_delivery_architecture", {})
    checks["target_local_architecture_fixed"] = all(
        architecture.get(key) is True
        for key in (
            "shared_encoder",
            "target_local_output_heads",
            "global_cross_target_softmax_prohibited",
            "architecture_is_not_a_factor",
        )
    )

    regimes = protocol.get("evidence_regimes", {})
    checks["matched_feedback_triad"] = set(
        regimes.get("required_matched_triad", ())
    ) == {
        "faithful_observation",
        "misleading_observation",
        "absent_observation",
    }
    checks["wrong_formalization_included"] = (
        "valid_certificate_for_wrong_formalization"
        in regimes.get("additional_invalidity_classes", ())
    )
    checks["four_correctness_layers"] = len(
        protocol.get("correctness_layers", ())
    ) == 4

    analysis = protocol.get("factorial_analysis", {})
    checks["saturated_factorial_analysis"] = (
        len(analysis.get("terms", ())) == 7
        and analysis.get("report_all_terms_not_only_winning_arm") is True
        and analysis.get("smallest_effects_of_interest_frozen_before_scoring")
        is True
    )

    comparators = set(protocol.get("mandatory_comparators", ()))
    checks["mandatory_prior_art_comparators"] = {
        "rationale_aware_robustness_objective",
        "runtime_contract_verifier_without_learned_validity",
        "matched_no_feedback_fallback",
        "schema_aligned_unseen_tool_control",
    }.issubset(comparators)

    gate = protocol.get("prospective_learnability_gate", {})
    checks["fresh_stricter_recall_gate"] = (
        gate.get("fresh_sealed_authority_split_required") is True
        and gate.get("historical_r8_does_not_pass_v56_gate") is True
        and float(gate.get("minimum_answer_class_recall", 0.0)) >= 0.20
        and float(gate.get("minimum_state_class_recall", 0.0)) >= 0.20
    )

    ladder = tuple(protocol.get("training_ladder", ()))
    checks["paper_2_scale_boundary"] = (
        tuple(stage.get("stage") for stage in ladder)
        == (
            "micro_factorial",
            "proxy_replication",
            "local_confirmation",
            "optional_scale_bridge",
        )
        and protocol.get("paper", {}).get("three_billion_training_authorized")
        is False
    )

    supersession = protocol.get("supersession", {})
    checks["historical_integrity"] = (
        supersession.get("historical_artifacts_immutable") is True
        and supersession.get("r8_architecture_evidence_only") is True
    )

    closure = protocol.get("literature_closure", {})
    checks["literature_closure_recorded"] = (
        closure.get("date") == "2026-09-06"
        and bool(closure.get("audit"))
        and len(closure.get("excluded_first_claims", ())) >= 6
    )

    firewalls = protocol.get("firewalls", {})
    checks["scientific_firewalls"] = all(
        firewalls.get(key) is True
        for key in (
            "terminal_split_single_use",
            "no_terminal_feedback_into_training",
            "arm_selection_uses_nonterminal_data_only",
            "all_authorities_sealed_before_scoring",
            "teacher_never_authorizes_correctness",
            "null_harmful_and_scale_reversing_results_are_reportable",
        )
    )

    supplied_id = protocol.get("protocol_id")
    unsigned = dict(protocol)
    unsigned.pop("protocol_id", None)
    checks["protocol_digest"] = supplied_id == content_digest(unsigned)
    return {
        "version": VERSION,
        "passed": all(checks.values()),
        "checks": checks,
        "audit_id": content_digest(
            {"version": VERSION, "protocol_id": supplied_id, "checks": checks}
        ),
    }


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V56 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def freeze_protocol(output: Path) -> Mapping[str, Any]:
    protocol = build_protocol()
    audit = audit_protocol(protocol)
    if not audit["passed"]:
        raise RuntimeError("V56 protocol failed its structural audit")

    _write_immutable(
        output / "protocol.json",
        json.dumps(protocol, indent=2, sort_keys=True) + "\n",
    )
    _write_immutable(
        output / "audit.json",
        json.dumps(audit, indent=2, sort_keys=True) + "\n",
    )
    report = "\n".join(
        (
            "# Cognitive-core V56 calibrated-tool-trust preflight",
            "",
            "- Structural audit passed: **%s**" % audit["passed"],
            "- Protocol ID: `%s`" % protocol["protocol_id"],
            "- Audit ID: `%s`" % audit["audit_id"],
            "- Factorial arms: **%d**" % len(protocol["arms"]),
            "- One-factor contrasts: **%d**"
            % len(protocol["one_factor_contrasts"]),
            "- 3B training authorized: **False**",
            "",
            "## Supersession decision",
            "",
            "V56 supersedes the prospective V55 experiment after the 2026-09-06 "
            "literature closure. V55 artifacts remain immutable. R8 carries "
            "forward only as evidence for target-local output heads.",
            "",
            "## Checks",
            "",
            *(
                "- %s: **%s**" % (key, value)
                for key, value in sorted(audit["checks"].items())
            ),
            "",
            "## Decision",
            "",
            "The V56 protocol is structurally qualified for fresh data and "
            "learnability implementation. The 20M-50M factorial is not yet "
            "authorized because no model has passed the fresh V56 class-recall gate.",
            "",
            "## Next executable gate",
            "",
            "Generate a fresh sealed micro-world with matched faithful, misleading, "
            "and absent observations; add model-adaptive tool-necessity calibration; "
            "then qualify the fixed target-local architecture on an untouched "
            "replication split.",
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)
    return {"protocol": protocol, "audit": audit}
