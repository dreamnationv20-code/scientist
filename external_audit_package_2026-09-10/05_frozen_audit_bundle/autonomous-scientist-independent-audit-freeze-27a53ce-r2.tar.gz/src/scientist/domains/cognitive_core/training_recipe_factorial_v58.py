from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_factorial_v57 import (
    build_protocol as build_v57_protocol,
)


VERSION = "cognitive-core-relational-control-factorial-v58"


def build_protocol() -> Mapping[str, Any]:
    protocol = copy.deepcopy(build_v57_protocol())
    predecessor_id = protocol.pop("protocol_id")
    protocol["version"] = VERSION
    protocol["supersession"] = {
        "predecessor": "cognitive-core-uncertainty-aware-control-factorial-v57",
        "predecessor_protocol_id": predecessor_id,
        "reason": (
            "V57 pipeline audit required end-to-end outcomes, learnable nuisance "
            "controls, and explicit validity-to-policy binding before scale-up"
        ),
        "historical_artifacts_immutable": True,
        "v57_pilot_inferential": False,
        "v57_effect_claims_authorized": False,
    }
    protocol["paper"]["working_title"] = (
        "Relational Cognitive Control: Causal Interactions among State, "
        "Evidence Validation, and Tool Policy Supervision"
    )
    protocol["factor_definitions"]["explicit_state_supervision"]["control"] = (
        "a visible learnable nuisance target with the same 16-class histogram, "
        "target count, tokens, and optimization weight"
    )
    protocol["factor_definitions"]["evidence_validity_supervision"][
        "control"
    ] = (
        "a visible learnable nuisance target with the same three-class histogram, "
        "observation exposure, target count, and optimization weight"
    )
    protocol["factor_definitions"]["adaptive_tool_policy_supervision"][
        "control"
    ] = (
        "a visible learnable nuisance target with the same five-class histogram, "
        "capability-token exposure, target count, and optimization weight"
    )
    protocol["fixed_delivery_architecture"].update(
        {
            "validity_to_policy_edge": True,
            "policy_validity_second_pass": True,
            "policy_to_validity_gradient_stopped": True,
            "architecture_qualification_predecessor_invalidated": True,
        }
    )
    protocol["model_interface"]["policy_visible_fields"].extend(
        ["predicted_validity_distribution", "visible_nuisance_token"]
    )
    protocol["model_interface"]["authority_only_fields"].append(
        "semantic_or_nuisance_arm_target_selection"
    )
    protocol["model_interface"]["prohibited_policy_fields"].append(
        "semantic_or_nuisance_arm_target_selection"
    )
    protocol["end_to_end_evaluator"] = {
        "required": True,
        "matched_regimes": [
            "absent_observation",
            "faithful_observation",
            "surface_matched_broken_state",
            "misleading_final_step",
            "wrong_tool_arguments",
            "incorrect_tool_response",
            "stale_observation",
            "contradictory_observation",
            "valid_certificate_for_wrong_formalization",
        ],
        "primary_estimands": [
            "clean_tool_value",
            "misleading_tool_harm",
            "value_inversion",
            "invalid_evidence_acceptance_rate",
            "coverage",
            "selective_accuracy",
            "call_rate",
            "retry_rate",
            "abstention_rate",
            "accuracy_cost_frontier",
        ],
        "direct_head_accuracy_role": "manipulation_check_only",
        "authority_scored": True,
    }
    gate = protocol["prospective_learnability_gate"]
    gate.update(
        {
            "v57_static_oracle_audit_passed": False,
            "v57_relational_evidence_probe_passed": False,
            "v57_joint_heldout_replication_passed": False,
            "qualification_run_id": None,
            "qualification_profile_id": None,
            "minimum_faithful_validity_accuracy": 0.65,
            "minimum_faithful_policy_accuracy": 0.65,
            "maximum_steps": 6000,
            "fixed_width": 96,
        }
    )
    protocol["factorial_authorization"] = {
        "authorized": False,
        "reason": "fresh V58 learnability replication has not passed",
        "authorized_next_stage": "v58_learnability_only",
        "submillion_pilot_is_inferential": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    protocol["mandatory_comparators"].extend(
        [
            "no_auxiliary_loss_ablation",
            "deterministic_controller_over_learned_validity",
        ]
    )
    protocol["firewalls"].update(
        {
            "faithful_sentinel_frozen_before_training": True,
            "end_to_end_evaluator_frozen_before_training": True,
            "nuisance_controls_frozen_before_training": True,
            "v57_pilot_outcomes_cannot_select_v58_effect_claims": True,
        }
    )
    protocol["protocol_id"] = content_digest(protocol)
    return protocol


def audit_protocol(protocol: Mapping[str, Any]) -> Mapping[str, Any]:
    interface = protocol["model_interface"]
    visible = set(interface["policy_visible_fields"])
    prohibited = set(interface["prohibited_policy_fields"])
    architecture = protocol["fixed_delivery_architecture"]
    gate = protocol["prospective_learnability_gate"]
    checks: Dict[str, bool] = {
        "version": protocol["version"] == VERSION,
        "answer_blind": not visible.intersection(prohibited),
        "validity_to_policy_is_fixed": all(
            architecture[key] is True
            for key in (
                "validity_to_policy_edge",
                "policy_validity_second_pass",
                "policy_to_validity_gradient_stopped",
                "architecture_is_not_a_factor",
            )
        ),
        "learnable_nuisance_controls": all(
            "visible learnable nuisance target"
            in protocol["factor_definitions"][factor]["control"]
            for factor in protocol["factors"]
        ),
        "end_to_end_primary": (
            protocol["end_to_end_evaluator"]["required"] is True
            and protocol["end_to_end_evaluator"]["direct_head_accuracy_role"]
            == "manipulation_check_only"
            and len(protocol["end_to_end_evaluator"]["primary_estimands"]) >= 8
        ),
        "faithful_floors_frozen": (
            gate["minimum_faithful_validity_accuracy"] >= 0.65
            and gate["minimum_faithful_policy_accuracy"] >= 0.65
        ),
        "factorial_not_preauthorized": (
            protocol["factorial_authorization"]["authorized"] is False
            and protocol["factorial_authorization"][
                "twenty_to_fifty_million_execution_authorized"
            ]
            is False
        ),
        "three_billion_prohibited": (
            protocol["factorial_authorization"][
                "three_billion_training_authorized"
            ]
            is False
        ),
        "v57_noninferential": (
            protocol["supersession"]["v57_pilot_inferential"] is False
            and protocol["supersession"]["v57_effect_claims_authorized"] is False
        ),
    }
    unsigned = dict(protocol)
    supplied_id = unsigned.pop("protocol_id", None)
    checks["protocol_digest"] = supplied_id == content_digest(unsigned)
    result: Dict[str, Any] = {
        "version": VERSION,
        "passed": all(checks.values()),
        "checks": checks,
        "protocol_id": supplied_id,
    }
    result["audit_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V58 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def freeze_protocol(output: Path) -> Mapping[str, Any]:
    protocol = build_protocol()
    audit = audit_protocol(protocol)
    if not audit["passed"]:
        raise RuntimeError("V58 protocol failed structural audit")
    _write_immutable(
        output / "protocol.json",
        json.dumps(protocol, indent=2, sort_keys=True) + "\n",
    )
    _write_immutable(
        output / "audit.json",
        json.dumps(audit, indent=2, sort_keys=True) + "\n",
    )
    _write_immutable(
        output / "LOCAL_RESULTS.md",
        "\n".join(
            (
                "# Cognitive-core V58 preflight",
                "",
                "- Structural audit passed: **True**",
                "- Protocol ID: `%s`" % protocol["protocol_id"],
                "- Audit ID: `%s`" % audit["audit_id"],
                "- Factorial authorized: **False**",
                "- 20M-50M execution authorized: **False**",
                "- 3B training authorized: **False**",
                "",
                "Next action: qualify the fixed V58 architecture on fresh data.",
                "",
            )
        ),
    )
    return {"protocol": protocol, "audit": audit}


__all__ = ["VERSION", "audit_protocol", "build_protocol", "freeze_protocol"]
