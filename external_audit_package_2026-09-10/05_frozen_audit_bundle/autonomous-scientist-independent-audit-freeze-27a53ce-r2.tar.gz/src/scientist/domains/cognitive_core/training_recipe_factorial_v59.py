from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Dict, Mapping

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_factorial_v58 import (
    build_protocol as build_v58_protocol,
)


VERSION = "cognitive-core-robust-promotion-factorial-v59"
PROMOTION_GATES = {
    "minimum_development_answer_accuracy": 0.74,
    "minimum_development_worst_family_accuracy": 0.64,
}


def build_protocol() -> Mapping[str, Any]:
    protocol = copy.deepcopy(build_v58_protocol())
    predecessor_id = protocol.pop("protocol_id")
    protocol["version"] = VERSION
    protocol["supersession"] = {
        "predecessor": "cognitive-core-relational-control-factorial-v58",
        "predecessor_protocol_id": predecessor_id,
        "reason": (
            "V58 relational binding passed, but a marginal development "
            "checkpoint lost 2.9 answer points and 2.7 worst-family points "
            "on its single held-out replication"
        ),
        "historical_artifacts_immutable": True,
        "v58_replication_opened_once": True,
        "v58_qualified": False,
        "v58_rerun_authorized": False,
    }
    protocol["paper"]["working_title"] = (
        "Robust Promotion for Relational Cognitive Control"
    )
    protocol["prospective_learnability_gate"].update(
        {
            "qualification_run_id": None,
            "qualification_profile_id": None,
            "maximum_steps": 6000,
            "fixed_width": 96,
            "target_batch_fractions": {
                "answer": 0.25,
                "state": 0.25,
                "evidence_validity": 0.25,
                "tool_policy": 0.25,
            },
            "terminal_thresholds_unchanged_from_v58": True,
        }
    )
    protocol["development_promotion_gate"] = {
        **PROMOTION_GATES,
        "all_other_v58_gates_required": True,
        "selection": "earliest_passing_checkpoint",
        "checkpoint_interval": 200,
        "terminal_data_opened_only_after_pass": True,
        "thresholds_are_not_terminal_gates": True,
    }
    protocol["single_change_claim"] = {
        "changed": "development_to_replication_promotion_thresholds",
        "unchanged": [
            "architecture",
            "losses",
            "optimizer",
            "width",
            "target_batch_fractions",
            "checkpoint_interval",
            "maximum_steps",
            "nuisance_controls",
            "end_to_end_evaluator",
            "terminal_qualification_gates",
        ],
    }
    protocol["factorial_authorization"] = {
        "authorized": False,
        "reason": "fresh V59 robust-promotion replication has not passed",
        "authorized_next_stage": "v59_learnability_only",
        "submillion_pilot_is_inferential": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    protocol["backup_if_development_fails"] = {
        "successor": "v60_answer_weighted_allocation",
        "fresh_data_required": True,
        "target_batch_fractions": {
            "answer": 0.35,
            "state": 0.25,
            "evidence_validity": 0.20,
            "tool_policy": 0.20,
        },
        "not_part_of_v59": True,
        "cannot_be_selected_after_v59_replication": True,
    }
    protocol["firewalls"].update(
        {
            "v58_terminal_split_spent": True,
            "v58_cannot_be_rerun": True,
            "v59_replication_unopened_before_promotion": True,
            "promotion_margins_frozen_before_training": True,
            "v59_only_changes_promotion_rule": True,
        }
    )
    protocol["protocol_id"] = content_digest(protocol)
    return protocol


def audit_protocol(protocol: Mapping[str, Any]) -> Mapping[str, Any]:
    promotion = protocol["development_promotion_gate"]
    gate = protocol["prospective_learnability_gate"]
    authorization = protocol["factorial_authorization"]
    single_change = protocol["single_change_claim"]
    checks: Dict[str, bool] = {
        "version": protocol["version"] == VERSION,
        "fresh_successor": (
            protocol["supersession"]["v58_qualified"] is False
            and protocol["supersession"]["v58_rerun_authorized"] is False
        ),
        "promotion_margins_frozen": (
            promotion["minimum_development_answer_accuracy"] == 0.74
            and promotion["minimum_development_worst_family_accuracy"] == 0.64
            and promotion["terminal_data_opened_only_after_pass"] is True
        ),
        "earliest_checkpoint": (
            promotion["selection"] == "earliest_passing_checkpoint"
            and promotion["checkpoint_interval"] == 200
        ),
        "terminal_gates_unchanged": (
            gate["terminal_thresholds_unchanged_from_v58"] is True
            and promotion["thresholds_are_not_terminal_gates"] is True
        ),
        "equal_target_allocation": gate["target_batch_fractions"]
        == {
            "answer": 0.25,
            "state": 0.25,
            "evidence_validity": 0.25,
            "tool_policy": 0.25,
        },
        "single_change": (
            single_change["changed"]
            == "development_to_replication_promotion_thresholds"
            and "architecture" in single_change["unchanged"]
            and "terminal_qualification_gates" in single_change["unchanged"]
        ),
        "factorial_not_preauthorized": (
            authorization["authorized"] is False
            and authorization["twenty_to_fifty_million_execution_authorized"]
            is False
            and authorization["three_billion_training_authorized"] is False
        ),
        "backup_is_separate": (
            protocol["backup_if_development_fails"]["not_part_of_v59"] is True
            and protocol["backup_if_development_fails"]
            ["cannot_be_selected_after_v59_replication"]
            is True
        ),
    }
    unsigned = dict(protocol)
    supplied_id = unsigned.pop("protocol_id", None)
    checks["protocol_digest"] = supplied_id == content_digest(unsigned)
    result: Dict[str, Any] = {
        "version": VERSION,
        "passed": all(checks.values()),
        "checks": checks,
        "protocol_id": supplied_id,
    }
    result["audit_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V59 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def freeze_protocol(output: Path) -> Mapping[str, Any]:
    protocol = build_protocol()
    audit = audit_protocol(protocol)
    if not audit["passed"]:
        raise RuntimeError("V59 protocol failed structural audit")
    _write_immutable(
        output / "protocol.json",
        json.dumps(protocol, indent=2, sort_keys=True) + "\n",
    )
    _write_immutable(
        output / "audit.json",
        json.dumps(audit, indent=2, sort_keys=True) + "\n",
    )
    _write_immutable(
        output / "LOCAL_RESULTS.md",
        "\n".join(
            (
                "# Cognitive-core V59 preflight",
                "",
                "- Structural audit passed: **True**",
                "- Protocol ID: `%s`" % protocol["protocol_id"],
                "- Audit ID: `%s`" % audit["audit_id"],
                "- Development answer promotion floor: **74%**",
                "- Development worst-family promotion floor: **64%**",
                "- Terminal gates changed: **False**",
                "- Factorial authorized: **False**",
                "- 20M-50M execution authorized: **False**",
                "- 3B training authorized: **False**",
                "",
                "Next action: qualify robust promotion on fresh V59 data.",
                "",
            )
        ),
    )
    return {"protocol": protocol, "audit": audit}


__all__ = [
    "PROMOTION_GATES",
    "VERSION",
    "audit_protocol",
    "build_protocol",
    "freeze_protocol",
]
