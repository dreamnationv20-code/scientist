from __future__ import annotations

import json
import platform
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_micro_world_v57 import (
    load_split,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    TARGETS,
    SmokeConfig,
    V56SeparatedHeadTransformer,
    _arrays,
    _balanced_batch,
    _optimizer,
    _parameter_count,
    adjudicate,
    evaluate,
)


VERSION = "cognitive-core-uncertainty-aware-control-joint-v57-r1"


def _monitor(
    examples_by_target: Mapping[str, Sequence[Mapping[str, Any]]],
) -> Tuple[Mapping[str, Any], ...]:
    monitor = []
    for target in TARGETS:
        ordered = sorted(
            examples_by_target[target],
            key=lambda row: content_digest(
                {
                    "version": VERSION,
                    "monitor": "v57-fixed-joint-development-v1",
                    "target": target,
                    "example_id": row["example_id"],
                }
            ),
        )
        monitor.extend(ordered[: min(1152, len(ordered))])
    return tuple(monitor)


def run_joint(
    dataset_root: Path,
    capability_profile_path: Path,
    config: SmokeConfig,
) -> Mapping[str, Any]:
    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    started = time.monotonic()
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    development_public, development_authority = load_split(
        dataset_root, "learnability_development"
    )
    materialized_development = materialize_policy_labels(
        development_public, development_authority, profile
    )
    development = training_examples(
        development_public, materialized_development
    )
    by_target = {
        target: tuple(row for row in development if row["target"] == target)
        for target in TARGETS
    }
    monitor = _monitor(by_target)

    mx.random.seed(config.model_seed)
    model = V56SeparatedHeadTransformer(config)
    mx.eval(model.parameters())
    optimizer = _optimizer(config, config.steps)

    def loss_fn(
        active_model: V56SeparatedHeadTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints = []
    selected_step = None
    for step in range(1, config.steps + 1):
        tokens, labels = _arrays(_balanced_batch(by_target, config, step))
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        if step % config.checkpoint_interval == 0 or step == config.steps:
            metrics = evaluate(model, monitor)
            decision = adjudicate(metrics)
            checkpoints.append(
                {
                    "step": step,
                    "loss": float(loss.item()),
                    "metrics": metrics,
                    "development_qualification": decision,
                }
            )
            if decision["passed"]:
                selected_step = step
                break

    development_metrics = checkpoints[-1]["metrics"]
    replication_opened = selected_step is not None
    replication = ()
    if replication_opened:
        replication_public, replication_authority = load_split(
            dataset_root, "learnability_replication"
        )
        materialized_replication = materialize_policy_labels(
            replication_public, replication_authority, profile
        )
        replication = training_examples(
            replication_public, materialized_replication
        )
        final_metrics = evaluate(model, replication)
    else:
        final_metrics = development_metrics
    decision = adjudicate(final_metrics)

    result: Dict[str, Any] = {
        "version": VERSION,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "architecture": {
            "shared_encoder": True,
            "target_local_output_heads": True,
            "uncertainty_aware_policy_token": True,
            "cross_target_softmax_competition": False,
        },
        "config": config.as_dict(),
        "parameter_count": _parameter_count(model),
        "development_examples": len(development),
        "development_monitor_examples": len(monitor),
        "replication_examples": len(replication),
        "selected_step": selected_step,
        "selection_rule": (
            "earliest development checkpoint passing all unchanged V56 outcome gates"
        ),
        "replication_opened": replication_opened,
        "checkpoints": checkpoints,
        "development_metrics": development_metrics,
        "metrics": final_metrics,
        "decision": decision,
        "factorial_authorized": decision["passed"] and replication_opened,
        "next_action": (
            "freeze_and_run_v57_micro_factorial"
            if decision["passed"] and replication_opened
            else (
                "close_v57_after_replication_failure"
                if replication_opened
                else "close_v57_after_development_failure"
            )
        ),
        "hardware": platform.platform(),
        "framework": "mlx",
        "elapsed_seconds": time.monotonic() - started,
    }
    result["run_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V57 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    metrics = result["metrics"]
    rows = []
    for target in TARGETS:
        row = metrics["by_target"][target]
        rows.append(
            "| %s | %.1f%% | %.1f%% |"
            % (
                target,
                row["accuracy"] * 100.0,
                row["minimum_class_recall"] * 100.0,
            )
        )
    report = "\n".join(
        (
            "# Cognitive-core V57 joint learnability",
            "",
            "- Qualification passed: **%s**" % result["decision"]["passed"],
            "- Development selected step: **%s**" % result["selected_step"],
            "- Replication opened: **%s**" % result["replication_opened"],
            "- Factorial authorized: **%s**" % result["factorial_authorized"],
            "- Parameters: **%s**" % f"{result['parameter_count']:,}",
            "- Run ID: `%s`" % result["run_id"],
            "",
            "## %s metrics"
            % ("Held-out replication" if result["replication_opened"] else "Development"),
            "",
            "| Target | Accuracy | Minimum recall |",
            "|---|---:|---:|",
            *rows,
            "",
            "Worst-family accuracy: **%.1f%%**"
            % (min(metrics["by_family"].values()) * 100.0),
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = ["VERSION", "run_joint", "write_result"]
