from __future__ import annotations

import json
import platform
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
    prediction_index,
)
from scientist.domains.cognitive_core.training_recipe_factorial_v59 import (
    PROMOTION_GATES,
)
from scientist.domains.cognitive_core.training_recipe_learnability_v58 import (
    adjudicate as adjudicate_v58,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    closed_book_answer_examples,
    estimate_capability_profile,
    load_split,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    TARGETS,
    SmokeConfig,
    _arrays,
    _balanced_batch,
    _balanced_rows,
    _optimizer,
    _predict,
    evaluate,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    V58RelationalControlTransformer,
    parameter_count,
)


VERSION = "cognitive-core-robust-promotion-learnability-v59-r1"


def _development_monitor(
    examples_by_target: Mapping[str, Sequence[Mapping[str, Any]]],
) -> Tuple[Mapping[str, Any], ...]:
    monitor = []
    for target in TARGETS:
        ordered = sorted(
            examples_by_target[target],
            key=lambda row: content_digest(
                {
                    "version": VERSION,
                    "monitor": "v59-fixed-development-monitor-v1",
                    "target": target,
                    "example_id": row["example_id"],
                }
            ),
        )
        monitor.extend(ordered[: min(1152, len(ordered))])
    return tuple(monitor)


def adjudicate_promotion(metrics: Mapping[str, Any]) -> Mapping[str, Any]:
    base = adjudicate_v58(metrics)
    checks = dict(base["checks"])
    observations = dict(base["observations"])
    checks["answer_accuracy"] = (
        observations["answer_accuracy"]
        >= PROMOTION_GATES["minimum_development_answer_accuracy"]
    )
    checks["worst_family_accuracy"] = (
        observations["worst_family_accuracy"]
        >= PROMOTION_GATES["minimum_development_worst_family_accuracy"]
    )
    passed = all(checks.values())
    return {
        "passed": passed,
        "checks": checks,
        "observations": observations,
        "terminal_gates": base["gates"],
        "promotion_gates": PROMOTION_GATES,
        "next_action": (
            "open_v59_replication_once"
            if passed
            else "continue_v59_development_without_opening_replication"
        ),
    }


def adjudicate_terminal(metrics: Mapping[str, Any]) -> Mapping[str, Any]:
    base = dict(adjudicate_v58(metrics))
    base["next_action"] = (
        "authorize_v59_noninferential_factorial_pilot"
        if base["passed"]
        else "close_v59_after_terminal_failure"
    )
    return base


def _train_calibrator(
    development: Sequence[Mapping[str, Any]],
    calibration: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    calibration_steps: int,
) -> Tuple[V58RelationalControlTransformer, Mapping[str, Any]]:
    mx.random.seed(config.model_seed)
    model = V58RelationalControlTransformer(config)
    mx.eval(model.parameters())
    optimizer = _optimizer(config, calibration_steps)

    def loss_fn(active_model, tokens, labels):
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    for step in range(1, calibration_steps + 1):
        batch = _balanced_rows(
            development,
            config.batch_size,
            config.data_seed + 15485863 * step,
        )
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
    development_metrics = evaluate(model, development)
    calibration_predictions = _predict(model, calibration)
    prediction_map = {
        row["view_id"]: prediction
        for row, prediction in zip(calibration, calibration_predictions)
    }
    checkpoint_id = content_digest(
        {
            "version": VERSION,
            "role": "v59_closed_book_capability_calibrator",
            "model_seed": config.model_seed,
            "data_seed": config.data_seed,
            "steps": calibration_steps,
            "last_loss": last_loss,
            "predictions": prediction_map,
        }
    )
    return model, {
        "checkpoint_id": checkpoint_id,
        "steps": calibration_steps,
        "last_loss": last_loss,
        "development_metrics": development_metrics,
        "predictions": prediction_map,
    }


def _end_to_end_metrics(
    model: V58RelationalControlTransformer,
    examples: Sequence[Mapping[str, Any]],
    public_rows: Sequence[Mapping[str, Any]],
    materialized_authority: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    predictions = _predict(model, examples)
    return evaluate_end_to_end(
        public_rows,
        materialized_authority,
        prediction_index(examples, predictions),
    )


def run_learnability(
    dataset_root: Path,
    protocol_path: Path,
    config: SmokeConfig,
    *,
    calibration_steps: int = 1200,
) -> Mapping[str, Any]:
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    if protocol["version"] != "cognitive-core-robust-promotion-factorial-v59":
        raise RuntimeError("V59 protocol version mismatch")
    if protocol["factorial_authorization"]["authorized"] is not False:
        raise RuntimeError("V59 learnability must precede factorial authorization")
    if protocol["development_promotion_gate"] != {
        **PROMOTION_GATES,
        "all_other_v58_gates_required": True,
        "selection": "earliest_passing_checkpoint",
        "checkpoint_interval": 200,
        "terminal_data_opened_only_after_pass": True,
        "thresholds_are_not_terminal_gates": True,
    }:
        raise RuntimeError("V59 promotion rule mismatch")
    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    started = time.monotonic()

    development_public, development_authority = load_split(
        dataset_root, "learnability_development"
    )
    calibration_public, calibration_authority = load_split(
        dataset_root, "capability_calibration"
    )
    calibration_development = closed_book_answer_examples(
        development_public, development_authority
    )
    calibration_examples = closed_book_answer_examples(
        calibration_public, calibration_authority
    )
    calibrator, calibration_result = _train_calibrator(
        calibration_development,
        calibration_examples,
        config,
        calibration_steps,
    )
    predictions = calibration_result.pop("predictions")
    profile = estimate_capability_profile(
        calibration_public,
        calibration_authority,
        predictions,
        model_id="v59-relational-control-%d" % parameter_count(calibrator),
        checkpoint_id=calibration_result["checkpoint_id"],
    )
    del calibrator

    materialized_development = materialize_policy_labels(
        development_public, development_authority, profile
    )
    development = training_examples(
        development_public, materialized_development
    )
    nuisance_audit = audit_nuisance_controls(development)
    if not nuisance_audit["passed"]:
        raise RuntimeError("V59 nuisance control audit failed")
    by_target = {
        target: tuple(row for row in development if row["target"] == target)
        for target in TARGETS
    }
    monitor = _development_monitor(by_target)

    mx.random.seed(config.model_seed + 1)
    model = V58RelationalControlTransformer(config)
    mx.eval(model.parameters())
    optimizer = _optimizer(config, config.steps)

    def loss_fn(active_model, tokens, labels):
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints = []
    selected_step = None
    for step in range(1, config.steps + 1):
        tokens, labels = _arrays(_balanced_batch(by_target, config, step))
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        if step % config.checkpoint_interval == 0 or step == config.steps:
            metrics = evaluate(model, monitor)
            promotion = adjudicate_promotion(metrics)
            checkpoints.append(
                {
                    "step": step,
                    "loss": float(loss.item()),
                    "metrics": metrics,
                    "development_promotion": promotion,
                }
            )
            if promotion["passed"]:
                selected_step = step
                break

    development_metrics = checkpoints[-1]["metrics"]
    development_e2e = _end_to_end_metrics(
        model,
        development,
        development_public,
        materialized_development,
    )
    replication_opened = selected_step is not None
    replication = ()
    replication_nuisance_audit = None
    if replication_opened:
        replication_public, replication_authority = load_split(
            dataset_root, "learnability_replication"
        )
        materialized_replication = materialize_policy_labels(
            replication_public, replication_authority, profile
        )
        replication = training_examples(
            replication_public, materialized_replication
        )
        replication_nuisance_audit = audit_nuisance_controls(replication)
        final_metrics = evaluate(model, replication)
        final_e2e = _end_to_end_metrics(
            model,
            replication,
            replication_public,
            materialized_replication,
        )
    else:
        final_metrics = development_metrics
        final_e2e = development_e2e
    decision = adjudicate_terminal(final_metrics)
    qualified = replication_opened and decision["passed"]

    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": protocol["protocol_id"],
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "config": config.as_dict(),
        "calibration_steps": calibration_steps,
        "calibration_result": calibration_result,
        "capability_profile": profile,
        "parameter_count": parameter_count(model),
        "target_batch_fractions": {
            "answer": 0.25,
            "state": 0.25,
            "evidence_validity": 0.25,
            "tool_policy": 0.25,
        },
        "promotion_gates": PROMOTION_GATES,
        "selection_rule": "earliest checkpoint passing robust V59 promotion",
        "nuisance_control_audit": nuisance_audit,
        "replication_nuisance_control_audit": replication_nuisance_audit,
        "checkpoints": checkpoints,
        "selected_step": selected_step,
        "replication_opened": replication_opened,
        "development_metrics": development_metrics,
        "development_end_to_end": development_e2e,
        "metrics": final_metrics,
        "end_to_end": final_e2e,
        "decision": decision,
        "qualified": qualified,
        "factorial_pilot_authorized": qualified,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": (
            "run_v59_noninferential_factorial_pilot"
            if qualified
            else (
                "close_v59_after_terminal_failure"
                if replication_opened
                else "close_v59_development_and_prepare_v60_answer_weighting"
            )
        ),
        "framework": "mlx",
        "hardware": platform.platform(),
        "elapsed_seconds": time.monotonic() - started,
    }
    result["run_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V59 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    _write_immutable(
        output / "capability-profile.json",
        json.dumps(result["capability_profile"], indent=2, sort_keys=True) + "\n",
    )
    metrics = result["metrics"]
    decision = result["decision"]
    rows = []
    for target in TARGETS:
        row = metrics["by_target"][target]
        rows.append(
            "| %s | %.1f%% | %.1f%% |"
            % (
                target,
                row["accuracy"] * 100.0,
                row["minimum_class_recall"] * 100.0,
            )
        )
    e2e = result["end_to_end"]["primary_estimands"]
    report = "\n".join(
        (
            "# Cognitive-core V59 robust-promotion learnability",
            "",
            "- Qualified: **%s**" % result["qualified"],
            "- Selected development step: **%s**" % result["selected_step"],
            "- Replication opened: **%s**" % result["replication_opened"],
            "- Factorial pilot authorized: **%s**"
            % result["factorial_pilot_authorized"],
            "- 20M-50M execution authorized: **False**",
            "- 3B training authorized: **False**",
            "- Parameters: **%s**" % f"{result['parameter_count']:,}",
            "- Run ID: `%s`" % result["run_id"],
            "",
            "| Target | Accuracy | Minimum recall |",
            "|---|---:|---:|",
            *rows,
            "",
            "- Faithful validity: **%.1f%%**"
            % (decision["observations"]["faithful_validity_accuracy"] * 100.0),
            "- Faithful policy: **%.1f%%**"
            % (decision["observations"]["faithful_policy_accuracy"] * 100.0),
            "- Clean-tool value: **%+.1f pp**" % (e2e["clean_tool_value"] * 100.0),
            "- Misleading-tool harm: **%+.1f pp**"
            % (e2e["misleading_tool_harm"] * 100.0),
            "- Invalid-evidence acceptance: **%.1f%%**"
            % (e2e["invalid_evidence_acceptance_rate"] * 100.0),
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = [
    "PROMOTION_GATES",
    "VERSION",
    "adjudicate_promotion",
    "adjudicate_terminal",
    "run_learnability",
    "write_result",
]
