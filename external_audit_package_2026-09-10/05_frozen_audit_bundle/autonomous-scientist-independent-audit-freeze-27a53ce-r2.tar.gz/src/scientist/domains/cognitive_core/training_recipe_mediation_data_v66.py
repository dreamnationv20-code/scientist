from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Mapping

from scientist.domains.cognitive_core import training_recipe_micro_world_v58 as base


VERSION = "cognitive-core-decoded-state-mediation-data-v66"
SEEDS = {
    "mediation_train": 67011,
    "mediation_development": 67021,
}
DEFAULT_PER_FAMILY = {
    "mediation_train": 2048,
    "mediation_development": 512,
}


@contextmanager
def _v66_context() -> Iterator[None]:
    original_version = base.VERSION
    original_seeds = base.SEEDS
    original_defaults = base.DEFAULT_PER_FAMILY
    try:
        base.VERSION = VERSION
        base.SEEDS = SEEDS
        base.DEFAULT_PER_FAMILY = DEFAULT_PER_FAMILY
        yield
    finally:
        base.VERSION = original_version
        base.SEEDS = original_seeds
        base.DEFAULT_PER_FAMILY = original_defaults


def generate_split(split: str, per_family: int | None = None):
    with _v66_context():
        return base.generate_split(split, per_family)


def audit_dataset(public_rows, authority_rows):
    with _v66_context():
        return base.audit_dataset(public_rows, authority_rows)


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
):
    with _v66_context():
        return base.freeze_dataset(output, per_family_by_split)


load_split = base.load_split


__all__ = [
    "DEFAULT_PER_FAMILY",
    "SEEDS",
    "VERSION",
    "audit_dataset",
    "freeze_dataset",
    "generate_split",
    "load_split",
]
