from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


VERSION = "cognitive-core-training-recipe-micro-world-v55-r7"
SEEDS = {"micro_development": 55101, "micro_replication": 55701}
DEFAULT_PER_FAMILY = {"micro_development": 2048, "micro_replication": 128}
FAMILIES = (
    "deductive_logic",
    "arithmetic_programs",
    "graph_search",
    "typed_tool_use",
)
VARIANTS = (
    "no_observation",
    "valid",
    "broken_state",
    "misleading_result",
    "wrong_formalization",
    "irrelevant",
)

PAD = 0
CLS = 1
TARGET_ANSWER = 2
TARGET_STATE = 3
TARGET_VERIFY = 4
TARGET_ROUTE = 5
FAMILY_TOKEN = {
    "deductive_logic": 8,
    "arithmetic_programs": 9,
    "graph_search": 10,
    "typed_tool_use": 11,
}
OBSERVE = 12
FORMAL = 13
STEP = 14
RESULT = 15
END = 16
NULL = 17
OP_AND = 18
OP_OR = 19
OP_XOR = 20
OP_ADD = 21
OP_SUB = 22
OP_MUL = 23
OP_MAX = 24
OP_EDGE = 25
OP_TOOL = 26
NUMBER_BASE = 64
INPUT_VOCAB_SIZE = 96
PROBLEM_LENGTH = 12
OBSERVATION_LENGTH = 12
SEQUENCE_LENGTH = 32

ANSWER_LABEL_BASE = 0
STATE_LABEL_BASE = 16
VERIFY_LABEL_BASE = 32
ROUTE_LABEL_BASE = 36
OUTPUT_CLASSES = 40
VERIFY_LABELS = {
    "accept": 0,
    "broken": 1,
    "wrong_problem": 2,
    "irrelevant": 3,
}
ROUTE_LABELS = {
    "answer": 0,
    "call": 1,
    "retry": 2,
    "reformalize": 3,
}

PROHIBITED_PUBLIC_FIELDS = {
    "answer",
    "state",
    "verification_label",
    "route_label",
    "formal_validity",
    "semantic_validity",
    "variant",
    "latent",
}


def _number(value: int) -> int:
    if not 0 <= value < 16:
        raise ValueError("micro-world values must be nibbles")
    return NUMBER_BASE + value


def _decode_number(token: int) -> int:
    value = token - NUMBER_BASE
    if not 0 <= value < 16:
        raise ValueError("token is not a micro-world number")
    return value


def _apply(operator: int, left: int, right: int) -> int:
    if operator == OP_AND:
        return int(bool(left) and bool(right))
    if operator == OP_OR:
        return int(bool(left) or bool(right))
    if operator == OP_XOR:
        return left ^ right
    if operator == OP_ADD:
        return (left + right) % 16
    if operator == OP_SUB:
        return (left - right) % 16
    if operator == OP_MUL:
        return (left * right) % 16
    if operator == OP_MAX:
        return max(left, right)
    if operator == OP_EDGE:
        # In the graph micro-world, the first record certifies the cost of the
        # first edge.  The second argument is a typed edge-context value.
        return left
    raise ValueError("unsupported micro-world operator")


def _alternate_operator(operator: int, choices: Sequence[int]) -> int:
    return next(candidate for candidate in choices if candidate != operator)


def _problem(
    family: str,
    op1: int,
    left: int,
    right: int,
    op2: int,
    third: int,
    extras: Sequence[int] = (),
) -> Tuple[int, ...]:
    values = [
        FAMILY_TOKEN[family],
        op1,
        _number(left),
        _number(right),
        op2,
        _number(third),
        *extras,
    ]
    values.extend([NULL] * (PROBLEM_LENGTH - len(values)))
    if len(values) != PROBLEM_LENGTH:
        raise ValueError("problem encoding overflow")
    return tuple(values)


def _observation(
    op1: int,
    left: int,
    right: int,
    claimed_state: int,
    op2: int,
    third: int,
    claimed_answer: int,
) -> Tuple[int, ...]:
    values = (
        OBSERVE,
        FORMAL,
        op1,
        _number(left),
        _number(right),
        STEP,
        _number(claimed_state),
        op2,
        _number(third),
        RESULT,
        _number(claimed_answer),
        END,
    )
    if len(values) != OBSERVATION_LENGTH:
        raise AssertionError("observation encoding changed length")
    return values


def _world_spec(family: str, rng: random.Random) -> Mapping[str, Any]:
    if family == "deductive_logic":
        left, right, third = (rng.randrange(2) for _ in range(3))
        op1 = rng.choice((OP_AND, OP_OR, OP_XOR))
        op2 = rng.choice((OP_AND, OP_OR, OP_XOR))
        state = _apply(op1, left, right)
        answer = _apply(op2, state, third)
        extras = (_number(rng.randrange(2)), OP_EDGE)
        choices = (OP_AND, OP_OR, OP_XOR)
    elif family == "arithmetic_programs":
        left, right, third = (rng.randrange(16) for _ in range(3))
        op1 = rng.choice((OP_ADD, OP_SUB, OP_XOR))
        op2 = rng.choice((OP_ADD, OP_MUL, OP_MAX))
        state = _apply(op1, left, right)
        answer = _apply(op2, state, third)
        extras = (_number(rng.randrange(16)), OP_TOOL)
        choices = (OP_ADD, OP_MUL, OP_MAX)
    elif family == "graph_search":
        # The task is the cost of a certified two-edge path.  Node identities
        # are nonce values; state is the first-edge cumulative cost.
        source = rng.randrange(8)
        middle = (source + rng.randrange(1, 8)) % 8
        target = (middle + rng.randrange(1, 8)) % 8
        left = rng.randrange(1, 8)
        right = rng.randrange(8)
        third = rng.randrange(1, 8)
        op1 = OP_EDGE
        op2 = OP_ADD
        state = left
        answer = (left + third) % 16
        extras = (
            _number(source),
            _number(middle),
            _number(target),
            OP_EDGE,
        )
        choices = (OP_ADD, OP_SUB, OP_MAX)
    elif family == "typed_tool_use":
        left, right = rng.randrange(16), rng.randrange(16)
        third = right
        op1 = OP_TOOL
        op2 = rng.choice((OP_ADD, OP_XOR, OP_MAX))
        tool_index = {OP_ADD: 0, OP_XOR: 1, OP_MAX: 2}[op2]
        state = tool_index
        answer = _apply(op2, left, right)
        extras = (OP_ADD, OP_XOR, OP_MAX, _number(rng.randrange(16)))
        choices = (OP_ADD, OP_XOR, OP_MAX)
    else:
        raise ValueError("unknown micro-world family")

    return {
        "family": family,
        "op1": op1,
        "left": left,
        "right": right,
        "op2": op2,
        "third": third,
        "state": state,
        "answer": answer,
        "extras": tuple(extras),
        "alternative_op2": _alternate_operator(op2, choices),
    }


def _record_state(
    spec: Mapping[str, Any], op1: int, left: int, right: int, op2: int
) -> int:
    if spec["family"] == "typed_tool_use":
        return {OP_ADD: 0, OP_XOR: 1, OP_MAX: 2}[op2]
    return _apply(op1, left, right)


def _record_answer(
    spec: Mapping[str, Any],
    op2: int,
    left: int,
    right: int,
    state: int,
    third: int,
) -> int:
    if spec["family"] == "typed_tool_use":
        return _apply(op2, left, right)
    return _apply(op2, state, third)


def _different_wrong_formalization(
    spec: Mapping[str, Any], state: int, answer: int
) -> Tuple[int, int, int, int, int]:
    if spec["family"] == "deductive_logic":
        choices = (OP_AND, OP_OR, OP_XOR)
    elif spec["family"] == "typed_tool_use":
        choices = (OP_ADD, OP_XOR, OP_MAX)
    else:
        choices = (OP_ADD, OP_SUB, OP_MUL, OP_MAX, OP_XOR)
    modulus = 2 if spec["family"] == "deductive_logic" else 16
    left_values = (int(spec["left"]), (int(spec["left"]) + 1) % modulus)
    right_values = (int(spec["right"]), (int(spec["right"]) + 1) % modulus)
    third_values = range(modulus)
    for operator in choices:
        if operator == int(spec["op2"]):
            continue
        for candidate_left in left_values:
            for candidate_right in right_values:
                for candidate_third in third_values:
                    candidate_state = _record_state(
                        spec,
                        int(spec["op1"]),
                        candidate_left,
                        candidate_right,
                        operator,
                    )
                    candidate_answer = _record_answer(
                        spec,
                        operator,
                        candidate_left,
                        candidate_right,
                        candidate_state,
                        candidate_third,
                    )
                    if candidate_answer != answer:
                        return (
                            operator,
                            candidate_left,
                            candidate_right,
                            candidate_third,
                            candidate_state,
                        )
    raise RuntimeError("could not construct a distinct wrong formalization")


def _variant_observation(
    spec: Mapping[str, Any], variant: str
) -> Tuple[int, ...]:
    if variant == "no_observation":
        return (PAD,) * OBSERVATION_LENGTH

    op1 = int(spec["op1"])
    left = int(spec["left"])
    right = int(spec["right"])
    state = int(spec["state"])
    op2 = int(spec["op2"])
    third = int(spec["third"])
    answer = int(spec["answer"])
    if variant == "valid":
        return _observation(op1, left, right, state, op2, third, answer)
    if variant == "broken_state":
        wrong_state = (state + 1) % 16
        wrong_answer = _record_answer(
            spec, op2, left, right, wrong_state, third
        )
        return _observation(
            op1, left, right, wrong_state, op2, third, wrong_answer
        )
    if variant == "misleading_result":
        return _observation(
            op1, left, right, state, op2, third, (answer + 1) % 16
        )
    if variant == "wrong_formalization":
        (
            alternative,
            wrong_left,
            wrong_right,
            wrong_third,
            wrong_state,
        ) = _different_wrong_formalization(spec, state, answer)
        wrong_answer = _record_answer(
            spec,
            alternative,
            wrong_left,
            wrong_right,
            wrong_state,
            wrong_third,
        )
        return _observation(
            op1,
            wrong_left,
            wrong_right,
            wrong_state,
            alternative,
            wrong_third,
            wrong_answer,
        )
    if variant == "irrelevant":
        other_left = (left + 3) % (2 if spec["family"] == "deductive_logic" else 16)
        other_right = (right + 5) % (2 if spec["family"] == "deductive_logic" else 16)
        other_state = _record_state(
            spec, op1, other_left, other_right, op2
        )
        other_answer = _record_answer(
            spec,
            op2,
            other_left,
            other_right,
            other_state,
            third,
        )
        return _observation(
            op1,
            other_left,
            other_right,
            other_state,
            op2,
            third,
            other_answer,
        )
    raise ValueError("unknown micro-world variant")


def _variant_authority(variant: str) -> Mapping[str, Any]:
    if variant == "no_observation":
        return {
            "formal_validity": None,
            "semantic_validity": None,
            "verification_label": None,
            "route_label": ROUTE_LABELS["call"],
        }
    if variant == "valid":
        return {
            "formal_validity": True,
            "semantic_validity": True,
            "verification_label": VERIFY_LABELS["accept"],
            "route_label": ROUTE_LABELS["answer"],
        }
    if variant in ("broken_state", "misleading_result"):
        return {
            "formal_validity": False,
            "semantic_validity": False,
            "verification_label": VERIFY_LABELS["broken"],
            "route_label": ROUTE_LABELS["retry"],
        }
    if variant == "wrong_formalization":
        return {
            "formal_validity": True,
            "semantic_validity": False,
            "verification_label": VERIFY_LABELS["wrong_problem"],
            "route_label": ROUTE_LABELS["reformalize"],
        }
    if variant == "irrelevant":
        return {
            "formal_validity": True,
            "semantic_validity": False,
            "verification_label": VERIFY_LABELS["irrelevant"],
            "route_label": ROUTE_LABELS["call"],
        }
    raise ValueError("unknown micro-world variant")


def generate_split(
    split: str, per_family: int | None = None
) -> Tuple[Tuple[Mapping[str, Any], ...], Tuple[Mapping[str, Any], ...]]:
    if split not in SEEDS:
        raise ValueError("unknown micro-world split")
    if per_family is None:
        per_family = DEFAULT_PER_FAMILY[split]
    if per_family <= 0:
        raise ValueError("per_family must be positive")
    public_rows = []
    authority_rows = []
    for family_index, family in enumerate(FAMILIES):
        rng = random.Random(SEEDS[split] + 1009 * family_index)
        for index in range(per_family):
            spec = _world_spec(family, rng)
            problem = _problem(
                family,
                int(spec["op1"]),
                int(spec["left"]),
                int(spec["right"]),
                int(spec["op2"]),
                int(spec["third"]),
                spec["extras"],
            )
            base_id = "w-" + content_digest(
                {
                    "version": VERSION,
                    "split": split,
                    "family": family,
                    "index": index,
                    "seed": SEEDS[split],
                }
            )[:20]
            for variant in VARIANTS:
                view_id = "v-" + content_digest(
                    {"base_id": base_id, "variant": variant, "version": VERSION}
                )[:20]
                observation = _variant_observation(spec, variant)
                public_rows.append(
                    {
                        "view_id": view_id,
                        "base_id": base_id,
                        "split": split,
                        "family": family,
                        "problem_tokens": list(problem),
                        "observation_tokens": list(observation),
                    }
                )
                authority_rows.append(
                    {
                        "view_id": view_id,
                        "base_id": base_id,
                        "variant": variant,
                        "answer": int(spec["answer"]),
                        "state": int(spec["state"]),
                        "latent": {
                            key: (list(value) if isinstance(value, tuple) else value)
                            for key, value in spec.items()
                        },
                        **_variant_authority(variant),
                    }
                )
    return tuple(public_rows), tuple(authority_rows)


def training_examples(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    authorities = {row["view_id"]: row for row in authority_rows}
    examples = []
    for public in public_rows:
        authority = authorities[public["view_id"]]
        input_tail = tuple(public["problem_tokens"]) + tuple(
            public["observation_tokens"]
        )
        targets = [
            ("answer", TARGET_ANSWER, ANSWER_LABEL_BASE + int(authority["answer"])),
            (
                "route",
                TARGET_ROUTE,
                ROUTE_LABEL_BASE + int(authority["route_label"]),
            ),
        ]
        if authority["variant"] == "no_observation":
            targets.append(
                ("state", TARGET_STATE, STATE_LABEL_BASE + int(authority["state"]))
            )
        else:
            targets.append(
                (
                    "verify",
                    TARGET_VERIFY,
                    VERIFY_LABEL_BASE + int(authority["verification_label"]),
                )
            )
        for target_name, target_token, label in targets:
            tokens = (CLS, target_token, *input_tail)
            tokens = tokens + (PAD,) * (SEQUENCE_LENGTH - len(tokens))
            if len(tokens) != SEQUENCE_LENGTH:
                raise ValueError("micro-world training sequence overflow")
            examples.append(
                {
                    "example_id": "e-"
                    + content_digest(
                        {
                            "view_id": public["view_id"],
                            "target": target_name,
                            "version": VERSION,
                        }
                    )[:20],
                    "view_id": public["view_id"],
                    "family": public["family"],
                    "target": target_name,
                    "tokens": tokens,
                    "label": label,
                    "variant": authority["variant"],
                }
            )
    return tuple(examples)


def _recompute(latent: Mapping[str, Any]) -> Tuple[int, int]:
    family = latent["family"]
    op1 = int(latent["op1"])
    left = int(latent["left"])
    right = int(latent["right"])
    op2 = int(latent["op2"])
    third = int(latent["third"])
    if family == "typed_tool_use":
        state = {OP_ADD: 0, OP_XOR: 1, OP_MAX: 2}[op2]
        return state, _apply(op2, left, right)
    state = _apply(op1, left, right)
    return state, _apply(op2, state, third)


def _record_is_formally_valid(
    latent: Mapping[str, Any], observation_tokens: Sequence[int]
) -> bool:
    if tuple(observation_tokens) == (PAD,) * OBSERVATION_LENGTH:
        return False
    if (
        observation_tokens[0] != OBSERVE
        or observation_tokens[1] != FORMAL
        or observation_tokens[5] != STEP
        or observation_tokens[9] != RESULT
        or observation_tokens[11] != END
    ):
        return False
    spec = dict(latent)
    op1 = int(observation_tokens[2])
    left = _decode_number(int(observation_tokens[3]))
    right = _decode_number(int(observation_tokens[4]))
    state = _decode_number(int(observation_tokens[6]))
    op2 = int(observation_tokens[7])
    third = _decode_number(int(observation_tokens[8]))
    answer = _decode_number(int(observation_tokens[10]))
    try:
        expected_state = _record_state(spec, op1, left, right, op2)
        expected_answer = _record_answer(
            spec, op2, left, right, state, third
        )
    except (KeyError, ValueError):
        return False
    return state == expected_state and answer == expected_answer


def audit_dataset(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    checks: Dict[str, bool] = {}
    checks["row_alignment"] = (
        len(public_rows) == len(authority_rows)
        and {row["view_id"] for row in public_rows}
        == {row["view_id"] for row in authority_rows}
    )
    checks["public_field_firewall"] = all(
        not PROHIBITED_PUBLIC_FIELDS.intersection(row) for row in public_rows
    )
    checks["fixed_public_shapes"] = all(
        len(row["problem_tokens"]) == PROBLEM_LENGTH
        and len(row["observation_tokens"]) == OBSERVATION_LENGTH
        for row in public_rows
    )
    checks["input_vocabulary"] = all(
        all(
            0 <= int(token) < INPUT_VOCAB_SIZE
            for token in (*row["problem_tokens"], *row["observation_tokens"])
        )
        for row in public_rows
    )

    public_by_view = {row["view_id"]: row for row in public_rows}
    authorities_by_base: Dict[str, list[Mapping[str, Any]]] = {}
    for authority in authority_rows:
        authorities_by_base.setdefault(authority["base_id"], []).append(authority)
    checks["complete_variant_sets"] = all(
        {row["variant"] for row in rows} == set(VARIANTS)
        for rows in authorities_by_base.values()
    )
    checks["opaque_view_ids"] = all(
        not any(variant in row["view_id"] for variant in VARIANTS)
        for row in public_rows
    )
    checks["problem_pairing"] = all(
        len(
            {
                tuple(public_by_view[row["view_id"]]["problem_tokens"])
                for row in rows
            }
        )
        == 1
        for rows in authorities_by_base.values()
    )
    checks["surface_matched_observations"] = all(
        all(
            len(public_by_view[row["view_id"]]["observation_tokens"])
            == OBSERVATION_LENGTH
            and sum(
                token == marker
                for token in public_by_view[row["view_id"]]["observation_tokens"]
            )
            == 1
            for marker in (OBSERVE, FORMAL, STEP, RESULT, END)
        )
        for rows in authorities_by_base.values()
        for row in rows
        if row["variant"] != "no_observation"
    )
    checks["authority_recomputes"] = all(
        _recompute(row["latent"]) == (int(row["state"]), int(row["answer"]))
        for row in authority_rows
    )
    authority_by_view = {row["view_id"]: row for row in authority_rows}
    checks["formal_validity_reexecutes"] = all(
        (
            row["formal_validity"]
            == _record_is_formally_valid(
                row["latent"], public_by_view[row["view_id"]]["observation_tokens"]
            )
        )
        for row in authority_rows
        if row["variant"] != "no_observation"
    )
    checks["wrong_formalization_is_formally_valid_only"] = all(
        row["formal_validity"] is True and row["semantic_validity"] is False
        for row in authority_rows
        if row["variant"] == "wrong_formalization"
    )
    checks["valid_is_accepted"] = all(
        row["verification_label"] == VERIFY_LABELS["accept"]
        and row["route_label"] == ROUTE_LABELS["answer"]
        for row in authority_rows
        if row["variant"] == "valid"
    )
    checks["invalid_is_not_answered"] = all(
        row["route_label"] != ROUTE_LABELS["answer"]
        for row in authority_rows
        if row["variant"] not in ("valid",)
    )

    examples = training_examples(public_rows, authority_rows)
    checks["training_sequence_shape"] = all(
        len(row["tokens"]) == SEQUENCE_LENGTH for row in examples
    )
    checks["training_label_range"] = all(
        0 <= int(row["label"]) < OUTPUT_CLASSES for row in examples
    )
    target_counts = {
        target: sum(row["target"] == target for row in examples)
        for target in ("answer", "state", "verify", "route")
    }
    checks["all_targets_present"] = all(target_counts.values())
    return {
        "version": VERSION,
        "passed": all(checks.values()),
        "checks": checks,
        "public_rows": len(public_rows),
        "authority_rows": len(authority_rows),
        "base_worlds": len(authorities_by_base),
        "target_examples": target_counts,
        "audit_id": content_digest(
            {
                "version": VERSION,
                "checks": checks,
                "public_ids": [row["view_id"] for row in public_rows],
                "authority_ids": [row["view_id"] for row in authority_rows],
            }
        ),
    }


def _jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable M55 micro-data: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
) -> Mapping[str, Any]:
    counts = dict(DEFAULT_PER_FAMILY)
    if per_family_by_split is not None:
        counts.update(per_family_by_split)
    manifest: Dict[str, Any] = {
        "version": VERSION,
        "splits": {},
        "families": list(FAMILIES),
        "variants": list(VARIANTS),
    }
    split_audits = {}
    for split in SEEDS:
        public_rows, authority_rows = generate_split(
            split, per_family=counts[split]
        )
        audit = audit_dataset(public_rows, authority_rows)
        if not audit["passed"]:
            raise RuntimeError("M55 micro-data audit failed for %s" % split)
        public_text = _jsonl(public_rows)
        authority_text = _jsonl(authority_rows)
        public_name = "%s-public.jsonl" % split
        authority_name = "%s-authority.jsonl" % split
        _write_immutable(output / public_name, public_text)
        _write_immutable(output / authority_name, authority_text)
        manifest["splits"][split] = {
            "seed": SEEDS[split],
            "per_family": counts[split],
            "public_path": public_name,
            "authority_path": authority_name,
            "public_sha256": _sha256(public_text),
            "authority_sha256": _sha256(authority_text),
            "base_worlds": audit["base_worlds"],
            "views": audit["public_rows"],
            "examples": sum(audit["target_examples"].values()),
            "audit_id": audit["audit_id"],
        }
        split_audits[split] = audit
    manifest["manifest_id"] = content_digest(manifest)
    overall = {
        "version": VERSION,
        "passed": all(audit["passed"] for audit in split_audits.values()),
        "split_audits": split_audits,
        "manifest_id": manifest["manifest_id"],
    }
    overall["audit_id"] = content_digest(overall)
    _write_immutable(
        output / "manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    )
    _write_immutable(
        output / "audit.json", json.dumps(overall, indent=2, sort_keys=True) + "\n"
    )
    return {"manifest": manifest, "audit": overall}


def load_split(
    root: Path, split: str
) -> Tuple[Tuple[Mapping[str, Any], ...], Tuple[Mapping[str, Any], ...]]:
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    entry = manifest["splits"][split]

    def read_jsonl(path: Path) -> Tuple[Mapping[str, Any], ...]:
        return tuple(
            json.loads(line)
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        )

    public = read_jsonl(root / entry["public_path"])
    authority = read_jsonl(root / entry["authority_path"])
    if _sha256(_jsonl(public)) != entry["public_sha256"]:
        raise RuntimeError("public micro-data digest mismatch")
    if _sha256(_jsonl(authority)) != entry["authority_sha256"]:
        raise RuntimeError("authority micro-data digest mismatch")
    return public, authority
