from __future__ import annotations

import hashlib
import json
import random
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core import training_recipe_micro_world_v55 as v55


VERSION = "cognitive-core-calibrated-tool-trust-micro-world-v56"
SEEDS = {
    "capability_calibration": 56031,
    "learnability_development": 56101,
    "learnability_replication": 56701,
}
DEFAULT_PER_FAMILY = {
    "capability_calibration": 512,
    "learnability_development": 2048,
    "learnability_replication": 256,
}
FAMILIES = v55.FAMILIES
VARIANTS = (
    "absent_observation",
    "faithful_observation",
    "surface_matched_broken_state",
    "misleading_final_step",
    "wrong_tool_arguments",
    "incorrect_tool_response",
    "stale_observation",
    "contradictory_observation",
    "valid_certificate_for_wrong_formalization",
)

PAD = v55.PAD
CLS = v55.CLS
TARGET_ANSWER = v55.TARGET_ANSWER
TARGET_STATE = v55.TARGET_STATE
TARGET_EVIDENCE_VALIDITY = v55.TARGET_VERIFY
TARGET_TOOL_POLICY = v55.TARGET_ROUTE
META = 27
INPUT_VOCAB_SIZE = v55.INPUT_VOCAB_SIZE
PROBLEM_LENGTH = v55.PROBLEM_LENGTH
OBSERVATION_LENGTH = v55.OBSERVATION_LENGTH
SEQUENCE_LENGTH = v55.SEQUENCE_LENGTH

ANSWER_LABEL_BASE = 0
STATE_LABEL_BASE = 16
EVIDENCE_VALIDITY_LABEL_BASE = 32
TOOL_POLICY_LABEL_BASE = 35
OUTPUT_CLASSES = 40
EVIDENCE_VALIDITY_LABELS = {"accept": 0, "reject": 1, "retry": 2}
TOOL_POLICY_LABELS = {
    "answer": 0,
    "call": 1,
    "retry": 2,
    "stop": 3,
    "abstain": 4,
}

PROHIBITED_PUBLIC_FIELDS = {
    "answer",
    "state",
    "difficulty_bin",
    "formal_validity",
    "semantic_faithfulness",
    "epistemic_admissibility",
    "evidence_validity_label",
    "tool_policy_label",
    "model_adaptive_tool_necessity",
    "optimal_action",
    "variant",
    "latent",
}


def _modulus(spec: Mapping[str, Any]) -> int:
    return 2 if spec["family"] == "deductive_logic" else 16


def _changed(value: int, modulus: int, delta: int = 1) -> int:
    return (value + delta) % modulus


def _record(
    spec: Mapping[str, Any],
    *,
    op1: int | None = None,
    left: int | None = None,
    right: int | None = None,
    op2: int | None = None,
    third: int | None = None,
    state: int | None = None,
    answer: int | None = None,
) -> Tuple[int, ...]:
    active_op1 = int(spec["op1"] if op1 is None else op1)
    active_left = int(spec["left"] if left is None else left)
    active_right = int(spec["right"] if right is None else right)
    active_op2 = int(spec["op2"] if op2 is None else op2)
    active_third = int(spec["third"] if third is None else third)
    active_state = (
        v55._record_state(
            spec, active_op1, active_left, active_right, active_op2
        )
        if state is None
        else int(state)
    )
    active_answer = (
        v55._record_answer(
            spec,
            active_op2,
            active_left,
            active_right,
            active_state,
            active_third,
        )
        if answer is None
        else int(answer)
    )
    return v55._observation(
        active_op1,
        active_left,
        active_right,
        active_state,
        active_op2,
        active_third,
        active_answer,
    )


def _variant_observation(
    spec: Mapping[str, Any], variant: str
) -> Tuple[int, ...]:
    if variant == "absent_observation":
        return (PAD,) * OBSERVATION_LENGTH
    if variant == "faithful_observation":
        return _record(spec)

    modulus = _modulus(spec)
    state = int(spec["state"])
    answer = int(spec["answer"])
    if variant == "surface_matched_broken_state":
        wrong_state = _changed(state, modulus)
        return _record(spec, state=wrong_state)
    if variant == "misleading_final_step":
        return _record(spec, state=state, answer=_changed(answer, modulus))
    if variant == "wrong_tool_arguments":
        return _record(spec, left=_changed(int(spec["left"]), modulus))
    if variant == "incorrect_tool_response":
        return _record(spec, state=state, answer=_changed(answer, modulus, 2))
    if variant == "stale_observation":
        return _record(
            spec,
            left=_changed(int(spec["left"]), modulus, 3),
            right=_changed(int(spec["right"]), modulus, 5),
            third=_changed(int(spec["third"]), modulus, 7),
        )
    if variant == "contradictory_observation":
        return _record(
            spec,
            state=_changed(state, modulus),
            answer=answer,
        )
    if variant == "valid_certificate_for_wrong_formalization":
        (
            alternative,
            wrong_left,
            wrong_right,
            wrong_third,
            wrong_state,
        ) = v55._different_wrong_formalization(spec, state, answer)
        return _record(
            spec,
            op2=alternative,
            left=wrong_left,
            right=wrong_right,
            third=wrong_third,
            state=wrong_state,
        )
    raise ValueError("unknown V56 micro-world variant")


def _difficulty_bin(spec: Mapping[str, Any]) -> int:
    score = (
        int(spec["left"])
        + 2 * int(spec["right"])
        + 3 * int(spec["third"])
        + int(spec["op1"])
        + int(spec["op2"])
    )
    return score % 3


def _variant_authority(
    spec: Mapping[str, Any], variant: str, observation: Sequence[int]
) -> Mapping[str, Any]:
    if variant == "absent_observation":
        return {
            "formal_validity": None,
            "semantic_faithfulness": None,
            "epistemic_admissibility": None,
            "evidence_validity_label": None,
        }
    formal = v55._record_is_formally_valid(spec, observation)
    semantic = variant == "faithful_observation"
    if semantic:
        label = EVIDENCE_VALIDITY_LABELS["accept"]
    elif formal:
        label = EVIDENCE_VALIDITY_LABELS["retry"]
    else:
        label = EVIDENCE_VALIDITY_LABELS["reject"]
    return {
        "formal_validity": formal,
        "semantic_faithfulness": semantic,
        "epistemic_admissibility": semantic,
        "evidence_validity_label": label,
    }


def generate_split(
    split: str, per_family: int | None = None
) -> Tuple[Tuple[Mapping[str, Any], ...], Tuple[Mapping[str, Any], ...]]:
    if split not in SEEDS:
        raise ValueError("unknown V56 micro-world split")
    if per_family is None:
        per_family = DEFAULT_PER_FAMILY[split]
    if per_family <= 0:
        raise ValueError("per_family must be positive")

    public_rows = []
    authority_rows = []
    for family_index, family in enumerate(FAMILIES):
        rng = random.Random(SEEDS[split] + 1009 * family_index)
        for index in range(per_family):
            spec = v55._world_spec(family, rng)
            problem = v55._problem(
                family,
                int(spec["op1"]),
                int(spec["left"]),
                int(spec["right"]),
                int(spec["op2"]),
                int(spec["third"]),
                spec["extras"],
            )
            declared_tool_cost = rng.randrange(1, 4)
            reliability_bin = rng.randrange(3)
            tool_reliability = (0.65, 0.80, 0.95)[reliability_bin]
            remaining_budget = rng.randrange(7)
            tool_available = rng.random() < 0.8
            base_id = "w-" + content_digest(
                {
                    "version": VERSION,
                    "split": split,
                    "family": family,
                    "index": index,
                    "seed": SEEDS[split],
                }
            )[:20]
            for variant in VARIANTS:
                view_id = "v-" + content_digest(
                    {"version": VERSION, "base_id": base_id, "variant": variant}
                )[:20]
                observation = _variant_observation(spec, variant)
                public_rows.append(
                    {
                        "view_id": view_id,
                        "base_id": base_id,
                        "split": split,
                        "family": family,
                        "problem_tokens": list(problem),
                        "observation_tokens": list(observation),
                        "declared_tool_cost": declared_tool_cost,
                        "tool_reliability": tool_reliability,
                        "tool_reliability_bin": reliability_bin,
                        "remaining_budget": remaining_budget,
                        "tool_available": tool_available,
                    }
                )
                authority_rows.append(
                    {
                        "view_id": view_id,
                        "base_id": base_id,
                        "variant": variant,
                        "answer": int(spec["answer"]),
                        "state": int(spec["state"]),
                        "difficulty_bin": _difficulty_bin(spec),
                        "latent": {
                            key: (list(value) if isinstance(value, tuple) else value)
                            for key, value in spec.items()
                        },
                        **_variant_authority(spec, variant, observation),
                    }
                )
    return tuple(public_rows), tuple(authority_rows)


def estimate_capability_profile(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
    answer_predictions: Mapping[str, int],
    *,
    model_id: str,
    checkpoint_id: str,
) -> Mapping[str, Any]:
    public_by_view = {row["view_id"]: row for row in public_rows}
    grouped: Dict[str, Dict[str, int]] = {}
    used_view_ids = []
    for authority in authority_rows:
        if authority["variant"] != "absent_observation":
            continue
        view_id = str(authority["view_id"])
        if view_id not in answer_predictions:
            raise ValueError("missing closed-book prediction for %s" % view_id)
        public = public_by_view[view_id]
        key = "%s|%d" % (public["family"], int(authority["difficulty_bin"]))
        bucket = grouped.setdefault(key, {"correct": 0, "count": 0})
        bucket["count"] += 1
        bucket["correct"] += int(
            int(answer_predictions[view_id]) == int(authority["answer"])
        )
        used_view_ids.append(view_id)

    capabilities = {
        key: {
            **counts,
            "smoothed_success_probability": (
                counts["correct"] + 1
            )
            / (counts["count"] + 2),
        }
        for key, counts in sorted(grouped.items())
    }
    profile: Dict[str, Any] = {
        "version": VERSION,
        "purpose": "model_adaptive_tool_necessity",
        "model_id": model_id,
        "checkpoint_id": checkpoint_id,
        "split": "capability_calibration",
        "prediction_count": len(used_view_ids),
        "capabilities": capabilities,
        "used_view_ids_digest": content_digest(sorted(used_view_ids)),
    }
    profile["profile_id"] = content_digest(profile)
    return profile


def _capability_probability(
    public: Mapping[str, Any],
    authority: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> float:
    key = "%s|%d" % (public["family"], int(authority["difficulty_bin"]))
    try:
        return float(profile["capabilities"][key]["smoothed_success_probability"])
    except KeyError as error:
        raise ValueError("capability profile is missing %s" % key) from error


def materialize_policy_labels(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
    capability_profile: Mapping[str, Any],
) -> Tuple[Mapping[str, Any], ...]:
    public_by_view = {row["view_id"]: row for row in public_rows}
    materialized = []
    for authority in authority_rows:
        public = public_by_view[authority["view_id"]]
        direct = _capability_probability(public, authority, capability_profile)
        cost = int(public["declared_tool_cost"])
        budget = int(public["remaining_budget"])
        available = bool(public["tool_available"])
        tool_value = float(public["tool_reliability"]) - 0.05 * cost
        beneficial = available and budget >= cost and tool_value > direct + 0.05
        variant = str(authority["variant"])
        if variant == "faithful_observation":
            action = "answer"
        elif variant == "absent_observation":
            if beneficial:
                action = "call"
            elif direct >= 0.70:
                action = "answer"
            else:
                action = "abstain"
        elif beneficial and budget >= 2 * cost:
            action = "retry"
        elif direct >= 0.70:
            action = "stop"
        else:
            action = "abstain"
        materialized.append(
            {
                **authority,
                "tool_policy_action": action,
                "tool_policy_label": TOOL_POLICY_LABELS[action],
                "capability_profile_id": capability_profile["profile_id"],
                "closed_book_success_probability": direct,
                "tool_expected_value": tool_value,
                "model_adaptive_tool_necessity": beneficial,
            }
        )
    return tuple(materialized)


def _model_tokens(public: Mapping[str, Any], target_token: int) -> Tuple[int, ...]:
    meta = (
        META,
        v55._number(int(public["declared_tool_cost"])),
        v55._number(int(public["tool_reliability_bin"])),
        v55._number(int(public["remaining_budget"])),
        v55._number(int(bool(public["tool_available"]))),
    )
    tokens = (
        CLS,
        target_token,
        *tuple(public["problem_tokens"]),
        *tuple(public["observation_tokens"]),
        *meta,
    )
    tokens = tokens + (PAD,) * (SEQUENCE_LENGTH - len(tokens))
    if len(tokens) != SEQUENCE_LENGTH:
        raise ValueError("V56 model sequence overflow")
    return tokens


def closed_book_answer_examples(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    public_by_view = {row["view_id"]: row for row in public_rows}
    examples = []
    for authority in authority_rows:
        if authority["variant"] != "absent_observation":
            continue
        public = public_by_view[authority["view_id"]]
        examples.append(
            {
                "example_id": "cb-"
                + content_digest(
                    {
                        "version": VERSION,
                        "view_id": public["view_id"],
                        "target": "closed_book_answer",
                    }
                )[:20],
                "view_id": public["view_id"],
                "family": public["family"],
                "target": "answer",
                "tokens": _model_tokens(public, TARGET_ANSWER),
                "label": ANSWER_LABEL_BASE + int(authority["answer"]),
                "variant": authority["variant"],
            }
        )
    return tuple(examples)


def training_examples(
    public_rows: Sequence[Mapping[str, Any]],
    materialized_authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    authorities = {row["view_id"]: row for row in materialized_authority_rows}
    examples = []
    for public in public_rows:
        authority = authorities[public["view_id"]]
        targets = [
            (
                "answer",
                TARGET_ANSWER,
                ANSWER_LABEL_BASE + int(authority["answer"]),
            ),
            (
                "state",
                TARGET_STATE,
                STATE_LABEL_BASE + int(authority["state"]),
            ),
            (
                "tool_policy",
                TARGET_TOOL_POLICY,
                TOOL_POLICY_LABEL_BASE + int(authority["tool_policy_label"]),
            ),
        ]
        if authority["variant"] != "absent_observation":
            targets.append(
                (
                    "evidence_validity",
                    TARGET_EVIDENCE_VALIDITY,
                    EVIDENCE_VALIDITY_LABEL_BASE
                    + int(authority["evidence_validity_label"]),
                )
            )
        for target_name, target_token, label in targets:
            tokens = _model_tokens(public, target_token)
            examples.append(
                {
                    "example_id": "e-"
                    + content_digest(
                        {
                            "version": VERSION,
                            "view_id": public["view_id"],
                            "target": target_name,
                            "capability_profile_id": authority[
                                "capability_profile_id"
                            ],
                        }
                    )[:20],
                    "view_id": public["view_id"],
                    "family": public["family"],
                    "target": target_name,
                    "tokens": tokens,
                    "label": label,
                    "variant": authority["variant"],
                }
            )
    return tuple(examples)


def audit_dataset(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    checks: Dict[str, bool] = {}
    checks["row_alignment"] = (
        len(public_rows) == len(authority_rows)
        and {row["view_id"] for row in public_rows}
        == {row["view_id"] for row in authority_rows}
    )
    checks["public_field_firewall"] = all(
        not PROHIBITED_PUBLIC_FIELDS.intersection(row) for row in public_rows
    )
    checks["fixed_public_shapes"] = all(
        len(row["problem_tokens"]) == PROBLEM_LENGTH
        and len(row["observation_tokens"]) == OBSERVATION_LENGTH
        for row in public_rows
    )
    checks["valid_public_metadata"] = all(
        1 <= int(row["declared_tool_cost"]) <= 3
        and int(row["tool_reliability_bin"]) in (0, 1, 2)
        and 0 <= int(row["remaining_budget"]) <= 6
        for row in public_rows
    )

    public_by_view = {row["view_id"]: row for row in public_rows}
    grouped: Dict[str, list[Mapping[str, Any]]] = {}
    for row in authority_rows:
        grouped.setdefault(str(row["base_id"]), []).append(row)
    checks["complete_variant_sets"] = all(
        {row["variant"] for row in rows} == set(VARIANTS)
        for rows in grouped.values()
    )
    checks["opaque_view_ids"] = all(
        not any(variant in str(row["view_id"]) for variant in VARIANTS)
        for row in public_rows
    )
    checks["matched_nonobservation_fields"] = all(
        len(
            {
                (
                    tuple(public_by_view[row["view_id"]]["problem_tokens"]),
                    int(public_by_view[row["view_id"]]["declared_tool_cost"]),
                    float(public_by_view[row["view_id"]]["tool_reliability"]),
                    int(public_by_view[row["view_id"]]["remaining_budget"]),
                    bool(public_by_view[row["view_id"]]["tool_available"]),
                )
                for row in rows
            }
        )
        == 1
        for rows in grouped.values()
    )
    checks["surface_matched_observations"] = all(
        len(public_by_view[row["view_id"]]["observation_tokens"])
        == OBSERVATION_LENGTH
        for row in authority_rows
    )
    checks["formal_validity_reexecutes"] = all(
        row["formal_validity"]
        == v55._record_is_formally_valid(
            row["latent"], public_by_view[row["view_id"]]["observation_tokens"]
        )
        for row in authority_rows
        if row["variant"] != "absent_observation"
    )
    formally_valid_semantic_failures = {
        "wrong_tool_arguments",
        "stale_observation",
        "valid_certificate_for_wrong_formalization",
    }
    checks["formal_semantic_separation"] = all(
        row["formal_validity"] is True
        and row["semantic_faithfulness"] is False
        and row["epistemic_admissibility"] is False
        for row in authority_rows
        if row["variant"] in formally_valid_semantic_failures
    )
    checks["faithful_is_admissible"] = all(
        row["formal_validity"] is True
        and row["semantic_faithfulness"] is True
        and row["epistemic_admissibility"] is True
        and row["evidence_validity_label"]
        == EVIDENCE_VALIDITY_LABELS["accept"]
        for row in authority_rows
        if row["variant"] == "faithful_observation"
    )
    checks["raw_data_has_no_policy_labels"] = all(
        "tool_policy_label" not in row for row in authority_rows
    )
    return {
        "version": VERSION,
        "passed": all(checks.values()),
        "checks": checks,
        "public_rows": len(public_rows),
        "authority_rows": len(authority_rows),
        "base_worlds": len(grouped),
        "audit_id": content_digest(
            {
                "version": VERSION,
                "checks": checks,
                "public_ids": [row["view_id"] for row in public_rows],
                "authority_ids": [row["view_id"] for row in authority_rows],
            }
        ),
    }


def _jsonl(rows: Iterable[Mapping[str, Any]]) -> str:
    return "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows)


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V56 micro-data: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
) -> Mapping[str, Any]:
    counts = dict(DEFAULT_PER_FAMILY)
    if per_family_by_split is not None:
        counts.update(per_family_by_split)
    manifest: Dict[str, Any] = {
        "version": VERSION,
        "purpose": "raw_worlds_before_model_adaptive_policy_labeling",
        "splits": {},
        "families": list(FAMILIES),
        "variants": list(VARIANTS),
        "capability_profile_frozen_separately": True,
    }
    split_audits = {}
    for split in SEEDS:
        public_rows, authority_rows = generate_split(split, counts[split])
        audit = audit_dataset(public_rows, authority_rows)
        if not audit["passed"]:
            raise RuntimeError("V56 micro-data audit failed for %s" % split)
        public_text = _jsonl(public_rows)
        authority_text = _jsonl(authority_rows)
        public_name = "%s-public.jsonl" % split
        authority_name = "%s-authority.jsonl" % split
        _write_immutable(output / public_name, public_text)
        _write_immutable(output / authority_name, authority_text)
        manifest["splits"][split] = {
            "seed": SEEDS[split],
            "per_family": counts[split],
            "public_file": public_name,
            "public_sha256": _sha256(public_text),
            "authority_file": authority_name,
            "authority_sha256": _sha256(authority_text),
            "rows": len(public_rows),
            "base_worlds": audit["base_worlds"],
            "audit_id": audit["audit_id"],
        }
        split_audits[split] = audit
    manifest["manifest_id"] = content_digest(manifest)
    aggregate_audit: Dict[str, Any] = {
        "version": VERSION,
        "passed": all(audit["passed"] for audit in split_audits.values()),
        "manifest_id": manifest["manifest_id"],
        "split_audits": split_audits,
    }
    aggregate_audit["audit_id"] = content_digest(aggregate_audit)
    _write_immutable(
        output / "manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    )
    _write_immutable(
        output / "audit.json",
        json.dumps(aggregate_audit, indent=2, sort_keys=True) + "\n",
    )
    return {"manifest": manifest, "audit": aggregate_audit}


def load_split(
    root: Path, split: str
) -> Tuple[Tuple[Mapping[str, Any], ...], Tuple[Mapping[str, Any], ...]]:
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    split_manifest = manifest["splits"][split]

    def load_rows(name: str) -> Tuple[Mapping[str, Any], ...]:
        return tuple(
            json.loads(line)
            for line in (root / name).read_text(encoding="utf-8").splitlines()
            if line.strip()
        )

    public = load_rows(split_manifest["public_file"])
    authority = load_rows(split_manifest["authority_file"])
    if _sha256(_jsonl(public)) != split_manifest["public_sha256"]:
        raise RuntimeError("V56 public split digest mismatch")
    if _sha256(_jsonl(authority)) != split_manifest["authority_sha256"]:
        raise RuntimeError("V56 authority split digest mismatch")
    return public, authority


__all__ = [
    "ANSWER_LABEL_BASE",
    "DEFAULT_PER_FAMILY",
    "EVIDENCE_VALIDITY_LABEL_BASE",
    "EVIDENCE_VALIDITY_LABELS",
    "FAMILIES",
    "INPUT_VOCAB_SIZE",
    "OUTPUT_CLASSES",
    "SEQUENCE_LENGTH",
    "STATE_LABEL_BASE",
    "TARGET_ANSWER",
    "TARGET_EVIDENCE_VALIDITY",
    "TARGET_STATE",
    "TARGET_TOOL_POLICY",
    "TOOL_POLICY_LABEL_BASE",
    "TOOL_POLICY_LABELS",
    "VARIANTS",
    "VERSION",
    "audit_dataset",
    "closed_book_answer_examples",
    "estimate_capability_profile",
    "freeze_dataset",
    "generate_split",
    "load_split",
    "materialize_policy_labels",
    "training_examples",
]
