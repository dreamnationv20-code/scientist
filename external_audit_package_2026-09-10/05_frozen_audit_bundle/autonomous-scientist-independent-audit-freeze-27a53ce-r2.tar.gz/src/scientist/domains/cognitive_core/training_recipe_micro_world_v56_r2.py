from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Mapping, Tuple

from scientist.domains.cognitive_core import training_recipe_micro_world_v56 as base


VERSION = "cognitive-core-calibrated-tool-trust-micro-world-v56-r2"
SEEDS = {
    "capability_calibration": 56071,
    "learnability_development": 56201,
    "learnability_replication": 56801,
}
DEFAULT_PER_FAMILY = dict(base.DEFAULT_PER_FAMILY)


def _fixed_variant_observation(
    spec: Mapping[str, Any], variant: str
) -> Tuple[int, ...]:
    if variant != "incorrect_tool_response":
        return _ORIGINAL_VARIANT_OBSERVATION(spec, variant)
    modulus = base._modulus(spec)
    return base._record(
        spec,
        state=int(spec["state"]),
        answer=base._changed(int(spec["answer"]), modulus, 1),
    )


_ORIGINAL_VARIANT_OBSERVATION = base._variant_observation


@contextmanager
def _r2_context() -> Iterator[None]:
    original_version = base.VERSION
    original_seeds = base.SEEDS
    original_defaults = base.DEFAULT_PER_FAMILY
    original_variant = base._variant_observation
    try:
        base.VERSION = VERSION
        base.SEEDS = SEEDS
        base.DEFAULT_PER_FAMILY = DEFAULT_PER_FAMILY
        base._variant_observation = _fixed_variant_observation
        yield
    finally:
        base.VERSION = original_version
        base.SEEDS = original_seeds
        base.DEFAULT_PER_FAMILY = original_defaults
        base._variant_observation = original_variant


def generate_split(split: str, per_family: int | None = None):
    with _r2_context():
        return base.generate_split(split, per_family)


def audit_dataset(public_rows, authority_rows):
    with _r2_context():
        return base.audit_dataset(public_rows, authority_rows)


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
):
    with _r2_context():
        return base.freeze_dataset(output, per_family_by_split)


load_split = base.load_split


__all__ = [
    "DEFAULT_PER_FAMILY",
    "SEEDS",
    "VERSION",
    "audit_dataset",
    "freeze_dataset",
    "generate_split",
    "load_split",
]
