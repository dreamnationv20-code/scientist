from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Mapping

from scientist.domains.cognitive_core import training_recipe_micro_world_v56 as base
from scientist.domains.cognitive_core.training_recipe_micro_world_v56_r2 import (
    _fixed_variant_observation,
)


VERSION = "cognitive-core-calibrated-tool-trust-micro-world-v56-r3"
SEEDS = {
    "capability_calibration": 56091,
    "learnability_development": 56301,
    "learnability_replication": 56901,
}
DEFAULT_PER_FAMILY = dict(base.DEFAULT_PER_FAMILY)


@contextmanager
def _r3_context() -> Iterator[None]:
    original_version = base.VERSION
    original_seeds = base.SEEDS
    original_defaults = base.DEFAULT_PER_FAMILY
    original_variant = base._variant_observation
    try:
        base.VERSION = VERSION
        base.SEEDS = SEEDS
        base.DEFAULT_PER_FAMILY = DEFAULT_PER_FAMILY
        base._variant_observation = _fixed_variant_observation
        yield
    finally:
        base.VERSION = original_version
        base.SEEDS = original_seeds
        base.DEFAULT_PER_FAMILY = original_defaults
        base._variant_observation = original_variant


def generate_split(split: str, per_family: int | None = None):
    with _r3_context():
        return base.generate_split(split, per_family)


def audit_dataset(public_rows, authority_rows):
    with _r3_context():
        return base.audit_dataset(public_rows, authority_rows)


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
):
    with _r3_context():
        return base.freeze_dataset(output, per_family_by_split)


load_split = base.load_split


__all__ = [
    "DEFAULT_PER_FAMILY",
    "SEEDS",
    "VERSION",
    "audit_dataset",
    "freeze_dataset",
    "generate_split",
    "load_split",
]
