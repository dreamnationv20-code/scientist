from __future__ import annotations

import math
from collections import Counter, defaultdict
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core import training_recipe_micro_world_v56 as base
from scientist.domains.cognitive_core.training_recipe_micro_world_v56_r2 import (
    _fixed_variant_observation,
)


VERSION = "cognitive-core-uncertainty-aware-control-micro-world-v57"
SEEDS = {
    "capability_calibration": 57031,
    "learnability_development": 57101,
    "learnability_replication": 57701,
}
DEFAULT_PER_FAMILY = dict(base.DEFAULT_PER_FAMILY)

FAMILIES = base.FAMILIES
VARIANTS = base.VARIANTS
INPUT_VOCAB_SIZE = base.INPUT_VOCAB_SIZE
SEQUENCE_LENGTH = base.SEQUENCE_LENGTH
TARGET_ANSWER = base.TARGET_ANSWER
TARGET_STATE = base.TARGET_STATE
TARGET_EVIDENCE_VALIDITY = base.TARGET_EVIDENCE_VALIDITY
TARGET_TOOL_POLICY = base.TARGET_TOOL_POLICY
ANSWER_LABEL_BASE = base.ANSWER_LABEL_BASE
STATE_LABEL_BASE = base.STATE_LABEL_BASE
EVIDENCE_VALIDITY_LABEL_BASE = base.EVIDENCE_VALIDITY_LABEL_BASE
TOOL_POLICY_LABEL_BASE = base.TOOL_POLICY_LABEL_BASE
OUTPUT_CLASSES = base.OUTPUT_CLASSES
TOOL_POLICY_LABELS = base.TOOL_POLICY_LABELS

CAPABILITY_NOT_APPLICABLE = 31
CAPABILITY_CODE_BASE = 32
DIRECT_THRESHOLD = 0.70
TOOL_ADVANTAGE_MARGIN = 0.05


@contextmanager
def _v57_context() -> Iterator[None]:
    original_version = base.VERSION
    original_seeds = base.SEEDS
    original_defaults = base.DEFAULT_PER_FAMILY
    original_variant = base._variant_observation
    try:
        base.VERSION = VERSION
        base.SEEDS = SEEDS
        base.DEFAULT_PER_FAMILY = DEFAULT_PER_FAMILY
        base._variant_observation = _fixed_variant_observation
        yield
    finally:
        base.VERSION = original_version
        base.SEEDS = original_seeds
        base.DEFAULT_PER_FAMILY = original_defaults
        base._variant_observation = original_variant


def generate_split(split: str, per_family: int | None = None):
    with _v57_context():
        return base.generate_split(split, per_family)


def audit_dataset(public_rows, authority_rows):
    with _v57_context():
        return base.audit_dataset(public_rows, authority_rows)


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
):
    with _v57_context():
        return base.freeze_dataset(output, per_family_by_split)


load_split = base.load_split


def _wilson_interval(correct: int, count: int, z: float = 1.96) -> Tuple[float, float]:
    if count <= 0:
        raise ValueError("Wilson interval requires a positive count")
    probability = correct / count
    denominator = 1.0 + z * z / count
    centre = (probability + z * z / (2.0 * count)) / denominator
    radius = (
        z
        * math.sqrt(
            probability * (1.0 - probability) / count
            + z * z / (4.0 * count * count)
        )
        / denominator
    )
    return max(0.0, centre - radius), min(1.0, centre + radius)


def estimate_capability_profile(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
    answer_predictions: Mapping[str, int],
    *,
    model_id: str,
    checkpoint_id: str,
) -> Mapping[str, Any]:
    public_by_view = {row["view_id"]: row for row in public_rows}
    grouped: Dict[str, Dict[str, int]] = {}
    used_view_ids = []
    for authority in authority_rows:
        if authority["variant"] != "absent_observation":
            continue
        view_id = str(authority["view_id"])
        if view_id not in answer_predictions:
            raise ValueError("missing closed-book prediction for %s" % view_id)
        public = public_by_view[view_id]
        key = "%s|%d" % (public["family"], int(authority["difficulty_bin"]))
        bucket = grouped.setdefault(key, {"correct": 0, "count": 0})
        bucket["count"] += 1
        bucket["correct"] += int(
            int(answer_predictions[view_id]) == int(authority["answer"])
        )
        used_view_ids.append(view_id)

    capabilities = {}
    for key, counts in sorted(grouped.items()):
        lower, upper = _wilson_interval(counts["correct"], counts["count"])
        capabilities[key] = {
            **counts,
            "smoothed_success_probability": (
                counts["correct"] + 1
            )
            / (counts["count"] + 2),
            "wilson_lower_95": lower,
            "wilson_upper_95": upper,
        }
    profile: Dict[str, Any] = {
        "version": VERSION,
        "purpose": "uncertainty_aware_model_adaptive_tool_control",
        "model_id": model_id,
        "checkpoint_id": checkpoint_id,
        "split": "capability_calibration",
        "prediction_count": len(used_view_ids),
        "capabilities": capabilities,
        "used_view_ids_digest": content_digest(sorted(used_view_ids)),
    }
    profile["profile_id"] = content_digest(profile)
    return profile


def _capability_bucket(
    public: Mapping[str, Any],
    authority: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> Mapping[str, Any]:
    key = "%s|%d" % (public["family"], int(authority["difficulty_bin"]))
    try:
        return profile["capabilities"][key]
    except KeyError as error:
        raise ValueError("capability profile is missing %s" % key) from error


def capability_code(lower: float, upper: float) -> Tuple[int, float, bool]:
    upper_decile = min(10, max(1, int(math.ceil(upper * 10.0 - 1.0e-12))))
    robust_direct = lower >= DIRECT_THRESHOLD
    code = (upper_decile - 1) + 10 * int(robust_direct)
    return code, upper_decile / 10.0, robust_direct


def materialize_policy_labels(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
    capability_profile: Mapping[str, Any],
) -> Tuple[Mapping[str, Any], ...]:
    public_by_view = {row["view_id"]: row for row in public_rows}
    materialized = []
    for authority in authority_rows:
        public = public_by_view[authority["view_id"]]
        bucket = _capability_bucket(public, authority, capability_profile)
        lower = float(bucket["wilson_lower_95"])
        upper = float(bucket["wilson_upper_95"])
        code, conservative_upper, robust_direct = capability_code(lower, upper)
        cost = int(public["declared_tool_cost"])
        budget = int(public["remaining_budget"])
        available = bool(public["tool_available"])
        tool_value = float(public["tool_reliability"]) - 0.05 * cost
        robust_tool_benefit = (
            available
            and budget >= cost
            and tool_value > conservative_upper + TOOL_ADVANTAGE_MARGIN
        )
        variant = str(authority["variant"])
        if variant == "faithful_observation":
            action = "answer"
        elif variant == "absent_observation":
            if robust_tool_benefit:
                action = "call"
            elif robust_direct:
                action = "answer"
            else:
                action = "abstain"
        elif robust_tool_benefit and budget >= 2 * cost:
            action = "retry"
        elif robust_direct:
            action = "stop"
        else:
            action = "abstain"
        materialized.append(
            {
                **authority,
                "tool_policy_action": action,
                "tool_policy_label": TOOL_POLICY_LABELS[action],
                "capability_profile_id": capability_profile["profile_id"],
                "capability_interval_lower": lower,
                "capability_interval_upper": upper,
                "capability_upper_decile": conservative_upper,
                "capability_code": code,
                "robust_direct_competence": robust_direct,
                "tool_expected_value": tool_value,
                "robust_tool_benefit": robust_tool_benefit,
            }
        )
    return tuple(materialized)


def _model_tokens(
    public: Mapping[str, Any],
    target_token: int,
    capability_token: int,
) -> Tuple[int, ...]:
    meta = (
        base.META,
        base.v55._number(int(public["declared_tool_cost"])),
        base.v55._number(int(public["tool_reliability_bin"])),
        base.v55._number(int(public["remaining_budget"])),
        base.v55._number(int(bool(public["tool_available"]))),
        capability_token,
    )
    tokens = (
        base.CLS,
        target_token,
        *tuple(public["problem_tokens"]),
        *tuple(public["observation_tokens"]),
        *meta,
    )
    if len(tokens) != SEQUENCE_LENGTH:
        raise ValueError("V57 model sequence length changed")
    if not all(0 <= int(token) < INPUT_VOCAB_SIZE for token in tokens):
        raise ValueError("V57 model token outside vocabulary")
    return tokens


def closed_book_answer_examples(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    public_by_view = {row["view_id"]: row for row in public_rows}
    examples = []
    for authority in authority_rows:
        if authority["variant"] != "absent_observation":
            continue
        public = public_by_view[authority["view_id"]]
        examples.append(
            {
                "example_id": "cb-"
                + content_digest(
                    {
                        "version": VERSION,
                        "view_id": public["view_id"],
                        "target": "closed_book_answer",
                    }
                )[:20],
                "view_id": public["view_id"],
                "family": public["family"],
                "target": "answer",
                "tokens": _model_tokens(
                    public, TARGET_ANSWER, CAPABILITY_NOT_APPLICABLE
                ),
                "label": ANSWER_LABEL_BASE + int(authority["answer"]),
                "variant": authority["variant"],
            }
        )
    return tuple(examples)


def training_examples(
    public_rows: Sequence[Mapping[str, Any]],
    materialized_authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    authorities = {row["view_id"]: row for row in materialized_authority_rows}
    examples = []
    for public in public_rows:
        authority = authorities[public["view_id"]]
        targets = [
            ("answer", TARGET_ANSWER, ANSWER_LABEL_BASE + int(authority["answer"])),
            ("state", TARGET_STATE, STATE_LABEL_BASE + int(authority["state"])),
            (
                "tool_policy",
                TARGET_TOOL_POLICY,
                TOOL_POLICY_LABEL_BASE + int(authority["tool_policy_label"]),
            ),
        ]
        if authority["variant"] != "absent_observation":
            targets.append(
                (
                    "evidence_validity",
                    TARGET_EVIDENCE_VALIDITY,
                    EVIDENCE_VALIDITY_LABEL_BASE
                    + int(authority["evidence_validity_label"]),
                )
            )
        for target_name, target_token, label in targets:
            capability_token = CAPABILITY_NOT_APPLICABLE
            if target_name == "tool_policy":
                capability_token = CAPABILITY_CODE_BASE + int(
                    authority["capability_code"]
                )
            examples.append(
                {
                    "example_id": "e-"
                    + content_digest(
                        {
                            "version": VERSION,
                            "view_id": public["view_id"],
                            "target": target_name,
                            "capability_profile_id": authority[
                                "capability_profile_id"
                            ],
                        }
                    )[:20],
                    "view_id": public["view_id"],
                    "family": public["family"],
                    "target": target_name,
                    "tokens": _model_tokens(public, target_token, capability_token),
                    "label": label,
                    "variant": authority["variant"],
                }
            )
    return tuple(examples)


def audit_materialized_policy(
    public_rows: Sequence[Mapping[str, Any]],
    materialized_rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    public_by_view = {row["view_id"]: row for row in public_rows}
    labels_by_tokens: Dict[Tuple[int, ...], Counter[int]] = defaultdict(Counter)
    action_counts: Counter[str] = Counter()
    for authority in materialized_rows:
        public = public_by_view[authority["view_id"]]
        tokens = _model_tokens(
            public,
            TARGET_TOOL_POLICY,
            CAPABILITY_CODE_BASE + int(authority["capability_code"]),
        )
        labels_by_tokens[tokens][int(authority["tool_policy_label"])] += 1
        action_counts[str(authority["tool_policy_action"])] += 1
    total = len(materialized_rows)
    bayes_correct = sum(max(counts.values()) for counts in labels_by_tokens.values())
    checks = {
        "all_five_actions_present": set(action_counts) == set(TOOL_POLICY_LABELS),
        "exact_input_labels_identifiable": bayes_correct == total,
        "no_exact_input_conflicts": all(
            len(counts) == 1 for counts in labels_by_tokens.values()
        ),
        "capability_code_in_vocabulary": all(
            CAPABILITY_CODE_BASE <= CAPABILITY_CODE_BASE + int(row["capability_code"])
            < INPUT_VOCAB_SIZE
            for row in materialized_rows
        ),
        "point_estimate_not_used_by_oracle": all(
            "closed_book_success_probability" not in row
            for row in materialized_rows
        ),
    }
    result: Dict[str, Any] = {
        "version": VERSION,
        "rows": total,
        "action_counts": dict(sorted(action_counts.items())),
        "exact_input_bayes_accuracy": bayes_correct / total,
        "unique_exact_inputs": len(labels_by_tokens),
        "checks": checks,
        "passed": all(checks.values()),
    }
    result["audit_id"] = content_digest(result)
    return result


__all__ = [
    "CAPABILITY_CODE_BASE",
    "CAPABILITY_NOT_APPLICABLE",
    "DEFAULT_PER_FAMILY",
    "SEEDS",
    "VERSION",
    "audit_dataset",
    "audit_materialized_policy",
    "capability_code",
    "closed_book_answer_examples",
    "estimate_capability_profile",
    "freeze_dataset",
    "generate_split",
    "load_split",
    "materialize_policy_labels",
    "training_examples",
]
