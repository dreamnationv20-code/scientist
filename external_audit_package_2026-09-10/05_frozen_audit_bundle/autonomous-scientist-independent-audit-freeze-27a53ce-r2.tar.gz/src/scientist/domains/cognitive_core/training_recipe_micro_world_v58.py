from __future__ import annotations

import random
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Iterator, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core import training_recipe_micro_world_v56 as raw
from scientist.domains.cognitive_core import training_recipe_micro_world_v57 as v57
from scientist.domains.cognitive_core.training_recipe_micro_world_v56_r2 import (
    _fixed_variant_observation,
)


VERSION = "cognitive-core-relational-control-micro-world-v58"
SEEDS = {
    "capability_calibration": 59031,
    "learnability_development": 59101,
    "learnability_replication": 59701,
}
DEFAULT_PER_FAMILY = dict(raw.DEFAULT_PER_FAMILY)
NUISANCE_SEED = 58991

FAMILIES = raw.FAMILIES
VARIANTS = raw.VARIANTS
INPUT_VOCAB_SIZE = raw.INPUT_VOCAB_SIZE
SEQUENCE_LENGTH = raw.SEQUENCE_LENGTH
TARGETS = ("answer", "state", "evidence_validity", "tool_policy")
TARGET_LABEL_BASES = {
    "answer": raw.ANSWER_LABEL_BASE,
    "state": raw.STATE_LABEL_BASE,
    "evidence_validity": raw.EVIDENCE_VALIDITY_LABEL_BASE,
    "tool_policy": raw.TOOL_POLICY_LABEL_BASE,
}


@contextmanager
def _v58_context() -> Iterator[None]:
    original_version = raw.VERSION
    original_seeds = raw.SEEDS
    original_defaults = raw.DEFAULT_PER_FAMILY
    original_variant = raw._variant_observation
    try:
        raw.VERSION = VERSION
        raw.SEEDS = SEEDS
        raw.DEFAULT_PER_FAMILY = DEFAULT_PER_FAMILY
        raw._variant_observation = _fixed_variant_observation
        yield
    finally:
        raw.VERSION = original_version
        raw.SEEDS = original_seeds
        raw.DEFAULT_PER_FAMILY = original_defaults
        raw._variant_observation = original_variant


def generate_split(split: str, per_family: int | None = None):
    with _v58_context():
        return raw.generate_split(split, per_family)


def audit_dataset(public_rows, authority_rows):
    with _v58_context():
        return raw.audit_dataset(public_rows, authority_rows)


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
):
    with _v58_context():
        return raw.freeze_dataset(output, per_family_by_split)


load_split = raw.load_split
capability_code = v57.capability_code
materialize_policy_labels = v57.materialize_policy_labels


def estimate_capability_profile(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
    answer_predictions: Mapping[str, int],
    *,
    model_id: str,
    checkpoint_id: str,
) -> Mapping[str, Any]:
    profile = dict(
        v57.estimate_capability_profile(
            public_rows,
            authority_rows,
            answer_predictions,
            model_id=model_id,
            checkpoint_id=checkpoint_id,
        )
    )
    profile.pop("profile_id", None)
    profile["version"] = VERSION
    profile["profile_id"] = content_digest(profile)
    return profile


def _permuted_nuisance_labels(
    rows: Sequence[Mapping[str, Any]], target: str
) -> Mapping[str, int]:
    ordered = sorted(rows, key=lambda row: str(row["example_id"]))
    semantic = [int(row["label"]) for row in ordered]
    indices = list(range(len(ordered)))
    random.Random(NUISANCE_SEED + 1009 * TARGETS.index(target)).shuffle(indices)
    return {
        str(row["example_id"]): semantic[source]
        for row, source in zip(ordered, indices)
    }


def attach_nuisance_controls(
    examples: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    mappings = {
        target: _permuted_nuisance_labels(
            tuple(row for row in examples if row["target"] == target), target
        )
        for target in TARGETS
    }
    result = []
    for row in examples:
        target = str(row["target"])
        semantic_label = int(row["label"])
        nuisance_label = int(mappings[target][str(row["example_id"])])
        base = TARGET_LABEL_BASES[target]
        nuisance_class = nuisance_label - base
        tokens = list(row["tokens"])
        tokens[-6] = raw.v55._number(nuisance_class)
        result.append(
            {
                **row,
                "tokens": tuple(tokens),
                "semantic_label": semantic_label,
                "nuisance_label": nuisance_label,
                "nuisance_class": nuisance_class,
                "label": semantic_label,
            }
        )
    return tuple(result)


def closed_book_answer_examples(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    return attach_nuisance_controls(
        v57.closed_book_answer_examples(public_rows, authority_rows)
    )


def training_examples(
    public_rows: Sequence[Mapping[str, Any]],
    materialized_authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    return attach_nuisance_controls(
        v57.training_examples(public_rows, materialized_authority_rows)
    )


def audit_nuisance_controls(
    examples: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    checks: Dict[str, bool] = {}
    for target in TARGETS:
        rows = tuple(row for row in examples if row["target"] == target)
        semantic = sorted(int(row["semantic_label"]) for row in rows)
        nuisance = sorted(int(row["nuisance_label"]) for row in rows)
        checks[f"{target}_histogram_exact"] = semantic == nuisance
        checks[f"{target}_visible_copy"] = all(
            int(row["tokens"][-6]) == raw.v55._number(int(row["nuisance_class"]))
            for row in rows
        )
        checks[f"{target}_permutation_active"] = any(
            int(row["semantic_label"]) != int(row["nuisance_label"])
            for row in rows
        )
    checks["fixed_sequence_length"] = all(
        len(row["tokens"]) == SEQUENCE_LENGTH for row in examples
    )
    checks["nuisance_is_not_arm_identity"] = all(
        "arm" not in row and "factors" not in row for row in examples
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "rows": len(examples),
        "checks": checks,
        "passed": all(checks.values()),
    }
    result["audit_id"] = content_digest(result)
    return result


__all__ = [
    "DEFAULT_PER_FAMILY",
    "SEEDS",
    "VERSION",
    "attach_nuisance_controls",
    "audit_dataset",
    "audit_nuisance_controls",
    "closed_book_answer_examples",
    "estimate_capability_profile",
    "freeze_dataset",
    "generate_split",
    "load_split",
    "materialize_policy_labels",
    "training_examples",
]
