from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

from scientist.domains.cognitive_core import training_recipe_micro_world_v58 as v58


VERSION = "cognitive-core-robust-promotion-micro-world-v59"
SEEDS = {
    "capability_calibration": 60031,
    "learnability_development": 60101,
    "learnability_replication": 60701,
}
DEFAULT_PER_FAMILY = dict(v58.DEFAULT_PER_FAMILY)
NUISANCE_SEED = 59991

FAMILIES = v58.FAMILIES
VARIANTS = v58.VARIANTS
INPUT_VOCAB_SIZE = v58.INPUT_VOCAB_SIZE
SEQUENCE_LENGTH = v58.SEQUENCE_LENGTH
TARGETS = v58.TARGETS
TARGET_LABEL_BASES = v58.TARGET_LABEL_BASES


@contextmanager
def _v59_context() -> Iterator[None]:
    original_version = v58.VERSION
    original_seeds = v58.SEEDS
    original_defaults = v58.DEFAULT_PER_FAMILY
    original_nuisance_seed = v58.NUISANCE_SEED
    try:
        v58.VERSION = VERSION
        v58.SEEDS = SEEDS
        v58.DEFAULT_PER_FAMILY = DEFAULT_PER_FAMILY
        v58.NUISANCE_SEED = NUISANCE_SEED
        yield
    finally:
        v58.VERSION = original_version
        v58.SEEDS = original_seeds
        v58.DEFAULT_PER_FAMILY = original_defaults
        v58.NUISANCE_SEED = original_nuisance_seed


def generate_split(split: str, per_family: int | None = None):
    with _v59_context():
        return v58.generate_split(split, per_family)


def audit_dataset(public_rows, authority_rows):
    with _v59_context():
        return v58.audit_dataset(public_rows, authority_rows)


def freeze_dataset(
    output: Path,
    per_family_by_split: Mapping[str, int] | None = None,
):
    with _v59_context():
        return v58.freeze_dataset(output, per_family_by_split)


load_split = v58.load_split
capability_code = v58.capability_code
materialize_policy_labels = v58.materialize_policy_labels


def estimate_capability_profile(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
    answer_predictions: Mapping[str, int],
    *,
    model_id: str,
    checkpoint_id: str,
) -> Mapping[str, Any]:
    with _v59_context():
        return v58.estimate_capability_profile(
            public_rows,
            authority_rows,
            answer_predictions,
            model_id=model_id,
            checkpoint_id=checkpoint_id,
        )


def attach_nuisance_controls(examples: Sequence[Mapping[str, Any]]):
    with _v59_context():
        return v58.attach_nuisance_controls(examples)


def closed_book_answer_examples(public_rows, authority_rows):
    with _v59_context():
        return v58.closed_book_answer_examples(public_rows, authority_rows)


def training_examples(public_rows, materialized_authority_rows):
    with _v59_context():
        return v58.training_examples(public_rows, materialized_authority_rows)


def audit_nuisance_controls(examples):
    with _v59_context():
        return v58.audit_nuisance_controls(examples)


__all__ = [
    "DEFAULT_PER_FAMILY",
    "SEEDS",
    "VERSION",
    "attach_nuisance_controls",
    "audit_dataset",
    "audit_nuisance_controls",
    "closed_book_answer_examples",
    "estimate_capability_profile",
    "freeze_dataset",
    "generate_split",
    "load_split",
    "materialize_policy_labels",
    "training_examples",
]
