from __future__ import annotations

import json
import math
import platform
import random
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    EVIDENCE_VALIDITY_LABEL_BASE,
    INPUT_VOCAB_SIZE,
    OUTPUT_CLASSES,
    SEQUENCE_LENGTH,
    STATE_LABEL_BASE,
    TARGET_ANSWER,
    TARGET_EVIDENCE_VALIDITY,
    TARGET_STATE,
    TARGET_TOOL_POLICY,
    TOOL_POLICY_LABEL_BASE,
    closed_book_answer_examples,
    estimate_capability_profile,
    load_split,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_smoke_v55 import (
    SmokeConfig,
)


VERSION = "cognitive-core-calibrated-tool-trust-mlx-learnability-v56-r1"
TARGETS = ("answer", "state", "evidence_validity", "tool_policy")
TARGET_BATCH_FRACTIONS = {target: 0.25 for target in TARGETS}
TARGET_LABEL_RANGES = {
    "answer": (0, STATE_LABEL_BASE),
    "state": (STATE_LABEL_BASE, EVIDENCE_VALIDITY_LABEL_BASE),
    "evidence_validity": (
        EVIDENCE_VALIDITY_LABEL_BASE,
        TOOL_POLICY_LABEL_BASE,
    ),
    "tool_policy": (TOOL_POLICY_LABEL_BASE, OUTPUT_CLASSES),
}
QUALIFICATION_GATES = {
    "minimum_answer_accuracy": 0.70,
    "minimum_answer_class_recall": 0.20,
    "minimum_state_accuracy": 0.75,
    "minimum_state_class_recall": 0.20,
    "minimum_evidence_validity_accuracy": 0.80,
    "minimum_evidence_validity_class_recall": 0.65,
    "minimum_tool_policy_accuracy": 0.80,
    "minimum_tool_policy_class_recall": 0.65,
    "minimum_worst_family_accuracy": 0.60,
    "minimum_parse_rate": 0.99,
    "minimum_action_schema_validity": 0.99,
}


class V56SeparatedHeadTransformer(nn.Module):
    """Shared encoder with fixed target-local normalization for V56."""

    def __init__(self, config: SmokeConfig) -> None:
        super().__init__()
        self.token_embedding = nn.Embedding(INPUT_VOCAB_SIZE, config.width)
        self.position_embedding = nn.Embedding(SEQUENCE_LENGTH, config.width)
        self.layers = [
            nn.TransformerEncoderLayer(
                dims=config.width,
                num_heads=config.heads,
                mlp_dims=4 * config.width,
                dropout=0.0,
                norm_first=True,
            )
            for _ in range(config.layers)
        ]
        self.norm = nn.LayerNorm(config.width)
        self.answer_head = nn.Linear(config.width, 16)
        self.state_head = nn.Linear(config.width, 16)
        self.evidence_validity_head = nn.Linear(config.width, 3)
        self.tool_policy_head = nn.Linear(config.width, 5)

    def __call__(self, tokens: mx.array) -> mx.array:
        positions = mx.arange(tokens.shape[1])
        hidden = self.token_embedding(tokens) + self.position_embedding(positions)
        for layer in self.layers:
            hidden = layer(hidden, None)
        pooled = self.norm(hidden[:, 0, :])
        logits = mx.concatenate(
            (
                self.answer_head(pooled),
                self.state_head(pooled),
                self.evidence_validity_head(pooled),
                self.tool_policy_head(pooled),
            ),
            axis=-1,
        )
        target = tokens[:, 1:2]
        classes = mx.arange(OUTPUT_CLASSES)[None, :]
        allowed = (
            ((target == TARGET_ANSWER) & (classes < STATE_LABEL_BASE))
            | (
                (target == TARGET_STATE)
                & (classes >= STATE_LABEL_BASE)
                & (classes < EVIDENCE_VALIDITY_LABEL_BASE)
            )
            | (
                (target == TARGET_EVIDENCE_VALIDITY)
                & (classes >= EVIDENCE_VALIDITY_LABEL_BASE)
                & (classes < TOOL_POLICY_LABEL_BASE)
            )
            | (
                (target == TARGET_TOOL_POLICY)
                & (classes >= TOOL_POLICY_LABEL_BASE)
            )
        )
        return mx.where(allowed, logits, mx.array(-1.0e9, dtype=logits.dtype))


def _arrays(
    examples: Sequence[Mapping[str, Any]],
) -> Tuple[mx.array, mx.array]:
    return (
        mx.array([row["tokens"] for row in examples], dtype=mx.int32),
        mx.array([row["label"] for row in examples], dtype=mx.int32),
    )


def _balanced_rows(
    examples: Sequence[Mapping[str, Any]], count: int, seed: int
) -> Tuple[Mapping[str, Any], ...]:
    rng = random.Random(seed)
    by_label: Dict[int, list[Mapping[str, Any]]] = {}
    for row in examples:
        by_label.setdefault(int(row["label"]), []).append(row)
    labels = sorted(by_label)
    base = count // len(labels)
    remainder = count % len(labels)
    result = []
    for label_index, label in enumerate(labels):
        sample_count = base + int(label_index < remainder)
        candidates = by_label[label]
        result.extend(
            candidates[rng.randrange(len(candidates))]
            for _ in range(sample_count)
        )
    rng.shuffle(result)
    return tuple(result)


def _balanced_batch(
    examples_by_target: Mapping[str, Sequence[Mapping[str, Any]]],
    config: SmokeConfig,
    step: int,
) -> Tuple[Mapping[str, Any], ...]:
    result = []
    for target_index, target in enumerate(TARGETS):
        count = int(config.batch_size * TARGET_BATCH_FRACTIONS[target])
        result.extend(
            _balanced_rows(
                examples_by_target[target],
                count,
                config.data_seed + 104729 * step + 1009 * target_index,
            )
        )
    rng = random.Random(config.data_seed + 130363 * step)
    rng.shuffle(result)
    if len(result) != config.batch_size:
        raise AssertionError("V56 target allocation changed the batch size")
    return tuple(result)


def _predict(
    model: V56SeparatedHeadTransformer,
    examples: Sequence[Mapping[str, Any]],
    batch_size: int = 512,
) -> Tuple[int, ...]:
    predictions = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        tokens, _ = _arrays(examples[start : start + batch_size])
        values = mx.argmax(model(tokens), axis=-1)
        mx.eval(values)
        predictions.extend(int(value) for value in values.tolist())
    model.train()
    return tuple(predictions)


def evaluate(
    model: V56SeparatedHeadTransformer,
    examples: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    predictions = _predict(model, examples)
    by_target: Dict[str, Dict[str, Any]] = {}
    by_family: Dict[str, list[bool]] = {}
    by_target_variant: Dict[str, Dict[str, list[bool]]] = {}
    for row, prediction in zip(examples, predictions):
        target = str(row["target"])
        correct = prediction == int(row["label"])
        target_row = by_target.setdefault(
            target,
            {"correct": 0, "total": 0, "class_correct": {}, "class_total": {}},
        )
        target_row["correct"] += int(correct)
        target_row["total"] += 1
        label = int(row["label"])
        target_row["class_correct"][label] = (
            target_row["class_correct"].get(label, 0) + int(correct)
        )
        target_row["class_total"][label] = (
            target_row["class_total"].get(label, 0) + 1
        )
        by_family.setdefault(str(row["family"]), []).append(correct)
        by_target_variant.setdefault(target, {}).setdefault(
            str(row["variant"]), []
        ).append(correct)

    target_metrics = {}
    for target, row in sorted(by_target.items()):
        recalls = {
            str(label): row["class_correct"].get(label, 0) / total
            for label, total in sorted(row["class_total"].items())
        }
        target_metrics[target] = {
            "accuracy": row["correct"] / row["total"],
            "minimum_class_recall": min(recalls.values()),
            "class_recall": recalls,
            "count": row["total"],
        }
    return {
        "by_target": target_metrics,
        "by_family": {
            family: sum(values) / len(values)
            for family, values in sorted(by_family.items())
        },
        "by_target_variant": {
            target: {
                variant: sum(values) / len(values)
                for variant, values in sorted(variants.items())
            }
            for target, variants in sorted(by_target_variant.items())
        },
        "response_parse_rate": 1.0,
        "action_schema_validity": 1.0,
        "overall_accuracy": sum(
            prediction == int(row["label"])
            for row, prediction in zip(examples, predictions)
        )
        / len(examples),
    }


def adjudicate(metrics: Mapping[str, Any]) -> Mapping[str, Any]:
    targets = metrics["by_target"]
    observations = {
        "answer_accuracy": targets["answer"]["accuracy"],
        "answer_class_recall": targets["answer"]["minimum_class_recall"],
        "state_accuracy": targets["state"]["accuracy"],
        "state_class_recall": targets["state"]["minimum_class_recall"],
        "evidence_validity_accuracy": targets["evidence_validity"]["accuracy"],
        "evidence_validity_class_recall": targets["evidence_validity"][
            "minimum_class_recall"
        ],
        "tool_policy_accuracy": targets["tool_policy"]["accuracy"],
        "tool_policy_class_recall": targets["tool_policy"][
            "minimum_class_recall"
        ],
        "worst_family_accuracy": min(metrics["by_family"].values()),
        "response_parse_rate": metrics["response_parse_rate"],
        "action_schema_validity": metrics["action_schema_validity"],
    }
    gate_to_observation = {
        "minimum_answer_accuracy": "answer_accuracy",
        "minimum_answer_class_recall": "answer_class_recall",
        "minimum_state_accuracy": "state_accuracy",
        "minimum_state_class_recall": "state_class_recall",
        "minimum_evidence_validity_accuracy": "evidence_validity_accuracy",
        "minimum_evidence_validity_class_recall": (
            "evidence_validity_class_recall"
        ),
        "minimum_tool_policy_accuracy": "tool_policy_accuracy",
        "minimum_tool_policy_class_recall": "tool_policy_class_recall",
        "minimum_worst_family_accuracy": "worst_family_accuracy",
        "minimum_parse_rate": "response_parse_rate",
        "minimum_action_schema_validity": "action_schema_validity",
    }
    checks = {
        observation: observations[observation] >= QUALIFICATION_GATES[gate]
        for gate, observation in gate_to_observation.items()
    }
    passed = all(checks.values())
    return {
        "passed": passed,
        "checks": checks,
        "observations": observations,
        "gates": QUALIFICATION_GATES,
        "next_action": (
            "authorize_v56_micro_factorial"
            if passed
            else "halt_factorial_and_diagnose_unlearned_v56_targets"
        ),
    }


def _optimizer(config: SmokeConfig, steps: int) -> optim.Optimizer:
    learning_rate = (
        optim.cosine_decay(
            config.learning_rate,
            steps,
            end=config.final_learning_rate,
        )
        if config.learning_rate_schedule == "cosine"
        else config.learning_rate
    )
    return optim.AdamW(learning_rate=learning_rate, weight_decay=0.0001)


def _parameter_count(model: nn.Module) -> int:
    return sum(math.prod(array.shape) for _, array in tree_flatten(model.parameters()))


def _train_answer_calibrator(
    development: Sequence[Mapping[str, Any]],
    calibration: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    calibration_steps: int,
) -> Tuple[V56SeparatedHeadTransformer, Mapping[str, Any]]:
    mx.random.seed(config.model_seed)
    model = V56SeparatedHeadTransformer(config)
    mx.eval(model.parameters())
    optimizer = _optimizer(config, calibration_steps)

    def loss_fn(
        active_model: V56SeparatedHeadTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    for step in range(1, calibration_steps + 1):
        batch = _balanced_rows(
            development,
            config.batch_size,
            config.data_seed + 15485863 * step,
        )
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())

    development_metrics = evaluate(model, development)
    calibration_predictions = _predict(model, calibration)
    prediction_map = {
        row["view_id"]: prediction
        for row, prediction in zip(calibration, calibration_predictions)
    }
    checkpoint_id = content_digest(
        {
            "version": VERSION,
            "role": "closed_book_capability_calibrator",
            "model_seed": config.model_seed,
            "data_seed": config.data_seed,
            "steps": calibration_steps,
            "last_loss": last_loss,
            "predictions": prediction_map,
        }
    )
    return model, {
        "checkpoint_id": checkpoint_id,
        "steps": calibration_steps,
        "last_loss": last_loss,
        "development_metrics": development_metrics,
        "predictions": prediction_map,
    }


def _development_monitor(
    examples_by_target: Mapping[str, Sequence[Mapping[str, Any]]],
) -> Tuple[Mapping[str, Any], ...]:
    monitor = []
    for target in TARGETS:
        ordered = sorted(
            examples_by_target[target],
            key=lambda row: content_digest(
                {
                    "version": VERSION,
                    "monitor": "v56-fixed-development-monitor-v1",
                    "example_id": row["example_id"],
                }
            ),
        )
        monitor.extend(ordered[: min(1152, len(ordered))])
    return tuple(monitor)


def run_learnability(
    dataset_root: Path,
    config: SmokeConfig,
    *,
    calibration_steps: int = 1200,
) -> Mapping[str, Any]:
    if calibration_steps <= 0:
        raise ValueError("calibration_steps must be positive")
    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    started = time.monotonic()

    development_public, development_authority = load_split(
        dataset_root, "learnability_development"
    )
    calibration_public, calibration_authority = load_split(
        dataset_root, "capability_calibration"
    )
    base_development = closed_book_answer_examples(
        development_public, development_authority
    )
    base_calibration = closed_book_answer_examples(
        calibration_public, calibration_authority
    )
    calibrator, calibration_result = _train_answer_calibrator(
        base_development,
        base_calibration,
        config,
        calibration_steps,
    )
    parameter_count = _parameter_count(calibrator)
    capability_profile = estimate_capability_profile(
        calibration_public,
        calibration_authority,
        calibration_result.pop("predictions"),
        model_id="v56-shared-encoder-%d" % parameter_count,
        checkpoint_id=calibration_result["checkpoint_id"],
    )
    del calibrator

    materialized_development = materialize_policy_labels(
        development_public,
        development_authority,
        capability_profile,
    )
    development = training_examples(
        development_public, materialized_development
    )
    by_target = {
        target: tuple(row for row in development if row["target"] == target)
        for target in TARGETS
    }
    if not all(by_target.values()):
        raise RuntimeError("V56 learnability data is missing a target")
    monitor = _development_monitor(by_target)

    mx.random.seed(config.model_seed + 1)
    model = V56SeparatedHeadTransformer(config)
    mx.eval(model.parameters())
    if _parameter_count(model) != parameter_count:
        raise AssertionError("calibrator and learnability models differ in size")
    optimizer = _optimizer(config, config.steps)

    def loss_fn(
        active_model: V56SeparatedHeadTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints = [{"step": 0, "loss": None, "metrics": evaluate(model, monitor)}]
    selected_step = None
    last_loss = float("nan")
    for step in range(1, config.steps + 1):
        batch = _balanced_batch(by_target, config, step)
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
        if step % config.checkpoint_interval == 0 or step == config.steps:
            metrics = evaluate(model, monitor)
            decision = adjudicate(metrics)
            checkpoints.append(
                {
                    "step": step,
                    "loss": last_loss,
                    "metrics": metrics,
                    "development_qualification": decision,
                }
            )
            if decision["passed"]:
                selected_step = step
                break

    development_metrics = checkpoints[-1]["metrics"]
    replication_opened = selected_step is not None
    replication = ()
    if replication_opened:
        replication_public, replication_authority = load_split(
            dataset_root, "learnability_replication"
        )
        materialized_replication = materialize_policy_labels(
            replication_public,
            replication_authority,
            capability_profile,
        )
        replication = training_examples(
            replication_public, materialized_replication
        )
        final_metrics = evaluate(model, replication)
    else:
        final_metrics = development_metrics
    decision = adjudicate(final_metrics)

    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": (
            "a332f05d176d4b9fa5244d621de6aedfe566ad11fdd9048bff91f150066819df"
        ),
        "architecture": {
            "shared_encoder": True,
            "target_local_output_heads": True,
            "head_sizes": {
                "answer": 16,
                "state": 16,
                "evidence_validity": 3,
                "tool_policy": 5,
            },
            "cross_target_softmax_competition": False,
            "target_batch_fractions": TARGET_BATCH_FRACTIONS,
        },
        "config": config.as_dict(),
        "calibration_steps": calibration_steps,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "parameter_count": parameter_count,
        "capability_profile": capability_profile,
        "calibration_result": calibration_result,
        "development_examples": len(development),
        "development_monitor_examples": len(monitor),
        "replication_examples": len(replication),
        "elapsed_seconds": time.monotonic() - started,
        "selected_step": selected_step,
        "selection_rule": (
            "earliest development checkpoint passing all prospective V56 gates"
        ),
        "replication_opened": replication_opened,
        "hardware": platform.platform(),
        "framework": "mlx",
        "checkpoints": checkpoints,
        "development_metrics": development_metrics,
        "metrics": final_metrics,
        "decision": decision,
    }
    result["run_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V56 result: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json", json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    _write_immutable(
        output / "capability-profile.json",
        json.dumps(result["capability_profile"], indent=2, sort_keys=True) + "\n",
    )
    metrics = result["metrics"]
    decision = result["decision"]
    scope = (
        "Held-out replication metrics"
        if result["replication_opened"]
        else "Development metrics; replication not opened"
    )
    lines = [
        "# Cognitive-core V56 calibrated-tool-trust learnability",
        "",
        "- Qualification passed: **%s**" % decision["passed"],
        "- Next action: `%s`" % decision["next_action"],
        "- Parameters: **%s**" % format(result["parameter_count"], ","),
        "- Capability profile: `%s`" % result["capability_profile"]["profile_id"],
        "- Selected step: **%s**" % result["selected_step"],
        "- Training time: **%.2f seconds**" % result["elapsed_seconds"],
        "- Run ID: `%s`" % result["run_id"],
        "",
        "## %s" % scope,
        "",
        "| Target | Accuracy | Minimum class recall |",
        "|---|---:|---:|",
    ]
    for target, row in sorted(metrics["by_target"].items()):
        lines.append(
            "| %s | %.1f%% | %.1f%% |"
            % (target, 100 * row["accuracy"], 100 * row["minimum_class_recall"])
        )
    lines.extend(("", "## Family accuracy", "", "| Family | Accuracy |", "|---|---:|"))
    for family, accuracy in sorted(metrics["by_family"].items()):
        lines.append("| %s | %.1f%% |" % (family, 100 * accuracy))
    lines.extend(
        (
            "",
            "## Boundary",
            "",
            "This run tests delivery and class coverage only. The capability "
            "profile was estimated on a disjoint closed-book split before policy "
            "labels were materialized. No factorial treatment effect, natural-language "
            "transfer, or 3B authorization follows unless the held-out gate passes.",
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", "\n".join(lines))


__all__ = [
    "QUALIFICATION_GATES",
    "SmokeConfig",
    "TARGET_LABEL_RANGES",
    "V56SeparatedHeadTransformer",
    "_balanced_batch",
    "adjudicate",
    "evaluate",
    "run_learnability",
    "write_result",
]
