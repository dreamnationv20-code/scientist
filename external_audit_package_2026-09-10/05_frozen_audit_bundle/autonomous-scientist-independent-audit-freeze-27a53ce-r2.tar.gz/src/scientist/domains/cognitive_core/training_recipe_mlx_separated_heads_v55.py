from __future__ import annotations

import json
import math
import platform
import random
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_micro_world_v55 import (
    INPUT_VOCAB_SIZE,
    OUTPUT_CLASSES,
    ROUTE_LABEL_BASE,
    SEQUENCE_LENGTH,
    STATE_LABEL_BASE,
    TARGET_ANSWER,
    TARGET_ROUTE,
    TARGET_STATE,
    TARGET_VERIFY,
    VERIFY_LABEL_BASE,
    load_split,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_smoke_v55 import (
    QUALIFICATION_GATES,
    SmokeConfig,
    adjudicate,
    write_result,
)


VERSION = "cognitive-core-training-recipe-mlx-separated-heads-v55-r8"
TARGET_BATCH_FRACTIONS = {
    "answer": 0.25,
    "state": 0.25,
    "verify": 0.25,
    "route": 0.25,
}
TARGET_LABEL_RANGES = {
    "answer": (0, STATE_LABEL_BASE),
    "state": (STATE_LABEL_BASE, VERIFY_LABEL_BASE),
    "verify": (VERIFY_LABEL_BASE, ROUTE_LABEL_BASE),
    "route": (ROUTE_LABEL_BASE, OUTPUT_CLASSES),
}


class SeparatedHeadProtocolTransformer(nn.Module):
    """Shared symbolic encoder with task-local normalized softmax heads."""

    def __init__(self, config: SmokeConfig) -> None:
        super().__init__()
        self.token_embedding = nn.Embedding(INPUT_VOCAB_SIZE, config.width)
        self.position_embedding = nn.Embedding(SEQUENCE_LENGTH, config.width)
        self.layers = [
            nn.TransformerEncoderLayer(
                dims=config.width,
                num_heads=config.heads,
                mlp_dims=4 * config.width,
                dropout=0.0,
                norm_first=True,
            )
            for _ in range(config.layers)
        ]
        self.norm = nn.LayerNorm(config.width)
        self.answer_head = nn.Linear(config.width, 16)
        self.state_head = nn.Linear(config.width, 16)
        self.verify_head = nn.Linear(config.width, 4)
        self.route_head = nn.Linear(config.width, 4)

    def __call__(self, tokens: mx.array) -> mx.array:
        positions = mx.arange(tokens.shape[1])
        hidden = self.token_embedding(tokens) + self.position_embedding(positions)
        for layer in self.layers:
            hidden = layer(hidden, None)
        pooled = self.norm(hidden[:, 0, :])
        logits = mx.concatenate(
            (
                self.answer_head(pooled),
                self.state_head(pooled),
                self.verify_head(pooled),
                self.route_head(pooled),
            ),
            axis=-1,
        )
        target = tokens[:, 1:2]
        classes = mx.arange(OUTPUT_CLASSES)[None, :]
        allowed = (
            ((target == TARGET_ANSWER) & (classes < STATE_LABEL_BASE))
            | (
                (target == TARGET_STATE)
                & (classes >= STATE_LABEL_BASE)
                & (classes < VERIFY_LABEL_BASE)
            )
            | (
                (target == TARGET_VERIFY)
                & (classes >= VERIFY_LABEL_BASE)
                & (classes < ROUTE_LABEL_BASE)
            )
            | ((target == TARGET_ROUTE) & (classes >= ROUTE_LABEL_BASE))
        )
        return mx.where(allowed, logits, mx.array(-1.0e9, dtype=logits.dtype))


def _arrays(
    examples: Sequence[Mapping[str, Any]],
) -> Tuple[mx.array, mx.array]:
    return (
        mx.array([row["tokens"] for row in examples], dtype=mx.int32),
        mx.array([row["label"] for row in examples], dtype=mx.int32),
    )


def _balanced_batch(
    examples_by_target: Mapping[str, Sequence[Mapping[str, Any]]],
    config: SmokeConfig,
    step: int,
) -> Tuple[Mapping[str, Any], ...]:
    rng = random.Random(config.data_seed + 104729 * step)
    result = []
    for target in ("answer", "state", "verify", "route"):
        per_target = int(config.batch_size * TARGET_BATCH_FRACTIONS[target])
        by_label: Dict[int, list[Mapping[str, Any]]] = {}
        for row in examples_by_target[target]:
            by_label.setdefault(int(row["label"]), []).append(row)
        labels = sorted(by_label)
        base = per_target // len(labels)
        remainder = per_target % len(labels)
        for label_index, label in enumerate(labels):
            count = base + int(label_index < remainder)
            candidates = by_label[label]
            result.extend(
                candidates[rng.randrange(len(candidates))] for _ in range(count)
            )
    rng.shuffle(result)
    if len(result) != config.batch_size:
        raise AssertionError("target allocation changed the batch size")
    return tuple(result)


def _predict(
    model: SeparatedHeadProtocolTransformer,
    examples: Sequence[Mapping[str, Any]],
    batch_size: int = 512,
) -> Tuple[int, ...]:
    predictions = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        tokens, _ = _arrays(examples[start : start + batch_size])
        values = mx.argmax(model(tokens), axis=-1)
        mx.eval(values)
        predictions.extend(int(value) for value in values.tolist())
    model.train()
    return tuple(predictions)


def evaluate(
    model: SeparatedHeadProtocolTransformer,
    examples: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    predictions = _predict(model, examples)
    by_target: Dict[str, Dict[str, Any]] = {}
    by_family: Dict[str, list[bool]] = {}
    by_target_variant: Dict[str, Dict[str, list[bool]]] = {}
    for row, prediction in zip(examples, predictions):
        target = str(row["target"])
        correct = prediction == int(row["label"])
        target_row = by_target.setdefault(
            target,
            {"correct": 0, "total": 0, "class_correct": {}, "class_total": {}},
        )
        target_row["correct"] += int(correct)
        target_row["total"] += 1
        label = int(row["label"])
        target_row["class_correct"][label] = (
            target_row["class_correct"].get(label, 0) + int(correct)
        )
        target_row["class_total"][label] = (
            target_row["class_total"].get(label, 0) + 1
        )
        by_family.setdefault(str(row["family"]), []).append(correct)
        by_target_variant.setdefault(target, {}).setdefault(
            str(row["variant"]), []
        ).append(correct)

    target_metrics = {}
    for target, row in sorted(by_target.items()):
        recalls = {
            str(label): row["class_correct"].get(label, 0) / total
            for label, total in sorted(row["class_total"].items())
        }
        target_metrics[target] = {
            "accuracy": row["correct"] / row["total"],
            "minimum_class_recall": min(recalls.values()),
            "class_recall": recalls,
            "count": row["total"],
        }
    return {
        "by_target": target_metrics,
        "by_family": {
            family: sum(values) / len(values)
            for family, values in sorted(by_family.items())
        },
        "by_target_variant": {
            target: {
                variant: sum(values) / len(values)
                for variant, values in sorted(variants.items())
            }
            for target, variants in sorted(by_target_variant.items())
        },
        "overall_accuracy": sum(
            prediction == int(row["label"])
            for row, prediction in zip(examples, predictions)
        )
        / len(examples),
    }


def run_smoke(dataset_root: Path, config: SmokeConfig) -> Mapping[str, Any]:
    development_public, development_authority = load_split(
        dataset_root, "micro_development"
    )
    development = training_examples(development_public, development_authority)
    monitor_limit = min(4608, len(development))
    monitor = tuple(
        sorted(
            development,
            key=lambda row: content_digest(
                {
                    "tokens": list(row["tokens"]),
                    "label": row["label"],
                    "target": row["target"],
                    "monitor": "m55-fixed-development-monitor-v1",
                }
            ),
        )[:monitor_limit]
    )
    by_target = {
        target: tuple(row for row in development if row["target"] == target)
        for target in ("answer", "state", "verify", "route")
    }
    if not all(by_target.values()):
        raise RuntimeError("M55 smoke training is missing a target family")

    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    mx.random.seed(config.model_seed)
    model = SeparatedHeadProtocolTransformer(config)
    mx.eval(model.parameters())
    parameter_count = sum(
        math.prod(array.shape) for _, array in tree_flatten(model.parameters())
    )
    learning_rate = (
        optim.cosine_decay(
            config.learning_rate,
            config.steps,
            end=config.final_learning_rate,
        )
        if config.learning_rate_schedule == "cosine"
        else config.learning_rate
    )
    optimizer = optim.AdamW(learning_rate=learning_rate, weight_decay=0.0001)

    def loss_fn(
        active_model: SeparatedHeadProtocolTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints = []
    started = time.monotonic()
    initial = evaluate(model, monitor)
    checkpoints.append({"step": 0, "loss": None, "metrics": initial})
    last_loss = float("nan")
    selected_step = None
    for step in range(1, config.steps + 1):
        batch = _balanced_batch(by_target, config, step)
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
        if step % config.checkpoint_interval == 0 or step == config.steps:
            checkpoint_metrics = evaluate(model, monitor)
            checkpoint_decision = adjudicate(checkpoint_metrics)
            checkpoints.append(
                {
                    "step": step,
                    "loss": last_loss,
                    "metrics": checkpoint_metrics,
                    "development_qualification": checkpoint_decision,
                }
            )
            if checkpoint_decision["passed"]:
                selected_step = step
                break

    elapsed = time.monotonic() - started
    development_metrics = checkpoints[-1]["metrics"]
    replication_opened = selected_step is not None
    replication = ()
    if replication_opened:
        replication_public, replication_authority = load_split(
            dataset_root, "micro_replication"
        )
        replication = training_examples(replication_public, replication_authority)
        final_metrics = evaluate(model, replication)
    else:
        final_metrics = development_metrics
    decision = adjudicate(final_metrics)
    result = {
        "version": VERSION,
        "architecture_intervention": {
            "shared_encoder": True,
            "target_separated_heads": True,
            "cross_target_softmax_competition": False,
            "target_batch_fractions": TARGET_BATCH_FRACTIONS,
            "frozen_gates": QUALIFICATION_GATES,
        },
        "config": config.as_dict(),
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "parameter_count": parameter_count,
        "development_examples": len(development),
        "development_monitor_examples": len(monitor),
        "replication_examples": len(replication),
        "elapsed_seconds": elapsed,
        "selected_step": selected_step,
        "selection_rule": "earliest_development_checkpoint_passing_all_frozen_gates",
        "replication_opened": replication_opened,
        "hardware": platform.platform(),
        "framework": "mlx",
        "checkpoints": checkpoints,
        "development_metrics": development_metrics,
        "metrics": final_metrics,
        "decision": decision,
    }
    result["run_id"] = content_digest(result)
    return result


__all__ = [
    "SeparatedHeadProtocolTransformer",
    "SmokeConfig",
    "TARGET_BATCH_FRACTIONS",
    "TARGET_LABEL_RANGES",
    "VERSION",
    "_balanced_batch",
    "evaluate",
    "run_smoke",
    "write_result",
]
