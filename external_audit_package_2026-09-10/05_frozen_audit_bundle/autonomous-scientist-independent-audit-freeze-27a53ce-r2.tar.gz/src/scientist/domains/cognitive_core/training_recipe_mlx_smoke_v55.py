from __future__ import annotations

import json
import math
import platform
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_micro_world_v55 import (
    INPUT_VOCAB_SIZE,
    OUTPUT_CLASSES,
    SEQUENCE_LENGTH,
    load_split,
    training_examples,
)


VERSION = "cognitive-core-training-recipe-mlx-learnability-v55-r7"
TARGET_BATCH_FRACTIONS = {
    "answer": 0.25,
    "state": 0.375,
    "verify": 0.1875,
    "route": 0.1875,
}
QUALIFICATION_GATES = {
    "minimum_answer_accuracy": 0.70,
    "minimum_state_accuracy": 0.75,
    "minimum_verify_accuracy": 0.80,
    "minimum_route_accuracy": 0.80,
    "minimum_verify_class_recall": 0.65,
    "minimum_route_class_recall": 0.65,
    "minimum_family_accuracy": 0.60,
}


@dataclass(frozen=True)
class SmokeConfig:
    width: int = 96
    layers: int = 2
    heads: int = 4
    steps: int = 6000
    batch_size: int = 128
    learning_rate: float = 0.001
    final_learning_rate: float = 0.0001
    learning_rate_schedule: str = "cosine"
    model_seed: int = 55031
    data_seed: int = 55041
    checkpoint_interval: int = 200
    compute_device: str = "gpu"

    def __post_init__(self) -> None:
        if self.width <= 0 or self.width % self.heads:
            raise ValueError("width must be positive and divisible by heads")
        if min(self.layers, self.steps, self.batch_size) <= 0:
            raise ValueError("training dimensions must be positive")
        if self.batch_size % 16:
            raise ValueError("batch size must be divisible by sixteen")
        if self.compute_device not in ("cpu", "gpu"):
            raise ValueError("compute_device must be cpu or gpu")
        if self.learning_rate_schedule not in ("constant", "cosine"):
            raise ValueError("unsupported learning-rate schedule")
        if not 0.0 <= self.final_learning_rate <= self.learning_rate:
            raise ValueError("final learning rate must be in [0, initial]")

    def as_dict(self) -> Mapping[str, Any]:
        return {
            "width": self.width,
            "layers": self.layers,
            "heads": self.heads,
            "steps": self.steps,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "final_learning_rate": self.final_learning_rate,
            "learning_rate_schedule": self.learning_rate_schedule,
            "model_seed": self.model_seed,
            "data_seed": self.data_seed,
            "checkpoint_interval": self.checkpoint_interval,
            "compute_device": self.compute_device,
        }


class ProtocolSmokeTransformer(nn.Module):
    def __init__(self, config: SmokeConfig) -> None:
        super().__init__()
        self.token_embedding = nn.Embedding(INPUT_VOCAB_SIZE, config.width)
        self.position_embedding = nn.Embedding(SEQUENCE_LENGTH, config.width)
        self.layers = [
            nn.TransformerEncoderLayer(
                dims=config.width,
                num_heads=config.heads,
                mlp_dims=4 * config.width,
                dropout=0.0,
                norm_first=True,
            )
            for _ in range(config.layers)
        ]
        self.norm = nn.LayerNorm(config.width)
        self.output = nn.Linear(config.width, OUTPUT_CLASSES)

    def __call__(self, tokens: mx.array) -> mx.array:
        positions = mx.arange(tokens.shape[1])
        hidden = self.token_embedding(tokens) + self.position_embedding(positions)
        for layer in self.layers:
            hidden = layer(hidden, None)
        return self.output(self.norm(hidden[:, 0, :]))


def _arrays(
    examples: Sequence[Mapping[str, Any]],
) -> Tuple[mx.array, mx.array]:
    return (
        mx.array([row["tokens"] for row in examples], dtype=mx.int32),
        mx.array([row["label"] for row in examples], dtype=mx.int32),
    )


def _balanced_batch(
    examples_by_target: Mapping[str, Sequence[Mapping[str, Any]]],
    config: SmokeConfig,
    step: int,
) -> Tuple[Mapping[str, Any], ...]:
    rng = random.Random(config.data_seed + 104729 * step)
    result = []
    for target in ("answer", "state", "verify", "route"):
        per_target = int(config.batch_size * TARGET_BATCH_FRACTIONS[target])
        candidates = examples_by_target[target]
        by_label: Dict[int, list[Mapping[str, Any]]] = {}
        for row in candidates:
            by_label.setdefault(int(row["label"]), []).append(row)
        labels = sorted(by_label)
        base = per_target // len(labels)
        remainder = per_target % len(labels)
        for label_index, label in enumerate(labels):
            count = base + int(label_index < remainder)
            label_rows = by_label[label]
            result.extend(
                label_rows[rng.randrange(len(label_rows))] for _ in range(count)
            )
    rng.shuffle(result)
    if len(result) != config.batch_size:
        raise AssertionError("target allocation changed the batch size")
    return tuple(result)


def _predict(
    model: ProtocolSmokeTransformer,
    examples: Sequence[Mapping[str, Any]],
    batch_size: int = 512,
) -> Tuple[int, ...]:
    predictions = []
    model.eval()
    for start in range(0, len(examples), batch_size):
        tokens, _ = _arrays(examples[start : start + batch_size])
        values = mx.argmax(model(tokens), axis=-1)
        mx.eval(values)
        predictions.extend(int(value) for value in values.tolist())
    model.train()
    return tuple(predictions)


def evaluate(
    model: ProtocolSmokeTransformer,
    examples: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    predictions = _predict(model, examples)
    by_target: Dict[str, Dict[str, Any]] = {}
    by_family: Dict[str, list[bool]] = {}
    by_target_variant: Dict[str, Dict[str, list[bool]]] = {}
    for row, prediction in zip(examples, predictions):
        target = str(row["target"])
        correct = prediction == int(row["label"])
        target_row = by_target.setdefault(
            target,
            {"correct": 0, "total": 0, "class_correct": {}, "class_total": {}},
        )
        target_row["correct"] += int(correct)
        target_row["total"] += 1
        label = int(row["label"])
        target_row["class_correct"][label] = (
            target_row["class_correct"].get(label, 0) + int(correct)
        )
        target_row["class_total"][label] = target_row["class_total"].get(label, 0) + 1
        by_family.setdefault(str(row["family"]), []).append(correct)
        by_target_variant.setdefault(target, {}).setdefault(
            str(row["variant"]), []
        ).append(correct)

    target_metrics = {}
    for target, row in sorted(by_target.items()):
        recalls = {
            str(label): row["class_correct"].get(label, 0) / total
            for label, total in sorted(row["class_total"].items())
        }
        target_metrics[target] = {
            "accuracy": row["correct"] / row["total"],
            "minimum_class_recall": min(recalls.values()),
            "class_recall": recalls,
            "count": row["total"],
        }
    return {
        "by_target": target_metrics,
        "by_family": {
            family: sum(values) / len(values)
            for family, values in sorted(by_family.items())
        },
        "by_target_variant": {
            target: {
                variant: sum(values) / len(values)
                for variant, values in sorted(variants.items())
            }
            for target, variants in sorted(by_target_variant.items())
        },
        "overall_accuracy": sum(
            prediction == int(row["label"])
            for row, prediction in zip(examples, predictions)
        )
        / len(examples),
    }


def adjudicate(metrics: Mapping[str, Any]) -> Mapping[str, Any]:
    targets = metrics["by_target"]
    observations = {
        "answer_accuracy": targets["answer"]["accuracy"],
        "state_accuracy": targets["state"]["accuracy"],
        "verify_accuracy": targets["verify"]["accuracy"],
        "route_accuracy": targets["route"]["accuracy"],
        "verify_class_recall": targets["verify"]["minimum_class_recall"],
        "route_class_recall": targets["route"]["minimum_class_recall"],
        "family_accuracy": min(metrics["by_family"].values()),
    }
    checks = {
        "answer_accuracy": observations["answer_accuracy"]
        >= QUALIFICATION_GATES["minimum_answer_accuracy"],
        "state_accuracy": observations["state_accuracy"]
        >= QUALIFICATION_GATES["minimum_state_accuracy"],
        "verify_accuracy": observations["verify_accuracy"]
        >= QUALIFICATION_GATES["minimum_verify_accuracy"],
        "route_accuracy": observations["route_accuracy"]
        >= QUALIFICATION_GATES["minimum_route_accuracy"],
        "verify_class_recall": observations["verify_class_recall"]
        >= QUALIFICATION_GATES["minimum_verify_class_recall"],
        "route_class_recall": observations["route_class_recall"]
        >= QUALIFICATION_GATES["minimum_route_class_recall"],
        "family_accuracy": observations["family_accuracy"]
        >= QUALIFICATION_GATES["minimum_family_accuracy"],
    }
    passed = all(checks.values())
    return {
        "passed": passed,
        "checks": checks,
        "observations": observations,
        "gates": QUALIFICATION_GATES,
        "next_action": (
            "authorize_micro_factorial"
            if passed
            else "halt_factorial_and_diagnose_unlearned_targets"
        ),
    }


def run_smoke(dataset_root: Path, config: SmokeConfig) -> Mapping[str, Any]:
    development_public, development_authority = load_split(
        dataset_root, "micro_development"
    )
    development = training_examples(development_public, development_authority)
    monitor_limit = min(4608, len(development))
    monitor = tuple(
        sorted(
            development,
            key=lambda row: content_digest(
                {
                    "tokens": list(row["tokens"]),
                    "label": row["label"],
                    "target": row["target"],
                    "monitor": "m55-fixed-development-monitor-v1",
                }
            ),
        )[:monitor_limit]
    )
    by_target = {
        target: tuple(row for row in development if row["target"] == target)
        for target in ("answer", "state", "verify", "route")
    }
    if not all(by_target.values()):
        raise RuntimeError("M55 smoke training is missing a target family")

    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    mx.random.seed(config.model_seed)
    model = ProtocolSmokeTransformer(config)
    mx.eval(model.parameters())
    parameter_count = sum(
        math.prod(array.shape) for _, array in tree_flatten(model.parameters())
    )
    learning_rate = (
        optim.cosine_decay(
            config.learning_rate,
            config.steps,
            end=config.final_learning_rate,
        )
        if config.learning_rate_schedule == "cosine"
        else config.learning_rate
    )
    optimizer = optim.AdamW(learning_rate=learning_rate, weight_decay=0.0001)

    def loss_fn(
        active_model: ProtocolSmokeTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints = []
    started = time.monotonic()
    initial = evaluate(model, monitor)
    checkpoints.append(
        {"step": 0, "loss": None, "metrics": initial}
    )
    last_loss = float("nan")
    selected_step = None
    for step in range(1, config.steps + 1):
        batch = _balanced_batch(by_target, config, step)
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
        if step % config.checkpoint_interval == 0 or step == config.steps:
            checkpoint_metrics = evaluate(model, monitor)
            checkpoint_decision = adjudicate(checkpoint_metrics)
            checkpoints.append(
                {
                    "step": step,
                    "loss": last_loss,
                    "metrics": checkpoint_metrics,
                    "development_qualification": checkpoint_decision,
                }
            )
            if checkpoint_decision["passed"]:
                selected_step = step
                break
    elapsed = time.monotonic() - started
    development_metrics = checkpoints[-1]["metrics"]
    replication_opened = selected_step is not None
    replication = ()
    if replication_opened:
        replication_public, replication_authority = load_split(
            dataset_root, "micro_replication"
        )
        replication = training_examples(
            replication_public, replication_authority
        )
        final_metrics = evaluate(model, replication)
    else:
        final_metrics = development_metrics
    decision = adjudicate(final_metrics)
    result = {
        "version": VERSION,
        "config": config.as_dict(),
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "parameter_count": parameter_count,
        "development_examples": len(development),
        "development_monitor_examples": len(monitor),
        "replication_examples": len(replication),
        "elapsed_seconds": elapsed,
        "selected_step": selected_step,
        "selection_rule": "earliest_development_checkpoint_passing_all_frozen_gates",
        "replication_opened": replication_opened,
        "hardware": platform.platform(),
        "framework": "mlx",
        "checkpoints": checkpoints,
        "development_metrics": development_metrics,
        "metrics": final_metrics,
        "decision": decision,
    }
    result["run_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable M55 smoke result: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json", json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    metrics = result["metrics"]
    decision = result["decision"]
    metric_scope = (
        "Held-out replication metrics"
        if result["replication_opened"]
        else "Development metrics; replication not opened"
    )
    lines = [
        "# Cognitive-core M55 learnability smoke",
        "",
        "- Qualification passed: **%s**" % decision["passed"],
        "- Next action: `%s`" % decision["next_action"],
        "- Parameters: **%s**" % format(result["parameter_count"], ","),
        "- Training time: **%.2f seconds**" % result["elapsed_seconds"],
        "- Selected step: **%s**" % result["selected_step"],
        "- Run ID: `%s`" % result["run_id"],
        "",
        "## %s" % metric_scope,
        "",
        "| Target | Accuracy | Minimum class recall |",
        "|---|---:|---:|",
    ]
    for target, row in sorted(metrics["by_target"].items()):
        lines.append(
            "| %s | %.1f%% | %.1f%% |"
            % (target, 100 * row["accuracy"], 100 * row["minimum_class_recall"])
        )
    lines.extend(
        (
            "",
            "## Family accuracy",
            "",
            "| Family | Accuracy |",
            "|---|---:|",
        )
    )
    for family, accuracy in sorted(metrics["by_family"].items()):
        lines.append("| %s | %.1f%% |" % (family, 100 * accuracy))
    lines.extend(
        (
            "",
            "## Boundary",
            "",
            "This smoke test tests whether the four targets are learnable from the "
            "audited symbolic micro-world. It estimates no causal training "
            "factor, natural-language transfer, scaling law, or 3B/70B comparison.",
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", "\n".join(lines))
