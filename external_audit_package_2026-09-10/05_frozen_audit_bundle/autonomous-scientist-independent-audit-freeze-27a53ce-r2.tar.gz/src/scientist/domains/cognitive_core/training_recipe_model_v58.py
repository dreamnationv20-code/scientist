from __future__ import annotations

import math

import mlx.core as mx
import mlx.nn as nn
from mlx.utils import tree_flatten

from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    EVIDENCE_VALIDITY_LABEL_BASE,
    INPUT_VOCAB_SIZE,
    OUTPUT_CLASSES,
    SEQUENCE_LENGTH,
    STATE_LABEL_BASE,
    TARGET_ANSWER,
    TARGET_EVIDENCE_VALIDITY,
    TARGET_STATE,
    TARGET_TOOL_POLICY,
    TOOL_POLICY_LABEL_BASE,
)
from scientist.domains.cognitive_core.training_recipe_mlx_smoke_v55 import (
    SmokeConfig,
)


VERSION = "cognitive-core-stop-gradient-validity-policy-model-v58-r1"


class V58RelationalControlTransformer(nn.Module):
    """Target-local model with an explicit stop-gradient validity-to-policy edge."""

    def __init__(self, config: SmokeConfig) -> None:
        super().__init__()
        self.token_embedding = nn.Embedding(INPUT_VOCAB_SIZE, config.width)
        self.position_embedding = nn.Embedding(SEQUENCE_LENGTH, config.width)
        self.layers = [
            nn.TransformerEncoderLayer(
                dims=config.width,
                num_heads=config.heads,
                mlp_dims=4 * config.width,
                dropout=0.0,
                norm_first=True,
            )
            for _ in range(config.layers)
        ]
        self.norm = nn.LayerNorm(config.width)
        self.answer_head = nn.Linear(config.width, 16)
        self.state_head = nn.Linear(config.width, 16)
        self.evidence_validity_head = nn.Linear(config.width, 3)
        self.tool_policy_head = nn.Linear(config.width + 3, 5)

    def _encode(self, tokens: mx.array) -> mx.array:
        positions = mx.arange(tokens.shape[1])
        hidden = self.token_embedding(tokens) + self.position_embedding(positions)
        for layer in self.layers:
            hidden = layer(hidden, None)
        return self.norm(hidden[:, 0, :])

    def _validity_features(self, tokens: mx.array) -> mx.array:
        validity_target = mx.full(
            (tokens.shape[0], 1), TARGET_EVIDENCE_VALIDITY, dtype=mx.int32
        )
        validity_tokens = mx.concatenate(
            (tokens[:, :1], validity_target, tokens[:, 2:]), axis=1
        )
        logits = self.evidence_validity_head(self._encode(validity_tokens))
        return mx.stop_gradient(mx.softmax(logits, axis=-1))

    def __call__(self, tokens: mx.array) -> mx.array:
        pooled = self._encode(tokens)
        validity_features = self._validity_features(tokens)
        logits = mx.concatenate(
            (
                self.answer_head(pooled),
                self.state_head(pooled),
                self.evidence_validity_head(pooled),
                self.tool_policy_head(
                    mx.concatenate((pooled, validity_features), axis=-1)
                ),
            ),
            axis=-1,
        )
        target = tokens[:, 1:2]
        classes = mx.arange(OUTPUT_CLASSES)[None, :]
        allowed = (
            ((target == TARGET_ANSWER) & (classes < STATE_LABEL_BASE))
            | (
                (target == TARGET_STATE)
                & (classes >= STATE_LABEL_BASE)
                & (classes < EVIDENCE_VALIDITY_LABEL_BASE)
            )
            | (
                (target == TARGET_EVIDENCE_VALIDITY)
                & (classes >= EVIDENCE_VALIDITY_LABEL_BASE)
                & (classes < TOOL_POLICY_LABEL_BASE)
            )
            | (
                (target == TARGET_TOOL_POLICY)
                & (classes >= TOOL_POLICY_LABEL_BASE)
            )
        )
        return mx.where(allowed, logits, mx.array(-1.0e9, dtype=logits.dtype))


def parameter_count(model: V58RelationalControlTransformer) -> int:
    return sum(math.prod(array.shape) for _, array in tree_flatten(model.parameters()))


__all__ = ["VERSION", "V58RelationalControlTransformer", "parameter_count"]
