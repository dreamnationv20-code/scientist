from __future__ import annotations

import mlx.core as mx

from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    EVIDENCE_VALIDITY_LABEL_BASE,
    OUTPUT_CLASSES,
    STATE_LABEL_BASE,
    TARGET_ANSWER,
    TARGET_EVIDENCE_VALIDITY,
    TARGET_STATE,
    TARGET_TOOL_POLICY,
    TOOL_POLICY_LABEL_BASE,
)
from scientist.domains.cognitive_core.training_recipe_mlx_smoke_v55 import (
    SmokeConfig,
)
from scientist.domains.cognitive_core.training_recipe_model_v62 import (
    V62StateAnswerBridgeTransformer,
)


VERSION = "cognitive-core-teacher-transition-state-answer-model-v63-r1"


class V63TeacherTransitionTransformer(V62StateAnswerBridgeTransformer):
    """State bridge with an optional continuous gold-to-predicted state mix."""

    def __init__(self, config: SmokeConfig) -> None:
        super().__init__(config)

    def __call__(
        self,
        tokens: mx.array,
        teacher_state: mx.array | None = None,
        teacher_alpha: float = 0.0,
    ) -> mx.array:
        pooled = self._encode(tokens)
        validity_features = self._validity_features(tokens)
        predicted_state = self._state_features(tokens)
        state_features = predicted_state
        if teacher_state is not None and teacher_alpha > 0.0:
            gold_state = mx.eye(16, dtype=predicted_state.dtype)[teacher_state]
            state_features = mx.stop_gradient(
                teacher_alpha * gold_state
                + (1.0 - teacher_alpha) * predicted_state
            )
        logits = mx.concatenate(
            (
                self.answer_head(pooled)
                + self.state_answer_bridge(state_features),
                self.state_head(pooled),
                self.evidence_validity_head(pooled),
                self.tool_policy_head(
                    mx.concatenate((pooled, validity_features), axis=-1)
                ),
            ),
            axis=-1,
        )
        target = tokens[:, 1:2]
        classes = mx.arange(OUTPUT_CLASSES)[None, :]
        allowed = (
            ((target == TARGET_ANSWER) & (classes < STATE_LABEL_BASE))
            | (
                (target == TARGET_STATE)
                & (classes >= STATE_LABEL_BASE)
                & (classes < EVIDENCE_VALIDITY_LABEL_BASE)
            )
            | (
                (target == TARGET_EVIDENCE_VALIDITY)
                & (classes >= EVIDENCE_VALIDITY_LABEL_BASE)
                & (classes < TOOL_POLICY_LABEL_BASE)
            )
            | (
                (target == TARGET_TOOL_POLICY)
                & (classes >= TOOL_POLICY_LABEL_BASE)
            )
        )
        return mx.where(allowed, logits, mx.array(-1.0e9, dtype=logits.dtype))


__all__ = ["VERSION", "V63TeacherTransitionTransformer"]
