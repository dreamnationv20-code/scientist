from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn

from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    EVIDENCE_VALIDITY_LABEL_BASE,
    OUTPUT_CLASSES,
    STATE_LABEL_BASE,
    TARGET_ANSWER,
    TARGET_EVIDENCE_VALIDITY,
    TARGET_STATE,
    TARGET_TOOL_POLICY,
    TOOL_POLICY_LABEL_BASE,
)
from scientist.domains.cognitive_core.training_recipe_mlx_smoke_v55 import (
    SmokeConfig,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    V58RelationalControlTransformer,
)


VERSION = "cognitive-core-structured-state-nonlinear-fusion-model-v65-r1"
FUSION_MODES = ("additive", "nonlinear")


class V65StructuredFusionTransformer(V58RelationalControlTransformer):
    """Matched-capacity model containing both additive and nonlinear fusions."""

    def __init__(self, config: SmokeConfig) -> None:
        super().__init__(config)
        self.state_answer_bridge = nn.Linear(16, 16, bias=False)
        self.current_nuisance_embedding = nn.Embedding(16, config.width)
        self.operator_nuisance_embedding = nn.Embedding(7, config.width)
        self.operand_nuisance_embedding = nn.Embedding(16, config.width)
        self.current_value_head = nn.Linear(2 * config.width, 16)
        self.pending_operator_head = nn.Linear(2 * config.width, 7)
        self.pending_operand_head = nn.Linear(2 * config.width, 16)
        self.structured_fusion = nn.Sequential(
            nn.Linear(config.width + 16 + 7 + 16, 2 * config.width),
            nn.GELU(),
            nn.Linear(2 * config.width, 16),
        )

    def _state_pooled(self, tokens: mx.array) -> mx.array:
        state_target = mx.full(
            (tokens.shape[0], 1), TARGET_STATE, dtype=mx.int32
        )
        state_tokens = mx.concatenate(
            (tokens[:, :1], state_target, tokens[:, 2:]), axis=1
        )
        return self._encode(state_tokens)

    def forward_with_structured(
        self,
        tokens: mx.array,
        fusion_mode: str,
        nuisance_codes: tuple[mx.array, mx.array, mx.array] | None = None,
    ) -> tuple[mx.array, tuple[mx.array, mx.array, mx.array]]:
        if fusion_mode not in FUSION_MODES:
            raise ValueError("unknown V65 fusion mode: %s" % fusion_mode)
        pooled = self._encode(tokens)
        validity_features = self._validity_features(tokens)
        state_pooled = self._state_pooled(tokens)
        if nuisance_codes is None:
            nuisance_codes = tuple(
                mx.zeros((tokens.shape[0],), dtype=mx.int32) for _ in range(3)
            )
        current_input = mx.concatenate(
            (state_pooled, self.current_nuisance_embedding(nuisance_codes[0])),
            axis=-1,
        )
        operator_input = mx.concatenate(
            (state_pooled, self.operator_nuisance_embedding(nuisance_codes[1])),
            axis=-1,
        )
        operand_input = mx.concatenate(
            (state_pooled, self.operand_nuisance_embedding(nuisance_codes[2])),
            axis=-1,
        )
        legacy_state_features = mx.stop_gradient(
            mx.softmax(self.state_head(state_pooled), axis=-1)
        )
        structured_logits = (
            self.current_value_head(current_input),
            self.pending_operator_head(operator_input),
            self.pending_operand_head(operand_input),
        )
        structured_features = mx.stop_gradient(
            mx.concatenate(
                tuple(mx.softmax(logits, axis=-1) for logits in structured_logits),
                axis=-1,
            )
        )
        if fusion_mode == "additive":
            answer_residual = self.state_answer_bridge(legacy_state_features)
        else:
            answer_residual = self.structured_fusion(
                mx.concatenate((pooled, structured_features), axis=-1)
            )
        logits = mx.concatenate(
            (
                self.answer_head(pooled) + answer_residual,
                self.state_head(pooled),
                self.evidence_validity_head(pooled),
                self.tool_policy_head(
                    mx.concatenate((pooled, validity_features), axis=-1)
                ),
            ),
            axis=-1,
        )
        target = tokens[:, 1:2]
        classes = mx.arange(OUTPUT_CLASSES)[None, :]
        allowed = (
            ((target == TARGET_ANSWER) & (classes < STATE_LABEL_BASE))
            | (
                (target == TARGET_STATE)
                & (classes >= STATE_LABEL_BASE)
                & (classes < EVIDENCE_VALIDITY_LABEL_BASE)
            )
            | (
                (target == TARGET_EVIDENCE_VALIDITY)
                & (classes >= EVIDENCE_VALIDITY_LABEL_BASE)
                & (classes < TOOL_POLICY_LABEL_BASE)
            )
            | (
                (target == TARGET_TOOL_POLICY)
                & (classes >= TOOL_POLICY_LABEL_BASE)
            )
        )
        masked = mx.where(allowed, logits, mx.array(-1.0e9, dtype=logits.dtype))
        return masked, structured_logits

    def __call__(
        self,
        tokens: mx.array,
        fusion_mode: str = "additive",
        nuisance_codes: tuple[mx.array, mx.array, mx.array] | None = None,
    ) -> mx.array:
        return self.forward_with_structured(
            tokens, fusion_mode, nuisance_codes
        )[0]


__all__ = ["FUSION_MODES", "VERSION", "V65StructuredFusionTransformer"]
