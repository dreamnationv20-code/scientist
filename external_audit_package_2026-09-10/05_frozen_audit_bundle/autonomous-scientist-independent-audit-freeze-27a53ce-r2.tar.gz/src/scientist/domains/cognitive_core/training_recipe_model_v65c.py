from __future__ import annotations

import mlx.core as mx

from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    EVIDENCE_VALIDITY_LABEL_BASE,
    OUTPUT_CLASSES,
    STATE_LABEL_BASE,
    TARGET_ANSWER,
    TARGET_EVIDENCE_VALIDITY,
    TARGET_STATE,
    TARGET_TOOL_POLICY,
    TOOL_POLICY_LABEL_BASE,
)
from scientist.domains.cognitive_core.training_recipe_mlx_smoke_v55 import (
    SmokeConfig,
)
from scientist.domains.cognitive_core.training_recipe_model_v65 import (
    V65StructuredFusionTransformer,
)


VERSION = "cognitive-core-context-only-matched-fusion-model-v65c-r1"
CONTEXT_CONTROL_DIMENSION = 16 + 7 + 16


class V65CContextOnlyFusionTransformer(V65StructuredFusionTransformer):
    """V65 architecture whose nonlinear answer residual receives context only.

    The trainable architecture and parameter count are exactly those of V65. The
    39 decoded-state inputs to ``structured_fusion`` are replaced by a fixed slice
    of the ordinary pooled context. This changes information routing, not capacity.
    Structured heads remain present and supervised so the comparison can be made
    at both nuisance- and semantic-supervision levels.
    """

    def __init__(self, config: SmokeConfig) -> None:
        if config.width < CONTEXT_CONTROL_DIMENSION:
            raise ValueError(
                "V65C requires width >= %d" % CONTEXT_CONTROL_DIMENSION
            )
        super().__init__(config)

    def forward_with_context_control(
        self,
        tokens: mx.array,
        nuisance_codes: tuple[mx.array, mx.array, mx.array] | None = None,
    ) -> tuple[mx.array, tuple[mx.array, mx.array, mx.array]]:
        pooled = self._encode(tokens)
        validity_features = self._validity_features(tokens)
        state_pooled = self._state_pooled(tokens)
        if nuisance_codes is None:
            nuisance_codes = tuple(
                mx.zeros((tokens.shape[0],), dtype=mx.int32) for _ in range(3)
            )
        current_input = mx.concatenate(
            (state_pooled, self.current_nuisance_embedding(nuisance_codes[0])),
            axis=-1,
        )
        operator_input = mx.concatenate(
            (state_pooled, self.operator_nuisance_embedding(nuisance_codes[1])),
            axis=-1,
        )
        operand_input = mx.concatenate(
            (state_pooled, self.operand_nuisance_embedding(nuisance_codes[2])),
            axis=-1,
        )
        structured_logits = (
            self.current_value_head(current_input),
            self.pending_operator_head(operator_input),
            self.pending_operand_head(operand_input),
        )
        context_features = mx.stop_gradient(
            pooled[:, :CONTEXT_CONTROL_DIMENSION]
        )
        answer_residual = self.structured_fusion(
            mx.concatenate((pooled, context_features), axis=-1)
        )
        logits = mx.concatenate(
            (
                self.answer_head(pooled) + answer_residual,
                self.state_head(pooled),
                self.evidence_validity_head(pooled),
                self.tool_policy_head(
                    mx.concatenate((pooled, validity_features), axis=-1)
                ),
            ),
            axis=-1,
        )
        target = tokens[:, 1:2]
        classes = mx.arange(OUTPUT_CLASSES)[None, :]
        allowed = (
            ((target == TARGET_ANSWER) & (classes < STATE_LABEL_BASE))
            | (
                (target == TARGET_STATE)
                & (classes >= STATE_LABEL_BASE)
                & (classes < EVIDENCE_VALIDITY_LABEL_BASE)
            )
            | (
                (target == TARGET_EVIDENCE_VALIDITY)
                & (classes >= EVIDENCE_VALIDITY_LABEL_BASE)
                & (classes < TOOL_POLICY_LABEL_BASE)
            )
            | (
                (target == TARGET_TOOL_POLICY)
                & (classes >= TOOL_POLICY_LABEL_BASE)
            )
        )
        masked = mx.where(
            allowed, logits, mx.array(-1.0e9, dtype=logits.dtype)
        )
        return masked, structured_logits

    def __call__(
        self,
        tokens: mx.array,
        nuisance_codes: tuple[mx.array, mx.array, mx.array] | None = None,
    ) -> mx.array:
        return self.forward_with_context_control(tokens, nuisance_codes)[0]


__all__ = [
    "CONTEXT_CONTROL_DIMENSION",
    "VERSION",
    "V65CContextOnlyFusionTransformer",
]
