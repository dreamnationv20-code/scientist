from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn

from scientist.domains.cognitive_core.training_recipe_mlx_smoke_v55 import (
    SmokeConfig,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    V58RelationalControlTransformer,
)
from scientist.domains.cognitive_core.training_recipe_trace_feasibility_v68t import (
    ANSWER_BASE,
    BOS_TOKEN,
    CURRENT_BASE,
    EOS_TOKEN,
    OPERAND_BASE,
    OPERATOR_BASE,
    TRACE_LENGTH,
    TRACE_VOCAB_SIZE,
)


VERSION = "cognitive-core-autoregressive-execution-trace-model-v68-r1"


def _position_bounds(position: int) -> tuple[int, int]:
    bounds = (
        (CURRENT_BASE, OPERATOR_BASE),
        (OPERATOR_BASE, OPERAND_BASE),
        (OPERAND_BASE, ANSWER_BASE),
        (ANSWER_BASE, EOS_TOKEN),
        (EOS_TOKEN, EOS_TOKEN + 1),
    )
    return bounds[position]


class V68AutoregressiveTraceTransformer(V58RelationalControlTransformer):
    """Shared encoder with a grammar-masked autoregressive trace decoder."""

    def __init__(self, config: SmokeConfig) -> None:
        super().__init__(config)
        self.trace_embedding = nn.Embedding(TRACE_VOCAB_SIZE, config.width)
        self.trace_context = nn.Linear(config.width, config.width)
        self.trace_recurrent = nn.GRU(config.width, config.width)
        self.trace_norm = nn.LayerNorm(config.width)
        self.trace_head = nn.Linear(config.width, TRACE_VOCAB_SIZE)

    @staticmethod
    def _mask_position(logits: mx.array, position: int) -> mx.array:
        lower, upper = _position_bounds(position)
        classes = mx.arange(TRACE_VOCAB_SIZE)
        allowed = (classes >= lower) & (classes < upper)
        return mx.where(
            allowed,
            logits,
            mx.array(-1.0e9, dtype=logits.dtype),
        )

    def trace_logits(
        self, tokens: mx.array, teacher_inputs: mx.array
    ) -> mx.array:
        if teacher_inputs.shape[1] != TRACE_LENGTH:
            raise ValueError("teacher inputs must have TRACE_LENGTH tokens")
        context = self.trace_context(self._encode(tokens))
        hidden = self.trace_recurrent(
            self.trace_embedding(teacher_inputs), context
        )
        logits = self.trace_head(self.trace_norm(hidden))
        return mx.stack(
            tuple(
                self._mask_position(logits[:, position, :], position)
                for position in range(TRACE_LENGTH)
            ),
            axis=1,
        )

    def generate_trace(
        self,
        tokens: mx.array,
        forced_prefix: mx.array | None = None,
        uniform_prefix: bool = False,
    ) -> mx.array:
        if forced_prefix is not None and uniform_prefix:
            raise ValueError("trace intervention must be forced or uniform")
        if forced_prefix is not None and forced_prefix.shape[1] != 3:
            raise ValueError("forced prefix must contain three tokens")
        hidden = self.trace_context(self._encode(tokens))
        next_embedding = self.trace_embedding(
            mx.full((tokens.shape[0],), BOS_TOKEN, dtype=mx.int32)
        )
        generated = []
        for position in range(TRACE_LENGTH):
            recurrent = self.trace_recurrent(
                next_embedding[:, None, :], hidden
            )
            hidden = recurrent[:, -1, :]
            logits = self._mask_position(
                self.trace_head(self.trace_norm(hidden)), position
            )
            predicted = mx.argmax(logits, axis=-1)
            if position < 3 and forced_prefix is not None:
                emitted = forced_prefix[:, position]
            else:
                emitted = predicted
            generated.append(emitted)
            if position < 3 and uniform_prefix:
                lower, upper = _position_bounds(position)
                support = mx.arange(lower, upper, dtype=mx.int32)
                next_embedding = mx.mean(
                    self.trace_embedding(support), axis=0, keepdims=True
                )
                next_embedding = mx.broadcast_to(
                    next_embedding, (tokens.shape[0], next_embedding.shape[-1])
                )
            else:
                next_embedding = self.trace_embedding(emitted)
        return mx.stack(tuple(generated), axis=1)


__all__ = ["VERSION", "V68AutoregressiveTraceTransformer"]
