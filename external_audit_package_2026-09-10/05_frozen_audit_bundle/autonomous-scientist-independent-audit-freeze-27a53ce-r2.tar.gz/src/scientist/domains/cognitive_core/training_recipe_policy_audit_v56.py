from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_micro_world_v56 import (
    TOOL_POLICY_LABELS,
    load_split,
    materialize_policy_labels,
)


VERSION = "cognitive-core-tool-policy-stability-audit-v56-r1"


def _wilson_interval(correct: int, count: int, z: float = 1.96) -> Tuple[float, float]:
    if count <= 0:
        raise ValueError("Wilson interval requires a positive count")
    probability = correct / count
    denominator = 1.0 + z * z / count
    centre = (probability + z * z / (2.0 * count)) / denominator
    radius = (
        z
        * math.sqrt(
            probability * (1.0 - probability) / count
            + z * z / (4.0 * count * count)
        )
        / denominator
    )
    return max(0.0, centre - radius), min(1.0, centre + radius)


def _policy_action(
    public: Mapping[str, Any],
    authority: Mapping[str, Any],
    direct: float,
) -> str:
    cost = int(public["declared_tool_cost"])
    budget = int(public["remaining_budget"])
    available = bool(public["tool_available"])
    tool_value = float(public["tool_reliability"]) - 0.05 * cost
    beneficial = available and budget >= cost and tool_value > direct + 0.05
    variant = str(authority["variant"])
    if variant == "faithful_observation":
        return "answer"
    if variant == "absent_observation":
        if beneficial:
            return "call"
        return "answer" if direct >= 0.70 else "abstain"
    if beneficial and budget >= 2 * cost:
        return "retry"
    return "stop" if direct >= 0.70 else "abstain"


def _profile_probability(
    profile: Mapping[str, Any], family: str, difficulty_bin: int
) -> float:
    return float(
        profile["capabilities"][f"{family}|{difficulty_bin}"][
            "smoothed_success_probability"
        ]
    )


def _model_key(public: Mapping[str, Any]) -> Tuple[Any, ...]:
    return (
        *tuple(public["problem_tokens"]),
        *tuple(public["observation_tokens"]),
        int(public["declared_tool_cost"]),
        int(public["tool_reliability_bin"]),
        int(public["remaining_budget"]),
        int(bool(public["tool_available"])),
    )


def audit_split(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
    profile: Mapping[str, Any],
    comparison_profile: Mapping[str, Any] | None = None,
) -> Mapping[str, Any]:
    public_by_view = {str(row["view_id"]): row for row in public_rows}
    authority_by_view = {str(row["view_id"]): row for row in authority_rows}
    materialized = materialize_policy_labels(public_rows, authority_rows, profile)

    labels_by_input: Dict[Tuple[Any, ...], Counter[str]] = defaultdict(Counter)
    action_counts: Counter[str] = Counter()
    action_counts_by_family: Dict[str, Counter[str]] = defaultdict(Counter)
    action_counts_by_variant: Dict[str, Counter[str]] = defaultdict(Counter)
    boundary_counts = {
        "direct_within_0.01": 0,
        "direct_within_0.025": 0,
        "direct_within_0.05": 0,
        "tool_advantage_within_0.01": 0,
        "tool_advantage_within_0.025": 0,
        "tool_advantage_within_0.05": 0,
    }
    uncertainty_disagreements = 0
    comparison_disagreements = 0
    bin_counterfactual_dependencies = 0

    for row in materialized:
        view_id = str(row["view_id"])
        public = public_by_view[view_id]
        authority = authority_by_view[view_id]
        family = str(public["family"])
        action = str(row["tool_policy_action"])
        action_counts[action] += 1
        action_counts_by_family[family][action] += 1
        action_counts_by_variant[str(authority["variant"])][action] += 1
        labels_by_input[_model_key(public)][action] += 1

        direct = float(row["closed_book_success_probability"])
        advantage = float(row["tool_expected_value"]) - direct - 0.05
        for tolerance in (0.01, 0.025, 0.05):
            suffix = str(tolerance).replace("0.", "0.")
            boundary_counts[f"direct_within_{suffix}"] += int(
                abs(direct - 0.70) <= tolerance
            )
            boundary_counts[f"tool_advantage_within_{suffix}"] += int(
                abs(advantage) <= tolerance
            )

        key = f"{family}|{int(authority['difficulty_bin'])}"
        bucket = profile["capabilities"][key]
        lower, upper = _wilson_interval(
            int(bucket["correct"]), int(bucket["count"])
        )
        uncertainty_disagreements += int(
            _policy_action(public, authority, lower)
            != _policy_action(public, authority, upper)
        )

        if comparison_profile is not None:
            comparison_direct = _profile_probability(
                comparison_profile, family, int(authority["difficulty_bin"])
            )
            comparison_disagreements += int(
                action != _policy_action(public, authority, comparison_direct)
            )

        bin_actions = {
            _policy_action(
                public,
                authority,
                _profile_probability(profile, family, difficulty_bin),
            )
            for difficulty_bin in range(3)
        }
        bin_counterfactual_dependencies += int(len(bin_actions) > 1)

    total = len(materialized)
    bayes_correct = sum(max(counts.values()) for counts in labels_by_input.values())
    ambiguous_groups = sum(len(counts) > 1 for counts in labels_by_input.values())
    result: Dict[str, Any] = {
        "rows": total,
        "action_counts": dict(sorted(action_counts.items())),
        "action_fractions": {
            action: count / total for action, count in sorted(action_counts.items())
        },
        "action_counts_by_family": {
            key: dict(sorted(value.items()))
            for key, value in sorted(action_counts_by_family.items())
        },
        "action_counts_by_variant": {
            key: dict(sorted(value.items()))
            for key, value in sorted(action_counts_by_variant.items())
        },
        "exact_input_bayes_accuracy": bayes_correct / total,
        "ambiguous_exact_input_groups": ambiguous_groups,
        "unique_exact_inputs": len(labels_by_input),
        "boundary_counts": boundary_counts,
        "boundary_fractions": {
            key: value / total for key, value in boundary_counts.items()
        },
        "wilson_endpoint_action_disagreements": uncertainty_disagreements,
        "wilson_endpoint_action_disagreement_fraction": (
            uncertainty_disagreements / total
        ),
        "difficulty_bin_counterfactual_dependencies": (
            bin_counterfactual_dependencies
        ),
        "difficulty_bin_counterfactual_dependency_fraction": (
            bin_counterfactual_dependencies / total
        ),
    }
    if comparison_profile is not None:
        result["comparison_profile_action_disagreements"] = comparison_disagreements
        result["comparison_profile_action_disagreement_fraction"] = (
            comparison_disagreements / total
        )
    return result


def run_audit(
    dataset_root: Path,
    result_path: Path,
    comparison_result_path: Path | None = None,
) -> Mapping[str, Any]:
    run_result = json.loads(result_path.read_text(encoding="utf-8"))
    profile = run_result["capability_profile"]
    comparison_profile = None
    if comparison_result_path is not None:
        comparison_profile = json.loads(
            comparison_result_path.read_text(encoding="utf-8")
        )["capability_profile"]

    splits = {}
    for split in ("learnability_development", "learnability_replication"):
        public_rows, authority_rows = load_split(dataset_root, split)
        splits[split] = audit_split(
            public_rows,
            authority_rows,
            profile,
            comparison_profile,
        )

    max_uncertainty = max(
        row["wilson_endpoint_action_disagreement_fraction"]
        for row in splits.values()
    )
    minimum_bayes = min(
        row["exact_input_bayes_accuracy"] for row in splits.values()
    )
    if minimum_bayes < 0.999:
        diagnosis = "policy_target_not_identifiable_from_model_input"
        next_action = "repair_input_equivalence_before_any_training"
    elif max_uncertainty > 0.05:
        diagnosis = "hard_policy_labels_are_calibration_uncertainty_sensitive"
        next_action = "supersede_v56_policy_oracle_before_any_training"
    else:
        diagnosis = "policy_target_is_stable_enough_for_optimization_audit"
        next_action = "audit_optimization_and_sampling_before_any_training"

    result: Dict[str, Any] = {
        "version": VERSION,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "run_id": run_result["run_id"],
        "profile_id": profile["profile_id"],
        "comparison_profile_id": (
            None if comparison_profile is None else comparison_profile["profile_id"]
        ),
        "splits": splits,
        "diagnosis": diagnosis,
        "next_action": next_action,
        "factorial_authorized": False,
        "new_training_run_authorized": False,
    }
    result["audit_id"] = content_digest(result)
    return result


__all__ = ["VERSION", "audit_split", "run_audit"]
