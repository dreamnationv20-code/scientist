from __future__ import annotations

import json
import platform
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_micro_world_v57 import (
    load_split,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    V56SeparatedHeadTransformer,
    _arrays,
    _balanced_rows,
    _optimizer,
    _parameter_count,
    evaluate,
)


VERSION = "cognitive-core-uncertainty-aware-control-probes-v57-r1"
PROBE_TARGETS = ("evidence_validity", "tool_policy")
PROBE_GATES = {
    "evidence_validity": {"accuracy": 0.80, "minimum_class_recall": 0.65},
    "tool_policy": {"accuracy": 0.80, "minimum_class_recall": 0.65},
}


def _monitor(
    examples: Sequence[Mapping[str, Any]], target: str, count: int = 1152
) -> Tuple[Mapping[str, Any], ...]:
    ordered = sorted(
        examples,
        key=lambda row: content_digest(
            {
                "version": VERSION,
                "monitor": "v57-target-specific-development-v1",
                "target": target,
                "example_id": row["example_id"],
            }
        ),
    )
    return tuple(ordered[: min(count, len(ordered))])


def adjudicate_probe(target: str, metrics: Mapping[str, Any]) -> Mapping[str, Any]:
    target_metrics = metrics["by_target"][target]
    gates = PROBE_GATES[target]
    checks = {
        "accuracy": float(target_metrics["accuracy"]) >= gates["accuracy"],
        "minimum_class_recall": (
            float(target_metrics["minimum_class_recall"])
            >= gates["minimum_class_recall"]
        ),
    }
    return {
        "target": target,
        "passed": all(checks.values()),
        "checks": checks,
        "observations": {
            "accuracy": target_metrics["accuracy"],
            "minimum_class_recall": target_metrics["minimum_class_recall"],
        },
        "gates": gates,
    }


def _train_probe(
    target: str,
    examples: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
) -> Mapping[str, Any]:
    active_examples = tuple(row for row in examples if row["target"] == target)
    monitor = _monitor(active_examples, target)
    mx.random.seed(config.model_seed + PROBE_TARGETS.index(target))
    model = V56SeparatedHeadTransformer(config)
    mx.eval(model.parameters())
    optimizer = _optimizer(config, config.steps)

    def loss_fn(
        active_model: V56SeparatedHeadTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints = []
    selected_step = None
    last_loss = float("nan")
    for step in range(1, config.steps + 1):
        batch = _balanced_rows(
            active_examples,
            config.batch_size,
            config.data_seed + 104729 * step + 1009 * PROBE_TARGETS.index(target),
        )
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
        if step % config.checkpoint_interval == 0 or step == config.steps:
            metrics = evaluate(model, monitor)
            decision = adjudicate_probe(target, metrics)
            checkpoints.append(
                {
                    "step": step,
                    "loss": last_loss,
                    "metrics": metrics,
                    "decision": decision,
                }
            )
            if decision["passed"]:
                selected_step = step
                break
    result = {
        "target": target,
        "examples": len(active_examples),
        "monitor_examples": len(monitor),
        "selected_step": selected_step,
        "checkpoints": checkpoints,
        "metrics": checkpoints[-1]["metrics"],
        "decision": checkpoints[-1]["decision"],
        "parameter_count": _parameter_count(model),
    }
    del model
    return result


def run_probes(
    dataset_root: Path,
    capability_profile_path: Path,
    config: SmokeConfig,
) -> Mapping[str, Any]:
    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    started = time.monotonic()
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    development_public, development_authority = load_split(
        dataset_root, "learnability_development"
    )
    materialized = materialize_policy_labels(
        development_public, development_authority, profile
    )
    examples = training_examples(development_public, materialized)
    probes = {
        target: _train_probe(target, examples, config) for target in PROBE_TARGETS
    }
    passed = all(probe["decision"]["passed"] for probe in probes.values())
    result: Dict[str, Any] = {
        "version": VERSION,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "config": config.as_dict(),
        "probes": probes,
        "passed": passed,
        "replication_opened": False,
        "joint_training_authorized": passed,
        "factorial_authorized": False,
        "next_action": (
            "run_v57_joint_learnability_development"
            if passed
            else "diagnose_failed_v57_target_probe"
        ),
        "hardware": platform.platform(),
        "framework": "mlx",
        "elapsed_seconds": time.monotonic() - started,
    }
    result["run_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V57 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    rows = []
    for target, probe in sorted(result["probes"].items()):
        metrics = probe["metrics"]["by_target"][target]
        rows.append(
            "| %s | %.1f%% | %.1f%% | %s | %s |"
            % (
                target,
                metrics["accuracy"] * 100.0,
                metrics["minimum_class_recall"] * 100.0,
                probe["selected_step"],
                probe["decision"]["passed"],
            )
        )
    report = "\n".join(
        (
            "# Cognitive-core V57 target-specific probes",
            "",
            "- Probe gate passed: **%s**" % result["passed"],
            "- Joint training authorized: **%s**"
            % result["joint_training_authorized"],
            "- Factorial authorized: **False**",
            "- Run ID: `%s`" % result["run_id"],
            "",
            "| Target | Accuracy | Minimum recall | Selected step | Passed |",
            "|---|---:|---:|---:|---:|",
            *rows,
            "",
            "Next action: `%s`. The held-out replication split remains sealed."
            % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = ["PROBE_GATES", "VERSION", "adjudicate_probe", "run_probes", "write_result"]
