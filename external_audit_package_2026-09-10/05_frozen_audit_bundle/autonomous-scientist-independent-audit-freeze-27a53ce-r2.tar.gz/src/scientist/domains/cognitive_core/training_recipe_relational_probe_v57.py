from __future__ import annotations

import json
import platform
import random
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_micro_world_v57 import (
    load_split,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    V56SeparatedHeadTransformer,
    _arrays,
    _balanced_rows,
    _optimizer,
    _parameter_count,
    evaluate,
)


VERSION = "cognitive-core-relational-evidence-probe-v57-r1"
TARGETS = ("answer", "state", "evidence_validity")
GATES = {
    "answer_accuracy": 0.70,
    "answer_class_recall": 0.20,
    "state_accuracy": 0.75,
    "state_class_recall": 0.20,
    "evidence_validity_accuracy": 0.80,
    "evidence_validity_class_recall": 0.65,
    "worst_family_accuracy": 0.60,
}


def _monitor(
    by_target: Mapping[str, Sequence[Mapping[str, Any]]]
) -> Tuple[Mapping[str, Any], ...]:
    result = []
    for target in TARGETS:
        ordered = sorted(
            by_target[target],
            key=lambda row: content_digest(
                {
                    "version": VERSION,
                    "monitor": "v57-relational-evidence-development-v1",
                    "target": target,
                    "example_id": row["example_id"],
                }
            ),
        )
        result.extend(ordered[: min(1152, len(ordered))])
    return tuple(result)


def _batch(
    by_target: Mapping[str, Sequence[Mapping[str, Any]]],
    config: SmokeConfig,
    step: int,
) -> Tuple[Mapping[str, Any], ...]:
    base = config.batch_size // len(TARGETS)
    remainder = config.batch_size % len(TARGETS)
    result = []
    for index, target in enumerate(TARGETS):
        count = base + int(index < remainder)
        result.extend(
            _balanced_rows(
                by_target[target],
                count,
                config.data_seed + 104729 * step + 1009 * index,
            )
        )
    rng = random.Random(config.data_seed + 130363 * step)
    rng.shuffle(result)
    return tuple(result)


def adjudicate(metrics: Mapping[str, Any]) -> Mapping[str, Any]:
    targets = metrics["by_target"]
    observations = {
        "answer_accuracy": targets["answer"]["accuracy"],
        "answer_class_recall": targets["answer"]["minimum_class_recall"],
        "state_accuracy": targets["state"]["accuracy"],
        "state_class_recall": targets["state"]["minimum_class_recall"],
        "evidence_validity_accuracy": targets["evidence_validity"]["accuracy"],
        "evidence_validity_class_recall": targets["evidence_validity"][
            "minimum_class_recall"
        ],
        "worst_family_accuracy": min(metrics["by_family"].values()),
    }
    checks = {
        key: observations[key] >= threshold for key, threshold in GATES.items()
    }
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "observations": observations,
        "gates": GATES,
    }


def run_probe(
    dataset_root: Path,
    capability_profile_path: Path,
    config: SmokeConfig,
) -> Mapping[str, Any]:
    mx.set_default_device(mx.gpu if config.compute_device == "gpu" else mx.cpu)
    started = time.monotonic()
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    public_rows, authority_rows = load_split(
        dataset_root, "learnability_development"
    )
    materialized = materialize_policy_labels(public_rows, authority_rows, profile)
    examples = training_examples(public_rows, materialized)
    by_target = {
        target: tuple(row for row in examples if row["target"] == target)
        for target in TARGETS
    }
    monitor = _monitor(by_target)

    mx.random.seed(config.model_seed)
    model = V56SeparatedHeadTransformer(config)
    mx.eval(model.parameters())
    optimizer = _optimizer(config, config.steps)

    def loss_fn(
        active_model: V56SeparatedHeadTransformer,
        tokens: mx.array,
        labels: mx.array,
    ) -> mx.array:
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints = []
    selected_step = None
    for step in range(1, config.steps + 1):
        tokens, labels = _arrays(_batch(by_target, config, step))
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        if step % config.checkpoint_interval == 0 or step == config.steps:
            metrics = evaluate(model, monitor)
            decision = adjudicate(metrics)
            checkpoints.append(
                {
                    "step": step,
                    "loss": float(loss.item()),
                    "metrics": metrics,
                    "decision": decision,
                }
            )
            if decision["passed"]:
                selected_step = step
                break
    decision = checkpoints[-1]["decision"]
    result: Dict[str, Any] = {
        "version": VERSION,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "config": config.as_dict(),
        "parameter_count": _parameter_count(model),
        "development_examples": sum(len(rows) for rows in by_target.values()),
        "monitor_examples": len(monitor),
        "checkpoints": checkpoints,
        "selected_step": selected_step,
        "metrics": checkpoints[-1]["metrics"],
        "decision": decision,
        "passed": decision["passed"],
        "replication_opened": False,
        "joint_training_authorized": decision["passed"],
        "factorial_authorized": False,
        "next_action": (
            "run_separately_initialized_v57_joint_development"
            if decision["passed"]
            else "close_v57_and_redesign_evidence_curriculum"
        ),
        "hardware": platform.platform(),
        "framework": "mlx",
        "elapsed_seconds": time.monotonic() - started,
    }
    result["run_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V57 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    metrics = result["metrics"]["by_target"]
    report = "\n".join(
        (
            "# Cognitive-core V57 relational-evidence probe",
            "",
            "- Passed: **%s**" % result["passed"],
            "- Selected step: **%s**" % result["selected_step"],
            "- Parameters: **%s**" % f"{result['parameter_count']:,}",
            "- Replication opened: **False**",
            "- Run ID: `%s`" % result["run_id"],
            "",
            "| Target | Accuracy | Minimum recall |",
            "|---|---:|---:|",
            *(
                "| %s | %.1f%% | %.1f%% |"
                % (
                    target,
                    metrics[target]["accuracy"] * 100.0,
                    metrics[target]["minimum_class_recall"] * 100.0,
                )
                for target in TARGETS
            ),
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = ["GATES", "VERSION", "adjudicate", "run_probe", "write_result"]
