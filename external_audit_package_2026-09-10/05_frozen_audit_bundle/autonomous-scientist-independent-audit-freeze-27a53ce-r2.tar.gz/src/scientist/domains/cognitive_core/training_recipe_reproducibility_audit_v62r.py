from __future__ import annotations

import json
import platform
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

import mlx.core as mx
import mlx.nn as nn

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_allocation_screen_v61 import (
    build_training_plan,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_v59 import (
    _evaluation_digest,
    _schedule_digest,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    _arrays,
    _optimizer,
    _predict,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    V58RelationalControlTransformer,
)
from scientist.domains.cognitive_core.training_recipe_state_bridge_data_v62 import (
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_state_bridge_screen_v62 import (
    ALLOCATION,
    _parameter_digest,
)


VERSION = "cognitive-core-mlx-cross-process-reproducibility-audit-v62r-r1"
SOURCE_PLAN_ID = "a973fb1b0a5cd9056fa9de35d18eb9d62d59252736112d775db025e5c8c67aea"
SOURCE_SCREEN_ID = "924fe4df7438836a9568df0ad49a7aa48055eb6e7dd44132289ed5919ea5ba75"
PROBE_STEPS = 256
CHECKPOINT_STEPS = (1, 16, 64, PROBE_STEPS)


def run_probe(
    dataset_root: Path,
    capability_profile_path: Path,
    source_plan_path: Path,
    source_result_path: Path,
    *,
    replicate_label: str,
    device: str = "gpu",
    steps: int = PROBE_STEPS,
) -> Mapping[str, Any]:
    source_plan = json.loads(source_plan_path.read_text(encoding="utf-8"))
    source_result = json.loads(source_result_path.read_text(encoding="utf-8"))
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if (
        source_plan["plan_id"] != SOURCE_PLAN_ID
        or source_result["screen_id"] != SOURCE_SCREEN_ID
        or source_plan["dataset_manifest_id"]
        != source_result["dataset_manifest_id"]
    ):
        raise RuntimeError("V62R source artifact mismatch")
    train_public, train_authority = load_split(dataset_root, "state_bridge_train")
    development_public, development_authority = load_split(
        dataset_root, "state_bridge_development"
    )
    training = training_examples(
        train_public,
        materialize_policy_labels(train_public, train_authority, profile),
    )
    development = training_examples(
        development_public,
        materialize_policy_labels(
            development_public, development_authority, profile
        ),
    )
    config = SmokeConfig(
        steps=steps,
        batch_size=128,
        model_seed=64101,
        data_seed=64111,
        compute_device=device,
    )
    frozen_schedule = build_training_plan(training, ALLOCATION, config)
    schedule_digest = _schedule_digest(frozen_schedule)
    evaluation = development[:4096]
    evaluation_digest = _evaluation_digest(evaluation)
    mx.set_default_device(mx.gpu if device == "gpu" else mx.cpu)
    mx.random.seed(config.model_seed)
    model = V58RelationalControlTransformer(config)
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    optimizer = _optimizer(config, config.steps)

    def loss_fn(active_model, tokens, labels):
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    checkpoints: Dict[str, Any] = {}
    started = time.monotonic()
    checkpoint_steps = tuple(sorted({1, 16, 64, steps}))
    for step, batch in enumerate(frozen_schedule, start=1):
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        if step in checkpoint_steps:
            checkpoints[str(step)] = {
                "parameter_digest": _parameter_digest(model),
                "loss": float(loss.item()),
            }
    predictions = _predict(model, evaluation)
    result: Dict[str, Any] = {
        "version": VERSION,
        "replicate_label": replicate_label,
        "source_plan_id": SOURCE_PLAN_ID,
        "source_screen_id": SOURCE_SCREEN_ID,
        "dataset_manifest_id": source_plan["dataset_manifest_id"],
        "mlx_version": "0.32.0",
        "device": device,
        "config": config.as_dict(),
        "allocation": ALLOCATION,
        "schedule_digest": schedule_digest,
        "evaluation_digest": evaluation_digest,
        "initial_parameter_digest": initial_parameter_digest,
        "checkpoints": checkpoints,
        "prediction_digest": content_digest(list(predictions)),
        "elapsed_seconds": time.monotonic() - started,
        "hardware": platform.platform(),
        "metrics_examined": False,
        "development_selection_reopened": False,
    }
    result["probe_id"] = content_digest(result)
    return result


def compare_probes(
    first: Mapping[str, Any], second: Mapping[str, Any]
) -> Mapping[str, Any]:
    checkpoint_steps = sorted(
        set(first["checkpoints"]).intersection(second["checkpoints"]),
        key=int,
    )
    checkpoint_matches = {
        step: first["checkpoints"][step]["parameter_digest"]
        == second["checkpoints"][step]["parameter_digest"]
        for step in checkpoint_steps
    }
    checks = {
        "distinct_process_labels": first["replicate_label"]
        != second["replicate_label"],
        "same_source_plan": first["source_plan_id"] == second["source_plan_id"],
        "same_source_screen": first["source_screen_id"]
        == second["source_screen_id"],
        "same_device": first["device"] == second["device"],
        "same_configuration": first["config"] == second["config"],
        "same_schedule": first["schedule_digest"] == second["schedule_digest"],
        "same_evaluation": first["evaluation_digest"]
        == second["evaluation_digest"],
        "same_initial_parameters": first["initial_parameter_digest"]
        == second["initial_parameter_digest"],
        "all_checkpoint_parameters_exact": bool(checkpoint_matches)
        and all(checkpoint_matches.values()),
        "same_predictions": first["prediction_digest"]
        == second["prediction_digest"],
    }
    exact = all(checks.values())
    full_horizon = int(first["config"]["steps"]) >= 5200
    first_divergence = next(
        (int(step) for step in checkpoint_steps if not checkpoint_matches[step]),
        None,
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "first_probe_id": first["probe_id"],
        "second_probe_id": second["probe_id"],
        "checkpoint_matches": checkpoint_matches,
        "first_parameter_divergence_step": first_divergence,
        "checks": checks,
        "exact_cross_process_reproducibility": exact,
        "next_action": (
            "authorize_cpu_as_deterministic_reference_backend"
            if exact and full_horizon
            else (
                "run_full_horizon_reproducibility_sentinel"
                if exact
                else "treat_seed_cells_as_stochastic_and_add_replicates_and_margins"
            )
        ),
    }
    result["comparison_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, payload: Mapping[str, Any]) -> None:
    text = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V62R artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_probe(path: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(path, result)


def write_comparison(path: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(path, result)


__all__ = [
    "CHECKPOINT_STEPS",
    "PROBE_STEPS",
    "VERSION",
    "compare_probes",
    "run_probe",
    "write_comparison",
    "write_probe",
]
