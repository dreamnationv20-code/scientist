from __future__ import annotations

import hashlib
import json
import platform
import statistics
import time
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

import mlx.core as mx
import mlx.nn as nn
from mlx.utils import tree_flatten

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.training_recipe_allocation_screen_v61 import (
    _core_family_metrics,
    adjudicate_model,
    build_training_plan,
)
from scientist.domains.cognitive_core.training_recipe_end_to_end_v58 import (
    evaluate_end_to_end,
    prediction_index,
)
from scientist.domains.cognitive_core.training_recipe_factorial_pilot_v59 import (
    PROTOCOL_ID,
    _deterministic_controller_predictions,
    _evaluation_digest,
    _schedule_digest,
)
from scientist.domains.cognitive_core.training_recipe_micro_world_v59 import (
    audit_nuisance_controls,
    materialize_policy_labels,
    training_examples,
)
from scientist.domains.cognitive_core.training_recipe_mlx_learnability_v56 import (
    SmokeConfig,
    _arrays,
    _optimizer,
    _predict,
    evaluate,
)
from scientist.domains.cognitive_core.training_recipe_model_v58 import (
    V58RelationalControlTransformer,
    parameter_count,
)
from scientist.domains.cognitive_core.training_recipe_model_v62 import (
    V62StateAnswerBridgeTransformer,
)
from scientist.domains.cognitive_core.training_recipe_state_bridge_data_v62 import (
    audit_dataset,
    load_split,
)


VERSION = "cognitive-core-state-answer-bridge-screen-v62-r1"
PREDECESSOR_SCREEN_ID = (
    "4b6961cc95fa8b2e822da3aa48bfd983a8dad8f1fa047bdfb105619755101876"
)
CANDIDATES = ("unbound", "state_bound")
ALLOCATION = {
    "answer": 32,
    "state": 32,
    "evidence_validity": 48,
    "tool_policy": 16,
}
MODEL_SEEDS = (64101, 64201)
DATA_SEEDS = (64111, 64211)
MINIMUM_MEAN_ARITHMETIC_GAIN = 0.03
MAXIMUM_SINGLE_SEED_ARITHMETIC_DECREMENT = 0.02
ARITHMETIC_FAMILY = "arithmetic_programs"


def _parameter_digest(model: nn.Module, *, base_only: bool = False) -> str:
    digest = hashlib.sha256()
    for name, array in tree_flatten(model.parameters()):
        if base_only and name.startswith("state_answer_bridge"):
            continue
        mx.eval(array)
        digest.update(name.encode("utf-8"))
        digest.update(str(tuple(array.shape)).encode("ascii"))
        digest.update(repr(array.tolist()).encode("utf-8"))
    return digest.hexdigest()


def _training_payload_digest(
    plan: Sequence[Sequence[Mapping[str, Any]]],
) -> str:
    return content_digest(
        [
            {"example_id": row["example_id"], "label": int(row["label"])}
            for batch in plan
            for row in batch
        ]
    )


def _train_candidate(
    candidate: str,
    plan: Sequence[Sequence[Mapping[str, Any]]],
    evaluation: Sequence[Mapping[str, Any]],
    evaluation_public: Sequence[Mapping[str, Any]],
    evaluation_authority: Sequence[Mapping[str, Any]],
    config: SmokeConfig,
    schedule_digest: str,
    evaluation_digest: str,
):
    if candidate not in CANDIDATES:
        raise ValueError("unknown V62 candidate: %s" % candidate)
    started = time.monotonic()
    mx.random.seed(config.model_seed)
    model = (
        V58RelationalControlTransformer(config)
        if candidate == "unbound"
        else V62StateAnswerBridgeTransformer(config)
    )
    mx.eval(model.parameters())
    initial_parameter_digest = _parameter_digest(model)
    initial_base_parameter_digest = _parameter_digest(model, base_only=True)
    parameters = parameter_count(model)
    optimizer = _optimizer(config, config.steps)

    def loss_fn(active_model, tokens, labels):
        return nn.losses.cross_entropy(
            active_model(tokens), labels, reduction="mean"
        )

    loss_and_grad = nn.value_and_grad(model, loss_fn)
    last_loss = float("nan")
    for batch in plan:
        tokens, labels = _arrays(batch)
        loss, gradients = loss_and_grad(model, tokens, labels)
        optimizer.update(model, gradients)
        mx.eval(model.parameters(), optimizer.state, loss)
        last_loss = float(loss.item())
    predictions = _predict(model, evaluation)
    metrics = evaluate(model, evaluation)
    learned_end_to_end = evaluate_end_to_end(
        evaluation_public,
        evaluation_authority,
        prediction_index(evaluation, predictions),
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "candidate": candidate,
        "config": config.as_dict(),
        "initial_parameter_digest": initial_parameter_digest,
        "initial_base_parameter_digest": initial_base_parameter_digest,
        "parameter_count": parameters,
        "training_schedule_digest": schedule_digest,
        "training_payload_digest": _training_payload_digest(plan),
        "evaluation_digest": evaluation_digest,
        "last_training_loss": last_loss,
        "metrics": metrics,
        "learned_end_to_end": learned_end_to_end,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "inferential": False,
    }
    result["run_id"] = content_digest(result)
    return result, predictions


def adjudicate_screen(
    records: Sequence[Mapping[str, Any]],
    verification_passed: bool,
) -> Mapping[str, Any]:
    by_seed = {}
    paired_effects = []
    for seed in MODEL_SEEDS:
        rows = {
            str(row["candidate"]): row
            for row in records
            if int(row["model_seed"]) == seed
        }
        if set(rows) != set(CANDIDATES):
            continue
        unbound = float(
            rows["unbound"]["core_family_accuracy"][ARITHMETIC_FAMILY]
        )
        state_bound = float(
            rows["state_bound"]["core_family_accuracy"][ARITHMETIC_FAMILY]
        )
        effect = state_bound - unbound
        paired_effects.append(effect)
        by_seed[str(seed)] = {
            "unbound_arithmetic_core_accuracy": unbound,
            "state_bound_arithmetic_core_accuracy": state_bound,
            "paired_arithmetic_effect": effect,
            "state_bound_full_gate_passed": rows["state_bound"]
            ["development_decision"]["passed"],
        }
    bound_rows = [row for row in records if row["candidate"] == "state_bound"]
    bound_passes = sum(
        int(row["development_decision"]["passed"]) for row in bound_rows
    )
    mean_effect = statistics.fmean(paired_effects) if paired_effects else float("nan")
    checks = {
        "execution_verification_passed": verification_passed,
        "two_complete_pairs": len(paired_effects) == 2,
        "state_bound_passes_two_of_two": len(bound_rows) == 2 and bound_passes == 2,
        "mean_arithmetic_gain_at_least_three_points": (
            len(paired_effects) == 2
            and mean_effect >= MINIMUM_MEAN_ARITHMETIC_GAIN
        ),
        "no_arithmetic_decrement_worse_than_two_points": (
            len(paired_effects) == 2
            and min(paired_effects) >= -MAXIMUM_SINGLE_SEED_ARITHMETIC_DECREMENT
        ),
    }
    eligible = all(checks.values())
    return {
        "paired_results": by_seed,
        "state_bound_full_gate_passes": bound_passes,
        "mean_paired_arithmetic_effect": mean_effect,
        "checks": checks,
        "state_bound_eligible": eligible,
        "v63_terminal_replication_authorized": eligible,
        "next_action": (
            "freeze_fresh_v63_terminal_replication_of_state_bound_recipe"
            if eligible
            else "freeze_state_first_teacher_forced_to_predicted_curriculum_screen"
        ),
    }


def prepare_screen(
    dataset_root: Path,
    capability_profile_path: Path,
    predecessor_result_path: Path,
) -> Mapping[str, Any]:
    predecessor = json.loads(predecessor_result_path.read_text(encoding="utf-8"))
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if (
        predecessor["screen_id"] != PREDECESSOR_SCREEN_ID
        or predecessor["decision"]["selected_candidate"] is not None
        or predecessor["decision"]["v62_replication_authorized"] is not False
    ):
        raise RuntimeError("V62 predecessor decision mismatch")
    train_public, train_authority = load_split(dataset_root, "state_bridge_train")
    development_public, development_authority = load_split(
        dataset_root, "state_bridge_development"
    )
    checks = {
        "v61_closed_without_candidate": True,
        "train_audit": audit_dataset(train_public, train_authority)["passed"],
        "development_audit": audit_dataset(
            development_public, development_authority
        )["passed"],
        "train_worlds_8192": len({row["base_id"] for row in train_public}) == 8192,
        "development_worlds_2048": (
            len({row["base_id"] for row in development_public}) == 2048
        ),
        "validity_heavy_allocation_fixed": ALLOCATION
        == {
            "answer": 32,
            "state": 32,
            "evidence_validity": 48,
            "tool_policy": 16,
        },
        "two_paired_seeds": len(MODEL_SEEDS) == len(DATA_SEEDS) == 2,
        "deterministic_delivery_fixed": True,
        "single_additive_architecture_intervention": True,
        "stop_gradient_state_edge": True,
    }
    plan: Dict[str, Any] = {
        "version": VERSION,
        "protocol_id": PROTOCOL_ID,
        "predecessor_screen_id": PREDECESSOR_SCREEN_ID,
        "dataset_manifest_id": json.loads(
            (dataset_root / "manifest.json").read_text(encoding="utf-8")
        )["manifest_id"],
        "capability_profile_id": profile["profile_id"],
        "candidates": list(CANDIDATES),
        "allocation": ALLOCATION,
        "model_seeds": list(MODEL_SEEDS),
        "data_seeds": list(DATA_SEEDS),
        "steps": 5200,
        "batch_size": 128,
        "minimum_mean_arithmetic_gain": MINIMUM_MEAN_ARITHMETIC_GAIN,
        "maximum_single_seed_arithmetic_decrement": (
            MAXIMUM_SINGLE_SEED_ARITHMETIC_DECREMENT
        ),
        "selection_rule": (
            "bound_two_of_two_full_gates_and_mean_paired_arithmetic_gain_ge_0.03_"
            "and_no_single_seed_effect_lt_minus_0.02"
        ),
        "checks": checks,
        "passed": all(checks.values()),
        "development_only": True,
        "v63_terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    plan["plan_id"] = content_digest(plan)
    return plan


def run_screen(
    dataset_root: Path,
    capability_profile_path: Path,
    plan_path: Path,
    progress_path: Path | None = None,
) -> Mapping[str, Any]:
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if not plan["passed"] or not plan["development_only"]:
        raise RuntimeError("V62 plan is not authorized")
    profile = json.loads(capability_profile_path.read_text(encoding="utf-8"))
    if profile["profile_id"] != plan["capability_profile_id"]:
        raise RuntimeError("V62 capability profile mismatch")
    train_public, train_authority = load_split(dataset_root, "state_bridge_train")
    development_public, development_authority = load_split(
        dataset_root, "state_bridge_development"
    )
    train_materialized = materialize_policy_labels(
        train_public, train_authority, profile
    )
    training = training_examples(train_public, train_materialized)
    if not audit_nuisance_controls(training)["passed"]:
        raise RuntimeError("V62 nuisance audit failed")
    development_materialized = materialize_policy_labels(
        development_public, development_authority, profile
    )
    development = training_examples(development_public, development_materialized)
    evaluation_digest = _evaluation_digest(development)
    mx.set_default_device(mx.gpu)
    started = time.monotonic()
    records = []
    for model_seed, data_seed in zip(MODEL_SEEDS, DATA_SEEDS):
        config = SmokeConfig(
            steps=int(plan["steps"]),
            batch_size=int(plan["batch_size"]),
            model_seed=model_seed,
            data_seed=data_seed,
            compute_device="gpu",
        )
        frozen_schedule = build_training_plan(training, ALLOCATION, config)
        schedule_digest = _schedule_digest(frozen_schedule)
        for candidate in CANDIDATES:
            trained, predictions = _train_candidate(
                candidate,
                frozen_schedule,
                development,
                development_public,
                development_materialized,
                config,
                schedule_digest,
                evaluation_digest,
            )
            deterministic_predictions = _deterministic_controller_predictions(
                development, development_public, predictions
            )
            deterministic_e2e = evaluate_end_to_end(
                development_public,
                development_materialized,
                deterministic_predictions,
            )
            core_family = _core_family_metrics(development, predictions)
            development_decision = adjudicate_model(
                trained["metrics"], core_family, deterministic_e2e
            )
            record: Dict[str, Any] = {
                **trained,
                "model_seed": model_seed,
                "data_seed": data_seed,
                "allocation": ALLOCATION,
                "core_family_accuracy": core_family,
                "deterministic_end_to_end": deterministic_e2e,
                "development_decision": development_decision,
            }
            record["record_id"] = content_digest(record)
            records.append(record)
            if progress_path is not None:
                progress_path.parent.mkdir(parents=True, exist_ok=True)
                progress_path.write_text(
                    json.dumps(
                        {
                            "version": VERSION,
                            "plan_id": plan["plan_id"],
                            "complete_records": records,
                            "complete_count": len(records),
                            "final_result_sealed": False,
                        },
                        indent=2,
                        sort_keys=True,
                    )
                    + "\n",
                    encoding="utf-8",
                )
            print(
                json.dumps(
                    {
                        "event": "v62_model_complete",
                        "candidate": candidate,
                        "model_seed": model_seed,
                        "development_passed": development_decision["passed"],
                        "elapsed_seconds": record["elapsed_seconds"],
                    },
                    sort_keys=True,
                ),
                flush=True,
            )
    pairing_checks = {}
    for seed in MODEL_SEEDS:
        paired = [row for row in records if row["model_seed"] == seed]
        pairing_checks[str(seed)] = {
            "two_candidates": len(paired) == 2
            and {row["candidate"] for row in paired} == set(CANDIDATES),
            "identical_base_initialization": len(
                {row["initial_base_parameter_digest"] for row in paired}
            )
            == 1,
            "identical_training_schedule": len(
                {row["training_schedule_digest"] for row in paired}
            )
            == 1,
            "identical_training_payload": len(
                {row["training_payload_digest"] for row in paired}
            )
            == 1,
        }
    parameter_counts = {
        row["candidate"]: row["parameter_count"] for row in records[:2]
    }
    checks = {
        "four_models_complete": len(records) == 4,
        "two_candidates_per_seed": all(
            row["two_candidates"] for row in pairing_checks.values()
        ),
        "paired_base_initialization": all(
            row["identical_base_initialization"] for row in pairing_checks.values()
        ),
        "paired_training_schedule": all(
            row["identical_training_schedule"] for row in pairing_checks.values()
        ),
        "paired_training_payload": all(
            row["identical_training_payload"] for row in pairing_checks.values()
        ),
        "identical_evaluation_cases": len(
            {row["evaluation_digest"] for row in records}
        )
        == 1,
        "bridge_adds_exactly_256_parameters": (
            parameter_counts.get("state_bound", 0)
            - parameter_counts.get("unbound", 0)
            == 256
        ),
    }
    verification_passed = all(checks.values())
    decision = adjudicate_screen(records, verification_passed)
    result: Dict[str, Any] = {
        "version": VERSION,
        "plan_id": plan["plan_id"],
        "dataset_manifest_id": plan["dataset_manifest_id"],
        "capability_profile_id": plan["capability_profile_id"],
        "predecessor_screen_id": PREDECESSOR_SCREEN_ID,
        "records": records,
        "pairing_checks": pairing_checks,
        "checks": checks,
        "verification_passed": verification_passed,
        "decision": decision,
        "elapsed_seconds": time.monotonic() - started,
        "framework": "mlx",
        "hardware": platform.platform(),
        "development_only": True,
        "v63_terminal_data_opened": False,
        "inferential": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
        "next_action": decision["next_action"],
    }
    result["screen_id"] = content_digest(result)
    return result


def _write_immutable(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V62 artifact: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def write_plan(path: Path, plan: Mapping[str, Any]) -> None:
    _write_immutable(path, json.dumps(plan, indent=2, sort_keys=True) + "\n")


def write_result(output: Path, result: Mapping[str, Any]) -> None:
    _write_immutable(
        output / "result.json",
        json.dumps(result, indent=2, sort_keys=True) + "\n",
    )
    rows = []
    for record in result["records"]:
        observations = record["development_decision"]["observations"]
        rows.append(
            "| %d | %s | %s | %.1f%% | %.1f%% | %.1f%% | %+.1f pp | %.1f%% |"
            % (
                record["model_seed"],
                record["candidate"],
                record["development_decision"]["passed"],
                observations["answer_accuracy"] * 100.0,
                observations["evidence_validity_accuracy"] * 100.0,
                record["core_family_accuracy"][ARITHMETIC_FAMILY] * 100.0,
                observations["deterministic_clean_tool_value"] * 100.0,
                observations["deterministic_invalid_acceptance"] * 100.0,
            )
        )
    report = "\n".join(
        (
            "# Cognitive-core V62 state-to-answer bridge screen",
            "",
            "- Execution verification passed: **%s**" % result["verification_passed"],
            "- State-bound candidate eligible: **%s**"
            % result["decision"]["state_bound_eligible"],
            "- Mean paired arithmetic effect: **%+.1f percentage points**"
            % (result["decision"]["mean_paired_arithmetic_effect"] * 100.0),
            "- V63 terminal replication authorized: **%s**"
            % result["decision"]["v63_terminal_replication_authorized"],
            "- V63 terminal data opened: **False**",
            "- Scientific effect claim authorized: **False**",
            "- 20M-50M execution authorized: **False**",
            "- 3B training authorized: **False**",
            "- Screen ID: `%s`" % result["screen_id"],
            "",
            "| Seed | Candidate | Full pass | Answer | Validity | Arithmetic core | Deterministic clean value | Invalid accept |",
            "|---:|---|---|---:|---:|---:|---:|---:|",
            *rows,
            "",
            "Next action: `%s`." % result["next_action"],
            "",
        )
    )
    _write_immutable(output / "LOCAL_RESULTS.md", report)


__all__ = [
    "ALLOCATION",
    "ARITHMETIC_FAMILY",
    "CANDIDATES",
    "VERSION",
    "adjudicate_screen",
    "prepare_screen",
    "run_screen",
    "write_plan",
    "write_result",
]
