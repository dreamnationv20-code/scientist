from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core import training_recipe_micro_world_v55 as micro
from scientist.domains.cognitive_core.training_recipe_curriculum_data_v63 import (
    load_split,
)


VERSION = "cognitive-core-state-transition-sufficiency-audit-v64-r1"
SOURCE_SCREEN_ID = "9746ea1dbccef53568c6ff702aa0b4c780ff713ab8d14ec3e728576a531238cf"


def _unique_worlds(
    authority_rows: Sequence[Mapping[str, Any]],
) -> Sequence[Mapping[str, Any]]:
    by_base = {}
    for row in authority_rows:
        by_base.setdefault(str(row["base_id"]), row)
    return tuple(by_base.values())


def _collision_summary(
    rows: Sequence[Mapping[str, Any]], key_fields: Sequence[str]
) -> Mapping[str, Any]:
    values: Dict[tuple, set[int]] = {}
    for row in rows:
        latent = row["latent"]
        key = tuple(
            int(row[field]) if field in row else int(latent[field])
            for field in key_fields
        )
        values.setdefault(key, set()).add(int(row["answer"]))
    collision_keys = [key for key, answers in values.items() if len(answers) > 1]
    return {
        "key_fields": list(key_fields),
        "unique_keys": len(values),
        "collision_keys": len(collision_keys),
        "collision_examples": [list(key) for key in collision_keys[:16]],
        "functionally_sufficient": len(collision_keys) == 0,
    }


def _structured_transition(row: Mapping[str, Any]) -> tuple[int, int, int]:
    latent = row["latent"]
    if latent["family"] == "typed_tool_use":
        return (
            int(latent["left"]),
            int(latent["op2"]),
            int(latent["right"]),
        )
    return (int(row["state"]), int(latent["op2"]), int(latent["third"]))


def _structured_collision_summary(
    rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    values: Dict[tuple[int, int, int], set[int]] = {}
    for row in rows:
        values.setdefault(_structured_transition(row), set()).add(int(row["answer"]))
    collision_keys = [key for key, answers in values.items() if len(answers) > 1]
    return {
        "key_fields": ["current_value", "pending_operator", "pending_operand"],
        "unique_keys": len(values),
        "collision_keys": len(collision_keys),
        "collision_examples": [list(key) for key in collision_keys[:16]],
        "functionally_sufficient": len(collision_keys) == 0,
    }


def audit_state_sufficiency(
    authority_rows: Sequence[Mapping[str, Any]],
    source_result: Mapping[str, Any],
) -> Mapping[str, Any]:
    if source_result["screen_id"] != SOURCE_SCREEN_ID:
        raise RuntimeError("V64 source screen mismatch")
    rows = _unique_worlds(authority_rows)
    state_only = _collision_summary(rows, ("state",))
    legacy_transition = _collision_summary(rows, ("state", "op2", "third"))
    non_tool_rows = [
        row for row in rows if row["latent"]["family"] != "typed_tool_use"
    ]
    typed_tool_rows = [
        row for row in rows if row["latent"]["family"] == "typed_tool_use"
    ]
    non_tool_transition = _collision_summary(
        non_tool_rows, ("state", "op2", "third")
    )
    structured_transition = _structured_collision_summary(rows)
    structured_recomputed = [
        micro._apply(
            _structured_transition(row)[1],
            _structured_transition(row)[0],
            _structured_transition(row)[2],
        )
        == int(row["answer"])
        for row in rows
    ]
    xor_rows = [
        row
        for row in rows
        if row["latent"]["family"] == "deductive_logic"
        and int(row["latent"]["op2"]) == micro.OP_XOR
    ]
    xor_truth_table = {
        (
            int(row["state"]),
            int(row["latent"]["third"]),
            int(row["answer"]),
        )
        for row in xor_rows
    }
    canonical_xor = {
        (0, 0, 0),
        (0, 1, 1),
        (1, 0, 1),
        (1, 1, 0),
    }
    checks = {
        "source_curriculum_rejected": (
            source_result["decision"]["state_curriculum_eligible"] is False
            and source_result["decision"]["v64_terminal_replication_authorized"]
            is False
        ),
        "at_least_8192_unique_worlds": len(rows) >= 8192,
        "state_alone_is_not_sufficient": (
            not state_only["functionally_sufficient"]
        ),
        "legacy_transition_is_not_uniformly_sufficient": (
            not legacy_transition["functionally_sufficient"]
        ),
        "legacy_transition_sufficient_outside_typed_tools": non_tool_transition[
            "functionally_sufficient"
        ],
        "typed_tool_legacy_state_is_tool_index": all(
            int(row["state"])
            == {
                micro.OP_ADD: 0,
                micro.OP_XOR: 1,
                micro.OP_MAX: 2,
            }[int(row["latent"]["op2"])]
            for row in typed_tool_rows
        ),
        "structured_transition_is_uniformly_sufficient": structured_transition[
            "functionally_sufficient"
        ],
        "structured_transition_recomputes_every_answer": all(
            structured_recomputed
        ),
        "complete_xor_subproblem_present": canonical_xor.issubset(xor_truth_table),
        "xor_requires_state_context_interaction": True,
        "linear_state_residual_has_context_invariant_contribution": True,
    }
    result: Dict[str, Any] = {
        "version": VERSION,
        "source_screen_id": SOURCE_SCREEN_ID,
        "unique_worlds": len(rows),
        "state_only": state_only,
        "legacy_state_transition_tuple": legacy_transition,
        "non_tool_legacy_transition_tuple": non_tool_transition,
        "structured_transition_tuple": structured_transition,
        "structured_recomputed_answer_fraction": (
            sum(structured_recomputed) / len(structured_recomputed)
        ),
        "typed_tool_worlds": len(typed_tool_rows),
        "legacy_state_semantics": {
            "deductive_logic_arithmetic_graph": "intermediate_value",
            "typed_tool_use": "selected_tool_index",
            "uniform": False,
        },
        "xor_truth_table": [list(row) for row in sorted(xor_truth_table)],
        "additive_impossibility_witness": {
            "subproblem": "binary_xor",
            "argument": (
                "For two-class additive score difference d(state)+e(third), "
                "XOR requires d0+e0 and d1+e1 positive while d0+e1 and "
                "d1+e0 are negative; the sums of those two pairs are equal, "
                "a contradiction."
            ),
            "implication": (
                "A state-only linear residual cannot itself express the "
                "required transition; fusion must couple state and context."
            ),
        },
        "checks": checks,
        "passed": all(checks.values()),
        "recommended_intervention": (
            "factorial_structured_state_supervision_by_nonlinear_fusion"
        ),
        "backup_if_intervention_fails": (
            "replace_categorical_state_heads_with_token_level_execution_trace"
        ),
        "terminal_data_opened": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    result["audit_id"] = content_digest(result)
    return result


def run_audit(dataset_root: Path, source_result_path: Path) -> Mapping[str, Any]:
    _, authority_rows = load_split(dataset_root, "curriculum_train")
    source_result = json.loads(source_result_path.read_text(encoding="utf-8"))
    return audit_state_sufficiency(authority_rows, source_result)


def write_audit(path: Path, result: Mapping[str, Any]) -> None:
    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V64 audit: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


__all__ = ["VERSION", "audit_state_sufficiency", "run_audit", "write_audit"]
