from __future__ import annotations

import random
from collections import Counter
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core import training_recipe_micro_world_v55 as micro


VERSION = "cognitive-core-structured-transition-state-v65-r1"
NUISANCE_SEED = 65991
COMPONENTS = ("current_value", "pending_operator", "pending_operand")
OPERATOR_TOKENS = (
    micro.OP_AND,
    micro.OP_OR,
    micro.OP_XOR,
    micro.OP_ADD,
    micro.OP_SUB,
    micro.OP_MUL,
    micro.OP_MAX,
)
OPERATOR_TO_CLASS = {token: index for index, token in enumerate(OPERATOR_TOKENS)}
CLASS_TO_OPERATOR = {index: token for token, index in OPERATOR_TO_CLASS.items()}


def structured_state(authority: Mapping[str, Any]) -> Mapping[str, int]:
    latent = authority["latent"]
    if latent["family"] == "typed_tool_use":
        current_value = int(latent["left"])
        pending_operand = int(latent["right"])
    else:
        current_value = int(authority["state"])
        pending_operand = int(latent["third"])
    return {
        "current_value": current_value,
        "pending_operator": OPERATOR_TO_CLASS[int(latent["op2"])],
        "pending_operand": pending_operand,
    }


def attach_structured_controls(
    examples: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Tuple[Mapping[str, Any], ...]:
    authority_by_view = {
        str(row["view_id"]): row for row in authority_rows
    }
    semantic_by_view = {
        view_id: structured_state(authority)
        for view_id, authority in authority_by_view.items()
    }
    state_rows = sorted(
        (row for row in examples if row["target"] == "state"),
        key=lambda row: str(row["example_id"]),
    )
    state_views = [str(row["view_id"]) for row in state_rows]
    nuisance_by_component: Dict[str, Dict[str, int]] = {}
    for component_index, component in enumerate(COMPONENTS):
        semantic_values = [semantic_by_view[view][component] for view in state_views]
        indices = list(range(len(state_views)))
        random.Random(NUISANCE_SEED + 1009 * component_index).shuffle(indices)
        nuisance_by_component[component] = {
            view: int(semantic_values[source])
            for view, source in zip(state_views, indices)
        }
    result = []
    for row in examples:
        view_id = str(row["view_id"])
        semantic = semantic_by_view[view_id]
        nuisance = {
            component: nuisance_by_component[component][view_id]
            for component in COMPONENTS
        }
        result.append(
            {
                **row,
                "structured_semantic": semantic,
                "structured_nuisance": nuisance,
            }
        )
    return tuple(result)


def audit_structured_controls(
    examples: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any]:
    authority_by_view = {
        str(row["view_id"]): row for row in authority_rows
    }
    state_rows = [row for row in examples if row["target"] == "state"]
    checks: Dict[str, bool] = {
        "one_state_row_per_view": len(state_rows) == len(authority_by_view),
        "fixed_sequence_length": all(len(row["tokens"]) == 32 for row in examples),
        "structured_fields_not_arm_identity": all(
            "arm" not in row and "factors" not in row for row in examples
        ),
    }
    for component in COMPONENTS:
        semantic_histogram = Counter(
            int(row["structured_semantic"][component]) for row in state_rows
        )
        nuisance_histogram = Counter(
            int(row["structured_nuisance"][component]) for row in state_rows
        )
        checks[f"{component}_histogram_exact"] = (
            semantic_histogram == nuisance_histogram
        )
        checks[f"{component}_permutation_active"] = any(
            int(row["structured_semantic"][component])
            != int(row["structured_nuisance"][component])
            for row in state_rows
        )
        checks[f"{component}_nuisance_side_channel_present"] = all(
            0 <= int(row["structured_nuisance"][component])
            < (7 if component == "pending_operator" else 16)
            for row in state_rows
        )
    transition_correct = []
    tuple_answers: Dict[tuple[int, int, int], set[int]] = {}
    for view_id, authority in authority_by_view.items():
        structured = structured_state(authority)
        operator = CLASS_TO_OPERATOR[structured["pending_operator"]]
        computed = micro._apply(
            operator,
            structured["current_value"],
            structured["pending_operand"],
        )
        answer = int(authority["answer"])
        transition_correct.append(computed == answer)
        key = tuple(structured[component] for component in COMPONENTS)
        tuple_answers.setdefault(key, set()).add(answer)
    checks["structured_transition_reexecutes_all_answers"] = all(
        transition_correct
    )
    checks["structured_transition_has_no_answer_collisions"] = all(
        len(answers) == 1 for answers in tuple_answers.values()
    )
    result: Dict[str, Any] = {
        "version": VERSION,
        "rows": len(examples),
        "state_rows": len(state_rows),
        "unique_transition_tuples": len(tuple_answers),
        "checks": checks,
        "passed": all(checks.values()),
    }
    result["audit_id"] = content_digest(result)
    return result


__all__ = [
    "CLASS_TO_OPERATOR",
    "COMPONENTS",
    "OPERATOR_TOKENS",
    "OPERATOR_TO_CLASS",
    "VERSION",
    "attach_structured_controls",
    "audit_structured_controls",
    "structured_state",
]
