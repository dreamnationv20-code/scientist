from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core import training_recipe_micro_world_v55 as micro
from scientist.domains.cognitive_core.training_recipe_specificity_data_v67 import (
    load_split,
)
from scientist.domains.cognitive_core.training_recipe_structured_state_v65 import (
    CLASS_TO_OPERATOR,
    COMPONENTS,
    structured_state,
)


VERSION = "cognitive-core-autoregressive-trace-feasibility-v68t-r2"
SOURCE_SPECIFICITY_ID = (
    "1edc3493480ed0f6f3aaeaadc9627dfa510a06790395557c724250e8322dc135"
)
BOS_TOKEN = 0
CURRENT_BASE = 1
OPERATOR_BASE = CURRENT_BASE + 16
# OP_SUB is used as a first-stage operator in the arithmetic generator, but it
# is never a pending (second-stage) operator.  Giving it a trace token would
# therefore create an unsupported output class.  Preserve the established
# semantic class IDs while compacting only the trace-token labels.
ACTIVE_OPERATOR_CLASSES = (0, 1, 2, 3, 5, 6)
OPERATOR_CLASS_TO_TRACE_LABEL = {
    semantic_class: trace_label
    for trace_label, semantic_class in enumerate(ACTIVE_OPERATOR_CLASSES)
}
TRACE_LABEL_TO_OPERATOR_CLASS = {
    trace_label: semantic_class
    for semantic_class, trace_label in OPERATOR_CLASS_TO_TRACE_LABEL.items()
}
OPERAND_BASE = OPERATOR_BASE + len(ACTIVE_OPERATOR_CLASSES)
ANSWER_BASE = OPERAND_BASE + 16
EOS_TOKEN = ANSWER_BASE + 16
TRACE_VOCAB_SIZE = EOS_TOKEN + 1
TRACE_LENGTH = 5
SPLITS = ("specificity_train", "specificity_development")


def compile_trace(authority: Mapping[str, Any]) -> tuple[int, ...]:
    state = structured_state(authority)
    return (
        CURRENT_BASE + int(state["current_value"]),
        OPERATOR_BASE
        + OPERATOR_CLASS_TO_TRACE_LABEL[int(state["pending_operator"])],
        OPERAND_BASE + int(state["pending_operand"]),
        ANSWER_BASE + int(authority["answer"]),
        EOS_TOKEN,
    )


def decode_trace(trace: Sequence[int]) -> Mapping[str, int]:
    if len(trace) != TRACE_LENGTH:
        raise ValueError("trace must contain exactly five tokens")
    current, operator, operand, answer, eos = (int(value) for value in trace)
    if not CURRENT_BASE <= current < OPERATOR_BASE:
        raise ValueError("invalid current-value token")
    if not OPERATOR_BASE <= operator < OPERAND_BASE:
        raise ValueError("invalid operator token")
    if not OPERAND_BASE <= operand < ANSWER_BASE:
        raise ValueError("invalid operand token")
    if not ANSWER_BASE <= answer < EOS_TOKEN:
        raise ValueError("invalid answer token")
    if eos != EOS_TOKEN:
        raise ValueError("invalid EOS token")
    return {
        "current_value": current - CURRENT_BASE,
        "pending_operator": TRACE_LABEL_TO_OPERATOR_CLASS[
            operator - OPERATOR_BASE
        ],
        "pending_operand": operand - OPERAND_BASE,
        "answer": answer - ANSWER_BASE,
    }


def _counterfactual_available(decoded: Mapping[str, int]) -> Mapping[str, bool]:
    original = int(decoded["answer"])
    result = {}
    domains = {
        "current_value": range(16),
        "pending_operator": ACTIVE_OPERATOR_CLASSES,
        "pending_operand": range(16),
    }
    for component, values in domains.items():
        changes = []
        for candidate in values:
            if candidate == int(decoded[component]):
                continue
            counterfactual = dict(decoded)
            counterfactual[component] = candidate
            computed = micro._apply(
                CLASS_TO_OPERATOR[counterfactual["pending_operator"]],
                counterfactual["current_value"],
                counterfactual["pending_operand"],
            )
            changes.append(int(computed) != original)
        result[component] = any(changes)
    return result


def audit_split(
    public_rows: Sequence[Mapping[str, Any]],
    authority_rows: Sequence[Mapping[str, Any]],
    split: str,
) -> Mapping[str, Any]:
    public_by_view = {str(row["view_id"]): row for row in public_rows}
    traces_by_base: Dict[str, set[tuple[int, ...]]] = {}
    answers_by_prefix: Dict[tuple[int, int, int], set[int]] = {}
    token_counts: Counter[int] = Counter()
    reexecution = []
    counterfactuals = {component: [] for component in COMPONENTS}
    counterfactuals_by_family: Dict[
        str, Dict[str, list[bool]]
    ] = {}
    seen_counterfactual_base_ids: set[str] = set()
    public_firewall = []
    trace_records = []
    forbidden_public_fields = {
        "trace",
        "trace_tokens",
        "current_value",
        "pending_operator",
        "pending_operand",
        "answer",
        "state",
    }
    for authority in authority_rows:
        view_id = str(authority["view_id"])
        trace = compile_trace(authority)
        decoded = decode_trace(trace)
        computed = micro._apply(
            CLASS_TO_OPERATOR[decoded["pending_operator"]],
            decoded["current_value"],
            decoded["pending_operand"],
        )
        reexecution.append(
            int(computed) == decoded["answer"] == int(authority["answer"])
        )
        base_id = str(authority["base_id"])
        traces_by_base.setdefault(base_id, set()).add(trace)
        prefix = tuple(trace[:3])
        answers_by_prefix.setdefault(prefix, set()).add(decoded["answer"])
        token_counts.update(trace)
        if base_id not in seen_counterfactual_base_ids:
            seen_counterfactual_base_ids.add(base_id)
            availability = _counterfactual_available(decoded)
            family = str(authority["latent"]["family"])
            family_records = counterfactuals_by_family.setdefault(
                family, {component: [] for component in COMPONENTS}
            )
            for component in COMPONENTS:
                counterfactuals[component].append(availability[component])
                family_records[component].append(availability[component])
        public_firewall.append(
            not forbidden_public_fields.intersection(public_by_view[view_id])
        )
        trace_records.append(
            {"view_id": view_id, "base_id": base_id, "trace": list(trace)}
        )

    expected_tokens = set(range(CURRENT_BASE, OPERATOR_BASE))
    expected_tokens.update(range(OPERATOR_BASE, OPERAND_BASE))
    expected_tokens.update(range(OPERAND_BASE, ANSWER_BASE))
    expected_tokens.update(range(ANSWER_BASE, EOS_TOKEN))
    expected_tokens.add(EOS_TOKEN)
    counterfactual_rates = {
        component: sum(values) / len(values)
        for component, values in counterfactuals.items()
    }
    counterfactual_counts_by_family = {
        family: {
            component: sum(values)
            for component, values in component_records.items()
        }
        for family, component_records in counterfactuals_by_family.items()
    }
    counterfactual_rates_by_family = {
        family: {
            component: sum(values) / len(values)
            for component, values in component_records.items()
        }
        for family, component_records in counterfactuals_by_family.items()
    }
    checks = {
        "row_alignment": len(public_rows) == len(authority_rows)
        and set(public_by_view)
        == {str(row["view_id"]) for row in authority_rows},
        "fixed_trace_length": all(
            len(record["trace"]) == TRACE_LENGTH for record in trace_records
        ),
        "disjoint_position_token_ranges": (
            CURRENT_BASE < OPERATOR_BASE < OPERAND_BASE < ANSWER_BASE < EOS_TOKEN
        ),
        "all_trace_tokens_in_vocabulary": set(token_counts)
        .issubset(set(range(TRACE_VOCAB_SIZE))),
        "all_semantic_trace_tokens_observed": expected_tokens.issubset(
            set(token_counts)
        ),
        "trace_reexecutes_every_answer": all(reexecution),
        "prefix_has_no_answer_collisions": all(
            len(answers) == 1 for answers in answers_by_prefix.values()
        ),
        "trace_invariant_across_observation_variants": all(
            len(traces) == 1 for traces in traces_by_base.values()
        ),
        "trace_fields_absent_from_public_rows": all(public_firewall),
        # Some Boolean transitions (for example AND(0, 0)) are locally
        # constant under a one-token edit.  Requiring every world to be
        # intervenable would silently remove a legitimate semantic stratum.
        # The screen instead evaluates interventions on an audited eligible
        # subset, with at least 50% support in every family and component.
        "each_family_component_has_majority_counterfactual_support": all(
            rate >= 0.5
            for component_rates in counterfactual_rates_by_family.values()
            for rate in component_rates.values()
        ),
    }
    result: Dict[str, Any] = {
        "version": VERSION,
        "split": split,
        "public_rows": len(public_rows),
        "authority_rows": len(authority_rows),
        "base_worlds": len(traces_by_base),
        "unique_trace_prefixes": len(answers_by_prefix),
        "trace_vocab_size": TRACE_VOCAB_SIZE,
        "trace_length": TRACE_LENGTH,
        "counterfactual_availability": counterfactual_rates,
        "counterfactual_counts_by_family": counterfactual_counts_by_family,
        "counterfactual_rates_by_family": counterfactual_rates_by_family,
        "counterfactual_eligibility_rule": (
            "evaluate each component intervention only on base worlds where "
            "an in-support one-token edit changes the reexecuted answer"
        ),
        "trace_payload_digest": content_digest({"records": trace_records}),
        "checks": checks,
        "passed": all(checks.values()),
    }
    result["audit_id"] = content_digest(result)
    return result


def run_audit(
    dataset_root: Path, source_result_path: Path
) -> Mapping[str, Any]:
    source = json.loads(source_result_path.read_text(encoding="utf-8"))
    source_candidate = dict(source)
    observed_source_id = source_candidate.pop("specificity_id")
    source_checks = {
        "source_digest_valid": observed_source_id
        == content_digest(source_candidate),
        "source_specificity_matches": source["specificity_id"]
        == SOURCE_SPECIFICITY_ID,
        "source_execution_verified": source["verification_passed"] is True,
        "source_specificity_rejected": source["decision"]
        ["semantic_specificity_established"]
        is False,
        "source_selected_trace_pivot": source["next_action"]
        == "pivot_to_token_execution_trace",
    }
    split_audits = {}
    for split in SPLITS:
        public_rows, authority_rows = load_split(dataset_root, split)
        split_audits[split] = audit_split(
            public_rows, authority_rows, split
        )
    checks = {
        **source_checks,
        "all_split_audits_pass": all(
            audit["passed"] for audit in split_audits.values()
        ),
        "free_running_evaluation_required": True,
        "teacher_forcing_not_valid_for_selection": True,
        "trace_prefix_interventions_required": True,
        "categorical_state_bridge_retired": True,
        "development_only": True,
    }
    result: Dict[str, Any] = {
        "version": VERSION,
        "source_specificity_id": SOURCE_SPECIFICITY_ID,
        "trace_schema": {
            "bos_token": BOS_TOKEN,
            "positions": [
                {"name": "current_value", "base": CURRENT_BASE, "classes": 16},
                {
                    "name": "pending_operator",
                    "base": OPERATOR_BASE,
                    "classes": len(ACTIVE_OPERATOR_CLASSES),
                    "semantic_class_values": list(ACTIVE_OPERATOR_CLASSES),
                },
                {"name": "pending_operand", "base": OPERAND_BASE, "classes": 16},
                {"name": "answer", "base": ANSWER_BASE, "classes": 16},
                {"name": "eos", "token": EOS_TOKEN, "classes": 1},
            ],
            "vocab_size": TRACE_VOCAB_SIZE,
            "trace_length": TRACE_LENGTH,
            "causal_order": (
                "context -> current -> operator -> operand -> answer -> eos"
            ),
        },
        "split_audits": split_audits,
        "checks": checks,
        "passed": all(checks.values()),
        "recommended_next_action": (
            "freeze_v68_autoregressive_execution_trace_screen"
        ),
        "screen_requirements": {
            "free_running_primary_evaluation": True,
            "teacher_forced_metrics_diagnostic_only": True,
            "matched_direct_answer_baseline": True,
            "permuted_trace_prefix_intervention": True,
            "uniform_trace_prefix_intervention": True,
            "evidence_validity_joint_gate": True,
            "three_independent_seed_blocks": True,
        },
        "development_only": True,
        "terminal_data_opened": False,
        "scientific_effect_claim_authorized": False,
        "twenty_to_fifty_million_execution_authorized": False,
        "three_billion_training_authorized": False,
    }
    result["audit_id"] = content_digest(result)
    return result


def write_audit(path: Path, result: Mapping[str, Any]) -> None:
    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_text(encoding="utf-8") != text:
        raise RuntimeError("refusing to overwrite immutable V68T audit: %s" % path)
    if not path.exists():
        path.write_text(text, encoding="utf-8")


__all__ = [
    "ACTIVE_OPERATOR_CLASSES",
    "ANSWER_BASE",
    "BOS_TOKEN",
    "CURRENT_BASE",
    "EOS_TOKEN",
    "OPERATOR_BASE",
    "OPERAND_BASE",
    "SOURCE_SPECIFICITY_ID",
    "TRACE_LENGTH",
    "TRACE_VOCAB_SIZE",
    "VERSION",
    "audit_split",
    "compile_trace",
    "decode_trace",
    "run_audit",
    "write_audit",
]
