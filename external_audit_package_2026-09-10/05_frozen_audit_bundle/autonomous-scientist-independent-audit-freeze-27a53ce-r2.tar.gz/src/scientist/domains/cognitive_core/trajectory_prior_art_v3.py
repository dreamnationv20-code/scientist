from __future__ import annotations

from scientist.program.literature import (
    ClaimClassification,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)


TRAJECTORY_PRIOR_ART_PLAN_VERSION = "cognitive-trajectory-prior-art-plan-v3"


def build_trajectory_prior_art_plan(kernel, domain) -> PriorArtAssessment:
    if kernel.mission is None:
        raise ValueError("trajectory prior-art planning requires a frozen mission")
    if kernel.mission.domain_id != domain.domain_id:
        raise ValueError("trajectory prior-art mission and domain disagree")
    incumbent = PriorWork(
        work_id="doi:10.48550/arxiv.2203.11171",
        title="Self-Consistency Improves Chain of Thought Reasoning in Language Models",
        year=2022,
        locator="https://doi.org/10.48550/arXiv.2203.11171",
        relation=PriorArtRelation.EXECUTABLE_BASELINE,
        matched_components=(
            "test-time sampling intervention",
            "answer aggregation across reasoning paths",
            "published executable inference baseline",
        ),
        executable=True,
    )
    test_time_scaling = PriorWork(
        work_id="doi:10.48550/arxiv.2408.03314",
        title=(
            "Scaling LLM Test-Time Compute Optimally can be More Effective "
            "than Scaling Model Parameters"
        ),
        year=2024,
        locator="https://doi.org/10.48550/arXiv.2408.03314",
        relation=PriorArtRelation.STRONG_OVERLAP,
        matched_components=(
            "adaptive test-time compute",
            "difficulty-conditioned inference allocation",
            "compute-performance frontier",
        ),
    )
    queries = tuple(
        LiteratureQuery(query=query, facet=facet, provider="frozen-trajectory-query-plan")
        for query, facet in (
            (
                "language model reasoning failure prediction test time compute allocation",
                SearchFacet.PROBLEM,
            ),
            (
                "adaptive inference compute chain of thought self consistency language models",
                SearchFacet.INTERVENTION,
            ),
            (
                "language model hidden state trajectory dynamics convergence reasoning correctness",
                SearchFacet.MECHANISM,
            ),
            (
                "language model reasoning trajectory oscillation diffusion early exit confidence",
                SearchFacet.MECHANISM,
            ),
            (
                "prospective prediction test time scaling language model reasoning matched compute",
                SearchFacet.EVALUATION,
            ),
        )
    )
    return PriorArtAssessment(
        signature=kernel.mission.claim_signature,
        trigger=LiteratureTrigger.NEW_PHENOMENON,
        queries=queries,
        closest_works=(incumbent, test_time_scaling),
        classification=ClaimClassification.NOVEL_CANDIDATE,
        rationale=(
            "The frozen prior position is that self-consistency and adaptive "
            "test-time scaling establish compute interventions, but do not by "
            "themselves establish an answer-blind failure-unit causal predictor "
            "based on pre-answer trajectory convergence, oscillation, or diffusion."
        ),
        novel_delta=(
            "Predict compute repair at the individual baseline-failure level before intervention outcomes rather than allocate compute from average difficulty.",
            "Use token-identity-free temporal trajectory descriptors and test their causal interaction with a cost-matched compute intervention.",
            "Require cross-size, held-regime, and independent-replication transport against family, complexity, generic-compute, and rejected-concept baselines.",
        ),
        citation_snowball_complete=False,
        searched_at="2026-09-08",
        reviewer_ref=TRAJECTORY_PRIOR_ART_PLAN_VERSION,
        executable_incumbent_id=incumbent.work_id,
    )


__all__ = [
    "TRAJECTORY_PRIOR_ART_PLAN_VERSION",
    "build_trajectory_prior_art_plan",
]
