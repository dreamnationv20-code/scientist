from __future__ import annotations

import gc
import hashlib
import json
import time
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Sequence

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.cognitive_core.internal_core_v28 import _batch_responses, _chat_prompt
from scientist.domains.cognitive_core.repair_benchmark_v32 import (
    REPAIR_BENCHMARK_VERSION,
    RepairTask,
    apply_edit,
    build_suite,
    execute,
    parse_program,
    score_program,
)
from scientist.domains.cognitive_core.repair_trajectory_data_v34 import (
    TRAJECTORY_DATA_VERSION,
    localized_revision_prompt,
    regeneration_prompt,
    regeneration_revision_prompt,
)


TRAJECTORY_REPAIR_VERSION = "general-cognitive-trajectory-repair-v34"


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _first_failing_case(task: RepairTask, program: Mapping[str, Any] | None) -> Mapping[str, Any]:
    if program is None:
        return task.counterexample
    for case in (task.counterexample,) + task.hidden_cases:
        try:
            observed = execute(task.representation, program, case["input"])
        except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
            return case
        if observed != case["expected"]:
            return case
    return {}


def _passes_revealed_verifier(
    task: RepairTask,
    program: Mapping[str, Any] | None,
    revealed_case: Mapping[str, Any],
) -> bool:
    if program is None:
        return False
    cases = list(task.visible_correct)
    if revealed_case:
        cases.append(revealed_case)
    for case in cases:
        try:
            if execute(task.representation, program, case["input"]) != case["expected"]:
                return False
        except (ArithmeticError, IndexError, KeyError, TypeError, ValueError):
            return False
    return True


def aggregate_trajectory_branch(
    condition: str,
    tasks: Sequence[RepairTask],
    first_responses: Sequence[str],
    revision_responses: Sequence[str],
    parser: Callable[[RepairTask, str], Mapping[str, Any] | None],
) -> Mapping[str, Any]:
    if not (len(tasks) == len(first_responses) == len(revision_responses)):
        raise ValueError("tasks and trajectory responses do not align")
    records = []
    by_representation: Dict[str, list[Mapping[str, Any]]] = {}
    for task, first_response, revision_response in zip(tasks, first_responses, revision_responses):
        first_program = parser(task, first_response)
        revision_program = parser(task, revision_response)
        revealed_case = _first_failing_case(task, first_program)
        revision_accepted = bool(revealed_case) and _passes_revealed_verifier(
            task, revision_program, revealed_case
        )
        final_program = revision_program if revision_accepted else first_program
        first_score = score_program(task, first_program)
        final_score = score_program(task, final_program)
        assessment = {
            "first_semantic_accuracy": first_score["semantic_accuracy"],
            "final_semantic_accuracy": final_score["semantic_accuracy"],
            "semantic_gain": final_score["semantic_accuracy"] - first_score["semantic_accuracy"],
            "first_preserved_correct_accuracy": first_score["preserved_correct_accuracy"],
            "final_preserved_correct_accuracy": final_score["preserved_correct_accuracy"],
            "first_exact": first_score["exact_program"],
            "final_exact": final_score["exact_program"],
            "revision_accepted": revision_accepted,
        }
        records.append(
            {
                "task_id": task.task_id,
                "representation": task.representation,
                "first_response": first_response,
                "revision_response": revision_response,
                "revealed_case": revealed_case,
                "assessment": assessment,
            }
        )
        by_representation.setdefault(task.representation, []).append(assessment)

    def summarize(items: Sequence[Mapping[str, Any]]) -> Mapping[str, float]:
        return {
            "first_semantic_accuracy": _mean([float(item["first_semantic_accuracy"]) for item in items]),
            "two_step_semantic_accuracy": _mean([float(item["final_semantic_accuracy"]) for item in items]),
            "monotonic_gain": _mean([float(item["semantic_gain"]) for item in items]),
            "first_preserved_correct_accuracy": _mean(
                [float(item["first_preserved_correct_accuracy"]) for item in items]
            ),
            "preserved_correct_accuracy": _mean(
                [float(item["final_preserved_correct_accuracy"]) for item in items]
            ),
            "first_exact_rate": _mean([float(bool(item["first_exact"])) for item in items]),
            "two_step_exact_rate": _mean([float(bool(item["final_exact"])) for item in items]),
            "revision_acceptance_rate": _mean(
                [float(bool(item["revision_accepted"])) for item in items]
            ),
        }

    assessments = [record["assessment"] for record in records]
    return {
        "condition": condition,
        "task_count": len(tasks),
        **summarize(assessments),
        "by_representation": {
            representation: summarize(items)
            for representation, items in sorted(by_representation.items())
        },
        "records": records,
    }


def _generate(
    model_path: str,
    adapter_path: Path,
    task_prompts: Sequence[str],
    *,
    batch_size: int,
    max_tokens: int,
) -> tuple[tuple[str, ...], float, Mapping[str, Any]]:
    from mlx_lm import load
    import mlx.core as mx

    model, tokenizer, config = load(model_path, adapter_path=str(adapter_path), return_config=True)
    prompts = tuple(_chat_prompt(tokenizer, prompt) for prompt in task_prompts)
    responses, peak_memory = _batch_responses(
        model,
        tokenizer,
        prompts,
        batch_size=batch_size,
        max_tokens=max_tokens,
        max_batch_tokens=12000,
    )
    del model
    gc.collect()
    mx.clear_cache()
    return responses, peak_memory, config


def evaluate_trajectory_repair(
    output_root: Path,
    benchmark_root: Path,
    trajectory_data_root: Path,
    model_path: str,
    localized_adapter: Path,
    regeneration_adapter: Path,
    *,
    batch_size: int = 8,
) -> Mapping[str, Any]:
    benchmark = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    data_freeze = json.loads((trajectory_data_root / "data-freeze.json").read_text(encoding="utf-8"))
    tasks = build_suite("trajectory_test", 30)
    started = time.monotonic()

    localized_first, localized_peak_1, config = _generate(
        model_path,
        localized_adapter,
        [task.edit_prompt() for task in tasks],
        batch_size=batch_size,
        max_tokens=48,
    )
    localized_revision, localized_peak_2, _ = _generate(
        model_path,
        localized_adapter,
        [localized_revision_prompt(task, response) for task, response in zip(tasks, localized_first)],
        batch_size=batch_size,
        max_tokens=48,
    )
    regeneration_first, regeneration_peak_1, _ = _generate(
        model_path,
        regeneration_adapter,
        [regeneration_prompt(task) for task in tasks],
        batch_size=batch_size,
        max_tokens=120,
    )
    regeneration_revision, regeneration_peak_2, _ = _generate(
        model_path,
        regeneration_adapter,
        [regeneration_revision_prompt(task, response) for task, response in zip(tasks, regeneration_first)],
        batch_size=batch_size,
        max_tokens=120,
    )
    localized = aggregate_trajectory_branch(
        "localized_edit",
        tasks,
        localized_first,
        localized_revision,
        lambda task, response: apply_edit(task, response),
    )
    regeneration = aggregate_trajectory_branch(
        "full_regeneration",
        tasks,
        regeneration_first,
        regeneration_revision,
        parse_program,
    )
    store = ArtifactStore(output_root)
    localized_records = localized.pop("records")
    regeneration_records = regeneration.pop("records")
    predictions_digest = store.put(
        "trajectory_repair_predictions",
        {"localized": localized_records, "regeneration": regeneration_records},
    )
    localized_advantage = (
        localized["two_step_semantic_accuracy"] - regeneration["two_step_semantic_accuracy"]
    )
    payload = {
        "version": TRAJECTORY_REPAIR_VERSION,
        "benchmark_version": REPAIR_BENCHMARK_VERSION,
        "trajectory_data_version": TRAJECTORY_DATA_VERSION,
        "benchmark_freeze_id": benchmark["freeze_id"],
        "trajectory_data_freeze_id": data_freeze["data_freeze_id"],
        "model_path": model_path,
        "model_type": str(config.get("model_type", "")),
        "quantization": dict(config.get("quantization", {})),
        "localized_adapter": str(localized_adapter),
        "regeneration_adapter": str(regeneration_adapter),
        "localized_adapter_sha256": hashlib.sha256(
            (localized_adapter / "adapters.safetensors").read_bytes()
        ).hexdigest(),
        "regeneration_adapter_sha256": hashlib.sha256(
            (regeneration_adapter / "adapters.safetensors").read_bytes()
        ).hexdigest(),
        "localized_metrics": localized,
        "regeneration_metrics": regeneration,
        "localized_advantage_over_regeneration": localized_advantage,
        "elapsed_seconds": time.monotonic() - started,
        "peak_memory_gb": max(
            localized_peak_1, localized_peak_2, regeneration_peak_1, regeneration_peak_2
        ),
        "predictions_digest": predictions_digest,
        "matched_protocol": {
            "training_examples_per_branch": data_freeze["counts"]["localized_train"],
            "generation_calls_per_task": 2,
            "same_base_model": True,
            "same_lora_layers": 8,
            "same_trajectory_training_iterations": 100,
            "output_token_caps": {"localized": 48, "regeneration": 120},
        },
        "claim_boundary": (
            "M34 compares interactive repair representations on synthetic tasks. Verifier feedback "
            "reveals one counterexample and adoption checks only that case plus four public invariants."
        ),
    }
    evaluation_id = content_digest(payload)[:20]
    manifest = {**payload, "evaluation_id": evaluation_id, "schema": 1}
    store.write_manifest(f"trajectory-repair-{evaluation_id}", manifest)
    return manifest


def assess_m34(
    evaluation: Mapping[str, Any],
    benchmark_root: Path,
    m32_assessment: Mapping[str, Any],
    m33_assessment: Mapping[str, Any],
) -> Mapping[str, Any]:
    freeze = json.loads((benchmark_root / "benchmark-freeze.json").read_text(encoding="utf-8"))
    gates = freeze["m34_gates"]
    localized = evaluation["localized_metrics"]
    checks = {
        "m32_prerequisite_passed": bool(m32_assessment["passed"]),
        "m33_prerequisite_passed": bool(m33_assessment["passed"]),
        "same_benchmark_freeze": evaluation["benchmark_freeze_id"] == freeze["freeze_id"],
        "localized_advantage": (
            evaluation["localized_advantage_over_regeneration"]
            >= gates["minimum_localized_advantage_over_regeneration"]
        ),
        "two_step_semantic_accuracy": (
            localized["two_step_semantic_accuracy"] >= gates["minimum_two_step_semantic_accuracy"]
        ),
        "monotonic_gain": localized["monotonic_gain"] >= gates["minimum_monotonic_gain"],
        "preserved_correct_accuracy": (
            localized["preserved_correct_accuracy"] >= gates["minimum_preserved_correct_accuracy"]
        ),
        "matched_training_and_calls": (
            evaluation["matched_protocol"]["training_examples_per_branch"] == 500
            and evaluation["matched_protocol"]["generation_calls_per_task"] == 2
        ),
    }
    payload = {
        "version": TRAJECTORY_REPAIR_VERSION,
        "evaluation_id": evaluation["evaluation_id"],
        "benchmark_freeze_id": freeze["freeze_id"],
        "checks": checks,
        "passed": all(checks.values()),
        "gates": gates,
        "localized_metrics": localized,
        "regeneration_metrics": evaluation["regeneration_metrics"],
        "localized_advantage_over_regeneration": evaluation["localized_advantage_over_regeneration"],
    }
    return {**payload, "assessment_id": content_digest(payload)}
