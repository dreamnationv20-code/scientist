"""MLX-native, low-rank intervention on post-block hidden states.

This is deliberately a small sidecar rather than an adaptation of the sealed
answer-label LoRA experiment.  It contains no dataset, model path, optimizer,
or evaluation logic.  A later, separately sealed experiment may install this
module after selected Qwen2 transformer blocks only after the source and
runtime certificates pass.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable

import mlx.core as mx
import mlx.nn as nn


VERSION = "verified-trace-hidden-state-intervention-v1"


@dataclass(frozen=True)
class StateInterventionSpec:
    """The fixed causal scope of a low-rank post-block state intervention."""

    model_family: str
    hidden_size: int
    block_indices: tuple[int, ...]
    rank: int
    scale: float
    position_policy: str = "all_sequence_positions_after_selected_blocks"

    def __post_init__(self) -> None:
        if not self.model_family:
            raise ValueError("model family is required")
        if self.hidden_size <= 0 or self.rank <= 0 or self.rank > self.hidden_size:
            raise ValueError("hidden size and rank are invalid")
        if not self.block_indices or len(set(self.block_indices)) != len(self.block_indices):
            raise ValueError("selected block indices must be non-empty and unique")
        if any(index < 0 for index in self.block_indices):
            raise ValueError("selected block indices must be non-negative")
        if self.scale < 0:
            raise ValueError("intervention scale must be non-negative")
        if self.position_policy != "all_sequence_positions_after_selected_blocks":
            raise ValueError("unexpected position policy")

    @property
    def parameter_count_per_block(self) -> int:
        return 2 * self.hidden_size * self.rank

    @property
    def parameter_count_total(self) -> int:
        return len(self.block_indices) * self.parameter_count_per_block

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["version"] = VERSION
        value["parameter_count_per_block"] = self.parameter_count_per_block
        value["parameter_count_total"] = self.parameter_count_total
        return value


class LowRankStateResidual(nn.Module):
    """A rank-limited residual map applied directly to a hidden state tensor.

    Its learned map has rank at most ``rank``.  Scale zero returns the exact
    incoming array, rather than relying on floating-point multiplication by
    zero.  That identity branch is an explicit causal-control requirement.
    """

    def __init__(self, hidden_size: int, rank: int, scale: float) -> None:
        super().__init__()
        if hidden_size <= 0 or rank <= 0 or rank > hidden_size or scale < 0:
            raise ValueError("invalid low-rank hidden-state intervention")
        self.hidden_size = hidden_size
        self.rank = rank
        self.scale = float(scale)
        self.down = nn.Linear(hidden_size, rank, bias=False)
        self.up = nn.Linear(rank, hidden_size, bias=False)

    def __call__(self, hidden_states: mx.array) -> mx.array:
        if hidden_states.ndim < 2 or hidden_states.shape[-1] != self.hidden_size:
            raise ValueError("hidden-state tensor does not match intervention width")
        if self.scale == 0.0:
            return hidden_states
        return hidden_states + self.scale * self.up(self.down(hidden_states))


class PostBlockStateIntervention(nn.Module):
    """Preserve a Qwen2 block's call signature and intervene on its output."""

    def __init__(self, block: nn.Module, intervention: LowRankStateResidual) -> None:
        super().__init__()
        self.block = block
        self.intervention = intervention

    def __call__(
        self,
        hidden_states: mx.array,
        mask: mx.array | None = None,
        cache: Any | None = None,
    ) -> mx.array:
        return self.intervention(self.block(hidden_states, mask, cache))


def install_post_block_interventions(model: Any, spec: StateInterventionSpec) -> tuple[int, ...]:
    """Install independent sidecars after fixed backbone layers.

    The function intentionally accepts only MLX-LM's Qwen-style ``layers``
    interface.  It does not freeze, unfreeze, train, or load weights; the
    caller must certify those actions separately.
    """

    layers = getattr(model, "layers", None)
    if not isinstance(layers, list):
        raise TypeError("model must expose Qwen-style mutable list layers")
    if max(spec.block_indices) >= len(layers):
        raise ValueError("selected intervention block is outside the backbone")
    for index in spec.block_indices:
        layers[index] = PostBlockStateIntervention(
            layers[index],
            LowRankStateResidual(spec.hidden_size, spec.rank, spec.scale),
        )
    return spec.block_indices


def intervention_tensor_count(modules: Iterable[LowRankStateResidual]) -> int:
    """Expose the expected two tensors per installed low-rank sidecar."""

    return sum(2 for _ in modules)
