from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.cognitive_core.functional_contracts_v9 import (
    FunctionalContractBundle,
)
from scientist.domains.cognitive_core.shared_substrate_v10 import (
    SHARED_SUBSTRATE_VERSION,
    WAVE_ONE_KEYS,
    SharedBaselineReconstruction,
)
from scientist.program.campaigns import (
    IncumbentEntry,
    IncumbentPortfolio,
    IncumbentRole,
)
from scientist.program.literature import (
    ClaimClassification,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)


WAVE_ONE_PRIOR_ART_VERSION = "cognitive-core-wave-one-prior-art-v10"
SHARED_BASELINE_WORK_ID = "shared-reference-baseline-reconstruction-v10"


@dataclass(frozen=True)
class WaveOneBaselineRegistration:
    assessments: Mapping[str, PriorArtAssessment]
    portfolios: Mapping[str, IncumbentPortfolio]
    shared_candidate_id: str
    shared_source_work_id: str
    baseline_artifact_id: str

    @property
    def registration_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "version": WAVE_ONE_PRIOR_ART_VERSION,
            "assessments": {
                key: item.as_dict()
                for key, item in sorted(self.assessments.items())
            },
            "portfolios": {
                key: item.as_dict()
                for key, item in sorted(self.portfolios.items())
            },
            "shared_candidate_id": self.shared_candidate_id,
            "shared_source_work_id": self.shared_source_work_id,
            "baseline_artifact_id": self.baseline_artifact_id,
        }
        if include_id:
            value["registration_id"] = self.registration_id
        return value


def _published_works() -> Mapping[str, PriorWork]:
    return {
        "goddard25": PriorWork(
            work_id="goddard-et-al-icml-2025-icl-task-generalization",
            title="When can in-context learning generalize out of task distribution?",
            year=2025,
            locator="https://proceedings.mlr.press/v267/goddard25a.html",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "task inference from demonstrations",
                "out-of-task-distribution generalization",
            ),
            abstract=(
                "Analyzes conditions under which in-context learning can infer "
                "and generalize beyond the training task distribution."
            ),
        ),
        "abedsoltan25": PriorWork(
            work_id="abedsoltan-et-al-icml-2025-compositional-task-generalization",
            title=(
                "Task Generalization with Autoregressive Compositional Structure"
            ),
            year=2025,
            locator="https://proceedings.mlr.press/v267/abedsoltan25a.html",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "compositional procedure representation",
                "unseen task generalization",
            ),
            abstract=(
                "Studies compositional task structure as a route to systematic "
                "task generalization."
            ),
        ),
        "self_rag": PriorWork(
            work_id="asai-et-al-iclr-2024-self-rag",
            title="Self-RAG: Learning to Retrieve, Generate, and Critique through Self-Reflection",
            year=2024,
            locator="https://openreview.net/forum?id=hSyW5go0v8",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "adaptive evidence retrieval",
                "relevance and support reflection",
            ),
            abstract=(
                "Learns when to retrieve and how to assess relevance and support "
                "during evidence-grounded generation."
            ),
        ),
        "hipporag2": PriorWork(
            work_id="gutierrez-et-al-icml-2025-hipporag-2",
            title="HippoRAG 2: From RAG to Memory",
            year=2025,
            locator="https://proceedings.mlr.press/v267/gutierrez25a.html",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "relational memory retrieval",
                "multi-hop evidence composition",
            ),
            abstract=(
                "Uses a graph-structured memory system for relational and "
                "multi-hop retrieval."
            ),
        ),
        "wise": PriorWork(
            work_id="wang-et-al-neurips-2024-wise",
            title="WISE: Rethinking the Knowledge Memory for Lifelong Model Editing",
            year=2024,
            locator="https://openreview.net/forum?id=NpoDbZBPZH",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "persistent requested changes",
                "lifelong knowledge editing",
            ),
            abstract=(
                "Separates editable knowledge memory to support repeated model "
                "updates while managing conflicts."
            ),
        ),
        "kaft": PriorWork(
            work_id="li-et-al-2022-kaft-controllable-working-memory",
            title="Large Language Models with Controllable Working Memory",
            year=2022,
            locator="https://arxiv.org/abs/2211.05110",
            relation=PriorArtRelation.STRONG_OVERLAP,
            matched_components=(
                "controllable contextual updates",
                "preserving knowledge under irrelevant context",
            ),
            abstract=(
                "Trains language models to use relevant context while retaining "
                "parametric knowledge under irrelevant or counterfactual context."
            ),
        ),
        "memory_layers": PriorWork(
            work_id="berges-et-al-icml-2025-memory-layers-at-scale",
            title="Memory Layers at Scale",
            year=2025,
            locator="https://proceedings.mlr.press/v267/berges25a.html",
            relation=PriorArtRelation.ADJACENT,
            matched_components=(
                "explicit memory capacity",
                "measured memory-system scaling cost",
            ),
            abstract=(
                "Evaluates explicit memory layers and their scaling trade-offs in "
                "large language models."
            ),
        ),
        "titans": PriorWork(
            work_id="behrouz-et-al-2025-titans",
            title="Titans: Learning to Memorize at Test Time",
            year=2025,
            locator="https://research.google/pubs/titans-learning-to-memorize-at-test-time/",
            relation=PriorArtRelation.ADJACENT,
            matched_components=(
                "test-time memory updates",
                "persistent-memory resource accounting",
            ),
            abstract=(
                "Introduces a test-time neural memory component and evaluates "
                "long-context memory behavior."
            ),
        ),
    }


_WORK_SELECTION = {
    "procedure_representation": ("goddard25", "abedsoltan25"),
    "task_inference": ("goddard25", "abedsoltan25"),
    "relevance_representation": ("self_rag", "hipporag2"),
    "requested_change": ("wise", "kaft"),
    "system_cost": ("memory_layers", "titans"),
}


_PROBLEM_LANGUAGE = {
    "procedure_representation": "systematic representation of reusable procedures across unseen surface forms",
    "task_inference": "few-shot latent task inference without hidden task labels",
    "relevance_representation": "relational relevance representation for evidence and protected state",
    "requested_change": "persistent requested knowledge or rule change without full retraining",
    "system_cost": "complete matched accounting of model, memory, retrieval, context, and adaptation cost",
}


def _queries(key: str) -> Tuple[LiteratureQuery, ...]:
    problem = _PROBLEM_LANGUAGE[key]
    return (
        LiteratureQuery(
            query=problem,
            facet=SearchFacet.PROBLEM,
            provider="PMLR",
        ),
        LiteratureQuery(
            query="shared persistent candidate interface for %s" % problem,
            facet=SearchFacet.INTERVENTION,
            provider="OpenReview",
        ),
        LiteratureQuery(
            query="mechanism and causal explanation for %s" % problem,
            facet=SearchFacet.MECHANISM,
            provider="arXiv",
        ),
        LiteratureQuery(
            query="references and citing work around %s" % problem,
            facet=SearchFacet.CITATION_NEIGHBORHOOD,
            provider="Semantic Scholar",
        ),
    )


def build_wave_one_registration(
    *,
    bundle: FunctionalContractBundle,
    reconstruction: SharedBaselineReconstruction,
    baseline_artifact_id: str,
) -> WaveOneBaselineRegistration:
    if tuple(sorted(bundle.wave_keys[1])) != tuple(sorted(WAVE_ONE_KEYS)):
        raise ValueError("functional bundle and shared substrate disagree on Wave 1")
    published = _published_works()
    shared_work = PriorWork(
        work_id=SHARED_BASELINE_WORK_ID,
        title="Exact typed shared reference baseline reconstruction",
        year=2026,
        locator="artifact:%s" % baseline_artifact_id,
        relation=PriorArtRelation.EXECUTABLE_BASELINE,
        matched_components=(
            "one shared candidate identity",
            "one persistent event/state trajectory",
            "exact typed procedure execution",
            "exact relation retrieval",
            "explicit target updates",
            "complete cost ledger",
        ),
        executable=True,
        abstract=(
            "Reconstructs the strongest currently executable common denominator "
            "of the local studies under one frozen interface; it is an internal "
            "operational baseline and makes no novelty claim."
        ),
    )
    assessments: Dict[str, PriorArtAssessment] = {}
    portfolios: Dict[str, IncumbentPortfolio] = {}
    primary = IncumbentEntry(
        candidate_id=reconstruction.candidate.candidate_id,
        name=reconstruction.candidate.name,
        role=IncumbentRole.BEST_END_TO_END,
        executable_digest=reconstruction.candidate.executable_digest,
        source_locator="artifact:%s" % baseline_artifact_id,
        source_work_id=SHARED_BASELINE_WORK_ID,
        reproduction_evidence_ids=(baseline_artifact_id,),
        metric_summary=reconstruction.metric_summary,
        limitations=reconstruction.limitations,
    )
    for key in WAVE_ONE_KEYS:
        leaf = bundle.contracts[key].leaf
        closest_works = (
            shared_work,
            *(published[item] for item in _WORK_SELECTION[key]),
        )
        signature = ClaimSignature(
            subject_id=leaf.node_id,
            statement=(
                "Reconstruct the current matched shared baseline before searching "
                "for improvement on the %s functional contract." % key
            ),
            problem=_PROBLEM_LANGUAGE[key],
            phenomenon=(
                "current local evidence is distributed across specialized studies "
                "and does not itself establish a single jointly evaluated candidate"
            ),
            intervention=(
                "run one deterministic candidate and persistent state through a "
                "frozen Wave-1 smoke trajectory with one complete cost ledger"
            ),
            mechanism=(
                "exact typed lookup and update constitute the reconstructed baseline; "
                "no candidate improvement mechanism is claimed"
            ),
            evaluation=(
                "case-level exact replay, candidate identity, smoke accuracy, and "
                "zero-valued full functional gates pending Phase 3"
            ),
        )
        assessment = PriorArtAssessment(
            signature=signature,
            trigger=LiteratureTrigger.INITIAL_SCOPE,
            queries=_queries(key),
            closest_works=closest_works,
            classification=ClaimClassification.REPRODUCTION,
            rationale=(
                "The registered artifact is an honest reproduction baseline. "
                "Published neighbors establish that each component has substantial "
                "prior art, while none replaces the required joint evaluator."
            ),
            novel_delta=(),
            citation_snowball_complete=True,
            searched_at="2026-08-18",
            reviewer_ref=WAVE_ONE_PRIOR_ART_VERSION,
            executable_incumbent_id=SHARED_BASELINE_WORK_ID,
        )
        null_entry = IncumbentEntry(
            candidate_id="null-%s" % leaf.node_id,
            name="Null no-op baseline for %s" % key,
            role=IncumbentRole.NULL,
            executable_digest=content_digest(
                {"kind": "null", "node_id": leaf.node_id}
            ),
            source_locator="internal:null:%s" % key,
            reproduction_evidence_ids=(baseline_artifact_id,),
            metric_summary={"%s_functional_gate" % key: 0.0},
            limitations=("Provides no capability and exists only as a floor.",),
        )
        portfolio = IncumbentPortfolio(
            node_id=leaf.node_id,
            literature_assessment_id=assessment.assessment_id,
            entries=(null_entry, primary),
            primary_incumbent_id=primary.candidate_id,
            selection_rationale=(
                "Use the same reconstructed candidate for all Wave-1 contracts so "
                "later improvements cannot win through baseline or identity switching."
            ),
        )
        assessments[key] = assessment
        portfolios[key] = portfolio
    return WaveOneBaselineRegistration(
        assessments=assessments,
        portfolios=portfolios,
        shared_candidate_id=reconstruction.candidate.candidate_id,
        shared_source_work_id=SHARED_BASELINE_WORK_ID,
        baseline_artifact_id=baseline_artifact_id,
    )
