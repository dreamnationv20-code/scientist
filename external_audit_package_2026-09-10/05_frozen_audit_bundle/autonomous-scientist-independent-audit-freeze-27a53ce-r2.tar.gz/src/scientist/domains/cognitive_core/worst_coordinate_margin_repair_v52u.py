from __future__ import annotations

import math
from typing import Any, Mapping, Sequence, Tuple


WORST_COORDINATE_MARGIN_REPAIR_VERSION = (
    "general-cognitive-worst-coordinate-margin-repair-v52u"
)
M52U_SEED = 53031
M52U_M52T_AUDIT_ID = (
    "024ef8d0df10d4c2665fa4feb82670f4e0237414626db55ff924e0491434c83f"
)


def worst_coordinate_loss_value(
    gaps: Sequence[float], mean_loss_weight: float = 0.1
) -> float:
    if not gaps:
        raise ValueError("M52u worst-coordinate loss requires at least one gap")
    losses = [math.log1p(math.exp(-float(gap))) for gap in gaps]
    return max(losses) + float(mean_loss_weight) * sum(losses) / len(losses)


def installation_gate_passed(
    local_metrics: Mapping[str, Any],
    exact_metrics: Mapping[str, Any],
    contract: Mapping[str, Any],
) -> Tuple[bool, Mapping[str, bool]]:
    checks = {
        "minimum_overall_local_ranking_accuracy": float(
            local_metrics["ranking"]["ranking_accuracy"]
        )
        >= float(contract["minimum_overall_local_ranking_accuracy"]),
        "minimum_each_variant_ranking_accuracy": min(
            float(row["ranking_accuracy"])
            for row in local_metrics["by_variant"].values()
        )
        >= float(contract["minimum_each_variant_ranking_accuracy"]),
        "minimum_each_family_ranking_accuracy": min(
            float(row["ranking_accuracy"])
            for row in local_metrics["by_family"].values()
        )
        >= float(contract["minimum_each_family_ranking_accuracy"]),
        "minimum_exact_one_balanced_accuracy": float(
            exact_metrics["balanced_accuracy"]
        )
        >= float(contract["minimum_exact_one_balanced_accuracy"]),
        "minimum_exact_one_swap_pair_accuracy": float(
            exact_metrics["swap_pair_accuracy"]
        )
        >= float(contract["minimum_exact_one_swap_pair_accuracy"]),
        "maximum_exact_one_order_bias": float(
            exact_metrics["candidate_order_bias"]
        )
        <= float(contract["maximum_exact_one_order_bias"]),
    }
    return all(checks.values()), checks


def select_earliest_installation_pass(
    candidates: Sequence[Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    passing = [row for row in candidates if bool(row["passed"])]
    if not passing:
        return None
    return min(passing, key=lambda row: int(row["iteration"]))


def holdout_adoption_gate_passed(
    repair_local: Mapping[str, Any],
    parent_local: Mapping[str, Any],
    repair_exact: Mapping[str, Any],
    parent_exact: Mapping[str, Any],
    contract: Mapping[str, Any],
) -> Tuple[bool, Mapping[str, bool]]:
    repair_accuracy = float(repair_local["ranking"]["ranking_accuracy"])
    parent_accuracy = float(parent_local["ranking"]["ranking_accuracy"])
    variant_deltas = [
        float(repair_local["by_variant"][variant]["ranking_accuracy"])
        - float(parent_local["by_variant"][variant]["ranking_accuracy"])
        for variant in repair_local["by_variant"]
    ]
    family_accuracies = [
        float(row["ranking_accuracy"])
        for row in repair_local["by_family"].values()
    ]
    checks = {
        "minimum_holdout_local_ranking_accuracy": repair_accuracy
        >= float(contract["minimum_holdout_local_ranking_accuracy"]),
        "minimum_holdout_local_ranking_delta": repair_accuracy - parent_accuracy
        >= float(contract["minimum_holdout_local_ranking_delta"]),
        "minimum_each_holdout_family_ranking_accuracy": min(family_accuracies)
        >= float(contract["minimum_each_holdout_family_ranking_accuracy"]),
        "maximum_each_variant_ranking_decline": min(variant_deltas)
        >= -float(contract["maximum_each_variant_ranking_decline"]),
        "minimum_holdout_exact_one_balanced_accuracy": float(
            repair_exact["balanced_accuracy"]
        )
        >= float(contract["minimum_holdout_exact_one_balanced_accuracy"]),
        "maximum_exact_one_balanced_accuracy_decline": float(
            repair_exact["balanced_accuracy"]
        )
        - float(parent_exact["balanced_accuracy"])
        >= -float(contract["maximum_exact_one_balanced_accuracy_decline"]),
        "minimum_holdout_exact_one_swap_pair_accuracy": float(
            repair_exact["swap_pair_accuracy"]
        )
        >= float(contract["minimum_holdout_exact_one_swap_pair_accuracy"]),
        "maximum_holdout_exact_one_order_bias": float(
            repair_exact["candidate_order_bias"]
        )
        <= float(contract["maximum_holdout_exact_one_order_bias"]),
    }
    return all(checks.values()), checks
