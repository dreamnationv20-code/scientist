from __future__ import annotations

from typing import Iterable, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.compiler_optimization.engine import (
    apply_rewrite,
    compile_expression,
    evaluate_rewrite,
    prove_equivalent,
)
from scientist.domains.compiler_optimization.models import (
    BitVectorExpression,
    CompilerExpressionCase,
    CompilerObservation,
    CompilerRewrite,
)
from scientist.kernel.capabilities import (
    ComparisonMode,
    DomainCapability,
    DomainCapabilityManifest,
    ResearchMode,
)
from scientist.kernel.contracts import ExecutionMode
from scientist.kernel.interfaces import PairedComparison, VerificationResult


class CompilerOptimizationAdapter:
    domain_id = "verified_compiler_optimization"
    adapter_version = "verified-compiler-optimization-adapter-v1"
    evaluator_ref = "apple-clang-21-o3-arm64-codegen-v1"
    verifier_ref = "z3-4.16-bitvector-equivalence-v1"
    execution_mode = ExecutionMode.DETERMINISTIC
    capabilities = DomainCapabilityManifest(
        domain_id=domain_id,
        research_modes=(
            ResearchMode.OPTIMIZATION,
            ResearchMode.SYNTHESIS,
            ResearchMode.VERIFICATION,
            ResearchMode.PHENOMENON_DISCOVERY,
        ),
        capabilities=(
            DomainCapability.CANDIDATE_RECONSTRUCTION,
            DomainCapability.PAIRED_COMPARISON,
            DomainCapability.BEHAVIOR_FINGERPRINT,
            DomainCapability.FAILURE_MINIMIZATION,
            DomainCapability.CODE_EXECUTION,
            DomainCapability.COST_ACCOUNTING,
        ),
        comparison_mode=ComparisonMode.PAIRED_INCUMBENT,
        primary_metric="instruction_reduction",
        independent_evidence_unit="expression schema instantiation",
        manifest_ref="verified-compiler-optimization-capabilities-v1",
        research_object_types=("verified_rewrite_schema",),
    )

    def candidate_id(self, candidate: CompilerRewrite) -> str:
        return candidate.candidate_id

    def candidate_as_dict(self, candidate: CompilerRewrite) -> Mapping[str, object]:
        value = candidate.as_dict()
        value["candidate_id"] = candidate.candidate_id
        return value

    def candidate_from_dict(self, value: Mapping[str, object]) -> CompilerRewrite:
        return CompilerRewrite.from_dict(value)

    def experiment_id(self, experiment: CompilerExpressionCase) -> str:
        return experiment.case_id

    def experiment_as_dict(
        self, experiment: CompilerExpressionCase
    ) -> Mapping[str, object]:
        return experiment.as_dict()

    def observation_as_dict(
        self, observation: CompilerObservation
    ) -> Mapping[str, object]:
        return observation.as_dict()

    def observation_id(self, observation: CompilerObservation) -> str:
        return observation.observation_id

    def evaluate(
        self,
        candidate: CompilerRewrite,
        experiment: CompilerExpressionCase,
    ) -> CompilerObservation:
        if candidate.name == "apple-clang-o3-no-source-rewrite":
            output = experiment.expression
            rewrite_count = 0
            instructions = compile_expression(output)
            return CompilerObservation(
                candidate_id=candidate.candidate_id,
                case_id=experiment.case_id,
                input_expression=experiment.expression,
                output_expression=output,
                rewrite_count=rewrite_count,
                instruction_count=len(instructions),
                instructions=instructions,
                assembly_digest=content_digest(list(instructions)),
                compiler_ref=self.evaluator_ref,
            )
        return evaluate_rewrite(
            candidate,
            experiment,
            compiler_ref=self.evaluator_ref,
        )

    def verify(
        self,
        experiment: CompilerExpressionCase,
        observation: CompilerObservation,
    ) -> VerificationResult:
        proof = prove_equivalent(
            experiment.expression,
            observation.output_expression,
        )
        checks = {
            "case_identity": observation.case_id == experiment.case_id,
            "compiler_identity": observation.compiler_ref == self.evaluator_ref,
            "assembly_present": bool(observation.instructions),
            "instruction_count_reconstructed": (
                observation.instruction_count == len(observation.instructions)
            ),
            "all_input_equivalence": proof.equivalent,
        }
        return VerificationResult(
            passed=all(checks.values()),
            checks=checks,
            details={
                "proof_ref": proof.proof_ref,
                "counterexample": proof.counterexample,
                "input_expression_id": experiment.expression.expression_id,
                "output_expression_id": observation.output_expression.expression_id,
            },
            verifier_ref=self.verifier_ref,
        )

    def compare(
        self,
        candidate: CompilerRewrite,
        incumbent: CompilerRewrite,
        experiment: CompilerExpressionCase,
    ) -> PairedComparison:
        candidate_observation = self.evaluate(candidate, experiment)
        incumbent_observation = self.evaluate(incumbent, experiment)
        return PairedComparison(
            candidate_id=candidate.candidate_id,
            incumbent_id=incumbent.candidate_id,
            experiment_id=experiment.case_id,
            metrics={
                "candidate_instruction_count": float(
                    candidate_observation.instruction_count
                ),
                "incumbent_instruction_count": float(
                    incumbent_observation.instruction_count
                ),
                "instruction_reduction": float(
                    incumbent_observation.instruction_count
                    - candidate_observation.instruction_count
                ),
            },
        )

    def behavior_fingerprint(
        self,
        candidate: CompilerRewrite,
        experiments: Iterable[CompilerExpressionCase],
    ) -> str:
        return content_digest(
            [
                {
                    "case_id": experiment.case_id,
                    "output_expression_id": self.evaluate(
                        candidate, experiment
                    ).output_expression.expression_id,
                }
                for experiment in experiments
            ]
        )

    def minimize_failure(
        self,
        experiment: CompilerExpressionCase,
        better: CompilerRewrite,
        worse: CompilerRewrite,
    ) -> CompilerExpressionCase:
        del better, worse
        return experiment

def incumbent_rewrite() -> CompilerRewrite:
    placeholder = BitVectorExpression("var", atom="a")
    return CompilerRewrite(
        name="apple-clang-o3-no-source-rewrite",
        source_pattern=placeholder,
        replacement_pattern=BitVectorExpression(
            "xor", (placeholder, BitVectorExpression("const", value=0))
        ),
        concept_ref="identity-source-pipeline",
        synthesis_ref="apple-clang-21-o3-arm64",
    )
