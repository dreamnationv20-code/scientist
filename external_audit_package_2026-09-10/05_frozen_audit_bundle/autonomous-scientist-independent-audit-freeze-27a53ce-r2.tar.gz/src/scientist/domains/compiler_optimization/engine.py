from __future__ import annotations

import functools
import random
import re
import subprocess
from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple

import z3

from scientist.core.artifacts import content_digest
from scientist.domains.compiler_optimization.models import (
    BINARY_OPERATORS,
    BitVectorExpression,
    COMMUTATIVE_OPERATORS,
    CompilerExpressionCase,
    CompilerObservation,
    CompilerRewrite,
    binary,
    const,
    unary,
    var,
)


BIT_WIDTH = 32
MASK = (1 << BIT_WIDTH) - 1
CLANG_FLAGS = ("-O3", "-S", "-x", "c", "-o", "-", "-")


@dataclass(frozen=True)
class ProofResult:
    equivalent: bool
    proof_ref: str
    counterexample: Optional[Mapping[str, int]] = None


@dataclass(frozen=True)
class SynthesizedSchema:
    source: BitVectorExpression
    replacement: BitVectorExpression
    source_instruction_count: int
    replacement_instruction_count: int
    proof_ref: str

    @property
    def instruction_gain(self) -> int:
        return self.source_instruction_count - self.replacement_instruction_count

    @property
    def schema_id(self) -> str:
        return content_digest(
            {
                "source": self.source.as_dict(),
                "replacement": self.replacement.as_dict(),
                "proof_ref": self.proof_ref,
            }
        )


def evaluate_expression(
    expression: BitVectorExpression,
    values: Mapping[str, int],
) -> int:
    if expression.op == "var":
        return int(values[str(expression.atom)]) & MASK
    if expression.op == "const":
        return int(expression.value) & MASK
    if expression.op == "not":
        return (~evaluate_expression(expression.args[0], values)) & MASK
    if expression.op == "neg":
        return (-evaluate_expression(expression.args[0], values)) & MASK
    left = evaluate_expression(expression.args[0], values)
    right = evaluate_expression(expression.args[1], values)
    return {
        "add": lambda: (left + right) & MASK,
        "sub": lambda: (left - right) & MASK,
        "and": lambda: left & right,
        "or": lambda: left | right,
        "xor": lambda: left ^ right,
        "shl": lambda: (left << (right & 31)) & MASK,
        "lshr": lambda: left >> (right & 31),
    }[expression.op]()


def _z3_expression(
    expression: BitVectorExpression,
    variables: Dict[str, z3.BitVecRef],
) -> z3.BitVecRef:
    if expression.op == "var":
        name = str(expression.atom)
        variables.setdefault(name, z3.BitVec(name, BIT_WIDTH))
        return variables[name]
    if expression.op == "const":
        return z3.BitVecVal(int(expression.value) & MASK, BIT_WIDTH)
    if expression.op == "not":
        return ~_z3_expression(expression.args[0], variables)
    if expression.op == "neg":
        return -_z3_expression(expression.args[0], variables)
    left = _z3_expression(expression.args[0], variables)
    right = _z3_expression(expression.args[1], variables)
    return {
        "add": lambda: left + right,
        "sub": lambda: left - right,
        "and": lambda: left & right,
        "or": lambda: left | right,
        "xor": lambda: left ^ right,
        "shl": lambda: left << right,
        "lshr": lambda: z3.LShR(left, right),
    }[expression.op]()


def prove_equivalent(
    left: BitVectorExpression,
    right: BitVectorExpression,
    *,
    timeout_ms: int = 2_000,
) -> ProofResult:
    variables: Dict[str, z3.BitVecRef] = {}
    left_value = _z3_expression(left, variables)
    right_value = _z3_expression(right, variables)
    solver = z3.Solver()
    solver.set(timeout=timeout_ms)
    solver.add(left_value != right_value)
    outcome = solver.check()
    proof_ref = content_digest(
        {
            "verifier": "z3-bitvector-equivalence-v1",
            "width": BIT_WIDTH,
            "left": left.as_dict(),
            "right": right.as_dict(),
            "outcome": str(outcome),
        }
    )
    if outcome == z3.unsat:
        return ProofResult(True, proof_ref)
    if outcome == z3.sat:
        model = solver.model()
        counterexample = {
            name: int(model.eval(value, model_completion=True).as_long())
            for name, value in sorted(variables.items())
        }
        return ProofResult(False, proof_ref, counterexample)
    return ProofResult(False, proof_ref)


@functools.lru_cache(maxsize=4096)
def compile_expression(expression: BitVectorExpression) -> Tuple[str, ...]:
    source = (
        "#include <stdint.h>\n"
        "__attribute__((noinline)) uint32_t candidate(uint32_t x, uint32_t y)"
        "{ return %s; }\n" % expression.to_c()
    )
    completed = subprocess.run(
        ("clang", *CLANG_FLAGS),
        input=source,
        text=True,
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError("clang rejected expression: %s" % completed.stderr.strip())
    instructions = []
    active = False
    for line in completed.stdout.splitlines():
        if re.match(r"^_?candidate:", line):
            active = True
            continue
        if active and (
            line.startswith("Lfunc_end") or line.startswith("\t.cfi_endproc")
        ):
            break
        stripped = line.strip()
        if active and line.startswith("\t") and stripped and not stripped.startswith(
            (".", "#")
        ):
            instructions.append(stripped)
    if not instructions:
        raise RuntimeError("clang assembly parser found no candidate instructions")
    return tuple(instructions)


def _match(
    pattern: BitVectorExpression,
    expression: BitVectorExpression,
    bindings: Dict[str, BitVectorExpression],
) -> bool:
    if pattern.op == "var" and pattern.atom in ("a", "b"):
        name = str(pattern.atom)
        existing = bindings.get(name)
        if existing is None:
            bindings[name] = expression
            return True
        return existing.expression_id == expression.expression_id
    if pattern.op != expression.op or pattern.atom != expression.atom or pattern.value != expression.value:
        return False
    if len(pattern.args) != len(expression.args):
        return False
    orientations = (expression.args,)
    if pattern.op in COMMUTATIVE_OPERATORS and len(expression.args) == 2:
        orientations = (expression.args, tuple(reversed(expression.args)))
    for arguments in orientations:
        trial = dict(bindings)
        if all(
            _match(left, right, trial)
            for left, right in zip(pattern.args, arguments)
        ):
            bindings.clear()
            bindings.update(trial)
            return True
    return False


def substitute(
    pattern: BitVectorExpression,
    bindings: Mapping[str, BitVectorExpression],
) -> BitVectorExpression:
    if pattern.op == "var" and pattern.atom in bindings:
        return bindings[str(pattern.atom)]
    if not pattern.args:
        return pattern
    return BitVectorExpression(
        pattern.op,
        tuple(substitute(argument, bindings) for argument in pattern.args),
        atom=pattern.atom,
        value=pattern.value,
    )


def apply_rewrite(
    expression: BitVectorExpression,
    rewrite: CompilerRewrite,
) -> Tuple[BitVectorExpression, int]:
    rewritten_arguments = []
    count = 0
    for argument in expression.args:
        rewritten, child_count = apply_rewrite(argument, rewrite)
        rewritten_arguments.append(rewritten)
        count += child_count
    current = (
        expression
        if not expression.args
        else BitVectorExpression(
            expression.op,
            tuple(rewritten_arguments),
            atom=expression.atom,
            value=expression.value,
        )
    )
    bindings: Dict[str, BitVectorExpression] = {}
    if _match(rewrite.source_pattern, current, bindings):
        return substitute(rewrite.replacement_pattern, bindings), count + 1
    return current, count


def evaluate_rewrite(
    rewrite: CompilerRewrite,
    case: CompilerExpressionCase,
    *,
    compiler_ref: str,
) -> CompilerObservation:
    output, rewrite_count = apply_rewrite(case.expression, rewrite)
    instructions = compile_expression(output)
    return CompilerObservation(
        candidate_id=rewrite.candidate_id,
        case_id=case.case_id,
        input_expression=case.expression,
        output_expression=output,
        rewrite_count=rewrite_count,
        instruction_count=len(instructions),
        instructions=instructions,
        assembly_digest=content_digest(list(instructions)),
        compiler_ref=compiler_ref,
    )


def identity_rewrite() -> CompilerRewrite:
    return CompilerRewrite(
        name="identity-before-apple-clang-o3",
        source_pattern=var("a"),
        replacement_pattern=binary("xor", var("a"), const(0)),
        concept_ref="no-source-rewrite",
        synthesis_ref="frozen-apple-clang-o3-incumbent",
    )


def _identity_apply(expression: BitVectorExpression) -> CompilerObservation:
    instructions = compile_expression(expression)
    return CompilerObservation(
        candidate_id="apple-clang-o3-no-source-rewrite",
        case_id="internal",
        input_expression=expression,
        output_expression=expression,
        rewrite_count=0,
        instruction_count=len(instructions),
        instructions=instructions,
        assembly_digest=content_digest(list(instructions)),
        compiler_ref="apple-clang-21-o3-arm64",
    )


def _fingerprint(expression: BitVectorExpression) -> Tuple[int, ...]:
    generator = random.Random(20_260_829)
    samples = (
        (0, 0),
        (0, 1),
        (1, 0),
        (MASK, 0),
        (0, MASK),
        (MASK, MASK),
        *tuple((generator.getrandbits(32), generator.getrandbits(32)) for _ in range(48)),
    )
    return tuple(
        evaluate_expression(expression, {"a": left, "b": right})
        for left, right in samples
    )


def synthesize_equivalent_schemas(limit: int = 96) -> Tuple[SynthesizedSchema, ...]:
    """Enumerate a typed schema grammar; no rewrite identity is preselected."""

    a, b, one = var("a"), var("b"), const(1)
    primitives = {
        expression.expression_id: expression
        for expression in (
            a,
            b,
            binary("add", a, b),
            binary("sub", a, b),
            binary("sub", b, a),
            binary("xor", a, b),
            binary("and", a, b),
            binary("or", a, b),
            unary("not", a),
            unary("not", b),
            unary("neg", a),
            unary("neg", b),
        )
    }
    derived = dict(primitives)
    for expression in tuple(primitives.values()):
        for op in ("shl", "lshr"):
            shifted = binary(op, expression, one)
            derived[shifted.expression_id] = shifted
    pool = tuple(sorted(derived.values(), key=lambda item: item.expression_id))
    replacements = tuple(
        sorted(primitives.values(), key=lambda item: (item.size, item.expression_id))
    )
    replacement_by_fingerprint: Dict[Tuple[int, ...], list[BitVectorExpression]] = {}
    for replacement in replacements:
        replacement_by_fingerprint.setdefault(_fingerprint(replacement), []).append(
            replacement
        )

    proposals: Dict[Tuple[str, str], SynthesizedSchema] = {}
    for op in ("add", "sub", "xor", "and", "or"):
        for left in pool:
            for right in pool:
                source = binary(op, left, right)
                if source.size <= 3:
                    continue
                matches = replacement_by_fingerprint.get(_fingerprint(source), ())
                for replacement in matches:
                    if source.size <= replacement.size:
                        continue
                    proof = prove_equivalent(source, replacement)
                    if not proof.equivalent:
                        continue
                    instantiated_source = substitute(source, {"a": var("x"), "b": var("y")})
                    instantiated_replacement = substitute(
                        replacement, {"a": var("x"), "b": var("y")}
                    )
                    source_count = len(compile_expression(instantiated_source))
                    replacement_count = len(compile_expression(instantiated_replacement))
                    schema = SynthesizedSchema(
                        source=source,
                        replacement=replacement,
                        source_instruction_count=source_count,
                        replacement_instruction_count=replacement_count,
                        proof_ref=proof.proof_ref,
                    )
                    proposals[(source.expression_id, replacement.expression_id)] = schema
    ranked = sorted(
        proposals.values(),
        key=lambda item: (
            -item.instruction_gain,
            -(item.source.size - item.replacement.size),
            item.schema_id,
        ),
    )
    return tuple(ranked[:limit])


def instantiate_schema(
    schema: SynthesizedSchema,
    left: BitVectorExpression,
    right: BitVectorExpression,
    *,
    wrapper: Optional[str] = None,
) -> Tuple[BitVectorExpression, BitVectorExpression]:
    bindings = {"a": left, "b": right}
    source = substitute(schema.source, bindings)
    replacement = substitute(schema.replacement, bindings)
    if wrapper == "xor_constant":
        source = binary("xor", source, const(0x9E3779B9))
        replacement = binary("xor", replacement, const(0x9E3779B9))
    elif wrapper == "add_context":
        source = binary("add", source, binary("and", var("x"), var("y")))
        replacement = binary(
            "add", replacement, binary("and", var("x"), var("y"))
        )
    return source, replacement
