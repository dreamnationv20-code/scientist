from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import EvidencePartition


COMMUTATIVE_OPERATORS = frozenset(("add", "and", "or", "xor"))
BINARY_OPERATORS = frozenset(
    ("add", "sub", "and", "or", "xor", "shl", "lshr")
)
UNARY_OPERATORS = frozenset(("not", "neg"))


@dataclass(frozen=True)
class BitVectorExpression:
    op: str
    args: Tuple["BitVectorExpression", ...] = ()
    atom: Optional[str] = None
    value: Optional[int] = None

    def __post_init__(self) -> None:
        if self.op == "var":
            if not self.atom or self.args or self.value is not None:
                raise ValueError("bit-vector variable is malformed")
        elif self.op == "const":
            if self.value is None or self.args or self.atom is not None:
                raise ValueError("bit-vector constant is malformed")
        elif self.op in UNARY_OPERATORS:
            if len(self.args) != 1 or self.atom is not None or self.value is not None:
                raise ValueError("unary bit-vector expression is malformed")
        elif self.op in BINARY_OPERATORS:
            if len(self.args) != 2 or self.atom is not None or self.value is not None:
                raise ValueError("binary bit-vector expression is malformed")
            if self.op in ("shl", "lshr") and self.args[1].op != "const":
                raise ValueError("pilot shift amounts must be constant")
        else:
            raise ValueError("unsupported bit-vector operator %r" % self.op)

    @property
    def expression_id(self) -> str:
        return content_digest(self.as_dict())

    @property
    def size(self) -> int:
        return 1 + sum(argument.size for argument in self.args)

    def operators(self) -> Tuple[str, ...]:
        return (self.op,) + tuple(
            operator
            for argument in self.args
            for operator in argument.operators()
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "op": self.op,
            "args": [argument.as_dict() for argument in self.args],
            "atom": self.atom,
            "value": self.value,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "BitVectorExpression":
        return cls(
            op=str(value["op"]),
            args=tuple(cls.from_dict(item) for item in value.get("args", ())),
            atom=None if value.get("atom") is None else str(value["atom"]),
            value=None if value.get("value") is None else int(value["value"]),
        )

    def to_c(self) -> str:
        if self.op == "var":
            return str(self.atom)
        if self.op == "const":
            return "%du" % (int(self.value) & 0xFFFFFFFF)
        if self.op == "not":
            return "(~%s)" % self.args[0].to_c()
        if self.op == "neg":
            return "(0u-%s)" % self.args[0].to_c()
        symbol = {
            "add": "+",
            "sub": "-",
            "and": "&",
            "or": "|",
            "xor": "^",
            "shl": "<<",
            "lshr": ">>",
        }[self.op]
        return "(%s%s%s)" % (self.args[0].to_c(), symbol, self.args[1].to_c())


def var(name: str) -> BitVectorExpression:
    return BitVectorExpression("var", atom=name)


def const(value: int) -> BitVectorExpression:
    return BitVectorExpression("const", value=value)


def unary(op: str, argument: BitVectorExpression) -> BitVectorExpression:
    return BitVectorExpression(op, (argument,))


def binary(
    op: str,
    left: BitVectorExpression,
    right: BitVectorExpression,
) -> BitVectorExpression:
    if op in COMMUTATIVE_OPERATORS and right.expression_id < left.expression_id:
        left, right = right, left
    return BitVectorExpression(op, (left, right))


@dataclass(frozen=True)
class CompilerRewrite:
    name: str
    source_pattern: BitVectorExpression
    replacement_pattern: BitVectorExpression
    concept_ref: str
    synthesis_ref: str

    def __post_init__(self) -> None:
        if not all((self.name, self.concept_ref, self.synthesis_ref)):
            raise ValueError("compiler rewrite identity is incomplete")
        if self.source_pattern.expression_id == self.replacement_pattern.expression_id:
            raise ValueError("compiler rewrite must change the expression")

    @property
    def candidate_id(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "source_pattern": self.source_pattern.as_dict(),
            "replacement_pattern": self.replacement_pattern.as_dict(),
            "concept_ref": self.concept_ref,
            "synthesis_ref": self.synthesis_ref,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "CompilerRewrite":
        return cls(
            name=str(value["name"]),
            source_pattern=BitVectorExpression.from_dict(value["source_pattern"]),
            replacement_pattern=BitVectorExpression.from_dict(
                value["replacement_pattern"]
            ),
            concept_ref=str(value["concept_ref"]),
            synthesis_ref=str(value["synthesis_ref"]),
        )


@dataclass(frozen=True)
class CompilerExpressionCase:
    case_ref: str
    expression: BitVectorExpression
    partition: EvidencePartition
    regime: str
    horizon: str

    def __post_init__(self) -> None:
        if not all((self.case_ref, self.regime, self.horizon)):
            raise ValueError("compiler expression case is incomplete")

    @property
    def case_id(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "case_ref": self.case_ref,
            "expression": self.expression.as_dict(),
            "partition": self.partition.value,
            "regime": self.regime,
            "horizon": self.horizon,
        }


@dataclass(frozen=True)
class CompilerObservation:
    candidate_id: str
    case_id: str
    input_expression: BitVectorExpression
    output_expression: BitVectorExpression
    rewrite_count: int
    instruction_count: int
    instructions: Tuple[str, ...]
    assembly_digest: str
    compiler_ref: str

    def __post_init__(self) -> None:
        if not all(
            (self.candidate_id, self.case_id, self.assembly_digest, self.compiler_ref)
        ):
            raise ValueError("compiler observation is incomplete")
        if self.rewrite_count < 0 or self.instruction_count <= 0:
            raise ValueError("compiler observation counts are invalid")
        if self.instruction_count != len(self.instructions):
            raise ValueError("instruction count and assembly disagree")

    @property
    def observation_id(self) -> str:
        return content_digest(self.as_dict())

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "case_id": self.case_id,
            "input_expression": self.input_expression.as_dict(),
            "output_expression": self.output_expression.as_dict(),
            "rewrite_count": self.rewrite_count,
            "instruction_count": self.instruction_count,
            "instructions": list(self.instructions),
            "assembly_digest": self.assembly_digest,
            "compiler_ref": self.compiler_ref,
        }
