from __future__ import annotations

from scientist.domains.compiler_optimization.adapter import (
    CompilerOptimizationAdapter,
    incumbent_rewrite,
)
from scientist.domains.compiler_optimization.models import (
    CompilerExpressionCase,
    CompilerRewrite,
    binary,
    const,
    var,
)
from scientist.domains.compiler_optimization.research import (
    CompilerAutonomousResearchComponent,
)
from scientist.domains.compiler_optimization.standard import (
    campaign_contract,
    problem_charter,
)
from scientist.kernel.contracts import EvidencePartition
from scientist.kernel.domain_registry import (
    DomainConformanceFixture,
    ScientificDomainBundle,
)
from scientist.program.research_kernel import ResearchActionKind


def domain_bundle() -> ScientificDomainBundle:
    adapter = CompilerOptimizationAdapter()
    incumbent = incumbent_rewrite()
    component = CompilerAutonomousResearchComponent()
    candidate = CompilerRewrite(
        name="conformance-add-zero",
        source_pattern=binary("add", var("a"), const(0)),
        replacement_pattern=var("a"),
        concept_ref="conformance-only",
        synthesis_ref="conformance-fixture-v1",
    )

    def fixture() -> DomainConformanceFixture:
        return DomainConformanceFixture(
            candidate=candidate,
            control=incumbent,
            experiment=CompilerExpressionCase(
                case_ref="conformance-add-zero",
                expression=binary("add", var("x"), const(0)),
                partition=EvidencePartition.DEVELOPMENT,
                regime="conformance",
                horizon="root_context",
            ),
        )

    return ScientificDomainBundle(
        domain_id=adapter.domain_id,
        adapter=adapter,
        charter_factory=problem_charter,
        campaign_factory=lambda incumbent_id: campaign_contract(
            incumbent_id or incumbent.candidate_id
        ),
        fixture_factory=fixture,
        capability_manifest=adapter.capabilities,
        bundle_ref="verified-compiler-optimization-domain-bundle-v1",
        research_components={
            action.value: component for action in ResearchActionKind
        },
    )
