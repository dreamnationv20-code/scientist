from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from statistics import mean
from typing import Any, Dict, List, Mapping, Optional, Tuple

from scientist.core.artifacts import content_digest
from scientist.domains.compiler_optimization.adapter import (
    CompilerOptimizationAdapter,
    incumbent_rewrite,
)
from scientist.domains.compiler_optimization.engine import (
    SynthesizedSchema,
    compile_expression,
    instantiate_schema,
    prove_equivalent,
    substitute,
    synthesize_equivalent_schemas,
)
from scientist.domains.compiler_optimization.models import (
    BitVectorExpression,
    CompilerExpressionCase,
    CompilerRewrite,
    binary,
    const,
    var,
)
from scientist.kernel.contracts import EvidencePartition, MetricDirection, MetricSpec
from scientist.program.campaigns import (
    IncumbentEntry,
    IncumbentPortfolio,
    IncumbentRole,
)
from scientist.program.causal_failure import (
    CausalFailureModel,
    CausalFailureModelSet,
    CausalRelationKind,
)
from scientist.program.contracts import HighLevelGoal
from scientist.program.literature import (
    ClaimClassification,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)
from scientist.program.research_kernel import (
    AutonomousResearchKernel,
    BehavioralMechanismCertificate,
    ConceptValidationCertificate,
    CounterfactualContrast,
    DiagnosticConceptHypothesis,
    DiscriminatingExperimentPlan,
    MultiHorizonEvaluationCertificate,
    PhenomenonAtlas,
    PhenomenonCase,
    ProgramDisposition,
    ResearchActionKind,
    ResearchDispatchResult,
    ResearchMissionContract,
    ResearchProgramDecision,
)


ROOT_NODE_ID = "verified-compiler-rewrite-root"
MISSION_HORIZONS = ("root_context", "nested_context")


@dataclass(frozen=True)
class AtlasSchemaRow:
    schema: SynthesizedSchema
    wrapper: Optional[str]
    case: CompilerExpressionCase
    replacement: BitVectorExpression
    source_instruction_count: int
    replacement_instruction_count: int
    evidence_id: str
    contrast_id: str

    @property
    def gain(self) -> int:
        return self.source_instruction_count - self.replacement_instruction_count


def compiler_goal() -> HighLevelGoal:
    return HighLevelGoal(
        name="Verified compiler optimization discovery",
        outcome=(
            "Discover a general, all-input-correct bit-vector rewrite that "
            "reduces optimized arm64 instruction count on sealed expressions."
        ),
        scope=(
            "pure uint32_t two-input expressions",
            "typed grammar synthesis",
            "Apple Clang 21 -O3 arm64",
            "Z3 32-bit equivalence proofs",
        ),
        anti_scope=(
            "mathematical novelty claims without candidate-specific literature",
            "undefined C semantics",
            "wall-clock, energy, x86, or production-deployment claims",
        ),
        terminal_metrics=(
            MetricSpec(
                name="instruction_reduction",
                direction=MetricDirection.MAXIMIZE,
                unit="static arm64 instructions",
                aggregation="sum over sealed independent expressions",
                primary=True,
            ),
            MetricSpec(
                name="proof_rate",
                direction=MetricDirection.MAXIMIZE,
                unit="fraction",
                aggregation="mean exact proof result",
            ),
        ),
        success_definition=(
            "A frozen schema is proven for every 32-bit input, improves both "
            "required contexts, has no sealed regression, and replicates."
        ),
        failure_conditions=(
            "no positive counterfactual compiler-cost gap is found",
            "the latent concept fails prospective discrimination",
            "Z3 produces a counterexample",
            "either required context has non-positive aggregate improvement",
            "any sealed expression regresses",
        ),
        integration_requirements=(
            "serialize the rewrite schema and exact Z3 proof identity",
            "retain source and replacement assembly for independent audit",
        ),
        total_compute_budget=2_000.0,
        max_parallel_campaigns=1,
    )


def compiler_mission(domain_bundle_ref: str) -> ResearchMissionContract:
    goal = compiler_goal()
    return ResearchMissionContract(
        goal=goal,
        goal_graph_ref="objective-first-compiler-goal-v1",
        root_node_id=ROOT_NODE_ID,
        domain_id=CompilerOptimizationAdapter.domain_id,
        domain_bundle_ref=domain_bundle_ref,
        research_question=(
            "Which missing semantic representation causes Clang -O3 to retain "
            "a costlier expression, and what verified schema repairs it?"
        ),
        claim_signature=ClaimSignature(
            subject_id=goal.goal_id,
            statement=(
                "A synthesized source rewrite reduces optimized arm64 instruction "
                "count while preserving every 32-bit input-output mapping."
            ),
            problem="verified compiler optimization of uint32_t expressions",
            phenomenon="semantically equivalent syntax can produce different code cost",
            intervention="apply one frozen all-input-proven rewrite schema",
            mechanism="canonicalize a missed semantic equivalence class",
            evaluation="sealed root and nested contexts with Z3 verification",
        ),
        primary_metric="instruction_reduction",
        terminal_gate_ref="verified-compiler-sealed-gate-v1",
        required_horizons=MISSION_HORIZONS,
        program_stop_rules=(
            "kill if no all-input-proven positive schema exists",
            "kill if prospective concept discrimination fails",
            "kill if a sealed expression regresses",
            "promote only as an internal replicated effect",
        ),
        forbidden_shortcuts=(
            "random testing cannot replace an all-input proof",
            "AST shrinkage cannot substitute for generated-code improvement",
            "development expressions cannot authorize the terminal claim",
            "a local result cannot be called mathematically novel or cross-platform",
        ),
        owner_ref="user-specified-compiler-discovery-goal",
    )


class CompilerAutonomousResearchComponent:
    """Domain instruments; the V3 kernel alone selects the action order."""

    name = "verified-compiler-autonomous-laboratory"
    component_version = "v1"

    def __init__(self) -> None:
        self.adapter = CompilerOptimizationAdapter()
        self.schemas: Tuple[SynthesizedSchema, ...] = ()
        self.atlas_rows: Tuple[AtlasSchemaRow, ...] = ()
        self.selected_schema: Optional[SynthesizedSchema] = None
        self.candidate: Optional[CompilerRewrite] = None
        self.prospective_rows: Tuple[Mapping[str, Any], ...] = ()
        self.sealed_rows: Tuple[Mapping[str, Any], ...] = ()

    def dispatch(self, action, kernel, domain) -> ResearchDispatchResult:
        handlers = {
            ResearchActionKind.FREEZE_MISSION: self._freeze_mission,
            ResearchActionKind.SURVEY_PRIOR_ART: self._survey_prior_art,
            ResearchActionKind.REPRODUCE_INCUMBENT: self._reproduce_incumbent,
            ResearchActionKind.MAP_PHENOMENON: self._map_phenomenon,
            ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS: self._build_diagnosis,
            ResearchActionKind.INVENT_LATENT_CONCEPT: self._invent_concept,
            ResearchActionKind.VALIDATE_LATENT_CONCEPT: self._validate_concept,
            ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT: (
                self._design_experiment
            ),
            ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM: (
                self._compile_and_audit
            ),
            ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION: self._evaluate,
            ResearchActionKind.MAKE_PROGRAM_DECISION: self._decide,
            ResearchActionKind.REPORT_TERMINAL: self._report,
        }
        return handlers[action.kind](kernel, domain)

    def _freeze_mission(self, kernel, domain) -> ResearchDispatchResult:
        mission = compiler_mission(domain.bundle_ref)
        kernel.freeze_mission(mission, domain)
        return self._progress("mission_frozen", mission_id=mission.mission_id)

    def _survey_prior_art(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        mission = kernel.mission
        works = (
            PriorWork(
                work_id="llvm-instcombine",
                title="LLVM InstCombine contributor guide",
                year=2026,
                locator="https://llvm.org/docs/InstCombineContributorGuide.html",
                relation=PriorArtRelation.EXECUTABLE_BASELINE,
                matched_components=(
                    "peephole algebraic canonicalization",
                    "production executable incumbent",
                ),
                executable=True,
                abstract="Production LLVM canonicalization and simplification rules.",
            ),
            PriorWork(
                work_id="alive2",
                title="Alive2: bounded translation validation for LLVM",
                year=2021,
                locator="https://github.com/AliveToolkit/alive2",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "SMT verification of compiler transformations",
                    "LLVM semantics",
                ),
                executable=True,
                abstract="Automatically proves or refutes LLVM transformations.",
            ),
            PriorWork(
                work_id="souper",
                title="Souper: a synthesizing superoptimizer",
                year=2016,
                locator="https://github.com/google/souper",
                relation=PriorArtRelation.STRONG_OVERLAP,
                matched_components=(
                    "enumerative synthesis",
                    "SMT-proven integer rewrites",
                ),
                executable=True,
                abstract="Synthesizes LLVM integer optimizations from dataflow expressions.",
            ),
            PriorWork(
                work_id="alphadev",
                title="Faster sorting algorithms discovered using deep reinforcement learning",
                year=2023,
                locator="https://www.nature.com/articles/s41586-023-06004-9",
                relation=PriorArtRelation.ADJACENT,
                matched_components=(
                    "machine-generated low-level algorithms",
                    "code-cost optimization",
                ),
                executable=False,
                abstract="Search discovered faster low-level sorting routines.",
            ),
        )
        queries = tuple(
            LiteratureQuery(query, facet, provider)
            for query, facet, provider in (
                (
                    "LLVM InstCombine missed bit-vector rewrites",
                    SearchFacet.PROBLEM,
                    "LLVM documentation",
                ),
                (
                    "SMT verified compiler superoptimization Alive2 Souper",
                    SearchFacet.INTERVENTION,
                    "ACM Digital Library",
                ),
                (
                    "semantic canonicalization machine instruction cost",
                    SearchFacet.MECHANISM,
                    "Google Scholar",
                ),
                (
                    "citations Alive2 Souper LLVM InstCombine",
                    SearchFacet.CITATION_NEIGHBORHOOD,
                    "Semantic Scholar",
                ),
                (
                    "held-out validation synthesized compiler rewrites",
                    SearchFacet.EVALUATION,
                    "arXiv",
                ),
            )
        )
        assessment = PriorArtAssessment(
            signature=mission.claim_signature,
            trigger=LiteratureTrigger.INITIAL_SCOPE,
            queries=queries,
            closest_works=works,
            classification=ClaimClassification.INCREMENTAL_ADVANCE,
            rationale=(
                "Verified rewrite synthesis and production peephole optimization "
                "are established. Before candidate-specific search, only an "
                "incremental autonomous-diagnosis claim is supportable."
            ),
            novel_delta=(
                "diagnosis-first prospective schema selection inside the frozen V3 lifecycle",
            ),
            citation_snowball_complete=True,
            searched_at=date.today().isoformat(),
            reviewer_ref="compiler-prior-art-auditor-v1",
            executable_incumbent_id="llvm-instcombine",
        )
        kernel.register_prior_art(assessment)
        return self._progress(
            "prior_art_closed",
            classification=assessment.classification.value,
            closest_works=[work.work_id for work in works],
        )

    def _reproduce_incumbent(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        expression = binary("add", var("x"), var("y"))
        instructions = compile_expression(expression)
        reproduction_id = content_digest(
            {
                "compiler": self.adapter.evaluator_ref,
                "expression": expression.as_dict(),
                "instructions": instructions,
            }
        )
        incumbent = incumbent_rewrite()
        portfolio = IncumbentPortfolio(
            node_id=ROOT_NODE_ID,
            literature_assessment_id=kernel.prior_art.assessment_id,
            entries=(
                IncumbentEntry(
                    candidate_id="unoptimized-source-null",
                    name="Unoptimized source representation",
                    role=IncumbentRole.NULL,
                    executable_digest=content_digest("unoptimized-source-null"),
                    source_locator="internal null control",
                    reproduction_evidence_ids=(),
                    metric_summary={"instruction_count": float(len(instructions))},
                    limitations=("not a deployable compiler baseline",),
                ),
                IncumbentEntry(
                    candidate_id=incumbent.candidate_id,
                    name="Apple Clang 21 -O3 arm64 with no source rewrite",
                    role=IncumbentRole.BEST_END_TO_END,
                    executable_digest=content_digest(incumbent.as_dict()),
                    source_locator="clang --version and local executable",
                    source_work_id="llvm-instcombine",
                    reproduction_evidence_ids=(reproduction_id,),
                    metric_summary={"instruction_count": float(len(instructions))},
                    limitations=(
                        "Apple arm64 only",
                        "source-expression pilot rather than full LLVM IR corpus",
                    ),
                ),
            ),
            primary_incumbent_id=incumbent.candidate_id,
            selection_rationale=(
                "The deployed local Apple Clang -O3 pipeline is the strongest "
                "executable end-to-end baseline available to this run."
            ),
        )
        kernel.register_incumbent(portfolio)
        return self._progress(
            "incumbent_reproduced",
            incumbent_id=incumbent.candidate_id,
            fixture_instructions=list(instructions),
        )

    def _schema_measurement(
        self,
        schema: SynthesizedSchema,
        wrapper: Optional[str],
        case_ref: str,
        partition: EvidencePartition,
    ) -> AtlasSchemaRow:
        source, replacement = instantiate_schema(
            schema,
            var("x"),
            var("y"),
            wrapper=wrapper,
        )
        source_instructions = compile_expression(source)
        replacement_instructions = compile_expression(replacement)
        horizon = "root_context" if wrapper is None else "nested_context"
        case = CompilerExpressionCase(
            case_ref=case_ref,
            expression=source,
            partition=partition,
            regime="direct" if wrapper is None else str(wrapper),
            horizon=horizon,
        )
        evidence_id = content_digest(
            {
                "case_id": case.case_id,
                "source_assembly": source_instructions,
                "replacement_assembly": replacement_instructions,
                "schema_proof_ref": schema.proof_ref,
            }
        )
        contrast = CounterfactualContrast(
            case_id=case.case_id,
            incumbent_decision="retain source expression before Clang -O3",
            forced_decision="replace with the proven cheaper semantic representative",
            terminal_effect=float(len(source_instructions) - len(replacement_instructions)),
            matched_context=(
                "same compiler, flags, target, expression inputs, and unsigned semantics"
            ),
            mediator_observation=(
                "generated arm64 instruction count changed after an equivalent rewrite"
            ),
            existing_descriptors=(
                "source_ast_size=%d" % source.size,
                "replacement_ast_size=%d" % replacement.size,
                "context=%s" % horizon,
            ),
            unexplained_by_current_representation=True,
            evidence_ids=(evidence_id,),
            analyst_ref="counterfactual-clang-codegen-miner-v1",
        )
        return AtlasSchemaRow(
            schema=schema,
            wrapper=wrapper,
            case=case,
            replacement=replacement,
            source_instruction_count=len(source_instructions),
            replacement_instruction_count=len(replacement_instructions),
            evidence_id=evidence_id,
            contrast_id=contrast.contrast_id,
        )

    def _map_phenomenon(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        self.schemas = synthesize_equivalent_schemas(limit=96)
        positive = tuple(schema for schema in self.schemas if schema.instruction_gain > 0)
        nonpositive = tuple(schema for schema in self.schemas if schema.instruction_gain <= 0)
        if not positive or not nonpositive:
            raise ValueError("schema grammar did not expose opposing compiler-cost effects")
        winner = positive[0]
        rows: List[AtlasSchemaRow] = [
            self._schema_measurement(
                winner, None, "development-winner-root", EvidencePartition.DEVELOPMENT
            ),
            self._schema_measurement(
                winner,
                "xor_constant",
                "development-winner-nested",
                EvidencePartition.DEVELOPMENT,
            ),
        ]
        for schema, wrapper, label in (
            (nonpositive[0], None, "development-control-root"),
            (nonpositive[-1], "add_context", "development-control-nested"),
        ):
            row = self._schema_measurement(
                schema, wrapper, label, EvidencePartition.DEVELOPMENT
            )
            rows.append(row)
        self.atlas_rows = tuple(rows)
        cases = tuple(
            PhenomenonCase(
                case_ref=row.case.case_ref,
                regime=row.case.regime,
                horizon=row.case.horizon,
                incumbent_decision="retain source expression before Clang -O3",
                outcome_metrics={
                    "instruction_count": float(row.source_instruction_count),
                    "ast_size": float(row.case.expression.size),
                },
                evidence_ids=(row.evidence_id,),
                trace_ref="clang-assembly:%s" % row.evidence_id,
            )
            for row in rows
        )
        # Reconstruct contrasts against the content-addressed phenomenon-case IDs.
        contrasts = tuple(
            CounterfactualContrast(
                case_id=case.case_id,
                incumbent_decision="retain source expression before Clang -O3",
                forced_decision="replace with the proven cheaper semantic representative",
                terminal_effect=float(row.gain),
                matched_context=(
                    "same compiler, flags, target, expression inputs, and unsigned semantics"
                ),
                mediator_observation=(
                    "generated arm64 instruction count after semantic replacement"
                ),
                existing_descriptors=(
                    "source_ast_size=%d" % row.case.expression.size,
                    "replacement_ast_size=%d" % row.replacement.size,
                    "context=%s" % row.case.horizon,
                ),
                unexplained_by_current_representation=True,
                evidence_ids=(row.evidence_id,),
                analyst_ref="counterfactual-clang-codegen-miner-v1",
            )
            for row, case in zip(rows, cases)
        )
        self.atlas_rows = tuple(
            AtlasSchemaRow(
                schema=row.schema,
                wrapper=row.wrapper,
                case=row.case,
                replacement=row.replacement,
                source_instruction_count=row.source_instruction_count,
                replacement_instruction_count=row.replacement_instruction_count,
                evidence_id=row.evidence_id,
                contrast_id=contrast.contrast_id,
            )
            for row, contrast in zip(rows, contrasts)
        )
        atlas = PhenomenonAtlas(
            mission_id=kernel.mission.mission_id,
            incumbent_portfolio_id=kernel.incumbent.portfolio_id,
            cases=cases,
            contrasts=contrasts,
            coverage_axes=(
                "rewrite_schema",
                "root_vs_nested_context",
                "generated_instruction_cost",
            ),
            sealed=True,
            builder_ref="typed-schema-counterfactual-atlas-v1",
        )
        kernel.register_atlas(atlas)
        return self._progress(
            "phenomenon_atlas_built",
            enumerated_schemas=len(self.schemas),
            positive_schemas=len(positive),
            contrast_effects=[contrast.terminal_effect for contrast in contrasts],
        )

    def _build_diagnosis(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        positive_rows = tuple(row for row in self.atlas_rows if row.gain > 0)
        evidence_ids = tuple(row.evidence_id for row in positive_rows)
        model = CausalFailureModel(
            target_node_id=ROOT_NODE_ID,
            cluster_id="semantic-cost-canonicalization-gap",
            cluster_description=(
                "All-input-equivalent expressions with similar visible shrinkage "
                "produce opposing generated-code effects."
            ),
            unavailable_information=(
                "the syntax-local optimizer lacks the relevant global semantic equivalence"
            ),
            information_available_after=(
                "Z3 equivalence proof plus paired native code generation"
            ),
            irreversible_decision="retain the original semantic representative",
            decision_point="before Clang optimization and instruction selection",
            alternative_action="canonicalize to the proven lower-cost representative",
            changed_result="fewer generated arm64 instructions on positive contrasts",
            causal_chain=(
                "missing semantic class -> costly retained form -> proof-guided "
                "canonicalization -> lower generated instruction count"
            ),
            causal_relations=(
                CausalRelationKind.STATE_SELECTS_POLICY,
                CausalRelationKind.FEEDBACK_CORRECTS_FUTURE_ACTION,
            ),
            observable_proxies=(
                "operator-relation signature",
                "paired generated-code cost gap",
                "all-input equivalence proof",
            ),
            evidence_ids=evidence_ids,
            assumptions=(
                "uint32_t operations use modulo-2^32 semantics",
                "static instruction count is the frozen local cost metric",
            ),
            distinguishing_predictions=(
                "the selected relation predicts positive cost gaps in unseen operands",
                "equally large AST reductions outside the relation need not improve code",
            ),
            falsification_conditions=(
                "prospective relation-matched cases do not improve",
                "AST size alone predicts prospective effects equally well",
            ),
            modeler_ref="compiler-causal-diagnostician-v1",
            decision_trace_ids=tuple(
                "clang-assembly:%s" % evidence_id for evidence_id in evidence_ids
            ),
            causal_signature=(
                "semantic_equivalence",
                "canonical_representation",
                "instruction_selection",
            ),
            information_regime="semantic equivalence hidden from the incumbent optimizer",
            mediator="selected semantic representative",
            counterfactual_effect=float(max(row.gain for row in positive_rows)),
            proxy_reliability=1.0,
            empirically_supported=True,
        )
        diagnosis = CausalFailureModelSet(
            target_node_id=ROOT_NODE_ID,
            failure_cluster_ids=(model.cluster_id,),
            models=(model,),
            source_artifact_ids=(*evidence_ids, kernel.atlas.atlas_id),
            builder_ref="compiler-causal-diagnostician-v1",
        )
        kernel.register_diagnosis(diagnosis)
        return self._progress(
            "causal_diagnosis_supported",
            model_id=model.model_id,
            maximum_counterfactual_effect=model.counterfactual_effect,
        )

    def _invent_concept(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        winner_rows = tuple(row for row in self.atlas_rows if row.gain > 0)
        self.selected_schema = max(
            (row.schema for row in winner_rows),
            key=lambda schema: (
                schema.instruction_gain,
                schema.source.size - schema.replacement.size,
                schema.schema_id,
            ),
        )
        selected_rows = tuple(
            row for row in self.atlas_rows if row.schema.schema_id == self.selected_schema.schema_id
        )
        source_ops = tuple(sorted(set(self.selected_schema.source.operators())))
        replacement_ops = tuple(
            sorted(set(self.selected_schema.replacement.operators()))
        )
        name = "proof_conditioned_%s_to_%s_canonicality" % (
            "_".join(source_ops),
            "_".join(replacement_ops),
        )
        concept = DiagnosticConceptHypothesis(
            atlas_id=kernel.atlas.atlas_id,
            causal_model_set_id=kernel.diagnosis.model_set_id,
            name=name,
            definition=(
                "Membership in an all-input semantic equivalence class where a "
                "specific operator relation, rather than AST shrinkage alone, "
                "selects a cheaper native-code canonical representative."
            ),
            input_primitives=(
                "typed operator-relation signature",
                "Z3 all-input equivalence result",
                "source and replacement AST sizes",
                "paired native instruction counts",
            ),
            computation=(
                "%s => %s"
                % (
                    self.selected_schema.source.to_c(),
                    self.selected_schema.replacement.to_c(),
                )
            ),
            causal_explanation=(
                "The incumbent recognizes syntax-local simplifications but not this "
                "global relation; proof-conditioned canonicalization exposes the "
                "lower-cost form to instruction selection."
            ),
            distinguishing_predictions=(
                "relation-matched unseen instantiations retain a positive code-cost gap",
                "size-matched equivalences outside the relation include zero-effect cases",
            ),
            boundary_conditions=(
                "pure uint32_t modulo arithmetic",
                "the schema matches structurally after typed substitution",
                "Apple Clang 21 -O3 arm64 cost model",
            ),
            falsification_conditions=(
                "the relation fails an all-input proof",
                "prospective discrimination does not beat AST shrinkage",
                "nested contexts erase the code-cost advantage",
            ),
            development_contrast_ids=tuple(row.contrast_id for row in selected_rows),
            required_predictive_score=0.75,
            minimum_predictive_improvement=0.20,
            prospective_case_count=4,
            validation_protocol_ref="sealed-schema-discrimination-v1",
            proposer_ref="contrast-conditioned-schema-inventor-v1",
        )
        kernel.register_concept(concept)
        return self._progress(
            "latent_concept_invented",
            concept_name=concept.name,
            source_pattern=self.selected_schema.source.to_c(),
            replacement_pattern=self.selected_schema.replacement.to_c(),
        )

    def _prospective_rows(self) -> Tuple[Mapping[str, Any], ...]:
        selected = self.selected_schema
        decoys = tuple(
            schema
            for schema in self.schemas
            if schema.instruction_gain == 0
            and schema.source.size >= selected.source.size - 1
        )[:2]
        operand_pairs = (
            (binary("xor", var("x"), const(0xA5A5A5A5)), var("y")),
            (binary("add", var("x"), const(17)), binary("xor", var("y"), const(3))),
        )
        rows: List[Mapping[str, Any]] = []
        for index, (left, right) in enumerate(operand_pairs):
            source, replacement = instantiate_schema(selected, left, right)
            gain = len(compile_expression(source)) - len(compile_expression(replacement))
            rows.append(
                {
                    "case_id": "prospective-match-%d" % index,
                    "matched": True,
                    "gain": gain,
                    "proof": prove_equivalent(source, replacement),
                    "source": source,
                    "replacement": replacement,
                }
            )
        for index, schema in enumerate(decoys):
            source, replacement = instantiate_schema(schema, *operand_pairs[index])
            gain = len(compile_expression(source)) - len(compile_expression(replacement))
            rows.append(
                {
                    "case_id": "prospective-size-decoy-%d" % index,
                    "matched": False,
                    "gain": gain,
                    "proof": prove_equivalent(source, replacement),
                    "source": source,
                    "replacement": replacement,
                }
            )
        if len(rows) != 4:
            raise ValueError("prospective concept validation requires four rows")
        return tuple(rows)

    def _validate_concept(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        rows = self._prospective_rows()
        self.prospective_rows = rows
        labels = tuple(row["gain"] > 0 and row["proof"].equivalent for row in rows)
        size_predictions = tuple(
            row["source"].size > row["replacement"].size for row in rows
        )
        concept_predictions = tuple(bool(row["matched"]) for row in rows)
        baseline_score = mean(
            float(prediction == label)
            for prediction, label in zip(size_predictions, labels)
        )
        augmented_score = mean(
            float(prediction == label)
            for prediction, label in zip(concept_predictions, labels)
        )
        matched_gains = tuple(row["gain"] for row in rows if row["matched"])
        evidence_ids = tuple(
            content_digest(
                {
                    "case_id": row["case_id"],
                    "source": row["source"].as_dict(),
                    "replacement": row["replacement"].as_dict(),
                    "gain": row["gain"],
                    "proof_ref": row["proof"].proof_ref,
                }
            )
            for row in rows
        )
        validation = ConceptValidationCertificate(
            concept_id=kernel.concept.concept_id,
            development_contrast_ids=kernel.concept.development_contrast_ids,
            prospective_case_ids=tuple(str(row["case_id"]) for row in rows),
            baseline_predictive_score=float(baseline_score),
            augmented_predictive_score=float(augmented_score),
            intervention_effect=float(mean(matched_gains)),
            required_predictive_score=kernel.concept.required_predictive_score,
            minimum_predictive_improvement=(
                kernel.concept.minimum_predictive_improvement
            ),
            evidence_ids=evidence_ids,
            evaluator_ref="independent-prospective-schema-validator-v1",
        )
        kernel.validate_concept(validation)
        return self._progress(
            "concept_validation_completed",
            passed=validation.passed,
            baseline_score=baseline_score,
            concept_score=augmented_score,
            matched_gains=list(matched_gains),
        )

    def _design_experiment(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        plan = DiscriminatingExperimentPlan(
            mission_id=kernel.mission.mission_id,
            concept_id=kernel.concept.concept_id,
            competing_hypothesis_ids=(
                kernel.concept.concept_id,
                "ast-shrinkage-null-hypothesis",
            ),
            predicted_outcomes={
                kernel.concept.concept_id: (
                    "positive reductions in unseen root and nested matches",
                    "zero Z3 counterexamples",
                    "no sealed regression",
                ),
                "ast-shrinkage-null-hypothesis": (
                    "benefit does not transfer by relation membership",
                    "nested context erases or reverses the advantage",
                ),
            },
            decision_rules={
                "all proofs pass and both contexts improve without regression": (
                    "promote an internal replicated compiler effect"
                ),
                "proof failure or regression": "kill the schema",
                "relation fails but another representation is evidenced": (
                    "materially reframe the concept"
                ),
            },
            horizon_refs=MISSION_HORIZONS,
            expected_information_gain=0.90,
            compute_cost=6.0,
            development_partition_ref="compiler-development-grammar-v1",
            sealed_evaluation_partition_ref="compiler-sealed-transfer-v1",
            oracle_inputs=(
                "development-only instruction-count contrasts",
                "development-only Z3 proof results",
            ),
            final_target_withheld=True,
            frozen=True,
            designer_ref="compiler-discriminating-experiment-designer-v1",
        )
        kernel.register_experiment(plan)
        return self._progress(
            "discriminating_experiment_frozen",
            plan_id=plan.plan_id,
            horizons=list(plan.horizon_refs),
        )

    def _probe_cases(self) -> Tuple[CompilerExpressionCase, ...]:
        source_root, _ = instantiate_schema(
            self.selected_schema, var("x"), var("y")
        )
        source_nested, _ = instantiate_schema(
            self.selected_schema,
            binary("xor", var("x"), const(5)),
            var("y"),
            wrapper="xor_constant",
        )
        return (
            CompilerExpressionCase(
                "behavior-probe-root",
                source_root,
                EvidencePartition.GUARD,
                "direct",
                "root_context",
            ),
            CompilerExpressionCase(
                "behavior-probe-nested",
                source_nested,
                EvidencePartition.GUARD,
                "xor_constant",
                "nested_context",
            ),
        )

    def _compile_and_audit(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        self.candidate = CompilerRewrite(
            name="verified-schema-%s" % self.selected_schema.schema_id[:12],
            source_pattern=self.selected_schema.source,
            replacement_pattern=self.selected_schema.replacement,
            concept_ref=kernel.concept.concept_id,
            synthesis_ref="typed-schema-enumerator-v1",
        )
        probes = self._probe_cases()
        incumbent = incumbent_rewrite()
        behavior = self.adapter.behavior_fingerprint(self.candidate, probes)
        incumbent_behavior = self.adapter.behavior_fingerprint(incumbent, probes)
        fallback_evidence = content_digest(
            {
                "fallback_candidate_id": incumbent.candidate_id,
                "portfolio_primary_id": kernel.incumbent.primary_incumbent_id,
                "probe_assemblies": [
                    self.adapter.evaluate(incumbent, probe).assembly_digest
                    for probe in probes
                ],
            }
        )
        certificate = BehavioralMechanismCertificate(
            concept_id=kernel.concept.concept_id,
            plan_id=kernel.experiment.plan_id,
            candidate_id=self.candidate.candidate_id,
            executable_digest=content_digest(self.candidate.as_dict()),
            mechanism_family="proof-conditioned-semantic-canonicalization",
            behavior_fingerprint=behavior,
            incumbent_behavior_fingerprint=incumbent_behavior,
            new_decision_primitives=(
                "all-input semantic-class membership",
                "relation-conditioned native cost gap",
            ),
            probe_trace_ids=tuple(probe.case_id for probe in probes),
            primary_incumbent_id=kernel.incumbent.primary_incumbent_id,
            fallback_candidate_id=incumbent.candidate_id,
            fallback_parity_evidence_ids=(fallback_evidence,),
            compiler_ref="typed-rewrite-schema-compiler-v1",
            auditor_ref="independent-z3-and-behavior-auditor-v1",
        )
        kernel.register_mechanism(certificate)
        return self._progress(
            "mechanism_compiled_and_audited",
            passed=certificate.passed,
            candidate_id=self.candidate.candidate_id,
            behaviorally_distinct=behavior != incumbent_behavior,
        )

    def _sealed_cases(self) -> Tuple[CompilerExpressionCase, ...]:
        operand_pairs = (
            (
                binary("lshr", var("x"), const(1)),
                binary("shl", var("y"), const(1)),
            ),
            (
                binary("or", var("x"), const(0x100)),
                binary("and", var("y"), const(0xFFFFFF00)),
            ),
            (
                binary("add", var("x"), const(0x1234)),
                binary("xor", var("y"), const(0x55AA55AA)),
            ),
        )
        cases: List[CompilerExpressionCase] = []
        for index, (left, right) in enumerate(operand_pairs):
            source, _ = instantiate_schema(self.selected_schema, left, right)
            cases.append(
                CompilerExpressionCase(
                    "sealed-root-%d" % index,
                    source,
                    EvidencePartition.REPLICATION,
                    "unseen_operand_pair_%d" % index,
                    "root_context",
                )
            )
            nested, _ = instantiate_schema(
                self.selected_schema,
                left,
                right,
                wrapper="add_context" if index % 2 == 0 else "xor_constant",
            )
            cases.append(
                CompilerExpressionCase(
                    "sealed-nested-%d" % index,
                    nested,
                    EvidencePartition.REPLICATION,
                    "unseen_operand_pair_%d" % index,
                    "nested_context",
                )
            )
        return tuple(cases)

    def _evaluate(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        incumbent = incumbent_rewrite()
        rows: List[Mapping[str, Any]] = []
        for case in self._sealed_cases():
            candidate_observation = self.adapter.evaluate(self.candidate, case)
            incumbent_observation = self.adapter.evaluate(incumbent, case)
            verification = self.adapter.verify(case, candidate_observation)
            gain = incumbent_observation.instruction_count - candidate_observation.instruction_count
            evidence_id = content_digest(
                {
                    "case": case.as_dict(),
                    "candidate": candidate_observation.as_dict(),
                    "incumbent": incumbent_observation.as_dict(),
                    "verification": verification.as_dict(),
                    "instruction_gain": gain,
                }
            )
            rows.append(
                {
                    "case": case,
                    "candidate": candidate_observation,
                    "incumbent": incumbent_observation,
                    "verification": verification,
                    "gain": gain,
                    "evidence_id": evidence_id,
                }
            )
        self.sealed_rows = tuple(rows)
        candidate_metrics: Dict[str, Dict[str, float]] = {}
        incumbent_metrics: Dict[str, Dict[str, float]] = {}
        for horizon in MISSION_HORIZONS:
            group = tuple(row for row in rows if row["case"].horizon == horizon)
            candidate_metrics[horizon] = {
                "instruction_reduction": float(sum(row["gain"] for row in group)),
                "proof_rate": float(mean(row["verification"].passed for row in group)),
                "cases_improved": float(sum(row["gain"] > 0 for row in group)),
                "cases_regressed": float(sum(row["gain"] < 0 for row in group)),
            }
            incumbent_metrics[horizon] = {
                "instruction_reduction": 0.0,
                "proof_rate": 1.0,
                "cases_improved": 0.0,
                "cases_regressed": 0.0,
            }
        all_proven = all(row["verification"].passed for row in rows)
        all_applied = all(row["candidate"].rewrite_count > 0 for row in rows)
        no_regression = all(row["gain"] >= 0 for row in rows)
        both_horizons_improve = all(
            candidate_metrics[horizon]["instruction_reduction"] > 0
            for horizon in MISSION_HORIZONS
        )
        terminal_gate = all(
            (all_proven, all_applied, no_regression, both_horizons_improve)
        )
        evidence_ids = tuple(str(row["evidence_id"]) for row in rows)
        evaluation = MultiHorizonEvaluationCertificate(
            candidate_id=self.candidate.candidate_id,
            plan_id=kernel.experiment.plan_id,
            horizon_metrics=candidate_metrics,
            incumbent_metrics=incumbent_metrics,
            prediction_checks={
                "all_input_equivalence": all_proven,
                "schema_fires_on_unseen_operands": all_applied,
                "root_and_nested_transfer": both_horizons_improve,
                "no_sealed_regression": no_regression,
            },
            development_evidence_ids=(kernel.atlas.atlas_id,),
            transfer_evidence_ids=(
                content_digest(
                    {
                        "transfer_summary": list(evidence_ids[:4]),
                        "candidate_id": self.candidate.candidate_id,
                    }
                ),
            ),
            terminal_evidence_ids=evidence_ids[:4],
            replication_evidence_ids=evidence_ids[4:],
            full_trajectory=True,
            oracle_free=True,
            terminal_gate_passed=terminal_gate,
            evaluator_ref=self.adapter.evaluator_ref,
            verifier_ref=self.adapter.verifier_ref,
            limitations=(
                "static instruction count is not wall-clock performance",
                "evaluation uses one Apple arm64 compiler version",
                "candidate-specific mathematical and LLVM prior art is not yet closed",
            ),
        )
        kernel.record_evaluation(evaluation)
        return self._progress(
            "sealed_evaluation_completed",
            claim_eligible=evaluation.claim_eligible,
            horizon_metrics=candidate_metrics,
            case_gains=[row["gain"] for row in rows],
        )

    def _decide(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        if kernel.evaluation is None:
            evidence = kernel.concept_validation.validation_id
            disposition = ProgramDisposition.KILL
            reasons = ("prospective concept validation failed",)
        elif kernel.evaluation.claim_eligible:
            evidence = kernel.evaluation.evaluation_id
            disposition = ProgramDisposition.PROMOTE
            reasons = (
                "all six sealed expressions are all-input equivalent",
                "both required contexts improve with no regression",
                "the result is eligible only as an internal replicated effect",
            )
        else:
            evidence = kernel.evaluation.evaluation_id
            disposition = ProgramDisposition.KILL
            reasons = (
                "the frozen terminal gate failed",
                "the one-cycle pilot forbids post-sealed tuning",
            )
        decision = ResearchProgramDecision(
            mission_id=kernel.mission.mission_id,
            disposition=disposition,
            central_hypothesis=(
                kernel.concept.causal_explanation
                if kernel.concept is not None
                else "semantic canonicalization can expose cheaper code"
            ),
            reasons=reasons,
            evidence_ids=(evidence,),
            localized_failure=None,
            repair_target=None,
            replacement_hypothesis=None,
            changed_representation_dimensions=(),
            decision_ref="independent-compiler-program-strategist-v1",
        )
        kernel.record_program_decision(decision)
        return self._progress(
            "program_decision_recorded",
            disposition=disposition.value,
            decision_id=decision.decision_id,
        )

    def _report(self, kernel, domain) -> ResearchDispatchResult:
        del domain
        details: Dict[str, Any] = {
            "terminal_disposition": kernel.terminal_disposition.value,
            "knowledge_records": len(kernel.knowledge.records),
        }
        if self.selected_schema is not None:
            details.update(
                {
                    "source_pattern": self.selected_schema.source.to_c(),
                    "replacement_pattern": self.selected_schema.replacement.to_c(),
                    "development_instruction_gain": (
                        self.selected_schema.instruction_gain
                    ),
                    "z3_proof_ref": self.selected_schema.proof_ref,
                }
            )
        if kernel.evaluation is not None:
            details["horizon_metrics"] = {
                horizon: dict(metrics)
                for horizon, metrics in kernel.evaluation.horizon_metrics.items()
            }
            details["limitations"] = list(kernel.evaluation.limitations)
        return ResearchDispatchResult(False, True, "terminal_report", details)

    @staticmethod
    def _progress(outcome: str, **details: Any) -> ResearchDispatchResult:
        return ResearchDispatchResult(True, False, outcome, details)

    def evidence_bundle(self) -> Mapping[str, Any]:
        """Raw domain evidence kept outside the compact kernel certificate."""

        return {
            "component": "%s@%s" % (self.name, self.component_version),
            "selected_schema": (
                None
                if self.selected_schema is None
                else {
                    "schema_id": self.selected_schema.schema_id,
                    "source": self.selected_schema.source.as_dict(),
                    "source_c": self.selected_schema.source.to_c(),
                    "replacement": self.selected_schema.replacement.as_dict(),
                    "replacement_c": self.selected_schema.replacement.to_c(),
                    "development_instruction_gain": (
                        self.selected_schema.instruction_gain
                    ),
                    "proof_ref": self.selected_schema.proof_ref,
                }
            ),
            "atlas": [
                {
                    "case": row.case.as_dict(),
                    "replacement": row.replacement.as_dict(),
                    "source_instructions": list(
                        compile_expression(row.case.expression)
                    ),
                    "replacement_instructions": list(
                        compile_expression(row.replacement)
                    ),
                    "instruction_gain": row.gain,
                    "evidence_id": row.evidence_id,
                    "contrast_id": row.contrast_id,
                }
                for row in self.atlas_rows
            ],
            "prospective_validation": [
                {
                    "case_id": row["case_id"],
                    "matched": row["matched"],
                    "source": row["source"].as_dict(),
                    "replacement": row["replacement"].as_dict(),
                    "instruction_gain": row["gain"],
                    "equivalent": row["proof"].equivalent,
                    "proof_ref": row["proof"].proof_ref,
                }
                for row in self.prospective_rows
            ],
            "sealed_evaluation": [
                {
                    "case": row["case"].as_dict(),
                    "candidate_observation": row["candidate"].as_dict(),
                    "incumbent_observation": row["incumbent"].as_dict(),
                    "verification": row["verification"].as_dict(),
                    "instruction_gain": row["gain"],
                    "evidence_id": row["evidence_id"],
                }
                for row in self.sealed_rows
            ],
        }
