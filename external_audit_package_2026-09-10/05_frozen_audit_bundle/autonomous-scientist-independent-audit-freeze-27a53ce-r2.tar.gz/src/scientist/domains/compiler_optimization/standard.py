from __future__ import annotations

from scientist.domains.compiler_optimization.adapter import CompilerOptimizationAdapter
from scientist.kernel.capabilities import ComparisonMode
from scientist.kernel.contracts import (
    AnalysisKind,
    BudgetContract,
    CampaignContract,
    ChannelRelation,
    DiscoveryChannelSpec,
    EvidenceAnalysisContract,
    EvidencePartition,
    GateContract,
    GateCriterion,
    GateKind,
    MetricDirection,
    MetricSpec,
    ProblemCharter,
)


def problem_charter() -> ProblemCharter:
    return ProblemCharter(
        name="Verified source-level compiler rewrite discovery",
        statement=(
            "Discover a general 32-bit unsigned bit-vector rewrite schema that "
            "is valid for every input and reduces Apple Clang -O3 arm64 code cost "
            "on sealed schema instantiations."
        ),
        domain_id=CompilerOptimizationAdapter.domain_id,
        scope=(
            "pure uint32_t expressions over two inputs",
            "typed arithmetic, bitwise, and constant-shift grammar",
            "Apple Clang 21 -O3 arm64 instruction count",
            "Z3 proof over all 32-bit inputs",
        ),
        anti_scope=(
            "claims of mathematical novelty before a candidate-specific search",
            "undefined or poison-producing C semantics",
            "wall-clock or cross-platform performance claims",
            "training on sealed transfer expressions",
        ),
        metrics=(
            MetricSpec(
                name="instruction_reduction",
                direction=MetricDirection.MAXIMIZE,
                unit="static arm64 instructions",
                aggregation="sum over independent expression instantiations",
                primary=True,
            ),
            MetricSpec(
                name="proof_rate",
                direction=MetricDirection.MAXIMIZE,
                unit="fraction",
                aggregation="mean Z3 equivalence outcome",
            ),
        ),
        success_definition=(
            "A frozen schema is proven for all 32-bit inputs, improves both root "
            "and nested sealed contexts, has no measured regression, and repeats "
            "on disjoint replication expressions."
        ),
        falsification_conditions=(
            "Z3 finds a counterexample",
            "the rewrite does not fire on sealed expressions",
            "instruction reduction is non-positive in either required context",
            "a sealed expression regresses",
        ),
    )


def campaign_contract(incumbent_candidate_id: str | None) -> CampaignContract:
    if not incumbent_candidate_id:
        raise ValueError("compiler optimization requires the frozen Clang incumbent")
    adapter = CompilerOptimizationAdapter()
    return CampaignContract(
        charter_id=problem_charter().charter_id,
        domain_adapter_ref=adapter.adapter_version,
        incumbent_candidate_id=incumbent_candidate_id,
        search_families=(),
        budget=BudgetContract(
            outer_rounds=1,
            failure_mining_evaluations_per_round=96,
            audit_cases_per_proposal=4,
            replication_cases=6,
            maximum_compute_units=2_000.0,
            proposals_by_channel={"typed_schema_synthesis": 96},
        ),
        evaluator_ref=adapter.evaluator_ref,
        verifier_ref=adapter.verifier_ref,
        development_partitions=(
            EvidencePartition.DEVELOPMENT,
            EvidencePartition.GUARD,
        ),
        gates=(
            GateContract(
                kind=GateKind.INCUMBENT_ADVANCE,
                evidence_partition=EvidencePartition.REPLICATION,
                criteria=(
                    GateCriterion(
                        metric="instruction_reduction",
                        operator=">",
                        threshold=0.0,
                        description="sealed total instruction reduction is positive",
                    ),
                    GateCriterion(
                        metric="proof_rate",
                        operator="==",
                        threshold=1.0,
                        description="every sealed rewrite is equivalent for all inputs",
                    ),
                ),
                minimum_evidence_count=6,
            ),
        ),
        comparison_mode=ComparisonMode.PAIRED_INCUMBENT,
        discovery_channels=(
            DiscoveryChannelSpec(
                "typed_schema_synthesis",
                ChannelRelation.INDEPENDENT,
                "typed operator grammar, causal failure atlas, and proof authority",
                True,
            ),
        ),
        evidence_analysis=EvidenceAnalysisContract(
            analysis_kind=AnalysisKind.DETERMINISTIC_PROOF,
            primary_metric="instruction_reduction",
            independent_unit="expression schema instantiation",
            group_keys=("regime", "horizon"),
            analyzer_ref="verified-compiler-paired-analysis-v1",
            minimum_independent_units=6,
        ),
    )
