from __future__ import annotations

from dataclasses import dataclass
import hashlib
import itertools
import json
import random
import re
from typing import Any, Callable, Iterable, Mapping, Sequence

from scientist.core.artifacts import content_digest


ASSAY_VERSION = "controlled-conceptual-jump-assay-preflight-v1"
_NAME = re.compile(r"^[a-z][a-z0-9_]{0,47}$")


@dataclass(frozen=True)
class Instance:
    instance_id: str
    split: str
    payload: Mapping[str, Any]
    target: bool

    def public(self) -> Mapping[str, Any]:
        return {
            "instance_id": self.instance_id,
            "split": self.split,
            "payload": self.payload,
        }


@dataclass(frozen=True)
class Family:
    family_id: str
    public_alias: str
    required_jump: bool
    input_type: str
    base_observers: tuple[str, ...]
    instances: tuple[Instance, ...]
    target_fn: Callable[[Mapping[str, Any]], bool]
    reference_declaration: Mapping[str, Any] | None = None
    base_program: Mapping[str, Any] | None = None


def _digest_id(prefix: str, value: Any) -> str:
    return "%s-%s" % (prefix, content_digest(value)[:12])


def _sequence_payload(bits: Sequence[bool], names: Sequence[str], nuisance: int) -> Mapping[str, Any]:
    return {
        "channel": list(names),
        "signals": [bool(value) for value in bits],
        "nuisance_phase": int(nuisance),
    }


def _graph_payload(
    nodes: Sequence[str], edges: Iterable[tuple[int, int]], src: int, dst: int, nuisance: int
) -> Mapping[str, Any]:
    return {
        "objects": list(nodes),
        "links": [[nodes[left], nodes[right]] for left, right in sorted(set(edges))],
        "probe": {"origin": nodes[src], "destination": nodes[dst]},
        "nuisance_phase": int(nuisance),
    }


def _seq_bits(payload: Mapping[str, Any]) -> tuple[bool, ...]:
    return tuple(bool(value) for value in payload["signals"])


def _graph_parts(payload: Mapping[str, Any]) -> tuple[tuple[str, ...], set[tuple[str, str]], str, str]:
    nodes = tuple(str(value) for value in payload["objects"])
    edges = {(str(left), str(right)) for left, right in payload["links"]}
    probe = payload["probe"]
    return nodes, edges, str(probe["origin"]), str(probe["destination"])


def base_signature(family: Family, payload: Mapping[str, Any]) -> tuple[Any, ...]:
    if family.input_type == "bool_sequence":
        bits = _seq_bits(payload)
        values = {
            "length": len(bits),
            "first": bits[0],
            "last": bits[-1],
            "any": any(bits),
            "all": all(bits),
        }
    elif family.input_type == "directed_graph":
        nodes, edges, src, dst = _graph_parts(payload)
        out_degree = sum(1 for left, _ in edges if left == src)
        in_degree = sum(1 for _, right in edges if right == dst)
        two_hop = any((src, middle) in edges and (middle, dst) in edges for middle in nodes)
        values = {
            "node_count": len(nodes),
            "edge_count": len(edges),
            "source_out_degree": out_degree,
            "target_in_degree": in_degree,
            "direct_edge": (src, dst) in edges,
            "two_hop": two_hop,
        }
    elif family.input_type == "undirected_graph":
        nodes, directed_edges, src, dst = _graph_parts(payload)
        edges = directed_edges | {(right, left) for left, right in directed_edges}
        values = {
            "node_count": len(nodes),
            "edge_count": len(directed_edges),
            "source_degree": sum(1 for left, _ in edges if left == src),
            "target_degree": sum(1 for left, _ in edges if left == dst),
            "direct_edge": (src, dst) in edges,
        }
    else:
        raise ValueError("unknown family input type")
    return tuple(values[name] for name in family.base_observers)


def _target_parity(payload: Mapping[str, Any]) -> bool:
    return sum(_seq_bits(payload)) % 2 == 1


def _target_run_three(payload: Mapping[str, Any]) -> bool:
    bits = _seq_bits(payload)
    return any(bits[index] == bits[index + 1] == bits[index + 2] for index in range(len(bits) - 2))


def _reachable(payload: Mapping[str, Any], undirected: bool = False) -> set[str]:
    nodes, edges, src, _ = _graph_parts(payload)
    if undirected:
        edges = edges | {(right, left) for left, right in edges}
    reached = {src}
    while True:
        updated = reached | {right for left, right in edges if left in reached}
        if updated == reached:
            return reached
        reached = updated


def _target_reachability(payload: Mapping[str, Any]) -> bool:
    _, _, _, dst = _graph_parts(payload)
    return dst in _reachable(payload)


def _target_component_even(payload: Mapping[str, Any]) -> bool:
    return len(_reachable(payload, undirected=True)) % 2 == 0


def _target_any(payload: Mapping[str, Any]) -> bool:
    return any(_seq_bits(payload))


def _target_endpoints_equal(payload: Mapping[str, Any]) -> bool:
    bits = _seq_bits(payload)
    return bits[0] == bits[-1]


def _target_direct_edge(payload: Mapping[str, Any]) -> bool:
    _, edges, src, dst = _graph_parts(payload)
    return (src, dst) in edges


def _target_source_degree_two(payload: Mapping[str, Any]) -> bool:
    _, edges, src, _ = _graph_parts(payload)
    undirected = edges | {(right, left) for left, right in edges}
    return sum(1 for left, _ in undirected if left == src) >= 2


def _sequence_instances(seed: int) -> tuple[Instance, ...]:
    rng = random.Random(seed)
    instances: list[Instance] = []
    for split, lengths in (("discovery", (4, 5, 6)), ("sealed_transfer", (8, 9))):
        for length in lengths:
            names = ["v%s" % content_digest([seed, split, length, index])[:5] for index in range(length)]
            for ordinal, bits in enumerate(itertools.product((False, True), repeat=length)):
                payload = _sequence_payload(bits, names, rng.randrange(10_000))
                instances.append(
                    Instance(
                        instance_id=_digest_id("w", [seed, split, length, ordinal, payload]),
                        split=split,
                        payload=payload,
                        target=False,
                    )
                )
    return tuple(instances)


def _directed_graph_instances(seed: int) -> tuple[Instance, ...]:
    rng = random.Random(seed)
    instances: list[Instance] = []
    for split, count, node_count in (("discovery", 768, 4), ("sealed_transfer", 1024, 6)):
        nodes = ["q%s" % content_digest([seed, split, node_count, index])[:5] for index in range(node_count)]
        possible = [(left, right) for left in range(node_count) for right in range(node_count) if left != right]
        edge_sets: list[set[tuple[int, int]]] = []
        if node_count == 4:
            for mask in range(1 << len(possible)):
                if len(edge_sets) >= count:
                    break
                edge_sets.append({edge for bit, edge in enumerate(possible) if mask & (1 << bit)})
        while len(edge_sets) < count:
            probability = rng.choice((0.15, 0.25, 0.4, 0.6))
            edge_sets.append({edge for edge in possible if rng.random() < probability})
        for ordinal, edges in enumerate(edge_sets):
            payload = _graph_payload(nodes, edges, 0, node_count - 1, rng.randrange(10_000))
            instances.append(
                Instance(
                    instance_id=_digest_id("w", [seed, split, ordinal, payload]),
                    split=split,
                    payload=payload,
                    target=False,
                )
            )
    return tuple(instances)


def _undirected_graph_instances(seed: int) -> tuple[Instance, ...]:
    rng = random.Random(seed)
    instances: list[Instance] = []
    for split, count, node_count in (("discovery", 512, 5), ("sealed_transfer", 1024, 7)):
        nodes = ["r%s" % content_digest([seed, split, node_count, index])[:5] for index in range(node_count)]
        possible = [(left, right) for left in range(node_count) for right in range(left + 1, node_count)]
        edge_sets: list[set[tuple[int, int]]] = []
        if node_count == 5:
            for mask in range(1 << len(possible)):
                if len(edge_sets) >= count:
                    break
                edge_sets.append({edge for bit, edge in enumerate(possible) if mask & (1 << bit)})
        while len(edge_sets) < count:
            probability = rng.choice((0.12, 0.22, 0.35, 0.5))
            edge_sets.append({edge for edge in possible if rng.random() < probability})
        for ordinal, edges in enumerate(edge_sets):
            payload = _graph_payload(nodes, edges, 0, node_count - 1, rng.randrange(10_000))
            instances.append(
                Instance(
                    instance_id=_digest_id("w", [seed, split, ordinal, payload]),
                    split=split,
                    payload=payload,
                    target=False,
                )
            )
    return tuple(instances)


def _with_targets(instances: Sequence[Instance], target: Callable[[Mapping[str, Any]], bool]) -> tuple[Instance, ...]:
    return tuple(
        Instance(item.instance_id, item.split, item.payload, bool(target(item.payload)))
        for item in instances
    )


def build_assay(seed: int = 73_991) -> tuple[Family, ...]:
    seq = _sequence_instances(seed)
    directed = _directed_graph_instances(seed + 1)
    undirected = _undirected_graph_instances(seed + 2)
    parity_decl = {
        "name": "latent_operator_a",
        "kind": "sequence_fold_bool",
        "signature": "Seq[Bool]->Bool",
        "semantics": {
            "identity": False,
            "table": {"00": False, "01": True, "10": True, "11": False},
        },
    }
    reach_decl = {
        "name": "latent_operator_b",
        "kind": "graph_fixed_point",
        "signature": "DirectedGraph*Node*Node->Bool",
        "semantics": {
            "edge_mode": "directed",
            "seed": "origin",
            "update": "forward_image_union",
            "accept": "contains_destination",
        },
    }
    component_decl = {
        "name": "latent_operator_c",
        "kind": "component_fold",
        "signature": "UndirectedGraph*Node->Bool",
        "semantics": {
            "edge_mode": "undirected",
            "seed": "origin",
            "update": "neighbors_union",
            "aggregate": "cardinality",
            "predicate": "even",
        },
    }
    run_decl = {
        "name": "latent_operator_d",
        "kind": "sequence_automaton",
        "signature": "Seq[Bool]->Bool",
        "semantics": {
            "states": ["s", "z1", "z2", "o1", "o2", "hit"],
            "start": "s",
            "accepting": ["hit"],
            "transition": {
                "s:0": "z1", "s:1": "o1", "z1:0": "z2", "z1:1": "o1",
                "z2:0": "hit", "z2:1": "o1", "o1:0": "z1", "o1:1": "o2",
                "o2:0": "z1", "o2:1": "hit", "hit:0": "hit", "hit:1": "hit",
            },
        },
    }
    families = (
        Family("required_sequence_parity", "family-%s" % content_digest([seed, 1])[:8], True, "bool_sequence", ("length", "first", "last", "any", "all"), _with_targets(seq, _target_parity), _target_parity, parity_decl),
        Family("required_graph_reachability", "family-%s" % content_digest([seed, 2])[:8], True, "directed_graph", ("node_count", "edge_count", "source_out_degree", "target_in_degree", "direct_edge", "two_hop"), _with_targets(directed, _target_reachability), _target_reachability, reach_decl),
        Family("required_component_parity", "family-%s" % content_digest([seed, 3])[:8], True, "undirected_graph", ("node_count", "edge_count", "source_degree", "target_degree", "direct_edge"), _with_targets(undirected, _target_component_even), _target_component_even, component_decl),
        Family("required_sequence_run", "family-%s" % content_digest([seed, 4])[:8], True, "bool_sequence", ("length", "first", "last", "any", "all"), _with_targets(seq, _target_run_three), _target_run_three, run_decl),
        Family("control_sequence_any", "family-%s" % content_digest([seed, 5])[:8], False, "bool_sequence", ("length", "first", "last", "any", "all"), _with_targets(seq, _target_any), _target_any, base_program={"op": "field", "name": "any"}),
        Family("control_graph_direct", "family-%s" % content_digest([seed, 6])[:8], False, "directed_graph", ("node_count", "edge_count", "source_out_degree", "target_in_degree", "direct_edge", "two_hop"), _with_targets(directed, _target_direct_edge), _target_direct_edge, base_program={"op": "field", "name": "direct_edge"}),
        Family("control_component_degree", "family-%s" % content_digest([seed, 7])[:8], False, "undirected_graph", ("node_count", "edge_count", "source_degree", "target_degree", "direct_edge"), _with_targets(undirected, _target_source_degree_two), _target_source_degree_two, base_program={"op": "ge", "field": "source_degree", "value": 2}),
        Family("control_sequence_endpoints", "family-%s" % content_digest([seed, 8])[:8], False, "bool_sequence", ("length", "first", "last", "any", "all"), _with_targets(seq, _target_endpoints_equal), _target_endpoints_equal, base_program={"op": "eq_fields", "left": "first", "right": "last"}),
    )
    return families


def compile_primitive(declaration: Mapping[str, Any]) -> Callable[[Mapping[str, Any]], bool]:
    allowed_top = {"name", "kind", "signature", "semantics"}
    if set(declaration) != allowed_top:
        raise ValueError("primitive declaration has unknown or missing fields")
    name = str(declaration["name"])
    if not _NAME.fullmatch(name) or any(word in name for word in ("task", "instance", "lookup", "python")):
        raise ValueError("invalid or answer-bearing primitive name")
    encoded = json.dumps(declaration, sort_keys=True)
    for forbidden in ("__", "import", "eval", "exec", "task_id", "instance_id", "lookup_table"):
        if forbidden in encoded:
            raise ValueError("forbidden host-language or instance-specific escape")
    if len(encoded) > 4_096:
        raise ValueError("primitive declaration exceeds size ceiling")
    kind = declaration["kind"]
    semantics = declaration["semantics"]
    if not isinstance(semantics, Mapping):
        raise ValueError("primitive semantics must be a mapping")

    if kind == "sequence_fold_bool":
        if declaration["signature"] != "Seq[Bool]->Bool" or set(semantics) != {"identity", "table"}:
            raise ValueError("invalid boolean-fold declaration")
        table = semantics["table"]
        if set(table) != {"00", "01", "10", "11"} or not all(isinstance(value, bool) for value in table.values()):
            raise ValueError("boolean fold requires a total boolean combine table")
        identity = semantics["identity"]
        if not isinstance(identity, bool):
            raise ValueError("boolean fold identity must be boolean")

        def evaluate(payload: Mapping[str, Any]) -> bool:
            state = identity
            for bit in _seq_bits(payload):
                state = bool(table[("1" if state else "0") + ("1" if bit else "0")])
            return state

        return evaluate

    if kind == "graph_fixed_point":
        expected = {
            "edge_mode": "directed", "seed": "origin",
            "update": "forward_image_union", "accept": "contains_destination",
        }
        if declaration["signature"] != "DirectedGraph*Node*Node->Bool" or dict(semantics) != expected:
            raise ValueError("unsupported graph fixed-point semantics")
        return _target_reachability

    if kind == "component_fold":
        expected = {
            "edge_mode": "undirected", "seed": "origin", "update": "neighbors_union",
            "aggregate": "cardinality", "predicate": "even",
        }
        if declaration["signature"] != "UndirectedGraph*Node->Bool" or dict(semantics) != expected:
            raise ValueError("unsupported component-fold semantics")
        return _target_component_even

    if kind == "sequence_automaton":
        if declaration["signature"] != "Seq[Bool]->Bool":
            raise ValueError("invalid automaton signature")
        if set(semantics) != {"states", "start", "accepting", "transition"}:
            raise ValueError("invalid automaton semantics")
        states = tuple(str(value) for value in semantics["states"])
        if not states or len(states) > 12 or len(set(states)) != len(states) or not all(_NAME.fullmatch(value) for value in states):
            raise ValueError("invalid automaton states")
        start = str(semantics["start"])
        accepting = {str(value) for value in semantics["accepting"]}
        transition = semantics["transition"]
        expected_keys = {"%s:%d" % (state, bit) for state in states for bit in (0, 1)}
        if start not in states or not accepting.issubset(states) or set(transition) != expected_keys:
            raise ValueError("automaton must provide a total transition table")
        if not all(str(value) in states for value in transition.values()):
            raise ValueError("automaton transition leaves its state set")

        def evaluate(payload: Mapping[str, Any]) -> bool:
            state = start
            for bit in _seq_bits(payload):
                state = str(transition["%s:%d" % (state, int(bit))])
            return state in accepting

        return evaluate

    raise ValueError("unsupported primitive kind")


def _base_values(family: Family, payload: Mapping[str, Any]) -> Mapping[str, Any]:
    signature = base_signature(family, payload)
    return dict(zip(family.base_observers, signature))


def evaluate_base_program(family: Family, payload: Mapping[str, Any]) -> bool:
    program = family.base_program
    if not program:
        raise ValueError("family has no base program")
    values = _base_values(family, payload)
    if program["op"] == "field":
        return bool(values[program["name"]])
    if program["op"] == "ge":
        return values[program["field"]] >= program["value"]
    if program["op"] == "eq_fields":
        return values[program["left"]] == values[program["right"]]
    raise ValueError("unsupported base program")


def separating_witness(family: Family, split: str) -> Mapping[str, Any] | None:
    by_signature: dict[tuple[Any, ...], dict[bool, Instance]] = {}
    for instance in family.instances:
        if instance.split != split:
            continue
        signature = base_signature(family, instance.payload)
        by_signature.setdefault(signature, {}).setdefault(instance.target, instance)
    for signature, outcomes in by_signature.items():
        if set(outcomes) == {False, True}:
            return {
                "base_signature": list(signature),
                "negative": outcomes[False].public(),
                "positive": outcomes[True].public(),
                "proof": (
                    "Both inputs are identical under every frozen base observer but have "
                    "different targets; therefore no program whose only inputs are those "
                    "observers can solve both, independent of program size."
                ),
            }
    return None


def _score(fn: Callable[[Mapping[str, Any]], bool], family: Family, split: str) -> Mapping[str, Any]:
    selected = [item for item in family.instances if item.split == split]
    correct = sum(bool(fn(item.payload)) == item.target for item in selected)
    return {"correct": correct, "count": len(selected), "accuracy": correct / len(selected)}


def _mutated_declaration(family_id: str, declaration: Mapping[str, Any]) -> Mapping[str, Any]:
    value = json.loads(json.dumps(declaration))
    value["name"] = "mutant_operator"
    if family_id == "required_sequence_parity":
        value["semantics"]["table"] = {"00": False, "01": True, "10": True, "11": True}
    elif family_id == "required_graph_reachability":
        value["semantics"]["accept"] = "direct_edge_only"
    elif family_id == "required_component_parity":
        value["semantics"]["predicate"] = "odd"
    elif family_id == "required_sequence_run":
        value["semantics"]["accepting"] = ["z2", "o2", "hit"]
    return value


def _mutation_failure(family: Family) -> Mapping[str, Any]:
    mutated = _mutated_declaration(family.family_id, family.reference_declaration or {})
    try:
        fn = compile_primitive(mutated)
    except ValueError as error:
        return {"mutant_rejected": True, "reason": str(error), "fails_source_or_transfer": True}
    source = _score(fn, family, "discovery")
    transfer = _score(fn, family, "sealed_transfer")
    return {
        "mutant_rejected": False,
        "source_accuracy": source["accuracy"],
        "transfer_accuracy": transfer["accuracy"],
        "fails_source_or_transfer": source["accuracy"] < 1.0 or transfer["accuracy"] < 1.0,
    }


def _bypass_tests() -> list[Mapping[str, Any]]:
    attempts = (
        {"name": "python_escape", "kind": "python", "signature": "X->Bool", "semantics": {"exec": "return True"}},
        {"name": "task_id_router", "kind": "sequence_fold_bool", "signature": "Seq[Bool]->Bool", "semantics": {"identity": False, "table": {"00": False, "01": True, "10": True, "11": False}, "task_id": "x"}},
        {"name": "lookup_operator", "kind": "sequence_fold_bool", "signature": "Seq[Bool]->Bool", "semantics": {"identity": False, "table": {"00": False, "01": True, "10": True, "11": False}, "lookup_table": {"w": True}}},
        {"name": "oversized_operator", "kind": "sequence_fold_bool", "signature": "Seq[Bool]->Bool", "semantics": {"identity": False, "table": {"00": False, "01": True, "10": True, "11": False}, "padding": "x" * 5_000}},
    )
    results = []
    for attempt in attempts:
        try:
            compile_primitive(attempt)
        except ValueError as error:
            results.append({"attempt": attempt["name"], "rejected": True, "reason": str(error)})
        else:
            results.append({"attempt": attempt["name"], "rejected": False})
    return results


def _public_family_contract(family: Family) -> Mapping[str, Any]:
    public = {
        "public_alias": family.public_alias,
        "input_type": family.input_type,
        "base_observers": list(family.base_observers),
        "discovery_instance_count": sum(item.split == "discovery" for item in family.instances),
        "sealed_instance_count": sum(item.split == "sealed_transfer" for item in family.instances),
    }
    return public


def run_preflight(seed: int = 73_991) -> Mapping[str, Any]:
    families = build_assay(seed)
    family_results = []
    for family in families:
        result: dict[str, Any] = {
            "family_id": family.family_id,
            "public_alias": family.public_alias,
            "required_jump": family.required_jump,
            "public_contract_hash": content_digest(_public_family_contract(family)),
            "target_vector_hash": hashlib.sha256(
                bytes(int(item.target) for item in family.instances)
            ).hexdigest(),
            "instance_manifest_hash": content_digest(
                [item.public() for item in family.instances]
            ),
        }
        if family.required_jump:
            discovery_witness = separating_witness(family, "discovery")
            transfer_witness = separating_witness(family, "sealed_transfer")
            reference_fn = compile_primitive(family.reference_declaration or {})
            result.update({
                "discovery_inadequacy_witness": discovery_witness,
                "transfer_inadequacy_witness": transfer_witness,
                "reference_declaration_hash": content_digest(family.reference_declaration),
                "reference_discovery_score": _score(reference_fn, family, "discovery"),
                "reference_transfer_score": _score(reference_fn, family, "sealed_transfer"),
                "mutation_test": _mutation_failure(family),
                "passed": bool(discovery_witness and transfer_witness)
                and _score(reference_fn, family, "discovery")["accuracy"] == 1.0
                and _score(reference_fn, family, "sealed_transfer")["accuracy"] == 1.0
                and _mutation_failure(family)["fails_source_or_transfer"],
            })
        else:
            discovery = _score(lambda payload: evaluate_base_program(family, payload), family, "discovery")
            transfer = _score(lambda payload: evaluate_base_program(family, payload), family, "sealed_transfer")
            result.update({
                "base_program": family.base_program,
                "base_discovery_score": discovery,
                "base_transfer_score": transfer,
                "passed": discovery["accuracy"] == 1.0 and transfer["accuracy"] == 1.0,
            })
        family_results.append(result)

    bypass = _bypass_tests()
    required_results = [item for item in family_results if item["required_jump"]]
    controls = [item for item in family_results if not item["required_jump"]]
    public_contract = {
        "version": ASSAY_VERSION,
        "seed": seed,
        "base_language": {
            "description": (
                "An arbitrary total function of the frozen base-observer vector. Raw "
                "structured inputs may be inspected during discovery, but terminal base "
                "programs cannot iterate over them or introduce new observers."
            ),
            "observer_contracts": sorted({
                "%s:%s" % (family.input_type, ",".join(family.base_observers))
                for family in families
            }),
        },
        "expansion_language": {
            "one_primitive_only": True,
            "typed_kinds": [
                "sequence_fold_bool", "graph_fixed_point", "component_fold", "sequence_automaton"
            ],
            "host_language_escape": False,
            "maximum_serialized_bytes": 4_096,
        },
        "families": [_public_family_contract(family) for family in families],
        "split_policy": (
            "Discovery and sealed-transfer instances differ in cardinality, symbols, "
            "topology where applicable, and nuisance phase."
        ),
    }
    public_forbidden = json.dumps(public_contract, sort_keys=True).casefold()
    leakage_terms = (
        "required_sequence_parity", "required_graph_reachability",
        "required_component_parity", "required_sequence_run", "reference_declaration",
    )
    leakage_passed = not any(term in public_forbidden for term in leakage_terms)
    passed = (
        len(required_results) >= 4
        and len(controls) >= 4
        and all(item["passed"] for item in family_results)
        and all(item["rejected"] for item in bypass)
        and leakage_passed
    )
    report = {
        "version": ASSAY_VERSION,
        "seed": seed,
        "public_contract": public_contract,
        "public_contract_id": content_digest(public_contract),
        "family_results": family_results,
        "bypass_tests": bypass,
        "leakage_test": {
            "forbidden_terms": list(leakage_terms),
            "passed": leakage_passed,
        },
        "aggregate": {
            "required_family_count": len(required_results),
            "required_family_pass_count": sum(item["passed"] for item in required_results),
            "no_jump_family_count": len(controls),
            "no_jump_family_pass_count": sum(item["passed"] for item in controls),
            "bypass_rejection_count": sum(item["rejected"] for item in bypass),
            "bypass_attempt_count": len(bypass),
            "episode_model_calls": 0,
            "preflight_passed": passed,
            "disposition": "eligible_for_small_model_pilot" if passed else "assay_killed_before_model_calls",
        },
        "interpretation": (
            "A pass establishes only that the assay contains a machine-checkable language "
            "boundary, necessary-expansion fixtures, no-jump controls, executable reference "
            "primitives, and sealed replay. It is not evidence that a model can invent them."
        ),
    }
    report["audit_id"] = content_digest(report)
    return report
