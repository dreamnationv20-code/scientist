from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import re
from typing import Any, Callable, Mapping, Sequence

from scientist.core.artifacts import content_digest
from scientist.domains.conceptual_jump.assay import build_assay as build_v1_assay


ASSAY_V2_VERSION = "controlled-conceptual-jump-unified-assay-preflight-v2"
_NAME = re.compile(r"^[a-z][a-z0-9_]{0,47}$")
BASE_OBSERVERS = (
    "entity_count", "relation_count", "anchor_equal", "anchor_link_forward",
    "anchor_link_reverse", "mark_any", "mark_all", "anchor0_mark", "anchor1_mark",
    "anchor0_out_degree", "anchor1_in_degree", "two_step_forward",
)


@dataclass(frozen=True)
class UnifiedInstance:
    instance_id: str
    split: str
    payload: Mapping[str, Any]
    target: bool


@dataclass(frozen=True)
class UnifiedFamily:
    family_id: str
    public_alias: str
    required_jump: bool
    instances: tuple[UnifiedInstance, ...]
    target_fn: Callable[[Mapping[str, Any]], bool]
    reference_program: Mapping[str, Any] | None = None
    base_program: Mapping[str, Any] | None = None


def _entities(payload: Mapping[str, Any]) -> tuple[str, ...]:
    return tuple(str(value) for value in payload["entities"])


def _relation(payload: Mapping[str, Any]) -> set[tuple[str, str]]:
    return {(str(left), str(right)) for left, right in payload["relation"]}


def _marks(payload: Mapping[str, Any]) -> set[str]:
    return {str(value) for value in payload["marked"]}


def _anchor(payload: Mapping[str, Any], index: int) -> str:
    return str(payload["anchors"][index])


def unified_base_values(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    entities = _entities(payload)
    relation = _relation(payload)
    marks = _marks(payload)
    left, right = _anchor(payload, 0), _anchor(payload, 1)
    return {
        "entity_count": len(entities),
        "relation_count": len(relation),
        "anchor_equal": left == right,
        "anchor_link_forward": (left, right) in relation,
        "anchor_link_reverse": (right, left) in relation,
        "mark_any": bool(marks),
        "mark_all": set(entities) == marks,
        "anchor0_mark": left in marks,
        "anchor1_mark": right in marks,
        "anchor0_out_degree": sum(1 for source, _ in relation if source == left),
        "anchor1_in_degree": sum(1 for _, target in relation if target == right),
        "two_step_forward": any((left, middle) in relation and (middle, right) in relation for middle in entities),
    }


def unified_base_signature(payload: Mapping[str, Any]) -> tuple[Any, ...]:
    values = unified_base_values(payload)
    return tuple(values[name] for name in BASE_OBSERVERS)


def _convert_sequence(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    entities = [str(value) for value in payload["channel"]]
    return {
        "entities": entities,
        "relation": [[entities[index], entities[index + 1]] for index in range(len(entities) - 1)],
        "marked": [entity for entity, bit in zip(entities, payload["signals"]) if bit],
        "anchors": [entities[0], entities[-1]],
        "nuisance": int(payload["nuisance_phase"]),
    }


def _convert_graph(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    entities = [str(value) for value in payload["objects"]]
    marked = [
        entity for entity in entities
        if int(hashlib.sha256(entity.encode()).hexdigest()[:2], 16) % 3 == 0
    ]
    return {
        "entities": entities,
        "relation": [list(edge) for edge in payload["links"]],
        "marked": marked,
        "anchors": [payload["probe"]["origin"], payload["probe"]["destination"]],
        "nuisance": int(payload["nuisance_phase"]),
    }


def _traverse(payload: Mapping[str, Any], reverse: bool = False, undirected: bool = False) -> set[str]:
    relation = _relation(payload)
    if reverse:
        relation = {(right, left) for left, right in relation}
    if undirected:
        relation = relation | {(right, left) for left, right in relation}
    reached = {_anchor(payload, 0)}
    while True:
        updated = reached | {right for left, right in relation if left in reached}
        if updated == reached:
            return reached
        reached = updated


def atomic_parity(payload: Mapping[str, Any]) -> bool:
    return len(_marks(payload)) % 2 == 1


def atomic_run_three(payload: Mapping[str, Any]) -> bool:
    relation = _relation(payload)
    marks = _marks(payload)
    current = _anchor(payload, 0)
    run = 0
    previous: bool | None = None
    for _ in _entities(payload):
        bit = current in marks
        run = run + 1 if previous is not None and previous == bit else 1
        if run >= 3:
            return True
        previous = bit
        next_values = sorted(right for left, right in relation if left == current)
        if not next_values:
            break
        current = next_values[0]
    return False


def atomic_forward_reach(payload: Mapping[str, Any]) -> bool:
    return _anchor(payload, 1) in _traverse(payload)


def atomic_reverse_reach(payload: Mapping[str, Any]) -> bool:
    return _anchor(payload, 1) in _traverse(payload, reverse=True)


def atomic_component_even(payload: Mapping[str, Any]) -> bool:
    return len(_traverse(payload, undirected=True)) % 2 == 0


def target_sequence_a(payload: Mapping[str, Any]) -> bool:
    return atomic_parity(payload) != atomic_run_three(payload)


def target_sequence_b(payload: Mapping[str, Any]) -> bool:
    base = unified_base_values(payload)
    return atomic_run_three(payload) and bool(base["anchor0_mark"] == base["anchor1_mark"])


def target_graph_a(payload: Mapping[str, Any]) -> bool:
    return atomic_forward_reach(payload) != atomic_component_even(payload)


def target_graph_b(payload: Mapping[str, Any]) -> bool:
    return atomic_reverse_reach(payload) and not atomic_component_even(payload)


def control_any(payload: Mapping[str, Any]) -> bool:
    return bool(unified_base_values(payload)["mark_any"])


def control_direct(payload: Mapping[str, Any]) -> bool:
    return bool(unified_base_values(payload)["anchor_link_forward"])


def control_degree(payload: Mapping[str, Any]) -> bool:
    return int(unified_base_values(payload)["anchor0_out_degree"]) >= 2


def control_anchor_marks(payload: Mapping[str, Any]) -> bool:
    values = unified_base_values(payload)
    return bool(values["anchor0_mark"] == values["anchor1_mark"])


def _expr(op: str, **kwargs: Any) -> Mapping[str, Any]:
    return {"op": op, **kwargs}


def _scan_state() -> list[Mapping[str, Any]]:
    return [
        {"name": "cursor", "type": "entity", "init": _expr("anchor", index=0)},
        {"name": "previous", "type": "bool", "init": _expr("const_bool", value=False)},
        {"name": "started", "type": "bool", "init": _expr("const_bool", value=False)},
        {"name": "run", "type": "int", "init": _expr("const_int", value=0)},
        {"name": "hit", "type": "bool", "init": _expr("const_bool", value=False)},
    ]


def _scan_update() -> Mapping[str, Any]:
    current_mark = _expr("marked", entity=_expr("state", name="cursor"))
    same = _expr("eq", left=current_mark, right=_expr("state", name="previous"))
    new_run = _expr(
        "if", condition=_expr("and", left=_expr("state", name="started"), right=same),
        then=_expr("add", left=_expr("state", name="run"), right=_expr("const_int", value=1)),
        otherwise=_expr("const_int", value=1),
    )
    return {
        "cursor": _expr("next_entity", entity=_expr("state", name="cursor"), direction="forward"),
        "previous": current_mark,
        "started": _expr("const_bool", value=True),
        "run": new_run,
        "hit": _expr(
            "or", left=_expr("state", name="hit"),
            right=_expr("ge", left=new_run, right=_expr("const_int", value=3)),
        ),
    }


def _parity_expr() -> Mapping[str, Any]:
    return _expr(
        "eq",
        left=_expr("mod", left=_expr("cardinality", value=_expr("marked_set")), right=_expr("const_int", value=2)),
        right=_expr("const_int", value=1),
    )


def _component_even_expr(state_name: str) -> Mapping[str, Any]:
    return _expr(
        "eq",
        left=_expr("mod", left=_expr("cardinality", value=_expr("state", name=state_name)), right=_expr("const_int", value=2)),
        right=_expr("const_int", value=0),
    )


def reference_programs() -> Mapping[str, Mapping[str, Any]]:
    sequence_a = {
        "name": "candidate_program", "signature": "Instance->Bool",
        "state": _scan_state(), "steps": "entity_count", "update": _scan_update(),
        "output": _expr("not", value=_expr("eq", left=_parity_expr(), right=_expr("state", name="hit"))),
    }
    sequence_b = {
        "name": "candidate_program", "signature": "Instance->Bool",
        "state": _scan_state(), "steps": "entity_count", "update": _scan_update(),
        "output": _expr(
            "and", left=_expr("state", name="hit"),
            right=_expr(
                "eq",
                left=_expr("marked", entity=_expr("anchor", index=0)),
                right=_expr("marked", entity=_expr("anchor", index=1)),
            ),
        ),
    }
    forward_init = _expr("singleton", value=_expr("anchor", index=0))
    graph_a = {
        "name": "candidate_program", "signature": "Instance->Bool",
        "state": [
            {"name": "forward", "type": "set", "init": forward_init},
            {"name": "component", "type": "set", "init": forward_init},
        ],
        "steps": "entity_count",
        "update": {
            "forward": _expr("union", left=_expr("state", name="forward"), right=_expr("image", value=_expr("state", name="forward"), direction="forward")),
            "component": _expr(
                "union", left=_expr("state", name="component"),
                right=_expr(
                    "union",
                    left=_expr("image", value=_expr("state", name="component"), direction="forward"),
                    right=_expr("image", value=_expr("state", name="component"), direction="reverse"),
                ),
            ),
        },
        "output": _expr(
            "not", value=_expr(
                "eq",
                left=_expr("contains", container=_expr("state", name="forward"), value=_expr("anchor", index=1)),
                right=_component_even_expr("component"),
            ),
        ),
    }
    graph_b = {
        "name": "candidate_program", "signature": "Instance->Bool",
        "state": [
            {"name": "reverse", "type": "set", "init": forward_init},
            {"name": "component", "type": "set", "init": forward_init},
        ],
        "steps": "entity_count",
        "update": {
            "reverse": _expr("union", left=_expr("state", name="reverse"), right=_expr("image", value=_expr("state", name="reverse"), direction="reverse")),
            "component": _expr(
                "union", left=_expr("state", name="component"),
                right=_expr(
                    "union",
                    left=_expr("image", value=_expr("state", name="component"), direction="forward"),
                    right=_expr("image", value=_expr("state", name="component"), direction="reverse"),
                ),
            ),
        },
        "output": _expr(
            "and",
            left=_expr("contains", container=_expr("state", name="reverse"), value=_expr("anchor", index=1)),
            right=_expr("not", value=_component_even_expr("component")),
        ),
    }
    return {
        "sequence_a": sequence_a,
        "sequence_b": sequence_b,
        "graph_a": graph_a,
        "graph_b": graph_b,
    }


ALLOWED_OPS = {
    "const_bool", "const_int", "anchor", "state", "marked", "marked_set",
    "singleton", "next_entity", "image", "union", "contains", "cardinality",
    "mod", "eq", "ge", "not", "and", "or", "if", "add",
}


def compile_program(program: Mapping[str, Any]) -> Callable[[Mapping[str, Any]], bool]:
    if set(program) != {"name", "signature", "state", "steps", "update", "output"}:
        raise ValueError("program has unknown or missing fields")
    if program["name"] != "candidate_program" or program["signature"] != "Instance->Bool":
        raise ValueError("program must use the neutral public name and signature")
    encoded = json.dumps(program, sort_keys=True)
    if len(encoded) > 12_000:
        raise ValueError("program exceeds the frozen AST ceiling")
    for forbidden in ("__", "import", "eval", "exec", "task", "family", "instance_id", "lookup", "python"):
        if forbidden in encoded.casefold():
            raise ValueError("program contains a forbidden answer-bearing or host-language token")
    if program["steps"] != "entity_count":
        raise ValueError("program must use the common structural step budget")
    state_decls = program["state"]
    if not isinstance(state_decls, list) or len(state_decls) > 8:
        raise ValueError("program state is malformed or oversized")
    names = [str(item.get("name")) for item in state_decls]
    if len(set(names)) != len(names) or not all(_NAME.fullmatch(name) for name in names):
        raise ValueError("state register names are invalid")
    if set(program["update"]) != set(names):
        raise ValueError("every state register requires one synchronous update")

    def validate_expr(expression: Any, depth: int = 0) -> None:
        if depth > 24 or not isinstance(expression, Mapping):
            raise ValueError("expression is malformed or too deep")
        op = expression.get("op")
        if op not in ALLOWED_OPS:
            raise ValueError("unsupported neutral-language operation")
        if op == "state" and expression.get("name") not in names:
            raise ValueError("expression references an undeclared register")
        for key, value in expression.items():
            if key == "op" or isinstance(value, (str, int, bool)) or value is None:
                continue
            if isinstance(value, Mapping):
                validate_expr(value, depth + 1)
            else:
                raise ValueError("expression contains a non-AST payload")

    for declaration in state_decls:
        if set(declaration) != {"name", "type", "init"} or declaration["type"] not in {"bool", "int", "entity", "set"}:
            raise ValueError("state declaration is malformed")
        validate_expr(declaration["init"])
    for expression in program["update"].values():
        validate_expr(expression)
    validate_expr(program["output"])

    def evaluate_expression(expression: Mapping[str, Any], payload: Mapping[str, Any], state: Mapping[str, Any]) -> Any:
        op = expression["op"]
        child = lambda key: evaluate_expression(expression[key], payload, state)
        if op in {"const_bool", "const_int"}:
            return expression["value"]
        if op == "anchor":
            return _anchor(payload, int(expression["index"]))
        if op == "state":
            return state[expression["name"]]
        if op == "marked":
            return child("entity") in _marks(payload)
        if op == "marked_set":
            return frozenset(_marks(payload))
        if op == "singleton":
            value = child("value")
            return frozenset(() if value is None else (value,))
        if op == "next_entity":
            value = child("entity")
            relation = _relation(payload)
            values = sorted(
                right if expression["direction"] == "forward" else left
                for left, right in relation
                if (left if expression["direction"] == "forward" else right) == value
            )
            return values[0] if values else None
        if op == "image":
            values = set(child("value"))
            relation = _relation(payload)
            if expression["direction"] == "forward":
                return frozenset(right for left, right in relation if left in values)
            if expression["direction"] == "reverse":
                return frozenset(left for left, right in relation if right in values)
            raise ValueError("invalid relation direction")
        if op == "union":
            return frozenset(set(child("left")) | set(child("right")))
        if op == "contains":
            return child("value") in child("container")
        if op == "cardinality":
            return len(child("value"))
        if op == "mod":
            right = int(child("right"))
            if right <= 0 or right > 16:
                raise ValueError("modulus is outside the frozen bound")
            return int(child("left")) % right
        if op == "eq":
            return child("left") == child("right")
        if op == "ge":
            return child("left") >= child("right")
        if op == "not":
            return not bool(child("value"))
        if op == "and":
            return bool(child("left")) and bool(child("right"))
        if op == "or":
            return bool(child("left")) or bool(child("right"))
        if op == "if":
            return child("then") if bool(child("condition")) else child("otherwise")
        if op == "add":
            return int(child("left")) + int(child("right"))
        raise ValueError("unsupported operation")

    def evaluate(payload: Mapping[str, Any]) -> bool:
        state: dict[str, Any] = {}
        for declaration in state_decls:
            state[declaration["name"]] = evaluate_expression(declaration["init"], payload, state)
        for _ in _entities(payload):
            state = {
                name: evaluate_expression(program["update"][name], payload, state)
                for name in names
            }
        result = evaluate_expression(program["output"], payload, state)
        if not isinstance(result, bool):
            raise ValueError("program output is not boolean")
        return result

    return evaluate


def _convert_instances(source: Sequence[Any], converter: Callable[[Mapping[str, Any]], Mapping[str, Any]], target: Callable[[Mapping[str, Any]], bool]) -> tuple[UnifiedInstance, ...]:
    converted = []
    for item in source:
        payload = converter(item.payload)
        converted.append(
            UnifiedInstance(
                instance_id="u-%s" % content_digest([item.instance_id, payload])[:14],
                split=item.split,
                payload=payload,
                target=bool(target(payload)),
            )
        )
    return tuple(converted)


def build_unified_assay(seed: int = 73_991) -> tuple[UnifiedFamily, ...]:
    old = {family.family_id: family for family in build_v1_assay(seed)}
    sequence_source = old["required_sequence_parity"].instances
    graph_source = old["required_graph_reachability"].instances
    sequence_a = _convert_instances(sequence_source, _convert_sequence, target_sequence_a)
    sequence_b = _convert_instances(sequence_source, _convert_sequence, target_sequence_b)
    graph_a = _convert_instances(graph_source, _convert_graph, target_graph_a)
    graph_b = _convert_instances(graph_source, _convert_graph, target_graph_b)
    programs = reference_programs()
    alias = lambda index: "family-%s" % content_digest([seed, "unified", index])[:10]
    return (
        UnifiedFamily("authority_required_1", alias(1), True, sequence_a, target_sequence_a, programs["sequence_a"]),
        UnifiedFamily("authority_required_2", alias(2), True, sequence_b, target_sequence_b, programs["sequence_b"]),
        UnifiedFamily("authority_required_3", alias(3), True, graph_a, target_graph_a, programs["graph_a"]),
        UnifiedFamily("authority_required_4", alias(4), True, graph_b, target_graph_b, programs["graph_b"]),
        UnifiedFamily("authority_control_1", alias(5), False, _convert_instances(sequence_source, _convert_sequence, control_any), control_any, base_program={"op": "field", "name": "mark_any"}),
        UnifiedFamily("authority_control_2", alias(6), False, _convert_instances(graph_source, _convert_graph, control_direct), control_direct, base_program={"op": "field", "name": "anchor_link_forward"}),
        UnifiedFamily("authority_control_3", alias(7), False, _convert_instances(graph_source, _convert_graph, control_degree), control_degree, base_program={"op": "ge", "name": "anchor0_out_degree", "value": 2}),
        UnifiedFamily("authority_control_4", alias(8), False, _convert_instances(sequence_source, _convert_sequence, control_anchor_marks), control_anchor_marks, base_program={"op": "eq", "left": "anchor0_mark", "right": "anchor1_mark"}),
    )


def evaluate_base(family: UnifiedFamily, payload: Mapping[str, Any]) -> bool:
    values = unified_base_values(payload)
    program = family.base_program or {}
    if program.get("op") == "field":
        return bool(values[program["name"]])
    if program.get("op") == "ge":
        return int(values[program["name"]]) >= int(program["value"])
    if program.get("op") == "eq":
        return values[program["left"]] == values[program["right"]]
    raise ValueError("invalid base program")


def _score(fn: Callable[[Mapping[str, Any]], bool], family: UnifiedFamily, split: str) -> Mapping[str, Any]:
    rows = [item for item in family.instances if item.split == split]
    correct = sum(bool(fn(item.payload)) == item.target for item in rows)
    return {"correct": correct, "count": len(rows), "accuracy": correct / len(rows)}


def witness(family: UnifiedFamily, split: str) -> Mapping[str, Any] | None:
    groups: dict[tuple[Any, ...], dict[bool, UnifiedInstance]] = {}
    for item in family.instances:
        if item.split != split:
            continue
        groups.setdefault(unified_base_signature(item.payload), {}).setdefault(item.target, item)
    for signature, outcomes in groups.items():
        if set(outcomes) == {False, True}:
            return {
                "base_signature": list(signature),
                "negative_instance_hash": content_digest(outcomes[False].payload),
                "positive_instance_hash": content_digest(outcomes[True].payload),
                "proof": "identical complete base-observer vector with different targets",
            }
    return None


ATOMIC_TEMPLATES: Mapping[str, Callable[[Mapping[str, Any]], bool]] = {
    "atomic_mark_any": control_any,
    "atomic_anchor_marks_equal": control_anchor_marks,
    "atomic_direct_relation": control_direct,
    "atomic_degree_threshold": control_degree,
    "atomic_mark_parity": atomic_parity,
    "atomic_three_run": atomic_run_three,
    "atomic_forward_traversal": atomic_forward_reach,
    "atomic_reverse_traversal": atomic_reverse_reach,
    "atomic_component_parity": atomic_component_even,
}


def _template_baseline(family: UnifiedFamily) -> Mapping[str, Any]:
    candidates = []
    for name, function in ATOMIC_TEMPLATES.items():
        discovery = _score(function, family, "discovery")
        transfer = _score(function, family, "sealed_transfer")
        candidates.append({"template": name, "discovery": discovery, "transfer": transfer})
    selected = sorted(candidates, key=lambda item: (-item["discovery"]["accuracy"], item["template"]))[0]
    return {"selected_by_discovery": selected, "all_candidates": candidates}


def _mutant(program: Mapping[str, Any]) -> Mapping[str, Any]:
    value = json.loads(json.dumps(program))
    value["output"] = _expr("not", value=value["output"])
    return value


def _public_contract(families: Sequence[UnifiedFamily], seed: int) -> Mapping[str, Any]:
    family_contracts = [
        {
            "public_alias": family.public_alias,
            "input_signature": "FiniteRelationalInstance->Bool",
            "base_observers": list(BASE_OBSERVERS),
            "interaction_budget": 8,
        }
        for family in families
    ]
    return {
        "version": ASSAY_V2_VERSION,
        "seed_commitment": hashlib.sha256(str(seed).encode()).hexdigest(),
        "input_signature": "FiniteRelationalInstance->Bool",
        "base_observers": list(BASE_OBSERVERS),
        "expansion_program": {
            "name": "candidate_program",
            "signature": "Instance->Bool",
            "one_program": True,
            "state_register_limit": 8,
            "ast_byte_limit": 12_000,
            "step_budget": "entity_count",
            "operations": sorted(ALLOWED_OPS),
            "host_access": False,
        },
        "families": family_contracts,
        "claim_boundary": "invention relative to the frozen base-observer representation",
    }


def _bypass_tests() -> list[Mapping[str, Any]]:
    valid = reference_programs()["sequence_a"]
    attempts = []
    for name, mutate in (
        ("host_escape", lambda value: value.update({"output": {"op": "exec", "value": "x"}})),
        ("answer_token", lambda value: value.update({"name": "task_router"})),
        ("oversized", lambda value: value["state"].append({"name": "x", "type": "bool", "init": {"op": "const_bool", "value": "x" * 13_000}})),
        ("undeclared_state", lambda value: value.update({"output": {"op": "state", "name": "ghost"}})),
    ):
        candidate = json.loads(json.dumps(valid))
        mutate(candidate)
        try:
            compile_program(candidate)
        except (ValueError, TypeError) as error:
            attempts.append({"attempt": name, "rejected": True, "reason": str(error)})
        else:
            attempts.append({"attempt": name, "rejected": False})
    return attempts


def run_unified_preflight(seed: int = 73_991) -> Mapping[str, Any]:
    families = build_unified_assay(seed)
    results = []
    for family in families:
        result: dict[str, Any] = {
            "authority_family_id": family.family_id,
            "public_alias": family.public_alias,
            "required_jump": family.required_jump,
            "instance_hash": content_digest([
                {"id": item.instance_id, "split": item.split, "payload": item.payload}
                for item in family.instances
            ]),
            "target_hash": hashlib.sha256(bytes(int(item.target) for item in family.instances)).hexdigest(),
        }
        if family.required_jump:
            function = compile_program(family.reference_program or {})
            source = _score(function, family, "discovery")
            transfer = _score(function, family, "sealed_transfer")
            discovery_witness = witness(family, "discovery")
            transfer_witness = witness(family, "sealed_transfer")
            template = _template_baseline(family)
            mutant_function = compile_program(_mutant(family.reference_program or {}))
            mutant_source = _score(mutant_function, family, "discovery")
            mutant_transfer = _score(mutant_function, family, "sealed_transfer")
            template_fails = (
                template["selected_by_discovery"]["discovery"]["accuracy"] < 0.95
                or template["selected_by_discovery"]["transfer"]["accuracy"] < 0.95
            )
            mutant_fails = mutant_source["accuracy"] < 0.95 or mutant_transfer["accuracy"] < 0.95
            result.update({
                "discovery_witness": discovery_witness,
                "transfer_witness": transfer_witness,
                "reference_program_hash": content_digest(family.reference_program),
                "reference_discovery": source,
                "reference_transfer": transfer,
                "atomic_template_baseline": template,
                "atomic_template_below_threshold": template_fails,
                "mutant": {
                    "discovery": mutant_source,
                    "transfer": mutant_transfer,
                    "status": "score_failure" if mutant_fails else "incorrectly_passed",
                },
                "passed": bool(discovery_witness and transfer_witness)
                and source["accuracy"] == 1.0 and transfer["accuracy"] == 1.0
                and template_fails and mutant_fails,
            })
        else:
            source = _score(lambda payload: evaluate_base(family, payload), family, "discovery")
            transfer = _score(lambda payload: evaluate_base(family, payload), family, "sealed_transfer")
            result.update({
                "base_program": family.base_program,
                "base_discovery": source,
                "base_transfer": transfer,
                "passed": source["accuracy"] == 1.0 and transfer["accuracy"] == 1.0,
            })
        results.append(result)

    public = _public_contract(families, seed)
    normalized_contracts = [
        {key: value for key, value in item.items() if key != "public_alias"}
        for item in public["families"]
    ]
    contracts_identical = all(item == normalized_contracts[0] for item in normalized_contracts)
    public_text = json.dumps(public, sort_keys=True).casefold()
    answer_terms = (
        "parity", "reach", "component", "run_three", "run-three", "automaton",
        "fixed_point", "fixed-point", "fold", "authority_required", "sequence", "graph",
    )
    no_answer_terms = not any(term in public_text for term in answer_terms)
    bypass = _bypass_tests()
    required = [item for item in results if item["required_jump"]]
    controls = [item for item in results if not item["required_jump"]]
    passed = (
        len(required) == 4 and len(controls) == 4
        and all(item["passed"] for item in results)
        and all(item["rejected"] for item in bypass)
        and contracts_identical and no_answer_terms
    )
    report = {
        "version": ASSAY_V2_VERSION,
        "seed": seed,
        "public_contract": public,
        "public_contract_id": content_digest(public),
        "family_results": results,
        "routing_audit": {
            "family_contracts_identical_after_alias_blinding": contracts_identical,
            "answer_bearing_terms_absent": no_answer_terms,
            "forbidden_answer_terms": list(answer_terms),
            "atomic_template_threshold": 0.95,
            "all_required_families_defeat_selected_atomic_template": all(
                item["atomic_template_below_threshold"] for item in required
            ),
        },
        "bypass_tests": bypass,
        "aggregate": {
            "required_families": len(required),
            "required_passed": sum(item["passed"] for item in required),
            "controls": len(controls),
            "controls_passed": sum(item["passed"] for item in controls),
            "bypass_attempts": len(bypass),
            "bypass_rejected": sum(item["rejected"] for item in bypass),
            "episode_model_calls": 0,
            "preflight_passed": passed,
            "disposition": "eligible_for_second_construct_audit" if passed else "repaired_assay_killed",
        },
        "claim_boundary": (
            "Even after a pass, this assay measures executable observer invention only "
            "relative to the frozen base-observer representation."
        ),
    }
    report["audit_id"] = content_digest(report)
    return report
