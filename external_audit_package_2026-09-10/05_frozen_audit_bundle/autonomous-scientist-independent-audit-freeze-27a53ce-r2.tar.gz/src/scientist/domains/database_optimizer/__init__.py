"""Typed, prospective test oracles for DBMS optimizer research."""

from scientist.domains.database_optimizer.derivative import (
    DerivativePrediction,
    TupleIntervention,
    predict_derivative,
)
from scientist.domains.database_optimizer.equivariance import (
    AffineAction,
    EquivariancePrediction,
    FinitePermutation,
    predict_equivariance,
)
from scientist.domains.database_optimizer.models import (
    Aggregate,
    Binary,
    Column,
    ColumnSpec,
    Database,
    Exists,
    Join,
    Literal,
    Query,
    QueryResult,
    SQLType,
    SelectItem,
    Table,
    TableRef,
    Unary,
)

__all__ = [
    "Aggregate",
    "AffineAction",
    "Binary",
    "Column",
    "ColumnSpec",
    "Database",
    "DerivativePrediction",
    "EquivariancePrediction",
    "Exists",
    "FinitePermutation",
    "Join",
    "Literal",
    "Query",
    "QueryResult",
    "SQLType",
    "SelectItem",
    "Table",
    "TableRef",
    "TupleIntervention",
    "Unary",
    "predict_derivative",
    "predict_equivariance",
]
