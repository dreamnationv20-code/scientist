from __future__ import annotations

from collections import OrderedDict
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

from scientist.domains.database_optimizer.models import (
    Aggregate,
    Binary,
    Column,
    Database,
    Exists,
    Expression,
    Literal,
    Query,
    QueryResult,
    Scalar,
    Unary,
    contains_aggregate,
)


RowContext = Dict[Tuple[str, str], Scalar]


def _sql_not(value: Scalar) -> Optional[bool]:
    if value is None:
        return None
    if not isinstance(value, bool):
        raise TypeError("NOT requires a boolean")
    return not value


def _sql_and(left: Scalar, right: Scalar) -> Optional[bool]:
    if left is False or right is False:
        return False
    if left is None or right is None:
        return None
    if not isinstance(left, bool) or not isinstance(right, bool):
        raise TypeError("AND requires booleans")
    return True


def _sql_or(left: Scalar, right: Scalar) -> Optional[bool]:
    if left is True or right is True:
        return True
    if left is None or right is None:
        return None
    if not isinstance(left, bool) or not isinstance(right, bool):
        raise TypeError("OR requires booleans")
    return False


def _compare(op: str, left: Scalar, right: Scalar) -> Optional[bool]:
    if left is None or right is None:
        return None
    if op == "eq":
        return left == right and type(left) is type(right)
    if op == "ne":
        return not (left == right and type(left) is type(right))
    if type(left) is not type(right):
        raise TypeError("ordered comparison requires matching SQL types")
    if op == "lt":
        return left < right
    if op == "le":
        return left <= right
    if op == "gt":
        return left > right
    if op == "ge":
        return left >= right
    raise ValueError("not a comparison: %s" % op)


def _arithmetic(op: str, left: Scalar, right: Scalar) -> Scalar:
    if left is None or right is None:
        return None
    if (
        not isinstance(left, int)
        or isinstance(left, bool)
        or not isinstance(right, int)
        or isinstance(right, bool)
    ):
        raise TypeError("arithmetic requires integers")
    if op == "add":
        return left + right
    if op == "sub":
        return left - right
    if op == "mul":
        return left * right
    raise ValueError("not arithmetic: %s" % op)


def _aggregate(
    expression: Aggregate,
    group: Sequence[RowContext],
    database: Database,
) -> Scalar:
    if expression.expression is None:
        values: Sequence[Scalar] = tuple(True for _ in group)
    else:
        values = tuple(
            _eval(expression.expression, row, database, None)
            for row in group
        )
    if expression.function == "count":
        return sum(value is not None for value in values)
    nonnull = tuple(value for value in values if value is not None)
    if not nonnull:
        return None
    if expression.function == "sum":
        if any(not isinstance(value, int) or isinstance(value, bool) for value in nonnull):
            raise TypeError("SUM requires integers")
        return sum(nonnull)  # type: ignore[arg-type]
    if expression.function == "min":
        return min(nonnull)
    if expression.function == "max":
        return max(nonnull)
    raise ValueError("unsupported aggregate")


def _eval(
    expression: Expression,
    row: RowContext,
    database: Database,
    group: Optional[Sequence[RowContext]],
) -> Scalar:
    if isinstance(expression, Column):
        try:
            return row[(expression.alias, expression.name)]
        except KeyError as error:
            raise KeyError(
                "unknown column %s.%s" % (expression.alias, expression.name)
            ) from error
    if isinstance(expression, Literal):
        return expression.value
    if isinstance(expression, Unary):
        value = _eval(expression.operand, row, database, group)
        if expression.op == "not":
            return _sql_not(value)
        if expression.op == "neg":
            if value is None:
                return None
            if not isinstance(value, int) or isinstance(value, bool):
                raise TypeError("negation requires integer")
            return -value
        if expression.op == "is_null":
            return value is None
        if expression.op == "is_not_null":
            return value is not None
    if isinstance(expression, Binary):
        left = _eval(expression.left, row, database, group)
        right = _eval(expression.right, row, database, group)
        if expression.op in {"eq", "ne", "lt", "le", "gt", "ge"}:
            return _compare(expression.op, left, right)
        if expression.op in {"add", "sub", "mul"}:
            return _arithmetic(expression.op, left, right)
        if expression.op == "and":
            return _sql_and(left, right)
        if expression.op == "or":
            return _sql_or(left, right)
    if isinstance(expression, Aggregate):
        if group is None:
            raise ValueError("aggregate evaluated outside a group")
        return _aggregate(expression, group, database)
    if isinstance(expression, Exists):
        result = evaluate_query(database, expression.query, outer_context=row)
        return bool(result.rows)
    raise TypeError("unsupported expression: %r" % (expression,))


def _table_rows(
    database: Database,
    table_name: str,
    alias: str,
    outer_context: Optional[Mapping[Tuple[str, str], Scalar]],
) -> List[RowContext]:
    table = database.tables[table_name]
    result = []
    for values in table.rows:
        row = dict(outer_context or {})
        row.update(
            {
                (alias, column.name): value
                for column, value in zip(table.columns, values)
            }
        )
        result.append(row)
    return result


def evaluate_query(
    database: Database,
    query: Query,
    *,
    outer_context: Optional[Mapping[Tuple[str, str], Scalar]] = None,
) -> QueryResult:
    rows = _table_rows(
        database,
        query.source.table_name,
        query.source.alias,
        outer_context,
    )
    for join in query.joins:
        right_rows = _table_rows(
            database,
            join.right.table_name,
            join.right.alias,
            outer_context,
        )
        joined: List[RowContext] = []
        right_table = database.tables[join.right.table_name]
        null_right = {
            (join.right.alias, column.name): None
            for column in right_table.columns
        }
        for left in rows:
            matches = []
            for right in right_rows:
                combined = dict(left)
                combined.update(
                    {
                        key: value
                        for key, value in right.items()
                        if key[0] == join.right.alias
                    }
                )
                if _eval(join.on, combined, database, None) is True:
                    matches.append(combined)
            if matches:
                joined.extend(matches)
            elif join.kind == "left":
                combined = dict(left)
                combined.update(null_right)
                joined.append(combined)
        rows = joined

    if query.where is not None:
        rows = [
            row
            for row in rows
            if _eval(query.where, row, database, None) is True
        ]

    aggregate_query = bool(query.group_by) or any(
        contains_aggregate(item.expression) for item in query.select
    )
    projected: List[Tuple[Scalar, ...]] = []
    if aggregate_query:
        groups: "OrderedDict[Tuple[Scalar, ...], List[RowContext]]" = OrderedDict()
        if query.group_by:
            for row in rows:
                key = tuple(
                    _eval(expression, row, database, None)
                    for expression in query.group_by
                )
                groups.setdefault(key, []).append(row)
        else:
            groups[()] = list(rows)
        for group in groups.values():
            representative = group[0] if group else dict(outer_context or {})
            projected.append(
                tuple(
                    _eval(item.expression, representative, database, group)
                    for item in query.select
                )
            )
    else:
        projected = [
            tuple(
                _eval(item.expression, row, database, None)
                for item in query.select
            )
            for row in rows
        ]

    if query.distinct:
        projected = list(OrderedDict((row, None) for row in projected))
    return QueryResult(
        columns=tuple(item.alias for item in query.select),
        rows=tuple(projected),
    )
