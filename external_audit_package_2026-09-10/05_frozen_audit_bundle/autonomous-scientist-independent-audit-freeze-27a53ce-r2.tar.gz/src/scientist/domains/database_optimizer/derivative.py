from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.domains.database_optimizer import bag_semantics, exhaustive_semantics
from scientist.domains.database_optimizer.models import (
    CanonicalRow,
    Database,
    Query,
    QueryResult,
    Scalar,
    Table,
)


@dataclass(frozen=True)
class TupleIntervention:
    table_name: str
    kind: str
    row: Tuple[Scalar, ...]

    def __post_init__(self) -> None:
        if not self.table_name:
            raise ValueError("intervention table must not be empty")
        if self.kind not in {"insert", "delete"}:
            raise ValueError("intervention kind must be insert or delete")

    def apply(self, database: Database) -> Database:
        try:
            table = database.tables[self.table_name]
        except KeyError as error:
            raise KeyError("intervention references an unknown table") from error
        # Reconstructing Table is also the schema/type validation authority.
        rows = list(table.rows)
        if self.kind == "insert":
            rows.append(self.row)
        else:
            try:
                rows.remove(self.row)
            except ValueError as error:
                raise ValueError("delete intervention row is not present") from error
        return database.replace_table(
            Table(table.name, table.columns, tuple(rows))
        )


def _serialize_delta(delta: Mapping[CanonicalRow, int]) -> Tuple[Dict[str, Any], ...]:
    return tuple(
        {
            "row": [list(value) for value in row],
            "signed_multiplicity": multiplicity,
        }
        for row, multiplicity in sorted(delta.items())
    )


@dataclass(frozen=True)
class DerivativePrediction:
    initial: QueryResult
    final: QueryResult
    signed_delta: Mapping[CanonicalRow, int]
    primary_checker_ref: str
    independent_checker_ref: str
    independent_agreement: bool

    @property
    def admissible(self) -> bool:
        return self.independent_agreement

    def as_dict(self) -> Dict[str, Any]:
        return {
            "initial": self.initial.as_dict(),
            "final": self.final.as_dict(),
            "signed_delta": list(_serialize_delta(self.signed_delta)),
            "primary_checker_ref": self.primary_checker_ref,
            "independent_checker_ref": self.independent_checker_ref,
            "independent_agreement": self.independent_agreement,
            "admissible": self.admissible,
        }


def predict_derivative(
    database: Database,
    query: Query,
    intervention: TupleIntervention,
) -> DerivativePrediction:
    changed = intervention.apply(database)
    initial = bag_semantics.evaluate_query(database, query)
    final = bag_semantics.evaluate_query(changed, query)
    reference_initial = exhaustive_semantics.evaluate_query(database, query)
    reference_final = exhaustive_semantics.evaluate_query(changed, query)
    agreement = (
        initial.columns == reference_initial.columns
        and final.columns == reference_final.columns
        and initial.multiset == reference_initial.multiset
        and final.multiset == reference_final.multiset
    )
    return DerivativePrediction(
        initial=initial,
        final=final,
        signed_delta=initial.signed_delta(final),
        primary_checker_ref="recursive-bag-semantics-v1",
        independent_checker_ref="positional-exhaustive-semantics-v1",
        independent_agreement=agreement,
    )
