from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple, Union

from scientist.domains.database_optimizer import bag_semantics, exhaustive_semantics
from scientist.domains.database_optimizer.models import (
    Aggregate,
    Binary,
    Column,
    ColumnSpec,
    Database,
    Exists,
    Expression,
    Join,
    Literal,
    Query,
    QueryResult,
    SQLType,
    Scalar,
    SelectItem,
    Table,
    Unary,
)


INT64_MIN = -(2**63)
INT64_MAX = 2**63 - 1


def _native_type(value: Scalar) -> Optional[SQLType]:
    if value is None:
        return None
    if isinstance(value, bool):
        return SQLType.BOOLEAN
    if isinstance(value, int):
        return SQLType.INTEGER
    if isinstance(value, str):
        return SQLType.TEXT
    raise TypeError("unsupported action value")


@dataclass(frozen=True)
class FinitePermutation:
    sql_type: SQLType
    mapping: Mapping[Scalar, Scalar]

    def __post_init__(self) -> None:
        if not self.mapping:
            raise ValueError("finite permutation requires a non-empty mapping")
        if None in self.mapping or None in self.mapping.values():
            raise ValueError("NULL is fixed implicitly and must not be mapped")
        if any(_native_type(value) != self.sql_type for value in self.mapping):
            raise ValueError("permutation keys do not match declared SQL type")
        if any(
            _native_type(value) != self.sql_type
            for value in self.mapping.values()
        ):
            raise ValueError("permutation values do not match declared SQL type")
        if set(self.mapping) != set(self.mapping.values()):
            raise ValueError("finite permutation must be a bijection on one domain")

    def apply(self, value: Scalar) -> Scalar:
        if value is None:
            return None
        if _native_type(value) != self.sql_type:
            return value
        try:
            return self.mapping[value]
        except KeyError as error:
            raise ValueError("finite permutation is undefined for %r" % (value,)) from error

    def inverse(self) -> "FinitePermutation":
        return FinitePermutation(
            self.sql_type,
            {value: key for key, value in self.mapping.items()},
        )

    def compose(self, other: "FinitePermutation") -> "FinitePermutation":
        if self.sql_type != other.sql_type or set(self.mapping) != set(other.mapping):
            raise ValueError("permutations require the same finite domain")
        return FinitePermutation(
            self.sql_type,
            {key: self.apply(other.apply(key)) for key in self.mapping},
        )


@dataclass(frozen=True)
class AffineAction:
    scale: int
    shift: int

    def __post_init__(self) -> None:
        if self.scale <= 0:
            raise ValueError("order-preserving affine action requires positive scale")
        if isinstance(self.scale, bool) or isinstance(self.shift, bool):
            raise ValueError("affine parameters must be integers")

    @property
    def sql_type(self) -> SQLType:
        return SQLType.INTEGER

    def apply(self, value: Scalar) -> Scalar:
        if value is None or _native_type(value) != SQLType.INTEGER:
            return value
        result = self.scale * int(value) + self.shift
        if result < INT64_MIN or result > INT64_MAX:
            raise OverflowError("affine action exceeds signed 64-bit range")
        return result

    def compose(self, other: "AffineAction") -> "AffineAction":
        return AffineAction(
            self.scale * other.scale,
            self.scale * other.shift + self.shift,
        )


ValueAction = Union[FinitePermutation, AffineAction]


def _transform_expression(expression: Expression, action: ValueAction) -> Expression:
    if isinstance(expression, Literal):
        return Literal(action.apply(expression.value))
    if isinstance(expression, Column):
        return expression
    if isinstance(expression, Unary):
        return Unary(expression.op, _transform_expression(expression.operand, action))
    if isinstance(expression, Binary):
        return Binary(
            expression.op,
            _transform_expression(expression.left, action),
            _transform_expression(expression.right, action),
        )
    if isinstance(expression, Aggregate):
        return Aggregate(
            expression.function,
            None
            if expression.expression is None
            else _transform_expression(expression.expression, action),
        )
    if isinstance(expression, Exists):
        return Exists(transform_query(expression.query, action))
    raise TypeError("unknown expression")


def transform_query(query: Query, action: ValueAction) -> Query:
    return Query(
        source=query.source,
        select=tuple(
            SelectItem(_transform_expression(item.expression, action), item.alias)
            for item in query.select
        ),
        joins=tuple(
            Join(join.kind, join.right, _transform_expression(join.on, action))
            for join in query.joins
        ),
        where=(
            None
            if query.where is None
            else _transform_expression(query.where, action)
        ),
        group_by=tuple(
            _transform_expression(expression, action)
            for expression in query.group_by
        ),
        distinct=query.distinct,
    )


def transform_database(database: Database, action: ValueAction) -> Database:
    tables = {}
    for name, table in database.tables.items():
        rows = []
        for row in table.rows:
            rows.append(
                tuple(
                    action.apply(value)
                    if column.sql_type == action.sql_type
                    else value
                    for column, value in zip(table.columns, row)
                )
            )
        tables[name] = Table(table.name, table.columns, tuple(rows))
    return Database(tables)


def _walk(expression: Expression) -> Tuple[Expression, ...]:
    values = [expression]
    if isinstance(expression, Unary):
        values.extend(_walk(expression.operand))
    elif isinstance(expression, Binary):
        values.extend(_walk(expression.left))
        values.extend(_walk(expression.right))
    elif isinstance(expression, Aggregate) and expression.expression is not None:
        values.extend(_walk(expression.expression))
    elif isinstance(expression, Exists):
        values.extend(_query_expressions(expression.query))
    return tuple(values)


def _query_expressions(query: Query) -> Tuple[Expression, ...]:
    roots = [item.expression for item in query.select]
    roots.extend(join.on for join in query.joins)
    roots.extend(query.group_by)
    if query.where is not None:
        roots.append(query.where)
    return tuple(child for root in roots for child in _walk(root))


def admissibility_reasons(
    database: Database,
    query: Query,
    action: ValueAction,
) -> Tuple[str, ...]:
    reasons = []
    expressions = _query_expressions(query)
    if isinstance(action, FinitePermutation):
        observed = {
            value
            for table in database.tables.values()
            for column, row in (
                (column, row)
                for row in table.rows
                for column in table.columns
            )
            for value in (row[table.columns.index(column)],)
            if column.sql_type == action.sql_type and value is not None
        }
        observed.update(
            expression.value
            for expression in expressions
            if isinstance(expression, Literal)
            and _native_type(expression.value) == action.sql_type
        )
        missing = observed.difference(action.mapping)
        if missing:
            reasons.append(
                "finite action is not total on observed domain: %s"
                % sorted(repr(item) for item in missing)
            )
        forbidden = {"lt", "le", "gt", "ge", "add", "sub", "mul"}
        if any(
            isinstance(expression, Binary) and expression.op in forbidden
            for expression in expressions
        ):
            reasons.append("finite permutation is restricted to equality semantics")
        if any(
            isinstance(expression, Aggregate)
            and expression.function in {"sum", "min", "max"}
            for expression in expressions
        ):
            reasons.append("finite permutation cannot preserve ordered/numeric aggregates")
    else:
        if any(
            isinstance(expression, Binary)
            and expression.op in {"add", "sub", "mul"}
            for expression in expressions
        ):
            reasons.append("affine order action excludes arithmetic expressions")
        if any(
            isinstance(expression, Aggregate) and expression.function == "sum"
            for expression in expressions
        ):
            reasons.append("affine order action excludes SUM")
        try:
            transform_database(database, action)
            transform_query(query, action)
        except OverflowError:
            reasons.append("affine action is not overflow-safe")
    return tuple(reasons)


@dataclass(frozen=True)
class EquivariancePrediction:
    original: QueryResult
    transformed: QueryResult
    independent_original: QueryResult
    independent_transformed: QueryResult
    admissibility_reasons: Tuple[str, ...]
    primary_checker_ref: str
    independent_checker_ref: str

    @property
    def independent_agreement(self) -> bool:
        return (
            self.original.multiset == self.independent_original.multiset
            and self.transformed.multiset == self.independent_transformed.multiset
        )

    @property
    def admissible(self) -> bool:
        return not self.admissibility_reasons and self.independent_agreement

    def as_dict(self) -> Dict[str, Any]:
        return {
            "original": self.original.as_dict(),
            "transformed": self.transformed.as_dict(),
            "independent_original": self.independent_original.as_dict(),
            "independent_transformed": self.independent_transformed.as_dict(),
            "admissibility_reasons": list(self.admissibility_reasons),
            "primary_checker_ref": self.primary_checker_ref,
            "independent_checker_ref": self.independent_checker_ref,
            "independent_agreement": self.independent_agreement,
            "admissible": self.admissible,
        }


def predict_equivariance(
    database: Database,
    query: Query,
    action: ValueAction,
) -> EquivariancePrediction:
    reasons = admissibility_reasons(database, query, action)
    transformed_database = transform_database(database, action)
    transformed_query_value = transform_query(query, action)
    return EquivariancePrediction(
        original=bag_semantics.evaluate_query(database, query),
        transformed=bag_semantics.evaluate_query(
            transformed_database,
            transformed_query_value,
        ),
        independent_original=exhaustive_semantics.evaluate_query(database, query),
        independent_transformed=exhaustive_semantics.evaluate_query(
            transformed_database,
            transformed_query_value,
        ),
        admissibility_reasons=reasons,
        primary_checker_ref="recursive-bag-semantics-v1",
        independent_checker_ref="positional-exhaustive-semantics-v1",
    )
