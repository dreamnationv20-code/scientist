from __future__ import annotations

from collections import OrderedDict
from itertools import product
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from scientist.domains.database_optimizer.models import (
    Aggregate,
    Binary,
    Column,
    Database,
    Exists,
    Expression,
    Literal,
    Query,
    QueryResult,
    Scalar,
    Unary,
    contains_aggregate,
)


# This checker deliberately uses alias -> positional row frames and a separate
# expression engine.  It shares only the immutable AST/data contracts with the
# recursive bag interpreter.
Frame = Dict[str, Tuple[Scalar, ...]]
OuterFrame = Mapping[str, Tuple[Tuple[str, ...], Tuple[Scalar, ...]]]


def _truth(value: Scalar) -> Optional[bool]:
    if value is None or isinstance(value, bool):
        return value
    raise TypeError("predicate value is not SQL boolean")


def _lookup(
    expression: Column,
    frame: Frame,
    schemas: Mapping[str, Tuple[str, ...]],
    outer: OuterFrame,
) -> Scalar:
    if expression.alias in frame:
        names = schemas[expression.alias]
        return frame[expression.alias][names.index(expression.name)]
    try:
        names, values = outer[expression.alias]
    except KeyError as error:
        raise KeyError(
            "unknown column %s.%s" % (expression.alias, expression.name)
        ) from error
    return values[names.index(expression.name)]


def _fold_aggregate(
    expression: Aggregate,
    frames: Sequence[Frame],
    database: Database,
    schemas: Mapping[str, Tuple[str, ...]],
    outer: OuterFrame,
) -> Scalar:
    if expression.expression is None:
        values: Tuple[Scalar, ...] = tuple(1 for _ in frames)
    else:
        values = tuple(
            _value(expression.expression, frame, database, schemas, outer, None)
            for frame in frames
        )
    present = tuple(value for value in values if value is not None)
    if expression.function == "count":
        return len(present)
    if not present:
        return None
    if expression.function == "sum":
        total = 0
        for value in present:
            if not isinstance(value, int) or isinstance(value, bool):
                raise TypeError("SUM requires integers")
            total += value
        return total
    ordered = sorted(present)
    if expression.function == "min":
        return ordered[0]
    if expression.function == "max":
        return ordered[-1]
    raise ValueError("unknown aggregate")


def _value(
    expression: Expression,
    frame: Frame,
    database: Database,
    schemas: Mapping[str, Tuple[str, ...]],
    outer: OuterFrame,
    group: Optional[Sequence[Frame]],
) -> Scalar:
    if isinstance(expression, Literal):
        return expression.value
    if isinstance(expression, Column):
        return _lookup(expression, frame, schemas, outer)
    if isinstance(expression, Unary):
        operand = _value(expression.operand, frame, database, schemas, outer, group)
        if expression.op == "is_null":
            return operand is None
        if expression.op == "is_not_null":
            return operand is not None
        if expression.op == "not":
            truth = _truth(operand)
            return None if truth is None else not truth
        if expression.op == "neg":
            if operand is None:
                return None
            if not isinstance(operand, int) or isinstance(operand, bool):
                raise TypeError("negation requires integer")
            return -operand
    if isinstance(expression, Binary):
        left = _value(expression.left, frame, database, schemas, outer, group)
        right = _value(expression.right, frame, database, schemas, outer, group)
        if expression.op == "and":
            left_truth, right_truth = _truth(left), _truth(right)
            if False in (left_truth, right_truth):
                return False
            if None in (left_truth, right_truth):
                return None
            return True
        if expression.op == "or":
            left_truth, right_truth = _truth(left), _truth(right)
            if True in (left_truth, right_truth):
                return True
            if None in (left_truth, right_truth):
                return None
            return False
        if left is None or right is None:
            return None
        if expression.op in {"eq", "ne"}:
            equal = type(left) is type(right) and left == right
            return equal if expression.op == "eq" else not equal
        if expression.op in {"lt", "le", "gt", "ge"}:
            if type(left) is not type(right):
                raise TypeError("ordered comparison requires equal SQL types")
            return {
                "lt": left < right,
                "le": left <= right,
                "gt": left > right,
                "ge": left >= right,
            }[expression.op]
        if not isinstance(left, int) or isinstance(left, bool):
            raise TypeError("arithmetic requires integers")
        if not isinstance(right, int) or isinstance(right, bool):
            raise TypeError("arithmetic requires integers")
        return {
            "add": left + right,
            "sub": left - right,
            "mul": left * right,
        }[expression.op]
    if isinstance(expression, Aggregate):
        if group is None:
            raise ValueError("aggregate used outside grouping")
        return _fold_aggregate(expression, group, database, schemas, outer)
    if isinstance(expression, Exists):
        nested_outer = dict(outer)
        for alias, values in frame.items():
            nested_outer[alias] = (schemas[alias], values)
        return bool(evaluate_query(database, expression.query, outer=nested_outer).rows)
    raise TypeError("unknown expression")


def _source_frames(
    database: Database,
    table_name: str,
    alias: str,
) -> Tuple[Frame, ...]:
    return tuple({alias: tuple(row)} for row in database.tables[table_name].rows)


def _cross_join(left: Iterable[Frame], right: Iterable[Frame]) -> Iterable[Frame]:
    for left_frame, right_frame in product(left, right):
        merged = dict(left_frame)
        merged.update(right_frame)
        yield merged


def evaluate_query(
    database: Database,
    query: Query,
    *,
    outer: Optional[OuterFrame] = None,
) -> QueryResult:
    outside: OuterFrame = outer or {}
    schemas = {
        query.source.alias: tuple(
            column.name for column in database.tables[query.source.table_name].columns
        )
    }
    frames = list(
        _source_frames(database, query.source.table_name, query.source.alias)
    )
    for join in query.joins:
        table = database.tables[join.right.table_name]
        schemas[join.right.alias] = tuple(column.name for column in table.columns)
        right_frames = _source_frames(database, table.name, join.right.alias)
        next_frames: List[Frame] = []
        for left in frames:
            matches = [
                combined
                for combined in _cross_join((left,), right_frames)
                if _value(join.on, combined, database, schemas, outside, None)
                is True
            ]
            if matches:
                next_frames.extend(matches)
            elif join.kind == "left":
                padded = dict(left)
                padded[join.right.alias] = tuple(None for _ in table.columns)
                next_frames.append(padded)
        frames = next_frames

    if query.where is not None:
        frames = [
            frame
            for frame in frames
            if _value(query.where, frame, database, schemas, outside, None)
            is True
        ]

    aggregate_query = bool(query.group_by) or any(
        contains_aggregate(item.expression) for item in query.select
    )
    rows: List[Tuple[Scalar, ...]] = []
    if aggregate_query:
        partitions: "OrderedDict[Tuple[Scalar, ...], List[Frame]]" = OrderedDict()
        if query.group_by:
            for frame in frames:
                key = tuple(
                    _value(expression, frame, database, schemas, outside, None)
                    for expression in query.group_by
                )
                partitions.setdefault(key, []).append(frame)
        else:
            partitions[()] = frames
        for partition in partitions.values():
            representative = partition[0] if partition else {}
            rows.append(
                tuple(
                    _value(
                        item.expression,
                        representative,
                        database,
                        schemas,
                        outside,
                        partition,
                    )
                    for item in query.select
                )
            )
    else:
        for frame in frames:
            rows.append(
                tuple(
                    _value(
                        item.expression,
                        frame,
                        database,
                        schemas,
                        outside,
                        None,
                    )
                    for item in query.select
                )
            )
    if query.distinct:
        rows = list(OrderedDict((row, None) for row in rows))
    return QueryResult(
        columns=tuple(item.alias for item in query.select),
        rows=tuple(rows),
    )
