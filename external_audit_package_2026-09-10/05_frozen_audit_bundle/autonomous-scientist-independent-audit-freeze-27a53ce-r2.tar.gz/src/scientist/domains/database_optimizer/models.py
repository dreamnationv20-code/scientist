from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple, Union


Scalar = Union[None, bool, int, str]
CanonicalScalar = Tuple[str, str]
CanonicalRow = Tuple[CanonicalScalar, ...]


class SQLType(str, Enum):
    INTEGER = "integer"
    BOOLEAN = "boolean"
    TEXT = "text"


@dataclass(frozen=True)
class ColumnSpec:
    name: str
    sql_type: SQLType
    nullable: bool = True

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("column name must not be empty")


def _valid_value(value: Scalar, spec: ColumnSpec) -> bool:
    if value is None:
        return spec.nullable
    if spec.sql_type == SQLType.BOOLEAN:
        return isinstance(value, bool)
    if spec.sql_type == SQLType.INTEGER:
        return isinstance(value, int) and not isinstance(value, bool)
    if spec.sql_type == SQLType.TEXT:
        return isinstance(value, str)
    return False


@dataclass(frozen=True)
class Table:
    name: str
    columns: Tuple[ColumnSpec, ...]
    rows: Tuple[Tuple[Scalar, ...], ...]

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("table name must not be empty")
        if not self.columns:
            raise ValueError("table requires columns")
        names = tuple(column.name for column in self.columns)
        if len(set(names)) != len(names):
            raise ValueError("table column names must be unique")
        for row in self.rows:
            if len(row) != len(self.columns):
                raise ValueError("row width does not match table schema")
            if not all(
                _valid_value(value, spec)
                for value, spec in zip(row, self.columns)
            ):
                raise ValueError("row value does not match declared SQL type")

    def row_mapping(self, row: Sequence[Scalar]) -> Dict[str, Scalar]:
        return {
            column.name: value
            for column, value in zip(self.columns, row)
        }


@dataclass(frozen=True)
class Database:
    tables: Mapping[str, Table]

    def __post_init__(self) -> None:
        if not self.tables:
            raise ValueError("database requires at least one table")
        if any(name != table.name for name, table in self.tables.items()):
            raise ValueError("database table key/name mismatch")

    def replace_table(self, table: Table) -> "Database":
        if table.name not in self.tables:
            raise KeyError("unknown table: %s" % table.name)
        values = dict(self.tables)
        values[table.name] = table
        return Database(values)


@dataclass(frozen=True)
class TableRef:
    table_name: str
    alias: str

    def __post_init__(self) -> None:
        if not self.table_name or not self.alias:
            raise ValueError("table reference is incomplete")


@dataclass(frozen=True)
class Column:
    alias: str
    name: str

    def __post_init__(self) -> None:
        if not self.alias or not self.name:
            raise ValueError("column reference is incomplete")


@dataclass(frozen=True)
class Literal:
    value: Scalar


@dataclass(frozen=True)
class Unary:
    op: str
    operand: "Expression"

    def __post_init__(self) -> None:
        if self.op not in {"not", "neg", "is_null", "is_not_null"}:
            raise ValueError("unsupported unary operator: %s" % self.op)


@dataclass(frozen=True)
class Binary:
    op: str
    left: "Expression"
    right: "Expression"

    def __post_init__(self) -> None:
        if self.op not in {
            "eq",
            "ne",
            "lt",
            "le",
            "gt",
            "ge",
            "add",
            "sub",
            "mul",
            "and",
            "or",
        }:
            raise ValueError("unsupported binary operator: %s" % self.op)


@dataclass(frozen=True)
class Aggregate:
    function: str
    expression: Optional["Expression"] = None

    def __post_init__(self) -> None:
        if self.function not in {"count", "sum", "min", "max"}:
            raise ValueError("unsupported aggregate: %s" % self.function)
        if self.function != "count" and self.expression is None:
            raise ValueError("aggregate %s requires an expression" % self.function)


@dataclass(frozen=True)
class Exists:
    query: "Query"


Expression = Union[Column, Literal, Unary, Binary, Aggregate, Exists]


@dataclass(frozen=True)
class Join:
    kind: str
    right: TableRef
    on: Expression

    def __post_init__(self) -> None:
        if self.kind not in {"inner", "left"}:
            raise ValueError("unsupported join kind: %s" % self.kind)


@dataclass(frozen=True)
class SelectItem:
    expression: Expression
    alias: str

    def __post_init__(self) -> None:
        if not self.alias:
            raise ValueError("select alias must not be empty")


def contains_aggregate(expression: Expression) -> bool:
    if isinstance(expression, Aggregate):
        return True
    if isinstance(expression, Unary):
        return contains_aggregate(expression.operand)
    if isinstance(expression, Binary):
        return contains_aggregate(expression.left) or contains_aggregate(
            expression.right
        )
    return False


@dataclass(frozen=True)
class Query:
    source: TableRef
    select: Tuple[SelectItem, ...]
    joins: Tuple[Join, ...] = ()
    where: Optional[Expression] = None
    group_by: Tuple[Expression, ...] = ()
    distinct: bool = False

    def __post_init__(self) -> None:
        if not self.select:
            raise ValueError("query requires a select list")
        aliases = (self.source.alias,) + tuple(join.right.alias for join in self.joins)
        if len(set(aliases)) != len(aliases):
            raise ValueError("query table aliases must be unique")
        select_aliases = tuple(item.alias for item in self.select)
        if len(set(select_aliases)) != len(select_aliases):
            raise ValueError("select aliases must be unique")
        if any(contains_aggregate(item.expression) for item in self.select):
            for item in self.select:
                if not contains_aggregate(item.expression) and (
                    item.expression not in self.group_by
                ):
                    raise ValueError(
                        "non-aggregate select expression must appear in GROUP BY"
                    )


def canonical_scalar(value: Scalar) -> CanonicalScalar:
    if value is None:
        return ("null", "")
    if isinstance(value, bool):
        return ("boolean", "true" if value else "false")
    if isinstance(value, int):
        return ("integer", str(value))
    if isinstance(value, str):
        return ("text", value)
    raise TypeError("unsupported SQL result value: %r" % (value,))


def canonical_row(row: Sequence[Scalar]) -> CanonicalRow:
    return tuple(canonical_scalar(value) for value in row)


@dataclass(frozen=True)
class QueryResult:
    columns: Tuple[str, ...]
    rows: Tuple[Tuple[Scalar, ...], ...]

    def __post_init__(self) -> None:
        if not self.columns:
            raise ValueError("query result requires columns")
        if any(len(row) != len(self.columns) for row in self.rows):
            raise ValueError("query-result row width mismatch")

    @property
    def multiset(self) -> Counter[CanonicalRow]:
        return Counter(canonical_row(row) for row in self.rows)

    def signed_delta(self, other: "QueryResult") -> Mapping[CanonicalRow, int]:
        """Return other - self as an exact signed bag."""

        if self.columns != other.columns:
            raise ValueError("cannot subtract query results with different columns")
        before = self.multiset
        after = other.multiset
        keys = set(before).union(after)
        return {
            row: after[row] - before[row]
            for row in sorted(keys)
            if after[row] != before[row]
        }

    def as_dict(self) -> Dict[str, Any]:
        return {
            "columns": list(self.columns),
            "rows": [list(row) for row in self.rows],
            "multiset": [
                {
                    "row": [list(value) for value in row],
                    "multiplicity": count,
                }
                for row, count in sorted(self.multiset.items())
            ],
        }
