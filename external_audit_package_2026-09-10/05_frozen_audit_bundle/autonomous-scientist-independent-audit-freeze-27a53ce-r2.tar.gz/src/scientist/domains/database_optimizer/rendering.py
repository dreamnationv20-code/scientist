from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional, Tuple

from scientist.domains.database_optimizer.models import (
    Aggregate,
    Binary,
    Column,
    Database,
    Exists,
    Expression,
    Literal,
    Query,
    SQLType,
    Scalar,
    Table,
    Unary,
)


class SQLDialect(str, Enum):
    POSTGRESQL = "postgresql"
    SQLITE = "sqlite"
    DUCKDB = "duckdb"
    MYSQL = "mysql"


_BINARY_OPERATORS = {
    "eq": "=",
    "ne": "<>",
    "lt": "<",
    "le": "<=",
    "gt": ">",
    "ge": ">=",
    "add": "+",
    "sub": "-",
    "mul": "*",
    "and": "AND",
    "or": "OR",
}


@dataclass(frozen=True)
class SQLRenderer:
    dialect: SQLDialect

    @property
    def identifier_quote(self) -> str:
        return "`" if self.dialect == SQLDialect.MYSQL else '"'

    def identifier(self, value: str) -> str:
        quote = self.identifier_quote
        if not value or "\x00" in value:
            raise ValueError("invalid SQL identifier")
        return quote + value.replace(quote, quote + quote) + quote

    @staticmethod
    def literal(value: Scalar) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, int):
            return str(value)
        if isinstance(value, str):
            return "'" + value.replace("'", "''") + "'"
        raise TypeError("unsupported SQL literal")

    def expression(self, expression: Expression) -> str:
        if isinstance(expression, Column):
            return "%s.%s" % (
                self.identifier(expression.alias),
                self.identifier(expression.name),
            )
        if isinstance(expression, Literal):
            return self.literal(expression.value)
        if isinstance(expression, Unary):
            operand = self.expression(expression.operand)
            if expression.op == "not":
                return "(NOT %s)" % operand
            if expression.op == "neg":
                return "(-%s)" % operand
            if expression.op == "is_null":
                return "(%s IS NULL)" % operand
            if expression.op == "is_not_null":
                return "(%s IS NOT NULL)" % operand
        if isinstance(expression, Binary):
            return "(%s %s %s)" % (
                self.expression(expression.left),
                _BINARY_OPERATORS[expression.op],
                self.expression(expression.right),
            )
        if isinstance(expression, Aggregate):
            argument = (
                "*"
                if expression.expression is None
                else self.expression(expression.expression)
            )
            return "%s(%s)" % (expression.function.upper(), argument)
        if isinstance(expression, Exists):
            return "EXISTS (%s)" % self.query(expression.query)
        raise TypeError("unsupported SQL expression")

    def query(self, query: Query) -> str:
        select = ", ".join(
            "%s AS %s"
            % (self.expression(item.expression), self.identifier(item.alias))
            for item in query.select
        )
        prefix = "SELECT DISTINCT" if query.distinct else "SELECT"
        sql = "%s %s FROM %s AS %s" % (
            prefix,
            select,
            self.identifier(query.source.table_name),
            self.identifier(query.source.alias),
        )
        for join in query.joins:
            keyword = "INNER JOIN" if join.kind == "inner" else "LEFT JOIN"
            sql += " %s %s AS %s ON %s" % (
                keyword,
                self.identifier(join.right.table_name),
                self.identifier(join.right.alias),
                self.expression(join.on),
            )
        if query.where is not None:
            sql += " WHERE %s" % self.expression(query.where)
        if query.group_by:
            sql += " GROUP BY %s" % ", ".join(
                self.expression(expression) for expression in query.group_by
            )
        return sql

    def column_type(self, sql_type: SQLType) -> str:
        if sql_type == SQLType.INTEGER:
            return "BIGINT" if self.dialect != SQLDialect.SQLITE else "INTEGER"
        if sql_type == SQLType.BOOLEAN:
            return "BOOLEAN"
        if self.dialect == SQLDialect.POSTGRESQL:
            return 'TEXT COLLATE "C"'
        if self.dialect == SQLDialect.SQLITE:
            return "TEXT COLLATE BINARY"
        if self.dialect == SQLDialect.MYSQL:
            return "TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin"
        return "VARCHAR"

    def create_table(self, table: Table) -> str:
        definitions = []
        for column in table.columns:
            value = "%s %s" % (
                self.identifier(column.name),
                self.column_type(column.sql_type),
            )
            if not column.nullable:
                value += " NOT NULL"
            definitions.append(value)
        return "CREATE TABLE %s (%s)" % (
            self.identifier(table.name),
            ", ".join(definitions),
        )

    def insert_rows(self, table: Table) -> Tuple[str, ...]:
        if not table.rows:
            return ()
        names = ", ".join(self.identifier(column.name) for column in table.columns)
        return tuple(
            "INSERT INTO %s (%s) VALUES (%s)"
            % (
                self.identifier(table.name),
                names,
                ", ".join(self.literal(value) for value in row),
            )
            for row in table.rows
        )

    def setup_database(self, database: Database) -> Tuple[str, ...]:
        statements = []
        for name in sorted(database.tables):
            table = database.tables[name]
            statements.append("DROP TABLE IF EXISTS %s" % self.identifier(name))
            statements.append(self.create_table(table))
            statements.extend(self.insert_rows(table))
        return tuple(statements)

    def database_script(
        self,
        database: Database,
        query: Optional[Query] = None,
    ) -> str:
        statements = list(self.setup_database(database))
        if query is not None:
            statements.append(self.query(query))
        return ";\n".join(statements) + ";\n"
