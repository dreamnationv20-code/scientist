from __future__ import annotations

from importlib import metadata

from scientist.kernel.domain_registry import DomainRegistry


def default_domain_registry(*, discover_plugins: bool = True) -> DomainRegistry:
    registry = DomainRegistry()
    registry.register(
        "online_1d_bin_packing",
        _binpacking_bundle,
    )
    registry.register(
        "cognitive_core_minilab",
        _cognitive_bundle,
    )
    registry.register(
        "verified_compiler_optimization",
        _compiler_optimization_bundle,
    )
    if discover_plugins:
        discovered = metadata.entry_points()
        if hasattr(discovered, "select"):
            domain_entries = discovered.select(group="scientist.domains")
        else:  # pragma: no cover - Python 3.9 compatibility
            domain_entries = discovered.get("scientist.domains", ())
        for entry in sorted(domain_entries, key=lambda item: item.name):
            if entry.name in registry.domain_ids:
                raise ValueError(
                    "installed domain duplicates built-in %r" % entry.name
                )
            registry.register(entry.name, entry.load())
    return registry


def _binpacking_bundle():
    from scientist.domains.binpacking.registration import domain_bundle

    return domain_bundle()


def _cognitive_bundle():
    from scientist.domains.cognitive_core.registration import domain_bundle

    return domain_bundle()


def _compiler_optimization_bundle():
    from scientist.domains.compiler_optimization.registration import domain_bundle

    return domain_bundle()
