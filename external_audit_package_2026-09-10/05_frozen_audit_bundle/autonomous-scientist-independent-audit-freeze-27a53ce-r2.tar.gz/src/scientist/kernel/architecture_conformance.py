from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple


@dataclass(frozen=True)
class ArchitectureConformanceReport:
    passed: bool
    checks: Mapping[str, bool]
    violations: Mapping[str, Tuple[str, ...]]
    verifier_ref: str = "problem-agnostic-architecture-boundary-v1"

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "violations": {
                key: list(value)
                for key, value in sorted(self.violations.items())
            },
            "verifier_ref": self.verifier_ref,
        }


def _imports(path: Path) -> Tuple[str, ...]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.append(node.module)
    return tuple(imports)


def _forbidden_imports(
    paths: Sequence[Path],
    forbidden_prefixes: Sequence[str],
) -> Tuple[str, ...]:
    violations = []
    for path in paths:
        for imported in _imports(path):
            if any(imported.startswith(prefix) for prefix in forbidden_prefixes):
                violations.append("%s -> %s" % (path, imported))
    return tuple(sorted(violations))


def _forbidden_names(
    paths: Sequence[Path],
    forbidden_names: Sequence[str],
) -> Tuple[str, ...]:
    violations = []
    forbidden = set(forbidden_names)
    for path in paths:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        names = {
            node.id for node in ast.walk(tree) if isinstance(node, ast.Name)
        }
        for name in sorted(names.intersection(forbidden)):
            violations.append("%s -> %s" % (path, name))
    return tuple(sorted(violations))


def _cli_authority_bypasses(path: Path) -> Tuple[str, ...]:
    """Return mutating CLI commands that bypass the scientific authority."""

    if not path.exists():
        return ("missing CLI composition root",)
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    allowed = {"goal-program-status", "binpacking-conformance"}
    bypasses = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.If):
            continue
        returns_direct_handler = any(
            isinstance(item, ast.Return)
            and any(
                isinstance(call, ast.Call)
                and isinstance(call.func, ast.Attribute)
                and call.func.attr == "handler"
                for call in ast.walk(item)
            )
            for item in node.body
        )
        if not returns_direct_handler:
            continue
        bypasses.update(
            value.value
            for value in ast.walk(node.test)
            if isinstance(value, ast.Constant)
            and isinstance(value.value, str)
            and value.value not in allowed
        )
    return tuple(sorted(bypasses))


def check_architecture_conformance(source_root: Path) -> ArchitectureConformanceReport:
    """Fail if reusable layers acquire a concrete problem dependency."""

    source_root = Path(source_root)
    kernel_paths = tuple((source_root / "kernel").rglob("*.py"))
    science_paths = tuple((source_root / "science").rglob("*.py"))
    core_paths = tuple((source_root / "core").rglob("*.py"))
    program_paths = tuple((source_root / "program").rglob("*.py"))
    runtime_paths = (source_root / "scientific_runtime.py",)
    universal_runtime_paths = (
        source_root / "scientific_runtime.py",
        source_root / "science" / "campaign_runtime.py",
        source_root / "program" / "manager.py",
    )
    violations = {
        "kernel_domain_dependencies": _forbidden_imports(
            kernel_paths,
            (
                "scientist.domains",
                "scientist.search",
                "scientist.studies",
                "scientist.confirmation",
            ),
        ),
        "science_domain_dependencies": _forbidden_imports(
            science_paths,
            (
                "scientist.domains",
                "scientist.search",
                "scientist.studies",
                "scientist.confirmation",
            ),
        ),
        "core_domain_dependencies": _forbidden_imports(
            core_paths,
            (
                "scientist.domains",
                "scientist.search",
                "scientist.studies",
                "scientist.confirmation",
            ),
        ),
        "program_domain_dependencies": _forbidden_imports(
            program_paths,
            (
                "scientist.domains",
                "scientist.search",
                "scientist.studies",
                "scientist.confirmation",
            ),
        ),
        "runtime_domain_dependencies": _forbidden_imports(
            runtime_paths,
            ("scientist.domains",),
        ),
        "universal_runtime_strategy_dependencies": _forbidden_imports(
            universal_runtime_paths,
            (
                "scientist.program.campaigns",
                "scientist.program.control_plane",
                "scientist.program.goal_graph_runtime",
                "scientist.search",
                "scientist.studies",
            ),
        ),
        "universal_runtime_strategy_symbols": _forbidden_names(
            universal_runtime_paths,
            (
                "SearchFamily",
                "IslandCampaignContract",
                "IncumbentPortfolio",
                "IslandCandidateProposal",
            ),
        ),
        "cli_authority_bypasses": _cli_authority_bypasses(
            source_root / "cli.py"
        ),
    }
    checks = {
        name.replace("dependencies", "are_absent"): not values
        for name, values in violations.items()
    }
    return ArchitectureConformanceReport(
        passed=all(checks.values()),
        checks=checks,
        violations=violations,
    )
