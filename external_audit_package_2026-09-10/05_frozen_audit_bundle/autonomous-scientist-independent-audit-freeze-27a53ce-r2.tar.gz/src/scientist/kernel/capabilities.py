from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Tuple, Union

from scientist.core.artifacts import content_digest


CAPABILITY_CONTRACT_VERSION = "scientist-domain-capabilities-v2"


class ResearchMode(str, Enum):
    """What kind of scientific object a campaign is trying to establish."""

    OPTIMIZATION = "optimization"
    ESTIMATION = "estimation"
    EXPLANATION = "explanation"
    SYNTHESIS = "synthesis"
    VERIFICATION = "verification"
    PHENOMENON_DISCOVERY = "phenomenon_discovery"


class ComparisonMode(str, Enum):
    PAIRED_INCUMBENT = "paired_incumbent"
    MULTI_CONTROL = "multi_control"
    ABSOLUTE = "absolute"
    HYPOTHESIS_CONTRAST = "hypothesis_contrast"
    DOMAIN_PROVIDED = "domain_provided"


class DomainCapability(str, Enum):
    CANDIDATE_RECONSTRUCTION = "candidate_reconstruction"
    EXPERIMENT_RECONSTRUCTION = "experiment_reconstruction"
    PAIRED_COMPARISON = "paired_comparison"
    MULTI_CONTROL_COMPARISON = "multi_control_comparison"
    BEHAVIOR_FINGERPRINT = "behavior_fingerprint"
    FAILURE_MINIMIZATION = "failure_minimization"
    EXPERIMENT_GENERATION = "experiment_generation"
    TRAINABLE_CANDIDATE = "trainable_candidate"
    INTERVENTION = "intervention"
    ABLATION = "ablation"
    STOCHASTIC_REPEATS = "stochastic_repeats"
    COST_ACCOUNTING = "cost_accounting"
    CODE_EXECUTION = "code_execution"
    HYPOTHESIS_CONTRAST = "hypothesis_contrast"
    DOMAIN_EVIDENCE_METRICS = "domain_evidence_metrics"


ResearchModeRef = Union[ResearchMode, str]
DomainCapabilityRef = Union[DomainCapability, str]


def _ref_value(value: Any) -> str:
    return str(getattr(value, "value", value))


@dataclass(frozen=True)
class DomainCapabilityManifest:
    """Declares optional concepts instead of forcing every domain to fake them."""

    domain_id: str
    research_modes: Tuple[ResearchModeRef, ...]
    capabilities: Tuple[DomainCapabilityRef, ...]
    comparison_mode: ComparisonMode
    primary_metric: str
    independent_evidence_unit: str
    manifest_ref: str
    research_object_types: Tuple[str, ...] = ("executable_artifact",)

    def __post_init__(self) -> None:
        if not all(
            (
                self.domain_id,
                self.research_modes,
                self.primary_metric,
                self.independent_evidence_unit,
                self.manifest_ref,
                self.research_object_types,
            )
        ):
            raise ValueError("domain capability manifest is incomplete")
        if len({_ref_value(item) for item in self.research_modes}) != len(
            self.research_modes
        ):
            raise ValueError("research modes must be unique")
        if len({_ref_value(item) for item in self.capabilities}) != len(
            self.capabilities
        ):
            raise ValueError("domain capabilities must be unique")
        if len(set(self.research_object_types)) != len(
            self.research_object_types
        ) or any(not item for item in self.research_object_types):
            raise ValueError("research object types must be nonempty and unique")
        paired = self.supports(DomainCapability.PAIRED_COMPARISON)
        if self.comparison_mode == ComparisonMode.PAIRED_INCUMBENT and not paired:
            raise ValueError("paired comparison mode requires its capability")
        if (
            self.comparison_mode == ComparisonMode.MULTI_CONTROL
            and not self.supports(DomainCapability.MULTI_CONTROL_COMPARISON)
        ):
            raise ValueError("multi-control mode requires its capability")
        if (
            self.comparison_mode == ComparisonMode.HYPOTHESIS_CONTRAST
            and not self.supports(DomainCapability.HYPOTHESIS_CONTRAST)
        ):
            raise ValueError("hypothesis contrast requires its capability")
        if (
            self.comparison_mode == ComparisonMode.DOMAIN_PROVIDED
            and not self.supports(DomainCapability.DOMAIN_EVIDENCE_METRICS)
        ):
            raise ValueError("domain-provided metrics require their capability")

    def supports(self, capability: DomainCapabilityRef) -> bool:
        return _ref_value(capability) in {
            _ref_value(item) for item in self.capabilities
        }

    def supports_mode(self, mode: ResearchModeRef) -> bool:
        return _ref_value(mode) in {
            _ref_value(item) for item in self.research_modes
        }

    def require(self, capability: DomainCapabilityRef) -> None:
        if not self.supports(capability):
            raise ValueError(
                "%s does not declare capability %s"
                % (self.domain_id, _ref_value(capability))
            )

    @property
    def manifest_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "contract_version": CAPABILITY_CONTRACT_VERSION,
            "domain_id": self.domain_id,
            "research_modes": [_ref_value(item) for item in self.research_modes],
            "capabilities": [_ref_value(item) for item in self.capabilities],
            "comparison_mode": self.comparison_mode.value,
            "primary_metric": self.primary_metric,
            "independent_evidence_unit": self.independent_evidence_unit,
            "manifest_ref": self.manifest_ref,
            "research_object_types": list(self.research_object_types),
        }
        if include_id:
            value["manifest_id"] = self.manifest_id
        return value
