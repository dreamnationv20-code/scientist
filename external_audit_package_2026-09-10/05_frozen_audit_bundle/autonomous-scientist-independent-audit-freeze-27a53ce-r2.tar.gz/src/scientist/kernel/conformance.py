from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Generic, Mapping, Sequence, Tuple, TypeVar

from scientist.core.artifacts import content_digest
from scientist.kernel.capabilities import (
    ComparisonMode,
    DomainCapability,
    DomainCapabilityManifest,
    ResearchMode,
)
from scientist.kernel.contracts import ExecutionMode
from scientist.kernel.interfaces import (
    BehaviorCharacterizer,
    CandidateCodec,
    CoreDomainAdapter,
    ContextualMetricExtractor,
    ControlledComparator,
    ExperimentCodec,
    FailureMinimizer,
    PairedComparator,
)


CandidateT = TypeVar("CandidateT")
ExperimentT = TypeVar("ExperimentT")
ObservationT = TypeVar("ObservationT")
FailureT = TypeVar("FailureT")


@dataclass(frozen=True)
class AdapterConformanceReport:
    domain_id: str
    adapter_version: str
    passed: bool
    checks: Mapping[str, bool]
    details: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "domain_id": self.domain_id,
            "adapter_version": self.adapter_version,
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "details": dict(self.details),
        }


def check_adapter_conformance(
    adapter: CoreDomainAdapter[
        CandidateT,
        ExperimentT,
        ObservationT,
    ],
    candidate: CandidateT,
    incumbent: CandidateT | None,
    experiment: ExperimentT,
    *,
    controls: Sequence[CandidateT] = (),
) -> AdapterConformanceReport:
    manifest = getattr(adapter, "capabilities", None)
    if manifest is None:
        manifest = DomainCapabilityManifest(
            domain_id=adapter.domain_id,
            research_modes=(ResearchMode.OPTIMIZATION,),
            capabilities=(
                DomainCapability.PAIRED_COMPARISON,
                DomainCapability.BEHAVIOR_FINGERPRINT,
            ),
            comparison_mode=ComparisonMode.PAIRED_INCUMBENT,
            primary_metric="improvement",
            independent_evidence_unit="legacy experiment",
            manifest_ref="legacy-adapter-inference-v1",
        )
    candidate_id = adapter.candidate_id(candidate)
    candidate_payload = adapter.candidate_as_dict(candidate)
    experiment_id = adapter.experiment_id(experiment)
    first = adapter.evaluate(candidate, experiment)
    second = adapter.evaluate(candidate, experiment)
    first_payload = adapter.observation_as_dict(first)
    second_payload = adapter.observation_as_dict(second)
    first_observation_id = adapter.observation_id(first)
    verification = adapter.verify(experiment, first)
    comparison = None
    resolved_controls = (
        (() if incumbent is None else (incumbent,)) + tuple(controls)
    )
    if manifest.supports(DomainCapability.PAIRED_COMPARISON):
        if incumbent is None or not isinstance(adapter, PairedComparator):
            raise ValueError(
                "paired-comparison adapter requires a conformance control"
            )
        comparison = adapter.compare(candidate, incumbent, experiment)
    controlled_comparison = None
    if manifest.comparison_mode in {
        ComparisonMode.MULTI_CONTROL,
        ComparisonMode.HYPOTHESIS_CONTRAST,
    }:
        if not resolved_controls or not isinstance(adapter, ControlledComparator):
            raise ValueError(
                "controlled-comparison adapter requires conformance controls"
            )
        controlled_comparison = adapter.compare_controls(
            candidate,
            resolved_controls,
            experiment,
        )
    contextual_metrics_available = (
        manifest.comparison_mode != ComparisonMode.DOMAIN_PROVIDED
        or isinstance(adapter, ContextualMetricExtractor)
    )
    first_fingerprint = None
    second_fingerprint = None
    if manifest.supports(DomainCapability.BEHAVIOR_FINGERPRINT):
        if not isinstance(adapter, BehaviorCharacterizer):
            raise ValueError(
                "behavior-fingerprint capability is declared but not implemented"
            )
        first_fingerprint = adapter.behavior_fingerprint(
            candidate,
            (experiment,),
        )
        second_fingerprint = adapter.behavior_fingerprint(
            candidate,
            (experiment,),
        )
    candidate_round_trip = True
    if manifest.supports(DomainCapability.CANDIDATE_RECONSTRUCTION):
        candidate_round_trip = (
            isinstance(adapter, CandidateCodec)
            and adapter.candidate_id(
                adapter.candidate_from_dict(candidate_payload)
            )
            == candidate_id
        )
    experiment_round_trip = True
    if manifest.supports(DomainCapability.EXPERIMENT_RECONSTRUCTION):
        experiment_round_trip = (
            isinstance(adapter, ExperimentCodec)
            and adapter.experiment_id(
                adapter.experiment_from_dict(
                    adapter.experiment_as_dict(experiment)
                )
            )
            == experiment_id
        )
    checks = {
        "identity_is_deterministic": (
            candidate_id == adapter.candidate_id(candidate)
        ),
        "identity_matches_payload": (
            candidate_id == str(candidate_payload.get("candidate_id"))
            or candidate_id == content_digest(candidate_payload)
        ),
        "experiment_identity_is_stable": (
            experiment_id == adapter.experiment_id(experiment)
        ),
        "evaluation_is_deterministic": (
            adapter.execution_mode == ExecutionMode.STOCHASTIC
            or first_payload == second_payload
        ),
        "execution_mode_is_declared": isinstance(
            adapter.execution_mode,
            ExecutionMode,
        ),
        "stochastic_mode_has_repeat_contract": (
            adapter.execution_mode != ExecutionMode.STOCHASTIC
            or manifest.supports(DomainCapability.STOCHASTIC_REPEATS)
        ),
        "capability_manifest_matches_domain": (
            manifest.domain_id == adapter.domain_id
        ),
        "candidate_reconstruction_if_declared": candidate_round_trip,
        "experiment_reconstruction_if_declared": experiment_round_trip,
        "observation_identity_is_stable": (
            first_observation_id == adapter.observation_id(first)
        ),
        "verification_passes": verification.passed,
        "verification_authority_matches": (
            verification.verifier_ref == adapter.verifier_ref
        ),
        "comparison_references_candidate": (
            comparison is None or comparison.candidate_id == candidate_id
        ),
        "comparison_references_control": (
            comparison is None
            or (
                incumbent is not None
                and comparison.incumbent_id
                == adapter.candidate_id(incumbent)
            )
        ),
        "comparison_references_experiment": (
            comparison is None or comparison.experiment_id == experiment_id
        ),
        "controlled_comparison_references_subject": (
            controlled_comparison is None
            or controlled_comparison.subject_id == candidate_id
        ),
        "controlled_comparison_references_controls": (
            controlled_comparison is None
            or controlled_comparison.control_ids
            == tuple(adapter.candidate_id(item) for item in resolved_controls)
        ),
        "controlled_comparison_references_experiment": (
            controlled_comparison is None
            or controlled_comparison.experiment_id == experiment_id
        ),
        "domain_metrics_if_declared": contextual_metrics_available,
        "behavior_fingerprint_is_deterministic": (
            first_fingerprint is None
            or first_fingerprint == second_fingerprint
        ),
        "failure_minimizer_if_declared": (
            not manifest.supports(DomainCapability.FAILURE_MINIMIZATION)
            or isinstance(adapter, FailureMinimizer)
        ),
        "primary_metric_is_emitted": (
            (
                comparison is None
                or manifest.primary_metric in comparison.metrics
            )
            and (
                controlled_comparison is None
                or manifest.primary_metric in controlled_comparison.metrics
            )
        ),
        "discovery_channels_are_optional": (
            not hasattr(adapter, "search_families")
            or bool(adapter.search_families())
        ),
        "evaluator_and_verifier_are_separate": (
            adapter.evaluator_ref != adapter.verifier_ref
        ),
    }
    return AdapterConformanceReport(
        domain_id=adapter.domain_id,
        adapter_version=adapter.adapter_version,
        passed=all(checks.values()),
        checks=checks,
        details={
            "candidate_id": candidate_id,
            "experiment_id": experiment_id,
            "behavior_fingerprint": first_fingerprint,
            "capability_manifest": manifest.as_dict(),
            "execution_mode": adapter.execution_mode.value,
            "observation_id": first_observation_id,
            "evaluator_ref": adapter.evaluator_ref,
            "verifier_ref": adapter.verifier_ref,
        },
    )
