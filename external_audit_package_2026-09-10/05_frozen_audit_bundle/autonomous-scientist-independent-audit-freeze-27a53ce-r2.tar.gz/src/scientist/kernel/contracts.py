from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.capabilities import ComparisonMode


ARCHITECTURE_VERSION = "autonomous-scientist-kernel-v2"


class MetricDirection(str, Enum):
    MINIMIZE = "minimize"
    MAXIMIZE = "maximize"
    TARGET = "target"


class EvidencePartition(str, Enum):
    DEVELOPMENT = "development"
    GUARD = "guard"
    AUDIT = "audit"
    REPLICATION = "replication"
    EXTERNAL_CONFIRMATION = "external_confirmation"


class ExecutionMode(str, Enum):
    DETERMINISTIC = "deterministic"
    SEEDED = "seeded"
    STOCHASTIC = "stochastic"


class ProbeLevel(str, Enum):
    L0_STATIC = "L0_static"
    L1_TOY = "L1_toy"
    L2_GENERATED = "L2_generated"
    L3_EXTERNAL = "L3_external"


class SearchFamily(str, Enum):
    ANCESTRY = "ancestry"
    DE_NOVO = "de_novo"
    HYBRID = "hybrid"


class ChannelRelation(str, Enum):
    INCUMBENT_DESCENDANT = "incumbent_descendant"
    INDEPENDENT = "independent"
    COMPOSITION = "composition"
    CROSS_DOMAIN_TRANSFER = "cross_domain_transfer"
    EXPERIMENT_DESIGN = "experiment_design"
    OTHER = "other"


class AnalysisKind(str, Enum):
    DOMAIN_PROVIDED = "domain_provided"
    PAIRED_MEAN_CONFIDENCE = "paired_mean_confidence"
    UNPAIRED_MEAN_CONFIDENCE = "unpaired_mean_confidence"
    EXACT_TEST = "exact_test"
    DETERMINISTIC_PROOF = "deterministic_proof"


class GateKind(str, Enum):
    VALIDATION = "validation"
    RESEARCH_OBJECT_ACCEPTANCE = "research_object_acceptance"
    DEPLOYMENT = "deployment"
    REPLICATION_NOMINATION = "replication_nomination"
    INCUMBENT_ADVANCE = "incumbent_advance"
    PUBLIC_CLAIM = "public_claim"


@dataclass(frozen=True)
class DiscoveryChannelSpec:
    channel_id: str
    relation: ChannelRelation
    parent_exposure: str
    literature_required: bool
    budget_weight: float = 1.0

    def __post_init__(self) -> None:
        if not self.channel_id or not self.parent_exposure:
            raise ValueError("discovery channel is incomplete")
        if self.budget_weight <= 0.0:
            raise ValueError("discovery channel budget weight must be positive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "channel_id": self.channel_id,
            "relation": self.relation.value,
            "parent_exposure": self.parent_exposure,
            "literature_required": self.literature_required,
            "budget_weight": self.budget_weight,
        }

    @classmethod
    def legacy(cls, family: SearchFamily) -> "DiscoveryChannelSpec":
        relation = {
            SearchFamily.ANCESTRY: ChannelRelation.INCUMBENT_DESCENDANT,
            SearchFamily.DE_NOVO: ChannelRelation.INDEPENDENT,
            SearchFamily.HYBRID: ChannelRelation.COMPOSITION,
        }[family]
        exposure = {
            SearchFamily.ANCESTRY: "incumbent mechanism and executable parents",
            SearchFamily.DE_NOVO: "no incumbent executable or parent mechanism",
            SearchFamily.HYBRID: "incumbent interface plus independent mechanism",
        }[family]
        return cls(family.value, relation, exposure, True)


@dataclass(frozen=True)
class EvidenceAnalysisContract:
    analysis_kind: AnalysisKind
    primary_metric: str
    independent_unit: str
    group_keys: Tuple[str, ...]
    analyzer_ref: str
    minimum_independent_units: int
    confidence_level: Optional[float] = None

    def __post_init__(self) -> None:
        if not all(
            (
                self.primary_metric,
                self.independent_unit,
                self.analyzer_ref,
            )
        ):
            raise ValueError("evidence analysis contract is incomplete")
        if self.minimum_independent_units <= 0:
            raise ValueError("minimum independent evidence must be positive")
        if len(set(self.group_keys)) != len(self.group_keys):
            raise ValueError("evidence group keys must be unique")
        if self.confidence_level is not None and not (
            0.0 < self.confidence_level < 1.0
        ):
            raise ValueError("confidence level must be in (0, 1)")
        if (
            self.analysis_kind
            in {
                AnalysisKind.PAIRED_MEAN_CONFIDENCE,
                AnalysisKind.UNPAIRED_MEAN_CONFIDENCE,
            }
            and self.confidence_level is None
        ):
            raise ValueError("confidence analysis requires a confidence level")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "analysis_kind": self.analysis_kind.value,
            "primary_metric": self.primary_metric,
            "independent_unit": self.independent_unit,
            "group_keys": list(self.group_keys),
            "analyzer_ref": self.analyzer_ref,
            "minimum_independent_units": self.minimum_independent_units,
            "confidence_level": self.confidence_level,
        }


@dataclass(frozen=True)
class MetricSpec:
    name: str
    direction: MetricDirection
    unit: str
    aggregation: str
    primary: bool = False
    target: Optional[float] = None

    def __post_init__(self) -> None:
        if not self.name or not self.unit or not self.aggregation:
            raise ValueError("metric fields must not be empty")
        if self.direction == MetricDirection.TARGET and self.target is None:
            raise ValueError("target metrics require a target value")
        if self.direction != MetricDirection.TARGET and self.target is not None:
            raise ValueError("only target metrics may define target")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "direction": self.direction.value,
            "unit": self.unit,
            "aggregation": self.aggregation,
            "primary": self.primary,
            "target": self.target,
        }


@dataclass(frozen=True)
class ProblemCharter:
    name: str
    statement: str
    domain_id: str
    scope: Tuple[str, ...]
    anti_scope: Tuple[str, ...]
    metrics: Tuple[MetricSpec, ...]
    success_definition: str
    falsification_conditions: Tuple[str, ...]
    risk_tier: str = "research_only"
    human_owner: Optional[str] = None

    def __post_init__(self) -> None:
        if not self.name or not self.statement or not self.domain_id:
            raise ValueError("problem charter identity must not be empty")
        if not self.scope or not self.anti_scope:
            raise ValueError("scope and anti_scope must both be explicit")
        if not self.metrics:
            raise ValueError("at least one metric is required")
        if sum(metric.primary for metric in self.metrics) != 1:
            raise ValueError("exactly one primary metric is required")
        if not self.success_definition:
            raise ValueError("success_definition must not be empty")
        if not self.falsification_conditions:
            raise ValueError("falsification conditions are required")

    @property
    def charter_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": ARCHITECTURE_VERSION,
            "name": self.name,
            "statement": self.statement,
            "domain_id": self.domain_id,
            "scope": list(self.scope),
            "anti_scope": list(self.anti_scope),
            "metrics": [metric.as_dict() for metric in self.metrics],
            "success_definition": self.success_definition,
            "falsification_conditions": list(
                self.falsification_conditions
            ),
            "risk_tier": self.risk_tier,
            "human_owner": self.human_owner,
        }
        if include_id:
            value["charter_id"] = self.charter_id
        return value


@dataclass(frozen=True)
class BudgetContract:
    outer_rounds: int
    proposals_per_family_per_round: int = 0
    failure_mining_evaluations_per_round: int = 0
    audit_cases_per_proposal: int = 0
    replication_cases: int = 0
    maximum_compute_units: Optional[float] = None
    proposals_by_channel: Mapping[str, int] = field(default_factory=dict)
    evidence_cases_by_partition: Mapping[EvidencePartition, int] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        optional_legacy = (
            self.proposals_per_family_per_round,
            self.failure_mining_evaluations_per_round,
            self.audit_cases_per_proposal,
            self.replication_cases,
        )
        if self.outer_rounds <= 0 or min(optional_legacy) < 0:
            raise ValueError(
                "campaign rounds must be positive and optional budgets non-negative"
            )
        if (
            self.maximum_compute_units is not None
            and self.maximum_compute_units <= 0
        ):
            raise ValueError("maximum_compute_units must be positive")
        if any(
            not channel or count < 0
            for channel, count in self.proposals_by_channel.items()
        ):
            raise ValueError("channel proposal budgets are invalid")
        if any(count < 0 for count in self.evidence_cases_by_partition.values()):
            raise ValueError("evidence partition budgets must be non-negative")
        if not any(
            (
                *optional_legacy,
                *self.proposals_by_channel.values(),
                *self.evidence_cases_by_partition.values(),
                0.0 if self.maximum_compute_units is None else self.maximum_compute_units,
            )
        ):
            raise ValueError("campaign budget does not authorize any work")

    def proposal_budget(self, channel_id: str) -> int:
        return int(
            self.proposals_by_channel.get(
                channel_id,
                self.proposals_per_family_per_round,
            )
        )

    def evidence_budget(self, partition: EvidencePartition) -> int:
        if partition in self.evidence_cases_by_partition:
            return int(self.evidence_cases_by_partition[partition])
        if partition == EvidencePartition.AUDIT:
            return self.audit_cases_per_proposal
        if partition in {
            EvidencePartition.REPLICATION,
            EvidencePartition.EXTERNAL_CONFIRMATION,
        }:
            return self.replication_cases
        if partition in {
            EvidencePartition.DEVELOPMENT,
            EvidencePartition.GUARD,
        }:
            return self.failure_mining_evaluations_per_round
        return 0

    def as_dict(self) -> Dict[str, Any]:
        return {
            "outer_rounds": self.outer_rounds,
            "proposals_per_family_per_round": (
                self.proposals_per_family_per_round
            ),
            "proposals_per_channel_per_round": (
                self.proposals_per_family_per_round
            ),
            "failure_mining_evaluations_per_round": (
                self.failure_mining_evaluations_per_round
            ),
            "audit_cases_per_proposal": self.audit_cases_per_proposal,
            "replication_cases": self.replication_cases,
            "maximum_compute_units": self.maximum_compute_units,
            "proposals_by_channel": dict(sorted(self.proposals_by_channel.items())),
            "evidence_cases_by_partition": {
                partition.value: int(count)
                for partition, count in sorted(
                    self.evidence_cases_by_partition.items(),
                    key=lambda item: item[0].value,
                )
            },
        }


@dataclass(frozen=True)
class GateCriterion:
    metric: str
    operator: str
    threshold: float
    description: str

    def __post_init__(self) -> None:
        if self.operator not in ("<", "<=", "==", ">=", ">"):
            raise ValueError("unsupported gate operator")
        if not self.metric or not self.description:
            raise ValueError("gate criterion fields must not be empty")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "metric": self.metric,
            "operator": self.operator,
            "threshold": self.threshold,
            "description": self.description,
        }


@dataclass(frozen=True)
class GateContract:
    kind: GateKind
    evidence_partition: EvidencePartition
    criteria: Tuple[GateCriterion, ...]
    minimum_evidence_count: int

    def __post_init__(self) -> None:
        if not self.criteria:
            raise ValueError("gate criteria must not be empty")
        if self.minimum_evidence_count <= 0:
            raise ValueError("minimum_evidence_count must be positive")
        allowed = {
            GateKind.VALIDATION: {
                EvidencePartition.GUARD,
                EvidencePartition.AUDIT,
                EvidencePartition.REPLICATION,
                EvidencePartition.EXTERNAL_CONFIRMATION,
            },
            GateKind.RESEARCH_OBJECT_ACCEPTANCE: {
                EvidencePartition.AUDIT,
                EvidencePartition.REPLICATION,
                EvidencePartition.EXTERNAL_CONFIRMATION,
            },
            GateKind.REPLICATION_NOMINATION: {
                EvidencePartition.AUDIT,
            },
            GateKind.DEPLOYMENT: {
                EvidencePartition.AUDIT,
                EvidencePartition.REPLICATION,
                EvidencePartition.EXTERNAL_CONFIRMATION,
            },
            GateKind.INCUMBENT_ADVANCE: {
                EvidencePartition.REPLICATION,
                EvidencePartition.EXTERNAL_CONFIRMATION,
            },
            GateKind.PUBLIC_CLAIM: {
                EvidencePartition.REPLICATION,
                EvidencePartition.EXTERNAL_CONFIRMATION,
            },
        }[self.kind]
        if self.evidence_partition not in allowed:
            raise ValueError(
                "%s cannot use %s evidence"
                % (self.kind.value, self.evidence_partition.value)
            )

    @property
    def contract_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kind": self.kind.value,
            "evidence_partition": self.evidence_partition.value,
            "criteria": [
                criterion.as_dict() for criterion in self.criteria
            ],
            "minimum_evidence_count": self.minimum_evidence_count,
        }
        if include_id:
            value["contract_id"] = self.contract_id
        return value


@dataclass(frozen=True)
class CampaignContract:
    charter_id: str
    domain_adapter_ref: str
    incumbent_candidate_id: Optional[str]
    search_families: Tuple[SearchFamily, ...]
    budget: BudgetContract
    evaluator_ref: str
    verifier_ref: str
    development_partitions: Tuple[EvidencePartition, ...]
    gates: Tuple[GateContract, ...]
    plateau_window: int = 2
    comparison_mode: ComparisonMode = ComparisonMode.PAIRED_INCUMBENT
    discovery_channels: Tuple[DiscoveryChannelSpec, ...] = ()
    evidence_analysis: Optional[EvidenceAnalysisContract] = None
    control_candidate_ids: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not (
            self.charter_id
            and self.domain_adapter_ref
            and self.evaluator_ref
            and self.verifier_ref
        ):
            raise ValueError("campaign references must not be empty")
        if (
            self.comparison_mode == ComparisonMode.PAIRED_INCUMBENT
            and not self.incumbent_candidate_id
        ):
            raise ValueError("paired campaigns require an incumbent")
        control_ids = self.resolved_control_candidate_ids
        if len(set(control_ids)) != len(control_ids):
            raise ValueError("campaign control identities must be unique")
        if (
            self.comparison_mode == ComparisonMode.MULTI_CONTROL
            and len(control_ids) < 2
        ):
            raise ValueError("multi-control campaigns require at least two controls")
        if (
            self.comparison_mode == ComparisonMode.HYPOTHESIS_CONTRAST
            and not control_ids
        ):
            raise ValueError("hypothesis contrast requires competing controls")
        if self.comparison_mode in {
            ComparisonMode.ABSOLUTE,
            ComparisonMode.DOMAIN_PROVIDED,
        } and self.incumbent_candidate_id is not None:
            raise ValueError("non-comparative campaigns cannot declare an incumbent")
        if not self.search_families and not self.discovery_channels:
            raise ValueError("at least one discovery channel is required")
        if len(set(self.search_families)) != len(self.search_families):
            raise ValueError("search families must be unique")
        if self.evaluator_ref == self.verifier_ref:
            raise ValueError(
                "evaluator and verifier authorities must be separate"
            )
        if not self.development_partitions:
            raise ValueError("development partitions must not be empty")
        if len(set(self.development_partitions)) != len(
            self.development_partitions
        ):
            raise ValueError("development partitions must be unique")
        if any(
            partition
            not in (
                EvidencePartition.DEVELOPMENT,
                EvidencePartition.GUARD,
            )
            for partition in self.development_partitions
        ):
            raise ValueError(
                "only development and guard evidence can train search"
            )
        if not self.gates:
            raise ValueError("at least one gate is required")
        if self.plateau_window < 1:
            raise ValueError("plateau_window must be positive")
        channels = self.resolved_discovery_channels
        channel_ids = tuple(item.channel_id for item in channels)
        if len(set(channel_ids)) != len(channel_ids):
            raise ValueError("discovery channel IDs must be unique")

    @property
    def resolved_discovery_channels(self) -> Tuple[DiscoveryChannelSpec, ...]:
        return self.discovery_channels or tuple(
            DiscoveryChannelSpec.legacy(family)
            for family in self.search_families
        )

    @property
    def resolved_control_candidate_ids(self) -> Tuple[str, ...]:
        return self.control_candidate_ids or (
            ()
            if self.incumbent_candidate_id is None
            else (self.incumbent_candidate_id,)
        )

    @property
    def campaign_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": ARCHITECTURE_VERSION,
            "charter_id": self.charter_id,
            "domain_adapter_ref": self.domain_adapter_ref,
            "incumbent_candidate_id": self.incumbent_candidate_id,
            "control_candidate_ids": list(self.resolved_control_candidate_ids),
            "comparison_mode": self.comparison_mode.value,
            "search_families": [
                family.value for family in self.search_families
            ],
            "budget": self.budget.as_dict(),
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "development_partitions": [
                partition.value for partition in self.development_partitions
            ],
            "gates": [gate.as_dict() for gate in self.gates],
            "discovery_channels": [
                channel.as_dict()
                for channel in self.resolved_discovery_channels
            ],
            "evidence_analysis": (
                None
                if self.evidence_analysis is None
                else self.evidence_analysis.as_dict()
            ),
            "plateau_window": self.plateau_window,
        }
        if include_id:
            value["campaign_id"] = self.campaign_id
        return value


@dataclass(frozen=True)
class CandidateRecord:
    domain_id: str
    family: SearchFamily | str
    representation: str
    executable_digest: str
    parent_ids: Tuple[str, ...]
    proposer_ref: str
    cycle_id: str
    round_index: int
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not (
            self.domain_id
            and self.representation
            and self.executable_digest
            and self.proposer_ref
            and self.cycle_id
        ):
            raise ValueError("candidate record fields must not be empty")
        if self.round_index < 0:
            raise ValueError("round_index must be non-negative")

    @property
    def candidate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "domain_id": self.domain_id,
            "family": (
                self.family.value
                if isinstance(self.family, SearchFamily)
                else str(self.family)
            ),
            "representation": self.representation,
            "executable_digest": self.executable_digest,
            "parent_ids": list(self.parent_ids),
            "proposer_ref": self.proposer_ref,
            "cycle_id": self.cycle_id,
            "round_index": self.round_index,
            "metadata": dict(self.metadata),
        }
        if include_id:
            value["candidate_id"] = self.candidate_id
        return value


@dataclass(frozen=True)
class EvidenceRecord:
    cycle_id: str
    candidate_id: str
    incumbent_id: Optional[str]
    experiment_id: str
    partition: EvidencePartition
    observation_digest: str
    verification_digest: str
    evaluator_ref: str
    verifier_ref: str
    metrics: Mapping[str, float]

    def __post_init__(self) -> None:
        required = (
            self.cycle_id,
            self.candidate_id,
            self.experiment_id,
            self.observation_digest,
            self.verification_digest,
            self.evaluator_ref,
            self.verifier_ref,
        )
        if not all(required):
            raise ValueError("evidence record fields must not be empty")
        if self.evaluator_ref == self.verifier_ref:
            raise ValueError(
                "evidence evaluator and verifier must be separate"
            )
        if not self.metrics:
            raise ValueError("evidence metrics must not be empty")

    @property
    def evidence_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": ARCHITECTURE_VERSION,
            "cycle_id": self.cycle_id,
            "candidate_id": self.candidate_id,
            "incumbent_id": self.incumbent_id,
            "experiment_id": self.experiment_id,
            "partition": self.partition.value,
            "observation_digest": self.observation_digest,
            "verification_digest": self.verification_digest,
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "metrics": dict(sorted(self.metrics.items())),
        }
        if include_id:
            value["evidence_id"] = self.evidence_id
        return value


@dataclass(frozen=True)
class BenchmarkExposureRecord:
    cycle_id: str
    benchmark_id: str
    component_ref: str
    purpose: str

    def __post_init__(self) -> None:
        if not (
            self.cycle_id
            and self.benchmark_id
            and self.component_ref
            and self.purpose
        ):
            raise ValueError(
                "benchmark exposure fields must not be empty"
            )

    @property
    def exposure_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": ARCHITECTURE_VERSION,
            "cycle_id": self.cycle_id,
            "benchmark_id": self.benchmark_id,
            "component_ref": self.component_ref,
            "purpose": self.purpose,
        }
        if include_id:
            value["exposure_id"] = self.exposure_id
        return value


@dataclass(frozen=True)
class ClaimRecord:
    cycle_id: str
    charter_id: str
    candidate_id: str
    incumbent_id: Optional[str]
    statement: str
    validity_scope: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    gate_decision_ids: Tuple[str, ...]
    limitations: Tuple[str, ...]

    def __post_init__(self) -> None:
        required = (
            self.cycle_id,
            self.charter_id,
            self.candidate_id,
            self.statement,
        )
        if not all(required):
            raise ValueError("claim record fields must not be empty")
        if not self.validity_scope:
            raise ValueError("claim validity_scope must not be empty")
        if not self.evidence_ids or not self.gate_decision_ids:
            raise ValueError(
                "claims require evidence and gate decisions"
            )
        if not self.limitations:
            raise ValueError("claim limitations must be explicit")

    @property
    def claim_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": ARCHITECTURE_VERSION,
            "cycle_id": self.cycle_id,
            "charter_id": self.charter_id,
            "candidate_id": self.candidate_id,
            "incumbent_id": self.incumbent_id,
            "statement": self.statement,
            "validity_scope": list(self.validity_scope),
            "evidence_ids": list(self.evidence_ids),
            "gate_decision_ids": list(self.gate_decision_ids),
            "limitations": list(self.limitations),
        }
        if include_id:
            value["claim_id"] = self.claim_id
        return value
