from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Mapping, Optional, Tuple

from scientist.kernel.capabilities import (
    ComparisonMode,
    DomainCapability,
    DomainCapabilityManifest,
)
from scientist.kernel.contracts import CampaignContract, ProblemCharter
from scientist.kernel.interfaces import EvidenceRequest


@dataclass(frozen=True)
class DomainConformanceFixture:
    candidate: Any
    experiment: Any
    control: Optional[Any] = None
    controls: Tuple[Any, ...] = ()

    @property
    def resolved_controls(self) -> Tuple[Any, ...]:
        return (
            (() if self.control is None else (self.control,))
            + tuple(self.controls)
        )


@dataclass(frozen=True)
class ScientificDomainBundle:
    """Composition-root object; the kernel never imports a concrete domain."""

    domain_id: str
    adapter: Any
    charter_factory: Callable[[], ProblemCharter]
    campaign_factory: Callable[[Optional[str]], CampaignContract]
    fixture_factory: Callable[[], DomainConformanceFixture]
    capability_manifest: DomainCapabilityManifest
    bundle_ref: str
    experiment_factory: Optional[Any] = None
    proposal_engines: Mapping[str, Any] = field(default_factory=dict)
    # Optional V3 lifecycle components. Legacy domain laboratories remain
    # valid without them; AutonomousResearchExecutive fails closed when a
    # required research phase has no installed component.
    research_components: Mapping[str, Any] = field(default_factory=dict)
    command_contract_adapter: Optional[
        Callable[[Any, CampaignContract], CampaignContract]
    ] = None
    campaign_builder: Optional[
        Callable[[Tuple[str, ...]], CampaignContract]
    ] = None

    def __post_init__(self) -> None:
        if not all((self.domain_id, self.bundle_ref)):
            raise ValueError("scientific domain bundle identity is incomplete")
        if self.adapter.domain_id != self.domain_id:
            raise ValueError("domain bundle and adapter disagree")
        if self.capability_manifest.domain_id != self.domain_id:
            raise ValueError("domain bundle and capability manifest disagree")
        charter = self.charter_factory()
        if charter.domain_id != self.domain_id:
            raise ValueError("domain bundle and problem charter disagree")
        primary_metrics = tuple(
            metric.name for metric in charter.metrics if metric.primary
        )
        if primary_metrics != (self.capability_manifest.primary_metric,):
            raise ValueError(
                "domain capability manifest and charter primary metric disagree"
            )
        if (
            self.capability_manifest.supports(
                DomainCapability.EXPERIMENT_GENERATION
            )
            and self.experiment_factory is None
        ):
            raise ValueError(
                "experiment-generation capability requires a factory"
            )
        fixture = self.fixture_factory()
        control_ids = tuple(
            self.adapter.candidate_id(control)
            for control in fixture.resolved_controls
        )
        if self.capability_manifest.comparison_mode == ComparisonMode.PAIRED_INCUMBENT:
            if len(control_ids) != 1:
                raise ValueError("paired domain bundle requires a control fixture")
        if self.capability_manifest.comparison_mode == ComparisonMode.MULTI_CONTROL:
            if len(control_ids) < 2:
                raise ValueError("multi-control bundle requires multiple controls")
        campaign = self.build_campaign(control_ids)
        if campaign.charter_id != charter.charter_id:
            raise ValueError("domain campaign and charter disagree")
        if campaign.domain_adapter_ref != self.adapter.adapter_version:
            raise ValueError("domain campaign and adapter version disagree")
        if (
            campaign.evaluator_ref != self.adapter.evaluator_ref
            or campaign.verifier_ref != self.adapter.verifier_ref
        ):
            raise ValueError("domain campaign authority references disagree")
        if campaign.comparison_mode != self.capability_manifest.comparison_mode:
            raise ValueError("domain campaign and comparison capability disagree")
        if campaign.resolved_control_candidate_ids != control_ids:
            raise ValueError("domain campaign and conformance controls disagree")
        if (
            campaign.evidence_analysis is None
            or campaign.evidence_analysis.primary_metric
            != self.capability_manifest.primary_metric
        ):
            raise ValueError("domain campaign and evidence analysis disagree")
        unknown_engines = set(self.proposal_engines).difference(
            channel.channel_id
            for channel in campaign.resolved_discovery_channels
        )
        if unknown_engines:
            raise ValueError(
                "proposal engines target unknown discovery channels: %s"
                % ",".join(sorted(unknown_engines))
            )

    def generate_experiments(self, request: Any) -> Tuple[Any, ...]:
        if self.experiment_factory is None:
            raise ValueError("domain does not declare experiment generation")
        experiments = tuple(self.experiment_factory.generate(request))
        return self._validate_evidence_batch(experiments, int(request.count))

    def generate_evidence(self, request: EvidenceRequest) -> Tuple[Any, ...]:
        if self.experiment_factory is None:
            raise ValueError("domain does not declare evidence generation")
        generator = getattr(self.experiment_factory, "generate_evidence", None)
        if not callable(generator):
            raise ValueError(
                "domain factory supports only legacy seeded experiment requests"
            )
        experiments = tuple(generator(request))
        return self._validate_evidence_batch(experiments, request.count)

    def _validate_evidence_batch(
        self,
        experiments: Tuple[Any, ...],
        expected_count: int,
    ) -> Tuple[Any, ...]:
        if len(experiments) != expected_count:
            raise ValueError("domain evidence factory returned another count")
        identities = tuple(
            self.adapter.experiment_id(experiment)
            for experiment in experiments
        )
        if len(set(identities)) != len(identities):
            raise ValueError("domain experiment factory returned duplicate identities")
        return experiments

    def build_campaign(
        self,
        control_ids: Tuple[str, ...],
    ) -> CampaignContract:
        if self.campaign_builder is not None:
            return self.campaign_builder(tuple(control_ids))
        primary = None if not control_ids else control_ids[0]
        return self.campaign_factory(primary)

    def proposal_engine(self, channel_id: str) -> Any:
        try:
            return self.proposal_engines[channel_id]
        except KeyError as error:
            raise ValueError(
                "domain has no proposal engine for channel %r" % channel_id
            ) from error

    def research_component(self, action_kind: str) -> Any:
        try:
            component = self.research_components[action_kind]
        except KeyError as error:
            raise ValueError(
                "domain has no autonomous research component for %r"
                % action_kind
            ) from error
        if not all(
            (
                getattr(component, "name", ""),
                getattr(component, "component_version", ""),
                callable(getattr(component, "dispatch", None)),
            )
        ):
            raise ValueError("installed autonomous research component is invalid")
        return component


class DomainRegistry:
    def __init__(self) -> None:
        self._providers: Dict[str, Callable[[], ScientificDomainBundle]] = {}

    def register(
        self,
        domain_id: str,
        provider: Callable[[], ScientificDomainBundle],
    ) -> None:
        if not domain_id or domain_id in self._providers:
            raise ValueError("domain registration is empty or duplicated")
        if not callable(provider):
            raise ValueError("domain provider must be callable")
        self._providers[domain_id] = provider

    @property
    def domain_ids(self) -> Tuple[str, ...]:
        return tuple(sorted(self._providers))

    def resolve(self, domain_id: str) -> ScientificDomainBundle:
        try:
            bundle = self._providers[domain_id]()
        except KeyError as error:
            raise ValueError(
                "unknown scientific domain %r; registered=%s"
                % (domain_id, ",".join(self.domain_ids))
            ) from error
        if bundle.domain_id != domain_id:
            raise ValueError("registered provider returned another domain")
        return bundle

    def as_dict(self) -> Mapping[str, Any]:
        return {"registered_domain_ids": list(self.domain_ids)}
