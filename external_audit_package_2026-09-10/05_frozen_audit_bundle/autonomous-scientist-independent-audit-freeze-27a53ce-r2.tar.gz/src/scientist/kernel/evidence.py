from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import NormalDist, mean, stdev
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.capabilities import ComparisonMode
from scientist.kernel.contracts import (
    AnalysisKind,
    EvidenceAnalysisContract,
    EvidencePartition,
)
from scientist.kernel.interfaces import (
    ContextualMetricExtractor,
    ControlledComparator,
    DomainEvidenceAnalyzer,
    ObservationMetricExtractor,
    PairedComparator,
    VerificationResult,
)


@dataclass(frozen=True)
class MeasurementRecord:
    domain_id: str
    subject_id: str
    control_ids: Tuple[str, ...]
    experiment_id: str
    partition: EvidencePartition
    observation: Mapping[str, Any]
    verification: VerificationResult
    metrics: Mapping[str, float]
    evaluator_ref: str
    verifier_ref: str

    @property
    def measurement_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "domain_id": self.domain_id,
            "subject_id": self.subject_id,
            "control_ids": list(self.control_ids),
            "experiment_id": self.experiment_id,
            "partition": self.partition.value,
            "observation": dict(self.observation),
            "verification": self.verification.as_dict(),
            "metrics": dict(sorted(self.metrics.items())),
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
        }
        if include_id:
            value["measurement_id"] = self.measurement_id
        return value


@dataclass(frozen=True)
class EvidenceSummary:
    analysis_contract: EvidenceAnalysisContract
    experiment_ids: Tuple[str, ...]
    metrics: Mapping[str, float]
    analyzer_ref: str

    @property
    def summary_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "analysis_contract": self.analysis_contract.as_dict(),
            "experiment_ids": list(self.experiment_ids),
            "metrics": dict(sorted(self.metrics.items())),
            "analyzer_ref": self.analyzer_ref,
        }
        if include_id:
            value["summary_id"] = self.summary_id
        return value


def analyze_measurements(
    adapter: Any,
    measurements: Sequence[MeasurementRecord],
    contract: EvidenceAnalysisContract,
) -> EvidenceSummary:
    if not measurements:
        raise ValueError("evidence analysis requires measurements")
    experiment_ids = tuple(item.experiment_id for item in measurements)
    if len(set(experiment_ids)) != len(experiment_ids):
        raise ValueError("independent evidence identities must be unique")
    if len(measurements) < contract.minimum_independent_units:
        raise ValueError("evidence analysis is underpowered by contract")
    rows = tuple(item.metrics for item in measurements)
    missing = [
        item.experiment_id
        for item in measurements
        if contract.primary_metric not in item.metrics
    ]
    if missing:
        raise ValueError("primary metric missing for: %s" % ",".join(missing))
    if contract.analysis_kind == AnalysisKind.DOMAIN_PROVIDED:
        if not isinstance(adapter, DomainEvidenceAnalyzer):
            raise ValueError("domain-provided analysis is not implemented")
        metrics = dict(
            adapter.analyze_evidence(rows, experiment_ids, contract)
        )
    elif contract.analysis_kind in {
        AnalysisKind.PAIRED_MEAN_CONFIDENCE,
        AnalysisKind.UNPAIRED_MEAN_CONFIDENCE,
    }:
        values = tuple(float(row[contract.primary_metric]) for row in rows)
        center = mean(values)
        standard_error = (
            0.0 if len(values) == 1 else stdev(values) / math.sqrt(len(values))
        )
        level = float(contract.confidence_level)
        critical = NormalDist().inv_cdf(0.5 + level / 2.0)
        metrics = {
            "independent_unit_count": float(len(values)),
            "aggregate_%s" % contract.primary_metric: sum(values),
            "mean_%s" % contract.primary_metric: center,
            "%s_standard_error" % contract.primary_metric: standard_error,
            "mean_%s_ci_lower" % contract.primary_metric: (
                center - critical * standard_error
            ),
            "mean_%s_ci_upper" % contract.primary_metric: (
                center + critical * standard_error
            ),
            "confidence_level": level,
            "wins": float(sum(value > 0.0 for value in values)),
            "ties": float(sum(value == 0.0 for value in values)),
            "losses": float(sum(value < 0.0 for value in values)),
            "loss_rate": sum(value < 0.0 for value in values) / float(len(values)),
            "maximum_regression": max(0.0, -min(values)),
        }
    elif contract.analysis_kind == AnalysisKind.DETERMINISTIC_PROOF:
        if len(measurements) != 1:
            raise ValueError("deterministic proof analysis expects one certificate")
        metrics = dict(rows[0])
    else:
        raise ValueError(
            "analysis kind %s requires a registered domain analyzer"
            % contract.analysis_kind.value
        )
    if not metrics or any(not math.isfinite(float(value)) for value in metrics.values()):
        raise ValueError("evidence analyzer returned invalid metrics")
    return EvidenceSummary(contract, experiment_ids, metrics, contract.analyzer_ref)


def evaluate_measurements(
    adapter: Any,
    subject: Any,
    experiments: Sequence[Any],
    *,
    partition: EvidencePartition,
    comparison_mode: ComparisonMode,
    control: Optional[Any] = None,
    controls: Sequence[Any] = (),
) -> Tuple[MeasurementRecord, ...]:
    """Generic verified execution for optimization and non-optimization domains."""

    if not experiments:
        raise ValueError("measurement execution requires experiments")
    subject_id = adapter.candidate_id(subject)
    resolved_controls = (
        (() if control is None else (control,)) + tuple(controls)
    )
    control_ids = tuple(
        adapter.candidate_id(item) for item in resolved_controls
    )
    if len(set(control_ids)) != len(control_ids):
        raise ValueError("measurement controls must have unique identities")
    records = []
    for experiment in experiments:
        observation = adapter.evaluate(subject, experiment)
        verification = adapter.verify(experiment, observation)
        if not verification.passed:
            raise ValueError("domain verifier rejected an observation")
        if verification.verifier_ref != adapter.verifier_ref:
            raise ValueError("domain returned another verifier authority")
        if comparison_mode == ComparisonMode.PAIRED_INCUMBENT:
            if len(resolved_controls) != 1 or not isinstance(adapter, PairedComparator):
                raise ValueError("paired measurement requires a control")
            metrics = adapter.compare(
                subject, resolved_controls[0], experiment
            ).metrics
        elif comparison_mode == ComparisonMode.ABSOLUTE:
            if resolved_controls:
                raise ValueError("absolute measurements cannot declare controls")
            if not isinstance(adapter, ObservationMetricExtractor):
                raise ValueError("absolute measurement metrics are not implemented")
            metrics = adapter.observation_metrics(experiment, observation)
        elif comparison_mode in {
            ComparisonMode.MULTI_CONTROL,
            ComparisonMode.HYPOTHESIS_CONTRAST,
        }:
            minimum = 2 if comparison_mode == ComparisonMode.MULTI_CONTROL else 1
            if (
                len(resolved_controls) < minimum
                or not isinstance(adapter, ControlledComparator)
            ):
                raise ValueError(
                    "%s measurement requires controlled comparison"
                    % comparison_mode.value
                )
            comparison = adapter.compare_controls(
                subject,
                resolved_controls,
                experiment,
            )
            if comparison.subject_id != subject_id:
                raise ValueError("controlled comparison references another subject")
            if comparison.control_ids != control_ids:
                raise ValueError("controlled comparison references other controls")
            if comparison.experiment_id != adapter.experiment_id(experiment):
                raise ValueError("controlled comparison references another task")
            metrics = comparison.metrics
        elif comparison_mode == ComparisonMode.DOMAIN_PROVIDED:
            if not isinstance(adapter, ContextualMetricExtractor):
                raise ValueError("domain-provided measurement metrics are unavailable")
            metrics = adapter.measurement_metrics(
                subject,
                resolved_controls,
                experiment,
                observation,
            )
        else:
            raise ValueError(
                "%s measurement requires a domain comparison service"
                % comparison_mode.value
            )
        records.append(
            MeasurementRecord(
                domain_id=adapter.domain_id,
                subject_id=subject_id,
                control_ids=control_ids,
                experiment_id=adapter.experiment_id(experiment),
                partition=partition,
                observation=dict(adapter.observation_as_dict(observation)),
                verification=verification,
                metrics={name: float(value) for name, value in metrics.items()},
                evaluator_ref=adapter.evaluator_ref,
                verifier_ref=adapter.verifier_ref,
            )
        )
    return tuple(records)
