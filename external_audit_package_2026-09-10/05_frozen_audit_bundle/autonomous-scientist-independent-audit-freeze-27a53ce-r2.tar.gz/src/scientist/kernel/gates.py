from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import GateContract


@dataclass(frozen=True)
class CriterionResult:
    metric: str
    observed: float
    operator: str
    threshold: float
    passed: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "metric": self.metric,
            "observed": self.observed,
            "operator": self.operator,
            "threshold": self.threshold,
            "passed": self.passed,
        }


@dataclass(frozen=True)
class GateDecision:
    contract_id: str
    candidate_id: str
    incumbent_id: Optional[str]
    evidence_count: int
    passed: bool
    results: Tuple[CriterionResult, ...]
    control_ids: Tuple[str, ...] = ()

    @property
    def decision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_id": self.contract_id,
            "candidate_id": self.candidate_id,
            "incumbent_id": self.incumbent_id,
            "control_ids": list(self.control_ids),
            "evidence_count": self.evidence_count,
            "passed": self.passed,
            "results": [result.as_dict() for result in self.results],
        }
        if include_id:
            value["decision_id"] = self.decision_id
        return value


def _compare(observed: float, operator: str, threshold: float) -> bool:
    if operator == "<":
        return observed < threshold
    if operator == "<=":
        return observed <= threshold
    if operator == "==":
        return observed == threshold
    if operator == ">=":
        return observed >= threshold
    if operator == ">":
        return observed > threshold
    raise ValueError("unsupported gate operator")


def evaluate_gate(
    contract: GateContract,
    candidate_id: str,
    incumbent_id: Optional[str],
    metrics: Mapping[str, float],
    evidence_count: int,
    *,
    control_ids: Tuple[str, ...] = (),
) -> GateDecision:
    if evidence_count < contract.minimum_evidence_count:
        raise ValueError("insufficient evidence for gate contract")
    missing = {
        criterion.metric
        for criterion in contract.criteria
        if criterion.metric not in metrics
    }
    if missing:
        raise ValueError(
            "missing gate metrics: %s" % ", ".join(sorted(missing))
        )
    results = tuple(
        CriterionResult(
            metric=criterion.metric,
            observed=float(metrics[criterion.metric]),
            operator=criterion.operator,
            threshold=criterion.threshold,
            passed=_compare(
                float(metrics[criterion.metric]),
                criterion.operator,
                criterion.threshold,
            ),
        )
        for criterion in contract.criteria
    )
    resolved_controls = control_ids or (
        () if incumbent_id is None else (incumbent_id,)
    )
    if len(set(resolved_controls)) != len(resolved_controls):
        raise ValueError("gate control identities must be unique")
    return GateDecision(
        contract_id=contract.contract_id,
        candidate_id=candidate_id,
        incumbent_id=incumbent_id,
        evidence_count=evidence_count,
        passed=all(result.passed for result in results),
        results=results,
        control_ids=resolved_controls,
    )
