from __future__ import annotations

from dataclasses import dataclass
from typing import (
    Any,
    Dict,
    Generic,
    Iterable,
    Mapping,
    Optional,
    Protocol,
    runtime_checkable,
    Sequence,
    Tuple,
    TypeVar,
)

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import (
    EvidencePartition,
    ExecutionMode,
    SearchFamily,
)
from scientist.kernel.capabilities import DomainCapabilityManifest


CandidateT = TypeVar("CandidateT")
ExperimentT = TypeVar("ExperimentT")
ObservationT = TypeVar("ObservationT")
FailureT = TypeVar("FailureT")


@dataclass(frozen=True)
class VerificationResult:
    passed: bool
    checks: Mapping[str, bool]
    details: Mapping[str, Any]
    verifier_ref: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "checks": dict(sorted(self.checks.items())),
            "details": dict(self.details),
            "verifier_ref": self.verifier_ref,
        }


@dataclass(frozen=True)
class PairedComparison:
    candidate_id: str
    incumbent_id: str
    experiment_id: str
    metrics: Mapping[str, float]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "incumbent_id": self.incumbent_id,
            "experiment_id": self.experiment_id,
            "metrics": dict(sorted(self.metrics.items())),
        }


@dataclass(frozen=True)
class ControlledComparison:
    """Metrics for a subject relative to any number of declared controls."""

    subject_id: str
    control_ids: Tuple[str, ...]
    experiment_id: str
    metrics: Mapping[str, float]

    def __post_init__(self) -> None:
        if not self.subject_id or not self.control_ids or not self.experiment_id:
            raise ValueError("controlled comparison identity is incomplete")
        if len(set(self.control_ids)) != len(self.control_ids):
            raise ValueError("controlled comparison controls must be unique")
        if not self.metrics:
            raise ValueError("controlled comparison metrics are empty")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "subject_id": self.subject_id,
            "control_ids": list(self.control_ids),
            "experiment_id": self.experiment_id,
            "metrics": dict(sorted(self.metrics.items())),
        }


class OptimizationDomainAdapter(
    Protocol[CandidateT, ExperimentT, ObservationT, FailureT]
):
    """Optional legacy surface for paired optimization laboratories."""

    domain_id: str
    adapter_version: str
    evaluator_ref: str
    verifier_ref: str
    execution_mode: ExecutionMode
    capabilities: DomainCapabilityManifest

    def candidate_id(self, candidate: CandidateT) -> str:
        ...

    def candidate_as_dict(self, candidate: CandidateT) -> Mapping[str, Any]:
        ...

    def experiment_id(self, experiment: ExperimentT) -> str:
        ...

    def experiment_as_dict(
        self,
        experiment: ExperimentT,
    ) -> Mapping[str, Any]:
        ...

    def observation_as_dict(
        self,
        observation: ObservationT,
    ) -> Mapping[str, Any]:
        ...

    def observation_id(self, observation: ObservationT) -> str:
        ...

    def evaluate(
        self,
        candidate: CandidateT,
        experiment: ExperimentT,
    ) -> ObservationT:
        ...

    def verify(
        self,
        experiment: ExperimentT,
        observation: ObservationT,
    ) -> VerificationResult:
        ...

    def compare(
        self,
        candidate: CandidateT,
        incumbent: CandidateT,
        experiment: ExperimentT,
    ) -> PairedComparison:
        ...

    def behavior_fingerprint(
        self,
        candidate: CandidateT,
        experiments: Iterable[ExperimentT],
    ) -> str:
        ...

    def minimize_failure(
        self,
        experiment: ExperimentT,
        better: CandidateT,
        worse: CandidateT,
    ) -> FailureT:
        ...

    def search_families(self) -> Tuple[SearchFamily, ...]:
        ...


# Backward-compatible name. Universal runtimes depend on CoreDomainAdapter;
# this larger interface is never a requirement for estimation, proof,
# explanation, synthesis, or verification domains.
DomainAdapter = OptimizationDomainAdapter


class CoreDomainAdapter(
    Protocol[CandidateT, ExperimentT, ObservationT]
):
    """Minimum authority every domain must implement.

    Comparison, behavioral identity, failure minimization, training, and
    intervention are intentionally separate optional protocols below.
    """

    domain_id: str
    adapter_version: str
    evaluator_ref: str
    verifier_ref: str
    execution_mode: ExecutionMode
    capabilities: DomainCapabilityManifest

    def candidate_id(self, candidate: CandidateT) -> str:
        ...

    def candidate_as_dict(self, candidate: CandidateT) -> Mapping[str, Any]:
        ...

    def experiment_id(self, experiment: ExperimentT) -> str:
        ...

    def experiment_as_dict(self, experiment: ExperimentT) -> Mapping[str, Any]:
        ...

    def observation_as_dict(self, observation: ObservationT) -> Mapping[str, Any]:
        ...

    def observation_id(self, observation: ObservationT) -> str:
        ...

    def evaluate(self, candidate: CandidateT, experiment: ExperimentT) -> ObservationT:
        ...

    def verify(
        self,
        experiment: ExperimentT,
        observation: ObservationT,
    ) -> VerificationResult:
        ...


@runtime_checkable
class PairedComparator(Protocol[CandidateT, ExperimentT]):
    def compare(
        self,
        candidate: CandidateT,
        incumbent: CandidateT,
        experiment: ExperimentT,
    ) -> PairedComparison:
        ...


@runtime_checkable
class ControlledComparator(Protocol[CandidateT, ExperimentT]):
    def compare_controls(
        self,
        subject: CandidateT,
        controls: Sequence[CandidateT],
        experiment: ExperimentT,
    ) -> ControlledComparison:
        ...


@runtime_checkable
class BehaviorCharacterizer(Protocol[CandidateT, ExperimentT]):
    def behavior_fingerprint(
        self,
        candidate: CandidateT,
        experiments: Iterable[ExperimentT],
    ) -> str:
        ...


@runtime_checkable
class FailureMinimizer(
    Protocol[CandidateT, ExperimentT, FailureT]
):
    def minimize_failure(
        self,
        experiment: ExperimentT,
        better: CandidateT,
        worse: CandidateT,
    ) -> FailureT:
        ...


@runtime_checkable
class CandidateCodec(Protocol[CandidateT]):
    def candidate_from_dict(self, value: Mapping[str, Any]) -> CandidateT:
        ...


@runtime_checkable
class ExperimentCodec(Protocol[ExperimentT]):
    def experiment_from_dict(self, value: Mapping[str, Any]) -> ExperimentT:
        ...


@runtime_checkable
class ObservationMetricExtractor(
    Protocol[ExperimentT, ObservationT]
):
    def observation_metrics(
        self,
        experiment: ExperimentT,
        observation: ObservationT,
    ) -> Mapping[str, float]:
        ...


@runtime_checkable
class ContextualMetricExtractor(
    Protocol[CandidateT, ExperimentT, ObservationT]
):
    def measurement_metrics(
        self,
        subject: CandidateT,
        controls: Sequence[CandidateT],
        experiment: ExperimentT,
        observation: ObservationT,
    ) -> Mapping[str, float]:
        ...


@runtime_checkable
class DomainEvidenceAnalyzer(Protocol):
    def analyze_evidence(
        self,
        metric_rows: Sequence[Mapping[str, float]],
        experiment_ids: Sequence[str],
        analysis_contract: Any,
    ) -> Mapping[str, float]:
        ...


@dataclass(frozen=True)
class ProposalContext(Generic[CandidateT, ExperimentT]):
    cycle_id: str
    round_index: int
    family: SearchFamily | str
    incumbent: CandidateT | None
    repair_experiments: Tuple[ExperimentT, ...]
    guard_experiments: Tuple[ExperimentT, ...]
    archive: Tuple[CandidateT, ...]
    issue_labels: Tuple[str, ...]
    evaluation_budget: int


class ProposalEngine(Protocol[CandidateT, ExperimentT]):
    name: str
    engine_version: str

    def propose(
        self,
        context: ProposalContext[CandidateT, ExperimentT],
    ) -> Sequence[CandidateT]:
        ...


@dataclass(frozen=True)
class ResearchObjectProposalContext(Generic[CandidateT, ExperimentT]):
    """Proposal context without optimization or incumbent assumptions."""

    cycle_id: str
    round_index: int
    discovery_channel: str
    reference_objects: Tuple[CandidateT, ...]
    adaptive_evidence: Tuple[ExperimentT, ...]
    guard_evidence: Tuple[ExperimentT, ...]
    archive: Tuple[CandidateT, ...]
    issue_labels: Tuple[str, ...]
    evaluation_budget: int

    def __post_init__(self) -> None:
        if (
            not self.cycle_id
            or not self.discovery_channel
            or self.round_index < 0
            or self.evaluation_budget <= 0
        ):
            raise ValueError("research-object proposal context is invalid")


@dataclass(frozen=True)
class ExperimentRequest:
    partition: EvidencePartition
    count: int
    seed_start: int
    difficulty: str
    mechanism_tags: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.count <= 0:
            raise ValueError("experiment count must be positive")
        if not self.difficulty:
            raise ValueError("difficulty must not be empty")


@dataclass(frozen=True)
class EvidenceRequest:
    """Domain-neutral request for proof tasks, datasets, probes, or trials."""

    partition: EvidencePartition
    count: int
    parameters: Mapping[str, Any]
    strata: Tuple[str, ...] = ()
    request_ref: str = "generic-evidence-request-v1"

    def __post_init__(self) -> None:
        if self.count <= 0 or not self.request_ref:
            raise ValueError("evidence request identity and count are required")
        if len(set(self.strata)) != len(self.strata):
            raise ValueError("evidence request strata must be unique")

    @property
    def request_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "partition": self.partition.value,
            "count": self.count,
            "parameters": dict(self.parameters),
            "strata": list(self.strata),
            "request_ref": self.request_ref,
        }
        if include_id:
            value["request_id"] = self.request_id
        return value


class EvidenceTaskFactory(Protocol[ExperimentT]):
    name: str
    factory_version: str

    def generate_evidence(
        self,
        request: EvidenceRequest,
    ) -> Sequence[ExperimentT]:
        ...


class ExperimentFactory(Protocol[ExperimentT]):
    name: str
    factory_version: str

    def generate(
        self,
        request: ExperimentRequest,
    ) -> Sequence[ExperimentT]:
        ...
