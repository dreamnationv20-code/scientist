from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Mapping, Optional, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.kernel.contracts import ARCHITECTURE_VERSION


class LedgerEventKind(str, Enum):
    CYCLE_STARTED = "cycle_started"
    CHARTER_REGISTERED = "charter_registered"
    CAMPAIGN_REGISTERED = "campaign_registered"
    PROBE_PREREGISTERED = "probe_preregistered"
    REVIEW_PROTOCOL_REGISTERED = "review_protocol_registered"
    BENCHMARK_EXPOSED = "benchmark_exposed"
    CANDIDATE_PROPOSED = "candidate_proposed"
    CANDIDATE_EVALUATED = "candidate_evaluated"
    FAILURE_MINED = "failure_mined"
    HYPOTHESIS_UPDATED = "hypothesis_updated"
    PROBE_ASSESSED = "probe_assessed"
    ADVERSARIAL_REVIEW_COMPLETED = "adversarial_review_completed"
    AUDIT_COMPLETED = "audit_completed"
    DEPLOYMENT_DECIDED = "deployment_decided"
    REPLICATION_NOMINATED = "replication_nominated"
    REPLICATION_COMPLETED = "replication_completed"
    INCUMBENT_ADVANCED = "incumbent_advanced"
    CLAIM_FROZEN = "claim_frozen"
    CONFIRMATION_OPENED = "confirmation_opened"
    CONFIRMATION_COMPLETED = "confirmation_completed"
    PLATEAU_DECLARED = "plateau_declared"
    CYCLE_COMPLETED = "cycle_completed"


DEVELOPMENT_MUTATIONS = {
    LedgerEventKind.PROBE_PREREGISTERED,
    LedgerEventKind.REVIEW_PROTOCOL_REGISTERED,
    LedgerEventKind.ADVERSARIAL_REVIEW_COMPLETED,
    LedgerEventKind.CANDIDATE_PROPOSED,
    LedgerEventKind.CANDIDATE_EVALUATED,
    LedgerEventKind.FAILURE_MINED,
    LedgerEventKind.HYPOTHESIS_UPDATED,
}


def _candidate_matches(
    event: "LedgerEvent",
    candidate_id: str,
) -> bool:
    return bool(candidate_id) and (
        event.payload.get("candidate_id") == candidate_id
    )


@dataclass(frozen=True)
class LedgerEvent:
    sequence: int
    cycle_id: str
    kind: LedgerEventKind
    payload: Mapping[str, Any]
    actor_ref: str
    previous_event_id: Optional[str]

    @property
    def event_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": ARCHITECTURE_VERSION,
            "sequence": self.sequence,
            "cycle_id": self.cycle_id,
            "kind": self.kind.value,
            "payload": dict(self.payload),
            "actor_ref": self.actor_ref,
            "previous_event_id": self.previous_event_id,
        }
        if include_id:
            value["event_id"] = self.event_id
        return value


class ScientificLedger:
    """Append-only event chain enforcing the main scientific firewalls."""

    def __init__(
        self,
        artifact_store: Optional[ArtifactStore] = None,
    ) -> None:
        self._events: List[LedgerEvent] = []
        self._artifact_store = artifact_store
        self._artifact_digests: List[str] = []

    @property
    def events(self) -> Tuple[LedgerEvent, ...]:
        return tuple(self._events)

    @property
    def artifact_digests(self) -> Tuple[str, ...]:
        return tuple(self._artifact_digests)

    def _cycle_events(self, cycle_id: str) -> Tuple[LedgerEvent, ...]:
        return tuple(
            event for event in self._events if event.cycle_id == cycle_id
        )

    def append(
        self,
        cycle_id: str,
        kind: LedgerEventKind,
        payload: Mapping[str, Any],
        actor_ref: str,
    ) -> LedgerEvent:
        if not cycle_id or not actor_ref:
            raise ValueError("cycle_id and actor_ref must not be empty")
        cycle_events = self._cycle_events(cycle_id)
        if not cycle_events and kind != LedgerEventKind.CYCLE_STARTED:
            raise ValueError("the first cycle event must be cycle_started")
        if cycle_events and kind == LedgerEventKind.CYCLE_STARTED:
            raise ValueError("cycle_started may occur only once per cycle")
        if kind == LedgerEventKind.CAMPAIGN_REGISTERED and not any(
            event.kind == LedgerEventKind.CHARTER_REGISTERED
            for event in cycle_events
        ):
            raise ValueError("campaign registration requires a charter")
        if kind in DEVELOPMENT_MUTATIONS and not any(
            event.kind == LedgerEventKind.CAMPAIGN_REGISTERED
            for event in cycle_events
        ):
            raise ValueError(
                "development requires a registered campaign contract"
            )
        frozen = any(
            event.kind
            in (
                LedgerEventKind.CLAIM_FROZEN,
                LedgerEventKind.CONFIRMATION_OPENED,
            )
            for event in cycle_events
        )
        if frozen and kind in DEVELOPMENT_MUTATIONS:
            raise ValueError(
                "development cannot mutate a frozen confirmation cycle"
            )
        if kind == LedgerEventKind.CONFIRMATION_OPENED and not any(
            event.kind == LedgerEventKind.CLAIM_FROZEN
            for event in cycle_events
        ):
            raise ValueError("confirmation requires a frozen claim")
        candidate_id = str(payload.get("candidate_id", ""))
        if kind == LedgerEventKind.PROBE_PREREGISTERED:
            proposed = any(
                event.kind == LedgerEventKind.CANDIDATE_PROPOSED
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            if not proposed or not payload.get("protocol_id"):
                raise ValueError(
                    "probe preregistration requires a proposed research object"
                )
        if kind == LedgerEventKind.REVIEW_PROTOCOL_REGISTERED:
            proposed = any(
                event.kind == LedgerEventKind.CANDIDATE_PROPOSED
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            if not proposed or not payload.get("protocol_id"):
                raise ValueError(
                    "review protocol requires a proposed research object"
                )
        if kind == LedgerEventKind.ADVERSARIAL_REVIEW_COMPLETED:
            protocol_id = payload.get("protocol_id")
            registered = any(
                event.kind == LedgerEventKind.REVIEW_PROTOCOL_REGISTERED
                and event.payload.get("protocol_id") == protocol_id
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            if not registered or not payload.get("round_id"):
                raise ValueError(
                    "adversarial review requires a matching protocol"
                )
        if kind == LedgerEventKind.PROBE_ASSESSED:
            protocol_id = payload.get("protocol_id")
            preregistered = any(
                event.kind == LedgerEventKind.PROBE_PREREGISTERED
                and event.payload.get("protocol_id") == protocol_id
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            if not preregistered:
                raise ValueError(
                    "probe assessment requires a matching preregistration"
                )
        if kind in (
            LedgerEventKind.AUDIT_COMPLETED,
            LedgerEventKind.DEPLOYMENT_DECIDED,
        ):
            evaluated = any(
                event.kind == LedgerEventKind.CANDIDATE_EVALUATED
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            if not evaluated:
                raise ValueError(
                    "%s requires prior candidate evaluation"
                    % kind.value
                )
        if kind == LedgerEventKind.REPLICATION_NOMINATED:
            audited = any(
                event.kind == LedgerEventKind.AUDIT_COMPLETED
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            if not audited:
                raise ValueError(
                    "replication nomination requires a candidate audit"
                )
        if kind == LedgerEventKind.CLAIM_FROZEN:
            nominated = any(
                event.kind == LedgerEventKind.REPLICATION_NOMINATED
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            if not nominated:
                raise ValueError(
                    "candidate claim freeze requires replication nomination"
                )
        if kind == LedgerEventKind.REPLICATION_COMPLETED:
            nominated = any(
                event.kind == LedgerEventKind.REPLICATION_NOMINATED
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            claim_frozen = any(
                event.kind == LedgerEventKind.CLAIM_FROZEN
                and _candidate_matches(event, candidate_id)
                for event in cycle_events
            )
            if not nominated or not claim_frozen:
                raise ValueError(
                    "replication requires nomination and a frozen claim"
                )
        if kind == LedgerEventKind.CONFIRMATION_COMPLETED and not any(
            event.kind == LedgerEventKind.CONFIRMATION_OPENED
            for event in cycle_events
        ):
            raise ValueError(
                "external confirmation must be explicitly opened"
            )
        if kind == LedgerEventKind.INCUMBENT_ADVANCED:
            confirmed = any(
                event.kind
                in (
                    LedgerEventKind.REPLICATION_COMPLETED,
                    LedgerEventKind.CONFIRMATION_COMPLETED,
                )
                and event.payload.get("passed") is True
                and event.payload.get("candidate_id") == candidate_id
                for event in cycle_events
            )
            if not candidate_id or not confirmed:
                raise ValueError(
                    "incumbent advance requires successful independent "
                    "replication or external confirmation"
                )
        event = LedgerEvent(
            sequence=len(self._events),
            cycle_id=cycle_id,
            kind=kind,
            payload=dict(payload),
            actor_ref=actor_ref,
            previous_event_id=(
                self._events[-1].event_id if self._events else None
            ),
        )
        self._events.append(event)
        if self._artifact_store is not None:
            self._artifact_digests.append(
                self._artifact_store.put(
                    "scientific_ledger_event",
                    event.as_dict(),
                )
            )
        return event

    def verify_chain(self) -> bool:
        previous = None
        for sequence, event in enumerate(self._events):
            if event.sequence != sequence:
                return False
            if event.previous_event_id != previous:
                return False
            previous = event.event_id
        return True

    def as_dict(self) -> Dict[str, Any]:
        return {
            "architecture_version": ARCHITECTURE_VERSION,
            "event_count": len(self._events),
            "chain_valid": self.verify_chain(),
            "head_event_id": (
                self._events[-1].event_id if self._events else None
            ),
            "events": [event.as_dict() for event in self._events],
            "artifact_digests": list(self._artifact_digests),
        }
