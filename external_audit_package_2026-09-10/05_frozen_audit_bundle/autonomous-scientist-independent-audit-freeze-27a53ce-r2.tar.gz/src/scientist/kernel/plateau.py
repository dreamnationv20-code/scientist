from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Sequence, Tuple


class PlateauKind(str, Enum):
    NONE = "none"
    INSUFFICIENT_HISTORY = "insufficient_history"
    EXPERIMENT_SPACE = "experiment_space"
    FAILURE_ABSTRACTION = "failure_abstraction"
    REPRESENTATION_SPACE = "representation_space"
    PROPOSAL_SPACE = "proposal_space"
    GENERALIZATION = "generalization"
    EVIDENCE_POWER = "evidence_power"


@dataclass(frozen=True)
class CampaignOutcomeSummary:
    campaign_id: str
    candidates_evaluated: int
    discriminating_failures: int
    transferred_failures: int
    novel_behaviors: int
    audit_improvements: int
    replication_nominations: int
    replication_attempts: int
    successful_replications: int
    replication_power_sufficient: bool

    def __post_init__(self) -> None:
        counts = (
            self.candidates_evaluated,
            self.discriminating_failures,
            self.transferred_failures,
            self.novel_behaviors,
            self.audit_improvements,
            self.replication_nominations,
            self.replication_attempts,
            self.successful_replications,
        )
        if not self.campaign_id:
            raise ValueError("campaign_id must not be empty")
        if min(counts) < 0:
            raise ValueError("campaign counts must be non-negative")
        if self.successful_replications > self.replication_attempts:
            raise ValueError(
                "successful_replications cannot exceed attempts"
            )
        if self.replication_attempts > self.replication_nominations:
            raise ValueError(
                "replication_attempts cannot exceed nominations"
            )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "campaign_id": self.campaign_id,
            "candidates_evaluated": self.candidates_evaluated,
            "discriminating_failures": self.discriminating_failures,
            "transferred_failures": self.transferred_failures,
            "novel_behaviors": self.novel_behaviors,
            "audit_improvements": self.audit_improvements,
            "replication_nominations": self.replication_nominations,
            "replication_attempts": self.replication_attempts,
            "successful_replications": self.successful_replications,
            "replication_power_sufficient": (
                self.replication_power_sufficient
            ),
        }


@dataclass(frozen=True)
class PlateauPolicy:
    campaign_window: int = 2
    minimum_candidates_per_campaign: int = 1

    def __post_init__(self) -> None:
        if self.campaign_window < 2:
            raise ValueError("campaign_window must be at least two")
        if self.minimum_candidates_per_campaign <= 0:
            raise ValueError(
                "minimum_candidates_per_campaign must be positive"
            )


@dataclass(frozen=True)
class PlateauDiagnosis:
    kind: PlateauKind
    campaign_ids: Tuple[str, ...]
    reason: str
    required_change: str
    totals: Dict[str, int]

    @property
    def is_plateau(self) -> bool:
        return self.kind not in (
            PlateauKind.NONE,
            PlateauKind.INSUFFICIENT_HISTORY,
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind.value,
            "is_plateau": self.is_plateau,
            "campaign_ids": list(self.campaign_ids),
            "reason": self.reason,
            "required_change": self.required_change,
            "totals": dict(self.totals),
        }


def diagnose_plateau(
    outcomes: Sequence[CampaignOutcomeSummary],
    policy: PlateauPolicy = PlateauPolicy(),
) -> PlateauDiagnosis:
    """Classify why repeated full campaigns did not advance the incumbent.

    A diagnosis is deliberately tied to a required architectural change.
    "Run the same search longer" is not a valid response to a detected
    plateau.
    """

    if len(outcomes) < policy.campaign_window:
        return PlateauDiagnosis(
            kind=PlateauKind.INSUFFICIENT_HISTORY,
            campaign_ids=tuple(outcome.campaign_id for outcome in outcomes),
            reason="too few completed campaigns to infer a plateau",
            required_change="complete the preregistered campaign window",
            totals={},
        )

    window = tuple(outcomes[-policy.campaign_window :])
    totals = {
        field: sum(int(getattr(outcome, field)) for outcome in window)
        for field in (
            "candidates_evaluated",
            "discriminating_failures",
            "transferred_failures",
            "novel_behaviors",
            "audit_improvements",
            "replication_nominations",
            "replication_attempts",
            "successful_replications",
        )
    }
    campaign_ids = tuple(outcome.campaign_id for outcome in window)

    if totals["successful_replications"] > 0:
        return PlateauDiagnosis(
            kind=PlateauKind.NONE,
            campaign_ids=campaign_ids,
            reason="the window contains a replicated incumbent advancement",
            required_change="continue from the confirmed incumbent",
            totals=totals,
        )

    budgets_complete = all(
        outcome.candidates_evaluated
        >= policy.minimum_candidates_per_campaign
        for outcome in window
    )
    if not budgets_complete:
        return PlateauDiagnosis(
            kind=PlateauKind.INSUFFICIENT_HISTORY,
            campaign_ids=campaign_ids,
            reason="one or more campaigns did not spend the minimum budget",
            required_change="finish the matched campaign budgets",
            totals=totals,
        )

    if totals["discriminating_failures"] == 0:
        return PlateauDiagnosis(
            kind=PlateauKind.EXPERIMENT_SPACE,
            campaign_ids=campaign_ids,
            reason="the experiment generator found no incumbent failures",
            required_change=(
                "change the experiment generator, sensors, or problem regime"
            ),
            totals=totals,
        )

    if totals["transferred_failures"] == 0:
        return PlateauDiagnosis(
            kind=PlateauKind.FAILURE_ABSTRACTION,
            campaign_ids=campaign_ids,
            reason="failures were found but no mechanism transferred",
            required_change=(
                "change failure clustering, minimization, or causal features"
            ),
            totals=totals,
        )

    if totals["novel_behaviors"] == 0:
        return PlateauDiagnosis(
            kind=PlateauKind.REPRESENTATION_SPACE,
            campaign_ids=campaign_ids,
            reason="the proposer produced no behaviorally novel candidates",
            required_change=(
                "expand the candidate representation or action vocabulary"
            ),
            totals=totals,
        )

    if totals["audit_improvements"] == 0:
        return PlateauDiagnosis(
            kind=PlateauKind.PROPOSAL_SPACE,
            campaign_ids=campaign_ids,
            reason=(
                "transferable failures and novel candidates did not produce "
                "an audit improvement"
            ),
            required_change=(
                "change the proposal engine or its causal repair objective"
            ),
            totals=totals,
        )

    if totals["replication_attempts"] == 0 or not all(
        outcome.replication_power_sufficient
        for outcome in window
        if outcome.replication_nominations > 0
    ):
        return PlateauDiagnosis(
            kind=PlateauKind.EVIDENCE_POWER,
            campaign_ids=campaign_ids,
            reason=(
                "directional audit effects were not tested with adequate "
                "independent evidence"
            ),
            required_change=(
                "increase replication power or complete frozen replication"
            ),
            totals=totals,
        )

    return PlateauDiagnosis(
        kind=PlateauKind.GENERALIZATION,
        campaign_ids=campaign_ids,
        reason="audit improvements failed adequately powered replication",
        required_change=(
            "revise the causal hypothesis or claimed domain of validity"
        ),
        totals=totals,
    )
