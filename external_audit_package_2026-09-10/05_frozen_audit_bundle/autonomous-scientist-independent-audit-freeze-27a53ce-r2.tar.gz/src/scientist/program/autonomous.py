from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Protocol, Tuple

from scientist.program.control_plane import ControlAction
from scientist.program.goal_graph_runtime import GoalGraphRuntime


AUTONOMOUS_GOAL_EXECUTIVE_VERSION = "autonomous-goal-executive-v1"


@dataclass(frozen=True)
class ActionDispatchResult:
    progressed: bool
    stop: bool
    outcome: str
    details: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.outcome:
            raise ValueError("action-dispatch outcome must not be empty")
        if self.progressed and self.stop:
            raise ValueError(
                "a progressing dispatch cannot simultaneously stop the loop"
            )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "progressed": self.progressed,
            "stop": self.stop,
            "outcome": self.outcome,
            "details": dict(self.details),
        }


class GoalActionHandler(Protocol):
    name: str

    def dispatch(
        self,
        action: ControlAction,
        runtime: GoalGraphRuntime,
    ) -> ActionDispatchResult:
        ...


@dataclass(frozen=True)
class GoalExecutiveStep:
    step_index: int
    action: ControlAction
    before_memory_head: str
    after_memory_head: str
    dispatch: ActionDispatchResult

    def as_dict(self) -> Dict[str, Any]:
        return {
            "step_index": self.step_index,
            "action": self.action.as_dict(),
            "before_memory_head": self.before_memory_head,
            "after_memory_head": self.after_memory_head,
            "dispatch": self.dispatch.as_dict(),
        }


@dataclass(frozen=True)
class GoalExecutiveOutcome:
    boundary: str
    steps: Tuple[GoalExecutiveStep, ...]
    status: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "executive_version": AUTONOMOUS_GOAL_EXECUTIVE_VERSION,
            "boundary": self.boundary,
            "steps": [step.as_dict() for step in self.steps],
            "status": dict(self.status),
        }


class AutonomousGoalExecutive:
    """Consume control-plane actions until a durable scientific boundary."""

    def __init__(
        self,
        runtime: GoalGraphRuntime,
        handler: GoalActionHandler,
    ) -> None:
        self.runtime = runtime
        self.handler = handler

    def run(self, max_steps: int = 8) -> GoalExecutiveOutcome:
        if max_steps <= 0:
            raise ValueError("autonomous executive max_steps must be positive")
        steps = []
        for step_index in range(max_steps):
            control = self.runtime.control_plane
            if control.resolution is not None:
                return GoalExecutiveOutcome(
                    boundary="root_resolved",
                    steps=tuple(steps),
                    status=self.runtime.status(),
                )
            actions = control.next_actions()
            if not actions:
                return GoalExecutiveOutcome(
                    boundary="no_control_action",
                    steps=tuple(steps),
                    status=self.runtime.status(),
                )
            action = actions[0]
            before = control.memory.events[-1].event_id
            dispatch = self.handler.dispatch(action, self.runtime)
            after = control.memory.events[-1].event_id
            if dispatch.progressed and after == before:
                raise ValueError(
                    "action handler claimed progress without a durable event"
                )
            steps.append(
                GoalExecutiveStep(
                    step_index=step_index,
                    action=action,
                    before_memory_head=before,
                    after_memory_head=after,
                    dispatch=dispatch,
                )
            )
            if dispatch.stop:
                return GoalExecutiveOutcome(
                    boundary=dispatch.outcome,
                    steps=tuple(steps),
                    status=self.runtime.status(),
                )
        return GoalExecutiveOutcome(
            boundary="step_budget_exhausted",
            steps=tuple(steps),
            status=self.runtime.status(),
        )
