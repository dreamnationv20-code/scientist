from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import (
    EvidencePartition,
    GateContract,
    GateKind,
    SearchFamily,
)
from scientist.kernel.gates import GateDecision, evaluate_gate
from scientist.program.goal_graph import GOAL_GRAPH_ARCHITECTURE_VERSION
from scientist.program.causal_failure import CausalFailureModelSet
from scientist.program.research_strategy import (
    ResearchProgramDiagnosis,
    StrategyDisposition,
)


class IncumbentRole(str, Enum):
    NULL = "null"
    CHEAPEST_CREDIBLE = "cheapest_credible"
    BEST_PUBLISHED_COMPONENT = "best_published_component"
    BEST_END_TO_END = "best_end_to_end"
    ORACLE_UPPER_BOUND = "oracle_upper_bound"


@dataclass(frozen=True)
class IncumbentEntry:
    candidate_id: str
    name: str
    role: IncumbentRole
    executable_digest: str
    source_locator: str
    reproduction_evidence_ids: Tuple[str, ...]
    metric_summary: Mapping[str, float]
    source_work_id: Optional[str] = None
    limitations: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not all(
            (
                self.candidate_id,
                self.name,
                self.executable_digest,
                self.source_locator,
            )
        ):
            raise ValueError("incumbent-entry fields must not be empty")
        if not self.metric_summary:
            raise ValueError("incumbent entries require measured metrics")

    @property
    def reproduced(self) -> bool:
        return bool(self.reproduction_evidence_ids)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "name": self.name,
            "role": self.role.value,
            "executable_digest": self.executable_digest,
            "source_locator": self.source_locator,
            "source_work_id": self.source_work_id,
            "reproduction_evidence_ids": list(
                self.reproduction_evidence_ids
            ),
            "reproduced": self.reproduced,
            "metric_summary": dict(sorted(self.metric_summary.items())),
            "limitations": list(self.limitations),
        }


@dataclass(frozen=True)
class IncumbentPortfolio:
    node_id: str
    literature_assessment_id: str
    entries: Tuple[IncumbentEntry, ...]
    primary_incumbent_id: str
    selection_rationale: str
    baseline_uncertain: bool = False
    uncertainty_reasons: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.literature_assessment_id,
                self.primary_incumbent_id,
                self.selection_rationale,
            )
        ):
            raise ValueError("incumbent-portfolio fields must not be empty")
        if not self.entries:
            raise ValueError("incumbent portfolio requires entries")
        ids = tuple(entry.candidate_id for entry in self.entries)
        if len(set(ids)) != len(ids):
            raise ValueError("incumbent candidate IDs must be unique")
        if self.primary_incumbent_id not in ids:
            raise ValueError("primary incumbent is absent from the portfolio")
        roles = {entry.role for entry in self.entries}
        if IncumbentRole.NULL not in roles:
            raise ValueError("incumbent portfolio requires a null baseline")
        if not roles.intersection(
            {
                IncumbentRole.BEST_PUBLISHED_COMPONENT,
                IncumbentRole.BEST_END_TO_END,
            }
        ):
            raise ValueError(
                "portfolio requires a published component or end-to-end baseline"
            )
        primary = next(
            entry
            for entry in self.entries
            if entry.candidate_id == self.primary_incumbent_id
        )
        if not primary.reproduced:
            raise ValueError(
                "the primary incumbent must be reproduced before search"
            )
        if self.baseline_uncertain and not self.uncertainty_reasons:
            raise ValueError(
                "baseline uncertainty requires explicit reasons"
            )
        if not self.baseline_uncertain and self.uncertainty_reasons:
            raise ValueError(
                "a closed portfolio cannot retain uncertainty reasons"
            )

    @property
    def primary(self) -> IncumbentEntry:
        return next(
            entry
            for entry in self.entries
            if entry.candidate_id == self.primary_incumbent_id
        )

    @property
    def closed(self) -> bool:
        return not self.baseline_uncertain

    @property
    def portfolio_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "node_id": self.node_id,
            "literature_assessment_id": self.literature_assessment_id,
            "entries": [entry.as_dict() for entry in self.entries],
            "primary_incumbent_id": self.primary_incumbent_id,
            "selection_rationale": self.selection_rationale,
            "baseline_uncertain": self.baseline_uncertain,
            "uncertainty_reasons": list(self.uncertainty_reasons),
            "closed": self.closed,
        }
        if include_id:
            value["portfolio_id"] = self.portfolio_id
        return value


class InformationChannel(str, Enum):
    PROBLEM_CONTRACT = "problem_contract"
    LITERATURE_FACTS = "literature_facts"
    NOVELTY_EXCLUSIONS = "novelty_exclusions"
    INCUMBENT_CODE = "incumbent_code"
    INCUMBENT_REASONING = "incumbent_reasoning"
    INCUMBENT_ERROR_LEDGER = "incumbent_error_ledger"
    DEAD_IDEA_LEDGER = "dead_idea_ledger"
    SURVIVOR_MECHANISMS = "survivor_mechanisms"


def default_information_views() -> Mapping[
    SearchFamily, Tuple[InformationChannel, ...]
]:
    return {
        SearchFamily.ANCESTRY: (
            InformationChannel.PROBLEM_CONTRACT,
            InformationChannel.LITERATURE_FACTS,
            InformationChannel.NOVELTY_EXCLUSIONS,
            InformationChannel.INCUMBENT_CODE,
            InformationChannel.INCUMBENT_REASONING,
            InformationChannel.INCUMBENT_ERROR_LEDGER,
            InformationChannel.DEAD_IDEA_LEDGER,
        ),
        SearchFamily.DE_NOVO: (
            InformationChannel.PROBLEM_CONTRACT,
            InformationChannel.LITERATURE_FACTS,
            InformationChannel.NOVELTY_EXCLUSIONS,
        ),
        SearchFamily.HYBRID: (
            InformationChannel.PROBLEM_CONTRACT,
            InformationChannel.LITERATURE_FACTS,
            InformationChannel.NOVELTY_EXCLUSIONS,
            InformationChannel.INCUMBENT_CODE,
            InformationChannel.INCUMBENT_ERROR_LEDGER,
            InformationChannel.DEAD_IDEA_LEDGER,
            InformationChannel.SURVIVOR_MECHANISMS,
        ),
    }


@dataclass(frozen=True)
class IslandCampaignContract:
    node_id: str
    leaf_contract_id: str
    incumbent_portfolio_id: str
    evaluator_ref: str
    verifier_ref: str
    quarantined_test_ref: str
    total_compute_budget: float
    max_rounds: int
    cycle_index: int = 0
    isolation_rounds: int = 1
    search_families: Tuple[SearchFamily, ...] = (
        SearchFamily.ANCESTRY,
        SearchFamily.DE_NOVO,
        SearchFamily.HYBRID,
    )
    information_views: Mapping[
        SearchFamily, Tuple[InformationChannel, ...]
    ] = field(default_factory=default_information_views)
    gates: Tuple[GateContract, ...] = ()
    selected_hypothesis_id: str | None = None
    selected_executable_digest: str | None = None
    selected_diagnostic_id: str | None = None

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.leaf_contract_id,
                self.incumbent_portfolio_id,
                self.evaluator_ref,
                self.verifier_ref,
                self.quarantined_test_ref,
            )
        ):
            raise ValueError("island-campaign references must not be empty")
        if self.evaluator_ref == self.verifier_ref:
            raise ValueError(
                "campaign evaluator and verifier must be independent"
            )
        if self.total_compute_budget <= 0 or self.max_rounds <= 0:
            raise ValueError("campaign budgets must be positive")
        if self.cycle_index < 0:
            raise ValueError("campaign cycle index must be non-negative")
        if self.isolation_rounds < 0:
            raise ValueError("isolation_rounds must be non-negative")
        required_families = {
            SearchFamily.ANCESTRY,
            SearchFamily.DE_NOVO,
            SearchFamily.HYBRID,
        }
        if set(self.search_families) != required_families:
            raise ValueError(
                "the standard campaign requires incremental, de novo, and hybrid"
            )
        if set(self.information_views) != required_families:
            raise ValueError(
                "information views must cover every search island"
            )
        forbidden = {
            InformationChannel.INCUMBENT_CODE,
            InformationChannel.INCUMBENT_REASONING,
            InformationChannel.INCUMBENT_ERROR_LEDGER,
            InformationChannel.SURVIVOR_MECHANISMS,
        }
        if forbidden.intersection(
            self.information_views[SearchFamily.DE_NOVO]
        ):
            raise ValueError(
                "de-novo search must remain blinded from incumbent mechanisms"
            )
        if InformationChannel.INCUMBENT_CODE not in self.information_views[
            SearchFamily.ANCESTRY
        ]:
            raise ValueError(
                "incremental search requires the incumbent implementation"
            )
        if (
            InformationChannel.SURVIVOR_MECHANISMS
            not in self.information_views[SearchFamily.HYBRID]
        ):
            raise ValueError(
                "hybrid search requires cross-island survivor mechanisms"
            )
        if not self.gates:
            raise ValueError("island campaigns require frozen quantitative gates")
        if len({gate.contract_id for gate in self.gates}) != len(self.gates):
            raise ValueError("island-campaign gates must be unique")
        if not any(
            gate.kind == GateKind.INCUMBENT_ADVANCE for gate in self.gates
        ):
            raise ValueError(
                "island campaigns require an independent-evidence advance gate"
            )
        selected_identity = (
            self.selected_hypothesis_id,
            self.selected_executable_digest,
            self.selected_diagnostic_id,
        )
        if any(selected_identity) and not all(selected_identity):
            raise ValueError(
                "campaign hypothesis, executable, and diagnostic identities "
                "must be recorded together"
            )

    @property
    def campaign_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "node_id": self.node_id,
            "leaf_contract_id": self.leaf_contract_id,
            "incumbent_portfolio_id": self.incumbent_portfolio_id,
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "quarantined_test_ref": self.quarantined_test_ref,
            "total_compute_budget": self.total_compute_budget,
            "max_rounds": self.max_rounds,
            "cycle_index": self.cycle_index,
            "isolation_rounds": self.isolation_rounds,
            "search_families": [
                family.value for family in self.search_families
            ],
            "information_views": {
                family.value: [
                    channel.value
                    for channel in self.information_views[family]
                ]
                for family in self.search_families
            },
            "gates": [gate.as_dict() for gate in self.gates],
            "selected_hypothesis_id": self.selected_hypothesis_id,
            "selected_executable_digest": (
                self.selected_executable_digest
            ),
            "selected_diagnostic_id": self.selected_diagnostic_id,
        }
        if include_id:
            value["campaign_id"] = self.campaign_id
        return value


@dataclass(frozen=True)
class IslandCandidateProposal:
    node_id: str
    family: SearchFamily
    executable_digest: str
    mechanism_summary: str
    ancestry_ids: Tuple[str, ...]
    proposer_ref: str
    round_index: int
    exposed_information: Tuple[InformationChannel, ...]
    literature_context_id: str | None = None
    literature_evidence_ids: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.executable_digest,
                self.mechanism_summary,
                self.proposer_ref,
            )
        ):
            raise ValueError("candidate-proposal fields must not be empty")
        if self.round_index < 0:
            raise ValueError("candidate round index must be non-negative")
        if len(set(self.ancestry_ids)) != len(self.ancestry_ids):
            raise ValueError("candidate ancestry must be unique")
        if len(set(self.exposed_information)) != len(
            self.exposed_information
        ):
            raise ValueError("candidate information exposures must be unique")
        if len(set(self.literature_evidence_ids)) != len(
            self.literature_evidence_ids
        ):
            raise ValueError("candidate literature evidence must be unique")
        if (
            self.literature_evidence_ids
            and self.literature_context_id is None
        ):
            raise ValueError(
                "candidate literature evidence requires a context"
            )
        if (
            InformationChannel.LITERATURE_FACTS
            in self.exposed_information
            and (
                self.literature_context_id is None
                or not self.literature_evidence_ids
            )
        ):
            raise ValueError(
                "declared literature exposure requires a bound context and "
                "source-work evidence"
            )

    @property
    def candidate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "node_id": self.node_id,
            "family": self.family.value,
            "executable_digest": self.executable_digest,
            "mechanism_summary": self.mechanism_summary,
            "ancestry_ids": list(self.ancestry_ids),
            "proposer_ref": self.proposer_ref,
            "round_index": self.round_index,
            "exposed_information": [
                channel.value for channel in self.exposed_information
            ],
            "literature_context_id": self.literature_context_id,
            "literature_evidence_ids": list(
                self.literature_evidence_ids
            ),
        }
        if include_id:
            value["candidate_id"] = self.candidate_id
        return value


@dataclass(frozen=True)
class TestExposureRecord:
    node_id: str
    actor_ref: str
    partition: EvidencePartition
    purpose: str
    dataset_digest: str
    candidate_id: Optional[str] = None
    adaptive_access: bool = False

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.actor_ref,
                self.purpose,
                self.dataset_digest,
            )
        ):
            raise ValueError("test-exposure fields must not be empty")
        quarantined = {
            EvidencePartition.AUDIT,
            EvidencePartition.REPLICATION,
            EvidencePartition.EXTERNAL_CONFIRMATION,
        }
        if self.partition in quarantined and self.adaptive_access:
            raise ValueError(
                "quarantined evidence cannot steer adaptive search"
            )
        if self.partition in quarantined and self.candidate_id is None:
            raise ValueError(
                "quarantined evidence requires a fixed candidate"
            )

    @property
    def exposure_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "node_id": self.node_id,
            "actor_ref": self.actor_ref,
            "partition": self.partition.value,
            "purpose": self.purpose,
            "dataset_digest": self.dataset_digest,
            "candidate_id": self.candidate_id,
            "adaptive_access": self.adaptive_access,
        }
        if include_id:
            value["exposure_id"] = self.exposure_id
        return value


@dataclass(frozen=True)
class VerificationRecord:
    node_id: str
    candidate_id: str
    family: SearchFamily
    evaluator_ref: str
    verifier_ref: str
    partition: EvidencePartition
    evidence_ids: Tuple[str, ...]
    effect_size: float
    lower_confidence_bound: float
    passed: bool
    criteria: Tuple[str, ...]
    exposure_ids: Tuple[str, ...]
    raw_artifact_ids: Tuple[str, ...]
    gate_contract_id: str
    metrics: Mapping[str, float]
    evidence_count: int

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.candidate_id,
                self.evaluator_ref,
                self.verifier_ref,
                self.gate_contract_id,
            )
        ):
            raise ValueError("verification references must not be empty")
        if self.evaluator_ref == self.verifier_ref:
            raise ValueError(
                "candidate evaluation and verification must be independent"
            )
        if (
            not self.evidence_ids
            or not self.criteria
            or not self.exposure_ids
            or not self.raw_artifact_ids
        ):
            raise ValueError(
                "verification requires evidence, criteria, exposures, and raw data"
            )
        if not self.metrics:
            raise ValueError("verification requires quantitative gate metrics")
        if self.evidence_count <= 0:
            raise ValueError("verification evidence count must be positive")

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "node_id": self.node_id,
            "candidate_id": self.candidate_id,
            "family": self.family.value,
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "partition": self.partition.value,
            "evidence_ids": list(self.evidence_ids),
            "effect_size": self.effect_size,
            "lower_confidence_bound": self.lower_confidence_bound,
            "passed": self.passed,
            "criteria": list(self.criteria),
            "exposure_ids": list(self.exposure_ids),
            "raw_artifact_ids": list(self.raw_artifact_ids),
            "gate_contract_id": self.gate_contract_id,
            "metrics": dict(sorted(self.metrics.items())),
            "evidence_count": self.evidence_count,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


@dataclass(frozen=True)
class ParentIntegrationRecord:
    node_id: str
    parent_id: str
    candidate_id: str
    preregistered_test_ref: str
    evaluator_ref: str
    verifier_ref: str
    partition: EvidencePartition
    evidence_ids: Tuple[str, ...]
    metric_deltas: Mapping[str, float]
    passed: bool
    causal_interpretation: str
    failure_mode: Optional[str] = None

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.parent_id,
                self.candidate_id,
                self.preregistered_test_ref,
                self.evaluator_ref,
                self.verifier_ref,
                self.causal_interpretation,
            )
        ):
            raise ValueError("parent-integration fields must not be empty")
        if self.node_id == self.parent_id:
            raise ValueError("a node cannot integrate into itself")
        if self.evaluator_ref == self.verifier_ref:
            raise ValueError(
                "parent integration requires an independent verifier"
            )
        if self.partition not in (
            EvidencePartition.REPLICATION,
            EvidencePartition.EXTERNAL_CONFIRMATION,
        ):
            raise ValueError(
                "parent integration requires sequestered evidence"
            )
        if not self.evidence_ids or not self.metric_deltas:
            raise ValueError(
                "parent integration requires evidence and measured deltas"
            )
        if self.passed and self.failure_mode is not None:
            raise ValueError(
                "passing integration cannot retain a failure mode"
            )
        if not self.passed and not self.failure_mode:
            raise ValueError(
                "failed integration requires a classified failure mode"
            )

    @property
    def integration_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "node_id": self.node_id,
            "parent_id": self.parent_id,
            "candidate_id": self.candidate_id,
            "preregistered_test_ref": self.preregistered_test_ref,
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "partition": self.partition.value,
            "evidence_ids": list(self.evidence_ids),
            "metric_deltas": dict(sorted(self.metric_deltas.items())),
            "passed": self.passed,
            "causal_interpretation": self.causal_interpretation,
            "failure_mode": self.failure_mode,
        }
        if include_id:
            value["integration_id"] = self.integration_id
        return value


@dataclass(frozen=True)
class CampaignRoundSummary:
    node_id: str
    round_index: int
    attempts_by_family: Mapping[SearchFamily, int]
    distinct_ancestries_by_family: Mapping[SearchFamily, int]
    best_verified_effect: float
    confidence_sufficient: bool
    failure_signature: str
    compute_spent: float
    budget_complete: bool
    causal_failure_models: Optional[CausalFailureModelSet] = None

    def __post_init__(self) -> None:
        if not self.node_id or not self.failure_signature:
            raise ValueError("campaign-round identity must not be empty")
        if self.round_index < 0 or self.compute_spent < 0:
            raise ValueError("round index and compute must be non-negative")
        families = {
            SearchFamily.ANCESTRY,
            SearchFamily.DE_NOVO,
            SearchFamily.HYBRID,
        }
        if set(self.attempts_by_family) != families:
            raise ValueError("round attempts must cover all three islands")
        if set(self.distinct_ancestries_by_family) != families:
            raise ValueError("round ancestry counts must cover all islands")
        if min(self.attempts_by_family.values()) < 0:
            raise ValueError("round attempt counts must be non-negative")
        if min(self.distinct_ancestries_by_family.values()) < 0:
            raise ValueError("round ancestry counts must be non-negative")
        if (
            self.causal_failure_models is not None
            and self.causal_failure_models.target_node_id != self.node_id
        ):
            raise ValueError(
                "campaign round causal models target another node"
            )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "round_index": self.round_index,
            "attempts_by_family": {
                family.value: int(self.attempts_by_family[family])
                for family in (
                    SearchFamily.ANCESTRY,
                    SearchFamily.DE_NOVO,
                    SearchFamily.HYBRID,
                )
            },
            "distinct_ancestries_by_family": {
                family.value: int(
                    self.distinct_ancestries_by_family[family]
                )
                for family in (
                    SearchFamily.ANCESTRY,
                    SearchFamily.DE_NOVO,
                    SearchFamily.HYBRID,
                )
            },
            "best_verified_effect": self.best_verified_effect,
            "confidence_sufficient": self.confidence_sufficient,
            "failure_signature": self.failure_signature,
            "compute_spent": self.compute_spent,
            "budget_complete": self.budget_complete,
            "causal_failure_models": (
                None
                if self.causal_failure_models is None
                else self.causal_failure_models.as_dict()
            ),
        }


@dataclass(frozen=True)
class CampaignPlateauPolicy:
    minimum_complete_rounds: int = 2
    no_improvement_window: int = 2
    minimum_attempts_per_island: int = 2
    minimum_distinct_ancestries_per_island: int = 2
    minimum_meaningful_effect: float = 0.0
    stable_failure_window: int = 2

    def __post_init__(self) -> None:
        counts = (
            self.minimum_complete_rounds,
            self.no_improvement_window,
            self.minimum_attempts_per_island,
            self.minimum_distinct_ancestries_per_island,
            self.stable_failure_window,
        )
        if min(counts) <= 0:
            raise ValueError("plateau-policy counts must be positive")
        if self.minimum_complete_rounds < self.no_improvement_window:
            raise ValueError(
                "complete-round requirement cannot be shorter than the window"
            )
        if self.minimum_complete_rounds < self.stable_failure_window:
            raise ValueError(
                "complete-round requirement cannot be shorter than failure window"
            )


class CampaignPlateauState(str, Enum):
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    ACTIVE = "active"
    PLATEAUED = "plateaued"


@dataclass(frozen=True)
class CampaignPlateauDiagnosis:
    state: CampaignPlateauState
    round_indices: Tuple[int, ...]
    reasons: Tuple[str, ...]
    reopen_triggers: Tuple[str, ...]

    @property
    def is_plateau(self) -> bool:
        return self.state == CampaignPlateauState.PLATEAUED

    def as_dict(self) -> Dict[str, Any]:
        return {
            "state": self.state.value,
            "is_plateau": self.is_plateau,
            "round_indices": list(self.round_indices),
            "reasons": list(self.reasons),
            "reopen_triggers": list(self.reopen_triggers),
        }


def diagnose_campaign_plateau(
    rounds: Sequence[CampaignRoundSummary],
    policy: CampaignPlateauPolicy,
) -> CampaignPlateauDiagnosis:
    complete = tuple(round_ for round_ in rounds if round_.budget_complete)
    if len(complete) < policy.minimum_complete_rounds:
        return CampaignPlateauDiagnosis(
            state=CampaignPlateauState.INSUFFICIENT_EVIDENCE,
            round_indices=tuple(item.round_index for item in complete),
            reasons=("too few full matched-budget rounds",),
            reopen_triggers=(),
        )

    coverage = complete[-policy.minimum_complete_rounds :]
    families = (
        SearchFamily.ANCESTRY,
        SearchFamily.DE_NOVO,
        SearchFamily.HYBRID,
    )
    coverage_failures = []
    for family in families:
        attempts = sum(
            item.attempts_by_family[family] for item in coverage
        )
        ancestries = sum(
            item.distinct_ancestries_by_family[family]
            for item in coverage
        )
        if attempts < policy.minimum_attempts_per_island:
            coverage_failures.append(
                "%s island did not meet its attempt floor" % family.value
            )
        if ancestries < policy.minimum_distinct_ancestries_per_island:
            coverage_failures.append(
                "%s island lacked ancestry diversity" % family.value
            )
    if coverage_failures:
        return CampaignPlateauDiagnosis(
            state=CampaignPlateauState.INSUFFICIENT_EVIDENCE,
            round_indices=tuple(item.round_index for item in coverage),
            reasons=tuple(coverage_failures),
            reopen_triggers=(),
        )

    improvement_window = complete[-policy.no_improvement_window :]
    meaningful = any(
        item.confidence_sufficient
        and item.best_verified_effect
        >= policy.minimum_meaningful_effect
        for item in improvement_window
    )
    if meaningful:
        return CampaignPlateauDiagnosis(
            state=CampaignPlateauState.ACTIVE,
            round_indices=tuple(
                item.round_index for item in improvement_window
            ),
            reasons=("the recent window contains a meaningful improvement",),
            reopen_triggers=(),
        )

    failure_window = complete[-policy.stable_failure_window :]
    signatures = {item.failure_signature for item in failure_window}
    if len(signatures) != 1:
        return CampaignPlateauDiagnosis(
            state=CampaignPlateauState.ACTIVE,
            round_indices=tuple(
                item.round_index for item in failure_window
            ),
            reasons=("failure modes are still changing",),
            reopen_triggers=(),
        )

    return CampaignPlateauDiagnosis(
        state=CampaignPlateauState.PLATEAUED,
        round_indices=tuple(item.round_index for item in coverage),
        reasons=(
            "all three islands met matched-budget and diversity floors",
            "no confidence-supported meaningful effect survived the window",
            "the dominant failure signature stabilized",
        ),
        reopen_triggers=(
            "new literature or a changed incumbent",
            "new sibling constraint or parent integration evidence",
            "new testbed, tool, model, or candidate representation",
            "a revised effect threshold or domain-of-validity contract",
        ),
    )


class IslandCampaignState:
    """Validated campaign state; proposal engines remain replaceable."""

    def __init__(
        self,
        contract: IslandCampaignContract,
        portfolio: IncumbentPortfolio,
        plateau_policy: CampaignPlateauPolicy,
    ) -> None:
        if contract.node_id != portfolio.node_id:
            raise ValueError("campaign and incumbent portfolio disagree")
        if contract.incumbent_portfolio_id != portfolio.portfolio_id:
            raise ValueError("campaign references another incumbent portfolio")
        if not portfolio.closed:
            raise ValueError(
                "search cannot start while the incumbent is uncertain"
            )
        self.contract = contract
        self.portfolio = portfolio
        self.plateau_policy = plateau_policy
        self._proposals: Dict[str, IslandCandidateProposal] = {}
        self._verifications: Dict[str, Tuple[VerificationRecord, ...]] = {}
        self._gate_decisions: Dict[str, GateDecision] = {}
        self._rounds: Tuple[CampaignRoundSummary, ...] = ()
        self._selected_candidate_id: Optional[str] = None
        self._strategy_termination: Optional[ResearchProgramDiagnosis] = None
        self._plateau = self._diagnose_plateau()

    @property
    def proposals(self) -> Mapping[str, IslandCandidateProposal]:
        return dict(self._proposals)

    @property
    def verifications(
        self,
    ) -> Mapping[str, Tuple[VerificationRecord, ...]]:
        return dict(self._verifications)

    @property
    def rounds(self) -> Tuple[CampaignRoundSummary, ...]:
        return self._rounds

    @property
    def gate_decisions(self) -> Mapping[str, GateDecision]:
        return dict(self._gate_decisions)

    @property
    def selected_candidate_id(self) -> Optional[str]:
        return self._selected_candidate_id

    @property
    def plateau(self) -> CampaignPlateauDiagnosis:
        return self._plateau

    @property
    def compute_spent(self) -> float:
        return sum(round_.compute_spent for round_ in self._rounds)

    def _diagnose_plateau(self) -> CampaignPlateauDiagnosis:
        if self._strategy_termination is not None:
            diagnosis = self._strategy_termination
            return CampaignPlateauDiagnosis(
                state=CampaignPlateauState.PLATEAUED,
                round_indices=tuple(item.round_index for item in self._rounds),
                reasons=(
                    "the research strategy exhausted materially different representations",
                    *diagnosis.reasons,
                ),
                reopen_triggers=(
                    "a new observation or action representation",
                    "a revised problem decomposition or experimental unit",
                    "new external evidence that invalidates the program diagnosis",
                ),
            )
        diagnosis = diagnose_campaign_plateau(
            self._rounds,
            self.plateau_policy,
        )
        if (
            len(self._rounds) == self.contract.max_rounds
            and self._selected_candidate_id is None
            and not diagnosis.is_plateau
        ):
            return CampaignPlateauDiagnosis(
                state=CampaignPlateauState.PLATEAUED,
                round_indices=tuple(
                    item.round_index for item in self._rounds
                ),
                reasons=(
                    "the preregistered campaign round budget was exhausted "
                    "without a replicated nomination",
                ),
                reopen_triggers=(
                    "new literature or a changed incumbent",
                    "new sibling constraint or parent integration evidence",
                    "new testbed, tool, model, or candidate representation",
                    "a revised campaign budget or domain-of-validity contract",
                ),
            )
        return diagnosis

    def park_for_strategy(
        self,
        diagnosis: ResearchProgramDiagnosis,
    ) -> CampaignPlateauDiagnosis:
        if diagnosis.disposition != StrategyDisposition.PARK:
            raise ValueError("campaign strategy termination requires a park diagnosis")
        if self._selected_candidate_id is not None:
            raise ValueError("a campaign with a replicated selection cannot be parked")
        if self._strategy_termination is not None:
            raise ValueError("campaign is already parked by research strategy")
        self._strategy_termination = diagnosis
        self._plateau = self._diagnose_plateau()
        return self._plateau

    def submit_proposal(self, proposal: IslandCandidateProposal) -> str:
        if proposal.node_id != self.contract.node_id:
            raise ValueError("candidate belongs to another goal node")
        if proposal.family not in self.contract.search_families:
            raise ValueError("candidate uses an undeclared island")
        if proposal.round_index >= self.contract.max_rounds:
            raise ValueError("candidate exceeds the campaign round budget")
        allowed_view = set(
            self.contract.information_views[proposal.family]
        )
        if not set(proposal.exposed_information).issubset(allowed_view):
            raise ValueError(
                "candidate observed information forbidden for its island"
            )
        if proposal.family == SearchFamily.ANCESTRY:
            if not proposal.ancestry_ids:
                raise ValueError(
                    "incremental candidates require incumbent ancestry"
                )
            if any(
                parent_id != self.portfolio.primary_incumbent_id
                and self._proposals[parent_id].family
                != SearchFamily.ANCESTRY
                for parent_id in proposal.ancestry_ids
                if parent_id in self._proposals
            ):
                raise ValueError(
                    "incremental lineage cannot inherit another island"
                )
        if proposal.family == SearchFamily.DE_NOVO:
            forbidden = {
                self.portfolio.primary_incumbent_id,
                *(
                    entry.candidate_id
                    for entry in self.portfolio.entries
                ),
            }
            if forbidden.intersection(proposal.ancestry_ids):
                raise ValueError(
                    "de-novo ancestry cannot inherit an incumbent"
                )
            if any(
                self._proposals[parent_id].family
                != SearchFamily.DE_NOVO
                for parent_id in proposal.ancestry_ids
                if parent_id in self._proposals
            ):
                raise ValueError(
                    "de-novo lineage cannot inherit another island"
                )
        if proposal.family == SearchFamily.HYBRID:
            if proposal.round_index < self.contract.isolation_rounds:
                raise ValueError(
                    "hybrid migration is forbidden during island isolation"
                )
            if len(proposal.ancestry_ids) < 2:
                raise ValueError(
                    "hybrid candidates require at least two survivor lineages"
                )
            parent_families = {
                self._proposals[parent_id].family
                for parent_id in proposal.ancestry_ids
                if parent_id in self._proposals
            }
            if not {
                SearchFamily.ANCESTRY,
                SearchFamily.DE_NOVO,
            }.issubset(parent_families):
                raise ValueError(
                    "hybrid candidates must combine incremental and de-novo survivors"
                )
            if any(
                proposal.round_index
                - self._proposals[parent_id].round_index
                < self.contract.isolation_rounds
                for parent_id in proposal.ancestry_ids
                if parent_id in self._proposals
                and self._proposals[parent_id].family
                in (
                    SearchFamily.ANCESTRY,
                    SearchFamily.DE_NOVO,
                )
            ):
                raise ValueError(
                    "hybrid migration violates the declared isolation delay"
                )
        if proposal.candidate_id in self._proposals:
            raise ValueError("candidate proposal is already registered")
        known_ancestry_ids = {
            self.portfolio.primary_incumbent_id,
            *self._proposals,
        }
        unknown_ancestry = set(proposal.ancestry_ids).difference(
            known_ancestry_ids
        )
        if unknown_ancestry:
            raise ValueError(
                "candidate ancestry references unknown lineages"
            )
        self._proposals[proposal.candidate_id] = proposal
        return proposal.candidate_id

    def record_verification(
        self,
        verification: VerificationRecord,
        exposures: Mapping[str, TestExposureRecord],
    ) -> GateDecision:
        proposal = self._proposals.get(verification.candidate_id)
        if proposal is None:
            raise ValueError("verification references an unknown candidate")
        if verification.node_id != self.contract.node_id:
            raise ValueError("verification belongs to another goal node")
        if verification.family != proposal.family:
            raise ValueError("verification island does not match candidate")
        if verification.evaluator_ref != self.contract.evaluator_ref:
            raise ValueError("verification used an undeclared evaluator")
        if verification.verifier_ref != self.contract.verifier_ref:
            raise ValueError("verification used an undeclared verifier")
        gate = next(
            (
                item
                for item in self.contract.gates
                if item.contract_id == verification.gate_contract_id
            ),
            None,
        )
        if gate is None:
            raise ValueError("verification references an undeclared gate")
        if gate.evidence_partition != verification.partition:
            raise ValueError("verification partition disagrees with its gate")
        missing = set(verification.exposure_ids).difference(exposures)
        if missing:
            raise ValueError(
                "verification references unknown test exposures"
            )
        for exposure_id in verification.exposure_ids:
            exposure = exposures[exposure_id]
            if exposure.node_id != self.contract.node_id:
                raise ValueError("test exposure belongs to another node")
            if exposure.candidate_id not in (
                None,
                verification.candidate_id,
            ):
                raise ValueError("test exposure belongs to another candidate")
            if exposure.partition != verification.partition:
                raise ValueError(
                    "verification partition disagrees with test exposure"
                )
        existing = self._verifications.get(verification.candidate_id, ())
        if any(
            item.verification_id == verification.verification_id
            for item in existing
        ):
            raise ValueError("verification is already registered")
        decision = evaluate_gate(
            gate,
            candidate_id=verification.candidate_id,
            incumbent_id=self.portfolio.primary_incumbent_id,
            metrics=verification.metrics,
            evidence_count=verification.evidence_count,
        )
        if verification.passed != decision.passed:
            raise ValueError(
                "verification pass flag disagrees with the frozen gate"
            )
        self._verifications[verification.candidate_id] = (
            *existing,
            verification,
        )
        self._gate_decisions[verification.verification_id] = decision
        return decision

    def nominate(self, candidate_id: str) -> VerificationRecord:
        if candidate_id not in self._proposals:
            raise ValueError("cannot nominate an unknown candidate")
        qualifying = tuple(
            (verification, self._gate_decisions[verification.verification_id])
            for verification in self._verifications.get(candidate_id, ())
            if verification.partition
            in (
                EvidencePartition.REPLICATION,
                EvidencePartition.EXTERNAL_CONFIRMATION,
            )
            and self._gate_decisions[verification.verification_id].passed
            and next(
                gate
                for gate in self.contract.gates
                if gate.contract_id == verification.gate_contract_id
            ).kind
            == GateKind.INCUMBENT_ADVANCE
        )
        if not qualifying:
            raise ValueError(
                "nomination requires passing sequestered verification"
            )
        self._selected_candidate_id = candidate_id
        return qualifying[-1][0]

    def complete_round(
        self,
        summary: CampaignRoundSummary,
    ) -> CampaignPlateauDiagnosis:
        if summary.node_id != self.contract.node_id:
            raise ValueError("campaign round belongs to another node")
        if summary.round_index != len(self._rounds):
            raise ValueError("campaign rounds must be sequential")
        if summary.round_index >= self.contract.max_rounds:
            raise ValueError("campaign exceeds its round budget")
        round_proposals = tuple(
            proposal
            for proposal in self._proposals.values()
            if proposal.round_index == summary.round_index
        )
        actual_attempts = {
            family: sum(
                proposal.family == family
                for proposal in round_proposals
            )
            for family in self.contract.search_families
        }
        if dict(summary.attempts_by_family) != actual_attempts:
            raise ValueError(
                "round attempt summary disagrees with registered candidates"
            )
        actual_ancestries = {
            family: len(
                {
                    (
                        proposal.ancestry_ids
                        if proposal.ancestry_ids
                        else (proposal.candidate_id,)
                    )
                    for proposal in round_proposals
                    if proposal.family == family
                }
            )
            for family in self.contract.search_families
        }
        if (
            dict(summary.distinct_ancestries_by_family)
            != actual_ancestries
        ):
            raise ValueError(
                "round ancestry summary disagrees with candidate lineage"
            )
        verified_effects = tuple(
            verification.effect_size
            for proposal in round_proposals
            for verification in self._verifications.get(
                proposal.candidate_id,
                (),
            )
        )
        if round_proposals and not verified_effects:
            raise ValueError(
                "a completed round requires verified candidate outcomes"
            )
        if verified_effects and abs(
            summary.best_verified_effect - max(verified_effects)
        ) > 1e-12:
            raise ValueError(
                "round best effect disagrees with verified outcomes"
            )
        if (
            self.compute_spent + summary.compute_spent
            > self.contract.total_compute_budget
        ):
            raise ValueError("campaign exceeds its compute budget")
        self._rounds = (*self._rounds, summary)
        self._plateau = self._diagnose_plateau()
        return self._plateau

    def as_dict(self) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "contract": self.contract.as_dict(),
            "portfolio": self.portfolio.as_dict(),
            "plateau_policy": {
                "minimum_complete_rounds": (
                    self.plateau_policy.minimum_complete_rounds
                ),
                "no_improvement_window": (
                    self.plateau_policy.no_improvement_window
                ),
                "minimum_attempts_per_island": (
                    self.plateau_policy.minimum_attempts_per_island
                ),
                "minimum_distinct_ancestries_per_island": (
                    self.plateau_policy
                    .minimum_distinct_ancestries_per_island
                ),
                "minimum_meaningful_effect": (
                    self.plateau_policy.minimum_meaningful_effect
                ),
                "stable_failure_window": (
                    self.plateau_policy.stable_failure_window
                ),
            },
            "proposals": [
                proposal.as_dict()
                for _, proposal in sorted(self._proposals.items())
            ],
            "verifications": {
                candidate_id: [
                    verification.as_dict()
                    for verification in verifications
                ]
                for candidate_id, verifications in sorted(
                    self._verifications.items()
                )
            },
            "gate_decisions": {
                verification_id: decision.as_dict()
                for verification_id, decision in sorted(
                    self._gate_decisions.items()
                )
            },
            "rounds": [round_.as_dict() for round_ in self._rounds],
            "compute_spent": self.compute_spent,
            "selected_candidate_id": self._selected_candidate_id,
            "plateau": self._plateau.as_dict(),
        }
        if self._strategy_termination is not None:
            value["strategy_termination"] = (
                self._strategy_termination.as_dict()
            )
        return value
