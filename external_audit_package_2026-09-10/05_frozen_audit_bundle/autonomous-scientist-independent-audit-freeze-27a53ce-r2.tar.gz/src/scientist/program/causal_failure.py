from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from collections import Counter
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest


CAUSAL_FAILURE_MODEL_VERSION = "causal-failure-model-v2"


class CausalRole(str, Enum):
    """Required roles in a failure model and a relational analogy."""

    UNAVAILABLE_INFORMATION = "unavailable_information"
    IRREVERSIBLE_DECISION = "irreversible_decision"
    ALTERNATIVE_ACTION = "alternative_action"
    CHANGED_RESULT = "changed_result"


REQUIRED_CAUSAL_ROLES = tuple(CausalRole)


class CausalRelationKind(str, Enum):
    """Domain-neutral edges used for structure, never keyword similarity."""

    INFORMATION_REVEALED_AFTER_COMMITMENT = (
        "information_revealed_after_commitment"
    )
    COMMITMENT_DESTROYS_OPTION = "commitment_destroys_option"
    ALTERNATIVE_PRESERVES_OPTION = "alternative_preserves_option"
    PRESERVED_OPTION_CHANGES_OUTCOME = (
        "preserved_option_changes_outcome"
    )
    FEEDBACK_CORRECTS_FUTURE_ACTION = "feedback_corrects_future_action"
    STATE_SELECTS_POLICY = "state_selects_policy"


@dataclass(frozen=True)
class CausalFailureModel:
    """A falsifiable causal account of one observed failure cluster."""

    target_node_id: str
    cluster_id: str
    cluster_description: str
    unavailable_information: str
    information_available_after: str
    irreversible_decision: str
    decision_point: str
    alternative_action: str
    changed_result: str
    causal_chain: str
    causal_relations: Tuple[CausalRelationKind, ...]
    observable_proxies: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    assumptions: Tuple[str, ...]
    distinguishing_predictions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    modeler_ref: str
    decision_trace_ids: Tuple[str, ...] = ()
    causal_signature: Tuple[str, ...] = ()
    information_regime: str = "unclassified"
    mediator: str = "unclassified"
    counterfactual_effect: float = 0.0
    proxy_reliability: float = 0.0
    empirically_supported: bool = False

    def __post_init__(self) -> None:
        required = (
            self.target_node_id,
            self.cluster_id,
            self.cluster_description,
            self.unavailable_information,
            self.information_available_after,
            self.irreversible_decision,
            self.decision_point,
            self.alternative_action,
            self.changed_result,
            self.causal_chain,
            self.causal_relations,
            self.observable_proxies,
            self.evidence_ids,
            self.assumptions,
            self.distinguishing_predictions,
            self.falsification_conditions,
            self.modeler_ref,
        )
        if not all(required):
            raise ValueError("causal failure model is incomplete")
        if len(set(self.observable_proxies)) != len(
            self.observable_proxies
        ):
            raise ValueError("causal-model proxies must be unique")
        if len(set(self.causal_relations)) != len(
            self.causal_relations
        ):
            raise ValueError("causal-model relation kinds must be unique")
        if len(set(self.evidence_ids)) != len(self.evidence_ids):
            raise ValueError("causal-model evidence IDs must be unique")
        if len(self.distinguishing_predictions) < 2:
            raise ValueError(
                "causal failure model requires two distinguishing predictions"
            )
        if len(self.falsification_conditions) < 2:
            raise ValueError(
                "causal failure model requires two falsification conditions"
            )
        if self.alternative_action == self.irreversible_decision:
            raise ValueError(
                "counterfactual action must differ from the failed decision"
            )
        if len(set(self.decision_trace_ids)) != len(
            self.decision_trace_ids
        ):
            raise ValueError("causal-model decision traces must be unique")
        if not math.isfinite(self.counterfactual_effect):
            raise ValueError("causal-model counterfactual effect must be finite")
        if not 0 <= self.proxy_reliability <= 1:
            raise ValueError("causal-model proxy reliability must be in [0, 1]")
        if self.empirically_supported and (
            not self.decision_trace_ids
            or not self.causal_signature
            or self.counterfactual_effect <= 0
        ):
            raise ValueError(
                "empirically supported causal models require a positive "
                "decision-level counterfactual replay"
            )

    @property
    def model_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def target_element(self, role: CausalRole) -> str:
        return {
            CausalRole.UNAVAILABLE_INFORMATION: (
                self.unavailable_information
            ),
            CausalRole.IRREVERSIBLE_DECISION: (
                self.irreversible_decision
            ),
            CausalRole.ALTERNATIVE_ACTION: self.alternative_action,
            CausalRole.CHANGED_RESULT: self.changed_result,
        }[role]

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": CAUSAL_FAILURE_MODEL_VERSION,
            "target_node_id": self.target_node_id,
            "cluster_id": self.cluster_id,
            "cluster_description": self.cluster_description,
            "unavailable_information": self.unavailable_information,
            "information_available_after": self.information_available_after,
            "irreversible_decision": self.irreversible_decision,
            "decision_point": self.decision_point,
            "alternative_action": self.alternative_action,
            "changed_result": self.changed_result,
            "causal_chain": self.causal_chain,
            "causal_relations": [
                relation.value for relation in self.causal_relations
            ],
            "observable_proxies": list(self.observable_proxies),
            "evidence_ids": list(self.evidence_ids),
            "assumptions": list(self.assumptions),
            "distinguishing_predictions": list(
                self.distinguishing_predictions
            ),
            "falsification_conditions": list(
                self.falsification_conditions
            ),
            "modeler_ref": self.modeler_ref,
            "decision_trace_ids": list(self.decision_trace_ids),
            "causal_signature": list(self.causal_signature),
            "information_regime": self.information_regime,
            "mediator": self.mediator,
            "counterfactual_effect": self.counterfactual_effect,
            "proxy_reliability": self.proxy_reliability,
            "empirically_supported": self.empirically_supported,
        }
        if include_id:
            value["model_id"] = self.model_id
        return value


@dataclass(frozen=True)
class CausalFailureModelSet:
    """Coverage certificate: exactly one causal model per failure cluster."""

    target_node_id: str
    failure_cluster_ids: Tuple[str, ...]
    models: Tuple[CausalFailureModel, ...]
    source_artifact_ids: Tuple[str, ...]
    builder_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_node_id,
                self.failure_cluster_ids,
                self.models,
                self.source_artifact_ids,
                self.builder_ref,
            )
        ):
            raise ValueError("causal failure model set is incomplete")
        if len(set(self.failure_cluster_ids)) != len(
            self.failure_cluster_ids
        ):
            raise ValueError("failure cluster IDs must be unique")
        if len(set(self.source_artifact_ids)) != len(
            self.source_artifact_ids
        ):
            raise ValueError("failure-model source artifacts must be unique")
        model_clusters = tuple(model.cluster_id for model in self.models)
        if len(set(model_clusters)) != len(model_clusters):
            raise ValueError(
                "each failure cluster must have exactly one causal model"
            )
        if set(model_clusters) != set(self.failure_cluster_ids):
            missing = sorted(
                set(self.failure_cluster_ids).difference(model_clusters)
            )
            extra = sorted(
                set(model_clusters).difference(self.failure_cluster_ids)
            )
            raise ValueError(
                "causal-model coverage mismatch; missing=%s extra=%s"
                % (missing, extra)
            )
        if any(
            model.target_node_id != self.target_node_id
            for model in self.models
        ):
            raise ValueError("causal failure models target multiple nodes")

    @property
    def model_set_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def coverage_complete(self) -> bool:
        return len(self.models) == len(self.failure_cluster_ids)

    @property
    def empirical_schema_count(self) -> int:
        return len(
            {
                model.causal_signature
                for model in self.models
                if model.empirically_supported and model.causal_signature
            }
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": CAUSAL_FAILURE_MODEL_VERSION,
            "target_node_id": self.target_node_id,
            "failure_cluster_ids": list(self.failure_cluster_ids),
            "models": [model.as_dict() for model in self.models],
            "source_artifact_ids": list(self.source_artifact_ids),
            "builder_ref": self.builder_ref,
            "coverage_complete": self.coverage_complete,
            "empirical_schema_count": self.empirical_schema_count,
        }
        if include_id:
            value["model_set_id"] = self.model_set_id
        return value


@dataclass(frozen=True)
class RelationalAnalogyMapping:
    """One role-preserving source-to-target causal correspondence."""

    causal_role: CausalRole
    target_model_id: str
    source_element: str
    target_element: str
    correspondence: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_model_id,
                self.source_element,
                self.target_element,
                self.correspondence,
            )
        ):
            raise ValueError("relational analogy mapping is incomplete")

    def as_dict(self) -> Dict[str, str]:
        return {
            "causal_role": self.causal_role.value,
            "target_model_id": self.target_model_id,
            "source_element": self.source_element,
            "target_element": self.target_element,
            "correspondence": self.correspondence,
        }


@dataclass(frozen=True)
class CausalDiscriminationAssessment:
    """Fail-closed certificate against a collapsed causal ontology."""

    target_node_id: str
    model_set_id: str
    supported_model_count: int
    unique_schema_count: int
    replay_support_rate: float
    maximum_schema_fraction: float
    reliable_proxy_model_count: int
    passed: bool
    failure_reasons: Tuple[str, ...]
    thresholds: Mapping[str, float]
    assessor_ref: str

    def __post_init__(self) -> None:
        if not all(
            (self.target_node_id, self.model_set_id, self.assessor_ref)
        ):
            raise ValueError("causal discrimination assessment is incomplete")
        if min(
            self.supported_model_count,
            self.unique_schema_count,
            self.reliable_proxy_model_count,
        ) < 0:
            raise ValueError("causal discrimination counts cannot be negative")
        if not all(
            math.isfinite(value) and 0 <= value <= 1
            for value in (
                self.replay_support_rate,
                self.maximum_schema_fraction,
            )
        ):
            raise ValueError("causal discrimination rates must be in [0, 1]")
        if self.passed and self.failure_reasons:
            raise ValueError(
                "passing causal discrimination cannot retain failure reasons"
            )
        if not self.passed and not self.failure_reasons:
            raise ValueError(
                "failed causal discrimination must state why it stopped"
            )

    @property
    def assessment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": CAUSAL_FAILURE_MODEL_VERSION,
            "target_node_id": self.target_node_id,
            "model_set_id": self.model_set_id,
            "supported_model_count": self.supported_model_count,
            "unique_schema_count": self.unique_schema_count,
            "replay_support_rate": self.replay_support_rate,
            "maximum_schema_fraction": self.maximum_schema_fraction,
            "reliable_proxy_model_count": self.reliable_proxy_model_count,
            "passed": self.passed,
            "failure_reasons": list(self.failure_reasons),
            "thresholds": dict(sorted(self.thresholds.items())),
            "assessor_ref": self.assessor_ref,
        }
        if include_id:
            value["assessment_id"] = self.assessment_id
        return value


def assess_causal_discrimination(
    model_set: CausalFailureModelSet,
    *,
    minimum_supported_schemas: int = 2,
    minimum_replay_support_rate: float = 0.25,
    maximum_schema_fraction: float = 0.85,
    minimum_proxy_reliability: float = 0.55,
    assessor_ref: str = "causal-discrimination-gate-v1",
) -> CausalDiscriminationAssessment:
    """Require empirically distinct causal mechanisms before retrieval."""

    if minimum_supported_schemas < 1:
        raise ValueError("minimum supported schemas must be positive")
    supported = tuple(
        model for model in model_set.models if model.empirically_supported
    )
    schema_counts = Counter(
        model.causal_signature for model in supported if model.causal_signature
    )
    schema_count = len(schema_counts)
    support_rate = len(supported) / float(len(model_set.models))
    largest_fraction = (
        1.0
        if not supported
        else max(schema_counts.values(), default=len(supported))
        / float(len(supported))
    )
    reliable_proxy_count = sum(
        model.proxy_reliability >= minimum_proxy_reliability
        for model in supported
        if model.information_regime == "predictive_proxy"
    )
    predictive_count = sum(
        model.information_regime == "predictive_proxy"
        for model in supported
    )
    failures = []
    if schema_count < minimum_supported_schemas:
        failures.append(
            "ontology_collapse:%d_supported_schema(s)_below_%d"
            % (schema_count, minimum_supported_schemas)
        )
    if support_rate < minimum_replay_support_rate:
        failures.append(
            "counterfactual_replay_support_rate_below_threshold"
        )
    if (
        len(supported) > 1
        and largest_fraction > maximum_schema_fraction
    ):
        failures.append("one_causal_schema_dominates_the_failure_set")
    if predictive_count and reliable_proxy_count < predictive_count:
        failures.append(
            "predictive_proxy_does_not_predict_held_out_future_structure"
        )
    return CausalDiscriminationAssessment(
        target_node_id=model_set.target_node_id,
        model_set_id=model_set.model_set_id,
        supported_model_count=len(supported),
        unique_schema_count=schema_count,
        replay_support_rate=support_rate,
        maximum_schema_fraction=largest_fraction,
        reliable_proxy_model_count=reliable_proxy_count,
        passed=not failures,
        failure_reasons=tuple(failures),
        thresholds={
            "minimum_supported_schemas": float(minimum_supported_schemas),
            "minimum_replay_support_rate": minimum_replay_support_rate,
            "maximum_schema_fraction": maximum_schema_fraction,
            "minimum_proxy_reliability": minimum_proxy_reliability,
        },
        assessor_ref=assessor_ref,
    )


def causal_failure_model_from_dict(
    value: Dict[str, Any],
) -> CausalFailureModel:
    if value.get("contract_version") != CAUSAL_FAILURE_MODEL_VERSION:
        raise ValueError("unsupported causal failure model version")
    model = CausalFailureModel(
        target_node_id=str(value["target_node_id"]),
        cluster_id=str(value["cluster_id"]),
        cluster_description=str(value["cluster_description"]),
        unavailable_information=str(value["unavailable_information"]),
        information_available_after=str(
            value["information_available_after"]
        ),
        irreversible_decision=str(value["irreversible_decision"]),
        decision_point=str(value["decision_point"]),
        alternative_action=str(value["alternative_action"]),
        changed_result=str(value["changed_result"]),
        causal_chain=str(value["causal_chain"]),
        causal_relations=tuple(
            CausalRelationKind(str(item))
            for item in value["causal_relations"]
        ),
        observable_proxies=tuple(
            str(item) for item in value["observable_proxies"]
        ),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        assumptions=tuple(str(item) for item in value["assumptions"]),
        distinguishing_predictions=tuple(
            str(item) for item in value["distinguishing_predictions"]
        ),
        falsification_conditions=tuple(
            str(item) for item in value["falsification_conditions"]
        ),
        modeler_ref=str(value["modeler_ref"]),
        decision_trace_ids=tuple(
            str(item) for item in value.get("decision_trace_ids", ())
        ),
        causal_signature=tuple(
            str(item) for item in value.get("causal_signature", ())
        ),
        information_regime=str(
            value.get("information_regime", "unclassified")
        ),
        mediator=str(value.get("mediator", "unclassified")),
        counterfactual_effect=float(
            value.get("counterfactual_effect", 0.0)
        ),
        proxy_reliability=float(value.get("proxy_reliability", 0.0)),
        empirically_supported=bool(
            value.get("empirically_supported", False)
        ),
    )
    supplied = value.get("model_id")
    if supplied is not None and str(supplied) != model.model_id:
        raise ValueError("causal failure model identity mismatch")
    return model


def causal_failure_model_set_from_dict(
    value: Dict[str, Any],
) -> CausalFailureModelSet:
    if value.get("contract_version") != CAUSAL_FAILURE_MODEL_VERSION:
        raise ValueError("unsupported causal failure model version")
    model_set = CausalFailureModelSet(
        target_node_id=str(value["target_node_id"]),
        failure_cluster_ids=tuple(
            str(item) for item in value["failure_cluster_ids"]
        ),
        models=tuple(
            causal_failure_model_from_dict(item)
            for item in value["models"]
        ),
        source_artifact_ids=tuple(
            str(item) for item in value["source_artifact_ids"]
        ),
        builder_ref=str(value["builder_ref"]),
    )
    supplied = value.get("model_set_id")
    if supplied is not None and str(supplied) != model_set.model_set_id:
        raise ValueError("causal failure model-set identity mismatch")
    if value.get("coverage_complete") is False:
        raise ValueError("serialized causal failure coverage is incomplete")
    supplied_schema_count = value.get("empirical_schema_count")
    if (
        supplied_schema_count is not None
        and int(supplied_schema_count) != model_set.empirical_schema_count
    ):
        raise ValueError("causal failure empirical schema count mismatch")
    return model_set


def causal_discrimination_from_dict(
    value: Mapping[str, Any],
) -> CausalDiscriminationAssessment:
    if value.get("contract_version") != CAUSAL_FAILURE_MODEL_VERSION:
        raise ValueError("unsupported causal failure model version")
    assessment = CausalDiscriminationAssessment(
        target_node_id=str(value["target_node_id"]),
        model_set_id=str(value["model_set_id"]),
        supported_model_count=int(value["supported_model_count"]),
        unique_schema_count=int(value["unique_schema_count"]),
        replay_support_rate=float(value["replay_support_rate"]),
        maximum_schema_fraction=float(
            value["maximum_schema_fraction"]
        ),
        reliable_proxy_model_count=int(
            value["reliable_proxy_model_count"]
        ),
        passed=bool(value["passed"]),
        failure_reasons=tuple(
            str(item) for item in value.get("failure_reasons", ())
        ),
        thresholds={
            str(key): float(item)
            for key, item in value["thresholds"].items()
        },
        assessor_ref=str(value["assessor_ref"]),
    )
    supplied = value.get("assessment_id")
    if supplied is not None and str(supplied) != assessment.assessment_id:
        raise ValueError("causal discrimination identity mismatch")
    return assessment
