"""Compatibility alias for the lightweight top-level Codex exchange module."""

import sys

from scientist import codex_exchange as _implementation

sys.modules[__name__] = _implementation
