from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import MetricSpec


PROGRAM_ARCHITECTURE_VERSION = "research-program-manager-v1"


class NodeKind(str, Enum):
    CAPABILITY = "capability"
    BOTTLENECK = "bottleneck"
    SCIENTIFIC_QUESTION = "scientific_question"
    ENGINEERING_ENABLER = "engineering_enabler"
    INTEGRATION = "integration"


class NodeStatus(str, Enum):
    PROPOSED = "proposed"
    READY = "ready"
    ACTIVE = "active"
    CONFIRMED = "confirmed"
    REFUTED = "refuted"
    BLOCKED = "blocked"
    SUPERSEDED = "superseded"
    INTEGRATED = "integrated"


class ChildCampaignOutcome(str, Enum):
    CONFIRMED = "confirmed"
    REFUTED = "refuted"
    INCONCLUSIVE = "inconclusive"


@dataclass(frozen=True)
class ChildCampaignProgress:
    """A durable, non-terminal update from a still-running child campaign."""

    node_id: str
    child_charter_id: str
    stage: str
    hypothesis_id: str
    evidence_ids: Tuple[str, ...]
    summary: str
    implications: Tuple[str, ...]
    compute_spent: float
    next_action: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.child_charter_id,
                self.stage,
                self.hypothesis_id,
                self.summary,
                self.next_action,
            )
        ):
            raise ValueError("campaign-progress fields must not be empty")
        if not self.evidence_ids or not self.implications:
            raise ValueError(
                "campaign progress requires evidence and implications"
            )
        if self.compute_spent < 0:
            raise ValueError("compute_spent must be non-negative")

    @property
    def progress_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "node_id": self.node_id,
            "child_charter_id": self.child_charter_id,
            "stage": self.stage,
            "hypothesis_id": self.hypothesis_id,
            "evidence_ids": list(self.evidence_ids),
            "summary": self.summary,
            "implications": list(self.implications),
            "compute_spent": self.compute_spent,
            "next_action": self.next_action,
        }
        if include_id:
            value["progress_id"] = self.progress_id
        return value


@dataclass(frozen=True)
class HighLevelGoal:
    name: str
    outcome: str
    scope: Tuple[str, ...]
    anti_scope: Tuple[str, ...]
    terminal_metrics: Tuple[MetricSpec, ...]
    success_definition: str
    failure_conditions: Tuple[str, ...]
    integration_requirements: Tuple[str, ...]
    total_compute_budget: float
    max_parallel_campaigns: int
    risk_tier: str = "research_only"
    human_owner: Optional[str] = None

    def __post_init__(self) -> None:
        if not self.name or not self.outcome:
            raise ValueError("goal identity must not be empty")
        if not self.scope or not self.anti_scope:
            raise ValueError("goal scope and anti_scope must be explicit")
        if not self.terminal_metrics:
            raise ValueError("goal requires terminal metrics")
        if sum(metric.primary for metric in self.terminal_metrics) != 1:
            raise ValueError(
                "goal requires exactly one primary terminal metric"
            )
        if not self.success_definition or not self.failure_conditions:
            raise ValueError(
                "goal success and failure conditions must be explicit"
            )
        if not self.integration_requirements:
            raise ValueError("goal integration requirements are required")
        if self.total_compute_budget <= 0:
            raise ValueError("goal compute budget must be positive")
        if self.max_parallel_campaigns <= 0:
            raise ValueError(
                "max_parallel_campaigns must be positive"
            )

    @property
    def goal_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "program_architecture_version": PROGRAM_ARCHITECTURE_VERSION,
            "name": self.name,
            "outcome": self.outcome,
            "scope": list(self.scope),
            "anti_scope": list(self.anti_scope),
            "terminal_metrics": [
                metric.as_dict() for metric in self.terminal_metrics
            ],
            "success_definition": self.success_definition,
            "failure_conditions": list(self.failure_conditions),
            "integration_requirements": list(
                self.integration_requirements
            ),
            "total_compute_budget": self.total_compute_budget,
            "max_parallel_campaigns": self.max_parallel_campaigns,
            "risk_tier": self.risk_tier,
            "human_owner": self.human_owner,
        }
        if include_id:
            value["goal_id"] = self.goal_id
        return value


@dataclass(frozen=True)
class ResearchNode:
    goal_id: str
    title: str
    question: str
    kind: NodeKind
    rationale: str
    acceptance_conditions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    expected_artifact: str
    prerequisite_ids: Tuple[str, ...] = ()
    estimated_compute: float = 1.0
    critical: bool = False
    alternative_group: Optional[str] = None
    tags: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        required = (
            self.goal_id,
            self.title,
            self.question,
            self.rationale,
            self.expected_artifact,
        )
        if not all(required):
            raise ValueError("research-node fields must not be empty")
        if not self.acceptance_conditions:
            raise ValueError("node acceptance conditions are required")
        if not self.falsification_conditions:
            raise ValueError("node falsification conditions are required")
        if self.estimated_compute <= 0:
            raise ValueError("estimated_compute must be positive")
        if len(set(self.prerequisite_ids)) != len(self.prerequisite_ids):
            raise ValueError("node prerequisites must be unique")

    @property
    def node_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "program_architecture_version": PROGRAM_ARCHITECTURE_VERSION,
            "goal_id": self.goal_id,
            "title": self.title,
            "question": self.question,
            "kind": self.kind.value,
            "rationale": self.rationale,
            "acceptance_conditions": list(self.acceptance_conditions),
            "falsification_conditions": list(
                self.falsification_conditions
            ),
            "expected_artifact": self.expected_artifact,
            "prerequisite_ids": list(self.prerequisite_ids),
            "estimated_compute": self.estimated_compute,
            "critical": self.critical,
            "alternative_group": self.alternative_group,
            "tags": list(self.tags),
        }
        if include_id:
            value["node_id"] = self.node_id
        return value


@dataclass(frozen=True)
class Decomposition:
    goal_id: str
    name: str
    causal_model: str
    assumptions: Tuple[str, ...]
    node_ids: Tuple[str, ...]
    distinguishing_predictions: Tuple[str, ...]
    decomposer_ref: str

    def __post_init__(self) -> None:
        if not (
            self.goal_id
            and self.name
            and self.causal_model
            and self.decomposer_ref
        ):
            raise ValueError("decomposition fields must not be empty")
        if not self.assumptions or not self.node_ids:
            raise ValueError(
                "decomposition requires assumptions and nodes"
            )
        if not self.distinguishing_predictions:
            raise ValueError(
                "decomposition requires distinguishing predictions"
            )
        if len(set(self.node_ids)) != len(self.node_ids):
            raise ValueError("decomposition node IDs must be unique")

    @property
    def decomposition_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "program_architecture_version": PROGRAM_ARCHITECTURE_VERSION,
            "goal_id": self.goal_id,
            "name": self.name,
            "causal_model": self.causal_model,
            "assumptions": list(self.assumptions),
            "node_ids": list(self.node_ids),
            "distinguishing_predictions": list(
                self.distinguishing_predictions
            ),
            "decomposer_ref": self.decomposer_ref,
        }
        if include_id:
            value["decomposition_id"] = self.decomposition_id
        return value


@dataclass(frozen=True)
class NodeAssessment:
    node_id: str
    goal_relevance: float
    bottleneck_probability: float
    tractability: float
    expected_information_gain: float
    integration_leverage: float
    estimated_cost: float
    basis: Tuple[str, ...]
    assessor_ref: str

    def __post_init__(self) -> None:
        probabilities = (
            self.goal_relevance,
            self.bottleneck_probability,
            self.tractability,
            self.expected_information_gain,
            self.integration_leverage,
        )
        if any(value < 0.0 or value > 1.0 for value in probabilities):
            raise ValueError("assessment factors must be in [0, 1]")
        if self.estimated_cost <= 0:
            raise ValueError("assessment cost must be positive")
        if not self.node_id or not self.basis or not self.assessor_ref:
            raise ValueError("assessment provenance is required")

    @property
    def expected_progress(self) -> float:
        mechanism_value = (
            self.bottleneck_probability * self.integration_leverage
            + self.expected_information_gain
        )
        return self.goal_relevance * self.tractability * mechanism_value

    @property
    def priority_score(self) -> float:
        return self.expected_progress / self.estimated_cost

    def as_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "goal_relevance": self.goal_relevance,
            "bottleneck_probability": self.bottleneck_probability,
            "tractability": self.tractability,
            "expected_information_gain": (
                self.expected_information_gain
            ),
            "integration_leverage": self.integration_leverage,
            "estimated_cost": self.estimated_cost,
            "expected_progress": self.expected_progress,
            "priority_score": self.priority_score,
            "basis": list(self.basis),
            "assessor_ref": self.assessor_ref,
        }


@dataclass(frozen=True)
class DecompositionProposal:
    decomposition: Decomposition
    nodes: Tuple[ResearchNode, ...]
    initial_assessments: Tuple[NodeAssessment, ...]

    def __post_init__(self) -> None:
        node_ids = tuple(node.node_id for node in self.nodes)
        if set(node_ids) != set(self.decomposition.node_ids):
            raise ValueError(
                "proposal nodes must match decomposition node IDs"
            )
        assessment_ids = {
            assessment.node_id for assessment in self.initial_assessments
        }
        if not assessment_ids.issubset(set(node_ids)):
            raise ValueError(
                "proposal assessments must reference proposal nodes"
            )


@dataclass(frozen=True)
class PortfolioPolicy:
    max_nodes: int
    compute_budget: float
    minimum_distinct_decompositions: int = 1

    def __post_init__(self) -> None:
        if self.max_nodes <= 0 or self.compute_budget <= 0:
            raise ValueError("portfolio limits must be positive")
        if self.minimum_distinct_decompositions <= 0:
            raise ValueError(
                "minimum_distinct_decompositions must be positive"
            )


@dataclass(frozen=True)
class PortfolioDecision:
    selected_node_ids: Tuple[str, ...]
    deferred_node_ids: Tuple[str, ...]
    total_estimated_cost: float
    policy: PortfolioPolicy
    scores: Mapping[str, float]
    rationale: str

    @property
    def decision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "selected_node_ids": list(self.selected_node_ids),
            "deferred_node_ids": list(self.deferred_node_ids),
            "total_estimated_cost": self.total_estimated_cost,
            "policy": {
                "max_nodes": self.policy.max_nodes,
                "compute_budget": self.policy.compute_budget,
                "minimum_distinct_decompositions": (
                    self.policy.minimum_distinct_decompositions
                ),
            },
            "scores": dict(sorted(self.scores.items())),
            "rationale": self.rationale,
        }
        if include_id:
            value["decision_id"] = self.decision_id
        return value


@dataclass(frozen=True)
class ChildCampaignResult:
    node_id: str
    child_charter_id: str
    outcome: ChildCampaignOutcome
    evidence_ids: Tuple[str, ...]
    summary: str
    implications: Tuple[str, ...]
    compute_spent: float
    claim_id: Optional[str] = None
    claim_authorization_id: Optional[str] = None

    def __post_init__(self) -> None:
        if not (
            self.node_id
            and self.child_charter_id
            and self.summary
        ):
            raise ValueError("child result fields must not be empty")
        if not self.evidence_ids or not self.implications:
            raise ValueError(
                "child result requires evidence and implications"
            )
        if self.compute_spent < 0:
            raise ValueError("compute_spent must be non-negative")
        if (
            self.outcome == ChildCampaignOutcome.CONFIRMED
            and not self.claim_id
        ):
            raise ValueError("confirmed child results require a claim")
        if (
            self.outcome != ChildCampaignOutcome.CONFIRMED
            and (
                self.claim_id is not None
                or self.claim_authorization_id is not None
            )
        ):
            raise ValueError(
                "only confirmed child results may carry claim metadata"
            )

    @property
    def result_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "node_id": self.node_id,
            "child_charter_id": self.child_charter_id,
            "outcome": self.outcome.value,
            "evidence_ids": list(self.evidence_ids),
            "summary": self.summary,
            "implications": list(self.implications),
            "compute_spent": self.compute_spent,
            "claim_id": self.claim_id,
            "claim_authorization_id": self.claim_authorization_id,
        }
        if include_id:
            value["result_id"] = self.result_id
        return value


@dataclass(frozen=True)
class ProgramResolution:
    goal_id: str
    resolved: bool
    integration_gate_contract_id: str
    integration_gate_decision_id: str
    evidence_ids: Tuple[str, ...]
    satisfied_requirements: Tuple[str, ...]
    unresolved_critical_node_ids: Tuple[str, ...]
    waived_critical_nodes: Mapping[str, str]
    limitations: Tuple[str, ...]
    reasons: Tuple[str, ...] = field(default_factory=tuple)

    @property
    def resolution_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "goal_id": self.goal_id,
            "resolved": self.resolved,
            "integration_gate_contract_id": (
                self.integration_gate_contract_id
            ),
            "integration_gate_decision_id": (
                self.integration_gate_decision_id
            ),
            "evidence_ids": list(self.evidence_ids),
            "satisfied_requirements": list(
                self.satisfied_requirements
            ),
            "unresolved_critical_node_ids": list(
                self.unresolved_critical_node_ids
            ),
            "waived_critical_nodes": dict(
                sorted(self.waived_critical_nodes.items())
            ),
            "limitations": list(self.limitations),
            "reasons": list(self.reasons),
        }
        if include_id:
            value["resolution_id"] = self.resolution_id
        return value
