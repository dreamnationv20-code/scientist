from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.kernel.contracts import GateContract, GateKind
from scientist.kernel.gates import GateDecision, evaluate_gate
from scientist.program.campaigns import (
    CampaignPlateauDiagnosis,
    CampaignPlateauPolicy,
    CampaignRoundSummary,
    IncumbentPortfolio,
    IslandCampaignContract,
    IslandCampaignState,
    IslandCandidateProposal,
    ParentIntegrationRecord,
    TestExposureRecord,
    VerificationRecord,
)
from scientist.program.contracts import HighLevelGoal
from scientist.program.causal_failure import CausalFailureModelSet
from scientist.program.goal_graph import (
    DEFAULT_MAX_EVIDENCE_DEPTH,
    DEFAULT_MAX_META_COMPUTE_FRACTION,
    DependencyEdge,
    DependencyKind,
    DynamicGoalGraph,
    GOAL_GRAPH_ARCHITECTURE_VERSION,
    GoalGraphDecompositionProposal,
    GoalNodeKind,
    GoalNodeRole,
    GoalNodeSpec,
    GoalNodeStatus,
    ParentCompositionRule,
    STRICT_REPRESENTATION_REVISION_TRIGGER,
)
from scientist.program.interfaces import GoalGraphDecomposer
from scientist.program.inspiration import (
    CrossDomainInspirationPortfolio,
)
from scientist.program.horizon_diagnostics import (
    ConceptGroundedGeneratorRevision,
    ConceptValidation,
    EvaluationHorizon,
    HorizonContrast,
    HorizonFailureDossier,
    HorizonKind,
    HorizonOutcome,
    HorizonPrediction,
    LatentConceptHypothesis,
    RepresentationAdequacyAssessment,
)
from scientist.program.literature import (
    ClaimAuthorization,
    ClaimLevel,
    PriorArtAssessment,
)
from scientist.program.research_strategy import (
    RepresentationChangeProposal,
    ResearchProgramContract,
    ResearchProgramDiagnosis,
    StrategyDisposition,
)
from scientist.program.qualification import LeafQualificationRecord
from scientist.program.diagnostics import LeafDiagnosticRecord


class ScientificMemoryEventKind(str, Enum):
    GOAL_REGISTERED = "goal_registered"
    LITERATURE_ASSESSMENT_REGISTERED = (
        "literature_assessment_registered"
    )
    DECOMPOSITION_REGISTERED = "decomposition_registered"
    DECOMPOSITION_REVISED = "decomposition_revised"
    DEPENDENCY_REGISTERED = "dependency_registered"
    NODE_ASSESSED = "node_assessed"
    FRONTIER_SCHEDULED = "frontier_scheduled"
    INCUMBENT_PORTFOLIO_REGISTERED = (
        "incumbent_portfolio_registered"
    )
    ISLAND_CAMPAIGN_STARTED = "island_campaign_started"
    CANDIDATE_PROPOSED = "candidate_proposed"
    TEST_EXPOSURE_RECORDED = "test_exposure_recorded"
    VERIFICATION_RECORDED = "verification_recorded"
    LEAF_QUALIFICATION_RECORDED = "leaf_qualification_recorded"
    LEAF_DIAGNOSTIC_RECORDED = "leaf_diagnostic_recorded"
    LOCAL_CANDIDATE_NOMINATED = "local_candidate_nominated"
    CAMPAIGN_ROUND_COMPLETED = "campaign_round_completed"
    RESEARCH_PROGRAM_REGISTERED = "research_program_registered"
    RESEARCH_PROGRAM_DIAGNOSED = "research_program_diagnosed"
    REPRESENTATION_CHANGE_ADOPTED = "representation_change_adopted"
    EVALUATION_HORIZON_REGISTERED = "evaluation_horizon_registered"
    HORIZON_PREDICTION_REGISTERED = "horizon_prediction_registered"
    HORIZON_OUTCOME_RECORDED = "horizon_outcome_recorded"
    HORIZON_CONTRAST_REGISTERED = "horizon_contrast_registered"
    HORIZON_FAILURE_DOSSIER_REGISTERED = (
        "horizon_failure_dossier_registered"
    )
    REPRESENTATION_ADEQUACY_ASSESSED = (
        "representation_adequacy_assessed"
    )
    LATENT_CONCEPT_REGISTERED = "latent_concept_registered"
    CONCEPT_VALIDATION_RECORDED = "concept_validation_recorded"
    GENERATOR_REVISION_REGISTERED = "generator_revision_registered"
    AUTONOMOUS_CONCEPT_INDUCED = "autonomous_concept_induced"
    TYPED_POLICY_PROGRAM_SYNTHESIZED = (
        "typed_policy_program_synthesized"
    )
    BLIND_TRANSFER_VALIDATED = "blind_transfer_validated"
    LATENT_OBJECT_MODEL_FROZEN = "latent_object_model_frozen"
    LATENT_OBJECT_AUDIT_VALIDATED = "latent_object_audit_validated"
    LATENT_OBJECT_CAUSAL_TEST_VALIDATED = (
        "latent_object_causal_test_validated"
    )
    SELF_SUPERVISED_OBJECT_MODEL_FROZEN = (
        "self_supervised_object_model_frozen"
    )
    SELF_SUPERVISED_OBJECT_AUDIT_VALIDATED = (
        "self_supervised_object_audit_validated"
    )
    SELF_SUPERVISED_OBJECT_CAUSAL_TEST_VALIDATED = (
        "self_supervised_object_causal_test_validated"
    )
    BEHAVIORAL_PREDICATE_PROGRAMS_FROZEN = (
        "behavioral_predicate_programs_frozen"
    )
    BEHAVIORAL_PREDICATE_AUDIT_VALIDATED = (
        "behavioral_predicate_audit_validated"
    )
    BEHAVIORAL_PREDICATE_CAUSAL_TEST_VALIDATED = (
        "behavioral_predicate_causal_test_validated"
    )
    EXECUTABLE_SCHEMA_GRAMMAR_FROZEN = (
        "executable_schema_grammar_frozen"
    )
    SCHEMA_INDUCTION_AUDIT_VALIDATED = (
        "schema_induction_audit_validated"
    )
    SCHEMA_CAUSAL_TEST_VALIDATED = "schema_causal_test_validated"
    PRIMITIVE_INVENTION_CORE_FROZEN = "primitive_invention_core_frozen"
    PRIMITIVE_INVENTION_AUDIT_VALIDATED = (
        "primitive_invention_audit_validated"
    )
    AUTONOMOUS_EXPERIMENT_POLICY_FROZEN = (
        "autonomous_experiment_policy_frozen"
    )
    AUTONOMOUS_EXPERIMENT_AUDIT_VALIDATED = (
        "autonomous_experiment_audit_validated"
    )
    REPRESENTATION_REVISION_CORE_FROZEN = (
        "representation_revision_core_frozen"
    )
    REPRESENTATION_REVISION_AUDIT_VALIDATED = (
        "representation_revision_audit_validated"
    )
    NATURALISTIC_TRANSFER_ADAPTER_FROZEN = (
        "naturalistic_transfer_adapter_frozen"
    )
    NATURALISTIC_TRANSFER_AUDIT_VALIDATED = (
        "naturalistic_transfer_audit_validated"
    )
    AUTONOMOUS_SCIENTIFIC_CYCLE_FROZEN = (
        "autonomous_scientific_cycle_frozen"
    )
    AUTONOMOUS_SCIENTIFIC_CYCLE_AUDIT_VALIDATED = (
        "autonomous_scientific_cycle_audit_validated"
    )
    COGNITIVE_CORE_V1_RELEASE_FROZEN = "cognitive_core_v1_release_frozen"
    COGNITIVE_CORE_V1_REPLICATION_VALIDATED = (
        "cognitive_core_v1_replication_validated"
    )
    CONCEPT_GROUNDED_REPRESENTATION_CHANGE_ADOPTED = (
        "concept_grounded_representation_change_adopted"
    )
    RESEARCH_PROGRAM_PARKED = "research_program_parked"
    NODE_PLATEAUED = "node_plateaued"
    CAUSAL_FAILURE_MODELS_REGISTERED = (
        "causal_failure_models_registered"
    )
    CROSS_DOMAIN_INSPIRATION_REGISTERED = (
        "cross_domain_inspiration_registered"
    )
    PARENT_INTEGRATION_RECORDED = "parent_integration_recorded"
    NODE_REOPENED = "node_reopened"
    ROOT_GATE_EVALUATED = "root_gate_evaluated"
    ROOT_RESOLVED = "root_resolved"
    ROOT_UNRESOLVED = "root_unresolved"


@dataclass(frozen=True)
class ScientificMemoryEvent:
    sequence: int
    goal_id: str
    kind: ScientificMemoryEventKind
    payload: Mapping[str, Any]
    actor_ref: str
    previous_event_id: Optional[str]

    @property
    def event_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "sequence": self.sequence,
            "goal_id": self.goal_id,
            "kind": self.kind.value,
            "payload": dict(self.payload),
            "actor_ref": self.actor_ref,
            "previous_event_id": self.previous_event_id,
        }
        if include_id:
            value["event_id"] = self.event_id
        return value


class ScientificMemoryLedger:
    """Hash-chained, event-sourced memory for the v2 control plane."""

    def __init__(
        self,
        goal_id: str,
        artifact_store: Optional[ArtifactStore] = None,
    ) -> None:
        if not goal_id:
            raise ValueError("goal_id must not be empty")
        self.goal_id = goal_id
        self._events: Tuple[ScientificMemoryEvent, ...] = ()
        self._artifact_store = artifact_store
        self._artifact_digests: Tuple[str, ...] = ()

    @property
    def events(self) -> Tuple[ScientificMemoryEvent, ...]:
        return self._events

    def append(
        self,
        kind: ScientificMemoryEventKind,
        payload: Mapping[str, Any],
        actor_ref: str,
    ) -> ScientificMemoryEvent:
        if not actor_ref:
            raise ValueError("memory event actor must not be empty")
        if (
            not self._events
            and kind != ScientificMemoryEventKind.GOAL_REGISTERED
        ):
            raise ValueError("the first memory event must register the goal")
        if (
            self._events
            and kind == ScientificMemoryEventKind.GOAL_REGISTERED
        ):
            raise ValueError("the goal may be registered only once")
        if self._events and self._events[-1].kind in (
            ScientificMemoryEventKind.ROOT_RESOLVED,
            ScientificMemoryEventKind.ROOT_UNRESOLVED,
        ):
            raise ValueError("a terminal scientific memory is immutable")
        event = ScientificMemoryEvent(
            sequence=len(self._events),
            goal_id=self.goal_id,
            kind=kind,
            payload=dict(payload),
            actor_ref=actor_ref,
            previous_event_id=(
                None if not self._events else self._events[-1].event_id
            ),
        )
        self._events = (*self._events, event)
        if self._artifact_store is not None:
            digest = self._artifact_store.put(
                "goal_graph_scientific_memory_event",
                event.as_dict(),
            )
            self._artifact_digests = (*self._artifact_digests, digest)
        return event

    def verify_chain(self) -> bool:
        previous = None
        for index, event in enumerate(self._events):
            if event.sequence != index:
                return False
            if event.previous_event_id != previous:
                return False
            previous = event.event_id
        return True

    def as_dict(self) -> Dict[str, Any]:
        return {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "goal_id": self.goal_id,
            "event_count": len(self._events),
            "chain_valid": self.verify_chain(),
            "head_event_id": (
                None if not self._events else self._events[-1].event_id
            ),
            "events": [event.as_dict() for event in self._events],
            "artifact_digests": list(self._artifact_digests),
        }


class ControlActionKind(str, Enum):
    SURVEY_LITERATURE = "survey_literature"
    DECOMPOSE_NODE = "decompose_node"
    RUN_QUALIFICATION = "run_qualification"
    RUN_DIAGNOSTIC = "run_diagnostic"
    ESTABLISH_INCUMBENT = "establish_incumbent"
    START_CAMPAIGN = "start_campaign"
    CONTINUE_CAMPAIGN = "continue_campaign"
    RUN_PARENT_INTEGRATION = "run_parent_integration"
    RUN_ROOT_GATE = "run_root_gate"
    BUILD_CAUSAL_FAILURE_MODEL = "build_causal_failure_model"
    SEEK_CROSS_DOMAIN_INSPIRATION = "seek_cross_domain_inspiration"
    FREEZE_EVALUATION_HORIZONS = "freeze_evaluation_horizons"
    RECORD_HORIZON_EVIDENCE = "record_horizon_evidence"
    BUILD_HORIZON_FAILURE_DOSSIER = "build_horizon_failure_dossier"
    ASSESS_REPRESENTATION_ADEQUACY = "assess_representation_adequacy"
    INVENT_LATENT_CONCEPT = "invent_latent_concept"
    VALIDATE_LATENT_CONCEPT = "validate_latent_concept"
    REPAIR_HYPOTHESIS_GENERATOR = "repair_hypothesis_generator"
    REVISE_GRAPH = "revise_graph"
    REPORT_TERMINAL = "report_terminal"


@dataclass(frozen=True)
class ControlAction:
    kind: ControlActionKind
    node_id: str
    reason: str
    parent_id: Optional[str] = None

    @property
    def action_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kind": self.kind.value,
            "node_id": self.node_id,
            "parent_id": self.parent_id,
            "reason": self.reason,
        }
        if include_id:
            value["action_id"] = self.action_id
        return value


@dataclass(frozen=True)
class NodeSchedulingAssessment:
    node_id: str
    root_relevance: float
    value_of_information: float
    success_probability: float
    integration_leverage: float
    uncertainty: float
    estimated_cost: float
    basis: Tuple[str, ...]
    assessor_ref: str

    def __post_init__(self) -> None:
        factors = (
            self.root_relevance,
            self.value_of_information,
            self.success_probability,
            self.integration_leverage,
            self.uncertainty,
        )
        if any(value < 0.0 or value > 1.0 for value in factors):
            raise ValueError("scheduling factors must be in [0, 1]")
        if self.estimated_cost <= 0:
            raise ValueError("scheduling cost must be positive")
        if not self.node_id or not self.basis or not self.assessor_ref:
            raise ValueError("scheduling assessment requires provenance")

    @property
    def expected_root_progress(self) -> float:
        exploitation = (
            self.success_probability * self.integration_leverage
        )
        exploration = self.value_of_information * self.uncertainty
        return self.root_relevance * (exploitation + exploration)

    @property
    def priority_score(self) -> float:
        return self.expected_root_progress / self.estimated_cost

    def as_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "root_relevance": self.root_relevance,
            "value_of_information": self.value_of_information,
            "success_probability": self.success_probability,
            "integration_leverage": self.integration_leverage,
            "uncertainty": self.uncertainty,
            "estimated_cost": self.estimated_cost,
            "expected_root_progress": self.expected_root_progress,
            "priority_score": self.priority_score,
            "basis": list(self.basis),
            "assessor_ref": self.assessor_ref,
        }


@dataclass(frozen=True)
class FrontierSchedule:
    node_ids: Tuple[str, ...]
    deferred_node_ids: Tuple[str, ...]
    estimated_cost: float
    scores: Mapping[str, float]
    rationale: str

    @property
    def schedule_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "node_ids": list(self.node_ids),
            "deferred_node_ids": list(self.deferred_node_ids),
            "estimated_cost": self.estimated_cost,
            "scores": dict(sorted(self.scores.items())),
            "rationale": self.rationale,
        }
        if include_id:
            value["schedule_id"] = self.schedule_id
        return value


@dataclass(frozen=True)
class RootGateEvaluation:
    goal_id: str
    gate_contract_id: str
    gate_decision_id: str
    passed: bool
    evidence_ids: Tuple[str, ...]
    satisfied_requirements: Tuple[str, ...]
    limitations: Tuple[str, ...]
    reasons: Tuple[str, ...]

    @property
    def evaluation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "goal_id": self.goal_id,
            "gate_contract_id": self.gate_contract_id,
            "gate_decision_id": self.gate_decision_id,
            "passed": self.passed,
            "evidence_ids": list(self.evidence_ids),
            "satisfied_requirements": list(
                self.satisfied_requirements
            ),
            "limitations": list(self.limitations),
            "reasons": list(self.reasons),
        }
        if include_id:
            value["evaluation_id"] = self.evaluation_id
        return value


class RootTerminalState(str, Enum):
    ACHIEVED = "achieved"
    UNRESOLVED = "unresolved"


class RootUnresolvedReason(str, Enum):
    BUDGET_EXHAUSTED = "budget_exhausted"
    EXTERNAL_BLOCKED = "external_blocked"
    SAFETY_BLOCKED = "safety_blocked"
    UNMEASURABLE_GOAL = "unmeasurable_goal"


@dataclass(frozen=True)
class RootResolutionCertificate:
    goal_id: str
    terminal_state: RootTerminalState
    evidence_ids: Tuple[str, ...]
    compute_spent: float
    unresolved_node_ids: Tuple[str, ...]
    limitations: Tuple[str, ...]
    reasons: Tuple[str, ...]
    root_gate_evaluation_id: Optional[str] = None
    unresolved_reason: Optional[RootUnresolvedReason] = None
    blockers: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.goal_id or not self.limitations:
            raise ValueError("root certificate requires identity and limits")
        if self.compute_spent < 0:
            raise ValueError("root certificate compute must be non-negative")
        if self.terminal_state == RootTerminalState.ACHIEVED:
            if self.root_gate_evaluation_id is None:
                raise ValueError("achievement requires a passing root gate")
            if self.unresolved_reason is not None or self.blockers:
                raise ValueError(
                    "achievement cannot retain unresolved metadata"
                )
        else:
            if self.unresolved_reason is None:
                raise ValueError(
                    "unresolved certificate requires a terminal reason"
                )
            if not self.blockers:
                raise ValueError(
                    "unresolved certificate requires concrete blockers"
                )

    @property
    def certificate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "goal_id": self.goal_id,
            "terminal_state": self.terminal_state.value,
            "evidence_ids": list(self.evidence_ids),
            "compute_spent": self.compute_spent,
            "unresolved_node_ids": list(self.unresolved_node_ids),
            "limitations": list(self.limitations),
            "reasons": list(self.reasons),
            "root_gate_evaluation_id": self.root_gate_evaluation_id,
            "unresolved_reason": (
                None
                if self.unresolved_reason is None
                else self.unresolved_reason.value
            ),
            "blockers": list(self.blockers),
        }
        if include_id:
            value["certificate_id"] = self.certificate_id
        return value


class AutonomousScientistControlPlane:
    """Goal-graph authority using the optional isolated-search strategy.

    This is not the universal domain boundary. Heterogeneous research domains
    use ResearchProgramManager plus ScientificCampaignRuntime; this class adds
    incumbent portfolios and ancestry/de-novo/hybrid campaigns when a domain
    explicitly chooses that optimization strategy.

    Planners may propose graphs, candidates, and assessments. This object
    alone controls admissibility, evidence boundaries, upward integration,
    plateau state, and root termination.
    """

    def __init__(
        self,
        goal: HighLevelGoal,
        root: GoalNodeSpec,
        *,
        artifact_store: Optional[ArtifactStore] = None,
        controller_ref: str = "goal-graph-control-plane-v2",
    ) -> None:
        if not controller_ref:
            raise ValueError("controller_ref must not be empty")
        if root.goal_id != goal.goal_id:
            raise ValueError("root node belongs to another high-level goal")
        self.goal = goal
        self.controller_ref = controller_ref
        self.graph = DynamicGoalGraph(goal.goal_id, root)
        self.memory = ScientificMemoryLedger(
            goal.goal_id,
            artifact_store=artifact_store,
        )
        self._literature: Dict[
            str, Tuple[PriorArtAssessment, ...]
        ] = {}
        self._cross_domain_inspirations: Dict[
            str, Tuple[CrossDomainInspirationPortfolio, ...]
        ] = {}
        self._causal_failure_models: Dict[
            str, Tuple[CausalFailureModelSet, ...]
        ] = {}
        self._portfolios: Dict[str, IncumbentPortfolio] = {}
        self._current_portfolio_ids: Dict[str, str] = {}
        self._campaigns: Dict[str, IslandCampaignState] = {}
        self._active_campaign_ids: Dict[str, str] = {}
        self._research_programs: Dict[str, ResearchProgramContract] = {}
        self._active_research_program_ids: Dict[str, str] = {}
        self._research_program_diagnoses: Dict[
            str, Tuple[ResearchProgramDiagnosis, ...]
        ] = {}
        self._representation_changes: Dict[
            str, RepresentationChangeProposal
        ] = {}
        self._evaluation_horizons: Dict[str, EvaluationHorizon] = {}
        self._horizon_predictions: Dict[str, HorizonPrediction] = {}
        self._horizon_outcomes: Dict[str, HorizonOutcome] = {}
        self._horizon_contrasts: Dict[str, HorizonContrast] = {}
        self._horizon_dossiers: Dict[str, HorizonFailureDossier] = {}
        self._representation_adequacy_assessments: Dict[
            str, RepresentationAdequacyAssessment
        ] = {}
        self._latent_concepts: Dict[str, LatentConceptHypothesis] = {}
        self._concept_validations: Dict[str, ConceptValidation] = {}
        self._generator_revisions: Dict[
            str, ConceptGroundedGeneratorRevision
        ] = {}
        self._concept_grounded_representation_changes: Dict[str, str] = {}
        self._exposures: Dict[str, TestExposureRecord] = {}
        self._leaf_qualifications: Dict[
            str, Tuple[LeafQualificationRecord, ...]
        ] = {}
        self._leaf_diagnostics: Dict[
            str, Tuple[LeafDiagnosticRecord, ...]
        ] = {}
        self._integrations: Dict[
            str, Tuple[ParentIntegrationRecord, ...]
        ] = {}
        self._scheduling_assessments: Dict[
            str, NodeSchedulingAssessment
        ] = {}
        self._root_gate_evaluations: Tuple[RootGateEvaluation, ...] = ()
        self._resolution: Optional[RootResolutionCertificate] = None
        self.memory.append(
            ScientificMemoryEventKind.GOAL_REGISTERED,
            {
                "goal": goal.as_dict(),
                "root": root.as_dict(),
            },
            actor_ref=self.controller_ref,
        )

    @property
    def resolution(self) -> Optional[RootResolutionCertificate]:
        return self._resolution

    @property
    def campaigns(self) -> Mapping[str, IslandCampaignState]:
        return dict(self._campaigns)

    @property
    def cross_domain_inspirations(
        self,
    ) -> Mapping[str, Tuple[CrossDomainInspirationPortfolio, ...]]:
        return dict(self._cross_domain_inspirations)

    @property
    def active_campaign_ids(self) -> Mapping[str, str]:
        return dict(self._active_campaign_ids)

    @property
    def research_programs(self) -> Mapping[str, ResearchProgramContract]:
        return dict(self._research_programs)

    @property
    def active_research_program_ids(self) -> Mapping[str, str]:
        return dict(self._active_research_program_ids)

    @property
    def research_program_diagnoses(
        self,
    ) -> Mapping[str, Tuple[ResearchProgramDiagnosis, ...]]:
        return dict(self._research_program_diagnoses)

    @property
    def representation_changes(
        self,
    ) -> Mapping[str, RepresentationChangeProposal]:
        return dict(self._representation_changes)

    @property
    def evaluation_horizons(self) -> Mapping[str, EvaluationHorizon]:
        return dict(self._evaluation_horizons)

    @property
    def horizon_predictions(self) -> Mapping[str, HorizonPrediction]:
        return dict(self._horizon_predictions)

    @property
    def horizon_outcomes(self) -> Mapping[str, HorizonOutcome]:
        return dict(self._horizon_outcomes)

    @property
    def horizon_contrasts(self) -> Mapping[str, HorizonContrast]:
        return dict(self._horizon_contrasts)

    @property
    def horizon_dossiers(self) -> Mapping[str, HorizonFailureDossier]:
        return dict(self._horizon_dossiers)

    @property
    def representation_adequacy_assessments(
        self,
    ) -> Mapping[str, RepresentationAdequacyAssessment]:
        return dict(self._representation_adequacy_assessments)

    @property
    def latent_concepts(self) -> Mapping[str, LatentConceptHypothesis]:
        return dict(self._latent_concepts)

    @property
    def concept_validations(self) -> Mapping[str, ConceptValidation]:
        return dict(self._concept_validations)

    @property
    def generator_revisions(
        self,
    ) -> Mapping[str, ConceptGroundedGeneratorRevision]:
        return dict(self._generator_revisions)

    @property
    def exposures(self) -> Mapping[str, TestExposureRecord]:
        return dict(self._exposures)

    @property
    def leaf_qualifications(
        self,
    ) -> Mapping[str, Tuple[LeafQualificationRecord, ...]]:
        return dict(self._leaf_qualifications)

    def current_leaf_qualification(
        self,
        node_id: str,
    ) -> Optional[LeafQualificationRecord]:
        history = self._leaf_qualifications.get(node_id, ())
        return None if not history else history[-1]

    @property
    def leaf_diagnostics(
        self,
    ) -> Mapping[str, Tuple[LeafDiagnosticRecord, ...]]:
        return dict(self._leaf_diagnostics)

    def current_leaf_diagnostic(
        self,
        node_id: str,
    ) -> Optional[LeafDiagnosticRecord]:
        history = self._leaf_diagnostics.get(node_id, ())
        return None if not history else history[-1]

    @property
    def compute_spent(self) -> float:
        campaign_compute = sum(
            campaign.compute_spent
            for campaign in self._campaigns.values()
        )
        qualification_compute = sum(
            record.compute_cost
            for records in self._leaf_qualifications.values()
            for record in records
        )
        diagnostic_compute = sum(
            record.compute_cost
            for records in self._leaf_diagnostics.values()
            for record in records
        )
        return campaign_compute + qualification_compute + diagnostic_compute

    @property
    def compute_remaining(self) -> float:
        return max(
            0.0,
            self.goal.total_compute_budget - self.compute_spent,
        )

    @property
    def compute_committed(self) -> float:
        return sum(
            max(
                0.0,
                self._campaigns[campaign_id].contract.total_compute_budget
                - self._campaigns[campaign_id].compute_spent,
            )
            for campaign_id in self._active_campaign_ids.values()
        )

    @property
    def compute_available_for_new_campaigns(self) -> float:
        return max(0.0, self.compute_remaining - self.compute_committed)

    @property
    def evidence_compute_spent(self) -> float:
        """Compute used by meta-evidence rather than functional objectives."""

        campaign_compute = sum(
            campaign.compute_spent
            for campaign in self._campaigns.values()
            if self.graph.nodes[campaign.contract.node_id].effective_role
            == GoalNodeRole.EVIDENCE
        )
        qualification_compute = sum(
            record.compute_cost
            for node_id, records in self._leaf_qualifications.items()
            if self.graph.nodes[node_id].effective_role
            == GoalNodeRole.EVIDENCE
            for record in records
        )
        diagnostic_compute = sum(
            record.compute_cost
            for node_id, records in self._leaf_diagnostics.items()
            if self.graph.nodes[node_id].effective_role
            == GoalNodeRole.EVIDENCE
            for record in records
        )
        horizon_compute = sum(
            outcome.compute_spent for outcome in self._horizon_outcomes.values()
        )
        return (
            campaign_compute
            + qualification_compute
            + diagnostic_compute
            + horizon_compute
        )

    @property
    def evidence_compute_committed(self) -> float:
        return sum(
            max(
                0.0,
                self._campaigns[campaign_id].contract.total_compute_budget
                - self._campaigns[campaign_id].compute_spent,
            )
            for node_id, campaign_id in self._active_campaign_ids.items()
            if self.graph.nodes[node_id].effective_role
            == GoalNodeRole.EVIDENCE
        )

    @property
    def evidence_compute_limit(self) -> float:
        fraction = (
            DEFAULT_MAX_META_COMPUTE_FRACTION
            if self.graph.has_explicit_role_separation
            else 1.0
        )
        return self.goal.total_compute_budget * fraction

    @property
    def evidence_compute_available(self) -> float:
        return max(
            0.0,
            self.evidence_compute_limit
            - self.evidence_compute_spent
            - self.evidence_compute_committed,
        )

    @property
    def objective_evidence_policy(self) -> Mapping[str, Any]:
        return {
            "active": self.graph.has_explicit_role_separation,
            "max_new_evidence_depth": DEFAULT_MAX_EVIDENCE_DEPTH,
            "maximum_meta_compute_fraction": (
                DEFAULT_MAX_META_COMPUTE_FRACTION
            ),
            "evidence_compute_spent": self.evidence_compute_spent,
            "evidence_compute_committed": self.evidence_compute_committed,
            "evidence_compute_available": self.evidence_compute_available,
            "representation_revision_trigger": (
                STRICT_REPRESENTATION_REVISION_TRIGGER
            ),
            "generic_representation_revision_allowed": (
                not self.graph.has_explicit_role_separation
            ),
        }

    @property
    def continuation_required(self) -> bool:
        return self._resolution is None and self.compute_remaining > 0

    def next_horizon_diagnostic_action(
        self,
        node_id: str,
    ) -> Optional[ControlAction]:
        """Return the next fail-closed step in the diagnostic-to-generative loop."""

        if node_id not in self.graph.nodes:
            raise ValueError("diagnostic action targets an unknown goal node")
        horizons = tuple(
            item
            for item in self._evaluation_horizons.values()
            if item.node_id == node_id
        )
        if not horizons:
            return ControlAction(
                kind=ControlActionKind.FREEZE_EVALUATION_HORIZONS,
                node_id=node_id,
                reason=(
                    "local and terminal horizons must be identified before "
                    "candidate outcomes are observed"
                ),
            )
        outcomes = tuple(
            item
            for item in self._horizon_outcomes.values()
            if item.node_id == node_id
        )
        observed_horizon_ids = {item.horizon_id for item in outcomes}
        if len(observed_horizon_ids) < 2:
            return ControlAction(
                kind=ControlActionKind.RECORD_HORIZON_EVIDENCE,
                node_id=node_id,
                reason=(
                    "the same frozen hypotheses need evidence at two or more "
                    "registered horizons"
                ),
            )
        contrasts = tuple(
            item
            for item in self._horizon_contrasts.values()
            if item.node_id == node_id
        )
        dossiers = tuple(
            item
            for item in self._horizon_dossiers.values()
            if item.node_id == node_id
        )
        if not contrasts or not dossiers:
            return ControlAction(
                kind=ControlActionKind.BUILD_HORIZON_FAILURE_DOSSIER,
                node_id=node_id,
                reason=(
                    "matched local successes that transfer and fail must be "
                    "contrasted before another solution search"
                ),
            )
        dossier = dossiers[-1]
        assessments = tuple(
            item
            for item in self._representation_adequacy_assessments.values()
            if item.dossier_id == dossier.dossier_id
        )
        if not assessments:
            return ControlAction(
                kind=ControlActionKind.ASSESS_REPRESENTATION_ADEQUACY,
                node_id=node_id,
                reason=(
                    "test whether current descriptors predict opposing "
                    "terminal outcomes on held-out contrasts"
                ),
            )
        assessment = assessments[-1]
        if not assessment.representation_insufficient:
            return None
        concepts = tuple(
            item
            for item in self._latent_concepts.values()
            if item.adequacy_assessment_id == assessment.assessment_id
        )
        if not concepts:
            return ControlAction(
                kind=ControlActionKind.INVENT_LATENT_CONCEPT,
                node_id=node_id,
                reason=(
                    "the frozen representation cannot explain the contrast; "
                    "invent a falsifiable missing concept"
                ),
            )
        concept_ids = {item.concept_id for item in concepts}
        validations = tuple(
            item
            for item in self._concept_validations.values()
            if item.concept_id in concept_ids
        )
        validated_concept_ids = {item.concept_id for item in validations}
        if any(
            item.concept_id not in validated_concept_ids for item in concepts
        ):
            return ControlAction(
                kind=ControlActionKind.VALIDATE_LATENT_CONCEPT,
                node_id=node_id,
                reason=(
                    "an invented concept needs prospective contrasts collected "
                    "after its registration before it can affect generation"
                ),
            )
        if not any(item.passed for item in validations):
            return ControlAction(
                kind=ControlActionKind.BUILD_HORIZON_FAILURE_DOSSIER,
                node_id=node_id,
                reason=(
                    "all concepts failed prospective validation; incorporate "
                    "those failures into a new dossier before inventing again"
                ),
            )
        passing_ids = {
            item.validation_id for item in validations if item.passed
        }
        if not any(
            item.concept_validation_id in passing_ids
            for item in self._generator_revisions.values()
        ):
            return ControlAction(
                kind=ControlActionKind.REPAIR_HYPOTHESIS_GENERATOR,
                node_id=node_id,
                reason=(
                    "the validated concept must change the hypothesis language "
                    "and produce behaviorally distinct proposals"
                ),
            )
        return None

    def next_actions(self) -> Tuple[ControlAction, ...]:
        """Return deterministic work that keeps attention on the root goal."""

        if self._resolution is not None:
            return (
                ControlAction(
                    kind=ControlActionKind.REPORT_TERMINAL,
                    node_id=self.graph.root_id,
                    reason=(
                        "the root has a %s certificate"
                        % self._resolution.terminal_state.value
                    ),
                ),
            )

        actions = []
        for node_id, node in sorted(self.graph.nodes.items()):
            status = self.graph.status(node_id)
            literature = self.current_literature(node_id)
            if status in (
                GoalNodeStatus.INVALIDATED,
                GoalNodeStatus.SUPERSEDED,
                GoalNodeStatus.INTEGRATED,
            ):
                continue
            if (
                status == GoalNodeStatus.PROPOSED
                and node.kind == GoalNodeKind.EXECUTABLE_LEAF
                and not self.graph.requirements_met(node_id)
            ):
                # A frozen downstream experiment is waiting for prerequisite
                # objective progress. Do not spend on its literature or search
                # program before that dependency integrates.
                continue
            if (
                literature is None
                and (
                    node.role != GoalNodeRole.OBJECTIVE
                    or node.kind == GoalNodeKind.EXECUTABLE_LEAF
                )
            ):
                actions.append(
                    ControlAction(
                        kind=ControlActionKind.SURVEY_LITERATURE,
                        node_id=node_id,
                        reason=(
                            "literature closure is required before "
                            "decomposition or solution search"
                        ),
                    )
                )
                continue
            if (
                "horizon-transport" in node.tags
                and status
                in (
                    GoalNodeStatus.READY,
                    GoalNodeStatus.SEARCHING,
                    GoalNodeStatus.INTEGRATION_FAILED,
                    GoalNodeStatus.PLATEAUED,
                    GoalNodeStatus.BLOCKED,
                )
            ):
                diagnostic_action = self.next_horizon_diagnostic_action(node_id)
                if diagnostic_action is not None:
                    actions.append(diagnostic_action)
                    continue
            if status == GoalNodeStatus.PROPOSED:
                actions.append(
                    ControlAction(
                        kind=ControlActionKind.DECOMPOSE_NODE,
                        node_id=node_id,
                        reason=(
                            "turn the unresolved question into falsifiable "
                            "children or an executable leaf"
                        ),
                    )
                )
                continue
            if status == GoalNodeStatus.READY:
                if node.kind != GoalNodeKind.EXECUTABLE_LEAF:
                    actions.append(
                        ControlAction(
                            kind=ControlActionKind.DECOMPOSE_NODE,
                            node_id=node_id,
                            reason="non-leaf nodes cannot enter experiment search",
                        )
                    )
                elif "qualification" in node.tags:
                    actions.append(
                        ControlAction(
                            kind=ControlActionKind.RUN_QUALIFICATION,
                            node_id=node_id,
                            reason=(
                                "the frozen infrastructure leaf requires direct "
                                "conformance evidence, not solution search"
                            ),
                        )
                    )
                elif "diagnostic" in node.tags:
                    actions.append(
                        ControlAction(
                            kind=ControlActionKind.RUN_DIAGNOSTIC,
                            node_id=node_id,
                            reason=(
                                "the frozen causal leaf requires matched "
                                "interventions and may resolve as supported, "
                                "refuted, mixed, or inconclusive"
                            ),
                        )
                    )
                elif node_id not in self._current_portfolio_ids:
                    actions.append(
                        ControlAction(
                            kind=ControlActionKind.ESTABLISH_INCUMBENT,
                            node_id=node_id,
                            reason=(
                                "reproduce the strongest literature-grounded "
                                "incumbent before searching"
                            ),
                        )
                    )
                elif node_id not in self._active_campaign_ids:
                    actions.append(
                        ControlAction(
                            kind=ControlActionKind.START_CAMPAIGN,
                            node_id=node_id,
                            reason=(
                                "the executable leaf is ready for matched "
                                "incremental, de-novo, and hybrid search"
                            ),
                        )
                    )
                continue
            if status in (
                GoalNodeStatus.SEARCHING,
                GoalNodeStatus.INTEGRATION_FAILED,
            ):
                if node_id in self._active_campaign_ids:
                    actions.append(
                        ControlAction(
                            kind=ControlActionKind.CONTINUE_CAMPAIGN,
                            node_id=node_id,
                            reason=(
                                "the root remains unresolved and this campaign "
                                "has not produced an integrated result or plateau"
                            ),
                        )
                    )
                else:
                    actions.append(
                        ControlAction(
                            kind=ControlActionKind.REVISE_GRAPH,
                            node_id=node_id,
                            reason=(
                                "the failed integration needs a new campaign "
                                "or a revised causal decomposition"
                            ),
                        )
                    )
                continue
            if status in (
                GoalNodeStatus.LOCALLY_VALIDATED,
                GoalNodeStatus.INTEGRATION_PENDING,
            ):
                if node_id == self.graph.root_id:
                    unresolved_evidence = tuple(
                        evidence_id
                        for evidence_id, evidence_node
                        in self.graph.nodes.items()
                        if evidence_node.effective_role
                        == GoalNodeRole.EVIDENCE
                        and evidence_node.critical
                        and self.graph.status(evidence_id)
                        != GoalNodeStatus.INTEGRATED
                    )
                    if not unresolved_evidence:
                        actions.append(
                            ControlAction(
                                kind=ControlActionKind.RUN_ROOT_GATE,
                                node_id=node_id,
                                reason=(
                                    "all objective children and independent "
                                    "evidence gates are integrated; run the "
                                    "frozen terminal experiment"
                                ),
                            )
                        )
                else:
                    for parent_id in self.graph.parents_of(node_id):
                        if not self.graph.parent_edge_integrated(
                            node_id,
                            parent_id,
                        ):
                            actions.append(
                                ControlAction(
                                    kind=(
                                        ControlActionKind
                                        .RUN_PARENT_INTEGRATION
                                    ),
                                    node_id=node_id,
                                    parent_id=parent_id,
                                    reason=(
                                        "local evidence must causally improve "
                                        "this parent before promotion"
                                    ),
                                )
                            )
                continue
            if status in (
                GoalNodeStatus.PLATEAUED,
                GoalNodeStatus.BLOCKED,
            ):
                if (
                    status == GoalNodeStatus.PLATEAUED
                    and self.current_cross_domain_inspiration(node_id) is None
                ):
                    if self.current_causal_failure_models(node_id) is None:
                        actions.append(
                            ControlAction(
                                kind=(
                                    ControlActionKind
                                    .BUILD_CAUSAL_FAILURE_MODEL
                                ),
                                node_id=node_id,
                                reason=(
                                    "every observed failure cluster needs a "
                                    "causal model before analogy retrieval"
                                ),
                            )
                        )
                        continue
                    actions.append(
                        ControlAction(
                            kind=(
                                ControlActionKind
                                .SEEK_CROSS_DOMAIN_INSPIRATION
                            ),
                            node_id=node_id,
                            reason=(
                                "a plateau must generate and stress-test "
                                "cross-domain mechanism transfers before "
                                "the graph is revised"
                            ),
                        )
                    )
                    continue
                actions.append(
                    ControlAction(
                        kind=ControlActionKind.REVISE_GRAPH,
                        node_id=node_id,
                        reason=(
                            "a local plateau is reversible and cannot "
                            "terminate an unresolved root goal"
                        ),
                    )
                )
        if self.graph.has_explicit_role_separation:
            actions.sort(
                key=lambda action: (
                    0
                    if self.graph.nodes[action.node_id].effective_role
                    == GoalNodeRole.OBJECTIVE
                    else 1,
                    self.graph.objective_distance(action.node_id),
                    action.node_id,
                    "" if action.parent_id is None else action.parent_id,
                )
            )
        return tuple(actions)

    def _ensure_open(self) -> None:
        if self._resolution is not None:
            raise ValueError("the root goal already has a terminal certificate")

    def current_literature(
        self,
        subject_id: str,
    ) -> Optional[PriorArtAssessment]:
        history = self._literature.get(subject_id, ())
        return None if not history else history[-1]

    def current_cross_domain_inspiration(
        self,
        node_id: str,
    ) -> Optional[CrossDomainInspirationPortfolio]:
        history = self._cross_domain_inspirations.get(node_id, ())
        return None if not history else history[-1]

    def current_causal_failure_models(
        self,
        node_id: str,
    ) -> Optional[CausalFailureModelSet]:
        registered = self._causal_failure_models.get(node_id, ())
        if registered:
            return registered[-1]
        observed = tuple(
            (
                campaign.contract.cycle_index,
                summary.round_index,
                campaign.contract.campaign_id,
                summary.causal_failure_models,
            )
            for campaign in self._campaigns.values()
            if campaign.contract.node_id == node_id
            for summary in campaign.rounds
            if summary.causal_failure_models is not None
        )
        if not observed:
            return None
        ordered = tuple(
            item[3] for item in sorted(observed, key=lambda item: item[:3])
        )
        if len(ordered) == 1:
            result = ordered[0]
            assert result is not None
            return result
        models = tuple(
            model
            for model_set in ordered
            if model_set is not None
            for model in model_set.models
        )
        source_artifact_ids = tuple(
            dict.fromkeys(
                artifact_id
                for model_set in ordered
                if model_set is not None
                for artifact_id in model_set.source_artifact_ids
            )
        )
        return CausalFailureModelSet(
            target_node_id=node_id,
            failure_cluster_ids=tuple(
                model.cluster_id for model in models
            ),
            models=models,
            source_artifact_ids=source_artifact_ids,
            builder_ref="campaign-causal-model-aggregate-v1",
        )

    def register_causal_failure_models(
        self,
        model_set: CausalFailureModelSet,
    ) -> str:
        self._ensure_open()
        node_id = model_set.target_node_id
        if node_id not in self.graph.nodes:
            raise ValueError(
                "causal failure models target an unknown goal node"
            )
        if self.graph.status(node_id) not in (
            GoalNodeStatus.PLATEAUED,
            GoalNodeStatus.BLOCKED,
            GoalNodeStatus.INTEGRATION_FAILED,
        ):
            raise ValueError(
                "causal failure modeling requires a failed or plateaued node"
            )
        if not model_set.coverage_complete:
            raise ValueError(
                "causal failure models do not cover every cluster"
            )
        history = self._causal_failure_models.get(node_id, ())
        if any(
            item.model_set_id == model_set.model_set_id
            for item in history
        ):
            raise ValueError(
                "causal failure model set is already registered"
            )
        self._causal_failure_models[node_id] = (*history, model_set)
        self.memory.append(
            ScientificMemoryEventKind.CAUSAL_FAILURE_MODELS_REGISTERED,
            model_set.as_dict(),
            actor_ref=model_set.builder_ref,
        )
        return model_set.model_set_id

    def register_cross_domain_inspiration(
        self,
        portfolio: CrossDomainInspirationPortfolio,
    ) -> str:
        self._ensure_open()
        node_id = portfolio.target_node_id
        if node_id not in self.graph.nodes:
            raise ValueError(
                "cross-domain inspiration targets an unknown goal node"
            )
        self._require_current_literature(node_id)
        if self.graph.status(node_id) not in (
            GoalNodeStatus.PLATEAUED,
            GoalNodeStatus.BLOCKED,
            GoalNodeStatus.INTEGRATION_FAILED,
        ):
            raise ValueError(
                "cross-domain inspiration requires a failed or plateaued node"
            )
        causal_models = self.current_causal_failure_models(node_id)
        if causal_models is None:
            raise ValueError(
                "cross-domain inspiration requires causal models for every "
                "failure cluster"
            )
        if portfolio.causal_failure_models is None:
            raise ValueError(
                "cross-domain inspiration omits its causal failure models"
            )
        if (
            portfolio.causal_failure_models.model_set_id
            != causal_models.model_set_id
        ):
            raise ValueError(
                "cross-domain inspiration uses stale causal failure models"
            )
        history = self._cross_domain_inspirations.get(node_id, ())
        if any(
            item.portfolio_id == portfolio.portfolio_id
            for item in history
        ):
            raise ValueError(
                "cross-domain inspiration portfolio is already registered"
            )
        self._cross_domain_inspirations[node_id] = (*history, portfolio)
        self.memory.append(
            ScientificMemoryEventKind.CROSS_DOMAIN_INSPIRATION_REGISTERED,
            portfolio.as_dict(),
            actor_ref=portfolio.synthesizer_ref,
        )
        return portfolio.portfolio_id

    def register_literature_assessment(
        self,
        assessment: PriorArtAssessment,
    ) -> str:
        self._ensure_open()
        subject_id = assessment.signature.subject_id
        if subject_id not in self.graph.nodes:
            raise ValueError(
                "literature assessment references an unknown goal node"
            )
        if not assessment.closure_passed:
            raise ValueError(
                "literature review is not closed: %s"
                % "; ".join(assessment.closure_failures)
            )
        if not assessment.closest_works:
            raise ValueError(
                "every goal node requires recorded closest prior work"
            )
        history = self._literature.get(subject_id, ())
        if any(
            item.assessment_id == assessment.assessment_id
            for item in history
        ):
            raise ValueError("literature assessment is already registered")
        self._literature[subject_id] = (*history, assessment)
        self.memory.append(
            ScientificMemoryEventKind.LITERATURE_ASSESSMENT_REGISTERED,
            assessment.as_dict(),
            actor_ref=assessment.reviewer_ref,
        )
        return assessment.assessment_id

    def _require_current_literature(
        self,
        node_id: str,
    ) -> PriorArtAssessment:
        assessment = self.current_literature(node_id)
        if assessment is None:
            raise ValueError(
                "node requires a closed literature survey before action"
            )
        return assessment

    def add_decomposition(
        self,
        nodes: Sequence[GoalNodeSpec],
        rule: ParentCompositionRule,
        *,
        assumptions: Sequence[str] = (),
        distinguishing_predictions: Sequence[str] = (),
        reasoning: str = "",
    ) -> None:
        self._ensure_open()
        parent = self.graph.nodes[rule.parent_id]
        if parent.role != GoalNodeRole.OBJECTIVE:
            self._require_current_literature(rule.parent_id)
        if nodes:
            self.graph.add_nodes(tuple(nodes))
        self.graph.set_composition_rule(rule)
        self.memory.append(
            ScientificMemoryEventKind.DECOMPOSITION_REGISTERED,
            {
                "nodes": [node.as_dict() for node in nodes],
                "rule": rule.as_dict(),
                "assumptions": list(assumptions),
                "distinguishing_predictions": list(
                    distinguishing_predictions
                ),
                "reasoning": reasoning,
            },
            actor_ref=rule.decomposer_ref,
        )

    def revise_decomposition(
        self,
        nodes: Sequence[GoalNodeSpec],
        rule: ParentCompositionRule,
        evidence_ids: Sequence[str],
        reason: str,
        *,
        assumptions: Sequence[str] = (),
        distinguishing_predictions: Sequence[str] = (),
    ) -> None:
        self._ensure_open()
        if not evidence_ids or not reason:
            raise ValueError(
                "decomposition revision requires evidence and a reason"
            )
        parent = self.graph.nodes[rule.parent_id]
        if parent.role != GoalNodeRole.OBJECTIVE:
            self._require_current_literature(rule.parent_id)
        previous_rule = self.graph.active_rule(rule.parent_id)
        if previous_rule is None:
            raise ValueError(
                "decomposition revision requires an active prior rule"
            )
        removed_children = set(previous_rule.child_ids).difference(
            rule.child_ids
        )
        orphaned_children = tuple(
            sorted(
                child_id
                for child_id in removed_children
                if self.graph.nodes[child_id].effective_role
                != GoalNodeRole.EVIDENCE
                if not any(
                    child_id in active.child_ids
                    for parent_id in self.graph.nodes
                    if parent_id != rule.parent_id
                    for active in (
                        self.graph.active_rule(parent_id),
                    )
                    if active is not None
                )
                and not any(
                    edge.kind == DependencyKind.SUPPORTS
                    and edge.source_id == child_id
                    for edge in self.graph.dependencies.values()
                )
            )
        )
        plateaued_children = tuple(
            child_id
            for child_id in orphaned_children
            if self.graph.status(child_id) == GoalNodeStatus.PLATEAUED
        )
        missing_inspiration = tuple(
            child_id
            for child_id in plateaued_children
            if self.current_cross_domain_inspiration(child_id) is None
        )
        if missing_inspiration:
            raise ValueError(
                "plateau revision requires cross-domain inspiration for: %s"
                % ", ".join(missing_inspiration)
            )
        supersedable = {
            GoalNodeStatus.PROPOSED,
            GoalNodeStatus.DECOMPOSED,
            GoalNodeStatus.READY,
            GoalNodeStatus.INTEGRATION_FAILED,
            GoalNodeStatus.INTEGRATED,
            GoalNodeStatus.PLATEAUED,
            GoalNodeStatus.BLOCKED,
            GoalNodeStatus.INVALIDATED,
        }
        if any(
            self.graph.status(child_id) not in supersedable
            for child_id in orphaned_children
        ):
            raise ValueError(
                "active or locally validated children cannot be superseded"
            )
        if nodes:
            self.graph.add_nodes(tuple(nodes))
        self.graph.set_composition_rule(rule)
        for child_id in orphaned_children:
            self.graph.transition(
                child_id,
                GoalNodeStatus.SUPERSEDED,
            )
        self.memory.append(
            ScientificMemoryEventKind.DECOMPOSITION_REVISED,
            {
                "new_nodes": [node.as_dict() for node in nodes],
                "rule": rule.as_dict(),
                "evidence_ids": list(evidence_ids),
                "reason": reason,
                "assumptions": list(assumptions),
                "distinguishing_predictions": list(
                    distinguishing_predictions
                ),
                "superseded_node_ids": list(orphaned_children),
                "cross_domain_inspiration_portfolio_ids": [
                    self.current_cross_domain_inspiration(
                        child_id
                    ).portfolio_id
                    for child_id in plateaued_children
                ],
                "causal_failure_model_set_ids": [
                    self.current_cross_domain_inspiration(
                        child_id
                    ).causal_failure_models.model_set_id
                    for child_id in plateaued_children
                ],
                "causal_failure_model_ids": [
                    model.model_id
                    for child_id in plateaued_children
                    for model in (
                        self.current_cross_domain_inspiration(
                            child_id
                        ).causal_failure_models.models
                    )
                ],
                "selected_cross_domain_inspiration_ids": [
                    inspiration_id
                    for child_id in plateaued_children
                    for inspiration_id in (
                        self.current_cross_domain_inspiration(
                            child_id
                        ).selected_inspiration_ids
                    )
                ],
                "hypothesis_tournament_ids": [
                    portfolio.tournament.tournament_id
                    for child_id in plateaued_children
                    for portfolio in (
                        self.current_cross_domain_inspiration(
                            child_id
                        ),
                    )
                    if portfolio.tournament is not None
                ],
                "selected_tournament_hypothesis_ids": [
                    (
                        portfolio.tournament.eligible_champion_id
                        or next(
                            hypothesis.hypothesis_id
                            for hypothesis
                            in portfolio.tournament.hypotheses
                            if hypothesis.inspiration_ids
                        )
                    )
                    for child_id in plateaued_children
                    for portfolio in (
                        self.current_cross_domain_inspiration(
                            child_id
                        ),
                    )
                    if portfolio.tournament is not None
                ],
            },
            actor_ref=rule.decomposer_ref,
        )

    def solicit_decomposition(
        self,
        node_id: str,
        decomposer: GoalGraphDecomposer,
        *,
        revision_evidence_ids: Sequence[str] = (),
        revision_reason: str = "",
    ) -> GoalGraphDecompositionProposal:
        """Ask a replaceable planner, then deterministically validate it."""

        self._ensure_open()
        try:
            parent = self.graph.nodes[node_id]
        except KeyError:
            raise ValueError("cannot decompose an unknown goal node")
        literature = self._require_current_literature(node_id)
        proposal = decomposer.decompose(
            self.goal,
            parent,
            self.graph.nodes,
            literature,
        )
        if proposal.parent_id != node_id:
            raise ValueError("decomposer returned a different parent")
        existing_rule = self.graph.active_rule(node_id)
        new_nodes = tuple(
            node
            for node in proposal.nodes
            if node.node_id not in self.graph.nodes
        )
        if existing_rule is None:
            self.add_decomposition(
                new_nodes,
                proposal.rule,
                assumptions=proposal.assumptions,
                distinguishing_predictions=(
                    proposal.distinguishing_predictions
                ),
                reasoning=proposal.reasoning,
            )
        else:
            self.revise_decomposition(
                new_nodes,
                proposal.rule,
                revision_evidence_ids,
                revision_reason,
                assumptions=proposal.assumptions,
                distinguishing_predictions=(
                    proposal.distinguishing_predictions
                ),
            )
        return proposal

    def add_dependency(
        self,
        edge: DependencyEdge,
        actor_ref: str,
    ) -> None:
        self._ensure_open()
        self.graph.add_dependency(edge)
        self.memory.append(
            ScientificMemoryEventKind.DEPENDENCY_REGISTERED,
            edge.as_dict(),
            actor_ref=actor_ref,
        )

    def assess_nodes(
        self,
        assessments: Sequence[NodeSchedulingAssessment],
    ) -> None:
        self._ensure_open()
        for assessment in assessments:
            if assessment.node_id not in self.graph.nodes:
                raise ValueError(
                    "scheduling assessment references an unknown node"
                )
            self._scheduling_assessments[
                assessment.node_id
            ] = assessment
            self.memory.append(
                ScientificMemoryEventKind.NODE_ASSESSED,
                assessment.as_dict(),
                actor_ref=assessment.assessor_ref,
            )

    def schedule_frontier(
        self,
        max_nodes: int,
        compute_budget: float,
    ) -> FrontierSchedule:
        self._ensure_open()
        if max_nodes <= 0 or compute_budget <= 0:
            raise ValueError("frontier schedule limits must be positive")
        available_slots = (
            self.goal.max_parallel_campaigns
            - len(self._active_campaign_ids)
        )
        if available_slots <= 0:
            raise ValueError("no parallel campaign slots are available")
        frontier_ids = tuple(
            node.node_id for node in self.graph.ready_leaves()
        )
        missing = set(frontier_ids).difference(
            self._scheduling_assessments
        )
        if missing:
            raise ValueError(
                "ready leaves lack scheduling assessments: %s"
                % ", ".join(sorted(missing))
            )
        def scheduling_score(node_id: str) -> float:
            base = self._scheduling_assessments[node_id].priority_score
            if not self.graph.has_explicit_role_separation:
                return base
            node = self.graph.nodes[node_id]
            role_weight = (
                1.0
                if node.effective_role == GoalNodeRole.OBJECTIVE
                else 0.5
            )
            distance = max(1, self.graph.objective_distance(node_id))
            return base * role_weight / float(distance)

        ranked = tuple(
            sorted(
                frontier_ids,
                key=lambda node_id: (
                    -scheduling_score(node_id),
                    node_id,
                ),
            )
        )
        selected = []
        cost = 0.0
        evidence_cost = 0.0
        budget = min(
            compute_budget,
            self.compute_available_for_new_campaigns,
        )
        evidence_budget = (
            min(
                budget * DEFAULT_MAX_META_COMPUTE_FRACTION,
                self.evidence_compute_available,
            )
            if self.graph.has_explicit_role_separation
            else budget
        )
        for node_id in ranked:
            if len(selected) >= min(max_nodes, available_slots):
                break
            item_cost = self._scheduling_assessments[
                node_id
            ].estimated_cost
            is_evidence = (
                self.graph.nodes[node_id].effective_role
                == GoalNodeRole.EVIDENCE
            )
            if is_evidence and evidence_cost + item_cost > evidence_budget:
                continue
            if cost + item_cost <= budget:
                selected.append(node_id)
                cost += item_cost
                if is_evidence:
                    evidence_cost += item_cost
        if not selected:
            raise ValueError("schedule budget admits no ready leaf")
        schedule = FrontierSchedule(
            node_ids=tuple(selected),
            deferred_node_ids=tuple(
                node_id for node_id in ranked if node_id not in selected
            ),
            estimated_cost=cost,
            scores={
                node_id: scheduling_score(node_id)
                for node_id in ranked
            },
            rationale=(
                "maximize expected objective-distance reduction and value of "
                "information per unit cost; evidence cannot masquerade as "
                "objective completion and consumes at most the declared "
                "meta-compute fraction"
            ),
        )
        self.memory.append(
            ScientificMemoryEventKind.FRONTIER_SCHEDULED,
            schedule.as_dict(),
            actor_ref=self.controller_ref,
        )
        return schedule

    def register_incumbent_portfolio(
        self,
        portfolio: IncumbentPortfolio,
    ) -> str:
        self._ensure_open()
        node = self.graph.nodes.get(portfolio.node_id)
        if node is None or node.leaf_contract is None:
            raise ValueError(
                "incumbent portfolios belong to executable leaves"
            )
        assessment = self._require_current_literature(portfolio.node_id)
        if portfolio.literature_assessment_id != assessment.assessment_id:
            raise ValueError(
                "incumbent portfolio is stale relative to literature"
            )
        if not portfolio.closed:
            raise ValueError(
                "uncertain incumbents block autonomous solution search"
            )
        if assessment.executable_incumbent_id is None:
            raise ValueError(
                "leaf literature must identify an executable incumbent"
            )
        if (
            portfolio.primary.source_work_id
            != assessment.executable_incumbent_id
        ):
            raise ValueError(
                "primary baseline does not reproduce the reviewed incumbent"
            )
        existing = self._portfolios.get(portfolio.portfolio_id)
        if existing is not None:
            if existing != portfolio:
                raise ValueError("incumbent portfolio identity conflict")
            return portfolio.portfolio_id
        self._portfolios[portfolio.portfolio_id] = portfolio
        self._current_portfolio_ids[
            portfolio.node_id
        ] = portfolio.portfolio_id
        self.memory.append(
            ScientificMemoryEventKind.INCUMBENT_PORTFOLIO_REGISTERED,
            portfolio.as_dict(),
            actor_ref=self.controller_ref,
        )
        return portfolio.portfolio_id

    def start_campaign(
        self,
        contract: IslandCampaignContract,
        plateau_policy: CampaignPlateauPolicy,
    ) -> str:
        self._ensure_open()
        if self.graph.status(contract.node_id) != GoalNodeStatus.READY:
            raise ValueError("campaign requires a ready executable leaf")
        if contract.node_id in self._active_campaign_ids:
            raise ValueError("goal node already has an active campaign")
        if (
            len(self._active_campaign_ids)
            >= self.goal.max_parallel_campaigns
        ):
            raise ValueError("goal parallel campaign limit is reached")
        node = self.graph.nodes[contract.node_id]
        assert node.leaf_contract is not None
        if contract.leaf_contract_id != node.leaf_contract.contract_id:
            raise ValueError("campaign references another leaf contract")
        portfolio_id = self._current_portfolio_ids.get(contract.node_id)
        if portfolio_id is None:
            raise ValueError("campaign requires an incumbent portfolio")
        if contract.incumbent_portfolio_id != portfolio_id:
            raise ValueError("campaign references a stale incumbent")
        if contract.total_compute_budget > node.leaf_contract.experiment_budget:
            raise ValueError("campaign exceeds the leaf experiment budget")
        if (
            contract.total_compute_budget
            > self.compute_available_for_new_campaigns
        ):
            raise ValueError(
                "campaign exceeds the uncommitted root compute budget"
            )
        if (
            self.graph.has_explicit_role_separation
            and node.effective_role == GoalNodeRole.EVIDENCE
            and contract.total_compute_budget
            > self.evidence_compute_available
        ):
            raise ValueError(
                "evidence campaign exceeds the reserved meta-compute budget"
            )
        portfolio = self._portfolios[portfolio_id]
        campaign = IslandCampaignState(
            contract,
            portfolio,
            plateau_policy,
        )
        if contract.campaign_id in self._campaigns:
            raise ValueError("campaign identity is already registered")
        self._campaigns[contract.campaign_id] = campaign
        self._active_campaign_ids[
            contract.node_id
        ] = contract.campaign_id
        self.graph.transition(
            contract.node_id,
            GoalNodeStatus.SEARCHING,
        )
        self.memory.append(
            ScientificMemoryEventKind.ISLAND_CAMPAIGN_STARTED,
            {
                "contract": contract.as_dict(),
                "plateau_policy": campaign.as_dict()["plateau_policy"],
            },
            actor_ref=self.controller_ref,
        )
        return contract.campaign_id

    def register_evaluation_horizon(
        self,
        horizon: EvaluationHorizon,
    ) -> str:
        """Freeze one level of realism before candidate outcomes are seen."""

        self._ensure_open()
        if horizon.node_id not in self.graph.nodes:
            raise ValueError("evaluation horizon targets an unknown goal node")
        if horizon.horizon_id in self._evaluation_horizons:
            raise ValueError("evaluation horizon is already registered")
        peers = tuple(
            item
            for item in self._evaluation_horizons.values()
            if item.node_id == horizon.node_id
        )
        if any(item.rank == horizon.rank for item in peers):
            raise ValueError("a node cannot have two horizons at one rank")
        if any(item.partition_ref == horizon.partition_ref for item in peers):
            raise ValueError("evaluation horizons require disjoint partitions")
        self._evaluation_horizons[horizon.horizon_id] = horizon
        self.memory.append(
            ScientificMemoryEventKind.EVALUATION_HORIZON_REGISTERED,
            horizon.as_dict(),
            actor_ref=horizon.registrar_ref,
        )
        return horizon.horizon_id

    def record_horizon_prediction(
        self,
        prediction: HorizonPrediction,
    ) -> str:
        """Record a candidate commitment before opening its horizon."""

        self._ensure_open()
        horizon = self._evaluation_horizons.get(prediction.horizon_id)
        if horizon is None:
            raise ValueError("prediction references an unknown horizon")
        if prediction.node_id != horizon.node_id:
            raise ValueError("prediction and horizon target different nodes")
        if set(prediction.expected_metrics) != set(horizon.metric_names):
            raise ValueError("prediction does not cover the horizon metrics")
        if prediction.prediction_id in self._horizon_predictions:
            raise ValueError("horizon prediction is already registered")
        if any(
            item.node_id == prediction.node_id
            and item.hypothesis_id == prediction.hypothesis_id
            and item.candidate_id == prediction.candidate_id
            and item.horizon_id == prediction.horizon_id
            for item in self._horizon_predictions.values()
        ):
            raise ValueError("candidate already has a prediction at this horizon")
        if any(
            item.node_id == prediction.node_id
            and item.hypothesis_id == prediction.hypothesis_id
            and item.candidate_id == prediction.candidate_id
            and item.horizon_id == prediction.horizon_id
            for item in self._horizon_outcomes.values()
        ):
            raise ValueError("prediction was registered after its outcome")
        self._horizon_predictions[prediction.prediction_id] = prediction
        self.memory.append(
            ScientificMemoryEventKind.HORIZON_PREDICTION_REGISTERED,
            prediction.as_dict(),
            actor_ref=prediction.predictor_ref,
        )
        return prediction.prediction_id

    def record_horizon_outcome(self, outcome: HorizonOutcome) -> str:
        """Attach independently verified evidence to a prior prediction."""

        self._ensure_open()
        horizon = self._evaluation_horizons.get(outcome.horizon_id)
        prediction = self._horizon_predictions.get(outcome.prediction_id)
        if horizon is None or prediction is None:
            raise ValueError("outcome requires a registered horizon and prediction")
        identity = (
            outcome.node_id,
            outcome.hypothesis_id,
            outcome.candidate_id,
            outcome.horizon_id,
        )
        if identity != (
            prediction.node_id,
            prediction.hypothesis_id,
            prediction.candidate_id,
            prediction.horizon_id,
        ):
            raise ValueError("outcome identity differs from its prediction")
        if set(outcome.observed_metrics) != set(horizon.metric_names):
            raise ValueError("outcome does not cover the horizon metrics")
        if outcome.compute_spent > horizon.compute_budget:
            raise ValueError("outcome exceeds its horizon compute budget")
        if (
            self.graph.has_explicit_role_separation
            and outcome.compute_spent > self.evidence_compute_available
        ):
            raise ValueError(
                "horizon outcome exceeds the reserved meta-compute budget"
            )
        if horizon.kind == HorizonKind.TERMINAL and not outcome.exposure_id:
            raise ValueError("terminal outcome requires a quarantined exposure")
        if outcome.outcome_id in self._horizon_outcomes:
            raise ValueError("horizon outcome is already registered")
        if any(
            item.prediction_id == outcome.prediction_id
            for item in self._horizon_outcomes.values()
        ):
            raise ValueError("prediction already has a recorded outcome")
        if outcome.exposure_id and any(
            item.exposure_id == outcome.exposure_id
            for item in self._horizon_outcomes.values()
            if item.exposure_id
        ):
            raise ValueError("quarantined exposure was already consumed")
        self._horizon_outcomes[outcome.outcome_id] = outcome
        self.memory.append(
            ScientificMemoryEventKind.HORIZON_OUTCOME_RECORDED,
            outcome.as_dict(),
            actor_ref=outcome.evaluator_ref,
        )
        return outcome.outcome_id

    def register_horizon_contrast(self, contrast: HorizonContrast) -> str:
        """Register where a locally positive effect did or did not transfer."""

        self._ensure_open()
        local = self._horizon_outcomes.get(contrast.local_outcome_id)
        terminal = self._horizon_outcomes.get(contrast.terminal_outcome_id)
        divergence = self._evaluation_horizons.get(
            contrast.first_divergence_horizon_id
        )
        if local is None or terminal is None or divergence is None:
            raise ValueError("contrast references unregistered horizon evidence")
        expected_identity = (
            contrast.node_id,
            contrast.hypothesis_id,
            contrast.candidate_id,
        )
        if expected_identity != (
            local.node_id,
            local.hypothesis_id,
            local.candidate_id,
        ) or expected_identity != (
            terminal.node_id,
            terminal.hypothesis_id,
            terminal.candidate_id,
        ):
            raise ValueError("contrast combines different candidates")
        local_horizon = self._evaluation_horizons[local.horizon_id]
        terminal_horizon = self._evaluation_horizons[terminal.horizon_id]
        if local_horizon.rank >= terminal_horizon.rank:
            raise ValueError("contrast horizons are not ordered")
        if not local_horizon.rank < divergence.rank <= terminal_horizon.rank:
            raise ValueError("first divergence is outside the compared horizons")
        if contrast.metric_name not in local.observed_metrics or (
            contrast.metric_name not in terminal.observed_metrics
        ):
            raise ValueError("contrast metric is absent from an outcome")
        if not math.isclose(
            contrast.local_effect,
            float(local.observed_metrics[contrast.metric_name]),
            abs_tol=1e-12,
        ) or not math.isclose(
            contrast.terminal_effect,
            float(terminal.observed_metrics[contrast.metric_name]),
            abs_tol=1e-12,
        ):
            raise ValueError("contrast effects do not match recorded outcomes")
        if contrast.contrast_id in self._horizon_contrasts:
            raise ValueError("horizon contrast is already registered")
        self._horizon_contrasts[contrast.contrast_id] = contrast
        self.memory.append(
            ScientificMemoryEventKind.HORIZON_CONTRAST_REGISTERED,
            contrast.as_dict(),
            actor_ref=contrast.analyst_ref,
        )
        return contrast.contrast_id

    def register_horizon_failure_dossier(
        self,
        dossier: HorizonFailureDossier,
    ) -> str:
        """Require matched transfer successes and failures before diagnosis."""

        self._ensure_open()
        if dossier.node_id not in self.graph.nodes:
            raise ValueError("dossier targets an unknown goal node")
        contrasts = tuple(
            self._horizon_contrasts.get(contrast_id)
            for contrast_id in dossier.contrast_ids
        )
        if any(item is None for item in contrasts):
            raise ValueError("dossier references an unknown contrast")
        typed_contrasts = tuple(item for item in contrasts if item is not None)
        if any(item.node_id != dossier.node_id for item in typed_contrasts):
            raise ValueError("dossier combines contrasts from different nodes")
        if not any(item.transport_failed for item in typed_contrasts):
            raise ValueError("dossier contains no short-to-terminal failure")
        if not any(item.transferred for item in typed_contrasts):
            raise ValueError("dossier lacks a matched successful transfer")
        if dossier.dossier_id in self._horizon_dossiers:
            raise ValueError("horizon-failure dossier is already registered")
        self._horizon_dossiers[dossier.dossier_id] = dossier
        self.memory.append(
            ScientificMemoryEventKind.HORIZON_FAILURE_DOSSIER_REGISTERED,
            dossier.as_dict(),
            actor_ref=dossier.builder_ref,
        )
        return dossier.dossier_id

    def register_representation_adequacy_assessment(
        self,
        assessment: RepresentationAdequacyAssessment,
    ) -> str:
        self._ensure_open()
        dossier = self._horizon_dossiers.get(assessment.dossier_id)
        if dossier is None:
            raise ValueError("adequacy assessment references an unknown dossier")
        if assessment.representation_id != dossier.representation_id:
            raise ValueError("adequacy assessment used another representation")
        assessed = set(assessment.development_contrast_ids).union(
            assessment.validation_contrast_ids
        )
        if not assessed.issubset(set(dossier.contrast_ids)):
            raise ValueError("adequacy assessment uses contrasts outside its dossier")
        validation = tuple(
            self._horizon_contrasts[item]
            for item in assessment.validation_contrast_ids
        )
        if not any(item.transport_failed for item in validation) or not any(
            item.transferred for item in validation
        ):
            raise ValueError(
                "adequacy validation requires opposing terminal outcomes"
            )
        if assessment.assessment_id in self._representation_adequacy_assessments:
            raise ValueError("representation adequacy was already assessed")
        self._representation_adequacy_assessments[
            assessment.assessment_id
        ] = assessment
        self.memory.append(
            ScientificMemoryEventKind.REPRESENTATION_ADEQUACY_ASSESSED,
            assessment.as_dict(),
            actor_ref=assessment.assessor_ref,
        )
        return assessment.assessment_id

    def register_latent_concept(
        self,
        concept: LatentConceptHypothesis,
    ) -> str:
        self._ensure_open()
        assessment = self._representation_adequacy_assessments.get(
            concept.adequacy_assessment_id
        )
        if assessment is None:
            raise ValueError("latent concept lacks an adequacy assessment")
        if not assessment.representation_insufficient:
            raise ValueError("existing representation was not shown insufficient")
        if concept.dossier_id != assessment.dossier_id:
            raise ValueError("latent concept references another dossier")
        if not math.isclose(
            concept.required_predictive_score,
            assessment.required_predictive_score,
            abs_tol=1e-12,
        ):
            raise ValueError(
                "latent concept changed the frozen predictive-quality floor"
            )
        if concept.concept_id in self._latent_concepts:
            raise ValueError("latent concept is already registered")
        self._latent_concepts[concept.concept_id] = concept
        self.memory.append(
            ScientificMemoryEventKind.LATENT_CONCEPT_REGISTERED,
            concept.as_dict(),
            actor_ref=concept.proposer_ref,
        )
        return concept.concept_id

    def record_autonomous_invention_milestone(
        self,
        concept_record: Mapping[str, Any],
        synthesis_record: Mapping[str, Any],
        validation_record: Mapping[str, Any],
    ) -> Tuple[str, str, str]:
        """Append a guarded concept -> program -> blind-validation chain."""

        self._ensure_open()
        milestone_id = str(concept_record.get("milestone_id", ""))
        bundle_id = str(concept_record.get("concept_bundle_id", ""))
        freeze_id = str(synthesis_record.get("candidate_freeze_id", ""))
        if not milestone_id or not bundle_id or not freeze_id:
            raise ValueError("autonomous milestone identities must not be empty")
        if synthesis_record.get("concept_bundle_id") != bundle_id:
            raise ValueError("synthesized program references another concept bundle")
        if validation_record.get("candidate_freeze_id") != freeze_id:
            raise ValueError("blind validation references another candidate freeze")
        if validation_record.get("milestone_id") != milestone_id:
            raise ValueError("blind validation references another milestone")
        if any(
            event.kind == ScientificMemoryEventKind.AUTONOMOUS_CONCEPT_INDUCED
            and event.payload.get("milestone_id") == milestone_id
            for event in self.memory.events
        ):
            raise ValueError("autonomous invention milestone is already recorded")
        concept_event = self.memory.append(
            ScientificMemoryEventKind.AUTONOMOUS_CONCEPT_INDUCED,
            dict(concept_record),
            actor_ref="ontology-neutral-structural-proposer-v16",
        )
        synthesis_event = self.memory.append(
            ScientificMemoryEventKind.TYPED_POLICY_PROGRAM_SYNTHESIZED,
            dict(synthesis_record),
            actor_ref="typed-enumerative-policy-synthesizer-v16",
        )
        validation_event = self.memory.append(
            ScientificMemoryEventKind.BLIND_TRANSFER_VALIDATED,
            dict(validation_record),
            actor_ref="autonomous-synthesis-independent-verifier-v16",
        )
        return (
            concept_event.event_id,
            synthesis_event.event_id,
            validation_event.event_id,
        )

    def record_latent_object_milestone(
        self,
        freeze_record: Mapping[str, Any],
        audit_record: Mapping[str, Any],
        causal_record: Mapping[str, Any],
    ) -> Tuple[str, str, str]:
        """Append a guarded latent-object freeze -> audit -> causal chain."""

        self._ensure_open()
        milestone_id = str(freeze_record.get("milestone_id", ""))
        freeze_id = str(freeze_record.get("candidate_freeze_id", ""))
        audit_trial_id = str(audit_record.get("audit_trial_id", ""))
        if not milestone_id or not freeze_id or not audit_trial_id:
            raise ValueError("latent-object milestone identities must not be empty")
        if audit_record.get("milestone_id") != milestone_id:
            raise ValueError("latent-object audit references another milestone")
        if audit_record.get("candidate_freeze_id") != freeze_id:
            raise ValueError("latent-object audit references another freeze")
        if causal_record.get("milestone_id") != milestone_id:
            raise ValueError("latent-object causal test references another milestone")
        if causal_record.get("audit_trial_id") != audit_trial_id:
            raise ValueError("latent-object causal test references another audit")
        if any(
            event.kind == ScientificMemoryEventKind.LATENT_OBJECT_MODEL_FROZEN
            and event.payload.get("milestone_id") == milestone_id
            for event in self.memory.events
        ):
            raise ValueError("latent-object milestone is already recorded")
        freeze_event = self.memory.append(
            ScientificMemoryEventKind.LATENT_OBJECT_MODEL_FROZEN,
            dict(freeze_record),
            actor_ref="latent-address-learning-runtime-v17",
        )
        audit_event = self.memory.append(
            ScientificMemoryEventKind.LATENT_OBJECT_AUDIT_VALIDATED,
            dict(audit_record),
            actor_ref="latent-object-independent-verifier-v17",
        )
        causal_event = self.memory.append(
            ScientificMemoryEventKind.LATENT_OBJECT_CAUSAL_TEST_VALIDATED,
            dict(causal_record),
            actor_ref="latent-object-causal-intervention-v17",
        )
        return (
            freeze_event.event_id,
            audit_event.event_id,
            causal_event.event_id,
        )

    def record_self_supervised_object_milestone(
        self,
        freeze_record: Mapping[str, Any],
        audit_record: Mapping[str, Any],
        causal_record: Mapping[str, Any],
    ) -> Tuple[str, str, str]:
        """Append a guarded unlabeled-model freeze -> audit -> causal chain."""

        self._ensure_open()
        milestone_id = str(freeze_record.get("milestone_id", ""))
        freeze_id = str(freeze_record.get("candidate_freeze_id", ""))
        trace_id = str(freeze_record.get("training_trace_id", ""))
        audit_trial_id = str(audit_record.get("audit_trial_id", ""))
        if not milestone_id or not freeze_id or not trace_id or not audit_trial_id:
            raise ValueError(
                "self-supervised object milestone identities must not be empty"
            )
        if audit_record.get("milestone_id") != milestone_id:
            raise ValueError("self-supervised audit references another milestone")
        if audit_record.get("candidate_freeze_id") != freeze_id:
            raise ValueError("self-supervised audit references another freeze")
        if causal_record.get("milestone_id") != milestone_id:
            raise ValueError(
                "self-supervised causal test references another milestone"
            )
        if causal_record.get("audit_trial_id") != audit_trial_id:
            raise ValueError("self-supervised causal test references another audit")
        if any(
            event.kind
            == ScientificMemoryEventKind.SELF_SUPERVISED_OBJECT_MODEL_FROZEN
            and event.payload.get("milestone_id") == milestone_id
            for event in self.memory.events
        ):
            raise ValueError(
                "self-supervised object milestone is already recorded"
            )
        freeze_event = self.memory.append(
            ScientificMemoryEventKind.SELF_SUPERVISED_OBJECT_MODEL_FROZEN,
            dict(freeze_record),
            actor_ref="unlabeled-consequence-address-learner-v18",
        )
        audit_event = self.memory.append(
            ScientificMemoryEventKind.SELF_SUPERVISED_OBJECT_AUDIT_VALIDATED,
            dict(audit_record),
            actor_ref="self-supervised-object-independent-verifier-v18",
        )
        causal_event = self.memory.append(
            ScientificMemoryEventKind.SELF_SUPERVISED_OBJECT_CAUSAL_TEST_VALIDATED,
            dict(causal_record),
            actor_ref="self-supervised-object-causal-intervention-v18",
        )
        return (
            freeze_event.event_id,
            audit_event.event_id,
            causal_event.event_id,
        )

    def record_behavioral_predicate_milestone(
        self,
        freeze_record: Mapping[str, Any],
        audit_record: Mapping[str, Any],
        causal_record: Mapping[str, Any],
    ) -> Tuple[str, str, str]:
        """Append a guarded predicate freeze -> transfer audit -> causal chain."""

        self._ensure_open()
        milestone_id = str(freeze_record.get("milestone_id", ""))
        freeze_id = str(freeze_record.get("candidate_freeze_id", ""))
        trace_id = str(freeze_record.get("discovery_trace_id", ""))
        trial_id = str(audit_record.get("audit_trial_id", ""))
        if not milestone_id or not freeze_id or not trace_id or not trial_id:
            raise ValueError("predicate milestone identities must not be empty")
        if audit_record.get("milestone_id") != milestone_id:
            raise ValueError("predicate audit references another milestone")
        if audit_record.get("candidate_freeze_id") != freeze_id:
            raise ValueError("predicate audit references another freeze")
        if causal_record.get("milestone_id") != milestone_id:
            raise ValueError("predicate causal test references another milestone")
        if causal_record.get("audit_trial_id") != trial_id:
            raise ValueError("predicate causal test references another audit")
        if any(
            event.kind
            == ScientificMemoryEventKind.BEHAVIORAL_PREDICATE_PROGRAMS_FROZEN
            and event.payload.get("milestone_id") == milestone_id
            for event in self.memory.events
        ):
            raise ValueError("behavioral predicate milestone is already recorded")
        freeze_event = self.memory.append(
            ScientificMemoryEventKind.BEHAVIORAL_PREDICATE_PROGRAMS_FROZEN,
            dict(freeze_record),
            actor_ref="consequence-guided-predicate-synthesizer-v19",
        )
        audit_event = self.memory.append(
            ScientificMemoryEventKind.BEHAVIORAL_PREDICATE_AUDIT_VALIDATED,
            dict(audit_record),
            actor_ref="behavioral-predicate-independent-verifier-v19",
        )
        causal_event = self.memory.append(
            ScientificMemoryEventKind.BEHAVIORAL_PREDICATE_CAUSAL_TEST_VALIDATED,
            dict(causal_record),
            actor_ref="behavioral-predicate-causal-intervention-v19",
        )
        return (
            freeze_event.event_id,
            audit_event.event_id,
            causal_event.event_id,
        )

    def record_schema_induction_milestone(
        self,
        freeze_record: Mapping[str, Any],
        audit_record: Mapping[str, Any],
        causal_record: Mapping[str, Any],
    ) -> Tuple[str, str, str]:
        """Append a guarded schema grammar freeze -> audit -> causal chain."""

        self._ensure_open()
        milestone_id = str(freeze_record.get("milestone_id", ""))
        freeze_id = str(freeze_record.get("candidate_freeze_id", ""))
        grammar_id = str(freeze_record.get("grammar_id", ""))
        trial_id = str(audit_record.get("audit_trial_id", ""))
        if not milestone_id or not freeze_id or not grammar_id or not trial_id:
            raise ValueError("schema-induction milestone identities must not be empty")
        if audit_record.get("milestone_id") != milestone_id:
            raise ValueError("schema audit references another milestone")
        if audit_record.get("candidate_freeze_id") != freeze_id:
            raise ValueError("schema audit references another freeze")
        if causal_record.get("milestone_id") != milestone_id:
            raise ValueError("schema causal test references another milestone")
        if causal_record.get("audit_trial_id") != trial_id:
            raise ValueError("schema causal test references another audit")
        if any(
            event.kind
            == ScientificMemoryEventKind.EXECUTABLE_SCHEMA_GRAMMAR_FROZEN
            and event.payload.get("milestone_id") == milestone_id
            for event in self.memory.events
        ):
            raise ValueError("schema-induction milestone is already recorded")
        freeze_event = self.memory.append(
            ScientificMemoryEventKind.EXECUTABLE_SCHEMA_GRAMMAR_FROZEN,
            dict(freeze_record),
            actor_ref="universal-behavioral-schema-synthesizer-v20",
        )
        audit_event = self.memory.append(
            ScientificMemoryEventKind.SCHEMA_INDUCTION_AUDIT_VALIDATED,
            dict(audit_record),
            actor_ref="schema-induction-independent-verifier-v20",
        )
        causal_event = self.memory.append(
            ScientificMemoryEventKind.SCHEMA_CAUSAL_TEST_VALIDATED,
            dict(causal_record),
            actor_ref="schema-composition-causal-intervention-v20",
        )
        return (
            freeze_event.event_id,
            audit_event.event_id,
            causal_event.event_id,
        )

    def record_cognitive_core_v1_milestone(
        self,
        freeze_record: Mapping[str, Any],
        audit_record: Mapping[str, Any],
    ) -> Tuple[str, str]:
        """Append one guarded M21--M26 freeze -> independent-audit pair."""

        self._ensure_open()
        phase = str(freeze_record.get("phase", ""))
        milestone_id = str(freeze_record.get("milestone_id", ""))
        freeze_id = str(freeze_record.get("freeze_id", ""))
        trial_id = str(audit_record.get("trial_id", ""))
        kinds = {
            "m21": (
                ScientificMemoryEventKind.PRIMITIVE_INVENTION_CORE_FROZEN,
                ScientificMemoryEventKind.PRIMITIVE_INVENTION_AUDIT_VALIDATED,
                "behavioral-primitive-inventor-v21",
                "primitive-invention-independent-verifier-v21",
            ),
            "m22": (
                ScientificMemoryEventKind.AUTONOMOUS_EXPERIMENT_POLICY_FROZEN,
                ScientificMemoryEventKind.AUTONOMOUS_EXPERIMENT_AUDIT_VALIDATED,
                "information-experiment-policy-v22",
                "autonomous-experiment-independent-verifier-v22",
            ),
            "m23": (
                ScientificMemoryEventKind.REPRESENTATION_REVISION_CORE_FROZEN,
                ScientificMemoryEventKind.REPRESENTATION_REVISION_AUDIT_VALIDATED,
                "contradiction-driven-representation-reviser-v23",
                "representation-revision-independent-verifier-v23",
            ),
            "m24": (
                ScientificMemoryEventKind.NATURALISTIC_TRANSFER_ADAPTER_FROZEN,
                ScientificMemoryEventKind.NATURALISTIC_TRANSFER_AUDIT_VALIDATED,
                "python-ast-transfer-adapter-v24",
                "naturalistic-transfer-independent-verifier-v24",
            ),
            "m25": (
                ScientificMemoryEventKind.AUTONOMOUS_SCIENTIFIC_CYCLE_FROZEN,
                ScientificMemoryEventKind.AUTONOMOUS_SCIENTIFIC_CYCLE_AUDIT_VALIDATED,
                "autonomous-scientific-cycle-v25",
                "autonomous-scientific-cycle-independent-verifier-v25",
            ),
            "m26": (
                ScientificMemoryEventKind.COGNITIVE_CORE_V1_RELEASE_FROZEN,
                ScientificMemoryEventKind.COGNITIVE_CORE_V1_REPLICATION_VALIDATED,
                "cognitive-core-v1-release-v26",
                "cognitive-core-v1-independent-release-verifier-v26",
            ),
        }
        if phase not in kinds:
            raise ValueError("unsupported Cognitive Core V1 milestone phase")
        if not milestone_id or not freeze_id or not trial_id:
            raise ValueError("Cognitive Core V1 milestone identities must not be empty")
        if audit_record.get("phase") != phase:
            raise ValueError("Cognitive Core V1 audit references another phase")
        if audit_record.get("milestone_id") != milestone_id:
            raise ValueError("Cognitive Core V1 audit references another milestone")
        if audit_record.get("freeze_id") != freeze_id:
            raise ValueError("Cognitive Core V1 audit references another freeze")
        freeze_kind, audit_kind, freeze_actor, audit_actor = kinds[phase]
        if any(
            event.kind == freeze_kind
            and event.payload.get("milestone_id") == milestone_id
            for event in self.memory.events
        ):
            raise ValueError("Cognitive Core V1 milestone is already recorded")
        freeze_event = self.memory.append(
            freeze_kind, dict(freeze_record), actor_ref=freeze_actor
        )
        audit_event = self.memory.append(
            audit_kind, dict(audit_record), actor_ref=audit_actor
        )
        return freeze_event.event_id, audit_event.event_id

    def record_concept_validation(
        self,
        validation: ConceptValidation,
    ) -> str:
        self._ensure_open()
        concept = self._latent_concepts.get(validation.concept_id)
        assessment = self._representation_adequacy_assessments.get(
            validation.adequacy_assessment_id
        )
        if concept is None or assessment is None:
            raise ValueError("concept validation lacks registered prerequisites")
        if concept.adequacy_assessment_id != assessment.assessment_id:
            raise ValueError("concept and validation use different assessments")
        if any(
            item.concept_id == concept.concept_id
            for item in self._concept_validations.values()
        ):
            raise ValueError(
                "a concept may consume only one prospective validation set"
            )
        dossier = self._horizon_dossiers[assessment.dossier_id]
        if validation.development_contrast_ids != dossier.contrast_ids:
            raise ValueError(
                "concept validation must declare every contrast available at "
                "concept-invention time"
            )
        if set(validation.validation_contrast_ids).intersection(
            dossier.contrast_ids
        ):
            raise ValueError(
                "concept validation reused a disclosed diagnostic contrast"
            )
        prospective = tuple(
            self._horizon_contrasts.get(contrast_id)
            for contrast_id in validation.validation_contrast_ids
        )
        if any(item is None for item in prospective):
            raise ValueError(
                "concept validation references an unknown prospective contrast"
            )
        typed_prospective = tuple(
            item for item in prospective if item is not None
        )
        if any(item.node_id != dossier.node_id for item in typed_prospective):
            raise ValueError(
                "concept validation combines contrasts from different nodes"
            )
        if not any(item.transport_failed for item in typed_prospective) or not any(
            item.transferred for item in typed_prospective
        ):
            raise ValueError(
                "prospective concept validation requires opposing outcomes"
            )
        concept_sequence = next(
            (
                event.sequence
                for event in self.memory.events
                if event.kind
                == ScientificMemoryEventKind.LATENT_CONCEPT_REGISTERED
                and event.payload.get("concept_id") == concept.concept_id
            ),
            None,
        )
        contrast_sequences = {
            str(event.payload.get("contrast_id")): event.sequence
            for event in self.memory.events
            if event.kind
            == ScientificMemoryEventKind.HORIZON_CONTRAST_REGISTERED
        }
        if concept_sequence is None or any(
            contrast_sequences.get(contrast_id, -1) <= concept_sequence
            for contrast_id in validation.validation_contrast_ids
        ):
            raise ValueError(
                "concept validation contrasts were not collected prospectively"
            )
        if not math.isclose(
            validation.required_predictive_score,
            concept.required_predictive_score,
            abs_tol=1e-12,
        ):
            raise ValueError(
                "concept validation changed the frozen predictive-quality floor"
            )
        if not math.isclose(
            validation.minimum_improvement,
            concept.minimum_predictive_improvement,
            abs_tol=1e-12,
        ):
            raise ValueError(
                "concept validation changed the frozen improvement threshold"
            )
        if (
            len(validation.validation_contrast_ids)
            != concept.prospective_contrast_count
        ):
            raise ValueError(
                "concept validation changed the frozen prospective sample size"
            )
        if validation.validation_id in self._concept_validations:
            raise ValueError("concept validation is already registered")
        self._concept_validations[validation.validation_id] = validation
        self.memory.append(
            ScientificMemoryEventKind.CONCEPT_VALIDATION_RECORDED,
            validation.as_dict(),
            actor_ref=validation.evaluator_ref,
        )
        return validation.validation_id

    def register_generator_revision(
        self,
        revision: ConceptGroundedGeneratorRevision,
    ) -> str:
        self._ensure_open()
        validation = self._concept_validations.get(
            revision.concept_validation_id
        )
        if validation is None or not validation.passed:
            raise ValueError("generator revision requires a validated concept")
        concept = self._latent_concepts[validation.concept_id]
        assessment = self._representation_adequacy_assessments[
            concept.adequacy_assessment_id
        ]
        dossier = self._horizon_dossiers[assessment.dossier_id]
        if revision.prior_representation_id != dossier.representation_id:
            raise ValueError("generator revision starts from another representation")
        if revision.revision_id in self._generator_revisions:
            raise ValueError("generator revision is already registered")
        self._generator_revisions[revision.revision_id] = revision
        self.memory.append(
            ScientificMemoryEventKind.GENERATOR_REVISION_REGISTERED,
            revision.as_dict(),
            actor_ref=revision.reviser_ref,
        )
        return revision.revision_id

    def register_research_program(
        self,
        program: ResearchProgramContract,
    ) -> str:
        """Bind an explicit hypothesis class to an active scientific node."""

        self._ensure_open()
        if program.node_id not in self.graph.nodes:
            raise ValueError("research program targets an unknown goal node")
        if program.node_id not in self._active_campaign_ids:
            raise ValueError("research program requires an active campaign")
        if program.parent_program_id is not None:
            raise ValueError(
                "revised programs must enter through a representation change"
            )
        if program.node_id in self._active_research_program_ids:
            raise ValueError("goal node already has an active research program")
        if program.program_id in self._research_programs:
            raise ValueError("research program is already registered")
        self._research_programs[program.program_id] = program
        self._active_research_program_ids[program.node_id] = program.program_id
        self.memory.append(
            ScientificMemoryEventKind.RESEARCH_PROGRAM_REGISTERED,
            program.as_dict(),
            actor_ref=program.strategy_ref,
        )
        return program.program_id

    def record_research_program_diagnosis(
        self,
        diagnosis: ResearchProgramDiagnosis,
    ) -> str:
        self._ensure_open()
        program = self._research_programs.get(diagnosis.program_id)
        if program is None:
            raise ValueError("diagnosis references an unknown research program")
        active_id = self._active_research_program_ids.get(program.node_id)
        if active_id != program.program_id:
            raise ValueError("only the active research program may be diagnosed")
        if (
            diagnosis.representation_id
            != program.representation.representation_id
        ):
            raise ValueError("diagnosis references another representation")
        existing = self._research_program_diagnoses.get(program.program_id, ())
        if any(
            item.diagnosis_id == diagnosis.diagnosis_id
            or item.cycle_index == diagnosis.cycle_index
            for item in existing
        ):
            raise ValueError("research-program cycle is already diagnosed")
        self._research_program_diagnoses[program.program_id] = (
            *existing,
            diagnosis,
        )
        self.memory.append(
            ScientificMemoryEventKind.RESEARCH_PROGRAM_DIAGNOSED,
            diagnosis.as_dict(),
            actor_ref=diagnosis.assessor_ref,
        )
        return diagnosis.diagnosis_id

    def adopt_representation_change(
        self,
        proposal: RepresentationChangeProposal,
    ) -> str:
        if self.graph.has_explicit_role_separation:
            raise ValueError(
                "objective/evidence graphs require a contrastive, "
                "concept-grounded representation revision"
            )
        return self._adopt_representation_change(proposal)

    def _adopt_representation_change(
        self,
        proposal: RepresentationChangeProposal,
    ) -> str:
        self._ensure_open()
        prior = self._research_programs.get(proposal.prior_program_id)
        if prior is None:
            raise ValueError("representation change references an unknown program")
        active_id = self._active_research_program_ids.get(prior.node_id)
        if active_id != prior.program_id:
            raise ValueError("representation change must revise the active program")
        diagnoses = self._research_program_diagnoses.get(prior.program_id, ())
        diagnosis = next(
            (
                item
                for item in diagnoses
                if item.diagnosis_id == proposal.diagnosis_id
            ),
            None,
        )
        if diagnosis is None:
            raise ValueError("representation change lacks a recorded diagnosis")
        if diagnosis.disposition != StrategyDisposition.CHANGE_REPRESENTATION:
            raise ValueError("diagnosis did not authorize representation change")
        revised = proposal.revised_program
        if revised.node_id != prior.node_id:
            raise ValueError("representation revision targets another goal node")
        if revised.parent_program_id != prior.program_id:
            raise ValueError("representation revision has the wrong program parent")
        if (
            revised.representation.parent_representation_id
            != prior.representation.representation_id
        ):
            raise ValueError(
                "representation revision has the wrong representation parent"
            )
        changed = set(revised.representation.changed_dimensions)
        if not set(diagnosis.required_dimensions).issubset(changed):
            raise ValueError(
                "representation revision omits a diagnosed change dimension"
            )
        if proposal.proposal_id in self._representation_changes:
            raise ValueError("representation change is already registered")
        if revised.program_id in self._research_programs:
            raise ValueError("revised research program is already registered")
        self._research_programs[revised.program_id] = revised
        self._active_research_program_ids[prior.node_id] = revised.program_id
        self._representation_changes[proposal.proposal_id] = proposal
        self.memory.append(
            ScientificMemoryEventKind.REPRESENTATION_CHANGE_ADOPTED,
            proposal.as_dict(),
            actor_ref=proposal.proposer_ref,
        )
        return revised.program_id

    def adopt_concept_grounded_representation_change(
        self,
        proposal: RepresentationChangeProposal,
        generator_revision_id: str,
    ) -> str:
        """Adopt only after a concept changed held-out prediction and generation."""

        revision = self._generator_revisions.get(generator_revision_id)
        if revision is None:
            raise ValueError("concept-grounded change lacks a generator revision")
        validation = self._concept_validations.get(
            revision.concept_validation_id
        )
        if validation is None or not validation.passed:
            raise ValueError("concept-grounded change lacks passing validation")
        prior = self._research_programs.get(proposal.prior_program_id)
        if prior is None:
            raise ValueError("concept-grounded change references an unknown program")
        revised_representation = proposal.revised_program.representation
        if revision.prior_representation_id != prior.representation.representation_id:
            raise ValueError("generator revision starts from another program")
        if (
            revision.revised_representation_id
            != revised_representation.representation_id
        ):
            raise ValueError("generator and program revisions disagree")
        program_id = self._adopt_representation_change(proposal)
        self._concept_grounded_representation_changes[
            proposal.proposal_id
        ] = generator_revision_id
        self.memory.append(
            ScientificMemoryEventKind.CONCEPT_GROUNDED_REPRESENTATION_CHANGE_ADOPTED,
            {
                "proposal_id": proposal.proposal_id,
                "generator_revision_id": generator_revision_id,
                "concept_validation_id": revision.concept_validation_id,
                "revised_program_id": program_id,
            },
            actor_ref=proposal.proposer_ref,
        )
        return program_id

    def park_research_program(
        self,
        node_id: str,
        diagnosis_id: str,
    ) -> str:
        """Stop spending after materially different representations fail."""

        self._ensure_open()
        program_id = self._active_research_program_ids.get(node_id)
        if program_id is None:
            raise ValueError("goal node has no active research program")
        diagnosis = next(
            (
                item
                for item in self._research_program_diagnoses.get(program_id, ())
                if item.diagnosis_id == diagnosis_id
            ),
            None,
        )
        if diagnosis is None or diagnosis.disposition != StrategyDisposition.PARK:
            raise ValueError("parking requires a recorded park diagnosis")
        campaign = self._active_campaign(node_id)
        campaign.park_for_strategy(diagnosis)
        status = self.graph.status(node_id)
        if status not in (
            GoalNodeStatus.SEARCHING,
            GoalNodeStatus.INTEGRATION_FAILED,
        ):
            raise ValueError("only unresolved search may be parked")
        self.graph.transition(node_id, GoalNodeStatus.PLATEAUED)
        self._active_campaign_ids.pop(node_id, None)
        self._active_research_program_ids.pop(node_id, None)
        self.memory.append(
            ScientificMemoryEventKind.RESEARCH_PROGRAM_PARKED,
            {
                "node_id": node_id,
                "campaign_id": campaign.contract.campaign_id,
                "program_id": program_id,
                "diagnosis": diagnosis.as_dict(),
            },
            actor_ref=self.controller_ref,
        )
        return diagnosis.diagnosis_id

    def _active_campaign(self, node_id: str) -> IslandCampaignState:
        try:
            campaign_id = self._active_campaign_ids[node_id]
        except KeyError:
            raise ValueError("goal node has no active island campaign")
        return self._campaigns[campaign_id]

    def submit_candidate(
        self,
        proposal: IslandCandidateProposal,
    ) -> str:
        self._ensure_open()
        status = self.graph.status(proposal.node_id)
        if status == GoalNodeStatus.INTEGRATION_FAILED:
            self.graph.transition(
                proposal.node_id,
                GoalNodeStatus.SEARCHING,
            )
        elif status != GoalNodeStatus.SEARCHING:
            raise ValueError(
                "candidates require a searching or integration-failed leaf"
            )
        campaign = self._active_campaign(proposal.node_id)
        candidate_id = campaign.submit_proposal(proposal)
        self.memory.append(
            ScientificMemoryEventKind.CANDIDATE_PROPOSED,
            proposal.as_dict(),
            actor_ref=proposal.proposer_ref,
        )
        return candidate_id

    def record_leaf_qualification(
        self,
        record: LeafQualificationRecord,
    ) -> str:
        """Record direct evidence for a frozen infrastructure leaf."""

        self._ensure_open()
        if record.node_id not in self.graph.nodes:
            raise ValueError("leaf qualification targets an unknown node")
        node = self.graph.nodes[record.node_id]
        if (
            node.kind != GoalNodeKind.EXECUTABLE_LEAF
            or node.leaf_contract is None
            or "qualification" not in node.tags
        ):
            raise ValueError("direct qualification requires a tagged executable leaf")
        if self.graph.status(record.node_id) != GoalNodeStatus.READY:
            raise ValueError("leaf qualification requires a ready node")
        self._require_current_literature(record.node_id)
        contract = node.leaf_contract
        if record.leaf_contract_id != contract.contract_id:
            raise ValueError("leaf qualification uses another frozen contract")
        if record.protocol_ref != contract.preregistration_ref:
            raise ValueError("leaf qualification uses another preregistered protocol")
        if record.metric_name != contract.metric.name:
            raise ValueError("leaf qualification reports another metric")
        if tuple(record.preregistered_success_conditions) != tuple(
            contract.success_conditions
        ):
            raise ValueError("leaf qualification changed its success conditions")
        if record.compute_cost > contract.experiment_budget:
            raise ValueError("leaf qualification exceeds its experiment budget")
        if record.compute_cost > self.compute_remaining:
            raise ValueError("leaf qualification exceeds the remaining root budget")
        if (
            self.graph.has_explicit_role_separation
            and node.effective_role == GoalNodeRole.EVIDENCE
            and record.compute_cost > self.evidence_compute_available
        ):
            raise ValueError(
                "leaf qualification exceeds the reserved meta-compute budget"
            )
        if record.passed and (
            contract.metric.target is None
            or not math.isclose(
                record.metric_value,
                contract.metric.target,
                rel_tol=0.0,
                abs_tol=1e-12,
            )
        ):
            raise ValueError("passing qualification misses its frozen metric target")
        history = self._leaf_qualifications.get(record.node_id, ())
        if any(
            item.qualification_id == record.qualification_id for item in history
        ):
            raise ValueError("leaf qualification is already registered")
        self._leaf_qualifications[record.node_id] = (*history, record)
        if record.passed:
            self.graph.transition(
                record.node_id,
                GoalNodeStatus.LOCALLY_VALIDATED,
            )
        self.memory.append(
            ScientificMemoryEventKind.LEAF_QUALIFICATION_RECORDED,
            {
                "record": record.as_dict(),
                "node_status": self.graph.status(record.node_id).value,
                "root_compute_spent": self.compute_spent,
            },
            actor_ref=record.verifier_ref,
        )
        return record.qualification_id

    def record_leaf_diagnostic(
        self,
        record: LeafDiagnosticRecord,
    ) -> str:
        """Record a preregistered causal resolution without inventing a candidate."""

        self._ensure_open()
        if record.node_id not in self.graph.nodes:
            raise ValueError("leaf diagnostic targets an unknown node")
        node = self.graph.nodes[record.node_id]
        if (
            node.kind != GoalNodeKind.EXECUTABLE_LEAF
            or node.leaf_contract is None
            or "diagnostic" not in node.tags
        ):
            raise ValueError("direct diagnostic requires a tagged executable leaf")
        if self.graph.status(record.node_id) != GoalNodeStatus.READY:
            raise ValueError("leaf diagnostic requires a ready node")
        self._require_current_literature(record.node_id)
        contract = node.leaf_contract
        if record.leaf_contract_id != contract.contract_id:
            raise ValueError("leaf diagnostic uses another frozen contract")
        if record.protocol_ref != contract.preregistration_ref:
            raise ValueError("leaf diagnostic uses another preregistered protocol")
        if record.metric_name != contract.metric.name:
            raise ValueError("leaf diagnostic reports another metric")
        if tuple(record.preregistered_success_conditions) != tuple(
            contract.success_conditions
        ):
            raise ValueError("leaf diagnostic changed its success conditions")
        if record.compute_cost > contract.experiment_budget:
            raise ValueError("leaf diagnostic exceeds its experiment budget")
        if record.compute_cost > self.compute_remaining:
            raise ValueError("leaf diagnostic exceeds the remaining root budget")
        if (
            self.graph.has_explicit_role_separation
            and node.effective_role == GoalNodeRole.EVIDENCE
            and record.compute_cost > self.evidence_compute_available
        ):
            raise ValueError(
                "leaf diagnostic exceeds the reserved meta-compute budget"
            )
        if record.resolved and (
            contract.metric.target is None
            or not math.isclose(
                record.metric_value,
                contract.metric.target,
                rel_tol=0.0,
                abs_tol=1e-12,
            )
        ):
            raise ValueError("resolved diagnostic misses its frozen metric target")
        history = self._leaf_diagnostics.get(record.node_id, ())
        if any(item.diagnostic_id == record.diagnostic_id for item in history):
            raise ValueError("leaf diagnostic is already registered")
        self._leaf_diagnostics[record.node_id] = (*history, record)
        if record.resolved:
            self.graph.transition(
                record.node_id,
                GoalNodeStatus.LOCALLY_VALIDATED,
            )
        self.memory.append(
            ScientificMemoryEventKind.LEAF_DIAGNOSTIC_RECORDED,
            {
                "record": record.as_dict(),
                "node_status": self.graph.status(record.node_id).value,
                "root_compute_spent": self.compute_spent,
            },
            actor_ref=record.verifier_ref,
        )
        return record.diagnostic_id

    def record_test_exposure(
        self,
        exposure: TestExposureRecord,
    ) -> str:
        self._ensure_open()
        self._active_campaign(exposure.node_id)
        if exposure.candidate_id is not None:
            campaign = self._active_campaign(exposure.node_id)
            if exposure.candidate_id not in campaign.proposals:
                raise ValueError(
                    "test exposure references an unknown candidate"
                )
        if exposure.exposure_id in self._exposures:
            raise ValueError("test exposure is already registered")
        self._exposures[exposure.exposure_id] = exposure
        self.memory.append(
            ScientificMemoryEventKind.TEST_EXPOSURE_RECORDED,
            exposure.as_dict(),
            actor_ref=exposure.actor_ref,
        )
        return exposure.exposure_id

    def record_verification(
        self,
        verification: VerificationRecord,
    ) -> str:
        self._ensure_open()
        campaign = self._active_campaign(verification.node_id)
        campaign.record_verification(verification, self._exposures)
        self.memory.append(
            ScientificMemoryEventKind.VERIFICATION_RECORDED,
            verification.as_dict(),
            actor_ref=verification.verifier_ref,
        )
        return verification.verification_id

    def nominate_local_candidate(
        self,
        node_id: str,
        candidate_id: str,
    ) -> VerificationRecord:
        self._ensure_open()
        if self.graph.status(node_id) != GoalNodeStatus.SEARCHING:
            raise ValueError("candidate nomination requires active search")
        campaign = self._active_campaign(node_id)
        verification = campaign.nominate(candidate_id)
        self.graph.transition(
            node_id,
            GoalNodeStatus.LOCALLY_VALIDATED,
        )
        self.memory.append(
            ScientificMemoryEventKind.LOCAL_CANDIDATE_NOMINATED,
            {
                "node_id": node_id,
                "candidate_id": candidate_id,
                "verification_id": verification.verification_id,
                "effect_size": verification.effect_size,
                "lower_confidence_bound": (
                    verification.lower_confidence_bound
                ),
            },
            actor_ref=self.controller_ref,
        )
        return verification

    def complete_campaign_round(
        self,
        summary: CampaignRoundSummary,
    ) -> CampaignPlateauDiagnosis:
        self._ensure_open()
        campaign = self._active_campaign(summary.node_id)
        if summary.compute_spent > self.compute_remaining:
            raise ValueError("campaign round exceeds the remaining root budget")
        diagnosis = campaign.complete_round(summary)
        strategy_park = None
        program_id = self._active_research_program_ids.get(summary.node_id)
        if program_id is not None:
            strategy_park = next(
                (
                    item
                    for item in self._research_program_diagnoses.get(
                        program_id,
                        (),
                    )
                    if item.cycle_index == summary.round_index
                    and item.disposition == StrategyDisposition.PARK
                ),
                None,
            )
        if campaign.selected_candidate_id is not None:
            strategy_park = None
        if strategy_park is not None:
            diagnosis = campaign.park_for_strategy(strategy_park)
        self.memory.append(
            ScientificMemoryEventKind.CAMPAIGN_ROUND_COMPLETED,
            {
                "campaign_id": campaign.contract.campaign_id,
                "summary": summary.as_dict(),
                "diagnosis": diagnosis.as_dict(),
                "root_compute_spent": self.compute_spent,
            },
            actor_ref=self.controller_ref,
        )
        if diagnosis.is_plateau:
            status = self.graph.status(summary.node_id)
            if status == GoalNodeStatus.LOCALLY_VALIDATED:
                return diagnosis
            if status not in (
                GoalNodeStatus.SEARCHING,
                GoalNodeStatus.INTEGRATION_FAILED,
            ):
                raise ValueError(
                    "only an unresolved search campaign may plateau"
                )
            self.graph.transition(
                summary.node_id,
                GoalNodeStatus.PLATEAUED,
            )
            self._active_campaign_ids.pop(summary.node_id, None)
            self._active_research_program_ids.pop(summary.node_id, None)
            if strategy_park is None:
                self.memory.append(
                    ScientificMemoryEventKind.NODE_PLATEAUED,
                    {
                        "node_id": summary.node_id,
                        "campaign_id": campaign.contract.campaign_id,
                        "diagnosis": diagnosis.as_dict(),
                    },
                    actor_ref=self.controller_ref,
                )
            else:
                self.memory.append(
                    ScientificMemoryEventKind.RESEARCH_PROGRAM_PARKED,
                    {
                        "node_id": summary.node_id,
                        "campaign_id": campaign.contract.campaign_id,
                        "program_id": program_id,
                        "diagnosis": strategy_park.as_dict(),
                    },
                    actor_ref=self.controller_ref,
                )
        return diagnosis

    def record_parent_integration(
        self,
        record: ParentIntegrationRecord,
    ) -> str:
        self._ensure_open()
        if record.parent_id not in self.graph.parents_of(record.node_id):
            raise ValueError(
                "integration target is not an active parent of the node"
            )
        status = self.graph.status(record.node_id)
        if status not in (
            GoalNodeStatus.LOCALLY_VALIDATED,
            GoalNodeStatus.INTEGRATION_PENDING,
            GoalNodeStatus.INTEGRATION_FAILED,
            GoalNodeStatus.INTEGRATED,
        ):
            raise ValueError(
                "node is not ready for parent-level integration"
            )
        node = self.graph.nodes[record.node_id]
        if node.leaf_contract is not None:
            qualification = self.current_leaf_qualification(record.node_id)
            diagnostic = self.current_leaf_diagnostic(record.node_id)
            if qualification is not None and qualification.passed:
                if record.candidate_id != qualification.qualification_id:
                    raise ValueError(
                        "parent integration must test the passing qualification"
                    )
                if not set(record.evidence_ids).issubset(
                    set(qualification.evidence_ids)
                    | set(qualification.raw_artifact_ids)
                ):
                    raise ValueError(
                        "parent integration uses evidence outside the qualification"
                    )
            elif diagnostic is not None and diagnostic.resolved:
                if record.candidate_id != diagnostic.diagnostic_id:
                    raise ValueError(
                        "parent integration must use the resolved diagnostic"
                    )
                if not set(record.evidence_ids).issubset(
                    set(diagnostic.evidence_ids)
                    | set(diagnostic.raw_artifact_ids)
                ):
                    raise ValueError(
                        "parent integration uses evidence outside the diagnostic"
                    )
            else:
                campaign = self._active_campaign(record.node_id)
                if record.candidate_id != campaign.selected_candidate_id:
                    raise ValueError(
                        "parent integration must test the nominated candidate"
                    )
            if (
                record.preregistered_test_ref
                != node.leaf_contract.parent_integration_test
            ):
                raise ValueError(
                    "parent integration test was not preregistered by the leaf"
                )
        history = self._integrations.get(record.node_id, ())
        if any(
            item.integration_id == record.integration_id
            for item in history
        ):
            raise ValueError("parent integration is already registered")
        self._integrations[record.node_id] = (*history, record)
        self.graph.mark_parent_integration(
            record.node_id,
            record.parent_id,
            record.passed,
        )
        if (
            record.passed
            and self.graph.status(record.node_id)
            == GoalNodeStatus.INTEGRATED
        ):
            self._active_campaign_ids.pop(record.node_id, None)
        self.memory.append(
            ScientificMemoryEventKind.PARENT_INTEGRATION_RECORDED,
            {
                "record": record.as_dict(),
                "node_status": self.graph.status(
                    record.node_id
                ).value,
                "parent_status": self.graph.status(
                    record.parent_id
                ).value,
            },
            actor_ref=record.verifier_ref,
        )
        return record.integration_id

    def reopen_node(
        self,
        node_id: str,
        trigger: str,
        evidence_ids: Sequence[str],
    ) -> None:
        self._ensure_open()
        if not trigger or not evidence_ids:
            raise ValueError(
                "node reopening requires a trigger and evidence"
            )
        self.graph.reopen(node_id)
        self.memory.append(
            ScientificMemoryEventKind.NODE_REOPENED,
            {
                "node_id": node_id,
                "trigger": trigger,
                "evidence_ids": list(evidence_ids),
                "new_status": self.graph.status(node_id).value,
            },
            actor_ref=self.controller_ref,
        )

    def evaluate_root(
        self,
        gate_contract: GateContract,
        gate_decision: GateDecision,
        evidence_ids: Sequence[str],
        satisfied_requirements: Sequence[str],
        limitations: Sequence[str],
        claim_authorization: ClaimAuthorization,
        waived_critical_nodes: Optional[Mapping[str, str]] = None,
    ) -> RootGateEvaluation:
        self._ensure_open()
        if (
            self.graph.status(self.graph.root_id)
            != GoalNodeStatus.INTEGRATION_PENDING
        ):
            raise ValueError(
                "root gate requires a composition-ready root"
            )
        if gate_contract.kind != GateKind.PUBLIC_CLAIM:
            raise ValueError("root resolution requires a public-claim gate")
        if gate_decision.contract_id != gate_contract.contract_id:
            raise ValueError("root gate contract and decision disagree")
        recomputed_decision = evaluate_gate(
            gate_contract,
            candidate_id=gate_decision.candidate_id,
            incumbent_id=gate_decision.incumbent_id,
            metrics={
                result.metric: result.observed
                for result in gate_decision.results
            },
            evidence_count=gate_decision.evidence_count,
        )
        if recomputed_decision.decision_id != gate_decision.decision_id:
            raise ValueError(
                "root gate decision disagrees with the frozen criteria"
            )
        if not evidence_ids or not limitations:
            raise ValueError(
                "root gate requires evidence and explicit limitations"
            )
        primary_metric = next(
            metric
            for metric in self.goal.terminal_metrics
            if metric.primary
        )
        if primary_metric.name not in {
            criterion.metric for criterion in gate_contract.criteria
        }:
            raise ValueError(
                "root gate does not test the primary terminal metric"
            )
        assessment = self._require_current_literature(
            self.graph.root_id
        )
        if not claim_authorization.authorized:
            raise ValueError("root claim authorization was denied")
        if (
            claim_authorization.assessment_id
            != assessment.assessment_id
            or claim_authorization.subject_id != self.graph.root_id
        ):
            raise ValueError(
                "root claim authorization is stale or belongs elsewhere"
            )
        if (
            claim_authorization.requested_level
            < ClaimLevel.REPLICATED_EFFECT
        ):
            raise ValueError(
                "root resolution requires at least a replicated effect"
            )
        waived_critical_nodes = dict(waived_critical_nodes or {})
        unresolved = set(self.graph.unresolved_critical_node_ids())
        invalid_waivers = set(waived_critical_nodes).difference(unresolved)
        if invalid_waivers:
            raise ValueError(
                "critical-node waiver references a resolved or unknown node"
            )
        if any(not reason for reason in waived_critical_nodes.values()):
            raise ValueError("critical-node waivers require reasons")
        required = set(self.goal.integration_requirements)
        supplied = set(satisfied_requirements)
        reasons = []
        if not gate_decision.passed:
            reasons.append("the terminal quantitative gate did not pass")
        missing = required.difference(supplied)
        if missing:
            reasons.append(
                "missing root integration requirements: %s"
                % ", ".join(sorted(missing))
            )
        unwaived = unresolved.difference(waived_critical_nodes)
        if unwaived:
            reasons.append(
                "unresolved critical nodes: %s"
                % ", ".join(sorted(unwaived))
            )
        evaluation = RootGateEvaluation(
            goal_id=self.goal.goal_id,
            gate_contract_id=gate_contract.contract_id,
            gate_decision_id=gate_decision.decision_id,
            passed=not reasons,
            evidence_ids=tuple(evidence_ids),
            satisfied_requirements=tuple(satisfied_requirements),
            limitations=tuple(limitations),
            reasons=tuple(reasons),
        )
        self._root_gate_evaluations = (
            *self._root_gate_evaluations,
            evaluation,
        )
        self.memory.append(
            ScientificMemoryEventKind.ROOT_GATE_EVALUATED,
            {
                "evaluation": evaluation.as_dict(),
                "waived_critical_nodes": dict(
                    sorted(waived_critical_nodes.items())
                ),
            },
            actor_ref=self.controller_ref,
        )
        if evaluation.passed:
            self.graph.transition(
                self.graph.root_id,
                GoalNodeStatus.INTEGRATED,
            )
            certificate = RootResolutionCertificate(
                goal_id=self.goal.goal_id,
                terminal_state=RootTerminalState.ACHIEVED,
                evidence_ids=tuple(evidence_ids),
                compute_spent=self.compute_spent,
                unresolved_node_ids=tuple(sorted(unresolved)),
                limitations=tuple(limitations),
                reasons=("all root success conditions passed",),
                root_gate_evaluation_id=evaluation.evaluation_id,
            )
            self._resolution = certificate
            self.memory.append(
                ScientificMemoryEventKind.ROOT_RESOLVED,
                certificate.as_dict(),
                actor_ref=self.controller_ref,
            )
        else:
            self.graph.transition(
                self.graph.root_id,
                GoalNodeStatus.INTEGRATION_FAILED,
            )
        return evaluation

    def issue_unresolved_certificate(
        self,
        reason: RootUnresolvedReason,
        blockers: Sequence[str],
        evidence_ids: Sequence[str],
        limitations: Sequence[str],
        minimum_viable_compute: Optional[float] = None,
    ) -> RootResolutionCertificate:
        self._ensure_open()
        if not blockers or not evidence_ids or not limitations:
            raise ValueError(
                "unresolved root requires blockers, evidence, and limitations"
            )
        if minimum_viable_compute is not None:
            if (
                not math.isfinite(minimum_viable_compute)
                or minimum_viable_compute <= 0
            ):
                raise ValueError(
                    "minimum viable compute must be positive and finite"
                )
        if reason == RootUnresolvedReason.BUDGET_EXHAUSTED:
            usable_compute_remains = (
                self.compute_remaining > 0
                and (
                    minimum_viable_compute is None
                    or self.compute_remaining >= minimum_viable_compute
                )
            )
            if usable_compute_remains:
                raise ValueError(
                    "budget exhaustion cannot be declared while enough "
                    "compute remains for a viable action"
                )
        if reason not in (
            RootUnresolvedReason.BUDGET_EXHAUSTED,
            RootUnresolvedReason.EXTERNAL_BLOCKED,
            RootUnresolvedReason.SAFETY_BLOCKED,
            RootUnresolvedReason.UNMEASURABLE_GOAL,
        ):
            raise ValueError("unsupported unresolved-root reason")
        certificate = RootResolutionCertificate(
            goal_id=self.goal.goal_id,
            terminal_state=RootTerminalState.UNRESOLVED,
            evidence_ids=tuple(evidence_ids),
            compute_spent=self.compute_spent,
            unresolved_node_ids=tuple(
                sorted(
                    node_id
                    for node_id, status in self.graph.statuses.items()
                    if status != GoalNodeStatus.INTEGRATED
                )
            ),
            limitations=tuple(limitations),
            reasons=(
                "the root objective remains unsatisfied",
                "termination is due to %s" % reason.value,
            ),
            unresolved_reason=reason,
            blockers=tuple(blockers),
        )
        self._resolution = certificate
        self.memory.append(
            ScientificMemoryEventKind.ROOT_UNRESOLVED,
            certificate.as_dict(),
            actor_ref=self.controller_ref,
        )
        return certificate

    def as_dict(self) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "controller_ref": self.controller_ref,
            "goal": self.goal.as_dict(),
            "graph": self.graph.as_dict(),
            "literature": {
                subject_id: [
                    assessment.as_dict() for assessment in assessments
                ]
                for subject_id, assessments in sorted(
                    self._literature.items()
                )
            },
            "incumbent_portfolios": [
                portfolio.as_dict()
                for _, portfolio in sorted(self._portfolios.items())
            ],
            "current_portfolio_ids": dict(
                sorted(self._current_portfolio_ids.items())
            ),
            "campaigns": {
                campaign_id: campaign.as_dict()
                for campaign_id, campaign in sorted(
                    self._campaigns.items()
                )
            },
            "active_campaign_ids": dict(
                sorted(self._active_campaign_ids.items())
            ),
            "test_exposures": [
                exposure.as_dict()
                for _, exposure in sorted(self._exposures.items())
            ],
            "parent_integrations": {
                node_id: [record.as_dict() for record in records]
                for node_id, records in sorted(self._integrations.items())
            },
            "scheduling_assessments": [
                assessment.as_dict()
                for _, assessment in sorted(
                    self._scheduling_assessments.items()
                )
            ],
            "root_gate_evaluations": [
                evaluation.as_dict()
                for evaluation in self._root_gate_evaluations
            ],
            "compute_spent": self.compute_spent,
            "compute_remaining": self.compute_remaining,
            "compute_committed": self.compute_committed,
            "compute_available_for_new_campaigns": (
                self.compute_available_for_new_campaigns
            ),
            "continuation_required": self.continuation_required,
            "resolution": (
                None
                if self._resolution is None
                else self._resolution.as_dict()
            ),
            "memory": self.memory.as_dict(),
        }
        if self._research_programs:
            value["research_programs"] = {
                program_id: program.as_dict()
                for program_id, program in sorted(
                    self._research_programs.items()
                )
            }
            value["active_research_program_ids"] = dict(
                sorted(self._active_research_program_ids.items())
            )
            value["research_program_diagnoses"] = {
                program_id: [item.as_dict() for item in diagnoses]
                for program_id, diagnoses in sorted(
                    self._research_program_diagnoses.items()
                )
            }
            value["representation_changes"] = {
                proposal_id: proposal.as_dict()
                for proposal_id, proposal in sorted(
                    self._representation_changes.items()
                )
            }
        if self._leaf_qualifications:
            value["leaf_qualifications"] = {
                node_id: [record.as_dict() for record in records]
                for node_id, records in sorted(
                    self._leaf_qualifications.items()
                )
            }
        if self._leaf_diagnostics:
            value["leaf_diagnostics"] = {
                node_id: [record.as_dict() for record in records]
                for node_id, records in sorted(
                    self._leaf_diagnostics.items()
                )
            }
        if self._cross_domain_inspirations:
            value["cross_domain_inspiration_portfolios"] = {
                node_id: [
                    portfolio.as_dict() for portfolio in portfolios
                ]
                for node_id, portfolios in sorted(
                    self._cross_domain_inspirations.items()
                )
            }
        if self._causal_failure_models:
            value["causal_failure_model_sets"] = {
                node_id: [
                    model_set.as_dict() for model_set in model_sets
                ]
                for node_id, model_sets in sorted(
                    self._causal_failure_models.items()
                )
            }
        if self._evaluation_horizons:
            value["evaluation_horizons"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(
                    self._evaluation_horizons.items()
                )
            }
            value["horizon_predictions"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(
                    self._horizon_predictions.items()
                )
            }
            value["horizon_outcomes"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(self._horizon_outcomes.items())
            }
            value["horizon_contrasts"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(
                    self._horizon_contrasts.items()
                )
            }
            value["horizon_failure_dossiers"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(self._horizon_dossiers.items())
            }
            value["representation_adequacy_assessments"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(
                    self._representation_adequacy_assessments.items()
                )
            }
            value["latent_concepts"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(self._latent_concepts.items())
            }
            value["concept_validations"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(
                    self._concept_validations.items()
                )
            }
            value["generator_revisions"] = {
                item_id: item.as_dict()
                for item_id, item in sorted(
                    self._generator_revisions.items()
                )
            }
            value["concept_grounded_representation_changes"] = dict(
                sorted(self._concept_grounded_representation_changes.items())
            )
        return value

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
        *,
        artifact_store: Optional[ArtifactStore] = None,
    ) -> "AutonomousScientistControlPlane":
        from scientist.program.goal_graph_serialization import (
            control_plane_from_dict,
        )

        return control_plane_from_dict(
            value,
            artifact_store=artifact_store,
        )
