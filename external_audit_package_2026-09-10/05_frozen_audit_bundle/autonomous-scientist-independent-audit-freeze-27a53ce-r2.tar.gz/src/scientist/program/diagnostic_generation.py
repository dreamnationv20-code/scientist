from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.program.hypothesis_learning import MechanismSignature


DIAGNOSTIC_GENERATION_VERSION = "diagnostic-grounded-generation-v1"


def _assert_unique(values: Tuple[str, ...], label: str) -> None:
    if not values or not all(values) or len(set(values)) != len(values):
        raise ValueError("%s must be non-empty and unique" % label)


class CapabilityEffectRole(str, Enum):
    IMPROVE = "improve"
    PRESERVE = "preserve"
    ACCEPTED_TRADEOFF = "accepted_tradeoff"


@dataclass(frozen=True)
class CapabilityChannelBranch:
    """One executable decision branch for one measured capability channel."""

    channel_id: str
    effect_role: CapabilityEffectRole
    intervention_operator: str
    state_update: str
    expected_effect: str
    falsification_condition: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.channel_id,
                self.intervention_operator,
                self.state_update,
                self.expected_effect,
                self.falsification_condition,
            )
        ):
            raise ValueError("capability-channel branch is incomplete")
        if self.channel_id in {"global", "aggregate", "overall"}:
            raise ValueError(
                "channel-conditional programs cannot use an aggregate channel"
            )

    @property
    def action_signature(self) -> str:
        return content_digest(
            {
                "channel_id": self.channel_id,
                "intervention_operator": self.intervention_operator,
                "state_update": self.state_update,
            }
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "channel_id": self.channel_id,
            "effect_role": self.effect_role.value,
            "intervention_operator": self.intervention_operator,
            "state_update": self.state_update,
            "expected_effect": self.expected_effect,
            "falsification_condition": self.falsification_condition,
            "action_signature": self.action_signature,
        }


@dataclass(frozen=True)
class ChannelConditionalHypothesisProgram:
    """A typed causal hypothesis whose intervention depends on target channel.

    ``execute`` is intentionally small but real: a probe evaluator can request
    a measured channel and obtain the exact intervention and state update that
    the hypothesis commits to. This prevents channel labels from being added as
    decorative prose while every proposal still executes the same policy.
    """

    target_node_id: str
    probe_problem_id: str
    source_concept_id: str
    source_diagnostic_id: str
    statement: str
    causal_factor: str
    mediator: str
    protected_resource: str
    branches: Tuple[CapabilityChannelBranch, ...]
    boundary_conditions: Tuple[str, ...]
    generator_ref: str
    compiler_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_node_id,
                self.probe_problem_id,
                self.source_concept_id,
                self.source_diagnostic_id,
                self.statement,
                self.causal_factor,
                self.mediator,
                self.protected_resource,
                self.generator_ref,
                self.compiler_ref,
            )
        ):
            raise ValueError("channel-conditional hypothesis is incomplete")
        if len(self.branches) < 2:
            raise ValueError(
                "channel-conditional hypotheses require at least two branches"
            )
        channel_ids = tuple(branch.channel_id for branch in self.branches)
        _assert_unique(channel_ids, "hypothesis capability channels")
        if not any(
            branch.effect_role == CapabilityEffectRole.IMPROVE
            for branch in self.branches
        ):
            raise ValueError("hypothesis must target at least one capability")
        if not any(
            branch.effect_role == CapabilityEffectRole.PRESERVE
            for branch in self.branches
        ):
            raise ValueError("hypothesis must protect at least one capability")
        if len(set(self.boundary_conditions)) != len(self.boundary_conditions):
            raise ValueError("hypothesis boundary conditions must be unique")

    @property
    def channel_ids(self) -> Tuple[str, ...]:
        return tuple(branch.channel_id for branch in self.branches)

    def execute(self, channel_id: str) -> Tuple[str, str]:
        matches = tuple(
            branch for branch in self.branches if branch.channel_id == channel_id
        )
        if len(matches) != 1:
            raise ValueError("hypothesis has no unique branch for capability channel")
        branch = matches[0]
        return branch.intervention_operator, branch.state_update

    @property
    def behavior_fingerprint(self) -> str:
        return content_digest(
            {
                "probe_problem_id": self.probe_problem_id,
                "channel_actions": {
                    branch.channel_id: [
                        branch.intervention_operator,
                        branch.state_update,
                    ]
                    for branch in sorted(
                        self.branches, key=lambda item: item.channel_id
                    )
                },
            }
        )

    @property
    def mechanism_signature(self) -> MechanismSignature:
        targets = tuple(
            branch.channel_id
            for branch in self.branches
            if branch.effect_role == CapabilityEffectRole.IMPROVE
        )
        protected = tuple(
            branch.channel_id
            for branch in self.branches
            if branch.effect_role == CapabilityEffectRole.PRESERVE
        )
        return MechanismSignature(
            target_failure_classes=("capability_channel_mismatch",),
            information_regime="capability_channel_observed",
            information_source="requested_capability_channel",
            intervention_operator=self.causal_factor,
            mediator=self.mediator,
            protected_resource=self.protected_resource,
            outcome="channel_conditional_capability_effect",
            boundary_conditions=self.boundary_conditions,
            signature_ref="diagnostic-grounded-channel-mechanism-v1",
            target_capability_channels=targets,
            protected_capability_channels=protected,
        )

    @property
    def hypothesis_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": DIAGNOSTIC_GENERATION_VERSION,
            "target_node_id": self.target_node_id,
            "probe_problem_id": self.probe_problem_id,
            "source_concept_id": self.source_concept_id,
            "source_diagnostic_id": self.source_diagnostic_id,
            "statement": self.statement,
            "causal_factor": self.causal_factor,
            "mediator": self.mediator,
            "protected_resource": self.protected_resource,
            "branches": [branch.as_dict() for branch in self.branches],
            "boundary_conditions": list(self.boundary_conditions),
            "generator_ref": self.generator_ref,
            "compiler_ref": self.compiler_ref,
            "mechanism_signature": self.mechanism_signature.as_dict(),
            "behavior_fingerprint": self.behavior_fingerprint,
        }
        if include_id:
            value["hypothesis_id"] = self.hypothesis_id
        return value


@dataclass(frozen=True)
class DiagnosticGroundedGeneratorRevision:
    """Certificate that a resolved diagnosis caused executable generation change."""

    target_node_id: str
    source_diagnostic_node_id: str
    source_diagnostic_id: str
    supported_concept_id: str
    probe_registry_id: str
    prior_representation_id: str
    revised_representation_id: str
    prior_generator_ref: str
    revised_generator_ref: str
    prior_behavior_fingerprints: Tuple[str, ...]
    generated_programs: Tuple[ChannelConditionalHypothesisProgram, ...]
    probe_problem_ids: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    reviser_ref: str

    def __post_init__(self) -> None:
        required = (
            self.target_node_id,
            self.source_diagnostic_node_id,
            self.source_diagnostic_id,
            self.supported_concept_id,
            self.probe_registry_id,
            self.prior_representation_id,
            self.revised_representation_id,
            self.prior_generator_ref,
            self.revised_generator_ref,
            self.reviser_ref,
        )
        if not all(required):
            raise ValueError("diagnostic-grounded generator revision is incomplete")
        if self.prior_representation_id == self.revised_representation_id:
            raise ValueError("generator revision must change representation")
        if self.prior_generator_ref == self.revised_generator_ref:
            raise ValueError("generator revision must change generator identity")
        _assert_unique(
            self.prior_behavior_fingerprints, "prior behavior fingerprints"
        )
        _assert_unique(self.probe_problem_ids, "generator probe problems")
        _assert_unique(self.evidence_ids, "generator revision evidence IDs")
        if len(self.generated_programs) < 2:
            raise ValueError("generator revision needs at least two programs")
        if any(
            program.target_node_id != self.target_node_id
            or program.source_diagnostic_id != self.source_diagnostic_id
            or program.source_concept_id != self.supported_concept_id
            or program.generator_ref != self.revised_generator_ref
            or program.probe_problem_id not in self.probe_problem_ids
            for program in self.generated_programs
        ):
            raise ValueError("generated program is not bound to the revision")
        _assert_unique(self.generated_hypothesis_ids, "generated hypothesis IDs")

    @property
    def generated_hypothesis_ids(self) -> Tuple[str, ...]:
        return tuple(program.hypothesis_id for program in self.generated_programs)

    @property
    def behavior_fingerprints(self) -> Tuple[str, ...]:
        return tuple(
            program.behavior_fingerprint for program in self.generated_programs
        )

    @property
    def revision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": DIAGNOSTIC_GENERATION_VERSION,
            "target_node_id": self.target_node_id,
            "source_diagnostic_node_id": self.source_diagnostic_node_id,
            "source_diagnostic_id": self.source_diagnostic_id,
            "supported_concept_id": self.supported_concept_id,
            "probe_registry_id": self.probe_registry_id,
            "prior_representation_id": self.prior_representation_id,
            "revised_representation_id": self.revised_representation_id,
            "prior_generator_ref": self.prior_generator_ref,
            "revised_generator_ref": self.revised_generator_ref,
            "prior_behavior_fingerprints": list(
                self.prior_behavior_fingerprints
            ),
            "generated_programs": [
                program.as_dict() for program in self.generated_programs
            ],
            "generated_hypothesis_ids": list(self.generated_hypothesis_ids),
            "behavior_fingerprints": list(self.behavior_fingerprints),
            "probe_problem_ids": list(self.probe_problem_ids),
            "evidence_ids": list(self.evidence_ids),
            "reviser_ref": self.reviser_ref,
        }
        if include_id:
            value["revision_id"] = self.revision_id
        return value


@dataclass(frozen=True)
class GeneratorRevisionVerification:
    revision_id: str
    check_results: Mapping[str, bool]
    prior_unique_behavior_count: int
    revised_unique_behavior_count: int
    target_channel_count: int
    probe_problem_count: int
    action_trace_ids: Tuple[str, ...]
    limitations: Tuple[str, ...]
    verifier_ref: str

    def __post_init__(self) -> None:
        if not self.revision_id or not self.check_results or not self.verifier_ref:
            raise ValueError("generator revision verification is incomplete")
        if min(
            self.prior_unique_behavior_count,
            self.revised_unique_behavior_count,
            self.target_channel_count,
            self.probe_problem_count,
        ) < 0:
            raise ValueError("generator revision counts cannot be negative")
        _assert_unique(self.action_trace_ids, "generator action traces")
        _assert_unique(self.limitations, "generator revision limitations")

    @property
    def passed(self) -> bool:
        return all(self.check_results.values())

    @property
    def verification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": DIAGNOSTIC_GENERATION_VERSION,
            "revision_id": self.revision_id,
            "check_results": dict(sorted(self.check_results.items())),
            "prior_unique_behavior_count": self.prior_unique_behavior_count,
            "revised_unique_behavior_count": self.revised_unique_behavior_count,
            "target_channel_count": self.target_channel_count,
            "probe_problem_count": self.probe_problem_count,
            "action_trace_ids": list(self.action_trace_ids),
            "limitations": list(self.limitations),
            "passed": self.passed,
            "verifier_ref": self.verifier_ref,
        }
        if include_id:
            value["verification_id"] = self.verification_id
        return value


def verify_diagnostic_grounded_revision(
    revision: DiagnosticGroundedGeneratorRevision,
    *,
    source_diagnostic_resolved: bool,
    source_supported_model_ids: Tuple[str, ...],
    verifier_ref: str,
) -> GeneratorRevisionVerification:
    programs = revision.generated_programs
    revised_fingerprints = revision.behavior_fingerprints
    target_channels = tuple(
        sorted(
            {
                branch.channel_id
                for program in programs
                for branch in program.branches
                if branch.effect_role == CapabilityEffectRole.IMPROVE
            }
        )
    )
    action_trace_ids = tuple(
        content_digest(
            {
                "program_id": program.hypothesis_id,
                "trace": [
                    [channel_id, *program.execute(channel_id)]
                    for channel_id in program.channel_ids
                ],
            }
        )
        for program in programs
    )
    checks = {
        "source_diagnostic_is_resolved": source_diagnostic_resolved,
        "concept_is_supported_by_source_diagnostic": (
            revision.supported_concept_id in source_supported_model_ids
        ),
        "probe_registry_is_bound_before_generation": all(
            revision.probe_registry_id in program.boundary_conditions
            for program in programs
        ),
        "every_program_has_channel_conditional_execution": all(
            len(set(program.execute(channel) for channel in program.channel_ids))
            >= 2
            for program in programs
        ),
        "every_program_targets_and_protects_distinct_channels": all(
            any(
                branch.effect_role == CapabilityEffectRole.IMPROVE
                for branch in program.branches
            )
            and any(
                branch.effect_role == CapabilityEffectRole.PRESERVE
                for branch in program.branches
            )
            for program in programs
        ),
        "multiple_capability_channels_are_targeted": len(target_channels) >= 2,
        "multiple_unseen_probe_problems_are_covered": (
            len(set(program.probe_problem_id for program in programs)) >= 2
        ),
        "revised_programs_are_behaviorally_distinct": (
            len(set(revised_fingerprints)) >= 2
        ),
        "revised_behavior_exceeds_prior_behavioral_support": (
            len(set(revised_fingerprints))
            > len(set(revision.prior_behavior_fingerprints))
        ),
        "channel_axis_changes_mechanism_identity": all(
            program.mechanism_signature.target_capability_channels
            and program.mechanism_signature.mechanism_id
            != MechanismSignature(
                target_failure_classes=("capability_channel_mismatch",),
                information_regime="capability_channel_observed",
                information_source="requested_capability_channel",
                intervention_operator=program.causal_factor,
                mediator=program.mediator,
                protected_resource=program.protected_resource,
                outcome="channel_conditional_capability_effect",
                boundary_conditions=program.boundary_conditions,
                signature_ref="diagnostic-grounded-channel-mechanism-v1",
            ).mechanism_id
            for program in programs
        ),
    }
    return GeneratorRevisionVerification(
        revision_id=revision.revision_id,
        check_results=checks,
        prior_unique_behavior_count=len(
            set(revision.prior_behavior_fingerprints)
        ),
        revised_unique_behavior_count=len(set(revised_fingerprints)),
        target_channel_count=len(target_channels),
        probe_problem_count=len(
            set(program.probe_problem_id for program in programs)
        ),
        action_trace_ids=action_trace_ids,
        limitations=(
            "This validates causal representation and executable generation, not downstream objective improvement.",
            "The probe problems are held out capability pairs in the cognitive-core task family, not external domains.",
            "A production generator must still invent useful factors rather than receive a curated factor vocabulary.",
        ),
        verifier_ref=verifier_ref,
    )

