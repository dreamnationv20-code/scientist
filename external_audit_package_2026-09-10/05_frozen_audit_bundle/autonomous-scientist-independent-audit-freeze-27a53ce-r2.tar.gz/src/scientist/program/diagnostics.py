from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import EvidencePartition


LEAF_DIAGNOSTIC_VERSION = "goal-graph-leaf-diagnostic-v1"


class DiagnosticDisposition(str, Enum):
    SUPPORTED = "supported"
    REFUTED = "refuted"
    MIXED = "mixed"
    INCONCLUSIVE = "inconclusive"


@dataclass(frozen=True)
class LeafDiagnosticRecord:
    """Auditable resolution of a causal diagnostic, not a solution candidate."""

    node_id: str
    leaf_contract_id: str
    protocol_ref: str
    evaluator_ref: str
    verifier_ref: str
    intervention_ids: Tuple[str, ...]
    frozen_predictions: Mapping[str, Tuple[str, ...]]
    observed_outcomes: Mapping[str, float]
    uncertainty_bounds: Mapping[str, float]
    model_scores: Mapping[str, float]
    supported_model_ids: Tuple[str, ...]
    disposition: DiagnosticDisposition
    validity_checks: Mapping[str, bool]
    preregistered_success_conditions: Tuple[str, ...]
    falsification_hits: Tuple[str, ...]
    evidence_ids_by_partition: Mapping[str, Tuple[str, ...]]
    raw_artifact_ids: Tuple[str, ...]
    horizon_refs: Tuple[str, ...]
    metric_name: str
    metric_value: float
    compute_cost: float
    limitations: Tuple[str, ...]
    schema_version: str = LEAF_DIAGNOSTIC_VERSION

    def __post_init__(self) -> None:
        required = (
            self.node_id,
            self.leaf_contract_id,
            self.protocol_ref,
            self.evaluator_ref,
            self.verifier_ref,
            self.metric_name,
        )
        if not all(required):
            raise ValueError("leaf diagnostic identity must not be empty")
        if self.evaluator_ref == self.verifier_ref:
            raise ValueError("leaf diagnostic requires an independent verifier")
        if not self.intervention_ids or len(set(self.intervention_ids)) != len(
            self.intervention_ids
        ):
            raise ValueError("leaf diagnostic interventions must be non-empty and unique")
        if "null" not in self.frozen_predictions:
            raise ValueError("leaf diagnostic must include a frozen null model")
        if not self.observed_outcomes or set(self.observed_outcomes) != set(
            self.uncertainty_bounds
        ):
            raise ValueError("diagnostic outcomes and uncertainty must align")
        if any(
            not math.isfinite(value) for value in self.observed_outcomes.values()
        ) or any(
            not math.isfinite(value) or value < 0.0
            for value in self.uncertainty_bounds.values()
        ):
            raise ValueError("diagnostic outcomes and uncertainty must be finite")
        if not self.model_scores or any(
            not math.isfinite(value) for value in self.model_scores.values()
        ):
            raise ValueError("leaf diagnostic requires finite model scores")
        if any(item not in self.model_scores for item in self.supported_model_ids):
            raise ValueError("supported diagnostic model lacks a score")
        if not self.validity_checks or not self.preregistered_success_conditions:
            raise ValueError("leaf diagnostic requires frozen validity conditions")
        if not self.raw_artifact_ids or not self.limitations:
            raise ValueError("leaf diagnostic requires artifacts and limitations")
        if not math.isfinite(self.metric_value):
            raise ValueError("leaf diagnostic metric must be finite")
        if not math.isfinite(self.compute_cost) or self.compute_cost < 0.0:
            raise ValueError("leaf diagnostic compute must be finite and non-negative")
        required_partitions = {
            EvidencePartition.AUDIT.value,
            EvidencePartition.REPLICATION.value,
        }
        if not required_partitions.issubset(self.evidence_ids_by_partition):
            raise ValueError("diagnostic requires audit and replication evidence")
        if any(
            not evidence_ids or any(not item for item in evidence_ids)
            for evidence_ids in self.evidence_ids_by_partition.values()
        ):
            raise ValueError("diagnostic partitions require evidence artifacts")
        if self.resolved and self.metric_value != 1.0:
            raise ValueError("resolved diagnostic must satisfy its binary metric")
        if not self.resolved and self.metric_value == 1.0:
            raise ValueError("unresolved diagnostic cannot satisfy its metric")

    @property
    def resolved(self) -> bool:
        return (
            all(self.validity_checks.values())
            and not self.falsification_hits
            and self.disposition != DiagnosticDisposition.INCONCLUSIVE
        )

    @property
    def evidence_ids(self) -> Tuple[str, ...]:
        return tuple(
            evidence_id
            for partition in sorted(self.evidence_ids_by_partition)
            for evidence_id in self.evidence_ids_by_partition[partition]
        )

    @property
    def diagnostic_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "schema_version": self.schema_version,
            "node_id": self.node_id,
            "leaf_contract_id": self.leaf_contract_id,
            "protocol_ref": self.protocol_ref,
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "intervention_ids": list(self.intervention_ids),
            "frozen_predictions": {
                model_id: list(predictions)
                for model_id, predictions in sorted(
                    self.frozen_predictions.items()
                )
            },
            "observed_outcomes": dict(sorted(self.observed_outcomes.items())),
            "uncertainty_bounds": dict(sorted(self.uncertainty_bounds.items())),
            "model_scores": dict(sorted(self.model_scores.items())),
            "supported_model_ids": list(self.supported_model_ids),
            "disposition": self.disposition.value,
            "validity_checks": dict(sorted(self.validity_checks.items())),
            "preregistered_success_conditions": list(
                self.preregistered_success_conditions
            ),
            "falsification_hits": list(self.falsification_hits),
            "evidence_ids_by_partition": {
                partition: list(evidence_ids)
                for partition, evidence_ids in sorted(
                    self.evidence_ids_by_partition.items()
                )
            },
            "raw_artifact_ids": list(self.raw_artifact_ids),
            "horizon_refs": list(self.horizon_refs),
            "metric_name": self.metric_name,
            "metric_value": self.metric_value,
            "compute_cost": self.compute_cost,
            "resolved": self.resolved,
            "limitations": list(self.limitations),
        }
        if include_id:
            value["diagnostic_id"] = self.diagnostic_id
        return value


def leaf_diagnostic_from_dict(
    value: Mapping[str, Any],
) -> LeafDiagnosticRecord:
    record = LeafDiagnosticRecord(
        node_id=str(value["node_id"]),
        leaf_contract_id=str(value["leaf_contract_id"]),
        protocol_ref=str(value["protocol_ref"]),
        evaluator_ref=str(value["evaluator_ref"]),
        verifier_ref=str(value["verifier_ref"]),
        intervention_ids=tuple(str(item) for item in value["intervention_ids"]),
        frozen_predictions={
            str(key): tuple(str(item) for item in items)
            for key, items in value["frozen_predictions"].items()
        },
        observed_outcomes={
            str(key): float(item)
            for key, item in value["observed_outcomes"].items()
        },
        uncertainty_bounds={
            str(key): float(item)
            for key, item in value["uncertainty_bounds"].items()
        },
        model_scores={
            str(key): float(item) for key, item in value["model_scores"].items()
        },
        supported_model_ids=tuple(
            str(item) for item in value["supported_model_ids"]
        ),
        disposition=DiagnosticDisposition(value["disposition"]),
        validity_checks={
            str(key): bool(item)
            for key, item in value["validity_checks"].items()
        },
        preregistered_success_conditions=tuple(
            str(item) for item in value["preregistered_success_conditions"]
        ),
        falsification_hits=tuple(
            str(item) for item in value["falsification_hits"]
        ),
        evidence_ids_by_partition={
            str(key): tuple(str(item) for item in items)
            for key, items in value["evidence_ids_by_partition"].items()
        },
        raw_artifact_ids=tuple(str(item) for item in value["raw_artifact_ids"]),
        horizon_refs=tuple(str(item) for item in value["horizon_refs"]),
        metric_name=str(value["metric_name"]),
        metric_value=float(value["metric_value"]),
        compute_cost=float(value["compute_cost"]),
        limitations=tuple(str(item) for item in value["limitations"]),
        schema_version=str(value.get("schema_version", LEAF_DIAGNOSTIC_VERSION)),
    )
    supplied = value.get("diagnostic_id")
    if supplied is not None and str(supplied) != record.diagnostic_id:
        raise ValueError("leaf diagnostic identity mismatch")
    if "resolved" in value and bool(value["resolved"]) != record.resolved:
        raise ValueError("leaf diagnostic resolution mismatch")
    return record
