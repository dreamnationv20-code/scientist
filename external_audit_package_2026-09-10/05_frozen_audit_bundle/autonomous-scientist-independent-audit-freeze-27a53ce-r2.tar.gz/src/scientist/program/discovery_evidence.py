from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import mean, stdev
from typing import Any, Dict, Iterable, Sequence, Tuple


DISCOVERY_EVIDENCE_VERSION = "episode-level-discovery-evidence-v1"


# Two-sided 95% Student-t critical values for small independent samples.  At
# larger sample sizes the normal approximation is sufficiently conservative
# for this discovery screen.
_T_975 = (
    0.0,
    12.706,
    4.303,
    3.182,
    2.776,
    2.571,
    2.447,
    2.365,
    2.306,
    2.262,
    2.228,
    2.201,
    2.179,
    2.160,
    2.145,
    2.131,
    2.120,
    2.110,
    2.101,
    2.093,
    2.086,
    2.080,
    2.074,
    2.069,
    2.064,
    2.060,
    2.056,
    2.052,
    2.048,
    2.045,
)


def _critical_value(sample_count: int) -> float:
    degrees_of_freedom = sample_count - 1
    if degrees_of_freedom < len(_T_975):
        return _T_975[degrees_of_freedom]
    return 1.96


@dataclass(frozen=True)
class PairedEpisodeEvidence:
    """Uncertainty computed only across independent episode groups."""

    group_ids: Tuple[str, ...]
    improvements: Tuple[float, ...]
    aggregate_improvement: float
    mean_improvement: float
    standard_error: float
    mean_ci_lower: float
    mean_ci_upper: float
    aggregate_ci_lower: float
    aggregate_ci_upper: float
    wins: int
    ties: int
    losses: int
    maximum_regression: float

    @property
    def episode_count(self) -> int:
        return len(self.improvements)

    @property
    def loss_rate(self) -> float:
        return self.losses / float(self.episode_count)

    def metrics(self) -> Dict[str, float]:
        return {
            "episode_count": float(self.episode_count),
            "independent_group_count": float(len(self.group_ids)),
            "aggregate_improvement": self.aggregate_improvement,
            "mean_improvement": self.mean_improvement,
            "improvement_standard_error": self.standard_error,
            "mean_improvement_ci_lower": self.mean_ci_lower,
            "mean_improvement_ci_upper": self.mean_ci_upper,
            "aggregate_improvement_ci_lower": self.aggregate_ci_lower,
            "aggregate_improvement_ci_upper": self.aggregate_ci_upper,
            "wins": float(self.wins),
            "ties": float(self.ties),
            "losses": float(self.losses),
            "batch_win_rate": self.wins / float(self.episode_count),
            "loss_rate": self.loss_rate,
            "maximum_regression": self.maximum_regression,
        }

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": DISCOVERY_EVIDENCE_VERSION,
            "unit_of_independence": "episode_group",
            "confidence_level": 0.95,
            "group_ids": list(self.group_ids),
            "improvements": list(self.improvements),
            **self.metrics(),
        }


def paired_episode_evidence(
    improvements: Iterable[float],
    group_ids: Sequence[str],
) -> PairedEpisodeEvidence:
    values = tuple(float(value) for value in improvements)
    groups = tuple(str(value) for value in group_ids)
    if len(values) < 2:
        raise ValueError(
            "paired discovery evidence requires at least two independent episodes"
        )
    if len(groups) != len(values):
        raise ValueError("each episode improvement requires one group identity")
    if len(set(groups)) != len(groups):
        raise ValueError(
            "decision rows or repeated episodes cannot be counted as independent"
        )
    if not all(math.isfinite(value) for value in values):
        raise ValueError("episode improvements must be finite")
    sample_mean = mean(values)
    standard_error = stdev(values) / math.sqrt(len(values))
    radius = _critical_value(len(values)) * standard_error
    lower = sample_mean - radius
    upper = sample_mean + radius
    return PairedEpisodeEvidence(
        group_ids=groups,
        improvements=values,
        aggregate_improvement=sum(values),
        mean_improvement=sample_mean,
        standard_error=standard_error,
        mean_ci_lower=lower,
        mean_ci_upper=upper,
        aggregate_ci_lower=lower * len(values),
        aggregate_ci_upper=upper * len(values),
        wins=sum(value > 0.0 for value in values),
        ties=sum(value == 0.0 for value in values),
        losses=sum(value < 0.0 for value in values),
        maximum_regression=max(0.0, max(-value for value in values)),
    )


@dataclass(frozen=True)
class DiscoveryQualification:
    evidence: PairedEpisodeEvidence
    minimum_independent_episodes: int
    passed: bool
    reasons: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "gate": "primary_discovery_performance",
            "passed": self.passed,
            "minimum_independent_episodes": self.minimum_independent_episodes,
            "criteria": [
                "95% confidence interval for aggregate improvement is positive",
                "95% confidence interval for mean episode improvement excludes zero",
                "minimum independent episode count is met",
            ],
            "reasons": list(self.reasons),
            "evidence": self.evidence.as_dict(),
        }


def qualify_discovery(
    evidence: PairedEpisodeEvidence,
    *,
    minimum_independent_episodes: int,
) -> DiscoveryQualification:
    if minimum_independent_episodes < 2:
        raise ValueError("discovery qualification requires at least two episodes")
    reasons = []
    if evidence.episode_count < minimum_independent_episodes:
        reasons.append("insufficient_independent_episodes")
    if evidence.aggregate_ci_lower <= 0.0:
        reasons.append("aggregate_improvement_confidence_interval_includes_zero")
    if evidence.mean_ci_lower <= 0.0:
        reasons.append("mean_improvement_confidence_interval_includes_zero")
    return DiscoveryQualification(
        evidence=evidence,
        minimum_independent_episodes=minimum_independent_episodes,
        passed=not reasons,
        reasons=tuple(reasons),
    )


@dataclass(frozen=True)
class DeploymentQualification:
    evidence: PairedEpisodeEvidence
    maximum_allowed_regression: float
    maximum_allowed_loss_rate: float
    passed: bool
    reasons: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "gate": "deployment_safety_only",
            "passed": self.passed,
            "maximum_allowed_regression": self.maximum_allowed_regression,
            "maximum_allowed_loss_rate": self.maximum_allowed_loss_rate,
            "criteria": [
                "worst-case episode regression is within deployment limit",
                "episode loss rate is within deployment limit",
            ],
            "reasons": list(self.reasons),
            "observed_maximum_regression": self.evidence.maximum_regression,
            "observed_loss_rate": self.evidence.loss_rate,
            "does_not_control_discovery": True,
        }


def qualify_deployment(
    evidence: PairedEpisodeEvidence,
    *,
    maximum_allowed_regression: float,
    maximum_allowed_loss_rate: float,
) -> DeploymentQualification:
    if maximum_allowed_regression < 0.0:
        raise ValueError("maximum deployment regression must be non-negative")
    if not 0.0 <= maximum_allowed_loss_rate <= 1.0:
        raise ValueError("maximum deployment loss rate must be in [0, 1]")
    reasons = []
    if evidence.maximum_regression > maximum_allowed_regression:
        reasons.append("worst_case_regression_exceeds_deployment_limit")
    if evidence.loss_rate > maximum_allowed_loss_rate:
        reasons.append("loss_rate_exceeds_deployment_limit")
    return DeploymentQualification(
        evidence=evidence,
        maximum_allowed_regression=maximum_allowed_regression,
        maximum_allowed_loss_rate=maximum_allowed_loss_rate,
        passed=not reasons,
        reasons=tuple(reasons),
    )
