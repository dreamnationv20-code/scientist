from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest


EXECUTABLE_HYPOTHESIS_VERSION = "executable-hypothesis-v1"


class InformationRegime(str, Enum):
    """How an online intervention copes with unavailable future state."""

    PREDICTIVE_PROXY = "predictive_proxy"
    ROBUST_OPTIONALITY = "robust_optionality"


class CausalEvolutionOperator(str, Enum):
    """Operators that must change an executable causal contract."""

    SOURCE_TRANSFER = "source_transfer"
    SUBSTITUTE_PROXY = "substitute_proxy"
    SUBSTITUTE_INTERVENTION = "substitute_intervention"
    SPECIALIZE_FAILURE_CLUSTER = "specialize_failure_cluster"
    ROBUSTIFY_OPTIONALITY = "robustify_optionality"
    MEDIATOR_ABLATION = "mediator_ablation"
    COMPLEMENTARY_CAUSAL_COMBINATION = (
        "complementary_causal_combination"
    )


@dataclass(frozen=True)
class GeneratorPatch:
    """Serializable seed that a registered generator must actually consume."""

    generator_ref: str
    information_regime: InformationRegime
    causal_operator: CausalEvolutionOperator
    feature_weights: Tuple[Tuple[str, float], ...]
    protected_option: str
    compiler_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.generator_ref,
                self.feature_weights,
                self.protected_option,
                self.compiler_ref,
            )
        ):
            raise ValueError("generator patch is incomplete")
        names = tuple(name for name, _ in self.feature_weights)
        if len(set(names)) != len(names):
            raise ValueError("generator patch feature names must be unique")
        if any(
            not name or not math.isfinite(float(weight))
            for name, weight in self.feature_weights
        ):
            raise ValueError("generator patch weights must be finite")
        if not any(abs(float(weight)) > 1e-12 for _, weight in self.feature_weights):
            raise ValueError("generator patch must change at least one feature")

    @property
    def patch_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": EXECUTABLE_HYPOTHESIS_VERSION,
            "generator_ref": self.generator_ref,
            "information_regime": self.information_regime.value,
            "causal_operator": self.causal_operator.value,
            "feature_weights": [
                [name, weight] for name, weight in self.feature_weights
            ],
            "protected_option": self.protected_option,
            "compiler_ref": self.compiler_ref,
        }
        if include_id:
            value["patch_id"] = self.patch_id
        return value


@dataclass(frozen=True)
class ExecutableHypothesisContract:
    """Typed, falsifiable bridge from a causal idea to executable search."""

    target_node_id: str
    target_cluster_ids: Tuple[str, ...]
    observable_trigger: str
    action_change: str
    protected_option: str
    mediator: str
    information_regime: InformationRegime
    expected_effect: float
    effect_unit: str
    matched_control_prediction: str
    ablation: str
    shuffled_information_prediction: str
    prior_art_distinction: str
    generator_patch: GeneratorPatch
    diagnostic_budget: int
    contract_ref: str

    def __post_init__(self) -> None:
        required = (
            self.target_node_id,
            self.target_cluster_ids,
            self.observable_trigger,
            self.action_change,
            self.protected_option,
            self.mediator,
            self.effect_unit,
            self.matched_control_prediction,
            self.ablation,
            self.shuffled_information_prediction,
            self.prior_art_distinction,
            self.contract_ref,
        )
        if not all(required):
            raise ValueError("executable hypothesis contract is incomplete")
        if len(set(self.target_cluster_ids)) != len(
            self.target_cluster_ids
        ):
            raise ValueError("hypothesis target clusters must be unique")
        if (
            not math.isfinite(self.expected_effect)
            or self.expected_effect <= 0
        ):
            raise ValueError("expected hypothesis effect must be positive")
        if self.diagnostic_budget < 1:
            raise ValueError("diagnostic budget must be positive")
        if (
            self.generator_patch.information_regime
            != self.information_regime
        ):
            raise ValueError(
                "hypothesis contract and generator patch disagree on "
                "information regime"
            )

    @property
    def executable_digest(self) -> str:
        return content_digest(
            {
                "target_node_id": self.target_node_id,
                "target_cluster_ids": list(self.target_cluster_ids),
                "observable_trigger": self.observable_trigger,
                "action_change": self.action_change,
                "protected_option": self.protected_option,
                "mediator": self.mediator,
                "information_regime": self.information_regime.value,
                "generator_patch": self.generator_patch.as_dict(),
            }
        )

    @property
    def contract_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": EXECUTABLE_HYPOTHESIS_VERSION,
            "target_node_id": self.target_node_id,
            "target_cluster_ids": list(self.target_cluster_ids),
            "observable_trigger": self.observable_trigger,
            "action_change": self.action_change,
            "protected_option": self.protected_option,
            "mediator": self.mediator,
            "information_regime": self.information_regime.value,
            "expected_effect": self.expected_effect,
            "effect_unit": self.effect_unit,
            "matched_control_prediction": self.matched_control_prediction,
            "ablation": self.ablation,
            "shuffled_information_prediction": (
                self.shuffled_information_prediction
            ),
            "prior_art_distinction": self.prior_art_distinction,
            "generator_patch": self.generator_patch.as_dict(),
            "diagnostic_budget": self.diagnostic_budget,
            "contract_ref": self.contract_ref,
            "executable_digest": self.executable_digest,
        }
        if include_id:
            value["contract_id"] = self.contract_id
        return value


@dataclass(frozen=True)
class HypothesisDiagnosticResult:
    """Cheap preregistered evidence collected before broad evolution."""

    contract_id: str
    executable_digest: str
    target_replay_count: int
    matched_control_count: int
    target_effect: float
    matched_control_effect: float
    ablation_effect: float
    shuffled_information_effect: float
    mediator_consistency: float
    prediction_log_score: float
    prior_art_distinct: bool
    passed: bool
    failure_reasons: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    diagnostic_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.contract_id,
                self.executable_digest,
                self.diagnostic_ref,
            )
        ):
            raise ValueError("hypothesis diagnostic is incomplete")
        if self.target_replay_count < 0 or self.matched_control_count < 0:
            raise ValueError("diagnostic replay counts cannot be negative")
        numeric = (
            self.target_effect,
            self.matched_control_effect,
            self.ablation_effect,
            self.shuffled_information_effect,
            self.mediator_consistency,
            self.prediction_log_score,
        )
        if not all(math.isfinite(value) for value in numeric):
            raise ValueError("diagnostic measurements must be finite")
        if not 0 <= self.mediator_consistency <= 1:
            raise ValueError("mediator consistency must be in [0, 1]")
        if self.passed and (
            self.failure_reasons
            or not self.prior_art_distinct
            or self.target_replay_count == 0
        ):
            raise ValueError(
                "a passing diagnostic cannot retain failure conditions"
            )
        if len(set(self.evidence_ids)) != len(self.evidence_ids):
            raise ValueError("diagnostic evidence IDs must be unique")

    @property
    def diagnostic_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def evidence_update(self) -> int:
        """Bounded tournament update derived only from diagnostic evidence."""

        if not self.passed:
            return -8
        raw = (
            2.0 * self.target_effect
            - self.matched_control_effect
            - abs(self.ablation_effect)
            + self.mediator_consistency
            + self.prediction_log_score
        )
        return max(-8, min(8, int(round(raw))))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": EXECUTABLE_HYPOTHESIS_VERSION,
            "contract_id": self.contract_id,
            "executable_digest": self.executable_digest,
            "target_replay_count": self.target_replay_count,
            "matched_control_count": self.matched_control_count,
            "target_effect": self.target_effect,
            "matched_control_effect": self.matched_control_effect,
            "ablation_effect": self.ablation_effect,
            "shuffled_information_effect": (
                self.shuffled_information_effect
            ),
            "mediator_consistency": self.mediator_consistency,
            "prediction_log_score": self.prediction_log_score,
            "prior_art_distinct": self.prior_art_distinct,
            "passed": self.passed,
            "failure_reasons": list(self.failure_reasons),
            "evidence_ids": list(self.evidence_ids),
            "diagnostic_ref": self.diagnostic_ref,
            "evidence_update": self.evidence_update,
        }
        if include_id:
            value["diagnostic_id"] = self.diagnostic_id
        return value


def generator_patch_from_dict(value: Mapping[str, Any]) -> GeneratorPatch:
    patch = GeneratorPatch(
        generator_ref=str(value["generator_ref"]),
        information_regime=InformationRegime(value["information_regime"]),
        causal_operator=CausalEvolutionOperator(value["causal_operator"]),
        feature_weights=tuple(
            (str(name), float(weight))
            for name, weight in value["feature_weights"]
        ),
        protected_option=str(value["protected_option"]),
        compiler_ref=str(value["compiler_ref"]),
    )
    supplied = value.get("patch_id")
    if supplied is not None and str(supplied) != patch.patch_id:
        raise ValueError("generator patch identity mismatch")
    return patch


def executable_hypothesis_from_dict(
    value: Mapping[str, Any],
) -> ExecutableHypothesisContract:
    contract = ExecutableHypothesisContract(
        target_node_id=str(value["target_node_id"]),
        target_cluster_ids=tuple(
            str(item) for item in value["target_cluster_ids"]
        ),
        observable_trigger=str(value["observable_trigger"]),
        action_change=str(value["action_change"]),
        protected_option=str(value["protected_option"]),
        mediator=str(value["mediator"]),
        information_regime=InformationRegime(value["information_regime"]),
        expected_effect=float(value["expected_effect"]),
        effect_unit=str(value["effect_unit"]),
        matched_control_prediction=str(
            value["matched_control_prediction"]
        ),
        ablation=str(value["ablation"]),
        shuffled_information_prediction=str(
            value["shuffled_information_prediction"]
        ),
        prior_art_distinction=str(value["prior_art_distinction"]),
        generator_patch=generator_patch_from_dict(value["generator_patch"]),
        diagnostic_budget=int(value["diagnostic_budget"]),
        contract_ref=str(value["contract_ref"]),
    )
    supplied = value.get("contract_id")
    if supplied is not None and str(supplied) != contract.contract_id:
        raise ValueError("executable hypothesis identity mismatch")
    digest = value.get("executable_digest")
    if digest is not None and str(digest) != contract.executable_digest:
        raise ValueError("executable hypothesis digest mismatch")
    return contract


def hypothesis_diagnostic_from_dict(
    value: Mapping[str, Any],
) -> HypothesisDiagnosticResult:
    result = HypothesisDiagnosticResult(
        contract_id=str(value["contract_id"]),
        executable_digest=str(value["executable_digest"]),
        target_replay_count=int(value["target_replay_count"]),
        matched_control_count=int(value["matched_control_count"]),
        target_effect=float(value["target_effect"]),
        matched_control_effect=float(value["matched_control_effect"]),
        ablation_effect=float(value["ablation_effect"]),
        shuffled_information_effect=float(
            value["shuffled_information_effect"]
        ),
        mediator_consistency=float(value["mediator_consistency"]),
        prediction_log_score=float(value["prediction_log_score"]),
        prior_art_distinct=bool(value["prior_art_distinct"]),
        passed=bool(value["passed"]),
        failure_reasons=tuple(
            str(item) for item in value.get("failure_reasons", ())
        ),
        evidence_ids=tuple(
            str(item) for item in value.get("evidence_ids", ())
        ),
        diagnostic_ref=str(value["diagnostic_ref"]),
    )
    supplied = value.get("diagnostic_id")
    if supplied is not None and str(supplied) != result.diagnostic_id:
        raise ValueError("hypothesis diagnostic identity mismatch")
    if (
        value.get("evidence_update") is not None
        and int(value["evidence_update"]) != result.evidence_update
    ):
        raise ValueError("hypothesis diagnostic evidence update mismatch")
    return result
