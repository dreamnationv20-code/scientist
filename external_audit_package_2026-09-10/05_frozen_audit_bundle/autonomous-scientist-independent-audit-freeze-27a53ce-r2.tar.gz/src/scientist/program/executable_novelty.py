from __future__ import annotations

import ast
from collections import Counter
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


EXECUTABLE_NOVELTY_VERSION = "canonical-executable-mechanism-v1"


def _bucket(count: int) -> str:
    if count <= 0:
        return "0"
    if count == 1:
        return "1"
    if count == 2:
        return "2"
    return "3_plus"


def _control_depth(node: ast.AST, depth: int = 0) -> int:
    nested = depth + int(isinstance(node, (ast.If, ast.For)))
    return max(
        (nested, *(_control_depth(child, nested) for child in ast.iter_child_nodes(node)))
    )


@dataclass(frozen=True)
class CanonicalExecutableMechanism:
    """A prose-independent, coarse structural identity for executable policies."""

    data_channels: Tuple[str, ...]
    operation_profile: Tuple[Tuple[str, str], ...]
    branch_bucket: str
    loop_bucket: str
    maximum_control_depth: int
    state_key_bucket: str
    return_modes: Tuple[str, ...]

    @property
    def signature_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": EXECUTABLE_NOVELTY_VERSION,
            "data_channels": list(self.data_channels),
            "operation_profile": [list(item) for item in self.operation_profile],
            "branch_bucket": self.branch_bucket,
            "loop_bucket": self.loop_bucket,
            "maximum_control_depth": self.maximum_control_depth,
            "state_key_bucket": self.state_key_bucket,
            "return_modes": list(self.return_modes),
        }
        if include_id:
            value["signature_id"] = self.signature_id
        return value


def canonical_executable_mechanism(
    source: str,
    *,
    input_names: Sequence[str] = (
        "item",
        "loads",
        "capacity",
        "item_index",
        "history",
        "state",
    ),
    abstain_values: Sequence[int] = (-2,),
) -> CanonicalExecutableMechanism:
    tree = ast.parse(source, mode="exec")
    reads = {
        node.id
        for node in ast.walk(tree)
        if isinstance(node, ast.Name)
        and isinstance(node.ctx, ast.Load)
        and node.id in input_names
    }
    operations = Counter(
        type(node).__name__
        for node in ast.walk(tree)
        if isinstance(
            node,
            (
                ast.Add,
                ast.Sub,
                ast.Mult,
                ast.Div,
                ast.Mod,
                ast.Compare,
                ast.BoolOp,
                ast.IfExp,
            ),
        )
    )
    state_keys = {
        node.slice.value
        for node in ast.walk(tree)
        if isinstance(node, ast.Subscript)
        and isinstance(node.value, ast.Name)
        and node.value.id == "state"
        and isinstance(node.slice, ast.Constant)
        and isinstance(node.slice.value, str)
    }
    returns = set()
    abstain_set = set(abstain_values)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Return) or node.value is None:
            continue
        value = node.value
        if (
            isinstance(value, ast.UnaryOp)
            and isinstance(value.op, ast.USub)
            and isinstance(value.operand, ast.Constant)
            and isinstance(value.operand.value, int)
        ):
            integer = -value.operand.value
            if integer in abstain_set:
                returns.add("abstain")
            elif integer == -1:
                returns.add("new_host")
            else:
                returns.add("constant_integer")
        elif isinstance(value, ast.Constant) and isinstance(value.value, int):
            returns.add("constant_integer")
        else:
            returns.add("computed_host")
    return CanonicalExecutableMechanism(
        data_channels=tuple(sorted(reads)),
        operation_profile=tuple(
            sorted((name, _bucket(count)) for name, count in operations.items())
        ),
        branch_bucket=_bucket(sum(isinstance(node, ast.If) for node in ast.walk(tree))),
        loop_bucket=_bucket(sum(isinstance(node, ast.For) for node in ast.walk(tree))),
        maximum_control_depth=_control_depth(tree),
        state_key_bucket=_bucket(len(state_keys)),
        return_modes=tuple(sorted(returns)),
    )

