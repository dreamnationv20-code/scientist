from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Iterable, Mapping, Optional, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import MetricSpec


GOAL_GRAPH_ARCHITECTURE_VERSION = "goal-graph-scientist-v2"
DEFAULT_MAX_EVIDENCE_DEPTH = 2
DEFAULT_MAX_META_COMPUTE_FRACTION = 0.35
STRICT_REPRESENTATION_REVISION_TRIGGER = (
    "held-out opposing outcomes remain unexplained by every frozen descriptor"
)


class GoalNodeKind(str, Enum):
    ROOT = "root"
    CAPABILITY = "capability"
    BOTTLENECK = "bottleneck"
    SCIENTIFIC_QUESTION = "scientific_question"
    ENGINEERING_ENABLER = "engineering_enabler"
    INTEGRATION = "integration"
    EXECUTABLE_LEAF = "executable_leaf"


class GoalNodeRole(str, Enum):
    """Whether a node changes the world or only justifies a claim about it."""

    OBJECTIVE = "objective"
    EVIDENCE = "evidence"


class GoalNodeStatus(str, Enum):
    PROPOSED = "proposed"
    DECOMPOSED = "decomposed"
    READY = "ready"
    SEARCHING = "searching"
    LOCALLY_VALIDATED = "locally_validated"
    INTEGRATION_PENDING = "integration_pending"
    INTEGRATION_FAILED = "integration_failed"
    INTEGRATED = "integrated"
    PLATEAUED = "plateaued"
    BLOCKED = "blocked"
    INVALIDATED = "invalidated"
    SUPERSEDED = "superseded"


class CompositionOperator(str, Enum):
    ALL = "all"
    ANY = "any"
    AT_LEAST = "at_least"
    PARETO = "pareto"


class DependencyKind(str, Enum):
    REQUIRES = "requires"
    INVALIDATES = "invalidates"
    SUPPORTS = "supports"


@dataclass(frozen=True)
class ExecutableLeafContract:
    """The stopping rule for goal decomposition.

    A leaf is not merely small. It must be executable, falsifiable, and
    causally connected to a decision at its immediate parent.
    """

    hypothesis: str
    parent_decision: str
    root_metric_link: str
    metric: MetricSpec
    success_conditions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    testbed_ref: str
    parent_integration_test: str
    experiment_budget: float
    preregistration_ref: str

    def __post_init__(self) -> None:
        required = (
            self.hypothesis,
            self.parent_decision,
            self.root_metric_link,
            self.testbed_ref,
            self.parent_integration_test,
            self.preregistration_ref,
        )
        if not all(required):
            raise ValueError("executable-leaf fields must not be empty")
        if not self.success_conditions or not self.falsification_conditions:
            raise ValueError(
                "an executable leaf requires success and falsification rules"
            )
        if self.experiment_budget <= 0:
            raise ValueError("leaf experiment budget must be positive")

    @property
    def contract_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "hypothesis": self.hypothesis,
            "parent_decision": self.parent_decision,
            "root_metric_link": self.root_metric_link,
            "metric": self.metric.as_dict(),
            "success_conditions": list(self.success_conditions),
            "falsification_conditions": list(
                self.falsification_conditions
            ),
            "testbed_ref": self.testbed_ref,
            "parent_integration_test": self.parent_integration_test,
            "experiment_budget": self.experiment_budget,
            "preregistration_ref": self.preregistration_ref,
        }
        if include_id:
            value["contract_id"] = self.contract_id
        return value


@dataclass(frozen=True)
class GoalNodeSpec:
    goal_id: str
    title: str
    question: str
    kind: GoalNodeKind
    rationale: str
    success_conditions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    expected_artifact: str
    critical: bool = False
    leaf_contract: Optional[ExecutableLeafContract] = None
    tags: Tuple[str, ...] = ()
    # Optional for checkpoint compatibility. Historical v2 nodes infer their
    # role from kind/tags; objective-first graphs freeze it explicitly.
    role: Optional[GoalNodeRole] = None

    def __post_init__(self) -> None:
        required = (
            self.goal_id,
            self.title,
            self.question,
            self.rationale,
            self.expected_artifact,
        )
        if not all(required):
            raise ValueError("goal-node fields must not be empty")
        if not self.success_conditions or not self.falsification_conditions:
            raise ValueError(
                "goal nodes require success and falsification conditions"
            )
        if self.kind == GoalNodeKind.ROOT and self.leaf_contract is not None:
            raise ValueError("the root must be decomposed, not run as a leaf")
        if (
            self.kind == GoalNodeKind.EXECUTABLE_LEAF
            and self.leaf_contract is None
        ):
            raise ValueError(
                "executable-leaf nodes require a leaf contract"
            )
        if (
            self.kind != GoalNodeKind.EXECUTABLE_LEAF
            and self.leaf_contract is not None
        ):
            raise ValueError(
                "only executable-leaf nodes may carry a leaf contract"
            )
        if len(set(self.tags)) != len(self.tags):
            raise ValueError("goal-node tags must be unique")

    @property
    def node_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def effective_role(self) -> GoalNodeRole:
        if self.role is not None:
            return self.role
        evidence_tags = {
            "diagnostic",
            "diagnosis",
            "measurement",
            "qualification",
            "validation",
            "terminal",
            "horizon-transport",
            "horizon-transport-map",
            "representation-adequacy",
            "latent-concept",
            "generator-revision",
            "causal-models",
            "causal-model-selection",
            "causal-intervention",
        }
        if evidence_tags.intersection(self.tags):
            return GoalNodeRole.EVIDENCE
        if self.kind == GoalNodeKind.ENGINEERING_ENABLER:
            return GoalNodeRole.EVIDENCE
        return GoalNodeRole.OBJECTIVE

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "goal_id": self.goal_id,
            "title": self.title,
            "question": self.question,
            "kind": self.kind.value,
            "rationale": self.rationale,
            "success_conditions": list(self.success_conditions),
            "falsification_conditions": list(
                self.falsification_conditions
            ),
            "expected_artifact": self.expected_artifact,
            "critical": self.critical,
            "leaf_contract": (
                None
                if self.leaf_contract is None
                else self.leaf_contract.as_dict()
            ),
            "tags": list(self.tags),
        }
        # Omitting an unset role preserves every historical node identity.
        if self.role is not None:
            value["role"] = self.role.value
        if include_id:
            value["node_id"] = self.node_id
        return value


@dataclass(frozen=True)
class ParentCompositionRule:
    parent_id: str
    child_ids: Tuple[str, ...]
    operator: CompositionOperator
    integration_test: str
    rationale: str
    decomposer_ref: str
    threshold: Optional[int] = None
    supersedes_rule_id: Optional[str] = None

    def __post_init__(self) -> None:
        if not all(
            (
                self.parent_id,
                self.integration_test,
                self.rationale,
                self.decomposer_ref,
            )
        ):
            raise ValueError("composition-rule fields must not be empty")
        if not self.child_ids:
            raise ValueError("composition rules require children")
        if len(set(self.child_ids)) != len(self.child_ids):
            raise ValueError("composition children must be unique")
        if self.parent_id in self.child_ids:
            raise ValueError("a node cannot decompose into itself")
        if self.operator in (
            CompositionOperator.ALL,
            CompositionOperator.ANY,
        ):
            if self.threshold is not None:
                raise ValueError(
                    "all/any composition must not define a threshold"
                )
        else:
            if self.threshold is None or self.threshold <= 0:
                raise ValueError(
                    "at-least/pareto composition requires a threshold"
                )
            if self.threshold > len(self.child_ids):
                raise ValueError(
                    "composition threshold exceeds child count"
                )

    @property
    def required_child_count(self) -> int:
        if self.operator == CompositionOperator.ALL:
            return len(self.child_ids)
        if self.operator == CompositionOperator.ANY:
            return 1
        assert self.threshold is not None
        return self.threshold

    @property
    def rule_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "parent_id": self.parent_id,
            "child_ids": list(self.child_ids),
            "operator": self.operator.value,
            "threshold": self.threshold,
            "required_child_count": self.required_child_count,
            "integration_test": self.integration_test,
            "rationale": self.rationale,
            "decomposer_ref": self.decomposer_ref,
            "supersedes_rule_id": self.supersedes_rule_id,
        }
        if include_id:
            value["rule_id"] = self.rule_id
        return value


@dataclass(frozen=True)
class DependencyEdge:
    source_id: str
    target_id: str
    kind: DependencyKind
    rationale: str
    evidence_ids: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.source_id or not self.target_id or not self.rationale:
            raise ValueError("dependency-edge fields must not be empty")
        if self.source_id == self.target_id:
            raise ValueError("a dependency edge cannot be self-referential")
        if self.kind == DependencyKind.INVALIDATES and not self.evidence_ids:
            raise ValueError("invalidation edges require evidence")

    @property
    def edge_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "kind": self.kind.value,
            "rationale": self.rationale,
            "evidence_ids": list(self.evidence_ids),
        }
        if include_id:
            value["edge_id"] = self.edge_id
        return value


@dataclass(frozen=True)
class GoalGraphDecompositionProposal:
    parent_id: str
    nodes: Tuple[GoalNodeSpec, ...]
    rule: ParentCompositionRule
    assumptions: Tuple[str, ...]
    distinguishing_predictions: Tuple[str, ...]
    reasoning: str

    def __post_init__(self) -> None:
        if not self.parent_id or not self.reasoning:
            raise ValueError("decomposition proposal identity is required")
        if self.rule.parent_id != self.parent_id:
            raise ValueError(
                "decomposition proposal and rule have different parents"
            )
        if not self.assumptions or not self.distinguishing_predictions:
            raise ValueError(
                "decomposition requires assumptions and predictions"
            )
        proposed_ids = {node.node_id for node in self.nodes}
        if not proposed_ids.issubset(set(self.rule.child_ids)):
            raise ValueError(
                "new decomposition nodes must be active children"
            )

    @property
    def proposal_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "parent_id": self.parent_id,
            "nodes": [node.as_dict() for node in self.nodes],
            "rule": self.rule.as_dict(),
            "assumptions": list(self.assumptions),
            "distinguishing_predictions": list(
                self.distinguishing_predictions
            ),
            "reasoning": self.reasoning,
        }
        if include_id:
            value["proposal_id"] = self.proposal_id
        return value


_ALLOWED_TRANSITIONS = {
    GoalNodeStatus.PROPOSED: {
        GoalNodeStatus.DECOMPOSED,
        GoalNodeStatus.READY,
        GoalNodeStatus.BLOCKED,
        GoalNodeStatus.INVALIDATED,
        GoalNodeStatus.SUPERSEDED,
    },
    GoalNodeStatus.DECOMPOSED: {
        GoalNodeStatus.INTEGRATION_PENDING,
        GoalNodeStatus.BLOCKED,
        GoalNodeStatus.INVALIDATED,
        GoalNodeStatus.SUPERSEDED,
    },
    GoalNodeStatus.READY: {
        GoalNodeStatus.SEARCHING,
        GoalNodeStatus.LOCALLY_VALIDATED,
        GoalNodeStatus.DECOMPOSED,
        GoalNodeStatus.BLOCKED,
        GoalNodeStatus.INVALIDATED,
        GoalNodeStatus.SUPERSEDED,
    },
    GoalNodeStatus.SEARCHING: {
        GoalNodeStatus.LOCALLY_VALIDATED,
        GoalNodeStatus.PLATEAUED,
        GoalNodeStatus.BLOCKED,
        GoalNodeStatus.INVALIDATED,
    },
    GoalNodeStatus.LOCALLY_VALIDATED: {
        GoalNodeStatus.INTEGRATED,
        GoalNodeStatus.INTEGRATION_FAILED,
        GoalNodeStatus.BLOCKED,
        GoalNodeStatus.INVALIDATED,
    },
    GoalNodeStatus.INTEGRATION_PENDING: {
        GoalNodeStatus.INTEGRATED,
        GoalNodeStatus.INTEGRATION_FAILED,
        GoalNodeStatus.BLOCKED,
        GoalNodeStatus.INVALIDATED,
    },
    GoalNodeStatus.INTEGRATION_FAILED: {
        GoalNodeStatus.READY,
        GoalNodeStatus.SEARCHING,
        GoalNodeStatus.DECOMPOSED,
        GoalNodeStatus.PLATEAUED,
        GoalNodeStatus.BLOCKED,
        GoalNodeStatus.INVALIDATED,
        GoalNodeStatus.SUPERSEDED,
    },
    GoalNodeStatus.INTEGRATED: {
        GoalNodeStatus.INVALIDATED,
        GoalNodeStatus.SUPERSEDED,
    },
    GoalNodeStatus.PLATEAUED: {
        GoalNodeStatus.READY,
        GoalNodeStatus.DECOMPOSED,
        GoalNodeStatus.INVALIDATED,
        GoalNodeStatus.SUPERSEDED,
    },
    GoalNodeStatus.BLOCKED: {
        GoalNodeStatus.READY,
        GoalNodeStatus.DECOMPOSED,
        GoalNodeStatus.INVALIDATED,
        GoalNodeStatus.SUPERSEDED,
    },
    GoalNodeStatus.INVALIDATED: {GoalNodeStatus.SUPERSEDED},
    GoalNodeStatus.SUPERSEDED: set(),
}


class DynamicGoalGraph:
    """A revisable AND/OR DAG above domain-specific experiment search."""

    def __init__(self, goal_id: str, root: GoalNodeSpec) -> None:
        if not goal_id:
            raise ValueError("goal_id must not be empty")
        if root.goal_id != goal_id:
            raise ValueError("root belongs to another goal")
        if root.kind != GoalNodeKind.ROOT:
            raise ValueError("dynamic goal graphs require a root node")
        self.goal_id = goal_id
        self.root_id = root.node_id
        self._nodes: Dict[str, GoalNodeSpec] = {root.node_id: root}
        self._statuses: Dict[str, GoalNodeStatus] = {
            root.node_id: GoalNodeStatus.PROPOSED
        }
        self._rules: Dict[str, ParentCompositionRule] = {}
        self._active_rule_ids: Dict[str, str] = {}
        self._dependencies: Dict[str, DependencyEdge] = {}
        self._integrated_parent_edges: set[Tuple[str, str]] = set()

    @property
    def nodes(self) -> Mapping[str, GoalNodeSpec]:
        return dict(self._nodes)

    @property
    def statuses(self) -> Mapping[str, GoalNodeStatus]:
        return dict(self._statuses)

    @property
    def rules(self) -> Mapping[str, ParentCompositionRule]:
        return dict(self._rules)

    @property
    def dependencies(self) -> Mapping[str, DependencyEdge]:
        return dict(self._dependencies)

    def status(self, node_id: str) -> GoalNodeStatus:
        try:
            return self._statuses[node_id]
        except KeyError:
            raise KeyError("unknown goal node: %s" % node_id)

    def active_rule(
        self,
        parent_id: str,
    ) -> Optional[ParentCompositionRule]:
        rule_id = self._active_rule_ids.get(parent_id)
        return None if rule_id is None else self._rules[rule_id]

    def add_nodes(self, nodes: Iterable[GoalNodeSpec]) -> None:
        additions = tuple(nodes)
        if not additions:
            raise ValueError("at least one goal node is required")
        by_id = {node.node_id: node for node in additions}
        if len(by_id) != len(additions):
            raise ValueError("duplicate nodes in graph addition")
        if set(by_id).intersection(self._nodes):
            raise ValueError("one or more goal nodes already exist")
        if any(node.goal_id != self.goal_id for node in additions):
            raise ValueError("goal node belongs to another goal")
        if any(node.kind == GoalNodeKind.ROOT for node in additions):
            raise ValueError("a goal graph may have only one root")
        self._nodes.update(by_id)
        self._statuses.update(
            {node_id: GoalNodeStatus.PROPOSED for node_id in by_id}
        )
        self._refresh()

    def add_dependency(self, edge: DependencyEdge) -> None:
        if edge.edge_id in self._dependencies:
            raise ValueError("dependency edge is already registered")
        if (
            edge.source_id not in self._nodes
            or edge.target_id not in self._nodes
        ):
            raise ValueError("dependency edge references an unknown node")
        if edge.kind == DependencyKind.SUPPORTS:
            source = self._nodes[edge.source_id]
            target = self._nodes[edge.target_id]
            if source.effective_role != GoalNodeRole.EVIDENCE:
                raise ValueError("support edges must originate at evidence nodes")
            if target.effective_role != GoalNodeRole.OBJECTIVE:
                raise ValueError("support edges must terminate at objective nodes")
        candidate = dict(self._dependencies)
        candidate[edge.edge_id] = edge
        self._assert_acyclic(
            self._nodes,
            self._rules,
            self._active_rule_ids,
            candidate,
        )
        self._dependencies[edge.edge_id] = edge
        if edge.kind == DependencyKind.INVALIDATES:
            self._statuses[edge.target_id] = GoalNodeStatus.INVALIDATED
        self._refresh()

    def set_composition_rule(
        self,
        rule: ParentCompositionRule,
    ) -> None:
        if rule.parent_id not in self._nodes:
            raise ValueError("composition parent is unknown")
        missing = set(rule.child_ids).difference(self._nodes)
        if missing:
            raise ValueError(
                "composition references missing children: %s"
                % ", ".join(sorted(missing))
            )
        parent = self._nodes[rule.parent_id]
        if parent.role == GoalNodeRole.OBJECTIVE:
            evidence_children = tuple(
                child_id
                for child_id in rule.child_ids
                if self._nodes[child_id].effective_role
                == GoalNodeRole.EVIDENCE
            )
            if evidence_children:
                raise ValueError(
                    "objective composition cannot count evidence nodes as "
                    "objective progress"
                )
        if parent.role == GoalNodeRole.EVIDENCE:
            non_evidence_children = tuple(
                child_id
                for child_id in rule.child_ids
                if self._nodes[child_id].effective_role
                != GoalNodeRole.EVIDENCE
            )
            if non_evidence_children:
                raise ValueError(
                    "evidence composition cannot contain objective nodes"
                )
            if self.evidence_depth(parent.node_id) >= DEFAULT_MAX_EVIDENCE_DEPTH:
                raise ValueError(
                    "evidence decomposition exceeds the maximum meta depth"
                )
        current_id = self._active_rule_ids.get(rule.parent_id)
        if current_id is None and rule.supersedes_rule_id is not None:
            raise ValueError("initial composition cannot supersede a rule")
        if current_id is not None:
            if rule.supersedes_rule_id != current_id:
                raise ValueError(
                    "composition revision must supersede the active rule"
                )
            if self._statuses[rule.parent_id] == GoalNodeStatus.INTEGRATED:
                raise ValueError(
                    "integrated nodes must be invalidated before revision"
                )
        candidate_rules = dict(self._rules)
        candidate_rules[rule.rule_id] = rule
        candidate_active = dict(self._active_rule_ids)
        candidate_active[rule.parent_id] = rule.rule_id
        self._assert_acyclic(
            self._nodes,
            candidate_rules,
            candidate_active,
            self._dependencies,
        )
        self._rules[rule.rule_id] = rule
        self._active_rule_ids[rule.parent_id] = rule.rule_id
        self._integrated_parent_edges = {
            edge
            for edge in self._integrated_parent_edges
            if edge[0] != rule.parent_id
        }
        self._statuses[rule.parent_id] = GoalNodeStatus.DECOMPOSED
        self._refresh()

    @staticmethod
    def _assert_acyclic(
        nodes: Mapping[str, GoalNodeSpec],
        rules: Mapping[str, ParentCompositionRule],
        active_rule_ids: Mapping[str, str],
        dependencies: Mapping[str, DependencyEdge],
    ) -> None:
        adjacency = {node_id: set() for node_id in nodes}
        for parent_id, rule_id in active_rule_ids.items():
            adjacency[parent_id].update(rules[rule_id].child_ids)
        for edge in dependencies.values():
            if edge.kind == DependencyKind.REQUIRES:
                adjacency[edge.source_id].add(edge.target_id)

        visiting = set()
        visited = set()

        def visit(node_id: str) -> None:
            if node_id in visiting:
                raise ValueError("goal graph must remain acyclic")
            if node_id in visited:
                return
            visiting.add(node_id)
            for adjacent in adjacency[node_id]:
                visit(adjacent)
            visiting.remove(node_id)
            visited.add(node_id)

        for node_id in nodes:
            visit(node_id)

    def _requirements_met(self, node_id: str) -> bool:
        prerequisites = tuple(
            edge.target_id
            for edge in self._dependencies.values()
            if edge.kind == DependencyKind.REQUIRES
            and edge.source_id == node_id
        )
        return all(
            self._statuses[prerequisite] == GoalNodeStatus.INTEGRATED
            for prerequisite in prerequisites
        )

    def requirements_met(self, node_id: str) -> bool:
        if node_id not in self._nodes:
            raise KeyError("unknown goal node: %s" % node_id)
        return self._requirements_met(node_id)

    def composition_satisfied(self, parent_id: str) -> bool:
        rule = self.active_rule(parent_id)
        if rule is None:
            return False
        integrated = sum(
            (parent_id, child_id) in self._integrated_parent_edges
            for child_id in rule.child_ids
        )
        return integrated >= rule.required_child_count

    def mark_parent_integration(
        self,
        child_id: str,
        parent_id: str,
        passed: bool,
    ) -> None:
        """Record an edge-specific causal integration result.

        A shared child must pass independently at every active parent. A
        global child status therefore cannot silently satisfy all parents.
        """

        if child_id not in self._nodes or parent_id not in self._nodes:
            raise ValueError("parent integration references an unknown node")
        rule = self.active_rule(parent_id)
        if rule is None or child_id not in rule.child_ids:
            raise ValueError(
                "parent integration is not an active decomposition edge"
            )
        status = self._statuses[child_id]
        if status not in (
            GoalNodeStatus.LOCALLY_VALIDATED,
            GoalNodeStatus.INTEGRATION_PENDING,
            GoalNodeStatus.INTEGRATION_FAILED,
            GoalNodeStatus.INTEGRATED,
        ):
            raise ValueError(
                "node has not reached a parent-integration boundary"
            )
        edge = (parent_id, child_id)
        if passed:
            self._integrated_parent_edges.add(edge)
            parents = self.parents_of(child_id)
            if parents and all(
                (parent, child_id) in self._integrated_parent_edges
                for parent in parents
            ):
                self._statuses[child_id] = GoalNodeStatus.INTEGRATED
            elif status != GoalNodeStatus.INTEGRATED:
                self._statuses[child_id] = GoalNodeStatus.LOCALLY_VALIDATED
        else:
            self._integrated_parent_edges.discard(edge)
            self._statuses[child_id] = GoalNodeStatus.INTEGRATION_FAILED
        self._refresh()

    def parents_of(self, node_id: str) -> Tuple[str, ...]:
        if node_id not in self._nodes:
            raise KeyError("unknown goal node: %s" % node_id)
        return tuple(
            sorted(
                parent_id
                for parent_id, rule_id in self._active_rule_ids.items()
                if node_id in self._rules[rule_id].child_ids
            )
        )

    def children_of(self, node_id: str) -> Tuple[str, ...]:
        rule = self.active_rule(node_id)
        return () if rule is None else rule.child_ids

    def evidence_for_objective(self, node_id: str) -> Tuple[GoalNodeSpec, ...]:
        if node_id not in self._nodes:
            raise KeyError("unknown goal node: %s" % node_id)
        if self._nodes[node_id].effective_role != GoalNodeRole.OBJECTIVE:
            raise ValueError("evidence can only attach to objective nodes")
        return tuple(
            self._nodes[edge.source_id]
            for _, edge in sorted(self._dependencies.items())
            if edge.kind == DependencyKind.SUPPORTS
            and edge.target_id == node_id
        )

    def supported_objectives(self, node_id: str) -> Tuple[GoalNodeSpec, ...]:
        if node_id not in self._nodes:
            raise KeyError("unknown goal node: %s" % node_id)
        return tuple(
            self._nodes[edge.target_id]
            for _, edge in sorted(self._dependencies.items())
            if edge.kind == DependencyKind.SUPPORTS
            and edge.source_id == node_id
        )

    @property
    def has_explicit_role_separation(self) -> bool:
        return any(node.role is not None for node in self._nodes.values())

    def evidence_depth(self, node_id: str) -> int:
        """Return the deepest active evidence ancestry, counting this node."""

        if node_id not in self._nodes:
            raise KeyError("unknown goal node: %s" % node_id)
        if self._nodes[node_id].effective_role != GoalNodeRole.EVIDENCE:
            raise ValueError("evidence depth is defined only for evidence nodes")

        memo: Dict[str, int] = {}

        def depth(current_id: str) -> int:
            cached = memo.get(current_id)
            if cached is not None:
                return cached
            evidence_parents = tuple(
                parent_id
                for parent_id in self.parents_of(current_id)
                if self._nodes[parent_id].effective_role
                == GoalNodeRole.EVIDENCE
            )
            value = (
                1
                if not evidence_parents
                else 1 + max(depth(parent_id) for parent_id in evidence_parents)
            )
            memo[current_id] = value
            return value

        return depth(node_id)

    def objective_distance(self, node_id: str) -> int:
        """Shortest declared route from a node to the root objective.

        Evidence is measured through its SUPPORTS attachment, so an unattached
        meta experiment is never treated as direct root progress.
        """

        if node_id not in self._nodes:
            raise KeyError("unknown goal node: %s" % node_id)
        node = self._nodes[node_id]
        frontier = (
            (node_id,)
            if node.effective_role == GoalNodeRole.OBJECTIVE
            else tuple(item.node_id for item in self.supported_objectives(node_id))
        )
        if not frontier:
            return len(self._nodes) + 1
        distance = 1 if node.effective_role == GoalNodeRole.EVIDENCE else 0
        seen = set(frontier)
        while frontier:
            if self.root_id in frontier:
                return distance
            parents = tuple(
                parent
                for child in frontier
                for parent in self.parents_of(child)
                if parent not in seen
            )
            seen.update(parents)
            frontier = parents
            distance += 1
        return len(self._nodes) + 1

    def progress_by_role(self) -> Mapping[str, Mapping[str, float | int]]:
        active = {
            GoalNodeRole.OBJECTIVE: [],
            GoalNodeRole.EVIDENCE: [],
        }
        for node_id, node in self._nodes.items():
            if node_id == self.root_id or self._statuses[node_id] in (
                GoalNodeStatus.INVALIDATED,
                GoalNodeStatus.SUPERSEDED,
            ):
                continue
            active[node.effective_role].append(node_id)
        result: Dict[str, Mapping[str, float | int]] = {}
        for role, node_ids in active.items():
            integrated = sum(
                self._statuses[node_id] == GoalNodeStatus.INTEGRATED
                for node_id in node_ids
            )
            total = len(node_ids)
            result[role.value] = {
                "integrated": integrated,
                "total": total,
                "fraction": 0.0 if not total else integrated / float(total),
            }
        return result

    def parent_edge_integrated(
        self,
        child_id: str,
        parent_id: str,
    ) -> bool:
        if child_id not in self._nodes or parent_id not in self._nodes:
            raise KeyError("parent integration references an unknown node")
        return (parent_id, child_id) in self._integrated_parent_edges

    def _refresh(self) -> None:
        changed = True
        while changed:
            changed = False
            for node_id, node in self._nodes.items():
                status = self._statuses[node_id]
                if status in (
                    GoalNodeStatus.INVALIDATED,
                    GoalNodeStatus.SUPERSEDED,
                    GoalNodeStatus.INTEGRATED,
                    GoalNodeStatus.SEARCHING,
                    GoalNodeStatus.LOCALLY_VALIDATED,
                    GoalNodeStatus.INTEGRATION_FAILED,
                    GoalNodeStatus.PLATEAUED,
                ):
                    continue
                rule = self.active_rule(node_id)
                if rule is not None:
                    desired = (
                        GoalNodeStatus.INTEGRATION_PENDING
                        if self.composition_satisfied(node_id)
                        else GoalNodeStatus.DECOMPOSED
                    )
                elif node.kind == GoalNodeKind.EXECUTABLE_LEAF:
                    desired = (
                        GoalNodeStatus.READY
                        if self._requirements_met(node_id)
                        else GoalNodeStatus.PROPOSED
                    )
                else:
                    desired = status
                if desired != status:
                    self._statuses[node_id] = desired
                    changed = True

    def transition(
        self,
        node_id: str,
        new_status: GoalNodeStatus,
    ) -> None:
        old_status = self.status(node_id)
        if new_status not in _ALLOWED_TRANSITIONS[old_status]:
            raise ValueError(
                "illegal goal-node transition: %s -> %s"
                % (old_status.value, new_status.value)
            )
        if new_status == GoalNodeStatus.READY:
            if self.active_rule(node_id) is not None:
                raise ValueError(
                    "a decomposed node cannot become an executable leaf"
                )
            if (
                self._nodes[node_id].kind
                != GoalNodeKind.EXECUTABLE_LEAF
            ):
                raise ValueError("only executable leaves may become ready")
            if not self._requirements_met(node_id):
                raise ValueError("leaf prerequisites are not integrated")
        if new_status == GoalNodeStatus.INTEGRATION_PENDING:
            if not self.composition_satisfied(node_id):
                raise ValueError(
                    "parent integration requires satisfied composition"
                )
        self._statuses[node_id] = new_status
        self._refresh()

    def reopen(self, node_id: str) -> None:
        status = self.status(node_id)
        if status not in (
            GoalNodeStatus.PLATEAUED,
            GoalNodeStatus.BLOCKED,
            GoalNodeStatus.INTEGRATION_FAILED,
        ):
            raise ValueError(
                "only plateaued, blocked, or integration-failed nodes reopen"
            )
        target = (
            GoalNodeStatus.DECOMPOSED
            if self.active_rule(node_id) is not None
            else GoalNodeStatus.READY
        )
        self.transition(node_id, target)

    def ready_leaves(self) -> Tuple[GoalNodeSpec, ...]:
        return tuple(
            self._nodes[node_id]
            for node_id in sorted(self._nodes)
            if self._statuses[node_id] == GoalNodeStatus.READY
        )

    def integration_frontier(self) -> Tuple[GoalNodeSpec, ...]:
        return tuple(
            self._nodes[node_id]
            for node_id in sorted(self._nodes)
            if self._statuses[node_id]
            in (
                GoalNodeStatus.LOCALLY_VALIDATED,
                GoalNodeStatus.INTEGRATION_PENDING,
            )
        )

    def unresolved_critical_node_ids(self) -> Tuple[str, ...]:
        # The root is resolved by the terminal public-claim gate itself. If a
        # critical root were included here, that gate would require the root
        # to be integrated before it could integrate the root: a circular
        # condition. Critical descendants remain mandatory.
        return tuple(
            node_id
            for node_id, node in sorted(self._nodes.items())
            if node_id != self.root_id
            and node.critical
            and self._statuses[node_id] != GoalNodeStatus.INTEGRATED
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "architecture_version": GOAL_GRAPH_ARCHITECTURE_VERSION,
            "goal_id": self.goal_id,
            "root_id": self.root_id,
            "nodes": [
                {
                    "specification": node.as_dict(),
                    "status": self._statuses[node_id].value,
                }
                for node_id, node in sorted(self._nodes.items())
            ],
            "active_rules": [
                self._rules[rule_id].as_dict()
                for _, rule_id in sorted(self._active_rule_ids.items())
            ],
            "rule_history": [
                rule.as_dict()
                for _, rule in sorted(self._rules.items())
            ],
            "dependencies": [
                edge.as_dict()
                for _, edge in sorted(self._dependencies.items())
            ],
            "integrated_parent_edges": [
                {"parent_id": parent_id, "child_id": child_id}
                for parent_id, child_id in sorted(
                    self._integrated_parent_edges
                )
            ],
            "ready_leaf_ids": [
                node.node_id for node in self.ready_leaves()
            ],
            "integration_frontier_ids": [
                node.node_id for node in self.integration_frontier()
            ],
            "unresolved_critical_node_ids": list(
                self.unresolved_critical_node_ids()
            ),
        }
