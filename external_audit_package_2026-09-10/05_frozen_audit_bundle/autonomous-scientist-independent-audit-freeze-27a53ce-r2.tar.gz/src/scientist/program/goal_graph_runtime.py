from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, canonical_json, content_digest
from scientist.kernel.contracts import EvidencePartition
from scientist.kernel.evidence import MeasurementRecord, analyze_measurements
from scientist.kernel.gates import GateDecision, evaluate_gate
from scientist.program.campaigns import TestExposureRecord, VerificationRecord
from scientist.program.control_plane import AutonomousScientistControlPlane
from scientist.program.discovery_evidence import paired_episode_evidence


GOAL_GRAPH_RUNTIME_VERSION = "goal-graph-runtime-v2-episode-confidence"


class GoalGraphRuntime:
    """Durable transaction boundary for the v2 scientific control plane."""

    _MUTATIONS = {
        "register_literature_assessment",
        "register_causal_failure_models",
        "register_cross_domain_inspiration",
        "add_decomposition",
        "revise_decomposition",
        "solicit_decomposition",
        "add_dependency",
        "assess_nodes",
        "schedule_frontier",
        "register_incumbent_portfolio",
        "start_campaign",
        "register_research_program",
        "record_research_program_diagnosis",
        "adopt_representation_change",
        "register_evaluation_horizon",
        "record_horizon_prediction",
        "record_horizon_outcome",
        "register_horizon_contrast",
        "register_horizon_failure_dossier",
        "register_representation_adequacy_assessment",
        "register_latent_concept",
        "record_autonomous_invention_milestone",
        "record_latent_object_milestone",
        "record_self_supervised_object_milestone",
        "record_behavioral_predicate_milestone",
        "record_schema_induction_milestone",
        "record_cognitive_core_v1_milestone",
        "record_concept_validation",
        "register_generator_revision",
        "adopt_concept_grounded_representation_change",
        "park_research_program",
        "submit_candidate",
        "record_leaf_qualification",
        "record_leaf_diagnostic",
        "record_test_exposure",
        "record_verification",
        "nominate_local_candidate",
        "complete_campaign_round",
        "record_parent_integration",
        "reopen_node",
        "evaluate_root",
        "issue_unresolved_certificate",
    }

    def __init__(
        self,
        control_plane: AutonomousScientistControlPlane,
        checkpoint_path: Path,
        *,
        artifact_store: Optional[ArtifactStore] = None,
        save_on_init: bool = True,
    ) -> None:
        self.control_plane = control_plane
        self.checkpoint_path = Path(checkpoint_path)
        self.artifact_store = artifact_store
        if artifact_store is not None:
            memory = self.control_plane.memory
            if memory._artifact_digests and (
                len(memory._artifact_digests) != len(memory.events)
            ):
                raise ValueError(
                    "scientific memory has partial artifact persistence"
                )
            if not memory._artifact_digests:
                memory._artifact_digests = tuple(
                    artifact_store.put(
                        "goal_graph_scientific_memory_event",
                        event.as_dict(),
                    )
                    for event in memory.events
                )
            memory._artifact_store = artifact_store
        if save_on_init:
            self.save_checkpoint()

    def _checkpoint_value(self) -> Dict[str, Any]:
        value = {
            "runtime_version": GOAL_GRAPH_RUNTIME_VERSION,
            "control_plane": self.control_plane.as_dict(),
        }
        value["checkpoint_id"] = content_digest(value)
        return value

    def save_checkpoint(self) -> Path:
        destination = self.checkpoint_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        payload = canonical_json(self._checkpoint_value()) + b"\n"
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=destination.name + ".",
            suffix=".tmp",
            dir=str(destination.parent),
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, destination)
        finally:
            temporary_path = Path(temporary_name)
            if temporary_path.exists():
                temporary_path.unlink()
        return destination

    def transact(self, method_name: str, *args, **kwargs):
        if method_name not in self._MUTATIONS:
            raise ValueError("unsupported control-plane transaction")
        method = getattr(self.control_plane, method_name)
        result = method(*args, **kwargs)
        self.save_checkpoint()
        return result

    def evaluate_and_record_batch(
        self,
        *,
        adapter: Any,
        node_id: str,
        candidate_id: str,
        candidate: Any,
        incumbent: Any,
        experiments: Sequence[Any],
        partition: EvidencePartition,
        gate_contract_id: str,
    ) -> Tuple[VerificationRecord, GateDecision]:
        """Run the declared adapter and persist independently verified evidence."""

        if self.artifact_store is None:
            raise ValueError(
                "adapter-backed verification requires an artifact store"
            )
        campaign_id = self.control_plane.active_campaign_ids.get(node_id)
        if campaign_id is None:
            raise ValueError("goal node has no active campaign")
        campaign = self.control_plane.campaigns[campaign_id]
        proposal = campaign.proposals.get(candidate_id)
        if proposal is None:
            raise ValueError("candidate is not registered in the campaign")
        if adapter.evaluator_ref != campaign.contract.evaluator_ref:
            raise ValueError("adapter evaluator differs from campaign contract")
        if adapter.verifier_ref != campaign.contract.verifier_ref:
            raise ValueError("adapter verifier differs from campaign contract")
        gate = next(
            (
                item
                for item in campaign.contract.gates
                if item.contract_id == gate_contract_id
            ),
            None,
        )
        if gate is None:
            raise ValueError("verification gate is not in the campaign contract")
        if gate.evidence_partition != partition:
            raise ValueError("verification partition differs from its gate")
        experiments = tuple(experiments)
        if not experiments:
            raise ValueError("adapter verification requires experiments")
        experiment_ids = tuple(
            adapter.experiment_id(experiment) for experiment in experiments
        )
        if len(set(experiment_ids)) != len(experiment_ids):
            raise ValueError("verification experiments must have unique identities")

        candidate_artifact = self.artifact_store.put(
            "domain_candidate",
            dict(adapter.candidate_as_dict(candidate)),
        )
        if candidate_artifact != proposal.executable_digest:
            raise ValueError(
                "proposal executable digest does not match adapter candidate"
            )
        experiment_artifact = self.artifact_store.put(
            "domain_experiment_batch",
            [
                dict(adapter.experiment_as_dict(experiment))
                for experiment in experiments
            ],
        )
        observation_artifacts = []
        verification_artifacts = []
        comparisons = []
        measurements = []
        for experiment in experiments:
            observation = adapter.evaluate(candidate, experiment)
            verification = adapter.verify(experiment, observation)
            if verification.verifier_ref != adapter.verifier_ref:
                raise ValueError("adapter returned another verifier authority")
            if not verification.passed:
                raise ValueError(
                    "independent adapter verification rejected an observation"
                )
            comparison = adapter.compare(candidate, incumbent, experiment)
            if comparison.experiment_id != adapter.experiment_id(experiment):
                raise ValueError("adapter comparison references another experiment")
            if comparison.candidate_id != adapter.candidate_id(candidate):
                raise ValueError("adapter comparison references another candidate")
            if comparison.incumbent_id != adapter.candidate_id(incumbent):
                raise ValueError("adapter comparison references another incumbent")
            observation_artifacts.append(
                self.artifact_store.put(
                    "domain_observation",
                    dict(adapter.observation_as_dict(observation)),
                )
            )
            verification_artifacts.append(
                self.artifact_store.put(
                    "domain_observation_verification",
                    verification.as_dict(),
                )
            )
            comparisons.append(comparison)
            measurements.append(
                MeasurementRecord(
                    domain_id=str(
                        getattr(adapter, "domain_id", "legacy_domain")
                    ),
                    subject_id=adapter.candidate_id(candidate),
                    control_ids=(adapter.candidate_id(incumbent),),
                    experiment_id=adapter.experiment_id(experiment),
                    partition=partition,
                    observation=dict(adapter.observation_as_dict(observation)),
                    verification=verification,
                    metrics={
                        name: float(value)
                        for name, value in comparison.metrics.items()
                    },
                    evaluator_ref=adapter.evaluator_ref,
                    verifier_ref=adapter.verifier_ref,
                )
            )

        metric_names = {
            name
            for comparison in comparisons
            for name in comparison.metrics
        }
        metrics = {
            name: sum(
                float(comparison.metrics.get(name, 0.0))
                for comparison in comparisons
            )
            for name in metric_names
        }
        analysis_contract = getattr(
            campaign.contract,
            "evidence_analysis",
            None,
        )
        improvements = tuple(
            float(comparison.metrics["improvement"])
            for comparison in comparisons
        )
        if analysis_contract is not None:
            evidence_summary = analyze_measurements(
                adapter,
                measurements,
                analysis_contract,
            )
            metrics.update(evidence_summary.metrics)
            primary = analysis_contract.primary_metric
            metrics["effect_size"] = metrics.get(
                "mean_%s" % primary,
                metrics.get(primary, 0.0),
            )
            metrics["mean_improvement_ci_lower"] = metrics.get(
                "mean_%s_ci_lower" % primary,
                metrics["effect_size"],
            )
        else:
            evidence_summary = None
        episode_evidence = (
            paired_episode_evidence(improvements, experiment_ids)
            if analysis_contract is None and len(improvements) >= 2
            else None
        )
        if analysis_contract is None:
            metrics.update(
                {
                "effect_size": (
                    improvements[0]
                    if episode_evidence is None
                    else episode_evidence.mean_improvement
                ),
                **(
                    {
                        "episode_count": 1.0,
                        "independent_group_count": 1.0,
                        "aggregate_improvement": improvements[0],
                        "mean_improvement": improvements[0],
                        "improvement_standard_error": 0.0,
                        "mean_improvement_ci_lower": improvements[0],
                        "mean_improvement_ci_upper": improvements[0],
                        "aggregate_improvement_ci_lower": improvements[0],
                        "aggregate_improvement_ci_upper": improvements[0],
                        "maximum_regression": max(0.0, -improvements[0]),
                        "wins": float(improvements[0] > 0.0),
                        "ties": float(improvements[0] == 0.0),
                        "losses": float(improvements[0] < 0.0),
                        "batch_win_rate": float(improvements[0] > 0.0),
                        "loss_rate": float(improvements[0] < 0.0),
                        "confidence_interval_defined": 0.0,
                    }
                    if episode_evidence is None
                    else {
                        **episode_evidence.metrics(),
                        "confidence_interval_defined": 1.0,
                    }
                ),
                }
            )
        if evidence_summary is not None:
            self.artifact_store.put(
                "domain_evidence_summary",
                evidence_summary.as_dict(),
            )
        decision = evaluate_gate(
            gate,
            candidate_id=candidate_id,
            incumbent_id=campaign.portfolio.primary_incumbent_id,
            metrics=metrics,
            evidence_count=len(experiments),
        )
        exposure = TestExposureRecord(
            node_id=node_id,
            actor_ref=adapter.verifier_ref,
            partition=partition,
            purpose="adapter-backed frozen quantitative gate",
            dataset_digest=experiment_artifact,
            candidate_id=candidate_id,
            adaptive_access=False,
        )
        self.control_plane.record_test_exposure(exposure)
        record = VerificationRecord(
            node_id=node_id,
            candidate_id=candidate_id,
            family=proposal.family,
            evaluator_ref=adapter.evaluator_ref,
            verifier_ref=adapter.verifier_ref,
            partition=partition,
            evidence_ids=tuple(observation_artifacts),
            effect_size=metrics["effect_size"],
            lower_confidence_bound=metrics[
                "mean_improvement_ci_lower"
            ],
            passed=decision.passed,
            criteria=tuple(
                criterion.description for criterion in gate.criteria
            ),
            exposure_ids=(exposure.exposure_id,),
            raw_artifact_ids=(
                candidate_artifact,
                experiment_artifact,
                *observation_artifacts,
                *verification_artifacts,
            ),
            gate_contract_id=gate.contract_id,
            metrics=metrics,
            evidence_count=len(experiments),
        )
        self.control_plane.record_verification(record)
        recorded = campaign.gate_decisions[record.verification_id]
        if recorded.decision_id != decision.decision_id:
            raise ValueError("control-plane gate decision changed during recording")
        self.save_checkpoint()
        return record, decision

    @classmethod
    def from_checkpoint(
        cls,
        checkpoint_path: Path,
        *,
        artifact_store: Optional[ArtifactStore] = None,
    ) -> "GoalGraphRuntime":
        path = Path(checkpoint_path)
        with path.open("r", encoding="utf-8") as handle:
            supplied = json.load(handle)
        if not isinstance(supplied, dict):
            raise ValueError("goal-graph checkpoint must be a JSON object")
        value = dict(supplied)
        checkpoint_id = value.pop("checkpoint_id", None)
        if checkpoint_id != content_digest(value):
            raise ValueError("goal-graph checkpoint digest mismatch")
        if value.get("runtime_version") != GOAL_GRAPH_RUNTIME_VERSION:
            raise ValueError("unsupported goal-graph runtime version")
        control = AutonomousScientistControlPlane.from_dict(
            value["control_plane"],
            artifact_store=artifact_store,
        )
        return cls(
            control,
            path,
            artifact_store=artifact_store,
            save_on_init=False,
        )

    def status(self) -> Dict[str, Any]:
        progress = self.control_plane.graph.progress_by_role()
        return {
            "runtime_version": GOAL_GRAPH_RUNTIME_VERSION,
            "checkpoint": str(self.checkpoint_path.resolve()),
            "goal_id": self.control_plane.goal.goal_id,
            "compute_spent": self.control_plane.compute_spent,
            "compute_remaining": self.control_plane.compute_remaining,
            "compute_committed": self.control_plane.compute_committed,
            "active_campaign_ids": dict(
                sorted(self.control_plane.active_campaign_ids.items())
            ),
            "continuation_required": (
                self.control_plane.continuation_required
            ),
            "objective_progress": progress["objective"],
            "evidence_progress": progress["evidence"],
            "objective_evidence_policy": dict(
                self.control_plane.objective_evidence_policy
            ),
            "evidence_attachments": {
                node_id: [item.node_id for item in evidence]
                for node_id, node in sorted(
                    self.control_plane.graph.nodes.items()
                )
                if node.effective_role.value == "objective"
                for evidence in (
                    self.control_plane.graph.evidence_for_objective(node_id),
                )
                if evidence
            },
            "resolution": (
                None
                if self.control_plane.resolution is None
                else self.control_plane.resolution.as_dict()
            ),
            "next_actions": [
                action.as_dict()
                for action in self.control_plane.next_actions()
            ],
            "memory_chain_valid": (
                self.control_plane.memory.verify_chain()
            ),
        }
