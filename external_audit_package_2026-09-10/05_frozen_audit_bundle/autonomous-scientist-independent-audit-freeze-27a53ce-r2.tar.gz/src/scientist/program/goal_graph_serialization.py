from __future__ import annotations

from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.kernel.contracts import (
    EvidencePartition,
    GateContract,
    GateCriterion,
    GateKind,
    MetricDirection,
    MetricSpec,
    SearchFamily,
)
from scientist.kernel.gates import GateDecision, evaluate_gate
from scientist.program.campaigns import (
    CampaignPlateauPolicy,
    CampaignRoundSummary,
    IncumbentEntry,
    IncumbentPortfolio,
    IncumbentRole,
    InformationChannel,
    IslandCampaignContract,
    IslandCampaignState,
    IslandCandidateProposal,
    ParentIntegrationRecord,
    TestExposureRecord,
    VerificationRecord,
)
from scientist.program.causal_failure import (
    CausalRelationKind,
    CausalRole,
    RelationalAnalogyMapping,
    causal_discrimination_from_dict,
    causal_failure_model_set_from_dict,
)
from scientist.program.contracts import HighLevelGoal
from scientist.program.goal_graph import (
    CompositionOperator,
    DependencyEdge,
    DependencyKind,
    DynamicGoalGraph,
    ExecutableLeafContract,
    GOAL_GRAPH_ARCHITECTURE_VERSION,
    GoalNodeKind,
    GoalNodeRole,
    GoalNodeSpec,
    GoalNodeStatus,
    ParentCompositionRule,
)
from scientist.program.literature import (
    ClaimClassification,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)
from scientist.program.inspiration import (
    CROSS_DOMAIN_INSPIRATION_VERSION,
    CrossDomainInspiration,
    CrossDomainInspirationPortfolio,
    MechanismMapping,
    TransferEvaluation,
)
from scientist.program.horizon_diagnostics import (
    adequacy_from_dict,
    concept_from_dict,
    concept_validation_from_dict,
    contrast_from_dict,
    dossier_from_dict,
    generator_revision_from_dict,
    horizon_from_dict,
    outcome_from_dict,
    prediction_from_dict,
)
from scientist.program.hypothesis_tournament import (
    HYPOTHESIS_TOURNAMENT_VERSION,
    HypothesisMatch,
    HypothesisOrigin,
    HypothesisProximity,
    HypothesisReview,
    HypothesisTournament,
    TournamentHypothesis,
)
from scientist.program.executable_hypothesis import (
    CausalEvolutionOperator,
    executable_hypothesis_from_dict,
    hypothesis_diagnostic_from_dict,
)
from scientist.program.hypothesis_learning import (
    evolution_basis_from_dict,
    generation_audit_from_dict,
    mechanism_signature_from_dict,
    prediction_profile_from_dict,
)
from scientist.program.mechanism_discovery import (
    MECHANISM_DISCOVERY_VERSION,
    DiscoveredMechanism,
    MechanismDiscoveryQuery,
    MechanismDiscoveryTrace,
)
from scientist.program.research_strategy import (
    diagnosis_from_dict,
    representation_change_from_dict,
    research_program_from_dict,
)
from scientist.program.qualification import leaf_qualification_from_dict
from scientist.program.diagnostics import leaf_diagnostic_from_dict


def _assert_identity(
    value: Mapping[str, Any],
    field: str,
    observed: str,
) -> None:
    supplied = value.get(field)
    if supplied is not None and str(supplied) != observed:
        raise ValueError("%s identity mismatch" % field)


def metric_from_dict(value: Mapping[str, Any]) -> MetricSpec:
    return MetricSpec(
        name=str(value["name"]),
        direction=MetricDirection(value["direction"]),
        unit=str(value["unit"]),
        aggregation=str(value["aggregation"]),
        primary=bool(value.get("primary", False)),
        target=(
            None if value.get("target") is None else float(value["target"])
        ),
    )


def goal_from_dict(value: Mapping[str, Any]) -> HighLevelGoal:
    goal = HighLevelGoal(
        name=str(value["name"]),
        outcome=str(value["outcome"]),
        scope=tuple(str(item) for item in value["scope"]),
        anti_scope=tuple(str(item) for item in value["anti_scope"]),
        terminal_metrics=tuple(
            metric_from_dict(item) for item in value["terminal_metrics"]
        ),
        success_definition=str(value["success_definition"]),
        failure_conditions=tuple(
            str(item) for item in value["failure_conditions"]
        ),
        integration_requirements=tuple(
            str(item) for item in value["integration_requirements"]
        ),
        total_compute_budget=float(value["total_compute_budget"]),
        max_parallel_campaigns=int(value["max_parallel_campaigns"]),
        risk_tier=str(value.get("risk_tier", "research_only")),
        human_owner=(
            None
            if value.get("human_owner") is None
            else str(value["human_owner"])
        ),
    )
    _assert_identity(value, "goal_id", goal.goal_id)
    return goal


def leaf_contract_from_dict(
    value: Mapping[str, Any],
) -> ExecutableLeafContract:
    contract = ExecutableLeafContract(
        hypothesis=str(value["hypothesis"]),
        parent_decision=str(value["parent_decision"]),
        root_metric_link=str(value["root_metric_link"]),
        metric=metric_from_dict(value["metric"]),
        success_conditions=tuple(
            str(item) for item in value["success_conditions"]
        ),
        falsification_conditions=tuple(
            str(item) for item in value["falsification_conditions"]
        ),
        testbed_ref=str(value["testbed_ref"]),
        parent_integration_test=str(value["parent_integration_test"]),
        experiment_budget=float(value["experiment_budget"]),
        preregistration_ref=str(value["preregistration_ref"]),
    )
    _assert_identity(value, "contract_id", contract.contract_id)
    return contract


def node_from_dict(value: Mapping[str, Any]) -> GoalNodeSpec:
    leaf_value = value.get("leaf_contract")
    node = GoalNodeSpec(
        goal_id=str(value["goal_id"]),
        title=str(value["title"]),
        question=str(value["question"]),
        kind=GoalNodeKind(value["kind"]),
        rationale=str(value["rationale"]),
        success_conditions=tuple(
            str(item) for item in value["success_conditions"]
        ),
        falsification_conditions=tuple(
            str(item) for item in value["falsification_conditions"]
        ),
        expected_artifact=str(value["expected_artifact"]),
        critical=bool(value.get("critical", False)),
        leaf_contract=(
            None
            if leaf_value is None
            else leaf_contract_from_dict(leaf_value)
        ),
        tags=tuple(str(item) for item in value.get("tags", ())),
        role=(
            None
            if value.get("role") is None
            else GoalNodeRole(str(value["role"]))
        ),
    )
    _assert_identity(value, "node_id", node.node_id)
    return node


def rule_from_dict(value: Mapping[str, Any]) -> ParentCompositionRule:
    rule = ParentCompositionRule(
        parent_id=str(value["parent_id"]),
        child_ids=tuple(str(item) for item in value["child_ids"]),
        operator=CompositionOperator(value["operator"]),
        integration_test=str(value["integration_test"]),
        rationale=str(value["rationale"]),
        decomposer_ref=str(value["decomposer_ref"]),
        threshold=(
            None if value.get("threshold") is None else int(value["threshold"])
        ),
        supersedes_rule_id=(
            None
            if value.get("supersedes_rule_id") is None
            else str(value["supersedes_rule_id"])
        ),
    )
    _assert_identity(value, "rule_id", rule.rule_id)
    return rule


def dependency_from_dict(value: Mapping[str, Any]) -> DependencyEdge:
    edge = DependencyEdge(
        source_id=str(value["source_id"]),
        target_id=str(value["target_id"]),
        kind=DependencyKind(value["kind"]),
        rationale=str(value["rationale"]),
        evidence_ids=tuple(
            str(item) for item in value.get("evidence_ids", ())
        ),
    )
    _assert_identity(value, "edge_id", edge.edge_id)
    return edge


def graph_from_dict(value: Mapping[str, Any]) -> DynamicGoalGraph:
    if value.get("architecture_version") != GOAL_GRAPH_ARCHITECTURE_VERSION:
        raise ValueError("unsupported goal-graph architecture version")
    node_records = tuple(value["nodes"])
    nodes = tuple(
        node_from_dict(record["specification"]) for record in node_records
    )
    by_id = {node.node_id: node for node in nodes}
    root_id = str(value["root_id"])
    if root_id not in by_id:
        raise ValueError("goal graph root is missing")
    graph = DynamicGoalGraph(str(value["goal_id"]), by_id[root_id])
    if graph.root_id != root_id:
        raise ValueError("goal graph root identity mismatch")
    graph._nodes = by_id
    graph._statuses = {
        node.node_id: GoalNodeStatus(record["status"])
        for node, record in zip(nodes, node_records)
    }
    rules = tuple(rule_from_dict(item) for item in value["rule_history"])
    graph._rules = {rule.rule_id: rule for rule in rules}
    active_rules = tuple(
        rule_from_dict(item) for item in value["active_rules"]
    )
    graph._active_rule_ids = {
        rule.parent_id: rule.rule_id for rule in active_rules
    }
    if not set(graph._active_rule_ids.values()).issubset(graph._rules):
        raise ValueError("active rule is absent from rule history")
    dependencies = tuple(
        dependency_from_dict(item) for item in value["dependencies"]
    )
    graph._dependencies = {
        edge.edge_id: edge for edge in dependencies
    }
    graph._integrated_parent_edges = {
        (str(item["parent_id"]), str(item["child_id"]))
        for item in value["integrated_parent_edges"]
    }
    if set(graph._statuses) != set(graph._nodes):
        raise ValueError("goal graph statuses do not cover every node")
    if any(node.goal_id != graph.goal_id for node in graph._nodes.values()):
        raise ValueError("goal graph contains a node from another goal")
    if any(
        parent_id not in graph._nodes or child_id not in graph._nodes
        for parent_id, child_id in graph._integrated_parent_edges
    ):
        raise ValueError("integrated edge references an unknown node")
    graph._assert_acyclic(
        graph._nodes,
        graph._rules,
        graph._active_rule_ids,
        graph._dependencies,
    )
    if content_digest(graph.as_dict()) != content_digest(dict(value)):
        raise ValueError("goal graph checkpoint is internally inconsistent")
    return graph


def signature_from_dict(value: Mapping[str, Any]) -> ClaimSignature:
    signature = ClaimSignature(
        subject_id=str(value["subject_id"]),
        statement=str(value["statement"]),
        problem=str(value["problem"]),
        phenomenon=str(value["phenomenon"]),
        intervention=str(value["intervention"]),
        mechanism=str(value["mechanism"]),
        evaluation=str(value["evaluation"]),
    )
    _assert_identity(value, "signature_id", signature.signature_id)
    return signature


def literature_from_dict(value: Mapping[str, Any]) -> PriorArtAssessment:
    assessment = PriorArtAssessment(
        signature=signature_from_dict(value["signature"]),
        trigger=LiteratureTrigger(value["trigger"]),
        queries=tuple(
            LiteratureQuery(
                query=str(item["query"]),
                facet=SearchFacet(item["facet"]),
                provider=str(item["provider"]),
            )
            for item in value["queries"]
        ),
        closest_works=tuple(
            PriorWork(
                work_id=str(item["work_id"]),
                title=str(item["title"]),
                year=int(item["year"]),
                locator=str(item["locator"]),
                relation=PriorArtRelation(item["relation"]),
                matched_components=tuple(
                    str(component)
                    for component in item["matched_components"]
                ),
                executable=bool(item.get("executable", False)),
                abstract=str(item.get("abstract", "")),
            )
            for item in value["closest_works"]
        ),
        classification=ClaimClassification(value["classification"]),
        rationale=str(value["rationale"]),
        novel_delta=tuple(str(item) for item in value["novel_delta"]),
        citation_snowball_complete=bool(
            value["citation_snowball_complete"]
        ),
        searched_at=str(value["searched_at"]),
        reviewer_ref=str(value["reviewer_ref"]),
        executable_incumbent_id=(
            None
            if value.get("executable_incumbent_id") is None
            else str(value["executable_incumbent_id"])
        ),
    )
    _assert_identity(value, "assessment_id", assessment.assessment_id)
    return assessment


def inspiration_from_dict(
    value: Mapping[str, Any],
) -> CrossDomainInspiration:
    if value.get("contract_version") != CROSS_DOMAIN_INSPIRATION_VERSION:
        raise ValueError("unsupported cross-domain inspiration version")
    inspiration = CrossDomainInspiration(
        target_node_id=str(value["target_node_id"]),
        target_domain=str(value["target_domain"]),
        source_domain=str(value["source_domain"]),
        source_problem=str(value["source_problem"]),
        source_mechanism=str(value["source_mechanism"]),
        source_reference=str(value["source_reference"]),
        invariant=str(value["invariant"]),
        mappings=tuple(
            MechanismMapping(
                source_element=str(item["source_element"]),
                target_element=str(item["target_element"]),
                transfer_argument=str(item["transfer_argument"]),
                causal_role=(
                    None
                    if item.get("causal_role") is None
                    else CausalRole(str(item["causal_role"]))
                ),
                target_model_id=(
                    None
                    if item.get("target_model_id") is None
                    else str(item["target_model_id"])
                ),
            )
            for item in value["mappings"]
        ),
        boundary_conditions=tuple(
            str(item) for item in value["boundary_conditions"]
        ),
        broken_assumptions=tuple(
            str(item) for item in value["broken_assumptions"]
        ),
        transferred_hypothesis=str(value["transferred_hypothesis"]),
        distinguishing_predictions=tuple(
            str(item) for item in value["distinguishing_predictions"]
        ),
        falsification_conditions=tuple(
            str(item) for item in value["falsification_conditions"]
        ),
        implementation_sketch=str(value["implementation_sketch"]),
        generator_ref=str(value["generator_ref"]),
    )
    _assert_identity(value, "inspiration_id", inspiration.inspiration_id)
    return inspiration


def transfer_evaluation_from_dict(
    value: Mapping[str, Any],
) -> TransferEvaluation:
    evaluation = TransferEvaluation(
        inspiration_id=str(value["inspiration_id"]),
        structural_fit=int(value["structural_fit"]),
        surprise=int(value["surprise"]),
        testability=int(value["testability"]),
        evidence_grounding=int(value["evidence_grounding"]),
        assumption_risk=int(value["assumption_risk"]),
        estimated_compute=float(value["estimated_compute"]),
        rationale=str(value["rationale"]),
    )
    if (
        value.get("priority_score") is not None
        and int(value["priority_score"]) != evaluation.priority_score
    ):
        raise ValueError("restored transfer priority mismatch")
    return evaluation


def mechanism_discovery_query_from_dict(
    value: Mapping[str, Any],
) -> MechanismDiscoveryQuery:
    if value.get("contract_version") != MECHANISM_DISCOVERY_VERSION:
        raise ValueError("unsupported mechanism discovery version")
    query = MechanismDiscoveryQuery(
        target_node_id=str(value["target_node_id"]),
        target_domain=str(value["target_domain"]),
        causal_failure_models=causal_failure_model_set_from_dict(
            dict(value["causal_failure_models"])
        ),
        causal_discrimination=causal_discrimination_from_dict(
            dict(value["causal_discrimination"])
        ),
        failure_signatures=tuple(
            str(item) for item in value["failure_signatures"]
        ),
        desired_capabilities=tuple(
            str(item) for item in value["desired_capabilities"]
        ),
        query_terms=tuple(str(item) for item in value["query_terms"]),
        excluded_source_domains=tuple(
            str(item)
            for item in value.get("excluded_source_domains", ())
        ),
        excluded_generator_refs=tuple(
            str(item)
            for item in value.get("excluded_generator_refs", ())
        ),
        literature_context_id=(
            None
            if value.get("literature_context_id") is None
            else str(value["literature_context_id"])
        ),
        literature_evidence_ids=tuple(
            str(item)
            for item in value.get("literature_evidence_ids", ())
        ),
        query_generator_ref=str(value["query_generator_ref"]),
    )
    _assert_identity(value, "query_id", query.query_id)
    return query


def discovered_mechanism_from_dict(
    value: Mapping[str, Any],
) -> DiscoveredMechanism:
    if value.get("contract_version") != MECHANISM_DISCOVERY_VERSION:
        raise ValueError("unsupported mechanism discovery version")
    mechanism = DiscoveredMechanism(
        query_id=str(value["query_id"]),
        catalog_key=str(value["catalog_key"]),
        source_domain=str(value["source_domain"]),
        source_problem=str(value["source_problem"]),
        source_mechanism=str(value["source_mechanism"]),
        source_reference=str(value["source_reference"]),
        invariant=str(value["invariant"]),
        capability_tags=tuple(
            str(item) for item in value["capability_tags"]
        ),
        generator_ref=str(value["generator_ref"]),
        relational_mappings=tuple(
            RelationalAnalogyMapping(
                causal_role=CausalRole(str(item["causal_role"])),
                target_model_id=str(item["target_model_id"]),
                source_element=str(item["source_element"]),
                target_element=str(item["target_element"]),
                correspondence=str(item["correspondence"]),
            )
            for item in value["relational_mappings"]
        ),
        matched_causal_relations=tuple(
            CausalRelationKind(str(item))
            for item in value["matched_causal_relations"]
        ),
        broken_assumptions=tuple(
            str(item) for item in value["broken_assumptions"]
        ),
        distinguishing_predictions=tuple(
            str(item) for item in value["distinguishing_predictions"]
        ),
        structural_fit=int(value["structural_fit"]),
        surprise=int(value["surprise"]),
        evidence_grounding=int(value["evidence_grounding"]),
        retrieval_score=int(value["retrieval_score"]),
    )
    _assert_identity(value, "discovery_id", mechanism.discovery_id)
    return mechanism


def mechanism_discovery_trace_from_dict(
    value: Mapping[str, Any],
) -> MechanismDiscoveryTrace:
    if value.get("contract_version") != MECHANISM_DISCOVERY_VERSION:
        raise ValueError("unsupported mechanism discovery version")
    trace = MechanismDiscoveryTrace(
        query=mechanism_discovery_query_from_dict(value["query"]),
        candidates=tuple(
            discovered_mechanism_from_dict(item)
            for item in value["candidates"]
        ),
        selected_discovery_ids=tuple(
            str(item) for item in value["selected_discovery_ids"]
        ),
        selection_rationale=str(value["selection_rationale"]),
        scout_ref=str(value["scout_ref"]),
    )
    _assert_identity(value, "trace_id", trace.trace_id)
    return trace


def tournament_hypothesis_from_dict(
    value: Mapping[str, Any],
) -> TournamentHypothesis:
    if value.get("contract_version") != HYPOTHESIS_TOURNAMENT_VERSION:
        raise ValueError("unsupported hypothesis tournament version")
    hypothesis = TournamentHypothesis(
        target_node_id=str(value["target_node_id"]),
        statement=str(value["statement"]),
        mechanism=str(value["mechanism"]),
        origin=HypothesisOrigin(value["origin"]),
        source_ref=str(value["source_ref"]),
        generator_ref=str(value["generator_ref"]),
        predictions=tuple(str(item) for item in value["predictions"]),
        falsification_conditions=tuple(
            str(item) for item in value["falsification_conditions"]
        ),
        assumptions=tuple(str(item) for item in value["assumptions"]),
        evidence_ids=tuple(
            str(item) for item in value.get("evidence_ids", ())
        ),
        mechanism_signature=mechanism_signature_from_dict(
            value["mechanism_signature"]
        ),
        prediction_profile=prediction_profile_from_dict(
            value["prediction_profile"]
        ),
        parent_ids=tuple(
            str(item) for item in value.get("parent_ids", ())
        ),
        inspiration_ids=tuple(
            str(item) for item in value.get("inspiration_ids", ())
        ),
        island_family=(
            None
            if value.get("island_family") is None
            else str(value["island_family"])
        ),
        generation=int(value.get("generation", 0)),
        revision_eligible=bool(
            value.get("revision_eligible", False)
        ),
        executable_contract=(
            None
            if value.get("executable_contract") is None
            else executable_hypothesis_from_dict(
                value["executable_contract"]
            )
        ),
        diagnostic_result=(
            None
            if value.get("diagnostic_result") is None
            else hypothesis_diagnostic_from_dict(
                value["diagnostic_result"]
            )
        ),
        causal_operator=(
            None
            if value.get("causal_operator") is None
            else CausalEvolutionOperator(value["causal_operator"])
        ),
        evolution_basis=(
            None
            if value.get("evolution_basis") is None
            else evolution_basis_from_dict(value["evolution_basis"])
        ),
    )
    if (
        value.get("scientific_identity") is not None
        and str(value["scientific_identity"])
        != hypothesis.scientific_identity
    ):
        raise ValueError("restored scientific hypothesis identity mismatch")
    _assert_identity(value, "hypothesis_id", hypothesis.hypothesis_id)
    return hypothesis


def hypothesis_review_from_dict(
    value: Mapping[str, Any],
) -> HypothesisReview:
    review = HypothesisReview(
        hypothesis_id=str(value["hypothesis_id"]),
        goal_alignment=int(value["goal_alignment"]),
        plausibility=int(value["plausibility"]),
        novelty=int(value["novelty"]),
        testability=int(value["testability"]),
        feasibility=int(value["feasibility"]),
        evidence_grounding=int(value["evidence_grounding"]),
        diversity_value=int(value["diversity_value"]),
        assumption_risk=int(value["assumption_risk"]),
        critique=tuple(str(item) for item in value["critique"]),
        improvement_directions=tuple(
            str(item) for item in value["improvement_directions"]
        ),
        reviewer_ref=str(value["reviewer_ref"]),
        evidence_update=int(value.get("evidence_update", 0)),
    )
    if (
        value.get("quality_score") is not None
        and int(value["quality_score"]) != review.quality_score
    ):
        raise ValueError("restored hypothesis review score mismatch")
    return review


def hypothesis_proximity_from_dict(
    value: Mapping[str, Any],
) -> HypothesisProximity:
    return HypothesisProximity(
        first_hypothesis_id=str(value["first_hypothesis_id"]),
        second_hypothesis_id=str(value["second_hypothesis_id"]),
        similarity=float(value["similarity"]),
        shared_terms=tuple(
            str(item) for item in value.get("shared_terms", ())
        ),
    )


def hypothesis_match_from_dict(
    value: Mapping[str, Any],
) -> HypothesisMatch:
    return HypothesisMatch(
        match_index=int(value["match_index"]),
        first_hypothesis_id=str(value["first_hypothesis_id"]),
        second_hypothesis_id=str(value["second_hypothesis_id"]),
        first_rating_before=float(value["first_rating_before"]),
        second_rating_before=float(value["second_rating_before"]),
        first_score=float(value["first_score"]),
        first_rating_after=float(value["first_rating_after"]),
        second_rating_after=float(value["second_rating_after"]),
        order_votes=tuple(str(item) for item in value["order_votes"]),
        facet_deltas={
            str(key): int(item)
            for key, item in value["facet_deltas"].items()
        },
        rationale=str(value["rationale"]),
    )


def hypothesis_tournament_from_dict(
    value: Mapping[str, Any],
) -> HypothesisTournament:
    if value.get("contract_version") != HYPOTHESIS_TOURNAMENT_VERSION:
        raise ValueError("unsupported hypothesis tournament version")
    tournament = HypothesisTournament(
        target_node_id=str(value["target_node_id"]),
        hypotheses=tuple(
            tournament_hypothesis_from_dict(item)
            for item in value["hypotheses"]
        ),
        reviews=tuple(
            hypothesis_review_from_dict(item)
            for item in value["reviews"]
        ),
        proximities=tuple(
            hypothesis_proximity_from_dict(item)
            for item in value["proximities"]
        ),
        matches=tuple(
            hypothesis_match_from_dict(item)
            for item in value["matches"]
        ),
        final_ratings={
            str(key): float(item)
            for key, item in value["final_ratings"].items()
        },
        survivor_ids=tuple(
            str(item) for item in value["survivor_ids"]
        ),
        champion_id=str(value["champion_id"]),
        eligible_champion_id=(
            None
            if value.get("eligible_champion_id") is None
            else str(value["eligible_champion_id"])
        ),
        generations_completed=int(value["generations_completed"]),
        meta_review=tuple(str(item) for item in value["meta_review"]),
        tournament_ref=str(value["tournament_ref"]),
        generation_audit=generation_audit_from_dict(
            value["generation_audit"]
        ),
        initial_rating=float(value.get("initial_rating", 1200.0)),
        k_factor=float(value.get("k_factor", 32.0)),
        required_discovery_channels=tuple(
            str(item)
            for item in value.get(
                "required_discovery_channels",
                ("ancestry", "de_novo", "hybrid", "cross_domain"),
            )
        ),
    )
    _assert_identity(value, "tournament_id", tournament.tournament_id)
    return tournament


def inspiration_portfolio_from_dict(
    value: Mapping[str, Any],
) -> CrossDomainInspirationPortfolio:
    if value.get("contract_version") != CROSS_DOMAIN_INSPIRATION_VERSION:
        raise ValueError("unsupported cross-domain portfolio version")
    portfolio = CrossDomainInspirationPortfolio(
        target_node_id=str(value["target_node_id"]),
        inspirations=tuple(
            inspiration_from_dict(item) for item in value["inspirations"]
        ),
        evaluations=tuple(
            transfer_evaluation_from_dict(item)
            for item in value["evaluations"]
        ),
        selected_inspiration_ids=tuple(
            str(item) for item in value["selected_inspiration_ids"]
        ),
        selection_rationale=str(value["selection_rationale"]),
        synthesizer_ref=str(value["synthesizer_ref"]),
        causal_failure_models=(
            None
            if value.get("causal_failure_models") is None
            else causal_failure_model_set_from_dict(
                dict(value["causal_failure_models"])
            )
        ),
        discovery_trace=(
            None
            if value.get("discovery_trace") is None
            else mechanism_discovery_trace_from_dict(
                value["discovery_trace"]
            )
        ),
        tournament=(
            None
            if value.get("tournament") is None
            else hypothesis_tournament_from_dict(value["tournament"])
        ),
    )
    _assert_identity(value, "portfolio_id", portfolio.portfolio_id)
    return portfolio


def portfolio_from_dict(value: Mapping[str, Any]) -> IncumbentPortfolio:
    portfolio = IncumbentPortfolio(
        node_id=str(value["node_id"]),
        literature_assessment_id=str(value["literature_assessment_id"]),
        entries=tuple(
            IncumbentEntry(
                candidate_id=str(item["candidate_id"]),
                name=str(item["name"]),
                role=IncumbentRole(item["role"]),
                executable_digest=str(item["executable_digest"]),
                source_locator=str(item["source_locator"]),
                reproduction_evidence_ids=tuple(
                    str(evidence_id)
                    for evidence_id in item["reproduction_evidence_ids"]
                ),
                metric_summary={
                    str(name): metric
                    for name, metric in item["metric_summary"].items()
                },
                source_work_id=(
                    None
                    if item.get("source_work_id") is None
                    else str(item["source_work_id"])
                ),
                limitations=tuple(
                    str(limitation)
                    for limitation in item.get("limitations", ())
                ),
            )
            for item in value["entries"]
        ),
        primary_incumbent_id=str(value["primary_incumbent_id"]),
        selection_rationale=str(value["selection_rationale"]),
        baseline_uncertain=bool(value.get("baseline_uncertain", False)),
        uncertainty_reasons=tuple(
            str(item) for item in value.get("uncertainty_reasons", ())
        ),
    )
    _assert_identity(value, "portfolio_id", portfolio.portfolio_id)
    return portfolio


def gate_from_dict(value: Mapping[str, Any]) -> GateContract:
    gate = GateContract(
        kind=GateKind(value["kind"]),
        evidence_partition=EvidencePartition(value["evidence_partition"]),
        criteria=tuple(
            GateCriterion(
                metric=str(item["metric"]),
                operator=str(item["operator"]),
                threshold=float(item["threshold"]),
                description=str(item["description"]),
            )
            for item in value["criteria"]
        ),
        minimum_evidence_count=int(value["minimum_evidence_count"]),
    )
    _assert_identity(value, "contract_id", gate.contract_id)
    return gate


def campaign_contract_from_dict(
    value: Mapping[str, Any],
) -> IslandCampaignContract:
    views = {
        SearchFamily(family): tuple(
            InformationChannel(channel) for channel in channels
        )
        for family, channels in value["information_views"].items()
    }
    contract = IslandCampaignContract(
        node_id=str(value["node_id"]),
        leaf_contract_id=str(value["leaf_contract_id"]),
        incumbent_portfolio_id=str(value["incumbent_portfolio_id"]),
        evaluator_ref=str(value["evaluator_ref"]),
        verifier_ref=str(value["verifier_ref"]),
        quarantined_test_ref=str(value["quarantined_test_ref"]),
        total_compute_budget=float(value["total_compute_budget"]),
        max_rounds=int(value["max_rounds"]),
        cycle_index=int(value.get("cycle_index", 0)),
        isolation_rounds=int(value.get("isolation_rounds", 1)),
        search_families=tuple(
            SearchFamily(item) for item in value["search_families"]
        ),
        information_views=views,
        gates=tuple(gate_from_dict(item) for item in value["gates"]),
        selected_hypothesis_id=(
            None
            if value.get("selected_hypothesis_id") is None
            else str(value["selected_hypothesis_id"])
        ),
        selected_executable_digest=(
            None
            if value.get("selected_executable_digest") is None
            else str(value["selected_executable_digest"])
        ),
        selected_diagnostic_id=(
            None
            if value.get("selected_diagnostic_id") is None
            else str(value["selected_diagnostic_id"])
        ),
    )
    _assert_identity(value, "campaign_id", contract.campaign_id)
    return contract


def proposal_from_dict(
    value: Mapping[str, Any],
) -> IslandCandidateProposal:
    proposal = IslandCandidateProposal(
        node_id=str(value["node_id"]),
        family=SearchFamily(value["family"]),
        executable_digest=str(value["executable_digest"]),
        mechanism_summary=str(value["mechanism_summary"]),
        ancestry_ids=tuple(str(item) for item in value["ancestry_ids"]),
        proposer_ref=str(value["proposer_ref"]),
        round_index=int(value["round_index"]),
        exposed_information=tuple(
            InformationChannel(item) for item in value["exposed_information"]
        ),
        literature_context_id=(
            None
            if value.get("literature_context_id") is None
            else str(value["literature_context_id"])
        ),
        literature_evidence_ids=tuple(
            str(item)
            for item in value.get("literature_evidence_ids", ())
        ),
    )
    _assert_identity(value, "candidate_id", proposal.candidate_id)
    return proposal


def exposure_from_dict(value: Mapping[str, Any]) -> TestExposureRecord:
    exposure = TestExposureRecord(
        node_id=str(value["node_id"]),
        actor_ref=str(value["actor_ref"]),
        partition=EvidencePartition(value["partition"]),
        purpose=str(value["purpose"]),
        dataset_digest=str(value["dataset_digest"]),
        candidate_id=(
            None
            if value.get("candidate_id") is None
            else str(value["candidate_id"])
        ),
        adaptive_access=bool(value.get("adaptive_access", False)),
    )
    _assert_identity(value, "exposure_id", exposure.exposure_id)
    return exposure


def verification_from_dict(
    value: Mapping[str, Any],
) -> VerificationRecord:
    verification = VerificationRecord(
        node_id=str(value["node_id"]),
        candidate_id=str(value["candidate_id"]),
        family=SearchFamily(value["family"]),
        evaluator_ref=str(value["evaluator_ref"]),
        verifier_ref=str(value["verifier_ref"]),
        partition=EvidencePartition(value["partition"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        effect_size=float(value["effect_size"]),
        lower_confidence_bound=float(value["lower_confidence_bound"]),
        passed=bool(value["passed"]),
        criteria=tuple(str(item) for item in value["criteria"]),
        exposure_ids=tuple(str(item) for item in value["exposure_ids"]),
        raw_artifact_ids=tuple(
            str(item) for item in value["raw_artifact_ids"]
        ),
        gate_contract_id=str(value["gate_contract_id"]),
        metrics={
            str(name): float(metric)
            for name, metric in value["metrics"].items()
        },
        evidence_count=int(value["evidence_count"]),
    )
    _assert_identity(value, "verification_id", verification.verification_id)
    return verification


def round_from_dict(value: Mapping[str, Any]) -> CampaignRoundSummary:
    return CampaignRoundSummary(
        node_id=str(value["node_id"]),
        round_index=int(value["round_index"]),
        attempts_by_family={
            SearchFamily(name): int(count)
            for name, count in value["attempts_by_family"].items()
        },
        distinct_ancestries_by_family={
            SearchFamily(name): int(count)
            for name, count in value[
                "distinct_ancestries_by_family"
            ].items()
        },
        best_verified_effect=float(value["best_verified_effect"]),
        confidence_sufficient=bool(value["confidence_sufficient"]),
        failure_signature=str(value["failure_signature"]),
        compute_spent=float(value["compute_spent"]),
        budget_complete=bool(value["budget_complete"]),
        causal_failure_models=(
            None
            if value.get("causal_failure_models") is None
            else causal_failure_model_set_from_dict(
                dict(value["causal_failure_models"])
            )
        ),
    )


def campaign_state_from_dict(
    value: Mapping[str, Any],
) -> IslandCampaignState:
    contract = campaign_contract_from_dict(value["contract"])
    portfolio = portfolio_from_dict(value["portfolio"])
    policy_value = value["plateau_policy"]
    policy = CampaignPlateauPolicy(
        minimum_complete_rounds=int(
            policy_value["minimum_complete_rounds"]
        ),
        no_improvement_window=int(policy_value["no_improvement_window"]),
        minimum_attempts_per_island=int(
            policy_value["minimum_attempts_per_island"]
        ),
        minimum_distinct_ancestries_per_island=int(
            policy_value["minimum_distinct_ancestries_per_island"]
        ),
        minimum_meaningful_effect=float(
            policy_value["minimum_meaningful_effect"]
        ),
        stable_failure_window=int(policy_value["stable_failure_window"]),
    )
    state = IslandCampaignState(contract, portfolio, policy)
    proposals = tuple(
        proposal_from_dict(item) for item in value["proposals"]
    )
    state._proposals = {
        proposal.candidate_id: proposal for proposal in proposals
    }
    state._verifications = {
        str(candidate_id): tuple(
            verification_from_dict(item) for item in records
        )
        for candidate_id, records in value["verifications"].items()
    }
    state._gate_decisions = {}
    gates = {gate.contract_id: gate for gate in contract.gates}
    for records in state._verifications.values():
        for verification in records:
            gate = gates.get(verification.gate_contract_id)
            if gate is None:
                raise ValueError("restored verification uses an unknown gate")
            decision = evaluate_gate(
                gate,
                candidate_id=verification.candidate_id,
                incumbent_id=portfolio.primary_incumbent_id,
                metrics=verification.metrics,
                evidence_count=verification.evidence_count,
            )
            if decision.passed != verification.passed:
                raise ValueError(
                    "restored verification disagrees with its frozen gate"
                )
            state._gate_decisions[verification.verification_id] = decision
    supplied_decisions = dict(value.get("gate_decisions", {}))
    if set(supplied_decisions) != set(state._gate_decisions):
        raise ValueError("restored gate decisions are incomplete")
    for verification_id, decision in state._gate_decisions.items():
        supplied = supplied_decisions[verification_id]
        _assert_identity(supplied, "decision_id", decision.decision_id)
        if content_digest(decision.as_dict()) != content_digest(supplied):
            raise ValueError("restored gate decision was modified")
    state._rounds = tuple(round_from_dict(item) for item in value["rounds"])
    state._selected_candidate_id = (
        None
        if value.get("selected_candidate_id") is None
        else str(value["selected_candidate_id"])
    )
    state._strategy_termination = (
        None
        if value.get("strategy_termination") is None
        else diagnosis_from_dict(value["strategy_termination"])
    )
    state._plateau = state._diagnose_plateau()
    if state._selected_candidate_id is not None:
        candidate_id = state._selected_candidate_id
        if candidate_id not in state._proposals:
            raise ValueError("restored selected candidate is unknown")
        qualifying = tuple(
            verification
            for verification in state._verifications.get(candidate_id, ())
            if state._gate_decisions[verification.verification_id].passed
            and gates[verification.gate_contract_id].kind
            == GateKind.INCUMBENT_ADVANCE
        )
        if not qualifying:
            raise ValueError("restored candidate lacks a passing advance gate")
    if content_digest(state.as_dict()) != content_digest(dict(value)):
        raise ValueError("campaign checkpoint is internally inconsistent")
    return state


def integration_from_dict(
    value: Mapping[str, Any],
) -> ParentIntegrationRecord:
    record = ParentIntegrationRecord(
        node_id=str(value["node_id"]),
        parent_id=str(value["parent_id"]),
        candidate_id=str(value["candidate_id"]),
        preregistered_test_ref=str(value["preregistered_test_ref"]),
        evaluator_ref=str(value["evaluator_ref"]),
        verifier_ref=str(value["verifier_ref"]),
        partition=EvidencePartition(value["partition"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        metric_deltas={
            str(name): float(metric)
            for name, metric in value["metric_deltas"].items()
        },
        passed=bool(value["passed"]),
        causal_interpretation=str(value["causal_interpretation"]),
        failure_mode=(
            None
            if value.get("failure_mode") is None
            else str(value["failure_mode"])
        ),
    )
    _assert_identity(value, "integration_id", record.integration_id)
    return record


def scheduling_assessment_from_dict(
    value: Mapping[str, Any],
):
    from scientist.program.control_plane import NodeSchedulingAssessment

    return NodeSchedulingAssessment(
        node_id=str(value["node_id"]),
        root_relevance=float(value["root_relevance"]),
        value_of_information=float(value["value_of_information"]),
        success_probability=float(value["success_probability"]),
        integration_leverage=float(value["integration_leverage"]),
        uncertainty=float(value["uncertainty"]),
        estimated_cost=float(value["estimated_cost"]),
        basis=tuple(str(item) for item in value["basis"]),
        assessor_ref=str(value["assessor_ref"]),
    )


def root_evaluation_from_dict(value: Mapping[str, Any]):
    from scientist.program.control_plane import RootGateEvaluation

    evaluation = RootGateEvaluation(
        goal_id=str(value["goal_id"]),
        gate_contract_id=str(value["gate_contract_id"]),
        gate_decision_id=str(value["gate_decision_id"]),
        passed=bool(value["passed"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        satisfied_requirements=tuple(
            str(item) for item in value["satisfied_requirements"]
        ),
        limitations=tuple(str(item) for item in value["limitations"]),
        reasons=tuple(str(item) for item in value["reasons"]),
    )
    _assert_identity(value, "evaluation_id", evaluation.evaluation_id)
    return evaluation


def resolution_from_dict(value: Optional[Mapping[str, Any]]):
    if value is None:
        return None
    from scientist.program.control_plane import (
        RootResolutionCertificate,
        RootTerminalState,
        RootUnresolvedReason,
    )

    reason = value.get("unresolved_reason")
    resolution = RootResolutionCertificate(
        goal_id=str(value["goal_id"]),
        terminal_state=RootTerminalState(value["terminal_state"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        compute_spent=float(value["compute_spent"]),
        unresolved_node_ids=tuple(
            str(item) for item in value["unresolved_node_ids"]
        ),
        limitations=tuple(str(item) for item in value["limitations"]),
        reasons=tuple(str(item) for item in value["reasons"]),
        root_gate_evaluation_id=(
            None
            if value.get("root_gate_evaluation_id") is None
            else str(value["root_gate_evaluation_id"])
        ),
        unresolved_reason=(
            None if reason is None else RootUnresolvedReason(reason)
        ),
        blockers=tuple(str(item) for item in value.get("blockers", ())),
    )
    _assert_identity(value, "certificate_id", resolution.certificate_id)
    return resolution


def memory_from_dict(
    value: Mapping[str, Any],
    artifact_store: Optional[ArtifactStore] = None,
):
    from scientist.program.control_plane import (
        ScientificMemoryEvent,
        ScientificMemoryEventKind,
        ScientificMemoryLedger,
    )

    if value.get("architecture_version") != GOAL_GRAPH_ARCHITECTURE_VERSION:
        raise ValueError("unsupported scientific-memory version")
    memory = ScientificMemoryLedger(
        str(value["goal_id"]),
        artifact_store=artifact_store,
    )
    events = tuple(
        ScientificMemoryEvent(
            sequence=int(item["sequence"]),
            goal_id=str(item["goal_id"]),
            kind=ScientificMemoryEventKind(item["kind"]),
            payload=dict(item["payload"]),
            actor_ref=str(item["actor_ref"]),
            previous_event_id=(
                None
                if item.get("previous_event_id") is None
                else str(item["previous_event_id"])
            ),
        )
        for item in value["events"]
    )
    for event, supplied in zip(events, value["events"]):
        _assert_identity(supplied, "event_id", event.event_id)
    memory._events = events
    memory._artifact_digests = tuple(
        str(item) for item in value.get("artifact_digests", ())
    )
    if not memory.verify_chain():
        raise ValueError("scientific-memory chain is invalid")
    if len(events) != int(value["event_count"]):
        raise ValueError("scientific-memory event count mismatch")
    expected_head = None if not events else events[-1].event_id
    if value.get("head_event_id") != expected_head:
        raise ValueError("scientific-memory head mismatch")
    if artifact_store is not None and memory._artifact_digests:
        if len(memory._artifact_digests) != len(events):
            raise ValueError("scientific-memory artifacts are incomplete")
        for digest, event in zip(memory._artifact_digests, events):
            envelope = artifact_store.get(digest)
            if envelope.get("kind") != "goal_graph_scientific_memory_event":
                raise ValueError("scientific-memory artifact has the wrong kind")
            if content_digest(envelope.get("value")) != content_digest(
                event.as_dict()
            ):
                raise ValueError("scientific-memory artifact was modified")
    return memory


def control_plane_from_dict(
    value: Mapping[str, Any],
    artifact_store: Optional[ArtifactStore] = None,
):
    from scientist.program.control_plane import AutonomousScientistControlPlane

    if value.get("architecture_version") != GOAL_GRAPH_ARCHITECTURE_VERSION:
        raise ValueError("unsupported control-plane architecture version")
    goal = goal_from_dict(value["goal"])
    graph = graph_from_dict(value["graph"])
    if graph.goal_id != goal.goal_id:
        raise ValueError("control-plane graph belongs to another goal")
    control = AutonomousScientistControlPlane(
        goal,
        graph.nodes[graph.root_id],
        controller_ref=str(value["controller_ref"]),
    )
    control.graph = graph
    control.memory = memory_from_dict(
        value["memory"],
        artifact_store=artifact_store,
    )
    control._literature = {
        str(subject_id): tuple(
            literature_from_dict(item) for item in assessments
        )
        for subject_id, assessments in value["literature"].items()
    }
    control._cross_domain_inspirations = {
        str(node_id): tuple(
            inspiration_portfolio_from_dict(item)
            for item in portfolios
        )
        for node_id, portfolios in value.get(
            "cross_domain_inspiration_portfolios",
            {},
        ).items()
    }
    control._causal_failure_models = {
        str(node_id): tuple(
            causal_failure_model_set_from_dict(dict(item))
            for item in model_sets
        )
        for node_id, model_sets in value.get(
            "causal_failure_model_sets",
            {},
        ).items()
    }
    if any(
        node_id not in graph.nodes
        or any(
            model_set.target_node_id != node_id
            for model_set in model_sets
        )
        for node_id, model_sets in (
            control._causal_failure_models.items()
        )
    ):
        raise ValueError(
            "causal failure model map references an unknown target"
        )
    if any(
        node_id not in graph.nodes
        or any(
            portfolio.target_node_id != node_id
            for portfolio in portfolios
        )
        for node_id, portfolios in (
            control._cross_domain_inspirations.items()
        )
    ):
        raise ValueError(
            "cross-domain inspiration map references an unknown target"
        )
    portfolios = tuple(
        portfolio_from_dict(item) for item in value["incumbent_portfolios"]
    )
    control._portfolios = {
        portfolio.portfolio_id: portfolio for portfolio in portfolios
    }
    control._current_portfolio_ids = {
        str(node_id): str(portfolio_id)
        for node_id, portfolio_id in value[
            "current_portfolio_ids"
        ].items()
    }
    control._campaigns = {
        str(campaign_id): campaign_state_from_dict(item)
        for campaign_id, item in value["campaigns"].items()
    }
    if any(
        campaign_id != campaign.contract.campaign_id
        for campaign_id, campaign in control._campaigns.items()
    ):
        raise ValueError("campaign map contains an identity mismatch")
    control._active_campaign_ids = {
        str(node_id): str(campaign_id)
        for node_id, campaign_id in value["active_campaign_ids"].items()
    }
    if not set(control._active_campaign_ids.values()).issubset(
        control._campaigns
    ):
        raise ValueError("active campaign map references an unknown campaign")
    control._leaf_qualifications = {
        str(node_id): tuple(
            leaf_qualification_from_dict(item) for item in records
        )
        for node_id, records in value.get("leaf_qualifications", {}).items()
    }
    if any(
        node_id not in graph.nodes
        or any(record.node_id != node_id for record in records)
        for node_id, records in control._leaf_qualifications.items()
    ):
        raise ValueError("leaf qualification map references another node")
    control._leaf_diagnostics = {
        str(node_id): tuple(
            leaf_diagnostic_from_dict(item) for item in records
        )
        for node_id, records in value.get("leaf_diagnostics", {}).items()
    }
    if any(
        node_id not in graph.nodes
        or any(record.node_id != node_id for record in records)
        for node_id, records in control._leaf_diagnostics.items()
    ):
        raise ValueError("leaf diagnostic map references another node")
    control._research_programs = {
        str(program_id): research_program_from_dict(item)
        for program_id, item in value.get("research_programs", {}).items()
    }
    if any(
        program_id != program.program_id
        for program_id, program in control._research_programs.items()
    ):
        raise ValueError("research-program map contains an identity mismatch")
    control._active_research_program_ids = {
        str(node_id): str(program_id)
        for node_id, program_id in value.get(
            "active_research_program_ids",
            {},
        ).items()
    }
    if not set(control._active_research_program_ids.values()).issubset(
        control._research_programs
    ):
        raise ValueError("active research program map references an unknown program")
    if any(
        control._research_programs[program_id].node_id != node_id
        for node_id, program_id in control._active_research_program_ids.items()
    ):
        raise ValueError("active research program targets another node")
    control._research_program_diagnoses = {
        str(program_id): tuple(diagnosis_from_dict(item) for item in diagnoses)
        for program_id, diagnoses in value.get(
            "research_program_diagnoses",
            {},
        ).items()
    }
    if any(
        program_id not in control._research_programs
        or any(item.program_id != program_id for item in diagnoses)
        for program_id, diagnoses in control._research_program_diagnoses.items()
    ):
        raise ValueError("research-program diagnoses reference an unknown program")
    control._representation_changes = {
        str(proposal_id): representation_change_from_dict(item)
        for proposal_id, item in value.get("representation_changes", {}).items()
    }
    if any(
        proposal_id != proposal.proposal_id
        or proposal.prior_program_id not in control._research_programs
        or proposal.revised_program.program_id not in control._research_programs
        for proposal_id, proposal in control._representation_changes.items()
    ):
        raise ValueError("representation-change map is internally inconsistent")
    control._evaluation_horizons = {
        str(item_id): horizon_from_dict(item)
        for item_id, item in value.get("evaluation_horizons", {}).items()
    }
    control._horizon_predictions = {
        str(item_id): prediction_from_dict(item)
        for item_id, item in value.get("horizon_predictions", {}).items()
    }
    control._horizon_outcomes = {
        str(item_id): outcome_from_dict(item)
        for item_id, item in value.get("horizon_outcomes", {}).items()
    }
    control._horizon_contrasts = {
        str(item_id): contrast_from_dict(item)
        for item_id, item in value.get("horizon_contrasts", {}).items()
    }
    control._horizon_dossiers = {
        str(item_id): dossier_from_dict(item)
        for item_id, item in value.get(
            "horizon_failure_dossiers", {}
        ).items()
    }
    control._representation_adequacy_assessments = {
        str(item_id): adequacy_from_dict(item)
        for item_id, item in value.get(
            "representation_adequacy_assessments", {}
        ).items()
    }
    control._latent_concepts = {
        str(item_id): concept_from_dict(item)
        for item_id, item in value.get("latent_concepts", {}).items()
    }
    control._concept_validations = {
        str(item_id): concept_validation_from_dict(item)
        for item_id, item in value.get("concept_validations", {}).items()
    }
    control._generator_revisions = {
        str(item_id): generator_revision_from_dict(item)
        for item_id, item in value.get("generator_revisions", {}).items()
    }
    diagnostic_maps = (
        (control._evaluation_horizons, "horizon_id"),
        (control._horizon_predictions, "prediction_id"),
        (control._horizon_outcomes, "outcome_id"),
        (control._horizon_contrasts, "contrast_id"),
        (control._horizon_dossiers, "dossier_id"),
        (control._representation_adequacy_assessments, "assessment_id"),
        (control._latent_concepts, "concept_id"),
        (control._concept_validations, "validation_id"),
        (control._generator_revisions, "revision_id"),
    )
    if any(
        item_id != getattr(item, identity_field)
        for item_map, identity_field in diagnostic_maps
        for item_id, item in item_map.items()
    ):
        raise ValueError("horizon-diagnostic map contains an identity mismatch")
    if any(
        item.node_id not in graph.nodes
        for item in control._evaluation_horizons.values()
    ):
        raise ValueError("evaluation horizon references an unknown node")
    if any(
        item.horizon_id not in control._evaluation_horizons
        for item in control._horizon_predictions.values()
    ):
        raise ValueError("horizon prediction references an unknown horizon")
    if any(
        item.horizon_id not in control._evaluation_horizons
        or item.prediction_id not in control._horizon_predictions
        for item in control._horizon_outcomes.values()
    ):
        raise ValueError("horizon outcome references unknown prerequisites")
    if any(
        item.local_outcome_id not in control._horizon_outcomes
        or item.terminal_outcome_id not in control._horizon_outcomes
        for item in control._horizon_contrasts.values()
    ):
        raise ValueError("horizon contrast references an unknown outcome")
    if any(
        any(
            contrast_id not in control._horizon_contrasts
            for contrast_id in item.contrast_ids
        )
        for item in control._horizon_dossiers.values()
    ):
        raise ValueError("horizon dossier references an unknown contrast")
    if any(
        item.dossier_id not in control._horizon_dossiers
        for item in control._representation_adequacy_assessments.values()
    ):
        raise ValueError("adequacy assessment references an unknown dossier")
    if any(
        item.adequacy_assessment_id
        not in control._representation_adequacy_assessments
        for item in control._latent_concepts.values()
    ):
        raise ValueError("latent concept references an unknown assessment")
    if any(
        item.concept_id not in control._latent_concepts
        for item in control._concept_validations.values()
    ):
        raise ValueError("concept validation references an unknown concept")
    if any(
        item.concept_validation_id not in control._concept_validations
        for item in control._generator_revisions.values()
    ):
        raise ValueError("generator revision references an unknown validation")
    control._concept_grounded_representation_changes = {
        str(proposal_id): str(revision_id)
        for proposal_id, revision_id in value.get(
            "concept_grounded_representation_changes", {}
        ).items()
    }
    if any(
        proposal_id not in control._representation_changes
        or revision_id not in control._generator_revisions
        for proposal_id, revision_id in (
            control._concept_grounded_representation_changes.items()
        )
    ):
        raise ValueError("concept-grounded representation change is inconsistent")
    exposures = tuple(
        exposure_from_dict(item) for item in value["test_exposures"]
    )
    control._exposures = {
        exposure.exposure_id: exposure for exposure in exposures
    }
    control._integrations = {
        str(node_id): tuple(
            integration_from_dict(item) for item in records
        )
        for node_id, records in value["parent_integrations"].items()
    }
    assessments = tuple(
        scheduling_assessment_from_dict(item)
        for item in value["scheduling_assessments"]
    )
    control._scheduling_assessments = {
        assessment.node_id: assessment for assessment in assessments
    }
    control._root_gate_evaluations = tuple(
        root_evaluation_from_dict(item)
        for item in value["root_gate_evaluations"]
    )
    control._resolution = resolution_from_dict(value.get("resolution"))
    if control.compute_spent > goal.total_compute_budget:
        raise ValueError("restored control plane exceeds its root budget")
    if len(control._active_campaign_ids) > goal.max_parallel_campaigns:
        raise ValueError("restored control plane exceeds its parallel limit")
    if content_digest(control.as_dict()) != content_digest(dict(value)):
        raise ValueError("control-plane checkpoint is internally inconsistent")
    return control
