from __future__ import annotations

from typing import Dict, Iterable, Mapping, Tuple

from scientist.program.contracts import (
    HighLevelGoal,
    NodeStatus,
    ResearchNode,
)


ALLOWED_TRANSITIONS = {
    NodeStatus.PROPOSED: {
        NodeStatus.READY,
        NodeStatus.BLOCKED,
        NodeStatus.SUPERSEDED,
    },
    NodeStatus.READY: {
        NodeStatus.ACTIVE,
        NodeStatus.BLOCKED,
        NodeStatus.SUPERSEDED,
    },
    NodeStatus.ACTIVE: {
        NodeStatus.CONFIRMED,
        NodeStatus.REFUTED,
        NodeStatus.BLOCKED,
    },
    NodeStatus.CONFIRMED: {
        NodeStatus.INTEGRATED,
        NodeStatus.SUPERSEDED,
    },
    NodeStatus.REFUTED: {
        NodeStatus.SUPERSEDED,
    },
    NodeStatus.BLOCKED: {
        NodeStatus.READY,
        NodeStatus.SUPERSEDED,
    },
    NodeStatus.SUPERSEDED: set(),
    NodeStatus.INTEGRATED: set(),
}


class ResearchProgramGraph:
    def __init__(self, goal: HighLevelGoal) -> None:
        self.goal = goal
        self._nodes: Dict[str, ResearchNode] = {}
        self._statuses: Dict[str, NodeStatus] = {}

    @property
    def nodes(self) -> Mapping[str, ResearchNode]:
        return dict(self._nodes)

    @property
    def statuses(self) -> Mapping[str, NodeStatus]:
        return dict(self._statuses)

    def status(self, node_id: str) -> NodeStatus:
        try:
            return self._statuses[node_id]
        except KeyError:
            raise KeyError("unknown research node: %s" % node_id)

    def add_nodes(self, nodes: Iterable[ResearchNode]) -> None:
        additions = tuple(nodes)
        if not additions:
            raise ValueError("at least one research node is required")
        addition_map = {node.node_id: node for node in additions}
        if len(addition_map) != len(additions):
            raise ValueError("duplicate research nodes in addition")
        overlap = set(addition_map).intersection(self._nodes)
        if overlap:
            raise ValueError(
                "research nodes already exist: %s"
                % ", ".join(sorted(overlap))
            )
        if any(node.goal_id != self.goal.goal_id for node in additions):
            raise ValueError("research node belongs to another goal")

        available = set(self._nodes).union(addition_map)
        missing = {
            prerequisite
            for node in additions
            for prerequisite in node.prerequisite_ids
            if prerequisite not in available
        }
        if missing:
            raise ValueError(
                "missing prerequisites: %s"
                % ", ".join(sorted(missing))
            )

        combined = dict(self._nodes)
        combined.update(addition_map)
        self._assert_acyclic(combined)
        self._nodes.update(addition_map)
        self._statuses.update(
            {node_id: NodeStatus.PROPOSED for node_id in addition_map}
        )
        self._refresh_proposed_nodes()

    @staticmethod
    def _assert_acyclic(nodes: Mapping[str, ResearchNode]) -> None:
        visiting = set()
        visited = set()

        def visit(node_id: str) -> None:
            if node_id in visiting:
                raise ValueError("research graph must be acyclic")
            if node_id in visited:
                return
            visiting.add(node_id)
            for prerequisite in nodes[node_id].prerequisite_ids:
                visit(prerequisite)
            visiting.remove(node_id)
            visited.add(node_id)

        for candidate_id in nodes:
            visit(candidate_id)

    def _refresh_proposed_nodes(self) -> None:
        changed = True
        while changed:
            changed = False
            for node_id, node in self._nodes.items():
                if self._statuses[node_id] != NodeStatus.PROPOSED:
                    continue
                prerequisite_statuses = tuple(
                    self._statuses[prerequisite]
                    for prerequisite in node.prerequisite_ids
                )
                if any(
                    status
                    in (
                        NodeStatus.REFUTED,
                        NodeStatus.BLOCKED,
                        NodeStatus.SUPERSEDED,
                    )
                    for status in prerequisite_statuses
                ):
                    self._statuses[node_id] = NodeStatus.BLOCKED
                    changed = True
                elif all(
                    status
                    in (
                        NodeStatus.CONFIRMED,
                        NodeStatus.INTEGRATED,
                    )
                    for status in prerequisite_statuses
                ):
                    self._statuses[node_id] = NodeStatus.READY
                    changed = True

    def transition(
        self,
        node_id: str,
        new_status: NodeStatus,
    ) -> None:
        old_status = self.status(node_id)
        if new_status not in ALLOWED_TRANSITIONS[old_status]:
            raise ValueError(
                "illegal node transition: %s -> %s"
                % (old_status.value, new_status.value)
            )
        if new_status == NodeStatus.READY:
            prerequisites_ready = all(
                self.status(prerequisite)
                in (NodeStatus.CONFIRMED, NodeStatus.INTEGRATED)
                for prerequisite in self._nodes[node_id].prerequisite_ids
            )
            if not prerequisites_ready:
                raise ValueError(
                    "node cannot be ready before its prerequisites"
                )
        self._statuses[node_id] = new_status
        if new_status in (
            NodeStatus.CONFIRMED,
            NodeStatus.REFUTED,
            NodeStatus.BLOCKED,
            NodeStatus.SUPERSEDED,
            NodeStatus.INTEGRATED,
        ):
            self._refresh_proposed_nodes()

    def frontier(self) -> Tuple[ResearchNode, ...]:
        return tuple(
            self._nodes[node_id]
            for node_id in sorted(self._nodes)
            if self._statuses[node_id] == NodeStatus.READY
        )

    def active(self) -> Tuple[ResearchNode, ...]:
        return tuple(
            self._nodes[node_id]
            for node_id in sorted(self._nodes)
            if self._statuses[node_id] == NodeStatus.ACTIVE
        )

    def unresolved_critical_node_ids(self) -> Tuple[str, ...]:
        return tuple(
            node_id
            for node_id, node in sorted(self._nodes.items())
            if node.critical
            and self._statuses[node_id]
            not in (NodeStatus.CONFIRMED, NodeStatus.INTEGRATED)
        )

    def restore_statuses(
        self,
        statuses: Mapping[str, NodeStatus],
    ) -> None:
        if set(statuses) != set(self._nodes):
            raise ValueError(
                "restored graph statuses must cover every research node"
            )
        for node_id, status in statuses.items():
            if not isinstance(status, NodeStatus):
                raise ValueError("restored graph status is invalid")
            node = self._nodes[node_id]
            if status in (NodeStatus.READY, NodeStatus.ACTIVE):
                if not all(
                    statuses[prerequisite]
                    in (NodeStatus.CONFIRMED, NodeStatus.INTEGRATED)
                    for prerequisite in node.prerequisite_ids
                ):
                    raise ValueError(
                        "restored ready/active node has unmet prerequisites"
                    )
        self._statuses = dict(statuses)

    def as_dict(self) -> Dict[str, object]:
        return {
            "goal_id": self.goal.goal_id,
            "nodes": [
                {
                    "specification": node.as_dict(),
                    "status": self._statuses[node_id].value,
                }
                for node_id, node in sorted(self._nodes.items())
            ],
            "frontier_node_ids": [
                node.node_id for node in self.frontier()
            ],
            "active_node_ids": [node.node_id for node in self.active()],
            "unresolved_critical_node_ids": list(
                self.unresolved_critical_node_ids()
            ),
        }
