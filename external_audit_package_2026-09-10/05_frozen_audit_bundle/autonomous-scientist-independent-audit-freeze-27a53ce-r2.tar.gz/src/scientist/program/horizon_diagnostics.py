from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest


HORIZON_DIAGNOSTICS_VERSION = "horizon-diagnostics-v1"


def _assert_unique(values: Tuple[str, ...], label: str) -> None:
    if not values or not all(values) or len(set(values)) != len(values):
        raise ValueError("%s must be non-empty and unique" % label)


def _assert_finite_mapping(values: Mapping[str, float], label: str) -> None:
    if not values or not all(values):
        raise ValueError("%s must not be empty" % label)
    if not all(math.isfinite(float(value)) for value in values.values()):
        raise ValueError("%s must be finite" % label)


def _assert_identity(
    value: Mapping[str, Any], field: str, observed: str
) -> None:
    supplied = value.get(field)
    if supplied is not None and str(supplied) != observed:
        raise ValueError("%s identity mismatch" % field)


class HorizonKind(str, Enum):
    DEVELOPMENT = "development"
    LOCAL_VALIDATION = "local_validation"
    TRANSFER = "transfer"
    TERMINAL = "terminal"


@dataclass(frozen=True)
class EvaluationHorizon:
    """One preregistered level of scientific realism."""

    node_id: str
    name: str
    rank: int
    kind: HorizonKind
    partition_ref: str
    task_family_ref: str
    model_family_ref: str
    metric_names: Tuple[str, ...]
    compute_budget: float
    sealed: bool
    registrar_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.name,
                self.partition_ref,
                self.task_family_ref,
                self.model_family_ref,
                self.registrar_ref,
            )
        ):
            raise ValueError("evaluation horizon is incomplete")
        if self.rank < 0 or self.compute_budget <= 0:
            raise ValueError("horizon rank and compute budget are invalid")
        _assert_unique(self.metric_names, "horizon metrics")
        if self.kind == HorizonKind.TERMINAL and not self.sealed:
            raise ValueError("terminal horizons must be sealed before use")

    @property
    def horizon_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "node_id": self.node_id,
            "name": self.name,
            "rank": self.rank,
            "kind": self.kind.value,
            "partition_ref": self.partition_ref,
            "task_family_ref": self.task_family_ref,
            "model_family_ref": self.model_family_ref,
            "metric_names": list(self.metric_names),
            "compute_budget": self.compute_budget,
            "sealed": self.sealed,
            "registrar_ref": self.registrar_ref,
        }
        if include_id:
            value["horizon_id"] = self.horizon_id
        return value


@dataclass(frozen=True)
class HorizonPrediction:
    """A candidate's quantitative commitment before a horizon is opened."""

    node_id: str
    hypothesis_id: str
    candidate_id: str
    horizon_id: str
    expected_metrics: Mapping[str, float]
    qualitative_predictions: Tuple[str, ...]
    boundary_conditions: Tuple[str, ...]
    predictor_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.hypothesis_id,
                self.candidate_id,
                self.horizon_id,
                self.predictor_ref,
            )
        ):
            raise ValueError("horizon prediction is incomplete")
        _assert_finite_mapping(self.expected_metrics, "expected metrics")
        _assert_unique(
            self.qualitative_predictions, "qualitative predictions"
        )
        _assert_unique(self.boundary_conditions, "boundary conditions")

    @property
    def prediction_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "node_id": self.node_id,
            "hypothesis_id": self.hypothesis_id,
            "candidate_id": self.candidate_id,
            "horizon_id": self.horizon_id,
            "expected_metrics": dict(sorted(self.expected_metrics.items())),
            "qualitative_predictions": list(self.qualitative_predictions),
            "boundary_conditions": list(self.boundary_conditions),
            "predictor_ref": self.predictor_ref,
        }
        if include_id:
            value["prediction_id"] = self.prediction_id
        return value


@dataclass(frozen=True)
class HorizonOutcome:
    """Independently evaluated evidence at one registered horizon."""

    node_id: str
    hypothesis_id: str
    candidate_id: str
    horizon_id: str
    prediction_id: str
    observed_metrics: Mapping[str, float]
    evidence_ids: Tuple[str, ...]
    independent_unit_ids: Tuple[str, ...]
    compute_spent: float
    evaluator_ref: str
    verifier_ref: str
    exposure_id: str | None = None

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.hypothesis_id,
                self.candidate_id,
                self.horizon_id,
                self.prediction_id,
                self.evaluator_ref,
                self.verifier_ref,
            )
        ):
            raise ValueError("horizon outcome is incomplete")
        _assert_finite_mapping(self.observed_metrics, "observed metrics")
        _assert_unique(self.evidence_ids, "outcome evidence IDs")
        _assert_unique(
            self.independent_unit_ids, "outcome independent units"
        )
        if self.compute_spent < 0:
            raise ValueError("outcome compute must be non-negative")

    @property
    def outcome_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "node_id": self.node_id,
            "hypothesis_id": self.hypothesis_id,
            "candidate_id": self.candidate_id,
            "horizon_id": self.horizon_id,
            "prediction_id": self.prediction_id,
            "observed_metrics": dict(sorted(self.observed_metrics.items())),
            "evidence_ids": list(self.evidence_ids),
            "independent_unit_ids": list(self.independent_unit_ids),
            "compute_spent": self.compute_spent,
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "exposure_id": self.exposure_id,
        }
        if include_id:
            value["outcome_id"] = self.outcome_id
        return value


@dataclass(frozen=True)
class HorizonContrast:
    """The same hypothesis observed at a cheap and a later horizon."""

    node_id: str
    hypothesis_id: str
    candidate_id: str
    local_outcome_id: str
    terminal_outcome_id: str
    metric_name: str
    local_effect: float
    terminal_effect: float
    first_divergence_horizon_id: str
    mediator_observation: str
    matched_context: str
    analyst_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.hypothesis_id,
                self.candidate_id,
                self.local_outcome_id,
                self.terminal_outcome_id,
                self.metric_name,
                self.first_divergence_horizon_id,
                self.mediator_observation,
                self.matched_context,
                self.analyst_ref,
            )
        ):
            raise ValueError("horizon contrast is incomplete")
        if self.local_outcome_id == self.terminal_outcome_id:
            raise ValueError("horizon contrast requires two outcomes")
        if not all(
            math.isfinite(value)
            for value in (self.local_effect, self.terminal_effect)
        ):
            raise ValueError("horizon contrast effects must be finite")

    @property
    def transport_failed(self) -> bool:
        return self.local_effect > 0.0 and self.terminal_effect <= 0.0

    @property
    def transferred(self) -> bool:
        return self.local_effect > 0.0 and self.terminal_effect > 0.0

    @property
    def contrast_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "node_id": self.node_id,
            "hypothesis_id": self.hypothesis_id,
            "candidate_id": self.candidate_id,
            "local_outcome_id": self.local_outcome_id,
            "terminal_outcome_id": self.terminal_outcome_id,
            "metric_name": self.metric_name,
            "local_effect": self.local_effect,
            "terminal_effect": self.terminal_effect,
            "first_divergence_horizon_id": (
                self.first_divergence_horizon_id
            ),
            "mediator_observation": self.mediator_observation,
            "matched_context": self.matched_context,
            "transport_failed": self.transport_failed,
            "transferred": self.transferred,
            "analyst_ref": self.analyst_ref,
        }
        if include_id:
            value["contrast_id"] = self.contrast_id
        return value


@dataclass(frozen=True)
class HorizonFailureDossier:
    """Matched successes and failures used to diagnose missing concepts."""

    node_id: str
    representation_id: str
    contrast_ids: Tuple[str, ...]
    existing_descriptors: Tuple[str, ...]
    failure_clusters: Tuple[str, ...]
    source_artifact_ids: Tuple[str, ...]
    builder_ref: str

    def __post_init__(self) -> None:
        if not all((self.node_id, self.representation_id, self.builder_ref)):
            raise ValueError("horizon-failure dossier is incomplete")
        _assert_unique(self.contrast_ids, "dossier contrasts")
        if len(self.contrast_ids) < 2:
            raise ValueError("dossier requires at least two matched contrasts")
        _assert_unique(self.existing_descriptors, "existing descriptors")
        _assert_unique(self.failure_clusters, "failure clusters")
        _assert_unique(self.source_artifact_ids, "dossier source artifacts")

    @property
    def dossier_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "node_id": self.node_id,
            "representation_id": self.representation_id,
            "contrast_ids": list(self.contrast_ids),
            "existing_descriptors": list(self.existing_descriptors),
            "failure_clusters": list(self.failure_clusters),
            "source_artifact_ids": list(self.source_artifact_ids),
            "builder_ref": self.builder_ref,
        }
        if include_id:
            value["dossier_id"] = self.dossier_id
        return value


@dataclass(frozen=True)
class RepresentationAdequacyAssessment:
    """Held-out test of whether the current concepts explain transfer."""

    dossier_id: str
    representation_id: str
    development_contrast_ids: Tuple[str, ...]
    validation_contrast_ids: Tuple[str, ...]
    baseline_predictive_score: float
    required_predictive_score: float
    unexplained_opposite_outcome_pairs: int
    minimum_unexplained_pairs: int
    evidence_ids: Tuple[str, ...]
    assessor_ref: str

    def __post_init__(self) -> None:
        if not all((self.dossier_id, self.representation_id, self.assessor_ref)):
            raise ValueError("representation adequacy assessment is incomplete")
        _assert_unique(
            self.development_contrast_ids, "adequacy development contrasts"
        )
        _assert_unique(
            self.validation_contrast_ids, "adequacy validation contrasts"
        )
        if set(self.development_contrast_ids).intersection(
            self.validation_contrast_ids
        ):
            raise ValueError("adequacy development and validation must be disjoint")
        if not 0.0 <= self.baseline_predictive_score <= 1.0:
            raise ValueError("baseline predictive score must be in [0, 1]")
        if not 0.0 < self.required_predictive_score <= 1.0:
            raise ValueError("required predictive score must be in (0, 1]")
        if min(
            self.unexplained_opposite_outcome_pairs,
            self.minimum_unexplained_pairs,
        ) < 0:
            raise ValueError("unexplained-pair counts cannot be negative")
        _assert_unique(self.evidence_ids, "adequacy evidence IDs")

    @property
    def representation_insufficient(self) -> bool:
        return (
            self.baseline_predictive_score < self.required_predictive_score
            and self.unexplained_opposite_outcome_pairs
            >= self.minimum_unexplained_pairs
            and self.minimum_unexplained_pairs > 0
        )

    @property
    def assessment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "dossier_id": self.dossier_id,
            "representation_id": self.representation_id,
            "development_contrast_ids": list(
                self.development_contrast_ids
            ),
            "validation_contrast_ids": list(self.validation_contrast_ids),
            "baseline_predictive_score": self.baseline_predictive_score,
            "required_predictive_score": self.required_predictive_score,
            "unexplained_opposite_outcome_pairs": (
                self.unexplained_opposite_outcome_pairs
            ),
            "minimum_unexplained_pairs": self.minimum_unexplained_pairs,
            "representation_insufficient": self.representation_insufficient,
            "evidence_ids": list(self.evidence_ids),
            "assessor_ref": self.assessor_ref,
        }
        if include_id:
            value["assessment_id"] = self.assessment_id
        return value


@dataclass(frozen=True)
class LatentConceptHypothesis:
    """A falsifiable concept proposed to explain a contrast dossier."""

    dossier_id: str
    adequacy_assessment_id: str
    name: str
    definition: str
    input_primitives: Tuple[str, ...]
    computation: str
    causal_explanation: str
    distinguishing_predictions: Tuple[str, ...]
    boundary_conditions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    required_predictive_score: float
    minimum_predictive_improvement: float
    prospective_contrast_count: int
    validation_protocol_ref: str
    proposer_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.dossier_id,
                self.adequacy_assessment_id,
                self.name,
                self.definition,
                self.computation,
                self.causal_explanation,
                self.validation_protocol_ref,
                self.proposer_ref,
            )
        ):
            raise ValueError("latent concept hypothesis is incomplete")
        _assert_unique(self.input_primitives, "concept input primitives")
        _assert_unique(
            self.distinguishing_predictions, "concept predictions"
        )
        _assert_unique(self.boundary_conditions, "concept boundaries")
        _assert_unique(
            self.falsification_conditions, "concept falsification conditions"
        )
        if len(self.distinguishing_predictions) < 2:
            raise ValueError("latent concept requires two predictions")
        if len(self.falsification_conditions) < 2:
            raise ValueError("latent concept requires two falsifiers")
        if not 0.0 < self.required_predictive_score <= 1.0:
            raise ValueError("concept predictive floor must be in (0, 1]")
        if not 0.0 < self.minimum_predictive_improvement <= 1.0:
            raise ValueError("concept minimum improvement must be in (0, 1]")
        if self.prospective_contrast_count < 2:
            raise ValueError("concept validation requires at least two contrasts")

    @property
    def concept_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "dossier_id": self.dossier_id,
            "adequacy_assessment_id": self.adequacy_assessment_id,
            "name": self.name,
            "definition": self.definition,
            "input_primitives": list(self.input_primitives),
            "computation": self.computation,
            "causal_explanation": self.causal_explanation,
            "distinguishing_predictions": list(
                self.distinguishing_predictions
            ),
            "boundary_conditions": list(self.boundary_conditions),
            "falsification_conditions": list(self.falsification_conditions),
            "required_predictive_score": self.required_predictive_score,
            "minimum_predictive_improvement": (
                self.minimum_predictive_improvement
            ),
            "prospective_contrast_count": self.prospective_contrast_count,
            "validation_protocol_ref": self.validation_protocol_ref,
            "proposer_ref": self.proposer_ref,
        }
        if include_id:
            value["concept_id"] = self.concept_id
        return value


@dataclass(frozen=True)
class ConceptValidation:
    """Prospective test that a concept adds held-out predictive information.

    ``development_contrast_ids`` are the contrasts available when the concept
    is invented.  ``validation_contrast_ids`` must be newly collected after
    concept registration; the control plane enforces that temporal quarantine.
    """

    concept_id: str
    adequacy_assessment_id: str
    development_contrast_ids: Tuple[str, ...]
    validation_contrast_ids: Tuple[str, ...]
    baseline_predictive_score: float
    augmented_predictive_score: float
    required_predictive_score: float
    minimum_improvement: float
    evidence_ids: Tuple[str, ...]
    evaluator_ref: str

    def __post_init__(self) -> None:
        if not all((self.concept_id, self.adequacy_assessment_id, self.evaluator_ref)):
            raise ValueError("concept validation is incomplete")
        _assert_unique(
            self.development_contrast_ids, "concept development contrasts"
        )
        _assert_unique(
            self.validation_contrast_ids, "concept validation contrasts"
        )
        if set(self.development_contrast_ids).intersection(
            self.validation_contrast_ids
        ):
            raise ValueError("concept development and validation must be disjoint")
        if not all(
            0.0 <= value <= 1.0
            for value in (
                self.baseline_predictive_score,
                self.augmented_predictive_score,
                self.required_predictive_score,
            )
        ):
            raise ValueError("concept predictive scores must be in [0, 1]")
        if self.required_predictive_score <= 0.0:
            raise ValueError("required predictive score must be in (0, 1]")
        if not 0.0 < self.minimum_improvement <= 1.0:
            raise ValueError("minimum concept improvement must be in (0, 1]")
        _assert_unique(self.evidence_ids, "concept validation evidence IDs")

    @property
    def predictive_improvement(self) -> float:
        return self.augmented_predictive_score - self.baseline_predictive_score

    @property
    def passed(self) -> bool:
        return (
            self.predictive_improvement >= self.minimum_improvement
            and self.augmented_predictive_score
            >= self.required_predictive_score
        )

    @property
    def validation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "concept_id": self.concept_id,
            "adequacy_assessment_id": self.adequacy_assessment_id,
            "development_contrast_ids": list(
                self.development_contrast_ids
            ),
            "validation_contrast_ids": list(self.validation_contrast_ids),
            "baseline_predictive_score": self.baseline_predictive_score,
            "augmented_predictive_score": self.augmented_predictive_score,
            "required_predictive_score": self.required_predictive_score,
            "minimum_improvement": self.minimum_improvement,
            "predictive_improvement": self.predictive_improvement,
            "passed": self.passed,
            "evidence_ids": list(self.evidence_ids),
            "evaluator_ref": self.evaluator_ref,
        }
        if include_id:
            value["validation_id"] = self.validation_id
        return value


@dataclass(frozen=True)
class ConceptGroundedGeneratorRevision:
    """Proof that a validated concept changed hypothesis generation."""

    concept_validation_id: str
    prior_representation_id: str
    revised_representation_id: str
    prior_generator_ref: str
    revised_generator_ref: str
    generated_hypothesis_ids: Tuple[str, ...]
    behavior_fingerprints: Tuple[str, ...]
    probe_problem_ids: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    reviser_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.concept_validation_id,
                self.prior_representation_id,
                self.revised_representation_id,
                self.prior_generator_ref,
                self.revised_generator_ref,
                self.reviser_ref,
            )
        ):
            raise ValueError("generator revision is incomplete")
        if self.prior_representation_id == self.revised_representation_id:
            raise ValueError("generator revision must change representation")
        if self.prior_generator_ref == self.revised_generator_ref:
            raise ValueError("generator revision must change generator identity")
        _assert_unique(
            self.generated_hypothesis_ids, "generated hypothesis IDs"
        )
        _assert_unique(self.behavior_fingerprints, "behavior fingerprints")
        _assert_unique(self.probe_problem_ids, "generator probe problems")
        _assert_unique(self.evidence_ids, "generator revision evidence IDs")
        if len(self.generated_hypothesis_ids) < 2:
            raise ValueError("generator revision needs at least two hypotheses")
        if len(self.behavior_fingerprints) < 2:
            raise ValueError("generator revision did not change behavior")

    @property
    def revision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HORIZON_DIAGNOSTICS_VERSION,
            "concept_validation_id": self.concept_validation_id,
            "prior_representation_id": self.prior_representation_id,
            "revised_representation_id": self.revised_representation_id,
            "prior_generator_ref": self.prior_generator_ref,
            "revised_generator_ref": self.revised_generator_ref,
            "generated_hypothesis_ids": list(self.generated_hypothesis_ids),
            "behavior_fingerprints": list(self.behavior_fingerprints),
            "probe_problem_ids": list(self.probe_problem_ids),
            "evidence_ids": list(self.evidence_ids),
            "reviser_ref": self.reviser_ref,
        }
        if include_id:
            value["revision_id"] = self.revision_id
        return value


def horizon_from_dict(value: Mapping[str, Any]) -> EvaluationHorizon:
    result = EvaluationHorizon(
        node_id=str(value["node_id"]),
        name=str(value["name"]),
        rank=int(value["rank"]),
        kind=HorizonKind(value["kind"]),
        partition_ref=str(value["partition_ref"]),
        task_family_ref=str(value["task_family_ref"]),
        model_family_ref=str(value["model_family_ref"]),
        metric_names=tuple(str(item) for item in value["metric_names"]),
        compute_budget=float(value["compute_budget"]),
        sealed=bool(value["sealed"]),
        registrar_ref=str(value["registrar_ref"]),
    )
    _assert_identity(value, "horizon_id", result.horizon_id)
    return result


def prediction_from_dict(value: Mapping[str, Any]) -> HorizonPrediction:
    result = HorizonPrediction(
        node_id=str(value["node_id"]),
        hypothesis_id=str(value["hypothesis_id"]),
        candidate_id=str(value["candidate_id"]),
        horizon_id=str(value["horizon_id"]),
        expected_metrics={
            str(name): float(metric)
            for name, metric in value["expected_metrics"].items()
        },
        qualitative_predictions=tuple(
            str(item) for item in value["qualitative_predictions"]
        ),
        boundary_conditions=tuple(
            str(item) for item in value["boundary_conditions"]
        ),
        predictor_ref=str(value["predictor_ref"]),
    )
    _assert_identity(value, "prediction_id", result.prediction_id)
    return result


def outcome_from_dict(value: Mapping[str, Any]) -> HorizonOutcome:
    result = HorizonOutcome(
        node_id=str(value["node_id"]),
        hypothesis_id=str(value["hypothesis_id"]),
        candidate_id=str(value["candidate_id"]),
        horizon_id=str(value["horizon_id"]),
        prediction_id=str(value["prediction_id"]),
        observed_metrics={
            str(name): float(metric)
            for name, metric in value["observed_metrics"].items()
        },
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        independent_unit_ids=tuple(
            str(item) for item in value["independent_unit_ids"]
        ),
        compute_spent=float(value["compute_spent"]),
        evaluator_ref=str(value["evaluator_ref"]),
        verifier_ref=str(value["verifier_ref"]),
        exposure_id=(
            None
            if value.get("exposure_id") is None
            else str(value["exposure_id"])
        ),
    )
    _assert_identity(value, "outcome_id", result.outcome_id)
    return result


def contrast_from_dict(value: Mapping[str, Any]) -> HorizonContrast:
    result = HorizonContrast(
        node_id=str(value["node_id"]),
        hypothesis_id=str(value["hypothesis_id"]),
        candidate_id=str(value["candidate_id"]),
        local_outcome_id=str(value["local_outcome_id"]),
        terminal_outcome_id=str(value["terminal_outcome_id"]),
        metric_name=str(value["metric_name"]),
        local_effect=float(value["local_effect"]),
        terminal_effect=float(value["terminal_effect"]),
        first_divergence_horizon_id=str(
            value["first_divergence_horizon_id"]
        ),
        mediator_observation=str(value["mediator_observation"]),
        matched_context=str(value["matched_context"]),
        analyst_ref=str(value["analyst_ref"]),
    )
    _assert_identity(value, "contrast_id", result.contrast_id)
    return result


def dossier_from_dict(value: Mapping[str, Any]) -> HorizonFailureDossier:
    result = HorizonFailureDossier(
        node_id=str(value["node_id"]),
        representation_id=str(value["representation_id"]),
        contrast_ids=tuple(str(item) for item in value["contrast_ids"]),
        existing_descriptors=tuple(
            str(item) for item in value["existing_descriptors"]
        ),
        failure_clusters=tuple(
            str(item) for item in value["failure_clusters"]
        ),
        source_artifact_ids=tuple(
            str(item) for item in value["source_artifact_ids"]
        ),
        builder_ref=str(value["builder_ref"]),
    )
    _assert_identity(value, "dossier_id", result.dossier_id)
    return result


def adequacy_from_dict(
    value: Mapping[str, Any],
) -> RepresentationAdequacyAssessment:
    result = RepresentationAdequacyAssessment(
        dossier_id=str(value["dossier_id"]),
        representation_id=str(value["representation_id"]),
        development_contrast_ids=tuple(
            str(item) for item in value["development_contrast_ids"]
        ),
        validation_contrast_ids=tuple(
            str(item) for item in value["validation_contrast_ids"]
        ),
        baseline_predictive_score=float(value["baseline_predictive_score"]),
        required_predictive_score=float(value["required_predictive_score"]),
        unexplained_opposite_outcome_pairs=int(
            value["unexplained_opposite_outcome_pairs"]
        ),
        minimum_unexplained_pairs=int(value["minimum_unexplained_pairs"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        assessor_ref=str(value["assessor_ref"]),
    )
    _assert_identity(value, "assessment_id", result.assessment_id)
    return result


def concept_from_dict(value: Mapping[str, Any]) -> LatentConceptHypothesis:
    result = LatentConceptHypothesis(
        dossier_id=str(value["dossier_id"]),
        adequacy_assessment_id=str(value["adequacy_assessment_id"]),
        name=str(value["name"]),
        definition=str(value["definition"]),
        input_primitives=tuple(
            str(item) for item in value["input_primitives"]
        ),
        computation=str(value["computation"]),
        causal_explanation=str(value["causal_explanation"]),
        distinguishing_predictions=tuple(
            str(item) for item in value["distinguishing_predictions"]
        ),
        boundary_conditions=tuple(
            str(item) for item in value["boundary_conditions"]
        ),
        falsification_conditions=tuple(
            str(item) for item in value["falsification_conditions"]
        ),
        required_predictive_score=float(value["required_predictive_score"]),
        minimum_predictive_improvement=float(
            value["minimum_predictive_improvement"]
        ),
        prospective_contrast_count=int(value["prospective_contrast_count"]),
        validation_protocol_ref=str(value["validation_protocol_ref"]),
        proposer_ref=str(value["proposer_ref"]),
    )
    _assert_identity(value, "concept_id", result.concept_id)
    return result


def concept_validation_from_dict(
    value: Mapping[str, Any],
) -> ConceptValidation:
    result = ConceptValidation(
        concept_id=str(value["concept_id"]),
        adequacy_assessment_id=str(value["adequacy_assessment_id"]),
        development_contrast_ids=tuple(
            str(item) for item in value["development_contrast_ids"]
        ),
        validation_contrast_ids=tuple(
            str(item) for item in value["validation_contrast_ids"]
        ),
        baseline_predictive_score=float(value["baseline_predictive_score"]),
        augmented_predictive_score=float(value["augmented_predictive_score"]),
        required_predictive_score=float(value["required_predictive_score"]),
        minimum_improvement=float(value["minimum_improvement"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        evaluator_ref=str(value["evaluator_ref"]),
    )
    _assert_identity(value, "validation_id", result.validation_id)
    return result


def generator_revision_from_dict(
    value: Mapping[str, Any],
) -> ConceptGroundedGeneratorRevision:
    result = ConceptGroundedGeneratorRevision(
        concept_validation_id=str(value["concept_validation_id"]),
        prior_representation_id=str(value["prior_representation_id"]),
        revised_representation_id=str(value["revised_representation_id"]),
        prior_generator_ref=str(value["prior_generator_ref"]),
        revised_generator_ref=str(value["revised_generator_ref"]),
        generated_hypothesis_ids=tuple(
            str(item) for item in value["generated_hypothesis_ids"]
        ),
        behavior_fingerprints=tuple(
            str(item) for item in value["behavior_fingerprints"]
        ),
        probe_problem_ids=tuple(
            str(item) for item in value["probe_problem_ids"]
        ),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        reviser_ref=str(value["reviser_ref"]),
    )
    _assert_identity(value, "revision_id", result.revision_id)
    return result
