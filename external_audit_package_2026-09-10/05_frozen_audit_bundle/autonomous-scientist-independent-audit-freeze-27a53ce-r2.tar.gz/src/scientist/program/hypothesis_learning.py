from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.program.executable_hypothesis import HypothesisDiagnosticResult


HYPOTHESIS_LEARNING_VERSION = "hypothesis-learning-v2-first-principles"
RISK_BUDGETED_DISCOVERY_VERSION = "risk-budgeted-discovery-v2-objective"


@dataclass(frozen=True)
class FirstPrinciplesDerivation:
    """Domain-neutral ideal-to-executable derivation for a research proposal.

    This contract records why an approximation should advance the objective.
    It deliberately contains no novelty or incumbent-distance requirement: an
    honest derivation may rediscover a known mechanism.
    """

    objective: str
    decision_variables: Tuple[str, ...]
    governing_constraints: Tuple[str, ...]
    ideal_solution: str
    tractable_approximation: str
    approximation_gap: str
    oracle_type: str
    oracle_scope: str
    oracle_procedure: str
    counterexample_families: Tuple[str, ...]
    revision_trigger: str
    alternative_approximations: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        required = (
            self.objective,
            self.decision_variables,
            self.governing_constraints,
            self.ideal_solution,
            self.tractable_approximation,
            self.approximation_gap,
            self.oracle_type,
            self.oracle_scope,
            self.oracle_procedure,
            self.counterexample_families,
            self.revision_trigger,
        )
        if not all(required):
            raise ValueError("first-principles derivation is incomplete")
        if len(self.governing_constraints) < 2:
            raise ValueError(
                "first-principles derivation needs at least two constraints"
            )
        if len(self.counterexample_families) < 2:
            raise ValueError(
                "first-principles derivation needs two counterexample families"
            )
        if self.alternative_approximations and len(
            self.alternative_approximations
        ) < 2:
            raise ValueError(
                "first-principles derivation needs at least two alternative "
                "approximations when alternatives are registered"
            )
        if self.oracle_type not in {"exact", "analytic", "simulation"}:
            raise ValueError(
                "validation oracle must be exact, analytic, or simulation"
            )
        for values, label in (
            (self.decision_variables, "decision variables"),
            (self.governing_constraints, "governing constraints"),
            (self.counterexample_families, "counterexample families"),
            (self.alternative_approximations, "alternative approximations"),
        ):
            if len(set(values)) != len(values):
                raise ValueError("first-principles %s must be unique" % label)

    @property
    def derivation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "contract_version": HYPOTHESIS_LEARNING_VERSION,
            "objective": self.objective,
            "decision_variables": list(self.decision_variables),
            "governing_constraints": list(self.governing_constraints),
            "ideal_solution": self.ideal_solution,
            "tractable_approximation": self.tractable_approximation,
            "approximation_gap": self.approximation_gap,
            "oracle_type": self.oracle_type,
            "oracle_scope": self.oracle_scope,
            "oracle_procedure": self.oracle_procedure,
            "counterexample_families": list(self.counterexample_families),
            "revision_trigger": self.revision_trigger,
        }
        if self.alternative_approximations:
            value["alternative_approximations"] = list(
                self.alternative_approximations
            )
        if include_id:
            value["derivation_id"] = self.derivation_id
        return value

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
    ) -> "FirstPrinciplesDerivation":
        derivation = cls(
            objective=str(value["objective"]),
            decision_variables=tuple(
                str(item) for item in value["decision_variables"]
            ),
            governing_constraints=tuple(
                str(item) for item in value["governing_constraints"]
            ),
            ideal_solution=str(value["ideal_solution"]),
            tractable_approximation=str(value["tractable_approximation"]),
            approximation_gap=str(value["approximation_gap"]),
            oracle_type=str(value["oracle_type"]),
            oracle_scope=str(value["oracle_scope"]),
            oracle_procedure=str(value["oracle_procedure"]),
            counterexample_families=tuple(
                str(item) for item in value["counterexample_families"]
            ),
            revision_trigger=str(value["revision_trigger"]),
            alternative_approximations=tuple(
                str(item)
                for item in value.get("alternative_approximations", ())
            ),
        )
        supplied = value.get("derivation_id")
        if supplied is not None and str(supplied) != derivation.derivation_id:
            raise ValueError("first-principles derivation identity mismatch")
        return derivation


class HypothesisFailureKind(str, Enum):
    """What an experiment actually invalidated."""

    NOT_EVALUATED = "not_evaluated"
    COMPILATION = "compilation_failure"
    MEDIATOR = "mediator_failure"
    CAUSAL = "causal_failure"
    TRANSPORT = "transport_failure"
    PRIOR_ART = "prior_art_failure"
    UNCERTAINTY = "uncertainty_failure"
    PASSED = "passed"


@dataclass(frozen=True)
class MechanismDistanceAssessment:
    """Structural distance from the incumbent's decision process.

    The assessment deliberately ignores prose, source domain, coefficient
    magnitude, and executable ancestry.  A candidate is distant only when it
    changes the decision topology or introduces a new decision primitive.
    """

    candidate_id: str
    candidate_topology: str
    incumbent_topology: str
    incumbent_blind: bool
    new_decision_primitives: Tuple[str, ...]
    structural_distance: int
    minimum_structural_distance: int
    require_incumbent_blind: bool
    require_new_decision_primitive: bool
    assessor_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.candidate_id,
                self.candidate_topology,
                self.incumbent_topology,
                self.assessor_ref,
            )
        ):
            raise ValueError("mechanism-distance assessment is incomplete")
        if not 0 <= self.structural_distance <= 4:
            raise ValueError("structural distance must be in [0, 4]")
        if not 0 <= self.minimum_structural_distance <= 4:
            raise ValueError("minimum structural distance must be in [0, 4]")
        if len(set(self.new_decision_primitives)) != len(
            self.new_decision_primitives
        ):
            raise ValueError("decision primitives must be unique")

    @property
    def failure_reasons(self) -> Tuple[str, ...]:
        reasons = []
        if self.structural_distance < self.minimum_structural_distance:
            reasons.append("insufficient_structural_distance")
        if self.require_incumbent_blind and not self.incumbent_blind:
            reasons.append("incumbent_dependency")
        if (
            self.require_new_decision_primitive
            and not self.new_decision_primitives
        ):
            reasons.append("no_new_decision_primitive")
        return tuple(reasons)

    @property
    def passed(self) -> bool:
        return not self.failure_reasons

    @property
    def assessment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": RISK_BUDGETED_DISCOVERY_VERSION,
            "candidate_id": self.candidate_id,
            "candidate_topology": self.candidate_topology,
            "incumbent_topology": self.incumbent_topology,
            "incumbent_blind": self.incumbent_blind,
            "new_decision_primitives": list(
                self.new_decision_primitives
            ),
            "structural_distance": self.structural_distance,
            "minimum_structural_distance": (
                self.minimum_structural_distance
            ),
            "require_incumbent_blind": self.require_incumbent_blind,
            "require_new_decision_primitive": (
                self.require_new_decision_primitive
            ),
            "passed": self.passed,
            "failure_reasons": list(self.failure_reasons),
            "assessor_ref": self.assessor_ref,
        }
        if include_id:
            value["assessment_id"] = self.assessment_id
        return value


@dataclass(frozen=True)
class RiskBudgetedDiscoveryAssessment:
    """A search-allocation score that can never authorize a truth claim."""

    mechanism_distance: MechanismDistanceAssessment
    behavior_distance: float
    intervention_rate: float
    upside_rate: float
    risk_utilization: float
    catastrophic_excess: float
    within_risk_budget: bool
    scorer_ref: str

    def __post_init__(self) -> None:
        if not self.scorer_ref:
            raise ValueError("discovery assessment requires a scorer")
        bounded = (
            self.behavior_distance,
            self.intervention_rate,
            self.upside_rate,
            self.risk_utilization,
        )
        if any(not 0.0 <= value <= 1.0 for value in bounded):
            raise ValueError("discovery fractions must be in [0, 1]")
        if self.catastrophic_excess < 0.0:
            raise ValueError("catastrophic excess cannot be negative")

    @property
    def discovery_score(self) -> float:
        # Distance and intervention volume are diagnostics, not evidence that
        # a candidate advances the objective.  Reward demonstrated upside and
        # unused risk headroom; penalize catastrophic excess.
        return (
            0.75 * self.upside_rate
            + 0.25 * (1.0 - self.risk_utilization)
            - 0.50 * self.catastrophic_excess
        )

    @property
    def admitted_for_exploration(self) -> bool:
        return (
            self.mechanism_distance.passed
            and self.within_risk_budget
        )

    @property
    def assessment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": RISK_BUDGETED_DISCOVERY_VERSION,
            "mechanism_distance": self.mechanism_distance.as_dict(),
            "behavior_distance": self.behavior_distance,
            "intervention_rate": self.intervention_rate,
            "upside_rate": self.upside_rate,
            "risk_utilization": self.risk_utilization,
            "catastrophic_excess": self.catastrophic_excess,
            "within_risk_budget": self.within_risk_budget,
            "admitted_for_exploration": self.admitted_for_exploration,
            "discovery_score": self.discovery_score,
            "claim_authority": "none",
            "scorer_ref": self.scorer_ref,
        }
        if include_id:
            value["assessment_id"] = self.assessment_id
        return value


@dataclass(frozen=True)
class MechanismSignature:
    """Domain-neutral causal identity, deliberately excluding source prose."""

    target_failure_classes: Tuple[str, ...]
    information_regime: str
    information_source: str
    intervention_operator: str
    mediator: str
    protected_resource: str
    outcome: str
    boundary_conditions: Tuple[str, ...]
    signature_ref: str
    target_capability_channels: Tuple[str, ...] = ()
    protected_capability_channels: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        required = (
            self.target_failure_classes,
            self.information_regime,
            self.information_source,
            self.intervention_operator,
            self.mediator,
            self.protected_resource,
            self.outcome,
            self.signature_ref,
        )
        if not all(required):
            raise ValueError("mechanism signature is incomplete")
        if len(set(self.target_failure_classes)) != len(
            self.target_failure_classes
        ):
            raise ValueError("target failure classes must be unique")
        if len(set(self.boundary_conditions)) != len(
            self.boundary_conditions
        ):
            raise ValueError("mechanism boundary conditions must be unique")
        if len(set(self.target_capability_channels)) != len(
            self.target_capability_channels
        ):
            raise ValueError("target capability channels must be unique")
        if len(set(self.protected_capability_channels)) != len(
            self.protected_capability_channels
        ):
            raise ValueError("protected capability channels must be unique")
        if set(self.target_capability_channels).intersection(
            self.protected_capability_channels
        ):
            raise ValueError(
                "target and protected capability channels must be disjoint"
            )

    @property
    def mechanism_id(self) -> str:
        identity = {
                "target_failure_classes": list(
                    self.target_failure_classes
                ),
                "information_regime": self.information_regime,
                "information_source": self.information_source,
                "intervention_operator": self.intervention_operator,
                "mediator": self.mediator,
                "protected_resource": self.protected_resource,
                "outcome": self.outcome,
                "boundary_conditions": list(self.boundary_conditions),
        }
        # Empty channel fields are the legacy representation. Omitting them
        # keeps every existing checkpoint and scientific identity stable while
        # allowing revised generators to make the newly validated causal axis
        # identity-bearing.
        if self.target_capability_channels:
            identity["target_capability_channels"] = list(
                self.target_capability_channels
            )
        if self.protected_capability_channels:
            identity["protected_capability_channels"] = list(
                self.protected_capability_channels
            )
        return content_digest(identity)

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HYPOTHESIS_LEARNING_VERSION,
            "target_failure_classes": list(self.target_failure_classes),
            "information_regime": self.information_regime,
            "information_source": self.information_source,
            "intervention_operator": self.intervention_operator,
            "mediator": self.mediator,
            "protected_resource": self.protected_resource,
            "outcome": self.outcome,
            "boundary_conditions": list(self.boundary_conditions),
            "signature_ref": self.signature_ref,
        }
        if self.target_capability_channels:
            value["target_capability_channels"] = list(
                self.target_capability_channels
            )
        if self.protected_capability_channels:
            value["protected_capability_channels"] = list(
                self.protected_capability_channels
            )
        if include_id:
            value["mechanism_id"] = self.mechanism_id
        return value

    def differing_dimensions(
        self,
        other: "MechanismSignature",
    ) -> Tuple[str, ...]:
        return tuple(
            name
            for name in (
                "target_failure_classes",
                "information_regime",
                "information_source",
                "intervention_operator",
                "mediator",
                "protected_resource",
                "outcome",
                "boundary_conditions",
                "target_capability_channels",
                "protected_capability_channels",
            )
            if getattr(self, name) != getattr(other, name)
        )


@dataclass(frozen=True)
class HypothesisPredictionProfile:
    """Standardized observations used to distinguish causal hypotheses."""

    target_effect: str
    target_control_relation: str
    information_ablation_response: str
    mediator_response: str
    mechanism_ablation_response: str
    boundary_predictions: Tuple[Tuple[str, str], ...]
    measurement_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_effect,
                self.target_control_relation,
                self.information_ablation_response,
                self.mediator_response,
                self.mechanism_ablation_response,
                self.measurement_ref,
            )
        ):
            raise ValueError("hypothesis prediction profile is incomplete")
        names = tuple(name for name, _ in self.boundary_predictions)
        if len(set(names)) != len(names):
            raise ValueError("prediction boundary names must be unique")
        if any(not name or not outcome for name, outcome in self.boundary_predictions):
            raise ValueError("prediction boundary entries are incomplete")

    @property
    def prediction_profile_id(self) -> str:
        return content_digest(
            {
                "target_effect": self.target_effect,
                "target_control_relation": self.target_control_relation,
                "information_ablation_response": (
                    self.information_ablation_response
                ),
                "mediator_response": self.mediator_response,
                "mechanism_ablation_response": (
                    self.mechanism_ablation_response
                ),
                "boundary_predictions": [
                    [name, outcome]
                    for name, outcome in self.boundary_predictions
                ],
            }
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HYPOTHESIS_LEARNING_VERSION,
            "target_effect": self.target_effect,
            "target_control_relation": self.target_control_relation,
            "information_ablation_response": (
                self.information_ablation_response
            ),
            "mediator_response": self.mediator_response,
            "mechanism_ablation_response": (
                self.mechanism_ablation_response
            ),
            "boundary_predictions": [
                [name, outcome]
                for name, outcome in self.boundary_predictions
            ],
            "measurement_ref": self.measurement_ref,
        }
        if include_id:
            value["prediction_profile_id"] = self.prediction_profile_id
        return value

    def differing_dimensions(
        self,
        other: "HypothesisPredictionProfile",
    ) -> Tuple[str, ...]:
        return tuple(
            name
            for name in (
                "target_effect",
                "target_control_relation",
                "information_ablation_response",
                "mediator_response",
                "mechanism_ablation_response",
                "boundary_predictions",
            )
            if getattr(self, name) != getattr(other, name)
        )


@dataclass(frozen=True)
class HypothesisEvolutionBasis:
    """Evidence and literature obligations for a genuine descendant."""

    failed_hypothesis_ids: Tuple[str, ...]
    failure_kind: HypothesisFailureKind
    failed_prediction: str
    evidence_ids: Tuple[str, ...]
    changed_assumption: str
    literature_refs: Tuple[str, ...]
    new_distinguishing_prediction: str
    evolution_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.failed_hypothesis_ids,
                self.failed_prediction,
                self.evidence_ids,
                self.changed_assumption,
                self.literature_refs,
                self.new_distinguishing_prediction,
                self.evolution_ref,
            )
        ):
            raise ValueError("evolved hypothesis lacks an evidence-linked basis")
        if self.failure_kind in (
            HypothesisFailureKind.NOT_EVALUATED,
            HypothesisFailureKind.PASSED,
        ):
            raise ValueError("evolution basis requires an observed failure")
        if len(set(self.failed_hypothesis_ids)) != len(
            self.failed_hypothesis_ids
        ):
            raise ValueError("failed hypothesis IDs must be unique")
        if len(set(self.evidence_ids)) != len(self.evidence_ids):
            raise ValueError("evolution evidence IDs must be unique")
        if len(set(self.literature_refs)) != len(self.literature_refs):
            raise ValueError("evolution literature references must be unique")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "contract_version": HYPOTHESIS_LEARNING_VERSION,
            "failed_hypothesis_ids": list(self.failed_hypothesis_ids),
            "failure_kind": self.failure_kind.value,
            "failed_prediction": self.failed_prediction,
            "evidence_ids": list(self.evidence_ids),
            "changed_assumption": self.changed_assumption,
            "literature_refs": list(self.literature_refs),
            "new_distinguishing_prediction": (
                self.new_distinguishing_prediction
            ),
            "evolution_ref": self.evolution_ref,
        }


@dataclass(frozen=True)
class HypothesisFailureAssessment:
    hypothesis_id: str
    failure_kind: HypothesisFailureKind
    failed_prediction: str
    evidence_ids: Tuple[str, ...]
    interpretation: str
    next_experiment: str
    literature_questions: Tuple[str, ...]
    assessor_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.hypothesis_id,
                self.failed_prediction,
                self.interpretation,
                self.next_experiment,
                self.literature_questions,
                self.assessor_ref,
            )
        ):
            raise ValueError("hypothesis failure assessment is incomplete")
        if len(set(self.evidence_ids)) != len(self.evidence_ids):
            raise ValueError("failure evidence IDs must be unique")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "contract_version": HYPOTHESIS_LEARNING_VERSION,
            "hypothesis_id": self.hypothesis_id,
            "failure_kind": self.failure_kind.value,
            "failed_prediction": self.failed_prediction,
            "evidence_ids": list(self.evidence_ids),
            "interpretation": self.interpretation,
            "next_experiment": self.next_experiment,
            "literature_questions": list(self.literature_questions),
            "assessor_ref": self.assessor_ref,
        }


@dataclass(frozen=True)
class HypothesisEquivalenceClass:
    representative_id: str
    member_ids: Tuple[str, ...]
    source_refs: Tuple[str, ...]
    inspiration_ids: Tuple[str, ...]
    executable_digests: Tuple[str, ...]
    rationale: str

    def __post_init__(self) -> None:
        if not self.representative_id or not self.member_ids or not self.rationale:
            raise ValueError("hypothesis equivalence class is incomplete")
        if self.representative_id not in self.member_ids:
            raise ValueError("equivalence representative must be a member")
        if len(set(self.member_ids)) != len(self.member_ids):
            raise ValueError("equivalence members must be unique")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "representative_id": self.representative_id,
            "member_ids": list(self.member_ids),
            "source_refs": list(self.source_refs),
            "inspiration_ids": list(self.inspiration_ids),
            "executable_digests": list(self.executable_digests),
            "rationale": self.rationale,
        }


@dataclass(frozen=True)
class HypothesisDiscrimination:
    first_hypothesis_id: str
    second_hypothesis_id: str
    mechanism_dimensions: Tuple[str, ...]
    prediction_dimensions: Tuple[str, ...]

    def __post_init__(self) -> None:
        if (
            not self.first_hypothesis_id
            or not self.second_hypothesis_id
            or self.first_hypothesis_id == self.second_hypothesis_id
            or not (self.mechanism_dimensions or self.prediction_dimensions)
        ):
            raise ValueError("hypothesis pair lacks a distinguishing observation")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "first_hypothesis_id": self.first_hypothesis_id,
            "second_hypothesis_id": self.second_hypothesis_id,
            "mechanism_dimensions": list(self.mechanism_dimensions),
            "prediction_dimensions": list(self.prediction_dimensions),
        }


@dataclass(frozen=True)
class HypothesisGenerationAudit:
    proposed_hypothesis_ids: Tuple[str, ...]
    admitted_hypothesis_ids: Tuple[str, ...]
    equivalence_classes: Tuple[HypothesisEquivalenceClass, ...]
    executable_collisions: Tuple[Tuple[str, ...], ...]
    discrimination_matrix: Tuple[HypothesisDiscrimination, ...]
    failure_assessments: Tuple[HypothesisFailureAssessment, ...]
    literature_query_ids: Tuple[str, ...]
    literature_source_refs: Tuple[str, ...]
    audit_ref: str

    def __post_init__(self) -> None:
        if (
            not self.proposed_hypothesis_ids
            or not self.admitted_hypothesis_ids
            or not self.audit_ref
        ):
            raise ValueError("hypothesis generation audit is incomplete")
        proposed = set(self.proposed_hypothesis_ids)
        admitted = set(self.admitted_hypothesis_ids)
        if (
            len(proposed) != len(self.proposed_hypothesis_ids)
            or len(admitted) != len(self.admitted_hypothesis_ids)
            or not admitted.issubset(proposed)
        ):
            raise ValueError("hypothesis audit identities are invalid")
        covered = {
            member
            for group in self.equivalence_classes
            for member in group.member_ids
        }
        if covered != proposed:
            raise ValueError("equivalence audit does not cover every proposal")
        if {
            group.representative_id for group in self.equivalence_classes
        } != admitted:
            raise ValueError("equivalence representatives and admissions disagree")

    @property
    def merged_count(self) -> int:
        return len(self.proposed_hypothesis_ids) - len(
            self.admitted_hypothesis_ids
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "contract_version": HYPOTHESIS_LEARNING_VERSION,
            "proposed_hypothesis_ids": list(self.proposed_hypothesis_ids),
            "admitted_hypothesis_ids": list(self.admitted_hypothesis_ids),
            "equivalence_classes": [
                group.as_dict() for group in self.equivalence_classes
            ],
            "executable_collisions": [
                list(group) for group in self.executable_collisions
            ],
            "discrimination_matrix": [
                item.as_dict() for item in self.discrimination_matrix
            ],
            "failure_assessments": [
                item.as_dict() for item in self.failure_assessments
            ],
            "literature_query_ids": list(self.literature_query_ids),
            "literature_source_refs": list(self.literature_source_refs),
            "merged_count": self.merged_count,
            "audit_ref": self.audit_ref,
        }


def classify_hypothesis_diagnostic(
    hypothesis_id: str,
    result: HypothesisDiagnosticResult | None,
    *,
    assessor_ref: str = "typed-hypothesis-failure-classifier-v1",
) -> HypothesisFailureAssessment:
    if result is None:
        return HypothesisFailureAssessment(
            hypothesis_id=hypothesis_id,
            failure_kind=HypothesisFailureKind.NOT_EVALUATED,
            failed_prediction="no executable diagnostic was run",
            evidence_ids=(),
            interpretation=(
                "The scientific mechanism remains unevaluated; no causal "
                "conclusion is authorized."
            ),
            next_experiment="compile and run a mediator-sensitive diagnostic",
            literature_questions=(
                "Which measurements operationalize this mediator?",
                "Which interventions distinguish the proposed mechanism?",
            ),
            assessor_ref=assessor_ref,
        )
    reasons = set(result.failure_reasons)
    if result.passed:
        kind = HypothesisFailureKind.PASSED
        failed_prediction = "none; all preregistered diagnostic gates passed"
        interpretation = "The diagnostic supports continued testing."
        next_experiment = "run broader independent validation"
        questions = (
            "Under which boundary conditions does the effect transport?",
        )
    elif "no_registered_executable_compiler" in reasons:
        kind = HypothesisFailureKind.COMPILATION
        failed_prediction = "the proposed intervention can be operationalized"
        interpretation = (
            "The implementation was unavailable; the causal hypothesis was "
            "not tested."
        )
        next_experiment = "construct and unit-test a mediator-preserving compiler"
        questions = (
            "How has this mediator been operationalized in executable systems?",
            "Which proxy-to-action interfaces preserve the causal semantics?",
        )
    elif (
        "compiled_action_did_not_engage_the_mediator" in reasons
        or result.mediator_consistency < 0.25
    ):
        kind = HypothesisFailureKind.MEDIATOR
        failed_prediction = "the compiled action changes the named mediator"
        interpretation = (
            "The operationalization did not manipulate the mediator, so a "
            "null outcome does not refute the upstream causal story."
        )
        next_experiment = (
            "replace the intervention and verify mediator engagement before "
            "measuring the outcome"
        )
        questions = (
            "Which interventions directly manipulate this mediator?",
            "Which measurements detect mediator engagement before outcomes?",
            "Which failed implementations left the mediator unchanged?",
        )
    elif "compiled_policy_matches_preregistered_prior_art" in reasons:
        kind = HypothesisFailureKind.PRIOR_ART
        failed_prediction = "the executable behavior is distinct from prior art"
        interpretation = (
            "The implementation rediscovered known behavior; novelty claims "
            "are rejected without rejecting the underlying causal relation."
        )
        next_experiment = "change a causal assumption and preregister a novel behavior"
        questions = (
            "Which behaviorally equivalent interventions are already published?",
            "Which boundary condition separates the proposed mechanism?",
        )
    elif (
        "insufficient_independent_suffix_replays" in reasons
        or "no_target_replays" in reasons
        or "no_matched_control_replays" in reasons
    ):
        kind = HypothesisFailureKind.UNCERTAINTY
        failed_prediction = "the experiment has enough independent support"
        interpretation = (
            "The diagnostic lacks sufficient independent observations for a "
            "causal verdict."
        )
        next_experiment = "collect additional independent target and control replays"
        questions = (
            "Which efficient designs increase power for sparse failures?",
            "Which matched controls reduce variance without leaking outcomes?",
        )
    elif (
        "target_effect_not_larger_than_matched_control" in reasons
        or "history_mask_did_not_remove_predictive_effect" in reasons
        or "robust_optionality_depended_on_history" in reasons
    ):
        kind = HypothesisFailureKind.TRANSPORT
        failed_prediction = (
            "the target-specific effect obeys the predicted boundary condition"
        )
        interpretation = (
            "The intervention changed behavior but the effect did not follow "
            "the predicted target/control or information boundary."
        )
        next_experiment = "test the failed boundary with a factorial intervention"
        questions = (
            "Which boundary conditions reverse or erase this mechanism?",
            "Which source assumptions fail during target-domain transport?",
        )
    else:
        kind = HypothesisFailureKind.CAUSAL
        failed_prediction = "engaging the proposed mechanism improves the outcome"
        interpretation = (
            "The mediator was measurable but the predicted outcome did not "
            "improve; revise the causal model."
        )
        next_experiment = "test a competing causal mediator on the same failures"
        questions = (
            "Which competing mechanisms explain this failure cluster?",
            "Which interventions produced null or reversed outcomes?",
        )
    return HypothesisFailureAssessment(
        hypothesis_id=hypothesis_id,
        failure_kind=kind,
        failed_prediction=failed_prediction,
        evidence_ids=result.evidence_ids,
        interpretation=interpretation,
        next_experiment=next_experiment,
        literature_questions=questions,
        assessor_ref=assessor_ref,
    )


def build_hypothesis_generation_audit(
    proposals: Sequence[Any],
    *,
    literature_query_ids: Sequence[str] = (),
    literature_source_refs: Sequence[str] = (),
    audit_ref: str = "canonical-hypothesis-admission-v1",
) -> Tuple[Tuple[Any, ...], HypothesisGenerationAudit]:
    """Merge scientific duplicates before Elo can reward their wording."""

    if not proposals:
        raise ValueError("hypothesis admission requires proposals")
    proposed_ids = tuple(item.hypothesis_id for item in proposals)
    if len(set(proposed_ids)) != len(proposed_ids):
        raise ValueError("proposal identities must be unique before admission")
    groups: Dict[Tuple[str, str], list[Any]] = {}
    for item in proposals:
        key = (
            item.mechanism_signature.mechanism_id,
            item.prediction_profile.prediction_profile_id,
        )
        groups.setdefault(key, []).append(item)
    representatives = tuple(group[0] for group in groups.values())
    equivalence_classes = tuple(
        HypothesisEquivalenceClass(
            representative_id=group[0].hypothesis_id,
            member_ids=tuple(item.hypothesis_id for item in group),
            source_refs=tuple(dict.fromkeys(item.source_ref for item in group)),
            inspiration_ids=tuple(
                dict.fromkeys(
                    inspiration_id
                    for item in group
                    for inspiration_id in item.inspiration_ids
                )
            ),
            executable_digests=tuple(
                dict.fromkeys(
                    item.executable_contract.executable_digest
                    for item in group
                    if item.executable_contract is not None
                )
            ),
            rationale=(
                "same domain-neutral mechanism signature and standardized "
                "prediction profile; alternate prose, sources, and patches "
                "are retained as rationales or operationalizations"
            ),
        )
        for group in groups.values()
    )
    executable_groups: Dict[str, list[str]] = {}
    for item in proposals:
        if item.executable_contract is None:
            continue
        executable_groups.setdefault(
            item.executable_contract.executable_digest,
            [],
        ).append(item.hypothesis_id)
    executable_collisions = tuple(
        tuple(ids)
        for _, ids in sorted(executable_groups.items())
        if len(ids) > 1
    )
    discrimination = []
    for index, first in enumerate(representatives):
        for second in representatives[index + 1 :]:
            mechanism_dimensions = (
                first.mechanism_signature.differing_dimensions(
                    second.mechanism_signature
                )
            )
            prediction_dimensions = (
                first.prediction_profile.differing_dimensions(
                    second.prediction_profile
                )
            )
            discrimination.append(
                HypothesisDiscrimination(
                    first_hypothesis_id=first.hypothesis_id,
                    second_hypothesis_id=second.hypothesis_id,
                    mechanism_dimensions=mechanism_dimensions,
                    prediction_dimensions=prediction_dimensions,
                )
            )
    assessments = tuple(
        classify_hypothesis_diagnostic(
            item.hypothesis_id,
            item.diagnostic_result,
        )
        for item in proposals
    )
    audit = HypothesisGenerationAudit(
        proposed_hypothesis_ids=proposed_ids,
        admitted_hypothesis_ids=tuple(
            item.hypothesis_id for item in representatives
        ),
        equivalence_classes=equivalence_classes,
        executable_collisions=executable_collisions,
        discrimination_matrix=tuple(discrimination),
        failure_assessments=assessments,
        literature_query_ids=tuple(dict.fromkeys(literature_query_ids)),
        literature_source_refs=tuple(
            dict.fromkeys(literature_source_refs)
        ),
        audit_ref=audit_ref,
    )
    return representatives, audit


def mechanism_signature_from_dict(
    value: Mapping[str, Any],
) -> MechanismSignature:
    signature = MechanismSignature(
        target_failure_classes=tuple(
            str(item) for item in value["target_failure_classes"]
        ),
        information_regime=str(value["information_regime"]),
        information_source=str(value["information_source"]),
        intervention_operator=str(value["intervention_operator"]),
        mediator=str(value["mediator"]),
        protected_resource=str(value["protected_resource"]),
        outcome=str(value["outcome"]),
        boundary_conditions=tuple(
            str(item) for item in value.get("boundary_conditions", ())
        ),
        signature_ref=str(value["signature_ref"]),
        target_capability_channels=tuple(
            str(item)
            for item in value.get("target_capability_channels", ())
        ),
        protected_capability_channels=tuple(
            str(item)
            for item in value.get("protected_capability_channels", ())
        ),
    )
    supplied = value.get("mechanism_id")
    if supplied is not None and str(supplied) != signature.mechanism_id:
        raise ValueError("mechanism signature identity mismatch")
    return signature


def prediction_profile_from_dict(
    value: Mapping[str, Any],
) -> HypothesisPredictionProfile:
    profile = HypothesisPredictionProfile(
        target_effect=str(value["target_effect"]),
        target_control_relation=str(value["target_control_relation"]),
        information_ablation_response=str(
            value["information_ablation_response"]
        ),
        mediator_response=str(value["mediator_response"]),
        mechanism_ablation_response=str(
            value["mechanism_ablation_response"]
        ),
        boundary_predictions=tuple(
            (str(name), str(outcome))
            for name, outcome in value.get("boundary_predictions", ())
        ),
        measurement_ref=str(value["measurement_ref"]),
    )
    supplied = value.get("prediction_profile_id")
    if (
        supplied is not None
        and str(supplied) != profile.prediction_profile_id
    ):
        raise ValueError("prediction profile identity mismatch")
    return profile


def evolution_basis_from_dict(
    value: Mapping[str, Any],
) -> HypothesisEvolutionBasis:
    return HypothesisEvolutionBasis(
        failed_hypothesis_ids=tuple(
            str(item) for item in value["failed_hypothesis_ids"]
        ),
        failure_kind=HypothesisFailureKind(value["failure_kind"]),
        failed_prediction=str(value["failed_prediction"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        changed_assumption=str(value["changed_assumption"]),
        literature_refs=tuple(
            str(item) for item in value["literature_refs"]
        ),
        new_distinguishing_prediction=str(
            value["new_distinguishing_prediction"]
        ),
        evolution_ref=str(value["evolution_ref"]),
    )


def generation_audit_from_dict(
    value: Mapping[str, Any],
) -> HypothesisGenerationAudit:
    return HypothesisGenerationAudit(
        proposed_hypothesis_ids=tuple(
            str(item) for item in value["proposed_hypothesis_ids"]
        ),
        admitted_hypothesis_ids=tuple(
            str(item) for item in value["admitted_hypothesis_ids"]
        ),
        equivalence_classes=tuple(
            HypothesisEquivalenceClass(
                representative_id=str(item["representative_id"]),
                member_ids=tuple(
                    str(member) for member in item["member_ids"]
                ),
                source_refs=tuple(
                    str(source) for source in item["source_refs"]
                ),
                inspiration_ids=tuple(
                    str(inspiration_id)
                    for inspiration_id in item.get("inspiration_ids", ())
                ),
                executable_digests=tuple(
                    str(digest) for digest in item["executable_digests"]
                ),
                rationale=str(item["rationale"]),
            )
            for item in value["equivalence_classes"]
        ),
        executable_collisions=tuple(
            tuple(str(member) for member in group)
            for group in value.get("executable_collisions", ())
        ),
        discrimination_matrix=tuple(
            HypothesisDiscrimination(
                first_hypothesis_id=str(item["first_hypothesis_id"]),
                second_hypothesis_id=str(item["second_hypothesis_id"]),
                mechanism_dimensions=tuple(
                    str(name) for name in item["mechanism_dimensions"]
                ),
                prediction_dimensions=tuple(
                    str(name) for name in item["prediction_dimensions"]
                ),
            )
            for item in value["discrimination_matrix"]
        ),
        failure_assessments=tuple(
            HypothesisFailureAssessment(
                hypothesis_id=str(item["hypothesis_id"]),
                failure_kind=HypothesisFailureKind(item["failure_kind"]),
                failed_prediction=str(item["failed_prediction"]),
                evidence_ids=tuple(
                    str(evidence_id)
                    for evidence_id in item["evidence_ids"]
                ),
                interpretation=str(item["interpretation"]),
                next_experiment=str(item["next_experiment"]),
                literature_questions=tuple(
                    str(question)
                    for question in item["literature_questions"]
                ),
                assessor_ref=str(item["assessor_ref"]),
            )
            for item in value["failure_assessments"]
        ),
        literature_query_ids=tuple(
            str(item) for item in value.get("literature_query_ids", ())
        ),
        literature_source_refs=tuple(
            str(item) for item in value.get("literature_source_refs", ())
        ),
        audit_ref=str(value["audit_ref"]),
    )
