from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    Mapping,
    Optional,
    Sequence,
    Tuple,
)

from scientist.core.artifacts import content_digest
from scientist.program.executable_hypothesis import (
    CausalEvolutionOperator,
    ExecutableHypothesisContract,
    HypothesisDiagnosticResult,
)
from scientist.program.hypothesis_learning import (
    HypothesisEvolutionBasis,
    HypothesisGenerationAudit,
    HypothesisPredictionProfile,
    MechanismSignature,
    build_hypothesis_generation_audit,
)


HYPOTHESIS_TOURNAMENT_VERSION = "hypothesis-elo-tournament-v5"


class HypothesisOrigin(str, Enum):
    ISLAND = "island"
    CROSS_DOMAIN = "cross_domain"
    EVOLUTION = "evolution"


@dataclass(frozen=True)
class TournamentHypothesis:
    target_node_id: str
    statement: str
    mechanism: str
    origin: HypothesisOrigin
    source_ref: str
    generator_ref: str
    predictions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    assumptions: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    mechanism_signature: MechanismSignature
    prediction_profile: HypothesisPredictionProfile
    parent_ids: Tuple[str, ...] = ()
    inspiration_ids: Tuple[str, ...] = ()
    island_family: str | None = None
    generation: int = 0
    revision_eligible: bool = False
    executable_contract: ExecutableHypothesisContract | None = None
    diagnostic_result: HypothesisDiagnosticResult | None = None
    causal_operator: CausalEvolutionOperator | None = None
    evolution_basis: HypothesisEvolutionBasis | None = None

    def __post_init__(self) -> None:
        required = (
            self.target_node_id,
            self.statement,
            self.mechanism,
            self.source_ref,
            self.generator_ref,
            self.predictions,
            self.falsification_conditions,
            self.assumptions,
        )
        if not all(required):
            raise ValueError("tournament hypothesis is incomplete")
        if len(self.predictions) < 2:
            raise ValueError("tournament hypothesis needs two predictions")
        if len(self.falsification_conditions) < 2:
            raise ValueError(
                "tournament hypothesis needs two falsification conditions"
            )
        if self.generation < 0:
            raise ValueError("hypothesis generation must be non-negative")
        if len(set(self.parent_ids)) != len(self.parent_ids):
            raise ValueError("hypothesis parents must be unique")
        if len(set(self.inspiration_ids)) != len(self.inspiration_ids):
            raise ValueError("hypothesis inspirations must be unique")
        if self.origin == HypothesisOrigin.ISLAND:
            if not self.island_family:
                raise ValueError(
                    "island hypotheses require their search family"
                )
            if self.generation != 0 or self.parent_ids:
                raise ValueError(
                    "island seed hypotheses cannot have tournament parents"
                )
        elif self.island_family is not None:
            raise ValueError(
                "only island hypotheses may identify an island family"
            )
        if self.origin == HypothesisOrigin.EVOLUTION:
            if self.generation == 0 or not self.parent_ids:
                raise ValueError(
                    "evolved hypotheses require parents and a generation"
                )
            if self.causal_operator is None:
                raise ValueError(
                    "evolved hypotheses require a causal evolution operator"
                )
            if self.evolution_basis is None:
                raise ValueError(
                    "evolved hypotheses require an evidence-linked basis"
                )
            if not set(self.evolution_basis.failed_hypothesis_ids).issubset(
                self.parent_ids
            ):
                raise ValueError(
                    "evolution basis must identify failed parent hypotheses"
                )
        elif self.causal_operator is not None or self.evolution_basis is not None:
            raise ValueError(
                "only evolved hypotheses may name an evolution operator "
                "or evolution basis"
            )
        if (self.executable_contract is None) != (
            self.diagnostic_result is None
        ):
            raise ValueError(
                "executable hypotheses require both contract and diagnostic"
            )
        if self.executable_contract is not None:
            if (
                self.executable_contract.target_node_id
                != self.target_node_id
                or self.executable_contract.generator_patch.generator_ref
                != self.generator_ref
            ):
                raise ValueError(
                    "hypothesis and executable contract disagree"
                )
            assert self.diagnostic_result is not None
            if (
                self.diagnostic_result.contract_id
                != self.executable_contract.contract_id
                or self.diagnostic_result.executable_digest
                != self.executable_contract.executable_digest
            ):
                raise ValueError(
                    "hypothesis diagnostic belongs to another executable"
                )
        if self.revision_eligible and (
            self.executable_contract is None
            or self.diagnostic_result is None
            or not self.diagnostic_result.passed
            or not self.diagnostic_result.prior_art_distinct
        ):
            raise ValueError(
                "revision eligibility requires a passing executable "
                "diagnostic and prior-art distinction"
            )

    @property
    def hypothesis_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def scientific_identity(self) -> str:
        return content_digest(
            {
                "mechanism_id": self.mechanism_signature.mechanism_id,
                "prediction_profile_id": (
                    self.prediction_profile.prediction_profile_id
                ),
            }
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HYPOTHESIS_TOURNAMENT_VERSION,
            "target_node_id": self.target_node_id,
            "statement": self.statement,
            "mechanism": self.mechanism,
            "origin": self.origin.value,
            "source_ref": self.source_ref,
            "generator_ref": self.generator_ref,
            "predictions": list(self.predictions),
            "falsification_conditions": list(
                self.falsification_conditions
            ),
            "assumptions": list(self.assumptions),
            "evidence_ids": list(self.evidence_ids),
            "mechanism_signature": self.mechanism_signature.as_dict(),
            "prediction_profile": self.prediction_profile.as_dict(),
            "parent_ids": list(self.parent_ids),
            "inspiration_ids": list(self.inspiration_ids),
            "island_family": self.island_family,
            "generation": self.generation,
            "revision_eligible": self.revision_eligible,
            "executable_contract": (
                None
                if self.executable_contract is None
                else self.executable_contract.as_dict()
            ),
            "diagnostic_result": (
                None
                if self.diagnostic_result is None
                else self.diagnostic_result.as_dict()
            ),
            "causal_operator": (
                None
                if self.causal_operator is None
                else self.causal_operator.value
            ),
            "evolution_basis": (
                None
                if self.evolution_basis is None
                else self.evolution_basis.as_dict()
            ),
            "scientific_identity": self.scientific_identity,
        }
        if include_id:
            value["hypothesis_id"] = self.hypothesis_id
        return value


@dataclass(frozen=True)
class HypothesisReview:
    hypothesis_id: str
    goal_alignment: int
    plausibility: int
    novelty: int
    testability: int
    feasibility: int
    evidence_grounding: int
    diversity_value: int
    assumption_risk: int
    critique: Tuple[str, ...]
    improvement_directions: Tuple[str, ...]
    reviewer_ref: str
    evidence_update: int = 0

    def __post_init__(self) -> None:
        if not all(
            (
                self.hypothesis_id,
                self.critique,
                self.improvement_directions,
                self.reviewer_ref,
            )
        ):
            raise ValueError("hypothesis review is incomplete")
        scores = (
            self.goal_alignment,
            self.plausibility,
            self.novelty,
            self.testability,
            self.feasibility,
            self.evidence_grounding,
            self.diversity_value,
            self.assumption_risk,
        )
        if any(
            not isinstance(score, int) or not 0 <= score <= 4
            for score in scores
        ):
            raise ValueError("review grades must be integers zero to four")
        if (
            not isinstance(self.evidence_update, int)
            or not -8 <= self.evidence_update <= 8
        ):
            raise ValueError(
                "diagnostic evidence update must be an integer in [-8, 8]"
            )

    @property
    def truth_score(self) -> int:
        return (
            2 * self.goal_alignment
            + 2 * self.plausibility
            + 2 * self.testability
            + self.feasibility
            + self.evidence_grounding
            - self.assumption_risk
            + self.evidence_update
        )

    @property
    def bounded_risk_reward(self) -> int:
        return (
            min(self.assumption_risk, 2)
            - 2 * max(0, self.assumption_risk - 2)
        )

    @property
    def discovery_score(self) -> int:
        return (
            2 * self.novelty
            + 2 * self.diversity_value
            + self.plausibility
            + self.testability
            + self.bounded_risk_reward
            + self.evidence_update
        )

    @property
    def quality_score(self) -> int:
        """Backward-compatible combined score; never a promotion gate."""
        return self.truth_score + self.discovery_score

    def as_dict(self) -> Dict[str, Any]:
        return {
            "contract_version": HYPOTHESIS_TOURNAMENT_VERSION,
            "hypothesis_id": self.hypothesis_id,
            "goal_alignment": self.goal_alignment,
            "plausibility": self.plausibility,
            "novelty": self.novelty,
            "testability": self.testability,
            "feasibility": self.feasibility,
            "evidence_grounding": self.evidence_grounding,
            "diversity_value": self.diversity_value,
            "assumption_risk": self.assumption_risk,
            "bounded_risk_reward": self.bounded_risk_reward,
            "truth_score": self.truth_score,
            "discovery_score": self.discovery_score,
            "quality_score": self.quality_score,
            "critique": list(self.critique),
            "improvement_directions": list(
                self.improvement_directions
            ),
            "reviewer_ref": self.reviewer_ref,
            "evidence_update": self.evidence_update,
        }


@dataclass(frozen=True)
class HypothesisProximity:
    first_hypothesis_id: str
    second_hypothesis_id: str
    similarity: float
    shared_terms: Tuple[str, ...]

    def __post_init__(self) -> None:
        if (
            not self.first_hypothesis_id
            or not self.second_hypothesis_id
            or self.first_hypothesis_id == self.second_hypothesis_id
        ):
            raise ValueError("hypothesis proximity pair is invalid")
        if not math.isfinite(self.similarity) or not 0 <= self.similarity <= 1:
            raise ValueError("hypothesis similarity must be in [0, 1]")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "first_hypothesis_id": self.first_hypothesis_id,
            "second_hypothesis_id": self.second_hypothesis_id,
            "similarity": self.similarity,
            "shared_terms": list(self.shared_terms),
        }


@dataclass(frozen=True)
class HypothesisMatch:
    match_index: int
    first_hypothesis_id: str
    second_hypothesis_id: str
    first_rating_before: float
    second_rating_before: float
    first_score: float
    first_rating_after: float
    second_rating_after: float
    order_votes: Tuple[str, str]
    facet_deltas: Mapping[str, int]
    rationale: str

    def __post_init__(self) -> None:
        if self.match_index < 0:
            raise ValueError("match index must be non-negative")
        if (
            not self.first_hypothesis_id
            or not self.second_hypothesis_id
            or self.first_hypothesis_id == self.second_hypothesis_id
            or not self.rationale
        ):
            raise ValueError("hypothesis match is incomplete")
        if self.first_score not in (0.0, 0.5, 1.0):
            raise ValueError("hypothesis match score must be win/draw/loss")
        if len(self.order_votes) != 2:
            raise ValueError("matches require AB and BA order votes")
        if not all(
            math.isfinite(value)
            for value in (
                self.first_rating_before,
                self.second_rating_before,
                self.first_rating_after,
                self.second_rating_after,
            )
        ):
            raise ValueError("Elo ratings must be finite")

    @property
    def winner_id(self) -> str | None:
        if self.first_score == 0.5:
            return None
        if self.first_score == 1.0:
            return self.first_hypothesis_id
        return self.second_hypothesis_id

    def as_dict(self) -> Dict[str, Any]:
        return {
            "contract_version": HYPOTHESIS_TOURNAMENT_VERSION,
            "match_index": self.match_index,
            "first_hypothesis_id": self.first_hypothesis_id,
            "second_hypothesis_id": self.second_hypothesis_id,
            "first_rating_before": self.first_rating_before,
            "second_rating_before": self.second_rating_before,
            "first_score": self.first_score,
            "first_rating_after": self.first_rating_after,
            "second_rating_after": self.second_rating_after,
            "winner_id": self.winner_id,
            "order_votes": list(self.order_votes),
            "order_consistent": (
                self.order_votes[0] == self.order_votes[1]
            ),
            "facet_deltas": dict(sorted(self.facet_deltas.items())),
            "rationale": self.rationale,
        }


@dataclass(frozen=True)
class HypothesisTournament:
    target_node_id: str
    hypotheses: Tuple[TournamentHypothesis, ...]
    reviews: Tuple[HypothesisReview, ...]
    proximities: Tuple[HypothesisProximity, ...]
    matches: Tuple[HypothesisMatch, ...]
    final_ratings: Mapping[str, float]
    survivor_ids: Tuple[str, ...]
    champion_id: str
    eligible_champion_id: str | None
    generations_completed: int
    meta_review: Tuple[str, ...]
    tournament_ref: str
    generation_audit: HypothesisGenerationAudit
    initial_rating: float = 1200.0
    k_factor: float = 32.0
    required_discovery_channels: Tuple[str, ...] = (
        "ancestry",
        "de_novo",
        "hybrid",
        "cross_domain",
    )

    def __post_init__(self) -> None:
        if (
            not self.target_node_id
            or not self.meta_review
            or not self.tournament_ref
            or self.generations_completed < 0
        ):
            raise ValueError("hypothesis tournament is incomplete")
        ids = {item.hypothesis_id for item in self.hypotheses}
        if len(ids) != len(self.hypotheses):
            raise ValueError("tournament hypotheses must be unique")
        if any(
            item.target_node_id != self.target_node_id
            for item in self.hypotheses
        ):
            raise ValueError("tournament spans multiple target nodes")
        review_ids = {item.hypothesis_id for item in self.reviews}
        if review_ids != ids or len(review_ids) != len(self.reviews):
            raise ValueError(
                "every tournament hypothesis needs exactly one review"
            )
        if set(self.final_ratings) != ids:
            raise ValueError("tournament ratings do not cover hypotheses")
        if set(self.generation_audit.admitted_hypothesis_ids) != ids:
            raise ValueError(
                "hypothesis admission audit and tournament disagree"
            )
        if (
            self.champion_id not in ids
            or not self.survivor_ids
            or not set(self.survivor_ids).issubset(ids)
        ):
            raise ValueError("tournament survivor identities are invalid")
        by_id = {
            item.hypothesis_id: item for item in self.hypotheses
        }
        for item in self.hypotheses:
            if item.origin != HypothesisOrigin.EVOLUTION:
                continue
            parent_digests = {
                by_id[parent_id].executable_contract.executable_digest
                for parent_id in item.parent_ids
                if parent_id in by_id
                and by_id[parent_id].executable_contract is not None
            }
            if (
                item.executable_contract is not None
                and item.executable_contract.executable_digest
                in parent_digests
            ):
                raise ValueError(
                    "causal evolution must change the executable digest"
                )
            if any(
                item.predictions == by_id[parent_id].predictions
                for parent_id in item.parent_ids
            ):
                raise ValueError(
                    "causal evolution must change its distinguishing "
                    "prediction"
                )
        if (
            self.eligible_champion_id is not None
            and (
                self.eligible_champion_id not in ids
                or not by_id[
                    self.eligible_champion_id
                ].revision_eligible
            )
        ):
            raise ValueError(
                "eligible tournament champion is not revision eligible"
            )
        if not self.required_discovery_channels:
            raise ValueError("tournament requires discovery channels")
        if len(set(self.required_discovery_channels)) != len(
            self.required_discovery_channels
        ):
            raise ValueError("tournament discovery channels must be unique")
        observed_channels = {
            (
                "cross_domain"
                if item.origin == HypothesisOrigin.CROSS_DOMAIN
                else item.island_family
            )
            for item in self.hypotheses
            if item.origin
            in (HypothesisOrigin.ISLAND, HypothesisOrigin.CROSS_DOMAIN)
        }
        missing_channels = set(self.required_discovery_channels).difference(
            observed_channels
        )
        if missing_channels:
            raise ValueError(
                "tournament is missing discovery channels: %s"
                % ", ".join(sorted(missing_channels))
            )

    @property
    def tournament_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": HYPOTHESIS_TOURNAMENT_VERSION,
            "target_node_id": self.target_node_id,
            "hypotheses": [
                hypothesis.as_dict() for hypothesis in self.hypotheses
            ],
            "reviews": [review.as_dict() for review in self.reviews],
            "proximities": [
                proximity.as_dict() for proximity in self.proximities
            ],
            "matches": [match.as_dict() for match in self.matches],
            "final_ratings": dict(sorted(self.final_ratings.items())),
            "survivor_ids": list(self.survivor_ids),
            "champion_id": self.champion_id,
            "eligible_champion_id": self.eligible_champion_id,
            "generations_completed": self.generations_completed,
            "meta_review": list(self.meta_review),
            "tournament_ref": self.tournament_ref,
            "generation_audit": self.generation_audit.as_dict(),
            "initial_rating": self.initial_rating,
            "k_factor": self.k_factor,
            "required_discovery_channels": list(
                self.required_discovery_channels
            ),
        }
        if include_id:
            value["tournament_id"] = self.tournament_id
        return value


ReviewFunction = Callable[[TournamentHypothesis], HypothesisReview]
EvolutionFunction = Callable[
    [
        int,
        Tuple[TournamentHypothesis, ...],
        Mapping[str, HypothesisReview],
    ],
    Tuple[TournamentHypothesis, ...],
]
ExperimentalMatchFunction = Callable[
    [TournamentHypothesis, TournamentHypothesis],
    Optional[Tuple[int, str]],
]


def _idea_tokens(hypothesis: TournamentHypothesis) -> frozenset[str]:
    text = " ".join((hypothesis.statement, hypothesis.mechanism))
    return frozenset(
        token.strip(".,:;()[]").casefold()
        for token in text.split()
        if len(token.strip(".,:;()[]")) >= 4
    )


def _proximities(
    hypotheses: Sequence[TournamentHypothesis],
) -> Tuple[HypothesisProximity, ...]:
    edges = []
    for index, first in enumerate(hypotheses):
        first_tokens = _idea_tokens(first)
        for second in hypotheses[index + 1 :]:
            second_tokens = _idea_tokens(second)
            union = first_tokens.union(second_tokens)
            shared = tuple(sorted(first_tokens.intersection(second_tokens)))
            similarity = 0.0 if not union else len(shared) / len(union)
            edges.append(
                HypothesisProximity(
                    first_hypothesis_id=first.hypothesis_id,
                    second_hypothesis_id=second.hypothesis_id,
                    similarity=similarity,
                    shared_terms=shared,
                )
            )
    return tuple(edges)


def _play_match(
    match_index: int,
    first: TournamentHypothesis,
    second: TournamentHypothesis,
    reviews: Mapping[str, HypothesisReview],
    ratings: Dict[str, float],
    *,
    k_factor: float,
    experimental_compare: Optional[
        ExperimentalMatchFunction
    ] = None,
) -> HypothesisMatch:
    first_review = reviews[first.hypothesis_id]
    second_review = reviews[second.hypothesis_id]

    def vote_for(left: float, right: float) -> str:
        if left > right:
            return first.hypothesis_id
        if left < right:
            return second.hypothesis_id
        return "draw"

    # The two votes optimize different scientific obligations.  Whenever the
    # domain can construct a prediction-disagreement experiment, its outcome
    # replaces the rubric-only evidence vote.
    experimental = (
        None
        if experimental_compare is None
        else experimental_compare(first, second)
    )
    first_evidence_case = first_review.truth_score
    second_evidence_case = second_review.truth_score
    first_discovery_case = first_review.discovery_score
    second_discovery_case = second_review.discovery_score
    if experimental is None or experimental[0] == 0:
        evidence_vote = vote_for(
            first_evidence_case,
            second_evidence_case,
        )
    elif experimental[0] > 0:
        evidence_vote = first.hypothesis_id
    else:
        evidence_vote = second.hypothesis_id
    discovery_vote = vote_for(first_discovery_case, second_discovery_case)
    if (
        evidence_vote == discovery_vote == first.hypothesis_id
    ):
        first_score = 1.0
    elif (
        evidence_vote == discovery_vote == second.hypothesis_id
    ):
        first_score = 0.0
    else:
        first_score = 0.5
    first_before = ratings[first.hypothesis_id]
    second_before = ratings[second.hypothesis_id]
    expected = 1.0 / (
        1.0 + 10.0 ** ((second_before - first_before) / 400.0)
    )
    change = k_factor * (first_score - expected)
    first_after = first_before + change
    second_after = second_before - change
    ratings[first.hypothesis_id] = first_after
    ratings[second.hypothesis_id] = second_after
    facets = {
        name: getattr(first_review, name)
        - getattr(second_review, name)
        for name in (
            "goal_alignment",
            "plausibility",
            "novelty",
            "testability",
            "feasibility",
            "evidence_grounding",
            "diversity_value",
            "assumption_risk",
        )
    }
    facets["experimental_prediction"] = (
        0 if experimental is None else int(experimental[0])
    )
    experimental_rationale = (
        "no executable prediction-disagreement experiment was available"
        if experimental is None
        else experimental[1]
    )
    return HypothesisMatch(
        match_index=match_index,
        first_hypothesis_id=first.hypothesis_id,
        second_hypothesis_id=second.hypothesis_id,
        first_rating_before=first_before,
        second_rating_before=second_before,
        first_score=first_score,
        first_rating_after=first_after,
        second_rating_after=second_after,
        order_votes=(evidence_vote, discovery_vote),
        facet_deltas=facets,
        rationale=(
            "the evidence vote used an executable prediction-disagreement "
            "experiment when available, while an independent "
            "novelty-and-diversity vote preserved bounded exploration; "
            + experimental_rationale
        ),
    )


def run_hypothesis_tournament(
    seeds: Sequence[TournamentHypothesis],
    *,
    review: ReviewFunction,
    evolve: EvolutionFunction,
    generations: int = 2,
    survivor_count: int = 5,
    initial_rating: float = 1200.0,
    k_factor: float = 32.0,
    tournament_ref: str = "structured-elo-hypothesis-tournament-v1",
    literature_query_ids: Sequence[str] = (),
    literature_source_refs: Sequence[str] = (),
    experimental_compare: Optional[
        ExperimentalMatchFunction
    ] = None,
    required_discovery_channels: Sequence[str] = (
        "ancestry",
        "de_novo",
        "hybrid",
        "cross_domain",
    ),
    minimum_seed_count: int = 6,
) -> HypothesisTournament:
    if generations < 1 or survivor_count < 1:
        raise ValueError("tournament generations and survivors must be positive")
    if minimum_seed_count < 2 or len(seeds) < minimum_seed_count:
        raise ValueError(
            "hypothesis tournament requires at least %d seeds"
            % minimum_seed_count
        )
    required_discovery_channels = tuple(required_discovery_channels)
    if not required_discovery_channels:
        raise ValueError("hypothesis tournament requires discovery channels")
    if len({item.target_node_id for item in seeds}) != 1:
        raise ValueError("hypothesis tournament seeds target multiple nodes")
    proposed_hypotheses = list(seeds)
    if len(
        {item.hypothesis_id for item in proposed_hypotheses}
    ) != len(proposed_hypotheses):
        raise ValueError("hypothesis tournament seeds contain duplicates")
    admitted_seeds, generation_audit = build_hypothesis_generation_audit(
        proposed_hypotheses,
        literature_query_ids=literature_query_ids,
        literature_source_refs=literature_source_refs,
    )
    if len(admitted_seeds) < 4:
        raise ValueError(
            "canonical admission left too few distinct hypotheses"
        )
    hypotheses = list(admitted_seeds)
    reviews: Dict[str, HypothesisReview] = {}
    ratings: Dict[str, float] = {}
    matches = []
    played_pairs = set()
    completed_generations = 0

    def add_hypothesis(hypothesis: TournamentHypothesis) -> None:
        if hypothesis.hypothesis_id in reviews:
            raise ValueError("evolution generated a duplicate hypothesis")
        if hypothesis.origin == HypothesisOrigin.EVOLUTION:
            by_id = {
                item.hypothesis_id: item for item in hypotheses
            }
            if not set(hypothesis.parent_ids).issubset(by_id):
                raise ValueError(
                    "evolution generated a hypothesis with unknown parents"
                )
            if hypothesis.executable_contract is not None:
                parent_digests = {
                    by_id[parent_id].executable_contract.executable_digest
                    for parent_id in hypothesis.parent_ids
                    if by_id[parent_id].executable_contract is not None
                }
                if (
                    hypothesis.executable_contract.executable_digest
                    in parent_digests
                ):
                    raise ValueError(
                        "causal evolution copied a parent executable"
                    )
            if any(
                hypothesis.predictions == by_id[parent_id].predictions
                for parent_id in hypothesis.parent_ids
            ):
                raise ValueError(
                    "causal evolution copied a parent prediction"
                )
        hypothesis_review = review(hypothesis)
        if hypothesis_review.hypothesis_id != hypothesis.hypothesis_id:
            raise ValueError("review belongs to another hypothesis")
        hypotheses.append(hypothesis)
        reviews[hypothesis.hypothesis_id] = hypothesis_review
        ratings[hypothesis.hypothesis_id] = initial_rating

    initial = tuple(hypotheses)
    hypotheses.clear()
    for hypothesis in initial:
        add_hypothesis(hypothesis)

    def play(first: TournamentHypothesis, second: TournamentHypothesis) -> None:
        pair = frozenset((first.hypothesis_id, second.hypothesis_id))
        if pair in played_pairs:
            return
        played_pairs.add(pair)
        matches.append(
            _play_match(
                len(matches),
                first,
                second,
                reviews,
                ratings,
                k_factor=k_factor,
                experimental_compare=experimental_compare,
            )
        )

    for index, first in enumerate(hypotheses):
        for second in hypotheses[index + 1 :]:
            play(first, second)

    for generation in range(1, generations + 1):
        ranked = tuple(
            sorted(
                hypotheses,
                key=lambda item: (
                    -ratings[item.hypothesis_id],
                    -reviews[item.hypothesis_id].quality_score,
                    item.hypothesis_id,
                ),
            )
        )
        descendants = evolve(generation, ranked, reviews)
        if not descendants:
            break
        completed_generations = generation
        previous = tuple(hypotheses)
        for descendant in descendants:
            if descendant.origin != HypothesisOrigin.EVOLUTION:
                raise ValueError(
                    "tournament descendants must have evolution origin"
                )
            if descendant.hypothesis_id in {
                item.hypothesis_id for item in proposed_hypotheses
            }:
                raise ValueError(
                    "evolution generated an identical proposal artifact"
                )
            proposed_hypotheses.append(descendant)
        admitted, generation_audit = build_hypothesis_generation_audit(
            proposed_hypotheses,
            literature_query_ids=literature_query_ids,
            literature_source_refs=literature_source_refs,
        )
        admitted_ids = {item.hypothesis_id for item in hypotheses}
        for descendant in admitted:
            if descendant.hypothesis_id not in admitted_ids:
                add_hypothesis(descendant)
        new_items = tuple(hypotheses[len(previous) :])
        proximity = _proximities(hypotheses)
        for new_item in new_items:
            nearest_ids = [
                (
                    edge.second_hypothesis_id
                    if edge.first_hypothesis_id == new_item.hypothesis_id
                    else edge.first_hypothesis_id,
                    edge.similarity,
                )
                for edge in proximity
                if new_item.hypothesis_id
                in (
                    edge.first_hypothesis_id,
                    edge.second_hypothesis_id,
                )
            ]
            opponent_ids = {
                item.hypothesis_id for item in ranked[:2]
            }
            opponent_ids.update(
                hypothesis_id
                for hypothesis_id, _ in sorted(
                    nearest_ids,
                    key=lambda item: (-item[1], item[0]),
                )[:2]
            )
            by_id = {
                item.hypothesis_id: item for item in hypotheses
            }
            for opponent_id in sorted(opponent_ids):
                if opponent_id != new_item.hypothesis_id:
                    play(new_item, by_id[opponent_id])
        for index, first in enumerate(new_items):
            for second in new_items[index + 1 :]:
                play(first, second)

    ranked = tuple(
        sorted(
            hypotheses,
            key=lambda item: (
                -ratings[item.hypothesis_id],
                -reviews[item.hypothesis_id].quality_score,
                item.hypothesis_id,
            ),
        )
    )
    eligible = tuple(item for item in ranked if item.revision_eligible)
    survivor_ids = tuple(
        item.hypothesis_id for item in ranked[:survivor_count]
    )
    if (
        eligible
        and eligible[0].hypothesis_id not in survivor_ids
    ):
        survivor_ids = (
            *survivor_ids[:-1],
            eligible[0].hypothesis_id,
        )
    common_weaknesses = sorted(
        {
            critique
            for hypothesis in ranked[:survivor_count]
            for critique in reviews[hypothesis.hypothesis_id].critique
        }
    )
    return HypothesisTournament(
        target_node_id=ranked[0].target_node_id,
        hypotheses=ranked,
        reviews=tuple(
            reviews[hypothesis.hypothesis_id]
            for hypothesis in ranked
        ),
        proximities=_proximities(ranked),
        matches=tuple(matches),
        final_ratings=dict(ratings),
        survivor_ids=survivor_ids,
        champion_id=ranked[0].hypothesis_id,
        eligible_champion_id=(
            None if not eligible else eligible[0].hypothesis_id
        ),
        generations_completed=completed_generations,
        meta_review=(
            (
                "Elo used executable prediction-disagreement experiments "
                "where hypotheses exposed distinct actions; ratings remain "
                "an internal allocation signal, not a performance claim."
            ),
            "Common survivor critiques: "
            + "; ".join(common_weaknesses[:4]),
            "Only a revision-eligible survivor may select executable search.",
        ),
        tournament_ref=tournament_ref,
        generation_audit=generation_audit,
        initial_rating=initial_rating,
        k_factor=k_factor,
        required_discovery_channels=required_discovery_channels,
    )
