from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

from scientist.core.artifacts import content_digest
from scientist.program.causal_failure import (
    CausalFailureModelSet,
    CausalRole,
    REQUIRED_CAUSAL_ROLES,
)
from scientist.program.hypothesis_tournament import HypothesisTournament
from scientist.program.mechanism_discovery import MechanismDiscoveryTrace


CROSS_DOMAIN_INSPIRATION_VERSION = "cross-domain-mechanism-transfer-v2"


@dataclass(frozen=True)
class MechanismMapping:
    """One explicit structural correspondence in a domain transfer."""

    source_element: str
    target_element: str
    transfer_argument: str
    causal_role: Optional[CausalRole] = None
    target_model_id: Optional[str] = None

    def __post_init__(self) -> None:
        if not all(
            (
                self.source_element,
                self.target_element,
                self.transfer_argument,
            )
        ):
            raise ValueError("mechanism mapping fields must not be empty")
        if (self.causal_role is None) != (self.target_model_id is None):
            raise ValueError(
                "causal mapping role and target model must appear together"
            )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "source_element": self.source_element,
            "target_element": self.target_element,
            "transfer_argument": self.transfer_argument,
            "causal_role": (
                None
                if self.causal_role is None
                else self.causal_role.value
            ),
            "target_model_id": self.target_model_id,
        }


@dataclass(frozen=True)
class CrossDomainInspiration:
    """A falsifiable mechanism transfer, not a surface-level analogy."""

    target_node_id: str
    target_domain: str
    source_domain: str
    source_problem: str
    source_mechanism: str
    source_reference: str
    invariant: str
    mappings: Tuple[MechanismMapping, ...]
    boundary_conditions: Tuple[str, ...]
    broken_assumptions: Tuple[str, ...]
    transferred_hypothesis: str
    distinguishing_predictions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    implementation_sketch: str
    generator_ref: str

    def __post_init__(self) -> None:
        required = (
            self.target_node_id,
            self.target_domain,
            self.source_domain,
            self.source_problem,
            self.source_mechanism,
            self.source_reference,
            self.invariant,
            self.transferred_hypothesis,
            self.implementation_sketch,
            self.generator_ref,
        )
        if not all(required):
            raise ValueError(
                "cross-domain inspiration identity and mechanism are required"
            )
        if self.target_domain.casefold() == self.source_domain.casefold():
            raise ValueError(
                "cross-domain inspiration must come from another domain"
            )
        if len(self.mappings) < 2:
            raise ValueError(
                "mechanism transfer requires at least two explicit mappings"
            )
        mapping_pairs = {
            (
                item.source_element,
                item.target_element,
                item.causal_role,
                item.target_model_id,
            )
            for item in self.mappings
        }
        if len(mapping_pairs) != len(self.mappings):
            raise ValueError("mechanism mappings must be distinct")
        if not self.boundary_conditions or not self.broken_assumptions:
            raise ValueError(
                "domain transfer requires boundaries and broken assumptions"
            )
        if len(self.distinguishing_predictions) < 2:
            raise ValueError(
                "domain transfer requires two distinguishing predictions"
            )
        if len(self.falsification_conditions) < 2:
            raise ValueError(
                "domain transfer requires two falsification conditions"
            )

    @property
    def inspiration_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": CROSS_DOMAIN_INSPIRATION_VERSION,
            "target_node_id": self.target_node_id,
            "target_domain": self.target_domain,
            "source_domain": self.source_domain,
            "source_problem": self.source_problem,
            "source_mechanism": self.source_mechanism,
            "source_reference": self.source_reference,
            "invariant": self.invariant,
            "mappings": [item.as_dict() for item in self.mappings],
            "boundary_conditions": list(self.boundary_conditions),
            "broken_assumptions": list(self.broken_assumptions),
            "transferred_hypothesis": self.transferred_hypothesis,
            "distinguishing_predictions": list(
                self.distinguishing_predictions
            ),
            "falsification_conditions": list(
                self.falsification_conditions
            ),
            "implementation_sketch": self.implementation_sketch,
            "generator_ref": self.generator_ref,
        }
        if include_id:
            value["inspiration_id"] = self.inspiration_id
        return value


@dataclass(frozen=True)
class TransferEvaluation:
    """Ordinal review of one transfer before it can seed a hypothesis."""

    inspiration_id: str
    structural_fit: int
    surprise: int
    testability: int
    evidence_grounding: int
    assumption_risk: int
    estimated_compute: float
    rationale: str

    def __post_init__(self) -> None:
        if not self.inspiration_id or not self.rationale:
            raise ValueError("transfer evaluation identity is required")
        grades = (
            self.structural_fit,
            self.surprise,
            self.testability,
            self.evidence_grounding,
            self.assumption_risk,
        )
        if any(
            not isinstance(grade, int) or not 0 <= grade <= 3
            for grade in grades
        ):
            raise ValueError("transfer grades must be integers from zero to three")
        if (
            not math.isfinite(self.estimated_compute)
            or self.estimated_compute <= 0
        ):
            raise ValueError(
                "transfer evaluation compute must be positive and finite"
            )

    @property
    def truth_score(self) -> int:
        return (
            2 * self.structural_fit
            + 2 * self.testability
            + self.evidence_grounding
            - self.assumption_risk
        )

    @property
    def bounded_risk_reward(self) -> int:
        return (
            min(self.assumption_risk, 2)
            - 2 * max(0, self.assumption_risk - 2)
        )

    @property
    def discovery_score(self) -> int:
        return (
            2 * self.structural_fit
            + 2 * self.surprise
            + self.testability
            + self.evidence_grounding
            + self.bounded_risk_reward
        )

    @property
    def priority_score(self) -> int:
        """Select experiments by discovery value, not claim confidence."""
        return self.discovery_score

    def as_dict(self) -> Dict[str, Any]:
        return {
            "inspiration_id": self.inspiration_id,
            "structural_fit": self.structural_fit,
            "surprise": self.surprise,
            "testability": self.testability,
            "evidence_grounding": self.evidence_grounding,
            "assumption_risk": self.assumption_risk,
            "estimated_compute": self.estimated_compute,
            "bounded_risk_reward": self.bounded_risk_reward,
            "truth_score": self.truth_score,
            "discovery_score": self.discovery_score,
            "priority_score": self.priority_score,
            "rationale": self.rationale,
        }


@dataclass(frozen=True)
class CrossDomainInspirationPortfolio:
    """A diverse, scored set of transfers for one hypothesis revision."""

    target_node_id: str
    inspirations: Tuple[CrossDomainInspiration, ...]
    evaluations: Tuple[TransferEvaluation, ...]
    selected_inspiration_ids: Tuple[str, ...]
    selection_rationale: str
    synthesizer_ref: str
    causal_failure_models: Optional[CausalFailureModelSet] = None
    discovery_trace: Optional[MechanismDiscoveryTrace] = None
    tournament: Optional[HypothesisTournament] = None

    def __post_init__(self) -> None:
        if (
            not self.target_node_id
            or not self.selection_rationale
            or not self.synthesizer_ref
        ):
            raise ValueError("inspiration portfolio provenance is required")
        if len(self.inspirations) < 3:
            raise ValueError(
                "inspiration portfolio requires at least three transfers"
            )
        if any(
            item.target_node_id != self.target_node_id
            for item in self.inspirations
        ):
            raise ValueError("inspiration portfolio targets multiple nodes")
        target_domains = {
            item.target_domain.casefold() for item in self.inspirations
        }
        if len(target_domains) != 1:
            raise ValueError("inspiration portfolio targets multiple domains")
        source_domains = {
            item.source_domain.casefold() for item in self.inspirations
        }
        if len(source_domains) < 3:
            raise ValueError(
                "inspiration portfolio requires three source domains"
            )
        inspiration_ids = {
            item.inspiration_id for item in self.inspirations
        }
        if len(inspiration_ids) != len(self.inspirations):
            raise ValueError("inspiration portfolio contains duplicates")
        if self.discovery_trace is not None:
            if self.causal_failure_models is None:
                raise ValueError(
                    "discovered transfers require causal failure models"
                )
            if (
                self.discovery_trace.query.target_node_id
                != self.target_node_id
            ):
                raise ValueError(
                    "mechanism discovery targets another goal node"
                )
            if (
                self.discovery_trace.query.causal_failure_models.model_set_id
                != self.causal_failure_models.model_set_id
            ):
                raise ValueError(
                    "portfolio and discovery use different causal models"
                )
            discovered_domains = {
                candidate.source_domain.casefold()
                for candidate in self.discovery_trace.candidates
                if candidate.discovery_id
                in self.discovery_trace.selected_discovery_ids
            }
            if not source_domains.issubset(discovered_domains):
                raise ValueError(
                    "inspirations were not selected by discovery trace"
                )
            required_mapping_keys = {
                (model.model_id, role)
                for model in self.causal_failure_models.models
                for role in REQUIRED_CAUSAL_ROLES
            }
            for inspiration in self.inspirations:
                observed_mapping_keys = {
                    (mapping.target_model_id, mapping.causal_role)
                    for mapping in inspiration.mappings
                    if mapping.causal_role is not None
                }
                if observed_mapping_keys != required_mapping_keys:
                    raise ValueError(
                        "transfer lacks a complete relational analogy"
                    )
        if self.tournament is not None:
            if self.tournament.target_node_id != self.target_node_id:
                raise ValueError(
                    "hypothesis tournament targets another goal node"
                )
            tournament_inspiration_ids = {
                inspiration_id
                for hypothesis in self.tournament.hypotheses
                for inspiration_id in hypothesis.inspiration_ids
            }
            tournament_inspiration_ids.update(
                inspiration_id
                for group in (
                    self.tournament.generation_audit.equivalence_classes
                )
                for inspiration_id in group.inspiration_ids
            )
            if not inspiration_ids.issubset(
                tournament_inspiration_ids
            ):
                raise ValueError(
                    "every transfer must enter the hypothesis tournament"
                )
        evaluation_ids = {
            item.inspiration_id for item in self.evaluations
        }
        if evaluation_ids != inspiration_ids:
            raise ValueError(
                "every inspiration requires exactly one transfer evaluation"
            )
        if len(evaluation_ids) != len(self.evaluations):
            raise ValueError("transfer evaluations contain duplicates")
        selected = set(self.selected_inspiration_ids)
        if (
            not selected
            or len(selected) != len(self.selected_inspiration_ids)
            or not selected.issubset(inspiration_ids)
        ):
            raise ValueError("selected inspiration IDs are invalid")
        priority = {
            item.inspiration_id: item.priority_score
            for item in self.evaluations
        }
        unselected = inspiration_ids.difference(selected)
        if unselected and min(priority[item] for item in selected) < max(
            priority[item] for item in unselected
        ):
            raise ValueError(
                "selected transfers must be the highest-priority tier"
            )

    @property
    def portfolio_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": CROSS_DOMAIN_INSPIRATION_VERSION,
            "target_node_id": self.target_node_id,
            "inspirations": [
                item.as_dict() for item in self.inspirations
            ],
            "evaluations": [
                item.as_dict() for item in self.evaluations
            ],
            "selected_inspiration_ids": list(
                self.selected_inspiration_ids
            ),
            "selection_rationale": self.selection_rationale,
            "synthesizer_ref": self.synthesizer_ref,
            "causal_failure_models": (
                None
                if self.causal_failure_models is None
                else self.causal_failure_models.as_dict()
            ),
            "discovery_trace": (
                None
                if self.discovery_trace is None
                else self.discovery_trace.as_dict()
            ),
            "tournament": (
                None
                if self.tournament is None
                else self.tournament.as_dict()
            ),
        }
        if include_id:
            value["portfolio_id"] = self.portfolio_id
        return value
