from __future__ import annotations

from typing import Mapping, Protocol, Sequence

from scientist.program.contracts import (
    DecompositionProposal,
    HighLevelGoal,
    NodeAssessment,
    ResearchNode,
)
from scientist.program.goal_graph import (
    GoalGraphDecompositionProposal,
    GoalNodeSpec,
)
from scientist.program.literature import PriorArtAssessment


class GoalDecomposer(Protocol):
    name: str
    decomposer_version: str

    def propose(
        self,
        goal: HighLevelGoal,
        existing_nodes: Mapping[str, ResearchNode],
    ) -> Sequence[DecompositionProposal]:
        ...


class ProgramAssessor(Protocol):
    name: str
    assessor_version: str

    def assess(
        self,
        goal: HighLevelGoal,
        nodes: Sequence[ResearchNode],
    ) -> Sequence[NodeAssessment]:
        ...


class GoalGraphDecomposer(Protocol):
    """Replaceable planner for one recursively selected goal-graph node."""

    name: str
    decomposer_version: str

    def decompose(
        self,
        goal: HighLevelGoal,
        parent: GoalNodeSpec,
        existing_nodes: Mapping[str, GoalNodeSpec],
        literature: PriorArtAssessment,
    ) -> GoalGraphDecompositionProposal:
        ...
