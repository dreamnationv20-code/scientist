from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Mapping, Optional, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.program.contracts import PROGRAM_ARCHITECTURE_VERSION


class ProgramEventKind(str, Enum):
    GOAL_REGISTERED = "goal_registered"
    DECOMPOSITION_REGISTERED = "decomposition_registered"
    NODE_ASSESSED = "node_assessed"
    PORTFOLIO_SELECTED = "portfolio_selected"
    PORTFOLIO_GOVERNANCE_EVALUATED = (
        "portfolio_governance_evaluated"
    )
    PORTFOLIO_SUSPENDED = "portfolio_suspended"
    NODE_ACTIVATED = "node_activated"
    CHILD_CHARTER_REGISTERED = "child_charter_registered"
    CHILD_CAMPAIGN_PROGRESS_RECORDED = (
        "child_campaign_progress_recorded"
    )
    PRIOR_ART_ASSESSMENT_REGISTERED = (
        "prior_art_assessment_registered"
    )
    CLAIM_AUTHORIZATION_EVALUATED = (
        "claim_authorization_evaluated"
    )
    CHILD_RESULT_INGESTED = "child_result_ingested"
    DECOMPOSITION_REVISED = "decomposition_revised"
    INTEGRATION_EVALUATED = "integration_evaluated"
    GOAL_RESOLVED = "goal_resolved"
    RUNTIME_COMPONENT_UPGRADED = "runtime_component_upgraded"


@dataclass(frozen=True)
class ProgramEvent:
    sequence: int
    goal_id: str
    kind: ProgramEventKind
    payload: Mapping[str, Any]
    actor_ref: str
    previous_event_id: Optional[str]

    @property
    def event_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "program_architecture_version": (
                PROGRAM_ARCHITECTURE_VERSION
            ),
            "sequence": self.sequence,
            "goal_id": self.goal_id,
            "kind": self.kind.value,
            "payload": dict(self.payload),
            "actor_ref": self.actor_ref,
            "previous_event_id": self.previous_event_id,
        }
        if include_id:
            value["event_id"] = self.event_id
        return value


class ResearchProgramLedger:
    def __init__(
        self,
        goal_id: str,
        artifact_store: Optional[ArtifactStore] = None,
    ) -> None:
        if not goal_id:
            raise ValueError("goal_id must not be empty")
        self.goal_id = goal_id
        self._events: List[ProgramEvent] = []
        self._artifact_store = artifact_store
        self._artifact_digests: List[str] = []

    @property
    def events(self) -> Tuple[ProgramEvent, ...]:
        return tuple(self._events)

    def append(
        self,
        kind: ProgramEventKind,
        payload: Mapping[str, Any],
        actor_ref: str,
    ) -> ProgramEvent:
        if not actor_ref:
            raise ValueError("actor_ref must not be empty")
        if not self._events and kind != ProgramEventKind.GOAL_REGISTERED:
            raise ValueError(
                "the first program event must register the goal"
            )
        if self._events and kind == ProgramEventKind.GOAL_REGISTERED:
            raise ValueError("the goal may be registered only once")
        if any(
            event.kind == ProgramEventKind.GOAL_RESOLVED
            for event in self._events
        ):
            raise ValueError("a resolved research program is immutable")
        event = ProgramEvent(
            sequence=len(self._events),
            goal_id=self.goal_id,
            kind=kind,
            payload=dict(payload),
            actor_ref=actor_ref,
            previous_event_id=(
                self._events[-1].event_id if self._events else None
            ),
        )
        self._events.append(event)
        if self._artifact_store is not None:
            digest = self._artifact_store.put(
                "research_program_event",
                event.as_dict(),
            )
            self._artifact_digests.append(digest)
        return event

    def verify_chain(self) -> bool:
        previous = None
        for sequence, event in enumerate(self._events):
            if event.sequence != sequence:
                return False
            if event.previous_event_id != previous:
                return False
            previous = event.event_id
        return True

    def as_dict(self) -> Dict[str, Any]:
        return {
            "program_architecture_version": (
                PROGRAM_ARCHITECTURE_VERSION
            ),
            "goal_id": self.goal_id,
            "event_count": len(self._events),
            "chain_valid": self.verify_chain(),
            "head_event_id": (
                self._events[-1].event_id if self._events else None
            ),
            "events": [event.as_dict() for event in self._events],
            "artifact_digests": list(self._artifact_digests),
        }

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
        artifact_store: Optional[ArtifactStore] = None,
    ) -> "ResearchProgramLedger":
        ledger = cls(str(value["goal_id"]), artifact_store=artifact_store)
        ledger._events = [
            ProgramEvent(
                sequence=int(event["sequence"]),
                goal_id=str(event["goal_id"]),
                kind=ProgramEventKind(event["kind"]),
                payload=dict(event["payload"]),
                actor_ref=str(event["actor_ref"]),
                previous_event_id=event["previous_event_id"],
            )
            for event in value.get("events", ())
        ]
        ledger._artifact_digests = list(
            value.get("artifact_digests", ())
        )
        if not ledger.verify_chain():
            raise ValueError("invalid research-program ledger chain")
        supplied_events = tuple(value.get("events", ()))
        if len(ledger._events) != len(supplied_events):
            raise ValueError("research-program event count mismatch")
        if any(
            event.event_id != supplied.get("event_id")
            for event, supplied in zip(ledger._events, supplied_events)
        ):
            raise ValueError("research-program event digest mismatch")
        if len(ledger._events) != int(value.get("event_count", -1)):
            raise ValueError("research-program ledger count mismatch")
        return ledger
