from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, IntEnum
from typing import Any, Dict, Optional, Tuple

from scientist.core.artifacts import content_digest


class LiteratureTrigger(str, Enum):
    INITIAL_SCOPE = "initial_scope"
    NEW_PHENOMENON = "new_phenomenon"
    NEW_INTERVENTION = "new_intervention"
    REPLICATION_NOMINATION = "replication_nomination"
    CLAIM_ESCALATION = "claim_escalation"
    PERIODIC_DELTA = "periodic_delta"


class SearchFacet(str, Enum):
    PROBLEM = "problem"
    PHENOMENON = "phenomenon"
    INTERVENTION = "intervention"
    MECHANISM = "mechanism"
    EVALUATION = "evaluation"
    CITATION_NEIGHBORHOOD = "citation_neighborhood"


class PriorArtRelation(str, Enum):
    DUPLICATES_CORE = "duplicates_core"
    STRONG_OVERLAP = "strong_overlap"
    EXECUTABLE_BASELINE = "executable_baseline"
    ADJACENT = "adjacent"


class ClaimClassification(str, Enum):
    NOT_APPLICABLE = "not_applicable"
    REPRODUCTION = "reproduction"
    REDISCOVERY = "rediscovery"
    INCREMENTAL_ADVANCE = "incremental_advance"
    NOVEL_CANDIDATE = "novel_candidate"


class ClaimLevel(IntEnum):
    INTERNAL_OBSERVATION = 0
    REPLICATED_EFFECT = 1
    FRONTIER_ADVANCE = 2
    BREAKTHROUGH = 3


@dataclass(frozen=True)
class ClaimSignature:
    subject_id: str
    statement: str
    problem: str
    phenomenon: str
    intervention: str
    mechanism: str
    evaluation: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.subject_id,
                self.statement,
                self.problem,
                self.phenomenon,
                self.intervention,
                self.mechanism,
                self.evaluation,
            )
        ):
            raise ValueError("claim-signature fields must not be empty")

    @property
    def signature_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "subject_id": self.subject_id,
            "statement": self.statement,
            "problem": self.problem,
            "phenomenon": self.phenomenon,
            "intervention": self.intervention,
            "mechanism": self.mechanism,
            "evaluation": self.evaluation,
        }
        if include_id:
            value["signature_id"] = self.signature_id
        return value


@dataclass(frozen=True)
class LiteratureQuery:
    query: str
    facet: SearchFacet
    provider: str

    def __post_init__(self) -> None:
        if not self.query or not self.provider:
            raise ValueError("literature-query fields must not be empty")

    def as_dict(self) -> Dict[str, str]:
        return {
            "query": self.query,
            "facet": self.facet.value,
            "provider": self.provider,
        }


@dataclass(frozen=True)
class PriorWork:
    work_id: str
    title: str
    year: int
    locator: str
    relation: PriorArtRelation
    matched_components: Tuple[str, ...]
    executable: bool = False
    abstract: str = ""

    def __post_init__(self) -> None:
        if not self.work_id or not self.title or not self.locator:
            raise ValueError("prior-work identity must not be empty")
        if self.year <= 0:
            raise ValueError("prior-work year must be positive")
        if not self.matched_components:
            raise ValueError("prior work requires matched components")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "work_id": self.work_id,
            "title": self.title,
            "year": self.year,
            "locator": self.locator,
            "relation": self.relation.value,
            "matched_components": list(self.matched_components),
            "executable": self.executable,
            "abstract": self.abstract,
        }


@dataclass(frozen=True)
class PriorArtAssessment:
    signature: ClaimSignature
    trigger: LiteratureTrigger
    queries: Tuple[LiteratureQuery, ...]
    closest_works: Tuple[PriorWork, ...]
    classification: ClaimClassification
    rationale: str
    novel_delta: Tuple[str, ...]
    citation_snowball_complete: bool
    searched_at: str
    reviewer_ref: str
    executable_incumbent_id: Optional[str] = None

    def __post_init__(self) -> None:
        if not self.rationale or not self.searched_at or not self.reviewer_ref:
            raise ValueError("prior-art assessment provenance is required")
        work_ids = {work.work_id for work in self.closest_works}
        if len(work_ids) != len(self.closest_works):
            raise ValueError("closest prior works must be unique")
        if (
            self.executable_incumbent_id is not None
            and self.executable_incumbent_id not in work_ids
        ):
            raise ValueError(
                "executable incumbent must be one of the closest works"
            )
        if self.executable_incumbent_id is not None:
            incumbent = next(
                work
                for work in self.closest_works
                if work.work_id == self.executable_incumbent_id
            )
            if not incumbent.executable:
                raise ValueError(
                    "declared executable incumbent is not executable"
                )
        if (
            self.classification
            in (
                ClaimClassification.INCREMENTAL_ADVANCE,
                ClaimClassification.NOVEL_CANDIDATE,
            )
            and not self.novel_delta
        ):
            raise ValueError(
                "advance classifications require an explicit novel delta"
            )

    @property
    def closure_failures(self) -> Tuple[str, ...]:
        if self.classification == ClaimClassification.NOT_APPLICABLE:
            return ()
        required_facets = {
            SearchFacet.PROBLEM,
            SearchFacet.INTERVENTION,
            SearchFacet.MECHANISM,
            SearchFacet.CITATION_NEIGHBORHOOD,
        }
        observed_facets = {query.facet for query in self.queries}
        providers = {query.provider for query in self.queries}
        failures = []
        missing = required_facets.difference(observed_facets)
        if missing:
            failures.append(
                "missing search facets: %s"
                % ", ".join(sorted(facet.value for facet in missing))
            )
        if len(providers) < 2:
            failures.append("fewer than two literature providers searched")
        if not self.closest_works:
            failures.append("no closest prior work recorded")
        if not self.citation_snowball_complete:
            failures.append("citation-neighborhood search is incomplete")
        if (
            self.classification
            in (
                ClaimClassification.INCREMENTAL_ADVANCE,
                ClaimClassification.NOVEL_CANDIDATE,
            )
            and self.executable_incumbent_id is None
        ):
            failures.append("no executable published incumbent recorded")
        return tuple(failures)

    @property
    def closure_passed(self) -> bool:
        return not self.closure_failures

    @property
    def assessment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "signature": self.signature.as_dict(),
            "trigger": self.trigger.value,
            "queries": [query.as_dict() for query in self.queries],
            "closest_works": [
                work.as_dict() for work in self.closest_works
            ],
            "classification": self.classification.value,
            "rationale": self.rationale,
            "novel_delta": list(self.novel_delta),
            "citation_snowball_complete": (
                self.citation_snowball_complete
            ),
            "searched_at": self.searched_at,
            "reviewer_ref": self.reviewer_ref,
            "executable_incumbent_id": self.executable_incumbent_id,
            "closure_passed": self.closure_passed,
            "closure_failures": list(self.closure_failures),
        }
        if include_id:
            value["assessment_id"] = self.assessment_id
        return value


@dataclass(frozen=True)
class ClaimAuthorization:
    subject_id: str
    claim_id: str
    assessment_id: str
    requested_level: ClaimLevel
    authorized: bool
    reasons: Tuple[str, ...]
    frontier_comparison_evidence_ids: Tuple[str, ...] = ()
    external_confirmation_evidence_ids: Tuple[str, ...] = ()
    broad_impact_evidence_ids: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.subject_id or not self.claim_id or not self.assessment_id:
            raise ValueError("claim-authorization identity is required")
        if self.authorized and self.reasons:
            raise ValueError(
                "authorized claim cannot retain denial reasons"
            )

    @property
    def authorization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "subject_id": self.subject_id,
            "claim_id": self.claim_id,
            "assessment_id": self.assessment_id,
            "requested_level": self.requested_level.name.lower(),
            "authorized": self.authorized,
            "reasons": list(self.reasons),
            "frontier_comparison_evidence_ids": list(
                self.frontier_comparison_evidence_ids
            ),
            "external_confirmation_evidence_ids": list(
                self.external_confirmation_evidence_ids
            ),
            "broad_impact_evidence_ids": list(
                self.broad_impact_evidence_ids
            ),
        }
        if include_id:
            value["authorization_id"] = self.authorization_id
        return value


def evaluate_claim_authorization(
    assessment: PriorArtAssessment,
    claim_id: str,
    requested_level: ClaimLevel,
    frontier_comparison_evidence_ids: Tuple[str, ...] = (),
    external_confirmation_evidence_ids: Tuple[str, ...] = (),
    broad_impact_evidence_ids: Tuple[str, ...] = (),
) -> ClaimAuthorization:
    if not claim_id:
        raise ValueError("claim_id must not be empty")
    reasons = list(assessment.closure_failures)
    if requested_level >= ClaimLevel.FRONTIER_ADVANCE:
        if assessment.classification not in (
            ClaimClassification.INCREMENTAL_ADVANCE,
            ClaimClassification.NOVEL_CANDIDATE,
        ):
            reasons.append(
                "prior-art classification does not support a frontier advance"
            )
        if not frontier_comparison_evidence_ids:
            reasons.append("no executable-frontier comparison evidence")
    if requested_level >= ClaimLevel.BREAKTHROUGH:
        if assessment.classification != ClaimClassification.NOVEL_CANDIDATE:
            reasons.append(
                "prior-art classification does not support novelty"
            )
        if not external_confirmation_evidence_ids:
            reasons.append("no external confirmation evidence")
        if not broad_impact_evidence_ids:
            reasons.append("no broad-impact evidence")
    return ClaimAuthorization(
        subject_id=assessment.signature.subject_id,
        claim_id=claim_id,
        assessment_id=assessment.assessment_id,
        requested_level=requested_level,
        authorized=not reasons,
        reasons=tuple(reasons),
        frontier_comparison_evidence_ids=(
            frontier_comparison_evidence_ids
        ),
        external_confirmation_evidence_ids=(
            external_confirmation_evidence_ids
        ),
        broad_impact_evidence_ids=broad_impact_evidence_ids,
    )
