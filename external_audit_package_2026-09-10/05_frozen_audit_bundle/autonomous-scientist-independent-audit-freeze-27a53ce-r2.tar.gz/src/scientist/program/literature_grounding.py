from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.program.literature import (
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
)


LITERATURE_GROUNDING_VERSION = "literature-source-packet-context-v6"
_TOKEN_PATTERN = re.compile(r"[a-z0-9]+")
_SENTENCE_PATTERN = re.compile(r"(?<=[.!?])\s+")


@dataclass(frozen=True)
class LiteratureMechanismVocabulary:
    mechanism_terms: Mapping[str, Tuple[str, ...]]
    contrastive_frontier: Mapping[str, Tuple[str, ...]]
    vocabulary_ref: str
    channel_exclusions: Mapping[str, Tuple[str, ...]] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        if not self.mechanism_terms or not self.vocabulary_ref:
            raise ValueError("literature mechanism vocabulary is incomplete")


def _normalized_text(values: Iterable[str]) -> str:
    return " ".join(values).casefold().replace("_", " ")


def _mechanisms(
    text: str,
    vocabulary: LiteratureMechanismVocabulary,
) -> Tuple[str, ...]:
    return tuple(
        mechanism
        for mechanism, terms in vocabulary.mechanism_terms.items()
        if any(term in text for term in terms)
    )


def _evidence_excerpt(work: PriorWork) -> str:
    if work.abstract.strip():
        return " ".join(work.abstract.split())[:1200]
    return "; ".join(work.matched_components)


@dataclass(frozen=True)
class LiteratureMechanismEvidence:
    mechanism: str
    work_id: str
    title: str
    year: int
    locator: str
    relation: PriorArtRelation
    evidence_excerpt: str
    is_executable_incumbent: bool
    is_latest_cohort: bool

    def __post_init__(self) -> None:
        if not all(
            (
                self.mechanism,
                self.work_id,
                self.title,
                self.locator,
                self.evidence_excerpt,
            )
        ):
            raise ValueError("literature mechanism evidence is incomplete")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "mechanism": self.mechanism,
            "work_id": self.work_id,
            "title": self.title,
            "year": self.year,
            "locator": self.locator,
            "relation": self.relation.value,
            "evidence_excerpt": self.evidence_excerpt,
            "is_executable_incumbent": self.is_executable_incumbent,
            "is_latest_cohort": self.is_latest_cohort,
        }


@dataclass(frozen=True)
class LiteratureSourcePacket:
    """Paper content preserved as generative input, before taxonomy reduction."""

    work_id: str
    title: str
    year: int
    locator: str
    relation: PriorArtRelation
    abstract: str
    matched_components: Tuple[str, ...]
    mechanism_passages: Tuple[str, ...]
    equations: Tuple[str, ...]
    limitations: Tuple[str, ...]
    causal_mappings: Tuple[str, ...]
    executable: bool

    def __post_init__(self) -> None:
        if not all((self.work_id, self.title, self.locator)):
            raise ValueError("literature source packet identity is incomplete")
        if not self.abstract and not self.matched_components:
            raise ValueError("literature source packet has no generative content")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "work_id": self.work_id,
            "title": self.title,
            "year": self.year,
            "locator": self.locator,
            "relation": self.relation.value,
            "abstract": self.abstract,
            "matched_components": list(self.matched_components),
            "mechanism_passages": list(self.mechanism_passages),
            "equations": list(self.equations),
            "limitations": list(self.limitations),
            "causal_mappings": list(self.causal_mappings),
            "executable": self.executable,
        }


@dataclass(frozen=True)
class LiteratureHypothesisContext:
    island_family: str
    assessment_id: str
    searched_at: str
    source_work_ids: Tuple[str, ...]
    evidence: Tuple[LiteratureMechanismEvidence, ...]
    known_mechanisms: Tuple[str, ...]
    hypothesis_mechanisms: Tuple[str, ...]
    novelty_exclusions: Tuple[str, ...]
    open_questions: Tuple[str, ...]
    causal_questions: Tuple[str, ...] = ()
    source_packets: Tuple[LiteratureSourcePacket, ...] = ()
    builder_ref: str = "source-preserving-literature-proposer-builder-v2"
    grounding_mode: str = "legacy_domain_taxonomy"

    def __post_init__(self) -> None:
        if not self.island_family:
            raise ValueError("literature context requires a discovery channel")
        if not all(
            (
                self.assessment_id,
                self.searched_at,
                self.source_work_ids,
                self.evidence,
                self.hypothesis_mechanisms,
                self.builder_ref,
                self.grounding_mode,
            )
        ):
            raise ValueError("literature hypothesis context is incomplete")
        if len(set(self.source_work_ids)) != len(self.source_work_ids):
            raise ValueError("literature source works must be unique")

    @property
    def context_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def evidence_for(
        self,
        mechanism: str,
    ) -> Tuple[LiteratureMechanismEvidence, ...]:
        return tuple(
            item for item in self.evidence if item.mechanism == mechanism
        )

    def primary_evidence(
        self,
        mechanism: str,
    ) -> LiteratureMechanismEvidence | None:
        candidates = self.evidence_for(mechanism)
        if not candidates:
            return None
        relation_rank = {
            PriorArtRelation.DUPLICATES_CORE: 4,
            PriorArtRelation.EXECUTABLE_BASELINE: 3,
            PriorArtRelation.STRONG_OVERLAP: 2,
            PriorArtRelation.ADJACENT: 1,
        }
        return max(
            candidates,
            key=lambda item: (
                item.is_latest_cohort,
                item.year,
                relation_rank[item.relation],
                item.work_id,
            ),
        )

    def proposer_material(
        self,
        *,
        max_sources: int | None = None,
        excluded_terms: Sequence[str] = (),
        preferred_terms: Sequence[str] = (),
    ) -> str:
        """Return a focused raw-evidence packet for hypothesis generation.

        The durable context may contain a broad survey.  Generation receives a
        deterministic retrieval slice so lane isolation is not defeated by
        prompt stuffing or near-identical evidence across discovery channels.
        """

        packets = (
            [item.as_dict() for item in self.source_packets]
            if self.source_packets
            else [
                {
                    "work_id": item.work_id,
                    "title": item.title,
                    "year": item.year,
                    "locator": item.locator,
                    "relation": item.relation.value,
                    "abstract_or_evidence": item.evidence_excerpt,
                }
                for item in self.evidence
            ]
        )
        excluded = tuple(term.casefold() for term in excluded_terms if term)
        preferred = tuple(term.casefold() for term in preferred_terms if term)

        def searchable(packet: Mapping[str, Any]) -> str:
            return json.dumps(
                packet,
                sort_keys=True,
                separators=(",", ":"),
            ).casefold()

        eligible = [
            packet
            for packet in packets
            if not any(term in searchable(packet) for term in excluded)
        ]
        if not eligible:
            raise ValueError(
                "focused literature retrieval removed every source packet"
            )
        eligible.sort(
            key=lambda packet: (
                -sum(searchable(packet).count(term) for term in preferred),
                -int(packet.get("year", 0)),
                str(packet.get("work_id", "")),
            )
        )
        if max_sources is not None:
            if max_sources <= 0:
                raise ValueError("focused literature source limit must be positive")
            eligible = eligible[:max_sources]
        return json.dumps(
            {
                "island_family": self.island_family,
                "papers": eligible,
                "open_questions": list(self.open_questions),
                "causal_questions": list(self.causal_questions),
                "retrieval": {
                    "available_source_count": len(packets),
                    "selected_source_count": len(eligible),
                    "preferred_terms": list(preferred_terms),
                },
                "instruction": (
                    "Reason directly from paper mechanisms, equations, "
                    "limitations, and causal mappings. Do not translate them "
                    "into the architecture's mechanism labels."
                ),
            },
            sort_keys=True,
            separators=(",", ":"),
        )

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, Any],
    ) -> "LiteratureHypothesisContext":
        context = cls(
            island_family=str(value["island_family"]),
            assessment_id=str(value["assessment_id"]),
            searched_at=str(value["searched_at"]),
            source_work_ids=tuple(str(item) for item in value["source_work_ids"]),
            evidence=tuple(
                LiteratureMechanismEvidence(
                    mechanism=str(item["mechanism"]),
                    work_id=str(item["work_id"]),
                    title=str(item["title"]),
                    year=int(item["year"]),
                    locator=str(item["locator"]),
                    relation=PriorArtRelation(str(item["relation"])),
                    evidence_excerpt=str(item["evidence_excerpt"]),
                    is_executable_incumbent=bool(
                        item["is_executable_incumbent"]
                    ),
                    is_latest_cohort=bool(item["is_latest_cohort"]),
                )
                for item in value["evidence"]
            ),
            known_mechanisms=tuple(
                str(item) for item in value["known_mechanisms"]
            ),
            hypothesis_mechanisms=tuple(
                str(item) for item in value["hypothesis_mechanisms"]
            ),
            novelty_exclusions=tuple(
                str(item) for item in value["novelty_exclusions"]
            ),
            open_questions=tuple(str(item) for item in value["open_questions"]),
            causal_questions=tuple(
                str(item) for item in value.get("causal_questions", ())
            ),
            source_packets=tuple(
                LiteratureSourcePacket(
                    work_id=str(item["work_id"]),
                    title=str(item["title"]),
                    year=int(item["year"]),
                    locator=str(item["locator"]),
                    relation=PriorArtRelation(str(item["relation"])),
                    abstract=str(item["abstract"]),
                    matched_components=tuple(
                        str(component)
                        for component in item["matched_components"]
                    ),
                    mechanism_passages=tuple(
                        str(passage)
                        for passage in item["mechanism_passages"]
                    ),
                    equations=tuple(str(equation) for equation in item["equations"]),
                    limitations=tuple(
                        str(limitation) for limitation in item["limitations"]
                    ),
                    causal_mappings=tuple(
                        str(mapping) for mapping in item["causal_mappings"]
                    ),
                    executable=bool(item["executable"]),
                )
                for item in value.get("source_packets", ())
            ),
            builder_ref=str(value.get("builder_ref", cls.builder_ref)),
            grounding_mode=str(
                value.get("grounding_mode", "legacy_domain_taxonomy")
            ),
        )
        supplied_id = value.get("context_id")
        if supplied_id is not None and supplied_id != context.context_id:
            raise ValueError("literature context identity mismatch")
        return context

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": LITERATURE_GROUNDING_VERSION,
            "island_family": self.island_family,
            "assessment_id": self.assessment_id,
            "searched_at": self.searched_at,
            "source_work_ids": list(self.source_work_ids),
            "evidence": [item.as_dict() for item in self.evidence],
            "known_mechanisms": list(self.known_mechanisms),
            "hypothesis_mechanisms": list(
                self.hypothesis_mechanisms
            ),
            "novelty_exclusions": list(self.novelty_exclusions),
            "open_questions": list(self.open_questions),
            "causal_questions": list(self.causal_questions),
            "source_packets": [
                item.as_dict() for item in self.source_packets
            ],
            "builder_ref": self.builder_ref,
            "grounding_mode": self.grounding_mode,
        }
        if include_id:
            value["context_id"] = self.context_id
        return value


def build_literature_hypothesis_context(
    assessment: PriorArtAssessment,
    island_family: str,
    *,
    vocabulary: LiteratureMechanismVocabulary,
    causal_questions: Sequence[str] = (),
) -> LiteratureHypothesisContext:
    """Convert retrieved papers into contrastive, island-safe mechanisms.

    Published mechanisms become explicit exclusions.  Hypothesis mechanisms
    emphasize adjacent work, broken assumptions, and causal questions rather
    than simply replaying the strongest known method.
    """

    if not assessment.closure_passed:
        raise ValueError(
            "hypothesis generation requires a closed literature survey"
        )
    latest_year = max(work.year for work in assessment.closest_works)
    latest_floor = latest_year - 2
    evidence = []
    source_packets = []
    mechanisms_by_work: Dict[str, Tuple[str, ...]] = {}
    for work in assessment.closest_works:
        sentences = tuple(
            sentence.strip()
            for sentence in _SENTENCE_PATTERN.split(work.abstract.strip())
            if sentence.strip()
        )
        equations = tuple(
            sentence
            for sentence in sentences
            if re.search(
                r"(?:=|≤|≥|<|>|arg\s*max|arg\s*min|E\s*\[|Q\s*\(|V\s*\(|Σ|sum\s*\()",
                sentence,
                flags=re.IGNORECASE,
            )
        )
        mechanism_passages = tuple(
            sentence
            for sentence in sentences
            if re.search(
                r"\b(?:method|mechanism|algorithm|policy|model|approach|"
                r"objective|score|value|decision|intervention|reservation|"
                r"optimi[sz]|learn(?:s|ed|ing)?)\b",
                sentence,
                flags=re.IGNORECASE,
            )
        )
        limitations = tuple(
            sentence
            for sentence in sentences
            if re.search(
                r"\b(?:limit(?:ation|ed)?|however|but|assum(?:e|es|ed|ption)|"
                r"fail(?:s|ed|ure)?|challenge|future work|open question|only when)\b",
                sentence,
                flags=re.IGNORECASE,
            )
        )
        causal_mappings = tuple(
            component
            for component in work.matched_components
            if re.search(
                r"(?:source|target|caus|mediator|intervention|broken assumption|"
                r"distinguishing prediction|alternative action|unavailable information|"
                r"irreversible)",
                component,
                flags=re.IGNORECASE,
            )
        )
        source_packets.append(
            LiteratureSourcePacket(
                work_id=work.work_id,
                title=work.title,
                year=work.year,
                locator=work.locator,
                relation=work.relation,
                abstract=" ".join(work.abstract.split()),
                matched_components=work.matched_components,
                mechanism_passages=mechanism_passages,
                equations=equations,
                limitations=limitations,
                causal_mappings=causal_mappings,
                executable=work.executable,
            )
        )
        text = _normalized_text(
            (
                work.title,
                work.abstract,
                *work.matched_components,
            )
        )
        detected = _mechanisms(text, vocabulary)
        mechanisms_by_work[work.work_id] = detected
        for mechanism in detected:
            evidence.append(
                LiteratureMechanismEvidence(
                    mechanism=mechanism,
                    work_id=work.work_id,
                    title=work.title,
                    year=work.year,
                    locator=work.locator,
                    relation=work.relation,
                    evidence_excerpt=_evidence_excerpt(work),
                    is_executable_incumbent=(
                        work.work_id
                        == assessment.executable_incumbent_id
                    ),
                    is_latest_cohort=work.year >= latest_floor,
                )
            )

    causal_text = _normalized_text(causal_questions)
    causal_mechanisms = _mechanisms(causal_text, vocabulary)
    known = tuple(
        dict.fromkeys(
            item.mechanism
            for item in evidence
            if item.relation
            in (
                PriorArtRelation.DUPLICATES_CORE,
                PriorArtRelation.EXECUTABLE_BASELINE,
                PriorArtRelation.STRONG_OVERLAP,
            )
        )
    )
    contrastive = tuple(
        dict.fromkeys(
            mechanism
            for known_mechanism in known
            for mechanism in vocabulary.contrastive_frontier.get(
                known_mechanism,
                (),
            )
        )
    )
    adjacent = tuple(
        dict.fromkeys(
            item.mechanism
            for item in evidence
            if item.relation == PriorArtRelation.ADJACENT
        )
    )
    non_incumbent = tuple(
        dict.fromkeys(
            item.mechanism
            for item in evidence
            if not item.is_executable_incumbent
        )
    )
    if island_family == "ancestry":
        hypotheses = (
            *causal_mechanisms,
            *contrastive,
            *adjacent,
            *non_incumbent,
        )
    elif island_family == "de_novo":
        hypotheses = (
            *causal_mechanisms,
            *contrastive,
            *adjacent,
            *(
                mechanism
                for mechanism in non_incumbent
                if mechanism
                not in vocabulary.channel_exclusions.get(
                    island_family,
                    (),
                )
            ),
        )
    else:
        hypotheses = (
            *causal_mechanisms,
            *contrastive,
            *adjacent,
            *non_incumbent,
        )
    hypotheses = tuple(dict.fromkeys(hypotheses))
    if not hypotheses:
        hypotheses = tuple(vocabulary.mechanism_terms)[:2]
    if not hypotheses:
        raise ValueError("domain literature vocabulary produced no mechanisms")

    open_questions = tuple(
        dict.fromkeys(
            component
            for work in assessment.closest_works
            for component in work.matched_components
            if (
                "broken assumption" in component.casefold()
                or "distinguishing prediction" in component.casefold()
                or "limitation" in component.casefold()
            )
        )
    )
    novelty_exclusions = tuple(
        "%s:%s" % (mechanism, item.work_id)
        for mechanism in known
        for item in evidence
        if item.mechanism == mechanism
        and item.relation
        in (
            PriorArtRelation.DUPLICATES_CORE,
            PriorArtRelation.EXECUTABLE_BASELINE,
            PriorArtRelation.STRONG_OVERLAP,
        )
    )
    ordered_work_ids = tuple(
        work.work_id
        for work in sorted(
            assessment.closest_works,
            key=lambda work: (-work.year, work.work_id),
        )
    )
    return LiteratureHypothesisContext(
        island_family=island_family,
        assessment_id=assessment.assessment_id,
        searched_at=assessment.searched_at,
        source_work_ids=ordered_work_ids,
        evidence=tuple(
            sorted(
                evidence,
                key=lambda item: (
                    -item.year,
                    item.mechanism,
                    item.work_id,
                ),
            )
        ),
        known_mechanisms=known,
        hypothesis_mechanisms=hypotheses,
        novelty_exclusions=novelty_exclusions,
        open_questions=open_questions,
        causal_questions=tuple(causal_questions),
        source_packets=tuple(
            sorted(
                source_packets,
                key=lambda item: (-item.year, item.work_id),
            )
        ),
        grounding_mode="domain_vocabulary:%s" % vocabulary.vocabulary_ref,
    )


def build_source_preserving_literature_context(
    assessment: PriorArtAssessment,
    discovery_channel: str,
    *,
    causal_questions: Sequence[str] = (),
) -> LiteratureHypothesisContext:
    """Generic grounding that does not impose a domain mechanism vocabulary."""

    source_vocabulary = LiteratureMechanismVocabulary(
        mechanism_terms={
            "source_work:%s" % work.work_id: (work.title.casefold(),)
            for work in assessment.closest_works
        },
        contrastive_frontier={},
        vocabulary_ref="dynamic-source-work-identity-v1",
    )
    base = build_literature_hypothesis_context(
        assessment,
        "cross_domain",
        vocabulary=source_vocabulary,
        causal_questions=causal_questions,
    )
    latest_year = max(work.year for work in assessment.closest_works)
    latest_floor = latest_year - 2
    evidence = tuple(
        LiteratureMechanismEvidence(
            mechanism="source_work:%s" % work.work_id,
            work_id=work.work_id,
            title=work.title,
            year=work.year,
            locator=work.locator,
            relation=work.relation,
            evidence_excerpt=_evidence_excerpt(work),
            is_executable_incumbent=(
                work.work_id == assessment.executable_incumbent_id
            ),
            is_latest_cohort=work.year >= latest_floor,
        )
        for work in assessment.closest_works
    )
    known = tuple(
        item.mechanism
        for item in evidence
        if item.relation
        in {
            PriorArtRelation.DUPLICATES_CORE,
            PriorArtRelation.EXECUTABLE_BASELINE,
            PriorArtRelation.STRONG_OVERLAP,
        }
    )
    generative = tuple(
        item.mechanism
        for item in evidence
        if item.relation == PriorArtRelation.ADJACENT
    ) or tuple(item.mechanism for item in evidence)
    return LiteratureHypothesisContext(
        island_family=discovery_channel,
        assessment_id=base.assessment_id,
        searched_at=base.searched_at,
        source_work_ids=base.source_work_ids,
        evidence=evidence,
        known_mechanisms=tuple(dict.fromkeys(known)),
        hypothesis_mechanisms=tuple(dict.fromkeys(generative)),
        novelty_exclusions=tuple(
            "%s:%s" % (item.mechanism, item.work_id)
            for item in evidence
            if item.mechanism in known
        ),
        open_questions=base.open_questions,
        causal_questions=base.causal_questions,
        source_packets=base.source_packets,
        builder_ref="generic-source-preserving-literature-builder-v1",
        grounding_mode="source_preserving_no_domain_taxonomy",
    )
