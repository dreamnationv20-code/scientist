from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Protocol, Sequence, Tuple

from scientist.kernel.contracts import ProblemCharter
from scientist.program.contracts import HighLevelGoal, ResearchNode
from scientist.program.literature import (
    ClaimClassification,
    ClaimLevel,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorWork,
    SearchFacet,
)
from scientist.program.runtime import CampaignExecution


class LiteratureSearchProvider(Protocol):
    name: str
    provider_version: str

    def search(
        self,
        query: str,
        facet: SearchFacet,
    ) -> Sequence[PriorWork]:
        ...

    def citation_neighborhood(
        self,
        work: PriorWork,
    ) -> Sequence[PriorWork]:
        ...


@dataclass(frozen=True)
class NoveltyDecision:
    classification: ClaimClassification
    rationale: str
    novel_delta: Tuple[str, ...]
    executable_incumbent_id: Optional[str]


class NoveltyClassifier(Protocol):
    name: str
    classifier_version: str

    def classify(
        self,
        signature: ClaimSignature,
        works: Sequence[PriorWork],
    ) -> NoveltyDecision:
        ...


class ClaimSignatureBuilder(Protocol):
    name: str
    builder_version: str

    def build_scope(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
    ) -> ClaimSignature:
        ...

    def build(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        execution: CampaignExecution,
    ) -> ClaimSignature:
        ...


class EventDrivenPriorArtReviewer:
    """Runs a fresh multi-facet survey whenever a child claim emerges."""

    name = "event-driven-prior-art-reviewer"
    reviewer_version = "v1"

    def __init__(
        self,
        providers: Sequence[LiteratureSearchProvider],
        classifier: NoveltyClassifier,
        signature_builder: ClaimSignatureBuilder,
        searched_at: str,
    ) -> None:
        self.providers = tuple(providers)
        self.classifier = classifier
        self.signature_builder = signature_builder
        self.searched_at = searched_at
        if len({provider.name for provider in self.providers}) < 2:
            raise ValueError(
                "event-driven review requires two literature providers"
            )
        if not searched_at:
            raise ValueError("literature search date is required")

    @staticmethod
    def _facet_queries(
        signature: ClaimSignature,
    ) -> Tuple[Tuple[SearchFacet, str], ...]:
        return (
            (SearchFacet.PROBLEM, signature.problem),
            (SearchFacet.PHENOMENON, signature.phenomenon),
            (SearchFacet.INTERVENTION, signature.intervention),
            (SearchFacet.MECHANISM, signature.mechanism),
            (SearchFacet.EVALUATION, signature.evaluation),
        )

    def review(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        execution: CampaignExecution,
    ) -> PriorArtAssessment:
        signature = self.signature_builder.build(
            goal,
            node,
            execution,
        )
        trigger = (
            LiteratureTrigger.CLAIM_ESCALATION
            if execution.requested_claim_level
            > ClaimLevel.REPLICATED_EFFECT
            else LiteratureTrigger.REPLICATION_NOMINATION
        )
        return self._review_signature(signature, trigger)

    def review_scope(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
    ) -> PriorArtAssessment:
        signature = self.signature_builder.build_scope(
            goal,
            node,
            charter,
        )
        return self._review_signature(
            signature,
            LiteratureTrigger.NEW_PHENOMENON,
        )

    def _review_signature(
        self,
        signature: ClaimSignature,
        trigger: LiteratureTrigger,
    ) -> PriorArtAssessment:
        if not signature.subject_id:
            raise ValueError("signature builder returned an empty subject")

        query_records = []
        works = {}
        for facet, query in self._facet_queries(signature):
            for provider in self.providers:
                query_records.append(
                    LiteratureQuery(
                        query=query,
                        facet=facet,
                        provider=provider.name,
                    )
                )
                for work in provider.search(query, facet):
                    works[work.work_id] = work

        seeds = tuple(
            sorted(
                works.values(),
                key=lambda work: (
                    work.relation.value,
                    work.year,
                    work.work_id,
                ),
            )[:8]
        )
        for provider in self.providers:
            for work in seeds:
                query_records.append(
                    LiteratureQuery(
                        query="citation-neighborhood:%s" % work.work_id,
                        facet=SearchFacet.CITATION_NEIGHBORHOOD,
                        provider=provider.name,
                    )
                )
                for neighbor in provider.citation_neighborhood(work):
                    works[neighbor.work_id] = neighbor

        ordered_works = tuple(
            works[key] for key in sorted(works)
        )
        decision = self.classifier.classify(
            signature,
            ordered_works,
        )
        return PriorArtAssessment(
            signature=signature,
            trigger=trigger,
            queries=tuple(query_records),
            closest_works=ordered_works,
            classification=decision.classification,
            rationale=decision.rationale,
            novel_delta=decision.novel_delta,
            citation_snowball_complete=True,
            searched_at=self.searched_at,
            reviewer_ref=(
                "%s:%s/%s:%s"
                % (
                    self.name,
                    self.reviewer_version,
                    self.classifier.name,
                    self.classifier.classifier_version,
                )
            ),
            executable_incumbent_id=(
                decision.executable_incumbent_id
            ),
        )
