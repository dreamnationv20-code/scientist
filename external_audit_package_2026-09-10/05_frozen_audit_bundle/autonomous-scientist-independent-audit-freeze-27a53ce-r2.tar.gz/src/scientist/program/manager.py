from __future__ import annotations

from typing import Dict, Mapping, Optional, Sequence, Set, Tuple

from scientist.core.artifacts import ArtifactStore
from scientist.kernel.contracts import (
    GateContract,
    GateKind,
    ProblemCharter,
)
from scientist.kernel.gates import GateDecision
from scientist.program.contracts import (
    ChildCampaignOutcome,
    ChildCampaignProgress,
    ChildCampaignResult,
    Decomposition,
    DecompositionProposal,
    HighLevelGoal,
    NodeAssessment,
    NodeStatus,
    PortfolioDecision,
    PortfolioPolicy,
    ProgramResolution,
)
from scientist.program.graph import ResearchProgramGraph
from scientist.program.interfaces import GoalDecomposer, ProgramAssessor
from scientist.program.ledger import (
    ProgramEventKind,
    ResearchProgramLedger,
)
from scientist.program.literature import (
    ClaimAuthorization,
    ClaimLevel,
    PriorArtAssessment,
    evaluate_claim_authorization,
)
from scientist.program.strategic_governance import (
    PortfolioGovernanceAuthorization,
)


class ResearchProgramManager:
    """Coordinates high-level goals without becoming an evidence authority."""

    def __init__(
        self,
        goal: HighLevelGoal,
        artifact_store: Optional[ArtifactStore] = None,
        manager_ref: str = "research-program-manager-v1",
    ) -> None:
        if not manager_ref:
            raise ValueError("manager_ref must not be empty")
        self.goal = goal
        self.manager_ref = manager_ref
        self.graph = ResearchProgramGraph(goal)
        self.ledger = ResearchProgramLedger(
            goal.goal_id,
            artifact_store=artifact_store,
        )
        self._decompositions: Dict[str, Decomposition] = {}
        self._node_decompositions: Dict[str, Set[str]] = {}
        self._assessments: Dict[str, NodeAssessment] = {}
        self._portfolio_decisions: Dict[str, PortfolioDecision] = {}
        self._portfolio_authorizations: Dict[
            str, PortfolioGovernanceAuthorization
        ] = {}
        self._child_charters: Dict[str, ProblemCharter] = {}
        self._campaign_progress: Dict[
            str, Tuple[ChildCampaignProgress, ...]
        ] = {}
        self._child_results: Dict[str, ChildCampaignResult] = {}
        self._prior_art_assessments: Dict[str, PriorArtAssessment] = {}
        self._claim_authorizations: Dict[str, ClaimAuthorization] = {}
        self._compute_spent = 0.0
        self._resolution: Optional[ProgramResolution] = None
        self.ledger.append(
            ProgramEventKind.GOAL_REGISTERED,
            goal.as_dict(),
            actor_ref=self.manager_ref,
        )

    @property
    def decompositions(self) -> Mapping[str, Decomposition]:
        return dict(self._decompositions)

    @property
    def assessments(self) -> Mapping[str, NodeAssessment]:
        return dict(self._assessments)

    @property
    def child_results(self) -> Mapping[str, ChildCampaignResult]:
        return dict(self._child_results)

    @property
    def portfolio_decisions(self) -> Mapping[str, PortfolioDecision]:
        return dict(self._portfolio_decisions)

    @property
    def portfolio_authorizations(
        self,
    ) -> Mapping[str, PortfolioGovernanceAuthorization]:
        return dict(self._portfolio_authorizations)

    @property
    def campaign_progress(
        self,
    ) -> Mapping[str, Tuple[ChildCampaignProgress, ...]]:
        return dict(self._campaign_progress)

    @property
    def child_charters(self) -> Mapping[str, ProblemCharter]:
        return dict(self._child_charters)

    @property
    def prior_art_assessments(
        self,
    ) -> Mapping[str, PriorArtAssessment]:
        return dict(self._prior_art_assessments)

    @property
    def claim_authorizations(
        self,
    ) -> Mapping[str, ClaimAuthorization]:
        return dict(self._claim_authorizations)

    @property
    def compute_spent(self) -> float:
        return self._compute_spent

    @property
    def compute_remaining(self) -> float:
        return max(0.0, self.goal.total_compute_budget - self._compute_spent)

    @property
    def resolution(self) -> Optional[ProgramResolution]:
        return self._resolution

    def _ensure_open(self) -> None:
        if self._resolution is not None and self._resolution.resolved:
            raise ValueError("the research goal is already resolved")

    def register_decomposition(
        self,
        proposal: DecompositionProposal,
    ) -> str:
        self._ensure_open()
        decomposition = proposal.decomposition
        if decomposition.goal_id != self.goal.goal_id:
            raise ValueError("decomposition belongs to another goal")
        if decomposition.decomposition_id in self._decompositions:
            raise ValueError("decomposition is already registered")

        existing_ids = set(self.graph.nodes)
        new_nodes = tuple(
            node for node in proposal.nodes
            if node.node_id not in existing_ids
        )
        conflicting = tuple(
            node for node in proposal.nodes
            if node.node_id in existing_ids
            and self.graph.nodes[node.node_id] != node
        )
        if conflicting:
            raise ValueError("node identity conflicts with existing graph")
        if new_nodes:
            self.graph.add_nodes(new_nodes)
        missing = set(decomposition.node_ids).difference(self.graph.nodes)
        if missing:
            raise ValueError(
                "decomposition references missing nodes: %s"
                % ", ".join(sorted(missing))
            )

        self._decompositions[
            decomposition.decomposition_id
        ] = decomposition
        for node_id in decomposition.node_ids:
            self._node_decompositions.setdefault(node_id, set()).add(
                decomposition.decomposition_id
            )
        self.ledger.append(
            ProgramEventKind.DECOMPOSITION_REGISTERED,
            {
                "decomposition": decomposition.as_dict(),
                "new_node_ids": [node.node_id for node in new_nodes],
            },
            actor_ref=decomposition.decomposer_ref,
        )
        self.assess_nodes(proposal.initial_assessments)
        return decomposition.decomposition_id

    def solicit_decompositions(
        self,
        decomposer: GoalDecomposer,
    ) -> Tuple[str, ...]:
        """Ask a replaceable planner for proposals, then validate each one."""
        self._ensure_open()
        proposals = tuple(
            decomposer.propose(self.goal, self.graph.nodes)
        )
        if not proposals:
            raise ValueError("goal decomposer returned no proposals")
        return tuple(
            self.register_decomposition(proposal)
            for proposal in proposals
        )

    def assess_nodes(
        self,
        assessments: Sequence[NodeAssessment],
    ) -> None:
        self._ensure_open()
        for assessment in assessments:
            if assessment.node_id not in self.graph.nodes:
                raise ValueError(
                    "assessment references an unknown research node"
                )
            self._assessments[assessment.node_id] = assessment
            self.ledger.append(
                ProgramEventKind.NODE_ASSESSED,
                assessment.as_dict(),
                actor_ref=assessment.assessor_ref,
            )

    def refresh_frontier_assessments(
        self,
        assessor: ProgramAssessor,
    ) -> Tuple[NodeAssessment, ...]:
        """Obtain planning judgments for every currently ready node."""
        self._ensure_open()
        frontier = self.graph.frontier()
        if not frontier:
            raise ValueError("the research graph has no ready frontier")
        assessments = tuple(assessor.assess(self.goal, frontier))
        expected_ids = {node.node_id for node in frontier}
        actual_ids = {
            assessment.node_id for assessment in assessments
        }
        if actual_ids != expected_ids:
            raise ValueError(
                "program assessor must assess the complete ready frontier"
            )
        self.assess_nodes(assessments)
        return assessments

    def _eligible_ranked_nodes(self) -> Tuple[str, ...]:
        frontier_ids = {
            node.node_id for node in self.graph.frontier()
        }
        return tuple(
            sorted(
                (
                    node_id
                    for node_id in frontier_ids
                    if node_id in self._assessments
                ),
                key=lambda node_id: (
                    -self._assessments[node_id].priority_score,
                    node_id,
                ),
            )
        )

    def select_portfolio(
        self,
        policy: PortfolioPolicy,
    ) -> PortfolioDecision:
        self._ensure_open()
        active_count = len(self.graph.active())
        available_slots = min(
            policy.max_nodes,
            self.goal.max_parallel_campaigns - active_count,
        )
        if available_slots <= 0:
            raise ValueError("no parallel campaign slots are available")
        budget_limit = min(policy.compute_budget, self.compute_remaining)
        if budget_limit <= 0:
            raise ValueError("the high-level goal budget is exhausted")

        ranked = self._eligible_ranked_nodes()
        if not ranked:
            raise ValueError(
                "no ready research nodes have current assessments"
            )
        available_decompositions = {
            decomposition_id
            for node_id in ranked
            for decomposition_id in self._node_decompositions.get(
                node_id,
                set(),
            )
        }
        required_diversity = policy.minimum_distinct_decompositions
        if required_diversity > len(available_decompositions):
            raise ValueError(
                "portfolio diversity exceeds ready decompositions"
            )

        selected = []
        selected_cost = 0.0
        covered_decompositions: Set[str] = set()

        while len(covered_decompositions) < required_diversity:
            candidates = []
            for node_id in ranked:
                if node_id in selected:
                    continue
                cost = self._assessments[node_id].estimated_cost
                if (
                    len(selected) >= available_slots
                    or selected_cost + cost > budget_limit
                ):
                    continue
                new_coverage = self._node_decompositions.get(
                    node_id,
                    set(),
                ).difference(covered_decompositions)
                if new_coverage:
                    candidates.append(
                        (
                            len(new_coverage),
                            self._assessments[node_id].priority_score,
                            node_id,
                        )
                    )
            if not candidates:
                raise ValueError(
                    "budget cannot satisfy portfolio diversity"
                )
            _, _, chosen = max(
                candidates,
                key=lambda value: (value[0], value[1], value[2]),
            )
            selected.append(chosen)
            selected_cost += self._assessments[chosen].estimated_cost
            covered_decompositions.update(
                self._node_decompositions.get(chosen, set())
            )

        for node_id in ranked:
            if node_id in selected or len(selected) >= available_slots:
                continue
            cost = self._assessments[node_id].estimated_cost
            if selected_cost + cost <= budget_limit:
                selected.append(node_id)
                selected_cost += cost

        decision = PortfolioDecision(
            selected_node_ids=tuple(selected),
            deferred_node_ids=tuple(
                node_id for node_id in ranked if node_id not in selected
            ),
            total_estimated_cost=selected_cost,
            policy=policy,
            scores={
                node_id: self._assessments[node_id].priority_score
                for node_id in ranked
            },
            rationale=(
                "maximize declared expected goal progress per unit cost "
                "while preserving competing-decomposition coverage"
            ),
        )
        self.ledger.append(
            ProgramEventKind.PORTFOLIO_SELECTED,
            decision.as_dict(),
            actor_ref=self.manager_ref,
        )
        self._portfolio_decisions[decision.decision_id] = decision
        return decision

    def register_portfolio_authorization(
        self,
        authorization: PortfolioGovernanceAuthorization,
    ) -> str:
        """Persist the independent pre-experiment governance decision."""

        self._ensure_open()
        if authorization.goal_id != self.goal.goal_id:
            raise ValueError("portfolio authorization belongs to another goal")
        decision = self._portfolio_decisions.get(
            authorization.portfolio_decision_id
        )
        if decision is None:
            raise ValueError("portfolio authorization references an unknown decision")
        if authorization.selected_node_ids != decision.selected_node_ids:
            raise ValueError("portfolio authorization selected-node mismatch")
        existing = self._portfolio_authorizations.get(
            authorization.authorization_id
        )
        if existing is not None:
            if existing != authorization:
                raise ValueError("portfolio authorization identity conflict")
            return existing.authorization_id
        self._portfolio_authorizations[
            authorization.authorization_id
        ] = authorization
        self.ledger.append(
            ProgramEventKind.PORTFOLIO_GOVERNANCE_EVALUATED,
            authorization.as_dict(),
            actor_ref=authorization.authority_ref,
        )
        return authorization.authorization_id

    def activate_portfolio(
        self,
        decision: PortfolioDecision,
        authorization_id: Optional[str] = None,
    ) -> None:
        self._ensure_open()
        registered = self._portfolio_decisions.get(decision.decision_id)
        if registered is None or registered != decision:
            raise ValueError("portfolio must be selected by this manager")
        if self.goal.risk_tier == "autonomous_discovery":
            authorization = self._portfolio_authorizations.get(
                str(authorization_id)
            )
            if authorization is None:
                raise ValueError(
                    "autonomous-discovery portfolio requires governance authorization"
                )
            if not authorization.authorized:
                raise ValueError("portfolio governance authorization was denied")
            if authorization.portfolio_decision_id != decision.decision_id:
                raise ValueError("portfolio governance authorization is stale")
        if (
            len(self.graph.active()) + len(decision.selected_node_ids)
            > self.goal.max_parallel_campaigns
        ):
            raise ValueError("portfolio exceeds parallel campaign limit")
        for node_id in decision.selected_node_ids:
            if self.graph.status(node_id) != NodeStatus.READY:
                raise ValueError(
                    "portfolio decision is stale for node %s" % node_id
                )
        for node_id in decision.selected_node_ids:
            self.graph.transition(node_id, NodeStatus.ACTIVE)
            self.ledger.append(
                ProgramEventKind.NODE_ACTIVATED,
                {
                    "node_id": node_id,
                    "portfolio_decision_id": decision.decision_id,
                },
                actor_ref=self.manager_ref,
            )

    def suspend_active_portfolio(
        self,
        decision: PortfolioDecision,
        reasons: Sequence[str],
        *,
        authority_ref: str,
    ) -> None:
        """Fail closed when new governance evidence invalidates an assay."""

        self._ensure_open()
        registered = self._portfolio_decisions.get(decision.decision_id)
        if registered is None or registered != decision:
            raise ValueError("portfolio must be selected by this manager")
        if not authority_ref:
            raise ValueError("portfolio suspension requires an authority")
        suspension_reasons = tuple(dict.fromkeys(str(item) for item in reasons))
        if not suspension_reasons or not all(suspension_reasons):
            raise ValueError("portfolio suspension requires non-empty reasons")
        for node_id in decision.selected_node_ids:
            if self.graph.status(node_id) != NodeStatus.ACTIVE:
                raise ValueError(
                    "portfolio suspension requires active node %s" % node_id
                )
        for node_id in decision.selected_node_ids:
            self.graph.transition(node_id, NodeStatus.BLOCKED)
        self.ledger.append(
            ProgramEventKind.PORTFOLIO_SUSPENDED,
            {
                "portfolio_decision_id": decision.decision_id,
                "node_ids": list(decision.selected_node_ids),
                "reasons": list(suspension_reasons),
            },
            actor_ref=authority_ref,
        )

    def register_child_charter(
        self,
        node_id: str,
        charter: ProblemCharter,
    ) -> None:
        self._ensure_open()
        if self.graph.status(node_id) != NodeStatus.ACTIVE:
            raise ValueError(
                "a child charter requires an active research node"
            )
        if node_id in self._child_charters:
            raise ValueError("child charter already registered")
        self._child_charters[node_id] = charter
        self.ledger.append(
            ProgramEventKind.CHILD_CHARTER_REGISTERED,
            {
                "node_id": node_id,
                "charter": charter.as_dict(),
            },
            actor_ref=self.manager_ref,
        )

    def register_prior_art_assessment(
        self,
        assessment: PriorArtAssessment,
    ) -> str:
        self._ensure_open()
        subject_id = assessment.signature.subject_id
        if (
            subject_id != self.goal.goal_id
            and subject_id not in self.graph.nodes
        ):
            raise ValueError(
                "prior-art assessment references an unknown subject"
            )
        existing = self._prior_art_assessments.get(
            assessment.assessment_id
        )
        if existing is not None:
            if existing != assessment:
                raise ValueError("prior-art assessment identity conflict")
            return assessment.assessment_id
        self._prior_art_assessments[
            assessment.assessment_id
        ] = assessment
        self.ledger.append(
            ProgramEventKind.PRIOR_ART_ASSESSMENT_REGISTERED,
            assessment.as_dict(),
            actor_ref=assessment.reviewer_ref,
        )
        return assessment.assessment_id

    def authorize_claim(
        self,
        assessment_id: str,
        claim_id: str,
        requested_level: ClaimLevel,
        frontier_comparison_evidence_ids: Sequence[str] = (),
        external_confirmation_evidence_ids: Sequence[str] = (),
        broad_impact_evidence_ids: Sequence[str] = (),
    ) -> ClaimAuthorization:
        self._ensure_open()
        try:
            assessment = self._prior_art_assessments[assessment_id]
        except KeyError:
            raise ValueError("claim authorization requires prior-art review")
        authorization = evaluate_claim_authorization(
            assessment,
            claim_id,
            requested_level,
            tuple(frontier_comparison_evidence_ids),
            tuple(external_confirmation_evidence_ids),
            tuple(broad_impact_evidence_ids),
        )
        existing = self._claim_authorizations.get(
            authorization.authorization_id
        )
        if existing is not None:
            if existing != authorization:
                raise ValueError("claim authorization identity conflict")
            return existing
        self._claim_authorizations[
            authorization.authorization_id
        ] = authorization
        self.ledger.append(
            ProgramEventKind.CLAIM_AUTHORIZATION_EVALUATED,
            authorization.as_dict(),
            actor_ref=self.manager_ref,
        )
        return authorization

    def ingest_child_result(
        self,
        result: ChildCampaignResult,
    ) -> None:
        self._ensure_open()
        if self.graph.status(result.node_id) != NodeStatus.ACTIVE:
            raise ValueError(
                "child result requires an active research node"
            )
        charter = self._child_charters.get(result.node_id)
        if charter is None:
            raise ValueError("child result has no registered charter")
        if charter.charter_id != result.child_charter_id:
            raise ValueError("child result charter identity mismatch")
        if result.node_id in self._child_results:
            raise ValueError("child result already ingested")
        if result.outcome == ChildCampaignOutcome.CONFIRMED:
            if result.claim_authorization_id is None:
                raise ValueError(
                    "confirmed child result requires claim authorization"
                )
            authorization = self._claim_authorizations.get(
                result.claim_authorization_id
            )
            if authorization is None:
                raise ValueError("unknown child-claim authorization")
            if not authorization.authorized:
                raise ValueError("child claim authorization was denied")
            if (
                authorization.requested_level
                < ClaimLevel.REPLICATED_EFFECT
            ):
                raise ValueError(
                    "confirmed child claim requires replicated-effect level"
                )
            if authorization.subject_id != result.node_id:
                raise ValueError(
                    "child claim authorization belongs to another node"
                )
            if authorization.claim_id != result.claim_id:
                raise ValueError("child claim identity mismatch")

        outcome_status = {
            ChildCampaignOutcome.CONFIRMED: NodeStatus.CONFIRMED,
            ChildCampaignOutcome.REFUTED: NodeStatus.REFUTED,
            ChildCampaignOutcome.INCONCLUSIVE: NodeStatus.BLOCKED,
        }[result.outcome]
        self.graph.transition(result.node_id, outcome_status)
        self._child_results[result.node_id] = result
        self._compute_spent += result.compute_spent
        self.ledger.append(
            ProgramEventKind.CHILD_RESULT_INGESTED,
            {
                "result": result.as_dict(),
                "node_status": outcome_status.value,
                "goal_compute_spent": self._compute_spent,
                "goal_compute_budget_exceeded": (
                    self._compute_spent
                    > self.goal.total_compute_budget
                ),
            },
            actor_ref=self.manager_ref,
        )

    def record_campaign_progress(
        self,
        progress: ChildCampaignProgress,
    ) -> None:
        """Record one attempt while deliberately keeping the node active."""

        self._ensure_open()
        if self.graph.status(progress.node_id) != NodeStatus.ACTIVE:
            raise ValueError(
                "campaign progress requires an active research node"
            )
        charter = self._child_charters.get(progress.node_id)
        if charter is None:
            raise ValueError("campaign progress has no registered charter")
        if charter.charter_id != progress.child_charter_id:
            raise ValueError("campaign progress charter identity mismatch")
        existing = self._campaign_progress.get(progress.node_id, ())
        if any(
            item.progress_id == progress.progress_id
            for item in existing
        ):
            raise ValueError("campaign progress already recorded")
        self._campaign_progress[progress.node_id] = (
            *existing,
            progress,
        )
        self._compute_spent += progress.compute_spent
        self.ledger.append(
            ProgramEventKind.CHILD_CAMPAIGN_PROGRESS_RECORDED,
            {
                "progress": progress.as_dict(),
                "node_status": NodeStatus.ACTIVE.value,
                "goal_compute_spent": self._compute_spent,
                "goal_compute_budget_exceeded": (
                    self._compute_spent
                    > self.goal.total_compute_budget
                ),
            },
            actor_ref=self.manager_ref,
        )

    def reopen_blocked_node(
        self,
        node_id: str,
        reason: str,
    ) -> None:
        self._ensure_open()
        if not reason:
            raise ValueError("reopen reason must not be empty")
        if self.graph.status(node_id) != NodeStatus.BLOCKED:
            raise ValueError("only blocked nodes may be reopened")
        self.graph.transition(node_id, NodeStatus.READY)
        self._child_charters.pop(node_id, None)
        self._child_results.pop(node_id, None)
        self.ledger.append(
            ProgramEventKind.DECOMPOSITION_REVISED,
            {"node_id": node_id, "reason": reason},
            actor_ref=self.manager_ref,
        )

    def evaluate_integration(
        self,
        gate_contract: GateContract,
        gate_decision: GateDecision,
        evidence_ids: Sequence[str],
        satisfied_requirements: Sequence[str],
        waived_critical_nodes: Mapping[str, str],
        limitations: Sequence[str],
        claim_authorization_id: str,
    ) -> ProgramResolution:
        self._ensure_open()
        if gate_contract.kind != GateKind.PUBLIC_CLAIM:
            raise ValueError(
                "high-level resolution requires a public-claim gate"
            )
        if gate_decision.contract_id != gate_contract.contract_id:
            raise ValueError("integration gate decision mismatch")
        if not evidence_ids:
            raise ValueError("integration requires independent evidence")
        if not limitations:
            raise ValueError("integration limitations must be explicit")
        authorization = self._claim_authorizations.get(
            claim_authorization_id
        )
        if authorization is None or not authorization.authorized:
            raise ValueError(
                "integration requires an authorized literature-checked claim"
            )
        if authorization.requested_level < ClaimLevel.REPLICATED_EFFECT:
            raise ValueError(
                "integration claim requires replicated-effect level"
            )
        if authorization.subject_id != self.goal.goal_id:
            raise ValueError(
                "integration claim authorization belongs to another subject"
            )
        satisfied = set(satisfied_requirements)
        required = set(self.goal.integration_requirements)
        missing_requirements = required.difference(satisfied)
        unresolved = set(
            self.graph.unresolved_critical_node_ids()
        )
        invalid_waivers = set(waived_critical_nodes).difference(unresolved)
        if invalid_waivers:
            raise ValueError(
                "waivers reference resolved or unknown critical nodes"
            )
        if any(not reason for reason in waived_critical_nodes.values()):
            raise ValueError("critical-node waivers require reasons")
        unwaived = unresolved.difference(waived_critical_nodes)
        reasons = []
        if not gate_decision.passed:
            reasons.append("terminal integration gate did not pass")
        if missing_requirements:
            reasons.append(
                "missing integration requirements: %s"
                % ", ".join(sorted(missing_requirements))
            )
        if unwaived:
            reasons.append(
                "unresolved critical nodes: %s"
                % ", ".join(sorted(unwaived))
            )
        resolved = not reasons
        resolution = ProgramResolution(
            goal_id=self.goal.goal_id,
            resolved=resolved,
            integration_gate_contract_id=gate_contract.contract_id,
            integration_gate_decision_id=gate_decision.decision_id,
            evidence_ids=tuple(evidence_ids),
            satisfied_requirements=tuple(satisfied_requirements),
            unresolved_critical_node_ids=tuple(sorted(unresolved)),
            waived_critical_nodes=dict(waived_critical_nodes),
            limitations=tuple(limitations),
            reasons=tuple(reasons),
        )
        self.ledger.append(
            ProgramEventKind.INTEGRATION_EVALUATED,
            resolution.as_dict(),
            actor_ref=self.manager_ref,
        )
        if resolved:
            for node_id, status in tuple(self.graph.statuses.items()):
                if status == NodeStatus.CONFIRMED:
                    self.graph.transition(node_id, NodeStatus.INTEGRATED)
            self._resolution = resolution
            self.ledger.append(
                ProgramEventKind.GOAL_RESOLVED,
                resolution.as_dict(),
                actor_ref=self.manager_ref,
            )
        return resolution

    def as_dict(self) -> Dict[str, object]:
        return {
            "manager_ref": self.manager_ref,
            "goal": self.goal.as_dict(),
            "graph": self.graph.as_dict(),
            "decompositions": [
                decomposition.as_dict()
                for _, decomposition in sorted(
                    self._decompositions.items()
                )
            ],
            "assessments": [
                assessment.as_dict()
                for _, assessment in sorted(
                    self._assessments.items()
                )
            ],
            "portfolio_decisions": [
                decision.as_dict()
                for _, decision in sorted(
                    self._portfolio_decisions.items()
                )
            ],
            "portfolio_authorizations": [
                authorization.as_dict()
                for _, authorization in sorted(
                    self._portfolio_authorizations.items()
                )
            ],
            "child_charters": {
                node_id: charter.as_dict()
                for node_id, charter in sorted(
                    self._child_charters.items()
                )
            },
            "child_results": {
                node_id: result.as_dict()
                for node_id, result in sorted(
                    self._child_results.items()
                )
            },
            "campaign_progress": {
                node_id: [
                    progress.as_dict()
                    for progress in progress_items
                ]
                for node_id, progress_items in sorted(
                    self._campaign_progress.items()
                )
            },
            "prior_art_assessments": [
                assessment.as_dict()
                for _, assessment in sorted(
                    self._prior_art_assessments.items()
                )
            ],
            "claim_authorizations": [
                authorization.as_dict()
                for _, authorization in sorted(
                    self._claim_authorizations.items()
                )
            ],
            "compute_spent": self.compute_spent,
            "compute_remaining": self.compute_remaining,
            "resolution": (
                None
                if self._resolution is None
                else self._resolution.as_dict()
            ),
            "ledger": self.ledger.as_dict(),
        }

    @classmethod
    def from_dict(
        cls,
        value: Mapping[str, object],
        artifact_store: Optional[ArtifactStore] = None,
    ) -> "ResearchProgramManager":
        from scientist.program.serialization import manager_from_dict

        return manager_from_dict(
            value,
            artifact_store=artifact_store,
        )
