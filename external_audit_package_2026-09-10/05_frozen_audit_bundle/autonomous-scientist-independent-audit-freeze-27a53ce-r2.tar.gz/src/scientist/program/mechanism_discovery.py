from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.program.causal_failure import (
    CausalDiscriminationAssessment,
    CausalFailureModelSet,
    CausalRelationKind,
    CausalRole,
    REQUIRED_CAUSAL_ROLES,
    RelationalAnalogyMapping,
)


MECHANISM_DISCOVERY_VERSION = "cross-domain-mechanism-discovery-v3"


@dataclass(frozen=True)
class MechanismDiscoveryQuery:
    target_node_id: str
    target_domain: str
    causal_failure_models: CausalFailureModelSet
    causal_discrimination: CausalDiscriminationAssessment
    failure_signatures: Tuple[str, ...]
    desired_capabilities: Tuple[str, ...]
    query_terms: Tuple[str, ...]
    excluded_source_domains: Tuple[str, ...] = ()
    excluded_generator_refs: Tuple[str, ...] = ()
    literature_context_id: str | None = None
    literature_evidence_ids: Tuple[str, ...] = ()
    query_generator_ref: str = "relational-mechanism-query-generator-v2"

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_node_id,
                self.target_domain,
                self.failure_signatures,
                self.desired_capabilities,
                self.query_terms,
                self.query_generator_ref,
            )
        ):
            raise ValueError("mechanism discovery query is incomplete")
        if (
            self.causal_failure_models.target_node_id
            != self.target_node_id
        ):
            raise ValueError(
                "mechanism query and causal models target different nodes"
            )
        if not self.causal_failure_models.coverage_complete:
            raise ValueError(
                "mechanism query requires complete failure-cluster coverage"
            )
        if (
            self.causal_discrimination.target_node_id
            != self.target_node_id
            or self.causal_discrimination.model_set_id
            != self.causal_failure_models.model_set_id
        ):
            raise ValueError(
                "causal discrimination assesses another failure model set"
            )
        if not self.causal_discrimination.passed:
            raise ValueError(
                "causal discrimination failed; stop before broad "
                "mechanism retrieval: %s"
                % ", ".join(
                    self.causal_discrimination.failure_reasons
                )
            )
        if len(set(self.query_terms)) != len(self.query_terms):
            raise ValueError("mechanism discovery query terms must be unique")
        if len(set(self.excluded_source_domains)) != len(
            self.excluded_source_domains
        ):
            raise ValueError("excluded source domains must be unique")
        if len(set(self.excluded_generator_refs)) != len(
            self.excluded_generator_refs
        ):
            raise ValueError("excluded generator references must be unique")
        if len(set(self.literature_evidence_ids)) != len(
            self.literature_evidence_ids
        ):
            raise ValueError("literature evidence references must be unique")
        if (
            self.literature_evidence_ids
            and self.literature_context_id is None
        ):
            raise ValueError(
                "mechanism literature evidence requires a context"
            )

    @property
    def query_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": MECHANISM_DISCOVERY_VERSION,
            "target_node_id": self.target_node_id,
            "target_domain": self.target_domain,
            "causal_failure_models": (
                self.causal_failure_models.as_dict()
            ),
            "causal_discrimination": self.causal_discrimination.as_dict(),
            # These fields are auditable retrieval hints. They never enter
            # the ranking score; causal-role and relation matches do.
            "failure_signatures": list(self.failure_signatures),
            "desired_capabilities": list(self.desired_capabilities),
            "query_terms": list(self.query_terms),
            "excluded_source_domains": list(
                self.excluded_source_domains
            ),
            "excluded_generator_refs": list(
                self.excluded_generator_refs
            ),
            "literature_context_id": self.literature_context_id,
            "literature_evidence_ids": list(
                self.literature_evidence_ids
            ),
            "query_generator_ref": self.query_generator_ref,
        }
        if include_id:
            value["query_id"] = self.query_id
        return value


@dataclass(frozen=True)
class SourceCausalMechanism:
    """Domain-neutral causal schema attached to a source mechanism."""

    unavailable_information: str
    irreversible_decision: str
    alternative_action: str
    changed_result: str
    causal_chain: str
    causal_relations: Tuple[CausalRelationKind, ...]
    broken_assumptions: Tuple[str, ...]
    distinguishing_predictions: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not all(
            (
                self.unavailable_information,
                self.irreversible_decision,
                self.alternative_action,
                self.changed_result,
                self.causal_chain,
                self.causal_relations,
                self.broken_assumptions,
                self.distinguishing_predictions,
            )
        ):
            raise ValueError("source causal mechanism is incomplete")
        if len(set(self.causal_relations)) != len(
            self.causal_relations
        ):
            raise ValueError("source causal relations must be unique")
        if len(self.distinguishing_predictions) < 2:
            raise ValueError(
                "source mechanism requires distinguishing predictions"
            )

    def source_element(self, role: CausalRole) -> str:
        return {
            CausalRole.UNAVAILABLE_INFORMATION: (
                self.unavailable_information
            ),
            CausalRole.IRREVERSIBLE_DECISION: (
                self.irreversible_decision
            ),
            CausalRole.ALTERNATIVE_ACTION: self.alternative_action,
            CausalRole.CHANGED_RESULT: self.changed_result,
        }[role]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "unavailable_information": self.unavailable_information,
            "irreversible_decision": self.irreversible_decision,
            "alternative_action": self.alternative_action,
            "changed_result": self.changed_result,
            "causal_chain": self.causal_chain,
            "causal_relations": [
                relation.value for relation in self.causal_relations
            ],
            "broken_assumptions": list(self.broken_assumptions),
            "distinguishing_predictions": list(
                self.distinguishing_predictions
            ),
        }


@dataclass(frozen=True)
class MechanismCatalogEntry:
    catalog_key: str
    source_domain: str
    source_problem: str
    source_mechanism: str
    source_reference: str
    invariant: str
    capability_tags: Tuple[str, ...]
    generator_ref: str
    surprise_prior: int
    grounding_prior: int
    causal_model: SourceCausalMechanism

    def __post_init__(self) -> None:
        required = (
            self.catalog_key,
            self.source_domain,
            self.source_problem,
            self.source_mechanism,
            self.source_reference,
            self.invariant,
            self.capability_tags,
            self.generator_ref,
            self.causal_model,
        )
        if not all(required):
            raise ValueError("mechanism catalog entry is incomplete")
        if len(set(self.capability_tags)) != len(self.capability_tags):
            raise ValueError("mechanism capability tags must be unique")
        for score in (self.surprise_prior, self.grounding_prior):
            if not isinstance(score, int) or not 0 <= score <= 4:
                raise ValueError(
                    "mechanism priors must be integers from zero to four"
                )


@dataclass(frozen=True)
class DiscoveredMechanism:
    query_id: str
    catalog_key: str
    source_domain: str
    source_problem: str
    source_mechanism: str
    source_reference: str
    invariant: str
    capability_tags: Tuple[str, ...]
    generator_ref: str
    relational_mappings: Tuple[RelationalAnalogyMapping, ...]
    matched_causal_relations: Tuple[CausalRelationKind, ...]
    broken_assumptions: Tuple[str, ...]
    distinguishing_predictions: Tuple[str, ...]
    structural_fit: int
    surprise: int
    evidence_grounding: int
    retrieval_score: int

    def __post_init__(self) -> None:
        required = (
            self.query_id,
            self.catalog_key,
            self.source_domain,
            self.source_problem,
            self.source_mechanism,
            self.source_reference,
            self.invariant,
            self.capability_tags,
            self.generator_ref,
            self.relational_mappings,
            self.matched_causal_relations,
            self.broken_assumptions,
            self.distinguishing_predictions,
        )
        if not all(required):
            raise ValueError("discovered mechanism is incomplete")
        for score in (
            self.structural_fit,
            self.surprise,
            self.evidence_grounding,
        ):
            if not isinstance(score, int) or not 0 <= score <= 4:
                raise ValueError(
                    "mechanism discovery grades must be zero to four"
                )
        if len(self.distinguishing_predictions) < 2:
            raise ValueError(
                "retrieved analogy requires distinguishing predictions"
            )
        if self.retrieval_score < 0:
            raise ValueError("mechanism retrieval score must be non-negative")

    @property
    def discovery_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": MECHANISM_DISCOVERY_VERSION,
            "query_id": self.query_id,
            "catalog_key": self.catalog_key,
            "source_domain": self.source_domain,
            "source_problem": self.source_problem,
            "source_mechanism": self.source_mechanism,
            "source_reference": self.source_reference,
            "invariant": self.invariant,
            "capability_tags": list(self.capability_tags),
            "generator_ref": self.generator_ref,
            "relational_mappings": [
                mapping.as_dict() for mapping in self.relational_mappings
            ],
            "matched_causal_relations": [
                relation.value
                for relation in self.matched_causal_relations
            ],
            "broken_assumptions": list(self.broken_assumptions),
            "distinguishing_predictions": list(
                self.distinguishing_predictions
            ),
            "structural_fit": self.structural_fit,
            "surprise": self.surprise,
            "evidence_grounding": self.evidence_grounding,
            "retrieval_score": self.retrieval_score,
        }
        if include_id:
            value["discovery_id"] = self.discovery_id
        return value


@dataclass(frozen=True)
class MechanismDiscoveryTrace:
    query: MechanismDiscoveryQuery
    candidates: Tuple[DiscoveredMechanism, ...]
    selected_discovery_ids: Tuple[str, ...]
    selection_rationale: str
    scout_ref: str

    def __post_init__(self) -> None:
        if not self.selection_rationale or not self.scout_ref:
            raise ValueError("mechanism discovery provenance is required")
        if len(self.candidates) < 3:
            raise ValueError(
                "mechanism discovery requires at least three candidates"
            )
        if any(
            candidate.query_id != self.query.query_id
            for candidate in self.candidates
        ):
            raise ValueError("mechanism candidate belongs to another query")
        candidate_ids = {
            candidate.discovery_id for candidate in self.candidates
        }
        if len(candidate_ids) != len(self.candidates):
            raise ValueError("mechanism discovery candidates must be unique")
        selected = set(self.selected_discovery_ids)
        if (
            len(selected) < 3
            or len(selected) != len(self.selected_discovery_ids)
            or not selected.issubset(candidate_ids)
        ):
            raise ValueError(
                "mechanism discovery must select three unique candidates"
            )
        selected_candidates = tuple(
            candidate
            for candidate in self.candidates
            if candidate.discovery_id in selected
        )
        selected_domains = {
            candidate.source_domain.casefold()
            for candidate in selected_candidates
        }
        if len(selected_domains) < 3:
            raise ValueError(
                "mechanism discovery must preserve source-domain diversity"
            )
        required_mapping_keys = {
            (model.model_id, role)
            for model in self.query.causal_failure_models.models
            for role in REQUIRED_CAUSAL_ROLES
        }
        for candidate in selected_candidates:
            observed = {
                (mapping.target_model_id, mapping.causal_role)
                for mapping in candidate.relational_mappings
            }
            if observed != required_mapping_keys:
                raise ValueError(
                    "selected analogy lacks complete causal-role mappings"
                )

    @property
    def trace_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "contract_version": MECHANISM_DISCOVERY_VERSION,
            "query": self.query.as_dict(),
            "candidates": [
                candidate.as_dict() for candidate in self.candidates
            ],
            "selected_discovery_ids": list(
                self.selected_discovery_ids
            ),
            "selection_rationale": self.selection_rationale,
            "scout_ref": self.scout_ref,
        }
        if include_id:
            value["trace_id"] = self.trace_id
        return value


class CatalogMechanismScout:
    """Retrieve by causal-role and relation alignment, not token overlap."""

    def __init__(
        self,
        entries: Sequence[MechanismCatalogEntry],
        *,
        scout_ref: str = "relational-catalog-mechanism-scout-v2",
    ) -> None:
        if not scout_ref or len(entries) < 3:
            raise ValueError("mechanism scout requires a corpus and identity")
        keys = {entry.catalog_key for entry in entries}
        if len(keys) != len(entries):
            raise ValueError("mechanism catalog keys must be unique")
        self.entries = tuple(entries)
        self.scout_ref = scout_ref

    def discover(
        self,
        query: MechanismDiscoveryQuery,
        *,
        limit: int = 6,
    ) -> MechanismDiscoveryTrace:
        if limit < 3:
            raise ValueError("mechanism discovery limit must be at least three")
        excluded_domains = {
            value.casefold() for value in query.excluded_source_domains
        }
        excluded_generators = set(query.excluded_generator_refs)
        candidates = []
        empirically_supported_models = tuple(
            model
            for model in query.causal_failure_models.models
            if model.empirically_supported
        )
        fit_models = (
            empirically_supported_models
            or query.causal_failure_models.models
        )
        for entry in self.entries:
            if entry.source_domain.casefold() in excluded_domains:
                continue
            if entry.generator_ref in excluded_generators:
                continue
            source_relations = set(entry.causal_model.causal_relations)
            per_schema_fit = tuple(
                len(source_relations.intersection(model.causal_relations))
                / float(
                    len(source_relations.union(model.causal_relations))
                )
                for model in fit_models
            )
            structural_fit = (
                0
                if not per_schema_fit
                else min(
                    4,
                    int(round(4.0 * sum(per_schema_fit) / len(per_schema_fit))),
                )
            )
            if structural_fit == 0:
                continue
            target_relations = {
                relation
                for model in query.causal_failure_models.models
                for relation in model.causal_relations
            }
            matched_relations = tuple(
                relation
                for relation in CausalRelationKind
                if relation in target_relations
                and relation in source_relations
            )
            mappings = tuple(
                RelationalAnalogyMapping(
                    causal_role=role,
                    target_model_id=model.model_id,
                    source_element=entry.causal_model.source_element(role),
                    target_element=model.target_element(role),
                    correspondence=(
                        "same causal role in the source and target chains; "
                        "the claim is structural, not terminological"
                    ),
                )
                for model in query.causal_failure_models.models
                for role in REQUIRED_CAUSAL_ROLES
            )
            predictions = tuple(
                dict.fromkeys(
                    (
                        *entry.causal_model.distinguishing_predictions,
                        *(
                            "For target cluster %s, the mapped alternative "
                            "should change the result only when the observable "
                            "proxy indicates the unavailable information."
                            % model.cluster_id
                            for model in query.causal_failure_models.models
                        ),
                    )
                )
            )
            retrieval_score = (
                4 * structural_fit
                + 2 * entry.surprise_prior
                + entry.grounding_prior
            )
            candidates.append(
                DiscoveredMechanism(
                    query_id=query.query_id,
                    catalog_key=entry.catalog_key,
                    source_domain=entry.source_domain,
                    source_problem=entry.source_problem,
                    source_mechanism=entry.source_mechanism,
                    source_reference=entry.source_reference,
                    invariant=entry.invariant,
                    capability_tags=entry.capability_tags,
                    generator_ref=entry.generator_ref,
                    relational_mappings=mappings,
                    matched_causal_relations=matched_relations,
                    broken_assumptions=(
                        entry.causal_model.broken_assumptions
                    ),
                    distinguishing_predictions=predictions,
                    structural_fit=structural_fit,
                    surprise=entry.surprise_prior,
                    evidence_grounding=entry.grounding_prior,
                    retrieval_score=retrieval_score,
                )
            )
        ranked = sorted(
            candidates,
            key=lambda candidate: (
                -candidate.retrieval_score,
                candidate.source_domain.casefold(),
                candidate.catalog_key,
            ),
        )
        selected = []
        selected_domains = set()
        for candidate in ranked:
            domain = candidate.source_domain.casefold()
            if domain in selected_domains:
                continue
            selected.append(candidate)
            selected_domains.add(domain)
            if len(selected) == limit:
                break
        if len(selected) < 3:
            raise ValueError(
                "mechanism corpus cannot satisfy relational diversity"
            )
        return MechanismDiscoveryTrace(
            query=query,
            candidates=tuple(ranked),
            selected_discovery_ids=tuple(
                candidate.discovery_id for candidate in selected
            ),
            selection_rationale=(
                "rank mechanisms by explicit causal-relation alignment, "
                "cross-domain surprise, and source grounding; require full "
                "source-to-target role mappings and preserve domain diversity"
            ),
            scout_ref=self.scout_ref,
        )
