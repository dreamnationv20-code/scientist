from __future__ import annotations

import os
import urllib.parse
from dataclasses import replace
from typing import Any, Mapping, Optional, Sequence

from scientist.core.artifacts import ArtifactStore
from scientist.program.literature import (
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)
from scientist.program.web_literature import (
    CrossrefWebProvider,
    JsonHttpTransport,
    LiveWebPriorArtReviewer,
    SemanticScholarWebProvider,
    _RecordedWebProvider,
    _relation_and_matches,
    _year,
)


OPENALEX_LITERATURE_PROVIDER_VERSION = "openalex-works-v1"
LIVE_WEB_REVIEWER_V4_VERSION = "live-web-prior-art-reviewer-v4"


def _abstract_from_inverted_index(value: Any) -> str:
    if not isinstance(value, dict):
        return ""
    positioned = []
    for token, positions in value.items():
        if not isinstance(positions, list):
            continue
        for position in positions:
            if isinstance(position, int) and position >= 0:
                positioned.append((position, str(token)))
    positioned.sort()
    return " ".join(token for _, token in positioned)


class OpenAlexWebProvider(_RecordedWebProvider):
    """OpenAlex search plus independent citation expansion for DOI seeds."""

    name = "OpenAlex API"
    provider_version = OPENALEX_LITERATURE_PROVIDER_VERSION
    base_url = "https://api.openalex.org"

    def _headers(self) -> Mapping[str, str]:
        headers = dict(super()._headers())
        mailto = os.environ.get("SCIENTIST_LITERATURE_MAILTO", "").strip()
        if mailto:
            headers["User-Agent"] = (
                "Scientist/0.1 autonomous-prior-art-review "
                "(mailto:%s)" % mailto
            )
        return headers

    @staticmethod
    def _select_fields() -> str:
        return (
            "id,doi,title,publication_year,primary_location,"
            "abstract_inverted_index,referenced_works,cited_by_count"
        )

    def search(
        self,
        query: str,
        facet: SearchFacet,
    ) -> Sequence[PriorWork]:
        parameters = {
            "search": query,
            "per-page": str(self.results_per_query),
            "select": self._select_fields(),
        }
        mailto = os.environ.get("SCIENTIST_LITERATURE_MAILTO", "").strip()
        if mailto:
            parameters["mailto"] = mailto
        url = "%s/works?%s" % (
            self.base_url,
            urllib.parse.urlencode(parameters),
        )
        payload = self._request(
            url=url,
            operation="search",
            query=query,
            facet=facet,
        )
        if payload is None:
            return ()
        items = payload.get("results", ())
        works = self._works_from_items(items, query, facet)
        self._set_result_count(len(works))
        return works

    def _works_from_items(
        self,
        items: Any,
        query: str,
        facet: SearchFacet,
    ) -> tuple[PriorWork, ...]:
        if not isinstance(items, list):
            return ()
        return tuple(
            work
            for item in items
            for work in (self._work_from_item(item, query, facet),)
            if work is not None
        )

    def _work_from_item(
        self,
        item: Any,
        query: str,
        facet: SearchFacet,
    ) -> Optional[PriorWork]:
        if not isinstance(item, dict):
            return None
        title = str(item.get("title", "")).strip()
        published_year = _year(item.get("publication_year"))
        openalex_url = str(item.get("id", "")).strip()
        openalex_id = openalex_url.rsplit("/", 1)[-1]
        doi_url = str(item.get("doi") or "").strip()
        doi = doi_url.lower().removeprefix("https://doi.org/")
        location = item.get("primary_location", {})
        landing_page = (
            str(location.get("landing_page_url") or "").strip()
            if isinstance(location, dict)
            else ""
        )
        if not title or published_year is None or not openalex_id:
            return None
        abstract = _abstract_from_inverted_index(
            item.get("abstract_inverted_index")
        )
        relation, matches = _relation_and_matches(
            query,
            title,
            abstract,
            facet,
            self.name,
        )
        return PriorWork(
            work_id=(
                "doi:%s" % doi
                if doi
                else "openalex:%s" % openalex_id
            ),
            title=title,
            year=published_year,
            locator=landing_page or doi_url or openalex_url,
            relation=relation,
            matched_components=matches,
            abstract=abstract,
        )

    def _resolve_seed(self, work: PriorWork) -> Optional[str]:
        if work.work_id.startswith("doi:"):
            identifier = "https://doi.org/%s" % work.work_id[4:]
            url = "%s/works/%s?%s" % (
                self.base_url,
                urllib.parse.quote(identifier, safe=":/"),
                urllib.parse.urlencode({"select": self._select_fields()}),
            )
            payload = self._request(
                url=url,
                operation="citation_seed_resolution",
                query=work.work_id,
                facet=SearchFacet.CITATION_NEIGHBORHOOD,
            )
            if isinstance(payload, dict):
                openalex_id = str(payload.get("id", "")).rsplit("/", 1)[-1]
                if openalex_id:
                    return openalex_id
        if work.work_id.startswith("openalex:"):
            return work.work_id.split(":", 1)[1]
        parameters = {
            "search": work.title,
            "per-page": "1",
            "select": self._select_fields(),
        }
        url = "%s/works?%s" % (
            self.base_url,
            urllib.parse.urlencode(parameters),
        )
        payload = self._request(
            url=url,
            operation="citation_seed_title_resolution",
            query=work.title,
            facet=SearchFacet.CITATION_NEIGHBORHOOD,
        )
        items = payload.get("results", ()) if isinstance(payload, dict) else ()
        first = items[0] if isinstance(items, list) and items else None
        openalex_url = str(first.get("id", "")) if isinstance(first, dict) else ""
        return openalex_url.rsplit("/", 1)[-1] or None

    def citation_neighborhood(
        self,
        work: PriorWork,
    ) -> Sequence[PriorWork]:
        openalex_id = self._resolve_seed(work)
        if not openalex_id:
            return ()
        parameters = {
            "filter": "cites:%s" % openalex_id,
            "per-page": str(self.results_per_query),
            "select": self._select_fields(),
        }
        mailto = os.environ.get("SCIENTIST_LITERATURE_MAILTO", "").strip()
        if mailto:
            parameters["mailto"] = mailto
        url = "%s/works?%s" % (
            self.base_url,
            urllib.parse.urlencode(parameters),
        )
        payload = self._request(
            url=url,
            operation="citation_neighborhood",
            query=work.work_id,
            facet=SearchFacet.CITATION_NEIGHBORHOOD,
        )
        if payload is None:
            return ()
        works = self._works_from_items(
            payload.get("results", ()),
            "citation neighbor of %s" % work.work_id,
            SearchFacet.CITATION_NEIGHBORHOOD,
        )
        self._set_result_count(len(works))
        return works


class LiveWebPriorArtReviewerV4(LiveWebPriorArtReviewer):
    """Reviewer with provider-derived, rather than hard-coded, provenance."""

    name = "live-web-prior-art-reviewer"
    reviewer_version = "v4"

    def review(self, planned):
        assessment = super().review(planned)
        stale = (
            "Live retrieval searched Crossref, DBLP, and Semantic Scholar "
            "for"
        )
        if stale not in assessment.rationale:
            raise ValueError("base reviewer provenance template changed")
        provider_names = [provider.name for provider in self.providers]
        if len(provider_names) < 2:
            raise ValueError("v4 reviewer requires independent providers")
        provider_text = (
            ", ".join(provider_names[:-1])
            + ", and "
            + provider_names[-1]
        )
        rationale = assessment.rationale.replace(
            stale,
            "Live retrieval searched %s for" % provider_text,
            1,
        ).replace(
            "DOI- or Semantic-Scholar-addressable planned seed",
            "provider-addressable planned seed",
            1,
        )
        if not self.last_manifest_digest:
            raise ValueError("v4 reviewer omitted its survey manifest")
        return replace(
            assessment,
            rationale=rationale,
            reviewer_ref="%s:%s:%s"
            % (self.name, self.reviewer_version, self.last_manifest_digest),
        )


def default_live_web_reviewer_v4(
    store: ArtifactStore,
    *,
    timeout_seconds: float = 20.0,
    results_per_query: int = 6,
    transport: Optional[JsonHttpTransport] = None,
) -> LiveWebPriorArtReviewer:
    """Use two citation-capable graph sources plus Crossref search evidence."""

    return LiveWebPriorArtReviewerV4(
        store,
        (
            CrossrefWebProvider(
                store,
                transport=transport,
                timeout_seconds=timeout_seconds,
                results_per_query=results_per_query,
            ),
            OpenAlexWebProvider(
                store,
                transport=transport,
                timeout_seconds=timeout_seconds,
                results_per_query=results_per_query,
            ),
            SemanticScholarWebProvider(
                store,
                transport=transport,
                timeout_seconds=timeout_seconds,
                results_per_query=results_per_query,
            ),
        ),
    )


__all__ = [
    "LIVE_WEB_REVIEWER_V4_VERSION",
    "OPENALEX_LITERATURE_PROVIDER_VERSION",
    "LiveWebPriorArtReviewerV4",
    "OpenAlexWebProvider",
    "default_live_web_reviewer_v4",
]
