from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import EvidencePartition


LEAF_QUALIFICATION_VERSION = "goal-graph-leaf-qualification-v1"


@dataclass(frozen=True)
class LeafQualificationRecord:
    """Fail-closed evidence for executable conformance/qualification leaves.

    Qualification leaves validate a frozen piece of scientific infrastructure.
    They do not synthesize a competing solution, so forcing them through an
    incumbent/island campaign would manufacture a meaningless search problem.
    """

    node_id: str
    leaf_contract_id: str
    protocol_ref: str
    evaluator_ref: str
    verifier_ref: str
    partition_commitments: Mapping[str, str]
    evidence_ids_by_partition: Mapping[str, Tuple[str, ...]]
    case_counts_by_partition: Mapping[str, int]
    check_results: Mapping[str, bool]
    preregistered_success_conditions: Tuple[str, ...]
    falsification_hits: Tuple[str, ...]
    raw_artifact_ids: Tuple[str, ...]
    metric_name: str
    metric_value: float
    compute_cost: float
    passed: bool
    limitations: Tuple[str, ...]
    schema_version: str = LEAF_QUALIFICATION_VERSION

    def __post_init__(self) -> None:
        required = (
            self.node_id,
            self.leaf_contract_id,
            self.protocol_ref,
            self.evaluator_ref,
            self.verifier_ref,
            self.metric_name,
        )
        if not all(required):
            raise ValueError("leaf qualification identity must not be empty")
        if self.evaluator_ref == self.verifier_ref:
            raise ValueError("leaf qualification requires an independent verifier")
        if not math.isfinite(self.metric_value):
            raise ValueError("leaf qualification metric must be finite")
        if not math.isfinite(self.compute_cost) or self.compute_cost < 0.0:
            raise ValueError("leaf qualification compute must be finite and non-negative")
        if not self.check_results:
            raise ValueError("leaf qualification requires frozen checks")
        if not self.preregistered_success_conditions:
            raise ValueError("leaf qualification requires preregistered conditions")
        if not self.raw_artifact_ids or not self.limitations:
            raise ValueError("leaf qualification requires artifacts and limitations")
        partitions = {item.value for item in EvidencePartition}
        commitment_keys = set(self.partition_commitments)
        evidence_keys = set(self.evidence_ids_by_partition)
        count_keys = set(self.case_counts_by_partition)
        if commitment_keys != partitions:
            raise ValueError("qualification must commit every evidence partition")
        if evidence_keys != partitions or count_keys != partitions:
            raise ValueError("qualification evidence must cover every partition")
        commitments = tuple(self.partition_commitments.values())
        if any(not item for item in commitments) or len(set(commitments)) != len(
            commitments
        ):
            raise ValueError("partition commitments must be non-empty and disjoint")
        if any(
            not evidence_ids
            or any(not evidence_id for evidence_id in evidence_ids)
            for evidence_ids in self.evidence_ids_by_partition.values()
        ):
            raise ValueError("each partition requires evidence artifacts")
        if any(count <= 0 for count in self.case_counts_by_partition.values()):
            raise ValueError("each qualification partition requires cases")
        derived_pass = (
            all(self.check_results.values())
            and not self.falsification_hits
            and self.metric_value == 1.0
        )
        if self.passed != derived_pass:
            raise ValueError("leaf qualification pass flag disagrees with evidence")

    @property
    def evidence_ids(self) -> Tuple[str, ...]:
        return tuple(
            evidence_id
            for partition in sorted(self.evidence_ids_by_partition)
            for evidence_id in self.evidence_ids_by_partition[partition]
        )

    @property
    def qualification_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "schema_version": self.schema_version,
            "node_id": self.node_id,
            "leaf_contract_id": self.leaf_contract_id,
            "protocol_ref": self.protocol_ref,
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "partition_commitments": dict(
                sorted(self.partition_commitments.items())
            ),
            "evidence_ids_by_partition": {
                partition: list(evidence_ids)
                for partition, evidence_ids in sorted(
                    self.evidence_ids_by_partition.items()
                )
            },
            "case_counts_by_partition": dict(
                sorted(self.case_counts_by_partition.items())
            ),
            "check_results": dict(sorted(self.check_results.items())),
            "preregistered_success_conditions": list(
                self.preregistered_success_conditions
            ),
            "falsification_hits": list(self.falsification_hits),
            "raw_artifact_ids": list(self.raw_artifact_ids),
            "metric_name": self.metric_name,
            "metric_value": self.metric_value,
            "compute_cost": self.compute_cost,
            "passed": self.passed,
            "limitations": list(self.limitations),
        }
        if include_id:
            value["qualification_id"] = self.qualification_id
        return value


def leaf_qualification_from_dict(
    value: Mapping[str, Any],
) -> LeafQualificationRecord:
    record = LeafQualificationRecord(
        node_id=str(value["node_id"]),
        leaf_contract_id=str(value["leaf_contract_id"]),
        protocol_ref=str(value["protocol_ref"]),
        evaluator_ref=str(value["evaluator_ref"]),
        verifier_ref=str(value["verifier_ref"]),
        partition_commitments={
            str(key): str(item)
            for key, item in value["partition_commitments"].items()
        },
        evidence_ids_by_partition={
            str(key): tuple(str(item) for item in items)
            for key, items in value["evidence_ids_by_partition"].items()
        },
        case_counts_by_partition={
            str(key): int(item)
            for key, item in value["case_counts_by_partition"].items()
        },
        check_results={
            str(key): bool(item)
            for key, item in value["check_results"].items()
        },
        preregistered_success_conditions=tuple(
            str(item) for item in value["preregistered_success_conditions"]
        ),
        falsification_hits=tuple(
            str(item) for item in value["falsification_hits"]
        ),
        raw_artifact_ids=tuple(str(item) for item in value["raw_artifact_ids"]),
        metric_name=str(value["metric_name"]),
        metric_value=float(value["metric_value"]),
        compute_cost=float(value["compute_cost"]),
        passed=bool(value["passed"]),
        limitations=tuple(str(item) for item in value["limitations"]),
        schema_version=str(
            value.get("schema_version", LEAF_QUALIFICATION_VERSION)
        ),
    )
    supplied = value.get("qualification_id")
    if supplied is not None and str(supplied) != record.qualification_id:
        raise ValueError("leaf qualification identity mismatch")
    return record
