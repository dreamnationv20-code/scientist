from __future__ import annotations

import json
import math
import os
import tempfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Protocol, Sequence, Tuple

from scientist.core.artifacts import canonical_json, content_digest
from scientist.kernel.domain_registry import ScientificDomainBundle
from scientist.program.campaigns import IncumbentPortfolio
from scientist.program.causal_failure import (
    CausalFailureModelSet,
    causal_failure_model_set_from_dict,
)
from scientist.program.contracts import HighLevelGoal
from scientist.program.goal_graph_serialization import (
    goal_from_dict,
    literature_from_dict,
    portfolio_from_dict,
    signature_from_dict,
)
from scientist.program.literature import ClaimSignature, PriorArtAssessment


AUTONOMOUS_RESEARCH_KERNEL_VERSION = "autonomous-research-kernel-v3"


def _unique(values: Sequence[str], label: str, minimum: int = 1) -> None:
    if len(values) < minimum or not all(values):
        raise ValueError("%s requires at least %d non-empty values" % (label, minimum))
    if len(set(values)) != len(values):
        raise ValueError("%s must be unique" % label)


def _finite_mapping(values: Mapping[str, float], label: str) -> None:
    if not values or not all(values):
        raise ValueError("%s must not be empty" % label)
    if not all(math.isfinite(float(value)) for value in values.values()):
        raise ValueError("%s must contain finite values" % label)


class ResearchPhase(str, Enum):
    MISSION = "mission"
    PRIOR_ART = "prior_art"
    INCUMBENT = "incumbent"
    PHENOMENON = "phenomenon"
    DIAGNOSIS = "diagnosis"
    CONCEPT = "concept"
    CONCEPT_VALIDATION = "concept_validation"
    EXPERIMENT = "experiment"
    MECHANISM = "mechanism"
    EVALUATION = "evaluation"
    PROGRAM_DECISION = "program_decision"
    TERMINAL = "terminal"


class ResearchActionKind(str, Enum):
    FREEZE_MISSION = "freeze_mission"
    SURVEY_PRIOR_ART = "survey_prior_art"
    REPRODUCE_INCUMBENT = "reproduce_incumbent"
    MAP_PHENOMENON = "map_phenomenon"
    BUILD_CAUSAL_DIAGNOSIS = "build_causal_diagnosis"
    INVENT_LATENT_CONCEPT = "invent_latent_concept"
    VALIDATE_LATENT_CONCEPT = "validate_latent_concept"
    DESIGN_DISCRIMINATING_EXPERIMENT = "design_discriminating_experiment"
    COMPILE_AND_AUDIT_MECHANISM = "compile_and_audit_mechanism"
    RUN_MULTI_HORIZON_EVALUATION = "run_multi_horizon_evaluation"
    MAKE_PROGRAM_DECISION = "make_program_decision"
    REPORT_TERMINAL = "report_terminal"


class ProgramDisposition(str, Enum):
    CONTINUE = "continue"
    REPAIR = "repair"
    KILL = "kill"
    REFRAME = "reframe"
    PROMOTE = "promote"


class KnowledgeKind(str, Enum):
    LITERATURE = "literature"
    INCUMBENT = "incumbent"
    OBSERVATION = "observation"
    CAUSAL_DIAGNOSIS = "causal_diagnosis"
    CONCEPT = "concept"
    MECHANISM = "mechanism"
    NEGATIVE_RESULT = "negative_result"
    PROGRAM_DECISION = "program_decision"


@dataclass(frozen=True)
class ResearchKernelPolicy:
    minimum_contrasts: int = 4
    minimum_unexplained_contrasts: int = 2
    minimum_regimes: int = 2
    minimum_horizons: int = 2
    maximum_repairs_per_concept: int = 1
    maximum_program_reframes: int = 1
    require_opposing_counterfactual_effects: bool = True
    require_closed_literature: bool = True
    require_reproduced_incumbent: bool = True
    require_full_trajectory_terminal_test: bool = True
    forbid_oracle_evidence_for_promotion: bool = True

    def __post_init__(self) -> None:
        counts = (
            self.minimum_contrasts,
            self.minimum_unexplained_contrasts,
            self.minimum_regimes,
            self.minimum_horizons,
        )
        if min(counts) <= 0:
            raise ValueError("research-kernel evidence thresholds must be positive")
        if self.minimum_unexplained_contrasts > self.minimum_contrasts:
            raise ValueError("unexplained contrast floor exceeds total contrast floor")
        if self.maximum_repairs_per_concept < 0 or self.maximum_program_reframes < 0:
            raise ValueError("research-kernel revision limits cannot be negative")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "minimum_contrasts": self.minimum_contrasts,
            "minimum_unexplained_contrasts": self.minimum_unexplained_contrasts,
            "minimum_regimes": self.minimum_regimes,
            "minimum_horizons": self.minimum_horizons,
            "maximum_repairs_per_concept": self.maximum_repairs_per_concept,
            "maximum_program_reframes": self.maximum_program_reframes,
            "require_opposing_counterfactual_effects": (
                self.require_opposing_counterfactual_effects
            ),
            "require_closed_literature": self.require_closed_literature,
            "require_reproduced_incumbent": self.require_reproduced_incumbent,
            "require_full_trajectory_terminal_test": (
                self.require_full_trajectory_terminal_test
            ),
            "forbid_oracle_evidence_for_promotion": (
                self.forbid_oracle_evidence_for_promotion
            ),
        }


@dataclass(frozen=True)
class ResearchMissionContract:
    goal: HighLevelGoal
    goal_graph_ref: str
    root_node_id: str
    domain_id: str
    domain_bundle_ref: str
    research_question: str
    claim_signature: ClaimSignature
    primary_metric: str
    terminal_gate_ref: str
    required_horizons: Tuple[str, ...]
    program_stop_rules: Tuple[str, ...]
    forbidden_shortcuts: Tuple[str, ...]
    owner_ref: str

    def __post_init__(self) -> None:
        required = (
            self.root_node_id,
            self.goal_graph_ref,
            self.domain_id,
            self.domain_bundle_ref,
            self.research_question,
            self.primary_metric,
            self.terminal_gate_ref,
            self.owner_ref,
        )
        if not all(required):
            raise ValueError("research mission is incomplete")
        if self.claim_signature.subject_id not in (
            self.goal.goal_id,
            self.root_node_id,
        ):
            raise ValueError("mission claim belongs to another research goal")
        primary = tuple(metric.name for metric in self.goal.terminal_metrics if metric.primary)
        if primary != (self.primary_metric,):
            raise ValueError("mission primary metric differs from the high-level goal")
        _unique(self.required_horizons, "mission horizons", minimum=2)
        _unique(self.program_stop_rules, "mission stop rules")
        _unique(self.forbidden_shortcuts, "mission forbidden shortcuts")

    @property
    def mission_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "goal": self.goal.as_dict(),
            "goal_graph_ref": self.goal_graph_ref,
            "root_node_id": self.root_node_id,
            "domain_id": self.domain_id,
            "domain_bundle_ref": self.domain_bundle_ref,
            "research_question": self.research_question,
            "claim_signature": self.claim_signature.as_dict(),
            "primary_metric": self.primary_metric,
            "terminal_gate_ref": self.terminal_gate_ref,
            "required_horizons": list(self.required_horizons),
            "program_stop_rules": list(self.program_stop_rules),
            "forbidden_shortcuts": list(self.forbidden_shortcuts),
            "owner_ref": self.owner_ref,
        }
        if include_id:
            value["mission_id"] = self.mission_id
        return value


@dataclass(frozen=True)
class PhenomenonCase:
    case_ref: str
    regime: str
    horizon: str
    incumbent_decision: str
    outcome_metrics: Mapping[str, float]
    evidence_ids: Tuple[str, ...]
    trace_ref: str

    def __post_init__(self) -> None:
        if not all((self.case_ref, self.regime, self.horizon, self.incumbent_decision, self.trace_ref)):
            raise ValueError("phenomenon case is incomplete")
        _finite_mapping(self.outcome_metrics, "phenomenon metrics")
        _unique(self.evidence_ids, "phenomenon evidence")

    @property
    def case_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "case_ref": self.case_ref,
            "regime": self.regime,
            "horizon": self.horizon,
            "incumbent_decision": self.incumbent_decision,
            "outcome_metrics": dict(sorted(self.outcome_metrics.items())),
            "evidence_ids": list(self.evidence_ids),
            "trace_ref": self.trace_ref,
        }
        if include_id:
            value["case_id"] = self.case_id
        return value


@dataclass(frozen=True)
class CounterfactualContrast:
    case_id: str
    incumbent_decision: str
    forced_decision: str
    terminal_effect: float
    matched_context: str
    mediator_observation: str
    existing_descriptors: Tuple[str, ...]
    unexplained_by_current_representation: bool
    evidence_ids: Tuple[str, ...]
    analyst_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.case_id,
                self.incumbent_decision,
                self.forced_decision,
                self.matched_context,
                self.mediator_observation,
                self.analyst_ref,
            )
        ):
            raise ValueError("counterfactual contrast is incomplete")
        if self.incumbent_decision == self.forced_decision:
            raise ValueError("counterfactual decision must differ from the incumbent")
        if not math.isfinite(self.terminal_effect):
            raise ValueError("counterfactual terminal effect must be finite")
        _unique(self.existing_descriptors, "contrast descriptors")
        _unique(self.evidence_ids, "contrast evidence")

    @property
    def contrast_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "case_id": self.case_id,
            "incumbent_decision": self.incumbent_decision,
            "forced_decision": self.forced_decision,
            "terminal_effect": self.terminal_effect,
            "matched_context": self.matched_context,
            "mediator_observation": self.mediator_observation,
            "existing_descriptors": list(self.existing_descriptors),
            "unexplained_by_current_representation": (
                self.unexplained_by_current_representation
            ),
            "evidence_ids": list(self.evidence_ids),
            "analyst_ref": self.analyst_ref,
        }
        if include_id:
            value["contrast_id"] = self.contrast_id
        return value


@dataclass(frozen=True)
class PhenomenonAtlas:
    mission_id: str
    incumbent_portfolio_id: str
    cases: Tuple[PhenomenonCase, ...]
    contrasts: Tuple[CounterfactualContrast, ...]
    coverage_axes: Tuple[str, ...]
    sealed: bool
    builder_ref: str

    def __post_init__(self) -> None:
        if not all((self.mission_id, self.incumbent_portfolio_id, self.builder_ref)):
            raise ValueError("phenomenon atlas is incomplete")
        if len({case.case_id for case in self.cases}) != len(self.cases):
            raise ValueError("phenomenon atlas cases must be unique")
        if len({item.contrast_id for item in self.contrasts}) != len(self.contrasts):
            raise ValueError("phenomenon atlas contrasts must be unique")
        case_ids = {case.case_id for case in self.cases}
        if any(item.case_id not in case_ids for item in self.contrasts):
            raise ValueError("counterfactual contrast references an unknown case")
        _unique(self.coverage_axes, "phenomenon coverage axes", minimum=2)

    @property
    def atlas_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def readiness_failures(self, policy: ResearchKernelPolicy) -> Tuple[str, ...]:
        failures = []
        if not self.sealed:
            failures.append("atlas_not_sealed")
        if len(self.contrasts) < policy.minimum_contrasts:
            failures.append("insufficient_counterfactual_contrasts")
        unexplained = sum(item.unexplained_by_current_representation for item in self.contrasts)
        if unexplained < policy.minimum_unexplained_contrasts:
            failures.append("insufficient_unexplained_contrasts")
        if len({case.regime for case in self.cases}) < policy.minimum_regimes:
            failures.append("insufficient_regime_coverage")
        if len({case.horizon for case in self.cases}) < policy.minimum_horizons:
            failures.append("insufficient_horizon_coverage")
        effects = tuple(item.terminal_effect for item in self.contrasts)
        if policy.require_opposing_counterfactual_effects and not (
            any(value > 0.0 for value in effects)
            and any(value <= 0.0 for value in effects)
        ):
            failures.append("no_opposing_counterfactual_outcomes")
        return tuple(failures)

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "mission_id": self.mission_id,
            "incumbent_portfolio_id": self.incumbent_portfolio_id,
            "cases": [case.as_dict() for case in self.cases],
            "contrasts": [item.as_dict() for item in self.contrasts],
            "coverage_axes": list(self.coverage_axes),
            "sealed": self.sealed,
            "builder_ref": self.builder_ref,
        }
        if include_id:
            value["atlas_id"] = self.atlas_id
        return value


@dataclass(frozen=True)
class DiagnosticConceptHypothesis:
    atlas_id: str
    causal_model_set_id: str
    name: str
    definition: str
    input_primitives: Tuple[str, ...]
    computation: str
    causal_explanation: str
    distinguishing_predictions: Tuple[str, ...]
    boundary_conditions: Tuple[str, ...]
    falsification_conditions: Tuple[str, ...]
    development_contrast_ids: Tuple[str, ...]
    required_predictive_score: float
    minimum_predictive_improvement: float
    prospective_case_count: int
    validation_protocol_ref: str
    proposer_ref: str

    def __post_init__(self) -> None:
        required = (
            self.atlas_id,
            self.causal_model_set_id,
            self.name,
            self.definition,
            self.computation,
            self.causal_explanation,
            self.validation_protocol_ref,
            self.proposer_ref,
        )
        if not all(required):
            raise ValueError("diagnostic concept is incomplete")
        _unique(self.input_primitives, "concept input primitives")
        _unique(self.distinguishing_predictions, "concept predictions", minimum=2)
        _unique(self.boundary_conditions, "concept boundary conditions")
        _unique(self.falsification_conditions, "concept falsifiers", minimum=2)
        _unique(self.development_contrast_ids, "concept development contrasts", minimum=2)
        if not 0.0 < self.required_predictive_score <= 1.0:
            raise ValueError("concept predictive floor must be in (0, 1]")
        if not 0.0 < self.minimum_predictive_improvement <= 1.0:
            raise ValueError("concept predictive improvement must be in (0, 1]")
        if self.prospective_case_count < 2:
            raise ValueError("concept validation needs prospective cases")

    @property
    def concept_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "atlas_id": self.atlas_id,
            "causal_model_set_id": self.causal_model_set_id,
            "name": self.name,
            "definition": self.definition,
            "input_primitives": list(self.input_primitives),
            "computation": self.computation,
            "causal_explanation": self.causal_explanation,
            "distinguishing_predictions": list(self.distinguishing_predictions),
            "boundary_conditions": list(self.boundary_conditions),
            "falsification_conditions": list(self.falsification_conditions),
            "development_contrast_ids": list(self.development_contrast_ids),
            "required_predictive_score": self.required_predictive_score,
            "minimum_predictive_improvement": self.minimum_predictive_improvement,
            "prospective_case_count": self.prospective_case_count,
            "validation_protocol_ref": self.validation_protocol_ref,
            "proposer_ref": self.proposer_ref,
        }
        if include_id:
            value["concept_id"] = self.concept_id
        return value


@dataclass(frozen=True)
class ConceptValidationCertificate:
    concept_id: str
    development_contrast_ids: Tuple[str, ...]
    prospective_case_ids: Tuple[str, ...]
    baseline_predictive_score: float
    augmented_predictive_score: float
    intervention_effect: float
    required_predictive_score: float
    minimum_predictive_improvement: float
    evidence_ids: Tuple[str, ...]
    evaluator_ref: str

    def __post_init__(self) -> None:
        if not self.concept_id or not self.evaluator_ref:
            raise ValueError("concept validation identity is incomplete")
        _unique(self.development_contrast_ids, "validation development contrasts", minimum=2)
        _unique(self.prospective_case_ids, "validation prospective cases", minimum=2)
        if set(self.development_contrast_ids).intersection(self.prospective_case_ids):
            raise ValueError("concept validation must be prospective")
        values = (
            self.baseline_predictive_score,
            self.augmented_predictive_score,
            self.required_predictive_score,
        )
        if not all(0.0 <= value <= 1.0 for value in values):
            raise ValueError("concept predictive scores must be in [0, 1]")
        if self.required_predictive_score <= 0.0:
            raise ValueError("required concept score must be positive")
        if not 0.0 < self.minimum_predictive_improvement <= 1.0:
            raise ValueError("concept improvement threshold must be in (0, 1]")
        if not math.isfinite(self.intervention_effect):
            raise ValueError("concept intervention effect must be finite")
        _unique(self.evidence_ids, "concept validation evidence")

    @property
    def predictive_improvement(self) -> float:
        return self.augmented_predictive_score - self.baseline_predictive_score

    @property
    def passed(self) -> bool:
        return (
            self.augmented_predictive_score >= self.required_predictive_score
            and self.predictive_improvement >= self.minimum_predictive_improvement
            and self.intervention_effect > 0.0
        )

    @property
    def validation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "concept_id": self.concept_id,
            "development_contrast_ids": list(self.development_contrast_ids),
            "prospective_case_ids": list(self.prospective_case_ids),
            "baseline_predictive_score": self.baseline_predictive_score,
            "augmented_predictive_score": self.augmented_predictive_score,
            "predictive_improvement": self.predictive_improvement,
            "intervention_effect": self.intervention_effect,
            "required_predictive_score": self.required_predictive_score,
            "minimum_predictive_improvement": self.minimum_predictive_improvement,
            "passed": self.passed,
            "evidence_ids": list(self.evidence_ids),
            "evaluator_ref": self.evaluator_ref,
        }
        if include_id:
            value["validation_id"] = self.validation_id
        return value


@dataclass(frozen=True)
class DiscriminatingExperimentPlan:
    mission_id: str
    concept_id: str
    competing_hypothesis_ids: Tuple[str, ...]
    predicted_outcomes: Mapping[str, Tuple[str, ...]]
    decision_rules: Mapping[str, str]
    horizon_refs: Tuple[str, ...]
    expected_information_gain: float
    compute_cost: float
    development_partition_ref: str
    sealed_evaluation_partition_ref: str
    oracle_inputs: Tuple[str, ...]
    final_target_withheld: bool
    frozen: bool
    designer_ref: str

    def __post_init__(self) -> None:
        required = (
            self.mission_id,
            self.concept_id,
            self.development_partition_ref,
            self.sealed_evaluation_partition_ref,
            self.designer_ref,
        )
        if not all(required):
            raise ValueError("discriminating experiment is incomplete")
        _unique(self.competing_hypothesis_ids, "competing hypotheses", minimum=2)
        if set(self.predicted_outcomes) != set(self.competing_hypothesis_ids):
            raise ValueError("experiment predictions must cover every hypothesis")
        if len({tuple(value) for value in self.predicted_outcomes.values()}) < 2:
            raise ValueError("experiment does not discriminate between hypotheses")
        if not self.decision_rules or not all(self.decision_rules):
            raise ValueError("experiment outcomes must change a research decision")
        _unique(self.horizon_refs, "experiment horizons", minimum=2)
        if not 0.0 < self.expected_information_gain <= 1.0:
            raise ValueError("expected information gain must be in (0, 1]")
        if not math.isfinite(self.compute_cost) or self.compute_cost <= 0.0:
            raise ValueError("experiment compute cost must be positive")
        if self.development_partition_ref == self.sealed_evaluation_partition_ref:
            raise ValueError("development and sealed evaluation must be disjoint")

    @property
    def plan_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def information_per_cost(self) -> float:
        return self.expected_information_gain / self.compute_cost

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "mission_id": self.mission_id,
            "concept_id": self.concept_id,
            "competing_hypothesis_ids": list(self.competing_hypothesis_ids),
            "predicted_outcomes": {
                key: list(items) for key, items in sorted(self.predicted_outcomes.items())
            },
            "decision_rules": dict(sorted(self.decision_rules.items())),
            "horizon_refs": list(self.horizon_refs),
            "expected_information_gain": self.expected_information_gain,
            "information_per_cost": self.information_per_cost,
            "compute_cost": self.compute_cost,
            "development_partition_ref": self.development_partition_ref,
            "sealed_evaluation_partition_ref": self.sealed_evaluation_partition_ref,
            "oracle_inputs": list(self.oracle_inputs),
            "final_target_withheld": self.final_target_withheld,
            "frozen": self.frozen,
            "designer_ref": self.designer_ref,
        }
        if include_id:
            value["plan_id"] = self.plan_id
        return value


@dataclass(frozen=True)
class BehavioralMechanismCertificate:
    concept_id: str
    plan_id: str
    candidate_id: str
    executable_digest: str
    mechanism_family: str
    behavior_fingerprint: str
    incumbent_behavior_fingerprint: str
    new_decision_primitives: Tuple[str, ...]
    probe_trace_ids: Tuple[str, ...]
    primary_incumbent_id: str
    fallback_candidate_id: str
    fallback_parity_evidence_ids: Tuple[str, ...]
    compiler_ref: str
    auditor_ref: str

    def __post_init__(self) -> None:
        required = (
            self.concept_id,
            self.plan_id,
            self.candidate_id,
            self.executable_digest,
            self.mechanism_family,
            self.behavior_fingerprint,
            self.incumbent_behavior_fingerprint,
            self.primary_incumbent_id,
            self.fallback_candidate_id,
            self.compiler_ref,
            self.auditor_ref,
        )
        if not all(required):
            raise ValueError("behavioral mechanism certificate is incomplete")
        if self.compiler_ref == self.auditor_ref:
            raise ValueError("mechanism compiler and behavioral auditor must be independent")
        _unique(self.new_decision_primitives, "new decision primitives")
        _unique(self.probe_trace_ids, "mechanism probe traces", minimum=2)
        _unique(self.fallback_parity_evidence_ids, "fallback parity evidence")

    @property
    def passed(self) -> bool:
        return (
            self.behavior_fingerprint != self.incumbent_behavior_fingerprint
            and self.fallback_candidate_id == self.primary_incumbent_id
            and bool(self.new_decision_primitives)
            and bool(self.fallback_parity_evidence_ids)
        )

    @property
    def certificate_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "concept_id": self.concept_id,
            "plan_id": self.plan_id,
            "candidate_id": self.candidate_id,
            "executable_digest": self.executable_digest,
            "mechanism_family": self.mechanism_family,
            "behavior_fingerprint": self.behavior_fingerprint,
            "incumbent_behavior_fingerprint": self.incumbent_behavior_fingerprint,
            "new_decision_primitives": list(self.new_decision_primitives),
            "probe_trace_ids": list(self.probe_trace_ids),
            "primary_incumbent_id": self.primary_incumbent_id,
            "fallback_candidate_id": self.fallback_candidate_id,
            "fallback_parity_evidence_ids": list(self.fallback_parity_evidence_ids),
            "compiler_ref": self.compiler_ref,
            "auditor_ref": self.auditor_ref,
            "passed": self.passed,
        }
        if include_id:
            value["certificate_id"] = self.certificate_id
        return value


@dataclass(frozen=True)
class MultiHorizonEvaluationCertificate:
    candidate_id: str
    plan_id: str
    horizon_metrics: Mapping[str, Mapping[str, float]]
    incumbent_metrics: Mapping[str, Mapping[str, float]]
    prediction_checks: Mapping[str, bool]
    development_evidence_ids: Tuple[str, ...]
    transfer_evidence_ids: Tuple[str, ...]
    terminal_evidence_ids: Tuple[str, ...]
    replication_evidence_ids: Tuple[str, ...]
    full_trajectory: bool
    oracle_free: bool
    terminal_gate_passed: bool
    evaluator_ref: str
    verifier_ref: str
    limitations: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not all((self.candidate_id, self.plan_id, self.evaluator_ref, self.verifier_ref)):
            raise ValueError("multi-horizon evaluation is incomplete")
        if self.evaluator_ref == self.verifier_ref:
            raise ValueError("evaluation and verification must be independent")
        if set(self.horizon_metrics) != set(self.incumbent_metrics):
            raise ValueError("candidate and incumbent horizons must match")
        if len(self.horizon_metrics) < 2:
            raise ValueError("multi-horizon evaluation requires at least two horizons")
        for name, metrics in self.horizon_metrics.items():
            _finite_mapping(metrics, "candidate metrics at %s" % name)
            _finite_mapping(self.incumbent_metrics[name], "incumbent metrics at %s" % name)
        if not self.prediction_checks:
            raise ValueError("evaluation must test preregistered predictions")
        for values, label in (
            (self.development_evidence_ids, "development evidence"),
            (self.transfer_evidence_ids, "transfer evidence"),
            (self.terminal_evidence_ids, "terminal evidence"),
            (self.replication_evidence_ids, "replication evidence"),
            (self.limitations, "evaluation limitations"),
        ):
            _unique(values, label)

    @property
    def claim_eligible(self) -> bool:
        return (
            self.full_trajectory
            and self.oracle_free
            and self.terminal_gate_passed
            and all(self.prediction_checks.values())
            and bool(self.replication_evidence_ids)
        )

    @property
    def evaluation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "candidate_id": self.candidate_id,
            "plan_id": self.plan_id,
            "horizon_metrics": {
                horizon: dict(sorted(metrics.items()))
                for horizon, metrics in sorted(self.horizon_metrics.items())
            },
            "incumbent_metrics": {
                horizon: dict(sorted(metrics.items()))
                for horizon, metrics in sorted(self.incumbent_metrics.items())
            },
            "prediction_checks": dict(sorted(self.prediction_checks.items())),
            "development_evidence_ids": list(self.development_evidence_ids),
            "transfer_evidence_ids": list(self.transfer_evidence_ids),
            "terminal_evidence_ids": list(self.terminal_evidence_ids),
            "replication_evidence_ids": list(self.replication_evidence_ids),
            "full_trajectory": self.full_trajectory,
            "oracle_free": self.oracle_free,
            "terminal_gate_passed": self.terminal_gate_passed,
            "claim_eligible": self.claim_eligible,
            "evaluator_ref": self.evaluator_ref,
            "verifier_ref": self.verifier_ref,
            "limitations": list(self.limitations),
        }
        if include_id:
            value["evaluation_id"] = self.evaluation_id
        return value


@dataclass(frozen=True)
class ResearchProgramDecision:
    mission_id: str
    disposition: ProgramDisposition
    central_hypothesis: str
    reasons: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    localized_failure: Optional[str]
    repair_target: Optional[str]
    replacement_hypothesis: Optional[str]
    changed_representation_dimensions: Tuple[str, ...]
    decision_ref: str

    def __post_init__(self) -> None:
        if not all((self.mission_id, self.central_hypothesis, self.reasons, self.evidence_ids, self.decision_ref)):
            raise ValueError("research-program decision is incomplete")
        _unique(self.reasons, "program decision reasons")
        _unique(self.evidence_ids, "program decision evidence")
        if self.disposition == ProgramDisposition.REPAIR and not all(
            (self.localized_failure, self.repair_target)
        ):
            raise ValueError("repair requires a localized failure and target")
        if self.disposition == ProgramDisposition.REFRAME and not (
            self.replacement_hypothesis and self.changed_representation_dimensions
        ):
            raise ValueError("reframe requires a new hypothesis and representation")
        if self.disposition != ProgramDisposition.REFRAME and (
            self.replacement_hypothesis or self.changed_representation_dimensions
        ):
            raise ValueError("only a reframe may replace the central representation")

    @property
    def decision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "mission_id": self.mission_id,
            "disposition": self.disposition.value,
            "central_hypothesis": self.central_hypothesis,
            "reasons": list(self.reasons),
            "evidence_ids": list(self.evidence_ids),
            "localized_failure": self.localized_failure,
            "repair_target": self.repair_target,
            "replacement_hypothesis": self.replacement_hypothesis,
            "changed_representation_dimensions": list(
                self.changed_representation_dimensions
            ),
            "decision_ref": self.decision_ref,
        }
        if include_id:
            value["decision_id"] = self.decision_id
        return value


@dataclass(frozen=True)
class ScientificKnowledgeRecord:
    mission_id: str
    domain_id: str
    kind: KnowledgeKind
    statement: str
    artifact_id: str
    evidence_ids: Tuple[str, ...]
    tags: Tuple[str, ...]
    status: str
    source_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.mission_id,
                self.domain_id,
                self.statement,
                self.artifact_id,
                self.status,
                self.source_ref,
            )
        ):
            raise ValueError("scientific knowledge record is incomplete")
        _unique(self.evidence_ids, "knowledge evidence")
        _unique(self.tags, "knowledge tags")

    @property
    def record_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "mission_id": self.mission_id,
            "domain_id": self.domain_id,
            "kind": self.kind.value,
            "statement": self.statement,
            "artifact_id": self.artifact_id,
            "evidence_ids": list(self.evidence_ids),
            "tags": list(self.tags),
            "status": self.status,
            "source_ref": self.source_ref,
        }
        if include_id:
            value["record_id"] = self.record_id
        return value


class ScientificKnowledgeBase:
    """Content-addressed cross-program memory, including negative results."""

    def __init__(self) -> None:
        self._records: Dict[str, ScientificKnowledgeRecord] = {}

    @property
    def records(self) -> Mapping[str, ScientificKnowledgeRecord]:
        return dict(self._records)

    def add(self, record: ScientificKnowledgeRecord) -> str:
        existing = self._records.get(record.record_id)
        if existing is not None and existing != record:
            raise ValueError("knowledge-record identity conflict")
        self._records[record.record_id] = record
        return record.record_id

    def query(
        self,
        *,
        domain_id: Optional[str] = None,
        kind: Optional[KnowledgeKind] = None,
        tags: Sequence[str] = (),
    ) -> Tuple[ScientificKnowledgeRecord, ...]:
        required_tags = set(tags)
        return tuple(
            record
            for _, record in sorted(self._records.items())
            if (domain_id is None or record.domain_id == domain_id)
            and (kind is None or record.kind == kind)
            and required_tags.issubset(record.tags)
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "records": [record.as_dict() for _, record in sorted(self._records.items())],
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ScientificKnowledgeBase":
        if value.get("kernel_version") != AUTONOMOUS_RESEARCH_KERNEL_VERSION:
            raise ValueError("unsupported scientific knowledge version")
        result = cls()
        for item in value.get("records", ()):
            result.add(knowledge_record_from_dict(item))
        return result


@dataclass(frozen=True)
class ExperimentPortfolioDecision:
    selected_plan_ids: Tuple[str, ...]
    deferred_plan_ids: Tuple[str, ...]
    total_compute_cost: float
    information_per_cost: Mapping[str, float]
    allocator_ref: str

    def __post_init__(self) -> None:
        if not self.selected_plan_ids or not self.allocator_ref:
            raise ValueError("experiment portfolio is incomplete")
        if set(self.selected_plan_ids).intersection(self.deferred_plan_ids):
            raise ValueError("experiment plans cannot be selected and deferred")
        if not math.isfinite(self.total_compute_cost) or self.total_compute_cost <= 0.0:
            raise ValueError("experiment portfolio cost must be positive")

    @property
    def decision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "selected_plan_ids": list(self.selected_plan_ids),
            "deferred_plan_ids": list(self.deferred_plan_ids),
            "total_compute_cost": self.total_compute_cost,
            "information_per_cost": dict(sorted(self.information_per_cost.items())),
            "allocator_ref": self.allocator_ref,
        }
        if include_id:
            value["decision_id"] = self.decision_id
        return value


def select_discriminating_experiments(
    plans: Sequence[DiscriminatingExperimentPlan],
    *,
    compute_budget: float,
    maximum_plans: int,
    allocator_ref: str = "information-gain-budget-controller-v1",
) -> ExperimentPortfolioDecision:
    """Select frozen experiments by information gain per unit compute."""

    if not math.isfinite(compute_budget) or compute_budget <= 0.0:
        raise ValueError("experiment compute budget must be positive")
    if maximum_plans <= 0:
        raise ValueError("experiment portfolio size must be positive")
    plans = tuple(plans)
    if not plans or len({plan.plan_id for plan in plans}) != len(plans):
        raise ValueError("experiment portfolio requires unique plans")
    if any(not plan.frozen for plan in plans):
        raise ValueError("only frozen experiment plans may receive compute")
    ranked = sorted(
        plans,
        key=lambda plan: (-plan.information_per_cost, -plan.expected_information_gain, plan.plan_id),
    )
    selected = []
    spent = 0.0
    for plan in ranked:
        if len(selected) >= maximum_plans:
            break
        if spent + plan.compute_cost <= compute_budget + 1e-12:
            selected.append(plan)
            spent += plan.compute_cost
    if not selected:
        raise ValueError("compute budget cannot fund any discriminating experiment")
    selected_ids = tuple(plan.plan_id for plan in selected)
    return ExperimentPortfolioDecision(
        selected_plan_ids=selected_ids,
        deferred_plan_ids=tuple(plan.plan_id for plan in ranked if plan.plan_id not in selected_ids),
        total_compute_cost=spent,
        information_per_cost={plan.plan_id: plan.information_per_cost for plan in ranked},
        allocator_ref=allocator_ref,
    )


@dataclass(frozen=True)
class ResearchKernelAction:
    kind: ResearchActionKind
    phase: ResearchPhase
    reason: str

    @property
    def action_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "kind": self.kind.value,
            "phase": self.phase.value,
            "reason": self.reason,
        }
        if include_id:
            value["action_id"] = self.action_id
        return value


class AutonomousResearchKernel:
    """Fail-closed authority for one complete, domain-neutral research cycle."""

    def __init__(
        self,
        policy: ResearchKernelPolicy = ResearchKernelPolicy(),
        knowledge: Optional[ScientificKnowledgeBase] = None,
    ) -> None:
        self.policy = policy
        self.knowledge = ScientificKnowledgeBase() if knowledge is None else knowledge
        self.mission: Optional[ResearchMissionContract] = None
        self.prior_art: Optional[PriorArtAssessment] = None
        self.incumbent: Optional[IncumbentPortfolio] = None
        self.atlas: Optional[PhenomenonAtlas] = None
        self.diagnosis: Optional[CausalFailureModelSet] = None
        self.concept: Optional[DiagnosticConceptHypothesis] = None
        self.concept_validation: Optional[ConceptValidationCertificate] = None
        self.experiment: Optional[DiscriminatingExperimentPlan] = None
        self.mechanism: Optional[BehavioralMechanismCertificate] = None
        self.evaluation: Optional[MultiHorizonEvaluationCertificate] = None
        self.decisions: Tuple[ResearchProgramDecision, ...] = ()
        self.repair_count = 0
        self.reframe_count = 0
        self.terminal_disposition: Optional[ProgramDisposition] = None

    @property
    def state_digest(self) -> str:
        return content_digest(self.as_dict())

    def _mission(self) -> ResearchMissionContract:
        if self.mission is None:
            raise ValueError("research mission has not been frozen")
        return self.mission

    def _remember(
        self,
        kind: KnowledgeKind,
        statement: str,
        artifact_id: str,
        evidence_ids: Sequence[str],
        tags: Sequence[str],
        status: str,
        source_ref: str,
    ) -> None:
        mission = self._mission()
        evidence = tuple(evidence_ids) or (artifact_id,)
        self.knowledge.add(
            ScientificKnowledgeRecord(
                mission_id=mission.mission_id,
                domain_id=mission.domain_id,
                kind=kind,
                statement=statement,
                artifact_id=artifact_id,
                evidence_ids=evidence,
                tags=tuple(tags),
                status=status,
                source_ref=source_ref,
            )
        )

    def freeze_mission(
        self,
        mission: ResearchMissionContract,
        domain: ScientificDomainBundle,
    ) -> str:
        if self.mission is not None:
            raise ValueError("research mission is already frozen")
        if mission.domain_id != domain.domain_id or mission.domain_bundle_ref != domain.bundle_ref:
            raise ValueError("mission and installed domain bundle disagree")
        self.mission = mission
        return mission.mission_id

    def register_prior_art(self, assessment: PriorArtAssessment) -> str:
        mission = self._mission()
        if self.prior_art is not None:
            raise ValueError("prior-art assessment is already registered")
        if assessment.signature.subject_id not in (mission.goal.goal_id, mission.root_node_id):
            raise ValueError("prior-art assessment belongs to another mission")
        if self.policy.require_closed_literature and not assessment.closure_passed:
            raise ValueError("literature closure failed: %s" % ", ".join(assessment.closure_failures))
        self.prior_art = assessment
        evidence = tuple(work.work_id for work in assessment.closest_works)
        self._remember(
            KnowledgeKind.LITERATURE,
            assessment.rationale,
            assessment.assessment_id,
            evidence,
            (assessment.classification.value, assessment.trigger.value),
            "closed" if assessment.closure_passed else "open",
            assessment.reviewer_ref,
        )
        return assessment.assessment_id

    def register_incumbent(self, portfolio: IncumbentPortfolio) -> str:
        if self.prior_art is None:
            raise ValueError("incumbent registration requires prior-art closure")
        if self.incumbent is not None:
            raise ValueError("incumbent portfolio is already registered")
        if portfolio.literature_assessment_id != self.prior_art.assessment_id:
            raise ValueError("incumbent portfolio uses another literature assessment")
        if self.policy.require_reproduced_incumbent and (
            not portfolio.closed or not portfolio.primary.reproduced
        ):
            raise ValueError("strongest incumbent must be reproduced and closed")
        self.incumbent = portfolio
        self._remember(
            KnowledgeKind.INCUMBENT,
            portfolio.selection_rationale,
            portfolio.portfolio_id,
            portfolio.primary.reproduction_evidence_ids,
            (portfolio.primary.role.value, "frozen_incumbent"),
            "reproduced" if portfolio.primary.reproduced else "unreproduced",
            "incumbent-auditor",
        )
        return portfolio.portfolio_id

    def register_atlas(self, atlas: PhenomenonAtlas) -> str:
        mission = self._mission()
        if self.incumbent is None:
            raise ValueError("phenomenon mapping requires a frozen incumbent")
        if atlas.mission_id != mission.mission_id:
            raise ValueError("phenomenon atlas belongs to another mission")
        if atlas.incumbent_portfolio_id != self.incumbent.portfolio_id:
            raise ValueError("phenomenon atlas uses another incumbent")
        failures = atlas.readiness_failures(self.policy)
        if failures:
            raise ValueError("phenomenon atlas is not diagnostic: %s" % ", ".join(failures))
        self.atlas = atlas
        evidence = tuple(
            evidence_id for item in atlas.contrasts for evidence_id in item.evidence_ids
        )
        self._remember(
            KnowledgeKind.OBSERVATION,
            "Sealed counterfactual failure atlas across regimes and horizons.",
            atlas.atlas_id,
            tuple(dict.fromkeys(evidence)),
            ("counterfactual", "multi_horizon", "phenomenon_atlas"),
            "diagnostically_ready",
            atlas.builder_ref,
        )
        return atlas.atlas_id

    def register_diagnosis(self, diagnosis: CausalFailureModelSet) -> str:
        mission = self._mission()
        if self.atlas is None:
            raise ValueError("causal diagnosis requires a phenomenon atlas")
        if diagnosis.target_node_id not in (mission.root_node_id, mission.goal.goal_id):
            raise ValueError("causal diagnosis targets another mission")
        if not diagnosis.coverage_complete or not all(
            model.empirically_supported for model in diagnosis.models
        ):
            raise ValueError("causal diagnosis requires replay-supported coverage")
        atlas_evidence = {
            evidence_id
            for item in self.atlas.contrasts
            for evidence_id in item.evidence_ids
        }
        if not atlas_evidence.intersection(diagnosis.source_artifact_ids):
            raise ValueError("causal diagnosis is not grounded in the phenomenon atlas")
        self.diagnosis = diagnosis
        self._remember(
            KnowledgeKind.CAUSAL_DIAGNOSIS,
            "Replay-supported causal models cover every registered failure cluster.",
            diagnosis.model_set_id,
            diagnosis.source_artifact_ids,
            ("causal", "counterfactual", "failure_model"),
            "supported",
            diagnosis.builder_ref,
        )
        return diagnosis.model_set_id

    def register_concept(self, concept: DiagnosticConceptHypothesis) -> str:
        if self.atlas is None or self.diagnosis is None:
            raise ValueError("concept invention requires atlas-grounded causal diagnosis")
        if self.concept is not None:
            raise ValueError("diagnostic concept is already registered")
        if concept.atlas_id != self.atlas.atlas_id:
            raise ValueError("concept belongs to another phenomenon atlas")
        if concept.causal_model_set_id != self.diagnosis.model_set_id:
            raise ValueError("concept belongs to another causal diagnosis")
        contrast_ids = {item.contrast_id for item in self.atlas.contrasts}
        if not set(concept.development_contrast_ids).issubset(contrast_ids):
            raise ValueError("concept cites unknown development contrasts")
        self.concept = concept
        self._remember(
            KnowledgeKind.CONCEPT,
            concept.causal_explanation,
            concept.concept_id,
            concept.development_contrast_ids,
            ("latent_concept", "prospective_prediction"),
            "unvalidated",
            concept.proposer_ref,
        )
        return concept.concept_id

    def validate_concept(self, validation: ConceptValidationCertificate) -> str:
        if self.concept is None:
            raise ValueError("concept validation requires a frozen concept")
        if self.concept_validation is not None:
            raise ValueError("concept validation is already registered")
        if validation.concept_id != self.concept.concept_id:
            raise ValueError("validation belongs to another concept")
        if validation.evaluator_ref == self.concept.proposer_ref:
            raise ValueError("concept proposal and validation must be independent")
        if validation.development_contrast_ids != self.concept.development_contrast_ids:
            raise ValueError("validation changed the concept development evidence")
        if len(validation.prospective_case_ids) < self.concept.prospective_case_count:
            raise ValueError("concept validation used too few prospective cases")
        self.concept_validation = validation
        self._remember(
            KnowledgeKind.CONCEPT if validation.passed else KnowledgeKind.NEGATIVE_RESULT,
            "Prospective concept validation %s." % ("passed" if validation.passed else "failed"),
            validation.validation_id,
            validation.evidence_ids,
            ("concept_validation", "prospective"),
            "passed" if validation.passed else "refuted",
            validation.evaluator_ref,
        )
        return validation.validation_id

    def register_experiment(self, plan: DiscriminatingExperimentPlan) -> str:
        mission = self._mission()
        if self.concept is None or self.concept_validation is None:
            raise ValueError("experiment design requires a validated concept")
        if self.experiment is not None:
            raise ValueError("discriminating experiment is already registered")
        if not self.concept_validation.passed:
            raise ValueError("a refuted concept cannot license mechanism search")
        if plan.mission_id != mission.mission_id or plan.concept_id != self.concept.concept_id:
            raise ValueError("experiment plan belongs to another research program")
        if not plan.frozen or not plan.final_target_withheld:
            raise ValueError("discriminating experiment must be frozen and answer-blind")
        if not set(mission.required_horizons).issubset(plan.horizon_refs):
            raise ValueError("experiment omits a mission-required horizon")
        self.experiment = plan
        return plan.plan_id

    def register_mechanism(self, certificate: BehavioralMechanismCertificate) -> str:
        if self.experiment is None or self.concept is None or self.incumbent is None:
            raise ValueError("mechanism compilation requires concept, experiment, and incumbent")
        if self.mechanism is not None:
            raise ValueError("behavioral mechanism is already registered")
        if certificate.plan_id != self.experiment.plan_id or certificate.concept_id != self.concept.concept_id:
            raise ValueError("mechanism certificate belongs to another experiment")
        if certificate.primary_incumbent_id != self.incumbent.primary_incumbent_id:
            raise ValueError("mechanism audit uses another incumbent")
        self.mechanism = certificate
        self._remember(
            KnowledgeKind.MECHANISM if certificate.passed else KnowledgeKind.NEGATIVE_RESULT,
            "Behavioral mechanism audit %s for family %s."
            % ("passed" if certificate.passed else "failed", certificate.mechanism_family),
            certificate.certificate_id,
            (*certificate.probe_trace_ids, *certificate.fallback_parity_evidence_ids),
            (certificate.mechanism_family, "behavioral_audit"),
            "passed" if certificate.passed else "collapsed",
            certificate.auditor_ref,
        )
        return certificate.certificate_id

    def record_evaluation(self, evaluation: MultiHorizonEvaluationCertificate) -> str:
        if self.mechanism is None or self.experiment is None:
            raise ValueError("evaluation requires a behaviorally audited mechanism")
        if self.evaluation is not None:
            raise ValueError("multi-horizon evaluation is already registered")
        if not self.mechanism.passed:
            raise ValueError("a collapsed mechanism cannot enter broad evaluation")
        if evaluation.candidate_id != self.mechanism.candidate_id:
            raise ValueError("evaluation uses another candidate")
        if evaluation.plan_id != self.experiment.plan_id:
            raise ValueError("evaluation uses another experiment plan")
        mission = self._mission()
        if not set(mission.required_horizons).issubset(evaluation.horizon_metrics):
            raise ValueError("evaluation omits a mission-required horizon")
        if any(
            mission.primary_metric not in evaluation.horizon_metrics[horizon]
            or mission.primary_metric not in evaluation.incumbent_metrics[horizon]
            for horizon in mission.required_horizons
        ):
            raise ValueError("evaluation omits the mission primary metric")
        independent_actors = {evaluation.evaluator_ref, evaluation.verifier_ref}
        design_actors = {
            self.mechanism.compiler_ref,
            self.mechanism.auditor_ref,
            self.experiment.designer_ref,
        }
        if independent_actors.intersection(design_actors):
            raise ValueError("broad evaluation must be independent of design and compilation")
        self.evaluation = evaluation
        kind = KnowledgeKind.MECHANISM if evaluation.claim_eligible else KnowledgeKind.NEGATIVE_RESULT
        self._remember(
            kind,
            "Multi-horizon evaluation %s the terminal claim gate."
            % ("passed" if evaluation.claim_eligible else "failed"),
            evaluation.evaluation_id,
            (*evaluation.terminal_evidence_ids, *evaluation.replication_evidence_ids),
            ("multi_horizon", "full_trajectory"),
            "claim_eligible" if evaluation.claim_eligible else "failed_terminal_gate",
            evaluation.verifier_ref,
        )
        return evaluation.evaluation_id

    def record_program_decision(self, decision: ResearchProgramDecision) -> str:
        mission = self._mission()
        if decision.mission_id != mission.mission_id:
            raise ValueError("program decision belongs to another mission")
        known_evidence = {
            value
            for record in self.knowledge.records.values()
            for value in (record.artifact_id, *record.evidence_ids)
        }
        if not set(decision.evidence_ids).issubset(known_evidence):
            raise ValueError("program decision cites evidence outside scientific memory")
        evaluation_actors = set()
        if self.evaluation is not None:
            evaluation_actors.update(
                (self.evaluation.evaluator_ref, self.evaluation.verifier_ref)
            )
        if decision.decision_ref in evaluation_actors:
            raise ValueError("program strategy must be independent of evaluation")
        if decision.disposition == ProgramDisposition.PROMOTE:
            if self.evaluation is None or not self.evaluation.claim_eligible:
                raise ValueError("promotion requires oracle-free replicated terminal success")
            self.terminal_disposition = ProgramDisposition.PROMOTE
        elif decision.disposition == ProgramDisposition.KILL:
            self.terminal_disposition = ProgramDisposition.KILL
        elif decision.disposition == ProgramDisposition.REPAIR:
            if self.repair_count >= self.policy.maximum_repairs_per_concept:
                raise ValueError("repair limit reached; kill or materially reframe")
            self.repair_count += 1
            self.mechanism = None
            self.evaluation = None
        elif decision.disposition == ProgramDisposition.REFRAME:
            if self.reframe_count >= self.policy.maximum_program_reframes:
                raise ValueError("program reframe limit reached; terminate the program")
            self.reframe_count += 1
            self.repair_count = 0
            self.atlas = None
            self.diagnosis = None
            self.concept = None
            self.concept_validation = None
            self.experiment = None
            self.mechanism = None
            self.evaluation = None
        elif decision.disposition == ProgramDisposition.CONTINUE:
            if self.evaluation is None:
                raise ValueError("continuation requires observed evaluation evidence")
            self.experiment = None
            self.mechanism = None
            self.evaluation = None
        self.decisions = (*self.decisions, decision)
        self._remember(
            KnowledgeKind.PROGRAM_DECISION,
            "; ".join(decision.reasons),
            decision.decision_id,
            decision.evidence_ids,
            (decision.disposition.value, "program_level"),
            "terminal" if self.terminal_disposition is not None else "active",
            decision.decision_ref,
        )
        return decision.decision_id

    def next_action(self) -> ResearchKernelAction:
        if self.terminal_disposition is not None:
            return ResearchKernelAction(
                ResearchActionKind.REPORT_TERMINAL,
                ResearchPhase.TERMINAL,
                "the research program has a terminal %s decision"
                % self.terminal_disposition.value,
            )
        if self.mission is None:
            return ResearchKernelAction(
                ResearchActionKind.FREEZE_MISSION,
                ResearchPhase.MISSION,
                "freeze the claim, goal graph boundary, horizons, and stop rules",
            )
        if self.prior_art is None:
            return ResearchKernelAction(
                ResearchActionKind.SURVEY_PRIOR_ART,
                ResearchPhase.PRIOR_ART,
                "close problem, intervention, mechanism, evaluation, and citation-neighborhood search",
            )
        if self.incumbent is None:
            return ResearchKernelAction(
                ResearchActionKind.REPRODUCE_INCUMBENT,
                ResearchPhase.INCUMBENT,
                "reproduce the strongest executable incumbent before invention",
            )
        if self.atlas is None:
            return ResearchKernelAction(
                ResearchActionKind.MAP_PHENOMENON,
                ResearchPhase.PHENOMENON,
                "map counterfactual failures across regimes and horizons before proposing mechanisms",
            )
        if self.diagnosis is None:
            return ResearchKernelAction(
                ResearchActionKind.BUILD_CAUSAL_DIAGNOSIS,
                ResearchPhase.DIAGNOSIS,
                "explain every failure cluster with replay-supported causal models",
            )
        if self.concept is None:
            return ResearchKernelAction(
                ResearchActionKind.INVENT_LATENT_CONCEPT,
                ResearchPhase.CONCEPT,
                "invent a missing variable that explains opposing counterfactual outcomes",
            )
        if self.concept_validation is None:
            return ResearchKernelAction(
                ResearchActionKind.VALIDATE_LATENT_CONCEPT,
                ResearchPhase.CONCEPT_VALIDATION,
                "test the concept prospectively before compiling a solution",
            )
        if not self.concept_validation.passed:
            return ResearchKernelAction(
                ResearchActionKind.MAKE_PROGRAM_DECISION,
                ResearchPhase.PROGRAM_DECISION,
                "the concept failed prospective validation; kill or materially reframe",
            )
        if self.experiment is None:
            return ResearchKernelAction(
                ResearchActionKind.DESIGN_DISCRIMINATING_EXPERIMENT,
                ResearchPhase.EXPERIMENT,
                "freeze an experiment whose outcomes separate competing mechanisms and change the program decision",
            )
        if self.mechanism is None:
            return ResearchKernelAction(
                ResearchActionKind.COMPILE_AND_AUDIT_MECHANISM,
                ResearchPhase.MECHANISM,
                "compile the concept and reject behavioral collapse or a weak fallback",
            )
        if not self.mechanism.passed:
            return ResearchKernelAction(
                ResearchActionKind.MAKE_PROGRAM_DECISION,
                ResearchPhase.PROGRAM_DECISION,
                "the executable collapsed into an incumbent family or weakened its fallback",
            )
        if self.evaluation is None:
            return ResearchKernelAction(
                ResearchActionKind.RUN_MULTI_HORIZON_EVALUATION,
                ResearchPhase.EVALUATION,
                "test preregistered predictions through transfer, full trajectory, and replication",
            )
        return ResearchKernelAction(
            ResearchActionKind.MAKE_PROGRAM_DECISION,
            ResearchPhase.PROGRAM_DECISION,
            "promote, repair, kill, or materially reframe from the frozen evidence",
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "policy": self.policy.as_dict(),
            "mission": None if self.mission is None else self.mission.as_dict(),
            "prior_art": None if self.prior_art is None else self.prior_art.as_dict(),
            "incumbent": None if self.incumbent is None else self.incumbent.as_dict(),
            "atlas": None if self.atlas is None else self.atlas.as_dict(),
            "diagnosis": None if self.diagnosis is None else self.diagnosis.as_dict(),
            "concept": None if self.concept is None else self.concept.as_dict(),
            "concept_validation": (
                None if self.concept_validation is None else self.concept_validation.as_dict()
            ),
            "experiment": None if self.experiment is None else self.experiment.as_dict(),
            "mechanism": None if self.mechanism is None else self.mechanism.as_dict(),
            "evaluation": None if self.evaluation is None else self.evaluation.as_dict(),
            "decisions": [decision.as_dict() for decision in self.decisions],
            "repair_count": self.repair_count,
            "reframe_count": self.reframe_count,
            "terminal_disposition": (
                None if self.terminal_disposition is None else self.terminal_disposition.value
            ),
            "next_action": self.next_action().as_dict(),
            "knowledge": self.knowledge.as_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "AutonomousResearchKernel":
        if value.get("kernel_version") != AUTONOMOUS_RESEARCH_KERNEL_VERSION:
            raise ValueError("unsupported autonomous research-kernel version")
        policy_value = value["policy"]
        policy = ResearchKernelPolicy(
            minimum_contrasts=int(policy_value["minimum_contrasts"]),
            minimum_unexplained_contrasts=int(
                policy_value["minimum_unexplained_contrasts"]
            ),
            minimum_regimes=int(policy_value["minimum_regimes"]),
            minimum_horizons=int(policy_value["minimum_horizons"]),
            maximum_repairs_per_concept=int(
                policy_value["maximum_repairs_per_concept"]
            ),
            maximum_program_reframes=int(policy_value["maximum_program_reframes"]),
            require_opposing_counterfactual_effects=bool(
                policy_value["require_opposing_counterfactual_effects"]
            ),
            require_closed_literature=bool(policy_value["require_closed_literature"]),
            require_reproduced_incumbent=bool(
                policy_value["require_reproduced_incumbent"]
            ),
            require_full_trajectory_terminal_test=bool(
                policy_value["require_full_trajectory_terminal_test"]
            ),
            forbid_oracle_evidence_for_promotion=bool(
                policy_value["forbid_oracle_evidence_for_promotion"]
            ),
        )
        knowledge = ScientificKnowledgeBase.from_dict(value["knowledge"])
        kernel = cls(policy=policy, knowledge=knowledge)
        if value.get("mission") is not None:
            kernel.mission = mission_from_dict(value["mission"])
        if value.get("prior_art") is not None:
            kernel.prior_art = literature_from_dict(value["prior_art"])
        if value.get("incumbent") is not None:
            kernel.incumbent = portfolio_from_dict(value["incumbent"])
        if value.get("atlas") is not None:
            kernel.atlas = phenomenon_atlas_from_dict(value["atlas"])
        if value.get("diagnosis") is not None:
            kernel.diagnosis = causal_failure_model_set_from_dict(value["diagnosis"])
        if value.get("concept") is not None:
            kernel.concept = diagnostic_concept_from_dict(value["concept"])
        if value.get("concept_validation") is not None:
            kernel.concept_validation = concept_validation_from_dict(
                value["concept_validation"]
            )
        if value.get("experiment") is not None:
            kernel.experiment = experiment_plan_from_dict(value["experiment"])
        if value.get("mechanism") is not None:
            kernel.mechanism = mechanism_certificate_from_dict(value["mechanism"])
        if value.get("evaluation") is not None:
            kernel.evaluation = evaluation_certificate_from_dict(value["evaluation"])
        kernel.decisions = tuple(
            program_decision_from_dict(item) for item in value.get("decisions", ())
        )
        kernel.repair_count = int(value.get("repair_count", 0))
        kernel.reframe_count = int(value.get("reframe_count", 0))
        terminal = value.get("terminal_disposition")
        kernel.terminal_disposition = (
            None if terminal is None else ProgramDisposition(terminal)
        )
        if kernel.repair_count < 0 or kernel.reframe_count < 0:
            raise ValueError("restored research-kernel counters are invalid")
        supplied_action = value.get("next_action")
        if supplied_action is not None and supplied_action.get("action_id") != kernel.next_action().action_id:
            raise ValueError("restored research-kernel next action changed")
        return kernel


def _identity(value: Mapping[str, Any], field: str, observed: str) -> None:
    supplied = value.get(field)
    if supplied is not None and str(supplied) != observed:
        raise ValueError("%s identity mismatch" % field)


def mission_from_dict(value: Mapping[str, Any]) -> ResearchMissionContract:
    result = ResearchMissionContract(
        goal=goal_from_dict(value["goal"]),
        goal_graph_ref=str(value["goal_graph_ref"]),
        root_node_id=str(value["root_node_id"]),
        domain_id=str(value["domain_id"]),
        domain_bundle_ref=str(value["domain_bundle_ref"]),
        research_question=str(value["research_question"]),
        claim_signature=signature_from_dict(value["claim_signature"]),
        primary_metric=str(value["primary_metric"]),
        terminal_gate_ref=str(value["terminal_gate_ref"]),
        required_horizons=tuple(str(item) for item in value["required_horizons"]),
        program_stop_rules=tuple(str(item) for item in value["program_stop_rules"]),
        forbidden_shortcuts=tuple(str(item) for item in value["forbidden_shortcuts"]),
        owner_ref=str(value["owner_ref"]),
    )
    _identity(value, "mission_id", result.mission_id)
    return result


def phenomenon_case_from_dict(value: Mapping[str, Any]) -> PhenomenonCase:
    result = PhenomenonCase(
        case_ref=str(value["case_ref"]),
        regime=str(value["regime"]),
        horizon=str(value["horizon"]),
        incumbent_decision=str(value["incumbent_decision"]),
        outcome_metrics={str(key): float(item) for key, item in value["outcome_metrics"].items()},
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        trace_ref=str(value["trace_ref"]),
    )
    _identity(value, "case_id", result.case_id)
    return result


def counterfactual_contrast_from_dict(value: Mapping[str, Any]) -> CounterfactualContrast:
    result = CounterfactualContrast(
        case_id=str(value["case_id"]),
        incumbent_decision=str(value["incumbent_decision"]),
        forced_decision=str(value["forced_decision"]),
        terminal_effect=float(value["terminal_effect"]),
        matched_context=str(value["matched_context"]),
        mediator_observation=str(value["mediator_observation"]),
        existing_descriptors=tuple(str(item) for item in value["existing_descriptors"]),
        unexplained_by_current_representation=bool(
            value["unexplained_by_current_representation"]
        ),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        analyst_ref=str(value["analyst_ref"]),
    )
    _identity(value, "contrast_id", result.contrast_id)
    return result


def phenomenon_atlas_from_dict(value: Mapping[str, Any]) -> PhenomenonAtlas:
    result = PhenomenonAtlas(
        mission_id=str(value["mission_id"]),
        incumbent_portfolio_id=str(value["incumbent_portfolio_id"]),
        cases=tuple(phenomenon_case_from_dict(item) for item in value["cases"]),
        contrasts=tuple(
            counterfactual_contrast_from_dict(item) for item in value["contrasts"]
        ),
        coverage_axes=tuple(str(item) for item in value["coverage_axes"]),
        sealed=bool(value["sealed"]),
        builder_ref=str(value["builder_ref"]),
    )
    _identity(value, "atlas_id", result.atlas_id)
    return result


def diagnostic_concept_from_dict(value: Mapping[str, Any]) -> DiagnosticConceptHypothesis:
    result = DiagnosticConceptHypothesis(
        atlas_id=str(value["atlas_id"]),
        causal_model_set_id=str(value["causal_model_set_id"]),
        name=str(value["name"]),
        definition=str(value["definition"]),
        input_primitives=tuple(str(item) for item in value["input_primitives"]),
        computation=str(value["computation"]),
        causal_explanation=str(value["causal_explanation"]),
        distinguishing_predictions=tuple(
            str(item) for item in value["distinguishing_predictions"]
        ),
        boundary_conditions=tuple(str(item) for item in value["boundary_conditions"]),
        falsification_conditions=tuple(
            str(item) for item in value["falsification_conditions"]
        ),
        development_contrast_ids=tuple(
            str(item) for item in value["development_contrast_ids"]
        ),
        required_predictive_score=float(value["required_predictive_score"]),
        minimum_predictive_improvement=float(value["minimum_predictive_improvement"]),
        prospective_case_count=int(value["prospective_case_count"]),
        validation_protocol_ref=str(value["validation_protocol_ref"]),
        proposer_ref=str(value["proposer_ref"]),
    )
    _identity(value, "concept_id", result.concept_id)
    return result


def concept_validation_from_dict(value: Mapping[str, Any]) -> ConceptValidationCertificate:
    result = ConceptValidationCertificate(
        concept_id=str(value["concept_id"]),
        development_contrast_ids=tuple(
            str(item) for item in value["development_contrast_ids"]
        ),
        prospective_case_ids=tuple(str(item) for item in value["prospective_case_ids"]),
        baseline_predictive_score=float(value["baseline_predictive_score"]),
        augmented_predictive_score=float(value["augmented_predictive_score"]),
        intervention_effect=float(value["intervention_effect"]),
        required_predictive_score=float(value["required_predictive_score"]),
        minimum_predictive_improvement=float(value["minimum_predictive_improvement"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        evaluator_ref=str(value["evaluator_ref"]),
    )
    _identity(value, "validation_id", result.validation_id)
    if "passed" in value and bool(value["passed"]) != result.passed:
        raise ValueError("concept validation outcome mismatch")
    return result


def experiment_plan_from_dict(value: Mapping[str, Any]) -> DiscriminatingExperimentPlan:
    result = DiscriminatingExperimentPlan(
        mission_id=str(value["mission_id"]),
        concept_id=str(value["concept_id"]),
        competing_hypothesis_ids=tuple(
            str(item) for item in value["competing_hypothesis_ids"]
        ),
        predicted_outcomes={
            str(key): tuple(str(item) for item in items)
            for key, items in value["predicted_outcomes"].items()
        },
        decision_rules={str(key): str(item) for key, item in value["decision_rules"].items()},
        horizon_refs=tuple(str(item) for item in value["horizon_refs"]),
        expected_information_gain=float(value["expected_information_gain"]),
        compute_cost=float(value["compute_cost"]),
        development_partition_ref=str(value["development_partition_ref"]),
        sealed_evaluation_partition_ref=str(value["sealed_evaluation_partition_ref"]),
        oracle_inputs=tuple(str(item) for item in value["oracle_inputs"]),
        final_target_withheld=bool(value["final_target_withheld"]),
        frozen=bool(value["frozen"]),
        designer_ref=str(value["designer_ref"]),
    )
    _identity(value, "plan_id", result.plan_id)
    return result


def mechanism_certificate_from_dict(value: Mapping[str, Any]) -> BehavioralMechanismCertificate:
    result = BehavioralMechanismCertificate(
        concept_id=str(value["concept_id"]),
        plan_id=str(value["plan_id"]),
        candidate_id=str(value["candidate_id"]),
        executable_digest=str(value["executable_digest"]),
        mechanism_family=str(value["mechanism_family"]),
        behavior_fingerprint=str(value["behavior_fingerprint"]),
        incumbent_behavior_fingerprint=str(value["incumbent_behavior_fingerprint"]),
        new_decision_primitives=tuple(str(item) for item in value["new_decision_primitives"]),
        probe_trace_ids=tuple(str(item) for item in value["probe_trace_ids"]),
        primary_incumbent_id=str(value["primary_incumbent_id"]),
        fallback_candidate_id=str(value["fallback_candidate_id"]),
        fallback_parity_evidence_ids=tuple(
            str(item) for item in value["fallback_parity_evidence_ids"]
        ),
        compiler_ref=str(value["compiler_ref"]),
        auditor_ref=str(value["auditor_ref"]),
    )
    _identity(value, "certificate_id", result.certificate_id)
    if "passed" in value and bool(value["passed"]) != result.passed:
        raise ValueError("behavioral mechanism audit mismatch")
    return result


def evaluation_certificate_from_dict(value: Mapping[str, Any]) -> MultiHorizonEvaluationCertificate:
    result = MultiHorizonEvaluationCertificate(
        candidate_id=str(value["candidate_id"]),
        plan_id=str(value["plan_id"]),
        horizon_metrics={
            str(horizon): {str(key): float(item) for key, item in metrics.items()}
            for horizon, metrics in value["horizon_metrics"].items()
        },
        incumbent_metrics={
            str(horizon): {str(key): float(item) for key, item in metrics.items()}
            for horizon, metrics in value["incumbent_metrics"].items()
        },
        prediction_checks={str(key): bool(item) for key, item in value["prediction_checks"].items()},
        development_evidence_ids=tuple(str(item) for item in value["development_evidence_ids"]),
        transfer_evidence_ids=tuple(str(item) for item in value["transfer_evidence_ids"]),
        terminal_evidence_ids=tuple(str(item) for item in value["terminal_evidence_ids"]),
        replication_evidence_ids=tuple(str(item) for item in value["replication_evidence_ids"]),
        full_trajectory=bool(value["full_trajectory"]),
        oracle_free=bool(value["oracle_free"]),
        terminal_gate_passed=bool(value["terminal_gate_passed"]),
        evaluator_ref=str(value["evaluator_ref"]),
        verifier_ref=str(value["verifier_ref"]),
        limitations=tuple(str(item) for item in value["limitations"]),
    )
    _identity(value, "evaluation_id", result.evaluation_id)
    if "claim_eligible" in value and bool(value["claim_eligible"]) != result.claim_eligible:
        raise ValueError("evaluation claim eligibility mismatch")
    return result


def program_decision_from_dict(value: Mapping[str, Any]) -> ResearchProgramDecision:
    result = ResearchProgramDecision(
        mission_id=str(value["mission_id"]),
        disposition=ProgramDisposition(value["disposition"]),
        central_hypothesis=str(value["central_hypothesis"]),
        reasons=tuple(str(item) for item in value["reasons"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        localized_failure=(None if value.get("localized_failure") is None else str(value["localized_failure"])),
        repair_target=(None if value.get("repair_target") is None else str(value["repair_target"])),
        replacement_hypothesis=(
            None if value.get("replacement_hypothesis") is None else str(value["replacement_hypothesis"])
        ),
        changed_representation_dimensions=tuple(
            str(item) for item in value["changed_representation_dimensions"]
        ),
        decision_ref=str(value["decision_ref"]),
    )
    _identity(value, "decision_id", result.decision_id)
    return result


def knowledge_record_from_dict(value: Mapping[str, Any]) -> ScientificKnowledgeRecord:
    result = ScientificKnowledgeRecord(
        mission_id=str(value["mission_id"]),
        domain_id=str(value["domain_id"]),
        kind=KnowledgeKind(value["kind"]),
        statement=str(value["statement"]),
        artifact_id=str(value["artifact_id"]),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
        tags=tuple(str(item) for item in value["tags"]),
        status=str(value["status"]),
        source_ref=str(value["source_ref"]),
    )
    _identity(value, "record_id", result.record_id)
    return result


class ResearchKernelRuntime:
    """Atomic checkpoint boundary for the V3 lifecycle and scientific memory."""

    def __init__(
        self,
        kernel: AutonomousResearchKernel,
        domain: ScientificDomainBundle,
        checkpoint_path: Path,
        *,
        save_on_init: bool = True,
    ) -> None:
        self.kernel = kernel
        self.domain = domain
        self.checkpoint_path = Path(checkpoint_path)
        if kernel.mission is not None and (
            kernel.mission.domain_id != domain.domain_id
            or kernel.mission.domain_bundle_ref != domain.bundle_ref
        ):
            raise ValueError("research checkpoint and installed domain disagree")
        if save_on_init:
            self.save_checkpoint()

    def _checkpoint_value(self) -> Dict[str, Any]:
        value = {
            "runtime_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "domain_id": self.domain.domain_id,
            "domain_bundle_ref": self.domain.bundle_ref,
            "kernel": self.kernel.as_dict(),
        }
        value["checkpoint_id"] = content_digest(value)
        return value

    def save_checkpoint(self) -> Path:
        destination = self.checkpoint_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        payload = canonical_json(self._checkpoint_value()) + b"\n"
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=destination.name + ".",
            suffix=".tmp",
            dir=str(destination.parent),
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, destination)
        finally:
            temporary_path = Path(temporary_name)
            if temporary_path.exists():
                temporary_path.unlink()
        return destination

    @classmethod
    def from_checkpoint(
        cls,
        checkpoint_path: Path,
        domain: ScientificDomainBundle,
    ) -> "ResearchKernelRuntime":
        path = Path(checkpoint_path)
        with path.open("r", encoding="utf-8") as handle:
            supplied = json.load(handle)
        if not isinstance(supplied, dict):
            raise ValueError("research-kernel checkpoint must be a JSON object")
        value = dict(supplied)
        checkpoint_id = value.pop("checkpoint_id", None)
        if checkpoint_id != content_digest(value):
            raise ValueError("research-kernel checkpoint digest mismatch")
        if value.get("runtime_version") != AUTONOMOUS_RESEARCH_KERNEL_VERSION:
            raise ValueError("unsupported research-kernel runtime version")
        if value.get("domain_id") != domain.domain_id or value.get("domain_bundle_ref") != domain.bundle_ref:
            raise ValueError("research-kernel checkpoint belongs to another domain")
        kernel = AutonomousResearchKernel.from_dict(value["kernel"])
        return cls(kernel, domain, path, save_on_init=False)


@dataclass(frozen=True)
class ResearchDispatchResult:
    progressed: bool
    stop: bool
    outcome: str
    details: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.outcome:
            raise ValueError("research dispatch outcome must not be empty")
        if self.progressed and self.stop:
            raise ValueError("a progressing research dispatch cannot also stop")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "progressed": self.progressed,
            "stop": self.stop,
            "outcome": self.outcome,
            "details": dict(self.details),
        }


class ResearchLifecycleComponent(Protocol):
    name: str
    component_version: str

    def dispatch(
        self,
        action: ResearchKernelAction,
        kernel: AutonomousResearchKernel,
        domain: ScientificDomainBundle,
    ) -> ResearchDispatchResult:
        ...


@dataclass(frozen=True)
class ResearchExecutiveStep:
    step_index: int
    action: ResearchKernelAction
    component_ref: str
    before_digest: str
    after_digest: str
    dispatch: ResearchDispatchResult

    def as_dict(self) -> Dict[str, Any]:
        return {
            "step_index": self.step_index,
            "action": self.action.as_dict(),
            "component_ref": self.component_ref,
            "before_digest": self.before_digest,
            "after_digest": self.after_digest,
            "dispatch": self.dispatch.as_dict(),
        }


@dataclass(frozen=True)
class ResearchExecutiveOutcome:
    boundary: str
    steps: Tuple[ResearchExecutiveStep, ...]
    state: Mapping[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "kernel_version": AUTONOMOUS_RESEARCH_KERNEL_VERSION,
            "boundary": self.boundary,
            "steps": [step.as_dict() for step in self.steps],
            "state": dict(self.state),
        }


class AutonomousResearchExecutive:
    """Drive V3 through components installed by a domain bundle."""

    def __init__(
        self,
        kernel: AutonomousResearchKernel,
        domain: ScientificDomainBundle,
        *,
        checkpoint_path: Optional[Path] = None,
    ) -> None:
        self.kernel = kernel
        self.domain = domain
        self.runtime = (
            None
            if checkpoint_path is None
            else ResearchKernelRuntime(kernel, domain, checkpoint_path)
        )

    def run(self, max_steps: int = 16) -> ResearchExecutiveOutcome:
        if max_steps <= 0:
            raise ValueError("autonomous research executive max_steps must be positive")
        steps = []
        for step_index in range(max_steps):
            action = self.kernel.next_action()
            component = self.domain.research_component(action.kind.value)
            before = self.kernel.state_digest
            dispatch = component.dispatch(action, self.kernel, self.domain)
            after = self.kernel.state_digest
            if dispatch.progressed and after == before:
                raise ValueError("research component claimed progress without changing durable state")
            step = ResearchExecutiveStep(
                step_index=step_index,
                action=action,
                component_ref="%s@%s" % (component.name, component.component_version),
                before_digest=before,
                after_digest=after,
                dispatch=dispatch,
            )
            steps.append(step)
            if self.runtime is not None:
                self.runtime.save_checkpoint()
            if dispatch.stop or action.kind == ResearchActionKind.REPORT_TERMINAL:
                return ResearchExecutiveOutcome(
                    boundary=dispatch.outcome,
                    steps=tuple(steps),
                    state=self.kernel.as_dict(),
                )
        return ResearchExecutiveOutcome(
            boundary="step_budget_exhausted",
            steps=tuple(steps),
            state=self.kernel.as_dict(),
        )
