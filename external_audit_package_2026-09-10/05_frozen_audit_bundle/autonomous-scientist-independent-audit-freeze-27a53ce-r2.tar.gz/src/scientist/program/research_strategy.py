from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Protocol, Sequence, Tuple

from scientist.core.artifacts import content_digest


RESEARCH_STRATEGY_VERSION = "research-program-strategy-v1"


class RepresentationDimension(str, Enum):
    OBSERVATION = "observation"
    STATE = "state"
    ACTION = "action"
    HYPOTHESIS_LANGUAGE = "hypothesis_language"
    COMPOSITION = "composition"
    OBJECTIVE = "objective"
    EXPERIMENT = "experiment"


@dataclass(frozen=True)
class RepresentationContract:
    """The conceptual and executable language available to a program.

    This is deliberately broader than a model prompt.  Its identity is bound
    into generated research objects, and a revision must name the dimensions
    it changes.  Domain adapters remain responsible for executable compliance.
    """

    domain_id: str
    name: str
    research_object_type: str
    observation_schema: Tuple[str, ...]
    state_schema: Tuple[str, ...]
    action_schema: Tuple[str, ...]
    hypothesis_language: Tuple[str, ...]
    composition_operators: Tuple[str, ...]
    objective_schema: Tuple[str, ...]
    experimental_unit: str
    compiler_ref: str
    evaluator_ref: str
    parent_representation_id: str | None = None
    changed_dimensions: Tuple[RepresentationDimension, ...] = ()

    def __post_init__(self) -> None:
        required_scalars = (
            self.domain_id,
            self.name,
            self.research_object_type,
            self.experimental_unit,
            self.compiler_ref,
            self.evaluator_ref,
        )
        required_sequences = (
            self.observation_schema,
            self.state_schema,
            self.action_schema,
            self.hypothesis_language,
            self.composition_operators,
            self.objective_schema,
        )
        if not all(required_scalars) or not all(required_sequences):
            raise ValueError("representation contract is incomplete")
        for sequence in required_sequences:
            if len(set(sequence)) != len(sequence) or not all(sequence):
                raise ValueError(
                    "representation contract entries must be non-empty and unique"
                )
        if len(set(self.changed_dimensions)) != len(self.changed_dimensions):
            raise ValueError("changed representation dimensions must be unique")
        if self.parent_representation_id is None and self.changed_dimensions:
            raise ValueError(
                "an initial representation cannot claim changed dimensions"
            )
        if self.parent_representation_id is not None and not self.changed_dimensions:
            raise ValueError(
                "a representation revision must change at least one dimension"
            )

    @property
    def representation_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "strategy_version": RESEARCH_STRATEGY_VERSION,
            "domain_id": self.domain_id,
            "name": self.name,
            "research_object_type": self.research_object_type,
            "observation_schema": list(self.observation_schema),
            "state_schema": list(self.state_schema),
            "action_schema": list(self.action_schema),
            "hypothesis_language": list(self.hypothesis_language),
            "composition_operators": list(self.composition_operators),
            "objective_schema": list(self.objective_schema),
            "experimental_unit": self.experimental_unit,
            "compiler_ref": self.compiler_ref,
            "evaluator_ref": self.evaluator_ref,
            "parent_representation_id": self.parent_representation_id,
            "changed_dimensions": [
                dimension.value for dimension in self.changed_dimensions
            ],
        }
        if include_id:
            value["representation_id"] = self.representation_id
        return value


@dataclass(frozen=True)
class ResearchProgramContract:
    """A falsifiable hypothesis class, not merely a candidate batch."""

    node_id: str
    question: str
    representation: RepresentationContract
    hypothesis_classes: Tuple[str, ...]
    assumptions: Tuple[str, ...]
    success_criteria: Tuple[str, ...]
    kill_criteria: Tuple[str, ...]
    candidate_budget: int
    strategy_ref: str
    parent_program_id: str | None = None

    def __post_init__(self) -> None:
        if not all((self.node_id, self.question, self.strategy_ref)):
            raise ValueError("research program identity is incomplete")
        for sequence in (
            self.hypothesis_classes,
            self.assumptions,
            self.success_criteria,
            self.kill_criteria,
        ):
            if not sequence or len(set(sequence)) != len(sequence):
                raise ValueError(
                    "research program declarations must be non-empty and unique"
                )
        if self.candidate_budget <= 0:
            raise ValueError("research program candidate budget must be positive")
        if (
            self.parent_program_id is None
            and self.representation.parent_representation_id is not None
        ):
            raise ValueError(
                "an initial research program requires an initial representation"
            )
        if (
            self.parent_program_id is not None
            and self.representation.parent_representation_id is None
        ):
            raise ValueError(
                "a revised research program requires a revised representation"
            )

    @property
    def program_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "strategy_version": RESEARCH_STRATEGY_VERSION,
            "node_id": self.node_id,
            "question": self.question,
            "representation": self.representation.as_dict(),
            "hypothesis_classes": list(self.hypothesis_classes),
            "assumptions": list(self.assumptions),
            "success_criteria": list(self.success_criteria),
            "kill_criteria": list(self.kill_criteria),
            "candidate_budget": self.candidate_budget,
            "strategy_ref": self.strategy_ref,
            "parent_program_id": self.parent_program_id,
        }
        if include_id:
            value["program_id"] = self.program_id
        return value


@dataclass(frozen=True)
class ResearchProgramEvidence:
    """Program-level evidence aggregated without changing scientific gates."""

    program_id: str
    representation_id: str
    cycle_index: int
    channel_evaluations: Mapping[str, int]
    proposed_count: int
    compiled_count: int
    evaluated_count: int
    behaviorally_distinct_count: int
    semantically_novel_count: int
    confidence_supported_improvement_count: int
    research_eligible_count: int
    mechanism_class_counts: Mapping[str, int]
    failure_counts: Mapping[str, int]
    best_effect: float
    best_lower_confidence_bound: float
    evidence_ids: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.program_id or not self.representation_id:
            raise ValueError("research-program evidence identity is incomplete")
        if self.cycle_index < 0:
            raise ValueError("research-program cycle index cannot be negative")
        counts = (
            self.proposed_count,
            self.compiled_count,
            self.evaluated_count,
            self.behaviorally_distinct_count,
            self.semantically_novel_count,
            self.confidence_supported_improvement_count,
            self.research_eligible_count,
            *self.channel_evaluations.values(),
            *self.mechanism_class_counts.values(),
            *self.failure_counts.values(),
        )
        if counts and min(counts) < 0:
            raise ValueError("research-program evidence counts cannot be negative")
        if not (
            self.proposed_count >= self.compiled_count >= self.evaluated_count
        ):
            raise ValueError(
                "program evidence must satisfy proposed >= compiled >= evaluated"
            )
        bounded = (
            self.behaviorally_distinct_count,
            self.semantically_novel_count,
            self.confidence_supported_improvement_count,
            self.research_eligible_count,
        )
        if any(count > self.evaluated_count for count in bounded):
            raise ValueError("program outcome counts exceed evaluated candidates")
        if sum(self.channel_evaluations.values()) != self.evaluated_count:
            raise ValueError("channel evaluations must cover every evaluation")
        if sum(self.mechanism_class_counts.values()) > self.evaluated_count:
            raise ValueError("mechanism classes exceed evaluated candidates")
        if not all(
            math.isfinite(value)
            for value in (self.best_effect, self.best_lower_confidence_bound)
        ):
            raise ValueError("program effects must be finite")
        if self.evaluated_count and not self.evidence_ids:
            raise ValueError("evaluated research programs require evidence IDs")
        if len(set(self.evidence_ids)) != len(self.evidence_ids):
            raise ValueError("research-program evidence IDs must be unique")

    @property
    def evidence_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "strategy_version": RESEARCH_STRATEGY_VERSION,
            "program_id": self.program_id,
            "representation_id": self.representation_id,
            "cycle_index": self.cycle_index,
            "channel_evaluations": dict(sorted(self.channel_evaluations.items())),
            "proposed_count": self.proposed_count,
            "compiled_count": self.compiled_count,
            "evaluated_count": self.evaluated_count,
            "behaviorally_distinct_count": self.behaviorally_distinct_count,
            "semantically_novel_count": self.semantically_novel_count,
            "confidence_supported_improvement_count": (
                self.confidence_supported_improvement_count
            ),
            "research_eligible_count": self.research_eligible_count,
            "mechanism_class_counts": dict(
                sorted(self.mechanism_class_counts.items())
            ),
            "failure_counts": dict(sorted(self.failure_counts.items())),
            "best_effect": self.best_effect,
            "best_lower_confidence_bound": self.best_lower_confidence_bound,
            "evidence_ids": list(self.evidence_ids),
        }
        if include_id:
            value["evidence_id"] = self.evidence_id
        return value


class StrategyDisposition(str, Enum):
    CONTINUE = "continue"
    REPAIR_PIPELINE = "repair_pipeline"
    CHANGE_REPRESENTATION = "change_representation"
    PARK = "park"


class ProgramFailureKind(str, Enum):
    INSUFFICIENT_EVIDENCE = "insufficient_evidence"
    NONE = "none"
    PIPELINE_ATTRITION = "pipeline_attrition"
    BEHAVIOR_COLLAPSE = "behavior_collapse"
    CONCEPTUAL_COLLAPSE = "conceptual_collapse"
    PROPOSAL_FAILURE = "proposal_failure"
    REPRESENTATION_EXHAUSTED = "representation_exhausted"


@dataclass(frozen=True)
class ResearchStrategyPolicy:
    minimum_evaluated_candidates: int
    minimum_evaluations_per_channel: int
    minimum_compile_yield: float = 0.45
    maximum_mechanism_class_fraction: float = 0.75
    maximum_representation_revisions: int = 2

    def __post_init__(self) -> None:
        if min(
            self.minimum_evaluated_candidates,
            self.minimum_evaluations_per_channel,
            self.maximum_representation_revisions,
        ) <= 0:
            raise ValueError("research-strategy policy counts must be positive")
        if not 0.0 < self.minimum_compile_yield <= 1.0:
            raise ValueError("minimum compile yield must be in (0, 1]")
        if not 0.0 < self.maximum_mechanism_class_fraction <= 1.0:
            raise ValueError("mechanism concentration must be in (0, 1]")


@dataclass(frozen=True)
class ResearchProgramDiagnosis:
    program_id: str
    representation_id: str
    evidence_id: str
    cycle_index: int
    disposition: StrategyDisposition
    failure_kind: ProgramFailureKind
    reasons: Tuple[str, ...]
    failed_assumptions: Tuple[str, ...]
    required_dimensions: Tuple[RepresentationDimension, ...]
    representation_revision_count: int
    assessor_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.program_id,
                self.representation_id,
                self.evidence_id,
                self.reasons,
                self.assessor_ref,
            )
        ):
            raise ValueError("research-program diagnosis is incomplete")
        if self.cycle_index < 0 or self.representation_revision_count < 0:
            raise ValueError("research-program diagnosis indices cannot be negative")
        if len(set(self.required_dimensions)) != len(self.required_dimensions):
            raise ValueError("required representation dimensions must be unique")
        representation_dispositions = {
            StrategyDisposition.CHANGE_REPRESENTATION,
            StrategyDisposition.PARK,
        }
        if (
            self.disposition == StrategyDisposition.CHANGE_REPRESENTATION
            and not self.required_dimensions
        ):
            raise ValueError("representation change requires named dimensions")
        if (
            self.disposition not in representation_dispositions
            and self.failure_kind == ProgramFailureKind.REPRESENTATION_EXHAUSTED
        ):
            raise ValueError("exhausted representations must park the program")

    @property
    def diagnosis_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "strategy_version": RESEARCH_STRATEGY_VERSION,
            "program_id": self.program_id,
            "representation_id": self.representation_id,
            "evidence_id": self.evidence_id,
            "cycle_index": self.cycle_index,
            "disposition": self.disposition.value,
            "failure_kind": self.failure_kind.value,
            "reasons": list(self.reasons),
            "failed_assumptions": list(self.failed_assumptions),
            "required_dimensions": [
                dimension.value for dimension in self.required_dimensions
            ],
            "representation_revision_count": (
                self.representation_revision_count
            ),
            "assessor_ref": self.assessor_ref,
        }
        if include_id:
            value["diagnosis_id"] = self.diagnosis_id
        return value


def diagnose_research_program(
    program: ResearchProgramContract,
    evidence: ResearchProgramEvidence,
    policy: ResearchStrategyPolicy,
    *,
    representation_revision_count: int,
    assessor_ref: str = "deterministic-research-strategy-diagnoser-v1",
) -> ResearchProgramDiagnosis:
    """Diagnose a whole hypothesis class after one matched evidence cycle."""

    if evidence.program_id != program.program_id:
        raise ValueError("strategy evidence belongs to another research program")
    if evidence.representation_id != program.representation.representation_id:
        raise ValueError("strategy evidence used another representation")
    channel_floor_met = bool(evidence.channel_evaluations) and all(
        count >= policy.minimum_evaluations_per_channel
        for count in evidence.channel_evaluations.values()
    )
    if (
        evidence.evaluated_count < policy.minimum_evaluated_candidates
        or not channel_floor_met
    ):
        return ResearchProgramDiagnosis(
            program_id=program.program_id,
            representation_id=evidence.representation_id,
            evidence_id=evidence.evidence_id,
            cycle_index=evidence.cycle_index,
            disposition=StrategyDisposition.CONTINUE,
            failure_kind=ProgramFailureKind.INSUFFICIENT_EVIDENCE,
            reasons=(
                "the matched program-level evidence floor has not been met",
            ),
            failed_assumptions=(),
            required_dimensions=(),
            representation_revision_count=representation_revision_count,
            assessor_ref=assessor_ref,
        )

    compile_yield = (
        evidence.compiled_count / evidence.proposed_count
        if evidence.proposed_count
        else 0.0
    )
    if compile_yield < policy.minimum_compile_yield:
        return ResearchProgramDiagnosis(
            program_id=program.program_id,
            representation_id=evidence.representation_id,
            evidence_id=evidence.evidence_id,
            cycle_index=evidence.cycle_index,
            disposition=StrategyDisposition.REPAIR_PIPELINE,
            failure_kind=ProgramFailureKind.PIPELINE_ATTRITION,
            reasons=(
                "most proposed objects failed before scientific evaluation",
                "generator or compiler attrition cannot diagnose the research idea",
            ),
            failed_assumptions=(
                "the proposal transport faithfully instantiates the declared program",
            ),
            required_dimensions=(),
            representation_revision_count=representation_revision_count,
            assessor_ref=assessor_ref,
        )

    if (
        evidence.confidence_supported_improvement_count > 0
        or evidence.research_eligible_count > 0
    ):
        return ResearchProgramDiagnosis(
            program_id=program.program_id,
            representation_id=evidence.representation_id,
            evidence_id=evidence.evidence_id,
            cycle_index=evidence.cycle_index,
            disposition=StrategyDisposition.CONTINUE,
            failure_kind=ProgramFailureKind.NONE,
            reasons=(
                "the program produced a confidence-supported or research-eligible candidate",
            ),
            failed_assumptions=(),
            required_dimensions=(),
            representation_revision_count=representation_revision_count,
            assessor_ref=assessor_ref,
        )

    if representation_revision_count >= policy.maximum_representation_revisions:
        return ResearchProgramDiagnosis(
            program_id=program.program_id,
            representation_id=evidence.representation_id,
            evidence_id=evidence.evidence_id,
            cycle_index=evidence.cycle_index,
            disposition=StrategyDisposition.PARK,
            failure_kind=ProgramFailureKind.REPRESENTATION_EXHAUSTED,
            reasons=(
                "multiple materially different representations produced no supported effect",
                "continuing would repeat an unproductive research program",
            ),
            failed_assumptions=(
                "the current problem framing contains a productive local research program",
            ),
            required_dimensions=(
                RepresentationDimension.OBSERVATION,
                RepresentationDimension.ACTION,
                RepresentationDimension.EXPERIMENT,
            ),
            representation_revision_count=representation_revision_count,
            assessor_ref=assessor_ref,
        )

    concentration = (
        max(evidence.mechanism_class_counts.values()) / evidence.evaluated_count
        if evidence.mechanism_class_counts and evidence.evaluated_count
        else 0.0
    )
    if evidence.behaviorally_distinct_count == 0:
        failure_kind = ProgramFailureKind.BEHAVIOR_COLLAPSE
        reasons = (
            "the program produced no behaviorally distinct research objects",
            "candidate-level prompt variation did not change executable behavior",
        )
        dimensions = (
            RepresentationDimension.ACTION,
            RepresentationDimension.HYPOTHESIS_LANGUAGE,
            RepresentationDimension.COMPOSITION,
        )
    elif concentration >= policy.maximum_mechanism_class_fraction:
        failure_kind = ProgramFailureKind.CONCEPTUAL_COLLAPSE
        reasons = (
            "candidate mechanisms concentrated in one conceptual family",
            "no candidate produced a confidence-supported improvement",
        )
        dimensions = (
            RepresentationDimension.STATE,
            RepresentationDimension.HYPOTHESIS_LANGUAGE,
            RepresentationDimension.COMPOSITION,
            RepresentationDimension.OBJECTIVE,
        )
    else:
        return ResearchProgramDiagnosis(
            program_id=program.program_id,
            representation_id=evidence.representation_id,
            evidence_id=evidence.evidence_id,
            cycle_index=evidence.cycle_index,
            disposition=StrategyDisposition.CHANGE_REPRESENTATION,
            failure_kind=ProgramFailureKind.PROPOSAL_FAILURE,
            reasons=(
                "the representation produced varied behaviors but no useful effect",
                "change the objective and experiment before spending another batch",
            ),
            failed_assumptions=(
                "the searched causal mechanisms target a binding bottleneck",
            ),
            required_dimensions=(
                RepresentationDimension.OBJECTIVE,
                RepresentationDimension.EXPERIMENT,
            ),
            representation_revision_count=representation_revision_count,
            assessor_ref=assessor_ref,
        )

    return ResearchProgramDiagnosis(
        program_id=program.program_id,
        representation_id=evidence.representation_id,
        evidence_id=evidence.evidence_id,
        cycle_index=evidence.cycle_index,
        disposition=StrategyDisposition.CHANGE_REPRESENTATION,
        failure_kind=failure_kind,
        reasons=reasons,
        failed_assumptions=(
            "the current candidate language spans mechanisms capable of progress",
        ),
        required_dimensions=dimensions,
        representation_revision_count=representation_revision_count,
        assessor_ref=assessor_ref,
    )


@dataclass(frozen=True)
class RepresentationChangeProposal:
    diagnosis_id: str
    prior_program_id: str
    revised_program: ResearchProgramContract
    preserved_invariants: Tuple[str, ...]
    removed_constraints: Tuple[str, ...]
    new_affordances: Tuple[str, ...]
    migration_steps: Tuple[str, ...]
    falsification_tests: Tuple[str, ...]
    proposer_ref: str

    def __post_init__(self) -> None:
        sequences = (
            self.preserved_invariants,
            self.removed_constraints,
            self.new_affordances,
            self.migration_steps,
            self.falsification_tests,
        )
        if not all((self.diagnosis_id, self.prior_program_id, self.proposer_ref)):
            raise ValueError("representation-change identity is incomplete")
        if not all(sequences):
            raise ValueError("representation change requires a complete migration")
        if self.revised_program.parent_program_id != self.prior_program_id:
            raise ValueError("revised program does not supersede the diagnosed one")
        if (
            self.revised_program.representation.parent_representation_id
            is None
        ):
            raise ValueError("representation change must name its parent")

    @property
    def proposal_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "strategy_version": RESEARCH_STRATEGY_VERSION,
            "diagnosis_id": self.diagnosis_id,
            "prior_program_id": self.prior_program_id,
            "revised_program": self.revised_program.as_dict(),
            "preserved_invariants": list(self.preserved_invariants),
            "removed_constraints": list(self.removed_constraints),
            "new_affordances": list(self.new_affordances),
            "migration_steps": list(self.migration_steps),
            "falsification_tests": list(self.falsification_tests),
            "proposer_ref": self.proposer_ref,
        }
        if include_id:
            value["proposal_id"] = self.proposal_id
        return value


class RepresentationStrategist(Protocol):
    name: str

    def propose_change(
        self,
        program: ResearchProgramContract,
        diagnosis: ResearchProgramDiagnosis,
    ) -> RepresentationChangeProposal:
        ...


def _assert_identity(
    value: Mapping[str, Any],
    field: str,
    observed: str,
) -> None:
    supplied = value.get(field)
    if supplied is not None and str(supplied) != observed:
        raise ValueError("%s identity mismatch" % field)


def representation_from_dict(value: Mapping[str, Any]) -> RepresentationContract:
    representation = RepresentationContract(
        domain_id=str(value["domain_id"]),
        name=str(value["name"]),
        research_object_type=str(value["research_object_type"]),
        observation_schema=tuple(str(item) for item in value["observation_schema"]),
        state_schema=tuple(str(item) for item in value["state_schema"]),
        action_schema=tuple(str(item) for item in value["action_schema"]),
        hypothesis_language=tuple(
            str(item) for item in value["hypothesis_language"]
        ),
        composition_operators=tuple(
            str(item) for item in value["composition_operators"]
        ),
        objective_schema=tuple(str(item) for item in value["objective_schema"]),
        experimental_unit=str(value["experimental_unit"]),
        compiler_ref=str(value["compiler_ref"]),
        evaluator_ref=str(value["evaluator_ref"]),
        parent_representation_id=(
            None
            if value.get("parent_representation_id") is None
            else str(value["parent_representation_id"])
        ),
        changed_dimensions=tuple(
            RepresentationDimension(item)
            for item in value.get("changed_dimensions", ())
        ),
    )
    _assert_identity(value, "representation_id", representation.representation_id)
    return representation


def research_program_from_dict(value: Mapping[str, Any]) -> ResearchProgramContract:
    program = ResearchProgramContract(
        node_id=str(value["node_id"]),
        question=str(value["question"]),
        representation=representation_from_dict(value["representation"]),
        hypothesis_classes=tuple(
            str(item) for item in value["hypothesis_classes"]
        ),
        assumptions=tuple(str(item) for item in value["assumptions"]),
        success_criteria=tuple(str(item) for item in value["success_criteria"]),
        kill_criteria=tuple(str(item) for item in value["kill_criteria"]),
        candidate_budget=int(value["candidate_budget"]),
        strategy_ref=str(value["strategy_ref"]),
        parent_program_id=(
            None
            if value.get("parent_program_id") is None
            else str(value["parent_program_id"])
        ),
    )
    _assert_identity(value, "program_id", program.program_id)
    return program


def program_evidence_from_dict(value: Mapping[str, Any]) -> ResearchProgramEvidence:
    evidence = ResearchProgramEvidence(
        program_id=str(value["program_id"]),
        representation_id=str(value["representation_id"]),
        cycle_index=int(value["cycle_index"]),
        channel_evaluations={
            str(name): int(count)
            for name, count in value["channel_evaluations"].items()
        },
        proposed_count=int(value["proposed_count"]),
        compiled_count=int(value["compiled_count"]),
        evaluated_count=int(value["evaluated_count"]),
        behaviorally_distinct_count=int(value["behaviorally_distinct_count"]),
        semantically_novel_count=int(value["semantically_novel_count"]),
        confidence_supported_improvement_count=int(
            value["confidence_supported_improvement_count"]
        ),
        research_eligible_count=int(value["research_eligible_count"]),
        mechanism_class_counts={
            str(name): int(count)
            for name, count in value["mechanism_class_counts"].items()
        },
        failure_counts={
            str(name): int(count)
            for name, count in value["failure_counts"].items()
        },
        best_effect=float(value["best_effect"]),
        best_lower_confidence_bound=float(
            value["best_lower_confidence_bound"]
        ),
        evidence_ids=tuple(str(item) for item in value["evidence_ids"]),
    )
    _assert_identity(value, "evidence_id", evidence.evidence_id)
    return evidence


def diagnosis_from_dict(value: Mapping[str, Any]) -> ResearchProgramDiagnosis:
    diagnosis = ResearchProgramDiagnosis(
        program_id=str(value["program_id"]),
        representation_id=str(value["representation_id"]),
        evidence_id=str(value["evidence_id"]),
        cycle_index=int(value["cycle_index"]),
        disposition=StrategyDisposition(value["disposition"]),
        failure_kind=ProgramFailureKind(value["failure_kind"]),
        reasons=tuple(str(item) for item in value["reasons"]),
        failed_assumptions=tuple(
            str(item) for item in value.get("failed_assumptions", ())
        ),
        required_dimensions=tuple(
            RepresentationDimension(item)
            for item in value.get("required_dimensions", ())
        ),
        representation_revision_count=int(
            value.get("representation_revision_count", 0)
        ),
        assessor_ref=str(value["assessor_ref"]),
    )
    _assert_identity(value, "diagnosis_id", diagnosis.diagnosis_id)
    return diagnosis


def representation_change_from_dict(
    value: Mapping[str, Any],
) -> RepresentationChangeProposal:
    proposal = RepresentationChangeProposal(
        diagnosis_id=str(value["diagnosis_id"]),
        prior_program_id=str(value["prior_program_id"]),
        revised_program=research_program_from_dict(value["revised_program"]),
        preserved_invariants=tuple(
            str(item) for item in value["preserved_invariants"]
        ),
        removed_constraints=tuple(
            str(item) for item in value["removed_constraints"]
        ),
        new_affordances=tuple(str(item) for item in value["new_affordances"]),
        migration_steps=tuple(str(item) for item in value["migration_steps"]),
        falsification_tests=tuple(
            str(item) for item in value["falsification_tests"]
        ),
        proposer_ref=str(value["proposer_ref"]),
    )
    _assert_identity(value, "proposal_id", proposal.proposal_id)
    return proposal
