from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass, replace
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional, Protocol, Tuple, Union

from scientist.core.artifacts import canonical_json, content_digest
from scientist.kernel.contracts import ProblemCharter
from scientist.program.contracts import (
    ChildCampaignOutcome,
    ChildCampaignProgress,
    ChildCampaignResult,
    HighLevelGoal,
    PortfolioPolicy,
    ResearchNode,
)
from scientist.program.literature import (
    ClaimLevel,
    PriorArtAssessment,
)
from scientist.program.manager import ResearchProgramManager
from scientist.program.ledger import ProgramEventKind


RUNTIME_VERSION = "autonomous-program-runtime-v1"


class RuntimeState(str, Enum):
    RUNNING = "running"
    GOAL_ACHIEVED = "goal_achieved"
    BUDGET_EXHAUSTED = "budget_exhausted"
    SAFETY_BLOCKED = "safety_blocked"
    EXTERNAL_BLOCKED = "external_blocked"
    USER_STOPPED = "user_stopped"


@dataclass(frozen=True)
class CampaignExecution:
    result: ChildCampaignResult
    scope_assessment_id: str
    requested_claim_level: ClaimLevel = ClaimLevel.REPLICATED_EFFECT
    frontier_comparison_evidence_ids: Tuple[str, ...] = ()
    external_confirmation_evidence_ids: Tuple[str, ...] = ()
    broad_impact_evidence_ids: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.scope_assessment_id:
            raise ValueError(
                "campaign execution requires a scoped prior-art assessment"
            )
        if (
            self.result.outcome == ChildCampaignOutcome.CONFIRMED
            and not self.result.claim_id
        ):
            raise ValueError(
                "confirmed campaign execution requires a claim ID"
            )


@dataclass(frozen=True)
class CampaignProgressExecution:
    progress: ChildCampaignProgress
    scope_assessment_id: str

    def __post_init__(self) -> None:
        if not self.scope_assessment_id:
            raise ValueError(
                "campaign progress requires a scoped prior-art assessment"
            )


@dataclass(frozen=True)
class RuntimeTermination:
    state: RuntimeState
    reason: str
    cycle: int

    def __post_init__(self) -> None:
        if self.state == RuntimeState.RUNNING:
            raise ValueError("running is not a termination state")
        if not self.reason:
            raise ValueError("termination reason must not be empty")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "state": self.state.value,
            "reason": self.reason,
            "cycle": self.cycle,
        }


class ChildCampaignDriver(Protocol):
    name: str
    driver_version: str

    def charter_for(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
    ) -> ProblemCharter:
        ...

    def run(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
        scope_assessment: PriorArtAssessment,
    ) -> Union[CampaignExecution, CampaignProgressExecution]:
        ...


class ProgressiveChildCampaignDriver(Protocol):
    """Optional driver extension that receives durable attempt history."""

    def run_next(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
        scope_assessment: PriorArtAssessment,
        history: Tuple[ChildCampaignProgress, ...],
    ) -> Union[CampaignExecution, CampaignProgressExecution]:
        ...


class PriorArtReviewer(Protocol):
    name: str
    reviewer_version: str

    def review_scope(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        charter: ProblemCharter,
    ) -> PriorArtAssessment:
        ...

    def review(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
        execution: CampaignExecution,
    ) -> PriorArtAssessment:
        ...


class SafetyPolicy(Protocol):
    name: str
    policy_version: str

    def allow(
        self,
        goal: HighLevelGoal,
        node: ResearchNode,
    ) -> Tuple[bool, str]:
        ...


class TerminalEvaluator(Protocol):
    name: str
    evaluator_version: str

    def evaluate(self, manager: ResearchProgramManager) -> bool:
        ...


class ContinuationPlanner(Protocol):
    name: str
    planner_version: str

    def revise(self, manager: ResearchProgramManager) -> bool:
        ...


class ProgramRuntime:
    """Durable scheduler that treats child findings as continuation events."""

    def __init__(
        self,
        manager: ResearchProgramManager,
        campaign_driver: ChildCampaignDriver,
        prior_art_reviewer: PriorArtReviewer,
        checkpoint_path: Path,
        safety_policy: Optional[SafetyPolicy] = None,
        terminal_evaluator: Optional[TerminalEvaluator] = None,
        continuation_planner: Optional[ContinuationPlanner] = None,
        cycle: int = 0,
        state: RuntimeState = RuntimeState.RUNNING,
        termination: Optional[RuntimeTermination] = None,
    ) -> None:
        self.manager = manager
        self.campaign_driver = campaign_driver
        self.prior_art_reviewer = prior_art_reviewer
        self.checkpoint_path = Path(checkpoint_path)
        self.safety_policy = safety_policy
        self.terminal_evaluator = terminal_evaluator
        self.continuation_planner = continuation_planner
        self.cycle = cycle
        self.state = state
        self.termination = termination
        if (
            self.state == RuntimeState.RUNNING
            and self.termination is not None
        ):
            raise ValueError("running runtime cannot have a termination")
        if (
            self.state != RuntimeState.RUNNING
            and self.termination is None
        ):
            raise ValueError("terminated runtime requires a termination")
        self.save_checkpoint()

    @property
    def is_terminal(self) -> bool:
        return self.state != RuntimeState.RUNNING

    def _checkpoint_value(self) -> Dict[str, Any]:
        payload = {
            "runtime_version": RUNTIME_VERSION,
            "state": self.state.value,
            "cycle": self.cycle,
            "termination": (
                None
                if self.termination is None
                else self.termination.as_dict()
            ),
            "manager": self.manager.as_dict(),
            "campaign_driver": {
                "name": self.campaign_driver.name,
                "version": self.campaign_driver.driver_version,
            },
            "prior_art_reviewer": {
                "name": self.prior_art_reviewer.name,
                "version": self.prior_art_reviewer.reviewer_version,
            },
        }
        payload["checkpoint_id"] = content_digest(payload)
        return payload

    def save_checkpoint(self) -> Path:
        value = self._checkpoint_value()
        destination = self.checkpoint_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=destination.name + ".",
            suffix=".tmp",
            dir=str(destination.parent),
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(canonical_json(value) + b"\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, destination)
        finally:
            temporary_path = Path(temporary_name)
            if temporary_path.exists():
                temporary_path.unlink()
        return destination

    @classmethod
    def from_checkpoint(
        cls,
        checkpoint_path: Path,
        campaign_driver: ChildCampaignDriver,
        prior_art_reviewer: PriorArtReviewer,
        safety_policy: Optional[SafetyPolicy] = None,
        terminal_evaluator: Optional[TerminalEvaluator] = None,
        continuation_planner: Optional[ContinuationPlanner] = None,
        allow_component_upgrade: bool = False,
        component_upgrade_reason: str = "",
    ) -> "ProgramRuntime":
        path = Path(checkpoint_path)
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        supplied_id = value.pop("checkpoint_id")
        if supplied_id != content_digest(value):
            raise ValueError("runtime checkpoint digest mismatch")
        if value.get("runtime_version") != RUNTIME_VERSION:
            raise ValueError("unsupported runtime checkpoint version")
        expected_driver = value["campaign_driver"]
        driver_changed = (
            expected_driver["name"] != campaign_driver.name
            or expected_driver["version"]
            != campaign_driver.driver_version
        )
        expected_reviewer = value["prior_art_reviewer"]
        reviewer_changed = (
            expected_reviewer["name"] != prior_art_reviewer.name
            or expected_reviewer["version"]
            != prior_art_reviewer.reviewer_version
        )
        if (driver_changed or reviewer_changed) and not (
            allow_component_upgrade
            and component_upgrade_reason
        ):
            raise ValueError(
                "runtime components differ from checkpoint; an explicit "
                "audited upgrade reason is required"
            )
        termination_value = value.get("termination")
        termination = (
            None
            if termination_value is None
            else RuntimeTermination(
                state=RuntimeState(termination_value["state"]),
                reason=str(termination_value["reason"]),
                cycle=int(termination_value["cycle"]),
            )
        )
        runtime = cls(
            manager=ResearchProgramManager.from_dict(value["manager"]),
            campaign_driver=campaign_driver,
            prior_art_reviewer=prior_art_reviewer,
            checkpoint_path=path,
            safety_policy=safety_policy,
            terminal_evaluator=terminal_evaluator,
            continuation_planner=continuation_planner,
            cycle=int(value["cycle"]),
            state=RuntimeState(value["state"]),
            termination=termination,
        )
        if driver_changed or reviewer_changed:
            runtime.manager.ledger.append(
                ProgramEventKind.RUNTIME_COMPONENT_UPGRADED,
                {
                    "reason": component_upgrade_reason,
                    "previous_campaign_driver": expected_driver,
                    "new_campaign_driver": {
                        "name": campaign_driver.name,
                        "version": campaign_driver.driver_version,
                    },
                    "previous_prior_art_reviewer": expected_reviewer,
                    "new_prior_art_reviewer": {
                        "name": prior_art_reviewer.name,
                        "version": (
                            prior_art_reviewer.reviewer_version
                        ),
                    },
                    "runtime_cycle": runtime.cycle,
                },
                actor_ref="program-runtime-component-upgrade",
            )
            runtime.save_checkpoint()
        return runtime

    def _terminate(self, state: RuntimeState, reason: str) -> RuntimeState:
        if state == RuntimeState.RUNNING:
            raise ValueError("cannot terminate into running state")
        self.state = state
        self.termination = RuntimeTermination(
            state=state,
            reason=reason,
            cycle=self.cycle,
        )
        self.save_checkpoint()
        return self.state

    def request_stop(self, reason: str) -> RuntimeState:
        return self._terminate(RuntimeState.USER_STOPPED, reason)

    def _next_active_node(self) -> Optional[ResearchNode]:
        active = self.manager.graph.active()
        if active:
            return active[0]
        frontier = self.manager.graph.frontier()
        if not frontier:
            return None
        try:
            decision = self.manager.select_portfolio(
                PortfolioPolicy(
                    max_nodes=1,
                    compute_budget=self.manager.compute_remaining,
                    minimum_distinct_decompositions=1,
                )
            )
        except ValueError as error:
            if self.manager.compute_remaining <= 0.0:
                self._terminate(
                    RuntimeState.BUDGET_EXHAUSTED,
                    "the declared high-level compute budget is exhausted",
                )
                return None
            self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "ready frontier cannot be scheduled: %s" % error,
            )
            return None
        self.manager.activate_portfolio(decision)
        self.save_checkpoint()
        return self.manager.graph.active()[0]

    def _close_confirmed_claim(
        self,
        node: ResearchNode,
        execution: CampaignExecution,
    ) -> Optional[ChildCampaignResult]:
        try:
            assessment = self.prior_art_reviewer.review(
                self.manager.goal,
                node,
                execution,
            )
        except Exception as error:
            self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "prior-art review failed: %s" % error,
            )
            return None
        if assessment.signature.subject_id != node.node_id:
            self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "prior-art review returned the wrong claim subject",
            )
            return None
        self.manager.register_prior_art_assessment(assessment)
        authorization = self.manager.authorize_claim(
            assessment.assessment_id,
            execution.result.claim_id or "",
            execution.requested_claim_level,
            execution.frontier_comparison_evidence_ids,
            execution.external_confirmation_evidence_ids,
            execution.broad_impact_evidence_ids,
        )
        if (
            not authorization.authorized
            and execution.requested_claim_level
            > ClaimLevel.REPLICATED_EFFECT
        ):
            authorization = self.manager.authorize_claim(
                assessment.assessment_id,
                execution.result.claim_id or "",
                ClaimLevel.REPLICATED_EFFECT,
            )
        if not authorization.authorized:
            self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "prior-art closure failed: %s"
                % "; ".join(authorization.reasons),
            )
            return None
        return replace(
            execution.result,
            claim_authorization_id=authorization.authorization_id,
        )

    def _scope_assessment(
        self,
        node: ResearchNode,
        charter: ProblemCharter,
    ) -> Optional[PriorArtAssessment]:
        existing = tuple(
            assessment
            for assessment in self.manager.prior_art_assessments.values()
            if (
                assessment.signature.subject_id == node.node_id
                and assessment.closure_passed
            )
        )
        if existing:
            return existing[-1]
        try:
            assessment = self.prior_art_reviewer.review_scope(
                self.manager.goal,
                node,
                charter,
            )
        except Exception as error:
            self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "pre-campaign prior-art review failed: %s" % error,
            )
            return None
        if assessment.signature.subject_id != node.node_id:
            self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "pre-campaign review returned the wrong claim subject",
            )
            return None
        self.manager.register_prior_art_assessment(assessment)
        if not assessment.closure_passed:
            self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "pre-campaign prior-art closure failed: %s"
                % "; ".join(assessment.closure_failures),
            )
            return None
        self.save_checkpoint()
        return assessment

    def step(self) -> RuntimeState:
        if self.is_terminal:
            return self.state
        if self.manager.resolution is not None:
            if self.manager.resolution.resolved:
                return self._terminate(
                    RuntimeState.GOAL_ACHIEVED,
                    "the terminal integration gate resolved the parent goal",
                )
        if self.manager.compute_remaining <= 0.0:
            return self._terminate(
                RuntimeState.BUDGET_EXHAUSTED,
                "the declared high-level compute budget is exhausted",
            )

        node = self._next_active_node()
        if self.is_terminal:
            return self.state
        if node is None:
            if self.terminal_evaluator is not None:
                try:
                    resolved = self.terminal_evaluator.evaluate(
                        self.manager
                    )
                except Exception as error:
                    return self._terminate(
                        RuntimeState.EXTERNAL_BLOCKED,
                        "terminal evaluation failed: %s" % error,
                    )
                self.save_checkpoint()
                if resolved:
                    return self._terminate(
                        RuntimeState.GOAL_ACHIEVED,
                        "the terminal evaluator resolved the parent goal",
                    )
            if (
                self.continuation_planner is not None
            ):
                try:
                    revised = self.continuation_planner.revise(
                        self.manager
                    )
                except Exception as error:
                    return self._terminate(
                        RuntimeState.EXTERNAL_BLOCKED,
                        "continuation planning failed: %s" % error,
                    )
                if revised:
                    self.save_checkpoint()
                    return self.state
            return self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "the goal is unresolved and no executable frontier remains",
            )

        if self.safety_policy is not None:
            allowed, reason = self.safety_policy.allow(
                self.manager.goal,
                node,
            )
            if not allowed:
                return self._terminate(
                    RuntimeState.SAFETY_BLOCKED,
                    reason,
                )

        charter = self.manager.child_charters.get(node.node_id)
        if charter is None:
            try:
                charter = self.campaign_driver.charter_for(
                    self.manager.goal,
                    node,
                )
            except Exception as error:
                return self._terminate(
                    RuntimeState.EXTERNAL_BLOCKED,
                    "child charter construction failed: %s" % error,
                )
            self.manager.register_child_charter(node.node_id, charter)
            self.save_checkpoint()

        scope_assessment = self._scope_assessment(node, charter)
        if scope_assessment is None:
            return self.state
        try:
            run_next = getattr(
                self.campaign_driver,
                "run_next",
                None,
            )
            if callable(run_next):
                execution = run_next(
                    self.manager.goal,
                    node,
                    charter,
                    scope_assessment,
                    self.manager.campaign_progress.get(
                        node.node_id,
                        (),
                    ),
                )
            else:
                execution = self.campaign_driver.run(
                    self.manager.goal,
                    node,
                    charter,
                    scope_assessment,
                )
        except Exception as error:
            return self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "child campaign failed: %s" % error,
            )
        if not isinstance(
            execution,
            (CampaignExecution, CampaignProgressExecution),
        ):
            return self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "child campaign returned an unsupported update",
            )
        if (
            execution.scope_assessment_id
            != scope_assessment.assessment_id
        ):
            return self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "child campaign was not bound to its scoped prior art",
            )
        if isinstance(execution, CampaignProgressExecution):
            progress = execution.progress
            if progress.node_id != node.node_id:
                return self._terminate(
                    RuntimeState.EXTERNAL_BLOCKED,
                    "campaign progress belongs to another node",
                )
            if progress.child_charter_id != charter.charter_id:
                return self._terminate(
                    RuntimeState.EXTERNAL_BLOCKED,
                    "campaign progress belongs to another charter",
                )
            try:
                self.manager.record_campaign_progress(progress)
            except Exception as error:
                return self._terminate(
                    RuntimeState.EXTERNAL_BLOCKED,
                    "campaign progress could not be recorded: %s"
                    % error,
                )
            self.cycle += 1
            self.save_checkpoint()
            return self.state
        result = execution.result
        if result.node_id != node.node_id:
            return self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "campaign driver returned a result for another node",
            )
        if result.child_charter_id != charter.charter_id:
            return self._terminate(
                RuntimeState.EXTERNAL_BLOCKED,
                "campaign driver returned a result for another charter",
            )
        if result.outcome == ChildCampaignOutcome.CONFIRMED:
            closed_result = self._close_confirmed_claim(node, execution)
            if closed_result is None:
                return self.state
            result = closed_result

        self.manager.ingest_child_result(result)
        self.cycle += 1
        self.save_checkpoint()
        return self.state

    def run_until_terminal(
        self,
        max_cycles: Optional[int] = None,
    ) -> RuntimeState:
        if max_cycles is not None and max_cycles <= 0:
            raise ValueError("max_cycles must be positive when supplied")
        completed = 0
        while not self.is_terminal:
            if max_cycles is not None and completed >= max_cycles:
                self.save_checkpoint()
                break
            before = self.cycle
            self.step()
            if self.cycle > before:
                completed += 1
            elif not self.is_terminal and max_cycles is not None:
                completed += 1
        return self.state
