from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from scientist.core.artifacts import ArtifactStore
from scientist.kernel.contracts import (
    MetricDirection,
    MetricSpec,
    ProblemCharter,
)
from scientist.program.contracts import (
    ChildCampaignOutcome,
    ChildCampaignProgress,
    ChildCampaignResult,
    Decomposition,
    HighLevelGoal,
    NodeAssessment,
    NodeKind,
    NodeStatus,
    PortfolioDecision,
    PortfolioPolicy,
    ProgramResolution,
    ResearchNode,
)
from scientist.program.graph import ResearchProgramGraph
from scientist.program.ledger import ResearchProgramLedger
from scientist.program.literature import (
    ClaimAuthorization,
    ClaimClassification,
    ClaimLevel,
    ClaimSignature,
    LiteratureQuery,
    LiteratureTrigger,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)
from scientist.program.strategic_governance import (
    portfolio_authorization_from_dict,
)


def _metric(value: Mapping[str, Any]) -> MetricSpec:
    return MetricSpec(
        name=str(value["name"]),
        direction=MetricDirection(value["direction"]),
        unit=str(value["unit"]),
        aggregation=str(value["aggregation"]),
        primary=bool(value.get("primary", False)),
        target=value.get("target"),
    )


def _goal(value: Mapping[str, Any]) -> HighLevelGoal:
    goal = HighLevelGoal(
        name=str(value["name"]),
        outcome=str(value["outcome"]),
        scope=tuple(value["scope"]),
        anti_scope=tuple(value["anti_scope"]),
        terminal_metrics=tuple(
            _metric(metric) for metric in value["terminal_metrics"]
        ),
        success_definition=str(value["success_definition"]),
        failure_conditions=tuple(value["failure_conditions"]),
        integration_requirements=tuple(
            value["integration_requirements"]
        ),
        total_compute_budget=float(value["total_compute_budget"]),
        max_parallel_campaigns=int(value["max_parallel_campaigns"]),
        risk_tier=str(value.get("risk_tier", "research_only")),
        human_owner=value.get("human_owner"),
    )
    if goal.goal_id != value.get("goal_id"):
        raise ValueError("restored goal digest mismatch")
    return goal


def _node(value: Mapping[str, Any]) -> ResearchNode:
    node = ResearchNode(
        goal_id=str(value["goal_id"]),
        title=str(value["title"]),
        question=str(value["question"]),
        kind=NodeKind(value["kind"]),
        rationale=str(value["rationale"]),
        acceptance_conditions=tuple(value["acceptance_conditions"]),
        falsification_conditions=tuple(
            value["falsification_conditions"]
        ),
        expected_artifact=str(value["expected_artifact"]),
        prerequisite_ids=tuple(value.get("prerequisite_ids", ())),
        estimated_compute=float(value.get("estimated_compute", 1.0)),
        critical=bool(value.get("critical", False)),
        alternative_group=value.get("alternative_group"),
        tags=tuple(value.get("tags", ())),
    )
    if node.node_id != value.get("node_id"):
        raise ValueError("restored research-node digest mismatch")
    return node


def _decomposition(value: Mapping[str, Any]) -> Decomposition:
    decomposition = Decomposition(
        goal_id=str(value["goal_id"]),
        name=str(value["name"]),
        causal_model=str(value["causal_model"]),
        assumptions=tuple(value["assumptions"]),
        node_ids=tuple(value["node_ids"]),
        distinguishing_predictions=tuple(
            value["distinguishing_predictions"]
        ),
        decomposer_ref=str(value["decomposer_ref"]),
    )
    if decomposition.decomposition_id != value.get("decomposition_id"):
        raise ValueError("restored decomposition digest mismatch")
    return decomposition


def _assessment(value: Mapping[str, Any]) -> NodeAssessment:
    return NodeAssessment(
        node_id=str(value["node_id"]),
        goal_relevance=float(value["goal_relevance"]),
        bottleneck_probability=float(value["bottleneck_probability"]),
        tractability=float(value["tractability"]),
        expected_information_gain=float(
            value["expected_information_gain"]
        ),
        integration_leverage=float(value["integration_leverage"]),
        estimated_cost=float(value["estimated_cost"]),
        basis=tuple(value["basis"]),
        assessor_ref=str(value["assessor_ref"]),
    )


def _portfolio_decision(value: Mapping[str, Any]) -> PortfolioDecision:
    raw_policy = value["policy"]
    decision = PortfolioDecision(
        selected_node_ids=tuple(value["selected_node_ids"]),
        deferred_node_ids=tuple(value["deferred_node_ids"]),
        total_estimated_cost=float(value["total_estimated_cost"]),
        policy=PortfolioPolicy(
            max_nodes=int(raw_policy["max_nodes"]),
            compute_budget=float(raw_policy["compute_budget"]),
            minimum_distinct_decompositions=int(
                raw_policy["minimum_distinct_decompositions"]
            ),
        ),
        scores={
            str(node_id): float(score)
            for node_id, score in value["scores"].items()
        },
        rationale=str(value["rationale"]),
    )
    if decision.decision_id != value.get("decision_id"):
        raise ValueError("restored portfolio-decision digest mismatch")
    return decision


def _charter(value: Mapping[str, Any]) -> ProblemCharter:
    charter = ProblemCharter(
        name=str(value["name"]),
        statement=str(value["statement"]),
        domain_id=str(value["domain_id"]),
        scope=tuple(value["scope"]),
        anti_scope=tuple(value["anti_scope"]),
        metrics=tuple(_metric(metric) for metric in value["metrics"]),
        success_definition=str(value["success_definition"]),
        falsification_conditions=tuple(
            value["falsification_conditions"]
        ),
        risk_tier=str(value.get("risk_tier", "research_only")),
        human_owner=value.get("human_owner"),
    )
    if charter.charter_id != value.get("charter_id"):
        raise ValueError("restored child-charter digest mismatch")
    return charter


def _child_result(value: Mapping[str, Any]) -> ChildCampaignResult:
    result = ChildCampaignResult(
        node_id=str(value["node_id"]),
        child_charter_id=str(value["child_charter_id"]),
        outcome=ChildCampaignOutcome(value["outcome"]),
        evidence_ids=tuple(value["evidence_ids"]),
        summary=str(value["summary"]),
        implications=tuple(value["implications"]),
        compute_spent=float(value["compute_spent"]),
        claim_id=value.get("claim_id"),
        claim_authorization_id=value.get("claim_authorization_id"),
    )
    if result.result_id != value.get("result_id"):
        raise ValueError("restored child-result digest mismatch")
    return result


def _campaign_progress(
    value: Mapping[str, Any],
) -> ChildCampaignProgress:
    progress = ChildCampaignProgress(
        node_id=str(value["node_id"]),
        child_charter_id=str(value["child_charter_id"]),
        stage=str(value["stage"]),
        hypothesis_id=str(value["hypothesis_id"]),
        evidence_ids=tuple(value["evidence_ids"]),
        summary=str(value["summary"]),
        implications=tuple(value["implications"]),
        compute_spent=float(value["compute_spent"]),
        next_action=str(value["next_action"]),
    )
    if progress.progress_id != value.get("progress_id"):
        raise ValueError("restored campaign-progress digest mismatch")
    return progress


def _signature(value: Mapping[str, Any]) -> ClaimSignature:
    signature = ClaimSignature(
        subject_id=str(value["subject_id"]),
        statement=str(value["statement"]),
        problem=str(value["problem"]),
        phenomenon=str(value["phenomenon"]),
        intervention=str(value["intervention"]),
        mechanism=str(value["mechanism"]),
        evaluation=str(value["evaluation"]),
    )
    if signature.signature_id != value.get("signature_id"):
        raise ValueError("restored claim-signature digest mismatch")
    return signature


def _prior_art(value: Mapping[str, Any]) -> PriorArtAssessment:
    assessment = PriorArtAssessment(
        signature=_signature(value["signature"]),
        trigger=LiteratureTrigger(value["trigger"]),
        queries=tuple(
            LiteratureQuery(
                query=str(query["query"]),
                facet=SearchFacet(query["facet"]),
                provider=str(query["provider"]),
            )
            for query in value["queries"]
        ),
        closest_works=tuple(
            PriorWork(
                work_id=str(work["work_id"]),
                title=str(work["title"]),
                year=int(work["year"]),
                locator=str(work["locator"]),
                relation=PriorArtRelation(work["relation"]),
                matched_components=tuple(work["matched_components"]),
                executable=bool(work.get("executable", False)),
                abstract=str(work.get("abstract", "")),
            )
            for work in value["closest_works"]
        ),
        classification=ClaimClassification(value["classification"]),
        rationale=str(value["rationale"]),
        novel_delta=tuple(value["novel_delta"]),
        citation_snowball_complete=bool(
            value["citation_snowball_complete"]
        ),
        searched_at=str(value["searched_at"]),
        reviewer_ref=str(value["reviewer_ref"]),
        executable_incumbent_id=value.get("executable_incumbent_id"),
    )
    if assessment.assessment_id != value.get("assessment_id"):
        raise ValueError("restored prior-art assessment digest mismatch")
    return assessment


def _authorization(value: Mapping[str, Any]) -> ClaimAuthorization:
    authorization = ClaimAuthorization(
        subject_id=str(value["subject_id"]),
        claim_id=str(value["claim_id"]),
        assessment_id=str(value["assessment_id"]),
        requested_level=ClaimLevel[
            str(value["requested_level"]).upper()
        ],
        authorized=bool(value["authorized"]),
        reasons=tuple(value["reasons"]),
        frontier_comparison_evidence_ids=tuple(
            value.get("frontier_comparison_evidence_ids", ())
        ),
        external_confirmation_evidence_ids=tuple(
            value.get("external_confirmation_evidence_ids", ())
        ),
        broad_impact_evidence_ids=tuple(
            value.get("broad_impact_evidence_ids", ())
        ),
    )
    if authorization.authorization_id != value.get("authorization_id"):
        raise ValueError("restored claim-authorization digest mismatch")
    return authorization


def _resolution(value: Optional[Mapping[str, Any]]) -> Optional[ProgramResolution]:
    if value is None:
        return None
    resolution = ProgramResolution(
        goal_id=str(value["goal_id"]),
        resolved=bool(value["resolved"]),
        integration_gate_contract_id=str(
            value["integration_gate_contract_id"]
        ),
        integration_gate_decision_id=str(
            value["integration_gate_decision_id"]
        ),
        evidence_ids=tuple(value["evidence_ids"]),
        satisfied_requirements=tuple(value["satisfied_requirements"]),
        unresolved_critical_node_ids=tuple(
            value["unresolved_critical_node_ids"]
        ),
        waived_critical_nodes=dict(value["waived_critical_nodes"]),
        limitations=tuple(value["limitations"]),
        reasons=tuple(value.get("reasons", ())),
    )
    if resolution.resolution_id != value.get("resolution_id"):
        raise ValueError("restored program-resolution digest mismatch")
    return resolution


def manager_from_dict(
    value: Mapping[str, object],
    artifact_store: Optional[ArtifactStore] = None,
):
    from scientist.program.manager import ResearchProgramManager

    payload: Dict[str, Any] = dict(value)
    goal = _goal(payload["goal"])
    manager = ResearchProgramManager(
        goal,
        artifact_store=artifact_store,
        manager_ref=str(
            payload.get("manager_ref", "research-program-manager-v1")
        ),
    )

    node_entries = payload["graph"]["nodes"]
    nodes = tuple(_node(entry["specification"]) for entry in node_entries)
    graph = ResearchProgramGraph(goal)
    graph.add_nodes(nodes)
    graph.restore_statuses(
        {
            node.node_id: NodeStatus(entry["status"])
            for node, entry in zip(nodes, node_entries)
        }
    )
    manager.graph = graph

    decompositions = tuple(
        _decomposition(item) for item in payload["decompositions"]
    )
    manager._decompositions = {
        item.decomposition_id: item for item in decompositions
    }
    manager._node_decompositions = {}
    for decomposition in decompositions:
        for node_id in decomposition.node_ids:
            manager._node_decompositions.setdefault(node_id, set()).add(
                decomposition.decomposition_id
            )
    manager._assessments = {
        item.node_id: item
        for item in (
            _assessment(raw) for raw in payload["assessments"]
        )
    }
    decisions = tuple(
        _portfolio_decision(raw)
        for raw in payload.get("portfolio_decisions", ())
    )
    manager._portfolio_decisions = {
        item.decision_id: item for item in decisions
    }
    authorizations = tuple(
        portfolio_authorization_from_dict(raw)
        for raw in payload.get("portfolio_authorizations", ())
    )
    manager._portfolio_authorizations = {
        item.authorization_id: item for item in authorizations
    }
    manager._child_charters = {
        str(node_id): _charter(raw)
        for node_id, raw in payload["child_charters"].items()
    }
    manager._child_results = {
        str(node_id): _child_result(raw)
        for node_id, raw in payload["child_results"].items()
    }
    manager._campaign_progress = {
        str(node_id): tuple(
            _campaign_progress(raw)
            for raw in progress_items
        )
        for node_id, progress_items in payload.get(
            "campaign_progress",
            {},
        ).items()
    }
    prior_art = tuple(
        _prior_art(raw)
        for raw in payload.get("prior_art_assessments", ())
    )
    manager._prior_art_assessments = {
        item.assessment_id: item for item in prior_art
    }
    authorizations = tuple(
        _authorization(raw)
        for raw in payload.get("claim_authorizations", ())
    )
    manager._claim_authorizations = {
        item.authorization_id: item for item in authorizations
    }
    manager._compute_spent = float(payload["compute_spent"])
    manager._resolution = _resolution(payload.get("resolution"))
    manager.ledger = ResearchProgramLedger.from_dict(
        payload["ledger"],
        artifact_store=artifact_store,
    )
    if manager.goal.goal_id != manager.ledger.goal_id:
        raise ValueError("restored manager and ledger goal mismatch")
    return manager
