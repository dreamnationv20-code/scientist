from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.program.contracts import HighLevelGoal, PortfolioDecision


STRATEGIC_GOVERNANCE_VERSION = "strategic-research-governance-v1"


def _nonempty_unique(values: Sequence[str], label: str, minimum: int = 1) -> None:
    if len(values) < minimum or not all(values):
        raise ValueError("%s requires at least %d non-empty values" % (label, minimum))
    if len(set(values)) != len(values):
        raise ValueError("%s must be unique" % label)


class DiscoveryMode(str, Enum):
    INCREMENTAL = "incremental"
    DE_NOVO = "de_novo"
    HYBRID = "hybrid"


class PriorArtDisposition(str, Enum):
    """Scientific outcome of an independent prior-art challenge."""

    ADVANCE = "advance"
    REPAIR = "repair"
    KILL = "kill"
    INFRASTRUCTURE_BLOCKED = "infrastructure_blocked"


@dataclass(frozen=True)
class RootRelevanceBridge:
    """A falsifiable causal path from one research node to the root metric."""

    goal_id: str
    node_id: str
    root_metric: str
    intervention: str
    mediator: str
    predicted_parent_effect: str
    predicted_root_effect: str
    causal_path: Tuple[str, ...]
    integration_test: str
    failure_implication: str
    author_ref: str

    def __post_init__(self) -> None:
        scalars = (
            self.goal_id,
            self.node_id,
            self.root_metric,
            self.intervention,
            self.mediator,
            self.predicted_parent_effect,
            self.predicted_root_effect,
            self.integration_test,
            self.failure_implication,
            self.author_ref,
        )
        if not all(scalars):
            raise ValueError("root-relevance bridge is incomplete")
        _nonempty_unique(self.causal_path, "root-relevance causal path", minimum=2)

    @property
    def bridge_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "governance_version": STRATEGIC_GOVERNANCE_VERSION,
            "goal_id": self.goal_id,
            "node_id": self.node_id,
            "root_metric": self.root_metric,
            "intervention": self.intervention,
            "mediator": self.mediator,
            "predicted_parent_effect": self.predicted_parent_effect,
            "predicted_root_effect": self.predicted_root_effect,
            "causal_path": list(self.causal_path),
            "integration_test": self.integration_test,
            "failure_implication": self.failure_implication,
            "author_ref": self.author_ref,
        }
        if include_id:
            value["bridge_id"] = self.bridge_id
        return value


@dataclass(frozen=True)
class ModeResearchCharter:
    """Operational definition of one hypothesis-generation channel."""

    mode: DiscoveryMode
    starting_material: Tuple[str, ...]
    allowed_transformations: Tuple[str, ...]
    forbidden_shortcuts: Tuple[str, ...]
    required_output: Tuple[str, ...]
    falsification_condition: str
    budget_fraction: float

    def __post_init__(self) -> None:
        for values, label in (
            (self.starting_material, "mode starting material"),
            (self.allowed_transformations, "mode transformations"),
            (self.forbidden_shortcuts, "mode forbidden shortcuts"),
            (self.required_output, "mode required output"),
        ):
            _nonempty_unique(values, label)
        if not self.falsification_condition:
            raise ValueError("mode charter requires a falsification condition")
        if not 0.0 < self.budget_fraction < 1.0:
            raise ValueError("mode budget fraction must be in (0, 1)")

    @property
    def operational_signature(self) -> str:
        return content_digest(
            {
                "starting_material": list(self.starting_material),
                "allowed_transformations": list(self.allowed_transformations),
                "forbidden_shortcuts": list(self.forbidden_shortcuts),
                "required_output": list(self.required_output),
                "falsification_condition": self.falsification_condition,
            }
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "mode": self.mode.value,
            "starting_material": list(self.starting_material),
            "allowed_transformations": list(self.allowed_transformations),
            "forbidden_shortcuts": list(self.forbidden_shortcuts),
            "required_output": list(self.required_output),
            "falsification_condition": self.falsification_condition,
            "budget_fraction": self.budget_fraction,
            "operational_signature": self.operational_signature,
        }


@dataclass(frozen=True)
class ThreeModeResearchCharter:
    node_id: str
    modes: Tuple[ModeResearchCharter, ...]
    shared_evaluator_ref: str
    shared_verifier_ref: str
    behavioral_family_classifier_ref: str
    evidence_partition_contract: str
    author_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.shared_evaluator_ref,
                self.shared_verifier_ref,
                self.behavioral_family_classifier_ref,
                self.evidence_partition_contract,
                self.author_ref,
            )
        ):
            raise ValueError("three-mode research charter is incomplete")
        if self.shared_evaluator_ref == self.shared_verifier_ref:
            raise ValueError("research evaluator and verifier must be independent")
        if {item.mode for item in self.modes} != set(DiscoveryMode):
            raise ValueError("research charter requires exactly the three discovery modes")
        if len(self.modes) != len(DiscoveryMode):
            raise ValueError("research charter contains duplicate discovery modes")
        if len({item.operational_signature for item in self.modes}) != len(self.modes):
            raise ValueError("discovery modes must differ operationally, not only by label")
        if abs(sum(item.budget_fraction for item in self.modes) - 1.0) > 1e-9:
            raise ValueError("discovery-mode budget fractions must sum to one")

    @property
    def charter_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "governance_version": STRATEGIC_GOVERNANCE_VERSION,
            "node_id": self.node_id,
            "modes": [item.as_dict() for item in self.modes],
            "shared_evaluator_ref": self.shared_evaluator_ref,
            "shared_verifier_ref": self.shared_verifier_ref,
            "behavioral_family_classifier_ref": self.behavioral_family_classifier_ref,
            "evidence_partition_contract": self.evidence_partition_contract,
            "author_ref": self.author_ref,
        }
        if include_id:
            value["charter_id"] = self.charter_id
        return value


@dataclass(frozen=True)
class PriorArtCoverageChallenge:
    node_id: str
    assessment_id: str
    assessment_reviewer_ref: str
    challenger_ref: str
    challenge_queries: Tuple[str, ...]
    coverage_tests: Tuple[str, ...]
    omitted_work_ids: Tuple[str, ...]
    strongest_uncaptured_relation: str
    disposition: PriorArtDisposition
    passed: bool
    reasons: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not all(
            (
                self.node_id,
                self.assessment_id,
                self.assessment_reviewer_ref,
                self.challenger_ref,
                self.strongest_uncaptured_relation,
            )
        ):
            raise ValueError("prior-art coverage challenge is incomplete")
        if self.assessment_reviewer_ref == self.challenger_ref:
            raise ValueError("prior-art challenge must be independent of the review")
        _nonempty_unique(self.challenge_queries, "coverage challenge queries", minimum=2)
        _nonempty_unique(self.coverage_tests, "coverage tests", minimum=2)
        if len(set(self.omitted_work_ids)) != len(self.omitted_work_ids):
            raise ValueError("omitted prior works must be unique")
        if self.passed != (self.disposition == PriorArtDisposition.ADVANCE):
            raise ValueError(
                "prior-art challenge passes exactly when the scientific "
                "disposition is advance"
            )
        if self.passed and (self.omitted_work_ids or self.reasons):
            raise ValueError("a passing coverage challenge cannot retain failures")
        if not self.passed and not self.reasons:
            raise ValueError("a failed coverage challenge requires reasons")

    @property
    def challenge_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "governance_version": STRATEGIC_GOVERNANCE_VERSION,
            "node_id": self.node_id,
            "assessment_id": self.assessment_id,
            "assessment_reviewer_ref": self.assessment_reviewer_ref,
            "challenger_ref": self.challenger_ref,
            "challenge_queries": list(self.challenge_queries),
            "coverage_tests": list(self.coverage_tests),
            "omitted_work_ids": list(self.omitted_work_ids),
            "strongest_uncaptured_relation": self.strongest_uncaptured_relation,
            "disposition": self.disposition.value,
            "passed": self.passed,
            "reasons": list(self.reasons),
        }
        if include_id:
            value["challenge_id"] = self.challenge_id
        return value


_REQUIRED_CONSTRUCT_CHECKS = {
    "answer_leakage_absent",
    "baseline_is_strong",
    "holdout_is_structural",
    "root_metric_is_measured",
    "shortcut_bypasses_rejected",
}


@dataclass(frozen=True)
class ConstructValidityAudit:
    node_id: str
    proposal_ref: str
    proposer_ref: str
    auditor_ref: str
    checks: Mapping[str, bool]
    leakage_probes: Tuple[str, ...]
    bypass_probes: Tuple[str, ...]
    limitations: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not all((self.node_id, self.proposal_ref, self.proposer_ref, self.auditor_ref)):
            raise ValueError("construct-validity audit is incomplete")
        if self.proposer_ref == self.auditor_ref:
            raise ValueError("construct audit must be independent of proposal design")
        missing = _REQUIRED_CONSTRUCT_CHECKS.difference(self.checks)
        if missing:
            raise ValueError(
                "construct audit omits checks: %s" % ", ".join(sorted(missing))
            )
        _nonempty_unique(self.leakage_probes, "construct leakage probes")
        _nonempty_unique(self.bypass_probes, "construct bypass probes")
        _nonempty_unique(self.limitations, "construct limitations")

    @property
    def passed(self) -> bool:
        return all(bool(value) for value in self.checks.values())

    @property
    def audit_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "governance_version": STRATEGIC_GOVERNANCE_VERSION,
            "node_id": self.node_id,
            "proposal_ref": self.proposal_ref,
            "proposer_ref": self.proposer_ref,
            "auditor_ref": self.auditor_ref,
            "checks": dict(sorted(self.checks.items())),
            "passed": self.passed,
            "leakage_probes": list(self.leakage_probes),
            "bypass_probes": list(self.bypass_probes),
            "limitations": list(self.limitations),
        }
        if include_id:
            value["audit_id"] = self.audit_id
        return value


@dataclass(frozen=True)
class ExecutableAssayPreflight:
    """Deterministic evidence that a frozen assay can actually be executed.

    A prose construct review is not enough to establish that named baselines
    support the same targets, that exact target versions are available, or
    that a matched-budget runner exists.  This receipt makes those conditions
    independently inspectable and fail-closed.
    """

    node_id: str
    proposal_ref: str
    auditor_ref: str
    target_ids: Tuple[str, ...]
    baseline_ids: Tuple[str, ...]
    candidate_target_support: Mapping[str, bool]
    baseline_target_support: Mapping[str, Mapping[str, bool]]
    target_versions_resolved: Mapping[str, bool]
    baseline_revision_refs: Mapping[str, str]
    runtime_requirements_available: Mapping[str, bool]
    matched_budget_runner_ready: bool
    evidence_refs: Tuple[str, ...]
    limitations: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not all((self.node_id, self.proposal_ref, self.auditor_ref)):
            raise ValueError("executable assay preflight is incomplete")
        _nonempty_unique(self.target_ids, "preflight targets")
        _nonempty_unique(self.baseline_ids, "preflight baselines")
        target_set = set(self.target_ids)
        baseline_set = set(self.baseline_ids)
        if set(self.candidate_target_support) != target_set:
            raise ValueError("candidate support must cover every frozen target")
        if set(self.target_versions_resolved) != target_set:
            raise ValueError("target-version checks must cover every frozen target")
        if set(self.baseline_target_support) != baseline_set:
            raise ValueError("baseline matrix must cover every named baseline")
        if set(self.baseline_revision_refs) != baseline_set:
            raise ValueError("every named baseline requires a pinned revision")
        for baseline_id, support in self.baseline_target_support.items():
            if set(support) != target_set:
                raise ValueError(
                    "baseline %s support must cover every frozen target"
                    % baseline_id
                )
            if not all(isinstance(value, bool) for value in support.values()):
                raise ValueError("baseline support values must be boolean")
        if not all(
            isinstance(value, bool)
            for value in self.candidate_target_support.values()
        ):
            raise ValueError("candidate support values must be boolean")
        if not all(
            isinstance(value, bool)
            for value in self.target_versions_resolved.values()
        ):
            raise ValueError("target-version values must be boolean")
        if not self.runtime_requirements_available or not all(
            isinstance(value, bool)
            for value in self.runtime_requirements_available.values()
        ):
            raise ValueError("runtime requirement checks must be non-empty booleans")
        if not all(self.baseline_revision_refs.values()):
            raise ValueError("baseline revision references must not be empty")
        _nonempty_unique(self.evidence_refs, "preflight evidence references")
        _nonempty_unique(self.limitations, "preflight limitations")

    @property
    def passed(self) -> bool:
        return (
            all(self.candidate_target_support.values())
            and all(self.target_versions_resolved.values())
            and all(self.runtime_requirements_available.values())
            and all(
                all(target_support.values())
                for target_support in self.baseline_target_support.values()
            )
            and self.matched_budget_runner_ready
        )

    @property
    def preflight_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "governance_version": STRATEGIC_GOVERNANCE_VERSION,
            "node_id": self.node_id,
            "proposal_ref": self.proposal_ref,
            "auditor_ref": self.auditor_ref,
            "target_ids": list(self.target_ids),
            "baseline_ids": list(self.baseline_ids),
            "candidate_target_support": dict(
                sorted(self.candidate_target_support.items())
            ),
            "baseline_target_support": {
                baseline_id: dict(sorted(support.items()))
                for baseline_id, support in sorted(
                    self.baseline_target_support.items()
                )
            },
            "target_versions_resolved": dict(
                sorted(self.target_versions_resolved.items())
            ),
            "baseline_revision_refs": dict(
                sorted(self.baseline_revision_refs.items())
            ),
            "runtime_requirements_available": dict(
                sorted(self.runtime_requirements_available.items())
            ),
            "matched_budget_runner_ready": self.matched_budget_runner_ready,
            "passed": self.passed,
            "evidence_refs": list(self.evidence_refs),
            "limitations": list(self.limitations),
        }
        if include_id:
            value["preflight_id"] = self.preflight_id
        return value


@dataclass(frozen=True)
class GraphStrategyReview:
    goal_id: str
    root_contract_id: str
    decomposition_ids: Tuple[str, ...]
    decomposer_refs: Tuple[str, ...]
    assessed_frontier_node_ids: Tuple[str, ...]
    selected_node_ids: Tuple[str, ...]
    rejected_easy_node_ids: Tuple[str, ...]
    distinguishing_evidence_plan: Tuple[str, ...]
    graph_revision_triggers: Tuple[str, ...]
    rationale: str
    strategist_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.goal_id,
                self.root_contract_id,
                self.rationale,
                self.strategist_ref,
            )
        ):
            raise ValueError("graph-strategy review is incomplete")
        _nonempty_unique(self.decomposition_ids, "competing decompositions", minimum=2)
        _nonempty_unique(self.decomposer_refs, "decomposer references")
        _nonempty_unique(self.assessed_frontier_node_ids, "assessed frontier")
        _nonempty_unique(self.selected_node_ids, "selected strategy nodes")
        _nonempty_unique(
            self.distinguishing_evidence_plan,
            "distinguishing evidence plan",
            minimum=2,
        )
        _nonempty_unique(self.graph_revision_triggers, "graph revision triggers", minimum=2)
        if not set(self.selected_node_ids).issubset(self.assessed_frontier_node_ids):
            raise ValueError("strategy selected a node outside the assessed frontier")
        if set(self.rejected_easy_node_ids).intersection(self.selected_node_ids):
            raise ValueError("strategy cannot both select and reject a node")
        if self.strategist_ref in set(self.decomposer_refs):
            raise ValueError("graph strategist must be independent of decomposition")

    @property
    def review_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "governance_version": STRATEGIC_GOVERNANCE_VERSION,
            "goal_id": self.goal_id,
            "root_contract_id": self.root_contract_id,
            "decomposition_ids": list(self.decomposition_ids),
            "decomposer_refs": list(self.decomposer_refs),
            "assessed_frontier_node_ids": list(self.assessed_frontier_node_ids),
            "selected_node_ids": list(self.selected_node_ids),
            "rejected_easy_node_ids": list(self.rejected_easy_node_ids),
            "distinguishing_evidence_plan": list(self.distinguishing_evidence_plan),
            "graph_revision_triggers": list(self.graph_revision_triggers),
            "rationale": self.rationale,
            "strategist_ref": self.strategist_ref,
        }
        if include_id:
            value["review_id"] = self.review_id
        return value


@dataclass(frozen=True)
class PortfolioGovernanceAuthorization:
    goal_id: str
    portfolio_decision_id: str
    selected_node_ids: Tuple[str, ...]
    graph_strategy_review_id: str
    root_bridge_ids: Tuple[str, ...]
    mode_charter_ids: Tuple[str, ...]
    prior_art_challenge_ids: Tuple[str, ...]
    construct_audit_ids: Tuple[str, ...]
    authorized: bool
    reasons: Tuple[str, ...]
    authority_ref: str
    executable_preflight_ids: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not all(
            (
                self.goal_id,
                self.portfolio_decision_id,
                self.selected_node_ids,
                self.graph_strategy_review_id,
                self.authority_ref,
            )
        ):
            raise ValueError("portfolio governance authorization is incomplete")
        if self.authorized and self.reasons:
            raise ValueError("authorized portfolio cannot retain denial reasons")
        if not self.authorized and not self.reasons:
            raise ValueError("denied portfolio requires reasons")

    @property
    def authorization_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "governance_version": STRATEGIC_GOVERNANCE_VERSION,
            "goal_id": self.goal_id,
            "portfolio_decision_id": self.portfolio_decision_id,
            "selected_node_ids": list(self.selected_node_ids),
            "graph_strategy_review_id": self.graph_strategy_review_id,
            "root_bridge_ids": list(self.root_bridge_ids),
            "mode_charter_ids": list(self.mode_charter_ids),
            "prior_art_challenge_ids": list(self.prior_art_challenge_ids),
            "construct_audit_ids": list(self.construct_audit_ids),
            "authorized": self.authorized,
            "reasons": list(self.reasons),
            "authority_ref": self.authority_ref,
        }
        # Preserve the content identity of historical v1 authorizations.
        if self.executable_preflight_ids:
            value["executable_preflight_ids"] = list(
                self.executable_preflight_ids
            )
        if include_id:
            value["authorization_id"] = self.authorization_id
        return value


def evaluate_portfolio_governance(
    goal: HighLevelGoal,
    decision: PortfolioDecision,
    graph_review: GraphStrategyReview,
    bridges: Mapping[str, RootRelevanceBridge],
    mode_charters: Mapping[str, ThreeModeResearchCharter],
    prior_art_challenges: Mapping[str, PriorArtCoverageChallenge],
    construct_audits: Mapping[str, ConstructValidityAudit],
    executable_preflights: Mapping[str, ExecutableAssayPreflight] | None = None,
    *,
    authority_ref: str = "deterministic-strategic-governance-authority-v1",
) -> PortfolioGovernanceAuthorization:
    """Fail closed before an autonomous discovery program spends experiment budget."""

    reasons = []
    selected = tuple(decision.selected_node_ids)
    if graph_review.goal_id != goal.goal_id:
        reasons.append("graph strategy belongs to another goal")
    if graph_review.root_contract_id != goal.goal_id:
        reasons.append("root completion contract was not frozen to the goal identity")
    if tuple(graph_review.selected_node_ids) != selected:
        reasons.append("portfolio differs from the independently reviewed strategy")

    bridge_ids = []
    charter_ids = []
    prior_ids = []
    construct_ids = []
    preflight_ids = []
    preflights = executable_preflights or {}
    primary_metrics = tuple(metric.name for metric in goal.terminal_metrics if metric.primary)
    primary_metric = primary_metrics[0]
    for node_id in selected:
        bridge = bridges.get(node_id)
        if bridge is None:
            reasons.append("node %s has no root-relevance bridge" % node_id)
        else:
            bridge_ids.append(bridge.bridge_id)
            if bridge.goal_id != goal.goal_id:
                reasons.append("node %s bridge belongs to another goal" % node_id)
            if bridge.root_metric != primary_metric:
                reasons.append("node %s bridge targets a non-primary root metric" % node_id)

        charter = mode_charters.get(node_id)
        if charter is None:
            reasons.append("node %s has no operational three-mode charter" % node_id)
        else:
            charter_ids.append(charter.charter_id)

        prior = prior_art_challenges.get(node_id)
        if prior is None:
            reasons.append("node %s has no independent prior-art coverage challenge" % node_id)
        else:
            prior_ids.append(prior.challenge_id)
            if not prior.passed:
                reasons.append("node %s prior-art coverage challenge failed" % node_id)

        construct = construct_audits.get(node_id)
        if construct is None:
            reasons.append("node %s has no independent construct-validity audit" % node_id)
        else:
            construct_ids.append(construct.audit_id)
            if not construct.passed:
                reasons.append("node %s construct-validity audit failed" % node_id)

        preflight = preflights.get(node_id)
        if preflight is None:
            reasons.append("node %s has no executable assay preflight" % node_id)
        else:
            preflight_ids.append(preflight.preflight_id)
            if preflight.proposal_ref != getattr(construct, "proposal_ref", None):
                reasons.append(
                    "node %s executable preflight targets another proposal" % node_id
                )
            if not preflight.passed:
                reasons.append("node %s executable assay preflight failed" % node_id)

    return PortfolioGovernanceAuthorization(
        goal_id=goal.goal_id,
        portfolio_decision_id=decision.decision_id,
        selected_node_ids=selected,
        graph_strategy_review_id=graph_review.review_id,
        root_bridge_ids=tuple(bridge_ids),
        mode_charter_ids=tuple(charter_ids),
        prior_art_challenge_ids=tuple(prior_ids),
        construct_audit_ids=tuple(construct_ids),
        authorized=not reasons,
        reasons=tuple(reasons),
        authority_ref=authority_ref,
        executable_preflight_ids=tuple(preflight_ids),
    )


def portfolio_authorization_from_dict(
    value: Mapping[str, Any],
) -> PortfolioGovernanceAuthorization:
    authorization = PortfolioGovernanceAuthorization(
        goal_id=str(value["goal_id"]),
        portfolio_decision_id=str(value["portfolio_decision_id"]),
        selected_node_ids=tuple(str(item) for item in value["selected_node_ids"]),
        graph_strategy_review_id=str(value["graph_strategy_review_id"]),
        root_bridge_ids=tuple(str(item) for item in value["root_bridge_ids"]),
        mode_charter_ids=tuple(str(item) for item in value["mode_charter_ids"]),
        prior_art_challenge_ids=tuple(
            str(item) for item in value["prior_art_challenge_ids"]
        ),
        construct_audit_ids=tuple(str(item) for item in value["construct_audit_ids"]),
        authorized=bool(value["authorized"]),
        reasons=tuple(str(item) for item in value["reasons"]),
        authority_ref=str(value["authority_ref"]),
        executable_preflight_ids=tuple(
            str(item) for item in value.get("executable_preflight_ids", ())
        ),
    )
    if authorization.authorization_id != value.get("authorization_id"):
        raise ValueError("restored portfolio-governance authorization digest mismatch")
    return authorization
