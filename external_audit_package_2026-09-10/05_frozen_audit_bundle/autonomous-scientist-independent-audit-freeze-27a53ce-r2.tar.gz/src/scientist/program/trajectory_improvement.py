from __future__ import annotations

import math
import random
from dataclasses import dataclass
from statistics import mean
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    Mapping,
    Protocol,
    Sequence,
    Tuple,
    TypeVar,
)

from scientist.core.artifacts import content_digest
from scientist.program.discovery_evidence import paired_episode_evidence


TRAJECTORY_IMPROVEMENT_VERSION = (
    "absolute-trajectory-policy-improvement-v5-prepared-niche-repair"
)


class TrajectoryCandidate(Protocol):
    @property
    def candidate_id(self) -> str:
        ...

    def as_dict(self) -> Mapping[str, Any]:
        ...


CandidateT = TypeVar("CandidateT", bound=TrajectoryCandidate)
ExperimentT = TypeVar("ExperimentT")


@dataclass(frozen=True)
class FrozenTrajectoryBatch(Generic[ExperimentT]):
    batch_id: str
    episode_ids: Tuple[str, ...]
    experiments: Tuple[ExperimentT, ...]

    def __post_init__(self) -> None:
        if not self.batch_id or len(self.episode_ids) < 2:
            raise ValueError("trajectory batch requires an identity and two episodes")
        if len(self.episode_ids) != len(self.experiments):
            raise ValueError("trajectory batch identities and experiments disagree")
        if len(set(self.episode_ids)) != len(self.episode_ids):
            raise ValueError("trajectory episodes must be independent")

    @property
    def batch_digest(self) -> str:
        return content_digest(
            {"batch_id": self.batch_id, "episode_ids": list(self.episode_ids)}
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "batch_id": self.batch_id,
            "episode_count": len(self.episode_ids),
            "episode_id_digest": content_digest(self.episode_ids),
            "batch_digest": self.batch_digest,
        }


@dataclass(frozen=True)
class AbsoluteTrajectoryEvaluation:
    candidate_id: str
    batch_id: str
    episode_ids: Tuple[str, ...]
    returns: Tuple[float, ...]
    diagnostics: Mapping[str, Any]

    def __post_init__(self) -> None:
        if not self.candidate_id or not self.batch_id:
            raise ValueError("trajectory evaluation is missing an identity")
        if len(self.episode_ids) < 2 or len(self.episode_ids) != len(self.returns):
            raise ValueError("trajectory evaluation requires one return per episode")
        if len(set(self.episode_ids)) != len(self.episode_ids):
            raise ValueError("trajectory returns must use independent episodes")
        if not all(math.isfinite(value) for value in self.returns):
            raise ValueError("trajectory returns must be finite")

    @property
    def expected_return(self) -> float:
        return mean(self.returns)

    @property
    def worst_return(self) -> float:
        return min(self.returns)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "batch_id": self.batch_id,
            "episode_ids": list(self.episode_ids),
            "returns": list(self.returns),
            "expected_return": self.expected_return,
            "worst_return": self.worst_return,
            "diagnostics": dict(self.diagnostics),
        }


@dataclass(frozen=True)
class TrajectoryImprovementConfig:
    population_size: int = 5
    elite_count: int = 2
    selection_pool_size: int = 3
    generation_count: int = 2
    mutation_seed: int = 64_203
    maximum_mutation_attempts: int = 100

    def __post_init__(self) -> None:
        if self.population_size < 2:
            raise ValueError("trajectory population requires at least two policies")
        if not 0 < self.elite_count < self.population_size:
            raise ValueError("trajectory elite count must be inside the population")
        if not 0 < self.selection_pool_size <= self.population_size:
            raise ValueError("invalid trajectory selection-pool size")
        if self.generation_count <= 0 or self.maximum_mutation_attempts <= 0:
            raise ValueError("invalid trajectory improvement budget")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": TRAJECTORY_IMPROVEMENT_VERSION,
            "population_size": self.population_size,
            "elite_count": self.elite_count,
            "selection_pool_size": self.selection_pool_size,
            "generation_count": self.generation_count,
            "mutation_seed": self.mutation_seed,
            "maximum_mutation_attempts": self.maximum_mutation_attempts,
            "optimization_signal": "absolute complete-trajectory return",
            "incumbent_input": None,
            "pairwise_comparator_input": None,
        }


@dataclass(frozen=True)
class TrajectoryEvaluationRecord(Generic[CandidateT]):
    candidate: CandidateT
    evaluation: AbsoluteTrajectoryEvaluation
    generation: int
    parent_ids: Tuple[str, ...]
    operator: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate": dict(self.candidate.as_dict()),
            "generation": self.generation,
            "parent_ids": list(self.parent_ids),
            "operator": self.operator,
            "evaluation": self.evaluation.as_dict(),
        }


@dataclass(frozen=True)
class TrajectoryImprovementOutcome(Generic[CandidateT]):
    config: TrajectoryImprovementConfig
    generations: Tuple[Tuple[TrajectoryEvaluationRecord[CandidateT], ...], ...]
    selection_records: Tuple[TrajectoryEvaluationRecord[CandidateT], ...]
    selected_candidate: CandidateT
    selection_id: str
    improvement_demonstrated: bool
    improvement_evidence: Mapping[str, Any] | None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "version": TRAJECTORY_IMPROVEMENT_VERSION,
            "config": self.config.as_dict(),
            "generations": [
                [record.as_dict() for record in generation]
                for generation in self.generations
            ],
            "selection_records": [
                record.as_dict() for record in self.selection_records
            ],
            "selected_candidate": dict(self.selected_candidate.as_dict()),
            "selection_id": self.selection_id,
            "selection_frozen": True,
            "incumbent_observed": False,
            "improvement_demonstrated": self.improvement_demonstrated,
            "improvement_evidence": (
                None
                if self.improvement_evidence is None
                else dict(self.improvement_evidence)
            ),
        }


def _record_rank(
    record: TrajectoryEvaluationRecord[CandidateT],
) -> Tuple[float, float, str]:
    return (
        -record.evaluation.expected_return,
        -record.evaluation.worst_return,
        record.candidate.candidate_id,
    )


def run_absolute_trajectory_improvement(
    config: TrajectoryImprovementConfig,
    initial_population: Sequence[CandidateT],
    development_batches: Sequence[FrozenTrajectoryBatch[ExperimentT]],
    selection_batch: FrozenTrajectoryBatch[ExperimentT],
    evaluate: Callable[
        [CandidateT, FrozenTrajectoryBatch[ExperimentT]],
        AbsoluteTrajectoryEvaluation,
    ],
    mutate: Callable[[CandidateT, random.Random, int, int], CandidateT],
    *,
    diversity_key: Callable[[CandidateT], str] | None = None,
    prepare_mutation: Callable[
        [Sequence[CandidateT], FrozenTrajectoryBatch[ExperimentT]], None
    ]
    | None = None,
    progress: Callable[[str, Mapping[str, Any]], None] | None = None,
) -> TrajectoryImprovementOutcome[CandidateT]:
    """Improve policies using only absolute return on complete trajectories."""

    if len(initial_population) != config.population_size:
        raise ValueError("initial trajectory population has the wrong size")
    if len(development_batches) != config.generation_count:
        raise ValueError("trajectory improvement needs one fresh batch per generation")
    candidate_ids = tuple(candidate.candidate_id for candidate in initial_population)
    if len(set(candidate_ids)) != len(candidate_ids):
        raise ValueError("initial trajectory candidates must be unique")
    batches = (*development_batches, selection_batch)
    all_episode_ids = tuple(
        episode_id for batch in batches for episode_id in batch.episode_ids
    )
    if len(set(all_episode_ids)) != len(all_episode_ids):
        raise ValueError("trajectory development and selection batches must be disjoint")

    rng = random.Random(config.mutation_seed)
    population = tuple(
        (candidate, (), "initial_semantic_seed")
        for candidate in initial_population
    )
    seen_candidates = set(candidate_ids)
    generations = []
    final_ranked: Tuple[TrajectoryEvaluationRecord[CandidateT], ...] = ()
    initial_records: Tuple[TrajectoryEvaluationRecord[CandidateT], ...] = ()
    for generation, batch in enumerate(development_batches):
        records = []
        for candidate, parent_ids, operator in population:
            evaluation = evaluate(candidate, batch)
            if evaluation.candidate_id != candidate.candidate_id:
                raise ValueError("trajectory evaluator changed candidate identity")
            if evaluation.batch_id != batch.batch_id:
                raise ValueError("trajectory evaluator changed batch identity")
            if evaluation.episode_ids != batch.episode_ids:
                raise ValueError("trajectory evaluator changed episode identities")
            records.append(
                TrajectoryEvaluationRecord(
                    candidate=candidate,
                    evaluation=evaluation,
                    generation=generation,
                    parent_ids=parent_ids,
                    operator=operator,
                )
            )
        final_ranked = tuple(sorted(records, key=_record_rank))
        if generation == 0:
            initial_records = final_ranked
        generations.append(tuple(records))
        if progress is not None:
            progress(
                "trajectory_generation_complete",
                {
                    "generation": generation,
                    "batch_id": batch.batch_id,
                    "best_candidate_id": final_ranked[0].candidate.candidate_id,
                    "best_expected_return": (
                        final_ranked[0].evaluation.expected_return
                    ),
                },
            )
        if generation + 1 == config.generation_count:
            break
        if diversity_key is None:
            elites = final_ranked[: config.elite_count]
        else:
            diverse_elites = []
            seen_niches = set()
            for record in final_ranked:
                niche = diversity_key(record.candidate)
                if not niche or niche in seen_niches:
                    continue
                diverse_elites.append(record)
                seen_niches.add(niche)
                if len(diverse_elites) == config.elite_count:
                    break
            if len(diverse_elites) < config.elite_count:
                selected_ids = {
                    record.candidate.candidate_id for record in diverse_elites
                }
                diverse_elites.extend(
                    record
                    for record in final_ranked
                    if record.candidate.candidate_id not in selected_ids
                )
            elites = tuple(diverse_elites[: config.elite_count])
        if prepare_mutation is not None:
            prepare_mutation(
                tuple(record.candidate for record in elites),
                batch,
            )
        next_population = [
            (
                record.candidate,
                (record.candidate.candidate_id,),
                "elite_recheck_on_fresh_batch",
            )
            for record in elites
        ]
        child_index = 0
        attempts = 0
        while len(next_population) < config.population_size:
            if attempts >= config.maximum_mutation_attempts:
                raise RuntimeError("trajectory mutation exhausted unique candidates")
            parent = elites[child_index % len(elites)].candidate
            child = mutate(parent, rng, generation + 1, child_index)
            attempts += 1
            child_index += 1
            if child.candidate_id in seen_candidates:
                continue
            seen_candidates.add(child.candidate_id)
            next_population.append(
                (
                    child,
                    (parent.candidate_id,),
                    "complete_policy_trajectory_mutation",
                )
            )
        population = tuple(next_population)

    # Selection evaluates the evolved finalists and every frozen initial policy.
    # Otherwise an initial control can disappear during evolution, making the
    # qualified-adoption comparison either weaker or impossible.
    selection_pool = list(final_ranked[: config.selection_pool_size])
    initial_set = set(candidate_ids)
    selected_ids = {record.candidate.candidate_id for record in selection_pool}
    selection_pool.extend(
        record
        for record in initial_records
        if record.candidate.candidate_id not in selected_ids
    )
    selection_records = tuple(
        TrajectoryEvaluationRecord(
            candidate=record.candidate,
            evaluation=evaluate(record.candidate, selection_batch),
            generation=record.generation,
            parent_ids=record.parent_ids,
            operator="fresh_selection_after:%s" % record.operator,
        )
        for record in selection_pool
    )

    def conservative_selection_rank(
        record: TrajectoryEvaluationRecord[CandidateT],
    ) -> Tuple[float, float, int, str]:
        rank = _record_rank(record)
        return (
            rank[0],
            rank[1],
            int(record.candidate.candidate_id not in initial_set),
            rank[2],
        )

    selected_record = min(selection_records, key=conservative_selection_rank)
    initial_selection_records = tuple(
        record
        for record in selection_records
        if record.candidate.candidate_id in initial_set
    )
    selected_initial_record = (
        None
        if not initial_selection_records
        else min(initial_selection_records, key=_record_rank)
    )
    improvement_evidence: Mapping[str, Any] | None = None
    improvement_demonstrated = False
    if (
        selected_record.candidate.candidate_id not in initial_set
        and selected_initial_record is not None
    ):
        paired = paired_episode_evidence(
            (
                candidate_return - initial_return
                for candidate_return, initial_return in zip(
                    selected_record.evaluation.returns,
                    selected_initial_record.evaluation.returns,
                )
            ),
            selected_record.evaluation.episode_ids,
        )
        improvement_evidence = {
            "candidate_id": selected_record.candidate.candidate_id,
            "initial_control_id": (
                selected_initial_record.candidate.candidate_id
            ),
            "paired_return_evidence": paired.as_dict(),
        }
        improvement_demonstrated = paired.mean_ci_lower > 0.0
        if not improvement_demonstrated:
            selected_record = selected_initial_record
    selection_payload = {
        "version": TRAJECTORY_IMPROVEMENT_VERSION,
        "candidate_id": selected_record.candidate.candidate_id,
        "selection_batch_digest": selection_batch.batch_digest,
        "selection_evaluation": selected_record.evaluation.as_dict(),
        "selection_rule": (
            "maximum mean absolute complete-trajectory return; mutations "
            "replace the best initial policy only when paired 95% confidence "
            "is strictly positive"
        ),
        "incumbent_observed": False,
        "improvement_demonstrated": improvement_demonstrated,
        "improvement_evidence": improvement_evidence,
    }
    selection_id = content_digest(selection_payload)
    if progress is not None:
        progress(
            "trajectory_policy_frozen",
            {
                "candidate_id": selected_record.candidate.candidate_id,
                "selection_id": selection_id,
                "expected_return": selected_record.evaluation.expected_return,
            },
        )
    return TrajectoryImprovementOutcome(
        config=config,
        generations=tuple(generations),
        selection_records=selection_records,
        selected_candidate=selected_record.candidate,
        selection_id=selection_id,
        improvement_demonstrated=improvement_demonstrated,
        improvement_evidence=improvement_evidence,
    )
