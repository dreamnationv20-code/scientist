from __future__ import annotations

import json
import os
import re
import getpass
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Mapping, Optional, Protocol, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.program.literature import (
    ClaimClassification,
    LiteratureQuery,
    PriorArtAssessment,
    PriorArtRelation,
    PriorWork,
    SearchFacet,
)


_TOKEN_PATTERN = re.compile(r"[a-z0-9]+")
_STOP_WORDS = {
    "a",
    "an",
    "and",
    "for",
    "from",
    "in",
    "of",
    "on",
    "or",
    "the",
    "to",
    "via",
    "with",
}
_SEMANTIC_SCHOLAR_KEYCHAIN_SERVICE = (
    "ai.scientist.semantic-scholar-api-key"
)


class WebLiteratureError(RuntimeError):
    """Raised when a web-literature request cannot produce JSON evidence."""

    def __init__(
        self,
        message: str,
        *,
        status: Optional[int] = None,
        response_body: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.response_body = response_body


@dataclass(frozen=True)
class JsonHttpResponse:
    status: int
    headers: Mapping[str, str]
    payload: Mapping[str, Any]


class JsonHttpTransport(Protocol):
    def get_json(
        self,
        url: str,
        *,
        headers: Mapping[str, str],
        timeout_seconds: float,
    ) -> JsonHttpResponse:
        ...


class UrllibJsonTransport:
    """Small dependency-free JSON transport used by literature providers."""

    def get_json(
        self,
        url: str,
        *,
        headers: Mapping[str, str],
        timeout_seconds: float,
    ) -> JsonHttpResponse:
        request = urllib.request.Request(
            url,
            headers=dict(headers),
            method="GET",
        )
        try:
            with urllib.request.urlopen(
                request,
                timeout=timeout_seconds,
            ) as response:
                body = response.read()
                response_headers = {
                    str(key): str(value)
                    for key, value in response.headers.items()
                }
                status = int(response.status)
        except urllib.error.HTTPError as error:
            body = error.read()
            raise WebLiteratureError(
                "HTTP %d from literature provider" % error.code,
                status=int(error.code),
                response_body=body.decode("utf-8", errors="replace"),
            ) from error
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            raise WebLiteratureError(
                "literature provider request failed: %s" % error
            ) from error
        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise WebLiteratureError(
                "literature provider returned invalid JSON",
                status=status,
                response_body=body.decode("utf-8", errors="replace"),
            ) from error
        if not isinstance(payload, dict):
            raise WebLiteratureError(
                "literature provider JSON root is not an object",
                status=status,
                response_body=body.decode("utf-8", errors="replace"),
            )
        return JsonHttpResponse(
            status=status,
            headers=response_headers,
            payload=payload,
        )


@dataclass(frozen=True)
class WebLiteratureReceipt:
    provider: str
    provider_version: str
    operation: str
    query: str
    facet: SearchFacet
    request_url: str
    requested_at: str
    success: bool
    status: Optional[int]
    result_count: int
    raw_response_artifact: str
    error: Optional[str] = None
    cache_hit: bool = False

    def as_dict(self) -> Dict[str, Any]:
        return {
            "provider": self.provider,
            "provider_version": self.provider_version,
            "operation": self.operation,
            "query": self.query,
            "facet": self.facet.value,
            "request_url": self.request_url,
            "requested_at": self.requested_at,
            "success": self.success,
            "status": self.status,
            "result_count": self.result_count,
            "raw_response_artifact": self.raw_response_artifact,
            "error": self.error,
            "cache_hit": self.cache_hit,
        }


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _semantic_scholar_api_key() -> str:
    environment_key = os.environ.get(
        "SEMANTIC_SCHOLAR_API_KEY",
        "",
    ).strip()
    if environment_key:
        return environment_key
    if sys.platform != "darwin":
        return ""
    try:
        result = subprocess.run(
            (
                "security",
                "find-generic-password",
                "-a",
                getpass.getuser(),
                "-s",
                _SEMANTIC_SCHOLAR_KEYCHAIN_SERVICE,
                "-w",
            ),
            check=False,
            capture_output=True,
            text=True,
            timeout=5.0,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return result.stdout.strip() if result.returncode == 0 else ""


def _tokens(value: str) -> Tuple[str, ...]:
    return tuple(
        token
        for token in _TOKEN_PATTERN.findall(value.lower())
        if token not in _STOP_WORDS and len(token) > 1
    )


def _relational_query_candidates(query: str) -> Tuple[str, ...]:
    """Map compositional mechanism prose to established research vocabulary."""

    token_set = set(_tokens(query))
    controlled_vocabulary = (
        (
            {"episode", "policy"},
            "policy evaluation reinforcement learning",
        ),
        (
            {"trajectory", "credit", "intervention"},
            "credit assignment reinforcement learning",
        ),
        (
            {"difference", "rewards"},
            "multi agent credit assignment",
        ),
        (
            {"subset", "ablation"},
            "policy ablation sequential decisions",
        ),
        (
            {"causal", "state"},
            "causal representation learning",
        ),
        (
            {"safe", "policy", "improvement"},
            "safe policy improvement",
        ),
        (
            {"offline", "policy"},
            "off policy evaluation",
        ),
        (
            {"confidence", "calibration"},
            "confidence calibration learning",
        ),
        (
            {"model", "predictive", "control"},
            "model predictive control",
        ),
    )
    return tuple(
        dict.fromkeys(
            provider_query
            for required, provider_query in controlled_vocabulary
            if required.issubset(token_set)
        )
    )


def _year(value: Any) -> Optional[int]:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    if 1800 <= parsed <= datetime.now(timezone.utc).year + 1:
        return parsed
    return None


def _relation_and_matches(
    query: str,
    title: str,
    abstract: str,
    facet: SearchFacet,
    provider: str,
) -> Tuple[PriorArtRelation, Tuple[str, ...]]:
    query_tokens = set(_tokens(query))
    document_tokens = set(_tokens("%s %s" % (title, abstract)))
    overlap = tuple(sorted(query_tokens.intersection(document_tokens)))
    coverage = (
        len(overlap) / len(query_tokens)
        if query_tokens
        else 0.0
    )
    relation = (
        PriorArtRelation.STRONG_OVERLAP
        if coverage >= 0.55 and len(overlap) >= 3
        else PriorArtRelation.ADJACENT
    )
    components = [
        "retrieved-via:%s" % provider,
        "facet:%s" % facet.value,
    ]
    components.extend("matched-term:%s" % token for token in overlap[:8])
    if not overlap:
        components.append("ranked-result-for-query")
    return relation, tuple(components)


class _RecordedWebProvider:
    name = ""
    provider_version = ""

    def __init__(
        self,
        store: ArtifactStore,
        *,
        transport: Optional[JsonHttpTransport] = None,
        timeout_seconds: float = 20.0,
        results_per_query: int = 6,
    ) -> None:
        if timeout_seconds <= 0.0:
            raise ValueError("literature timeout must be positive")
        if results_per_query <= 0:
            raise ValueError("literature result count must be positive")
        self.store = store
        self.transport = transport or UrllibJsonTransport()
        self.timeout_seconds = timeout_seconds
        self.results_per_query = results_per_query
        self.receipts: list[WebLiteratureReceipt] = []
        self._cache: Dict[str, JsonHttpResponse] = {}

    def _headers(self) -> Mapping[str, str]:
        return {
            "Accept": "application/json",
            "User-Agent": (
                "Scientist/0.1 autonomous-prior-art-review "
                "(https://github.com/openai)"
            ),
        }

    def _request(
        self,
        *,
        url: str,
        operation: str,
        query: str,
        facet: SearchFacet,
    ) -> Optional[Mapping[str, Any]]:
        requested_at = _now()
        cache_hit = url in self._cache
        try:
            response = (
                self._cache[url]
                if cache_hit
                else self.transport.get_json(
                    url,
                    headers=self._headers(),
                    timeout_seconds=self.timeout_seconds,
                )
            )
            self._cache[url] = response
            raw_value = {
                "schema": 1,
                "provider": self.name,
                "provider_version": self.provider_version,
                "operation": operation,
                "query": query,
                "facet": facet.value,
                "request_url": url,
                "requested_at": requested_at,
                "status": response.status,
                "response_headers": dict(sorted(response.headers.items())),
                "payload": response.payload,
                "cache_hit": cache_hit,
            }
            raw_digest = self.store.put(
                "web_literature_raw_response",
                raw_value,
            )
            self.receipts.append(
                WebLiteratureReceipt(
                    provider=self.name,
                    provider_version=self.provider_version,
                    operation=operation,
                    query=query,
                    facet=facet,
                    request_url=url,
                    requested_at=requested_at,
                    success=True,
                    status=response.status,
                    result_count=0,
                    raw_response_artifact=raw_digest,
                    cache_hit=cache_hit,
                )
            )
            return response.payload
        except WebLiteratureError as error:
            failure_value = {
                "schema": 1,
                "provider": self.name,
                "provider_version": self.provider_version,
                "operation": operation,
                "query": query,
                "facet": facet.value,
                "request_url": url,
                "requested_at": requested_at,
                "status": error.status,
                "error": str(error),
                "response_body": error.response_body,
                "cache_hit": False,
            }
            raw_digest = self.store.put(
                "web_literature_failed_response",
                failure_value,
            )
            self.receipts.append(
                WebLiteratureReceipt(
                    provider=self.name,
                    provider_version=self.provider_version,
                    operation=operation,
                    query=query,
                    facet=facet,
                    request_url=url,
                    requested_at=requested_at,
                    success=False,
                    status=error.status,
                    result_count=0,
                    raw_response_artifact=raw_digest,
                    error=str(error),
                )
            )
            return None

    def _set_result_count(self, count: int) -> None:
        receipt = self.receipts[-1]
        self.receipts[-1] = WebLiteratureReceipt(
            provider=receipt.provider,
            provider_version=receipt.provider_version,
            operation=receipt.operation,
            query=receipt.query,
            facet=receipt.facet,
            request_url=receipt.request_url,
            requested_at=receipt.requested_at,
            success=receipt.success,
            status=receipt.status,
            result_count=count,
            raw_response_artifact=receipt.raw_response_artifact,
            error=receipt.error,
            cache_hit=receipt.cache_hit,
        )


class CrossrefWebProvider(_RecordedWebProvider):
    """Crossref REST API search plus reference-list expansion."""

    name = "Crossref Web API"
    provider_version = "rest-v1"
    base_url = "https://api.crossref.org"

    def _headers(self) -> Mapping[str, str]:
        headers = dict(super()._headers())
        mailto = os.environ.get("SCIENTIST_LITERATURE_MAILTO", "").strip()
        if mailto:
            headers["User-Agent"] = (
                "Scientist/0.1 autonomous-prior-art-review "
                "(mailto:%s)" % mailto
            )
        return headers

    def search(
        self,
        query: str,
        facet: SearchFacet,
    ) -> Sequence[PriorWork]:
        parameters = {
            "query.bibliographic": query,
            "rows": str(self.results_per_query),
            "select": (
                "DOI,title,published-print,published-online,"
                "published,URL,abstract,reference,is-referenced-by-count"
            ),
        }
        mailto = os.environ.get("SCIENTIST_LITERATURE_MAILTO", "").strip()
        if mailto:
            parameters["mailto"] = mailto
        url = "%s/works?%s" % (
            self.base_url,
            urllib.parse.urlencode(parameters),
        )
        payload = self._request(
            url=url,
            operation="search",
            query=query,
            facet=facet,
        )
        if payload is None:
            return ()
        message = payload.get("message", {})
        items = message.get("items", ()) if isinstance(message, dict) else ()
        works = []
        if isinstance(items, list):
            for item in items:
                work = self._work_from_item(item, query, facet)
                if work is not None:
                    works.append(work)
        self._set_result_count(len(works))
        return tuple(works)

    def _work_from_item(
        self,
        item: Any,
        query: str,
        facet: SearchFacet,
    ) -> Optional[PriorWork]:
        if not isinstance(item, dict):
            return None
        titles = item.get("title", ())
        title = (
            str(titles[0]).strip()
            if isinstance(titles, list) and titles
            else ""
        )
        doi = str(item.get("DOI", "")).strip().lower()
        locator = str(item.get("URL", "")).strip()
        published = (
            item.get("published-print")
            or item.get("published-online")
            or item.get("published")
            or {}
        )
        date_parts = (
            published.get("date-parts", ())
            if isinstance(published, dict)
            else ()
        )
        published_year = (
            _year(date_parts[0][0])
            if (
                isinstance(date_parts, list)
                and date_parts
                and isinstance(date_parts[0], list)
                and date_parts[0]
            )
            else None
        )
        if not title or published_year is None or not (doi or locator):
            return None
        work_id = "doi:%s" % doi if doi else (
            "crossref:%s" % content_digest(
                {"title": title, "year": published_year, "url": locator}
            )
        )
        locator = locator or "https://doi.org/%s" % doi
        relation, matches = _relation_and_matches(
            query,
            title,
            str(item.get("abstract", "")),
            facet,
            self.name,
        )
        return PriorWork(
            work_id=work_id,
            title=title,
            year=published_year,
            locator=locator,
            relation=relation,
            matched_components=matches,
            abstract=str(item.get("abstract", "") or ""),
        )

    def citation_neighborhood(
        self,
        work: PriorWork,
    ) -> Sequence[PriorWork]:
        if not work.work_id.startswith("doi:"):
            return ()
        doi = work.work_id[4:]
        url = "%s/works/%s" % (
            self.base_url,
            urllib.parse.quote(doi, safe=""),
        )
        payload = self._request(
            url=url,
            operation="citation_neighborhood",
            query=work.work_id,
            facet=SearchFacet.CITATION_NEIGHBORHOOD,
        )
        if payload is None:
            return ()
        message = payload.get("message", {})
        references = (
            message.get("reference", ())
            if isinstance(message, dict)
            else ()
        )
        neighbors = []
        if isinstance(references, list):
            for reference in references[: self.results_per_query]:
                if not isinstance(reference, dict):
                    continue
                ref_doi = str(reference.get("DOI", "")).strip().lower()
                title = str(
                    reference.get("article-title")
                    or reference.get("series-title")
                    or reference.get("volume-title")
                    or ("Referenced work %s" % ref_doi if ref_doi else "")
                ).strip()
                ref_year = _year(reference.get("year"))
                if not title or ref_year is None:
                    continue
                work_id = (
                    "doi:%s" % ref_doi
                    if ref_doi
                    else "crossref-reference:%s"
                    % content_digest(
                        {
                            "seed": work.work_id,
                            "title": title,
                            "year": ref_year,
                        }
                    )
                )
                locator = (
                    "https://doi.org/%s" % ref_doi
                    if ref_doi
                    else work.locator
                )
                neighbors.append(
                    PriorWork(
                        work_id=work_id,
                        title=title,
                        year=ref_year,
                        locator=locator,
                        relation=PriorArtRelation.ADJACENT,
                        matched_components=(
                            "retrieved-via:%s" % self.name,
                            "citation-neighbor-of:%s" % work.work_id,
                        ),
                    )
                )
        self._set_result_count(len(neighbors))
        return tuple(neighbors)


class SemanticScholarWebProvider(_RecordedWebProvider):
    """Semantic Scholar Graph API relevance and reference search."""

    name = "Semantic Scholar Web API"
    provider_version = "graph-v1"
    base_url = "https://api.semanticscholar.org/graph/v1"

    def __init__(
        self,
        store: ArtifactStore,
        *,
        transport: Optional[JsonHttpTransport] = None,
        timeout_seconds: float = 20.0,
        results_per_query: int = 6,
        api_key: Optional[str] = None,
    ) -> None:
        super().__init__(
            store,
            transport=transport,
            timeout_seconds=timeout_seconds,
            results_per_query=results_per_query,
        )
        self._api_key = (
            _semantic_scholar_api_key()
            if api_key is None
            else api_key.strip()
        )
        self._last_live_request = 0.0

    def _request(
        self,
        *,
        url: str,
        operation: str,
        query: str,
        facet: SearchFacet,
    ) -> Optional[Mapping[str, Any]]:
        if isinstance(self.transport, UrllibJsonTransport):
            elapsed = time.monotonic() - self._last_live_request
            if elapsed < 1.1:
                time.sleep(1.1 - elapsed)
        payload = super()._request(
            url=url,
            operation=operation,
            query=query,
            facet=facet,
        )
        self._last_live_request = time.monotonic()
        retry_count = 0
        while (
            isinstance(self.transport, UrllibJsonTransport)
            and payload is None
            and self.receipts
            and self.receipts[-1].status in (429, 500, 502, 503, 504)
            and retry_count < 3
        ):
            retry_count += 1
            time.sleep(float(2 ** (retry_count - 1)))
            payload = super()._request(
                url=url,
                operation="%s_retry_%d" % (operation, retry_count),
                query=query,
                facet=facet,
            )
            self._last_live_request = time.monotonic()
        return payload

    def _headers(self) -> Mapping[str, str]:
        headers = dict(super()._headers())
        if self._api_key:
            headers["x-api-key"] = self._api_key
        return headers

    def search(
        self,
        query: str,
        facet: SearchFacet,
    ) -> Sequence[PriorWork]:
        provider_queries = tuple(
            dict.fromkeys((query, *_relational_query_candidates(query)))
        )
        for query_index, provider_query in enumerate(provider_queries):
            parameters = {
                "query": provider_query,
                "limit": str(self.results_per_query),
                "fields": (
                    "paperId,title,year,url,abstract,externalIds,"
                    "citationCount"
                ),
            }
            url = "%s/paper/search?%s" % (
                self.base_url,
                urllib.parse.urlencode(parameters),
            )
            operation = "search" if query_index == 0 else (
                "search_controlled_vocabulary_%d" % query_index
            )
            payload = self._request(
                url=url,
                operation=operation,
                query=provider_query,
                facet=facet,
            )
            if payload is None:
                continue
            items = payload.get("data", ())
            works = []
            if isinstance(items, list):
                for item in items:
                    work = self._work_from_item(
                        item,
                        provider_query,
                        facet,
                    )
                    if work is not None:
                        works.append(work)
            self._set_result_count(len(works))
            if works:
                return tuple(works)
        return ()

    def _work_from_item(
        self,
        item: Any,
        query: str,
        facet: SearchFacet,
    ) -> Optional[PriorWork]:
        if not isinstance(item, dict):
            return None
        title = str(item.get("title", "")).strip()
        paper_id = str(item.get("paperId", "")).strip()
        published_year = _year(item.get("year"))
        external_ids = item.get("externalIds", {})
        doi = (
            str(external_ids.get("DOI", "")).strip().lower()
            if isinstance(external_ids, dict)
            else ""
        )
        locator = str(item.get("url", "")).strip()
        if not title or published_year is None or not paper_id:
            return None
        work_id = "doi:%s" % doi if doi else "s2:%s" % paper_id
        locator = locator or (
            "https://www.semanticscholar.org/paper/%s" % paper_id
        )
        relation, matches = _relation_and_matches(
            query,
            title,
            str(item.get("abstract") or ""),
            facet,
            self.name,
        )
        return PriorWork(
            work_id=work_id,
            title=title,
            year=published_year,
            locator=locator,
            relation=relation,
            matched_components=matches,
            abstract=str(item.get("abstract") or ""),
        )

    def citation_neighborhood(
        self,
        work: PriorWork,
    ) -> Sequence[PriorWork]:
        if work.work_id.startswith("doi:"):
            identifier = "DOI:%s" % work.work_id[4:]
        elif work.work_id.startswith("s2:"):
            identifier = work.work_id[3:]
        else:
            return ()
        parameters = {
            "limit": str(self.results_per_query),
            "fields": (
                "paperId,title,year,url,abstract,externalIds,citationCount"
            ),
        }
        url = "%s/paper/%s/references?%s" % (
            self.base_url,
            urllib.parse.quote(identifier, safe=""),
            urllib.parse.urlencode(parameters),
        )
        payload = self._request(
            url=url,
            operation="citation_neighborhood",
            query=work.work_id,
            facet=SearchFacet.CITATION_NEIGHBORHOOD,
        )
        if payload is None and work.work_id.startswith("doi:"):
            # Semantic Scholar occasionally indexes a valid publisher DOI but
            # does not resolve it through the DOI route.  Resolve the frozen
            # seed title to a paper ID and retry; both requests remain in the
            # evidence receipts so the fallback cannot hide the failed lookup.
            resolution_parameters = {
                "query": work.title,
                "limit": "1",
                "fields": (
                    "paperId,title,year,url,abstract,externalIds,"
                    "citationCount"
                ),
            }
            resolution_url = "%s/paper/search?%s" % (
                self.base_url,
                urllib.parse.urlencode(resolution_parameters),
            )
            resolution = self._request(
                url=resolution_url,
                operation="citation_seed_title_resolution",
                query=work.title,
                facet=SearchFacet.CITATION_NEIGHBORHOOD,
            )
            resolution_items = (
                resolution.get("data", ())
                if isinstance(resolution, dict)
                else ()
            )
            first = (
                resolution_items[0]
                if isinstance(resolution_items, list) and resolution_items
                else None
            )
            paper_id = (
                str(first.get("paperId", "")).strip()
                if isinstance(first, dict)
                else ""
            )
            resolved_title = (
                str(first.get("title", "")).strip()
                if isinstance(first, dict)
                else ""
            )
            if paper_id and set(_tokens(work.title)).intersection(
                _tokens(resolved_title)
            ):
                url = "%s/paper/%s/references?%s" % (
                    self.base_url,
                    urllib.parse.quote(paper_id, safe=""),
                    urllib.parse.urlencode(parameters),
                )
                payload = self._request(
                    url=url,
                    operation="citation_neighborhood_title_resolved",
                    query=work.work_id,
                    facet=SearchFacet.CITATION_NEIGHBORHOOD,
                )
        if payload is None:
            return ()
        items = payload.get("data", ())
        neighbors = []
        if isinstance(items, list):
            for item in items:
                cited = (
                    item.get("citedPaper")
                    if isinstance(item, dict)
                    else None
                )
                candidate = self._work_from_item(
                    cited,
                    "citation neighbor of %s" % work.work_id,
                    SearchFacet.CITATION_NEIGHBORHOOD,
                )
                if candidate is not None:
                    neighbors.append(candidate)
        self._set_result_count(len(neighbors))
        return tuple(neighbors)


class DblpWebProvider(_RecordedWebProvider):
    """DBLP publication-search API for computer-science coverage."""

    name = "DBLP Web API"
    provider_version = "publication-search-v2"
    base_url = "https://dblp.org/search/publ/api"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._last_live_request = 0.0

    def _request(
        self,
        *,
        url: str,
        operation: str,
        query: str,
        facet: SearchFacet,
    ) -> Optional[Mapping[str, Any]]:
        if isinstance(self.transport, UrllibJsonTransport):
            elapsed = time.monotonic() - self._last_live_request
            if elapsed < 1.1:
                time.sleep(1.1 - elapsed)
        payload = super()._request(
            url=url,
            operation=operation,
            query=query,
            facet=facet,
        )
        self._last_live_request = time.monotonic()
        return payload

    @staticmethod
    def _query_candidates(query: str) -> Tuple[str, ...]:
        """Translate prose queries to DBLP vocabulary without topic drift."""

        tokens = tuple(_tokens(query))
        token_set = set(tokens)
        candidates = [
            (
                "online bin packing"
                if {"online", "bin", "packing"}.issubset(token_set)
                else " ".join(tokens[:4])
            )
        ]
        candidates.extend(_relational_query_candidates(query))
        return tuple(
            dict.fromkeys(
                candidate for candidate in candidates if candidate
            )
        )

    def search(
        self,
        query: str,
        facet: SearchFacet,
    ) -> Sequence[PriorWork]:
        for query_index, provider_query in enumerate(
            self._query_candidates(query)
        ):
            parameters = {
                "q": provider_query,
                "format": "json",
                "h": str(self.results_per_query),
                "c": "0",
            }
            url = "%s?%s" % (
                self.base_url,
                urllib.parse.urlencode(parameters),
            )
            operation = "search" if query_index == 0 else (
                "search_controlled_vocabulary_%d" % query_index
            )
            payload = self._request(
                url=url,
                operation=operation,
                query=provider_query,
                facet=facet,
            )
            retry_count = 0
            while (
                payload is None
                and self.receipts
                and self.receipts[-1].status
                in (429, 500, 502, 503, 504)
                and retry_count < 2
            ):
                retry_count += 1
                time.sleep(float(retry_count))
                payload = self._request(
                    url=url,
                    operation="%s_retry_%d" % (operation, retry_count),
                    query=provider_query,
                    facet=facet,
                )
            if payload is None:
                continue
            result = payload.get("result", {})
            hits = result.get("hits", {}) if isinstance(result, dict) else {}
            items = hits.get("hit", ()) if isinstance(hits, dict) else ()
            if isinstance(items, dict):
                items = [items]
            works = []
            if isinstance(items, list):
                for item in items:
                    work = self._work_from_hit(item, provider_query, facet)
                    if work is not None:
                        works.append(work)
            self._set_result_count(len(works))
            if works:
                return tuple(works)
        return ()

    def _work_from_hit(
        self,
        item: Any,
        query: str,
        facet: SearchFacet,
    ) -> Optional[PriorWork]:
        if not isinstance(item, dict):
            return None
        info = item.get("info", {})
        if not isinstance(info, dict):
            return None
        title = str(info.get("title", "")).strip().rstrip(".")
        published_year = _year(info.get("year"))
        doi = str(info.get("doi", "")).strip().lower()
        key = str(info.get("key", "")).strip()
        locator = str(
            info.get("ee")
            or info.get("url")
            or ""
        ).strip()
        if not title or published_year is None or not (key or locator):
            return None
        work_id = (
            "doi:%s" % doi
            if doi
            else "dblp:%s" % key
        )
        if locator.startswith("db/"):
            locator = "https://dblp.org/%s" % locator
        elif locator.startswith("https://dblp.org/rec/"):
            locator = locator
        elif not locator:
            locator = "https://dblp.org/rec/%s" % key
        relation, matches = _relation_and_matches(
            query,
            title,
            str(info.get("venue", "")),
            facet,
            self.name,
        )
        return PriorWork(
            work_id=work_id,
            title=title,
            year=published_year,
            locator=locator,
            relation=relation,
            matched_components=matches,
        )

    def citation_neighborhood(
        self,
        work: PriorWork,
    ) -> Sequence[PriorWork]:
        # DBLP does not claim to own citation data. Citation closure is
        # supplied independently by Crossref and Semantic Scholar.
        return ()


class LiveWebPriorArtReviewer:
    """Turns a prior-art plan into a fail-closed, two-provider web survey."""

    name = "live-web-prior-art-reviewer"
    reviewer_version = "v3"
    _REQUIRED_SEARCH_FACETS = (
        SearchFacet.PROBLEM,
        SearchFacet.INTERVENTION,
        SearchFacet.MECHANISM,
        SearchFacet.EVALUATION,
    )

    def __init__(
        self,
        store: ArtifactStore,
        providers: Sequence[_RecordedWebProvider],
    ) -> None:
        self.store = store
        self.providers = tuple(providers)
        if len({provider.name for provider in self.providers}) < 2:
            raise ValueError(
                "live web review requires two independent providers"
            )
        self.last_manifest_digest: Optional[str] = None

    def review(
        self,
        planned: PriorArtAssessment,
    ) -> PriorArtAssessment:
        starts = {
            provider.name: len(provider.receipts)
            for provider in self.providers
        }
        planned_queries = self._planned_queries(planned)
        query_records = []
        live_works: Dict[str, PriorWork] = {}
        query_success: Dict[str, set[str]] = {}
        query_content_success: Dict[str, set[str]] = {}
        query_facets: Dict[str, SearchFacet] = {}
        relational_mappings = []
        search_success: Dict[SearchFacet, set[str]] = {
            facet: set() for facet in self._REQUIRED_SEARCH_FACETS
        }
        for facet, query in planned_queries:
            query_key = "%s:%s" % (facet.value, query)
            query_success.setdefault(query_key, set())
            query_content_success.setdefault(query_key, set())
            query_facets[query_key] = facet
            for provider in self.providers:
                before = len(provider.receipts)
                works = provider.search(query, facet)
                executed_query = (
                    provider.receipts[-1].query
                    if len(provider.receipts) > before
                    else query
                )
                query_records.append(
                    LiteratureQuery(
                        query=executed_query,
                        facet=facet,
                        provider=provider.name,
                    )
                )
                if (
                    len(provider.receipts) > before
                    and provider.receipts[-1].success
                    and works
                ):
                    search_success[facet].add(provider.name)
                    query_success[query_key].add(provider.name)
                    if any(work.abstract.strip() for work in works):
                        query_content_success[query_key].add(
                            provider.name
                        )
                for work in works:
                    relational_mappings.append(
                        {
                            "facet": facet.value,
                            "planned_query": query,
                            "executed_query": executed_query,
                            "provider": provider.name,
                            "work_id": work.work_id,
                            "relation": work.relation.value,
                            "matched_components": list(
                                work.matched_components
                            ),
                        }
                    )
                    live_works[work.work_id] = self._prefer_work(
                        live_works.get(work.work_id),
                        work,
                    )

        incumbent = self._incumbent(planned)
        citation_seeds = tuple(
            work
            for work in planned.closest_works
            if work.work_id.startswith(("doi:", "s2:"))
        )
        citation_success_by_seed: Dict[str, set[str]] = {
            work.work_id: set() for work in citation_seeds
        }
        for seed in citation_seeds:
            for provider in self.providers:
                before = len(provider.receipts)
                neighbors = provider.citation_neighborhood(seed)
                if len(provider.receipts) > before:
                    query_records.append(
                        LiteratureQuery(
                            query=(
                                "citation-neighborhood:%s"
                                % seed.work_id
                            ),
                            facet=SearchFacet.CITATION_NEIGHBORHOOD,
                            provider=provider.name,
                        )
                    )
                    if provider.receipts[-1].success:
                        citation_success_by_seed[seed.work_id].add(
                            provider.name
                        )
                for work in neighbors:
                    live_works[work.work_id] = self._prefer_work(
                        live_works.get(work.work_id),
                        work,
                    )

        for seed in planned.closest_works:
            live_works[seed.work_id] = self._prefer_work(
                live_works.get(seed.work_id),
                seed,
            )
        search_matrix_complete = all(
            len(search_success[facet]) >= 2
            for facet in self._REQUIRED_SEARCH_FACETS
        )
        query_matrix_complete = all(
            len(providers) >= 2
            for providers in query_success.values()
        )
        mechanism_content_complete = all(
            bool(query_content_success[key])
            for key, facet in query_facets.items()
            if facet == SearchFacet.MECHANISM
        )
        closure_complete = (
            search_matrix_complete
            and query_matrix_complete
            and mechanism_content_complete
            and bool(citation_success_by_seed)
            and all(
                len(providers) >= 2
                for providers in citation_success_by_seed.values()
            )
            and any(
                work_id != incumbent.work_id
                for work_id in live_works
            )
        )
        receipts = tuple(
            receipt
            for provider in self.providers
            for receipt in provider.receipts[starts[provider.name] :]
        )
        manifest_value = {
            "schema": 1,
            "subject_id": planned.signature.subject_id,
            "signature_id": planned.signature.signature_id,
            "providers": [
                {
                    "name": provider.name,
                    "version": provider.provider_version,
                }
                for provider in self.providers
            ],
            "receipts": [receipt.as_dict() for receipt in receipts],
            "search_success": {
                facet.value: sorted(search_success[facet])
                for facet in self._REQUIRED_SEARCH_FACETS
            },
            "query_success": {
                key: sorted(query_success[key])
                for key in sorted(query_success)
            },
            "query_content_success": {
                key: sorted(query_content_success[key])
                for key in sorted(query_content_success)
            },
            "mechanism_content_complete": (
                mechanism_content_complete
            ),
            "abstract_work_ids": sorted(
                work.work_id
                for work in live_works.values()
                if work.abstract.strip()
            ),
            "citation_success": sorted(
                {
                    provider
                    for providers in citation_success_by_seed.values()
                    for provider in providers
                }
            ),
            "citation_success_by_seed": {
                seed_id: sorted(citation_success_by_seed[seed_id])
                for seed_id in sorted(citation_success_by_seed)
            },
            "search_matrix_complete": search_matrix_complete,
            "query_matrix_complete": query_matrix_complete,
            "closure_complete": closure_complete,
            "live_work_ids": sorted(live_works),
            "relational_mappings": relational_mappings,
            "local_fixture_counted_toward_closure": False,
        }
        manifest_digest = self.store.put(
            "web_literature_survey_manifest",
            manifest_value,
        )
        self.last_manifest_digest = manifest_digest
        failures = [
            "%s %s failed"
            % (receipt.provider, receipt.operation)
            for receipt in receipts
            if not receipt.success
        ]
        classification = planned.classification
        novel_delta = planned.novel_delta
        web_overlap_note = ""
        if classification == ClaimClassification.NOVEL_CANDIDATE:
            mechanism_tokens = set(_tokens(planned.signature.mechanism))
            generic_tokens = {
                "online",
                "one",
                "dimensional",
                "bin",
                "packing",
                "placement",
                "policy",
                "score",
                "scoring",
            }
            distinguishing_tokens = mechanism_tokens.difference(
                generic_tokens
            )
            candidate_mappings = tuple(
                mapping
                for mapping in relational_mappings
                if mapping["facet"] == SearchFacet.MECHANISM.value
                and mapping["planned_query"]
                == mapping["executed_query"]
                and distinguishing_tokens.intersection(
                    _tokens(str(mapping["planned_query"]))
                )
            )
            if any(
                mapping["relation"]
                == PriorArtRelation.DUPLICATES_CORE.value
                for mapping in candidate_mappings
            ):
                classification = ClaimClassification.REDISCOVERY
                novel_delta = ()
                web_overlap_note = (
                    " Exact candidate-mechanism retrieval duplicated the "
                    "core intervention, so the web evidence downgraded the "
                    "claim to rediscovery."
                )
            elif any(
                mapping["relation"]
                == PriorArtRelation.STRONG_OVERLAP.value
                for mapping in candidate_mappings
            ):
                classification = ClaimClassification.INCREMENTAL_ADVANCE
                web_overlap_note = (
                    " Exact candidate-mechanism retrieval found strong "
                    "overlap, so the web evidence limited the claim to an "
                    "incremental advance."
                )
        rationale = (
            "%s Live retrieval searched Crossref, DBLP, and Semantic "
            "Scholar for problem, intervention, mechanism, and evaluation "
            "facets, then "
            "expanded the reference neighborhoods of every DOI- or Semantic-"
            "Scholar-addressable planned seed. "
            "The bundled prior-art list was retained only to identify the "
            "executable incumbent and did not count toward web closure.%s%s"
            % (
                planned.rationale,
                web_overlap_note,
                (
                    " Retrieval failures: %s." % "; ".join(failures)
                    if failures
                    else ""
                ),
            )
        )
        return PriorArtAssessment(
            signature=planned.signature,
            trigger=planned.trigger,
            queries=tuple(query_records),
            closest_works=tuple(
                live_works[key] for key in sorted(live_works)
            ),
            classification=classification,
            rationale=rationale,
            novel_delta=novel_delta,
            citation_snowball_complete=closure_complete,
            searched_at=_now()[:10],
            reviewer_ref=(
                "%s:%s:%s"
                % (self.name, self.reviewer_version, manifest_digest)
            ),
            executable_incumbent_id=incumbent.work_id,
        )

    @classmethod
    def _planned_queries(
        cls,
        planned: PriorArtAssessment,
    ) -> Tuple[Tuple[SearchFacet, str], ...]:
        selected = []
        observed = set()
        for query in planned.queries:
            if (
                query.facet in cls._REQUIRED_SEARCH_FACETS
                and (query.facet, query.query) not in observed
            ):
                selected.append((query.facet, query.query))
                observed.add((query.facet, query.query))
        signature_fallback = {
            SearchFacet.PROBLEM: planned.signature.problem,
            SearchFacet.INTERVENTION: planned.signature.intervention,
            SearchFacet.MECHANISM: planned.signature.mechanism,
            SearchFacet.EVALUATION: planned.signature.evaluation,
        }
        observed_facets = {facet for facet, _ in selected}
        selected.extend(
            (facet, signature_fallback[facet])
            for facet in cls._REQUIRED_SEARCH_FACETS
            if facet not in observed_facets
        )
        return tuple(selected)

    @staticmethod
    def _incumbent(planned: PriorArtAssessment) -> PriorWork:
        incumbent_id = planned.executable_incumbent_id
        if incumbent_id is None:
            raise ValueError(
                "live review requires an executable published incumbent"
            )
        return next(
            work
            for work in planned.closest_works
            if work.work_id == incumbent_id
        )

    @staticmethod
    def _prefer_work(
        existing: Optional[PriorWork],
        candidate: PriorWork,
    ) -> PriorWork:
        if existing is None:
            return candidate
        relation_rank = {
            PriorArtRelation.DUPLICATES_CORE: 4,
            PriorArtRelation.EXECUTABLE_BASELINE: 3,
            PriorArtRelation.STRONG_OVERLAP: 2,
            PriorArtRelation.ADJACENT: 1,
        }
        candidate_rank = relation_rank[candidate.relation]
        existing_rank = relation_rank[existing.relation]
        if candidate_rank > existing_rank:
            return candidate
        if (
            candidate_rank == existing_rank
            and len(candidate.abstract.strip())
            > len(existing.abstract.strip())
        ):
            return candidate
        return existing


def default_live_web_reviewer(
    store: ArtifactStore,
    *,
    timeout_seconds: float = 20.0,
    results_per_query: int = 6,
    transport: Optional[JsonHttpTransport] = None,
) -> LiveWebPriorArtReviewer:
    return LiveWebPriorArtReviewer(
        store,
        (
            CrossrefWebProvider(
                store,
                transport=transport,
                timeout_seconds=timeout_seconds,
                results_per_query=results_per_query,
            ),
            DblpWebProvider(
                store,
                transport=transport,
                timeout_seconds=timeout_seconds,
                results_per_query=results_per_query,
            ),
            SemanticScholarWebProvider(
                store,
                transport=transport,
                timeout_seconds=timeout_seconds,
                results_per_query=results_per_query,
            ),
        ),
    )
