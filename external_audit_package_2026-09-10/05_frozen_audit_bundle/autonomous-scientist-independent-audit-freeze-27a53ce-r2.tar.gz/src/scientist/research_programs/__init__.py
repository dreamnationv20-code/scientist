"""Concrete high-level research programs."""

from scientist.research_programs.cognitive_core import (
    build_program as build_cognitive_core_program,
    high_level_goal as cognitive_core_goal,
)

__all__ = [
    "build_cognitive_core_program",
    "cognitive_core_goal",
]
