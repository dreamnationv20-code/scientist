from __future__ import annotations

from typing import Dict, Tuple

from scientist.kernel.contracts import (
    MetricDirection,
    MetricSpec,
    ProblemCharter,
)
from scientist.program.contracts import (
    Decomposition,
    DecompositionProposal,
    HighLevelGoal,
    NodeAssessment,
    NodeKind,
    ResearchNode,
)
from scientist.program.manager import ResearchProgramManager


PROGRAM_VERSION = "cognitive-core-research-program-v3-diagnostic-first"
LEGACY_PROGRAM_VERSION = "cognitive-core-research-program-v2-historical"


def legacy_high_level_goal() -> HighLevelGoal:
    """Frozen v2 objective used only to interpret historical checkpoints."""

    return HighLevelGoal(
        name="Compact evidence-grounded cognitive core",
        outcome=(
            "Develop a compact learner that preserves transferable reasoning "
            "and rapid task learning, recognizes missing knowledge, and uses "
            "external evidence reliably while storing less incompressible "
            "factual knowledge in its parameters."
        ),
        scope=(
            "causal training experiments at matched parameter and token budgets",
            "procedural out-of-distribution generalization",
            "oracle and imperfect external evidence use",
            "calibrated abstention and knowledge-boundary recognition",
            "micro-model MiniLab followed by larger open-weight validation",
        ),
        anti_scope=(
            "claiming that zero parametric knowledge is optimal",
            "equating benchmark accuracy with general intelligence",
            "unmatched comparisons across model sizes or compute budgets",
            "human-facing or safety-critical deployment",
            "a one-billion-parameter implementation in the first MiniLab",
        ),
        terminal_metrics=(
            MetricSpec(
                name="cognitive_core_score_delta",
                direction=MetricDirection.MAXIMIZE,
                unit="normalized score",
                aggregation=(
                    "paired geometric-mean delta across procedural "
                    "generalization, evidence use, abstention, and efficiency"
                ),
                primary=True,
            ),
            MetricSpec(
                name="procedural_generalization_delta",
                direction=MetricDirection.MAXIMIZE,
                unit="accuracy fraction",
                aggregation="paired mean across held-out task families",
            ),
            MetricSpec(
                name="evidence_utilization_delta",
                direction=MetricDirection.MAXIMIZE,
                unit="accuracy fraction",
                aggregation="paired mean with oracle and imperfect evidence",
            ),
            MetricSpec(
                name="known_answer_destruction_delta",
                direction=MetricDirection.MINIMIZE,
                unit="accuracy fraction",
                aggregation=(
                    "fraction of correct closed-book answers destroyed by "
                    "added evidence"
                ),
            ),
            MetricSpec(
                name="abstention_brier_delta",
                direction=MetricDirection.MINIMIZE,
                unit="Brier score",
                aggregation="paired mean on answerable/unanswerable probes",
            ),
            MetricSpec(
                name="incompressible_recall_delta",
                direction=MetricDirection.MINIMIZE,
                unit="accuracy fraction",
                aggregation="closed-book random-fact recall delta",
            ),
        ),
        success_definition=(
            "At matched parameter count, training tokens, and inference budget, "
            "a frozen design beats both a monolithic learner and a "
            "knowledgeless/anonymized-data baseline on independent procedural, "
            "evidence-use, and abstention gates while reducing incompressible "
            "closed-book recall."
        ),
        failure_conditions=(
            "reasoning gains disappear after matching compute and data exposure",
            "reduced factual recall does not improve transferable procedures",
            "external evidence causes net accuracy loss or poor calibration",
            "the effect is limited to trained task templates",
            "the claimed gain fails frozen cross-seed replication",
        ),
        integration_requirements=(
            "candidate is reconstructable under a fixed parameter budget",
            "procedural gains transfer to held-out operations and lengths",
            "oracle evidence is used when parametric knowledge is absent",
            "irrelevant or conflicting evidence does not erase known answers",
            "the system abstains or retrieves at calibrated knowledge boundaries",
            "the full result survives frozen multi-seed replication",
        ),
        total_compute_budget=500.0,
        max_parallel_campaigns=3,
        risk_tier="research_only",
    )


def high_level_goal() -> HighLevelGoal:
    return HighLevelGoal(
        name="Compact evidence-grounded cognitive core",
        outcome=(
            "Discover and validate the best division of labor among "
            "parameters, context, external memory, and rapid adaptation so "
            "a compact learner preserves reusable procedures, learns new "
            "tasks quickly, recognizes its knowledge boundaries, and "
            "handles changing evidence better than matched monolithic and "
            "retrieval-augmented controls."
        ),
        scope=(
            "causal training experiments at matched parameter and token budgets",
            "procedural out-of-distribution generalization",
            "oracle and imperfect external evidence use",
            "calibrated abstention and knowledge-boundary recognition",
            "micro-model MiniLab followed by larger open-weight validation",
            "multi-horizon diagnosis of local-to-terminal transfer failures",
            "end-to-end accounting for external memory and adaptation costs",
        ),
        anti_scope=(
            "claiming that zero parametric knowledge is optimal",
            "equating benchmark accuracy with general intelligence",
            "unmatched comparisons across model sizes or compute budgets",
            "human-facing or safety-critical deployment",
            "a one-billion-parameter implementation in the first MiniLab",
            "assuming that reduced factual recall is intrinsically beneficial",
            "using one scalar score to conceal a collapsed capability",
        ),
        terminal_metrics=(
            MetricSpec(
                name="cognitive_core_pareto_gate",
                direction=MetricDirection.TARGET,
                unit="binary gate",
                aggregation=(
                    "all frozen capability floors and matched-cost criteria"
                ),
                primary=True,
                target=1.0,
            ),
            MetricSpec(
                name="procedural_generalization_delta",
                direction=MetricDirection.MAXIMIZE,
                unit="accuracy fraction",
                aggregation="paired mean across held-out task families",
            ),
            MetricSpec(
                name="rapid_task_learning_delta",
                direction=MetricDirection.MAXIMIZE,
                unit="normalized sample-efficiency score",
                aggregation="paired mean across unseen task families",
            ),
            MetricSpec(
                name="evidence_utilization_delta",
                direction=MetricDirection.MAXIMIZE,
                unit="accuracy fraction",
                aggregation="paired mean with oracle and imperfect evidence",
            ),
            MetricSpec(
                name="known_answer_destruction_delta",
                direction=MetricDirection.MINIMIZE,
                unit="accuracy fraction",
                aggregation=(
                    "fraction of correct closed-book answers destroyed by "
                    "added evidence"
                ),
            ),
            MetricSpec(
                name="knowledge_boundary_utility_delta",
                direction=MetricDirection.MAXIMIZE,
                unit="decision utility",
                aggregation="paired answer, retrieve, clarify, or abstain utility",
            ),
            MetricSpec(
                name="knowledge_update_retention_delta",
                direction=MetricDirection.MAXIMIZE,
                unit="accuracy fraction",
                aggregation="paired update accuracy with unrelated-skill retention",
            ),
            MetricSpec(
                name="end_to_end_system_cost_delta",
                direction=MetricDirection.MINIMIZE,
                unit="normalized resource cost",
                aggregation=(
                    "parameters, training, context, retrieval, external "
                    "storage, inference, and adaptation"
                ),
            ),
        ),
        success_definition=(
            "At matched end-to-end system cost, a frozen design satisfies "
            "every procedural, rapid-learning, knowledge-boundary, evidence, "
            "update, and retention floor and Pareto-improves over both a "
            "monolithic learner and a strong retrieval-augmented learner on "
            "independent task families and model configurations."
        ),
        failure_conditions=(
            "gains disappear after matching total system rather than model-only cost",
            "any essential capability falls below its frozen non-regression floor",
            "external evidence causes net decision-utility loss or poor calibration",
            "the effect is limited to trained task templates",
            "the claimed gain fails frozen cross-seed replication",
        ),
        integration_requirements=(
            "candidate is reconstructable under a fixed total system budget",
            "procedural gains transfer to held-out operations and lengths",
            "new procedures are acquired more efficiently on unseen task families",
            "oracle evidence is used when parametric knowledge is absent",
            "irrelevant or conflicting evidence does not erase known answers",
            "the system abstains or retrieves at calibrated knowledge boundaries",
            "updates alter targeted knowledge without destroying unrelated skills",
            "the full result survives frozen multi-seed replication",
        ),
        total_compute_budget=500.0,
        max_parallel_campaigns=3,
        risk_tier="research_only",
    )


def research_nodes(
    goal: HighLevelGoal,
) -> Dict[str, ResearchNode]:
    laboratory = ResearchNode(
        goal_id=goal.goal_id,
        title="Cognitive Core MiniLab validity",
        question=(
            "Can a deterministic, leakage-resistant micro-model laboratory "
            "separately measure parametric recall, procedural "
            "generalization, evidence use, distraction, and abstention?"
        ),
        kind=NodeKind.ENGINEERING_ENABLER,
        rationale=(
            "Without separable measurements, apparent cognitive gains can "
            "be benchmark leakage or a hidden knowledge/compute trade."
        ),
        acceptance_conditions=(
            "generators have disjoint train, guard, audit, and replication IDs",
            "an independent verifier reconstructs every metric",
            "seeded training and evaluation are reproducible",
            "seeded positive and negative controls are detected",
        ),
        falsification_conditions=(
            "a partition collision or metric leakage is detected",
            "the same seed and contract produce different observations",
            "a deliberately memorizing control scores as procedural transfer",
        ),
        expected_artifact="conforming MiniLab domain adapter and qualification",
        estimated_compute=5.0,
        critical=True,
        tags=("laboratory", "measurement", "prerequisite"),
    )
    phenomenon = ResearchNode(
        goal_id=goal.goal_id,
        title="Matched memorization–procedure trade-off",
        question=(
            "At fixed parameters, training tokens, optimizer steps, and "
            "data exposure, does increasing incompressible factual load "
            "causally reduce held-out procedural learning?"
        ),
        kind=NodeKind.SCIENTIFIC_QUESTION,
        rationale=(
            "This is the minimal causal version of the claim that factual "
            "memorization distracts a compact cognitive core."
        ),
        acceptance_conditions=(
            "procedural generalization declines monotonically with random-fact load",
            "fact recall rises under the same matched contract",
            "the trade-off replicates across seeds and at least two model sizes",
        ),
        falsification_conditions=(
            "procedural performance is invariant after matched controls",
            "the effect is explained by fewer procedural training examples",
            "the effect reverses on untouched operations or lengths",
        ),
        expected_artifact="frozen causal load-response claim",
        prerequisite_ids=(laboratory.node_id,),
        estimated_compute=40.0,
        critical=False,
        tags=("memorization", "procedure", "causal"),
    )
    routing_phenomenon = ResearchNode(
        goal_id=goal.goal_id,
        title="Memory-to-context compositional routing",
        question=(
            "Can a compact learner preserve a correct incompressible "
            "memory under irrelevant context while using relevant or "
            "updating evidence and abstaining when neither source answers?"
        ),
        kind=NodeKind.BOTTLENECK,
        rationale=(
            "The first matched MiniLab refuted a simple procedure-capacity "
            "penalty but exposed severe known-answer destruction under "
            "irrelevant evidence."
        ),
        acceptance_conditions=(
            "closed-book memory remains above the frozen retention gate",
            "irrelevant context has bounded known-answer destruction",
            "oracle and updating evidence remain usable",
            "the phenomenon replicates on fresh fact mappings and key sets",
        ),
        falsification_conditions=(
            "the effect disappears under a unified query format",
            "the failure is explained by answerability labels or key-range shortcuts",
            "fresh task worlds do not reproduce the routing gap",
        ),
        expected_artifact="frozen memory/evidence routing claim",
        prerequisite_ids=(laboratory.node_id,),
        estimated_compute=45.0,
        critical=True,
        tags=("memory", "routing", "context", "causal"),
    )
    capacity = ResearchNode(
        goal_id=goal.goal_id,
        title="Representational-capacity competition",
        question=(
            "Is any memorization–procedure trade-off caused by finite "
            "representational capacity rather than training dynamics?"
        ),
        kind=NodeKind.BOTTLENECK,
        rationale=(
            "A capacity mechanism predicts a shifted load-response boundary "
            "with width and a persistent effect after schedule matching."
        ),
        acceptance_conditions=(
            "the critical fact-load boundary shifts systematically with model width",
            "extra optimization does not remove the matched trade-off",
        ),
        falsification_conditions=(
            "width does not move the boundary",
            "schedule or regularization removes the effect at fixed width",
        ),
        expected_artifact="capacity scaling law and falsifiable boundary",
        prerequisite_ids=(phenomenon.node_id,),
        estimated_compute=80.0,
        critical=False,
        alternative_group="memorization_procedure_mechanism",
        tags=("capacity", "scaling"),
    )
    kinetics = ResearchNode(
        goal_id=goal.goal_id,
        title="Circuit-kinetics and curriculum competition",
        question=(
            "Is the trade-off caused by in-weights memorization circuits "
            "outcompeting generalizable in-context or procedural circuits "
            "during training?"
        ),
        kind=NodeKind.BOTTLENECK,
        rationale=(
            "Prior synthetic-transformer work reports distinct memorization "
            "and generalization phases and transient in-context learning."
        ),
        acceptance_conditions=(
            "training order or regularization changes procedural persistence",
            "matched checkpoints show a generalization-to-memorization transition",
        ),
        falsification_conditions=(
            "curriculum and regularization do not move the trade-off",
            "no distinct temporal regimes appear across seeds",
        ),
        expected_artifact="checkpoint-level causal kinetics claim",
        prerequisite_ids=(phenomenon.node_id,),
        estimated_compute=70.0,
        critical=False,
        alternative_group="memorization_procedure_mechanism",
        tags=("optimization", "curriculum", "circuits"),
    )
    evidence_use = ResearchNode(
        goal_id=goal.goal_id,
        title="External-evidence utilization bottleneck",
        question=(
            "When factual memory is suppressed, what training signal lets a "
            "compact core use oracle evidence, ignore distractors, preserve "
            "known answers, and retrieve or abstain appropriately?"
        ),
        kind=NodeKind.CAPABILITY,
        rationale=(
            "Removing memory is not useful if the small model cannot consume "
            "retrieved evidence or is distracted by context."
        ),
        acceptance_conditions=(
            "oracle evidence closes most of the absent-knowledge gap",
            "irrelevant evidence has bounded known-answer destruction",
            "retrieval and abstention decisions are calibrated",
        ),
        falsification_conditions=(
            "oracle evidence remains unused",
            "context causes a net accuracy loss",
            "confidence fails to distinguish answerable cases",
        ),
        expected_artifact="evidence-use training and routing candidate",
        prerequisite_ids=(routing_phenomenon.node_id,),
        estimated_compute=90.0,
        critical=True,
        alternative_group="cognitive_core_design",
        tags=("retrieval", "abstention", "calibration"),
    )
    curriculum = ResearchNode(
        goal_id=goal.goal_id,
        title="Minimal useful parametric curriculum",
        question=(
            "Which compressible concepts and linguistic or algorithmic "
            "primitives must remain parametric for reasoning and evidence "
            "use, and which entity-linked facts should be externalized?"
        ),
        kind=NodeKind.SCIENTIFIC_QUESTION,
        rationale=(
            "The strongest hypothesis is probably selective memory, not "
            "literal knowledgelessness."
        ),
        acceptance_conditions=(
            "a selective curriculum Pareto-dominates both all-memory and no-memory controls",
            "the retained knowledge classes predict cross-task transfer",
        ),
        falsification_conditions=(
            "zero-knowledge or monolithic training remains Pareto-optimal",
            "the selected curriculum fails outside trained task templates",
        ),
        expected_artifact="minimal curriculum and inclusion rule",
        prerequisite_ids=(routing_phenomenon.node_id,),
        estimated_compute=100.0,
        critical=True,
        alternative_group="cognitive_core_design",
        tags=("curriculum", "knowledge", "abstraction"),
    )
    integration = ResearchNode(
        goal_id=goal.goal_id,
        title="Integrated cognitive-core candidate",
        question=(
            "Does the best frozen training and memory design improve the "
            "complete terminal score under independent evaluation?"
        ),
        kind=NodeKind.INTEGRATION,
        rationale=(
            "Local memorization, reasoning, or retrieval improvements do not "
            "establish a useful cognitive core unless they work together."
        ),
        acceptance_conditions=goal.integration_requirements,
        falsification_conditions=goal.failure_conditions,
        expected_artifact="frozen integrated candidate and terminal claim",
        prerequisite_ids=(
            evidence_use.node_id,
            curriculum.node_id,
        ),
        estimated_compute=100.0,
        critical=True,
        tags=("integration", "replication"),
    )
    return {
        "laboratory": laboratory,
        "phenomenon": phenomenon,
        "routing_phenomenon": routing_phenomenon,
        "capacity": capacity,
        "kinetics": kinetics,
        "evidence_use": evidence_use,
        "curriculum": curriculum,
        "integration": integration,
    }


def _assessment(
    node: ResearchNode,
    relevance: float,
    bottleneck: float,
    tractability: float,
    information: float,
    leverage: float,
    basis: Tuple[str, ...],
) -> NodeAssessment:
    return NodeAssessment(
        node_id=node.node_id,
        goal_relevance=relevance,
        bottleneck_probability=bottleneck,
        tractability=tractability,
        expected_information_gain=information,
        integration_leverage=leverage,
        estimated_cost=node.estimated_compute,
        basis=basis,
        assessor_ref=PROGRAM_VERSION + ":literature-grounded-assessment-v1",
    )


def decomposition_proposals(
    goal: HighLevelGoal,
) -> Tuple[DecompositionProposal, ...]:
    nodes = research_nodes(goal)
    shared = (nodes["laboratory"],)
    source_basis = (
        "Karpathy cognitive-core formulation, October 2025",
        "Chan et al. 2022 in-context/in-weights trade-off",
        "Singh et al. 2023 transient in-context learning",
        "Gibson et al. 2026 memorization/generalization phases",
        "Cohen et al. 2026 knowledgeless language models",
        "Pandey et al. 2026 small-model retrieval utilization",
    )
    laboratory_assessment = _assessment(
        nodes["laboratory"],
        1.0,
        1.0,
        0.95,
        0.9,
        1.0,
        source_basis,
    )
    phenomenon_assessment = _assessment(
        nodes["phenomenon"],
        1.0,
        0.9,
        0.85,
        1.0,
        0.95,
        source_basis,
    )
    routing_assessment = _assessment(
        nodes["routing_phenomenon"],
        1.0,
        0.95,
        0.9,
        1.0,
        1.0,
        source_basis
        + (
            (
                "replicated KAFT-style MiniLab routing rediscovery, "
                "July 2026"
            ),
        ),
    )
    definitions = (
        (
            "Finite-capacity decomposition",
            (
                "Incompressible facts consume finite representational "
                "capacity that would otherwise implement transferable "
                "procedures."
            ),
            nodes["capacity"],
            (
                "Increasing width shifts the factual-load point at which "
                "procedural generalization degrades."
            ),
            (0.8, 0.75, 0.9, 0.8),
        ),
        (
            "Circuit-kinetics decomposition",
            (
                "Memorization circuits win an optimization competition over "
                "generalizing circuits even before hard capacity is reached."
            ),
            nodes["kinetics"],
            (
                "Curriculum, stopping time, or regularization preserves "
                "procedural generalization without adding parameters."
            ),
            (0.75, 0.8, 0.95, 0.8),
        ),
        (
            "Externalized-knowledge decomposition",
            (
                "A compact core is limited primarily by evidence utilization "
                "and epistemic routing after factual knowledge is externalized."
            ),
            nodes["evidence_use"],
            (
                "Evidence-use and abstention training closes the oracle "
                "retrieval gap and prevents context distraction."
            ),
            (0.95, 0.7, 0.9, 1.0),
        ),
        (
            "Selective-curriculum decomposition",
            (
                "Reasoning and knowledge are partly entangled; a useful core "
                "needs compressible primitives but should externalize "
                "entity-linked incompressible facts."
            ),
            nodes["curriculum"],
            (
                "An intermediate structured curriculum Pareto-dominates both "
                "monolithic and fully knowledgeless training."
            ),
            (0.95, 0.65, 0.9, 1.0),
        ),
    )
    proposals = []
    for index, (
        name,
        causal_model,
        distinctive_node,
        prediction,
        assessment_values,
    ) in enumerate(definitions):
        trunk_node = (
            nodes["phenomenon"]
            if index < 2
            else nodes["routing_phenomenon"]
        )
        proposal_nodes = shared + (trunk_node, distinctive_node)
        if distinctive_node.node_id == nodes["curriculum"].node_id:
            proposal_nodes += (nodes["integration"],)
        decomposition = Decomposition(
            goal_id=goal.goal_id,
            name=name,
            causal_model=causal_model,
            assumptions=(
                "the MiniLab metrics isolate procedures from factual recall",
                "effects at micro scale are diagnostic, not direct evidence at one billion parameters",
                "matched compute and exposure remove trivial data-allocation explanations",
            ),
            node_ids=tuple(node.node_id for node in proposal_nodes),
            distinguishing_predictions=(prediction,),
            decomposer_ref=PROGRAM_VERSION,
        )
        distinctive_assessment = _assessment(
            distinctive_node,
            relevance=assessment_values[0],
            bottleneck=assessment_values[1],
            tractability=assessment_values[2],
            information=assessment_values[3],
            leverage=assessment_values[0],
            basis=source_basis,
        )
        assessments = (distinctive_assessment,)
        if index == 0:
            assessments = (
                laboratory_assessment,
                phenomenon_assessment,
            ) + assessments
        elif index == 2:
            assessments = (routing_assessment,) + assessments
        if distinctive_node.node_id == nodes["curriculum"].node_id:
            assessments += (
                _assessment(
                    nodes["integration"],
                    relevance=1.0,
                    bottleneck=1.0,
                    tractability=0.5,
                    information=0.95,
                    leverage=1.0,
                    basis=source_basis,
                ),
            )
        proposals.append(
            DecompositionProposal(
                decomposition=decomposition,
                nodes=proposal_nodes,
                initial_assessments=assessments,
            )
        )
    return tuple(proposals)


def build_legacy_program() -> ResearchProgramManager:
    """Build the frozen v2 graph for replay and historical interpretation."""

    goal = legacy_high_level_goal()
    manager = ResearchProgramManager(
        goal,
        manager_ref=LEGACY_PROGRAM_VERSION,
    )
    for proposal in decomposition_proposals(goal):
        manager.register_decomposition(proposal)
    return manager


def build_program() -> ResearchProgramManager:
    """Backward-compatible alias for the historical v2 program.

    Fresh work must enter through
    ``scientist.domains.cognitive_core.goal_program.build_control_plane``.
    """

    return build_legacy_program()


def minilab_charter() -> ProblemCharter:
    goal = high_level_goal()
    node = research_nodes(goal)["laboratory"]
    return ProblemCharter(
        name=node.title,
        statement=node.question,
        domain_id="cognitive_core_minilab",
        scope=(
            "seeded synthetic symbolic tasks",
            "micro-model training on a single local computer",
            "separate procedural, fact, evidence, and abstention probes",
        ),
        anti_scope=(
            "natural-language competence claims",
            "one-billion-parameter scaling claims",
            "human cognition equivalence",
            "benchmark-only breakthrough claims",
        ),
        metrics=(
            MetricSpec(
                name="qualification_checks_passed",
                direction=MetricDirection.TARGET,
                unit="checks",
                aggregation="all required independent checks",
                primary=True,
                target=1.0,
            ),
        ),
        success_definition=(
            "All partition, determinism, independent-verification, and "
            "positive/negative-control checks pass."
        ),
        falsification_conditions=node.falsification_conditions,
        risk_tier="research_only",
    )
