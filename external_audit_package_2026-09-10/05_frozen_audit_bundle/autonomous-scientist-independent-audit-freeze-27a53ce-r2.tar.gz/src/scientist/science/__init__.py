"""Domain-independent scientific contracts and inference utilities."""

from importlib import import_module
from typing import Any


_PROTOCOL_EXPORTS = {
    "EvidenceProvenanceContract",
    "ExpectedRange",
    "PredictionAssessment",
    "ProbeAssessment",
    "ProbeDisposition",
    "ProbeOutcomeRule",
    "ProbeProtocol",
    "assess_probe",
}
_REVIEW_EXPORTS = {
    "AdversarialReviewProtocol",
    "BoundedReviewCapPolicy",
    "IssueDisposition",
    "IssueResponse",
    "IssueSeverity",
    "ReviewIssue",
    "ReviewRound",
    "ReviewCapDecision",
    "ReviewCapDisposition",
    "ReviewTargetStatus",
    "resolve_review_round",
    "resolve_bounded_review_cap",
}
_HYPOTHESIS_FORGE_EXPORTS = {
    "ForgeBackedCausalHypothesisGenerator",
    "ForgedCausalHypothesis",
    "HypothesisForgeBrief",
    "HypothesisForgePortfolio",
    "HypothesisForgeProposer",
    "OpportunityKind",
    "PrimarySourceSpan",
    "ResearchOpportunity",
    "StructuralProblemSignature",
    "StructuralTransferMapping",
}

__all__ = sorted(_PROTOCOL_EXPORTS | _REVIEW_EXPORTS | _HYPOTHESIS_FORGE_EXPORTS)


def __getattr__(name: str) -> Any:
    if name in _PROTOCOL_EXPORTS:
        module_name = "scientist.science.protocols"
    elif name in _REVIEW_EXPORTS:
        module_name = "scientist.science.review"
    elif name in _HYPOTHESIS_FORGE_EXPORTS:
        module_name = "scientist.science.hypothesis_forge"
    else:
        raise AttributeError(name)
    value = getattr(import_module(module_name), name)
    globals()[name] = value
    return value
