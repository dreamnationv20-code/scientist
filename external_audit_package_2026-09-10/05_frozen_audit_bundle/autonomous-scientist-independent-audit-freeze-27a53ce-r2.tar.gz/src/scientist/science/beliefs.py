from __future__ import annotations

import math
from typing import Dict, Mapping


LOSS_POSTERIOR_RULE = "normalized prior * exp(-temperature * cumulative_loss)"


def loss_posterior(
    priors: Mapping[str, float],
    cumulative_losses: Mapping[str, float],
    temperature: float = 1.0,
) -> Dict[str, float]:
    """Return generalized-Bayes weights; these are not truth probabilities."""
    if not priors:
        raise ValueError("at least one prior is required")
    if temperature <= 0.0:
        raise ValueError("temperature must be positive")
    if set(priors) != set(cumulative_losses):
        raise ValueError("priors and cumulative_losses must have the same keys")
    if any(value <= 0.0 for value in priors.values()):
        raise ValueError("priors must be positive")
    if any(value < 0.0 for value in cumulative_losses.values()):
        raise ValueError("losses must be non-negative")

    log_weights = {
        key: math.log(priors[key]) - temperature * cumulative_losses[key]
        for key in priors
    }
    largest = max(log_weights.values())
    unnormalized = {
        key: math.exp(value - largest) for key, value in log_weights.items()
    }
    total = sum(unnormalized.values())
    return {
        key: unnormalized[key] / total
        for key in sorted(unnormalized)
    }


def entropy(weights: Mapping[str, float]) -> float:
    return -sum(
        weight * math.log(weight)
        for weight in weights.values()
        if weight > 0.0
    )
