from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.kernel.conformance import AdapterConformanceReport, check_adapter_conformance
from scientist.kernel.contracts import EvidencePartition, GateContract
from scientist.kernel.domain_registry import ScientificDomainBundle
from scientist.kernel.interfaces import (
    EvidenceRequest,
    ExperimentRequest,
    ProposalContext,
    ResearchObjectProposalContext,
)
from scientist.kernel.evidence import (
    EvidenceSummary,
    MeasurementRecord,
    analyze_measurements,
    evaluate_measurements,
)
from scientist.kernel.gates import GateDecision, evaluate_gate
from scientist.kernel.ledger import LedgerEventKind, ScientificLedger
from scientist.science.protocols import (
    ProbeAssessment,
    ProbeProtocol,
    assess_probe,
)
from scientist.science.review import (
    AdversarialReviewProtocol,
    ReviewRound,
    ReviewTargetStatus,
)


GENERIC_CAMPAIGN_RUNTIME_VERSION = "problem-agnostic-leaf-campaign-v1"


@dataclass(frozen=True)
class CampaignEvaluation:
    candidate_id: str
    control_id: Optional[str]
    control_ids: Tuple[str, ...]
    partition: EvidencePartition
    measurement_ids: Tuple[str, ...]
    evidence_summary: EvidenceSummary
    gate_decision: GateDecision
    artifact_ids: Tuple[str, ...]
    probe_assessment: Optional[ProbeAssessment] = None

    @property
    def research_object_id(self) -> str:
        return self.candidate_id

    @property
    def protocol_id(self) -> Optional[str]:
        return (
            None
            if self.probe_assessment is None
            else self.probe_assessment.protocol_id
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "research_object_id": self.research_object_id,
            "control_id": self.control_id,
            "control_ids": list(self.control_ids),
            "partition": self.partition.value,
            "measurement_ids": list(self.measurement_ids),
            "evidence_summary": self.evidence_summary.as_dict(),
            "gate_decision": self.gate_decision.as_dict(),
            "artifact_ids": list(self.artifact_ids),
            "protocol_id": self.protocol_id,
            "probe_assessment": (
                None
                if self.probe_assessment is None
                else self.probe_assessment.as_dict()
            ),
        }


class ScientificCampaignRuntime:
    """Generic executable leaf for optimization and non-optimization domains."""

    def __init__(
        self,
        domain: ScientificDomainBundle,
        artifact_root: Path,
        *,
        cycle_label: str = "generic-campaign",
    ) -> None:
        self.domain = domain
        self.adapter = domain.adapter
        self.store = ArtifactStore(Path(artifact_root))
        fixture = domain.fixture_factory()
        self.conformance: AdapterConformanceReport = check_adapter_conformance(
            self.adapter,
            fixture.candidate,
            fixture.control,
            fixture.experiment,
            controls=fixture.controls,
        )
        if not self.conformance.passed:
            raise ValueError("domain bundle failed adapter conformance")
        control_ids = tuple(
            self.adapter.candidate_id(control)
            for control in fixture.resolved_controls
        )
        self.charter = domain.charter_factory()
        self.contract = domain.build_campaign(control_ids)
        if self.contract.evidence_analysis is None:
            raise ValueError(
                "generic campaigns require an evidence analysis contract"
            )
        primary_metrics = {
            metric.name for metric in self.charter.metrics if metric.primary
        }
        if self.contract.evidence_analysis.primary_metric not in primary_metrics:
            raise ValueError(
                "campaign evidence analysis and charter primary metric disagree"
            )
        self.cycle_id = "%s-%s" % (
            cycle_label,
            content_digest(
                {
                    "runtime": GENERIC_CAMPAIGN_RUNTIME_VERSION,
                    "domain_id": domain.domain_id,
                    "campaign_id": self.contract.campaign_id,
                }
            )[:24],
        )
        self.ledger = ScientificLedger(self.store)
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CYCLE_STARTED,
            {
                "runtime_version": GENERIC_CAMPAIGN_RUNTIME_VERSION,
                "domain_id": domain.domain_id,
                "capability_manifest_id": domain.capability_manifest.manifest_id,
            },
            "generic-campaign-runtime",
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CHARTER_REGISTERED,
            {"charter_id": self.charter.charter_id},
            "generic-campaign-runtime",
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CAMPAIGN_REGISTERED,
            {"campaign_id": self.contract.campaign_id},
            "generic-campaign-runtime",
        )
        self._registered_candidates = set()
        self._probe_protocols: Dict[str, ProbeProtocol] = {}
        self._probe_evidence: Dict[str, Tuple[Any, ...]] = {}
        self._assessed_probe_ids = set()
        self._review_protocols: Dict[str, AdversarialReviewProtocol] = {}
        self._review_rounds: Dict[str, Tuple[ReviewRound, ...]] = {}

    def register_review_protocol(
        self,
        protocol: AdversarialReviewProtocol,
    ) -> str:
        """Register the typed information barrier for a research object."""

        if protocol.target_id not in self._registered_candidates:
            raise ValueError(
                "review protocol requires a registered research object"
            )
        if protocol.protocol_id in self._review_protocols:
            raise ValueError("review protocol is already registered")
        artifact_id = self.store.put(
            "adversarial_review_protocol",
            protocol.as_dict(),
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.REVIEW_PROTOCOL_REGISTERED,
            {
                "candidate_id": protocol.target_id,
                "protocol_id": protocol.protocol_id,
                "protocol_artifact_id": artifact_id,
            },
            protocol.orchestrator_ref,
        )
        self._review_protocols[protocol.protocol_id] = protocol
        self._review_rounds[protocol.protocol_id] = ()
        return protocol.protocol_id

    def record_review_round(self, review_round: ReviewRound) -> str:
        """Persist one complete, sequential issue/response exchange."""

        protocol = self._review_protocols.get(review_round.protocol_id)
        if protocol is None:
            raise ValueError("review protocol is not registered")
        if review_round.target_id != protocol.target_id:
            raise ValueError("review round names another research object")
        previous = self._review_rounds[protocol.protocol_id]
        if review_round.round_index != len(previous) + 1:
            raise ValueError("review rounds must be recorded in order")
        if previous:
            if previous[-1].target_status == ReviewTargetStatus.DEAD:
                raise ValueError("a retired research object cannot be reviewed")
            if (
                review_round.target_version_before
                != previous[-1].target_version_after
            ):
                raise ValueError("review round breaks the target version chain")
        artifact_id = self.store.put(
            "adversarial_review_round",
            review_round.as_dict(),
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.ADVERSARIAL_REVIEW_COMPLETED,
            {
                "candidate_id": protocol.target_id,
                "protocol_id": protocol.protocol_id,
                "round_id": review_round.round_id,
                "round_index": review_round.round_index,
                "target_status": review_round.target_status.value,
                "review_artifact_id": artifact_id,
            },
            protocol.orchestrator_ref,
        )
        self._review_rounds[protocol.protocol_id] = (*previous, review_round)
        return review_round.round_id

    def preregister_probe(self, protocol: ProbeProtocol) -> str:
        """Freeze a complete evidence protocol before generating its tasks."""

        if protocol.campaign_id != self.contract.campaign_id:
            raise ValueError("probe protocol belongs to another campaign")
        if protocol.research_object_id not in self._registered_candidates:
            raise ValueError(
                "probe protocol requires a registered research object"
            )
        gate = next(
            (
                item
                for item in self.contract.gates
                if item.contract_id == protocol.gate_contract_id
            ),
            None,
        )
        if (
            gate is None
            or gate.evidence_partition
            != protocol.evidence_request.partition
        ):
            raise ValueError("probe gate and evidence partition are undeclared")
        self._require_evidence_budget(
            protocol.evidence_request.partition,
            protocol.evidence_request.count,
        )
        if protocol.protocol_id in self._probe_protocols:
            raise ValueError("probe protocol is already registered")
        artifact_id = self.store.put(
            "domain_probe_protocol",
            protocol.as_dict(),
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.PROBE_PREREGISTERED,
            {
                "candidate_id": protocol.research_object_id,
                "protocol_id": protocol.protocol_id,
                "request_id": protocol.evidence_request.request_id,
                "gate_contract_id": protocol.gate_contract_id,
                "protocol_artifact_id": artifact_id,
            },
            protocol.registered_by,
        )
        self._probe_protocols[protocol.protocol_id] = protocol
        return protocol.protocol_id

    def generate_preregistered_evidence(
        self,
        protocol_id: str,
    ) -> Tuple[Any, ...]:
        """Generate exactly the tasks named by an immutable probe protocol."""

        protocol = self._probe_protocols.get(protocol_id)
        if protocol is None:
            raise ValueError("probe protocol is not registered")
        if protocol_id in self._probe_evidence:
            raise ValueError("probe evidence was already generated")
        evidence = self.generate_evidence(protocol.evidence_request)
        self._probe_evidence[protocol_id] = evidence
        return evidence

    def evaluate_preregistered(
        self,
        protocol_id: str,
        research_object: Any,
        *,
        controls: Sequence[Any] = (),
    ) -> CampaignEvaluation:
        """Execute frozen evidence, apply frozen bars, and surface surprises."""

        protocol = self._probe_protocols.get(protocol_id)
        if protocol is None:
            raise ValueError("probe protocol is not registered")
        if protocol_id in self._assessed_probe_ids:
            raise ValueError("probe protocol was already assessed")
        evidence_tasks = self._probe_evidence.get(protocol_id)
        if evidence_tasks is None:
            raise ValueError("probe evidence must be generated before evaluation")
        if self.adapter.candidate_id(research_object) != protocol.research_object_id:
            raise ValueError("probe protocol names another research object")
        evaluation = self.evaluate_research_object(
            research_object,
            evidence_tasks,
            partition=protocol.evidence_request.partition,
            gate_contract_id=protocol.gate_contract_id,
            controls=controls,
        )
        assessment_metrics = dict(evaluation.evidence_summary.metrics)
        assessment_metrics.update(
            {
                item.metric: item.observed
                for item in evaluation.gate_decision.results
            }
        )
        assessment = assess_probe(
            protocol,
            assessment_metrics,
            gate_passed=evaluation.gate_decision.passed,
        )
        assessment_artifact = self.store.put(
            "domain_probe_assessment",
            assessment.as_dict(),
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.PROBE_ASSESSED,
            {
                "candidate_id": protocol.research_object_id,
                "protocol_id": protocol_id,
                "assessment_id": assessment.assessment_id,
                "disposition": assessment.disposition.value,
                "surprising_metrics": list(assessment.surprising_metrics),
            },
            self.adapter.verifier_ref,
        )
        self._assessed_probe_ids.add(protocol_id)
        return CampaignEvaluation(
            candidate_id=evaluation.candidate_id,
            control_id=evaluation.control_id,
            control_ids=evaluation.control_ids,
            partition=evaluation.partition,
            measurement_ids=evaluation.measurement_ids,
            evidence_summary=evaluation.evidence_summary,
            gate_decision=evaluation.gate_decision,
            artifact_ids=(*evaluation.artifact_ids, assessment_artifact),
            probe_assessment=assessment,
        )

    def generate_experiments(
        self,
        request: ExperimentRequest,
    ) -> Tuple[Any, ...]:
        """Generate an identity-checked batch through the registered bundle."""

        self._require_evidence_budget(request.partition, request.count)
        return self.domain.generate_experiments(request)

    def generate_evidence(
        self,
        request: EvidenceRequest,
    ) -> Tuple[Any, ...]:
        """Generate proof tasks, datasets, probes, or trials without seed assumptions."""

        self._require_evidence_budget(request.partition, request.count)
        return self.domain.generate_evidence(request)

    def _require_evidence_budget(
        self,
        partition: EvidencePartition,
        count: int,
    ) -> None:
        declared = self.contract.budget.evidence_budget(partition)
        if declared <= 0 or count > declared:
            raise ValueError(
                "evidence request exceeds the declared partition budget"
            )

    def proposal_engine(self, discovery_channel: str) -> Any:
        channel_ids = {
            item.channel_id
            for item in self.contract.resolved_discovery_channels
        }
        if discovery_channel not in channel_ids:
            raise ValueError("proposal engine uses an undeclared channel")
        return self.domain.proposal_engine(discovery_channel)

    def generate_proposals(
        self,
        discovery_channel: str,
        context: ProposalContext,
    ) -> Tuple[Any, ...]:
        """Generate a bounded, identity-checked batch through the bundle."""

        if context.cycle_id != self.cycle_id:
            raise ValueError("proposal context belongs to another campaign")
        family = getattr(context.family, "value", context.family)
        if str(family) != discovery_channel:
            raise ValueError("proposal context and discovery channel disagree")
        declared = self.contract.budget.proposal_budget(discovery_channel)
        if declared <= 0 or context.evaluation_budget > declared:
            raise ValueError("proposal context exceeds the channel budget")
        engine = self.proposal_engine(discovery_channel)
        candidates = tuple(engine.propose(context))
        if not candidates:
            raise ValueError("proposal engine returned no candidates")
        if len(candidates) > context.evaluation_budget:
            raise ValueError("proposal engine exceeded its evaluation budget")
        identities = tuple(
            self.adapter.candidate_id(candidate) for candidate in candidates
        )
        if len(set(identities)) != len(identities):
            raise ValueError("proposal engine returned duplicate candidates")
        return candidates

    def generate_research_objects(
        self,
        discovery_channel: str,
        context: ResearchObjectProposalContext,
    ) -> Tuple[Any, ...]:
        """Generate artifacts, proofs, models, datasets, or hypotheses."""

        if context.cycle_id != self.cycle_id:
            raise ValueError("proposal context belongs to another campaign")
        if context.discovery_channel != discovery_channel:
            raise ValueError("proposal context and discovery channel disagree")
        declared = self.contract.budget.proposal_budget(discovery_channel)
        if declared <= 0 or context.evaluation_budget > declared:
            raise ValueError("proposal context exceeds the channel budget")
        engine = self.proposal_engine(discovery_channel)
        research_objects = tuple(engine.propose(context))
        if not research_objects:
            raise ValueError("proposal engine returned no research objects")
        if len(research_objects) > context.evaluation_budget:
            raise ValueError("proposal engine exceeded its evaluation budget")
        identities = tuple(
            self.adapter.candidate_id(item) for item in research_objects
        )
        if len(set(identities)) != len(identities):
            raise ValueError("proposal engine returned duplicate research objects")
        return research_objects

    def register_candidate(
        self,
        candidate: Any,
        *,
        discovery_channel: str,
        hypothesis_id: Optional[str] = None,
    ) -> str:
        channel_ids = {
            item.channel_id for item in self.contract.resolved_discovery_channels
        }
        if discovery_channel not in channel_ids:
            raise ValueError("candidate uses an undeclared discovery channel")
        candidate_id = self.adapter.candidate_id(candidate)
        if candidate_id in self._registered_candidates:
            raise ValueError("candidate is already registered")
        payload = dict(self.adapter.candidate_as_dict(candidate))
        artifact_id = self.store.put("domain_candidate", payload)
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CANDIDATE_PROPOSED,
            {
                "candidate_id": candidate_id,
                "candidate_artifact_id": artifact_id,
                "discovery_channel": discovery_channel,
                "hypothesis_id": hypothesis_id,
            },
            "registered-domain-proposer",
        )
        self._registered_candidates.add(candidate_id)
        return candidate_id

    def register_research_object(
        self,
        research_object: Any,
        *,
        discovery_channel: str,
        hypothesis_id: Optional[str] = None,
    ) -> str:
        return self.register_candidate(
            research_object,
            discovery_channel=discovery_channel,
            hypothesis_id=hypothesis_id,
        )

    def evaluate(
        self,
        candidate: Any,
        experiments: Sequence[Any],
        *,
        partition: EvidencePartition,
        gate_contract_id: str,
        control: Optional[Any] = None,
        controls: Sequence[Any] = (),
    ) -> CampaignEvaluation:
        candidate_id = self.adapter.candidate_id(candidate)
        if candidate_id not in self._registered_candidates:
            raise ValueError("candidate must be registered before evaluation")
        gate = next(
            (
                item
                for item in self.contract.gates
                if item.contract_id == gate_contract_id
            ),
            None,
        )
        if gate is None or gate.evidence_partition != partition:
            raise ValueError("evaluation gate or evidence partition is undeclared")
        measurements = evaluate_measurements(
            self.adapter,
            candidate,
            tuple(experiments),
            partition=partition,
            comparison_mode=self.contract.comparison_mode,
            control=control,
            controls=controls,
        )
        summary = analyze_measurements(
            self.adapter,
            measurements,
            self.contract.evidence_analysis,
        )
        metric_names = {
            name for item in measurements for name in item.metrics
        }
        gate_metrics = {
            name: sum(float(item.metrics.get(name, 0.0)) for item in measurements)
            for name in metric_names
        }
        gate_metrics.update(summary.metrics)
        resolved_controls = (
            (() if control is None else (control,)) + tuple(controls)
        )
        control_ids = tuple(
            self.adapter.candidate_id(item) for item in resolved_controls
        )
        control_id = control_ids[0] if len(control_ids) == 1 else None
        decision = evaluate_gate(
            gate,
            candidate_id,
            control_id,
            gate_metrics,
            len(measurements),
            control_ids=control_ids,
        )
        artifacts = tuple(
            self.store.put("domain_measurement", item.as_dict())
            for item in measurements
        )
        summary_artifact = self.store.put(
            "domain_evidence_summary",
            summary.as_dict(),
        )
        gate_artifact = self.store.put(
            "domain_gate_decision",
            decision.as_dict(),
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CANDIDATE_EVALUATED,
            {
                "candidate_id": candidate_id,
                "partition": partition.value,
                "evidence_summary_id": summary.summary_id,
            },
            self.adapter.evaluator_ref,
        )
        if partition == EvidencePartition.AUDIT:
            self.ledger.append(
                self.cycle_id,
                LedgerEventKind.AUDIT_COMPLETED,
                {
                    "candidate_id": candidate_id,
                    "passed": decision.passed,
                    "gate_decision_id": decision.decision_id,
                },
                self.adapter.verifier_ref,
            )
        return CampaignEvaluation(
            candidate_id=candidate_id,
            control_id=control_id,
            control_ids=control_ids,
            partition=partition,
            measurement_ids=tuple(item.measurement_id for item in measurements),
            evidence_summary=summary,
            gate_decision=decision,
            artifact_ids=(*artifacts, summary_artifact, gate_artifact),
        )

    def evaluate_research_object(
        self,
        research_object: Any,
        evidence_tasks: Sequence[Any],
        *,
        partition: EvidencePartition,
        gate_contract_id: str,
        controls: Sequence[Any] = (),
    ) -> CampaignEvaluation:
        return self.evaluate(
            research_object,
            evidence_tasks,
            partition=partition,
            gate_contract_id=gate_contract_id,
            controls=controls,
        )
