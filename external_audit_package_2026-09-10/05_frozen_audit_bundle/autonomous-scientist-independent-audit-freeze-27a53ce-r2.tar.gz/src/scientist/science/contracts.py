from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Tuple

from scientist.core.artifacts import content_digest


@dataclass(frozen=True)
class Hypothesis:
    name: str
    statement: str
    model_kind: str
    executable_ref: str
    prior_weight: float = 1.0

    def __post_init__(self) -> None:
        if not self.name or not self.statement or not self.executable_ref:
            raise ValueError("hypothesis fields must not be empty")
        if self.prior_weight <= 0.0:
            raise ValueError("prior_weight must be positive")

    @property
    def hypothesis_id(self) -> str:
        return content_digest(
            {
                "schema": 1,
                "name": self.name,
                "statement": self.statement,
                "model_kind": self.model_kind,
                "executable_ref": self.executable_ref,
            }
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "hypothesis_id": self.hypothesis_id,
            "name": self.name,
            "statement": self.statement,
            "model_kind": self.model_kind,
            "executable_ref": self.executable_ref,
            "prior_weight": self.prior_weight,
        }


@dataclass(frozen=True)
class Prediction:
    hypothesis_id: str
    experiment_id: str
    target: str
    predicted_value: float

    @property
    def prediction_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "schema": 1,
            "hypothesis_id": self.hypothesis_id,
            "experiment_id": self.experiment_id,
            "target": self.target,
            "predicted_value": self.predicted_value,
        }
        if include_id:
            value["prediction_id"] = self.prediction_id
        return value


@dataclass(frozen=True)
class Evidence:
    experiment_id: str
    target: str
    observed_value: float
    method_ref: str

    @property
    def evidence_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "schema": 1,
            "experiment_id": self.experiment_id,
            "target": self.target,
            "observed_value": self.observed_value,
            "method_ref": self.method_ref,
        }
        if include_id:
            value["evidence_id"] = self.evidence_id
        return value


@dataclass(frozen=True)
class ModelPredictionEvidenceBundle:
    hypothesis_id: str
    prediction_ids: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    cumulative_loss: float
    normalized_weight: float
    update_rule: str

    def __post_init__(self) -> None:
        if len(self.prediction_ids) != len(self.evidence_ids):
            raise ValueError("each prediction must have one evidence link")
        if self.cumulative_loss < 0.0:
            raise ValueError("cumulative_loss must be non-negative")
        if not 0.0 <= self.normalized_weight <= 1.0:
            raise ValueError("normalized_weight must be in [0, 1]")

    @property
    def bundle_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value = {
            "schema": 1,
            "hypothesis_id": self.hypothesis_id,
            "prediction_ids": list(self.prediction_ids),
            "evidence_ids": list(self.evidence_ids),
            "cumulative_loss": self.cumulative_loss,
            "normalized_weight": self.normalized_weight,
            "update_rule": self.update_rule,
        }
        if include_id:
            value["bundle_id"] = self.bundle_id
        return value
