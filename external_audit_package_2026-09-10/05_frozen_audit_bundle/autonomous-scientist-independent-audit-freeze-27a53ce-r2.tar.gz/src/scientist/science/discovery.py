from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Protocol, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import ChannelRelation, DiscoveryChannelSpec
from scientist.program.hypothesis_tournament import (
    EvolutionFunction,
    HypothesisReview,
    HypothesisTournament,
    TournamentHypothesis,
    run_hypothesis_tournament,
)
from scientist.program.literature import (
    ClaimClassification,
    PriorArtAssessment,
)
from scientist.science.hypothesis_forge import HypothesisForgePortfolio
from scientist.science.hypotheses import CausalHypothesisContract


MECHANISM_FIRST_DISCOVERY_VERSION = "mechanism-first-discovery-core-v1"


class CausalHypothesisGenerator(Protocol):
    name: str
    generator_version: str

    def generate(
        self,
        *,
        target_node_id: str,
        channel: DiscoveryChannelSpec,
        literature_context: Any,
        experimental_findings: Sequence[Mapping[str, Any]],
        count: int,
    ) -> Sequence[CausalHypothesisContract]:
        ...


class CandidatePriorArtReviewer(Protocol):
    reviewer_ref: str

    def review_candidate(
        self,
        hypothesis: CausalHypothesisContract,
    ) -> PriorArtAssessment:
        ...


class HypothesisCompiler(Protocol):
    compiler_ref: str

    def compile(
        self,
        hypothesis: CausalHypothesisContract,
        prior_art: PriorArtAssessment,
    ) -> Any:
        ...


class DistinguishingDiagnostic(Protocol):
    diagnostic_ref: str

    def diagnose(
        self,
        hypothesis: CausalHypothesisContract,
        candidate: Any,
    ) -> Mapping[str, Any]:
        ...


class SemanticNoveltyAssessor(Protocol):
    assessor_ref: str

    def assess(
        self,
        hypothesis: CausalHypothesisContract,
        candidate: Any,
        prior_art: PriorArtAssessment,
    ) -> Mapping[str, Any]:
        ...


@dataclass(frozen=True)
class CompiledHypothesis:
    hypothesis: CausalHypothesisContract
    prior_art: PriorArtAssessment
    candidate: Any
    candidate_id: str
    distinguishing_diagnostic: Mapping[str, Any]
    semantic_novelty: Mapping[str, Any]

    @property
    def admitted_to_performance_evaluation(self) -> bool:
        return bool(
            self.distinguishing_diagnostic.get("passed")
            and self.semantic_novelty.get("passed")
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "hypothesis": self.hypothesis.as_dict(),
            "prior_art": self.prior_art.as_dict(),
            "candidate_id": self.candidate_id,
            "distinguishing_diagnostic": dict(self.distinguishing_diagnostic),
            "semantic_novelty": dict(self.semantic_novelty),
            "admitted_to_performance_evaluation": (
                self.admitted_to_performance_evaluation
            ),
        }


@dataclass(frozen=True)
class MechanismFirstDiscoveryResult:
    target_node_id: str
    channels: Tuple[DiscoveryChannelSpec, ...]
    proposed_hypotheses: Tuple[CausalHypothesisContract, ...]
    tournament: HypothesisTournament
    compiled: Tuple[CompiledHypothesis, ...]
    rejected_prior_art_hypothesis_ids: Tuple[str, ...]
    compiler_ref: str
    hypothesis_forge_portfolios: Tuple[HypothesisForgePortfolio, ...] = ()

    @property
    def result_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "contract_version": MECHANISM_FIRST_DISCOVERY_VERSION,
            "target_node_id": self.target_node_id,
            "channels": [item.as_dict() for item in self.channels],
            "proposed_hypotheses": [
                item.as_dict() for item in self.proposed_hypotheses
            ],
            "tournament": self.tournament.as_dict(),
            "compiled": [item.as_dict() for item in self.compiled],
            "rejected_prior_art_hypothesis_ids": list(
                self.rejected_prior_art_hypothesis_ids
            ),
            "compiler_ref": self.compiler_ref,
            "hypothesis_forge_portfolios": [
                item.as_dict() for item in self.hypothesis_forge_portfolios
            ],
            "ordering_guarantees": [
                "literature_before_hypothesis",
                "source_grounded_opportunity_and_structural_signature_before_hypothesis",
                "canonical_mechanism_admission_before_elo",
                "elo_survival_before_candidate_specific_literature",
                "candidate_specific_literature_before_compilation",
                "distinguishing_and_semantic_gates_before_performance",
                "novelty_and_performance_are_separate",
            ],
        }
        if include_id:
            value["result_id"] = self.result_id
        return value


def run_mechanism_first_discovery(
    *,
    target_node_id: str,
    channels: Sequence[DiscoveryChannelSpec],
    literature_contexts: Mapping[str, Any],
    experimental_findings: Sequence[Mapping[str, Any]],
    generator: CausalHypothesisGenerator,
    prior_art_reviewer: CandidatePriorArtReviewer,
    compiler: HypothesisCompiler,
    diagnostic: DistinguishingDiagnostic,
    novelty_assessor: SemanticNoveltyAssessor,
    review: Callable[[TournamentHypothesis], HypothesisReview],
    evolve: EvolutionFunction,
    hypotheses_per_channel: int,
    survivor_count: int,
) -> MechanismFirstDiscoveryResult:
    """Run problem-agnostic discovery through the pre-performance gates."""

    channels = tuple(channels)
    if not channels or hypotheses_per_channel < 1 or survivor_count < 1:
        raise ValueError("mechanism-first discovery budget is invalid")
    channel_ids = tuple(item.channel_id for item in channels)
    if len(set(channel_ids)) != len(channel_ids):
        raise ValueError("mechanism-first discovery channels must be unique")
    if set(channel_ids) != set(literature_contexts):
        raise ValueError("every discovery channel needs its literature context")
    proposals = []
    forge_portfolios = []
    for channel in channels:
        generated = tuple(
            generator.generate(
                target_node_id=target_node_id,
                channel=channel,
                literature_context=literature_contexts[channel.channel_id],
                experimental_findings=experimental_findings,
                count=hypotheses_per_channel,
            )
        )
        if len(generated) != hypotheses_per_channel:
            raise ValueError("hypothesis generator returned the wrong count")
        for hypothesis in generated:
            if hypothesis.target_node_id != target_node_id:
                raise ValueError("generated hypothesis targets another node")
            if hypothesis.discovery_channel != channel.channel_id:
                raise ValueError("generated hypothesis entered another channel")
            expected_cross_domain = (
                channel.relation == ChannelRelation.CROSS_DOMAIN_TRANSFER
            )
            if hypothesis.cross_domain != expected_cross_domain:
                raise ValueError("hypothesis and channel transfer status disagree")
        portfolio_for = getattr(generator, "portfolio_for", None)
        if callable(portfolio_for):
            portfolio = portfolio_for(
                target_node_id=target_node_id,
                channel_id=channel.channel_id,
            )
            if tuple(item.hypothesis_id for item in portfolio.selected_hypotheses()) != tuple(
                item.hypothesis_id for item in generated
            ):
                raise ValueError("hypothesis forge portfolio and generated proposals disagree")
            forge_portfolios.append(portfolio)
        proposals.extend(generated)
    tournament_seeds = tuple(item.as_tournament_hypothesis() for item in proposals)
    tournament_to_contract = {
        seed.hypothesis_id: contract
        for seed, contract in zip(tournament_seeds, proposals)
    }
    required_channels = tuple(
        "cross_domain"
        if item.relation == ChannelRelation.CROSS_DOMAIN_TRANSFER
        else item.channel_id
        for item in channels
    )
    tournament = run_hypothesis_tournament(
        tournament_seeds,
        review=review,
        evolve=evolve,
        generations=1,
        survivor_count=min(survivor_count, len(tournament_seeds)),
        required_discovery_channels=required_channels,
        minimum_seed_count=max(2, len(channels)),
        tournament_ref="problem-agnostic-mechanism-elo-v1",
    )
    compiled = []
    rejected = []
    for tournament_id in tournament.survivor_ids:
        hypothesis = tournament_to_contract.get(tournament_id)
        if hypothesis is None:
            # Evolution may create a survivor. It must be represented by a
            # new causal contract before a compiler can consume it.
            raise ValueError(
                "evolved tournament survivor lacks a causal contract"
            )
        prior_art = prior_art_reviewer.review_candidate(hypothesis)
        if prior_art.signature.subject_id != hypothesis.hypothesis_id:
            raise ValueError("candidate-specific literature reviewed another idea")
        if not prior_art.closure_passed:
            raise ValueError("candidate-specific literature failed closed")
        if prior_art.classification in {
            ClaimClassification.REPRODUCTION,
            ClaimClassification.REDISCOVERY,
        }:
            rejected.append(hypothesis.hypothesis_id)
            continue
        candidate = compiler.compile(hypothesis, prior_art)
        declared_candidate_id = getattr(candidate, "candidate_id", None)
        if declared_candidate_id is None:
            serializer = getattr(candidate, "as_dict", None)
            if not callable(serializer):
                raise ValueError("compiled candidate lacks a stable identity")
            declared_candidate_id = content_digest(serializer())
        candidate_id = str(declared_candidate_id)
        diagnostic_result = dict(diagnostic.diagnose(hypothesis, candidate))
        novelty = dict(
            novelty_assessor.assess(hypothesis, candidate, prior_art)
        )
        if "passed" not in diagnostic_result or "passed" not in novelty:
            raise ValueError("pre-performance gates must report passed status")
        compiled.append(
            CompiledHypothesis(
                hypothesis=hypothesis,
                prior_art=prior_art,
                candidate=candidate,
                candidate_id=candidate_id,
                distinguishing_diagnostic=diagnostic_result,
                semantic_novelty=novelty,
            )
        )
    return MechanismFirstDiscoveryResult(
        target_node_id=target_node_id,
        channels=channels,
        proposed_hypotheses=tuple(proposals),
        tournament=tournament,
        compiled=tuple(compiled),
        rejected_prior_art_hypothesis_ids=tuple(rejected),
        compiler_ref=compiler.compiler_ref,
        hypothesis_forge_portfolios=tuple(forge_portfolios),
    )
