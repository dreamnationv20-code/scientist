from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

from scientist.core.artifacts import content_digest
from scientist.program.hypothesis_learning import (
    HypothesisPredictionProfile,
    MechanismSignature,
)
from scientist.program.hypothesis_tournament import (
    HypothesisOrigin,
    TournamentHypothesis,
)


SCIENTIFIC_HYPOTHESIS_VERSION = "problem-agnostic-causal-hypothesis-v1"


@dataclass(frozen=True)
class RelationalMapping:
    source_element: str
    target_element: str
    causal_role: str

    def __post_init__(self) -> None:
        if not all((self.source_element, self.target_element, self.causal_role)):
            raise ValueError("relational mapping is incomplete")

    def as_dict(self) -> Dict[str, str]:
        return {
            "source_element": self.source_element,
            "target_element": self.target_element,
            "causal_role": self.causal_role,
        }


@dataclass(frozen=True)
class MechanismFingerprint:
    """Semantic mechanism identity across algorithms, models, and systems."""

    information_used: Tuple[str, ...]
    state_or_memory: str
    inference_horizon: str
    coupling_scope: str
    optimization_object: str
    intervention_structure: str
    fallback_or_control: str
    known_family: str
    computational_topology: str

    def __post_init__(self) -> None:
        values = (
            self.information_used,
            self.state_or_memory,
            self.inference_horizon,
            self.coupling_scope,
            self.optimization_object,
            self.intervention_structure,
            self.fallback_or_control,
            self.known_family,
            self.computational_topology,
        )
        if not all(values):
            raise ValueError("mechanism fingerprint is incomplete")
        if len(set(self.information_used)) != len(self.information_used):
            raise ValueError("mechanism information sources must be unique")

    @property
    def fingerprint_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "information_used": list(self.information_used),
            "state_or_memory": self.state_or_memory,
            "inference_horizon": self.inference_horizon,
            "coupling_scope": self.coupling_scope,
            "optimization_object": self.optimization_object,
            "intervention_structure": self.intervention_structure,
            "fallback_or_control": self.fallback_or_control,
            "known_family": self.known_family,
            "computational_topology": self.computational_topology,
        }
        if include_id:
            value["fingerprint_id"] = self.fingerprint_id
        return value


@dataclass(frozen=True)
class CausalHypothesisContract:
    """Problem-agnostic hypothesis, required before implementation search."""

    target_node_id: str
    discovery_channel: str
    research_object: str
    statement: str
    target_failure: str
    causal_mechanism: str
    observed_information: Tuple[str, ...]
    unavailable_or_latent_information: str
    intervention: str
    mediator: str
    outcome: str
    source_domain: str
    source_mechanism: str
    relational_mappings: Tuple[RelationalMapping, ...]
    broken_assumptions: Tuple[str, ...]
    distinguishing_predictions: Tuple[str, ...]
    ablations: Tuple[str, ...]
    boundary_conditions: Tuple[str, ...]
    expected_failure: str
    falsification_conditions: Tuple[str, ...]
    mechanism_fingerprint: MechanismFingerprint
    literature_refs: Tuple[str, ...]
    generator_ref: str
    cross_domain: bool = False

    def __post_init__(self) -> None:
        required = (
            self.target_node_id,
            self.discovery_channel,
            self.research_object,
            self.statement,
            self.target_failure,
            self.causal_mechanism,
            self.observed_information,
            self.unavailable_or_latent_information,
            self.intervention,
            self.mediator,
            self.outcome,
            self.source_domain,
            self.source_mechanism,
            self.relational_mappings,
            self.broken_assumptions,
            self.distinguishing_predictions,
            self.ablations,
            self.boundary_conditions,
            self.expected_failure,
            self.falsification_conditions,
            self.literature_refs,
            self.generator_ref,
        )
        if not all(required):
            raise ValueError("causal hypothesis contract is incomplete")
        if len(self.relational_mappings) < 2:
            raise ValueError("causal transfer requires two relational mappings")
        if len(self.distinguishing_predictions) < 2:
            raise ValueError("hypothesis requires two distinguishing predictions")
        if len(self.falsification_conditions) < 2:
            raise ValueError("hypothesis requires two falsification conditions")

    @property
    def hypothesis_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "contract_version": SCIENTIFIC_HYPOTHESIS_VERSION,
            "target_node_id": self.target_node_id,
            "discovery_channel": self.discovery_channel,
            "research_object": self.research_object,
            "statement": self.statement,
            "target_failure": self.target_failure,
            "causal_mechanism": self.causal_mechanism,
            "observed_information": list(self.observed_information),
            "unavailable_or_latent_information": (
                self.unavailable_or_latent_information
            ),
            "intervention": self.intervention,
            "mediator": self.mediator,
            "outcome": self.outcome,
            "source_domain": self.source_domain,
            "source_mechanism": self.source_mechanism,
            "relational_mappings": [
                item.as_dict() for item in self.relational_mappings
            ],
            "broken_assumptions": list(self.broken_assumptions),
            "distinguishing_predictions": list(
                self.distinguishing_predictions
            ),
            "ablations": list(self.ablations),
            "boundary_conditions": list(self.boundary_conditions),
            "expected_failure": self.expected_failure,
            "falsification_conditions": list(self.falsification_conditions),
            "mechanism_fingerprint": self.mechanism_fingerprint.as_dict(),
            "literature_refs": list(self.literature_refs),
            "generator_ref": self.generator_ref,
            "cross_domain": self.cross_domain,
        }
        if include_id:
            value["hypothesis_id"] = self.hypothesis_id
        return value

    def as_tournament_hypothesis(self) -> TournamentHypothesis:
        fingerprint = self.mechanism_fingerprint
        origin = (
            HypothesisOrigin.CROSS_DOMAIN
            if self.cross_domain
            else HypothesisOrigin.ISLAND
        )
        return TournamentHypothesis(
            target_node_id=self.target_node_id,
            statement=self.statement,
            mechanism=self.causal_mechanism,
            origin=origin,
            source_ref="|".join(self.literature_refs),
            generator_ref=self.generator_ref,
            predictions=self.distinguishing_predictions,
            falsification_conditions=self.falsification_conditions,
            assumptions=(*self.broken_assumptions, *self.boundary_conditions),
            evidence_ids=self.literature_refs,
            mechanism_signature=MechanismSignature(
                target_failure_classes=(self.target_failure,),
                information_regime=fingerprint.state_or_memory,
                information_source="|".join(fingerprint.information_used),
                intervention_operator=fingerprint.intervention_structure,
                mediator=self.mediator,
                protected_resource=fingerprint.fallback_or_control,
                outcome=self.outcome,
                boundary_conditions=self.boundary_conditions,
                signature_ref="problem-agnostic-mechanism-fingerprint-v1",
            ),
            prediction_profile=HypothesisPredictionProfile(
                target_effect=self.distinguishing_predictions[0],
                target_control_relation=self.distinguishing_predictions[1],
                information_ablation_response=self.ablations[0],
                mediator_response="the declared mediator changes",
                mechanism_ablation_response=self.ablations[-1],
                boundary_predictions=(("expected_failure", self.expected_failure),),
                measurement_ref="problem-agnostic-distinguishing-test-v1",
            ),
            inspiration_ids=self.literature_refs,
            island_family=(None if self.cross_domain else self.discovery_channel),
        )

