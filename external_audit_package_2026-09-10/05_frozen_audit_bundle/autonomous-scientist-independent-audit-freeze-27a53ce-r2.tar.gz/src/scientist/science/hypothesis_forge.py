from __future__ import annotations

"""Source-grounded hypothesis generation contracts.

The scientific kernel owns truth and promotion decisions.  This module owns a
narrower boundary: it makes the *creative* inputs to mechanism-first discovery
auditable.  A forge proposes a portfolio from explicit research opportunities,
primary-source spans, structural problem signatures, and causal transfer
mappings.  It cannot compile, evaluate, or promote a hypothesis.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Protocol, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import DiscoveryChannelSpec
from scientist.science.hypotheses import CausalHypothesisContract


HYPOTHESIS_FORGE_VERSION = "source-grounded-hypothesis-forge-v1"


class OpportunityKind(str, Enum):
    """Literature-derived routes for generating a research opportunity."""

    TENSION = "tension"
    BOTTLENECK = "bottleneck"
    CONTRADICTION = "contradiction"
    LOAD_BEARING_ASSUMPTION = "load_bearing_assumption"


@dataclass(frozen=True)
class PrimarySourceSpan:
    """A checkable primary-source passage used in creative reasoning."""

    work_id: str
    locator: str
    section: str
    excerpt: str
    supports: str

    def __post_init__(self) -> None:
        if not all((self.work_id, self.locator, self.section, self.excerpt, self.supports)):
            raise ValueError("primary-source span is incomplete")
        if len(self.excerpt.strip()) < 12:
            raise ValueError("primary-source span excerpt is too short")

    @property
    def span_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, str]:
        value = {
            "work_id": self.work_id,
            "locator": self.locator,
            "section": self.section,
            "excerpt": self.excerpt,
            "supports": self.supports,
        }
        if include_id:
            value["span_id"] = self.span_id
        return value


@dataclass(frozen=True)
class ResearchOpportunity:
    """A falsifiable, literature-grounded reason to search a mechanism space."""

    target_node_id: str
    kind: OpportunityKind
    question: str
    source_span_ids: Tuple[str, ...]
    confirmation_stakes: str
    refutation_stakes: str
    kill_check: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_node_id,
                self.question,
                self.source_span_ids,
                self.confirmation_stakes,
                self.refutation_stakes,
                self.kill_check,
            )
        ):
            raise ValueError("research opportunity is incomplete")
        if len(set(self.source_span_ids)) != len(self.source_span_ids):
            raise ValueError("research opportunity source spans must be unique")

    @property
    def opportunity_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "target_node_id": self.target_node_id,
            "kind": self.kind.value,
            "question": self.question,
            "source_span_ids": list(self.source_span_ids),
            "confirmation_stakes": self.confirmation_stakes,
            "refutation_stakes": self.refutation_stakes,
            "kill_check": self.kill_check,
        }
        if include_id:
            value["opportunity_id"] = self.opportunity_id
        return value


@dataclass(frozen=True)
class StructuralProblemSignature:
    """Domain-free search key written before analogy retrieval or proposal."""

    opportunity_id: str
    objective: str
    constraints: Tuple[str, ...]
    hardness: str
    solution_shape: str
    builder_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.opportunity_id,
                self.objective,
                self.constraints,
                self.hardness,
                self.solution_shape,
                self.builder_ref,
            )
        ):
            raise ValueError("structural problem signature is incomplete")
        if len(set(self.constraints)) != len(self.constraints):
            raise ValueError("structural problem signature constraints must be unique")

    @property
    def signature_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "opportunity_id": self.opportunity_id,
            "objective": self.objective,
            "constraints": list(self.constraints),
            "hardness": self.hardness,
            "solution_shape": self.solution_shape,
            "builder_ref": self.builder_ref,
        }
        if include_id:
            value["signature_id"] = self.signature_id
        return value


@dataclass(frozen=True)
class StructuralTransferMapping:
    """One source-to-target correspondence backed by a source passage."""

    source_element: str
    target_element: str
    causal_role: str
    source_span_id: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.source_element,
                self.target_element,
                self.causal_role,
                self.source_span_id,
            )
        ):
            raise ValueError("structural transfer mapping is incomplete")

    def as_dict(self) -> Dict[str, str]:
        return {
            "source_element": self.source_element,
            "target_element": self.target_element,
            "causal_role": self.causal_role,
            "source_span_id": self.source_span_id,
        }


@dataclass(frozen=True)
class ForgedCausalHypothesis:
    """A causal hypothesis plus the reasoning artifacts that generated it."""

    hypothesis: CausalHypothesisContract
    opportunity_id: str
    signature_id: str
    source_domain: str
    mappings: Tuple[StructuralTransferMapping, ...]
    first_discriminating_experiment: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.opportunity_id,
                self.signature_id,
                self.source_domain,
                self.mappings,
                self.first_discriminating_experiment,
            )
        ):
            raise ValueError("forged causal hypothesis is incomplete")
        if self.hypothesis.source_domain != self.source_domain:
            raise ValueError("forged hypothesis source domain disagrees with its contract")
        if len(self.mappings) < 2:
            raise ValueError("forged causal hypothesis requires two structural mappings")
        pairs = {(item.source_element, item.target_element, item.causal_role) for item in self.mappings}
        if len(pairs) != len(self.mappings):
            raise ValueError("forged causal hypothesis mappings must be distinct")

    @property
    def forged_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "hypothesis": self.hypothesis.as_dict(),
            "opportunity_id": self.opportunity_id,
            "signature_id": self.signature_id,
            "source_domain": self.source_domain,
            "mappings": [item.as_dict() for item in self.mappings],
            "first_discriminating_experiment": self.first_discriminating_experiment,
        }
        if include_id:
            value["forged_id"] = self.forged_id
        return value


@dataclass(frozen=True)
class HypothesisForgeBrief:
    """Bounded source material and observations available to a forge invocation."""

    target_node_id: str
    channel_id: str
    literature_context_id: str
    source_work_ids: Tuple[str, ...]
    experimental_findings: Tuple[Mapping[str, Any], ...]
    context_material: str
    builder_ref: str = "source-grounded-hypothesis-forge-brief-v1"

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_node_id,
                self.channel_id,
                self.literature_context_id,
                self.source_work_ids,
                self.context_material,
                self.builder_ref,
            )
        ):
            raise ValueError("hypothesis forge brief is incomplete")
        if len(set(self.source_work_ids)) != len(self.source_work_ids):
            raise ValueError("hypothesis forge source works must be unique")

    @property
    def brief_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "contract_version": HYPOTHESIS_FORGE_VERSION,
            "target_node_id": self.target_node_id,
            "channel_id": self.channel_id,
            "literature_context_id": self.literature_context_id,
            "source_work_ids": list(self.source_work_ids),
            "experimental_findings": [dict(item) for item in self.experimental_findings],
            "context_material": self.context_material,
            "builder_ref": self.builder_ref,
        }
        if include_id:
            value["brief_id"] = self.brief_id
        return value

    @classmethod
    def from_literature_context(
        cls,
        *,
        target_node_id: str,
        channel: DiscoveryChannelSpec,
        literature_context: Any,
        experimental_findings: Sequence[Mapping[str, Any]],
    ) -> "HypothesisForgeBrief":
        context_id = getattr(literature_context, "context_id", None)
        source_work_ids = getattr(literature_context, "source_work_ids", None)
        proposer_material = getattr(literature_context, "proposer_material", None)
        if not context_id or not source_work_ids or not callable(proposer_material):
            raise ValueError(
                "hypothesis forge requires a source-preserving literature context"
            )
        return cls(
            target_node_id=target_node_id,
            channel_id=channel.channel_id,
            literature_context_id=str(context_id),
            source_work_ids=tuple(str(item) for item in source_work_ids),
            experimental_findings=tuple(dict(item) for item in experimental_findings),
            context_material=str(proposer_material()),
        )


@dataclass(frozen=True)
class HypothesisForgePortfolio:
    """The complete, auditable output of one bounded forge invocation."""

    brief: HypothesisForgeBrief
    source_spans: Tuple[PrimarySourceSpan, ...]
    opportunities: Tuple[ResearchOpportunity, ...]
    signatures: Tuple[StructuralProblemSignature, ...]
    proposals: Tuple[ForgedCausalHypothesis, ...]
    selected_hypothesis_ids: Tuple[str, ...]
    proposer_ref: str

    def __post_init__(self) -> None:
        if not self.proposer_ref:
            raise ValueError("hypothesis forge portfolio requires proposer provenance")
        if len(self.source_spans) < 2 or len(self.opportunities) < 2 or len(self.proposals) < 2:
            raise ValueError("hypothesis forge requires multiple sources, opportunities, and proposals")
        span_by_id = {item.span_id: item for item in self.source_spans}
        if len(span_by_id) != len(self.source_spans):
            raise ValueError("hypothesis forge source spans must be unique")
        if not {item.work_id for item in self.source_spans}.issubset(self.brief.source_work_ids):
            raise ValueError("hypothesis forge cited a work outside its literature context")
        opportunity_by_id = {item.opportunity_id: item for item in self.opportunities}
        if len(opportunity_by_id) != len(self.opportunities):
            raise ValueError("hypothesis forge opportunities must be unique")
        if any(item.target_node_id != self.brief.target_node_id for item in self.opportunities):
            raise ValueError("hypothesis forge opportunity targets another node")
        if any(not set(item.source_span_ids).issubset(span_by_id) for item in self.opportunities):
            raise ValueError("hypothesis forge opportunity cites an unknown source span")
        signature_by_id = {item.signature_id: item for item in self.signatures}
        if len(signature_by_id) != len(self.signatures):
            raise ValueError("hypothesis forge signatures must be unique")
        if set(item.opportunity_id for item in self.signatures) != set(opportunity_by_id):
            raise ValueError("every hypothesis forge opportunity needs one structural signature")
        hypothesis_ids = {item.hypothesis.hypothesis_id for item in self.proposals}
        if len(hypothesis_ids) != len(self.proposals):
            raise ValueError("hypothesis forge proposals must be unique")
        if any(
            item.hypothesis.target_node_id != self.brief.target_node_id
            or item.hypothesis.discovery_channel != self.brief.channel_id
            for item in self.proposals
        ):
            raise ValueError("hypothesis forge proposal belongs to another target or channel")
        if any(
            item.opportunity_id not in opportunity_by_id
            or item.signature_id not in signature_by_id
            or signature_by_id[item.signature_id].opportunity_id != item.opportunity_id
            for item in self.proposals
        ):
            raise ValueError("hypothesis forge proposal lacks its opportunity or signature")
        if any(
            not {mapping.source_span_id for mapping in item.mappings}.issubset(span_by_id)
            for item in self.proposals
        ):
            raise ValueError("hypothesis forge transfer mapping cites an unknown span")
        if any(
            not set(item.hypothesis.literature_refs).issubset(self.brief.source_work_ids)
            for item in self.proposals
        ):
            raise ValueError("hypothesis forge hypothesis cites work outside its literature context")
        if len({item.kind for item in self.opportunities}) < 2:
            raise ValueError("hypothesis forge must use more than one opportunity kind")
        selected = set(self.selected_hypothesis_ids)
        if not selected or len(selected) != len(self.selected_hypothesis_ids) or not selected.issubset(hypothesis_ids):
            raise ValueError("hypothesis forge selected hypotheses are invalid")

    @property
    def portfolio_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def selected_hypotheses(self) -> Tuple[CausalHypothesisContract, ...]:
        selected = set(self.selected_hypothesis_ids)
        return tuple(
            item.hypothesis for item in self.proposals if item.hypothesis.hypothesis_id in selected
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "contract_version": HYPOTHESIS_FORGE_VERSION,
            "brief": self.brief.as_dict(),
            "source_spans": [item.as_dict() for item in self.source_spans],
            "opportunities": [item.as_dict() for item in self.opportunities],
            "signatures": [item.as_dict() for item in self.signatures],
            "proposals": [item.as_dict() for item in self.proposals],
            "selected_hypothesis_ids": list(self.selected_hypothesis_ids),
            "proposer_ref": self.proposer_ref,
        }
        if include_id:
            value["portfolio_id"] = self.portfolio_id
        return value


class HypothesisForgeProposer(Protocol):
    """A creative component constrained by a source-grounded forge brief."""

    name: str
    generator_version: str

    def forge(
        self,
        *,
        brief: HypothesisForgeBrief,
        count: int,
    ) -> HypothesisForgePortfolio:
        ...


class ForgeBackedCausalHypothesisGenerator:
    """Adapter that makes a forge usable by mechanism-first discovery.

    The adapter intentionally exposes no compiler or evaluator.  It only turns
    a validated selected portfolio into causal-hypothesis proposals and retains
    the portfolio for durable inclusion in the discovery result.
    """

    def __init__(self, proposer: HypothesisForgeProposer) -> None:
        self.proposer = proposer
        self.name = "hypothesis_forge:%s" % proposer.name
        self.generator_version = proposer.generator_version
        self._portfolios: Dict[Tuple[str, str], HypothesisForgePortfolio] = {}

    def generate(
        self,
        *,
        target_node_id: str,
        channel: DiscoveryChannelSpec,
        literature_context: Any,
        experimental_findings: Sequence[Mapping[str, Any]],
        count: int,
    ) -> Sequence[CausalHypothesisContract]:
        if count < 2:
            raise ValueError("hypothesis forge requires at least two proposals per channel")
        brief = HypothesisForgeBrief.from_literature_context(
            target_node_id=target_node_id,
            channel=channel,
            literature_context=literature_context,
            experimental_findings=experimental_findings,
        )
        portfolio = self.proposer.forge(brief=brief, count=count)
        if portfolio.brief.brief_id != brief.brief_id:
            raise ValueError("hypothesis forge portfolio belongs to another brief")
        selected = portfolio.selected_hypotheses()
        if len(selected) != count:
            raise ValueError("hypothesis forge returned the wrong selected proposal count")
        self._portfolios[(target_node_id, channel.channel_id)] = portfolio
        return selected

    def portfolio_for(
        self,
        *,
        target_node_id: str,
        channel_id: str,
    ) -> HypothesisForgePortfolio:
        try:
            return self._portfolios[(target_node_id, channel_id)]
        except KeyError as error:
            raise ValueError("hypothesis forge has no portfolio for this channel") from error
