from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Tuple

from scientist.core.artifacts import content_digest


PREEXECUTION_REMEDIATION_VERSION = "bounded-preexecution-remediation-v1"


class PreexecutionDefectClass(str, Enum):
    FATAL_SCIENTIFIC = "fatal_scientific"
    REPAIRABLE_ENGINEERING = "repairable_engineering"


FATAL_SCIENTIFIC_CATEGORIES = (
    "answer_or_outcome_access",
    "consumed_release_reuse",
    "scientific_contract_change",
    "model_boundary_change",
    "threshold_or_estimand_change",
    "post_outcome_selection",
)

REPAIRABLE_ENGINEERING_CATEGORIES = (
    "namespace_or_partition_collision",
    "serialization_or_atomicity",
    "runtime_compatibility",
    "artifact_binding",
    "certificate_schema",
)


@dataclass(frozen=True)
class BoundedPreexecutionRemediationPolicy:
    """Keep scientific review immutable while allowing bounded pre-outcome repairs.

    The policy exists specifically to avoid the failure mode where an audit cap
    either loops forever or turns a correctable pre-execution implementation bug
    into a new scientific campaign.  It never authorizes outcome-informed work.
    """

    policy_ref: str
    maximum_engineering_remediations: int = 1
    fatal_categories: Tuple[str, ...] = FATAL_SCIENTIFIC_CATEGORIES
    repairable_categories: Tuple[str, ...] = REPAIRABLE_ENGINEERING_CATEGORIES

    def __post_init__(self) -> None:
        if not self.policy_ref:
            raise ValueError("preexecution remediation policy reference is required")
        if self.maximum_engineering_remediations < 0:
            raise ValueError("engineering remediation bound cannot be negative")
        categories = self.fatal_categories + self.repairable_categories
        if not all(categories) or len(categories) != len(set(categories)):
            raise ValueError("preexecution remediation categories must be unique")

    @property
    def policy_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "version": PREEXECUTION_REMEDIATION_VERSION,
            "policy_ref": self.policy_ref,
            "maximum_engineering_remediations": self.maximum_engineering_remediations,
            "fatal_categories": list(self.fatal_categories),
            "repairable_categories": list(self.repairable_categories),
        }
        if include_id:
            value["policy_id"] = self.policy_id
        return value


@dataclass(frozen=True)
class PreexecutionRemediationDecision:
    policy_id: str
    defect_category: str
    defect_class: PreexecutionDefectClass
    remediation_index: int
    authorized: bool
    terminal_if_next_verification_fails: bool
    reason: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "policy_id": self.policy_id,
            "defect_category": self.defect_category,
            "defect_class": self.defect_class.value,
            "remediation_index": self.remediation_index,
            "authorized": self.authorized,
            "terminal_if_next_verification_fails": self.terminal_if_next_verification_fails,
            "reason": self.reason,
        }


def resolve_preexecution_remediation(
    policy: BoundedPreexecutionRemediationPolicy,
    *,
    defect_category: str,
    prior_engineering_remediations: int,
    model_invoked: bool,
    qualification_release_consumed: bool,
    raw_answer_or_outcome_accessed: bool,
    scientific_contract_changed: bool,
) -> PreexecutionRemediationDecision:
    if prior_engineering_remediations < 0:
        raise ValueError("prior remediation count cannot be negative")
    known = set(policy.fatal_categories + policy.repairable_categories)
    if defect_category not in known:
        raise ValueError("preexecution defect category is outside the policy")
    fatal_state = (
        model_invoked
        or qualification_release_consumed
        or raw_answer_or_outcome_accessed
        or scientific_contract_changed
        or defect_category in policy.fatal_categories
    )
    remediation_index = prior_engineering_remediations + 1
    within_cap = remediation_index <= policy.maximum_engineering_remediations
    authorized = not fatal_state and within_cap
    if fatal_state:
        reason = "fatal scientific or post-release state cannot be repaired by engineering reseal"
        defect_class = PreexecutionDefectClass.FATAL_SCIENTIFIC
    elif not within_cap:
        reason = "bounded engineering remediation allowance is exhausted"
        defect_class = PreexecutionDefectClass.REPAIRABLE_ENGINEERING
    else:
        reason = "answer-blind pre-execution engineering defect may receive one fresh reseal"
        defect_class = PreexecutionDefectClass.REPAIRABLE_ENGINEERING
    return PreexecutionRemediationDecision(
        policy_id=policy.policy_id,
        defect_category=defect_category,
        defect_class=defect_class,
        remediation_index=remediation_index,
        authorized=authorized,
        terminal_if_next_verification_fails=True,
        reason=reason,
    )
