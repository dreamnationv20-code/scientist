from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


PREEXECUTION_GOVERNANCE_VERSION = "bounded-pre-model-conformance-governance-v2"


class DefectClass(str, Enum):
    IMPLEMENTATION_CONFORMANCE = "implementation_conformance"
    SCIENTIFIC_PROTOCOL_INVALIDATING = "scientific_or_protocol_invalidating"
    AMBIGUOUS = "ambiguous"


IMPLEMENTATION_CONFORMANCE_CATEGORIES = (
    "manifest_or_schema_completeness",
    "artifact_or_source_binding",
    "implementation_formula_mismatch_to_unambiguous_frozen_contract",
    "runtime_or_precision_claim_mismatch",
    "deterministic_atomicity_or_serialization",
)

SCIENTIFIC_PROTOCOL_INVALIDATING_CATEGORIES = (
    "hypothesis_or_causal_question_change",
    "measurement_family_change",
    "fixture_or_task_semantics_change",
    "target_engagement_gate_change",
    "resource_cap_or_model_boundary_change",
    "analysis_estimand_or_tie_rule_change",
    "evidentiary_criterion_change",
    "answer_blindness_or_firewall_change",
    "post_model_or_outcome_adaptation",
)

PROTECTED_SCIENTIFIC_FIELDS = (
    "scientific_hypothesis",
    "measurement_family",
    "fixtures_and_task_semantics",
    "target_engagement_gates",
    "resource_caps",
    "analysis_and_estimands",
    "evidentiary_criteria",
    "answer_blindness_and_firewalls",
    "model_boundary",
)

REQUIRED_REAUDIT_CHECK_IDS = (
    "repair_token_identity",
    "single_use_ledger_identity",
    "zero_model_access",
    "protected_contract_identity",
    "protected_artifact_byte_identity",
    "changed_paths_exactly_authorized",
    "finding_to_diff_traceability",
    "implementation_conformance_restored",
    "no_scientific_or_protocol_change",
    "no_audit_ambiguity",
    "anti_loop_invariant",
    "fresh_independent_reaudit",
)


def _require_digest(value: str, name: str) -> None:
    if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
        raise ValueError("%s must be a lowercase sha256/content digest" % name)


def protected_contract_digest(contract: Mapping[str, Any]) -> str:
    missing = set(PROTECTED_SCIENTIFIC_FIELDS).difference(contract)
    if missing:
        raise ValueError("protected scientific contract is missing fields: %s" % ", ".join(sorted(missing)))
    extras = set(contract).difference(PROTECTED_SCIENTIFIC_FIELDS)
    if extras:
        raise ValueError("protected scientific contract has ungoverned fields: %s" % ", ".join(sorted(extras)))
    return content_digest({field: contract[field] for field in PROTECTED_SCIENTIFIC_FIELDS})


@dataclass(frozen=True)
class GovernancePolicy:
    policy_ref: str
    maximum_candidate_conformance_repairs: int = 1
    maximum_governance_meta_repairs: int = 1
    implementation_categories: Tuple[str, ...] = IMPLEMENTATION_CONFORMANCE_CATEGORIES
    scientific_categories: Tuple[str, ...] = SCIENTIFIC_PROTOCOL_INVALIDATING_CATEGORIES
    protected_fields: Tuple[str, ...] = PROTECTED_SCIENTIFIC_FIELDS
    required_reaudit_checks: Tuple[str, ...] = REQUIRED_REAUDIT_CHECK_IDS

    def __post_init__(self) -> None:
        if not self.policy_ref:
            raise ValueError("governance policy reference is required")
        if self.maximum_candidate_conformance_repairs != 1:
            raise ValueError("candidate conformance repair cap must be exactly one")
        if self.maximum_governance_meta_repairs != 1:
            raise ValueError("governance meta-repair cap must be exactly one")
        categories = self.implementation_categories + self.scientific_categories
        if len(categories) != len(set(categories)) or not all(categories):
            raise ValueError("defect categories must be nonempty and disjoint")
        if tuple(self.protected_fields) != PROTECTED_SCIENTIFIC_FIELDS:
            raise ValueError("protected scientific fields cannot be weakened or reordered")
        if tuple(self.required_reaudit_checks) != REQUIRED_REAUDIT_CHECK_IDS:
            raise ValueError("re-audit check registry cannot be weakened or reordered")

    @property
    def policy_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_ref": self.policy_ref,
            "maximum_candidate_conformance_repairs": self.maximum_candidate_conformance_repairs,
            "maximum_governance_meta_repairs": self.maximum_governance_meta_repairs,
            "implementation_conformance_categories": list(self.implementation_categories),
            "scientific_protocol_invalidating_categories": list(self.scientific_categories),
            "protected_scientific_fields": list(self.protected_fields),
            "required_fresh_reaudit_check_ids": list(self.required_reaudit_checks),
            "unknown_or_ambiguous_defect_action": "terminate_candidate",
            "repeated_conformance_failure_action": "terminate_candidate",
            "any_model_load_call_or_outcome_access_action": "terminate_candidate",
            "anti_loop_invariant": "lineage_repair_tokens_issued <= 1 and consumed_tokens are unique and every repair requires one fresh terminal re-audit",
        }
        if include_id:
            body["policy_id"] = self.policy_id
        return body


@dataclass(frozen=True)
class AuditDefect:
    finding_id: str
    category: str
    defect_class: DefectClass
    affected_paths: Tuple[str, ...]
    reason: str

    def __post_init__(self) -> None:
        _require_digest(self.finding_id, "finding_id")
        if not self.category or not self.reason or not self.affected_paths:
            raise ValueError("audit defect must have category, reason, and affected paths")
        if len(self.affected_paths) != len(set(self.affected_paths)) or not all(self.affected_paths):
            raise ValueError("affected paths must be unique and nonempty")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "finding_id": self.finding_id,
            "category": self.category,
            "defect_class": self.defect_class.value,
            "affected_paths": list(self.affected_paths),
            "reason": self.reason,
        }


@dataclass(frozen=True)
class ModelAccessAttestation:
    scientific_model_load_count: int
    scientific_model_call_count: int
    answer_or_outcome_access_count: int
    execution_claim_count: int
    model_output_artifact_count: int
    evidence_refs: Tuple[str, ...]

    def __post_init__(self) -> None:
        if min(
            self.scientific_model_load_count,
            self.scientific_model_call_count,
            self.answer_or_outcome_access_count,
            self.execution_claim_count,
            self.model_output_artifact_count,
        ) < 0:
            raise ValueError("model/outcome access counts cannot be negative")
        if not self.evidence_refs or len(self.evidence_refs) != len(set(self.evidence_refs)) or not all(self.evidence_refs):
            raise ValueError("zero-access evidence refs must be unique and nonempty")

    @property
    def evidence_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    @property
    def is_zero(self) -> bool:
        return (
            self.scientific_model_load_count == 0
            and self.scientific_model_call_count == 0
            and self.answer_or_outcome_access_count == 0
            and self.execution_claim_count == 0
            and self.model_output_artifact_count == 0
        )

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "scientific_model_load_count": self.scientific_model_load_count,
            "scientific_model_call_count": self.scientific_model_call_count,
            "answer_or_outcome_access_count": self.answer_or_outcome_access_count,
            "execution_claim_count": self.execution_claim_count,
            "model_output_artifact_count": self.model_output_artifact_count,
            "evidence_refs": list(self.evidence_refs),
            "zero_access": self.is_zero,
        }
        if include_id:
            body["evidence_id"] = self.evidence_id
        return body


@dataclass(frozen=True)
class CandidateEnvelope:
    candidate_id: str
    root_candidate_id: str
    package_id: str
    protected_contract: Mapping[str, Any]
    protected_artifact_hashes: Mapping[str, str]
    implementation_file_hashes: Mapping[str, str]

    def __post_init__(self) -> None:
        for value, name in (
            (self.candidate_id, "candidate_id"),
            (self.root_candidate_id, "root_candidate_id"),
            (self.package_id, "package_id"),
        ):
            _require_digest(value, name)
        protected_contract_digest(self.protected_contract)
        if not self.protected_artifact_hashes or not self.implementation_file_hashes:
            raise ValueError("candidate must bind protected and implementation files")
        overlap = set(self.protected_artifact_hashes).intersection(self.implementation_file_hashes)
        if overlap:
            raise ValueError("protected and implementation path registries must be disjoint")
        for registry in (self.protected_artifact_hashes, self.implementation_file_hashes):
            if not all(registry) or not all(value for value in registry.values()):
                raise ValueError("candidate file registries cannot contain empty paths or hashes")
            for path, digest in registry.items():
                _require_digest(digest, "hash for %s" % path)

    @property
    def protected_contract_id(self) -> str:
        return protected_contract_digest(self.protected_contract)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "root_candidate_id": self.root_candidate_id,
            "package_id": self.package_id,
            "protected_contract": dict(self.protected_contract),
            "protected_contract_id": self.protected_contract_id,
            "protected_artifact_hashes": dict(self.protected_artifact_hashes),
            "implementation_file_hashes": dict(self.implementation_file_hashes),
        }


@dataclass(frozen=True)
class RepairLedger:
    policy_id: str
    root_candidate_id: str
    issued_token_ids: Tuple[str, ...] = ()
    consumed_token_ids: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _require_digest(self.policy_id, "ledger policy_id")
        _require_digest(self.root_candidate_id, "ledger root_candidate_id")
        if len(self.issued_token_ids) != len(set(self.issued_token_ids)):
            raise ValueError("repair tokens cannot be issued twice")
        if len(self.consumed_token_ids) != len(set(self.consumed_token_ids)):
            raise ValueError("repair tokens cannot be consumed twice")
        if not set(self.consumed_token_ids).issubset(self.issued_token_ids):
            raise ValueError("only issued repair tokens may be consumed")
        if len(self.issued_token_ids) > 1 or len(self.consumed_token_ids) > 1:
            raise ValueError("anti-loop invariant violated: more than one repair in a lineage")
        for value in self.issued_token_ids + self.consumed_token_ids:
            _require_digest(value, "repair token id")

    @property
    def ledger_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_id": self.policy_id,
            "root_candidate_id": self.root_candidate_id,
            "issued_token_ids": list(self.issued_token_ids),
            "consumed_token_ids": list(self.consumed_token_ids),
            "anti_loop_invariant_satisfied": len(self.issued_token_ids) <= 1 and len(self.consumed_token_ids) <= 1,
        }
        if include_id:
            body["ledger_id"] = self.ledger_id
        return body


@dataclass(frozen=True)
class RepairDecision:
    policy_id: str
    root_candidate_id: str
    baseline_candidate_id: str
    parent_audit_id: str
    authorized: bool
    terminal: bool
    classification: str
    allowed_changed_paths: Tuple[str, ...]
    protected_contract_id: str
    reason: str

    @property
    def decision_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_id": self.policy_id,
            "root_candidate_id": self.root_candidate_id,
            "baseline_candidate_id": self.baseline_candidate_id,
            "parent_audit_id": self.parent_audit_id,
            "authorized": self.authorized,
            "terminal": self.terminal,
            "classification": self.classification,
            "allowed_changed_paths": list(self.allowed_changed_paths),
            "protected_contract_id": self.protected_contract_id,
            "reason": self.reason,
        }
        if include_id:
            body["decision_id"] = self.decision_id
        return body


def classify_preexecution_audit(
    policy: GovernancePolicy,
    *,
    candidate: CandidateEnvelope,
    parent_audit_id: str,
    findings: Sequence[AuditDefect],
    access: ModelAccessAttestation,
    ledger: RepairLedger,
) -> RepairDecision:
    _require_digest(parent_audit_id, "parent_audit_id")
    if ledger.policy_id != policy.policy_id or ledger.root_candidate_id != candidate.root_candidate_id:
        raise ValueError("repair ledger provenance does not match policy/candidate")
    if not findings:
        return RepairDecision(
            policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
            False, True, "audit_ambiguity", (), candidate.protected_contract_id,
            "a rejected audit without explicit defect findings is ambiguous and terminal",
        )
    unique_findings = {finding.finding_id for finding in findings}
    if len(unique_findings) != len(findings):
        raise ValueError("audit findings must be unique")
    if not access.is_zero:
        return RepairDecision(
            policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
            False, True, "post_model_or_outcome_state", (), candidate.protected_contract_id,
            "any model load, model call, answer access, or outcome access terminates repair eligibility",
        )
    if ledger.issued_token_ids or ledger.consumed_token_ids:
        return RepairDecision(
            policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
            False, True, "repair_allowance_exhausted", (), candidate.protected_contract_id,
            "the lineage has already issued or consumed its only repair token",
        )
    for finding in findings:
        if finding.defect_class is DefectClass.AMBIGUOUS:
            return RepairDecision(
                policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
                False, True, "audit_ambiguity", (), candidate.protected_contract_id,
                "any ambiguous finding terminates the candidate",
            )
        if (
            finding.defect_class is DefectClass.SCIENTIFIC_PROTOCOL_INVALIDATING
            or finding.category in policy.scientific_categories
        ):
            return RepairDecision(
                policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
                False, True, "scientific_or_protocol_invalidating", (), candidate.protected_contract_id,
                "scientific or protocol-invalidating defects cannot be repaired under this policy",
            )
        if (
            finding.defect_class is not DefectClass.IMPLEMENTATION_CONFORMANCE
            or finding.category not in policy.implementation_categories
        ):
            return RepairDecision(
                policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
                False, True, "unknown_or_inconsistent_classification", (), candidate.protected_contract_id,
                "unknown or class/category-inconsistent findings terminate the candidate",
            )
    paths = tuple(sorted({path for finding in findings for path in finding.affected_paths}))
    if not set(paths).issubset(candidate.implementation_file_hashes):
        return RepairDecision(
            policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
            False, True, "protected_or_unregistered_diff_scope", (), candidate.protected_contract_id,
            "a conformance repair may touch only registered implementation files",
        )
    return RepairDecision(
        policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
        True, False, "implementation_conformance", paths, candidate.protected_contract_id,
        "exactly one pre-model implementation-conformance repair may be sealed for fresh independent re-audit",
    )


def issue_single_use_repair_token(
    policy: GovernancePolicy,
    *,
    decision: RepairDecision,
    candidate: CandidateEnvelope,
    access: ModelAccessAttestation,
    ledger: RepairLedger,
    versioned_replacement_paths: Mapping[str, str],
) -> tuple[Mapping[str, Any], RepairLedger]:
    if not decision.authorized or decision.terminal or decision.classification != "implementation_conformance":
        raise ValueError("repair decision does not authorize a token")
    if decision.policy_id != policy.policy_id or decision.baseline_candidate_id != candidate.candidate_id:
        raise ValueError("repair decision provenance mismatch")
    if decision.protected_contract_id != candidate.protected_contract_id or not access.is_zero:
        raise ValueError("protected contract or zero-access condition changed")
    if ledger.policy_id != policy.policy_id or ledger.root_candidate_id != candidate.root_candidate_id:
        raise ValueError("repair ledger provenance mismatch")
    if ledger.issued_token_ids or ledger.consumed_token_ids:
        raise ValueError("anti-loop invariant blocks a second token")
    if set(versioned_replacement_paths) != set(decision.allowed_changed_paths):
        raise ValueError("every affected implementation path requires one exact replacement path")
    replacements = tuple(versioned_replacement_paths.values())
    occupied = set(candidate.implementation_file_hashes).union(candidate.protected_artifact_hashes)
    if (
        len(replacements) != len(set(replacements))
        or any(not path or path in occupied for path in replacements)
        or any("r1" not in path.rsplit("/", 1)[-1] for path in replacements)
    ):
        raise ValueError("repair targets must be unique, new, explicitly r1-versioned paths")
    body = {
        "version": PREEXECUTION_GOVERNANCE_VERSION,
        "policy_id": policy.policy_id,
        "decision_id": decision.decision_id,
        "root_candidate_id": candidate.root_candidate_id,
        "baseline_candidate_id": candidate.candidate_id,
        "baseline_package_id": candidate.package_id,
        "parent_audit_id": decision.parent_audit_id,
        "repair_index": 1,
        "maximum_uses": 1,
        "allowed_changed_paths": list(decision.allowed_changed_paths),
        "versioned_replacement_paths": dict(versioned_replacement_paths),
        "baseline_implementation_file_hashes": dict(candidate.implementation_file_hashes),
        "protected_contract_id": candidate.protected_contract_id,
        "protected_artifact_hashes": dict(candidate.protected_artifact_hashes),
        "zero_model_access_evidence_id": access.evidence_id,
        "required_fresh_reaudit_check_ids": list(policy.required_reaudit_checks),
        "rejection_or_second_failure_action": "terminate_candidate",
    }
    token = {**body, "repair_token_id": content_digest(body)}
    next_ledger = RepairLedger(
        policy_id=ledger.policy_id,
        root_candidate_id=ledger.root_candidate_id,
        issued_token_ids=(token["repair_token_id"],),
        consumed_token_ids=(),
    )
    return token, next_ledger


def verify_and_consume_repair_submission(
    policy: GovernancePolicy,
    *,
    token: Mapping[str, Any],
    baseline: CandidateEnvelope,
    repaired: CandidateEnvelope,
    access: ModelAccessAttestation,
    ledger: RepairLedger,
) -> tuple[Mapping[str, Any], RepairLedger]:
    token_id = str(token.get("repair_token_id", ""))
    if token_id != content_digest({key: value for key, value in token.items() if key != "repair_token_id"}):
        raise ValueError("repair token identity mismatch")
    if (
        token.get("policy_id") != policy.policy_id
        or token.get("repair_index") != 1
        or token.get("maximum_uses") != 1
        or baseline.candidate_id != token.get("baseline_candidate_id")
        or repaired.root_candidate_id != baseline.root_candidate_id
        or repaired.root_candidate_id != token.get("root_candidate_id")
    ):
        raise ValueError("repair token provenance or single-use index mismatch")
    if ledger.issued_token_ids != (token_id,) or ledger.consumed_token_ids:
        raise ValueError("repair token is unissued, already consumed, or lineage is ambiguous")
    if not access.is_zero or access.evidence_id == token.get("zero_model_access_evidence_id"):
        # A new attestation is mandatory, not merely a copied pre-repair assertion.
        raise ValueError("repair submission requires fresh zero-model-access evidence")
    if baseline.protected_contract_id != repaired.protected_contract_id or repaired.protected_contract_id != token.get("protected_contract_id"):
        raise ValueError("protected scientific contract changed during repair")
    if dict(repaired.protected_artifact_hashes) != dict(token.get("protected_artifact_hashes", {})):
        raise ValueError("protected artifact bytes changed during repair")
    if dict(baseline.implementation_file_hashes) != dict(token.get("baseline_implementation_file_hashes", {})):
        raise ValueError("baseline implementation provenance changed")
    allowed = tuple(token.get("allowed_changed_paths", ()))
    replacement_map = dict(token.get("versioned_replacement_paths", {}))
    if set(replacement_map) != set(allowed):
        raise ValueError("replacement map does not match the authorized path set")
    expected_paths = (set(baseline.implementation_file_hashes).difference(allowed)).union(replacement_map.values())
    if set(repaired.implementation_file_hashes) != expected_paths:
        raise ValueError("repaired implementation registry is not the exact versioned replacement set")
    for path in set(baseline.implementation_file_hashes).difference(allowed):
        if repaired.implementation_file_hashes[path] != baseline.implementation_file_hashes[path]:
            raise ValueError("unaffected implementation bytes changed")
    for old_path, new_path in replacement_map.items():
        if repaired.implementation_file_hashes[new_path] == baseline.implementation_file_hashes[old_path]:
            raise ValueError("versioned replacement bytes are unchanged")
    body = {
        "version": PREEXECUTION_GOVERNANCE_VERSION,
        "policy_id": policy.policy_id,
        "repair_token_id": token_id,
        "root_candidate_id": repaired.root_candidate_id,
        "baseline_candidate_id": baseline.candidate_id,
        "repaired_candidate_id": repaired.candidate_id,
        "repaired_package_id": repaired.package_id,
        "repair_index": 1,
        "changed_components": list(allowed),
        "versioned_replacement_paths": replacement_map,
        "before_hashes": {path: baseline.implementation_file_hashes[path] for path in allowed},
        "after_hashes": {replacement_map[path]: repaired.implementation_file_hashes[replacement_map[path]] for path in allowed},
        "protected_contract_id": repaired.protected_contract_id,
        "protected_artifact_hashes": dict(repaired.protected_artifact_hashes),
        "fresh_zero_model_access_evidence_id": access.evidence_id,
        "fresh_independent_reaudit_required": True,
    }
    submission = {**body, "submission_id": content_digest(body)}
    consumed = RepairLedger(
        policy_id=ledger.policy_id,
        root_candidate_id=ledger.root_candidate_id,
        issued_token_ids=ledger.issued_token_ids,
        consumed_token_ids=(token_id,),
    )
    return submission, consumed


def evaluate_fresh_reaudit(
    policy: GovernancePolicy,
    *,
    token: Mapping[str, Any],
    submission: Mapping[str, Any],
    ledger: RepairLedger,
    audit_id: str,
    check_ids: Sequence[str],
    checks_passed: Sequence[bool],
    critical_defect_count: int,
    disposition: str,
    access: ModelAccessAttestation,
) -> Mapping[str, Any]:
    _require_digest(audit_id, "fresh re-audit id")
    token_id = str(token.get("repair_token_id", ""))
    submission_id = str(submission.get("submission_id", ""))
    if submission_id != content_digest({key: value for key, value in submission.items() if key != "submission_id"}):
        raise ValueError("repair submission identity mismatch")
    exact_registry = (
        len(check_ids) == len(policy.required_reaudit_checks)
        and len(set(check_ids)) == len(check_ids)
        and set(check_ids) == set(policy.required_reaudit_checks)
        and len(checks_passed) == len(check_ids)
    )
    provenance_valid = (
        token_id in ledger.issued_token_ids
        and token_id in ledger.consumed_token_ids
        and submission.get("repair_token_id") == token_id
        and token.get("repair_index") == 1
    )
    passed = (
        exact_registry
        and provenance_valid
        and access.is_zero
        and critical_defect_count == 0
        and all(checks_passed)
        and disposition == "activate_candidate_after_conformance_reaudit"
    )
    body = {
        "version": PREEXECUTION_GOVERNANCE_VERSION,
        "policy_id": policy.policy_id,
        "repair_token_id": token_id,
        "submission_id": submission_id,
        "fresh_reaudit_id": audit_id,
        "exact_reaudit_check_registry": exact_registry,
        "single_use_provenance_valid": provenance_valid,
        "zero_model_access": access.is_zero,
        "critical_defect_count": critical_defect_count,
        "all_checks_passed": bool(checks_passed) and all(checks_passed),
        "disposition": disposition,
        "authorized": passed,
        "terminal": not passed,
        "next_action": "candidate may proceed only to its previously frozen next boundary" if passed else "terminate candidate; no second repair or audit loop",
        "anti_loop_invariant_satisfied": len(ledger.issued_token_ids) == 1 and len(ledger.consumed_token_ids) == 1,
    }
    return {**body, "reaudit_decision_id": content_digest(body)}
