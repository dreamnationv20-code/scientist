from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest
from scientist.science.preexecution_governance_v2 import (
    IMPLEMENTATION_CONFORMANCE_CATEGORIES,
    PROTECTED_SCIENTIFIC_FIELDS,
    REQUIRED_REAUDIT_CHECK_IDS,
    SCIENTIFIC_PROTOCOL_INVALIDATING_CATEGORIES,
    AuditDefect,
    CandidateEnvelope,
    DefectClass,
    RepairDecision,
    protected_contract_digest,
)


PREEXECUTION_GOVERNANCE_VERSION = "bounded-pre-model-conformance-governance-v2-r1"
AUDIT_EXCHANGE_VERSION = "codex-structured-exchange-v1"
ACCESS_EVENT_KINDS = (
    "scientific_model_load",
    "scientific_model_call",
    "answer_or_outcome_access",
    "execution_claim",
    "model_output_artifact",
)
ACCESS_CHECKPOINT_PHASES = ("pre_repair", "post_repair", "pre_reaudit")
INITIAL_AUDIT_OPERATION = "independently_audit_frozen_preexecution_candidate"
INITIAL_AUDIT_PRODUCER = "autonomous-ai-scientist-independent-preexecution-candidate-auditor"
REAUDIT_OPERATION = "independently_reaudit_candidate_after_conformance_repair"
REAUDIT_PRODUCER = "autonomous-ai-scientist-independent-preexecution-candidate-reauditor"


def _array(item: Mapping[str, Any], minimum: int, maximum: int) -> Mapping[str, Any]:
    return {"type": "array", "minItems": minimum, "maxItems": maximum, "items": dict(item)}


def initial_audit_response_schema() -> Mapping[str, Any]:
    string = {"type": "string"}
    finding = {
        "type": "object",
        "properties": {
            "defect_class": {"type": "string", "enum": [item.value for item in DefectClass]},
            "category": {"type": "string", "enum": list(IMPLEMENTATION_CONFORMANCE_CATEGORIES + SCIENTIFIC_PROTOCOL_INVALIDATING_CATEGORIES)},
            "affected_paths": _array(string, 1, 16),
            "reason": string,
        },
        "required": ["defect_class", "category", "affected_paths", "reason"],
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {
            "disposition": {"type": "string", "enum": ["authorize_one_implementation_conformance_repair", "reject_candidate_terminal"]},
            "defect_findings": _array(finding, 0, 16),
            "critical_defects": _array(string, 0, 16),
        },
        "required": ["disposition", "defect_findings", "critical_defects"],
        "additionalProperties": False,
    }


def reaudit_response_schema() -> Mapping[str, Any]:
    string = {"type": "string"}
    check = {
        "type": "object",
        "properties": {
            "check_id": {"type": "string", "enum": list(REQUIRED_REAUDIT_CHECK_IDS)},
            "passed": {"type": "boolean"},
            "reason": string,
            "evidence_refs": _array(string, 1, 8),
        },
        "required": ["check_id", "passed", "reason", "evidence_refs"],
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "properties": {
            "repair_token_id": string,
            "submission_id": string,
            "parent_audit_evidence_id": string,
            "pre_reaudit_checkpoint_id": string,
            "checks": _array(check, len(REQUIRED_REAUDIT_CHECK_IDS), len(REQUIRED_REAUDIT_CHECK_IDS)),
            "critical_defects": _array(string, 0, 16),
            "audit_ambiguity": {"type": "boolean"},
            "disposition": {"type": "string", "enum": ["activate_candidate_after_conformance_reaudit", "reject_candidate_after_conformance_reaudit"]},
        },
        "required": [
            "repair_token_id", "submission_id", "parent_audit_evidence_id", "pre_reaudit_checkpoint_id",
            "checks", "critical_defects", "audit_ambiguity", "disposition",
        ],
        "additionalProperties": False,
    }


def _require_digest(value: str, name: str) -> None:
    if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
        raise ValueError("%s must be a lowercase sha256/content digest" % name)


def _read_object(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("expected JSON object: %s" % path)
    return value


def _write_exclusive(path: Path, value: Mapping[str, Any]) -> None:
    payload = (json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class GovernancePolicy:
    policy_ref: str
    repair_authority_root: str
    access_authority_root: str
    maximum_candidate_conformance_repairs: int = 1
    maximum_governance_meta_repairs: int = 1
    implementation_categories: Tuple[str, ...] = IMPLEMENTATION_CONFORMANCE_CATEGORIES
    scientific_categories: Tuple[str, ...] = SCIENTIFIC_PROTOCOL_INVALIDATING_CATEGORIES
    protected_fields: Tuple[str, ...] = PROTECTED_SCIENTIFIC_FIELDS
    required_reaudit_checks: Tuple[str, ...] = REQUIRED_REAUDIT_CHECK_IDS

    def __post_init__(self) -> None:
        if not self.policy_ref:
            raise ValueError("governance policy reference is required")
        for value, name in ((self.repair_authority_root, "repair authority"), (self.access_authority_root, "access authority")):
            path = Path(value)
            if not path.is_absolute():
                raise ValueError("%s root must be absolute and policy-bound" % name)
        if Path(self.repair_authority_root) == Path(self.access_authority_root):
            raise ValueError("repair and access authority roots must be separate")
        if self.maximum_candidate_conformance_repairs != 1 or self.maximum_governance_meta_repairs != 1:
            raise ValueError("candidate and meta repair caps must each equal one")
        if tuple(self.protected_fields) != PROTECTED_SCIENTIFIC_FIELDS:
            raise ValueError("protected scientific fields cannot change")
        if tuple(self.required_reaudit_checks) != REQUIRED_REAUDIT_CHECK_IDS:
            raise ValueError("fresh re-audit registry cannot change")
        categories = self.implementation_categories + self.scientific_categories
        if len(categories) != len(set(categories)) or not all(categories):
            raise ValueError("defect categories must remain nonempty and disjoint")

    @property
    def policy_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_ref": self.policy_ref,
            "repair_authority_root": str(Path(self.repair_authority_root)),
            "access_authority_root": str(Path(self.access_authority_root)),
            "maximum_candidate_conformance_repairs": self.maximum_candidate_conformance_repairs,
            "maximum_governance_meta_repairs": self.maximum_governance_meta_repairs,
            "implementation_conformance_categories": list(self.implementation_categories),
            "scientific_protocol_invalidating_categories": list(self.scientific_categories),
            "protected_scientific_fields": list(self.protected_fields),
            "required_fresh_reaudit_check_ids": list(self.required_reaudit_checks),
            "initial_audit_operation": INITIAL_AUDIT_OPERATION,
            "initial_audit_producer": INITIAL_AUDIT_PRODUCER,
            "reaudit_operation": REAUDIT_OPERATION,
            "reaudit_producer": REAUDIT_PRODUCER,
            "unknown_or_ambiguous_action": "terminate_candidate",
            "any_access_action": "terminate_candidate",
            "repeated_failure_action": "terminate_candidate",
            "anti_loop_invariant": "one canonical issued file per root candidate and one canonical consumed file per token",
        }
        if include_id:
            body["policy_id"] = self.policy_id
        return body


class RepairAuthorityStore:
    """Filesystem-authoritative, append-only single-use lineage registry."""

    def __init__(self, policy: GovernancePolicy) -> None:
        self.policy = policy
        self.root = Path(policy.repair_authority_root)
        self.root.mkdir(parents=True, exist_ok=True)
        policy_path = self.root / "policy.json"
        policy_binding = {"version": PREEXECUTION_GOVERNANCE_VERSION, "policy_id": policy.policy_id, "root": str(self.root)}
        binding = {**policy_binding, "binding_id": content_digest(policy_binding)}
        if policy_path.exists():
            if _read_object(policy_path) != binding:
                raise ValueError("repair authority policy binding changed")
        else:
            _write_exclusive(policy_path, binding)

    def _issued_path(self, root_candidate_id: str) -> Path:
        _require_digest(root_candidate_id, "root_candidate_id")
        return self.root / "issued" / (root_candidate_id + ".json")

    def _consumed_path(self, token_id: str) -> Path:
        _require_digest(token_id, "repair_token_id")
        return self.root / "consumed" / (token_id + ".json")

    def issued_record(self, root_candidate_id: str) -> Mapping[str, Any] | None:
        path = self._issued_path(root_candidate_id)
        if not path.exists():
            return None
        value = _read_object(path)
        if value.get("issuance_id") != content_digest({key: item for key, item in value.items() if key != "issuance_id"}):
            raise ValueError("repair issuance record identity mismatch")
        return value

    def consumed_record(self, token_id: str) -> Mapping[str, Any] | None:
        path = self._consumed_path(token_id)
        if not path.exists():
            return None
        value = _read_object(path)
        if value.get("consumption_id") != content_digest({key: item for key, item in value.items() if key != "consumption_id"}):
            raise ValueError("repair consumption record identity mismatch")
        return value

    def issue(self, token: Mapping[str, Any]) -> Mapping[str, Any]:
        root_candidate_id = str(token["root_candidate_id"])
        token_id = str(token["repair_token_id"])
        if self.issued_record(root_candidate_id) is not None:
            raise ValueError("anti-loop invariant: root candidate already received its only repair token")
        body = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_id": self.policy.policy_id,
            "root_candidate_id": root_candidate_id,
            "repair_token_id": token_id,
            "token_digest_verified": token_id == content_digest({key: value for key, value in token.items() if key != "repair_token_id"}),
            "repair_index": token["repair_index"],
        }
        if not body["token_digest_verified"] or body["repair_index"] != 1:
            raise ValueError("repair token identity or index invalid")
        record = {**body, "issuance_id": content_digest(body)}
        try:
            _write_exclusive(self._issued_path(root_candidate_id), record)
        except FileExistsError as error:
            raise ValueError("anti-loop invariant: concurrent or prior issuance exists") from error
        return record

    def consume(self, token: Mapping[str, Any], submission_id: str) -> Mapping[str, Any]:
        token_id = str(token["repair_token_id"])
        _require_digest(submission_id, "submission_id")
        issued = self.issued_record(str(token["root_candidate_id"]))
        if issued is None or issued["repair_token_id"] != token_id:
            raise ValueError("repair token has no canonical issuance")
        if self.consumed_record(token_id) is not None:
            raise ValueError("repair token was already consumed")
        body = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_id": self.policy.policy_id,
            "root_candidate_id": token["root_candidate_id"],
            "repair_token_id": token_id,
            "issuance_id": issued["issuance_id"],
            "submission_id": submission_id,
            "consumption_index": 1,
        }
        record = {**body, "consumption_id": content_digest(body)}
        try:
            _write_exclusive(self._consumed_path(token_id), record)
        except FileExistsError as error:
            raise ValueError("repair token was concurrently or previously consumed") from error
        return record

    def snapshot(self, root_candidate_id: str) -> Mapping[str, Any]:
        issued = self.issued_record(root_candidate_id)
        consumed = self.consumed_record(str(issued["repair_token_id"])) if issued is not None else None
        body = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_id": self.policy.policy_id,
            "authority_root": str(self.root),
            "root_candidate_id": root_candidate_id,
            "issued_record": issued,
            "consumed_record": consumed,
            "issued_count": 1 if issued else 0,
            "consumed_count": 1 if consumed else 0,
            "anti_loop_invariant_satisfied": (1 if issued else 0) <= 1 and (1 if consumed else 0) <= 1,
        }
        return {**body, "snapshot_id": content_digest(body)}


class AccessAuthorityStore:
    """Canonical access-event registry and phase-chained zero-access checkpoints."""

    def __init__(self, policy: GovernancePolicy) -> None:
        self.policy = policy
        self.root = Path(policy.access_authority_root)
        self.root.mkdir(parents=True, exist_ok=True)
        policy_path = self.root / "policy.json"
        policy_binding = {"version": PREEXECUTION_GOVERNANCE_VERSION, "policy_id": policy.policy_id, "root": str(self.root)}
        binding = {**policy_binding, "binding_id": content_digest(policy_binding)}
        if policy_path.exists():
            if _read_object(policy_path) != binding:
                raise ValueError("access authority policy binding changed")
        else:
            _write_exclusive(policy_path, binding)

    def _event_directory(self, root_candidate_id: str) -> Path:
        _require_digest(root_candidate_id, "root_candidate_id")
        return self.root / "events" / root_candidate_id

    def _checkpoint_path(self, root_candidate_id: str, phase: str) -> Path:
        if phase not in ACCESS_CHECKPOINT_PHASES:
            raise ValueError("unknown access-checkpoint phase")
        return self.root / "checkpoints" / root_candidate_id / (phase + ".json")

    def record_access_event(self, root_candidate_id: str, event_kind: str, event_ref: str) -> Mapping[str, Any]:
        if event_kind not in ACCESS_EVENT_KINDS or not event_ref:
            raise ValueError("unknown access event or empty reference")
        body = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_id": self.policy.policy_id,
            "root_candidate_id": root_candidate_id,
            "event_kind": event_kind,
            "event_ref": event_ref,
        }
        event = {**body, "event_id": content_digest(body)}
        _write_exclusive(self._event_directory(root_candidate_id) / (event["event_id"] + ".json"), event)
        return event

    def _events(self, root_candidate_id: str) -> list[Mapping[str, Any]]:
        directory = self._event_directory(root_candidate_id)
        events = []
        for path in sorted(directory.glob("*.json")) if directory.exists() else []:
            value = _read_object(path)
            if value.get("event_id") != content_digest({key: item for key, item in value.items() if key != "event_id"}):
                raise ValueError("access event identity mismatch")
            if value.get("policy_id") != self.policy.policy_id or value.get("root_candidate_id") != root_candidate_id:
                raise ValueError("access event provenance mismatch")
            events.append(value)
        return events

    def checkpoint(self, root_candidate_id: str, phase: str, parent_checkpoint_id: str | None) -> Mapping[str, Any]:
        expected_index = ACCESS_CHECKPOINT_PHASES.index(phase)
        if expected_index == 0:
            if parent_checkpoint_id is not None:
                raise ValueError("pre-repair checkpoint cannot have a parent")
        else:
            prior_phase = ACCESS_CHECKPOINT_PHASES[expected_index - 1]
            prior = self.read_checkpoint(root_candidate_id, prior_phase)
            if prior is None or prior["checkpoint_id"] != parent_checkpoint_id:
                raise ValueError("zero-access checkpoint chain is incomplete or stale")
        events = self._events(root_candidate_id)
        if events:
            raise ValueError("nonzero authoritative access-event registry terminates repair eligibility")
        body = {
            "version": PREEXECUTION_GOVERNANCE_VERSION,
            "policy_id": self.policy.policy_id,
            "authority_root": str(self.root),
            "root_candidate_id": root_candidate_id,
            "phase": phase,
            "phase_index": expected_index,
            "parent_checkpoint_id": parent_checkpoint_id,
            "access_event_ids": [],
            "scientific_model_load_count": 0,
            "scientific_model_call_count": 0,
            "answer_or_outcome_access_count": 0,
            "execution_claim_count": 0,
            "model_output_artifact_count": 0,
            "zero_access": True,
        }
        value = {**body, "checkpoint_id": content_digest(body)}
        try:
            _write_exclusive(self._checkpoint_path(root_candidate_id, phase), value)
        except FileExistsError as error:
            raise ValueError("zero-access phase checkpoint already exists") from error
        return value

    def read_checkpoint(self, root_candidate_id: str, phase: str) -> Mapping[str, Any] | None:
        path = self._checkpoint_path(root_candidate_id, phase)
        if not path.exists():
            return None
        value = _read_object(path)
        if value.get("checkpoint_id") != content_digest({key: item for key, item in value.items() if key != "checkpoint_id"}):
            raise ValueError("zero-access checkpoint identity mismatch")
        return value

    def verify_checkpoint(self, checkpoint: Mapping[str, Any], root_candidate_id: str, phase: str) -> None:
        canonical = self.read_checkpoint(root_candidate_id, phase)
        if canonical is None or canonical != checkpoint:
            raise ValueError("zero-access checkpoint is not the canonical authority record")
        if checkpoint.get("policy_id") != self.policy.policy_id or not checkpoint.get("zero_access"):
            raise ValueError("zero-access checkpoint policy/status mismatch")
        if self._events(root_candidate_id):
            raise ValueError("access occurred after the zero-access checkpoint")


def verify_independent_audit_exchange(
    request_path: Path,
    response_path: Path,
    receipt_path: Path,
    *,
    expected_operation: str,
    expected_producer: str,
    expected_response_schema: Mapping[str, Any],
) -> Mapping[str, Any]:
    request_path, response_path, receipt_path = map(Path, (request_path, response_path, receipt_path))
    request, response, receipt = map(_read_object, (request_path, response_path, receipt_path))
    identity = {
        "exchange_version": request.get("exchange_version"),
        "operation": request.get("operation"),
        "producer_ref": request.get("producer_ref"),
        "prompt": request.get("prompt"),
        "response_schema": request.get("response_schema"),
    }
    packet_id = content_digest(identity)
    if (
        request.get("packet_id") != packet_id
        or request.get("exchange_version") != AUDIT_EXCHANGE_VERSION
        or request.get("operation") != expected_operation
        or request.get("producer_ref") != expected_producer
        or request.get("response_schema") != expected_response_schema
        or Path(str(request.get("response_path", ""))).resolve() != response_path.resolve()
    ):
        raise ValueError("independent audit request identity or provenance mismatch")
    worker = response.get("worker", {})
    if (
        response.get("schema") != 1
        or response.get("exchange_version") != AUDIT_EXCHANGE_VERSION
        or response.get("packet_id") != packet_id
        or response.get("producer_ref") != expected_producer
        or worker.get("kind") != "authenticated_local_codex_cli"
        or worker.get("sandbox") != "read-only"
        or worker.get("api_key_environment_removed") is not True
        or not isinstance(response.get("response"), dict)
    ):
        raise ValueError("independent audit response envelope provenance mismatch")
    if (
        receipt.get("schema") != 1
        or receipt.get("exchange_version") != AUDIT_EXCHANGE_VERSION
        or receipt.get("packet_id") != packet_id
        or receipt.get("operation") != expected_operation
        or receipt.get("producer_ref") != expected_producer
        or receipt.get("request_digest") != content_digest(request)
        or receipt.get("response_digest") != content_digest(response)
        or receipt.get("status") != "validated_and_consumed"
        or receipt.get("worker") != worker
    ):
        raise ValueError("independent audit receipt identity or provenance mismatch")
    body = {
        "version": PREEXECUTION_GOVERNANCE_VERSION,
        "packet_id": packet_id,
        "operation": expected_operation,
        "producer_ref": expected_producer,
        "request_path": str(request_path.resolve()),
        "request_sha256": _sha256(request_path),
        "response_path": str(response_path.resolve()),
        "response_sha256": _sha256(response_path),
        "receipt_path": str(receipt_path.resolve()),
        "receipt_sha256": _sha256(receipt_path),
        "worker": worker,
        "response": response["response"],
    }
    return {**body, "audit_evidence_id": content_digest(body)}


def _defects_from_audit(audit_evidence: Mapping[str, Any]) -> list[AuditDefect]:
    response = audit_evidence["response"]
    raw = response.get("defect_findings")
    if not isinstance(raw, list):
        raise ValueError("independent audit response has no defect-finding registry")
    findings = []
    for item in raw:
        if not isinstance(item, dict):
            raise ValueError("audit defect finding is not an object")
        defect_class = DefectClass(str(item.get("defect_class")))
        body = {
            "category": str(item.get("category", "")),
            "defect_class": defect_class.value,
            "affected_paths": list(item.get("affected_paths", ())),
            "reason": str(item.get("reason", "")),
        }
        findings.append(AuditDefect(content_digest(body), body["category"], defect_class, tuple(body["affected_paths"]), body["reason"]))
    return findings


def classify_preexecution_audit(
    policy: GovernancePolicy,
    *,
    candidate: CandidateEnvelope,
    audit_request_path: Path,
    audit_response_path: Path,
    audit_receipt_path: Path,
    pre_repair_checkpoint: Mapping[str, Any],
    repair_store: RepairAuthorityStore,
    access_store: AccessAuthorityStore,
) -> RepairDecision:
    if repair_store.policy.policy_id != policy.policy_id or access_store.policy.policy_id != policy.policy_id:
        raise ValueError("authority stores are not bound to the policy")
    access_store.verify_checkpoint(pre_repair_checkpoint, candidate.root_candidate_id, "pre_repair")
    audit_evidence = verify_independent_audit_exchange(
        audit_request_path,
        audit_response_path,
        audit_receipt_path,
        expected_operation=INITIAL_AUDIT_OPERATION,
        expected_producer=INITIAL_AUDIT_PRODUCER,
        expected_response_schema=initial_audit_response_schema(),
    )
    parent_audit_id = str(audit_evidence.get("audit_evidence_id", ""))
    _require_digest(parent_audit_id, "audit evidence id")
    if repair_store.issued_record(candidate.root_candidate_id) is not None:
        return RepairDecision(
            policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
            False, True, "repair_allowance_exhausted", (), candidate.protected_contract_id,
            "the authoritative lineage store already contains the only permitted issuance",
        )
    try:
        findings = _defects_from_audit(audit_evidence)
    except (ValueError, TypeError):
        findings = []
    response = audit_evidence.get("response", {})
    if response.get("disposition") != "authorize_one_implementation_conformance_repair" or not findings:
        return RepairDecision(
            policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
            False, True, "audit_ambiguity_or_nonrepair_disposition", (), candidate.protected_contract_id,
            "only an explicit independent one-repair disposition with nonempty classified findings is eligible",
        )
    for finding in findings:
        if finding.defect_class is DefectClass.AMBIGUOUS:
            classification = "audit_ambiguity"
        elif finding.defect_class is DefectClass.SCIENTIFIC_PROTOCOL_INVALIDATING or finding.category in policy.scientific_categories:
            classification = "scientific_or_protocol_invalidating"
        elif finding.defect_class is not DefectClass.IMPLEMENTATION_CONFORMANCE or finding.category not in policy.implementation_categories:
            classification = "unknown_or_inconsistent_classification"
        elif not set(finding.affected_paths).issubset(candidate.implementation_file_hashes):
            classification = "protected_or_unregistered_diff_scope"
        else:
            continue
        return RepairDecision(
            policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
            False, True, classification, (), candidate.protected_contract_id,
            "independent finding is not an eligible implementation-conformance defect",
        )
    paths = tuple(sorted({path for finding in findings for path in finding.affected_paths}))
    return RepairDecision(
        policy.policy_id, candidate.root_candidate_id, candidate.candidate_id, parent_audit_id,
        True, False, "implementation_conformance", paths, candidate.protected_contract_id,
        "one append-only pre-model conformance repair is eligible for fresh independent re-audit",
    )


def issue_single_use_repair_token(
    policy: GovernancePolicy,
    *,
    decision: RepairDecision,
    candidate: CandidateEnvelope,
    parent_audit_request_path: Path,
    parent_audit_response_path: Path,
    parent_audit_receipt_path: Path,
    pre_repair_checkpoint: Mapping[str, Any],
    versioned_replacement_paths: Mapping[str, str],
    repair_store: RepairAuthorityStore,
    access_store: AccessAuthorityStore,
) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    if not decision.authorized or decision.terminal or decision.classification != "implementation_conformance":
        raise ValueError("repair decision is not eligible")
    audit_evidence = verify_independent_audit_exchange(
        parent_audit_request_path,
        parent_audit_response_path,
        parent_audit_receipt_path,
        expected_operation=INITIAL_AUDIT_OPERATION,
        expected_producer=INITIAL_AUDIT_PRODUCER,
        expected_response_schema=initial_audit_response_schema(),
    )
    if decision.parent_audit_id != audit_evidence.get("audit_evidence_id"):
        raise ValueError("repair decision is not bound to the independent audit")
    access_store.verify_checkpoint(pre_repair_checkpoint, candidate.root_candidate_id, "pre_repair")
    if set(versioned_replacement_paths) != set(decision.allowed_changed_paths):
        raise ValueError("versioned replacement map must exactly cover audit-identified paths")
    occupied = set(candidate.implementation_file_hashes).union(candidate.protected_artifact_hashes)
    replacements = tuple(versioned_replacement_paths.values())
    if len(replacements) != len(set(replacements)) or any(path in occupied or "r1" not in path.rsplit("/", 1)[-1] for path in replacements):
        raise ValueError("replacement paths must be unique, new, and explicitly r1-versioned")
    body = {
        "version": PREEXECUTION_GOVERNANCE_VERSION,
        "policy_id": policy.policy_id,
        "root_candidate_id": candidate.root_candidate_id,
        "baseline_candidate_id": candidate.candidate_id,
        "baseline_package_id": candidate.package_id,
        "parent_audit_evidence_id": audit_evidence["audit_evidence_id"],
        "parent_audit_packet_id": audit_evidence["packet_id"],
        "pre_repair_checkpoint_id": pre_repair_checkpoint["checkpoint_id"],
        "repair_index": 1,
        "maximum_uses": 1,
        "allowed_changed_paths": list(decision.allowed_changed_paths),
        "versioned_replacement_paths": dict(versioned_replacement_paths),
        "baseline_implementation_file_hashes": dict(candidate.implementation_file_hashes),
        "protected_contract_id": candidate.protected_contract_id,
        "protected_artifact_hashes": dict(candidate.protected_artifact_hashes),
        "required_fresh_reaudit_check_ids": list(policy.required_reaudit_checks),
        "rejection_or_reaudit_failure_action": "terminate_candidate_without_second_repair",
    }
    token = {**body, "repair_token_id": content_digest(body)}
    issuance = repair_store.issue(token)
    return token, {"issuance": issuance, "lineage_snapshot": repair_store.snapshot(candidate.root_candidate_id)}


def verify_and_consume_repair_submission(
    policy: GovernancePolicy,
    *,
    token: Mapping[str, Any],
    baseline: CandidateEnvelope,
    repaired: CandidateEnvelope,
    post_repair_checkpoint: Mapping[str, Any],
    repair_store: RepairAuthorityStore,
    access_store: AccessAuthorityStore,
) -> tuple[Mapping[str, Any], Mapping[str, Any]]:
    token_id = str(token.get("repair_token_id", ""))
    if token_id != content_digest({key: value for key, value in token.items() if key != "repair_token_id"}):
        raise ValueError("repair token identity mismatch")
    access_store.verify_checkpoint(post_repair_checkpoint, baseline.root_candidate_id, "post_repair")
    if post_repair_checkpoint.get("parent_checkpoint_id") != token.get("pre_repair_checkpoint_id"):
        raise ValueError("post-repair zero-access evidence is not chained to token issuance")
    issued = repair_store.issued_record(baseline.root_candidate_id)
    if issued is None or issued["repair_token_id"] != token_id or repair_store.consumed_record(token_id) is not None:
        raise ValueError("repair token is not canonically issued exactly once and unconsumed")
    if baseline.protected_contract_id != repaired.protected_contract_id or repaired.protected_contract_id != token.get("protected_contract_id"):
        raise ValueError("protected scientific contract changed")
    if dict(repaired.protected_artifact_hashes) != dict(token.get("protected_artifact_hashes", {})):
        raise ValueError("protected artifact bytes changed")
    if dict(baseline.implementation_file_hashes) != dict(token.get("baseline_implementation_file_hashes", {})):
        raise ValueError("baseline implementation provenance changed")
    allowed = tuple(token.get("allowed_changed_paths", ()))
    replacement_map = dict(token.get("versioned_replacement_paths", {}))
    expected_paths = set(baseline.implementation_file_hashes).difference(allowed).union(replacement_map.values())
    if set(repaired.implementation_file_hashes) != expected_paths or set(replacement_map) != set(allowed):
        raise ValueError("repaired implementation registry is outside exact versioned diff scope")
    for path in set(baseline.implementation_file_hashes).difference(allowed):
        if repaired.implementation_file_hashes[path] != baseline.implementation_file_hashes[path]:
            raise ValueError("unaffected implementation bytes changed")
    for old_path, new_path in replacement_map.items():
        if repaired.implementation_file_hashes[new_path] == baseline.implementation_file_hashes[old_path]:
            raise ValueError("versioned replacement bytes are unchanged")
    body = {
        "version": PREEXECUTION_GOVERNANCE_VERSION,
        "policy_id": policy.policy_id,
        "repair_token_id": token_id,
        "root_candidate_id": repaired.root_candidate_id,
        "baseline_candidate_id": baseline.candidate_id,
        "repaired_candidate_id": repaired.candidate_id,
        "repaired_package_id": repaired.package_id,
        "repair_index": 1,
        "changed_components": list(allowed),
        "versioned_replacement_paths": replacement_map,
        "before_hashes": {path: baseline.implementation_file_hashes[path] for path in allowed},
        "after_hashes": {replacement_map[path]: repaired.implementation_file_hashes[replacement_map[path]] for path in allowed},
        "protected_contract_id": repaired.protected_contract_id,
        "protected_artifact_hashes": dict(repaired.protected_artifact_hashes),
        "post_repair_checkpoint_id": post_repair_checkpoint["checkpoint_id"],
        "fresh_independent_reaudit_required": True,
    }
    submission = {**body, "submission_id": content_digest(body)}
    consumption = repair_store.consume(token, submission["submission_id"])
    return submission, {"consumption": consumption, "lineage_snapshot": repair_store.snapshot(repaired.root_candidate_id)}


def evaluate_fresh_reaudit(
    policy: GovernancePolicy,
    *,
    token: Mapping[str, Any],
    submission: Mapping[str, Any],
    pre_reaudit_checkpoint: Mapping[str, Any],
    audit_request_path: Path,
    audit_response_path: Path,
    audit_receipt_path: Path,
    repair_store: RepairAuthorityStore,
    access_store: AccessAuthorityStore,
) -> Mapping[str, Any]:
    token_id = str(token.get("repair_token_id", ""))
    submission_id = str(submission.get("submission_id", ""))
    if submission_id != content_digest({key: value for key, value in submission.items() if key != "submission_id"}):
        raise ValueError("repair submission identity mismatch")
    access_store.verify_checkpoint(pre_reaudit_checkpoint, str(token["root_candidate_id"]), "pre_reaudit")
    audit_evidence = verify_independent_audit_exchange(
        audit_request_path,
        audit_response_path,
        audit_receipt_path,
        expected_operation=REAUDIT_OPERATION,
        expected_producer=REAUDIT_PRODUCER,
        expected_response_schema=reaudit_response_schema(),
    )
    if pre_reaudit_checkpoint.get("parent_checkpoint_id") != submission.get("post_repair_checkpoint_id"):
        raise ValueError("pre-re-audit zero-access checkpoint chain is broken")
    issued = repair_store.issued_record(str(token["root_candidate_id"]))
    consumed = repair_store.consumed_record(token_id)
    response = audit_evidence.get("response", {})
    checks = response.get("checks", [])
    check_ids = [row.get("check_id") for row in checks if isinstance(row, dict)]
    exact_registry = (
        len(check_ids) == len(policy.required_reaudit_checks)
        and len(set(check_ids)) == len(check_ids)
        and set(check_ids) == set(policy.required_reaudit_checks)
        and all(set(row) == {"check_id", "passed", "reason", "evidence_refs"} for row in checks)
    )
    provenance_valid = (
        audit_evidence.get("operation") == REAUDIT_OPERATION
        and audit_evidence.get("producer_ref") == REAUDIT_PRODUCER
        and audit_evidence.get("audit_evidence_id") != token.get("parent_audit_evidence_id")
        and audit_evidence.get("packet_id") != token.get("parent_audit_packet_id")
        and response.get("repair_token_id") == token_id
        and response.get("submission_id") == submission_id
        and response.get("parent_audit_evidence_id") == token.get("parent_audit_evidence_id")
        and response.get("pre_reaudit_checkpoint_id") == pre_reaudit_checkpoint.get("checkpoint_id")
        and issued is not None
        and issued.get("repair_token_id") == token_id
        and consumed is not None
        and consumed.get("submission_id") == submission_id
    )
    defects = response.get("critical_defects", None)
    ambiguity = response.get("audit_ambiguity", True)
    all_checks_passed = bool(checks) and all(row.get("passed") is True for row in checks)
    authorized = (
        exact_registry
        and provenance_valid
        and defects == []
        and ambiguity is False
        and all_checks_passed
        and response.get("disposition") == "activate_candidate_after_conformance_reaudit"
    )
    body = {
        "version": PREEXECUTION_GOVERNANCE_VERSION,
        "policy_id": policy.policy_id,
        "repair_token_id": token_id,
        "submission_id": submission_id,
        "parent_audit_evidence_id": token.get("parent_audit_evidence_id"),
        "fresh_audit_evidence_id": audit_evidence.get("audit_evidence_id"),
        "fresh_audit_packet_id": audit_evidence.get("packet_id"),
        "pre_reaudit_checkpoint_id": pre_reaudit_checkpoint.get("checkpoint_id"),
        "checks": checks,
        "critical_defects": defects,
        "audit_ambiguity": ambiguity,
        "audit_disposition": response.get("disposition"),
        "exact_reaudit_check_registry": exact_registry,
        "fresh_independent_audit_provenance_valid": provenance_valid,
        "all_checks_passed": all_checks_passed,
        "authorized": authorized,
        "terminal": not authorized,
        "next_action": "candidate may proceed only to its previously frozen next boundary" if authorized else "terminate candidate; no second repair, resubmission, or audit loop",
        "lineage_snapshot": repair_store.snapshot(str(token["root_candidate_id"])),
    }
    return {**body, "reaudit_decision_id": content_digest(body)}
