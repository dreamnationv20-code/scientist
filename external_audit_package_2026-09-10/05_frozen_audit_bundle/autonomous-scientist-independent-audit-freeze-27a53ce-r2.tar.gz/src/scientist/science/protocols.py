from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import content_digest
from scientist.kernel.contracts import GateCriterion
from scientist.kernel.interfaces import EvidenceRequest


PROBE_PROTOCOL_VERSION = "domain-neutral-preregistered-probe-v1"
REQUIRED_PROBE_ARTIFACT_KINDS = (
    "domain_measurement",
    "domain_evidence_summary",
    "domain_gate_decision",
    "domain_probe_assessment",
)


class ProbeDisposition(str, Enum):
    PASS = "pass"
    KILL = "kill"
    EVOLVE = "evolve"
    PARK = "park"


@dataclass(frozen=True)
class EvidenceProvenanceContract:
    """Why an evidence source is a valid instance of the target phenomenon."""

    source_kind: str
    source_ref: str
    acquisition_ref: str
    validity_argument: str
    license_ref: Optional[str] = None
    partitioning_ref: Optional[str] = None

    def __post_init__(self) -> None:
        if not all(
            (
                self.source_kind,
                self.source_ref,
                self.acquisition_ref,
                self.validity_argument,
            )
        ):
            raise ValueError("evidence provenance contract is incomplete")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "source_kind": self.source_kind,
            "source_ref": self.source_ref,
            "acquisition_ref": self.acquisition_ref,
            "validity_argument": self.validity_argument,
            "license_ref": self.license_ref,
            "partitioning_ref": self.partitioning_ref,
        }


@dataclass(frozen=True)
class ExpectedRange:
    """A prediction frozen before evidence is generated."""

    metric: str
    lower: float
    upper: float
    rationale: str

    def __post_init__(self) -> None:
        if not self.metric or not self.rationale:
            raise ValueError("expected range identity is incomplete")
        if not math.isfinite(self.lower) or not math.isfinite(self.upper):
            raise ValueError("expected range bounds must be finite")
        if self.lower > self.upper:
            raise ValueError("expected range lower bound exceeds upper bound")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "metric": self.metric,
            "lower": self.lower,
            "upper": self.upper,
            "rationale": self.rationale,
        }


@dataclass(frozen=True)
class ProbeOutcomeRule:
    """An all-of criterion set mapped to a predeclared disposition."""

    disposition: ProbeDisposition
    criteria: Tuple[GateCriterion, ...]
    interpretation: str

    def __post_init__(self) -> None:
        if not self.criteria or not self.interpretation:
            raise ValueError("probe outcome rule is incomplete")
        if any(not math.isfinite(item.threshold) for item in self.criteria):
            raise ValueError("probe outcome thresholds must be finite")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "disposition": self.disposition.value,
            "criteria": [item.as_dict() for item in self.criteria],
            "interpretation": self.interpretation,
        }


@dataclass(frozen=True)
class ProbeProtocol:
    """Immutable protocol that must exist before its evidence tasks are made."""

    campaign_id: str
    research_object_id: str
    question: str
    hypothesis_statement: str
    hypothesis_ids: Tuple[str, ...]
    evidence_request: EvidenceRequest
    gate_contract_id: str
    procedure_ref: str
    configuration: Mapping[str, Any]
    provenance: EvidenceProvenanceContract
    expected_ranges: Tuple[ExpectedRange, ...]
    outcome_rules: Tuple[ProbeOutcomeRule, ...]
    artifact_kinds: Tuple[str, ...]
    registered_by: str
    default_disposition: ProbeDisposition = ProbeDisposition.EVOLVE

    def __post_init__(self) -> None:
        if not all(
            (
                self.campaign_id,
                self.research_object_id,
                self.question,
                self.hypothesis_statement,
                self.hypothesis_ids,
                self.gate_contract_id,
                self.procedure_ref,
                self.configuration,
                self.expected_ranges,
                self.outcome_rules,
                self.artifact_kinds,
                self.registered_by,
            )
        ):
            raise ValueError("probe protocol is incomplete")
        if len(set(self.hypothesis_ids)) != len(self.hypothesis_ids):
            raise ValueError("probe hypothesis identities must be unique")
        if len(set(item.metric for item in self.expected_ranges)) != len(
            self.expected_ranges
        ):
            raise ValueError("probe expected metrics must be unique")
        if len(set(self.artifact_kinds)) != len(self.artifact_kinds):
            raise ValueError("probe artifact kinds must be unique")
        missing_artifacts = set(REQUIRED_PROBE_ARTIFACT_KINDS).difference(
            self.artifact_kinds
        )
        if missing_artifacts:
            raise ValueError(
                "probe protocol omits runtime artifacts: %s"
                % ", ".join(sorted(missing_artifacts))
            )
        dispositions = {item.disposition for item in self.outcome_rules}
        if not {ProbeDisposition.PASS, ProbeDisposition.KILL}.issubset(
            dispositions
        ):
            raise ValueError("probe protocol requires pass and kill rules")

    @property
    def protocol_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "protocol_version": PROBE_PROTOCOL_VERSION,
            "campaign_id": self.campaign_id,
            "research_object_id": self.research_object_id,
            "question": self.question,
            "hypothesis_statement": self.hypothesis_statement,
            "hypothesis_ids": list(self.hypothesis_ids),
            "evidence_request": self.evidence_request.as_dict(),
            "gate_contract_id": self.gate_contract_id,
            "procedure_ref": self.procedure_ref,
            "configuration": dict(self.configuration),
            "provenance": self.provenance.as_dict(),
            "expected_ranges": [item.as_dict() for item in self.expected_ranges],
            "outcome_rules": [item.as_dict() for item in self.outcome_rules],
            "artifact_kinds": list(self.artifact_kinds),
            "registered_by": self.registered_by,
            "default_disposition": self.default_disposition.value,
        }
        if include_id:
            value["protocol_id"] = self.protocol_id
        return value


@dataclass(frozen=True)
class PredictionAssessment:
    metric: str
    observed: float
    expected_lower: float
    expected_upper: float
    surprising: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "metric": self.metric,
            "observed": self.observed,
            "expected_lower": self.expected_lower,
            "expected_upper": self.expected_upper,
            "surprising": self.surprising,
        }


@dataclass(frozen=True)
class ProbeAssessment:
    protocol_id: str
    disposition: ProbeDisposition
    matched_rule_index: Optional[int]
    gate_passed: bool
    predictions: Tuple[PredictionAssessment, ...]

    @property
    def surprising_metrics(self) -> Tuple[str, ...]:
        return tuple(item.metric for item in self.predictions if item.surprising)

    @property
    def assessment_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "protocol_id": self.protocol_id,
            "disposition": self.disposition.value,
            "matched_rule_index": self.matched_rule_index,
            "gate_passed": self.gate_passed,
            "predictions": [item.as_dict() for item in self.predictions],
            "surprising_metrics": list(self.surprising_metrics),
        }
        if include_id:
            value["assessment_id"] = self.assessment_id
        return value


def _criterion_matches(criterion: GateCriterion, observed: float) -> bool:
    if criterion.operator == "<":
        return observed < criterion.threshold
    if criterion.operator == "<=":
        return observed <= criterion.threshold
    if criterion.operator == "==":
        return observed == criterion.threshold
    if criterion.operator == ">=":
        return observed >= criterion.threshold
    if criterion.operator == ">":
        return observed > criterion.threshold
    raise ValueError("unsupported probe criterion operator")


def assess_probe(
    protocol: ProbeProtocol,
    metrics: Mapping[str, float],
    *,
    gate_passed: bool,
) -> ProbeAssessment:
    """Mechanically compare results with the frozen prediction and decision bars."""

    required = {
        item.metric for item in protocol.expected_ranges
    } | {
        criterion.metric
        for rule in protocol.outcome_rules
        for criterion in rule.criteria
    }
    missing = required.difference(metrics)
    if missing:
        raise ValueError(
            "probe assessment is missing metrics: %s"
            % ", ".join(sorted(missing))
        )
    if any(not math.isfinite(float(metrics[name])) for name in required):
        raise ValueError("probe assessment metrics must be finite")
    predictions = tuple(
        PredictionAssessment(
            metric=item.metric,
            observed=float(metrics[item.metric]),
            expected_lower=item.lower,
            expected_upper=item.upper,
            surprising=not (
                item.lower <= float(metrics[item.metric]) <= item.upper
            ),
        )
        for item in protocol.expected_ranges
    )
    matching = tuple(
        index
        for index, rule in enumerate(protocol.outcome_rules)
        if all(
            _criterion_matches(criterion, float(metrics[criterion.metric]))
            for criterion in rule.criteria
        )
    )
    if len(matching) > 1:
        raise ValueError("probe outcome rules overlap for the observed metrics")
    matched_index = matching[0] if matching else None
    disposition = (
        protocol.default_disposition
        if matched_index is None
        else protocol.outcome_rules[matched_index].disposition
    )
    if disposition == ProbeDisposition.PASS and not gate_passed:
        raise ValueError("probe pass rule conflicts with the campaign gate")
    return ProbeAssessment(
        protocol_id=protocol.protocol_id,
        disposition=disposition,
        matched_rule_index=matched_index,
        gate_passed=gate_passed,
        predictions=predictions,
    )
