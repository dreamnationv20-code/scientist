from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Mapping, Sequence, Tuple

from scientist.core.artifacts import content_digest


ADVERSARIAL_REVIEW_VERSION = "typed-adversarial-review-v1"


class IssueSeverity(str, Enum):
    FATAL = "fatal"
    MAJOR = "major"
    MINOR = "minor"


class IssueDisposition(str, Enum):
    REVISE = "revise"
    REBUT = "rebut"
    ACCEPT = "accept"


class ReviewTargetStatus(str, Enum):
    ACTIVE = "active"
    DEAD = "dead"


class ReviewCapDisposition(str, Enum):
    CONTINUE_REVISION = "continue_revision"
    AUTHORIZED_BY_REVIEW = "authorized_by_review"
    ACCEPTED_WITH_LIMITATIONS_AT_CAP = "accepted_with_limitations_at_cap"
    BLOCKED_AT_HARD_BOUNDARY = "blocked_at_hard_boundary"


@dataclass(frozen=True)
class BoundedReviewCapPolicy:
    """Finite review-loop policy with a non-waivable scientific boundary.

    Reviewers may continue to identify improvements forever. This contract
    separates defects that invalidate the experiment from limitations that
    must be disclosed but need not consume an unbounded implementation loop.
    """

    policy_ref: str
    maximum_rounds: int
    hard_blocking_categories: Tuple[str, ...]
    waivable_categories: Tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.policy_ref:
            raise ValueError("bounded review policy reference is required")
        if self.maximum_rounds <= 0:
            raise ValueError("bounded review maximum must be positive")
        if not self.hard_blocking_categories:
            raise ValueError("bounded review requires a hard boundary")
        if not self.waivable_categories:
            raise ValueError("bounded review requires declared limitation categories")
        categories = self.hard_blocking_categories + self.waivable_categories
        if len(set(categories)) != len(categories) or not all(categories):
            raise ValueError("bounded review categories must be non-empty and disjoint")

    @property
    def policy_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "policy_ref": self.policy_ref,
            "maximum_rounds": self.maximum_rounds,
            "hard_blocking_categories": list(self.hard_blocking_categories),
            "waivable_categories": list(self.waivable_categories),
        }
        if include_id:
            value["policy_id"] = self.policy_id
        return value


@dataclass(frozen=True)
class ReviewCapDecision:
    policy_id: str
    round_index: int
    reviewer_passed: bool
    disposition: ReviewCapDisposition
    effective_authorized: bool
    hard_defect_ids: Tuple[str, ...]
    accepted_limitation_ids: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "policy_id": self.policy_id,
            "round_index": self.round_index,
            "reviewer_passed": self.reviewer_passed,
            "disposition": self.disposition.value,
            "effective_authorized": self.effective_authorized,
            "hard_defect_ids": list(self.hard_defect_ids),
            "accepted_limitation_ids": list(self.accepted_limitation_ids),
        }


def resolve_bounded_review_cap(
    policy: BoundedReviewCapPolicy,
    *,
    round_index: int,
    reviewer_passed: bool,
    defects: Sequence[Mapping[str, Any]],
) -> ReviewCapDecision:
    """Resolve a finite review loop without waiving experiment validity.

    Each defect must carry a stable id and a preregistered category. Before the
    ceiling, any reviewer rejection authorizes another revision. At the ceiling,
    only declared limitations may be accepted; a hard-category defect remains
    blocking. A clean reviewer pass always authorizes advancement.
    """

    if round_index <= 0 or round_index > policy.maximum_rounds:
        raise ValueError("bounded review round is outside its declared ceiling")
    allowed = set(policy.hard_blocking_categories + policy.waivable_categories)
    defect_ids = [str(item.get("defect_id", "")) for item in defects]
    categories = [str(item.get("category", "")) for item in defects]
    if not all(defect_ids) or len(defect_ids) != len(set(defect_ids)):
        raise ValueError("bounded review defects require unique non-empty ids")
    if any(category not in allowed for category in categories):
        raise ValueError("bounded review defect category is outside policy")
    hard = tuple(
        defect_id
        for defect_id, category in zip(defect_ids, categories)
        if category in policy.hard_blocking_categories
    )
    limitations = tuple(
        defect_id
        for defect_id, category in zip(defect_ids, categories)
        if category in policy.waivable_categories
    )
    if not reviewer_passed and not defects:
        hard = ("uncategorized_reviewer_rejection",)
    if reviewer_passed:
        disposition = ReviewCapDisposition.AUTHORIZED_BY_REVIEW
        authorized = True
    elif round_index < policy.maximum_rounds:
        disposition = ReviewCapDisposition.CONTINUE_REVISION
        authorized = False
    elif hard:
        disposition = ReviewCapDisposition.BLOCKED_AT_HARD_BOUNDARY
        authorized = False
    else:
        disposition = ReviewCapDisposition.ACCEPTED_WITH_LIMITATIONS_AT_CAP
        authorized = True
    return ReviewCapDecision(
        policy_id=policy.policy_id,
        round_index=round_index,
        reviewer_passed=reviewer_passed,
        disposition=disposition,
        effective_authorized=authorized,
        hard_defect_ids=hard,
        accepted_limitation_ids=limitations,
    )


@dataclass(frozen=True)
class AdversarialReviewProtocol:
    """The only information allowed to cross a proposer/reviewer boundary."""

    target_id: str
    allowed_labels: Tuple[str, ...]
    jurisdictions: Tuple[str, ...]
    max_rounds: int
    orchestrator_ref: str

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_id,
                self.allowed_labels,
                self.jurisdictions,
                self.orchestrator_ref,
            )
        ):
            raise ValueError("adversarial review protocol is incomplete")
        if len(set(self.allowed_labels)) != len(self.allowed_labels):
            raise ValueError("review issue labels must be unique")
        if len(set(self.jurisdictions)) != len(self.jurisdictions):
            raise ValueError("review jurisdictions must be unique")
        if self.max_rounds <= 0:
            raise ValueError("review round ceiling must be positive")

    @property
    def protocol_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "review_version": ADVERSARIAL_REVIEW_VERSION,
            "target_id": self.target_id,
            "allowed_labels": list(self.allowed_labels),
            "jurisdictions": list(self.jurisdictions),
            "max_rounds": self.max_rounds,
            "orchestrator_ref": self.orchestrator_ref,
        }
        if include_id:
            value["protocol_id"] = self.protocol_id
        return value


@dataclass(frozen=True)
class ReviewIssue:
    """A defect assertion without hidden reviewer reasoning or a proposed fix."""

    target_id: str
    round_index: int
    section: str
    label: str
    severity: IssueSeverity
    statement: str
    jurisdiction: str
    reviewer_ref: str
    evidence_refs: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not all(
            (
                self.target_id,
                self.section,
                self.label,
                self.statement,
                self.jurisdiction,
                self.reviewer_ref,
            )
        ):
            raise ValueError("review issue is incomplete")
        if self.round_index <= 0:
            raise ValueError("review issue round must be positive")
        if "\n" in self.statement or "\r" in self.statement:
            raise ValueError("review issue statements must be one line")
        if len(set(self.evidence_refs)) != len(self.evidence_refs):
            raise ValueError("review issue evidence references must be unique")

    @property
    def issue_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "target_id": self.target_id,
            "round_index": self.round_index,
            "section": self.section,
            "label": self.label,
            "severity": self.severity.value,
            "statement": self.statement,
            "jurisdiction": self.jurisdiction,
            "reviewer_ref": self.reviewer_ref,
            "evidence_refs": list(self.evidence_refs),
        }
        if include_id:
            value["issue_id"] = self.issue_id
        return value


@dataclass(frozen=True)
class IssueResponse:
    issue_id: str
    disposition: IssueDisposition
    target_version_after: str
    justification: str
    evidence_refs: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not all(
            (
                self.issue_id,
                self.target_version_after,
                self.justification,
            )
        ):
            raise ValueError("review response is incomplete")
        if "\n" in self.justification or "\r" in self.justification:
            raise ValueError("review response justifications must be one line")
        if self.disposition == IssueDisposition.REBUT and not self.evidence_refs:
            raise ValueError("a rebuttal requires external evidence")
        if len(set(self.evidence_refs)) != len(self.evidence_refs):
            raise ValueError("response evidence references must be unique")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "issue_id": self.issue_id,
            "disposition": self.disposition.value,
            "target_version_after": self.target_version_after,
            "justification": self.justification,
            "evidence_refs": list(self.evidence_refs),
        }


@dataclass(frozen=True)
class ReviewRound:
    protocol_id: str
    target_id: str
    round_index: int
    target_version_before: str
    target_version_after: str
    issues: Tuple[ReviewIssue, ...]
    responses: Tuple[IssueResponse, ...]
    target_status: ReviewTargetStatus
    fatal_issue_ids: Tuple[str, ...]
    accepted_limitation_issue_ids: Tuple[str, ...]

    @property
    def round_id(self) -> str:
        return content_digest(self.as_dict(include_id=False))

    def as_dict(self, include_id: bool = True) -> Dict[str, Any]:
        value: Dict[str, Any] = {
            "protocol_id": self.protocol_id,
            "target_id": self.target_id,
            "round_index": self.round_index,
            "target_version_before": self.target_version_before,
            "target_version_after": self.target_version_after,
            "issues": [item.as_dict() for item in self.issues],
            "responses": [item.as_dict() for item in self.responses],
            "target_status": self.target_status.value,
            "fatal_issue_ids": list(self.fatal_issue_ids),
            "accepted_limitation_issue_ids": list(
                self.accepted_limitation_issue_ids
            ),
        }
        if include_id:
            value["round_id"] = self.round_id
        return value


def resolve_review_round(
    protocol: AdversarialReviewProtocol,
    *,
    round_index: int,
    target_version_before: str,
    issues: Tuple[ReviewIssue, ...],
    responses: Tuple[IssueResponse, ...],
) -> ReviewRound:
    """Validate a complete issue/response exchange and derive its status."""

    if not target_version_before:
        raise ValueError("review target version is required")
    if round_index <= 0 or round_index > protocol.max_rounds:
        raise ValueError("review exceeds its preregistered round ceiling")
    if not issues:
        raise ValueError("review round must contain at least one issue")
    issue_by_id: Mapping[str, ReviewIssue] = {
        item.issue_id: item for item in issues
    }
    if len(issue_by_id) != len(issues):
        raise ValueError("review round contains duplicate issues")
    if any(
        item.target_id != protocol.target_id
        or item.round_index != round_index
        or item.label not in protocol.allowed_labels
        or item.jurisdiction not in protocol.jurisdictions
        for item in issues
    ):
        raise ValueError("review issue falls outside the protocol")
    response_by_id: Mapping[str, IssueResponse] = {
        item.issue_id: item for item in responses
    }
    if len(response_by_id) != len(responses):
        raise ValueError("review round contains duplicate responses")
    if set(response_by_id) != set(issue_by_id):
        raise ValueError("every review issue requires exactly one response")
    versions = {item.target_version_after for item in responses}
    if len(versions) != 1:
        raise ValueError("review responses disagree on the resulting version")
    target_version_after = next(iter(versions))
    revised = any(
        item.disposition == IssueDisposition.REVISE for item in responses
    )
    if revised == (target_version_after == target_version_before):
        raise ValueError("review revision disposition and target version disagree")
    fatal_accepts = tuple(
        issue_id
        for issue_id, response in response_by_id.items()
        if response.disposition == IssueDisposition.ACCEPT
        and issue_by_id[issue_id].severity == IssueSeverity.FATAL
    )
    limitations = tuple(
        issue_id
        for issue_id, response in response_by_id.items()
        if response.disposition == IssueDisposition.ACCEPT
        and issue_by_id[issue_id].severity
        in {IssueSeverity.MAJOR, IssueSeverity.MINOR}
    )
    return ReviewRound(
        protocol_id=protocol.protocol_id,
        target_id=protocol.target_id,
        round_index=round_index,
        target_version_before=target_version_before,
        target_version_after=target_version_after,
        issues=issues,
        responses=responses,
        target_status=(
            ReviewTargetStatus.DEAD
            if fatal_accepts
            else ReviewTargetStatus.ACTIVE
        ),
        fatal_issue_ids=fatal_accepts,
        accepted_limitation_issue_ids=limitations,
    )
