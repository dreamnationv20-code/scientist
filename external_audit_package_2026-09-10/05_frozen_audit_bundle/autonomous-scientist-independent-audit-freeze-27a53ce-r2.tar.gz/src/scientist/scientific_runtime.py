from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Tuple, Union

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.core.exceptions import ScientificCommandPaused
from scientist.kernel.conformance import check_adapter_conformance
from scientist.kernel.domain_registry import ScientificDomainBundle
from scientist.kernel.ledger import LedgerEventKind, ScientificLedger


SCIENTIFIC_COMMAND_RUNTIME_VERSION = "scientific-command-runtime-v2-domain-registry"


def _output_root(arguments: Any) -> Path:
    output = (
        getattr(arguments, "output", None)
        or getattr(arguments, "artifact_root", None)
    )
    if output is not None:
        return Path(output)
    source = (
        getattr(arguments, "discovery_manifest", None)
        or getattr(arguments, "campaign_manifest", None)
    )
    if source is not None:
        return Path(source).resolve().parent.parent
    return Path("runs")


def _argument_payload(arguments: Any) -> Dict[str, Any]:
    return {
        str(name): value
        for name, value in vars(arguments).items()
        if name != "handler" and not str(name).startswith("_")
    }


@dataclass(frozen=True)
class ScientificCommandOutcome:
    """Typed link from a command handler to its durable scientific outputs."""

    exit_code: int = 0
    manifest_paths: Tuple[str, ...] = ()
    artifact_ids: Tuple[str, ...] = ()
    details: Mapping[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "exit_code": int(self.exit_code),
            "manifest_paths": list(self.manifest_paths),
            "artifact_ids": list(self.artifact_ids),
            "details": dict(self.details),
        }


class ScientificCommandRuntime:
    """Mandatory kernel boundary for installed domain-laboratory commands."""

    def __init__(
        self,
        arguments: Any,
        *,
        domain: ScientificDomainBundle,
        lazy_start: bool = False,
    ) -> None:
        self.arguments = arguments
        self.command = str(arguments.command)
        self.argument_payload = _argument_payload(arguments)
        self.domain = domain
        self.store: Optional[ArtifactStore] = None
        self.adapter: Any = None
        self.charter: Any = None
        self.contract: Any = None
        self.conformance: Any = None
        self.conformance_digest: Optional[str] = None
        self.cycle_id: Optional[str] = None
        self.ledger: Optional[ScientificLedger] = None
        self._started = False
        if not lazy_start:
            self.start()

    @property
    def started(self) -> bool:
        return self._started

    def start(self) -> None:
        """Open the authority boundary after any artifact-free preflight."""

        if self._started:
            return
        self.store = ArtifactStore(_output_root(self.arguments))
        domain = self.domain
        self.adapter = domain.adapter
        self.charter = domain.charter_factory()
        fixture = domain.fixture_factory()
        control_ids = tuple(
            self.adapter.candidate_id(control)
            for control in fixture.resolved_controls
        )
        standard_contract = domain.build_campaign(control_ids)
        self.contract = (
            standard_contract
            if domain.command_contract_adapter is None
            else domain.command_contract_adapter(
                self.arguments, standard_contract
            )
        )
        if self.contract.charter_id != self.charter.charter_id:
            raise ValueError("domain charter and campaign contract disagree")
        if self.contract.domain_adapter_ref != self.adapter.adapter_version:
            raise ValueError("domain adapter and campaign contract disagree")
        if domain.capability_manifest != self.adapter.capabilities:
            raise ValueError("domain capability manifest and adapter disagree")
        if (
            self.contract.comparison_mode
            != domain.capability_manifest.comparison_mode
        ):
            raise ValueError("command contract changed the domain comparison mode")
        if (
            self.contract.evidence_analysis is None
            or self.contract.evidence_analysis.primary_metric
            != domain.capability_manifest.primary_metric
        ):
            raise ValueError("command contract changed the domain evidence authority")
        conformance = check_adapter_conformance(
            self.adapter,
            fixture.candidate,
            fixture.control,
            fixture.experiment,
            controls=fixture.controls,
        )
        if not conformance.passed:
            raise RuntimeError(
                "domain adapter failed kernel conformance: %s"
                % conformance.as_dict()
            )
        self.conformance = conformance
        self.conformance_digest = self.store.put(
            "cli_adapter_conformance",
            conformance.as_dict(),
        )
        self.cycle_id = "cli-" + content_digest(
            {
                "runtime_version": SCIENTIFIC_COMMAND_RUNTIME_VERSION,
                "command": self.command,
                "arguments": self.argument_payload,
                "started_ns": time.time_ns(),
            }
        )[:32]
        self.ledger = ScientificLedger(artifact_store=self.store)
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CYCLE_STARTED,
            {
                "runtime_version": SCIENTIFIC_COMMAND_RUNTIME_VERSION,
                "command": self.command,
                "arguments": self.argument_payload,
                "adapter_conformance_digest": self.conformance_digest,
                "domain_id": domain.domain_id,
                "domain_bundle_ref": domain.bundle_ref,
                "capability_manifest_id": (
                    domain.capability_manifest.manifest_id
                ),
            },
            "scientist-cli-runtime",
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CHARTER_REGISTERED,
            {
                "charter_id": self.charter.charter_id,
                "charter": self.charter.as_dict(),
            },
            "scientist-cli-runtime",
        )
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CAMPAIGN_REGISTERED,
            {
                "campaign_id": self.contract.campaign_id,
                "campaign": self.contract.as_dict(),
                "command_scope": (
                    "domain laboratory command; v2 root scheduling occurs "
                    "through GoalGraphRuntime"
                ),
            },
            "scientist-cli-runtime",
        )
        self._started = True

    def execute(
        self,
        handler: Callable[
            [Any], Union[int, ScientificCommandOutcome]
        ],
    ) -> int:
        before_manifests = self._manifest_paths()
        try:
            raw_outcome = handler(self.arguments)
            if not self._started:
                raise RuntimeError(
                    "lazy scientific command completed without opening "
                    "the authority boundary"
                )
            if isinstance(raw_outcome, ScientificCommandOutcome):
                outcome = raw_outcome
            else:
                exit_code = int(raw_outcome)
                created = tuple(
                    str(path.resolve())
                    for path in self._manifest_paths()
                    if path not in before_manifests
                )
                outcome = ScientificCommandOutcome(
                    exit_code=exit_code,
                    manifest_paths=created,
                )
            self._validate_outcome(outcome)
        except ScientificCommandPaused as pause:
            if not self._started:
                raise
            outcome = ScientificCommandOutcome(
                exit_code=pause.exit_code,
                details={"message": str(pause), **pause.details},
            )
            self._finish(
                status="paused",
                exit_code=pause.exit_code,
                error_type=None,
                outcome=outcome,
            )
            print(str(pause))
            for name, value in sorted(pause.details.items()):
                print("%s: %s" % (name, value))
            return pause.exit_code
        except BaseException as error:
            if self._started:
                self._finish(
                    status="failed",
                    exit_code=None,
                    error_type=type(error).__name__,
                    outcome=None,
                )
            raise
        exit_code = int(outcome.exit_code)
        self._finish(
            status="complete" if exit_code == 0 else "failed",
            exit_code=exit_code,
            error_type=None,
            outcome=outcome,
        )
        return exit_code

    def _manifest_paths(self) -> Tuple[Path, ...]:
        if self.store is None or not self.store.manifests.exists():
            return ()
        return tuple(sorted(self.store.manifests.glob("*.json")))

    def _validate_outcome(self, outcome: ScientificCommandOutcome) -> None:
        if self.store is None:
            raise RuntimeError("scientific command runtime was not started")
        root = self.store.root.resolve()
        for supplied in outcome.manifest_paths:
            path = Path(supplied).resolve()
            if root != path and root not in path.parents:
                raise ValueError("command manifest is outside its artifact root")
            if not path.is_file():
                raise ValueError("command manifest does not exist")
        for artifact_id in outcome.artifact_ids:
            self.store.get(artifact_id)

    def _finish(
        self,
        *,
        status: str,
        exit_code: Optional[int],
        error_type: Optional[str],
        outcome: Optional[ScientificCommandOutcome],
    ) -> Path:
        if self.store is None or self.ledger is None or self.cycle_id is None:
            raise RuntimeError("scientific command runtime was not started")
        self.ledger.append(
            self.cycle_id,
            LedgerEventKind.CYCLE_COMPLETED,
            {
                "status": status,
                "exit_code": exit_code,
                "error_type": error_type,
            },
            "scientist-cli-runtime",
        )
        receipt = {
            "schema": 1,
            "runtime_version": SCIENTIFIC_COMMAND_RUNTIME_VERSION,
            "cycle_id": self.cycle_id,
            "command": self.command,
            "arguments": self.argument_payload,
            "status": status,
            "exit_code": exit_code,
            "error_type": error_type,
            "outcome": None if outcome is None else outcome.as_dict(),
            "charter_id": self.charter.charter_id,
            "campaign_id": self.contract.campaign_id,
            "adapter_ref": self.adapter.adapter_version,
            "domain_id": self.domain.domain_id,
            "domain_bundle_ref": self.domain.bundle_ref,
            "capability_manifest": (
                self.domain.capability_manifest.as_dict()
            ),
            "adapter_conformance_digest": self.conformance_digest,
            "ledger": self.ledger.as_dict(),
        }
        receipt_digest = self.store.put(
            "scientific_cli_runtime_receipt",
            receipt,
        )
        return self.store.write_manifest(
            self.cycle_id,
            {
                "schema": 1,
                "kind": "scientific_cli_runtime_receipt",
                "cycle_id": self.cycle_id,
                "command": self.command,
                "status": status,
                "receipt_digest": receipt_digest,
                "ledger_head_event_id": (
                    self.ledger.events[-1].event_id
                ),
                "outcome": None if outcome is None else outcome.as_dict(),
            },
        )
