"""Executable candidate search engines."""

