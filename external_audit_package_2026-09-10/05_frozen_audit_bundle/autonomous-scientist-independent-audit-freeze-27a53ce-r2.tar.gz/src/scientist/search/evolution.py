from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore
from scientist.domains.binpacking.evaluator import (
    EvaluationReport,
    evaluate_heuristic,
    prepare_references,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.programs import (
    PriorityProgram,
    crossover_expressions,
    mutate_expression,
    random_expression,
    seed_programs,
)


ArchiveCell = Tuple[int, int, int, int]


@dataclass(frozen=True)
class SearchConfig:
    seed: int = 0
    evaluation_budget: int = 200
    initial_random: int = 16
    crossover_probability: float = 0.25
    max_expression_depth: int = 5
    max_expression_nodes: int = 31
    complexity_penalty: float = 0.002
    reference_mode: str = "exact"
    record_placements: bool = True

    def as_dict(self) -> Dict[str, Any]:
        return {
            "seed": self.seed,
            "evaluation_budget": self.evaluation_budget,
            "initial_random": self.initial_random,
            "crossover_probability": self.crossover_probability,
            "max_expression_depth": self.max_expression_depth,
            "max_expression_nodes": self.max_expression_nodes,
            "complexity_penalty": self.complexity_penalty,
            "reference_mode": self.reference_mode,
            "record_placements": self.record_placements,
        }


@dataclass(frozen=True)
class CandidateRecord:
    program: PriorityProgram
    parent_ids: Tuple[str, ...]
    operator: str
    evaluation_index: int
    fitness: float
    archive_cell: ArchiveCell
    report: EvaluationReport
    candidate_artifact: Optional[str] = None
    report_artifact: Optional[str] = None

    def summary(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.program.candidate_id,
            "rendered": self.program.expression.render(),
            "complexity": self.program.complexity,
            "parent_ids": list(self.parent_ids),
            "operator": self.operator,
            "evaluation_index": self.evaluation_index,
            "fitness": self.fitness,
            "archive_cell": list(self.archive_cell),
            "mean_regret": self.report.mean_regret,
            "p95_regret": self.report.p95_regret,
            "worst_regret": self.report.worst_regret,
            "candidate_artifact": self.candidate_artifact,
            "report_artifact": self.report_artifact,
        }


class BehaviourArchive:
    def __init__(self) -> None:
        self._cells: Dict[ArchiveCell, CandidateRecord] = {}

    def add(self, record: CandidateRecord) -> bool:
        current = self._cells.get(record.archive_cell)
        if current is None or record.fitness > current.fitness:
            self._cells[record.archive_cell] = record
            return True
        return False

    def records(self) -> Tuple[CandidateRecord, ...]:
        return tuple(
            self._cells[cell] for cell in sorted(self._cells)
        )

    def sample(self, rng: random.Random) -> CandidateRecord:
        records = self.records()
        if not records:
            raise RuntimeError("cannot sample an empty archive")
        return rng.choice(records)

    def best(self) -> CandidateRecord:
        if not self._cells:
            raise RuntimeError("archive is empty")
        return max(
            self._cells.values(),
            key=lambda record: (
                record.fitness,
                -record.program.complexity,
                record.program.candidate_id,
            ),
        )


@dataclass(frozen=True)
class SearchOutcome:
    config: SearchConfig
    best: CandidateRecord
    archive: Tuple[CandidateRecord, ...]
    evaluated: Tuple[CandidateRecord, ...]
    duplicate_attempts: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "config": self.config.as_dict(),
            "best_candidate_id": self.best.program.candidate_id,
            "archive_size": len(self.archive),
            "evaluated_count": len(self.evaluated),
            "duplicate_attempts": self.duplicate_attempts,
            "archive": [record.summary() for record in self.archive],
            "evaluated": [record.summary() for record in self.evaluated],
        }


def _fitness(
    report: EvaluationReport,
    complexity: int,
    penalty: float,
    instance_weights: Optional[Mapping[str, float]] = None,
    global_mean_ceiling: Optional[float] = None,
    global_constraint_penalty: float = 10.0,
) -> float:
    if instance_weights is None:
        primary_loss = report.mean_regret
    else:
        weighted_regret = 0.0
        total_weight = 0.0
        for observation in report.observations:
            instance_id = str(observation["instance_id"])
            weight = float(instance_weights[instance_id])
            if weight <= 0.0:
                raise ValueError("instance weights must be positive")
            weighted_regret += weight * float(observation["regret"])
            total_weight += weight
        primary_loss = weighted_regret / total_weight
    loss = (
        primary_loss
        + 0.25 * report.p95_regret
        + 0.10 * report.worst_regret
        + penalty * complexity
    )
    if (
        global_mean_ceiling is not None
        and report.mean_regret > global_mean_ceiling
    ):
        loss += global_constraint_penalty * (
            report.mean_regret - global_mean_ceiling
        )
    return -float(loss)


def _bucket(value: float, bucket_count: int = 5) -> int:
    return min(bucket_count - 1, max(0, int(value * bucket_count)))


def _behaviour_cell(
    program: PriorityProgram,
    report: EvaluationReport,
    instances: Sequence[BinPackingInstance],
) -> ArchiveCell:
    if any(
        observation.get("placements") is None
        for observation in report.observations
    ):
        regrets = [
            float(observation["regret"])
            for observation in report.observations
        ]
        zero_regret_rate = sum(value == 0.0 for value in regrets) / len(regrets)
        high_regret_rate = sum(value >= 2.0 for value in regrets) / len(regrets)
        complexity_bucket = (
            0 if program.complexity <= 3
            else 1 if program.complexity <= 9
            else 2
        )
        return (
            min(4, int(report.mean_regret)),
            _bucket(zero_regret_rate),
            _bucket(high_regret_rate),
            complexity_bucket,
        )

    capacities = {
        instance.instance_id: instance.capacity for instance in instances
    }
    selected_fill: List[float] = []
    selected_index: List[float] = []
    deliberate_opens = 0
    placement_count = 0
    for observation in report.observations:
        capacity = capacities[str(observation["instance_id"])]
        previous_loads: Sequence[int] = ()
        for placement in observation["placements"]:
            loads = placement["loads_after"]
            bin_index = int(placement["bin_index"])
            item = int(placement["item"])
            opened_bin = len(loads) > len(previous_loads)
            if opened_bin and any(
                load + item <= capacity for load in previous_loads
            ):
                deliberate_opens += 1
            placement_count += 1
            selected_fill.append(float(loads[bin_index]) / capacity)
            selected_index.append(
                bin_index / float(max(1, len(loads) - 1))
            )
            previous_loads = loads

    mean_fill = sum(selected_fill) / len(selected_fill)
    mean_index = sum(selected_index) / len(selected_index)
    complexity_bucket = (
        0 if program.complexity <= 3
        else 1 if program.complexity <= 9
        else 2
    )
    deliberate_open_rate = deliberate_opens / float(placement_count)
    return (
        _bucket(mean_fill),
        _bucket(mean_index),
        _bucket(deliberate_open_rate),
        complexity_bucket,
    )


def run_evolutionary_search(
    config: SearchConfig,
    instances: Iterable[BinPackingInstance],
    artifact_store: Optional[ArtifactStore] = None,
    additional_seed_programs: Iterable[PriorityProgram] = (),
    instance_weights: Optional[Mapping[str, float]] = None,
    global_mean_ceiling: Optional[float] = None,
    global_constraint_penalty: float = 10.0,
) -> SearchOutcome:
    if config.evaluation_budget <= 0:
        raise ValueError("evaluation_budget must be positive")
    instance_tuple = tuple(instances)
    if not instance_tuple:
        raise ValueError("at least one development instance is required")
    instance_ids = {instance.instance_id for instance in instance_tuple}
    if instance_weights is not None and set(instance_weights) != instance_ids:
        raise ValueError("instance weights must cover exactly the development suite")

    rng = random.Random(config.seed)
    references = prepare_references(instance_tuple, config.reference_mode)
    archive = BehaviourArchive()
    evaluated: List[CandidateRecord] = []
    seen = set()
    duplicate_attempts = 0

    def evaluate(
        program: PriorityProgram,
        parent_ids: Tuple[str, ...],
        operator: str,
    ) -> bool:
        if program.candidate_id in seen:
            return False
        seen.add(program.candidate_id)
        report = evaluate_heuristic(
            program,
            instance_tuple,
            optima=references,
            reference_mode=config.reference_mode,
            include_placements=config.record_placements,
        )
        cell = _behaviour_cell(program, report, instance_tuple)
        fitness = _fitness(
            report,
            program.complexity,
            config.complexity_penalty,
            instance_weights,
            global_mean_ceiling,
            global_constraint_penalty,
        )
        report_artifact = None
        candidate_artifact = None
        if artifact_store is not None:
            report_artifact = artifact_store.put(
                "search_evaluation_report",
                report.as_dict(),
            )
            candidate_artifact = artifact_store.put(
                "priority_program_candidate",
                {
                    "program": program.as_dict(),
                    "parent_ids": list(parent_ids),
                    "operator": operator,
                    "evaluation_index": len(evaluated),
                    "fitness": fitness,
                    "archive_cell": list(cell),
                    "report_artifact": report_artifact,
                },
            )
        record = CandidateRecord(
            program=program,
            parent_ids=parent_ids,
            operator=operator,
            evaluation_index=len(evaluated),
            fitness=fitness,
            archive_cell=cell,
            report=report,
            candidate_artifact=candidate_artifact,
            report_artifact=report_artifact,
        )
        evaluated.append(record)
        archive.add(record)
        return True

    initial_programs = [
        (program, "seed") for program in seed_programs()
    ]
    initial_programs.extend(
        (program, "regime_seed")
        for program in additional_seed_programs
    )
    initial_programs.extend(
        (
            PriorityProgram(random_expression(rng, max_depth=4)),
            "random_seed",
        )
        for _ in range(config.initial_random)
    )
    for program, operator in initial_programs:
        if len(evaluated) >= config.evaluation_budget:
            break
        if not evaluate(program, (), operator):
            duplicate_attempts += 1

    maximum_attempts = config.evaluation_budget * 100
    attempts = 0
    while (
        len(evaluated) < config.evaluation_budget
        and attempts < maximum_attempts
    ):
        attempts += 1
        first_parent = archive.sample(rng)
        if (
            len(archive.records()) > 1
            and rng.random() < config.crossover_probability
        ):
            second_parent = archive.sample(rng)
            child_expression = crossover_expressions(
                first_parent.program.expression,
                second_parent.program.expression,
                rng,
                max_depth=config.max_expression_depth,
                max_nodes=config.max_expression_nodes,
            )
            parents = (
                first_parent.program.candidate_id,
                second_parent.program.candidate_id,
            )
            operator = "crossover"
        else:
            child_expression = mutate_expression(
                first_parent.program.expression,
                rng,
                max_depth=config.max_expression_depth,
                max_nodes=config.max_expression_nodes,
            )
            parents = (first_parent.program.candidate_id,)
            operator = "mutation"

        if not evaluate(PriorityProgram(child_expression), parents, operator):
            duplicate_attempts += 1

    if len(evaluated) != config.evaluation_budget:
        raise RuntimeError(
            "search exhausted unique candidates at %d/%d evaluations"
            % (len(evaluated), config.evaluation_budget)
        )

    return SearchOutcome(
        config=config,
        best=archive.best(),
        archive=archive.records(),
        evaluated=tuple(evaluated),
        duplicate_attempts=duplicate_attempts,
    )
