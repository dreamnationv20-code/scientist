from __future__ import annotations

import json
import random
import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Protocol, Sequence, Tuple, Union

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.binpacking.equivalence import (
    BEHAVIOUR_FINGERPRINT_SCHEMA,
    behaviour_trace,
    direct_action_comparison,
)
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.first_principles_oracle import (
    assess_first_principles_objective_gate,
)
from scientist.domains.binpacking.de_novo_calibration import (
    DeNovoCalibrationConfig,
    calibrate_de_novo_program,
)
from scientist.domains.binpacking.de_novo_learning import (
    CounterexampleAtlasConfig,
    assess_representation_headroom,
    build_counterexample_atlas,
    build_de_novo_research_memory,
    classify_de_novo_evidence,
)
from scientist.domains.binpacking.rollout_teacher import (
    RolloutTeacherConfig,
    build_rollout_teacher,
)
from scientist.domains.binpacking.code_policy import (
    CodeModelBackend,
    GeneratedPolicyModuleProgram,
    GeneratedPolicyProgram,
    GeneratedPolicyRejected,
    PolicyCalibrationParameter,
    generated_policy_prompt,
)
from scientist.domains.binpacking.mechanism_hypothesis import (
    CausalMechanismHypothesis,
    mechanism_compiler_prompt,
    mechanism_hypothesis_prompt,
    mechanism_review,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.research_strategy import (
    assess_compiled_representation,
)
from scientist.domains.binpacking.scientific_validation import (
    assess_distinguishing_mechanism,
    assess_host_baseline_authority,
    assess_semantic_novelty,
)
from scientist.domains.binpacking.programs import (
    ActionHybridProgram,
    CalibratedOverrideActionProgram,
    CalibratedOverrideHybridProgram,
    ContextualLinearProgram,
    DemandMemoryProgram,
    Expression,
    FunSearchResidualProgram,
    HybridPolicyProgram,
    MoonshotHybridProgram,
    MoonshotProgram,
    PriorityProgram,
    RegimeRouterProgram,
    StructuralHybridProgram,
    crossover_expressions,
    mutate_expression,
    program_from_dict,
    random_expression,
    seed_programs,
)
from scientist.program.hypothesis_learning import (
    MechanismDistanceAssessment,
    RiskBudgetedDiscoveryAssessment,
)
from scientist.program.literature_grounding import (
    LiteratureHypothesisContext,
)
from scientist.program.research_strategy import ResearchProgramContract
from scientist.program.discovery_evidence import paired_episode_evidence
from scientist.search.residual import PairedPolicyReport, evaluate_paired_policy


ISLAND_SEARCH_VERSION = (
    "three-island-mechanism-compiled-v21-executable-objective-gate"
)
ISLAND_NAMES = ("funsearch_ancestry", "de_novo", "hybrid")
IslandName = str
SearchProgram = Union[
    GeneratedPolicyModuleProgram,
    GeneratedPolicyProgram,
    FunSearchResidualProgram,
    PriorityProgram,
    HybridPolicyProgram,
    ActionHybridProgram,
    MoonshotProgram,
    MoonshotHybridProgram,
    StructuralHybridProgram,
    CalibratedOverrideActionProgram,
    CalibratedOverrideHybridProgram,
    ContextualLinearProgram,
    DemandMemoryProgram,
    RegimeRouterProgram,
]
ArchiveCell = Tuple[int, int, int, int]


class IslandSearchStalled(RuntimeError):
    """Raised when a lane stops producing valid evidence within its budget."""


@dataclass(frozen=True)
class IslandSearchConfig:
    island: IslandName
    seed: int
    evaluation_budget: int = 40
    initial_random: int = 6
    crossover_probability: float = 0.25
    max_expression_depth: int = 8
    max_expression_nodes: int = 63
    residual_scale: float = 0.10
    research_guard_mean_delta_ceiling: float = 0.0
    research_guard_regression_fraction_ceiling: float = 0.35
    research_guard_max_regression: int = 1
    episode_confidence_discovery: bool = False
    guard_mean_delta_ceiling: float = 0.0
    guard_regression_fraction_ceiling: float = 0.0
    guard_max_regression: int = 1
    exploration_lane: bool = False
    minimum_mechanism_distance: int = 0
    require_incumbent_blind: bool = False
    require_new_decision_primitive: bool = False
    exploration_mean_regression_ceiling: float = 4.0
    exploration_regression_fraction_ceiling: float = 0.85
    exploration_max_regression: int = 8
    require_mechanism_gate: bool = False
    require_de_novo_learning_gate: bool = False
    minimum_known_control_action_distance: float = 0.001
    max_candidates_per_mechanism_cluster: int = 0
    max_consecutive_candidate_rejections: int = 0

    def __post_init__(self) -> None:
        if self.island not in ISLAND_NAMES:
            raise ValueError("unknown island: %s" % self.island)
        if self.evaluation_budget <= 0:
            raise ValueError("evaluation_budget must be positive")
        if self.initial_random < 0:
            raise ValueError("initial_random must be non-negative")
        if not 0.0 <= self.crossover_probability <= 1.0:
            raise ValueError("invalid crossover probability")
        if self.max_expression_depth <= 0 or self.max_expression_nodes <= 0:
            raise ValueError("expression limits must be positive")
        if self.residual_scale <= 0:
            raise ValueError("residual_scale must be positive")
        if not 0.0 <= self.research_guard_regression_fraction_ceiling <= 1.0:
            raise ValueError("invalid research guard regression fraction")
        if self.research_guard_max_regression < 0:
            raise ValueError(
                "research_guard_max_regression must be non-negative"
            )
        if not 0.0 <= self.guard_regression_fraction_ceiling <= 1.0:
            raise ValueError("invalid guard regression fraction")
        if self.guard_max_regression < 0:
            raise ValueError("guard_max_regression must be non-negative")
        if not 0 <= self.minimum_mechanism_distance <= 4:
            raise ValueError("minimum mechanism distance must be in [0, 4]")
        if self.exploration_mean_regression_ceiling < 0.0:
            raise ValueError(
                "exploration mean-regression ceiling must be non-negative"
            )
        if not 0.0 <= (
            self.exploration_regression_fraction_ceiling
        ) <= 1.0:
            raise ValueError(
                "invalid exploration regression fraction"
            )
        if self.exploration_max_regression <= 0:
            raise ValueError(
                "exploration maximum regression must be positive"
            )
        if not 0.0 <= self.minimum_known_control_action_distance <= 1.0:
            raise ValueError("known-control action distance must be in [0, 1]")
        if self.max_candidates_per_mechanism_cluster < 0:
            raise ValueError("mechanism-cluster cap must be non-negative")
        if self.max_consecutive_candidate_rejections < 0:
            raise ValueError("candidate-rejection limit must be non-negative")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "island": self.island,
            "seed": self.seed,
            "evaluation_budget": self.evaluation_budget,
            "initial_random": self.initial_random,
            "crossover_probability": self.crossover_probability,
            "max_expression_depth": self.max_expression_depth,
            "max_expression_nodes": self.max_expression_nodes,
            "residual_scale": self.residual_scale,
            "research_guard_mean_delta_ceiling": (
                self.research_guard_mean_delta_ceiling
            ),
            "research_guard_regression_fraction_ceiling": (
                self.research_guard_regression_fraction_ceiling
            ),
            "research_guard_max_regression": (
                self.research_guard_max_regression
            ),
            "episode_confidence_discovery": (
                self.episode_confidence_discovery
            ),
            "guard_mean_delta_ceiling": self.guard_mean_delta_ceiling,
            "guard_regression_fraction_ceiling": (
                self.guard_regression_fraction_ceiling
            ),
            "guard_max_regression": self.guard_max_regression,
            "exploration_lane": self.exploration_lane,
            "minimum_mechanism_distance": (
                self.minimum_mechanism_distance
            ),
            "require_incumbent_blind": self.require_incumbent_blind,
            "require_new_decision_primitive": (
                self.require_new_decision_primitive
            ),
            "exploration_mean_regression_ceiling": (
                self.exploration_mean_regression_ceiling
            ),
            "exploration_regression_fraction_ceiling": (
                self.exploration_regression_fraction_ceiling
            ),
            "exploration_max_regression": (
                self.exploration_max_regression
            ),
            "require_mechanism_gate": self.require_mechanism_gate,
            "require_de_novo_learning_gate": (
                self.require_de_novo_learning_gate
            ),
            "minimum_known_control_action_distance": (
                self.minimum_known_control_action_distance
            ),
            "max_candidates_per_mechanism_cluster": (
                self.max_candidates_per_mechanism_cluster
            ),
            "max_consecutive_candidate_rejections": (
                self.max_consecutive_candidate_rejections
            ),
        }


def _mechanism_gate_decision(
    semantic_novelty: Mapping[str, Any],
    config: IslandSearchConfig,
    *,
    candidate_family: Optional[str] = None,
    first_principles_objective_gate: Optional[Mapping[str, Any]] = None,
    de_novo_objective_calibration: Optional[Mapping[str, Any]] = None,
    de_novo_representation_headroom: Optional[Mapping[str, Any]] = None,
) -> Mapping[str, Any]:
    """Separate scientific admission from the stronger novelty claim.

    An ancestry intervention may honestly disclose its baseline family because
    incremental work is novel only in the intervention.  A first-principles
    derivation may also rediscover a known policy: that forfeits novelty credit,
    but it does not invalidate the derivation or its objective test.
    """

    semantic_passed = bool(semantic_novelty.get("passed", False))
    failure_reasons = {
        str(reason)
        for reason in semantic_novelty.get("failure_reasons", ())
    }
    known_family_matches = tuple(
        semantic_novelty.get("known_family_matches", ())
    )
    disclosure_scope_exception = (
        config.island == "funsearch_ancestry"
        and
        not known_family_matches
        and failure_reasons
        == {"mechanism_fingerprint_names_known_family"}
    )
    effective_family = candidate_family or (
        "de_novo" if config.island == "de_novo" else config.island
    )
    first_principles_lane = effective_family == "de_novo"
    first_principles_objective_passed = bool(
        first_principles_objective_gate
        and first_principles_objective_gate.get("passed", False)
    )
    calibration_passed = bool(
        de_novo_objective_calibration is None
        or de_novo_objective_calibration.get("passed", False)
    )
    representation_headroom_passed = bool(
        not config.require_de_novo_learning_gate
        or (
            de_novo_representation_headroom is not None
            and de_novo_representation_headroom.get("passed", False)
        )
    )
    first_principles_scope_exception = (
        first_principles_lane
        and first_principles_objective_passed
        and calibration_passed
        and representation_headroom_passed
    )
    if first_principles_lane and first_principles_objective_gate is None:
        failure_reasons.add("first_principles_objective_gate_missing")
    elif first_principles_lane and not first_principles_objective_passed:
        failure_reasons.update(
            "first_principles_objective:%s" % reason
            for reason in first_principles_objective_gate.get(
                "failure_reasons", ()
            )
        )
    if first_principles_lane and not calibration_passed:
        failure_reasons.update(
            "de_novo_objective_calibration:%s" % reason
            for reason in de_novo_objective_calibration.get(
                "failure_reasons", ()
            )
        )
    if (
        first_principles_lane
        and config.require_de_novo_learning_gate
        and de_novo_representation_headroom is None
    ):
        failure_reasons.add("de_novo_representation_headroom_missing")
    elif first_principles_lane and not representation_headroom_passed:
        failure_reasons.update(
            "de_novo_representation_headroom:%s" % reason
            for reason in de_novo_representation_headroom.get(
                "failure_reasons", ()
            )
        )
    passed = (
        (
            first_principles_scope_exception
            if config.require_de_novo_learning_gate
            else (semantic_passed or first_principles_scope_exception)
        )
        if first_principles_lane
        else (semantic_passed or disclosure_scope_exception)
    )
    report = {
        "schema": 1,
        "search_version": ISLAND_SEARCH_VERSION,
        "policy": "lane_scoped_semantic_admission",
        "island": config.island,
        "passed": passed,
        "semantic_novelty_passed": semantic_passed,
        "known_family_disclosure_scope_exception": (
            disclosure_scope_exception
        ),
        "ancestry_known_family_scope_exception": (
            disclosure_scope_exception
        ),
        "first_principles_novelty_scope_exception": (
            first_principles_scope_exception and not semantic_passed
        ),
        "first_principles_objective_gate": (
            None
            if first_principles_objective_gate is None
            else dict(first_principles_objective_gate)
        ),
        "first_principles_objective_passed": (
            first_principles_objective_passed
        ),
        "de_novo_objective_calibration": (
            None
            if de_novo_objective_calibration is None
            else dict(de_novo_objective_calibration)
        ),
        "de_novo_objective_calibration_passed": calibration_passed,
        "de_novo_representation_headroom": (
            None
            if de_novo_representation_headroom is None
            else dict(de_novo_representation_headroom)
        ),
        "de_novo_representation_headroom_passed": (
            representation_headroom_passed
        ),
        "de_novo_representation_headroom_required": (
            config.require_de_novo_learning_gate
        ),
        "novelty_credit_conferred": semantic_passed,
        "failure_reasons": sorted(failure_reasons),
    }
    return {
        **report,
        "decision_id": content_digest(report),
    }


@dataclass(frozen=True)
class Proposal:
    program: SearchProgram
    parent_ids: Tuple[str, ...]
    operator: str


class ProposalEngine(Protocol):
    """Boundary for deterministic or model-generated proposal engines."""

    name: str

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        ...

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence["IslandCandidateRecord"],
        rng: random.Random,
    ) -> Proposal:
        ...


def _residual_seed_expressions() -> Tuple[Expression, ...]:
    large_item = Expression.unary(
        "step",
        Expression.binary(
            "sub",
            Expression.feature("item"),
            Expression.const(0.5),
        ),
    )
    valley_repairs = tuple(
        Expression.binary(
            "mul",
            large_item,
            Expression.unary(
                "step",
                Expression.binary(
                    "sub",
                    Expression.const(threshold),
                    Expression.feature("remaining_after"),
                ),
            ),
        )
        for threshold in (0.06, 0.07, 0.08)
    )
    return (
        Expression.const(0.0),
        Expression.feature("fill_after"),
        Expression.unary("neg", Expression.feature("fill_after")),
        Expression.feature("bin_index"),
        Expression.unary("neg", Expression.feature("bin_index")),
        Expression.feature("is_new_bin"),
        Expression.unary("neg", Expression.feature("is_new_bin")),
        *valley_repairs,
    )


def _action_hybrid_seed_pairs(
) -> Tuple[Tuple[Expression, Expression], ...]:
    exact_fill = Expression.binary(
        "sub",
        Expression.const(0.0),
        Expression.feature("remaining_after"),
    )
    near_fill = Expression.binary(
        "sub",
        Expression.const(0.02),
        Expression.feature("remaining_after"),
    )
    large_item = Expression.binary(
        "sub",
        Expression.feature("item"),
        Expression.const(0.5),
    )
    return (
        (Expression.const(1.0), Expression.const(0.0)),
        (exact_fill, Expression.const(1.0)),
        (near_fill, Expression.const(1.0)),
        (large_item, Expression.unary(
            "neg",
            Expression.feature("remaining_after"),
        )),
        (
            Expression.binary(
                "sub",
                Expression.feature("seen_std"),
                Expression.const(0.15),
            ),
            Expression.feature("fill_after"),
        ),
        (
            Expression.binary(
                "sub",
                Expression.feature("seen_large_fraction"),
                Expression.const(0.5),
            ),
            Expression.unary(
                "neg",
                Expression.feature("bin_index"),
            ),
        ),
    )


def _literature_expression(mechanism: str) -> Expression:
    remaining = Expression.feature("remaining_after")
    seen_mean = Expression.feature("seen_mean")
    seen_std = Expression.feature("seen_std")
    seen_large = Expression.feature("seen_large_fraction")
    negative_remaining = Expression.unary("neg", remaining)
    if mechanism == "tight_fit_priority":
        return negative_remaining
    if mechanism == "parameterized_score_evolution":
        return Expression.binary(
            "add",
            Expression.feature("fill_after"),
            Expression.binary("mul", seen_std, negative_remaining),
        )
    if mechanism in (
        "predictive_profile_reservation",
        "adaptive_pattern_memory",
    ):
        return Expression.unary(
            "neg",
            Expression.binary("sub", remaining, seen_mean),
        )
    if mechanism == "state_conditioned_policy_selection":
        return Expression.binary(
            "mul",
            Expression.unary(
                "step",
                Expression.binary(
                    "sub",
                    seen_std,
                    Expression.const(0.15),
                ),
            ),
            negative_remaining,
        )
    if mechanism == "counterfactual_lookahead":
        return Expression.unary(
            "neg",
            Expression.unary(
                "square",
                Expression.binary("sub", remaining, seen_mean),
            ),
        )
    if mechanism == "option_preservation":
        return Expression.binary("mul", seen_large, remaining)
    if mechanism == "change_detection":
        return Expression.binary(
            "mul",
            seen_std,
            Expression.binary(
                "sub",
                remaining,
                Expression.const(0.25),
            ),
        )
    if mechanism == "failure_syndrome_intervention":
        return Expression.binary(
            "mul",
            Expression.unary(
                "step",
                Expression.binary(
                    "sub",
                    seen_std,
                    Expression.const(0.15),
                ),
            ),
            Expression.unary(
                "step",
                Expression.binary(
                    "sub",
                    remaining,
                    Expression.const(0.25),
                ),
            ),
        )
    return Expression.unary(
        "neg",
        Expression.unary(
            "abs",
            Expression.binary("sub", remaining, seen_mean),
        ),
    )


def _literature_operator(
    context: LiteratureHypothesisContext,
    mechanism: str,
) -> str:
    evidence = context.primary_evidence(mechanism)
    source_id = (
        evidence.work_id
        if evidence is not None
        else context.source_work_ids[0]
    )
    return "literature_contrast_seed:%s:%s" % (
        mechanism,
        source_id,
    )


def _literature_expression_seeds(
    context: LiteratureHypothesisContext,
) -> Tuple[Tuple[str, Expression], ...]:
    observed = set()
    seeds = []
    for mechanism in context.hypothesis_mechanisms:
        expression = _literature_expression(mechanism)
        digest = content_digest(expression.as_dict())
        if digest in observed:
            continue
        observed.add(digest)
        seeds.append((mechanism, expression))
    return tuple(seeds)


class StructuredEvolutionProposer:
    """AlphaEvolve-shaped search using typed DSL mutation and crossover.

    This is deliberately not presented as an LLM proposer.  It gives the
    campaign an executable, reproducible proposer boundary that a code model
    can replace later without changing evaluation or promotion contracts.
    """

    name = "structured_dsl_mutation_crossover"

    def __init__(
        self,
        literature_context: Optional[
            LiteratureHypothesisContext
        ] = None,
    ) -> None:
        self.literature_context = literature_context
        self.literature_context_id = (
            None
            if literature_context is None
            else literature_context.context_id
        )

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        if config.island == "funsearch_ancestry":
            default_expressions = _residual_seed_expressions()
            yield Proposal(
                FunSearchResidualProgram(
                    default_expressions[0],
                    config.residual_scale,
                ),
                (),
                "incumbent",
            )
            observed = {
                content_digest(default_expressions[0].as_dict())
            }
            if self.literature_context is not None:
                for mechanism, expression in (
                    _literature_expression_seeds(
                        self.literature_context
                    )
                ):
                    digest = content_digest(expression.as_dict())
                    if digest in observed:
                        continue
                    observed.add(digest)
                    yield Proposal(
                        FunSearchResidualProgram(
                            expression,
                            config.residual_scale,
                        ),
                        (),
                        _literature_operator(
                            self.literature_context,
                            mechanism,
                        ),
                    )
            for expression in default_expressions[1:]:
                digest = content_digest(expression.as_dict())
                if digest in observed:
                    continue
                observed.add(digest)
                yield Proposal(
                    FunSearchResidualProgram(
                        expression,
                        config.residual_scale,
                    ),
                    (),
                    "mechanism_control_seed",
                )
            for _ in range(config.initial_random):
                yield Proposal(
                    FunSearchResidualProgram(
                        random_expression(rng, 4),
                        config.residual_scale,
                    ),
                    (),
                    "random_seed",
                )
            return

        if config.island == "de_novo":
            if self.literature_context is not None:
                for mechanism, expression in (
                    _literature_expression_seeds(
                        self.literature_context
                    )
                ):
                    yield Proposal(
                        PriorityProgram(expression),
                        (),
                        _literature_operator(
                            self.literature_context,
                            mechanism,
                        ),
                    )
            for program in seed_programs():
                yield Proposal(program, (), "published_policy_control_seed")
            for _ in range(config.initial_random):
                yield Proposal(
                    PriorityProgram(random_expression(rng, 4)),
                    (),
                    "random_seed",
                )
            return

        if self.literature_context is not None:
            for mechanism, expression in _literature_expression_seeds(
                self.literature_context
            ):
                yield Proposal(
                    ActionHybridProgram(
                        Expression.binary(
                            "sub",
                            Expression.feature("seen_std"),
                            Expression.const(0.15),
                        ),
                        expression,
                        config.residual_scale,
                    ),
                    (),
                    _literature_operator(
                        self.literature_context,
                        mechanism,
                    ),
                )
        for router, de_novo in _action_hybrid_seed_pairs():
            yield Proposal(
                ActionHybridProgram(
                    router,
                    de_novo,
                    config.residual_scale,
                ),
                (),
                "incumbent"
                if de_novo == Expression.const(0.0)
                else "routing_seed",
            )
        for _ in range(config.initial_random):
            yield Proposal(
                ActionHybridProgram(
                    random_expression(rng, 3),
                    random_expression(rng, 4),
                    config.residual_scale,
                ),
                (),
                "random_seed",
            )

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence["IslandCandidateRecord"],
        rng: random.Random,
    ) -> Proposal:
        first = rng.choice(tuple(archive))
        use_crossover = (
            len(archive) > 1
            and rng.random() < config.crossover_probability
        )
        second = rng.choice(tuple(archive)) if use_crossover else None
        if config.island == "funsearch_ancestry":
            assert isinstance(first.program, FunSearchResidualProgram)
            if second is not None:
                assert isinstance(second.program, FunSearchResidualProgram)
                expression = crossover_expressions(
                    first.program.expression,
                    second.program.expression,
                    rng,
                    config.max_expression_depth,
                    config.max_expression_nodes,
                )
                return Proposal(
                    FunSearchResidualProgram(
                        expression,
                        config.residual_scale,
                    ),
                    (
                        first.program.candidate_id,
                        second.program.candidate_id,
                    ),
                    "crossover",
                )
            return Proposal(
                FunSearchResidualProgram(
                    mutate_expression(
                        first.program.expression,
                        rng,
                        config.max_expression_depth,
                        config.max_expression_nodes,
                    ),
                    config.residual_scale,
                ),
                (first.program.candidate_id,),
                "mutation",
            )

        if config.island == "de_novo":
            assert isinstance(first.program, PriorityProgram)
            if second is not None:
                assert isinstance(second.program, PriorityProgram)
                expression = crossover_expressions(
                    first.program.expression,
                    second.program.expression,
                    rng,
                    config.max_expression_depth,
                    config.max_expression_nodes,
                )
                return Proposal(
                    PriorityProgram(expression),
                    (
                        first.program.candidate_id,
                        second.program.candidate_id,
                    ),
                    "crossover",
                )
            return Proposal(
                PriorityProgram(
                    mutate_expression(
                        first.program.expression,
                        rng,
                        config.max_expression_depth,
                        config.max_expression_nodes,
                    )
                ),
                (first.program.candidate_id,),
                "mutation",
            )

        assert isinstance(first.program, ActionHybridProgram)
        if second is not None:
            assert isinstance(second.program, ActionHybridProgram)
            if rng.random() < 0.5:
                router = crossover_expressions(
                    first.program.router_expression,
                    second.program.router_expression,
                    rng,
                    config.max_expression_depth,
                    config.max_expression_nodes,
                )
                de_novo = first.program.de_novo_expression
                operator = "router_crossover"
            else:
                router = first.program.router_expression
                de_novo = crossover_expressions(
                    first.program.de_novo_expression,
                    second.program.de_novo_expression,
                    rng,
                    config.max_expression_depth,
                    config.max_expression_nodes,
                )
                operator = "policy_crossover"
            return Proposal(
                ActionHybridProgram(
                    router,
                    de_novo,
                    config.residual_scale,
                ),
                (
                    first.program.candidate_id,
                    second.program.candidate_id,
                ),
                operator,
            )
        if rng.random() < 0.5:
            router = mutate_expression(
                first.program.router_expression,
                rng,
                config.max_expression_depth,
                config.max_expression_nodes,
            )
            de_novo = first.program.de_novo_expression
            operator = "router_mutation"
        else:
            router = first.program.router_expression
            de_novo = mutate_expression(
                first.program.de_novo_expression,
                rng,
                config.max_expression_depth,
                config.max_expression_nodes,
            )
            operator = "policy_mutation"
        return Proposal(
            ActionHybridProgram(
                router,
                de_novo,
                config.residual_scale,
            ),
            (first.program.candidate_id,),
            operator,
        )


class ExecutableCodeProposer:
    """Code-model proposer; it never falls back to registered templates."""

    def __init__(
        self,
        backend: CodeModelBackend,
        literature_context: LiteratureHypothesisContext,
        *,
        additional_literature_contexts: Sequence[
            LiteratureHypothesisContext
        ] = (),
        batch_size: int = 4,
    ) -> None:
        if batch_size <= 0 or batch_size > 16:
            raise ValueError("code proposer batch size must be in [1, 16]")
        self.backend = backend
        self.literature_context = literature_context
        self.additional_literature_contexts = tuple(
            additional_literature_contexts
        )
        self.literature_context_id = literature_context.context_id
        self.batch_size = batch_size
        self.name = "executable_code_model:%s" % backend.model_ref
        self._pending: List[Proposal] = []

    def _literature_material(self) -> str:
        contexts = (
            self.literature_context,
            *self.additional_literature_contexts,
        )
        return "\n".join(
            (
                context.proposer_material()
                if callable(getattr(context, "proposer_material", None))
                else json.dumps(
                    context.as_dict(),
                    sort_keys=True,
                    separators=(",", ":"),
                )
            )
            for context in contexts
        )

    @staticmethod
    def _parent_material(
        archive: Sequence["IslandCandidateRecord"],
    ) -> str:
        if not archive:
            return "No parent policies. Generate from first principles."
        parents = sorted(
            archive,
            key=lambda record: record.rank,
            reverse=True,
        )[:4]
        return json.dumps(
            [
                {
                    "candidate": record.program.as_dict(),
                    "episode_performance": (
                        record.discovery_evidence.as_dict()
                    ),
                    "deployment_safe": record.deployment_safe,
                }
                for record in parents
            ],
            sort_keys=True,
            separators=(",", ":"),
        )

    def _generate(
        self,
        config: IslandSearchConfig,
        archive: Sequence["IslandCandidateRecord"],
        count: int,
    ) -> Tuple[Proposal, ...]:
        prompt = generated_policy_prompt(
            island=config.island,
            literature_material=self._literature_material(),
            parent_material=self._parent_material(archive),
        )
        proposals = []
        rejected = []
        observed_ids = set()
        request_prompt = prompt
        for attempt in range(3):
            remaining = count - len(proposals)
            if remaining == 0:
                break
            prompt_digest = content_digest(request_prompt)
            generated = self.backend.generate(request_prompt, remaining)
            attempt_rejections = []
            for index, item in enumerate(generated):
                try:
                    program = GeneratedPolicyProgram(
                        source=str(item["source"]),
                        model_ref=self.backend.model_ref,
                        prompt_digest=prompt_digest,
                        literature_context_id=(
                            self.literature_context.context_id
                        ),
                        rationale=str(item.get("rationale", "")),
                        inspiration_refs=tuple(
                            str(value)
                            for value in item.get("inspiration_refs", ())
                        ),
                    )
                    if program.candidate_id in observed_ids:
                        raise ValueError("duplicate executable source")
                except (KeyError, TypeError, ValueError) as error:
                    message = "attempt-%d:item-%d:%s" % (
                        attempt + 1,
                        index,
                        error,
                    )
                    rejected.append(message)
                    attempt_rejections.append(message)
                    continue
                observed_ids.add(program.candidate_id)
                proposals.append(
                    Proposal(
                        program=program,
                        parent_ids=tuple(
                            record.program.candidate_id
                            for record in archive[:4]
                        ),
                        operator="code_model_generation",
                    )
                )
            if attempt_rejections and len(proposals) < count:
                request_prompt = (
                    prompt
                    + "\n\nThe preceding batch was rejected by the static "
                    "sandbox for these reasons:\n- "
                    + "\n- ".join(attempt_rejections)
                    + "\nReturn corrected, structurally distinct replacements only."
                )
        if len(proposals) != count:
            raise RuntimeError(
                "code proposer rejected %d/%d generated policies: %s"
                % (len(rejected), count, "; ".join(rejected))
            )
        return tuple(proposals)

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        del rng
        count = min(
            config.evaluation_budget,
            max(1, config.initial_random),
        )
        return self._generate(config, (), count)

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence["IslandCandidateRecord"],
        rng: random.Random,
    ) -> Proposal:
        del rng
        if not self._pending:
            self._pending.extend(
                self._generate(config, archive, self.batch_size)
            )
        return self._pending.pop(0)


def _mechanism_contract_failures(
    hypothesis: CausalMechanismHypothesis,
) -> Tuple[str, ...]:
    """Fail closed when a lane label does not match its causal structure."""

    fingerprint = hypothesis.fingerprint
    baseline_memory = fingerprint.memory in {"none", "current_state_only"}
    baseline_horizon = fingerprint.horizon in {"myopic", "one_step"}
    baseline_coupling = fingerprint.action_coupling in {
        "independent_action_scoring",
        "none",
    }
    failures = []
    # These concepts can be useful sources of inspiration, but they are not
    # legal target actions in strict online irrevocable bin packing.  Check the
    # intervention-bearing fields rather than the whole hypothesis so a valid
    # proposal may still say that it works *without* lookahead or repacking.
    intervention_text = " ".join(
        (
            hypothesis.causal_mechanism,
            hypothesis.alternative_action,
            fingerprint.action_coupling,
            fingerprint.intervention_structure,
        )
    ).casefold()
    forbidden_actions = {
        "deferral_or_buffering": (
            r"\bdefer(?:red|ral|ring)?\b",
            r"\bbuffer(?:ed|ing)?\b",
            r"\bstag(?:e|ed|ing)\b",
        ),
        "reordering": (
            r"\bre-?order(?:ed|ing)?\b",
            r"\barrival[- ]order change\b",
        ),
        "repacking_or_migration": (
            r"\bre-?pack(?:ed|ing)?\b",
            r"\bunpack(?:ed|ing)?\b",
            r"\bmigrat(?:e|ed|es|ing|ion|ions)\b",
            r"\bmove (?:a |an |the )?(?:previous|placed|existing) item\b",
        ),
        "lookahead": (
            r"\blook[- ]?ahead\b",
            r"\bfuture (?:arrival|arrivals|item|items)\b",
            r"\bobservable (?:queue|suffix)\b",
        ),
    }

    def affirmatively_proposes(pattern: str) -> bool:
        """Ignore an action name when its clause explicitly forbids it."""

        for match in re.finditer(pattern, intervention_text):
            prefix = intervention_text[max(0, match.start() - 180):match.start()]
            clause = re.split(r"[.;]", prefix)[-1]
            negated = re.search(
                r"\b(?:no|not|never|without|forbid(?:s|den)?|"
                r"prohibit(?:s|ed)?)\b"
                r"(?:(?!\b(?:but|instead|except)\b).){0,140}$",
                clause,
            )
            if negated is None:
                return True
        return False

    for label, patterns in forbidden_actions.items():
        if any(affirmatively_proposes(pattern) for pattern in patterns):
            failures.append("out_of_scope_%s" % label)
    if hypothesis.island_family == "de_novo":
        if hypothesis.first_principles_derivation is None:
            failures.append("de_novo_missing_first_principles_derivation")
    if hypothesis.island_family == "cross_domain":
        target_heuristic_text = json.dumps(
            hypothesis.as_dict(include_id=False),
            sort_keys=True,
            separators=(",", ":"),
        ).casefold()
        if any(
            name in target_heuristic_text
            for name in (
                "funsearch",
                "best fit",
                "best_fit",
                "first fit",
                "first_fit",
                "worst fit",
                "worst_fit",
                "next fit",
                "next_fit",
            )
        ):
            failures.append("independent_invention_names_target_policy")
        if fingerprint.decision_topology == "greedy_scalar_action_score":
            failures.append("cross_domain_topology_is_scalar_greedy")
        if fingerprint.structural_distance < 2:
            failures.append("cross_domain_structural_distance_below_two")
        if baseline_memory and baseline_horizon and baseline_coupling:
            failures.append("cross_domain_introduces_no_decision_primitive")
        source = hypothesis.source_domain.casefold()
        if "bin pack" in source or "bin-pack" in source:
            failures.append("cross_domain_source_is_target_domain")
    if hypothesis.island_family == "hybrid":
        if fingerprint.decision_topology == "greedy_scalar_action_score":
            failures.append("hybrid_topology_is_scalar_greedy")
        if fingerprint.structural_distance < 2:
            failures.append("hybrid_structural_distance_below_two")
        if baseline_coupling:
            failures.append("hybrid_has_no_routing_or_action_coupling")
    return tuple(failures)


class MechanismCodeProposer:
    """Generate causal contracts first, then compile bounded joint policies.

    Unlike :class:`ExecutableCodeProposer`, this production proposer cannot
    emit the legacy ``score_action`` program type.  Lane identity is carried by
    the causal contract and the compiled program, while hybrid parentage and
    cross-domain origin are explicit provenance rather than prompt labels.
    """

    def __init__(
        self,
        backend: CodeModelBackend,
        literature_context: LiteratureHypothesisContext,
        *,
        island_family: str,
        target_node_id: str,
        cross_domain_context: Optional[LiteratureHypothesisContext] = None,
        hybrid_parent_material: Sequence[Mapping[str, Any]] = (),
        experimental_findings: str = "",
        batch_size: int = 4,
        artifact_store: Optional[ArtifactStore] = None,
        campaign_stage_id: Optional[str] = None,
        existing_proposals: Sequence[Proposal] = (),
        research_program: Optional[ResearchProgramContract] = None,
        baseline_policy_ref: Optional[str] = None,
        sequential_de_novo_learning: bool = False,
    ) -> None:
        if island_family not in {"ancestry", "de_novo", "hybrid"}:
            raise ValueError("mechanism proposer has an unknown island family")
        if batch_size <= 0 or batch_size > 16:
            raise ValueError("mechanism proposer batch size must be in [1, 16]")
        if not target_node_id:
            raise ValueError("mechanism proposer requires a target node")
        self.backend = backend
        self.literature_context = literature_context
        self.island_family = island_family
        self.target_node_id = target_node_id
        self.cross_domain_context = cross_domain_context
        self.hybrid_parent_material = tuple(
            dict(item) for item in hybrid_parent_material
        )
        self.experimental_findings = experimental_findings
        self.batch_size = batch_size
        self.artifact_store = artifact_store
        self.campaign_stage_id = campaign_stage_id
        self.research_program = research_program
        self.sequential_de_novo_learning = bool(
            sequential_de_novo_learning
        )
        if self.sequential_de_novo_learning and island_family != "de_novo":
            raise ValueError(
                "sequential de-novo learning is reserved for the de-novo island"
            )
        self.baseline_policy_ref = (
            baseline_policy_ref
            if baseline_policy_ref is not None
            else (
                "funsearch_or_reference"
                if island_family == "ancestry"
                else None
            )
        )
        if island_family == "ancestry" and not self.baseline_policy_ref:
            raise ValueError("ancestry proposer requires a host baseline ref")
        if island_family != "ancestry" and self.baseline_policy_ref is not None:
            raise ValueError("only ancestry proposer may receive a host baseline")
        if (
            research_program is not None
            and research_program.node_id != target_node_id
        ):
            raise ValueError("research program targets another goal node")
        self.literature_context_id = literature_context.context_id
        self.name = "mechanism_compiled_code_model:%s" % backend.model_ref
        self._pending: List[Proposal] = []
        self._incumbent_exposure_audit_ids: Dict[str, str] = {}
        self._first_principles_audit_ids: Dict[str, str] = {}
        self.required_parent_programs = tuple(
            program_from_dict(item["candidate"])
            for item in self.hybrid_parent_material
            if isinstance(item.get("candidate"), Mapping)
        )
        self._resumed_cross_domain = any(
            isinstance(proposal.program, GeneratedPolicyModuleProgram)
            and proposal.program.island_family == "cross_domain"
            for proposal in existing_proposals
        )
        compiled_hypothesis_ids = {
            proposal.program.hypothesis_id
            for proposal in existing_proposals
            if isinstance(proposal.program, GeneratedPolicyModuleProgram)
        }
        compiled_fingerprint_ids = {
            proposal.program.mechanism_fingerprint.fingerprint_id
            for proposal in existing_proposals
            if isinstance(proposal.program, GeneratedPolicyModuleProgram)
        }
        if self.artifact_store is not None and self.campaign_stage_id is not None:
            for _, value in self.artifact_store.iter_kind(
                "compiled_mechanism_candidate"
            ):
                if value.get("campaign_stage_id") != self.campaign_stage_id:
                    continue
                candidate = value.get("candidate", {})
                hypothesis_id = str(value.get("hypothesis_id", ""))
                fingerprint_id = str(
                    candidate.get("mechanism_fingerprint", {}).get(
                        "fingerprint_id",
                        "",
                    )
                )
                if hypothesis_id:
                    compiled_hypothesis_ids.add(hypothesis_id)
                if fingerprint_id:
                    compiled_fingerprint_ids.add(fingerprint_id)
        self._attempted_hypothesis_ids = set(compiled_hypothesis_ids)
        self._attempted_fingerprint_ids = set(compiled_fingerprint_ids)
        self._rejected_hypothesis_ids: set[str] = set()
        self._rejected_fingerprint_ids: set[str] = set()
        if self.artifact_store is not None and self.campaign_stage_id is not None:
            for _, value in self.artifact_store.iter_kind(
                "causal_mechanism_hypothesis_rejection"
            ):
                if value.get("campaign_stage_id") != self.campaign_stage_id:
                    continue
                hypothesis_id = str(value.get("hypothesis_id", ""))
                fingerprint_id = str(value.get("fingerprint_id", ""))
                if hypothesis_id:
                    self._rejected_hypothesis_ids.add(hypothesis_id)
                if fingerprint_id:
                    self._rejected_fingerprint_ids.add(fingerprint_id)
        cached_hypotheses: Dict[
            str, List[CausalMechanismHypothesis]
        ] = {}
        if self.artifact_store is not None and self.campaign_stage_id is not None:
            for _, value in self.artifact_store.iter_kind(
                "causal_mechanism_hypothesis"
            ):
                if value.get("campaign_stage_id") != self.campaign_stage_id:
                    continue
                if not value.get("admitted_for_compilation", False):
                    continue
                try:
                    raw_hypothesis = value["hypothesis"]
                    family = str(raw_hypothesis["island_family"])
                    hypothesis = CausalMechanismHypothesis.from_model_dict(
                        raw_hypothesis,
                        target_node_id=self.target_node_id,
                        island_family=family,
                        generator_ref=str(
                            raw_hypothesis.get("generator_ref", self.name)
                        ),
                    )
                except (KeyError, TypeError, ValueError):
                    continue
                if hypothesis.hypothesis_id in compiled_hypothesis_ids:
                    continue
                cached_hypotheses.setdefault(family, []).append(hypothesis)
        self._cached_hypotheses = {
            family: list(
                {
                    hypothesis.hypothesis_id: hypothesis
                    for hypothesis in hypotheses
                }.values()
            )
            for family, hypotheses in cached_hypotheses.items()
        }
        parent_families = {
            str(item.get("family", ""))
            for item in self.hybrid_parent_material
        }
        if self.island_family == "hybrid" and not {
            "ancestry",
            "de_novo",
        }.issubset(parent_families):
            raise ValueError(
                "hybrid mechanism generation requires ancestry and de-novo parents"
            )

    @property
    def _hybrid_parent_ids(self) -> Tuple[str, ...]:
        return tuple(
            str(item["candidate"]["candidate_id"])
            for item in self.hybrid_parent_material
            if isinstance(item.get("candidate"), Mapping)
            and item["candidate"].get("candidate_id")
        )

    def _parent_material(
        self,
        archive: Sequence["IslandCandidateRecord"],
        *,
        family: Optional[str] = None,
    ) -> str:
        if family == "de_novo":
            prior_results = []
            for record in archive:
                if not isinstance(record.program, GeneratedPolicyModuleProgram):
                    continue
                evidence = record.discovery_evidence
                prior_results.append(
                    {
                        "candidate_id": record.program.candidate_id,
                        "first_principles_derivation_id": (
                            record.program.first_principles_derivation_id
                        ),
                        "mean_objective_improvement": evidence.mean_improvement,
                        "mean_improvement_ci_lower": evidence.mean_ci_lower,
                        "wins": evidence.wins,
                        "losses": evidence.losses,
                        "counterexample_signal": (
                            "revise the approximation or representation"
                            if evidence.mean_improvement <= 0.0
                            else "retain and stress-test the derivation"
                        ),
                    }
                )
            research_memory = []
            hypotheses_by_id = {}
            if self.artifact_store is not None:
                for _, value in self.artifact_store.iter_kind(
                    "causal_mechanism_hypothesis"
                ):
                    if (
                        self.campaign_stage_id is not None
                        and value.get("campaign_stage_id")
                        != self.campaign_stage_id
                    ):
                        continue
                    raw = value.get("hypothesis", {})
                    hypothesis_id = str(raw.get("hypothesis_id", ""))
                    if hypothesis_id:
                        hypotheses_by_id[hypothesis_id] = raw
                for _, value in self.artifact_store.iter_kind(
                    "de_novo_research_memory"
                ):
                    if (
                        self.campaign_stage_id is not None
                        and value.get("campaign_stage_id")
                        != self.campaign_stage_id
                    ):
                        continue
                    headroom = value.get("representation_headroom", {})
                    classification = value.get("classification", {})
                    hypothesis_id = str(value.get("hypothesis_id", ""))
                    raw = hypotheses_by_id.get(hypothesis_id, {})
                    derivation = raw.get("first_principles_derivation") or {}
                    research_memory.append(
                        {
                            "hypothesis_id": hypothesis_id,
                            "statement": raw.get("statement"),
                            "causal_mechanism": raw.get("causal_mechanism"),
                            "tractable_approximation": derivation.get(
                                "tractable_approximation"
                            ),
                            "approximation_gap": derivation.get(
                                "approximation_gap"
                            ),
                            "registered_alternative_approximations": (
                                derivation.get(
                                    "alternative_approximations", []
                                )
                            ),
                            "failure_kind": classification.get(
                                "failure_kind"
                            ),
                            "disposition": classification.get(
                                "disposition"
                            ),
                            "required_changes": classification.get(
                                "required_changes", []
                            ),
                            "preserve_theory": classification.get(
                                "preserve_theory"
                            ),
                            "development_headroom": headroom.get(
                                "development", {}
                            ),
                            "heldout_headroom": headroom.get(
                                "holdout", {}
                            ),
                            "heldout_authority_rule": headroom.get(
                                "holdout_rule_evidence", {}
                            ),
                            "parameter_sensitivity": headroom.get(
                                "parameter_sensitivity", {}
                            ),
                            "counterexample_examples": headroom.get(
                                "counterexample_examples", []
                            )[:6],
                        }
                    )
            research_memory = research_memory[-8:]
            return json.dumps(
                {
                    "first_principles_iteration": True,
                    "executable_parents": [],
                    "prior_objective_results": prior_results,
                    "counterexample_conditioned_research_memory": (
                        research_memory
                    ),
                    "instruction": (
                        "Use state-level failures as counterexamples to the "
                        "derivation. Apply the recorded disposition and required "
                        "changes. Preserve a theory only when preserve_theory is "
                        "true; otherwise replace its mediator and surrogate. "
                        "For a preserved theory, propose a structurally distinct "
                        "approximation rather than new coefficients. Do not mutate "
                        "prior executable code as a parent, and do not use the "
                        "target policy as a source of mechanism ideas."
                    ),
                },
                sort_keys=True,
                separators=(",", ":"),
            )
        if family == "cross_domain":
            return json.dumps(
                {
                    "independent_invention_lane": True,
                    "executable_parents_withheld": True,
                    "same_lane_candidate_ids_seen": [
                        record.program.candidate_id for record in archive
                    ],
                },
                sort_keys=True,
                separators=(",", ":"),
            )
        value = {
            "required_cross_island_parents": list(
                self.hybrid_parent_material
            ),
            "host_enforced_baseline_ref": self.baseline_policy_ref,
            "adaptive_same_lane_archive": json.loads(
                ExecutableCodeProposer._parent_material(archive)
            )
            if archive
            else [],
        }
        # Keep the required cross-island parents before adaptive same-lane
        # material so neither the model nor deterministic test compilers can
        # mistake a previous hybrid for one of its source components.
        return json.dumps(value, sort_keys=False, separators=(",", ":"))

    def _research_program_material(self, family: str) -> str:
        if family == "de_novo":
            representation = (
                None
                if self.research_program is None
                else self.research_program.representation
            )
            return json.dumps(
                {
                    "contract": "first-principles-objective-derivation-v1",
                    "domain_id": (
                        "online_one_dimensional_bin_packing"
                        if representation is None
                        else representation.domain_id
                    ),
                    "objective": (
                        "minimize the number of bins used by each complete episode"
                    ),
                    "objective_direction": "lower_is_better",
                    "decision_variables": [
                        "the feasible host selected for the current item",
                        "whether a new host is opened when no open host is selected",
                    ],
                    "observations": (
                        ["item", "loads", "item_index", "bounded_history"]
                        if representation is None
                        else list(representation.observation_schema)
                    ),
                    "legal_invariants": [
                        "one current item must be placed irrevocably",
                        "only a feasible open host or one new host may be selected",
                        "future arrivals and existing placements are unavailable",
                        "total packed load is conserved",
                    ],
                    "derivation_stages": [
                        "formalize the objective and constraints",
                        "derive an ideal rule without implementation limits",
                        "derive a legal tractable approximation",
                        "measure the approximation gap with a micro-oracle",
                        "search targeted counterexamples",
                        "revise the representation when the declared trigger fires",
                    ],
                    "admission_basis": [
                        "complete derivation",
                        "testable approximation-to-objective claim",
                        "exact or analytic micro-oracle",
                        (
                            "positive exact conditional advantage over the "
                            "declared executable fallback"
                        ),
                        "noninferior terminal outcome on the tiny oracle suite",
                    ],
                    "explicit_non_goals": [
                        "distance from an incumbent",
                        "novelty for its own sake",
                        "unusual decision topology",
                        "large intervention rate",
                    ],
                },
                sort_keys=True,
                separators=(",", ":"),
            )
        if self.research_program is None:
            return "No explicit research-program revision."
        if family != "cross_domain":
            return json.dumps(
                self.research_program.as_dict(),
                sort_keys=True,
                separators=(",", ":"),
            )
        representation = self.research_program.representation
        return json.dumps(
            {
                "contract": "independent-invention-problem-only-v1",
                "domain_id": representation.domain_id,
                "problem_goal": (
                    "reduce complete-episode bin count under held-out evaluation"
                ),
                "observation_schema": list(representation.observation_schema),
                "state_schema": list(representation.state_schema),
                "action_schema": list(representation.action_schema),
                "legal_invariants": [
                    "one current item must be placed irrevocably",
                    "only a feasible open host or one new host may be selected",
                    "future arrivals and existing placements are unavailable",
                ],
                "withheld_information": [
                    "reference-policy identity",
                    "reference-policy code",
                    "reference-policy behavior",
                    "reference-relative experimental findings",
                ],
            },
            sort_keys=True,
            separators=(",", ":"),
        )

    def _incumbent_exposure_audit(
        self,
        family: str,
        prompt: str,
    ) -> Optional[str]:
        if family != "cross_domain":
            return None
        forbidden_terms = (
            "funsearch",
            "best fit",
            "first fit",
            "worst fit",
            "next fit",
        )
        folded = prompt.casefold().replace("_", "-").replace("-", " ")
        matches = tuple(term for term in forbidden_terms if term in folded)
        report = {
            "schema": 1,
            "family": family,
            "policy": "independent_invention_prompt_exposure_v1",
            "prompt_digest": content_digest(prompt),
            "prompt_characters": len(prompt),
            "forbidden_terms": list(forbidden_terms),
            "forbidden_matches": list(matches),
            "passed": not matches,
        }
        audit_id = self._record("incumbent_exposure_audit", report)
        audit_id = audit_id or content_digest(report)
        if matches:
            raise ValueError(
                "independent invention prompt exposed target policies: %s"
                % ",".join(matches)
            )
        return audit_id

    def _first_principles_prompt_audit(
        self,
        family: str,
        prompt: str,
    ) -> Optional[str]:
        if family != "de_novo":
            return None
        required_terms = (
            "objective",
            "governing constraints",
            "ideal solution",
            "tractable approximation",
            "approximation gap",
            "micro-oracle",
            "counterexample",
            "revision trigger",
            "alternative approximations",
            "novelty",
        )
        folded = prompt.casefold().replace("_", " ").replace("-", " ")
        missing = tuple(
            term
            for term in required_terms
            if term.replace("-", " ") not in folded
        )
        report = {
            "schema": 1,
            "family": family,
            "policy": "first_principles_prompt_contract_v1",
            "prompt_digest": content_digest(prompt),
            "prompt_characters": len(prompt),
            "required_terms": list(required_terms),
            "missing_terms": list(missing),
            "passed": not missing,
        }
        audit_id = self._record("first_principles_prompt_audit", report)
        audit_id = audit_id or content_digest(report)
        if missing:
            raise ValueError(
                "de-novo prompt omitted first-principles stages: %s"
                % ",".join(missing)
            )
        return audit_id

    def _record(self, kind: str, value: Mapping[str, Any]) -> Optional[str]:
        if self.artifact_store is None:
            return None
        return self.artifact_store.put(
            kind,
            {
                "campaign_stage_id": self.campaign_stage_id,
                **dict(value),
            },
        )

    def _request_hypotheses(
        self,
        *,
        family: str,
        context: LiteratureHypothesisContext,
        count: int,
        archive: Sequence["IslandCandidateRecord"],
        reserved_fingerprint_ids: Sequence[str] = (),
    ) -> Tuple[CausalMechanismHypothesis, ...]:
        parent_material = self._parent_material(archive, family=family)
        # A separate cross-domain request already uses the cross-domain
        # literature as its primary source packet.  Exposing that packet to
        # ancestry or ordinary de-novo requests contaminates their lane and
        # makes the citation allowlist disagree with the prompt.
        cross_material = "No separate relational-transfer packet."
        base_prompt = mechanism_hypothesis_prompt(
            island_family=family,
            literature_context=context,
            experimental_findings=self.experimental_findings,
            count=count,
            parent_material=parent_material,
            cross_domain_material=cross_material,
            research_program_material=self._research_program_material(family),
        )
        if family == "cross_domain":
            base_prompt = base_prompt.replace(
                self.experimental_findings,
                "Withheld in the independent invention lane.",
            ) if self.experimental_findings else base_prompt
        exposure_audit_id = self._incumbent_exposure_audit(family, base_prompt)
        first_principles_audit_id = self._first_principles_prompt_audit(
            family,
            base_prompt,
        )
        if self._rejected_hypothesis_ids or self._rejected_fingerprint_ids:
            base_prompt += (
                "\n\nPERSISTENT REJECTION MEMORY (never repeat these "
                "contract identities):\n"
                + json.dumps(
                    {
                        "hypothesis_ids": sorted(
                            self._rejected_hypothesis_ids
                        ),
                        "fingerprint_ids": sorted(
                            self._rejected_fingerprint_ids
                        ),
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                )
            )
        accepted: List[CausalMechanismHypothesis] = []
        rejection_messages = []
        observed_hypotheses = {
            *self._attempted_hypothesis_ids,
            *self._rejected_hypothesis_ids,
        }
        observed_fingerprints = {
            *self._attempted_fingerprint_ids,
            *self._rejected_fingerprint_ids,
        }
        observed_fingerprints.update({
            record.program.mechanism_fingerprint.fingerprint_id
            for record in archive
            if isinstance(record.program, GeneratedPolicyModuleProgram)
        })
        observed_fingerprints.update(reserved_fingerprint_ids)
        cached = self._cached_hypotheses.pop(family, [])
        supplied_refs = set(context.source_work_ids)
        for hypothesis in cached:
            if len(accepted) >= count:
                break
            failures = _mechanism_contract_failures(hypothesis)
            claimed_refs = set(hypothesis.literature_refs)
            review = mechanism_review(hypothesis.as_tournament_hypothesis())
            if (
                failures
                or (
                    family != "de_novo"
                    and not claimed_refs.intersection(supplied_refs)
                )
                or not claimed_refs.issubset(supplied_refs)
                or hypothesis.hypothesis_id in observed_hypotheses
                or hypothesis.fingerprint.fingerprint_id in observed_fingerprints
                or review.goal_alignment < 3
                or review.testability < 3
                or (
                    family not in {"ancestry", "de_novo"}
                    and (review.novelty < 2 or review.diversity_value < 2)
                )
            ):
                continue
            observed_hypotheses.add(hypothesis.hypothesis_id)
            observed_fingerprints.add(hypothesis.fingerprint.fingerprint_id)
            self._attempted_hypothesis_ids.add(hypothesis.hypothesis_id)
            self._attempted_fingerprint_ids.add(
                hypothesis.fingerprint.fingerprint_id
            )
            if exposure_audit_id is not None:
                self._incumbent_exposure_audit_ids[
                    hypothesis.hypothesis_id
                ] = exposure_audit_id
            if first_principles_audit_id is not None:
                self._first_principles_audit_ids[
                    hypothesis.hypothesis_id
                ] = first_principles_audit_id
            accepted.append(hypothesis)
        request_prompt = base_prompt
        for attempt in range(8):
            remaining = count - len(accepted)
            if remaining == 0:
                break
            generated = self.backend.generate_mechanisms(
                request_prompt,
                remaining,
            )
            attempt_rejections = []
            for index, item in enumerate(generated):
                hypothesis: Optional[CausalMechanismHypothesis] = None
                try:
                    hypothesis = CausalMechanismHypothesis.from_model_dict(
                        item,
                        target_node_id=self.target_node_id,
                        island_family=family,
                        generator_ref=self.name,
                    )
                    failures = _mechanism_contract_failures(hypothesis)
                    if failures:
                        raise ValueError(",".join(failures))
                    supplied_refs = set(context.source_work_ids)
                    claimed_refs = set(hypothesis.literature_refs)
                    if (
                        family != "de_novo"
                        and not claimed_refs.intersection(supplied_refs)
                    ):
                        raise ValueError(
                            "causal hypothesis cites no supplied source work_id"
                        )
                    if not claimed_refs.issubset(supplied_refs):
                        raise ValueError(
                            "causal hypothesis contains an unknown source work_id"
                        )
                    if hypothesis.hypothesis_id in observed_hypotheses:
                        raise ValueError("duplicate causal hypothesis")
                    if (
                        hypothesis.fingerprint.fingerprint_id
                        in observed_fingerprints
                    ):
                        raise ValueError("duplicate executable mechanism fingerprint")
                    review = mechanism_review(
                        hypothesis.as_tournament_hypothesis()
                    )
                    if review.goal_alignment < 3 or review.testability < 3:
                        raise ValueError(
                            "causal hypothesis failed alignment or testability review"
                        )
                    if family not in {"ancestry", "de_novo"} and (
                        review.novelty < 2 or review.diversity_value < 2
                    ):
                        raise ValueError(
                            "non-ancestry hypothesis failed novelty allocation review"
                        )
                except (KeyError, TypeError, ValueError) as error:
                    message = "attempt-%d:item-%d:%s" % (
                        attempt + 1,
                        index,
                        error,
                    )
                    rejection_messages.append(message)
                    attempt_rejections.append(message)
                    hypothesis_id = (
                        "" if hypothesis is None else hypothesis.hypothesis_id
                    )
                    fingerprint_id = (
                        ""
                        if hypothesis is None
                        else hypothesis.fingerprint.fingerprint_id
                    )
                    if hypothesis_id:
                        self._rejected_hypothesis_ids.add(hypothesis_id)
                        observed_hypotheses.add(hypothesis_id)
                    if fingerprint_id:
                        self._rejected_fingerprint_ids.add(fingerprint_id)
                        observed_fingerprints.add(fingerprint_id)
                    self._record(
                        "causal_mechanism_hypothesis_rejection",
                        {
                            "family": family,
                            "attempt": attempt + 1,
                            "item_index": index,
                            "reason": str(error),
                            "hypothesis_id": hypothesis_id,
                            "fingerprint_id": fingerprint_id,
                            "raw_response": dict(item),
                        },
                    )
                    continue
                observed_hypotheses.add(hypothesis.hypothesis_id)
                observed_fingerprints.add(
                    hypothesis.fingerprint.fingerprint_id
                )
                self._attempted_hypothesis_ids.add(
                    hypothesis.hypothesis_id
                )
                self._attempted_fingerprint_ids.add(
                    hypothesis.fingerprint.fingerprint_id
                )
                if exposure_audit_id is not None:
                    self._incumbent_exposure_audit_ids[
                        hypothesis.hypothesis_id
                    ] = exposure_audit_id
                if first_principles_audit_id is not None:
                    self._first_principles_audit_ids[
                        hypothesis.hypothesis_id
                    ] = first_principles_audit_id
                self._record(
                    "causal_mechanism_hypothesis",
                    {
                        "hypothesis": hypothesis.as_dict(),
                        "review": review.as_dict(),
                        "admitted_for_compilation": True,
                    },
                )
                accepted.append(hypothesis)
            if attempt_rejections and len(accepted) < count:
                request_prompt = (
                    base_prompt
                    + "\n\nThe preceding causal contracts were rejected:\n- "
                    + "\n- ".join(attempt_rejections)
                    + (
                        "\nReturn corrected objective derivations; change the "
                        "ideal-to-approximation argument when a prior one failed."
                        if family == "de_novo"
                        else "\nReturn structurally distinct corrected contracts only."
                    )
                )
        if len(accepted) != count:
            raise RuntimeError(
                "mechanism proposer rejected %d contracts while filling %d slots: %s"
                % (
                    len(rejection_messages),
                    count,
                    "; ".join(rejection_messages),
                )
            )
        return tuple(accepted)

    def _literature_binding(
        self,
        hypothesis: CausalMechanismHypothesis,
        context: LiteratureHypothesisContext,
    ) -> str:
        value = {
            "hypothesis_id": hypothesis.hypothesis_id,
            "island_family": hypothesis.island_family,
            "base_assessment_id": context.assessment_id,
            "base_context_id": context.context_id,
            "claimed_literature_refs": list(hypothesis.literature_refs),
            "available_source_work_ids": list(context.source_work_ids),
            "binding_kind": "candidate-specific-prior-art-binding-v1",
        }
        digest = self._record("candidate_specific_literature_binding", value)
        return digest or content_digest(value)

    def _compile(
        self,
        hypotheses: Sequence[CausalMechanismHypothesis],
        contexts: Mapping[str, LiteratureHypothesisContext],
        archive: Sequence["IslandCandidateRecord"],
    ) -> Tuple[Proposal, ...]:
        compile_family = (
            hypotheses[0].island_family if hypotheses else self.island_family
        )
        parent_material = self._parent_material(
            archive,
            family=compile_family,
        )
        archive_parent_ids = tuple(
            record.program.candidate_id
            for record in sorted(
                archive,
                key=lambda record: record.rank,
                reverse=True,
            )[:4]
        )
        remaining = list(hypotheses)
        proposals: List[Proposal] = []
        rejection_messages = []
        compile_feedback = ""
        for attempt in range(3):
            if not remaining:
                break
            prompt = mechanism_compiler_prompt(
                remaining,
                contexts,
                parent_material=parent_material,
                research_program_material=self._research_program_material(
                    compile_family
                ),
            ) + compile_feedback
            compiler_exposure_audit_id = self._incumbent_exposure_audit(
                compile_family,
                prompt,
            )
            compiler_first_principles_audit_id = (
                self._first_principles_prompt_audit(
                    compile_family,
                    prompt,
                )
            )
            prompt_digest = content_digest(prompt)
            generated = self.backend.compile_mechanisms(
                prompt,
                len(remaining),
            )
            expected = {
                hypothesis.hypothesis_id: hypothesis
                for hypothesis in remaining
            }
            accepted_ids = set()
            attempt_rejections = []
            for index, item in enumerate(generated):
                supplied_id = str(item.get("hypothesis_id", ""))
                hypothesis = expected.get(supplied_id)
                try:
                    if hypothesis is None:
                        raise ValueError("compiler returned an unknown hypothesis_id")
                    if supplied_id in accepted_ids:
                        raise ValueError("compiler duplicated a hypothesis_id")
                    fixed_parent_ids = (
                        self._hybrid_parent_ids
                        if hypothesis.island_family == "hybrid"
                        else (
                            (str(self.baseline_policy_ref),)
                            if hypothesis.island_family == "ancestry"
                            else ()
                        )
                    )
                    parent_ids = (
                        ()
                        if hypothesis.island_family in {
                            "de_novo",
                            "cross_domain",
                        }
                        else tuple(
                            dict.fromkeys(
                                (*fixed_parent_ids, *archive_parent_ids)
                            )
                        )
                    )
                    derivation = (
                        hypothesis.first_principles_derivation
                        if hypothesis.island_family == "de_novo"
                        else None
                    )
                    first_principles_audit_id = (
                        None
                        if compiler_first_principles_audit_id is None
                        else (
                            self._record(
                                "first_principles_candidate_binding",
                                {
                                    "hypothesis_id": hypothesis.hypothesis_id,
                                    "generation_audit_id": (
                                        self._first_principles_audit_ids.get(
                                            hypothesis.hypothesis_id
                                        )
                                    ),
                                    "compiler_audit_id": (
                                        compiler_first_principles_audit_id
                                    ),
                                    "derivation_id": (
                                        None
                                        if derivation is None
                                        else derivation.derivation_id
                                    ),
                                    "passed": bool(derivation),
                                },
                            )
                            or content_digest(
                                {
                                    "hypothesis_id": hypothesis.hypothesis_id,
                                    "generation_audit_id": (
                                        self._first_principles_audit_ids.get(
                                            hypothesis.hypothesis_id
                                        )
                                    ),
                                    "compiler_audit_id": (
                                        compiler_first_principles_audit_id
                                    ),
                                    "derivation_id": (
                                        None
                                        if derivation is None
                                        else derivation.derivation_id
                                    ),
                                    "passed": bool(derivation),
                                }
                            )
                        )
                    )
                    program = GeneratedPolicyModuleProgram(
                        source=str(item["source"]),
                        model_ref=self.backend.model_ref,
                        prompt_digest=prompt_digest,
                        hypothesis_id=hypothesis.hypothesis_id,
                        mechanism_fingerprint=hypothesis.fingerprint,
                        candidate_literature_assessment_id=(
                            self._literature_binding(
                                hypothesis,
                                contexts[hypothesis.hypothesis_id],
                            )
                        ),
                        distinguishing_prediction=(
                            hypothesis.distinguishing_prediction
                        ),
                        information_ablation=hypothesis.information_ablation,
                        mechanism_ablation=hypothesis.mechanism_ablation,
                        rationale=str(item.get("rationale", "")),
                        inspiration_refs=tuple(
                            str(value)
                            for value in item.get("inspiration_refs", ())
                        ),
                        island_family=hypothesis.island_family,
                        parent_candidate_ids=parent_ids,
                        baseline_policy_ref=(
                            str(self.baseline_policy_ref)
                            if hypothesis.island_family == "ancestry"
                            else None
                        ),
                        incumbent_exposure_audit_id=(
                            None
                            if compiler_exposure_audit_id is None
                            else content_digest(
                                {
                                    "generation_audit_id": (
                                        self._incumbent_exposure_audit_ids.get(
                                            hypothesis.hypothesis_id
                                        )
                                    ),
                                    "compiler_audit_id": (
                                        compiler_exposure_audit_id
                                    ),
                                }
                            )
                        ),
                        first_principles_derivation_id=(
                            None
                            if derivation is None
                            else derivation.derivation_id
                        ),
                        first_principles_audit_id=(
                            first_principles_audit_id
                        ),
                        representation_contract_id=(
                            "legacy-untyped-module-representation"
                            if self.research_program is None
                            else self.research_program.representation.representation_id
                        ),
                        calibration_parameters=tuple(
                            PolicyCalibrationParameter.from_dict(value)
                            for value in item.get(
                                "calibration_parameters", ()
                            )
                        ),
                    )
                    if hypothesis.island_family == "de_novo" and not all(
                        (
                            program.first_principles_derivation_id,
                            program.first_principles_audit_id,
                        )
                    ):
                        raise ValueError(
                            "compiled de-novo policy lost first-principles provenance"
                        )
                    if self.research_program is not None:
                        compliance = assess_compiled_representation(
                            program.source,
                            program.mechanism_fingerprint,
                            self.research_program.representation,
                        )
                        self._record(
                            "candidate_representation_compliance",
                            {
                                "program_id": self.research_program.program_id,
                                "candidate_id": program.candidate_id,
                                "assessment": compliance.as_dict(),
                            },
                        )
                        if not compliance.passed:
                            raise ValueError(
                                "compiled candidate violates representation contract: %s"
                                % ",".join(compliance.failure_reasons)
                            )
                except (KeyError, TypeError, ValueError) as error:
                    message = "attempt-%d:item-%d:%s" % (
                        attempt + 1,
                        index,
                        error,
                    )
                    rejection_messages.append(message)
                    attempt_rejections.append(message)
                    continue
                accepted_ids.add(supplied_id)
                operator = (
                    "cross_domain_mechanism_compilation"
                    if hypothesis.island_family == "cross_domain"
                    else "%s_mechanism_compilation" % self.island_family
                )
                proposal = Proposal(
                    program=program,
                    parent_ids=program.parent_candidate_ids,
                    operator=operator,
                )
                self._record(
                    "compiled_mechanism_candidate",
                    {
                        "hypothesis_id": hypothesis.hypothesis_id,
                        "candidate": program.as_dict(),
                        "parent_ids": list(program.parent_candidate_ids),
                        "operator": operator,
                    },
                )
                proposals.append(proposal)
            remaining = [
                hypothesis
                for hypothesis in remaining
                if hypothesis.hypothesis_id not in accepted_ids
            ]
            if attempt_rejections and remaining:
                compile_feedback = (
                    "\n\nThe preceding compiled modules were rejected by the "
                    "identity or static sandbox contract:\n- "
                    + "\n- ".join(attempt_rejections)
                    + "\nReturn corrected modules for the remaining hypothesis "
                    "identities only. Rewrite rejected source from scratch; do "
                    "not elaborate or patch the oversized version. For every "
                    "static-size or nested-loop rejection, use no more than one "
                    "history loop in build_state and one loads loop in "
                    "choose_action, keep the source below 1,800 characters and "
                    "roughly 45 nonblank lines, and compute a smaller faithful "
                    "surrogate of the same registered mechanism. Preserve the "
                    "hypothesis_id, causal decision topology, fallback, and all "
                    "required calibration parameter state reads."
                )
        if remaining and not proposals:
            raise RuntimeError(
                "mechanism compiler produced no valid policies for %d hypotheses: %s"
                % (
                    len(remaining),
                    "; ".join(rejection_messages),
                )
            )
        if remaining:
            self._record(
                "mechanism_compilation_shortfall",
                {
                    "requested_count": len(hypotheses),
                    "accepted_count": len(proposals),
                    "remaining_hypothesis_ids": [
                        hypothesis.hypothesis_id for hypothesis in remaining
                    ],
                    "rejections": list(rejection_messages),
                    "disposition": (
                        "retain_valid_modules_and_replenish_via_next_batch"
                    ),
                },
            )
        return tuple(proposals)

    def _generate(
        self,
        config: IslandSearchConfig,
        archive: Sequence["IslandCandidateRecord"],
        count: int,
    ) -> Tuple[Proposal, ...]:
        del config
        requests: List[Tuple[str, LiteratureHypothesisContext, int]] = []
        cross_count = 0
        cross_domain_in_archive = any(
            isinstance(record.program, GeneratedPolicyModuleProgram)
            and record.program.island_family == "cross_domain"
            for record in archive
        )
        if (
            self.island_family == "de_novo"
            and self.cross_domain_context is not None
            and not self._resumed_cross_domain
            and not cross_domain_in_archive
        ):
            cross_count = min(count, max(1, count // 3))
        main_count = count - cross_count
        if main_count:
            requests.append(
                (self.island_family, self.literature_context, main_count)
            )
        if cross_count:
            requests.append(
                ("cross_domain", self.cross_domain_context, cross_count)
            )
        proposals: List[Proposal] = []
        reserved_fingerprints = set()
        for family, context, family_count in requests:
            generated = self._request_hypotheses(
                family=family,
                context=context,
                count=family_count,
                archive=archive,
                reserved_fingerprint_ids=tuple(reserved_fingerprints),
            )
            reserved_fingerprints.update(
                hypothesis.fingerprint.fingerprint_id
                for hypothesis in generated
            )
            family_contexts = {
                hypothesis.hypothesis_id: context for hypothesis in generated
            }
            # Compile each lane under its own execution, provenance, and prompt
            # audit contract.  Combining de-novo and transfer hypotheses in one
            # call previously let whichever family came first define both.
            proposals.extend(
                self._compile(generated, family_contexts, archive)
            )
        return tuple(proposals)

    def seeds(
        self,
        config: IslandSearchConfig,
        rng: random.Random,
    ) -> Iterable[Proposal]:
        del rng
        count = min(
            config.evaluation_budget,
            max(1, config.initial_random),
        )
        if self.sequential_de_novo_learning:
            # Evaluate one theory before proposing the next so state-level
            # rejection evidence can condition invention immediately.
            count = 1
        return self._generate(config, (), count)

    def propose(
        self,
        config: IslandSearchConfig,
        archive: Sequence["IslandCandidateRecord"],
        rng: random.Random,
    ) -> Proposal:
        del rng
        if not self._pending:
            count = 1 if self.sequential_de_novo_learning else self.batch_size
            self._pending.extend(
                self._generate(config, archive, count)
            )
        return self._pending.pop(0)


def _mechanism_distance_assessment(
    program: SearchProgram,
    config: IslandSearchConfig,
) -> MechanismDistanceAssessment:
    if isinstance(program, GeneratedPolicyModuleProgram):
        canonical = program.canonical_mechanism
        topology = "canonical:%s" % canonical.signature_id
        incumbent_blind = bool(program.incumbent_exposure_audit_id)
        primitives_list = []
        if "history" in canonical.data_channels:
            primitives_list.append("history_conditioned_state")
        if canonical.maximum_control_depth >= 2:
            primitives_list.append("multi_stage_control_flow")
        if canonical.loop_bucket in {"2", "3_plus"}:
            primitives_list.append("multi_pass_action_set_transformation")
        if "abstain" in canonical.return_modes:
            primitives_list.append("host_backed_abstention")
        primitives = tuple(primitives_list)
        distance = min(4, len(primitives))
    elif isinstance(program, GeneratedPolicyProgram):
        topology = "greedy_scalar_action_score"
        incumbent_blind = True
        primitives = ()
        distance = 1
    elif isinstance(program, MoonshotProgram):
        topology = program.decision_topology
        incumbent_blind = True
        primitives = program.new_decision_primitives
        distance = 4
    elif isinstance(program, MoonshotHybridProgram):
        topology = "sparse_moonshot_override"
        incumbent_blind = False
        primitives = (
            "failure_syndrome_gate",
            *program.moonshot.new_decision_primitives,
        )
        distance = 3
    elif isinstance(program, StructuralHybridProgram):
        topology = "typed_structural_override"
        incumbent_blind = False
        primitives = (
            "state_conditioned_structural_override",
            *program.moonshot.new_decision_primitives,
        )
        distance = 3
    elif isinstance(program, CalibratedOverrideHybridProgram):
        topology = "trajectory_credit_episode_transport_override"
        incumbent_blind = False
        primitives = program.new_decision_primitives
        distance = 4
    elif isinstance(program, CalibratedOverrideActionProgram):
        topology = "learned_counterfactual_action_ranker"
        incumbent_blind = False
        primitives = ("strict_pairwise_advantage_supervision",)
        distance = 3
    elif isinstance(program, RegimeRouterProgram):
        topology = "complete_policy_router"
        incumbent_blind = program.mode == "de_novo"
        primitives = ("state_conditioned_policy_selection",)
        distance = 2
    elif isinstance(program, HybridPolicyProgram):
        topology = "incumbent_policy_router"
        incumbent_blind = False
        primitives = ("state_conditioned_policy_selection",)
        distance = 2
    elif isinstance(program, (ContextualLinearProgram, DemandMemoryProgram)):
        topology = "greedy_scalar_action_score"
        incumbent_blind = program.mode == "de_novo"
        primitives = ()
        distance = 1 if incumbent_blind else 0
    elif isinstance(program, PriorityProgram):
        topology = "greedy_scalar_action_score"
        incumbent_blind = True
        primitives = ()
        distance = 1
    else:
        topology = "incumbent_scalar_score_perturbation"
        incumbent_blind = False
        primitives = ()
        distance = 0
    minimum_distance = config.minimum_mechanism_distance
    require_new_primitive = config.require_new_decision_primitive
    if (
        isinstance(program, GeneratedPolicyModuleProgram)
        and program.island_family == "de_novo"
    ):
        # Structural novelty is telemetry in a first-principles lane, never an
        # admission requirement.
        minimum_distance = 0
        require_new_primitive = False
    elif (
        isinstance(program, GeneratedPolicyModuleProgram)
        and program.island_family == "cross_domain"
    ):
        minimum_distance = max(2, minimum_distance)
        require_new_primitive = True
    return MechanismDistanceAssessment(
        candidate_id=program.candidate_id,
        candidate_topology=topology,
        incumbent_topology="greedy_scalar_action_score",
        incumbent_blind=incumbent_blind,
        new_decision_primitives=tuple(primitives),
        structural_distance=distance,
        minimum_structural_distance=(
            minimum_distance
        ),
        require_incumbent_blind=config.require_incumbent_blind,
        require_new_decision_primitive=(
            require_new_primitive
        ),
        assessor_ref="program-structure-mechanism-distance-v1",
    )


def _hybrid_parent_contribution_diagnostic(
    candidate: OnlineHeuristic,
    parents: Sequence[OnlineHeuristic],
    instances: Sequence[BinPackingInstance],
) -> Mapping[str, Any]:
    """Verify that a compiled hybrid follows each parent on a distinct slice."""

    if len(parents) < 2:
        report = {
            "schema": 1,
            "candidate_id": getattr(candidate, "candidate_id", candidate.name),
            "parent_ids": [
                getattr(parent, "candidate_id", parent.name)
                for parent in parents
            ],
            "parent_disagreement_decisions": 0,
            "parent_contribution_decisions": [0, 0],
            "passed": False,
            "failure_reasons": ["hybrid_requires_two_executable_parents"],
        }
        return {**report, "assessment_id": content_digest(report)}
    first, second = parents[:2]
    parent_disagreements = 0
    contributions = [0, 0]
    decisions = 0
    for instance in instances:
        loads: List[int] = []
        history: List[int] = []
        for item_index, item in enumerate(instance.items):
            state_loads = tuple(loads)
            state_history = tuple(history)
            candidate_action = candidate.choose_bin(
                item,
                state_loads,
                instance.capacity,
                item_index,
                state_history,
            )
            parent_actions = (
                first.choose_bin(
                    item,
                    state_loads,
                    instance.capacity,
                    item_index,
                    state_history,
                ),
                second.choose_bin(
                    item,
                    state_loads,
                    instance.capacity,
                    item_index,
                    state_history,
                ),
            )
            decisions += 1
            if parent_actions[0] != parent_actions[1]:
                parent_disagreements += 1
                if candidate_action == parent_actions[0]:
                    contributions[0] += 1
                if candidate_action == parent_actions[1]:
                    contributions[1] += 1
            if candidate_action is None:
                loads.append(item)
            else:
                if (
                    candidate_action < 0
                    or candidate_action >= len(loads)
                    or loads[candidate_action] + item > instance.capacity
                ):
                    raise ValueError(
                        "compiled hybrid selected an invalid diagnostic action"
                    )
                loads[candidate_action] += item
            history.append(item)
    failures = []
    if parent_disagreements == 0:
        failures.append("hybrid_parents_never_disagree_on_diagnostic_states")
    if contributions[0] == 0:
        failures.append("hybrid_never_uses_ancestry_parent_action")
    if contributions[1] == 0:
        failures.append("hybrid_never_uses_de_novo_parent_action")
    report = {
        "schema": 1,
        "candidate_id": getattr(candidate, "candidate_id", candidate.name),
        "parent_ids": [
            getattr(first, "candidate_id", first.name),
            getattr(second, "candidate_id", second.name),
        ],
        "decision_count": decisions,
        "parent_disagreement_decisions": parent_disagreements,
        "parent_contribution_decisions": contributions,
        "passed": not failures,
        "failure_reasons": failures,
        "claim_authority": "diagnostic_only_not_episode_performance",
    }
    return {**report, "assessment_id": content_digest(report)}


def _within_exploration_risk_budget(
    report: PairedPolicyReport,
    config: IslandSearchConfig,
) -> bool:
    return (
        report.mean_delta
        <= config.exploration_mean_regression_ceiling
        and (
            report.losses / float(len(report.deltas))
            <= config.exploration_regression_fraction_ceiling
        )
        and (
            report.maximum_regression
            <= config.exploration_max_regression
        )
    )


def _discovery_assessment(
    program: SearchProgram,
    config: IslandSearchConfig,
    repair_report: PairedPolicyReport,
    guard_report: PairedPolicyReport,
    behavior_distance: float,
    intervention_rate: float,
) -> RiskBudgetedDiscoveryAssessment:
    repair_count = float(len(repair_report.deltas))
    upside_rate = repair_report.wins / repair_count
    maximum_regression = max(0.0, guard_report.maximum_regression)
    risk_limit = float(config.exploration_max_regression)
    risk_utilization = min(1.0, maximum_regression / risk_limit)
    catastrophic_excess = max(
        0.0,
        maximum_regression - risk_limit,
    ) / risk_limit
    return RiskBudgetedDiscoveryAssessment(
        mechanism_distance=_mechanism_distance_assessment(
            program,
            config,
        ),
        behavior_distance=behavior_distance,
        intervention_rate=intervention_rate,
        upside_rate=upside_rate,
        risk_utilization=risk_utilization,
        catastrophic_excess=catastrophic_excess,
        within_risk_budget=_within_exploration_risk_budget(
            guard_report,
            config,
        ),
        scorer_ref="bounded-epistemic-risk-discovery-score-v1",
    )


@dataclass(frozen=True)
class IslandCandidateRecord:
    island: IslandName
    program: SearchProgram
    parent_ids: Tuple[str, ...]
    operator: str
    evaluation_index: int
    repair_report: PairedPolicyReport
    guard_report: PairedPolicyReport
    behavior_fingerprint: str
    discovery_assessment: RiskBudgetedDiscoveryAssessment
    semantic_novelty: Mapping[str, Any]
    mechanism_gate_decision: Mapping[str, Any]
    distinguishing_diagnostic: Mapping[str, Any]
    eligible: bool
    deployment_safe: bool
    exploration_lane: bool
    episode_confidence_discovery: bool
    archive_cell: ArchiveCell
    artifact_digest: Optional[str] = None

    @property
    def discovery_evidence(self):
        return paired_episode_evidence(
            (-float(delta) for delta in self.guard_report.deltas),
            self.guard_report.instance_ids,
        )

    @property
    def truth_rank(self) -> Tuple[float, ...]:
        if not self.episode_confidence_discovery:
            return (
                float(self.eligible),
                -self.repair_report.mean_delta,
                float(self.repair_report.wins),
                -self.guard_report.mean_delta,
                -float(self.guard_report.losses),
                -float(self.program.complexity),
            )
        return (
            float(self.eligible),
            self.discovery_evidence.mean_ci_lower,
            self.discovery_evidence.mean_improvement,
            self.discovery_evidence.aggregate_improvement,
            -float(self.program.complexity),
        )

    @property
    def discovery_rank(self) -> Tuple[float, ...]:
        if (
            isinstance(self.program, GeneratedPolicyModuleProgram)
            and self.program.island_family == "de_novo"
        ):
            # De-novo allocation follows objective evidence.  Novelty,
            # structural distance, behavior distance, and intervention volume
            # remain reportable diagnostics but cannot outrank performance.
            return (
                float(self.discovery_admitted),
                self.discovery_evidence.mean_ci_lower,
                self.discovery_evidence.mean_improvement,
                self.discovery_evidence.aggregate_improvement,
                self.discovery_assessment.upside_rate,
                float(self.distinguishing_diagnostic["passed"]),
                -self.discovery_assessment.risk_utilization,
                -float(self.program.complexity),
            )
        return (
            float(self.semantic_novelty["passed"]),
            float(self.distinguishing_diagnostic["passed"]),
            float(
                self.discovery_assessment.admitted_for_exploration
            ),
            self.discovery_assessment.discovery_score,
            float(
                self.discovery_assessment
                .mechanism_distance.structural_distance
            ),
            self.discovery_assessment.behavior_distance,
            self.discovery_assessment.intervention_rate,
            *self.truth_rank[1:],
        )

    @property
    def discovery_admitted(self) -> bool:
        admitted = self.discovery_assessment.admitted_for_exploration
        if (
            isinstance(self.program, GeneratedPolicyModuleProgram)
            and self.program.island_family == "de_novo"
        ):
            return (
                admitted
                and bool(self.mechanism_gate_decision["passed"])
                and bool(self.distinguishing_diagnostic["passed"])
                and self.discovery_evidence.mean_improvement > 0.0
            )
        return admitted

    @property
    def rank(self) -> Tuple[float, ...]:
        return (
            self.discovery_rank
            if self.exploration_lane
            else self.truth_rank
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "island": self.island,
            "candidate": self.program.as_dict(),
            "parent_ids": list(self.parent_ids),
            "operator": self.operator,
            "evaluation_index": self.evaluation_index,
            "repair_report": self.repair_report.as_dict(),
            "guard_report": self.guard_report.as_dict(),
            "behavior_fingerprint": self.behavior_fingerprint,
            "discovery_assessment": (
                self.discovery_assessment.as_dict()
            ),
            "semantic_novelty": dict(self.semantic_novelty),
            "mechanism_gate_decision": dict(
                self.mechanism_gate_decision
            ),
            "distinguishing_diagnostic": dict(
                self.distinguishing_diagnostic
            ),
            "discovery_score": (
                self.discovery_assessment.discovery_score
            ),
            "discovery_admitted": (
                self.discovery_admitted
            ),
            "research_eligible": self.eligible,
            "discovery_performance": self.discovery_evidence.as_dict(),
            "eligible": self.eligible,
            "deployment_safe": self.deployment_safe,
            "exploration_lane": self.exploration_lane,
            "episode_confidence_discovery": (
                self.episode_confidence_discovery
            ),
            "archive_cell": list(self.archive_cell),
            "truth_rank": list(self.truth_rank),
            "discovery_rank": list(self.discovery_rank),
            "rank": list(self.rank),
            "artifact_digest": self.artifact_digest,
        }


@dataclass(frozen=True)
class IslandSearchOutcome:
    config: IslandSearchConfig
    proposer_name: str
    incumbent_name: str
    best: IslandCandidateRecord
    evaluated: Tuple[IslandCandidateRecord, ...]
    archive: Tuple[IslandCandidateRecord, ...]
    duplicate_attempts: int
    literature_context_id: Optional[str] = None
    literature_evidence_ids: Tuple[str, ...] = ()

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "search_version": ISLAND_SEARCH_VERSION,
            "config": self.config.as_dict(),
            "proposer": self.proposer_name,
            "incumbent_name": self.incumbent_name,
            "best_candidate_id": self.best.program.candidate_id,
            "evaluated_count": len(self.evaluated),
            "archive_size": len(self.archive),
            "duplicate_attempts": self.duplicate_attempts,
            "literature_context_id": self.literature_context_id,
            "literature_evidence_ids": list(
                self.literature_evidence_ids
            ),
            "best": self.best.as_dict(),
            "evaluated": [record.as_dict() for record in self.evaluated],
            "archive": [record.as_dict() for record in self.archive],
        }


def _research_eligible(
    report: PairedPolicyReport,
    config: IslandSearchConfig,
) -> bool:
    if not config.episode_confidence_discovery:
        return (
            report.mean_delta
            <= config.research_guard_mean_delta_ceiling
            and (
                report.losses / float(len(report.deltas))
                <= config.research_guard_regression_fraction_ceiling
            )
            and report.maximum_regression
            <= config.research_guard_max_regression
        )
    # In the reset architecture, discovery is intentionally independent of
    # deployment limits. The legacy branch above remains only for archived
    # study reproduction.
    evidence = paired_episode_evidence(
        (-float(delta) for delta in report.deltas),
        report.instance_ids,
    )
    return (
        evidence.aggregate_improvement > 0.0
        and evidence.mean_ci_lower > 0.0
    )


def _deployment_safe(
    report: PairedPolicyReport,
    config: IslandSearchConfig,
) -> bool:
    return (
        report.mean_delta <= config.guard_mean_delta_ceiling
        and (
            report.losses / float(len(report.deltas))
            <= config.guard_regression_fraction_ceiling
        )
        and report.maximum_regression <= config.guard_max_regression
    )


def _cell(record: IslandCandidateRecord) -> ArchiveCell:
    repair_rate = record.repair_report.wins / float(
        len(record.repair_report.deltas)
    )
    regression_rate = record.guard_report.losses / float(
        len(record.guard_report.deltas)
    )
    complexity = record.program.complexity
    topology = (
        record.discovery_assessment
        .mechanism_distance.candidate_topology
    )
    topology_bucket = int(content_digest(topology)[:2], 16) % 8
    return (
        min(4, int(repair_rate * 5)),
        min(4, int(regression_rate * 5)),
        0 if complexity <= 3 else 1 if complexity <= 9 else 2,
        topology_bucket,
    )


def run_island_search(
    config: IslandSearchConfig,
    repair_instances: Iterable[BinPackingInstance],
    guard_instances: Iterable[BinPackingInstance],
    incumbent: OnlineHeuristic,
    *,
    carried_programs: Sequence[SearchProgram] = (),
    proposer: Optional[ProposalEngine] = None,
    literature_context: Optional[
        LiteratureHypothesisContext
    ] = None,
    artifact_store: Optional[ArtifactStore] = None,
    resumed_proposals: Sequence[Proposal] = (),
    campaign_stage_id: Optional[str] = None,
) -> IslandSearchOutcome:
    repair = tuple(repair_instances)
    guard = tuple(guard_instances)
    if not repair or not guard:
        raise ValueError("repair and guard suites must both be non-empty")
    proposer = proposer or StructuredEvolutionProposer(
        literature_context
    )
    proposer_context_id = getattr(
        proposer,
        "literature_context_id",
        None,
    )
    if (
        literature_context is not None
        and proposer_context_id != literature_context.context_id
    ):
        raise ValueError(
            "proposal engine is not bound to the supplied literature context"
        )
    rng = random.Random(config.seed)
    repair_incumbent_results = {
        instance.instance_id: pack(instance, incumbent)
        for instance in repair
    }
    guard_incumbent_results = {
        instance.instance_id: pack(instance, incumbent)
        for instance in guard
    }
    repair_incumbent_bins = {
        instance_id: result.bin_count
        for instance_id, result in repair_incumbent_results.items()
    }
    guard_incumbent_bins = {
        instance_id: result.bin_count
        for instance_id, result in guard_incumbent_results.items()
    }
    incumbent_placements = {
        instance_id: tuple(
            placement.bin_index for placement in result.placements
        )
        for instance_id, result in (
            *repair_incumbent_results.items(),
            *guard_incumbent_results.items(),
        )
    }
    evaluated: List[IslandCandidateRecord] = []
    archive: Dict[ArchiveCell, IslandCandidateRecord] = {}
    seen = set()
    seen_behaviors = set()
    duplicate_attempts = 0
    attempted_mechanism_clusters: Dict[str, int] = {}
    rollout_teacher_cache = None
    counterexample_atlas_cache = None

    def _evaluate_candidate(proposal: Proposal) -> bool:
        nonlocal rollout_teacher_cache, counterexample_atlas_cache
        program = proposal.program
        objective_calibration = None
        if (
            isinstance(program, GeneratedPolicyModuleProgram)
            and program.island_family == "de_novo"
            and program.calibration_parameters
        ):
            if rollout_teacher_cache is None:
                rollout_teacher_cache = build_rollout_teacher(
                    RolloutTeacherConfig(
                        capacity=repair[0].capacity,
                        item_low=max(1, int(round(repair[0].capacity * 2 / 15))),
                        item_high=max(
                            1, int(round(repair[0].capacity * 2 / 3))
                        ),
                        base_seed=config.seed + 8_900_000,
                    )
                )
                if artifact_store is not None:
                    artifact_store.put(
                        "de_novo_rollout_teacher",
                        rollout_teacher_cache.as_dict(),
                    )
            calibration = calibrate_de_novo_program(
                program,
                incumbent,
                rollout_teacher_cache.probes,
                config=DeNovoCalibrationConfig(
                    capacity=repair[0].capacity,
                    base_seed=config.seed + 9_100_000,
                ),
            )
            objective_calibration = calibration.as_dict()
            if artifact_store is not None:
                artifact_store.put(
                    "de_novo_objective_calibration",
                    objective_calibration,
                )
            program = calibration.selected_program
            proposal = Proposal(
                program=program,
                parent_ids=proposal.parent_ids,
                operator=proposal.operator + "_objective_calibrated",
            )
        if program.candidate_id in seen:
            return False
        seen.add(program.candidate_id)
        canonical = getattr(program, "canonical_mechanism", None)
        cluster_id = (
            canonical.signature_id if canonical is not None else None
        )
        if cluster_id is not None:
            observed = attempted_mechanism_clusters.get(cluster_id, 0)
            if (
                config.max_candidates_per_mechanism_cluster
                and observed >= config.max_candidates_per_mechanism_cluster
            ):
                if artifact_store is not None:
                    artifact_store.put(
                        "three_island_canonical_cluster_rejection",
                        {
                            "campaign_stage_id": campaign_stage_id,
                            "island": config.island,
                            "candidate": program.as_dict(),
                            "canonical_mechanism": canonical.as_dict(),
                            "cluster_attempt_count": observed,
                            "cluster_cap": (
                                config.max_candidates_per_mechanism_cluster
                            ),
                            "episode_screen_executed": False,
                        },
                    )
                return False
            attempted_mechanism_clusters[cluster_id] = observed + 1
        traces = behaviour_trace(program, (*repair, *guard))
        fingerprint = content_digest(
            {
                "schema": BEHAVIOUR_FINGERPRINT_SCHEMA,
                "traces": traces,
            }
        )
        if fingerprint in seen_behaviors:
            return False
        seen_behaviors.add(fingerprint)
        diagnostic_suite = (*repair[:6], *guard[:6])
        semantic_novelty = assess_semantic_novelty(
            program,
            diagnostic_suite,
            capacity=diagnostic_suite[0].capacity,
            minimum_known_control_action_distance=(
                config.minimum_known_control_action_distance
            ),
        )
        first_principles_objective_gate = None
        de_novo_representation_headroom = None
        de_novo_classification = None
        if (
            isinstance(program, GeneratedPolicyModuleProgram)
            and program.island_family == "de_novo"
        ):
            if counterexample_atlas_cache is None:
                counterexample_atlas_cache = build_counterexample_atlas(
                    CounterexampleAtlasConfig(
                        capacity=diagnostic_suite[0].capacity,
                    )
                )
                if artifact_store is not None:
                    artifact_store.put(
                        "de_novo_counterexample_atlas",
                        counterexample_atlas_cache.as_dict(),
                    )
            de_novo_representation_headroom = (
                assess_representation_headroom(
                    program,
                    counterexample_atlas_cache,
                )
            )
            if artifact_store is not None:
                artifact_store.put(
                    "de_novo_representation_headroom",
                    de_novo_representation_headroom,
                )
            first_principles_objective_gate = (
                assess_first_principles_objective_gate(
                    program,
                    capacity=diagnostic_suite[0].capacity,
                )
            )
            de_novo_classification = classify_de_novo_evidence(
                de_novo_representation_headroom,
                calibration=objective_calibration,
                objective_oracle=first_principles_objective_gate,
            )
        mechanism_gate_decision = _mechanism_gate_decision(
            semantic_novelty,
            config,
            candidate_family=(
                program.island_family
                if isinstance(program, GeneratedPolicyModuleProgram)
                else None
            ),
            first_principles_objective_gate=(
                first_principles_objective_gate
            ),
            de_novo_objective_calibration=objective_calibration,
            de_novo_representation_headroom=(
                de_novo_representation_headroom
            ),
        )
        distinguishing_diagnostic = assess_distinguishing_mechanism(
            program,
            diagnostic_suite,
        )
        baseline_authority = assess_host_baseline_authority(
            program,
            incumbent,
            diagnostic_suite,
        )
        if baseline_authority["applicable"]:
            distinguishing_failures = tuple(
                distinguishing_diagnostic.get("failure_reasons", ())
            )
            distinguishing_diagnostic = {
                **distinguishing_diagnostic,
                "baseline_authority": baseline_authority,
                "passed": bool(distinguishing_diagnostic["passed"])
                and bool(baseline_authority["passed"]),
                "failure_reasons": list(
                    dict.fromkeys(
                        (
                            *distinguishing_failures,
                            *baseline_authority["failure_reasons"],
                        )
                    )
                ),
            }
            distinguishing_diagnostic = {
                **distinguishing_diagnostic,
                "assessment_id": content_digest(
                    {
                        key: value
                        for key, value in distinguishing_diagnostic.items()
                        if key != "assessment_id"
                    }
                ),
            }
        required_parent_programs = tuple(
            getattr(proposer, "required_parent_programs", ())
        )
        if required_parent_programs:
            parent_contribution = _hybrid_parent_contribution_diagnostic(
                program,
                required_parent_programs,
                diagnostic_suite,
            )
            distinguishing_failures = tuple(
                distinguishing_diagnostic.get("failure_reasons", ())
            )
            distinguishing_diagnostic = {
                **distinguishing_diagnostic,
                "hybrid_parent_contribution": parent_contribution,
                "passed": bool(distinguishing_diagnostic["passed"])
                and bool(parent_contribution["passed"]),
                "failure_reasons": list(
                    dict.fromkeys(
                        (
                            *distinguishing_failures,
                            *parent_contribution["failure_reasons"],
                        )
                    )
                ),
            }
            distinguishing_diagnostic = {
                **distinguishing_diagnostic,
                "assessment_id": content_digest(
                    {
                        key: value
                        for key, value in distinguishing_diagnostic.items()
                        if key != "assessment_id"
                    }
                ),
            }
        mechanism_distance = _mechanism_distance_assessment(
            program,
            config,
        )
        if config.require_mechanism_gate and not (
            mechanism_gate_decision["passed"]
            and distinguishing_diagnostic["passed"]
            and mechanism_distance.passed
        ):
            if artifact_store is not None:
                if (
                    isinstance(program, GeneratedPolicyModuleProgram)
                    and program.island_family == "de_novo"
                    and de_novo_representation_headroom is not None
                    and de_novo_classification is not None
                ):
                    artifact_store.put(
                        "de_novo_research_memory",
                        build_de_novo_research_memory(
                            program,
                            de_novo_representation_headroom,
                            de_novo_classification,
                            calibration=objective_calibration,
                            objective_oracle=(
                                first_principles_objective_gate
                            ),
                            campaign_stage_id=campaign_stage_id,
                        ),
                    )
                artifact_store.put(
                    "three_island_pre_screen_rejection",
                    {
                        "campaign_stage_id": campaign_stage_id,
                        "island": config.island,
                        "candidate": program.as_dict(),
                        "semantic_novelty": semantic_novelty,
                        "mechanism_gate_decision": (
                            mechanism_gate_decision
                        ),
                        "distinguishing_diagnostic": distinguishing_diagnostic,
                        "mechanism_distance": mechanism_distance.as_dict(),
                        "de_novo_representation_headroom": (
                            de_novo_representation_headroom
                        ),
                        "de_novo_learning_classification": (
                            de_novo_classification
                        ),
                        "episode_screen_executed": False,
                    },
                )
            return False
        action_comparison = direct_action_comparison(
            program,
            incumbent,
            (*repair, *guard),
        )
        decision_count = sum(
            len(trace["placements"]) for trace in traces
        )
        differing_trace_decisions = sum(
            candidate_bin != incumbent_bin
            for trace in traces
            for candidate_bin, incumbent_bin in zip(
                trace["placements"],
                incumbent_placements[trace["instance_id"]],
            )
        )
        behavior_distance = (
            differing_trace_decisions / float(decision_count)
            if decision_count
            else 0.0
        )
        repair_report = evaluate_paired_policy(
            program,
            incumbent,
            repair,
            repair_incumbent_bins,
        )
        guard_report = evaluate_paired_policy(
            program,
            incumbent,
            guard,
            guard_incumbent_bins,
        )
        discovery_assessment = _discovery_assessment(
            program,
            config,
            repair_report,
            guard_report,
            behavior_distance,
            (
                float(baseline_authority["intervention_rate"])
                if baseline_authority["applicable"]
                else action_comparison.disagreement_rate
            ),
        )
        provisional = IslandCandidateRecord(
            island=config.island,
            program=program,
            parent_ids=proposal.parent_ids,
            operator=proposal.operator,
            evaluation_index=len(evaluated),
            repair_report=repair_report,
            guard_report=guard_report,
            behavior_fingerprint=fingerprint,
            discovery_assessment=discovery_assessment,
            semantic_novelty=semantic_novelty,
            mechanism_gate_decision=mechanism_gate_decision,
            distinguishing_diagnostic=distinguishing_diagnostic,
            eligible=(
                _research_eligible(guard_report, config)
                and (
                    not config.require_mechanism_gate
                    or (
                        mechanism_gate_decision["passed"]
                        and distinguishing_diagnostic["passed"]
                    )
                )
            ),
            deployment_safe=_deployment_safe(guard_report, config),
            exploration_lane=config.exploration_lane,
            episode_confidence_discovery=(
                config.episode_confidence_discovery
            ),
            archive_cell=(0, 0, 0, 0),
        )
        cell = _cell(provisional)
        value = {
            **provisional.as_dict(),
            "archive_cell": list(cell),
            "campaign_stage_id": campaign_stage_id,
        }
        artifact_digest = (
            artifact_store.put("three_island_candidate_evaluation", value)
            if artifact_store is not None
            else None
        )
        record = IslandCandidateRecord(
            island=config.island,
            program=program,
            parent_ids=proposal.parent_ids,
            operator=proposal.operator,
            evaluation_index=len(evaluated),
            repair_report=repair_report,
            guard_report=guard_report,
            behavior_fingerprint=fingerprint,
            discovery_assessment=discovery_assessment,
            semantic_novelty=semantic_novelty,
            mechanism_gate_decision=mechanism_gate_decision,
            distinguishing_diagnostic=distinguishing_diagnostic,
            eligible=provisional.eligible,
            deployment_safe=provisional.deployment_safe,
            exploration_lane=config.exploration_lane,
            episode_confidence_discovery=(
                config.episode_confidence_discovery
            ),
            archive_cell=cell,
            artifact_digest=artifact_digest,
        )
        evaluated.append(record)
        current = archive.get(cell)
        if current is None or record.rank > current.rank:
            archive[cell] = record
        return True

    def evaluate(proposal: Proposal) -> bool:
        """Keep failures in untrusted generated code candidate-local."""

        try:
            return _evaluate_candidate(proposal)
        except GeneratedPolicyRejected as error:
            if artifact_store is not None:
                artifact_store.put(
                    "three_island_candidate_runtime_rejection",
                    {
                        "campaign_stage_id": campaign_stage_id,
                        "island": config.island,
                        "candidate": proposal.program.as_dict(),
                        "parent_ids": list(proposal.parent_ids),
                        "operator": proposal.operator,
                        "failure_type": "generated_policy_runtime_rejection",
                        "failure_message": str(error),
                        "episode_evaluation_completed": False,
                    },
                )
            return False

    for proposal in resumed_proposals:
        if len(evaluated) >= config.evaluation_budget:
            break
        if not evaluate(proposal):
            duplicate_attempts += 1
    if not resumed_proposals:
        for program in carried_programs:
            if len(evaluated) >= config.evaluation_budget:
                break
            if not evaluate(Proposal(program, (), "carried_elite")):
                duplicate_attempts += 1
        for proposal in proposer.seeds(config, rng):
            if len(evaluated) >= config.evaluation_budget:
                break
            if not evaluate(proposal):
                duplicate_attempts += 1

    attempts = 0
    consecutive_rejections = 0
    maximum_attempts = config.evaluation_budget * 300
    while len(evaluated) < config.evaluation_budget and attempts < maximum_attempts:
        if (
            config.max_consecutive_candidate_rejections
            and consecutive_rejections
            >= config.max_consecutive_candidate_rejections
        ):
            value = {
                "campaign_stage_id": campaign_stage_id,
                "island": config.island,
                "evaluated_count": len(evaluated),
                "evaluation_budget": config.evaluation_budget,
                "consecutive_rejections": consecutive_rejections,
                "rejection_limit": (
                    config.max_consecutive_candidate_rejections
                ),
                "disposition": "stop_lane_and_revise_generation_protocol",
            }
            if artifact_store is not None:
                artifact_store.put("three_island_lane_stalled", value)
            raise IslandSearchStalled(
                "%s lane stalled after %d consecutive invalid candidates "
                "at %d/%d evaluations"
                % (
                    config.island,
                    consecutive_rejections,
                    len(evaluated),
                    config.evaluation_budget,
                )
            )
        attempts += 1
        proposal = proposer.propose(
            config,
            tuple(archive.values()),
            rng,
        )
        if not evaluate(proposal):
            duplicate_attempts += 1
            consecutive_rejections += 1
        else:
            consecutive_rejections = 0
    if len(evaluated) != config.evaluation_budget:
        raise RuntimeError(
            "%s island exhausted unique candidates at %d/%d"
            % (
                config.island,
                len(evaluated),
                config.evaluation_budget,
            )
        )
    return IslandSearchOutcome(
        config=config,
        proposer_name=proposer.name,
        incumbent_name=incumbent.name,
        best=max(evaluated, key=lambda record: record.rank),
        evaluated=tuple(evaluated),
        archive=tuple(archive[cell] for cell in sorted(archive)),
        duplicate_attempts=duplicate_attempts,
        literature_context_id=(
            None
            if literature_context is None
            else literature_context.context_id
        ),
        literature_evidence_ids=(
            ()
            if literature_context is None
            else literature_context.source_work_ids
        ),
    )
