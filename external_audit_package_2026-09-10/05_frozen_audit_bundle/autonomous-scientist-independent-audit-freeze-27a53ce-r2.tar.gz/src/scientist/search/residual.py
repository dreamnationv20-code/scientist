from __future__ import annotations

import random
from dataclasses import dataclass
from statistics import mean
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.programs import (
    Expression,
    FunSearchResidualProgram,
    crossover_expressions,
    mutate_expression,
    random_expression,
)


RESIDUAL_SEARCH_VERSION = "funsearch-residual-repair-v1"
RepairCell = Tuple[int, int, int]


@dataclass(frozen=True)
class ResidualRepairConfig:
    seed: int = 0
    evaluation_budget: int = 200
    initial_random: int = 16
    crossover_probability: float = 0.25
    max_expression_depth: int = 8
    max_expression_nodes: int = 63
    residual_scale: float = 0.05
    guard_mean_delta_ceiling: float = 0.0
    guard_regression_fraction_ceiling: float = 0.10
    guard_max_regression: int = 1

    def __post_init__(self) -> None:
        if self.evaluation_budget <= 0:
            raise ValueError("evaluation_budget must be positive")
        if self.initial_random < 0:
            raise ValueError("initial_random must be non-negative")
        if not 0.0 <= self.crossover_probability <= 1.0:
            raise ValueError("invalid crossover probability")
        if self.max_expression_depth <= 0 or self.max_expression_nodes <= 0:
            raise ValueError("expression limits must be positive")
        if self.residual_scale <= 0:
            raise ValueError("residual_scale must be positive")
        if not 0.0 <= self.guard_regression_fraction_ceiling <= 1.0:
            raise ValueError("invalid guard regression fraction")
        if self.guard_max_regression < 0:
            raise ValueError("guard_max_regression must be non-negative")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "seed": self.seed,
            "evaluation_budget": self.evaluation_budget,
            "initial_random": self.initial_random,
            "crossover_probability": self.crossover_probability,
            "max_expression_depth": self.max_expression_depth,
            "max_expression_nodes": self.max_expression_nodes,
            "residual_scale": self.residual_scale,
            "guard_mean_delta_ceiling": self.guard_mean_delta_ceiling,
            "guard_regression_fraction_ceiling": (
                self.guard_regression_fraction_ceiling
            ),
            "guard_max_regression": self.guard_max_regression,
        }


@dataclass(frozen=True)
class PairedPolicyReport:
    candidate_name: str
    incumbent_name: str
    instance_ids: Tuple[str, ...]
    deltas: Tuple[int, ...]

    @property
    def mean_delta(self) -> float:
        return mean(self.deltas)

    @property
    def wins(self) -> int:
        return sum(delta < 0 for delta in self.deltas)

    @property
    def ties(self) -> int:
        return sum(delta == 0 for delta in self.deltas)

    @property
    def losses(self) -> int:
        return sum(delta > 0 for delta in self.deltas)

    @property
    def maximum_regression(self) -> int:
        return max(self.deltas)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate_name": self.candidate_name,
            "incumbent_name": self.incumbent_name,
            "instance_count": len(self.deltas),
            "mean_delta_candidate_minus_incumbent": self.mean_delta,
            "wins": self.wins,
            "ties": self.ties,
            "losses": self.losses,
            "maximum_regression": self.maximum_regression,
            "observations": [
                {
                    "instance_id": instance_id,
                    "bin_delta_candidate_minus_incumbent": delta,
                }
                for instance_id, delta in zip(self.instance_ids, self.deltas)
            ],
        }


def evaluate_paired_policy(
    candidate: OnlineHeuristic,
    incumbent: OnlineHeuristic,
    instances: Iterable[BinPackingInstance],
    incumbent_bins: Optional[Mapping[str, int]] = None,
) -> PairedPolicyReport:
    instance_tuple = tuple(instances)
    if not instance_tuple:
        raise ValueError("paired evaluation requires at least one instance")
    references = (
        {
            instance.instance_id: pack(instance, incumbent).bin_count
            for instance in instance_tuple
        }
        if incumbent_bins is None
        else incumbent_bins
    )
    if set(references) != {
        instance.instance_id for instance in instance_tuple
    }:
        raise ValueError("incumbent references do not match paired suite")
    return PairedPolicyReport(
        candidate_name=candidate.name,
        incumbent_name=incumbent.name,
        instance_ids=tuple(
            instance.instance_id for instance in instance_tuple
        ),
        deltas=tuple(
            pack(instance, candidate).bin_count
            - int(references[instance.instance_id])
            for instance in instance_tuple
        ),
    )


@dataclass(frozen=True)
class ResidualCandidateRecord:
    program: FunSearchResidualProgram
    parent_ids: Tuple[str, ...]
    operator: str
    evaluation_index: int
    repair_report: PairedPolicyReport
    guard_report: PairedPolicyReport
    eligible: bool
    archive_cell: RepairCell
    artifact_digest: Optional[str] = None

    @property
    def rank(self) -> Tuple[float, ...]:
        return (
            float(self.eligible),
            -self.repair_report.mean_delta,
            -self.guard_report.mean_delta,
            float(self.repair_report.wins),
            -float(self.guard_report.losses),
            -float(self.program.complexity),
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "candidate": self.program.as_dict(),
            "parent_ids": list(self.parent_ids),
            "operator": self.operator,
            "evaluation_index": self.evaluation_index,
            "repair_report": self.repair_report.as_dict(),
            "guard_report": self.guard_report.as_dict(),
            "eligible": self.eligible,
            "archive_cell": list(self.archive_cell),
            "rank": list(self.rank),
            "artifact_digest": self.artifact_digest,
        }


@dataclass(frozen=True)
class ResidualRepairOutcome:
    config: ResidualRepairConfig
    incumbent_name: str
    best: ResidualCandidateRecord
    evaluated: Tuple[ResidualCandidateRecord, ...]
    archive: Tuple[ResidualCandidateRecord, ...]
    duplicate_attempts: int

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "search_version": RESIDUAL_SEARCH_VERSION,
            "config": self.config.as_dict(),
            "incumbent_name": self.incumbent_name,
            "best_candidate_id": self.best.program.candidate_id,
            "evaluated_count": len(self.evaluated),
            "archive_size": len(self.archive),
            "duplicate_attempts": self.duplicate_attempts,
            "best": self.best.as_dict(),
            "evaluated": [record.as_dict() for record in self.evaluated],
            "archive": [record.as_dict() for record in self.archive],
        }


def _cell(record: ResidualCandidateRecord) -> RepairCell:
    repair_rate = record.repair_report.wins / float(
        len(record.repair_report.deltas)
    )
    regression_rate = record.guard_report.losses / float(
        len(record.guard_report.deltas)
    )
    complexity_bucket = (
        0 if record.program.complexity <= 3
        else 1 if record.program.complexity <= 9
        else 2
    )
    return (
        min(4, int(repair_rate * 5)),
        min(4, int(regression_rate * 5)),
        complexity_bucket,
    )


def _eligible(
    report: PairedPolicyReport,
    config: ResidualRepairConfig,
) -> bool:
    return (
        report.mean_delta <= config.guard_mean_delta_ceiling
        and (
            report.losses / float(len(report.deltas))
            <= config.guard_regression_fraction_ceiling
        )
        and report.maximum_regression <= config.guard_max_regression
    )


def _seed_expressions() -> Tuple[Expression, ...]:
    large_item = Expression.unary(
        "step",
        Expression.binary(
            "sub",
            Expression.feature("item"),
            Expression.const(0.5),
        ),
    )
    valley_repairs = tuple(
        Expression.binary(
            "mul",
            large_item,
            Expression.unary(
                "step",
                Expression.binary(
                    "sub",
                    Expression.const(threshold),
                    Expression.feature("remaining_after"),
                ),
            ),
        )
        for threshold in (0.06, 0.07, 0.08)
    )
    return (
        Expression.const(0.0),
        Expression.feature("fill_after"),
        Expression.unary("neg", Expression.feature("fill_after")),
        Expression.feature("bin_index"),
        Expression.unary("neg", Expression.feature("bin_index")),
        Expression.feature("is_new_bin"),
        Expression.unary("neg", Expression.feature("is_new_bin")),
        Expression.feature("seen_mean"),
        Expression.feature("seen_std"),
        *valley_repairs,
    )


def run_residual_repair_search(
    config: ResidualRepairConfig,
    repair_instances: Iterable[BinPackingInstance],
    guard_instances: Iterable[BinPackingInstance],
    incumbent: OnlineHeuristic,
    artifact_store: Optional[ArtifactStore] = None,
) -> ResidualRepairOutcome:
    repair_tuple = tuple(repair_instances)
    guard_tuple = tuple(guard_instances)
    if not repair_tuple or not guard_tuple:
        raise ValueError("repair and guard suites must both be non-empty")
    rng = random.Random(config.seed)
    repair_incumbent_bins = {
        instance.instance_id: pack(instance, incumbent).bin_count
        for instance in repair_tuple
    }
    guard_incumbent_bins = {
        instance.instance_id: pack(instance, incumbent).bin_count
        for instance in guard_tuple
    }
    evaluated: List[ResidualCandidateRecord] = []
    archive: Dict[RepairCell, ResidualCandidateRecord] = {}
    seen = set()
    duplicate_attempts = 0

    def evaluate(
        program: FunSearchResidualProgram,
        parent_ids: Tuple[str, ...],
        operator: str,
    ) -> bool:
        if program.candidate_id in seen:
            return False
        seen.add(program.candidate_id)
        repair_report = evaluate_paired_policy(
            program,
            incumbent,
            repair_tuple,
            repair_incumbent_bins,
        )
        guard_report = evaluate_paired_policy(
            program,
            incumbent,
            guard_tuple,
            guard_incumbent_bins,
        )
        is_eligible = _eligible(guard_report, config)
        provisional = ResidualCandidateRecord(
            program=program,
            parent_ids=parent_ids,
            operator=operator,
            evaluation_index=len(evaluated),
            repair_report=repair_report,
            guard_report=guard_report,
            eligible=is_eligible,
            archive_cell=(0, 0, 0),
        )
        cell = _cell(provisional)
        artifact_digest = None
        if artifact_store is not None:
            artifact_digest = artifact_store.put(
                "funsearch_residual_candidate_evaluation",
                {
                    **provisional.as_dict(),
                    "archive_cell": list(cell),
                },
            )
        record = ResidualCandidateRecord(
            program=program,
            parent_ids=parent_ids,
            operator=operator,
            evaluation_index=len(evaluated),
            repair_report=repair_report,
            guard_report=guard_report,
            eligible=is_eligible,
            archive_cell=cell,
            artifact_digest=artifact_digest,
        )
        evaluated.append(record)
        incumbent_record = archive.get(cell)
        if incumbent_record is None or record.rank > incumbent_record.rank:
            archive[cell] = record
        return True

    for expression in _seed_expressions():
        if len(evaluated) >= config.evaluation_budget:
            break
        evaluate(
            FunSearchResidualProgram(expression, config.residual_scale),
            (),
            "incumbent" if expression == Expression.const(0.0) else "seed",
        )
    for _ in range(config.initial_random):
        if len(evaluated) >= config.evaluation_budget:
            break
        if not evaluate(
            FunSearchResidualProgram(
                random_expression(rng, 4),
                config.residual_scale,
            ),
            (),
            "random_seed",
        ):
            duplicate_attempts += 1

    attempts = 0
    maximum_attempts = config.evaluation_budget * 200
    while len(evaluated) < config.evaluation_budget and attempts < maximum_attempts:
        attempts += 1
        parent_pool = tuple(archive.values())
        first = rng.choice(parent_pool)
        if (
            len(parent_pool) > 1
            and rng.random() < config.crossover_probability
        ):
            second = rng.choice(parent_pool)
            expression = crossover_expressions(
                first.program.expression,
                second.program.expression,
                rng,
                max_depth=config.max_expression_depth,
                max_nodes=config.max_expression_nodes,
            )
            parents = (
                first.program.candidate_id,
                second.program.candidate_id,
            )
            operator = "crossover"
        else:
            expression = mutate_expression(
                first.program.expression,
                rng,
                max_depth=config.max_expression_depth,
                max_nodes=config.max_expression_nodes,
            )
            parents = (first.program.candidate_id,)
            operator = "mutation"
        if not evaluate(
            FunSearchResidualProgram(expression, config.residual_scale),
            parents,
            operator,
        ):
            duplicate_attempts += 1

    if len(evaluated) != config.evaluation_budget:
        raise RuntimeError(
            "residual search exhausted unique candidates at %d/%d"
            % (len(evaluated), config.evaluation_budget)
        )
    return ResidualRepairOutcome(
        config=config,
        incumbent_name=incumbent.name,
        best=max(evaluated, key=lambda record: record.rank),
        evaluated=tuple(evaluated),
        archive=tuple(archive[cell] for cell in sorted(archive)),
        duplicate_attempts=duplicate_attempts,
    )
