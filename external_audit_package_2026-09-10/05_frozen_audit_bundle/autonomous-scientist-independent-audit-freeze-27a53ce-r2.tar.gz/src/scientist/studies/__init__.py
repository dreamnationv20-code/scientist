"""Executable scientific studies built on the kernel."""

