from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, replace
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore
from scientist.domains.binpacking.counterexamples import (
    Counterexample,
    minimize_policy_gap,
)
from scientist.domains.binpacking.exact import optimal_bin_count
from scientist.domains.binpacking.generators import generate_suite
from scientist.domains.binpacking.heuristics import OnlineHeuristic, pack
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.science.beliefs import (
    LOSS_POSTERIOR_RULE,
    entropy,
    loss_posterior,
)
from scientist.science.contracts import (
    Evidence,
    Hypothesis,
    ModelPredictionEvidenceBundle,
    Prediction,
)


@dataclass(frozen=True)
class ActiveStudyConfig:
    families: Tuple[str, ...]
    selection_mode: str = "active"
    pool_seed_start: int = 30_000
    pool_seed_count: int = 20
    length: int = 14
    capacity: int = 100
    evaluation_budget: int = 12
    temperature: float = 0.7
    maximum_counterexamples: int = 3

    def __post_init__(self) -> None:
        if not self.families:
            raise ValueError("at least one family is required")
        if self.pool_seed_count <= 0:
            raise ValueError("pool_seed_count must be positive")
        if self.length <= 0 or self.capacity <= 0:
            raise ValueError("length and capacity must be positive")
        if self.evaluation_budget <= 0:
            raise ValueError("evaluation_budget must be positive")
        if self.temperature <= 0.0:
            raise ValueError("temperature must be positive")
        if self.maximum_counterexamples < 0:
            raise ValueError("maximum_counterexamples must be non-negative")
        if self.selection_mode not in ("active", "passive"):
            raise ValueError("selection_mode must be active or passive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "families": list(self.families),
            "selection_mode": self.selection_mode,
            "pool_seed_start": self.pool_seed_start,
            "pool_seed_count": self.pool_seed_count,
            "length": self.length,
            "capacity": self.capacity,
            "evaluation_budget": self.evaluation_budget,
            "temperature": self.temperature,
            "maximum_counterexamples": self.maximum_counterexamples,
        }


@dataclass(frozen=True)
class StudyRound:
    index: int
    instance_id: str
    family: str
    seed: int
    selection_score: float
    prior_weights: Mapping[str, float]
    predicted_bin_counts: Mapping[str, int]
    prediction_ids: Mapping[str, str]
    optimal_bin_count: int
    evidence_id: str
    regrets: Mapping[str, int]
    posterior_weights: Mapping[str, float]
    posterior_entropy: float

    def as_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "instance_id": self.instance_id,
            "family": self.family,
            "seed": self.seed,
            "selection_score": self.selection_score,
            "prior_weights": dict(sorted(self.prior_weights.items())),
            "predicted_bin_counts": dict(
                sorted(self.predicted_bin_counts.items())
            ),
            "prediction_ids": dict(sorted(self.prediction_ids.items())),
            "optimal_bin_count": self.optimal_bin_count,
            "evidence_id": self.evidence_id,
            "regrets": dict(sorted(self.regrets.items())),
            "posterior_weights": dict(sorted(self.posterior_weights.items())),
            "posterior_entropy": self.posterior_entropy,
        }


@dataclass(frozen=True)
class ActiveStudyOutcome:
    config: ActiveStudyConfig
    hypotheses: Tuple[Hypothesis, ...]
    rounds: Tuple[StudyRound, ...]
    bundles: Tuple[ModelPredictionEvidenceBundle, ...]
    counterexamples: Tuple[Counterexample, ...]
    selected_instance_ids: Tuple[str, ...]
    remaining_pool_size: int
    exact_evaluations: int
    artifact_digests: Mapping[str, str]

    @property
    def winner(self) -> ModelPredictionEvidenceBundle:
        return max(
            self.bundles,
            key=lambda bundle: (
                bundle.normalized_weight,
                -bundle.cumulative_loss,
                bundle.hypothesis_id,
            ),
        )

    @property
    def final_entropy(self) -> float:
        return self.rounds[-1].posterior_entropy

    @property
    def discriminating_rounds(self) -> int:
        return sum(
            len(set(round_.predicted_bin_counts.values())) > 1
            for round_ in self.rounds
        )

    def as_dict(self) -> Dict[str, Any]:
        names = {
            hypothesis.hypothesis_id: hypothesis.name
            for hypothesis in self.hypotheses
        }
        return {
            "schema": 1,
            "config": self.config.as_dict(),
            "hypotheses": [
                hypothesis.as_dict() for hypothesis in self.hypotheses
            ],
            "rounds": [round_.as_dict() for round_ in self.rounds],
            "bundles": [bundle.as_dict() for bundle in self.bundles],
            "counterexamples": [
                counterexample.as_dict()
                for counterexample in self.counterexamples
            ],
            "selected_instance_ids": list(self.selected_instance_ids),
            "remaining_pool_size": self.remaining_pool_size,
            "exact_evaluations": self.exact_evaluations,
            "final_entropy": self.final_entropy,
            "discriminating_rounds": self.discriminating_rounds,
            "winner_hypothesis_id": self.winner.hypothesis_id,
            "winner_name": names[self.winner.hypothesis_id],
            "artifact_digests": dict(sorted(self.artifact_digests.items())),
        }


def _selection_score(
    predicted_counts: Mapping[str, int],
    weights: Mapping[str, float],
) -> float:
    """Weighted pairwise disagreement among still-plausible models."""
    score = 0.0
    for left, right in itertools.combinations(sorted(predicted_counts), 2):
        difference = abs(predicted_counts[left] - predicted_counts[right])
        score += math.sqrt(weights[left] * weights[right]) * difference
    return score


def _make_hypotheses(
    policies: Mapping[str, OnlineHeuristic],
) -> Dict[str, Hypothesis]:
    return {
        name: Hypothesis(
            name=name,
            statement=(
                "%s is optimal or near-optimal on the declared instance "
                "distribution." % name
            ),
            model_kind="executable_online_policy",
            executable_ref="binpacking_policy:%s:v1" % name,
            prior_weight=1.0,
        )
        for name in sorted(policies)
    }


def run_active_policy_study(
    config: ActiveStudyConfig,
    policies: Mapping[str, OnlineHeuristic],
    artifact_store: Optional[ArtifactStore] = None,
) -> ActiveStudyOutcome:
    if len(policies) < 2:
        raise ValueError("at least two competing policies are required")
    hypotheses_by_name = _make_hypotheses(policies)
    hypothesis_names = {
        hypothesis.hypothesis_id: name
        for name, hypothesis in hypotheses_by_name.items()
    }
    hypotheses_by_id = {
        hypothesis.hypothesis_id: hypothesis
        for hypothesis in hypotheses_by_name.values()
    }
    pool = generate_suite(
        families=config.families,
        seeds=range(
            config.pool_seed_start,
            config.pool_seed_start + config.pool_seed_count,
        ),
        length=config.length,
        capacity=config.capacity,
    )
    if config.evaluation_budget > len(pool):
        raise ValueError("evaluation_budget exceeds the experiment pool")

    predicted_pool: Dict[str, Dict[str, int]] = {}
    instances_by_id = {instance.instance_id: instance for instance in pool}
    for instance in pool:
        predicted_pool[instance.instance_id] = {
            hypothesis.hypothesis_id: pack(
                instance,
                policies[name],
            ).bin_count
            for name, hypothesis in hypotheses_by_name.items()
        }

    artifact_digests: Dict[str, str] = {}
    if artifact_store is not None:
        artifact_digests["experiment_pool"] = artifact_store.put(
            "active_study_experiment_pool",
            [instance.as_dict() for instance in pool],
        )
        for name, hypothesis in hypotheses_by_name.items():
            artifact_digests["hypothesis:%s" % name] = artifact_store.put(
                "hypothesis",
                hypothesis.as_dict(),
            )

    priors = {
        hypothesis_id: hypothesis.prior_weight
        for hypothesis_id, hypothesis in hypotheses_by_id.items()
    }
    cumulative_losses = {hypothesis_id: 0.0 for hypothesis_id in priors}
    weights = loss_posterior(priors, cumulative_losses, config.temperature)
    remaining_ids = set(instances_by_id)
    rounds: List[StudyRound] = []
    prediction_ids: Dict[str, List[str]] = {
        hypothesis_id: [] for hypothesis_id in priors
    }
    evidence_ids: Dict[str, List[str]] = {
        hypothesis_id: [] for hypothesis_id in priors
    }

    for round_index in range(config.evaluation_budget):
        if config.selection_mode == "active":
            scored = [
                (
                    _selection_score(predicted_pool[instance_id], weights),
                    instance_id,
                )
                for instance_id in remaining_ids
            ]
            selection_score, selected_id = max(
                scored,
                key=lambda pair: (pair[0], pair[1]),
            )
        else:
            # Content IDs are hash-distributed, giving a deterministic
            # selection that does not inspect model predictions.
            selected_id = min(remaining_ids)
            selection_score = _selection_score(
                predicted_pool[selected_id],
                weights,
            )
        remaining_ids.remove(selected_id)
        instance = instances_by_id[selected_id]
        prior_weights_by_name = {
            hypothesis_names[key]: value for key, value in weights.items()
        }

        round_predictions: Dict[str, Prediction] = {}
        round_prediction_ids: Dict[str, str] = {}
        for hypothesis_id, count in predicted_pool[selected_id].items():
            name = hypothesis_names[hypothesis_id]
            prediction = Prediction(
                hypothesis_id=hypothesis_id,
                experiment_id=selected_id,
                target="optimal_bin_count",
                predicted_value=float(count),
            )
            round_predictions[hypothesis_id] = prediction
            round_prediction_ids[name] = prediction.prediction_id
            prediction_ids[hypothesis_id].append(prediction.prediction_id)
            if artifact_store is not None:
                artifact_store.put("prediction", prediction.as_dict())

        # Predictions are registered before this exact-solver observation.
        optimum = optimal_bin_count(instance.items, instance.capacity)
        evidence = Evidence(
            experiment_id=selected_id,
            target="optimal_bin_count",
            observed_value=float(optimum),
            method_ref="binpacking_exact_branch_and_bound:v1",
        )
        if artifact_store is not None:
            artifact_store.put("evidence", evidence.as_dict())

        regrets_by_name: Dict[str, int] = {}
        for hypothesis_id, count in predicted_pool[selected_id].items():
            regret = int(count - optimum)
            if regret < 0:
                raise AssertionError("policy used fewer bins than the optimum")
            cumulative_losses[hypothesis_id] += regret
            prediction_ids_for_model = prediction_ids[hypothesis_id]
            if prediction_ids_for_model[-1] != round_predictions[
                hypothesis_id
            ].prediction_id:
                raise AssertionError("prediction/evidence ordering failed")
            evidence_ids[hypothesis_id].append(evidence.evidence_id)
            regrets_by_name[hypothesis_names[hypothesis_id]] = regret

        weights = loss_posterior(
            priors,
            cumulative_losses,
            config.temperature,
        )
        posterior_by_name = {
            hypothesis_names[key]: value for key, value in weights.items()
        }
        round_record = StudyRound(
            index=round_index,
            instance_id=selected_id,
            family=instance.family,
            seed=instance.seed,
            selection_score=selection_score,
            prior_weights=prior_weights_by_name,
            predicted_bin_counts={
                hypothesis_names[key]: value
                for key, value in predicted_pool[selected_id].items()
            },
            prediction_ids=round_prediction_ids,
            optimal_bin_count=optimum,
            evidence_id=evidence.evidence_id,
            regrets=regrets_by_name,
            posterior_weights=posterior_by_name,
            posterior_entropy=entropy(weights),
        )
        rounds.append(round_record)
        if artifact_store is not None:
            artifact_store.put("active_study_round", round_record.as_dict())

    bundles = tuple(
        ModelPredictionEvidenceBundle(
            hypothesis_id=hypothesis_id,
            prediction_ids=tuple(prediction_ids[hypothesis_id]),
            evidence_ids=tuple(evidence_ids[hypothesis_id]),
            cumulative_loss=cumulative_losses[hypothesis_id],
            normalized_weight=weights[hypothesis_id],
            update_rule=LOSS_POSTERIOR_RULE,
        )
        for hypothesis_id in sorted(hypotheses_by_id)
    )
    if artifact_store is not None:
        for bundle in bundles:
            name = hypothesis_names[bundle.hypothesis_id]
            artifact_digests["bundle:%s" % name] = artifact_store.put(
                "model_prediction_evidence_bundle",
                bundle.as_dict(),
            )

    winner_bundle = max(
        bundles,
        key=lambda bundle: (
            bundle.normalized_weight,
            -bundle.cumulative_loss,
            bundle.hypothesis_id,
        ),
    )
    winner_name = hypothesis_names[winner_bundle.hypothesis_id]
    winner_policy = policies[winner_name]
    selected_instances = [
        instances_by_id[round_.instance_id] for round_ in rounds
    ]
    counterexamples: List[Counterexample] = []
    competitors = sorted(
        (
            name
            for name in policies
            if name != winner_name
        ),
        key=lambda name: (
            cumulative_losses[hypotheses_by_name[name].hypothesis_id],
            name,
        ),
        reverse=True,
    )
    for competitor_name in competitors:
        if len(counterexamples) >= config.maximum_counterexamples:
            break
        candidates = [
            instance
            for instance in selected_instances
            if pack(instance, winner_policy).bin_count
            < pack(instance, policies[competitor_name]).bin_count
        ]
        if not candidates:
            continue
        source = max(
            candidates,
            key=lambda instance: (
                pack(instance, policies[competitor_name]).bin_count
                - pack(instance, winner_policy).bin_count,
                instance.instance_id,
            ),
        )
        counterexample = minimize_policy_gap(
            source,
            winner_policy,
            policies[competitor_name],
        )
        counterexample = replace(
            counterexample,
            optimum=optimal_bin_count(
                counterexample.minimized_instance.items,
                counterexample.minimized_instance.capacity,
            ),
        )
        counterexamples.append(counterexample)
        if artifact_store is not None:
            artifact_digests[
                "counterexample:%s:%s" % (winner_name, competitor_name)
            ] = artifact_store.put(
                "minimized_counterexample",
                counterexample.as_dict(),
            )

    return ActiveStudyOutcome(
        config=config,
        hypotheses=tuple(
            hypotheses_by_name[name] for name in sorted(hypotheses_by_name)
        ),
        rounds=tuple(rounds),
        bundles=bundles,
        counterexamples=tuple(counterexamples),
        selected_instance_ids=tuple(
            round_.instance_id for round_ in rounds
        ),
        remaining_pool_size=len(remaining_ids),
        exact_evaluations=len(rounds) + len(counterexamples),
        artifact_digests=artifact_digests,
    )
