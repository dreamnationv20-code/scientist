from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.binpacking.adversary import (
    AdversaryConfig,
    AdversaryOutcome,
    evolve_adversarial_sequences,
    select_diverse_adversaries,
)
from scientist.domains.binpacking.counterexamples import (
    Counterexample,
    minimize_policy_gap,
)
from scientist.domains.binpacking.equivalence import behaviour_fingerprint
from scientist.domains.binpacking.evaluator import (
    EvaluationReport,
    evaluate_heuristic,
    prepare_references,
)
from scientist.domains.binpacking.generators import generate_suite
from scientist.domains.binpacking.heuristics import (
    baseline_heuristics,
    literature_heuristics,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.search.evolution import (
    SearchConfig,
    SearchOutcome,
    run_evolutionary_search,
)


M3_DISCOVERY_VERSION = "m3-adversarial-discovery-v1"


@dataclass(frozen=True)
class AdversarialSearchConfig:
    capacity: int = 150
    length: int = 120
    development_seed_start: int = 0
    development_seed_count: int = 10
    validation_seed_start: int = 160_000
    validation_seed_count: int = 10
    equivalence_seed_start: int = 170_000
    equivalence_seed_count: int = 8
    scout_candidate_budget: int = 60
    arm_candidate_budget: int = 100
    adversary_evaluation_budget: int = 200
    adversary_initial_population: int = 20
    augmentation_count: int = 12
    search_seed: int = 0
    adversary_seed: int = 31

    def __post_init__(self) -> None:
        if self.capacity != 150:
            raise ValueError("M3's OR-distribution contract requires capacity 150")
        if self.length <= 1:
            raise ValueError("length must exceed one")
        if min(
            self.development_seed_count,
            self.validation_seed_count,
            self.equivalence_seed_count,
            self.scout_candidate_budget,
            self.arm_candidate_budget,
            self.adversary_evaluation_budget,
            self.adversary_initial_population,
            self.augmentation_count,
        ) <= 0:
            raise ValueError("suite counts and budgets must be positive")
        if self.augmentation_count > self.adversary_initial_population:
            raise ValueError(
                "augmentation_count cannot exceed adversary_initial_population"
            )
        if (
            self.adversary_initial_population
            > self.adversary_evaluation_budget
        ):
            raise ValueError(
                "adversary_initial_population cannot exceed its budget"
            )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "capacity": self.capacity,
            "length": self.length,
            "development_seed_start": self.development_seed_start,
            "development_seed_count": self.development_seed_count,
            "validation_seed_start": self.validation_seed_start,
            "validation_seed_count": self.validation_seed_count,
            "equivalence_seed_start": self.equivalence_seed_start,
            "equivalence_seed_count": self.equivalence_seed_count,
            "scout_candidate_budget": self.scout_candidate_budget,
            "arm_candidate_budget": self.arm_candidate_budget,
            "adversary_evaluation_budget": self.adversary_evaluation_budget,
            "adversary_initial_population": self.adversary_initial_population,
            "augmentation_count": self.augmentation_count,
            "search_seed": self.search_seed,
            "adversary_seed": self.adversary_seed,
        }


@dataclass(frozen=True)
class DiscoveryArm:
    name: str
    augmentation_instance_ids: Tuple[str, ...]
    search: SearchOutcome
    validation: EvaluationReport
    equivalent_known_policies: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "augmentation_instance_ids": list(self.augmentation_instance_ids),
            "search": self.search.as_dict(),
            "candidate": self.search.best.program.as_dict(),
            "validation": self.validation.as_dict(),
            "equivalent_known_policies": list(
                self.equivalent_known_policies
            ),
        }


@dataclass(frozen=True)
class AdversarialSearchOutcome:
    config: AdversarialSearchConfig
    scout: SearchOutcome
    adversary: AdversaryOutcome
    minimized_scout_counterexample: Optional[Counterexample]
    control: DiscoveryArm
    treatment: DiscoveryArm
    reference_validation: Mapping[str, EvaluationReport]
    frozen_bundle: Mapping[str, Any]
    frozen_bundle_digest: str
    suite_digests: Mapping[str, str]
    artifact_digests: Mapping[str, str]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "discovery_version": M3_DISCOVERY_VERSION,
            "config": self.config.as_dict(),
            "scout": self.scout.as_dict(),
            "adversary": self.adversary.as_dict(),
            "minimized_scout_counterexample": (
                None
                if self.minimized_scout_counterexample is None
                else self.minimized_scout_counterexample.as_dict()
            ),
            "control": self.control.as_dict(),
            "treatment": self.treatment.as_dict(),
            "reference_validation": {
                name: report.as_dict()
                for name, report in sorted(self.reference_validation.items())
            },
            "frozen_bundle": dict(self.frozen_bundle),
            "frozen_bundle_digest": self.frozen_bundle_digest,
            "suite_digests": dict(sorted(self.suite_digests.items())),
            "artifact_digests": dict(sorted(self.artifact_digests.items())),
        }


def _suite(
    config: AdversarialSearchConfig,
    seed_start: int,
    seed_count: int,
) -> Tuple[BinPackingInstance, ...]:
    return generate_suite(
        families=("or_uniform",),
        seeds=range(seed_start, seed_start + seed_count),
        length=config.length,
        capacity=config.capacity,
    )


def _search_config(
    config: AdversarialSearchConfig,
    budget: int,
    seed: int,
) -> SearchConfig:
    return SearchConfig(
        seed=seed,
        evaluation_budget=budget,
        initial_random=min(16, max(1, budget // 4)),
        max_expression_depth=10,
        max_expression_nodes=63,
        reference_mode="volume_lower_bound",
        record_placements=False,
    )


def run_adversarial_search(
    config: AdversarialSearchConfig,
    artifact_store: Optional[ArtifactStore] = None,
    source_provenance: Optional[Mapping[str, Any]] = None,
    external_source_contract: Optional[Mapping[str, Any]] = None,
) -> AdversarialSearchOutcome:
    """Run M3 discovery without opening the external OR-Library corpus."""

    development = _suite(
        config,
        config.development_seed_start,
        config.development_seed_count,
    )
    validation = _suite(
        config,
        config.validation_seed_start,
        config.validation_seed_count,
    )
    equivalence = _suite(
        config,
        config.equivalence_seed_start,
        config.equivalence_seed_count,
    )
    suite_digests: Dict[str, str] = {}
    artifact_digests: Dict[str, str] = {}
    if artifact_store is not None:
        for name, suite in (
            ("development", development),
            ("validation", validation),
            ("equivalence", equivalence),
        ):
            suite_digests[name] = artifact_store.put(
                "m3_%s_generated_suite" % name,
                [instance.as_dict() for instance in suite],
            )

    scout = run_evolutionary_search(
        _search_config(
            config,
            config.scout_candidate_budget,
            config.search_seed,
        ),
        development,
        artifact_store=artifact_store,
    )
    published_reference = literature_heuristics()["funsearch_or_reference"]
    adversary = evolve_adversarial_sequences(
        AdversaryConfig(
            seed=config.adversary_seed,
            evaluation_budget=config.adversary_evaluation_budget,
            initial_population=config.adversary_initial_population,
            length=config.length,
            capacity=config.capacity,
            minimum_item=20,
            maximum_item=100,
        ),
        scout.best.program,
        published_reference,
        artifact_store=artifact_store,
    )
    random_records = adversary.evaluated[: config.augmentation_count]
    adversarial_records = select_diverse_adversaries(
        adversary,
        config.augmentation_count,
    )
    control_instances = development + tuple(
        record.instance for record in random_records
    )
    treatment_instances = development + tuple(
        record.instance for record in adversarial_records
    )
    if len(control_instances) != len(treatment_instances):
        raise AssertionError("M3 search arms must have matched suite sizes")
    if artifact_store is not None:
        suite_digests["control_training"] = artifact_store.put(
            "m3_control_training_suite",
            [instance.as_dict() for instance in control_instances],
        )
        suite_digests["treatment_training"] = artifact_store.put(
            "m3_treatment_training_suite",
            [instance.as_dict() for instance in treatment_instances],
        )
        artifact_digests["adversary"] = artifact_store.put(
            "m3_adversary_summary",
            adversary.as_dict(),
        )

    arm_config = _search_config(
        config,
        config.arm_candidate_budget,
        config.search_seed + 1,
    )
    shared_seed = (scout.best.program,)
    control_search = run_evolutionary_search(
        arm_config,
        control_instances,
        artifact_store=artifact_store,
        additional_seed_programs=shared_seed,
    )
    treatment_search = run_evolutionary_search(
        arm_config,
        treatment_instances,
        artifact_store=artifact_store,
        additional_seed_programs=shared_seed,
    )

    # This is the preregistration boundary. Both programs and the external
    # claims are frozen before generated validation or OR-Library confirmation.
    frozen_bundle = {
        "schema": 1,
        "discovery_version": M3_DISCOVERY_VERSION,
        "candidate_roles": {
            "random_augmentation_control": control_search.best.program.as_dict(),
            "adversarial_augmentation_treatment": (
                treatment_search.best.program.as_dict()
            ),
        },
        "primary_candidate_role": "adversarial_augmentation_treatment",
        "training_contract": {
            "distribution": "integer uniform [20, 100]",
            "capacity": config.capacity,
            "sequence_length": config.length,
            "base_instance_count": len(development),
            "augmentation_count_per_arm": config.augmentation_count,
            "candidate_evaluations_per_arm": config.arm_candidate_budget,
            "adversary_sequence_evaluations": (
                config.adversary_evaluation_budget
            ),
            "external_benchmark_opened": False,
        },
        "confirmation_contract": {
            "corpus": "OR-Library binpack1.txt through binpack4.txt",
            "reference": "best-known bin count recorded in each source instance",
            "primary_metric": "mean excess bins over recorded best known",
            "paired_instances": True,
            "no_candidate_selection_after_opening": True,
        },
        "external_source_contract": dict(
            external_source_contract or {}
        ),
        "preregistered_predictions": [
            {
                "id": "adversarial_beats_random",
                "claim": (
                    "The adversarial-augmentation treatment has lower mean "
                    "excess than the random-augmentation control."
                ),
                "comparison": "treatment_mean_excess < control_mean_excess",
            },
            {
                "id": "candidate_beats_published_reference",
                "claim": (
                    "The treatment has lower mean excess than the published "
                    "FunSearch OR-distribution reference."
                ),
                "comparison": "treatment_mean_excess < funsearch_mean_excess",
            },
        ],
        "source_provenance": dict(source_provenance or {}),
    }
    frozen_bundle_digest = content_digest(frozen_bundle)
    if artifact_store is not None:
        stored_freeze = artifact_store.put(
            "m3_frozen_candidate_bundle",
            frozen_bundle,
        )
        artifact_digests["frozen_candidate_bundle"] = stored_freeze

    validation_references = prepare_references(
        validation,
        "volume_lower_bound",
    )
    known_policies = {
        **baseline_heuristics(),
        **literature_heuristics(),
    }
    known_fingerprints = {
        name: behaviour_fingerprint(policy, equivalence)
        for name, policy in known_policies.items()
    }

    def arm(
        name: str,
        augmentation_ids: Tuple[str, ...],
        search: SearchOutcome,
    ) -> DiscoveryArm:
        fingerprint = behaviour_fingerprint(search.best.program, equivalence)
        return DiscoveryArm(
            name=name,
            augmentation_instance_ids=augmentation_ids,
            search=search,
            validation=evaluate_heuristic(
                search.best.program,
                validation,
                optima=validation_references,
                reference_mode="volume_lower_bound",
                include_placements=False,
            ),
            equivalent_known_policies=tuple(
                sorted(
                    policy_name
                    for policy_name, known_fingerprint
                    in known_fingerprints.items()
                    if fingerprint == known_fingerprint
                )
            ),
        )

    control = arm(
        "random_augmentation_control",
        tuple(record.instance.instance_id for record in random_records),
        control_search,
    )
    treatment = arm(
        "adversarial_augmentation_treatment",
        tuple(
            record.instance.instance_id
            for record in adversarial_records
        ),
        treatment_search,
    )
    reference_validation = {
        name: evaluate_heuristic(
            policy,
            validation,
            optima=validation_references,
            reference_mode="volume_lower_bound",
            include_placements=False,
        )
        for name, policy in known_policies.items()
        if name in ("best_fit", "funsearch_or_reference")
    }
    counterexample = None
    if adversary.best.target_gap > 0:
        counterexample = minimize_policy_gap(
            adversary.best.instance,
            published_reference,
            scout.best.program,
        )
        if artifact_store is not None:
            artifact_digests["minimized_scout_counterexample"] = (
                artifact_store.put(
                    "m3_minimized_scout_counterexample",
                    counterexample.as_dict(),
                )
            )

    if artifact_store is not None:
        for result in (control, treatment):
            artifact_digests["%s_validation" % result.name] = (
                artifact_store.put(
                    "m3_generated_validation_report",
                    result.validation.as_dict(),
                )
            )

    return AdversarialSearchOutcome(
        config=config,
        scout=scout,
        adversary=adversary,
        minimized_scout_counterexample=counterexample,
        control=control,
        treatment=treatment,
        reference_validation=reference_validation,
        frozen_bundle=frozen_bundle,
        frozen_bundle_digest=frozen_bundle_digest,
        suite_digests=suite_digests,
        artifact_digests=artifact_digests,
    )
