from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple, Union

from scientist.core.artifacts import ArtifactStore
from scientist.domains.binpacking.generators import generate_suite
from scientist.domains.binpacking.programs import (
    ActionHybridProgram,
    Expression,
    FunSearchResidualProgram,
    HybridPolicyProgram,
    PriorityProgram,
)
from scientist.search.residual import (
    PairedPolicyReport,
    evaluate_paired_policy,
)


REPLICATION_VERSION = "three-island-finalist-replication-v1"
FrozenProgram = Union[
    PriorityProgram,
    FunSearchResidualProgram,
    HybridPolicyProgram,
    ActionHybridProgram,
]


@dataclass(frozen=True)
class CampaignReplicationConfig:
    replicate_count: int = 5
    instances_per_length: int = 40
    lengths: Tuple[int, ...] = (120, 250, 500)
    capacity: int = 150
    seed_start: int = 120_000_000
    replicate_seed_stride: int = 1_000_000
    sign_test_alpha: float = 0.01
    required_nonregressing_replicates: int = 4
    required_strictly_improving_replicates: int = 3

    def __post_init__(self) -> None:
        if min(
            self.replicate_count,
            self.instances_per_length,
            self.capacity,
            self.replicate_seed_stride,
        ) <= 0:
            raise ValueError("replication counts must be positive")
        if not self.lengths or min(self.lengths) <= 0:
            raise ValueError("replication lengths must be positive")
        if not 0.0 < self.sign_test_alpha < 1.0:
            raise ValueError("sign_test_alpha must be in (0, 1)")
        if not (
            0
            < self.required_nonregressing_replicates
            <= self.replicate_count
        ):
            raise ValueError("invalid nonregressing replicate requirement")
        if not (
            0
            < self.required_strictly_improving_replicates
            <= self.replicate_count
        ):
            raise ValueError("invalid improving replicate requirement")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "replicate_count": self.replicate_count,
            "instances_per_length": self.instances_per_length,
            "lengths": list(self.lengths),
            "capacity": self.capacity,
            "seed_start": self.seed_start,
            "replicate_seed_stride": self.replicate_seed_stride,
            "sign_test_alpha": self.sign_test_alpha,
            "required_nonregressing_replicates": (
                self.required_nonregressing_replicates
            ),
            "required_strictly_improving_replicates": (
                self.required_strictly_improving_replicates
            ),
        }


@dataclass(frozen=True)
class ReplicationBatch:
    replicate_index: int
    reports_by_length: Mapping[int, PairedPolicyReport]

    @property
    def pooled_delta(self) -> int:
        return sum(
            sum(report.deltas)
            for report in self.reports_by_length.values()
        )

    @property
    def wins(self) -> int:
        return sum(
            report.wins for report in self.reports_by_length.values()
        )

    @property
    def losses(self) -> int:
        return sum(
            report.losses for report in self.reports_by_length.values()
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "replicate_index": self.replicate_index,
            "pooled_delta": self.pooled_delta,
            "wins": self.wins,
            "losses": self.losses,
            "reports_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(
                    self.reports_by_length.items()
                )
            },
        }


def _combine_reports(
    reports: Sequence[PairedPolicyReport],
) -> PairedPolicyReport:
    if not reports:
        raise ValueError("cannot combine an empty report collection")
    candidate_names = {report.candidate_name for report in reports}
    incumbent_names = {report.incumbent_name for report in reports}
    if len(candidate_names) != 1 or len(incumbent_names) != 1:
        raise ValueError("reports do not compare the same policies")
    return PairedPolicyReport(
        candidate_name=reports[0].candidate_name,
        incumbent_name=reports[0].incumbent_name,
        instance_ids=tuple(
            instance_id
            for report in reports
            for instance_id in report.instance_ids
        ),
        deltas=tuple(
            delta for report in reports for delta in report.deltas
        ),
    )


def exact_one_sided_sign_test(
    wins: int,
    losses: int,
) -> float:
    """P(W >= observed wins | p=0.5), discarding paired ties."""

    if wins < 0 or losses < 0:
        raise ValueError("wins and losses must be non-negative")
    non_ties = wins + losses
    if non_ties == 0 or wins <= losses:
        return 1.0
    numerator = sum(
        math.comb(non_ties, successes)
        for successes in range(wins, non_ties + 1)
    )
    return numerator / float(2 ** non_ties)


@dataclass(frozen=True)
class CampaignReplicationOutcome:
    config: CampaignReplicationConfig
    source_campaign_digest: str
    candidate: FrozenProgram
    incumbent: FrozenProgram
    batches: Tuple[ReplicationBatch, ...]
    aggregate_by_length: Mapping[int, PairedPolicyReport]
    pooled_delta: int
    wins: int
    ties: int
    losses: int
    sign_test_p_value: float
    prediction_results: Mapping[str, bool]
    confirmed_generated_improvement: bool
    suite_digests: Mapping[str, str]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "replication_version": REPLICATION_VERSION,
            "config": self.config.as_dict(),
            "source_campaign_digest": self.source_campaign_digest,
            "candidate": self.candidate.as_dict(),
            "optimization_incumbent": self.incumbent.as_dict(),
            "batches": [batch.as_dict() for batch in self.batches],
            "aggregate_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(
                    self.aggregate_by_length.items()
                )
            },
            "pooled_delta": self.pooled_delta,
            "wins": self.wins,
            "ties": self.ties,
            "losses": self.losses,
            "sign_test_p_value": self.sign_test_p_value,
            "prediction_results": dict(
                sorted(self.prediction_results.items())
            ),
            "confirmed_generated_improvement": (
                self.confirmed_generated_improvement
            ),
            "suite_digests": dict(sorted(self.suite_digests.items())),
            "candidate_search_performed": False,
            "external_benchmark_opened": False,
        }


def run_campaign_replication(
    config: CampaignReplicationConfig,
    candidate: FrozenProgram,
    source_campaign_digest: str,
    artifact_store: Optional[ArtifactStore] = None,
    incumbent_program: Optional[FrozenProgram] = None,
) -> CampaignReplicationOutcome:
    incumbent: FrozenProgram = (
        incumbent_program
        if incumbent_program is not None
        else FunSearchResidualProgram(Expression.const(0.0), 0.10)
    )
    batches = []
    suite_digests: Dict[str, str] = {}
    for replicate_index in range(config.replicate_count):
        reports = {}
        for length_index, length in enumerate(config.lengths):
            seed_start = (
                config.seed_start
                + replicate_index * config.replicate_seed_stride
                + length_index * 100_000
            )
            suite = generate_suite(
                ("or_uniform",),
                range(
                    seed_start,
                    seed_start + config.instances_per_length,
                ),
                length,
                config.capacity,
            )
            reports[length] = evaluate_paired_policy(
                candidate,
                incumbent,
                suite,
            )
            if artifact_store is not None:
                suite_digests[
                    "replicate_%d_length_%d"
                    % (replicate_index, length)
                ] = artifact_store.put(
                    "three_island_finalist_replication_suite",
                    [instance.as_dict() for instance in suite],
                )
        batches.append(
            ReplicationBatch(
                replicate_index=replicate_index,
                reports_by_length=reports,
            )
        )
    aggregate_by_length = {
        length: _combine_reports(
            tuple(
                batch.reports_by_length[length]
                for batch in batches
            )
        )
        for length in config.lengths
    }
    aggregate = _combine_reports(
        tuple(aggregate_by_length[length] for length in config.lengths)
    )
    pooled_deltas = tuple(batch.pooled_delta for batch in batches)
    nonregressing = sum(delta <= 0 for delta in pooled_deltas)
    improving = sum(delta < 0 for delta in pooled_deltas)
    sign_test_p_value = exact_one_sided_sign_test(
        aggregate.wins,
        aggregate.losses,
    )
    prediction_results = {
        "strict_aggregate_improvement": sum(aggregate.deltas) < 0,
        "no_aggregate_scale_regression": all(
            sum(report.deltas) <= 0
            for report in aggregate_by_length.values()
        ),
        "replicate_nonregression": (
            nonregressing
            >= config.required_nonregressing_replicates
        ),
        "replicate_strict_improvement": (
            improving
            >= config.required_strictly_improving_replicates
        ),
        "paired_sign_test": (
            sign_test_p_value <= config.sign_test_alpha
        ),
    }
    return CampaignReplicationOutcome(
        config=config,
        source_campaign_digest=source_campaign_digest,
        candidate=candidate,
        incumbent=incumbent,
        batches=tuple(batches),
        aggregate_by_length=aggregate_by_length,
        pooled_delta=sum(aggregate.deltas),
        wins=aggregate.wins,
        ties=aggregate.ties,
        losses=aggregate.losses,
        sign_test_p_value=sign_test_p_value,
        prediction_results=prediction_results,
        confirmed_generated_improvement=all(
            prediction_results.values()
        ),
        suite_digests=suite_digests,
    )
