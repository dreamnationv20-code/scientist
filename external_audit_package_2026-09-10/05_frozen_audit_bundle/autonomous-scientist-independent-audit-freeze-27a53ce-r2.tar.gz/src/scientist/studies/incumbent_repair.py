from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.binpacking.adversary import (
    AdversaryConfig,
    AdversaryOutcome,
    evolve_adversarial_sequences,
    select_diverse_adversaries,
)
from scientist.domains.binpacking.counterexamples import (
    Counterexample,
    minimize_policy_gap,
)
from scientist.domains.binpacking.generators import generate_suite
from scientist.domains.binpacking.heuristics import (
    baseline_heuristics,
    literature_heuristics,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.programs import (
    Expression,
    FunSearchResidualProgram,
)
from scientist.search.residual import (
    PairedPolicyReport,
    ResidualRepairConfig,
    ResidualRepairOutcome,
    evaluate_paired_policy,
    run_residual_repair_search,
)


M31_STUDY_VERSION = "m3.1-incumbent-repair-v2"


@dataclass(frozen=True)
class IncumbentRepairConfig:
    capacity: int = 150
    length: int = 120
    guard_seed_start: int = 180_000
    guard_seed_count_per_length: int = 6
    audit_seed_start: int = 600_000
    audit_seed_count_per_length: int = 20
    minimum_audit_wins: int = 1
    validation_seed_start: int = 700_000
    validation_seed_count: int = 10
    validation_lengths: Tuple[int, ...] = (120, 250, 500)
    adversary_evaluation_budget: int = 200
    adversary_initial_population: int = 20
    repair_instance_count: int = 12
    candidate_evaluation_budget: int = 120
    adversary_seed: int = 47
    search_seed: int = 53
    residual_scale: float = 0.10
    guard_regression_fraction_ceiling: float = 0.0

    def __post_init__(self) -> None:
        if self.capacity != 150:
            raise ValueError("M3.1 uses the OR distribution at capacity 150")
        if min(
            self.length,
            self.guard_seed_count_per_length,
            self.audit_seed_count_per_length,
            self.validation_seed_count,
            self.adversary_evaluation_budget,
            self.adversary_initial_population,
            self.repair_instance_count,
            self.candidate_evaluation_budget,
        ) <= 0:
            raise ValueError("lengths, counts, and budgets must be positive")
        if not self.validation_lengths:
            raise ValueError("at least one validation length is required")
        if self.minimum_audit_wins <= 0:
            raise ValueError("minimum_audit_wins must be positive")
        if self.repair_instance_count > self.adversary_initial_population:
            raise ValueError(
                "repair_instance_count cannot exceed initial population"
            )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "capacity": self.capacity,
            "length": self.length,
            "guard_seed_start": self.guard_seed_start,
            "guard_seed_count_per_length": (
                self.guard_seed_count_per_length
            ),
            "audit_seed_start": self.audit_seed_start,
            "audit_seed_count_per_length": (
                self.audit_seed_count_per_length
            ),
            "minimum_audit_wins": self.minimum_audit_wins,
            "validation_seed_start": self.validation_seed_start,
            "validation_seed_count": self.validation_seed_count,
            "validation_lengths": list(self.validation_lengths),
            "adversary_evaluation_budget": self.adversary_evaluation_budget,
            "adversary_initial_population": self.adversary_initial_population,
            "repair_instance_count": self.repair_instance_count,
            "candidate_evaluation_budget": self.candidate_evaluation_budget,
            "adversary_seed": self.adversary_seed,
            "search_seed": self.search_seed,
            "residual_scale": self.residual_scale,
            "guard_regression_fraction_ceiling": (
                self.guard_regression_fraction_ceiling
            ),
        }


@dataclass(frozen=True)
class RepairArm:
    name: str
    repair_instance_ids: Tuple[str, ...]
    search: ResidualRepairOutcome
    audit_by_length: Mapping[int, PairedPolicyReport]
    promotion_passed: bool
    promoted_program: FunSearchResidualProgram
    validation_by_length: Mapping[int, PairedPolicyReport]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "repair_instance_ids": list(self.repair_instance_ids),
            "search": self.search.as_dict(),
            "proposed_candidate": self.search.best.program.as_dict(),
            "audit_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(self.audit_by_length.items())
            },
            "promotion_passed": self.promotion_passed,
            "promoted_candidate": self.promoted_program.as_dict(),
            "validation_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(
                    self.validation_by_length.items()
                )
            },
        }


@dataclass(frozen=True)
class IncumbentRepairOutcome:
    config: IncumbentRepairConfig
    adversary: AdversaryOutcome
    minimized_incumbent_counterexample: Optional[Counterexample]
    control: RepairArm
    treatment: RepairArm
    treatment_vs_control_by_length: Mapping[int, PairedPolicyReport]
    best_fit_vs_incumbent_by_length: Mapping[int, PairedPolicyReport]
    frozen_bundle: Mapping[str, Any]
    frozen_bundle_digest: str
    prediction_results: Mapping[str, bool]
    suite_digests: Mapping[str, str]
    artifact_digests: Mapping[str, str]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "study_version": M31_STUDY_VERSION,
            "config": self.config.as_dict(),
            "adversary": self.adversary.as_dict(),
            "minimized_incumbent_counterexample": (
                None
                if self.minimized_incumbent_counterexample is None
                else self.minimized_incumbent_counterexample.as_dict()
            ),
            "control": self.control.as_dict(),
            "treatment": self.treatment.as_dict(),
            "treatment_vs_control_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(
                    self.treatment_vs_control_by_length.items()
                )
            },
            "best_fit_vs_incumbent_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(
                    self.best_fit_vs_incumbent_by_length.items()
                )
            },
            "frozen_bundle": dict(self.frozen_bundle),
            "frozen_bundle_digest": self.frozen_bundle_digest,
            "prediction_results": dict(sorted(self.prediction_results.items())),
            "suite_digests": dict(sorted(self.suite_digests.items())),
            "artifact_digests": dict(sorted(self.artifact_digests.items())),
        }


def _suite(
    seed_start: int,
    seed_count: int,
    length: int,
    capacity: int,
) -> Tuple[BinPackingInstance, ...]:
    return generate_suite(
        ("or_uniform",),
        range(seed_start, seed_start + seed_count),
        length,
        capacity,
    )


def run_incumbent_repair_study(
    config: IncumbentRepairConfig,
    artifact_store: Optional[ArtifactStore] = None,
    source_provenance: Optional[Mapping[str, Any]] = None,
) -> IncumbentRepairOutcome:
    incumbent = literature_heuristics()["funsearch_or_reference"]
    best_fit = baseline_heuristics()["best_fit"]
    guard = tuple(
        instance
        for index, length in enumerate(config.validation_lengths)
        for instance in _suite(
            config.guard_seed_start + index * 1_000,
            config.guard_seed_count_per_length,
            length,
            config.capacity,
        )
    )
    validation_suites = {
        length: _suite(
            config.validation_seed_start + index * 10_000,
            config.validation_seed_count,
            length,
            config.capacity,
        )
        for index, length in enumerate(config.validation_lengths)
    }
    audit_suites = {
        length: _suite(
            config.audit_seed_start + index * 10_000,
            config.audit_seed_count_per_length,
            length,
            config.capacity,
        )
        for index, length in enumerate(config.validation_lengths)
    }
    adversary = evolve_adversarial_sequences(
        AdversaryConfig(
            seed=config.adversary_seed,
            evaluation_budget=config.adversary_evaluation_budget,
            initial_population=config.adversary_initial_population,
            length=config.length,
            capacity=config.capacity,
            minimum_item=20,
            maximum_item=100,
        ),
        incumbent,
        best_fit,
        artifact_store=artifact_store,
    )
    random_records = adversary.evaluated[: config.repair_instance_count]
    adversarial_records = select_diverse_adversaries(
        adversary,
        config.repair_instance_count,
        minimum_target_gap=1,
    )
    control_repair = tuple(record.instance for record in random_records)
    treatment_repair = tuple(
        record.instance for record in adversarial_records
    )
    search_config = ResidualRepairConfig(
        seed=config.search_seed,
        evaluation_budget=config.candidate_evaluation_budget,
        residual_scale=config.residual_scale,
        guard_mean_delta_ceiling=0.0,
        guard_regression_fraction_ceiling=(
            config.guard_regression_fraction_ceiling
        ),
        guard_max_regression=1,
    )
    control_search = run_residual_repair_search(
        search_config,
        control_repair,
        guard,
        incumbent,
        artifact_store,
    )
    treatment_search = run_residual_repair_search(
        search_config,
        treatment_repair,
        guard,
        incumbent,
        artifact_store,
    )

    incumbent_program = FunSearchResidualProgram(
        Expression.const(0.0),
        config.residual_scale,
    )

    def audit(
        search: ResidualRepairOutcome,
    ) -> Mapping[int, PairedPolicyReport]:
        return {
            length: evaluate_paired_policy(
                search.best.program,
                incumbent,
                suite,
            )
            for length, suite in audit_suites.items()
        }

    def promote(
        search: ResidualRepairOutcome,
        reports: Mapping[int, PairedPolicyReport],
    ) -> Tuple[bool, FunSearchResidualProgram]:
        if search.best.program.expression == Expression.const(0.0):
            return True, incumbent_program
        losses = sum(report.losses for report in reports.values())
        wins = sum(report.wins for report in reports.values())
        passed = losses == 0 and wins >= config.minimum_audit_wins
        return (
            passed,
            search.best.program if passed else incumbent_program,
        )

    control_audit = audit(control_search)
    treatment_audit = audit(treatment_search)
    control_passed, control_program = promote(
        control_search,
        control_audit,
    )
    treatment_passed, treatment_program = promote(
        treatment_search,
        treatment_audit,
    )

    frozen_bundle = {
        "schema": 1,
        "study_version": M31_STUDY_VERSION,
        "incumbent": "funsearch_or_reference",
        "candidate_roles": {
            "random_repair_control": control_program.as_dict(),
            "adversarial_repair_treatment": (
                treatment_program.as_dict()
            ),
        },
        "proposed_candidates": {
            "random_repair_control": control_search.best.program.as_dict(),
            "adversarial_repair_treatment": (
                treatment_search.best.program.as_dict()
            ),
        },
        "promotion_audit": {
            "instances_per_length": config.audit_seed_count_per_length,
            "minimum_wins": config.minimum_audit_wins,
            "maximum_losses": 0,
            "control_passed": control_passed,
            "treatment_passed": treatment_passed,
        },
        "promotion_contract": {
            "guard_mean_delta_ceiling": 0.0,
            "guard_regression_fraction_ceiling": (
                config.guard_regression_fraction_ceiling
            ),
            "guard_max_regression": 1,
            "candidate_evaluations_per_arm": (
                config.candidate_evaluation_budget
            ),
            "repair_instances_per_arm": config.repair_instance_count,
        },
        "validation_contract": {
            "distribution": "generated integer uniform [20, 100]",
            "capacity": config.capacity,
            "lengths": list(config.validation_lengths),
            "instances_per_length": config.validation_seed_count,
            "external_confirmation": False,
            "reason": "OR-Library was opened in M3 and is diagnostic only",
        },
        "preregistered_predictions": [
            {
                "id": "treatment_non_regression_all_lengths",
                "comparison": (
                    "treatment mean bin delta vs FunSearch <= 0 "
                    "at every validation length"
                ),
            },
            {
                "id": "treatment_strict_pooled_improvement",
                "comparison": (
                    "sum of treatment bin deltas vs FunSearch < 0 "
                    "over all validation instances"
                ),
            },
            {
                "id": "treatment_beats_control_pooled",
                "comparison": (
                    "sum of treatment bins minus control bins < 0 "
                    "over all validation instances"
                ),
            },
        ],
        "source_provenance": dict(source_provenance or {}),
    }
    frozen_bundle_digest = content_digest(frozen_bundle)

    def validation(
        program: FunSearchResidualProgram,
    ) -> Mapping[int, PairedPolicyReport]:
        return {
            length: evaluate_paired_policy(
                program,
                incumbent,
                suite,
            )
            for length, suite in validation_suites.items()
        }

    control_validation = validation(control_program)
    treatment_validation = validation(treatment_program)
    treatment_vs_control = {
        length: evaluate_paired_policy(
            treatment_program,
            control_program,
            suite,
        )
        for length, suite in validation_suites.items()
    }
    best_fit_validation = {
        length: evaluate_paired_policy(
            best_fit,
            incumbent,
            suite,
        )
        for length, suite in validation_suites.items()
    }
    control = RepairArm(
        name="random_repair_control",
        repair_instance_ids=tuple(
            record.instance.instance_id for record in random_records
        ),
        search=control_search,
        audit_by_length=control_audit,
        promotion_passed=control_passed,
        promoted_program=control_program,
        validation_by_length=control_validation,
    )
    treatment = RepairArm(
        name="adversarial_repair_treatment",
        repair_instance_ids=tuple(
            record.instance.instance_id
            for record in adversarial_records
        ),
        search=treatment_search,
        audit_by_length=treatment_audit,
        promotion_passed=treatment_passed,
        promoted_program=treatment_program,
        validation_by_length=treatment_validation,
    )
    minimized = None
    if adversary.best.target_gap > 0:
        minimized = minimize_policy_gap(
            adversary.best.instance,
            best_fit,
            incumbent,
        )

    treatment_delta_sum = sum(
        sum(report.deltas) for report in treatment_validation.values()
    )
    treatment_control_delta_sum = sum(
        sum(report.deltas) for report in treatment_vs_control.values()
    )
    prediction_results = {
        "treatment_non_regression_all_lengths": all(
            report.mean_delta <= 0.0
            for report in treatment_validation.values()
        ),
        "treatment_strict_pooled_improvement": treatment_delta_sum < 0,
        "treatment_beats_control_pooled": treatment_control_delta_sum < 0,
    }
    suite_digests: Dict[str, str] = {}
    artifact_digests: Dict[str, str] = {}
    if artifact_store is not None:
        suite_digests["guard"] = artifact_store.put(
            "m31_guard_suite",
            [instance.as_dict() for instance in guard],
        )
        suite_digests["control_repair"] = artifact_store.put(
            "m31_control_repair_suite",
            [instance.as_dict() for instance in control_repair],
        )
        suite_digests["treatment_repair"] = artifact_store.put(
            "m31_treatment_repair_suite",
            [instance.as_dict() for instance in treatment_repair],
        )
        for length, suite in validation_suites.items():
            suite_digests["validation_%d" % length] = artifact_store.put(
                "m31_validation_suite",
                [instance.as_dict() for instance in suite],
            )
        for length, suite in audit_suites.items():
            suite_digests["audit_%d" % length] = artifact_store.put(
                "m31_promotion_audit_suite",
                [instance.as_dict() for instance in suite],
            )
        artifact_digests["adversary"] = artifact_store.put(
            "m31_adversary_summary",
            adversary.as_dict(),
        )
        artifact_digests["frozen_bundle"] = artifact_store.put(
            "m31_frozen_generated_validation_bundle",
            frozen_bundle,
        )
        if minimized is not None:
            artifact_digests["counterexample"] = artifact_store.put(
                "m31_minimized_incumbent_counterexample",
                minimized.as_dict(),
            )

    return IncumbentRepairOutcome(
        config=config,
        adversary=adversary,
        minimized_incumbent_counterexample=minimized,
        control=control,
        treatment=treatment,
        treatment_vs_control_by_length=treatment_vs_control,
        best_fit_vs_incumbent_by_length=best_fit_validation,
        frozen_bundle=frozen_bundle,
        frozen_bundle_digest=frozen_bundle_digest,
        prediction_results=prediction_results,
        suite_digests=suite_digests,
        artifact_digests=artifact_digests,
    )
