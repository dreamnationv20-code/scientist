from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import ArtifactStore
from scientist.domains.binpacking.equivalence import behaviour_fingerprint
from scientist.domains.binpacking.evaluator import (
    EvaluationReport,
    evaluate_heuristic,
    prepare_references,
)
from scientist.domains.binpacking.failure_regimes import (
    FailureRegimeReport,
    TargetedSeed,
    discover_failure_regimes,
    generate_targeted_seeds,
)
from scientist.domains.binpacking.generators import generate_suite
from scientist.domains.binpacking.heuristics import (
    baseline_heuristics,
    literature_heuristics,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.search.evolution import (
    SearchConfig,
    SearchOutcome,
    run_evolutionary_search,
)


@dataclass(frozen=True)
class MatchedRegimeSearchConfig:
    families: Tuple[str, ...]
    length: int = 14
    validation_length: Optional[int] = None
    sealed_length: Optional[int] = None
    capacity: int = 100
    reference_mode: str = "exact"
    development_seed_start: int = 0
    development_seed_count: int = 6
    validation_seed_start: int = 70_000
    validation_seed_count: int = 6
    sealed_seed_start: int = 80_000
    sealed_seed_count: int = 12
    equivalence_seed_start: int = 90_000
    equivalence_seed_count: int = 8
    equivalence_length: int = 40
    evaluation_budget: int = 200
    search_seed: int = 0
    regime_emphasis: float = 3.0
    maximum_targeted_seeds: int = 24

    def __post_init__(self) -> None:
        if not self.families:
            raise ValueError("at least one family is required")
        if self.length <= 0 or self.capacity <= 0:
            raise ValueError("length and capacity must be positive")
        if self.validation_length is not None and self.validation_length <= 0:
            raise ValueError("validation_length must be positive")
        if self.sealed_length is not None and self.sealed_length <= 0:
            raise ValueError("sealed_length must be positive")
        if self.reference_mode not in ("exact", "volume_lower_bound"):
            raise ValueError("unknown reference_mode")
        if min(
            self.development_seed_count,
            self.validation_seed_count,
            self.sealed_seed_count,
            self.equivalence_seed_count,
            self.evaluation_budget,
        ) <= 0:
            raise ValueError("suite counts and budget must be positive")
        if self.regime_emphasis < 0.0:
            raise ValueError("regime_emphasis must be non-negative")
        if self.maximum_targeted_seeds < 0:
            raise ValueError("maximum_targeted_seeds must be non-negative")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "families": list(self.families),
            "length": self.length,
            "validation_length": self.validation_length,
            "sealed_length": self.sealed_length,
            "capacity": self.capacity,
            "reference_mode": self.reference_mode,
            "development_seed_start": self.development_seed_start,
            "development_seed_count": self.development_seed_count,
            "validation_seed_start": self.validation_seed_start,
            "validation_seed_count": self.validation_seed_count,
            "sealed_seed_start": self.sealed_seed_start,
            "sealed_seed_count": self.sealed_seed_count,
            "equivalence_seed_start": self.equivalence_seed_start,
            "equivalence_seed_count": self.equivalence_seed_count,
            "equivalence_length": self.equivalence_length,
            "evaluation_budget": self.evaluation_budget,
            "search_seed": self.search_seed,
            "regime_emphasis": self.regime_emphasis,
            "maximum_targeted_seeds": self.maximum_targeted_seeds,
        }


@dataclass(frozen=True)
class MethodResult:
    method: str
    search: SearchOutcome
    validation: EvaluationReport
    sealed: EvaluationReport
    equivalent_baselines: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "method": self.method,
            "search": self.search.as_dict(),
            "candidate": self.search.best.program.as_dict(),
            "validation": self.validation.as_dict(),
            "sealed": self.sealed.as_dict(),
            "equivalent_baselines": list(self.equivalent_baselines),
        }


@dataclass(frozen=True)
class MatchedRegimeSearchOutcome:
    config: MatchedRegimeSearchConfig
    failure_report: FailureRegimeReport
    targeted_seeds: Tuple[TargetedSeed, ...]
    target_weights: Mapping[str, float]
    baseline: MethodResult
    targeted: MethodResult
    best_fit_validation: EvaluationReport
    best_fit_sealed: EvaluationReport
    known_reference_validation: Mapping[str, EvaluationReport]
    known_reference_sealed: Mapping[str, EvaluationReport]
    suite_digests: Mapping[str, str]
    artifact_digests: Mapping[str, str]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "config": self.config.as_dict(),
            "failure_report": self.failure_report.as_dict(),
            "targeted_seeds": [seed.as_dict() for seed in self.targeted_seeds],
            "target_weights": dict(sorted(self.target_weights.items())),
            "baseline": self.baseline.as_dict(),
            "targeted": self.targeted.as_dict(),
            "best_fit_validation": self.best_fit_validation.as_dict(),
            "best_fit_sealed": self.best_fit_sealed.as_dict(),
            "known_reference_validation": {
                name: report.as_dict()
                for name, report in sorted(
                    self.known_reference_validation.items()
                )
            },
            "known_reference_sealed": {
                name: report.as_dict()
                for name, report in sorted(
                    self.known_reference_sealed.items()
                )
            },
            "suite_digests": dict(sorted(self.suite_digests.items())),
            "artifact_digests": dict(sorted(self.artifact_digests.items())),
        }


def _suite(
    config: MatchedRegimeSearchConfig,
    seed_start: int,
    seed_count: int,
    length: Optional[int] = None,
) -> Tuple[BinPackingInstance, ...]:
    return generate_suite(
        families=config.families,
        seeds=range(seed_start, seed_start + seed_count),
        length=config.length if length is None else length,
        capacity=config.capacity,
    )


def run_matched_regime_search(
    config: MatchedRegimeSearchConfig,
    artifact_store: Optional[ArtifactStore] = None,
) -> MatchedRegimeSearchOutcome:
    development = _suite(
        config,
        config.development_seed_start,
        config.development_seed_count,
    )
    validation = _suite(
        config,
        config.validation_seed_start,
        config.validation_seed_count,
        config.validation_length,
    )
    sealed = _suite(
        config,
        config.sealed_seed_start,
        config.sealed_seed_count,
        config.sealed_length,
    )
    equivalence = _suite(
        config,
        config.equivalence_seed_start,
        config.equivalence_seed_count,
        max(config.length, config.equivalence_length),
    )
    suites = {
        "development": development,
        "validation": validation,
        "sealed": sealed,
        "equivalence": equivalence,
    }
    suite_digests: Dict[str, str] = {}
    artifact_digests: Dict[str, str] = {}
    if artifact_store is not None:
        for name, instances in suites.items():
            suite_digests[name] = artifact_store.put(
                "%s_instance_suite" % name,
                [instance.as_dict() for instance in instances],
            )

    development_optima = prepare_references(
        development,
        config.reference_mode,
    )
    validation_optima = prepare_references(
        validation,
        config.reference_mode,
    )
    sealed_optima = prepare_references(
        sealed,
        config.reference_mode,
    )
    best_fit = baseline_heuristics()["best_fit"]
    failure_report = discover_failure_regimes(
        best_fit,
        development,
        development_optima,
        reference_mode=config.reference_mode,
    )
    target_weights = failure_report.target_weights(config.regime_emphasis)
    targeted_seeds = generate_targeted_seeds(
        failure_report,
        config.maximum_targeted_seeds,
    )
    if artifact_store is not None:
        artifact_digests["failure_regimes"] = artifact_store.put(
            "failure_regime_report",
            failure_report.as_dict(),
        )
        artifact_digests["targeted_seeds"] = artifact_store.put(
            "regime_targeted_seed_set",
            [seed.as_dict() for seed in targeted_seeds],
        )
        artifact_digests["target_weights"] = artifact_store.put(
            "development_instance_weights",
            target_weights,
        )

    search_config = SearchConfig(
        seed=config.search_seed,
        evaluation_budget=config.evaluation_budget,
        max_expression_depth=10,
        max_expression_nodes=63,
        reference_mode=config.reference_mode,
        record_placements=config.reference_mode == "exact",
    )
    baseline_search = run_evolutionary_search(
        search_config,
        development,
        artifact_store=artifact_store,
    )
    targeted_search = run_evolutionary_search(
        search_config,
        development,
        artifact_store=artifact_store,
        additional_seed_programs=(
            seed.program for seed in targeted_seeds
        ),
        instance_weights=target_weights,
        global_mean_ceiling=failure_report.evaluator_report.mean_regret,
        global_constraint_penalty=10.0,
    )

    baselines = baseline_heuristics()
    known_heuristics = {**baselines, **literature_heuristics()}
    baseline_fingerprints = {
        name: behaviour_fingerprint(heuristic, equivalence)
        for name, heuristic in known_heuristics.items()
    }

    def result(method: str, search: SearchOutcome) -> MethodResult:
        candidate_fingerprint = behaviour_fingerprint(
            search.best.program,
            equivalence,
        )
        return MethodResult(
            method=method,
            search=search,
            validation=evaluate_heuristic(
                search.best.program,
                validation,
                optima=validation_optima,
                reference_mode=config.reference_mode,
                include_placements=config.reference_mode == "exact",
            ),
            sealed=evaluate_heuristic(
                search.best.program,
                sealed,
                optima=sealed_optima,
                reference_mode=config.reference_mode,
                include_placements=config.reference_mode == "exact",
            ),
            equivalent_baselines=tuple(
                sorted(
                    name
                    for name, fingerprint in baseline_fingerprints.items()
                    if fingerprint == candidate_fingerprint
                )
            ),
        )

    baseline_result = result("m1_unweighted", baseline_search)
    targeted_result = result("m2_regime_targeted", targeted_search)
    best_fit_validation = evaluate_heuristic(
        best_fit,
        validation,
        optima=validation_optima,
        reference_mode=config.reference_mode,
        include_placements=config.reference_mode == "exact",
    )
    best_fit_sealed = evaluate_heuristic(
        best_fit,
        sealed,
        optima=sealed_optima,
        reference_mode=config.reference_mode,
        include_placements=config.reference_mode == "exact",
    )
    known_reference_validation = {
        name: evaluate_heuristic(
            heuristic,
            validation,
            optima=validation_optima,
            reference_mode=config.reference_mode,
            include_placements=config.reference_mode == "exact",
        )
        for name, heuristic in literature_heuristics().items()
    }
    known_reference_sealed = {
        name: evaluate_heuristic(
            heuristic,
            sealed,
            optima=sealed_optima,
            reference_mode=config.reference_mode,
            include_placements=config.reference_mode == "exact",
        )
        for name, heuristic in literature_heuristics().items()
    }
    if artifact_store is not None:
        for method_result in (baseline_result, targeted_result):
            artifact_digests[
                "%s_validation" % method_result.method
            ] = artifact_store.put(
                "matched_search_validation_report",
                method_result.validation.as_dict(),
            )
            artifact_digests[
                "%s_sealed" % method_result.method
            ] = artifact_store.put(
                "matched_search_sealed_report",
                method_result.sealed.as_dict(),
            )

    return MatchedRegimeSearchOutcome(
        config=config,
        failure_report=failure_report,
        targeted_seeds=targeted_seeds,
        target_weights=target_weights,
        baseline=baseline_result,
        targeted=targeted_result,
        best_fit_validation=best_fit_validation,
        best_fit_sealed=best_fit_sealed,
        known_reference_validation=known_reference_validation,
        known_reference_sealed=known_reference_sealed,
        suite_digests=suite_digests,
        artifact_digests=artifact_digests,
    )
