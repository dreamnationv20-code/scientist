from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from scientist.core.artifacts import ArtifactStore
from scientist.studies.incumbent_repair import (
    IncumbentRepairConfig,
    IncumbentRepairOutcome,
    run_incumbent_repair_study,
)


REPLICATION_VERSION = "m3.1-repair-replication-v2"


@dataclass(frozen=True)
class RepairReplicationConfig:
    replicate_count: int = 3
    guard_seed_start: int = 300_000
    audit_seed_start: int = 600_000
    validation_seed_start: int = 700_000
    seed_stride: int = 50_000
    adversary_seed_start: int = 101
    search_seed_start: int = 211
    length: int = 120
    guard_seed_count_per_length: int = 6
    audit_seed_count_per_length: int = 20
    validation_seed_count: int = 10
    validation_lengths: Tuple[int, ...] = (120, 250, 500)
    adversary_evaluation_budget: int = 200
    adversary_initial_population: int = 20
    repair_instance_count: int = 12
    candidate_evaluation_budget: int = 120
    residual_scale: float = 0.10

    def __post_init__(self) -> None:
        if self.replicate_count <= 0:
            raise ValueError("replicate_count must be positive")
        if self.seed_stride <= 0:
            raise ValueError("seed_stride must be positive")

    def as_dict(self) -> Dict[str, Any]:
        return {
            "replicate_count": self.replicate_count,
            "guard_seed_start": self.guard_seed_start,
            "audit_seed_start": self.audit_seed_start,
            "validation_seed_start": self.validation_seed_start,
            "seed_stride": self.seed_stride,
            "adversary_seed_start": self.adversary_seed_start,
            "search_seed_start": self.search_seed_start,
            "length": self.length,
            "guard_seed_count_per_length": (
                self.guard_seed_count_per_length
            ),
            "audit_seed_count_per_length": (
                self.audit_seed_count_per_length
            ),
            "validation_seed_count": self.validation_seed_count,
            "validation_lengths": list(self.validation_lengths),
            "adversary_evaluation_budget": self.adversary_evaluation_budget,
            "adversary_initial_population": self.adversary_initial_population,
            "repair_instance_count": self.repair_instance_count,
            "candidate_evaluation_budget": self.candidate_evaluation_budget,
            "residual_scale": self.residual_scale,
        }


@dataclass(frozen=True)
class RepairReplicationOutcome:
    config: RepairReplicationConfig
    replicates: Tuple[IncumbentRepairOutcome, ...]
    pooled_treatment_deltas: Tuple[int, ...]
    pooled_control_deltas: Tuple[int, ...]
    aggregate_prediction_results: Mapping[str, bool]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "replication_version": REPLICATION_VERSION,
            "config": self.config.as_dict(),
            "replicate_summaries": [
                {
                    "replicate_index": index,
                    "candidate_id": (
                        outcome.treatment.promoted_program.candidate_id
                    ),
                    "candidate": (
                        outcome.treatment.promoted_program.as_dict()
                    ),
                    "proposed_candidate": (
                        outcome.treatment.search.best.program.as_dict()
                    ),
                    "promotion_passed": outcome.treatment.promotion_passed,
                    "promotion_audit": {
                        "wins": sum(
                            report.wins
                            for report in outcome.treatment
                            .audit_by_length.values()
                        ),
                        "ties": sum(
                            report.ties
                            for report in outcome.treatment
                            .audit_by_length.values()
                        ),
                        "losses": sum(
                            report.losses
                            for report in outcome.treatment
                            .audit_by_length.values()
                        ),
                        "by_length": {
                            str(length): report.as_dict()
                            for length, report in sorted(
                                outcome.treatment.audit_by_length.items()
                            )
                        },
                    },
                    "pooled_treatment_delta": (
                        self.pooled_treatment_deltas[index]
                    ),
                    "pooled_control_delta": self.pooled_control_deltas[index],
                    "prediction_results": dict(
                        sorted(outcome.prediction_results.items())
                    ),
                    "frozen_bundle_digest": outcome.frozen_bundle_digest,
                    "suite_digests": dict(
                        sorted(outcome.suite_digests.items())
                    ),
                    "artifact_digests": dict(
                        sorted(outcome.artifact_digests.items())
                    ),
                }
                for index, outcome in enumerate(self.replicates)
            ],
            "pooled_treatment_deltas": list(self.pooled_treatment_deltas),
            "pooled_control_deltas": list(self.pooled_control_deltas),
            "aggregate_treatment_delta": sum(
                self.pooled_treatment_deltas
            ),
            "aggregate_control_delta": sum(self.pooled_control_deltas),
            "strictly_improving_replicates": sum(
                delta < 0 for delta in self.pooled_treatment_deltas
            ),
            "non_regressing_replicates": sum(
                delta <= 0 for delta in self.pooled_treatment_deltas
            ),
            "aggregate_prediction_results": dict(
                sorted(self.aggregate_prediction_results.items())
            ),
        }


def _pooled_delta(
    outcome: IncumbentRepairOutcome,
    arm: str,
) -> int:
    reports = (
        outcome.treatment.validation_by_length
        if arm == "treatment"
        else outcome.control.validation_by_length
    )
    return sum(
        sum(report.deltas) for report in reports.values()
    )


def run_repair_replication(
    config: RepairReplicationConfig,
    artifact_store: Optional[ArtifactStore] = None,
    source_provenance: Optional[Mapping[str, Any]] = None,
) -> RepairReplicationOutcome:
    outcomes = []
    for index in range(config.replicate_count):
        outcomes.append(
            run_incumbent_repair_study(
                IncumbentRepairConfig(
                    length=config.length,
                    guard_seed_start=(
                        config.guard_seed_start + index * config.seed_stride
                    ),
                    guard_seed_count_per_length=(
                        config.guard_seed_count_per_length
                    ),
                    audit_seed_start=(
                        config.audit_seed_start + index * config.seed_stride
                    ),
                    audit_seed_count_per_length=(
                        config.audit_seed_count_per_length
                    ),
                    validation_seed_start=(
                        config.validation_seed_start
                        + index * config.seed_stride
                    ),
                    validation_seed_count=config.validation_seed_count,
                    validation_lengths=config.validation_lengths,
                    adversary_evaluation_budget=(
                        config.adversary_evaluation_budget
                    ),
                    adversary_initial_population=(
                        config.adversary_initial_population
                    ),
                    repair_instance_count=config.repair_instance_count,
                    candidate_evaluation_budget=(
                        config.candidate_evaluation_budget
                    ),
                    adversary_seed=(
                        config.adversary_seed_start + index * 997
                    ),
                    search_seed=config.search_seed_start + index * 991,
                    residual_scale=config.residual_scale,
                    guard_regression_fraction_ceiling=0.0,
                ),
                artifact_store=artifact_store,
                source_provenance=source_provenance,
            )
        )
    outcome_tuple = tuple(outcomes)
    treatment_deltas = tuple(
        _pooled_delta(outcome, "treatment")
        for outcome in outcome_tuple
    )
    control_deltas = tuple(
        _pooled_delta(outcome, "control")
        for outcome in outcome_tuple
    )
    treatment_control_deltas = tuple(
        treatment - control
        for treatment, control in zip(treatment_deltas, control_deltas)
    )
    aggregate_predictions = {
        "all_replicates_non_regressing": all(
            delta <= 0 for delta in treatment_deltas
        ),
        "majority_replicates_strictly_improve": (
            sum(delta < 0 for delta in treatment_deltas)
            > config.replicate_count / 2.0
        ),
        "aggregate_treatment_strictly_improves": sum(treatment_deltas) < 0,
        "aggregate_treatment_beats_control": (
            sum(treatment_control_deltas) < 0
        ),
    }
    return RepairReplicationOutcome(
        config=config,
        replicates=outcome_tuple,
        pooled_treatment_deltas=treatment_deltas,
        pooled_control_deltas=control_deltas,
        aggregate_prediction_results=aggregate_predictions,
    )
