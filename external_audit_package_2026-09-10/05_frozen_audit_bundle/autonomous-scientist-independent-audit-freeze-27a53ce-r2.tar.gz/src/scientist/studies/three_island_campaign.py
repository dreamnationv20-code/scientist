from __future__ import annotations

from dataclasses import dataclass
from statistics import mean
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from scientist.core.artifacts import ArtifactStore, content_digest
from scientist.domains.binpacking.adversary import (
    AdversaryConfig,
    AdversaryOutcome,
    AdversarialSequenceRecord,
    evolve_adversarial_sequences,
)
from scientist.domains.binpacking.counterexamples import (
    Counterexample,
    minimize_policy_gap,
)
from scientist.domains.binpacking.equivalence import behaviour_fingerprint
from scientist.domains.binpacking.generators import generate_instance, generate_suite
from scientist.domains.binpacking.heuristics import (
    OnlineHeuristic,
    baseline_heuristics,
    literature_heuristics,
    pack,
)
from scientist.domains.binpacking.models import BinPackingInstance
from scientist.domains.binpacking.programs import (
    ActionHybridProgram,
    Expression,
    FunSearchResidualProgram,
    PriorityProgram,
)
from scientist.search.islands import (
    ISLAND_NAMES,
    IslandCandidateRecord,
    IslandSearchConfig,
    IslandSearchOutcome,
    SearchProgram,
    StructuredEvolutionProposer,
    run_island_search,
)
from scientist.search.residual import PairedPolicyReport, evaluate_paired_policy


CAMPAIGN_VERSION = "m3.2-three-island-autonomous-campaign-v3"
ProgressCallback = Callable[[str], None]


@dataclass(frozen=True)
class ThreeIslandCampaignConfig:
    rounds: int = 6
    capacity: int = 150
    length: int = 120
    candidate_budget_per_island: int = 40
    initial_random_candidates: int = 6
    adversary_budget_per_round: int = 80
    adversary_initial_population: int = 12
    repair_instance_count: int = 12
    motif_variant_count: int = 12
    carry_elites_per_island: int = 6
    comparator_scout_count: int = 20
    comparator_probe_count: int = 12
    guard_seed_count_per_length: int = 4
    audit_seed_count_per_length: int = 8
    validation_seed_count_per_length: int = 20
    validation_lengths: Tuple[int, ...] = (120, 250, 500)
    minimum_audit_wins: int = 1
    nomination_minimum_audit_wins: int = 2
    nomination_maximum_regression: int = 1
    base_seed: int = 1_000
    residual_scale: float = 0.10
    guard_regression_fraction_ceiling: float = 0.0

    def __post_init__(self) -> None:
        positive = (
            self.rounds,
            self.capacity,
            self.length,
            self.candidate_budget_per_island,
            self.adversary_budget_per_round,
            self.adversary_initial_population,
            self.repair_instance_count,
            self.comparator_scout_count,
            self.comparator_probe_count,
            self.guard_seed_count_per_length,
            self.audit_seed_count_per_length,
            self.validation_seed_count_per_length,
        )
        if min(positive) <= 0:
            raise ValueError("campaign counts and budgets must be positive")
        if self.initial_random_candidates < 0:
            raise ValueError("initial_random_candidates must be non-negative")
        if self.motif_variant_count < 0:
            raise ValueError("motif_variant_count must be non-negative")
        if self.carry_elites_per_island < 0:
            raise ValueError("carry_elites_per_island must be non-negative")
        if self.adversary_initial_population > self.adversary_budget_per_round:
            raise ValueError("adversary initial population exceeds budget")
        if not self.validation_lengths:
            raise ValueError("validation_lengths must not be empty")
        if self.minimum_audit_wins <= 0:
            raise ValueError("minimum_audit_wins must be positive")
        if self.nomination_minimum_audit_wins <= 0:
            raise ValueError(
                "nomination_minimum_audit_wins must be positive"
            )
        if self.nomination_maximum_regression < 0:
            raise ValueError(
                "nomination_maximum_regression must be non-negative"
            )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "rounds": self.rounds,
            "capacity": self.capacity,
            "length": self.length,
            "candidate_budget_per_island": self.candidate_budget_per_island,
            "initial_random_candidates": self.initial_random_candidates,
            "adversary_budget_per_round": self.adversary_budget_per_round,
            "adversary_initial_population": self.adversary_initial_population,
            "repair_instance_count": self.repair_instance_count,
            "motif_variant_count": self.motif_variant_count,
            "carry_elites_per_island": self.carry_elites_per_island,
            "comparator_scout_count": self.comparator_scout_count,
            "comparator_probe_count": self.comparator_probe_count,
            "guard_seed_count_per_length": (
                self.guard_seed_count_per_length
            ),
            "audit_seed_count_per_length": (
                self.audit_seed_count_per_length
            ),
            "validation_seed_count_per_length": (
                self.validation_seed_count_per_length
            ),
            "validation_lengths": list(self.validation_lengths),
            "minimum_audit_wins": self.minimum_audit_wins,
            "nomination_minimum_audit_wins": (
                self.nomination_minimum_audit_wins
            ),
            "nomination_maximum_regression": (
                self.nomination_maximum_regression
            ),
            "base_seed": self.base_seed,
            "residual_scale": self.residual_scale,
            "guard_regression_fraction_ceiling": (
                self.guard_regression_fraction_ceiling
            ),
        }


@dataclass(frozen=True)
class ComparatorSelection:
    selected_name: str
    selected_behavior_fingerprint: str
    prior_selection_count: int
    distinct_challenger_behaviors: int
    candidate_scores: Mapping[str, int]
    scout_instance_ids: Tuple[str, ...]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "selected_name": self.selected_name,
            "selected_behavior_fingerprint": (
                self.selected_behavior_fingerprint
            ),
            "prior_selection_count": self.prior_selection_count,
            "distinct_challenger_behaviors": (
                self.distinct_challenger_behaviors
            ),
            "candidate_funsearch_gap_sums": dict(
                sorted(self.candidate_scores.items())
            ),
            "scout_instance_ids": list(self.scout_instance_ids),
        }


@dataclass(frozen=True)
class RoundIslandResult:
    search: IslandSearchOutcome
    audit_by_length: Mapping[int, PairedPolicyReport]
    promotion_passed: bool
    promotion_reason: str
    deployed_program: SearchProgram
    replication_nominated: bool
    nomination_reason: str

    @property
    def audit_wins(self) -> int:
        return sum(report.wins for report in self.audit_by_length.values())

    @property
    def audit_losses(self) -> int:
        return sum(report.losses for report in self.audit_by_length.values())

    @property
    def pooled_audit_delta(self) -> int:
        return sum(
            sum(report.deltas) for report in self.audit_by_length.values()
        )

    def as_dict(self) -> Dict[str, Any]:
        return {
            "search": self.search.as_dict(),
            "proposed_candidate": self.search.best.program.as_dict(),
            "audit_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(self.audit_by_length.items())
            },
            "audit_wins": self.audit_wins,
            "audit_losses": self.audit_losses,
            "pooled_audit_delta": self.pooled_audit_delta,
            "promotion_passed": self.promotion_passed,
            "promotion_reason": self.promotion_reason,
            "deployed_candidate": self.deployed_program.as_dict(),
            "replication_nominated": self.replication_nominated,
            "nomination_reason": self.nomination_reason,
        }


@dataclass(frozen=True)
class CampaignRound:
    round_index: int
    comparator_selection: ComparatorSelection
    adversary: AdversaryOutcome
    minimized_counterexample: Optional[Counterexample]
    motif_variants_tested: int
    motif_variants_with_positive_gap: int
    positive_adversary_count: int
    repair_instance_ids: Tuple[str, ...]
    islands: Mapping[str, RoundIslandResult]
    suite_digests: Mapping[str, str]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "round_index": self.round_index,
            "comparator_selection": self.comparator_selection.as_dict(),
            "adversary": self.adversary.as_dict(),
            "minimized_counterexample": (
                None
                if self.minimized_counterexample is None
                else self.minimized_counterexample.as_dict()
            ),
            "motif_variants_tested": self.motif_variants_tested,
            "motif_variants_with_positive_gap": (
                self.motif_variants_with_positive_gap
            ),
            "positive_adversary_count": self.positive_adversary_count,
            "repair_instance_ids": list(self.repair_instance_ids),
            "islands": {
                name: self.islands[name].as_dict()
                for name in ISLAND_NAMES
            },
            "suite_digests": dict(sorted(self.suite_digests.items())),
        }


@dataclass(frozen=True)
class ThreeIslandCampaignOutcome:
    config: ThreeIslandCampaignConfig
    proposer_name: str
    incumbent_program: SearchProgram
    rounds: Tuple[CampaignRound, ...]
    finalist_island: str
    finalist_program: SearchProgram
    finalist_source_round: Optional[int]
    validation_by_length: Mapping[int, PairedPolicyReport]
    island_finalists: Mapping[str, SearchProgram]
    island_validation_by_length: Mapping[
        str,
        Mapping[int, PairedPolicyReport],
    ]
    best_fit_validation_by_length: Mapping[int, PairedPolicyReport]
    provisional_breakthrough: bool
    replication_recommended: bool
    breakthrough_reasons: Tuple[str, ...]
    validation_suite_digests: Mapping[str, str]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": 1,
            "campaign_version": CAMPAIGN_VERSION,
            "config": self.config.as_dict(),
            "proposer": self.proposer_name,
            "optimization_incumbent": self.incumbent_program.as_dict(),
            "outer_round_count": len(self.rounds),
            "rounds": [round_.as_dict() for round_ in self.rounds],
            "finalist_island": self.finalist_island,
            "finalist_source_round": self.finalist_source_round,
            "finalist": self.finalist_program.as_dict(),
            "validation_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(
                    self.validation_by_length.items()
                )
            },
            "island_finalists": {
                island: program.as_dict()
                for island, program in sorted(
                    self.island_finalists.items()
                )
            },
            "island_validation_by_length": {
                island: {
                    str(length): report.as_dict()
                    for length, report in sorted(reports.items())
                }
                for island, reports in sorted(
                    self.island_validation_by_length.items()
                )
            },
            "best_fit_validation_by_length": {
                str(length): report.as_dict()
                for length, report in sorted(
                    self.best_fit_validation_by_length.items()
                )
            },
            "provisional_breakthrough": self.provisional_breakthrough,
            "replication_recommended": self.replication_recommended,
            "breakthrough_reasons": list(self.breakthrough_reasons),
            "validation_suite_digests": dict(
                sorted(self.validation_suite_digests.items())
            ),
            "external_benchmark_opened": False,
        }


def _suite(
    seed_start: int,
    count: int,
    length: int,
    capacity: int,
) -> Tuple[BinPackingInstance, ...]:
    return generate_suite(
        ("or_uniform",),
        range(seed_start, seed_start + count),
        length,
        capacity,
    )


def _choose_comparator(
    candidates: Sequence[OnlineHeuristic],
    incumbent: OnlineHeuristic,
    scout: Sequence[BinPackingInstance],
    fixed_probe: Sequence[BinPackingInstance],
    selection_counts: Mapping[str, int],
) -> Tuple[OnlineHeuristic, ComparatorSelection]:
    unique: Dict[str, OnlineHeuristic] = {}
    for candidate in candidates:
        unique[candidate.name] = candidate
    scores_by_name = {
        name: sum(
            max(
                0,
                pack(instance, incumbent).bin_count
                - pack(instance, candidate).bin_count,
            )
            for instance in scout
        )
        for name, candidate in unique.items()
    }
    incumbent_fingerprint = behaviour_fingerprint(
        incumbent,
        fixed_probe,
    )
    by_fingerprint: Dict[str, OnlineHeuristic] = {}
    score_by_fingerprint: Dict[str, int] = {}
    for name, candidate in unique.items():
        fingerprint = behaviour_fingerprint(candidate, fixed_probe)
        if fingerprint == incumbent_fingerprint:
            continue
        score = scores_by_name[name]
        if (
            fingerprint not in by_fingerprint
            or score > score_by_fingerprint[fingerprint]
        ):
            by_fingerprint[fingerprint] = candidate
            score_by_fingerprint[fingerprint] = score
    if not by_fingerprint:
        raise RuntimeError("no non-incumbent comparator behavior available")
    positive = {
        fingerprint: candidate
        for fingerprint, candidate in by_fingerprint.items()
        if score_by_fingerprint[fingerprint] > 0
    }
    selectable = positive or by_fingerprint
    selected_fingerprint, selected = min(
        selectable.items(),
        key=lambda item: (
            selection_counts.get(item[0], 0),
            -score_by_fingerprint[item[0]],
            item[1].name,
        ),
    )
    return selected, ComparatorSelection(
        selected_name=selected.name,
        selected_behavior_fingerprint=selected_fingerprint,
        prior_selection_count=selection_counts.get(
            selected_fingerprint,
            0,
        ),
        distinct_challenger_behaviors=len(by_fingerprint),
        candidate_scores=scores_by_name,
        scout_instance_ids=tuple(instance.instance_id for instance in scout),
    )


def _ranked_unique_records(
    outcome: AdversaryOutcome,
) -> Tuple[AdversarialSequenceRecord, ...]:
    ordered = sorted(
        outcome.evaluated,
        key=lambda record: (
            record.target_gap,
            record.target_excess,
            record.fitness,
            record.instance.instance_id,
        ),
        reverse=True,
    )
    seen = set()
    result = []
    for record in ordered:
        if record.instance.instance_id in seen:
            continue
        seen.add(record.instance.instance_id)
        result.append(record)
    return tuple(result)


def _motif_variants(
    counterexample: Counterexample,
    *,
    round_index: int,
    config: ThreeIslandCampaignConfig,
) -> Tuple[BinPackingInstance, ...]:
    motif = counterexample.minimized_instance.items
    if len(motif) >= config.length:
        return ()
    variants = []
    for index in range(config.motif_variant_count):
        generated = generate_instance(
            "or_uniform",
            (
                config.base_seed
                + 30_000_000
                + round_index * 100_000
                + index
            ),
            config.length,
            config.capacity,
        )
        width = len(motif)
        available = config.length - width
        if index % 3 == 0:
            start = 0
        elif index % 3 == 1:
            start = available // 2
        else:
            start = available
        items = (
            generated.items[:start]
            + motif
            + generated.items[start + width :]
        )
        variants.append(
            BinPackingInstance(
                instance_id=content_digest(
                    {
                        "kind": "motif_transfer_variant",
                        "round": round_index,
                        "motif": list(motif),
                        "background": generated.instance_id,
                        "position": start,
                    }
                )[:20],
                family="motif_transfer_or_uniform",
                seed=generated.seed,
                capacity=config.capacity,
                items=items,
            )
        )
    return tuple(variants)


def _fresh_multiscale_suites(
    *,
    seed_base: int,
    count: int,
    lengths: Sequence[int],
    capacity: int,
) -> Mapping[int, Tuple[BinPackingInstance, ...]]:
    return {
        length: _suite(
            seed_base + index * 10_000,
            count,
            length,
            capacity,
        )
        for index, length in enumerate(lengths)
    }


def _pooled(
    suites: Mapping[int, Sequence[BinPackingInstance]],
) -> Tuple[BinPackingInstance, ...]:
    return tuple(
        instance
        for length in sorted(suites)
        for instance in suites[length]
    )


def _audit(
    candidate: OnlineHeuristic,
    incumbent: OnlineHeuristic,
    suites: Mapping[int, Sequence[BinPackingInstance]],
) -> Mapping[int, PairedPolicyReport]:
    return {
        length: evaluate_paired_policy(candidate, incumbent, suite)
        for length, suite in suites.items()
    }


def _select_nominated(
    candidates: Sequence[Tuple[int, RoundIslandResult]],
    fallback: SearchProgram,
) -> Tuple[SearchProgram, Optional[int]]:
    passed = [
        (round_index, result)
        for round_index, result in candidates
        if result.replication_nominated
    ]
    if not passed:
        return fallback, None
    round_index, result = max(
        passed,
        key=lambda item: (
            -item[1].pooled_audit_delta,
            item[1].audit_wins - item[1].audit_losses,
            -item[1].audit_losses,
            -item[1].search.best.program.complexity,
            -item[0],
        ),
    )
    return result.search.best.program, round_index


def run_three_island_campaign(
    config: ThreeIslandCampaignConfig,
    artifact_store: Optional[ArtifactStore] = None,
    progress: Optional[ProgressCallback] = None,
    incumbent_program: Optional[SearchProgram] = None,
) -> ThreeIslandCampaignOutcome:
    incumbent: OnlineHeuristic = (
        incumbent_program
        if incumbent_program is not None
        else literature_heuristics()["funsearch_or_reference"]
    )
    best_fit = baseline_heuristics()["best_fit"]
    fallback: SearchProgram = (
        incumbent_program
        if incumbent_program is not None
        else FunSearchResidualProgram(
            Expression.const(0.0),
            config.residual_scale,
        )
    )
    proposer = StructuredEvolutionProposer()
    rounds: List[CampaignRound] = []
    carried: Dict[str, Tuple[SearchProgram, ...]] = {
        island: () for island in ISLAND_NAMES
    }
    if isinstance(fallback, FunSearchResidualProgram):
        carried["funsearch_ancestry"] = (fallback,)
    elif isinstance(fallback, PriorityProgram):
        carried["de_novo"] = (fallback,)
    elif isinstance(fallback, ActionHybridProgram):
        carried["hybrid"] = (fallback,)
    challenger_pool: List[OnlineHeuristic] = [best_fit]
    comparator_probe = _suite(
        config.base_seed + 70_000_000,
        config.comparator_probe_count,
        config.length,
        config.capacity,
    )
    comparator_selection_counts: Dict[str, int] = {}

    for round_index in range(config.rounds):
        if progress is not None:
            progress(
                "round %d/%d: mining incumbent failures"
                % (round_index + 1, config.rounds)
            )
        round_seed = config.base_seed + round_index * 1_000_000
        scout = _suite(
            round_seed + 10_000,
            config.comparator_scout_count,
            config.length,
            config.capacity,
        )
        comparator, comparator_selection = _choose_comparator(
            challenger_pool,
            incumbent,
            scout,
            comparator_probe,
            comparator_selection_counts,
        )
        selected_fingerprint = (
            comparator_selection.selected_behavior_fingerprint
        )
        comparator_selection_counts[selected_fingerprint] = (
            comparator_selection_counts.get(selected_fingerprint, 0) + 1
        )
        adversary = evolve_adversarial_sequences(
            AdversaryConfig(
                seed=round_seed + 101,
                evaluation_budget=config.adversary_budget_per_round,
                initial_population=config.adversary_initial_population,
                length=config.length,
                capacity=config.capacity,
                minimum_item=20,
                maximum_item=100,
            ),
            incumbent,
            comparator,
        )
        ranked_records = _ranked_unique_records(adversary)
        positive_records = tuple(
            record for record in ranked_records if record.target_gap > 0
        )
        minimized = (
            minimize_policy_gap(
                positive_records[0].instance,
                comparator,
                incumbent,
            )
            if positive_records
            else None
        )
        motif_variants = (
            _motif_variants(
                minimized,
                round_index=round_index,
                config=config,
            )
            if minimized is not None
            else ()
        )
        positive_motif_variants = tuple(
            instance
            for instance in motif_variants
            if (
                pack(instance, incumbent).bin_count
                > pack(instance, comparator).bin_count
            )
        )
        repair_candidates = (
            positive_motif_variants
            + tuple(record.instance for record in positive_records)
            + tuple(record.instance for record in ranked_records)
        )
        repair = []
        repair_seen = set()
        for instance in repair_candidates:
            if instance.instance_id in repair_seen:
                continue
            repair_seen.add(instance.instance_id)
            repair.append(instance)
            if len(repair) == config.repair_instance_count:
                break
        if len(repair) < config.repair_instance_count:
            raise RuntimeError("adversary did not yield enough repair cases")
        repair_tuple = tuple(repair)
        guard_suites = _fresh_multiscale_suites(
            seed_base=round_seed + 200_000,
            count=config.guard_seed_count_per_length,
            lengths=config.validation_lengths,
            capacity=config.capacity,
        )
        audit_suites = _fresh_multiscale_suites(
            seed_base=round_seed + 400_000,
            count=config.audit_seed_count_per_length,
            lengths=config.validation_lengths,
            capacity=config.capacity,
        )
        guard = _pooled(guard_suites)
        island_results: Dict[str, RoundIslandResult] = {}
        for island_index, island in enumerate(ISLAND_NAMES):
            if progress is not None:
                progress(
                    "round %d/%d: searching %s island"
                    % (round_index + 1, config.rounds, island)
                )
            search = run_island_search(
                IslandSearchConfig(
                    island=island,
                    seed=round_seed + 600_000 + island_index * 10_000,
                    evaluation_budget=config.candidate_budget_per_island,
                    initial_random=config.initial_random_candidates,
                    residual_scale=config.residual_scale,
                    guard_mean_delta_ceiling=0.0,
                    guard_regression_fraction_ceiling=(
                        config.guard_regression_fraction_ceiling
                    ),
                    guard_max_regression=1,
                ),
                repair_tuple,
                guard,
                incumbent,
                carried_programs=carried[island],
                proposer=proposer,
            )
            audit_reports = _audit(
                search.best.program,
                incumbent,
                audit_suites,
            )
            wins = sum(report.wins for report in audit_reports.values())
            losses = sum(report.losses for report in audit_reports.values())
            pooled_audit_delta = sum(
                sum(report.deltas)
                for report in audit_reports.values()
            )
            maximum_audit_regression = max(
                report.maximum_regression
                for report in audit_reports.values()
            )
            passed = losses == 0 and wins >= config.minimum_audit_wins
            if losses:
                reason = "rejected: %d untouched-audit regressions" % losses
            elif wins < config.minimum_audit_wins:
                reason = "rejected: no untouched-audit improvement"
            else:
                reason = "promoted: %d wins and zero losses" % wins
            nominated = (
                pooled_audit_delta < 0
                and wins >= config.nomination_minimum_audit_wins
                and wins > losses
                and maximum_audit_regression
                <= config.nomination_maximum_regression
            )
            if pooled_audit_delta >= 0:
                nomination_reason = (
                    "not nominated: pooled audit delta %d"
                    % pooled_audit_delta
                )
            elif wins < config.nomination_minimum_audit_wins:
                nomination_reason = (
                    "not nominated: %d wins below minimum %d"
                    % (wins, config.nomination_minimum_audit_wins)
                )
            elif wins <= losses:
                nomination_reason = (
                    "not nominated: wins %d do not exceed losses %d"
                    % (wins, losses)
                )
            elif (
                maximum_audit_regression
                > config.nomination_maximum_regression
            ):
                nomination_reason = (
                    "not nominated: maximum regression %d exceeds %d"
                    % (
                        maximum_audit_regression,
                        config.nomination_maximum_regression,
                    )
                )
            else:
                nomination_reason = (
                    "nominated for frozen replication: audit delta %d, "
                    "wins/losses %d/%d"
                    % (pooled_audit_delta, wins, losses)
                )
            result = RoundIslandResult(
                search=search,
                audit_by_length=audit_reports,
                promotion_passed=passed,
                promotion_reason=reason,
                deployed_program=search.best.program if passed else fallback,
                replication_nominated=nominated,
                nomination_reason=nomination_reason,
            )
            island_results[island] = result
            carried[island] = tuple(
                record.program
                for record in sorted(
                    search.archive,
                    key=lambda record: record.rank,
                    reverse=True,
                )[: config.carry_elites_per_island]
            )
            challenger_pool.append(search.best.program)
            if progress is not None:
                progress(
                    "round %d/%d: %s repair Δ %.3f, guard Δ %.3f, "
                    "audit W/L %d/%d — %s"
                    % (
                        round_index + 1,
                        config.rounds,
                        island,
                        search.best.repair_report.mean_delta,
                        search.best.guard_report.mean_delta,
                        wins,
                        losses,
                        (
                            "PROMOTE"
                            if passed
                            else "NOMINATE"
                            if nominated
                            else "fallback"
                        ),
                    )
                )
        suite_digests: Dict[str, str] = {}
        if artifact_store is not None:
            suite_digests["repair"] = artifact_store.put(
                "m32_round_repair_suite",
                [instance.as_dict() for instance in repair_tuple],
            )
            suite_digests["guard"] = artifact_store.put(
                "m32_round_guard_suite",
                [instance.as_dict() for instance in guard],
            )
            suite_digests["audit"] = artifact_store.put(
                "m32_round_untouched_audit_suite",
                [
                    instance.as_dict()
                    for instance in _pooled(audit_suites)
                ],
            )
        round_result = CampaignRound(
            round_index=round_index,
            comparator_selection=comparator_selection,
            adversary=adversary,
            minimized_counterexample=minimized,
            motif_variants_tested=len(motif_variants),
            motif_variants_with_positive_gap=len(
                positive_motif_variants
            ),
            positive_adversary_count=len(positive_records),
            repair_instance_ids=tuple(
                instance.instance_id for instance in repair_tuple
            ),
            islands=island_results,
            suite_digests=suite_digests,
        )
        rounds.append(round_result)
        if progress is not None:
            progress(
                "round %d/%d complete: comparator %s, positive failures "
                "%d/%d, motif transfers %d/%d"
                % (
                    round_index + 1,
                    config.rounds,
                    comparator.name,
                    len(positive_records),
                    len(adversary.evaluated),
                    len(positive_motif_variants),
                    len(motif_variants),
                )
            )

    island_finalists: Dict[str, SearchProgram] = {}
    island_source_rounds: Dict[str, Optional[int]] = {}
    for island in ISLAND_NAMES:
        program, source_round = _select_nominated(
            tuple(
                (round_.round_index, round_.islands[island])
                for round_ in rounds
            ),
            fallback,
        )
        island_finalists[island] = program
        island_source_rounds[island] = source_round

    finalist_island = max(
        ISLAND_NAMES,
        key=lambda island: (
            sum(
                round_.islands[island].audit_wins
                for round_ in rounds
                if round_.islands[island].replication_nominated
            ),
            -sum(
                round_.islands[island].pooled_audit_delta
                for round_ in rounds
                if round_.islands[island].replication_nominated
            ),
            -island_finalists[island].complexity,
        ),
    )
    finalist = island_finalists[finalist_island]
    finalist_source_round = island_source_rounds[finalist_island]
    validation_suites = _fresh_multiscale_suites(
        seed_base=config.base_seed + 90_000_000,
        count=config.validation_seed_count_per_length,
        lengths=config.validation_lengths,
        capacity=config.capacity,
    )
    validation = _audit(finalist, incumbent, validation_suites)
    island_validation = {
        island: _audit(program, incumbent, validation_suites)
        for island, program in island_finalists.items()
    }
    best_fit_validation = _audit(best_fit, incumbent, validation_suites)
    pooled_delta = sum(sum(report.deltas) for report in validation.values())
    total_losses = sum(report.losses for report in validation.values())
    improving_lengths = sum(
        report.mean_delta < 0 for report in validation.values()
    )
    breakthrough_reasons = (
        "strict pooled improvement versus the optimization incumbent"
        if pooled_delta < 0
        else "no strict pooled improvement versus the optimization incumbent",
        "zero validation regressions"
        if total_losses == 0
        else "%d validation regressions" % total_losses,
        "improvement at %d/%d tested scales"
        % (improving_lengths, len(validation)),
    )
    provisional_breakthrough = (
        pooled_delta < 0
        and total_losses == 0
        and improving_lengths >= min(2, len(validation))
    )
    replication_recommended = (
        pooled_delta < 0
        and all(
            report.mean_delta <= 0.0
            for report in validation.values()
        )
        and sum(report.wins for report in validation.values())
        > sum(report.losses for report in validation.values())
        and max(
            report.maximum_regression
            for report in validation.values()
        )
        <= config.nomination_maximum_regression
    )
    validation_suite_digests: Dict[str, str] = {}
    if artifact_store is not None:
        for length, suite in validation_suites.items():
            validation_suite_digests[str(length)] = artifact_store.put(
                "m32_untouched_final_validation_suite",
                [instance.as_dict() for instance in suite],
            )
    if progress is not None:
        progress(
            "final untouched validation: island %s, pooled Δ %d, "
            "losses %d, improved scales %d/%d"
            % (
                finalist_island,
                pooled_delta,
                total_losses,
                improving_lengths,
                len(validation),
            )
        )
    return ThreeIslandCampaignOutcome(
        config=config,
        proposer_name=proposer.name,
        incumbent_program=fallback,
        rounds=tuple(rounds),
        finalist_island=finalist_island,
        finalist_program=finalist,
        finalist_source_round=finalist_source_round,
        validation_by_length=validation,
        island_finalists=island_finalists,
        island_validation_by_length=island_validation,
        best_fit_validation_by_length=best_fit_validation,
        provisional_breakthrough=provisional_breakthrough,
        replication_recommended=replication_recommended,
        breakthrough_reasons=breakthrough_reasons,
        validation_suite_digests=validation_suite_digests,
    )
